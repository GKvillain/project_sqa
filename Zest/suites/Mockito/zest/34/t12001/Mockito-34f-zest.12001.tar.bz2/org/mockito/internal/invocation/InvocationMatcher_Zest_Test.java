package org.mockito.internal.invocation;
import org.junit.Test;
import static org.junit.Assert.*;
public class InvocationMatcher_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 0, "\udae9\ude96\udace\udc6d\udb86\udc41\udbc3\uddf9\udb0d\udea4\udbc1\uddf8\ud931\udd52\udb8f\uddf0\udaf9\uddfb\ud8e3\udfc7\udaff\ude0b\udbb0\ude29\udbe9\udefb\uda19\udca1", "\u3fae\ub48a", "\udbff\uddba\udacf\udf48\ud961\udd6c\uda39\udc68\udbc4\udf51\ud834\udf57\udba7\udf47\udbd4\udc6b\ud8ef\udf24",
        46, 38597, -855720958, -6595330474869369948L, 32026L, true, true, (char) 18331, (char) 17375,
        Double.longBitsToDouble(0x3fd4cdf2f8e9c45eL), Double.longBitsToDouble(0x3fe3c78f4518a0fbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 0, "\udae9\udee9\udace\udc6d\udb86\udc41\ud903\udeba\u9e81\udbc1\uddf8\ud931\udd52\udb8f\uddf0\udaf9\uddfb\ud8e3\udfc7\udaff\ude0b\udbb0\ude29\udbe9\udefb\uda19\udca1", "\u3fae\ub48a", "\udbff\uddba\udacf\udf48\ud961\udd6c\uda39\udc68\udbc4\udf51\ud834\udf57\udba7\udf47\udbd4\udc6b\ud8ef\udf24",
        46, 38597, -855720958, -6595330474869369948L, 32026L, true, true, (char) 18331, (char) 17375,
        Double.longBitsToDouble(0x3fd4cdf2f8e9c45eL), Double.longBitsToDouble(0x3fe3c78f4518a0fbL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 0, "\udace\udd11\udace\udc6d\udb85\udffb\udbc3\uddf9\udb0d\udea4\udbc1\uddf8\ud931\udd52\udb8f\uddf0\udaf9\uddfb\ud8e3\udfc7\udaff\ude0b\ud87a\udc2d\u1630\uda19\udca9", "\u3fae\u45e5", "\udbff\uddba\udacf\udf48\ud961\udd6c\uda39\udc68\udbc4\udf51\ud834\udf57\ud8b1\ude4b\udbd4\udc6b\ud8ef\udf24",
        46, 38597, -855720958, -6595330474869369948L, 32026L, true, true, (char) 60265, (char) 17375,
        Double.longBitsToDouble(0x3fa56f97c74e22f0L), Double.longBitsToDouble(0x3fb0a7fa0fab8fd8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 0, "\udae9\ude96\udace\udc6d\uda65\udd40\ud8d0\uddf9\ud976\udc5a\uda0e\udf14\ud931\uddd9\ud939\udee4\udaf9\uddfb\ud8e3\udfc7\uda78\udd48\udbb0\ude29\udbe9\udefb\uda19\udca1", "\u3fa5\ub48a", "\udbff\uddba\udacf\udf48\ud961\udd6c\uda39\udc68\udbc4\udf51\ud834\udf57\udba7\udf47\udbd4\udc6b\ud8ef\udf24",
        46, 84621, -79709182, -348189659666652889L, 32026L, true, true, (char) 18331, (char) 17375,
        Double.longBitsToDouble(0x3fd4cdf2f8e9c45eL), Double.longBitsToDouble(0x3fe3c78f4518a0fbL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 2, 0, "\udae9\ude96\udace\udc6d\udba7\udc71\udbc3\uddf9\udb0d\udea4\udbc1\uddf8\ud931\udd52\udb8f\uddf0\ud957\udd0a\udbcb\udfc8\u3a75\udbb0\ude29\ud943\udf28\uda19\udca1", "\u3fae\u4e3b", "\ud80f\udffa\udbb6\uddc7\udabb\udfec\uda39\udc68\udbc4\udf51\ud834\udf57\udba7\udf47\udbd4\udc6b\ud8ef\udf24",
        46, 38597, -863713278, -6595330474869369948L, 32026L, true, true, (char) 18331, (char) 17375,
        Double.longBitsToDouble(0x3fd4cdf2f8e9c45eL), Double.longBitsToDouble(0x3fe3c78f4518a0fbL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 9, "\uda09\udfa6\udace\udc06\udb00\ude7e\udbc3\uddf9\udb0d\udea4\udbc1\uddf8\ud931\udd52\udb8f\uddf0\udaf9\uddfb\ud8e3\udfc7\udaff\ude0b\udbb0\ude29", "\u1845\u98c2\u3fae", "\u084b\ud9c5\udcdc\udaa7\ude32\ud961\udd6c\uda39\udc68",
        19, 4871, -770749955, 157424000989732850L, -83163L, false, false, (char) 31454, (char) 63516,
        Double.longBitsToDouble(0x3fe4f368d314af49L), Double.longBitsToDouble(0x3fa0ae0aa7ccca40L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 8, 8, "\ud93f\udd80\udace\udc6d\ud964\udc38\udb28\udeaa\ud99d\udc4b\ud847\udf6e\ud9a7\uded1\udb24\udfdf\udaef\udcbd\ud9ce\udee8\udb91\ude95\udb5f\udccc\udb78\udc66\ud938\udde2\udb84\udd82\udb02\uded5\ud971\uddb8\ud89d\uddff\ud8d3\udd08\ud93e\ude79", "\u469b\u0cb1", "\uda47\udf58\ud936\udeee\u0ad9\uda00\uddfd\uda69\udc3e\udba1\udea2\ud845\udcdb\udbca\udc32\udb8d\udf65\ud9e6\uddfb\ud828\udf70\udbcf\ude90\udbaa\ude92\ud89e\udf8a\uda60\udc4f\ud81e\udfa7\udb2e\udc52",
        48, 96858, -1577113660, -779729122854349960L, 77637L, true, false, (char) 27569, (char) 54173,
        Double.longBitsToDouble(0x3fe34fb8c31acef6L), Double.longBitsToDouble(0x3fde4099ea356eeeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 2, 6, "\udb40\udee9\ud90c\udd63\ud82e\ude0f\udae7\udda7\ud83b\ude5c\ud906\udfe0\uda59\udebd\udb99\udc71\udbdc\udc6b\ud8e4\udc2b\udaff\ude0b\ud87a\udc2d\u1630\uda19\udca9\u031b\ud893\udd37\uda52\ude8d\udb1e\udde3", "\u0a24\u95b2\u1240\u9d9f\u2188\u7527\u3894\ud3c5\uc0ac", "\ud821\udc79\ud98f\udd38\uda3c\udd0a",
        55, 73638, -1066487147, -9063756796963616583L, -36011L, false, false, (char) 5579, (char) 27253,
        Double.longBitsToDouble(0x3fe2596bfda200b2L), Double.longBitsToDouble(0x3fd73a1d06c7181eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 6, "\uda09\udfa6\udace\udc06\udb35\udc7e\udbc3\uddf9\udb0d\udea4\udbc1\uddf8\ud931\udd5a\udb8f\uddf0\ud814\udffd\ud8e3\udfc7\ud90e\ude73\udbb0\ude29", "\u2032\u98c2\u3fae", "\udaba\udc46\ud9c5\udcdc\udaa7\ude32\ud961\udd6c\udb04\udc8c",
        20, 253, -770749988, 157424000989732850L, -83163L, false, false, (char) 31454, (char) 63516,
        Double.longBitsToDouble(0x3fe4f368d314af49L), Double.longBitsToDouble(0x3fa0ae0aa7ccca40L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 0, "\udae9\ude96\udace\udc6d\udb86\udc41\ud85a\udcc5\udb9e\udd55\udbc5\udec8\ud931\udd52\ud9d3\ude22\udaf9\uddfb\ud8e3\udfc7\udaff\ude0b\udbb0\ude29\udbe9\udefb", "\ubd49\ua141", "\u084b\udbff\uddba\udacf\udf48\ud961\udd6c\uda39\udc68\udbc4\udf51\ud834\udf57\udba7\udf47\udbd4\udc6b\uda21\udcec\u7d4c\udbab\udc01\ud9ec\udd65\ud862\udc7b\udbf2\ude11\udbbc\udc55\ud840\udd25\uda15\udc87",
        44, 19192, -500202164, -1015389695536031112L, 44146L, true, true, (char) 50698, (char) 64253,
        Double.longBitsToDouble(0x3fd4c894f87e1262L), Double.longBitsToDouble(0x3fecb6973ae4721aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.invocation.InvocationMatcher|captureArgumentsFrom|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getInvocation||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getLocation||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getMatchers||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getMethod||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|hasSameMethod|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|hasSimilarMethod|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|matches|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|safelyArgumentsMatch|[Ljava.lang.Object;|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|toString||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|toString|org.mockito.internal.reporting.PrintSettings|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "C|org.mockito.internal.invocation.InvocationMatcher|<init>|org.mockito.internal.invocation.Invocation,java.util.List",
    "C|org.mockito.internal.invocation.InvocationMatcher|<init>|org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|captureArgumentsFrom|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
