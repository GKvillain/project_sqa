package org.mockito.internal.configuration.injection;
import org.junit.Test;
import static org.junit.Assert.*;
public class FinalMockCandidateFilter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 1, 0, 0, "\ud82c\udfc3\uda16\uddf2\ud987\uddb9\udbeb\udc95", "\uc2da\u5112", "\ud8c0\udf7c\udb3d\ude61",
        26, 81305, -553253924, 3888910131555953899L, 56270L, true, false, (char) 6684, (char) 49407,
        Double.longBitsToDouble(0x3fec4f63b6501b73L), Double.longBitsToDouble(0x3fe5f178a6ef42c7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 1, 0, 0, "\ubed7\uda16\uddf2\ud97b\udedc\udbeb\udc95", "\uc2da\u5112", "\ud8c0\udf7c\udb3d\ude61",
        26, -767, -553254144, 3888910131555953899L, 56270L, true, false, (char) 14619, (char) 7096,
        Double.longBitsToDouble(0x3fec4f63b6501b73L), Double.longBitsToDouble(0x3fe5f178a00042c7L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 1, 1, 0, 0, "\ud82c\udfc3\uda16\uddf2\ud987\uddb9\udbea\udfcc", "\u0192\u5112", "\ud8c0\udf7c\udb0d\udf05",
        26, 81305, -553253924, 3888910131555953899L, 56270L, true, false, (char) 6684, (char) 49407,
        Double.longBitsToDouble(0x3fec4f63b6501b73L), Double.longBitsToDouble(0x3fe5f178a00000c7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\000", "\udbb6\udfdd",
        47, 42074, -998646170, -2835564408037638096L, 71457L, true, true, (char) 22803, (char) 0,
        Double.longBitsToDouble(0x3d54000000000000L), Double.longBitsToDouble(0x3fe0000000270042L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 1, 1, 0, 1, "\ud82c\udfc3\uda16\uddf2\udb2f\udf2e\udbeb\udc95", "\uc29d\u5112", "\ud8c1\udc04\udb3d\ude61",
        28, 68401, -553254023, 1006606370038836459L, 56270L, true, false, (char) 6684, (char) 49407,
        Double.longBitsToDouble(0x3fec4f63b1390f73L), Double.longBitsToDouble(0x3fd49ce3670002a2L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 1, 0, 1, "\ud803\udd9e\uda16\uddf2\ud8cb\udd9b\udb74\uddc1\udb26\udf6b\udbb6\udfdd\u7bbf\u663b\udbf2\udee3\ud920\udee0\ud8c0\udf7c\udb3d\ude61\udba3\udcfe\udb8a\udd1b\ud9de\uddea\udbdf\udda6\ud80d\udc66", "\u55ca\ub542\u9c8f\u7c12\u7e1c\ub154\u99ff\u2032\u8a5f\u97cc\ud4c4\ud269\u1cd4\u0e9c\u9f6b\u034c\u4d98\u39d5\ucd0a\uac0d:\u48ac\ua0c6\u6939\u8e15", "\udb8e\udd60\udab2\udcc0\ud825\udf92\uda3a\ude6d\uda85\ude5d\u55cf\ud88a\udefb",
        1, 21302, 54448415, 3739522732065322766L, 16418L, false, false, (char) 23361, (char) 9706,
        Double.longBitsToDouble(0x3fd4083b1ab4b7ceL), Double.longBitsToDouble(0x3fb4b00e7e770c10L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=new org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda61\udc1d\uda16\uddf2\ud987\uddb9\udbeb\udc95", "\uc2da\u5112", "\ud88d\udf0c\udb3d\ude1d",
        41, 81305, -553253924, 3888910131555953899L, 56270L, true, false, (char) 61754, (char) 18853,
        Double.longBitsToDouble(0x3fead763b6506864L), Double.longBitsToDouble(0x3fe5f178a0ef42c7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udbf2\udec5\uda16\udd64\ud987\uddb9\udbeb\udc95", "\uc2da\u815e", "\ud8c0\udf7c",
        49, 801, 1480035305, -2376207509058212055L, -38071L, false, false, (char) 47209, (char) 27675,
        Double.longBitsToDouble(0x3fedc52a3b4e3f95L), Double.longBitsToDouble(0x3fe280db9ebe2f14L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 1, 0, 0, "\ud9a7\udd45\ud820\udc4d\ud987\uddb9\udbeb\udc95", "\uc2da\u5112", "\ud8c0\udf7c\udb3d\ude61",
        26, 81305, -553253924, 3888910131555953899L, -49001L, false, true, (char) 3129, (char) 33219,
        Double.longBitsToDouble(0x3fe5f178a6ef42c7L), Double.longBitsToDouble(0x3fe60b39be77b9beL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud9fb\udf8a\uda18\udf41\ud97b\udedc\udbeb\udc95\udb37\ude4ed\u7bbf\u663b", "\uaff1\uac98", "\ud9de\udd0e\ud8aa\ude57\ud823\udd8e\ud95e\ude99\ud9e7\ude15\udb4a\ude2b\u38c9\ud8ba\ude91\ud87b\udd27\ud8e8\udd16\ud9c8\udead\udaf3\ude38\uf038\ud832\ude67\u63f5",
        46, 49597, -1165890850, 8934301276188106429L, -41176L, false, false, (char) 10921, (char) 9791,
        Double.longBitsToDouble(0x3fe53b4450c8bf83L), Double.longBitsToDouble(0x3fea49b550309b75L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$2:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$2:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud9fb\udf8a\ud8c3\udf78\ud97b\udedc\udbeb\udc95\ud8cc\udc79,\u7bbf\u663b", "\uaff1\uac98", "\ud840\udf94\ud8ba\udfae\ud823\udd8e\ud95e\ude99\ud9e7\ude15\udb4a\ude2b\u38c9\ud8ba\ude91\ud87b\udd27\ud8e8\udd16\ud9aa\udd11\ud8b2\udd18\uf023\ud832\ude67\ud936\udc42",
        -2, 49597, -1165909839, 8934301276188106429L, -41176L, true, true, (char) 23548, (char) 65387,
        Double.longBitsToDouble(0x3fe53b4450c8bf83L), Double.longBitsToDouble(0x3fea49b550309b75L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.FinalMockCandidateFilter$2:@? |this=org.mockito.internal.configuration.injection.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 1, 0, 0, "\ud9fb\udf5d\ud9ad\ude6c\ud9cb\udd7a\uda82\udfc4\ud8cc\udc79,\u7bbf\uda6c\udfa4\udbf2\udf77\ud808\udf0a", "\u3309\u6b0b\u06b9\u4877\u92ea\u58af\u303f\u4b88", "\uda92\udd22",
        50, 66146, -875867970, 5913296478016446770L, -27626L, true, true, (char) 8806, (char) 21434,
        Double.longBitsToDouble(0x3fdc81bcf3a7c858L), Double.longBitsToDouble(0x3fd2d1ecf52339b4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.configuration.injection.FinalMockCandidateFilter|filterCandidate|java.util.Collection,java.lang.reflect.Field,java.lang.Object|new:org.mockito.internal.configuration.injection.FinalMockCandidateFilter:",
    "C|org.mockito.internal.configuration.injection.FinalMockCandidateFilter|<init>|",
    "M|org.mockito.internal.configuration.injection.FinalMockCandidateFilter|filterCandidate|java.util.Collection,java.lang.reflect.Field,java.lang.Object|new:org.mockito.internal.configuration.injection.FinalMockCandidateFilter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
