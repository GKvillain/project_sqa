package org.mockito.internal.configuration.injection.filter;
import org.junit.Test;
import static org.junit.Assert.*;
public class FinalMockCandidateFilter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 4, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\ud967\ude4c\uda3c\ude89\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud8e4\ude34\ud967\udf01\uda6e\ude16\uda4e\udcdd", "\uaf0f\u80b5\u964b", "\ud8b6\udf35",
        48, 37585, 1644790877, -95005196252443122L, 9248L, false, true, (char) 56323, (char) 11090,
        Double.longBitsToDouble(0x3fee14981af18f3aL), Double.longBitsToDouble(0x3fd5ee6fd4b0b5feL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 4, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbe8\udee3\ud8e5\udf92\uda74\udf0d\udae2\udf6f\udb71\uddd4\ud849\ude12\ud9c2\udf65\udb73\udf28\uda3c\ude89\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud8e4\ude34\ud9b7\udd5d\ud935\udda0\uda6c\udfdd", "\uaf0f\u2fd2\uc6cb", "\udb9e\udeaa",
        10, 37585, 1270252637, -1956235358428046913L, 9248L, false, true, (char) 28767, (char) 30493,
        Double.longBitsToDouble(0x3feb43ee5056af1cL), Double.longBitsToDouble(0x3febf5bbc5f11f9aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.ArrayList:[private transient sun.util.calendar.BaseCalendar$Date java.util.Date.cdate, private transient long java.util.Date.fastTime] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 10, 5, 4, "\uda0f\udd0c\ud928\udd09\uda73\udf23\udbfc\udd6d\ud8bd\ude92\ud82c\ude0d\ud972\udd57\ud8af\udeb0\udbd8\udecb\udb01\udfea\uccb1\uda3c\udefa\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud800\udfc3\ud967\udf01\udb4b\udc44\ud9b5\udf94", "\u120a\u7313\u9655\u8ae1", "\udbaf\udc1c\ud845\udff9\uc224\ud838\udd33\ud9d3\ude25\ud9e3\udc14\ud9f6\uddc5\ud8a3\udd63\udbbf\udddd\udafa\udcad",
        52, 72754, 1526677854, -3219376265006538040L, -79515L, false, false, (char) 16567, (char) 64086,
        Double.longBitsToDouble(0x3fef6c563b5b6b5bL), Double.longBitsToDouble(0x3fd30e39ae657798L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 4, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\ud967\ude4c\uda3c\ude89\ud83b\udfc2\ud951\udce9\ud8f7\udedc\ud8e4\ude34\ud967\udf01\uda6e\ude16\uda4e\udcdd", "\uaf19\u80b5\u964b", "\ud8b6\udf02\ub4fc\udb4f\udec0\ud92b\udc98\ud976\udccb",
        16, 36228, -278549824, 5720494128085044385L, 93598L, true, false, (char) 10332, (char) 54615,
        Double.longBitsToDouble(0x3fb544a8b131ebf8L), Double.longBitsToDouble(0x3fe127777e532803L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 4, "\uda9a\udd6a\uda70\udcb5\ud829\udf1b\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\ud967\ude4c\uda3c\ude89\ud888\udce7\udb24\udded\ud8f7\udedc\ud8e4\ude34\ud940\udde9\ud9bf\udfca\uda86\ude6c", "\uaf0f\u80b5\u964b", "\ud8b6\udf35",
        48, 37585, 1644790877, -95005196252435954L, 9248L, false, true, (char) 56471, (char) 11090,
        Double.longBitsToDouble(0x3fee14981af18f3aL), Double.longBitsToDouble(0x3fd5ee6fd4b0b5feL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 5, 14, 4, "\uda9a\udd6a\uda70\udcb5\udbfb\udee0\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbb1\udf46\uda39\udce1\ud967\ude4c\uda3c\ude89\ud9f3\uddb5\udb24\udded\ud8f7\udedc\udb1e\udf12\ud975\udcc6\uda6e\ude16\uda4e\udcdd", "\uaf0f\u80b5\u964b", "\ud8b6\udf35",
        48, 37585, 1644790877, -95005196252443122L, 9248L, false, true, (char) 56323, (char) 44113,
        Double.longBitsToDouble(0x3fee6475aaf18f41L), Double.longBitsToDouble(0x3fd5ee6fd4b0b5feL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 4, "\ud9fd\udc1b\u01cd\uda73\udedc\udbfc\udd6d\ud8bd\ude92\ud988\udf8a\udac2\udd5f\udbde\udd11\udbd8\udecb\udbab\udddd\ud967\ude4c\uda3c\ude89\uda3a\udcfb\udb24\ude4e\ud8f7\udedc\ud8e4\ude34\ud809\uddb1\uda6e\ude0b\ud93a\udd34", "\uae4d\u80b5", "\ud964\udf29\ud8ba\udf37\udbb8\udd81\ud83c\udfc1\uc224\ud838\udd33\udb38\udd17\ud9e3\udca9\ud9f6\uddc5\uda7d\ude45\udaa3\udc37\udaf9\udc9b",
        13, 25385, -416986643, -875308295303452677L, -85646L, false, false, (char) 46811, (char) 56808,
        Double.longBitsToDouble(0x3feeb5fa6b913eb5L), Double.longBitsToDouble(0x3fe05f0508090625L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 14, 14, 4, "\udb50\udd04\udab7\uddad\uda73\udedc\uda98\uddcf\ud8bd\udeeb\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\udb7c\udef7\udb74\ude1a\ud9df\udddd\udb24\udded\ud8f7\udedc\ud8e4\ude34\ud967\udf01\uda6e\ude16\uda4e\udcdd", "\uaf0f\u80b5\u964b", "\ud8b6\udf35",
        48, 37585, -422345635, 316683229848924978L, 9248L, false, true, (char) 56323, (char) 60497,
        Double.longBitsToDouble(0x3fee6ddb0af18f3aL), Double.longBitsToDouble(0x3fd5ee6fd4b0b5feL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 14, 4, "\uda9a\udd6a\uda70\udcb5\uda94\ude2b\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\ud967\ude4c\uda3c\ude89\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud8e4\ude34\ud967\udf01\uda6e\ude16\uda4e\udcdd", "\uaf0f\u80b5\u964b", "\ud8b6\udf35",
        48, 37585, 1644790877, -95005196252443122L, 9248L, false, true, (char) 56323, (char) 11090,
        Double.longBitsToDouble(0x3fee14981af18f3aL), Double.longBitsToDouble(0x3fd5ee6fd4b0b5feL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 10, 14, 4, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda67\udf10\udac2\udd5f\ud8af\udeb0\udbc3\uddcb\uda39\udd43\ud967\ude4c\uda3c\ude89\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud873\udd90\ud9ba\udcbb\ud9b0\udd0d\uda4e\uddc9", "\uaf0f\u80b5\u964b", "\uae51",
        48, 37585, 1644790877, -95005196252443122L, 9248L, false, true, (char) 56323, (char) 11090,
        Double.longBitsToDouble(0x3fb4e4c0d78f5108L), Double.longBitsToDouble(0x3fd5ee6fd4b0b5feL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=java.util.ArrayList:[] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 2, 10, 10, 4, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\ude76\udbd8\udecb\uda39\udd43\ud967\ude4c\uda3c\ude89\ud9f3\uddb5\udb51\udded\ud822\udfc1\ud8e4\ude34\ud967\udf01\uda6e\ude16\uda4e\udcdd", "\uaf0f\u80b5\u964b", "\ud8b6\udf35",
        48, 37585, 1644790877, -95005196252443122L, 9248L, false, true, (char) 56323, (char) 11090,
        Double.longBitsToDouble(0x3fee14981cc3fc3aL), Double.longBitsToDouble(0x3fd7a617c3f01db2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 5, 0, 15, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda8a\udc0d\udaa9\udd88\ud8af\ude87\udb19\udc4c\uda48\udd60\ud967\ude4c\ud815\udef5\ud9f3\udd66\ud9e7\udc2e\ud800\udd23\ud8ec\udd9b\ud967\udf01\uda6e\ude16\uda4e\udcdd", "\uaf0f\u858d\u964b\u8ae1\u60ea\u13cc\ua634\uaf32\ua08e\ucfb6\u175b\uc191\u6712\u8f26\ud237\u2f69\u63b4\ucd4c\u9537\u706e\uaef6\u81d9\u167a\ua393\u2bbb\u2f97\uc51c\u3bfd\u70b6\u1c3a\u21c5\u3891\ub937\u5e24\u02a7\u419a\u8a40\ub76d\ucc5c\u9798\u7be1", "\ud855\udd3d\u7b6c",
        13, 4778, -595111782, -5056326795586914634L, 1342L, true, true, (char) 28711, (char) 62527,
        Double.longBitsToDouble(0x3fc06fe0138fdb58L), Double.longBitsToDouble(0x3fefd5c838ceb1b1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.filter.TypeBasedCandidateFilter:@?\012",
        Z.run(T, 1, 7, 13, 1, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda7b\udc0d\udac2\udd5f\ud8af\udeb0\udb7b\udfdd\uda39\udd16\ud967\ude4c\ud822\udfbb\ud9f3\udd1f\udb24\udded\ud8f7\udedc\u95f6\ud819\udd99\uda54\udfd6\uda4e\udd22\ud921\udcf5\ud8e5\udc13\ud905\udeed\udb35\ude09\ud896\udded\udb59\udf09\ud974\ude1c\ud9ae\ude91\udbc9\udd5d\udbe7\uddfa\uc224\ud91a\udfe5\uda5a\udc6c\udaf3\udd1c", "\ud237\uc5ed\u221a\ud486\u7e6e\u45c0\u6ad4\u083e\u8218\u397e\u7384\u3608\u80f3\u237e\ub692\u06b4\ud0e0\u736c\uc65b\u7ba3\u766e\u1b48\u433b\u9dac\ud560\u26b0\u0dcf\ua88e\u9932\ub121\ub613\u3bfe\ub3c8\u31b0\u50e3\u2a34\u9b03", "\ud8fa\ude30\ud8c0\udebc\udbff\udf2a\ud89e\udf3a\ud8c3\udc8e",
        -4, 61023, -628451647, -7337596768171261230L, -7489L, false, true, (char) 60150, (char) 54375,
        Double.longBitsToDouble(0x3fa8c98939c93030L), Double.longBitsToDouble(0x3fdae23cd9551a1eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 9, 14, 4, "\ud866\udd10\udb6a\udcb2\uda73\udedc\udbfc\udd6d\ud8d7\udc4b\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\ud967\ude4c\ud9bb\ude07\ud88a\udd1a\udb4c\udded\ud9c2\udd81\uda48\udcc4\ud8b7\udcc5\uda6e\ude25\uda4e\udcdd", "\u7ff6\u80b5\u964b", "\ud8b6\udf35",
        49, 37585, 1644790877, -94880865539158514L, 14034L, true, false, (char) 29290, (char) 54409,
        Double.longBitsToDouble(0x3fbd1d9d42420458L), Double.longBitsToDouble(0x3fdd6f374c17e430L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=new org.mockito.internal.configuration.injection.filter.NameBasedCandidateFilter:@?\012",
        Z.run(T, 2, 12, 6, 1, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\ud9ab\ude39\ud9f9\ude9d\udb56\udd86\ud81e\ude59\ud8af\udeb0\udbd8\udecb\uda39\udcce\ue4b5\uda3c\ude89\u0ddf\udb20\udde2\ud9e8\udfe2\udb16\udfe0\ud972\uddad\ud873\uded8\uda59\udd83", "\u3545\u5a74\u19af\ubb25\ud564", "\ud960\udfed\ud849\ude30\ud838\udd33\udac7\udfaf\uda21\udff6\ud9fc\udc15\udb2f\udfa8\ud87b\ude51\u8140",
        31, 72801, -1544928930, -6641921338965023014L, 22309L, true, false, (char) 63177, (char) 52793,
        Double.longBitsToDouble(0x3fc500defe0fc0dcL), Double.longBitsToDouble(0x3fe843f0bf711ea6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 2, "\uda9a\udd6a\uda70\udcb5", "\u53b2\u7961\u3614\u74b3\u5b28", "\uda3c\ude89\uda20\udf46\udbee\udc6b\ud8f7\udedc",
        -4, 20600, -426267755, 4459132318404197773L, 24103L, false, false, (char) 17412, (char) 8781,
        Double.longBitsToDouble(0x3fe26e821c7b1af9L), Double.longBitsToDouble(0x3fdc21268353e5c0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 10, "\uafef\uda70\udcb5\uda73\udedc\udbe8\udee3\ud8e5\udf92\uda74\udf0d\udae2\udf6f\udb71\uddd4\ud849\ude12\ud9c2\udf65\udb73\udee7\uda3c\ude89\ud9f3\uddb5\udb24\udded\ud8f7\udedc", "\u0a9b\u50cb\ub908\u7a7a\u5680\u2fd2\u5dff\uaade\u1c91\uc4b1\ud4b2\ud0f3\u3e34\ube20\u8697\u61c0\u852b", "\udaff\udc80\uda92\udea3\ud9cf\udc16\u2c59\u2733\uda54\udecb\ud8e3\udd9e\u46c2\uda51\uddb6\ud96e\udc7f\ud9f8\udc0a\ud88e\ude18\uda00\udf0b\ud9f7\udd70\u1438\ud9da\udc51\udb04\uddba\uda1c\uddc9",
        19, 39904, -1704834487, -6257917211221846242L, -78169L, true, true, (char) 7017, (char) 78,
        Double.longBitsToDouble(0x3fe1b7d4bb1289f9L), Double.longBitsToDouble(0x3fedb9e83e1039baL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 2, 13, 9, 4, "\uda0f\udd0c\ud928\udd09\uda73\udf23\udbfc\udd6d\ud8bd\ude92\ud82c\ude0d\ud972\udd57\ud8af\udeb0\udbd8\udecb\udb01\udfea\uccb1\uda3c\udefa\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud800\udfc3\ud967\udf01\udb4b\udc44\ud9b5\udf94", "\u120a\u7313\u9655\u8ae1", "\udbaf\udc1c\ud845\udff9\uc224\ud838\udd33\ud9d3\ude25\ud9e3\udc14\ud9f6\uddc5\ud8a3\udd63\udbbf\udddd\udafa\udcad",
        52, 72754, 1526677854, -2570857918665186616L, -79515L, false, false, (char) 16567, (char) 64086,
        Double.longBitsToDouble(0x3fef6c563b5b6b5bL), Double.longBitsToDouble(0x3fd30e39ae657798L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.ArrayList:[private transient sun.util.calendar.BaseCalendar$Date java.util.Date.cdate, private transient long java.util.Date.fastTime] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 4, "\ud92b\udd0c\ud86b\udd09\uda73\udf23\udbfc\udd6d\ubf91\ud82c\ude0d\ud972\udd57\ud8af\udeb0\udbd8\udecb\udb01\udfea\uccb1\uda3c\udefa\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud800\udfc3\ud967\udf01\udb4b\udc44\ud9b5\udf94", "\u120a\u7313\u8e76\u8ae1", "\u281d\ud846\udc44\ud81c\uded9\udb99\uddde\ud9d3\udf16\ud9e3\udc14\ud9f6\uddc5\ud8a3\udd63\udbbf\udddd\ud8d8\udcb8",
        52, 72754, 1526677854, -3219376265006538040L, -79515L, false, false, (char) 16567, (char) 64086,
        Double.longBitsToDouble(0x3fef6c563b5b6b5bL), Double.longBitsToDouble(0x3fd30e39ae657798L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 4, "\uda0f\udd0c\ud928\udd09\uda73\udf23\ud8ae\udc71\ud8bd\ude92\ud82c\ude0d\uda0e\udc2e\ud8af\udeb0\udbd8\udecb\udb01\udfea\uccb1\uda3c\udefa\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud800\udfc3\ud967\udf01\udb4b\udc44\ud9b5\udf94", "\u120a\u7313\u9655\u8ae1", "\udbaf\udc1c\ud845\udff9\uc224\ud838\udd33\ud9d3\ude25\ud9e3\udc14\ud9f6\uddc5\ud8a3\udd63\udbbf\udddd\udafa\udcad",
        52, 72656, 64569694, -3219375676596018488L, -79515L, false, false, (char) 16567, (char) 64086,
        Double.longBitsToDouble(0x3fd138ac76221610L), Double.longBitsToDouble(0x3fd30e39ae657798L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 4, "\uda0f\udd0c\udafe\uddb4\ud8ea\udeab\udbe0\udc1e\udbd3\ude27\ud82c\ude0d\ud972\udd57\udb55\udd00\udbd6\uddcb\udb01\udfea\uccb1\uda3c\udefa\ud9f3\uddb5\ud908\udde9\ud934\uddfb\ud90d\udd14\ud9ac\uded1\ua334\udacb\udec7", "\u120a\u7313\u1bf6\u8a71", "\udbaf\udc65\udb84\udefd\uc224\ud838\udd33\uda58\udf23\ud9e3\udc14\ud9f6\uddc5\ud8a3\udd63\udb6b\uddd3\udafa\udcad",
        39, 39274, -1191231138, -3199096202543488312L, 91403L, false, true, (char) 32762, (char) 31109,
        Double.longBitsToDouble(0x3fe36c1cb4d7c8acL), Double.longBitsToDouble(0x3fcf1bc964272a70L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.ArrayList:[transient java.lang.Object[] java.util.ArrayList.elementData, private int java.util.ArrayList.size] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 10, 5, 4, "\uda0f\udd0c", "\u943e\u53b2\u45ac\u030e\u8b6a\u8c1b\u7c24", "\ud9f3\uddb5\ud8c8\udee4",
        37, 95341, -745762400, 839828513957468310L, -33507L, true, true, (char) 64748, (char) 41998,
        Double.longBitsToDouble(0x3feba9f6c062d043L), Double.longBitsToDouble(0x3feca654d1a4fc68L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=new org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 2, 10, 12, 4, "\uda0f\udd0c\ud928\udd09\udb03\udfdb\ud860\udfe8\udb2a\udfa0\ud812\uddb3\ud972\udd57\ud8af\udeb0\udbd8\udecb\udb01\udfea\uccb1\uda3c\udefa\ud9f3\uddb5\udba7\udea0\ud9d6\udeca\udbec\udf83\ud967\udf01\uda82\udc40\ud9b5\udf94", "\u1c2e\u7313\u1d6f\u8c98", "\udbaf\udc1c\ud845\udff9\uc224\ud838\udd33\ud9d3\ude25\ud9e3\udc14\udba5\udf7c\uda30\udf71\ud80f\udc09\uda97\udf17",
        19, 72754, 1526677854, -3219376265006538040L, -79515L, false, false, (char) 16567, (char) 64086,
        Double.longBitsToDouble(0x3fef6c563b5b6b5bL), Double.longBitsToDouble(0x3fd30e39ae657798L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=new org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 2, 10, 12, 12, "\ud9db\uddb2\ud8d5\udfd4\ud803\ude4c\udbfc\udd6d\udbed\udc0a\ud906\udd83\ud883\udf74\ud89f\udc05\ud812\uddb1\udb02\udc0e\ud91f\ude5f\ud82c\udd03\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud8d4\udcbe\ud967\udf01\udb4b\udc44\ud9b5\udf94", "\u120a\u7313\u9655\uc69e", "\uda3c\udec7\ud845\udff9\u8e43\ud838\udd33\ud9d3\ude25\ud9e3\udc14\ud9f6\uddc5\ud8a3\udd63\ud804\udcaf\udafa\udcad\udad8\udc4a\udaaf\ude26\uda31\ude8d\udafd\udd64",
        43, 99478, -1969689604, -3458981842166763525L, -82881L, true, false, (char) 59060, (char) 20150,
        Double.longBitsToDouble(0x3fd30e39ae657798L), Double.longBitsToDouble(0x3fe5fd07548dc8daL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 9, 5, 4, "\uda0f\udd0c\ud928\udd09\udacb\udeae\ud81c\udc23\uda25\udfc1\ud8b0\udfc3\ud972\udd43\ud8af\udeb0\udbad\udfcb\ud825\udc47\ud8a5\udc55\udbd0\udf37\ud9f3\udd46\udb44\udffd\ud8f7\udedc\ud800\udfc3\ud982\udd01\udb4b\udc44\ud96e\udc55", "j\u7324\u9655\u8ae1", "\udb30\udd54\ud84e\udec1\uc224\ud838\udd33",
        24, 28032, -278549824, -1112953903461056169L, 37278L, false, false, (char) 10332, (char) 54615,
        Double.longBitsToDouble(0x3fef4e9a968df563L), Double.longBitsToDouble(0x3fefe69742578a98L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.util.ArrayList:[private transient sun.util.calendar.BaseCalendar$Date java.util.Date.cdate, private transient long java.util.Date.fastTime] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 2, 10, 9, 4, "\uda0f\udd0c\ud928\udd09\uda73\udf23\uda3a\udecc\udbfa\udfd3\udb08\udc45\ua361\ud8af\udee3\udbd8\udecb\udb01\udfea\uccb1\uda3c\udefa\ud9f3\uddb5\udb24\udded\udbc7\udd44\ud992\ude34\ud889\udf52\udb4b\udc44\ud9b5\udf94", "\u120a\u7313\u9655\u3be1", "\ud957\udc10\ud845\udff9\ud8bd\udf6b\ud958\udeaa\ud9ea\udd90\uda13\udddf\uda12\udfd0\ud882\udee2\udbbf\udddd\udafa\udcad",
        52, 62042, 1907058205, -3219361228326034744L, -79391L, false, false, (char) 16567, (char) 64086,
        Double.longBitsToDouble(0x3fef6c563b5b6b5bL), Double.longBitsToDouble(0x3fd30e39aa657798L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.util.ArrayList:[private int java.lang.String.hash] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 10, 5, 4, "\uda0f\udd0c\ud928\udd09\uda73\udf23\udbfc\udd6d\ud8bd\ude92\ud82c\ude0d\ud972\udd57\ud8af\udeb0\udbd8\udecb\udb01\udfea\uccb1\uda3c\udefa\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud800\udfc3\ud967\udf01\udb4b\udc44\ud94d\udf70", "\ud4d0\u7313\u9655\u8ae1\u3118\uc351\ua8ca\uca30\ua08e\ucfb6\u4fe6\uc191", "\udb39\udfd4\udafa\udd14\udadb\udd12\udaba\udd48\udb81\ude56\udbd9\udf9c\uda6e\udf9a\udae7\udc3d\udb23\udd10\udb25\udf82\ud944\udd87\ud990\udf62\ud8ad\udeaf\uda05\udff2\uda80\ude40\uda60\uddae\ud815\udd2b\udadc\ude33",
        42, 12553, 330395551, -774612074556948692L, -11090L, true, false, (char) 25815, (char) 32687,
        Double.longBitsToDouble(0x3fef5dbfbe77fed4L), Double.longBitsToDouble(0x3fb4495a42d48998L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 10, 3, 4, "\ud991\uddcd\udb4f\ude1b\udb86\udc57\udbfc\udd6d\ud8bd\ude92\ud82c\ude0d\ud972\udd57\ud8af\udeb0\udbd8\udecb\udb01\udfea\uccb1\uda3c\udefa\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud800\udfc3\ud967\udf01\udbf1\udcd7\ud892\udf63", "\u120a\u7313\u6cd4\ubfad\u9b05\uc2f3\u0b5d\ucb0e\ud3bf", "\ud9e2\udfe5",
        1, 76698, 1288814935, -7853346352880556094L, -51198L, false, false, (char) 63002, (char) 60635,
        Double.longBitsToDouble(0x3fc4b1d0c95e695cL), Double.longBitsToDouble(0x3fefde7ffcfb361fL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 1, 12, 14, 4, "\uda9a\udd6a\ud8f6\udc37\udabd\udfbe\udb6d\udc19\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\ud969\udfdb\ud968\uddd9\udade\udd86\ud83b\udfc2\ud951\udce9\ud8bf\udee0\ud8e4\ude34\ud967\udf01\uda6e\ude16\uda4e\udcdd", "\uaf19\u80b5\u964b", "\udb5b\udc2e\ud884\udece\udb27\uddf0\udbb8\udda0\ud976\udcf0",
        16, 36228, -278549824, 5720494128085044385L, 93598L, true, false, (char) 10332, (char) 54615,
        Double.longBitsToDouble(0x3fb544a8b931ebf8L), Double.longBitsToDouble(0x3f9e1647ca6986c0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 9, 3, 15, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\ud967\ude4c\uda3c\ude89\ud83b\udfc2\ud951\udce9\ud81b\ude94\ud8e4\ude2e\ud967\udf01\ud846\udfa2\u2782", "\u080a", "\ud8c4\udcf9",
        3, 4088, -220142142, -3554323443205753169L, 54013L, false, false, (char) 55869, (char) 13952,
        Double.longBitsToDouble(0x3fc429ec7c6b70dcL), Double.longBitsToDouble(0x3fee14981af1b739L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\0121=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$1:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\012",
        Z.run(T, 2, 0, 13, 4, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\ud967\ude4c\uda3c\ude89\ud83b\udfc2\ud951\udce9\ud81d\udfc8\ud8d3\ude28\ud967\udf01\uda6e\ude16\uda4e\udcdd", "\uaf19\u80b5\u964b", "\ud8b6\udf02\ub4fc\ud8de\udc67\ud896\ude54\uda59\udcf1",
        25, 36228, -278549824, 5720563397317594273L, 93598L, true, false, (char) 10332, (char) 54615,
        Double.longBitsToDouble(0x3fb544a8b131ebf8L), Double.longBitsToDouble(0x3fe127777e532803L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 9, 14, 4, "\uda9a\udd6a\udb9c\udf8a\ud98c\udcab\udbfc\udd6d\ud8bd\ude92\ud87f\udf05\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\u68c6\ud9be\uddf2\udbb8\udca2\ud951\udce9\ud8f7\udedc\ud82b\udc79\udb88\udc17\uda6e\ude16\uda4e\udcdd", "\ud3cd\u060b\u6ee5", "\ud8b6\udf02\udb53\udd4d\udb3e\udd30\ud92b\udc98\ud976\udccb",
        56, 5392, -899849979, 5720494209689423009L, -31454L, true, false, (char) 10332, (char) 54615,
        Double.longBitsToDouble(0x3fb544a88131ebf8L), Double.longBitsToDouble(0x3fe12434b6532803L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.util.ArrayList:[private int java.lang.String.hash] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=java.util.ArrayList:[private int java.lang.String.hash] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 2, 10, 10, 4, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\udaf8\ude51\uabc9\u34e7\ud8b0\ude68\udac0\udcf6\uda39\udd43\ud967\ude4c", "\u3e6c", "\ud967\udf01\uda6e\ude76\uda4e\udcdd\ud803\udeb4",
        0, 18542, 1479893034, 4528618927760335733L, -66803L, true, false, (char) 56144, (char) 47160,
        Double.longBitsToDouble(0x3fd99f38e5805efcL), Double.longBitsToDouble(0x3feccf7b2ca14f63L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=java.util.ArrayList:[] |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 2, 10, 10, 4, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\ude76\udbd8\udecb\uda39\udd43\ud967\ude4c\ud8c8\udc6e\ud9f3\uddb5\udb51\udded\ud822\udfc1\ud8e4\ude34\u91a0\uda6e\ude16\uda4e\udcdd", "\uaf0f\u80b5\u964b", "\000",
        49, 37585, 1644790877, -95005196252443122L, 9248L, false, true, (char) 56323, (char) 11090,
        Double.longBitsToDouble(0x3fee14981cc3fc3aL), Double.longBitsToDouble(0x3ebf080000000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 2, 9, 9, 4, "\ud866\udd10\udb6a\udcb2\uda73\udedc\udbfc\udd6d\ud8d7\udc4b\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\ud967\ude4c\ud9bb\ude07\ud88a\udd1a\udb4c\udded\ud9c2\udd81\uda48\udcc4\ud8b7\udcc5\uda6e\ude25\uda4e\udcdd", "\u7ff6\u80b5\u964b", "\ud8b6\udf35",
        49, 37585, 1644790877, -94880865539158514L, 14034L, true, false, (char) 29290, (char) 54409,
        Double.longBitsToDouble(0x3fbd1d9d42420458L), Double.longBitsToDouble(0x3fdd6f374c17e430L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.configuration.injection.PropertyAndSetterInjection:@?\012",
        Z.run(T, 2, 9, 9, 3, "\udad3\udf7b\uda15\udfdd", "\u1cb3\u7961", "\ud833\udca6\ud9c2\udf65\udb73\udee7\udaab\udd7f\ud9d4\udecf\udb24\udded\ud8f7\udedc\ud8eb\udde2\udb1c\udc4f\ud86f\udd9d\ud875\ude42\udbfe\udf57\ud8e6\udd6c\ud9b5\udee5\uda63\udf4e\ud898\ude70\udbca\udde5\udbc8\udd84\ud9a1\udf81\ud9c2\ude83\ud8e2\udca9\ud8d0\udcee\ud991\udcb4\ud9eb\udf28\uda01\udc42\udb81\ude3e\udaae\udffd\ud95d\ude46\udaff\udc80\uda92\udea3\ud9cf\udc16\u2c59\u2733\uda54\udecb\ud8e3\udd9e\u46c2\uda51\uddb6\ud96e\udc7f\ud9f8\udc0a\ud88e\ude18\uda00\udf0b\ud9f7\udd70\u1438\ud9da\udc51\udb04\uddba\uda1c\uddc9\ud95b\udc3c\uda7b\udd18\uda45\udcf6\udb1d\udc55\udb76\udfc6\uda6e\uddb7\ub2ed\ucf54\ud904\udc7f\ud966\udcd7\ud971\udf41\udab9\udeaa\ud8f4\udc29\ud888\ude99\udb4a\udd91\udad0\udfa8\ud97d\udc4d\uda3e\udc99\ud9d5\udf57\ud95c\udc4e\uda54\udd3c\udaa5\udcaa\ufec3\uda19\udd22\udb39\udf23\uda6a\uddf8\ud80b\udf91\ud827\ude1b\u7dfd\ud9fd\udd17\ud8b5\uddd6\uda75\udfc9\udbd3\udf5e\ud800\udfbe\udb21\uddaa\uda0a\udd33\udb20\udd7c\udb06\udc80\udb0f\udfdf\udb70\udfd6\uda7a\udd38\ud964\uddbc",
        24, 39476, 571103305, -3428400219856162277L, -4679L, true, true, (char) 23727, (char) 4169,
        Double.longBitsToDouble(0x3fe253e30297690eL), Double.longBitsToDouble(0x3fe673b2a7bc006bL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 4, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda74\udf0d\udac2\udd5f\ud8af\udeb0\udbd8\udecb\uda39\udd43\ud967\ude4c\uda3c\ude89\ud9f3\uddb5\udb24\udded\ud8f7\udedc\ud8e4\ude34\ud967\udf01\uda6e\ude16\uda4e\udcdd", "\uaf0f\u80b5\u964b", "\ud8b6\udf35",
        48, 37585, 1644790877, -95005196252443122L, 9248L, false, true, (char) 56323, (char) 11090,
        Double.longBitsToDouble(0x3fee149818e34766L), Double.longBitsToDouble(0x3fd5ee6fd4b0b5feL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter$2:@? |this=org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda9a\udd6a\uda70\udcb5\uda73\udedc\udbfc\udd6d\ud8bd\ude92\uda7b\udc0d\udac2\udd5f\ud8af\udeb0\uc7d9\ud875\udd14\ud967\ude4c\ud822\udfbb\ud9f3\udd1f\udb24\udded\ud8f7\udedc\u95f6\ud819\udd99,\000\ucf5a\ud8e5\udc13\ud905\udeed\udb35\ude09\ud896\udded\udb59\udf09\ud974\ude1c\ud9ae\ude91\udbc9\udd5d\udbe7\uddfa\uc224\ud91a\udfe5\ud800\ude1f\udaf3\udcbe", "\ud196\uc5ed\u221a\ud486\u7e6e\u45c0\u6ad4\u083e\u8218\u397e\u7384\u3608\u80f3\u237e\ub692\u06b4\ud0e0\u736c\uc65b\u7ba3\u766e\u1b48\u433b\u9dac\ud5605\000\ua88e\000\u9da3\ub613\u3bfe\ub3c8\u31b0\u50e3\u2a34\u9b03", "\ud8fa\ude30\ud8c0\udebc\udbff\udf2a\ud89e\udf3a\ud8c3\udc8e",
        -4, 61023, -628451840, -7337596768171261230L, -7489L, false, true, (char) 60150, (char) 54375,
        Double.longBitsToDouble(0x3fa8c98939c93030L), Double.longBitsToDouble(0x3fdae23cd9551a1eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 0, 0, "\uda9a\udd6a\uda70\udcb5\udbad\udf19\udb7f\udd57\ud8bd\udeb5\uda7b\udc0d\udac2\udd5f\ud8af\udeb0\uc7d9\ud875\udd14\ud967\ude4c\ud822\udfbb\ud9f3\udd1f\udb24\udded\ud8f7\udedc\u95f6\ud819\udd99,\000\ucf5a\ud8e5\udc13\ud905\udeed\udb35\ude0d\ud896\udded\udb59\udf09\ud974\ude1c\ud9ae\ude91\udbc9\udd5d\udbe7\uddfa\uc224\ud91a\udfe5\ud800\ude1f\udaf3\udcbe", "\ud196\uc5ed\u221a\ud486\u7e6e\u45c0\u6ad4\u083e\u8218\u397e\u7384\u3608\u80f3\u237e\uc5b8\u06b4\ud0e0\u736c\uc65b\u7ba3\u766e\u1b48\u433b\u9dac\u02f0\u2154h\ua88e\000\u9da3\ub613\u3bfe\ub3c8\u31b0\u50e3\u2a34\ub6dd", "\ud984\uddd6\udbb8\ude51\udbff\udf2a\ud89e\udf3a\ud8c3\udc8e",
        -4, 33550, -690761594, -7337594826846043438L, -7489L, false, true, (char) 60150, (char) 54375,
        Double.longBitsToDouble(0x3fa8c98939c93030L), Double.longBitsToDouble(0x3fdae23cd9551a1eL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.injection.filter.NameBasedCandidateFilter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 14, 6, "\uda9a\udd6a\uda70\udcb5\udbad\udf19\udbbe\udc5c\ud8bd\udeb5\uda7b\udc0d\ud96b\udd47\ud990\udd20\ud879\udf5b\udabf\udee7\ud967\udeac\udbe5\udfbc\ud9d0\udff0\udb24\udded\ud8f7\udedc\u95f6\ud901\ude5b,\uda96\ude92\udb1a\uddba\ud8e5\udc13\ud905\udeed\udb35\ude0d\ud896\udded\udb59\udf09\ud974\ude1c\ud9ae\ude91\udbdd\ude5d\udbe7\uddfa\uc224\ud91a\udfe5\ud800\ude1f\ud8b1\udd0c", "\u093c\uc650\u5f24\u6782\u7f98\u21f7\u6ad4\u083e\u8218\u397e\u0bbb\u3608\u80f3", "\ud81e\udd7e\udb66\udddf\uda47\udd69\udbc7\uddf8\udbaf\udd6b\uda89\udeb1\uda90\uded4\udbf2\udf30\udbbb\uded2\udba8\udd6e\ud998\udeb7\ud9a9\ude90",
        55, 18800, -1741306395, -940018954857031450L, 62904L, false, false, (char) 29387, (char) 11608,
        Double.longBitsToDouble(0x3fd4c443492e32e0L), Double.longBitsToDouble(0x3fe5c05440c378dbL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter|filterCandidate|java.util.Collection,java.lang.reflect.Field,java.util.List,java.lang.Object|new:org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:",
    "M|org.mockito.internal.configuration.injection.filter.NameBasedCandidateFilter|filterCandidate|java.util.Collection,java.lang.reflect.Field,java.util.List,java.lang.Object|new:org.mockito.internal.configuration.injection.filter.NameBasedCandidateFilter:org.mockito.internal.configuration.injection.filter.MockCandidateFilter",
    "M|org.mockito.internal.configuration.injection.filter.TypeBasedCandidateFilter|filterCandidate|java.util.Collection,java.lang.reflect.Field,java.util.List,java.lang.Object|new:org.mockito.internal.configuration.injection.filter.TypeBasedCandidateFilter:org.mockito.internal.configuration.injection.filter.MockCandidateFilter",
    "M|org.mockito.internal.configuration.injection.PropertyAndSetterInjection|injectMockCandidatesOnFields|java.util.Set,java.lang.Object,boolean,java.util.List|new:org.mockito.internal.configuration.injection.PropertyAndSetterInjection:",
    "C|org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter|<init>|",
    "M|org.mockito.internal.configuration.injection.filter.MockCandidateFilter|filterCandidate|java.util.Collection,java.lang.reflect.Field,java.util.List,java.lang.Object|new:org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:",
    "C|org.mockito.internal.configuration.injection.filter.NameBasedCandidateFilter|<init>|org.mockito.internal.configuration.injection.filter.MockCandidateFilter",
    "C|org.mockito.internal.configuration.injection.filter.TypeBasedCandidateFilter|<init>|org.mockito.internal.configuration.injection.filter.MockCandidateFilter",
    "M|org.mockito.internal.configuration.injection.PropertyAndSetterInjection|initializeInjectMocksField|java.lang.reflect.Field,java.lang.Object|new:org.mockito.internal.configuration.injection.PropertyAndSetterInjection:",
    "M|org.mockito.internal.configuration.injection.PropertyAndSetterInjection|injectMockCandidates|java.lang.Class,java.util.Set,java.lang.Object|new:org.mockito.internal.configuration.injection.PropertyAndSetterInjection:",
    "M|org.mockito.internal.configuration.injection.PropertyAndSetterInjection|orderedInstanceFieldsFrom|java.lang.Class|new:org.mockito.internal.configuration.injection.PropertyAndSetterInjection:",
    "M|org.mockito.internal.configuration.injection.PropertyAndSetterInjection|processInjection|java.lang.reflect.Field,java.lang.Object,java.util.Set|new:org.mockito.internal.configuration.injection.PropertyAndSetterInjection:",
    "C|org.mockito.internal.configuration.injection.PropertyAndSetterInjection|<init>|",
    "M|org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter|filterCandidate|java.util.Collection,java.lang.reflect.Field,java.util.List,java.lang.Object|new:org.mockito.internal.configuration.injection.filter.FinalMockCandidateFilter:",
    "M|org.mockito.internal.configuration.injection.filter.NameBasedCandidateFilter|filterCandidate|java.util.Collection,java.lang.reflect.Field,java.util.List,java.lang.Object|new:org.mockito.internal.configuration.injection.filter.NameBasedCandidateFilter:org.mockito.internal.configuration.injection.filter.MockCandidateFilter",
    "M|org.mockito.internal.configuration.injection.filter.TypeBasedCandidateFilter|filterCandidate|java.util.Collection,java.lang.reflect.Field,java.util.List,java.lang.Object|new:org.mockito.internal.configuration.injection.filter.TypeBasedCandidateFilter:org.mockito.internal.configuration.injection.filter.MockCandidateFilter",
    "M|org.mockito.internal.configuration.injection.PropertyAndSetterInjection|injectMockCandidatesOnFields|java.util.Set,java.lang.Object,boolean,java.util.List|new:org.mockito.internal.configuration.injection.PropertyAndSetterInjection:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
