package org.mockito.internal.stubbing.defaultanswers;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReturnsEmptyValues_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud872\udf35\udb49\ude6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udf9e", "\u0209\u92d1\u6898\ubf66\ua9e1\u76e0\u06a2\u4c61\u53e0\u4e7e", "\ud87a\udd87\ud9da\ude8c\ud8b1\udcd4\uda4c\udc3e\ud8c0\uddc5\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udae7\udeb3\ud93f\udfba\ud9a4\udc28\ud87f\udc28\udb6d\udd8d\udb64\ude66\uda3f\udcb0\uda63\uddeb\ud960\udf57",
        29, 32362, 1865627771, 3705498065881396899L, 28676L, false, true, (char) 6243, (char) 22563,
        Double.longBitsToDouble(0x3fc014d7e0cf2f0cL), Double.longBitsToDouble(0x3fe349b1bf959db4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud872\udf35\udb49\ude6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udf9e", "\u0209\u92d1\u6898\ubf66\ua9e1\u76e0\u06a2\u4c61\u53e0\u4e7e", "\ud87a\udd87\ud9da\ude8c\ud8b1\udcd4\uda4c\udc3e\ud8c0\uddc5\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udae7\udeb3\ud93f\udfba\ud9a4\udc28\ud87f\udc28\udb6d\udd8d\udb64\ude66\uda3f\udcb0\uda63\uddeb\ud960\udf57",
        29, 32362, 1865627771, 3705498065881396899L, 28676L, false, true, (char) 6243, (char) 22563,
        Double.longBitsToDouble(0x3fc014d7e0cc9400L), Double.longBitsToDouble(0x3fe349b1bf959db4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud872\udf35\udb49\ude6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udf9e", "\u0209\u92d1\u6898\ubf66\ua9e1\u76e0\u06a2\u4c61\u53e0\u4e7e", "\ud87a\udd87\ud9da\ude8c\ud8b1\udcd4\uda4c\udc3e\ud8c0\uddc5\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udae7\udeb3\ud93f\udfba\ud9a4\udc28\ud87f\udc28\udb6d\udd8d\udb64\ude66\uda3f\udcb0\uda63\uddeb\ud960\udf57",
        29, 51240, 1868581954, 3705498065881396899L, 28676L, false, true, (char) 6243, (char) 22563,
        Double.longBitsToDouble(0x3fc014d7e0cf2f0cL), Double.longBitsToDouble(0x3fe349b1bf959db4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udb76\udcf7\udb49\ude95\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udf9e\ud9af\udeea", "\u92d1\u6898\ubf66\ua9e1\u76e0\u06a2\u4c61\u53e0\u4e7e\u34ee\uc50c\u4c1c\ubd7c\u33fb\ua6d8\u0311\u470c\u34d0\u4e1a\ua268\u92e0\u30be", "\uda4a\ude39\ud9e4\ude83\uda63\udd13\ud960\udf57\ud980\udc19\udadd\udfc2\uda6b\udf08\udb35\udde3\uda10\udeac\udbc3\udf06\u16bd\ud902\udc1e\ud8a5\udfb7\ud9be\udf9c\udbca\udd6b\udbb8\udf64\ud81f\udc9e\ud9e7\udf34\ud8e7\udf2b\udada\udfe2\udb0e\udedb\ud8cc\udd24\udb8c\udd93",
        16, 22219, 936554733, -2804591334206034330L, -93685L, true, true, (char) 53310, (char) 15694,
        Double.longBitsToDouble(0x3fe362e22fdb51bfL), Double.longBitsToDouble(0x3fe978ce104fe462L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud872\udf35\udb49\ude6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udf9e", "\u0209\u92d1\u6898\ubf66\ua9e1\u76e0\u06a2\u4c61\u53e0\u4e7e", "\ud87a\udd87\ud9da\ude8c\ud8b1\udcd4\uda4c\udc3e\ud8c0\uddc5\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udae7\udeb3\ud93f\udfba\ud9a4\udc28\ud87f\udc28\udb6d\udd8d\udb64\ude66\uda3f\udcb0\uda63\uddeb\ud960\udf57",
        29, 32362, 1865627771, 3705498065881396899L, 28676L, false, true, (char) 6243, (char) 22563,
        Double.longBitsToDouble(0x3fc014d7e0cf2f0cL), Double.longBitsToDouble(0x3fe349b1bf959db4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 0, 0, "\ud872\udf35\udb49\ude6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb9a\udc53\ud993\udc86\udb66\udcd0\ud82b\udcee\uda39\udf95", "\ub20a\uad87", "\udaaa\udfa4\ud8c7\udd06\udbab\udd14\ud859\udd5c\ud87a\udd87\ud9d1\ude8c\uda0f\udf40\uda5d\ude91\ud9ef\udf0d\udb0b\udf55\udbbd\ude5d",
        35, 85346, 166088485, 1040103350758173142L, 49059L, false, true, (char) 27452, (char) 65388,
        Double.longBitsToDouble(0x3fe5199d62bcbcc1L), Double.longBitsToDouble(0x3fe2e608bdf25b46L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.lang.Integer:0 |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 0, 2, "\ud872\udf35\udb49\ude6a\udbe5\udf10\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udf9e", "\u0209\u92d1\u6898\ubf66\ua9e1\u76e0\u5e56\u6e6b\u69de\u4e7e", "\udb60\udf95\ud9c8\ude6d\udaf7\uddd8\ud976\ude21\udb52\ude05\ud91f\udc95\udbbd\ude5d\uda4d\udeb8\udb15\udd89\ud81a\udd1b\ud8c6\udc15\ud87f\udc28\udb6d\udd8d\udb64\ude66\uda3f\udcb0\uda63\uddeb\ud960\udf57",
        29, 66122, -2072795348, 7095036219515570126L, 28676L, false, true, (char) 6243, (char) 22563,
        Double.longBitsToDouble(0x3fc014d7e0cf2f0cL), Double.longBitsToDouble(0x3fe349b1bf959d24L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 1, "\ud872\udf35\udb49\ude6a\udbe5\udf20\ud822\udec1\ud843\udf00\ud9b7\udf40\udb6f\udf9e", "\u3087\u92e6\uc340\ubeab\ubeea\u76e0\u06a2\u4c61\u53e0\u4e7e", "\ud87a\udd87\udb6c\udc96\uda3d\udc03\uda4c\udc3e\ud8c0\uddc5\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udae7\udeb3\ud93f\udfba\ud9a4\udc28\ud87f\udc28\ud9a0\udea5\udb75\ude7e\uda3f\udcb0\uda63\uddeb\ud960\ude92",
        29, 32362, 1865627771, 3705498065881396899L, 28676L, false, true, (char) 47459, (char) 22563,
        Double.longBitsToDouble(0x3fc014d7e38f2f0cL), Double.longBitsToDouble(0x3fe349b1bf959db4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 0, 0, 2, "\ud872\udf35\udb49\ude6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\ud91a\udfd4", "\uafc0\u9552\u6898\ubf5d\ua9e1\u76e0\u06a2\u4c61\u53e0\u4e7e", "\ud87a\udd87\ud9da\ude8c\ud8b1\udcd4\uda4c\udc3e\ud8c0\uddc5\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udae7\udeb3\ud93f\udfba\ud9a4\udc28\ud87f\udc28\udb6d\udd8d\udb64\ude66\uda3f\udcb0\uda63\uddeb\ud960\udf57",
        29, 32362, 1865627771, 3705498065881396899L, 28676L, false, true, (char) 6243, (char) 22563,
        Double.longBitsToDouble(0x3fc014d7e2e0e30cL), Double.longBitsToDouble(0x3fe349b1bf959db4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 1, 2, 1, 2, "\ud872\udf35\udb49\ude6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udf9e", "\u0209\u92d1\u6898\ubf66\ua9e1\u76e0\u06a2\u3678\u4307\u4e7e", "\ud87a\udd87\ud9da\ude8c\ud8b1\udcd4\uda4c\udc3e\ud8c0\uddc5\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udae7\udeb3\ud93f\udfba\ud9a4\udc28\ud87f\udc28\udb6d\udd8d\udb64\ude66\uda3f\udcb0\uda63\uddeb\ud960\udf57",
        29, 32362, 1865627771, 3705498066051266211L, 74110L, false, true, (char) 39555, (char) 22563,
        Double.longBitsToDouble(0x3fc014d7e0cf2f0cL), Double.longBitsToDouble(0x3fe349b1bf959db4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud82b\ude91\udb49\udf0d\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\ud814\ude51", "\u0209\u92d1\ua978\u2cb2\u6bcd\u76e0\u06a2\u93f6", "\ud977\udf49\uda6a\ude36\u5737\ud907\udec4\ud879\udc0a\udaa7\udd62\udbc4\udc44\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udac3\udf9e\ud951\uddc2\ud9a4\udc28\udb40\udf29",
        25, 21471, -361880074, -2808050523408430269L, -23878L, true, false, (char) 527, (char) 8719,
        Double.longBitsToDouble(0x3fe5e5e6095cc117L), Double.longBitsToDouble(0x3fdf25b4670849beL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.lang.Integer:0 |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 0, 0, 2, "\ud872\udf35\udb44\udc6a\udbe5\udf20\u3e59\ud80e\udcce\ud9b7\udf0d\u6fba", "\ua985\u81a7\u6898\ubf66\ua9e1\u76e0\u06a2\u4c61\u53e0", "\udba6\ude49\udb36\udf96",
        43, 34256, 217517947, -3499889950688959646L, 10811L, true, false, (char) 25660, (char) 37623,
        Double.longBitsToDouble(0x3fe934efa5f67b14L), Double.longBitsToDouble(0x3fdedea6e7fa8790L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 1, 2, 1, 2, "\ud872\udf35\udb49\ude6a\uda8b\udde4\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udf9e", "\u0209", "\udb64\udce7\udaab\uddda\udb31\udc3f\uda5c\udca6\ud9ef\udcf5\uf6c1\000\000\000",
        -4, 74223, 1894088237, 934232468665263266L, -34464L, true, false, (char) 44886, (char) 61120,
        Double.longBitsToDouble(0x3fbf42798eb7d328L), Double.longBitsToDouble(0x3feaacfd10009df4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.util.ArrayList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 0, 0, 2, "\udb06\ude09\udb49\ude6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udfa8", "\u022d\u92d1\u6898\ubf66\ua9e1\u76e0\u06a2\u4c61\u53e0\u4e7e", "\uda67\udd1f\udb13\ude6d\udbf8\ude39\ud9c9\udd00\ud889\udd4e\ud91f\udc5c\udbbd\ude5d\uda4d\ude31\uda82\uddad\ud93f\udfba\ud9a4\udc28",
        9, 94693, 2068240616, -1554263081766841875L, 49059L, false, true, (char) 10608, (char) 4730,
        Double.longBitsToDouble(0x3fe5199b64bcbcc1L), Double.longBitsToDouble(0x3fd801e91be4b68cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud811\udf2e\ud853\udd6e\uda87\udfa4\ud822\udec1\ud828\udeb8\ud9b7\udf0d\udb6f\udf9e\ud9b7\udfec\udb66\udcd0\ud82b\udcee\uda39\udf95\udbb7\udd70\udbf6\udc50\udb85\udc33\u79e7\uda5c\udc94\ud9ef\udcf5\udace\udd0a\uda52\ude8c\udb71\udfc5\ud874\udd61\uda55\udee6\uda9e\udf11\ud8b1\udcd4", "\u470c\u34d0\u14eb", "\ud9a4\udc28\ud87f\udc28\udb6d\udd8d\udb64\ude66\uda3f\udcb0\uda63\uddeb\ud960\udf57\uda4f\udd81\ud91c\udd64\ud8f6\uded2\udb35\udde3\uda10\udeac\udbc3\udf06\u16bd\ud902\udc1e\ud8a5\udfb7\ud9be\udf9c\ud8ed\udcfc\udbb8\udf64\ud81f\udc9e\udbfc\udc51\uda58\udfe2",
        32, 77073, -263144207, 6762330251752741690L, -1939L, false, true, (char) 60934, (char) 64306,
        Double.longBitsToDouble(0x3fe19470e60dc625L), Double.longBitsToDouble(0x3faff109c1ca6610L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 2, "\ud872\udf35\ud7bd\ud8f8\udd54\ud8c8\uddc7\ud81a\ude5f\ud9b7\udf0d\udb6f\udf9e", "\u0209\u920a\ucbe5\u37a7\ub868\u76e0\u6fa1\u4c61\u53e0\u4e7e", "\ud994\uddb4\ud9da\udea3\ud8b1\udcd4\uda4c\udc3e\ud8c0\uddc5\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udae7\udeb3\ud93f\udfba\ud9a4\udc28",
        9, 94693, 2064941862, -1554263081766841875L, 49059L, false, true, (char) 33307, (char) 548,
        Double.longBitsToDouble(0x3fe5199b62bcbcc1L), Double.longBitsToDouble(0x3fd5cc117c145a8cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.util.LinkedList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud872\udf35\udb3a\udf6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb1f\udc55\ud993\udd06\ud8d2\uddcb\ud82b\udcee\ud89c\ude06", "\ub20a\u4eb7", "\udaaa\udfa4\ud8c7\udd06\udbab\udd14\ud859\udd5c\ud981\uddac",
        18, 90537, 1504192841, 991141829277095523L, 10811L, true, false, (char) 16777, (char) 30481,
        Double.longBitsToDouble(0x3fe934efa5f67b14L), Double.longBitsToDouble(0x3fdedea6e7fa8790L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud872\udf35\udb49\ude6a\udbe5\udf20\ud822\udec1\ud81c\udcfa\ud9b7\udf0d\udb6f\udf9e", "\u0209\u92d1\u6898\ubf66\ua9e1\u76e0\u06a2\u4c61\u53e0\u4e7e", "\udb8e\ude93\ud9de\uddb2\ud8b1\udcd4\udb3d\ude55\ud8c0\uddc5\ud91f\udc5c\udbbd\ude5d\uda4d\udeb8\udae7\udeb3\ud93f\udfba\ud9a4\udc28\ud87f\udc28\udb6d\udd8d\ud8e4\udfc8\uda6d\ude8c\uda63\uddeb\ud960\udf57",
        29, 32362, 1865627771, 3705498065881396899L, 28676L, false, true, (char) 6243, (char) 22563,
        Double.longBitsToDouble(0x3fc014d0e0cf2f0cL), Double.longBitsToDouble(0x3fe349b1bf959db4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues|returnValueFor|java.lang.Class|new:org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues|answer|org.mockito.invocation.InvocationOnMock|new:org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:",
    "C|org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues|<init>|",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues|returnValueFor|java.lang.Class|new:org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
