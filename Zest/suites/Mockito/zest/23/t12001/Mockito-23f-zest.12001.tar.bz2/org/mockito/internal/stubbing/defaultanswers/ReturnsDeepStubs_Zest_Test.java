package org.mockito.internal.stubbing.defaultanswers;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReturnsDeepStubs_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 1, 2, 6, "\ud8e0\ude61", "\u8d9a\u3aba\ub46c\u784f\u4f34\u3462\u47f2\ud20f\uc877\u876a\u7c8f\u4072\ua342\u15e3\u796d\u70e9\uca45", "\udbb8\udd72\u6c98\ud981\udc65\udbd9\udf7a\ud95e\udfc7\udaa8\udd2f\udb3a\udfa3\ud8dd\udf2d",
        58, 45085, -1224870905, 1401763271041897397L, -70731L, false, false, (char) 7154, (char) 23790,
        Double.longBitsToDouble(0x3f98d5bb604cc660L), Double.longBitsToDouble(0x3fe317773a443d54L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 1, 2, 6, "\ud8e0\ude61", "\u8d9a\u3aba\u72f3\u784f\u4f34\u3462\u47f2\ud20f\u2c9d\u86f8\u7c8f\u554d\u1899\u15e3\u796d\u74e9\uca45\u46dc\ub706\u5617\u4a71\u04fe\u1c42\u77b5\u4366\u17b2", "\ud8a3\udfa4\uda21\udfb9\ud9d0\udd6a\udb2d\ude61\ud9b6\udd1b\udaf0\udc91",
        -2, 47712, -709159304, 7364405840333736706L, -97372L, false, false, (char) 8523, (char) 59006,
        Double.longBitsToDouble(0x3fe0f721265b442eL), Double.longBitsToDouble(0x3fe605ce4b76591dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 1, 11, 4, 4, "\ud8d8\udcf9", "\u8d9a\u9d20\u2f3d\u495a\u4f34\u8b15\ua8e1\u076d\u8cad\u388a\u1591\u0630\u9bf3\u4c8f\u796d\u3b2b\uca41\u46dc\u5907\u2d80\u4a71\u10fe\ua2c6\u23f9\u34e1\u1286\u2e4c", "\ud919\udebf\ud9d0\udd89\uda46\udeed\ud9b6\udc9a\udaf0\udc91\ud8e5\uded6\u742f\ud90a\udffa\ud89e\udf73\ud819\udd80\ud884\uddcf\ud9e9\udea8\ud9e9\ude2e\uda76\udf14\uda5a\udd0e\u0e46\ud88d\udf17\ud8f3\udd36\ud8c3\udcee\uda81\udfec\ud985\udd24\udb84\udf0d\ud9ab\uddc5\ud8ea\udf26\udbcf\ude31\udb89\uddd5\u231f\ud883\udd5d\uda2f\ude66\ud860\ude4c",
        1, 18057, -1033894902, -8810743850012711557L, 97664L, false, false, (char) 52862, (char) 39298,
        Double.longBitsToDouble(0x3fd2152cdbefeca2L), Double.longBitsToDouble(0x3fd1e22fffcea5d6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 5, 2, 6, "\ud8e0\ude61", "\ub045\u1676\ub3d4\u784f\u4f34\u3462\u47f2\ud20f\uc877\u876a\u7c8f\u4072\ua342\u15e3\u796d\u70e9\uca45", "\udbb8\udd72\u6c98\ud981\udc65\udbd9\udf7a\ud95e\udfc7\udaa8\udd2f\udb3a\udfa3\ud8dd\udf2d",
        58, 45085, -1224870905, 1401763271041897397L, -70731L, false, false, (char) 7154, (char) 23790,
        Double.longBitsToDouble(0x3f98d5bb604cc660L), Double.longBitsToDouble(0x3fe317773a443d54L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 8, "\ud8d7\udda2\ud96c\udd74\udbbd\udf4a\uda2e\uddc2\ud8cc\udc32\udbb3\udfd7\ud89b\udc9e\uda9c\udc87\uda9b\udf85\udbc8\udcd4\uda49\udf7d\udb91\udc85\ud9e4\udf5c\ud8b7\udff4\ud96d\udc36\udbc4\udd47\ud8a3\udd83\ud856\udca5\ud9e3\udeba\ud8aa\udd04", "\u561f\u219b\uacdc\ud163\u7a21\uccff\u12f6\u7218", "\ud8bd\udc25\ud9f8\udde3\udb34\udea3\ud9b6\udc79\udaf0\udc91\ud8e5\uded6\u7503\ud9f0\udd92\udb90\udc4d\uda11\udd19\ud8fe\udfda\ud92a\udc0b\ud96f\ude43\ud954\ude64\udb8d\udd83\udb68\ude2f\udbae\udf2f\ud9d9\udfe5\udaea\udf45",
        13, 75444, 1278391181, 8941967185814831823L, -38352L, true, true, (char) 19531, (char) 22058,
        Double.longBitsToDouble(0x3fc3f9a6ff7494c0L), Double.longBitsToDouble(0x3fe72dbc6a7eb143L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 9, 2, 6, "\ud8e0\ude61\ud96c\udd74\ud9c4\udcda\udbe2\ude7f\ud9a4\udfb3\ud944\udf49\ud89b\udc9e", "\u47f2\ud20f\uc877\u876a", "\udbc4\udd47\udb63\ude3c\ud830\udcfa\udb1b\ude77\uda13\udc89\ud80b\udfca\udb93\udce5",
        22, 64544, -1897833530, 8286668066675417365L, -23764L, false, true, (char) 24758, (char) 51010,
        Double.longBitsToDouble(0x3feda89ba15c5577L), Double.longBitsToDouble(0x3fdabe4b3aff52f6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 6, "\ud8e0\ude61", "\u6258\u4532\u5ad4\u784f\u4f34\u3462\u47f2\ud20f\uc877\u876a\u0ea2\u00e1\ua18a", "\ud9e3\udeba\ud826\udd78\udbcd\ude6e\ud962\udfca",
        50, 70669, -596505945, 8286629899314323733L, -31165L, true, true, (char) 24614, (char) 51010,
        Double.longBitsToDouble(0x3feda89ba2b7a5a4L), Double.longBitsToDouble(0x3fdabe4b86fd52f6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 5, "\ud8e0\ude61", "\u3516\u2deb\ua9e2\u784f\u2202\u3462\u6309\ud20f\uc877\u876a\u7c8f\u4072\ua342\ub78a\u7a40\u70e9\uca45", "\udbb8\udd72\u6c98\ud981\udc65\udbd9\udf7a\ud95e\udfc7\udaa8\udd2f\ud9f9\udc7c\ud9dd\udf19",
        58, 45085, -1227885561, 8870138827954727884L, -5195L, true, false, (char) 61615, (char) 23790,
        Double.longBitsToDouble(0x3f98d5bb604cc660L), Double.longBitsToDouble(0x3fe317773a443d54L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 5, 8, 10, "\ud8d8\udc2c\ud98f\udeb5\ud8cf\udfcb\udbe2\ude7f\ud9a4\udfb3\ud854\udf51\udb61\udca1\ud847\udebb\ud8c0\udec5\ud918\udf41\ud9a3\udfa5\ud89d\ude91\ud9f0\udc3a\ud8b7\udff4\ud96d\udc36\udbc4\udd47\uda69\udea5\uda42\ude50\ud9d1\ude39\ud919\ude0a\ud8a7\uddda\ud9e1\udfd1\ud800\udfae\udb43\udddb\ud81f\uddef\uda84\udfa4\uda01\ude90\uda06\ude9d\uda8b\udead\ud91c\udf64\udbe2\udf91\ud8a4\udc45\u3b70\ud9cf\udd5a\ud81a\ude36\ud9bd\udd23\udaf0\udc91\ud8e5\uded6\u742f\ud90a\udffa\ud8b0\udd7c\uda91\udd2b\ud8f4\udda7\uda2a\udce7\uda7d\udeb2\uda2b\udcab\ud813\udfa2", "\u8d66\u7254\u8a97\u5040\u14a4\ubbf7\u54fc", "\ud8d7\udf2e\udad0\udc0c\ud97a\udf7c\ud87f\udc46\uda0e\udc5e\ud95b\udc65\uda23\ude1b\uda17\udfb2\ud834\ude9a",
        34, 54342, -1168623298, -4106971050191710465L, 55625L, true, true, (char) 31270, (char) 1193,
        Double.longBitsToDouble(0x3fd51b4be625a48aL), Double.longBitsToDouble(0x3fd91273d4a34f10L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 6, "\ud983\udcda", "\ub40f", "\ud89b\udc9e\uda9c\udc87",
        41, 85003, -1875386740, -7534329376712723780L, 56460L, false, true, (char) 50355, (char) 59324,
        Double.longBitsToDouble(0x3fc83b7e625d9584L), Double.longBitsToDouble(0x3fe820775e22b23eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 8, 2, 6, "\ud8e0\ude61", "\u795f\u6969\ucbe0\u6523\u4eee\u3462", "\ud89d\ude91\ud9f0\udc3a\ud8b7\udff4\ud96d\udc36\udba0\ude47",
        33, 90375, -1005090635, 1075102494104675076L, 41551L, false, true, (char) 21005, (char) 46997,
        Double.longBitsToDouble(0x3fd15730072a5b84L), Double.longBitsToDouble(0x3fe8c6bac69b4d24L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 6, "\ud8e0\ude61", "\u8d9a\u3aba\ub3a9\u784f\u4f34\u3462\u0133\ud20f\uc877\u876a\u7c8f\u4072\ua342\u15e3\u796d\u70e9\ua92e", "\udbb8\udd72\u6c98\ud981\udc65\udbcf\udec6\ud95e\udfc7\udaa8\udd2f\u8718",
        -5, -1000, 1813970944, -5260780478470549435L, 43234L, false, false, (char) 23790, (char) 30163,
        Double.longBitsToDouble(0x3fe813319e62eee7L), Double.longBitsToDouble(0x3f2eaa41b1e6f000L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 0, "\ud8e0\ude61", "\ud5af\u3aba\ua507\uba4e\u64a0\u3700\ua455\ud1d5\uc877\u2527\u780e\u7e4a\ubf5b\uaa68\u796d\u70e9\uca45", "\udbd4\udd68\u49a0\uda81\udd42\ud9b8\udfcf\udae3\ude2c\ud988\ude0b\udb3a\udff2\udb63\udf30\uda7a\ude7e\ud8a3\udfa4\udbef\ude7f\udbfd\udc9b\udb60\udee8\ud9b6\udd1b\ud9df\udf09\ud9b0\udd2a\u742f\ud90a\udffa\udb75\ude1d",
        -1, 84130, 332401220, 2199418445673472641L, 55998L, true, true, (char) 10752, (char) 57341,
        Double.longBitsToDouble(0x3fc39ba08c160970L), Double.longBitsToDouble(0x3fe9107fa4ce32f7L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 12, 2, 6, "\ud8e0\ude61", "\u8d9a", "\ud89b\udc9e\uda9c\udc87",
        7, 56840, -1875386740, 8822744469896926325L, 56460L, false, true, (char) 50355, (char) 55037,
        Double.longBitsToDouble(0x3fc83b7e625d9584L), Double.longBitsToDouble(0x3ecd788800000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 13, 6, "\udb01\udd71", "\u8d9a\u539e\ub3fc\u784f\u120d\u3462\u47f2\ud20f\uc877\u876a\u7c8f\u4072\ua342\ua559\u796d\u2fb9\ua23e\u47cc\ub706\u5617\u4a71\u7dfe", "\udaa8\udd2f\udb3a\udfa3\udac9\udfc8\uda7a\ude7b\ud8a3\udfa4\uda21\udfb9\ud9d0\udd6a\udb2d\ude61\ud9b6\udd1b\udaf0\udc91\ud8e5\uded6\ud9bf\udc28\ud90a\udffa\udb75\ude1d",
        -1, 84130, -383382972, 193458957595838249L, -4100L, true, true, (char) 29804, (char) 35767,
        Double.longBitsToDouble(0x3feab01c1c08eea1L), Double.longBitsToDouble(0x3fdb368ee84b11daL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 1, 1, 6, "\ud8e0\ude61", "\u8d9a\u3aba\u72f3\u784f\u4f34\u3462\u47f2\ud20f\u2c9d\u86f8\u7c8f\u554d\u1899\u15e3\u796d\u74e9\u2d43\u46dc\ub706\u5617\u4a71\u04fe\u1c42\u77b5\u4366\u17b2", "\ud8a3\udfa4\uda21\udfb9\ud9d0\udd6a\udb2d\ude61\ud9b6\udd1b\udaf0\udc91",
        -2, 47712, -709159304, 7364405840333736706L, -97372L, false, false, (char) 8523, (char) 59006,
        Double.longBitsToDouble(0x3fe0f721265b442eL), Double.longBitsToDouble(0x3fe605ce4b76591dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 9, 5, 2, "\ud8e0\ude61\udab6\udd3a\ud8cf\udf93\udbe2\ude7f\ud9a4\udfb3\ud87c\udf54\ud89b\udd20", "\u8aee\ud20f\u2c9d\u86f8", "\uda1c\udf1d\uda66\udd5b\ud86e\ude07\ud9e4\udeba\ud826\udd78\udbcd\ude6e\ud962\udfca\udbb8\udd72\ud8f4\udee3\ud959\udc90\uda47\uddb2\u2421",
        49, 91756, 162651679, -2924792312089310907L, -46364L, true, true, (char) 22619, (char) 29283,
        Double.longBitsToDouble(0x3fbfaa5ec0471f48L), Double.longBitsToDouble(0x3fe3c233b018d5bbL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 7, 6, "\ud8e0\ude61", "\u8d9a\u7f2b\uba0d\u784f\u681b\u37b5\u1f72\ud20f\u2c9d\u86f8\u7c8f\u554d\u1899\u15e3\u796d\u3ce9\uca45\u6625\ub706\u5617\u4a71\u04fe\u1c42\u77b5\u21b4\u28f3", "\ud8a3\udfa4\uda21\udfb9\ud9d0\udd6a\udb2d\ude61\ud9b6\udd1b\udaf0\udc91",
        -2, 47712, -709159304, 7364405840333736706L, -97372L, false, false, (char) 8523, (char) 59006,
        Double.longBitsToDouble(0x3fe0f721265b442eL), Double.longBitsToDouble(0x3fe1300e4b76591dL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 5, 2, 6, "\ud8e6\udde1", "\ub2aa\u1046\u72f3\u784f\u8cc1\u8611\ub547\u75d5\u5ec6\u86f8\u7c8f\u554d\u1899\u15e3\u796d\u7470\uca45\u46dc\ub706\u5617\u4a71\u04fe\u1c42\u77b5\u4366\u17b2", "\ud8a3\udfa4\uda21\udfb9\ud9d0\udd6a\udb37\udd06\ud989\ude32\udaf0\udcb3",
        -2, 47712, -709159304, 7364405840321517058L, -97372L, false, false, (char) 48113, (char) 59006,
        Double.longBitsToDouble(0x3f9ee4248e94e500L), Double.longBitsToDouble(0x3fe601682b76591dL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 8, 8, 8, "\ud8d7\udda2\ud96c\udd74\u00f2\uda2e\uddc2\ud8cc\udc32\udbb3\udfd7\ud89b\udc9e\uda9c\udc87\uda9b\udf85\udbc8\udcd4\uda49\udf7dZ\ud9e4\udf5c\ud8b7\udff4\ud96d\udc36\udbc4\udd47\ud8a3\udd83\ud856\udca5\ud9e3\udeba\ud8aa\udd04", "\u561f", "\ud894\udf89\uda4b\udfa5\ud99e\udee2\udb3b\udc13\ud8a6\udc92\uda7a\ude7e\uda66\udf3e\ud8bd\udc25",
        56, 61605, -457657835, -6234233494056611714L, 24536L, false, false, (char) 61816, (char) 30069,
        Double.longBitsToDouble(0x3fc6d392f608e23cL), Double.longBitsToDouble(0x3fd160cd1fcda492L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 9, 9, 8, "\udb69\ude0b\ud95d\udff3\ud923\ude22\udaf0\udc89\ud896\ude56\ud8d1\ude61\ud89b\udc5e\uda9c\udc87\ud911\udf80\udbc8\udcd4\uda49\udf7d\udb91\udc85\ud9e4\udf5c\ud8b7\udff4\ud96d\udc36\udbc4\udd47\ud8a3\udd83\ud856\udca5\ud9e3\udeba\uda6d\ude1e", "\u561f\u2b69\uaea2\ud163\u6085\u112d\u5bff\u388c", "\udb2c\udddd\ud8db\udd72\udb34\udea3\ud9b6\udc79\udb68\ude2c\ud8e5\ude5f\u7503\ud9f0\udd92\udb90\udc4d\ud82d\udf33\ud8fe\udfda\ud92a\udc0b",
        59, 81790, -672839706, -1987596173769467349L, -58300L, true, true, (char) 35833, (char) 167,
        Double.longBitsToDouble(0x3fc40f4180aa8650L), Double.longBitsToDouble(0x3fd1729646abb1eaL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 1, 9, 2, 6, "\ud8e0\ude61\ud96c\udd74\ud9c4\udcda\udbe2\ude7f\ud9a4\udfb3\ud944\udf49\ud89b\udc9e", "\u47f2\ud20f\uc877\u876a", "\udbc4\udd47\udb63\ude3c\ud830\udcfa\udb1b\ude77\uda13\udc89\ud80b\udfca\udb93\udce5",
        22, 64544, -1897833530, 8286668069051578001L, -23764L, false, true, (char) 24758, (char) 10886,
        Double.longBitsToDouble(0x3feda89ba15c5577L), Double.longBitsToDouble(0x3fdabe4b3aff52f6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 1, 9, 2, 6, "\ud8e0\ude61\ud96c\udd74\ud9c4\udcda\udbe2\ude7f\ud9a4\udfb3\udb7a\udefb\udafc\udc59", "\u47f2\u5c2c\uc877\u876a", "\udbc4\udd47\udb63\ude3c\ud830\udcfa\udb1b\ude77\ud95b\udc8d\ud80b\udfca\udb93\udce5",
        24, 64544, 1931870150, 4475521721125969720L, -23764L, false, false, (char) 36385, (char) 35712,
        Double.longBitsToDouble(0x3fe119c2b9405577L), Double.longBitsToDouble(0x3fdab75baaff52f6L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 11, 5, 0, "\ud8e0\ude61", "\ud59a\u7541\u4907\uba4e\u64a0\u3700\ua455\u4e98\u78b7\u101e\u7868\u7e4a\u28d7\uab14\u2787\u56a9\uca45", "\udbd4\udd68\ud126\ud829\udda5\ud8c5\ude36\udb0a\ude85\udb0a\udcec\udb3a\udff9\udb63\udf30\udb36\ude7c\udbdf\udfa2\uda8d\udcf9\udb0c\udfc3",
        51, 73327, -1887728213, 9090015297282056005L, -75448L, false, true, (char) 21559, (char) 58446,
        Double.longBitsToDouble(0x3fc268504142f560L), Double.longBitsToDouble(0x3fb27a6bd550eb40L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 6, "\ud8e0\ude61", "\u8d9a\u3aba\ub46c\u784f\u4f34\ub28e\u47f2\ud20f\uc81d\u876a\u7c8f\u4072\000\000\000\u70e9\uca45", "\udbb8\udd72\u6c98\020\udbcf\udec6\ud95e\udfc7\udaa8\udd2f\udb3a\udfa3\ud8dd\udf2d",
        26, 45085, -1224870905, 1401763271041897397L, -70731L, false, false, (char) 7154, (char) 23790,
        Double.longBitsToDouble(0x3f98d5bb604cc660L), Double.longBitsToDouble(0x3fb8bbb9d221eaa0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 8, "\ud8e0\ude61", "\ud5af\u3aba\ua507\uba4e\u64a0\u3700\ua455\ud1d5\uc877\u2527\u780e\u7e4a\ubf5b\uaa68\u796d\u70e9\uca45", "\udbd4\udd68\u49a0\020\ud9ae\udfb6\udae3\ude2c\ud988\ude0b\udb3a\udff2\udb63\udf30\uda7a\ude7e\ud8a3\udfa4\udbef\ude7f\udbfd\udc9b\udb60\udee8\ud9b6\udd1b\ud9df\udf09\ud9b0\udd2a\u742f\ud90a\udffa\udb75\ude1d",
        -1, 84130, 332401220, 2199418445673472641L, 55998L, true, true, (char) 10752, (char) 57341,
        Double.longBitsToDouble(0x3fc39ba08c160970L), Double.longBitsToDouble(0x3fe9107fa4ce32f7L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|answer|org.mockito.invocation.InvocationOnMock|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|instantiateDelegateIfNeeded||new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|instantiateMockitoCoreIfNeeded||new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|recordDeepStubMock|java.lang.Object,org.mockito.internal.stubbing.InvocationContainerImpl|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|withSettingsUsing|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|actualParameterizedType|java.lang.Object|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|createNewDeepStubMock|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|getMock|org.mockito.invocation.InvocationOnMock,org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|returnsDeepStubsAnswerUsing|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "C|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|<init>|",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|answer|org.mockito.invocation.InvocationOnMock|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|instantiateDelegateIfNeeded||new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|instantiateMockitoCoreIfNeeded||new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|recordDeepStubMock|java.lang.Object,org.mockito.internal.stubbing.InvocationContainerImpl|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|withSettingsUsing|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
