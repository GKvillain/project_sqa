package org.mockito.internal.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class MockUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 1, 8, 8, 6, "\uda9a\udfcd\ud883\udd94\u1517", "\u3dea\u03c5\u031e\u06f9\u1f82\uacaa\ub43f\u0480\u29e7\u1f41\ua9ad\u5abe\u02c0\u7923\ucc52\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c",
        57, 12387, 1037042690, -3939311112719108445L, 84384L, false, true, (char) 44237, (char) 48674,
        Double.longBitsToDouble(0x3fea664d893a0de6L), Double.longBitsToDouble(0x3faeb84cfc5ecc70L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 1, 8, 8, 6, "\uda9a\udfcd\ud883\udd94\u1517\uda44\udd70\ud8a5\udcf5\ud957\ude26\uda49\udf3d\uda01\udf44\ud85f\udcfc\uda09\udd74\udb20\udfea\udb15\udffd", "\u1f41\ua9ad\u5abe\u02c0\u7923\ucc52\uc8fc\ub392\u773f\ud4e2\u5626\ud301\ub739\ubb93\u293f", "\udb46\udde3\ud9f2\ude87\ud8fe\udc7b\ud92e\udc7c\uda36\uddc1",
        41, 41468, -911096637, 1001517982257099066L, 33179L, false, true, (char) 46587, (char) 46043,
        Double.longBitsToDouble(0x3fe4f37a7ecaed94L), Double.longBitsToDouble(0x3fdadbb7c0f432f4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 1, 8, 8, 6, "\uda9a\udfcd\udbcd\udfd8\udbeb\udcaf", "\u3dea\u03c5\u031e\u06f9\u4818\uac86\ub43f\u0480\u29e7\u1f41\ua9ad\u46be\u02c0\u7923\ucc52\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c\ud876\udc5d\ud87f\udd41\uda0b\udfa6\ud8bf\ude31\ubfbc\ud92e\udc90\uda36\uddc1\ud8e5\udc5d\uba98\udaca\udd8f\udaab\udc1d\udaf3\udfdc\uef1b\udbe7\udff9\ud94b\udfad\udb33\udee8\uda7b\udccc\ud8bf\udc7c\udac2\udd9f\udbdf\udf55",
        50, 48921, 2066695225, 1948820577226987425L, 82366L, true, true, (char) 46592, (char) 43098,
        Double.longBitsToDouble(0x3fce25f381ae0ed8L), Double.longBitsToDouble(0x3fd056566c4b889eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 1, 2, 0, 8, "\u7fd1\ud883\udd27\u1517", "\u3dea\u00fb\000\u06f9\u1f82\uacaa\u75a1\u4426\u29e7\u1f41\ua9ad\u5abe\u02c0\u7923\ucc52\ub696\u3639\u1d48", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbdd\udded",
        57, 12387, 1037042690, -3939311112719108445L, 84384L, false, true, (char) 44237, (char) 95,
        Double.longBitsToDouble(0x3fea664d88000de6L), Double.longBitsToDouble(0x3e4f17b000000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 1, 6, 8, 6, "\uda9a\udfcd\ud883\udd94\u1517", "\u3dea\u03c5\u031e\u06f9\u1f82\uacaa\ub43f\u0480\u29e7\u1f41\ua9ad\u5abe\u02c0\u7923\ucc52\ub696\ub3d9\u729d", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c",
        57, 14411, 1037042826, -3939311112719108445L, 84384L, false, true, (char) 44237, (char) 46557,
        Double.longBitsToDouble(0x3fe5bcd924a61d2dL), Double.longBitsToDouble(0x3fe7e8c1efc5ec10L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 3, 8, 6, "\uda9a\udfcd\ud883\udd94\u1517", "\u3dea\u03c5\u031e\u06f9\u1f82\uacaa\ub43f\u0480\u29e7\u1f41\ua9ad\u5abe\ub33e\u7923\ucc52\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c",
        57, 12387, 1037042690, -3939311112719108445L, 84384L, false, true, (char) 44237, (char) 48674,
        Double.longBitsToDouble(0x3fea664d893a0de6L), Double.longBitsToDouble(0x3faeb84cfc5ecc70L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 0, 8, 9, "\ud8da\udf25\ud883\udde2\ud867\udd8e\ub2f7\ud8af\udd37\ud96a\udf70\ud8ca\ude95\ud904\udd96\ud872\udcd3\ud857\udd5a\udafc\udd8a\udb15\udffd", "\u1ede\u62e8\u5b4b\uc9c3\u95f8\u5e00\u08cd\ucece\u7738\ud4e2\u5626\uc6f7\ua0e5\u887c\ud17f", "\ud965\udd25\ud9e8\ude36\ua2b0\ud92e\udc90\ua4ff\ud8e5\udc5d\uba98\uda53\uddaa\uda18\uded4\udaf3\udfdc\uef1b\udb70\uddfe\ud8e4\udeb9\ud8b0\ude3c\udadf\ude65",
        57, 26802, -402151310, -3059854358835533334L, 27158L, false, true, (char) 31449, (char) 54979,
        Double.longBitsToDouble(0x3fd753f1b0f1b150L), Double.longBitsToDouble(0x3fb7e5855fc89648L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 1, 8, 6, "\uda9a\udfcd\ud973\udd0c\udb97\udd18", "\u91d9\u7182\u031e\u06f9\u1f82\uacaa\ub43f\uc9f9\u29e7\u173d\u5289\u5b65\u02c0\u7923\ucc52\ub696\ub3d9\ua223", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c",
        57, 90283, 1028376658, -3939311112719108445L, 88924L, true, true, (char) 44237, (char) 35182,
        Double.longBitsToDouble(0x3fe040f9bf48359fL), Double.longBitsToDouble(0x3fb9ab6efe2f6638L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 6, "\uda9a\udfcd\ud883\udd94\u1517", "\u3dea\u03c5\u031e\u06f9\ucefe\uac14\ub43f\u0480\u29e7\u1f41\ua9ad\u5abe\u02c0\u7923\u90c3\u6b22\u816b\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c",
        57, 12387, 1037042690, -3939311112719108445L, 84384L, false, true, (char) 44237, (char) 48674,
        Double.longBitsToDouble(0x3fea664d893a0de6L), Double.longBitsToDouble(0x3faeb84cfc5ecc70L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 4, 7, 0, "\uda86\udd41\ud902\udcf3\u14c5\uda44\udd70\ud8a5\udcf5\ud957\ude26\uda49\udf3d\uda01\udf44\ud85f\udcfc\ud860\udfc0\ud9b7\ude31\ud850\udc3a", "\u1f41\ua9ad\u5abe\u041f\u78d4\ucc52", "\ud8e6\udea8\udad7\udc19\ud92e\uded3\udab3\udecf\udb17\udc4f\ud989\ude73\udbaf\uddeb\udac9\udd30\ud87f\udc8b\uda0f\udca6\ud8bf\ude31\ubfbc\ud904\udf35\uda36\uddc1",
        41, 41468, -911096637, 977931258753167674L, 41741L, false, false, (char) 21392, (char) 5081,
        Double.longBitsToDouble(0x3fd12623cb302822L), Double.longBitsToDouble(0x3fd57187c624f048L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 1, 9, 8, 6, "\udafb\ude44\u9243\udbe6\udd98", "\uaeb4\u03c5\u031e\u06f9\u1f82\uacaa\ub43f\u0480\u29e7\u45f5\ubbf4\u5abe\u02c0\u7923\uc581\ucd1b\u9dc8\u4ba3", "\udab3\udf17\ud9e1\udc14\ud92d\udcd0\ud876\udc2d\ud876\udc5d\udb95\udd2b\ud857\udf0c\ud8b0\udc92\uda0a\ude65",
        41, 67808, -225059050, -6387065022278921761L, 51237L, true, false, (char) 58508, (char) 52678,
        Double.longBitsToDouble(0x3fd604a0663abfacL), Double.longBitsToDouble(0x3fc38a09ccdb0e28L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.MockUtil:@?\0121=new org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 2, 8, 8, 6, "\uda9a\udfcd\ud883\udd94\u1517", "\u3dea\u03c5\u031e\u06f9\u1f82\uacaa\ub43f\u0480\u29e7\u1f41\ua9ad\u5abe\u02c0\u7923\ucc52\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c\ud876\udc5d\ud87f\udd41\uda0b\udfa6\ud8bf\ude31\ubfbc\ud92e\udc90\uda36\uddc1\ud8e5\udc5d\ud929\udc15\udaca\udd93\udaab\udc1d\udaf3\udfdc\uef1b\udb61\udc75\uda6d\udfa6\ud900\udeae\udaf0\udebb\udbc2\udf3a\ud908\udc3a\udb58\udf9f\uda7a\udd3e\udbad\ude03\udb67\ude8f\uda2b\udfc1\u28e6\udba1\udc02\udaa8\ude7d\ud823\udcb3\uda14\udd52\ud901\udeeb\ud917\udc32\ud9fc\udf46\ud933\udfff\uda9a\udfbc\udbd9\udd97\ud87a\udfc0\ud841\udca8\udae1\udde1",
        -2, 18619, -1397456643, 4996230879239557095L, 33946L, true, true, (char) 8521, (char) 13123,
        Double.longBitsToDouble(0x3fea41e9f06207adL), Double.longBitsToDouble(0x3fc03fcb9de73418L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 1, 8, 6, "\ud9ca\udfa5\ud9a8\udf03\udbe8\ude33", "\u3dea\u03c5", "\uda09\udd74\udb20\udfea\udb0c\udcdd\ud9d8\udc57\ud847\udecd\udb81\udf03\ud975\udcc4",
        30, 13809, 1871213811, 7115669033736003653L, -71471L, false, true, (char) 22610, (char) 18876,
        Double.longBitsToDouble(0x3fe1f9f3b6c6649eL), Double.longBitsToDouble(0x3feedeb8ee728ffdL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 1, 2, 5, 4, "\uda9a\udfcd\ud883\udd94\u1517", "\u3dfe\u03c5\u1dc8\u06f9\u1f82\uacaa\ub43f\u0480\u52e7\u1f41\u647c\u5ac7\u02c0\u7923\ucc52\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c\ud876\udc5d\ud87f\udc96\uda0b\udfa6\ud8bf\ude31",
        -3, 47440, -1848717248, -3327782897760347396L, 38017L, false, true, (char) 26838, (char) 58508,
        Double.longBitsToDouble(0x3fccd93bae4e0ef4L), Double.longBitsToDouble(0x3fdf97c170d5a392L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 0, 4, 9, "\uda9a\udfcd\ud883\udd94\u1517\uda44\udd70\ud8a5\udcf5\ud9e9\udd8f\uda49\udef4\uda03\udf05\ud835\udf62\uda09\udd74\udaca\udc1d\udaff\udc5f", "\u7d40\ua9ad\u88c3\u3d71\u7923\ucc52\ub696\ub3d9\u773f\u72dc\u61dd\ud301\ub739\u4f0b\ud17f", "\ud8ee\udd58\ud8bf\ude31\ubfbc\ud92e\udc90\ud8de\udf95\ud8e5\udd3f\uba98\udaa2\udc8f\udaab\udc1d\ud99f\udd8f\uda8a\udfe7\ud8a6\udd74\udafc\udcca\ud997\udf4f\uda20\udecb",
        11, 44268, 491232406, 5807080521451026924L, 45008L, false, false, (char) 54002, (char) 48480,
        Double.longBitsToDouble(0x3fe2227991a86d5bL), Double.longBitsToDouble(0x3fcd30a1e45d37f0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 1, 5, 8, 6, "\uda9a\udfcd\ud883\udd94\u1517", "\u3dea\u072f\u02ad\u06f9\u1f82\uacaa\ub43f\u0480\u4d07\u0ae3\ua9ad\u5abe\u02c0\u7923\u1323\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c",
        57, 12387, 1037042690, -3939311112719108445L, 84384L, false, true, (char) 44237, (char) 48740,
        Double.longBitsToDouble(0x3fea664d893a0de6L), Double.longBitsToDouble(0x3fe9eb84c82228fbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.MockUtil:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 8, 0, 3, "\uda9a\udfcd\ud9e7\udf4c\ud95b\udcd3", "\u6b7a\ucab0\u031e\u9947\u4eb0\u0612\u4e53\u0480\u12e7\u1f41\u4d43\u0735\u7946\u7923\ucc52\ub696\ub3d9\u773f\u0ce3\u29b4\ud301\u558f\u0152\ud17f\u8c59\u1f1a\u9d44\ua09e\u2cb7\u7c33\u3da6\uc08d\u9b21", "\ud8bf\udf82\u89c4\udbac\udd7b\uda1e\udc5f\ud84d\udd8e\uc34a",
        0, 81928, 1147917790, 7002903495494958202L, 77041L, false, false, (char) 47030, (char) 12078,
        Double.longBitsToDouble(0x3fe800f90fabd7f7L), Double.longBitsToDouble(0x3fdf071d0efed2a0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 6, "\uda9a\udfcd", "\uccad\u2a2e\u3dea\u03c5\u031e\u06f9\u1f82\uacaa\ub43f\u1d47\u71dd\u647d\u09a6\u5abe\u02c0\u7923\ucc52\ubafa\u7d68\u0d4f\ud4c9\u5626\ud2c6\ub739\ubb93", "\ud87f\udd41\uda0b\udfa6\ud8bf\ude31\ubfbc\udac7\uddb3",
        7, 61166, -111158532, 9129294261688573300L, 67966L, false, false, (char) 876, (char) 44591,
        Double.longBitsToDouble(0x3fe544ed45c0f4d3L), Double.longBitsToDouble(0x3fd6cd39ff230c96L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.MockUtil:@?\0121=new org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 2, 8, 8, 6, "\uda9a\udfcd\udbcd\udfd8\udbeb\udcaf", "\u3dea\u03c5\u031e\u06f9\u4818\uac86\ub43f\u0480\u29e7\u1f41\ua9ad\u46be\u02c0\u7923\ucc52\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c\ud876\udc5d\ud87f\udd41\uda0b\udfa6\ud8bf\ude31\ubfbc\ud92e\udc90\uda36\uddc1\ud8e5\udc5d\uba98\udaca\udd8f\udae1\uddd2\udaf3\udfdc\uef1b\udbe7\udff9\ud94b\udfad\udb33\udee8\uda7b\udccc\ud8bf\udc7c\udac2\udd9f\udbdf\udf55",
        50, 48921, 2066695225, 1948820577226987425L, 82366L, true, true, (char) 46592, (char) 43098,
        Double.longBitsToDouble(0x3fce25f381ae0ed8L), Double.longBitsToDouble(0x3fd056566c4b889eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.MockUtil:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 2, 8, 5, 6, "\uda9a\udfcd\udbb6\udcd1\udbeb\udcaf", "\u3dea\u03c5\u031e\u06f9\u4818\uac86\ub43f\u180e\u67aa\u1f41\ua9ad\u46be\u02c0\u7923\ucc52\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c\ud876\udc5d\ud87f\udd41\uda0b\udfa6\ud8bf\ude31\ubfbc\udb6f\udf12\uda36\ude76\ud8e5\udc5d\uba98\udaca\udd8f\udaab\udc1d\udaf3\udfdc\uef1b\udbe7\udff9\ud94b\udfad\udb33\udee8\uda7b\udccc\ud8bf\udc7c\udac2\udd9f\udbdf\udf55",
        50, 48921, 2066695225, 1948820577226987425L, 82366L, true, true, (char) 46592, (char) 43098,
        Double.longBitsToDouble(0x3fce25f381ae0ed8L), Double.longBitsToDouble(0x3fd056566c4b889eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.MockUtil:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 2, 0, 8, "\u7fd1\ud883\udd27\u1517", "\u1dea\u6c83l\u4b7d\u1f82\uacaa\u75a1\u4426\u29e7\u6841\ua9ad\u5abe\u6fbf\u7923\u8dae\ub696\u3639\u1d48", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbdd\udded",
        57, 38571, 1037042735, -3939311112719108445L, 84384L, false, true, (char) 44237, (char) 95,
        Double.longBitsToDouble(0x3fea664d8aaea436L), Double.longBitsToDouble(0x3fc00db37f17b000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 6, 4, 8, "\u7fd1\ud883\udd27\u1517", "\ud024\ud11b\000", "\udb20\udfea\u75a1\ud8e1\udc2f\ud896\udebf",
        31, 37267, -1607487980, -4674042545071121901L, -56411L, true, true, (char) 12282, (char) 50786,
        Double.longBitsToDouble(0x3fe123c1721976c3L), Double.longBitsToDouble(0x3fe028cc618c9f25L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 2, 6, 6, 6, "\ud8a1\udef1\udb93\ude8d\u1517", "\u125b\u03c5\u031e\u06f9\u1f82\uacaa\ub43f\u0480\u29e7\u1f41\ua9ad\u5abe\u3fb4\u99b9\ucc52\ub696\ub3d9\u0205", "\ud828\ude91\udbb5\udcde\ud934\udeeb\udb8e\udfdb\ud921\udd6e\uda20\udc0e",
        -4, 88658, 312538787, 5351097896811810880L, -90524L, false, false, (char) 24027, (char) 35283,
        Double.longBitsToDouble(0x3fe7e8c1efc5ec10L), Double.longBitsToDouble(0x3fee8f404d31622aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 0, "\uda86\udd41\ud902\udcf3\u14c5\uda44\udd70\ud8a5\udcf5\ud957\ude26\uda49\udf3d\uda01\udf44\ud85f\udcfc\ud860\udfc0\ud9b7\ude31\ud850\udc10", "\u1a41\ua9ad\u5abe\u041f\u78d4\ucc52", "\ud881\uddab\udab6\udf77\ud8ee\uddde\ud872\udf2f\udb17\udc4f\ud989\ude73\udbaf\uddeb\udac9\udd30\ud87f\udc8b\uda0f\udca6\ud8bf\ude31\ubfbc\ud904\udf35\uda36\uddc1",
        41, 41468, -911096637, 977931258753167674L, 41741L, false, false, (char) 21392, (char) 5081,
        Double.longBitsToDouble(0x3fdc4623cc2c3c28L), Double.longBitsToDouble(0x3fef2986e3ab9ef8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 6, 1, 0, "\uda86\udd41", "\uccad\ud33f", "\ud9c5\udc0a\ud85f\udcfc\ud860\udfc0\ud9b7\ude31\ud850\udc0b\udbd0\udee6",
        19, 90798, 1264861299, 1742758399092888225L, 70686L, false, false, (char) 20324, (char) 38468,
        Double.longBitsToDouble(0x3fe06a04108fdd2eL), Double.longBitsToDouble(0x3fd5626775963210L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\0121=new org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 2, 6, 9, 3, "\uda9a\udfcd\ud9c5\udd4c\ud95b\udcd3", "\u6b7a\u9602\u1815\u9947\u4eb0\u0612\u4e53\u0480\uc7f8\u8d56\u17e0\ud6e8\u7946\u7923\ucc52\ub696\ub3d9\u773f\u0bca\u891a\ud301\u558f\u0152\u2549\u2684\u1f1a\u9d44\ua09e\u2cb7\u7c33\u3da6\u041d\ub948", "\ud8bf\udf82\u89c4\udbac\udd7b\uda1e\udc5f\ud84d\udd8e\uc34a\udaed\ude18",
        6, 54186, 1641435040, 5571371075384111398L, 55490L, false, true, (char) 12078, (char) 55840,
        Double.longBitsToDouble(0x3fed5ebfbdf071d0L), Double.longBitsToDouble(0x3febfb4a83d7e6fdL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.MockUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 3, "\udb1f\ude70\ud93c\udfc4\ud95b\udcd3", "\u6b65\ucab0\u031e\u9947\u116a\u1c4f\u8b75\u0479\u12e7\u1f41\u4d43\uaafd\u7946\u7923\ucc52\ub696\ubc6c\u773f\u0ce3\u29b4\ud301\u558f\u0152\ud17f\u8c59\ua8e1\u5940\ua0e4\u2cb7\u7c33\u3da6\u9ff9\u471c", "\ud8bf\udf82\u89c4\ud8c0\udf82\uda1e\udc5f\ud84d\udd8e\uc34a",
        8, 81928, -15749666, 7003096175944825978L, 77041L, false, false, (char) 47030, (char) 12078,
        Double.longBitsToDouble(0x3fe800f90fabd7f7L), Double.longBitsToDouble(0x3fd1271d0efed2a0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.MockUtil:@?\0121=null |this=org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 2, 2, 2, 3, "\uda9a\udfcd\ud9e7\udf4c\ud95b\udcd3", "\u099a\ucab0\u031e\u9947\u4eb0\u0612\u4e53\u0480\u12e7\u1f41\u4d43\u0735\u7946\u7923\ucc42\ub696\ub3d9\u773f\ubd41\u29b4\u859a\u4ffa\u0152\ud17f\u8c59\u1f1a\u9445\ua09e\u2cb7\u5988\u3da6\uc08d\u9b21", "\ud9ba\udd0a\u9958\udbac\udd7b\uda1e\udc5f\ud84d\udd8e\uda3f\udd07\ud842\udd70\ud842\udd7f\ud8c8\udd4a\ud88b\udd5a\ud9be\udd08\ud9ae\udc5f",
        16, 11098, -155752120, 2243136168192883456L, -37040L, true, true, (char) 27534, (char) 39681,
        Double.longBitsToDouble(0x3fa41df5ef4d2680L), Double.longBitsToDouble(0x3fa0831521ceb0b0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.MockUtil:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 8, 1, 3, "\uda9a\udfcd\udbb6\udcd1\udbeb\udcaf\uda44\udd70\ud8a5\udcf5\ud957\ude26\uda49\udf3d\udbc4\udc70\udb95\udfb8\udb94\udf3a\udb20\udfc6\udb15\udffd\ud96a\udef2\ud857\udc90\udb81\udf03\ud975\udcc4\udb80\udf80\ud978\udfce\uda84\udf85\ud9a9\udcde\u23d2", "\ua294\u6012\ud301\ub739\ubb93\ud17f\u92b8\ud6f1\u5ad6\ua07c\u2cb7\u5d57\u3e5b\u306d\u9a9f\ud483\u13c5\u56ae\ua175\u63ee\u7cd8", "\ud8bf\udc7c\udac2\udd9f\udbdf\udf55\ud972\ude81\ue490\ud998\udf7b\u5b95\udb31\udd15\ud93b\udecc\ud870\udf1c",
        13, 22973, 798767224, -8955912597586653077L, 37691L, false, false, (char) 15149, (char) 14512,
        Double.longBitsToDouble(0x3fdbadb41672a898L), Double.longBitsToDouble(0x3fe70cab3b3398bdL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 2, 5, 5, 6, "\uda9a\udfcd\udbb6\udcd1\udbeb\udcaf", "\u3dea\u03c5\u031e\u06f9\u4818\uac86\ub43f\u180e\u67aa\u1f41\ua9ad\u46be\u02c0\u7923\ucc52\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud935\udd3a\udbf4\udc2c\ud84b\udfa8\ud8ae\udcc1\uda0b\udfa6\ud8bf\ude31\ubfbc\udb6f\udf12\uda36\ude76\ud8e5\udc5d\udbba\udfbe\udb15\udc50\udadb\udf96\udaf3\udfdc\uef1b\udbe7\udff9\ud94b\udfad\udb33\udee8\uda7b\udccc\ud8bf\udc7c\udac2\udd9f\udbdf\udf55",
        50, 48921, 2066695225, 1948820577226987425L, 82366L, true, true, (char) 46592, (char) 43098,
        Double.longBitsToDouble(0x3fce25f381ae0ed8L), Double.longBitsToDouble(0x3fd056566c4b889eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.util.MockUtil:@?\012",
        Z.run(T, 2, 5, 5, 6, "\udba0\udf91\ud8c5\udf39\udb12\udced\uda44\udd70", "\u03c5", "\udbe0\udf12\udb20\udfd7\udb15\udffd\ud902\udc5e\ud857\udc90\udb81\udf03\ud975\udcc4",
        45, 13809, 1871213811, 7115669033736003653L, 25454L, false, true, (char) 8973, (char) 48198,
        Double.longBitsToDouble(0x3fe1f9f3b2c6649eL), Double.longBitsToDouble(0x3feedeb8edb8d846L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 6, "\uda9a\udfcd\udbb1\udeeb\u1517", "\u3e68\u03c5\u5c0d\u06f9\u1f82\u24dd\ub43f\u0480\u29e7\u1f41\ua9ad\u5abe\u02c0\u7923\ucc52\ub696\ub3d9\u773f", "\udab3\udecf\udb17\udc4f\ud947\udf3a\udbf4\udc2c",
        57, 12420, 1037042690, -3939311112719108445L, 84384L, false, true, (char) 44237, (char) 48674,
        Double.longBitsToDouble(0x3fb3326c4b156990L), Double.longBitsToDouble(0x3faeb84cfc5ecc70L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.util.MockUtil|resetMock|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.util.MockUtil|createMock|java.lang.Class,org.mockito.internal.creation.MockSettingsImpl|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.util.MockUtil|getInterceptor|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.util.MockUtil|getMockHandler|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.util.MockUtil|getMockName|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.util.MockUtil|isMock|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.util.MockUtil|isMockitoMock|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.util.MockUtil|newMethodInterceptorFilter|org.mockito.internal.creation.MockSettingsImpl|new:org.mockito.internal.util.MockUtil:",
    "C|org.mockito.internal.util.MockUtil|<init>|org.mockito.internal.util.MockCreationValidator",
    "C|org.mockito.internal.util.MockUtil|<init>|",
    "M|org.mockito.internal.util.MockUtil|resetMock|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
