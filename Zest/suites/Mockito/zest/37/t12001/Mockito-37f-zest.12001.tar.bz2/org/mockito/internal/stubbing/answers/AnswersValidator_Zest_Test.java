package org.mockito.internal.stubbing.answers;
import org.junit.Test;
import static org.junit.Assert.*;
public class AnswersValidator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 5, "\uda9a\udcc9\udbe1\udff5\ud96d\udc4b\uda1f\udfbd\udb3d\udc04\udbc5\ude2d\ud812\udc6e\udad2\udce8\udb4d\udc14\ud99f\udeaf\ud8b5\udd9e\udba7\uded9", "\u96e7\ud5f4\u673f", "\ud8e4\udfde\udb3c\udc35\udb69\udf42\udabb\ude71",
        48, 8677, -166446001, 5552265556043887886L, 49312L, true, true, (char) 17749, (char) 32133,
        Double.longBitsToDouble(0x3fef317754c30cefL), Double.longBitsToDouble(0x3fe3a3381e0a5890L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 3, "\uda9a\udcc9\udbe1\udff5\u5820\uda1f\udfe5\udb3d\udc04\udbc5\ude2d\ud812\udc6e\udad2\udce8\udb4d\udc14\ud99f\udeaf\ud8b5\udd9e\udba7\uded9", "\ub68b\ud5f4\u673f", "\ud8e4\udfde\udb3c\udc35\udb69\udf42\udabb\ude71",
        48, 8677, 521419855, 5552266247533622542L, 49312L, true, true, (char) 17749, (char) 34949,
        Double.longBitsToDouble(0x3fef35083cc30cefL), Double.longBitsToDouble(0x3fe3a3381e0a5890L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.answers.AnswersValidator:@?\012",
        Z.run(T, 1, 0, 2, 1, "\uca36\udaae\ude57\ud96d\udc4b\u009c\000\udbc5\ude2d\000\udad1\udff2\udb4d\udc14\u2de6\ud881\ude9f\udba7\uded9", "\u965e\ud5f4\u673f", "\ud8e4\udfde\udb3c\udc35\udb69\udf42\udabb\ude71",
        48, 8677, -166446001, 5552265556043887886L, 49312L, false, true, (char) 17749, (char) 32133,
        Double.longBitsToDouble(0x3fef317754c30cefL), Double.longBitsToDouble(0x3fe3a3381e0a5890L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.answers.AnswersValidator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 5, "\uda9a\udcc9\udbe1\udff5\ud96d\udc4b\uda1f\udfbd\ud9d5\udd52\udbdb\udc32\ud93a\ude2b\udad2\udce8\udb4d\udc14\ud99f\udeaf\ud9ea\udd9f\udba7\uded9", "\u1637\ud5f4\u6741", "\udb9f\udf06\udbb3\ude9e\ud9a9\udcaa\ud83f\udd72",
        41, 56020, -166446001, 5552265556578000142L, -53651L, false, true, (char) 17749, (char) 32133,
        Double.longBitsToDouble(0x3fef317754c30cefL), Double.longBitsToDouble(0x3fe3a3381e0a5890L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 5, "\uda9a\udcc9\udbe1\udff5\udac8\udc98\uda1f\udf6e\udb3d\udc04\udbc5\ude2d\ud825\uddb8\udbf6\udcbf\udb4d\udc66\ud99f\udeaf\ud8b5\udd9e\udba7\uded9", "\u1113\u3877\ubece", "\u813e\udb3b\udfbb\udb69\udf42\ud8ca\udff4",
        28, 46743, -166446021, 5594766078503941390L, 49312L, true, true, (char) 17749, (char) 32133,
        Double.longBitsToDouble(0x3fef317756090cefL), Double.longBitsToDouble(0x3fe3a3381e0a5890L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.answers.AnswersValidator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 4, "\uda9a\udcc9\udbe1\udff5\ud96d\udc4b\u0d6f\udb54\udddc\udbc5\ude2d\ud812\udc6e\udad2\udce8\udb4d\udc14\ud99f\udeaf\ud8b5\udd9e\udba7\uded9", "\u96e7\ud5f4\u673f", "\ud93b\udc59\uda33\udfde\udb69\udf42\udabb\ude71",
        48, 69533, -465356036, 364118785313076714L, 60832L, true, true, (char) 17749, (char) 32133,
        Double.longBitsToDouble(0x3fef317754c30cefL), Double.longBitsToDouble(0x3fe3a3381e0a5890L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.answers.AnswersValidator:@?\0121=void |this=org.mockito.internal.stubbing.answers.AnswersValidator:@?\012",
        Z.run(T, 2, 0, 0, 5, "\ud99d\udc8b\uda37\udf84\ud8ee\udebe\ud954\udc9e\udabb\udee3\udbc5\ude2d\ud804\udfa8\ud890\udd12\udb4d\udc14\ud99f\udeaf\ud8b5\udd9e\udba7\uded9", "\u96e7\ud5f4\uca1f", "\udbbb\ude67\ud913\udde3\udaf1\udc42\uda9d\udef4\udbad\ude2e\udb11\ude08\ud924\udfb9\ud9be\udca5\udb4b\udf54\ufd1c\uda38\udd44\udb55\udc06",
        4, 41342, 216991648, 7425511935259461236L, -30246L, false, false, (char) 12068, (char) 65409,
        Double.longBitsToDouble(0x3fed6acee9cd974bL), Double.longBitsToDouble(0x3fc8e3c0f1376a98L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.answers.AnswersValidator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 0, "\uda6f\udc23\ud80d\udc9c\udbdf\udc6d\uda1f\udfbd\udb3d\udc04\ud9ce\ude59\ud811\udffe\ud987\udf82\ud806\udc65\u7bc7\ud8b5\udd9e\udba7\uded9", "\u8c97\u3869\u59ec", "\ud8e4\udfde\ud8e1\udd47\ud943\udcce\u0539",
        -3, 8677, 880109391, 4111488959358690579L, 49312L, true, true, (char) 55892, (char) 53026,
        Double.longBitsToDouble(0x3fef300c6d4799efL), Double.longBitsToDouble(0x3fc1f1007829607cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.answers.AnswersValidator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 5, "\uda9a\udcc9\udbe1\udff5\ud96d\udc4b\ud812\udcb8\uda19\udd32\udbc5\ude2b\udadb\udcd2\udad2\udce8\udb4d\udc14\ud99f\udeaf\ud911\udf4d\udb7e\uddd9", "\u2e49\ua64f\u673f\ua9a7\u52f0\ub143\ub68a\u0fcb\uc1b4\u61b5\u0c33\ub86b\u8be5", "\udac5\udc74\udb55\udc06\uda88\uddf1\udb36\udfa1\ud85e\udc86\ud85c\uded5\udaa1\ude8d\ud9fc\ude8f\udba1\udc2d\ud8d9\udde3\udb78\udf09",
        58, 44255, -176365595, 5705602467275169366L, -97088L, false, true, (char) 50074, (char) 27869,
        Double.longBitsToDouble(0x3fef449418e34dfeL), Double.longBitsToDouble(0x3f36d78946fd4000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.answers.AnswersValidator:@?\0121=new org.mockito.internal.stubbing.answers.AnswersValidator:@?\012",
        Z.run(T, 2, 5, 5, 5, "\ud857\udd92\udbe2\udc19\ud96d\udc4b\uda1f\udfbd\ud825\udf59\ud893\ude4d\uc309\udaeb\udef0\udb42\ude9b\ud88d\udda4\ud926\udd5d\udbda\ude19", "\u5593\u519b\ubc6d\ua9a7\u52f0\ub164\ub68a\u0fcb\u858f", "\ud806\ude09\ud9be\udca5\udb4b\udf54\ufd1c\uda38\udd44\ud806\udf97\uda65\udc5b\udbbe\udfa1\udb0f\udf16\ud9cd\udfdf\udb78\udfa6\ud999\udf10\uaf5f\ud87b\ude1f\ud9c1\udc2c\udb9f\udc37\ud8b5\udd5f\ud956\udd7a\ud840\udc56\u960c\ud836\ude7d\ud9fe\udf68\ud9af\udca6",
        51, 732, -878883398, -8922998488980830687L, 81635L, false, true, (char) 64459, (char) 7793,
        Double.longBitsToDouble(0x3fe59624f741168bL), Double.longBitsToDouble(0x3fee47ed8adf6395L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.answers.AnswersValidator:@?\012",
        Z.run(T, 1, 5, 2, 1, "\udb49\udc6f\udacf\udf44\ud987\udedf\uda39\udfa2\000\ud9e6\udcff\uda31\udf6f\uda7a\udd25", "\u7d11\u297e", "\ud869\udf5d",
        15, 10371, -379649927, -6878387468503526063L, -39552L, false, false, (char) 11166, (char) 57113,
        Double.longBitsToDouble(0x3fd9b5518837ed7aL), Double.longBitsToDouble(0x3fd0e4d0d4310118L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.answers.AnswersValidator:@?\012",
        Z.run(T, 1, 5, 5, 2, "\uca36\udaae\ude57\ud96d\udc4b", "\ubb7e\u5987\ud616\uce01\ud2ec\u60af\uc53f\u0882\u849d\u965e\ucce7\u891a\u22fc\u6b6f\u0bea\ub68a\u0fcb\u4fa1\ub977", "\udabc\udfee\udad7\udeeb\uda14\udee5\ud935\udf3a\ud99b\udd63\udaa8\uddbf\udb36\udfa1\ud84a\udca9",
        12, 49191, -1675743734, -8451163217685539597L, -13161L, false, true, (char) 35584, (char) 6398,
        Double.longBitsToDouble(0x3fdccb5c60251322L), Double.longBitsToDouble(0x3fe2d3dee82491f6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 5, "\uda9a\udcc9\udbe1\udff5\ud96d\udc4b\uda1f\udfbd\udb3d\udc04\udb97\udf57\uda18\udc2d\udad2\udc12\udb4d\udc14\ud99f\udeaf\ud8b5\udd9e\udba7\uded9", "\u7817\u816e\u673f", "\ud8e4\udfde\udb3c\udc35\udb69\udf42\udabb\ude71",
        48, 8677, 185875535, 6739564833586410761L, 49312L, true, true, (char) 17749, (char) 14470,
        Double.longBitsToDouble(0x3fef317765c30cefL), Double.longBitsToDouble(0x3fe3a08e170a5890L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.stubbing.answers.AnswersValidator:@?\0121=new org.mockito.internal.stubbing.answers.AnswersValidator:@?\012",
        Z.run(T, 2, 6, 5, 5, "\uda9a\udcc9\udbe1\udff5\ud96d\udc4b\uda1f\udfbd\uda23\udd59\udbdb\udc32\ud907\udef4\udad2\udce8\udb4d\udc14\udb34\udeda\ud9ea\udd19\udba7\uded9", "\u1637\ud5f4\u6741", "\udb9f\udf06\uda34\uddb5\ud83c\ude27\ud83f\udd72",
        41, 56020, -166446001, 5552265556578000142L, -53651L, false, true, (char) 17749, (char) 32133,
        Double.longBitsToDouble(0x3fef317754c30cefL), Double.longBitsToDouble(0x3fe3a33b76ff5890L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.stubbing.answers.AnswersValidator|validate|org.mockito.stubbing.Answer,org.mockito.internal.invocation.Invocation|new:org.mockito.internal.stubbing.answers.AnswersValidator:",
    "M|org.mockito.internal.stubbing.answers.AnswersValidator|validateMockingConcreteClass|org.mockito.internal.stubbing.answers.CallsRealMethods,org.mockito.internal.invocation.Invocation|new:org.mockito.internal.stubbing.answers.AnswersValidator:",
    "M|org.mockito.internal.stubbing.answers.AnswersValidator|validateDoNothing|org.mockito.internal.stubbing.answers.DoesNothing,org.mockito.internal.invocation.Invocation|new:org.mockito.internal.stubbing.answers.AnswersValidator:",
    "M|org.mockito.internal.stubbing.answers.AnswersValidator|validateException|org.mockito.internal.stubbing.answers.ThrowsException,org.mockito.internal.invocation.Invocation|new:org.mockito.internal.stubbing.answers.AnswersValidator:",
    "M|org.mockito.internal.stubbing.answers.AnswersValidator|validateReturnValue|org.mockito.internal.stubbing.answers.Returns,org.mockito.internal.invocation.Invocation|new:org.mockito.internal.stubbing.answers.AnswersValidator:",
    "C|org.mockito.internal.stubbing.answers.AnswersValidator|<init>|",
    "M|org.mockito.internal.stubbing.answers.AnswersValidator|validate|org.mockito.stubbing.Answer,org.mockito.internal.invocation.Invocation|new:org.mockito.internal.stubbing.answers.AnswersValidator:",
    "M|org.mockito.internal.stubbing.answers.AnswersValidator|validateMockingConcreteClass|org.mockito.internal.stubbing.answers.CallsRealMethods,org.mockito.internal.invocation.Invocation|new:org.mockito.internal.stubbing.answers.AnswersValidator:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
