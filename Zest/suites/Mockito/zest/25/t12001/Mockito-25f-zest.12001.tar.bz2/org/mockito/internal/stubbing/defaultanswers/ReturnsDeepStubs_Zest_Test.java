package org.mockito.internal.stubbing.defaultanswers;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReturnsDeepStubs_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 10, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\ud870\uddc3\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud870\udf2b\udb2c\udf93\udbe2\udc15\ud93c\ude30\ud887\ude9c\udbcf\ude49\udb8b\udd70\ud9c9\ude87\udb69\ude41\ud945\udfcc\udaa0\udf8c\udbab\udf0d\ua9d9\udbbf\udc4c\ud85e\udfbb\ud936\udf79\ud867\udeb2", "\u2552\ua4d9\u574d\ua549\u4753\u88a9\u6ff0\u5575\u6418\u275f\u7b81", "\udaf9\udc84\uda86\udd78\uda8a\udc2d\uda02\udd85\uda48\udfbe",
        50, 62105, 75549409, 6234581146618434180L, 56146L, false, true, (char) 34534, (char) 38095,
        Double.longBitsToDouble(0x3fd23c931b9ab234L), Double.longBitsToDouble(0x3fdd552e1f31858cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 5, "\udb24\ude54", "\u9acc\u783a\u09e9\u9e45\u2b56\u5008\ud12d3\000\000\u0d1b\u026e\ube5c", "\000\udb60\udfd0\udbbf\udc4c",
        57, 11806, 301538723, 3649944828821616959L, -100000L, false, false, (char) 23587, (char) 4141,
        Double.longBitsToDouble(0x3f4d698400000000L), Double.longBitsToDouble(0x3fa03f43977a9600L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 10, "\udb24\ude2d\udba6\udfb9\ud8c1\udc6c\ud870\uddc3\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud870\udf2b\udb4a\udc93\udbe2\udc15\ud93c\ude30\ud887\ude9c\udbcf\ude49\udb8b\udd70\uda51\udf4b\udb59\ude1d\ud945\udfcc\udaa0\udf8c\udbab\udf0d\ua9d9\udbbf\udc4c\ud85e\udfbb\ud8f6\udd57\ud867\ude2d\ud888\udc78\udb11\udc7a\udb4f\udd17", "\ua549\u4753\u88a9\u6ff0\u2066", "\uda6a\udd6e\uda1e\ude9f\ud878\udd70",
        9, 41727, -2116638819, 5447487551141629524L, 56010L, true, false, (char) 59574, (char) 16393,
        Double.longBitsToDouble(0x3fd96478ac1d962cL), Double.longBitsToDouble(0x3fd046651dad69dcL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 2, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\ud870\uddc3\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud870\udf2b\udb2c\udf93\udbe2\udc15\ud93c\ude30\ud887\ude9c\udbcf\ude49\udb8b\udd70\ud9c9\ude87\udb69\ude41\ud945\udfcc\udaa0\udf8c\udbab\udf0d\ua9d9\udbbf\udc4c\ud9d0\udfb4\ud936\udf79\ud867\udeb2", "\u2552\ua4d9\u574d\ua549\u4753\u88a9\u6ff0\u5575\u6418\u275f\u7b81", "\udaf9\udc84\uda86\udd78\uda8a\udc2d\uda02\udd85\uda48\udfbe",
        50, 62105, -257974934, 6234581146618434180L, 56146L, false, true, (char) 34534, (char) 38095,
        Double.longBitsToDouble(0x3fd23c931b9ab234L), Double.longBitsToDouble(0x3fdd552e1f31858cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 6, 7, 7, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\ud870\uddc3\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud870\udf2b\udb2c\udf93\udbe2\udc15\ud93c\ude30\ud887\ude9c\udbfd\udd1f\udb3a\udc00\ud885\udda5\udb51\udd79\ud945\udfcc\udaa0\udf8c\udbab\udf0d\ua9d9\udbb8\udd40\ud91e\udf21\uda2b\ude01\ud867\udec1", "\u2552\ua4d9\u00c9\ua5ab\u4753\u88a9\u6ff0\u5575\u9cfc\ud295\u7b81", "\udaf9\udc84\uda86\udd78\uda8a\udc2d\ud96c\udf1b\uda1b\udf17",
        50, 62105, 75549409, 1983183098380682775L, 56146L, false, true, (char) 34534, (char) 38095,
        Double.longBitsToDouble(0x3fd23c931b9ab234L), Double.longBitsToDouble(0x3fdd552e1f31858cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 8, "\ud87b\udcc4", "\u9a87\u783a\u09e9\u9e92\u2b56\u5008\ud12d\u6752\u7269\u56aa\u0e07\u026e\ube5c\u0ad2\ub19e\u27b3\u5697\u7b3f\u56ae", "\ud8a5\udfe9\ud885\udd69\ud9fc\ude22\uda78\udcf4\ud95b\udee5\ud848\ude09\udac1\udea3\uda4c\udd4e\uda21\ude7c\ud93a\udc5d\ud869\udf37\udac1\udce5\ud89a\udc59\ud84e\udd59\ud80b\udc5d\ud9b6\ude1b\uda86\udd78\uda8a\udc2d\uda46\ude48\ud921\udf29\ud903\ude5c\udbc5\uddd3\udb9c\udf33\ud920\udf9e\uda4e\udd87\uda39\udd61\uda79\udc15\udb95\uddb9\ud97e\uddb0\ud886\udf2b\ud8ee\ude63\ud95f\udfb9\uda0c\uddf1\ud9dc\ude34\ud8ce\ude21\ud924\udd67\udb87\uddd6\u6e95\ud8aa\udc3e\ud930\ude70\ud9f9\uddef\uda18\udd56\ud801\udd7c\udabe\uddb5\ud808\udf4d\u12f0\ud97f\udda5\uda62\ude76\ud8b7\ude44\ud968\udd4a\ud9c2\udc8b\uda31\ude63\udb69\udfc1\udb7f\udd20\ue390\ud8a4\udc2f\ud853\uddf1\ud97e\udf56\uda49\udfd9\ud937\udca6",
        58, 29245, -217218399, -3423956889597942690L, -37173L, true, true, (char) 11626, (char) 44858,
        Double.longBitsToDouble(0x3fe7e89fc8911c39L), Double.longBitsToDouble(0x3fc1a4d83acd5ed0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 12, 7, 2, "\ud9ff\ude3c", "\ud7e3", "\udaa1\ude99\ud870\udf2b\udb2c\udf93\udbe2\udc15\ud93c\ude30\ud887\ude9c\udbcf\ude49\ud95c\udd9a\ud9c9\ude87\udb5b\uddb7\ud945\udfcc\udaa0\udf8c\udbab\udf0d\ua9d9\ud8dc\udc9a",
        19, 11802, 301538723, 3649944828821616959L, 65026L, false, true, (char) 14655, (char) 6982,
        Double.longBitsToDouble(0x3fa03f43977a9600L), Double.longBitsToDouble(0x3fec9cb1c798cd34L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 7, 7, 10, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\ud870\uddc3\uda65\udd37\ud807\udcdd\ud828\udc4b\ud87c\udd94\udb2c\udf93\udbff\udc15\ud93c\ude30\ud887\ude9c\udbcf\ude49\udb8b\udd70\ud9c9\ude87\udafb\udfe7\udbd9\udccc\uda27\udedd\ud9c2\udd78\uff15\udbbf\udc4c\ud85e\udfbb\ud936\udf79\ud867\udeb2", "\u2552\ua4d9\u574d\u9649\u4753\u88a9\u6ff0\u5575\u6418\u275f\u7b81", "\udaf9\udc84\uda86\udd78\uda8a\udc2d\uda02\udd85\uda48\udfbe",
        50, 62105, 75549409, 6234581146618434180L, 56146L, false, true, (char) 34534, (char) 38095,
        Double.longBitsToDouble(0x3fd23c931b9ab234L), Double.longBitsToDouble(0x3fd1152e1f31858cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 10, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\ud870\uddc3\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud870\udf2b\udb2c\udf93\udbe2\udc15\ud93c\ude30\ud887\ude9c\udbcf\ude49\udb39\udea6\ud9d6\udfb2\udb69\ude41\ud945\udfcc\udaa0\udf8c\udbab\udf0d", "\u68ee\u1884\u3af0\ub184", "\udbbd\udcbf\udbac\ude2b\ud82f\udc09\udac1\udea3\uda4c\udd4e\udb86\udd6e\ud867\udf05\ud876\udf3b\udaa4\udc94\uda77\uddcc\uda1e\ude9f\ud878\udd70\udaf9\udc84\uda86\udd91\uda8a\udc2d\uda02\udd85\uda48\udfbe\ud903\ude5c\udbc5\uddd3\udbba\udf24\ud920\udf9e\ud8f5\udebb\udad0\ude77\udbea\udc0f\ud8dc\udf32",
        57, 28414, 1494920483, 5972236879729691093L, -27129L, false, false, (char) 12208, (char) 62430,
        Double.longBitsToDouble(0x3fda494fe5820bd8L), Double.longBitsToDouble(0x3fe0c1066b4174c2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\ud870\uddc3", "\u9e45\u2b56\u5008\ud12d\u6752\u7269\u8071\uc1d7\u026e\ube5c\u0ad2\ub19e\u16ee\uba31\u3eac\u12b5\u1884\u3af0", "\uda62\udfc0\ud8c1\udfdc\udbac\ude2b\ud82f\udc09\udac1\udea3\uda4c\udd4e\udb86\udd6e\ud867\udf05\ud876\udf3b\udaa4\udc94\uda77\uddcc",
        57, 32454, 1568851714, 2835446039863273373L, -47180L, false, true, (char) 40414, (char) 15772,
        Double.longBitsToDouble(0x3fe4282402845685L), Double.longBitsToDouble(0x3fd74478ac1d9720L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 10, "\udb24\ude22\udaf4\ude67\udbeb\uddf3\ud81f\udeb9\ud90b\ude82\ud9b6\udfcc\udbdd\udf8c\udadf\udf21\udb2c\udf81\udbe2\udc15\ud93c\ude30\ud97d\ude38\udbcf\uddc4\udb8b\udd70\ud833\udc7b\ud832\ude42\udb14\udd48\udab7\udd65\udbab\udf0d\ua9d9\udbbf\udc4c\ud85e\udfbb\ud936\udf79\ud867\udeb2", "\u6793\u23eb\u171e\u8b0d\u4753\u88a9\u6fed\uc4b8\ubd8f\u76db\u84df", "\ud903\udd55\uda9f\ude58\uda8a\udc2d\uda02\udd85\ud983\udcbf",
        50, 92137, -1396991255, 6234427730386621060L, -21704L, false, true, (char) 6596, (char) 14728,
        Double.longBitsToDouble(0x3febf4098d1f7d46L), Double.longBitsToDouble(0x3fdd552e1f31858cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 6, 1, 10, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\udbff\udcc9\ud9be\udc10\udb0c\udce3", "\u5008\ud12d\u6752\ubb4b\u55fa\u0e07\u639e\u245c\u0b27\ub19e", "\udbbf\udc4c\ud9f1\udf84\ud908\ude4b\ud867\udeb2",
        29, 90783, 1215061884, -7669301386184864769L, -48858L, false, true, (char) 6982, (char) 62119,
        Double.longBitsToDouble(0x3fd77a9607272c70L), Double.longBitsToDouble(0x3fecc669a030e18dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 1, 7, 6, 9, "\udb24\ude54\udaf4\ude67\uda65\uded9\ud8f1\udd0b\udb75\udc0a\uda72\udd69\uda97\uddc8\ud870\udf2b\udb2c\udf93\udace\udc6c\ud93c\udef1\ud887\ude9c\udbcf\ude49\udb8b\udd70\ud9d3\udf50\udb69\ude41\ud945\udfcc\udaa0\udf9d\udbab\udf0d\ud90f\udffa\uf1cb\ud85f\udc49\ud90b\udca2\ud867\udeb2", "\u2552\ua4d9\u574d\ua549\u4753\u011b\u6ff0\u5575\u6418\u275f\u7b81", "\udaf9\udc84\uda86\udd78\uda8a\udc2d\uda02\udd85\uda48\udfbe",
        50, 62105, 75549409, 6234581146618434180L, 56042L, false, false, (char) 39165, (char) 16197,
        Double.longBitsToDouble(0x3febb811b1bc522eL), Double.longBitsToDouble(0x3fdd552e4f30b1c2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 12, 4, 10, "\udbdf\udd6f\ud97f\udcfe\udbf1\udc32\ud870\uddc3\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud870\udf2b\udb2c\udf93\udbe2\udc15\ud93c\ude30\ud887\ude9c\udbcf\ude5a\udb8b\udd70\ud9c9\ude87\udb69\ude41\ud945\udfcc\udaa0\udf8c\udbab\udf0d\ua9d9\udbbf\udc1f\ud85e\udfbb\ud936\udf79\ud867\udeb2", "\u2552\u752b\u574d\u2f98\u46ea\u88a9\u6f21\u5575\u6418\u275f\u7b81", "\udaf9\udc84\uda86\udd78\uda89\udfaf\uda02\udd85\uda1a\udf3a",
        50, 2944, 1579746899, 6234581146618434180L, 56146L, false, true, (char) 34534, (char) 38095,
        Double.longBitsToDouble(0x3fd23c931b9ab234L), Double.longBitsToDouble(0x3fdd552e1f31858cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 12, 7, 11, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\ud892\udc40\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud870\udf2b\udb2c\udf93\udbe2\udc15\ud93c\ude30\ud887\ude9c\udbcf\ude49\udb8b\udd70\ud9c9\ude87\ud8ba\udde9\ud948\udd59\udaf6\udf16\u3181\ud80a\udd98\udbbf\udc4c\ud85e\udf9a\udaf2\ude38\uf8be", "\ub7ea\ua4d9\u574d\ua549\u3bac\u8841\u6ff0\u5575\u6418\u275f\u7b81", "\udaf9\udc84\uda86\udd78\uda8a\udc2d\uda02\udd85\uda48\udfbe",
        50, 62105, 72862433, 6234581146618434180L, 48719L, false, true, (char) 34534, (char) 38095,
        Double.longBitsToDouble(0x3fd23c931b9ab234L), Double.longBitsToDouble(0x3fdd552e1f31858cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 6, 7, 10, "\udb24\ude93\udaf4\ude67\udbeb\uddf3\ud870\uddc3\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud81f\uddc1\uda79\udf8c\udbe2\udc78\ud93c\ude30\udb36\uddda\udbcf\ude49\udb8b\udd70\ud9c9\ude87\udbb4\udd87\ud96b\uddee\ud909\udf82\udbab\udf0d\ua9d9\udbbf\udc4c\ud85e\udfbb\ud936\udf79\ud95f\ude7b", "\u2552\ua4d9\u574d\ua549\u4753\u88a9\u6ff0\u5575\u6418", "\uda1e\ude9f\ud878\udd70\udaf9\udc84",
        47, 17181, 1268342033, -3159048279924335714L, -48063L, true, false, (char) 26889, (char) 32032,
        Double.longBitsToDouble(0x3fe07658b1046651L), Double.longBitsToDouble(0x3fe7c27f7666a669L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 4, 6, 10, "\udb24\ude2d\udba6\udfb9\ud8c1\udc6c\ud870\uddc3\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud870\udf2b\udb4a\udc93\udbe2\udc15\ud93c\ude30\ud8f8\udff5\ud8e2\udce4\udb8b\udd70\uda51\udf4b\udb59\ude1d\ud945\udf79\udaa0\udf8c\udbab\udf0d\ua9d9\udbbf\udc4c\ud85e\udfbb\ud8f6\udd57\ud867\ude2d\ud93c\udc91\ud8b9\udc71\ud9ad\udc26", "\ua549\u4753\u88a9\u6ff0\u2066", "\uda6a\udd6e\uda1e\ude9f\ud878\udd70",
        9, 41727, -2116638819, 5447487551141629524L, 56010L, true, false, (char) 59574, (char) 16393,
        Double.longBitsToDouble(0x3fd96478ac1d962cL), Double.longBitsToDouble(0x3fd046651dad69dcL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 1, 7, 7, 2, "\udb24\ude54\udaf4\ude67\ud9bd\uddf2\ud870\uddc3\udacf\udf67\udb0c\udd7d\ud8ae\ude1a\ud870\udf37\udb2c\udf93\udbe2\udc15\ud93c\ude30\ud91e\udf97\udbcf\ude33\udb8b\udd70\ud88b\udf9e\ud8c0\udd9c\ud88b\uded4\udabc\ude66\udbab\udf0d\ua9d9\udbbf\udc4c\ud9d0\udfb4\ud936\udf79\ud867\udeb2", "\u2552\u2f02\u574d\ua549\u4753\u88a9\u6ff0\u5575\u6418\u275f\u7b81", "\udaf9\udc84\uda86\udd78\uda8a\udc1f\uda02\udd85\uda48\udfbe",
        50, 62105, -257974934, 6263347261078508164L, -74926L, false, true, (char) 34534, (char) 38095,
        Double.longBitsToDouble(0x3fd44255e66e4cb4L), Double.longBitsToDouble(0x3fe17d1a1017ab07L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 7, 6, 2, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\udbfe\udcf6\ud81d\udd02\udb0c\udce3\udaa1\ude99\ud870\udf2b\uda70\uddb6\udbe2\udc15\ud93c\ude30\ud92f\udf5f\udbcf\uddf1\udb8b\udd70\ud9c9\ude87\udb69\ude41\ud945\udfcc\ud881\ude86\udb75\ude82\ud805\uddd9\ud8f5\ude68\ud9d1\udc76\ud936\udf79\ud867\udeb2", "\u24f7\ua4d9\u574d\uc297\u7cfd\u88a9\u6ff0\u4da8\u6418\u275f\u7b81", "\udaf9\udc84\uda86\udd78\uda8a\udc2d\uda02\uddc2\udb22\udecf",
        33, 62105, -257974934, 6234581147440517764L, -81919L, true, false, (char) 22120, (char) 61967,
        Double.longBitsToDouble(0x3fd23c97db9ab234L), Double.longBitsToDouble(0x3fdd552e1e31858cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 10, "\udb24\ude54\udaf4\ude67\udbeb\uddf3\udb97\ude50\ud9be\udc10\udb0c\udce3\udaa1\ude99\ud893\udd6a\udb2c\udf93\udbe2\udc15\ud93c\ude30\ud975\ude93\udbcf\ude49\udb8b\udd70\udbf3\ude50\udb89\udf17\ud945\udfcc\udaa0\udf8c\udbab\udf0d\ua9d9\udbbf\udc4c\ud85e\udfbb\ud936\udf79\ud9ce\udf1d", "\u2552\ua655\u574d\ua017\u2931\u88a9\u1461\u52dd\u6418\ube74\uc7d6\u7396\u7a00\u9596\u9b7b\ud215\u9eaa\u2a5e\uc9e5\ub70c\u4037", "\udad0\ude77\uda79\udc15\udb30\uddb9\ud97e\uddb0\ud886\udf2b\ud8ee\ude63\ud970\udeaf\ud92b\ude39\ud261\ud8d4\udc3e",
        23, 46820, 159654582, -2452665607727112846L, 65585L, false, true, (char) 43055, (char) 40288,
        Double.longBitsToDouble(0x3fee6f6274531219L), Double.longBitsToDouble(0x3fe14cdde09dfc71L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$1:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 10, "\udb24\ude22\udaf4\ude67\udbeb\uddf3\ud81f\udeb9\ud90b\ude82\ud9b6\udfcc\udbdd\udf8c\udadf\udf21\udb2c\udf81\udbe2\udc15\ud93c\ude30\ud97d\ude38\udbcf\uddc4\udb8b\udd70\ud833\udc7b\ud832\ude42\udb14\udd48\udab7\udd65\uda37\udcf2\ud9dd\udfce\udbbe\udff1\ud85e\udfbb\ud936\udf79\uda97\udca4", "\u6793\u23eb\u171e\u8b0d\u4753\u1066\u6fed\uc4b8\ubd8f\u76db\u84df", "\ud903\udd55\uda9f\ude58\uda8a\udc2d\uda02\udd85\ud983\udcbf",
        50, 92137, -1396991255, 6234427730386621060L, -21704L, false, true, (char) 21757, (char) 64253,
        Double.longBitsToDouble(0x3febf4098d1f7d20L), Double.longBitsToDouble(0x3fdd552e1f31858cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|answer|org.mockito.invocation.InvocationOnMock|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|createNewDeepStubMock|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|getMock|org.mockito.invocation.InvocationOnMock,org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|recordDeepStubMock|java.lang.Object,org.mockito.internal.stubbing.InvocationContainerImpl|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|returnsDeepStubsAnswerUsing|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|withSettingsUsing|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|actualParameterizedType|java.lang.Object|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "C|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|<init>|",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|answer|org.mockito.invocation.InvocationOnMock|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|createNewDeepStubMock|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|getMock|org.mockito.invocation.InvocationOnMock,org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|recordDeepStubMock|java.lang.Object,org.mockito.internal.stubbing.InvocationContainerImpl|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|returnsDeepStubsAnswerUsing|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|withSettingsUsing|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
