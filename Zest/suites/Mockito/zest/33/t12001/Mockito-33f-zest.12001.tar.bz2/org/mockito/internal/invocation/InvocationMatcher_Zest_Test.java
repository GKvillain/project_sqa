package org.mockito.internal.invocation;
import org.junit.Test;
import static org.junit.Assert.*;
public class InvocationMatcher_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 1, 2, "\udb9f\udf30\ud947\ude21\udb36\ude70\ud99a\udc12", "\ua482\ube4d\u66e1\u43ec\u2c10", "\ud89e\udc59\udbee\udc80",
        59, 73102, -168072140, -213509946822954699L, 35010L, false, true, (char) 41970, (char) 62609,
        Double.longBitsToDouble(0x3fe47a626ac3c137L), Double.longBitsToDouble(0x3fc74634baf20598L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 6, 8, "\uda03\udd10\ud95c\udf9a", "\u9028\u9f4c\ua482\ube4d\u66e1\u43ec\u2c10\u6b0c", "\udbee\udc80\ud96c\udc77\udb0c\ude35\udb6c\udf9c\udbc6\udd49\ud979\ude8e\ued70\ud9f8\ude40\ud8db\udc3b\ud9ff\udebe\ud9a6\udd86\udb7c\udfbb\ud86e\udcc8\udb33\udedb",
        20, 23810, 696936124, 8752781633367714531L, -81067L, true, true, (char) 40682, (char) 62945,
        Double.longBitsToDouble(0x3fd7cfa66a993800L), Double.longBitsToDouble(0x3fb994851419fa28L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 2, "\u45f5\ud947\ude21\udb36\ude70\ud99a\udc12", "\ua482\ube4d\u66e1\u43ec\u2c10", "\ud89e\udc59\udbee\udc80",
        59, 65050, -168072140, -213509946822954699L, 35010L, false, true, (char) 41970, (char) 61713,
        Double.longBitsToDouble(0x3fe47a626ac3c137L), Double.longBitsToDouble(0x3fc74634baf20598L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 1, 2, "\udb9f\udf30\ud947\ude21\udb36\ude70\ud99a\udc12", "b\000\u4bea", "\ud43f\uda5b\udc1d\ud89e\udc59\udbee\udc80\ud94a\ude77\udb0c\ude35\ucf8e\ud905\udda9\uf935\u4368\ud9ca\udd24\ud8db\udc3b\ud9fb\udf5c\ud9a6\udd86\udb7c\udfbb\ud86e\udcc8\udb33\udedb\udbff\udcec\u8944\uda07\ude32\u5d26\udab0\ude72\udada\udfef\ud93e\ude9b\ud9bf\udc30\ud90e\udfc7",
        14, 25289, 997509107, -1521507641423348353L, 22817L, false, false, (char) 51747, (char) 41354,
        Double.longBitsToDouble(0x3fe860432f208d8bL), Double.longBitsToDouble(0x3fef523608a0f7bdL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 2, 0, 6, "\udb9f\udf30\uda2d\udf53\udb36\udd9c\ud99a\udc12", "\ua482\ube4d\u66e1\u43ec\u2c10", "\ud89e\udc59\udbee\udc80",
        59, 73102, -168072140, -213509946822954699L, 39874L, false, false, (char) 34975, (char) 20843,
        Double.longBitsToDouble(0x3fe47a626ac3c137L), Double.longBitsToDouble(0x3fc74634baf20598L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 2, "\udbe1\udc50\ud947\ude21\udb28\udf1c\ud99a\udc12", "\ua482\ube4d\u59c5\u43be\u1c16", "\uda98\udcd5\ud91e\udd1e",
        20, 73102, -168072140, -213509946822954699L, 35010L, false, true, (char) 41970, (char) 62609,
        Double.longBitsToDouble(0x3fe47a626fedf4d8L), Double.longBitsToDouble(0x3fd1d4defa7132caL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 8, "\ud93e\ude0a\udadc\udd00", "\u4ca9\u9f4c\u96b9\ua886\u0931\u9bff\u0b16\u32a1", "\ud825\ude9d\ud96c\udc92\udb44\ude31\u1a92\ud851\udc62\ud979\ude8e\uda94\udc3c\ud9f8\ude40\ud8db\udc3b\ud9ff\udebe\ud9ec\udd89\udb7c\udfbb\ud86e\udcc8\udb33\udedb",
        20, 23810, 696936124, 7086702658580639274L, -81067L, false, false, (char) 53767, (char) 54355,
        Double.longBitsToDouble(0x3fd74fadfafa8b76L), Double.longBitsToDouble(0x3fb994853f075078L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 2, "\udbe1\udc50\ud947\ude21\udb28\udf1c\ud99a\udc12", "\ua482\ube4d\u04c5\u43f4\u1c16", "\ud930\udda1\ud91e\udd1e",
        20, 73102, -168072140, -213509946822954699L, -64574L, false, false, (char) 41970, (char) 62609,
        Double.longBitsToDouble(0x3fe47a626fedf4d8L), Double.longBitsToDouble(0x3fd1d4defb7532caL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 2, 2, "\udbe1\udc50\ud947\ude21\udb28\udf1c\ud99a\udc12\ud8f7\udd78\uda6b\udfd9\udaf2\udf48\ud8c8\udf4e\udaed\udd6b\uda5c\udc64\udb77\udee4", "\u31f9\ua997\u70e9", "\ud950\udc6e\ud968\udec7\ued70\ud9f8\ude40\ud8db\udc3b\udab6\uddbb\ud9a6\udd44\udb7c\udfbb\ud86e\udcc8\udae7\udde6\udb11\udc84\ud800\udf13\ud8ba\uddd5\udaf4\uddfb\uda79\udefa\udb97\udee4\udaa6\udea1\ud81e\ude3f",
        -1, 20763, 1453645451, 8998598068662819150L, 21382L, true, false, (char) 12976, (char) 63271,
        Double.longBitsToDouble(0x3fea2fdb826c1ee0L), Double.longBitsToDouble(0x3fce9f66282074c4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 3, 1, "\uda44\udf4c\uda55\udf7a\uda43\udc5c\ud9a2\uddad\ud8f7\udd78\uda6b\udfd9\udaf2\udf48\udb61\udd29\ud8d4\udc5c\uda5c\udc4b\uda3f\udde6\ud912\udfe3\uda5b\udca4\ud89e\udc59\ud89e\udff5\udb09\udd6f\udb0c\uddaf\udb6c\udf9c\udb20\udf4d\ud931\udd93\u8a05\udbbc\ude11\ud8dd\udca6\ud9ff\udebe\uda5e\udf83\udb7c\udfbb\ud816\udd3d\udae4\udfbc\ud9dc\udf39\ud971\ude82\udaf6\udcc7", "\u027a\u2cf9\u79cb\u403c", "\udbe8\udf61\ud908\uddec\udbf1\udc3f",
        27, 56772, 1718980834, 8476873956679726853L, -64476L, false, true, (char) 12609, (char) 55225,
        Double.longBitsToDouble(0x3f929942bc672460L), Double.longBitsToDouble(0x3fd17887b52cfb5eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.invocation.InvocationMatcher|hasSameMethod|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|captureArgumentsFrom|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|createFrom|java.util.List|static",
    "M|org.mockito.internal.invocation.InvocationMatcher|getInvocation||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getLocation||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getMatchers||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getMethod||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|hasSimilarMethod|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|matches|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|safelyArgumentsMatch|[Ljava.lang.Object;|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|toString||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|toString|org.mockito.internal.reporting.PrintSettings|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
    "C|org.mockito.internal.invocation.InvocationMatcher|<init>|org.mockito.internal.invocation.Invocation,java.util.List",
    "C|org.mockito.internal.invocation.InvocationMatcher|<init>|org.mockito.internal.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|hasSameMethod|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.internal.invocation.Invocation",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
