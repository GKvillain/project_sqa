package org.mockito.internal.util.reflection;
import org.junit.Test;
import static org.junit.Assert.*;
public class GenericMetadataSupport_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 6, 0, 8, "\ud928\udf28\ud91d\udd38", "\u22bf\u9a50\u2fda\u826e\uc004\u1cc0\u2f27\u8b59\u555c\u3a4c", "\udb53\udf28\ud84a\udd69",
        31, 6129, 107277913, -176827035984626878L, -87362L, false, true, (char) 5946, (char) 23084,
        Double.longBitsToDouble(0x3fe5a28d3bed19dfL), Double.longBitsToDouble(0x3fb978a4985855d0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 6, 0, 5, "\ud928\udf28\ud91d\udd38", "\u22bf\u9a50\u2fda\u826e\uc004\u63dc\u3875\u4460\u54f4\u3a4c", "\udb53\udf28\ud84a\udd69",
        31, 6129, 107277913, -176827035984626878L, -87362L, false, true, (char) 5946, (char) 23084,
        Double.longBitsToDouble(0x3fe5a28d3bed19dfL), Double.longBitsToDouble(0x3fb978a4984bd5d0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 0, 0, "\ud928\ude61", "\u5f8dj", "\udb86\udd58\udb4b\udfe1\uda17\ude7c\udb72\udec3\ud876\udc7b\ud996\udcac\ud989\udc50",
        40, 87986, 97, -8391314112567137340L, -38983L, true, false, (char) 139, (char) 53939,
        Double.longBitsToDouble(0x3fd5e4430a01dbd8L), Double.longBitsToDouble(0x3faac782bb70e750L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 8, 0, 4, "\ud9aa\udf82\udae2\udeaa", "\u22bf\u5bb0\u7713\u4649\uc004\u45be\uc8a2\u5aa8\uadd9\ucf20", "\uda67\ude3d\ud84a\udd7c",
        31, 6129, 358936153, -6956007783300818091L, 78056L, true, false, (char) 1595, (char) 39579,
        Double.longBitsToDouble(0x3fea5a8d3933e73fL), Double.longBitsToDouble(0x3fe465c78427563fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 8, "\udbd7\udf80\uda86\udf51", "\u22bf\u9a50\u2fda\u826e\uc004\u1cc0\u2f27\u8b59\u555c\u3a4c\u2832", "\ud84a\udd69\ud8c3\udccf\ud9df\udf6b\ud9bd\udeb9\udbe8\udc99\uda16\udd3c\udaff\udeb8\ud8ec\udc4d\uda13\udf53\ud858\udd0f\udb74\udc86\ud922\udd3a",
        -1, 28109, -1935482101, 5303929000393267363L, -71588L, true, true, (char) 33806, (char) 20976,
        Double.longBitsToDouble(0x3feeb57745f62b91L), Double.longBitsToDouble(0x3fcb6a239640eed4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 6, 0, 0, "\uda98\ude7a\udad5\udfac\udb0a\udfff\udab4\udc05\udacc\udf77\udb0b\udd08\udbf0\udf20\udb86\udd58\udb4b\udfe1\uda17\ude7c\udb72\udec3\ud876\udc7b\ud996\udcac\ud989\udc50\ueb13\udaa7\udfd9\udb53\udf28\ud84a\udd69\ud8c3\udccf", "\u5dd6\u7b7f\ucb85\u13f1\ud014", "\ud937\udc3a\ua231\udb74\udd06\u9f82\ud9ba\udcf7\ud830\udc8f\ud80d\udeac\ud92a\udf30\udb26\ude90\ud902\udf86",
        11, 73838, -1976633838, 2648643767151618146L, -17800L, false, true, (char) 36914, (char) 10953,
        Double.longBitsToDouble(0x3fe87c28118008e3L), Double.longBitsToDouble(0x3fe9785cd570b944L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 6, 0, 8, "\ud928\udf28\ud91d\udd38", "\u22bf\u1464\u2fda\u826e\uc004\u1cc0\u2f27\u8b59\u555c\u3a4c", "\udb53\udf28\uda90\udf50",
        42, 96764, 107277913, -176827035984626878L, -87450L, false, true, (char) 5946, (char) 23084,
        Double.longBitsToDouble(0x3fe5a28d3bed19dfL), Double.longBitsToDouble(0x3fb978a4985855d0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.LinkedHashMap:{} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 6, 0, 4, "\udb62\ude8a\ud815\udca1\ud964\udc52\ud91b\udfac\udaab\udc91", "\u826e\ubf36\u1c6e\u2f27\u8b59\u42a3\ub3f9", "\udb53\udf28\ud9ea\udd63",
        56, 6129, 107277913, -176827035984626878L, 61739L, true, true, (char) 20672, (char) 14187,
        Double.longBitsToDouble(0x3fb978a0d85855d0L), Double.longBitsToDouble(0x3fd9dc952089c8faL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 2, 8, "\ud928\udf28\udb13\udf88", "\u22bf\ud1dd\u1de6\u3541\ua6cb\u1cc0\u839f\u8b6c\u5575", "\ud821\udfec\udb53\udf7a",
        44, 41196, 1435116129, 460755127870305564L, -56602L, false, true, (char) 25351, (char) 61582,
        Double.longBitsToDouble(0x3fedb873aab451a7L), Double.longBitsToDouble(0x3fef68cef865e292L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 6, 0, 4, "\ud928\udf28\ud91d\udd38", "\u22bf\u9a50\u2fda\u826e\uc004\u1cc0\u2f27\u8b59\u555c\u3a4c\u2832\u7efa\u3286", "\ud8e7\udf23\ud9c1\udf7b\udbe8\udc99\uda16\udd3c\udaff\udeb8\ud8ec\udc4d\uda13\udf53",
        50, 54391, 434086580, -2120487420427583387L, 87233L, true, false, (char) 50961, (char) 26515,
        Double.longBitsToDouble(0x3feb47da10b46774L), Double.longBitsToDouble(0x3fe8fb567abfd963L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 6, 0, 8, "\ud928\udf28\udaa4\udf9d", "\u22bf\u9a50\u67b5\u826e\uc004\u1cc0\u2f27\u8b59\u555c\u3a4c", "\udb53\udf28\udb55\udced",
        37, 10647, 107277913, -176827035984626878L, -87362L, false, true, (char) 5946, (char) 23084,
        Double.longBitsToDouble(0x3fe5a28d3bed19dfL), Double.longBitsToDouble(0x3fb978a4985855d0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 6, 8, 4, "\ud928\udf28\ud91d\udd38", "\u22bf\u9a50\u3003\u8a92\uc004\u9e86\u92fc\u8b59\u555c\u3a4c", "\udb53\udf28\uda5b\udd50\ub243\udb2c\udecb\udbf3\udff4\ud82c\uddfc\uda0c\udf75\udaff\ude0a\ud8ec\udc4d\ud9bd\udee8\uda7a\udf36\u3cfd\udb0e\udf97\ua231\udb74\udd06",
        4, 34534, 1522455547, 3897021057391155504L, -17472L, false, true, (char) 41911, (char) 62751,
        Double.longBitsToDouble(0x3fd4c9bbee1c0162L), Double.longBitsToDouble(0x3fe1acb883f79bcbL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 8, "\ud928\udf28\ud925\udfe4", "\u22bf\u9a50\u2fda\u826e\uc004\u1cc0\u2f27\u8b59\uc7ba\u3a4c", "\udb53\udf28\ud84a\udd69",
        31, 62433, 112071490, -176827035984626878L, -87362L, false, false, (char) 6195, (char) 23084,
        Double.longBitsToDouble(0x3fe5a28d3bed19dfL), Double.longBitsToDouble(0x3fb978a4985855d0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 4, 9, 8, "\ud928\udf28\uda49\udfca\ud823\udec3\udbb6\ude7d\ud988\uddbe", "\u4c3d\ua7f6\u762d\u88a8\u8bea\ua50f\u5388", "\ud839\udf7b\ud865\udd0d",
        4, 21766, -1822945305, 5554384895825116048L, -91761L, false, false, (char) 5946, (char) 64043,
        Double.longBitsToDouble(0x3fefba496f0559b4L), Double.longBitsToDouble(0x3fb97894185855d0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 7, 11, 8, "\ud928\udf28\ud91d\udd38", "\ua24f\u9a50", "\udb4b\udfe1\uda17\ude7c\udb72\udec3\ud81e\udcf0\udb12\udcd0\ud989\udd22\ueb13\udaa7\udfd9\udb53\udf28\ud84a\udd69\ud8c3\udccf\udaf2\udfd6\udaeb\ude94\uda83\udc30\ud99e\udda9",
        18, 14030, -468412932, 222564946710223788L, 34791L, true, false, (char) 21950, (char) 19087,
        Double.longBitsToDouble(0x3fd7676b7e163728L), Double.longBitsToDouble(0x3fed8f9b6df7beecL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 5, 0, 8, "\ud935\udf28\ud91d\udd38", "\u22bf\u9a50\u1d7c\u4b6b\ubf84\u1cc0\u2f27\u8b59\u555c\u8bd0", "\udb53\udf28\ud84a\udd69",
        31, 6129, 107277913, -176827035984626878L, -87362L, false, true, (char) 5946, (char) 5128,
        Double.longBitsToDouble(0x3fd3189397da33beL), Double.longBitsToDouble(0x3fb978a4985855d0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 0, 8, "\ud928\udf28\ud91d\udd38", "\u22bf\u9a50\u2fda\uad03\uc004\u1cc0\u2f27\u4603\u1fab\u3a4c", "\udb53\udf28\ud84a\udd69",
        31, 6129, 107277913, -191019643745109182L, -87362L, false, true, (char) 5946, (char) 23084,
        Double.longBitsToDouble(0x3fe5a28d3bed19dfL), Double.longBitsToDouble(0x3fb978a4985855d0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap:{E={firstBound=class java.lang.Object, interfaceBounds=[]}} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 0, 0, 8, "\000", "\000", "\000\000\udb44\udce1\uda02\ude00\000\000\000",
        -5, -1000, -503316480, 8725722324271104L, 39873L, false, false, (char) 0, (char) 30926,
        Double.longBitsToDouble(0x3fe5a000015e4430L), Double.longBitsToDouble(0x3fcf9dbd80d63c00L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 2, 8, "\ud928\udf28\ud91d\udd38", "\u1b7d\u9a50\ua7bd\u826e\uc004\u1cc0\u2f27\u8b5d\u24b3\u4297", "\ud852\udc32\ud925\udc3c",
        50, 56802, -1267919799, 5459440310125034254L, -91663L, false, true, (char) 5946, (char) 23084,
        Double.longBitsToDouble(0x3fe5a28d3bed19dfL), Double.longBitsToDouble(0x3fb978a4985855d0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 11, 4, 8, "\ud893\udc85\ud95b\udc51\ud92f\ude94\ud893\udfad\udb5d\ude6d\uda49\udc59\ud968\udf7b\ud9d0\udd3a\udb58\udd2d", "\uac2b\u54a5\ud688\u34cb", "\udb0d\udedf\ud8a3\udef3\ud9e9\ude55\ud9bd\udeb9\ud9e9\udfd6\uda16\udd3c\uda85\udebb",
        43, 6490, 242583605, 5883754687968027202L, -18181L, true, true, (char) 63943, (char) 15656,
        Double.longBitsToDouble(0x3fd39cddc5a23f26L), Double.longBitsToDouble(0x3fcee203d72fc718L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap:{} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.LinkedHashMap:{} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 0, 0, 4, "\udbd5\udd1d\ud944\udfb2", "\u1da6\u9a50\u2fda\u826e\uc004\ub950\u6fa9\u53fc\u54a7\u3a4c", "\udb53\udf28\ud84a\udd69",
        31, 83169, 107237343, -176827035984626878L, -87362L, false, true, (char) 43773, (char) 23084,
        Double.longBitsToDouble(0x3fa7f3873ed197e0L), Double.longBitsToDouble(0x3fb978a4985855d0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 11, 1, "\ud928\udee9\ud91d\udd38", "\u22bf\u9a50\u2fda\u826e\uabe4\u1cc0\u2f27\u8b59\u4479\ua53f", "\udb66\ude9f\ud8fe\ude70\ud8c3\udccf",
        0, 35691, -1131293281, -6929617027268057270L, 58408L, true, true, (char) 21510, (char) 34912,
        Double.longBitsToDouble(0x3fdc87e79a6998aaL), Double.longBitsToDouble(0x3fe85851747f9fc9L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 11, "\ud911\udd6f\ud939\udd38\ud809\udea5\ud893\udff1\uda99\udc56\ud97e\ude4d\u64c3\ud816\udd89\udb7e\udff8\uda1d\ude77\ud8b8\udd2b\ud876\udc7b\ud996\udcac\uda69\udf32\ud8c0\udd3d\udb1d\udcde\udace\uddf3\ud844\ude90\ud8c2\uded3\ud9df\udf6b\ud9bd\udeb9\udbe8\udc99\ud833\udc2b\udaff\ude21\ud83d\ude81\uda13\udf53\ud858\udd0f\ud9d1\udf95\ud936\udfb5\ua231\udaa4\udf9e\ud861\udc03\uda8b\udd42\ud879\udc7d\udb89\udf36\udad1\udeee\ud8b9\ude5b\udb83\udfdf\ud9b2\udf29\uda2e\udc4d\ud9fc\ude7c\udac6\ude6c\ud89e\ude8c\ud8d8\udc21\udb49\udc87\udb1e\udf3c\ud950\udeb0", "\u2bb7\u9ff5\uc99c\u0562\u2f19\u1ecf\u127f\u84dd\u11d2\u3611\u8aee\u0d52\u754c\u416f\u1c26\u91a7\ub1b4\u060a", "\udaf6\udd38\ud957\udf49\udab2\udd21\ud800\udc10",
        52, 4910, 164693132, 754982778444758229L, 57877L, true, false, (char) 24904, (char) 62734,
        Double.longBitsToDouble(0x3fea71813b9c90e7L), Double.longBitsToDouble(0x3fba4494a80815c0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 2, 7, "\ud928\ude61\ud91d\udd38\udb1b\udfc0\ud887\udda1j\udac5\uddc2\uda4e\ude2f\udb87\udf58\ud9e5\udfcb\ud93b\udeed\ud802\udc07\ud8b4\udd03\ud997\uddac\u4615\uda6f\udfb4\ud996\udd51a\ud84a\udd69\ud8c3\udccf\ud9df\udf6b\ud9bd\udeb9", "\u5972\u5284", "\udadf\udefd\ud988\udfeb\ud86d\udea0\udbca\ude1f\uda09\udf9a\udacd\udddd\udbfe\udfeb\uda32\uddd4\uda8d\uddc8\ud8ca\ude78\ud818\udfdb\ud978\ude81\ud9fa\udd99\udb20\udd95",
        33, 41102, 1291733917, 349882505399327984L, -10199L, false, true, (char) 58901, (char) 62936,
        Double.longBitsToDouble(0x3fd290d81945fb86L), Double.longBitsToDouble(0x3febcd7c59bc98acL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=void |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 6, 11, 8, "\ud928\ude61", "\u5f8dj", "\udb86\udd58\udb73\udf64\uda17\ude7c\udb72\udec3\ud876\udc7b\ud996\udcac\ud989\udc50",
        40, 87986, 97, -8391314112567137340L, -38983L, true, false, (char) 139, (char) 53939,
        Double.longBitsToDouble(0x3fd5e4430a01dbd8L), Double.longBitsToDouble(0x3faac782bb70e750L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Long |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 9, 0, "\ud9aa\udf82\udaf9\ude21\ud809\udea5\ud8d8\udd74\udac0\udfb5\uda50\uddeb\udbcc\ude5a\udbd2\udebe\udb4b\udfe1\ud996\udf5f\ud801\ude68\ud95f\udf6e\u48be\ud9c0\uddc7", "\u5341\u9649", "\udada\udf40\uda71\ude16\uda67\udc95\ud92f\udff2\u1013\uda24\udffa",
        -2, 63133, -415272117, -5120494699295028596L, 64123L, true, false, (char) 48553, (char) 46512,
        Double.longBitsToDouble(0x3fe086f0a4c64c5eL), Double.longBitsToDouble(0x3fcfab71a3ca4fdcL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Class:char |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.lang.Class:char |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 8, 8, 3, "\ud9aa\udf82\udae2\udeaa", "\u22bf\u8c3e\u7713\u4649\uc004\u45be\uc8a2\u5aa8\uadd9\u8b33", "\uda65\ude68\ud84a\udd7c\ud8c3\udccf\ud9df\udf6b\ud942\udebb\ud91d\udcbb\udb3e\udc55\udaca\uddea\ud9ad\udee6\ud958\udd72\uda35\udfc5\udb7c\ude24\uda32\uddd5\udab5\udd42",
        13, 25441, 344137737, -9200139691872950896L, 10124L, false, false, (char) 39203, (char) 63833,
        Double.longBitsToDouble(0x3fed1702bcd74404L), Double.longBitsToDouble(0x3fe8ba57fbf86782L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 9, 1, 6, "\udbc6\udef5\uda86\udf51\udaf5\udd70\ud894\udc12", "\u2fda\u826e\u471b\u1cc0\u2f27\u8b59\u555c\u3a4c\u2887\u531b\u32bd", "\ud9df\udf6b\ud98f\ude5b\udbe8\udc99\uda16\udd3c\ud86e\udc87",
        10, 6668, 242583605, 5883754687968006068L, -18181L, true, true, (char) 58357, (char) 41534,
        Double.longBitsToDouble(0x3fe8b872aefc35d1L), Double.longBitsToDouble(0x3fee7cd92302b10cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 5, 6, 0, "\uda98\ude7a\udad5\udfac\udb0a\udfff\udab4\udc05\udacc\udf77\udb0b\udd08\udaba\ude63\udbb3\udc08\udb4b\udfe1\uda17\ude7c\udb72\udec3\ud876\udc7b\ud996\udcac\ud989\udc50\ud809\udc68\udbca\udfb2\udb53\udf28\ud84a\udd69\ud8c3\udccf", "\u5dd6\u7b7f\ucb85\u13f1\ud014\u1158\u7f9a\ub6f7", "\u9f82\ud9ba\udcf7\ud830\udc8f\ud80d\udeac\ud92a\udf30\udb26\ude90\ud902\udf86\udb22\udea7\u687c\uda19\udf20",
        8, 97978, -324742953, 7715439016279890774L, 170L, true, true, (char) 35426, (char) 2761,
        Double.longBitsToDouble(0x3fd70b9445246f22L), Double.longBitsToDouble(0x3fcf6e018de79728L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 4, "\udb62\ude8a\udaaf\udd9a\ud964\udc52\ud91b\udfac\udaab\udc91", "\u826e\uaabd\u19d3\u34c8\u6857\u42a3\ub3f9", "\ud9b3\udde3\udb57\ude23",
        23, 6129, 111959037, -146427740194374846L, 61739L, false, true, (char) 6768, (char) 14125,
        Double.longBitsToDouble(0x3fb978a0c85855d0L), Double.longBitsToDouble(0x3fd20e072089c9a2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.LinkedHashMap:{E={firstBound=class java.lang.Object, interfaceBounds=[]}} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 6, 0, 0, "\uda6a\udf3f\ud815\udca1\ud9ba\udc5a\udb2c\udded\ud9ce\udc29", "\u826e\ubf1e\u314d\u2b17\u8b59\u42a3\ub3f9", "\udb50\udf6d\udb01\ude20",
        37, 6129, 107277913, -176827035984626878L, 61739L, true, true, (char) 25292, (char) 9929,
        Double.longBitsToDouble(0x3fb978bdd85852d0L), Double.longBitsToDouble(0x3feda1629044e4a9L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 6, 6, 4, "\udb62\ude8a\ud815\udca1\udb64\udf47\ud91b\udfac\u32e2", "\u2694\ubf4f\u1c6e\u2f27\u69b7\u073e\u2968\u9cc2\u7efa\u3286\u50ed\ud121\u402e\u168d\u5dd6\u7b7f\u6a77\ud31e\u4f38\u7487\u1926\ucf3a\u1673\u0a4f\u72e4\ubd01\u83b8\u2c79", "\ud917\udf5a\udb08\udf6a\ud9df\udea6\udb63\udfc6\ud8c0\udec7\uda16\udd17\ud822\ude1a\udaf8\udde9\ud973\udeeb\uda29\ude57\u4283\uce93\udbfc\udeae\uda91\udd7b\udb64\udc5d\ud92b\ude26",
        4, 78718, 1442821449, 3064739623899761731L, -93420L, false, false, (char) 20897, (char) 28542,
        Double.longBitsToDouble(0x3fddf7cd626f911aL), Double.longBitsToDouble(0x3fe8d2cf3d21d41aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=void |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 11, 11, 4, "\uda02\uded4\ud815\udca1\ud964\udc52\ud91b\udfac\ud934\udef8\udaf2\ude66\udbd4\udf71\ud943\udeb2\ud9e1\udddb\ud866\udc56\ud9d5\uddc6\ud876\udc7b\ud829\udf39\ud995\uddc4\udbc2\udf5e\udb65\uded0", "\u1ded", "\udb55\udccb\ud85f\ude7d\ud91f\udc48\ud985\udc39\udaec\udd35",
        25, 13151, 245175785, -2124809733780357019L, 58307L, false, false, (char) 31887, (char) 2826,
        Double.longBitsToDouble(0x3fcec89921f40cb8L), Double.longBitsToDouble(0x3fd2e0d7428170e4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 9, 8, "\udbb4\ude25\udacb\udc0a\ud823\udef9\udbb6\ude7d\ud988\uddbe\udb09\udfe5\udb00\udce8\udbed\udf1e\ud8fc\udfcb", "\u8bea\ua50f\ub437\ua0df\u6ce3\u48c8\u8c71", "\ud92d\udfcb\ud8db\udf51\ud86d\udee3\u0edb\ud909\udece\uda00\udda3",
        23, 73223, 380946423, -1729876624645898206L, 94625L, false, true, (char) 62402, (char) 25798,
        Double.longBitsToDouble(0x3fdb573b18b0c714L), Double.longBitsToDouble(0x3fc868c52863fc00L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 7, 7, 1, "\ud928\udf28\ud91d\udd38", "\u5f59\u9a37\uc079\u766a\uc004\u1cc0\u2f27\uaba4\u0f5f\u3b1e", "\udb53\udf28\ud84a\udd69",
        31, 65041, 1680044206, 6527491409301439884L, -87362L, false, true, (char) 39352, (char) 8522,
        Double.longBitsToDouble(0x3fe304acd6e552e3L), Double.longBitsToDouble(0x3fb978a4beeb2f08L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.LinkedHashMap:{E={firstBound=class java.lang.Object, interfaceBounds=[]}} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 4, 0, 8, "\000", "\000", "\udbb4\uddad\udb67\udc90\udb44\udce1\udb6e\udff6'\000\000",
        -5, -1000, -503316480, 43065669482971136L, 39873L, false, false, (char) 13342, (char) 30926,
        Double.longBitsToDouble(0x3fe5a000015e4430L), Double.longBitsToDouble(0x3fcf9dbd80d63c00L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap:{E={firstBound=class java.lang.Object, interfaceBounds=[]}} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.LinkedHashMap:{E={firstBound=class java.lang.Object, interfaceBounds=[]}} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 0, 0, 8, "\000", "\u3f65", "\ud9ea\udfc2\ud82d\udc10\udb44\udce1\uda02\ude00\udaa0\udef2\ud881\ude3f\ud80f\ude58",
        -5, 57216, -490952747, -7701436839734018048L, 39873L, false, false, (char) 5962, (char) 30926,
        Double.longBitsToDouble(0x3fe5a000015e4430L), Double.longBitsToDouble(0x3fcf9dbd80d63c00L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=null |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 4, 4, 3, "\ud811\udd39\ue6e6\u00f8\000\ud977\ude3b\udb0b\udd08\ud9b7\udcda\000\udb44\udce1\uda02\ude00\000\udbc6\udc02\000\u00b5\ud80c\udc05\ud977\ude3b\udb44\udc01\ud846\udd23\ud8c3\udccf\ud85a\ude69\000\udbb5\udfda\uda10\udfaf\udaff\udeb8\ud8ec\udc4d\ud8ae\ude53\udbc1\udd24\udb6d\udd6e\udbb4\ude85\ud94d\uddfb\udb2e\udc0f\udada\uddfb", "\u728d\u5183\u434d\u1425\u7264\ub036\u6293\ub2b8\uc4ef\ua76b\ub7d9", "\ud846\udc15",
        52, 62817, -313017477, 7516192692180787634L, 68576L, true, true, (char) 54140, (char) 19696,
        Double.longBitsToDouble(0x3fe985a9883fad94L), Double.longBitsToDouble(0x3fe0a1a8f44860f5L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 5, 5, 8, "\udbd5\udd1d\ud971\udeca\ud85b\udff8\ud95f\udf38\udbe9\ude49\udb0b\udd08\u1b21\udba7\uddf1\udb4b\udfe1\ud8f2\udc24\uda1b\udd89\uace4\ud995\udfec\ud989\udc50\ueb13\udaa7\udfd9\udb53\udf28\ud84a\udd69\ud8c3\udccf\udba0\udeac\ud996\udc3f\ud868\udc99\uda16\udd3c\udaff\udeb8\ud051", "\u8626\uc45f\u38cb\uce8f\u12cd\u5f85\uc273\uc25f\u8983\u515a\u423d\ub681\u41d5\u1fee\u5985\u1e4c\u939d\u958f\ub165\u482f\u134f\u56a6\ucd10\u00c3\u62ca\u1fa2\u203d", "\ud939\uddc9\ud98f\udd6c\udb2f\udec2\ud92f\udf81\ud8af\uddad\ud846\udc18\ud9b1\udeeb\ud8d4\udee1",
        1, 94214, -1973767099, 7180914379870530869L, 18912L, true, true, (char) 7751, (char) 44556,
        Double.longBitsToDouble(0x3fea74942c1c3e4dL), Double.longBitsToDouble(0x3fdc39b3118daff8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 6, 0, 8, "\ud928\udf28\ud91d\udd38", "\u22bf\u9a50\u2fda\u8f6e\uc004\u1cc0\u2f27\u8b59\u555c\u3a4c", "\udb53\udf28\ud84a\udd69",
        31, 6129, 107277913, -176827035984626878L, -87362L, false, true, (char) 5946, (char) 23084,
        Double.longBitsToDouble(0x3fe5a28d3bed19dfL), Double.longBitsToDouble(0x3fb978a499e855d0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 0, "\ud9aa\udf82\udaf9\ude21\ud809\udea5\ud8d8\udd74\udac0\udfb5\uda50\uddeb\udbcc\ude5a\udbd2\udebe\udb4b\udfe1\ud996\udf5f\ud801\ude68\ud95f\udf6e\u48be\ud9c0\uddc7", "\u5341\u9649", "\udada\udf40\uda71\ude16\uda67\udc95\ud92f\udff2\u1013\uda24\udffa",
        -2, 71152, -415272117, -5120494699295028596L, 64123L, true, false, (char) 48553, (char) 46512,
        Double.longBitsToDouble(0x3fe086f0a4c64c5eL), Double.longBitsToDouble(0x3fcfab71a3c913dcL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 9, 9, 0, "\ud9aa\udf82\udaf9\ude21\ud809\udea5\ud8d8\udd74\udac0\udfb5\uda50\uddeb\udbcc\ude5a\udbd2\udebe\udb4b\udfe1\ud996\udf5f\ud801\ude68\ud95f\udf6e\u48be\ud9c0\uddc7", "\u5341\u9649", "\udada\udf40\uda71\ude16\uda67\udc95\ud92f\udff2\u1013\uda24\udffa",
        -4, 71256, -415272117, -5120494699295028596L, 64123L, true, false, (char) 48553, (char) 46512,
        Double.longBitsToDouble(0x3fe086f0a4c64c5eL), Double.longBitsToDouble(0x3fcfab71a3c913dcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|actualTypeArguments||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|boundsOf|java.lang.reflect.TypeVariable|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|boundsOf|java.lang.reflect.WildcardType|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|extraInterfaces||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|getActualTypeArgumentFor|java.lang.reflect.TypeVariable|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|hasRawExtraInterfaces||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|inferFrom|java.lang.reflect.Type|static",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|rawExtraInterfaces||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|rawType||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|registerTypeParametersOn|[Ljava.lang.reflect.TypeVariable;|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|registerTypeVariableIfNotPresent|java.lang.reflect.TypeVariable|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|registerTypeVariablesOn|java.lang.reflect.Type|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|resolveGenericReturnType|java.lang.reflect.Method|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
