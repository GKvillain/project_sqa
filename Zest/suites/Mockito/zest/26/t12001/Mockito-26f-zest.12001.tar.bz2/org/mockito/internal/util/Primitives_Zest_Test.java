package org.mockito.internal.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class Primitives_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 0, 0, "\uda11\udd49\ud95d\udfc1\ud8bf\ude05\udb4f\udf74\udb0e\udfba\udb5f\ude89\udaa7\ude06\ua2a1\udad8\udc20", "\ub986", "\udb30\ude77\udb9c\udde7\ud83b\uddd2\u3bb8\u5ab2\uc8b3\uda40\ude5f\ud88c\udcd6\uda93\udff9\ud832\udd8a",
        -3, 31066, 2139779366, -6720810565364148658L, -52538L, true, false, (char) 52538, (char) 35208,
        Double.longBitsToDouble(0x3fe07252f39d6606L), Double.longBitsToDouble(0x3feaa47648ce1254L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 0, 0, "\uda11\udd49\ud95d\udfc1\ud8bf\ude05\udb4f\udf74\udb0e\udfba\udb5f\ude89\udaa7\ude06\ua2a1\udad8\udc20", "\ub986\u3f74\u9715", "\ud83b\uddd2\u3bb8\u5ab2\udb5c\udc1f\uda40\ude5f",
        53, 55860, 985402900, -1102645462225094222L, 89030L, true, true, (char) 28754, (char) 14678,
        Double.longBitsToDouble(0x3fe6fef75ffced3eL), Double.longBitsToDouble(0x3fe8ac139e0e4a5eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 3, 0, "\uda11\udd49\ud95d\udfc1\ud8bf\ude05\udb4f\udf74\udb0e\udfba\udb5f\ude89\ud815\uddfd\ua2a1\udaf4\ude20", "\u94d3\uc664\u9d64", "\ud83b\uddd2\u3bb8\u5ab2\uc8b3\uda40\ude5f",
        53, 55860, 985402900, -1102645462225094222L, 89030L, false, false, (char) 55723, (char) 14678,
        Double.longBitsToDouble(0x3fe6fef75ffced3eL), Double.longBitsToDouble(0x3fe8ac139e0e4a5eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Character:\000\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 0, 0, "\ud8b1\udf80\ud95d\udfc1\ud8bf\ude05\udb46\udcfb\udb0e\udfba\udb5f\ude89\udaa7\ude06\ua2a1\udae8\udc36", "\ub51d\u34e0\u4aca\u7942\u9f42\u0b2f\u1c81\u8843\u8ed0\ubbb5\ub65d\u5730\ub3b0\u13a8\u372e\u704f", "\udb5a\udc1c\udbab\udca6\uadc4\udb25\uddf2\udbbd\uddcc\ud897\udc11\u24f1\uda1b\udc68\ud8d8\udd73\u7139\uda52\udef0",
        27, 85585, -870529281, 3237014682327285214L, 63359L, false, false, (char) 56738, (char) 35768,
        Double.longBitsToDouble(0x3fd1e8b7d3d9401eL), Double.longBitsToDouble(0x3fe1cd274689daaeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 0, "\uda11\udd49\ud95d\udfc1\ud8bf\ude05\udb4f\udf74\udb0e\udfba\udb5f\ude89\udaa7\ude06\ua2a1\udad8\udc20", "\ub986", "\udb30\ude77\udb9c\udde7\ud83b\uddd2\u3bb8\u5ab2\uc8b3\uda40\ude5f\ud88c\udcd6\uda93\udff9\ud832\udd8a",
        -3, 61180, 2139779366, -6720810566219786674L, -52538L, true, false, (char) 52538, (char) 35208,
        Double.longBitsToDouble(0x3fe07252f39d6606L), Double.longBitsToDouble(0x3feaa47648ce1254L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 0, 0, "\uda11\udd49\ud95d\udfc1\ud8bf\ude05\udb4f\udf74\udb0e\udfba\udb5f\ude89\udaa7\ude06\ua2a1\udad8\udc20\udb0f\udde3\ud982\udfc4\ud8fa\uddf0\udae0\ude69\ud8ce\udc9f\udb30\ude77\udb9c\udde7\ud83b\uddd2\u3bb8", "\ubbb5\u44cd\u5730\ub3b0\u13a8\u372e\u704f\u93da\ua81d\u892b\uaf64\u5cfd\u70d1\uc278\u66f9\uad6e\uc10d", "\ud86c\udec5\udbb7\ude70\udbcd\ude28\ud8b9\udd17\uda83\udcf0\ud8db\udc48\udb55\udd23\ud9b8\udde6\ucee3\ud848\ude3a\ud91f\udf5d\udba0\uddbc\ud888\udc6b",
        31, 64966, 396540137, -7126466534777279649L, -26852L, false, false, (char) 23612, (char) 22226,
        Double.longBitsToDouble(0x3fd1b3f8a85c1ddeL), Double.longBitsToDouble(0x3fd4c8ef46e07f0cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 2, 0, 0, "\uda11\udd49\ud95d\udfc1\ud8bf\ude05\udb4f\udf74\udb0e\udfba\udb5f\ude89\udaa7\ude06\ua2a1\udad8\udc20", "\u7515", "\udb30\ude77\udb9c\udde7\ud83b\uddd2\u3bb8\u5ab2\uc8b3\uda40\ude5f\ud88c\udcd6\uda93\udff9\ud832\udd8a\u1d7b\udbeb\uddaa\ud868\udcaa\ud96f\udcc9\udb86\udd52\udb5a\udc1c\udbab\udca6\uadc4\udbaa\udc95\udbc6\udf76\ud897\udc11\u24f1\uda1b\udc68\ud970\udc3f\ud872\ude51\udba1\udef9\ud922\udce4",
        23, 98501, -1866550168, 662191925727798434L, 92649L, true, true, (char) 1508, (char) 8275,
        Double.longBitsToDouble(0x3fbcb9013e03aac0L), Double.longBitsToDouble(0x3f92e21efbf8a1e0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 0, "\uda11\udd49\ud95d\udfc1\ud8bf\ude05\ud8d7\udcd9\ud826\udef3\ud8de\udc52\udaa7\ude06\ua2a1\uda05\udc97", "\u28bc\u30c7\ucfa8\uaf08", "\uda94\udee0\uda2c\udeaf\ud914\udd28\udb81\ude18\ud803\udcbe\udb41\udf23\udb68\udf37\ud8d1\ude90\ud950\udd3f\ud844\udc1e\ud9b8\udf4e\uda17\udfcd\uda5f\ude23\ud8ff\udcff\udbbc\udc6d\uda6c\ude8d",
        28, 78842, -1899394147, 1320895354698084558L, 11716L, true, false, (char) 2065, (char) 28572,
        Double.longBitsToDouble(0x3febdba638723a38L), Double.longBitsToDouble(0x3fd955740e71f2c8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Class:int\0121=null\012",
        Z.run(T, 2, 1, 2, 3, "\uda11\udd49\ud922\udec4\ud870\udd9f\uda35\udd6b\uda50\udebb\udb39\udd09\uda56\udcbf\ud95f\udcbc\udad8\udc20", "\ub986", "\udb30\ude77\ud99f\udf67\ud99e\udf0b\udbde\udea1\u5ab2\uc8b3\uda40\ude5f\ud88c\udcd6",
        15, 45900, -256729653, 5683676537292484902L, -40174L, true, false, (char) 14678, (char) 26058,
        Double.longBitsToDouble(0x3fef4769f7158273L), Double.longBitsToDouble(0x3f8c94bcd4d1c740L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Class:int\012",
        Z.run(T, 2, 2, 1, 0, "\uda11\udd49\ud95d\udfc1\ud8bf\ude05\udbb7\ude28\ud8fb\udcd7\uda0f\udf5d\ud89a\udc40\ua2a1\udad8\udc20", "\ub986", "\udb42\udf40\udb9c\uddd7\udadb\udec7\u3bb8\ud809\udfa9\ud88e\ude00\ud85d\udd8a\ud88c\udcdd\uda93\udff9\ud832\udd8a",
        16, 148, 2139779366, -6720810595428919730L, -52538L, true, false, (char) 6086, (char) 18920,
        Double.longBitsToDouble(0x3fe07252f39d6606L), Double.longBitsToDouble(0x3feaa4764b02c054L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 0, "\ud9bf\udf15\ud98d\udc21\ud8bf\ude05\udb4f\udf74\udb0e\udfba\ud82e\uddf1\ud8ea\udf89\udbfe\udcdd\ud908\udc9e", "\uba86\u39d3", "\ud8ed\ude08\ud83b\uddd2\udb05\ude71\u5b52\uc8b3",
        10, 6383, -607559140, 4592561199924230769L, 99360L, false, false, (char) 28936, (char) 55723,
        Double.longBitsToDouble(0x3fe0737ddedfdeebL), Double.longBitsToDouble(0x3fefe769f7158273L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 1, "\uda11\udd49\udad9\ude1e\ud905\udd66\udb4f\udf74\udb0e\udfba\udb5f\ude89\udaa7\ude06\ua2a1\udad8\udc20", "\ub986\u2a59\u2ed6\u70b9\ua7a8\u2ead\u12ec\u298e\uc988\ub982\u44cd\u5730\uc1fc\ud111\u0b84", "\ud8ab\udf72\uda46\udf45\udbab\udcdb\udaf9\udfc8\udbaa\ude95\udbc6\udf76\ud897\udc11\udacf\udcd2\udb3d\udfd9\ud8de\udfe7\u80d4\ud85e\ude41\udab3\udc9f\udb2a\udc67\ud924\udf1d",
        20, 44251, -840375200, 5425679744441484910L, -86258L, true, true, (char) 2853, (char) 34717,
        Double.longBitsToDouble(0x3fcdc77619ec6e48L), Double.longBitsToDouble(0x3fe93602ad30b755L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Class:int\0121=java.lang.Class:int\012",
        Z.run(T, 2, 1, 1, 0, "\uda11\udd49\ud95d\udfc1\ud8bf\ude05\udb4f\udf74\udb0e\udfba\udb5f\ude89\ud815\uddfd\ua2a1\udaf4\ude20", "\u94d3\uc664\u9d64", "\ud83b\uddd2\u3bb8\u5ab2\uc8b3",
        58, 6383, -607559140, 4232273228626828747L, 60038L, false, false, (char) 47368, (char) 55723,
        Double.longBitsToDouble(0x3fe4d795d8dfdeebL), Double.longBitsToDouble(0x3fefe76eff158273L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 0, 0, "\ud9c0\udf37\ud95d\udfef\ud8bf\ude05\udb4f\udf74\udb0e\udfba\udb5f\ude89\udaa7\ude06\ua2a1\udb9a\udcc2", "\ua47a\u8dd1\u4ff2\ub84c\u4209\ud247", "\uc8b3\uda40\ude5f\ud88c\udcd6\uda93\udff9\udbaf\udea9\ud9d8\ude0e\udbeb\ude57\ud868\udcaa\udb79\udce6\udb86\udd2d\udb5a\udc1c\udbab\udca6\uadc4\udba9\udc58\udbc6\udf76\ud897\udc11\u24f1\uda1b\udc68\ud9f5\udf15\ud932\udf5d\udbf8\udeb2\udad8\udc16\udb72\ude50\udbe4\udf66\ud86f\udede\udb68\udc80\udb01\udf01\udbde\udd53\udb2b\ude43\ud995\udf6f\ud8d6\udc56\u9e8b\udbe9\udd6b\ud8c3\udc2a\udb22\uddd2\udad1\udf79\ud856\udccc\ud80b\udccb\uda6d\udcea\ud909\udef7\udab0\udfd7\udb2b\ude7b\udbf3\udfce\udb8f\udeff\udb3c\udce1\udab9\udc62\ud8fa\udc52\uda1b\udc53\uda11\udcda\udb1c\ude1d\ud977\udd95\ud8e7\udfb2",
        31, 65168, -2006861431, -7708554646095915502L, 75561L, true, false, (char) 8076, (char) 38247,
        Double.longBitsToDouble(0x3fe02cb075d0a26eL), Double.longBitsToDouble(0x3fed2a5363ff2254L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.util.Primitives|isPrimitiveWrapper|java.lang.Class|static",
    "M|org.mockito.internal.util.Primitives|primitiveTypeOf|java.lang.Class|static",
    "M|org.mockito.internal.util.Primitives|primitiveValueOrNullFor|java.lang.Class|static",
    "M|org.mockito.internal.util.Primitives|primitiveWrapperOf|java.lang.Class|static",
    "C|org.mockito.internal.util.Primitives|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
