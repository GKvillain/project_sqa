package org.mockito.exceptions;
import org.junit.Test;
import static org.junit.Assert.*;
public class Reporter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 11, 15, 0, "\u6ac3\ud9e2\ude15", "\ud269\u2940\ua7b1\u168d\ud7b6\u7e3b\u9c19\u5fdc\u81bd\ud174\u2ed7\ub5ae\u6963\u2852\u47df\uace0\u5cb2\u4892\u8eb5\u06ee\uc109\u3224\u3db1\u2608\u29f0\u4df7\ub9d7\u0ac1\u5283\u4e9d\u477d\u5848\u419b", "\udb24\ude80\udbd8\udc47\ud85c\udc30\ud8ac\ude31\ud938\uddc6\uda6d\ude20\ud9aa\ude9d\ud8e3\udd47\udb23\udf64\udb3d\udd2f\ud814\udf55\ud8ca\udf6b\ucdd2\ud9f2\udc2b\udb94\udc36\udb79\udc87\ud80c\udd4c",
        18, 46461, 1152686456, -2029422017055152264L, -44061L, true, false, (char) 53140, (char) 17195,
        Double.longBitsToDouble(0x3fed7bfe49ea6b80L), Double.longBitsToDouble(0x3fecd3ca9472b194L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 13, 12, 12, "\u6f2d\ud9e2\ude15", "\ud269\u2940\ua7b1\u168d\ud7b6\u7e3b\u9c19\u5fdc\u81bd\ud174\u2ed7\ub5ae\u6963\u2852\u47df\uace0\u5cb2\u4892\u8eb5\u06ee\uc109\u3224\u3db1\u2608\u29f0\u4df7\ub9d7\u0ac1\u5283\u4e9d\u477d\u5848\u419b", "\udb24\ude80\udbd8\udc47\ud85c\udc30\ud8ac\ude31\ud938\uddc6\uda6d\ude20\ud9aa\ude9d\ud8e3\udd47\udb23\udf64\udb3d\udd2f\ud814\udf55\ud921\udf7d\ud810\udc06\ud9f2\udc2b\udb94\udc36\udb79\udc87\ud80c\udd4c",
        18, 46461, 1152686456, -2029422017055152264L, -44061L, true, false, (char) 53140, (char) 17195,
        Double.longBitsToDouble(0x3fed7bfe49ea6b80L), Double.longBitsToDouble(0x3fecd3ca9472b194L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 11, 15, 14, "\uda98\udd4b\uda87\udec1\u9a9f\udbe2\udc6f", "\ua7b1\u168d", "\udae2\udfe4\ud8c6\udec4\udb3c\udc59\ud974\udf09\ud846\uddf4",
        25, 72694, -2042641769, 6714911138704516004L, 11073L, false, false, (char) 10249, (char) 13347,
        Double.longBitsToDouble(0x3fdfce37b2ee72d4L), Double.longBitsToDouble(0x3fe99761302b5e36L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 10, 0, "\u6ac3\ud9e2\ude15", "\u07b4\u1478\u2cb2\u168d\ud7b6\u7e3b\u9c19\u5fdc\u81bd\ud174\u2ed7\ub5ae\u6963\u2852\u47df\uace0\u5cb2\u4892\u8eb5\u4064\ucc9a\ud3b3\u3db1\u2608\u29f0\u4df7\ub9d7\u0b93\u5283\u52c3\u794e\u5848\u419b", "\uda12\udc3f\ud842\udc5d\ud85c\udc30\ud8ac\ude31\ud938\uddc6\udb9c\udd28\ud9aa\ude9d\ud8e3\udd47\udb23\udf64\udb3d\udd2f\ud814\udf55\ud8ca\udf6b\ucdd2\ud9f2\udc2b\udb94\udc36\udb79\udc87\ubfc0",
        -2, 76953, -1719249597, -2051940015192004744L, -56253L, true, false, (char) 53140, (char) 25130,
        Double.longBitsToDouble(0x3fed7bfe4fea6b80L), Double.longBitsToDouble(0x3fed7c2a3472b194L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 5, 15, 0, "\udbe0\udf14\udb23\udcd6\u9a9a\ud8c3\ude80\udb9a\udd53\uda09\udfce\udb14\udc40", "\ua9d8\u9c19\u5fdc\u81bd\ud174\u2ed7\uad65\ua1f9\u282f\u090f\u5fbd\u5cb2\u4892\u3409\uc89e\uc109\u3224\u3db1\u048d\u98fe\u4df7\ub9d7\u0ac1\u5283\u45bf\u6f98\ucc48", "\uda93\udf65\udb24\udecc\udbd8\udc47\ud88b\udc21",
        37, 56179, 1780990466, 8393236838954597381L, -82575L, true, true, (char) 26774, (char) 13951,
        Double.longBitsToDouble(0x3fe3b5fb8ee393f6L), Double.longBitsToDouble(0x3fe127de4631c530L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 15, 0, "\u6ac3\ud9e2\ude15", "\ud269\u2940\ua7b1\u168d\ud7b6\u7e3b\u9c19\u5fdc\u81bd\ud174\u2ed7\ub5ae\u6963\u2852\u47df\uace0\u5cb2\u4892\u60d1\u06ee\uc109\u3224\u3db1\u94b4\u2a3e\u4df7\ub9d7\u0ac1\u5283\u4e9d\u477d\u5848\u419b", "\udafc\udfe7\udbd8\udc47\ud85c\udc30\ud8ac\ude31\ud938\uddc6\ud81b\ude97\ud895\udc0f\udbc3\ude96\udb7b\udd75\udb3d\udd43\ud814\udf55\ud8ca\udf6b\ucdd2\ud9f2\udc2b\udb94\udc36\udb79\udc87\ud80c\udd4c",
        18, 46461, 1152686456, -2029422017055152264L, -44061L, true, false, (char) 53140, (char) 17195,
        Double.longBitsToDouble(0x3fed7ba649ea6b80L), Double.longBitsToDouble(0x3fe374d296763901L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.FriendlyReminderException\012",
        Z.run(T, 1, 4, 12, 0, "\u6ac3\ud9e2\ude15", "\ud269", "\ud80e\udcd6\ud8c8\udc01\udb9c\udc82\ud8c5\udf84\ud836\udec5\ud8ca\udef9",
        5, 66604, -951138069, 1870826310982812311L, -54447L, true, true, (char) 16828, (char) 42636,
        Double.longBitsToDouble(0x3fe81e002f7ecca4L), Double.longBitsToDouble(0x3fdfce37b2ee72d4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 9, 15, 2, "\u6ac3\ud9e2\ude15", "\ud269\u2940\ua7b1\u168d\ud7b6\u7e3b\u1a1b\u6002\u81bd\ud174\u2ed7\ub5ae\u6963\u2852\u47df\uace0\u5cb2\u4892\u8eb5\u06ee\u49e5\u0dce\uc031\u02a2\ua202\ub83e\uc82f\u0ac1\u5283\u4e9d\u477d\u5848\u4150", "\udb24\ude80\udbb2\udd98\ud85c\udc30\ud8ac\ude31\ud938\uddc6\uda6d\ude20\uda8d\udd4f\udaae\udfcf\udb23\udf64\udb3d\udd2f\ud814\udf55\udafe\udf45\ucdd2\ud9f2\udc2b\udb94\udc36\udb79\udc87\ud80c\udd4c",
        22, 59152, 1152686564, -2029422017055152264L, -44061L, true, false, (char) 53140, (char) 17195,
        Double.longBitsToDouble(0x3fed7bfe49ea6b80L), Double.longBitsToDouble(0x3fe642c1f472ddb7L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.CannotStubVoidMethodWithReturnValue\012",
        Z.run(T, 1, 10, 15, 0, "\u6ac3\ud9e2\ude15", "\ud269\u2940\ua7b1\u168d\ud7b6\u7e3b\u9c19\u5fdc\u81bd\ud174\u2ed7\ub5ae\u6963\u2852\u47df\uace0\u5cb2\u4892\u8eb5\u06ee\uc109\u3224\u3db1\u2608\u29f0\ub3e3\ub962\u0ac1\u5283\u4e9d\u477d\u5848\u419b", "\udb24\ude80\udbd8\udc47\ud85c\udc30\ud8ac\ude31\ud938\uddc6\uda6d\ude20\ud9aa\ude9d\ud8e3\udd47\udb23\udf64\udb3d\udd2f\ud814\udf55\ud8ca\udf6b\ud80a\uded2\uda1e\udee6\udb94\udc36\udb79\udc87\ud80c\udd4c",
        18, 90765, 510290060, -2029422017055152264L, -44061L, true, false, (char) 53140, (char) 17195,
        Double.longBitsToDouble(0x3fed7bfe49ea6b80L), Double.longBitsToDouble(0x3fecd3ca9472b194L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 13, 0, "\u6ac3\ud9e2\ude15", "\ud269\uaf41\u9b43\u16b5\ud7b6\u7e3b\u9c19\u2074\u81bd\ud174\u2ed7\ub5ae\u6963\u2852\u47df\uace0\u75e1\u0323\u8eb5\u06ee\ud5d3\u8ede\u4f34\u08fa\u2987\u4df7\ub9d7\u0ac1\u5283\u4e9d\ud79a\u5848\u419b", "\udb24\ude80\udbd8\udc47\ud85c\udc30\ud8ac\ude31\ud938\uddc6\uda6d\ude20\ud9aa\ude9d\ud8e3\udd47\udb23\udf64\udb3d\udd2f\ud814\udf55\ud8ca\udf6b\ucdd2\ud9f2\udc2b\udb94\udc36\udb79\udc87\ud80c\udd4c",
        18, 46461, 1152686456, -2029422017055152264L, -44061L, true, false, (char) 53140, (char) 17195,
        Double.longBitsToDouble(0x3fed7bfe49ea6b80L), Double.longBitsToDouble(0x3fecd3ca9472b194L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 0, "\udb88\udf59\ud9e2\ude15", "\ud269\u2940\ua7b1\u168d\ud7b6\u7e3b\u9c19\u5fdc\u81bd\ud174\u2ed7\ub5ae\u6963\u2852\u47df\ub27b\u2bab\u4892\u8eb5\u06ee\uc109\u3224\u3db1\u2608\u29f0\u4df7\ub9d7\u0ac1\u5283\u4e9d\u477d\u5848\u419b", "\udac8\udf23\uc5a1\ud85b\udfb0\ud8ac\ude31\ud938\uddc6\uda6d\ude20\ud9aa\ude9d\ud8e3\udd47\udb23\udf64\udb3d\udd2f\ud814\udf55\ud8ca\udf6b\ucdd2\ud9f2\udc2b\udb94\udc36\udb79\udc87\ud80c\udd4c",
        18, 46461, 1152686456, -3766967048290031752L, -44061L, true, false, (char) 53140, (char) 17195,
        Double.longBitsToDouble(0x3fed7bfe49ea6b80L), Double.longBitsToDouble(0x3fecd3ca968eb194L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 15, 0, "\u6ac3\ud8f8\udf21", "\ud269\u2940\ua7b1\u168d\ud7b6\u7e3b\u9c19\u5fdc\u81bd\ud174\u2ed7\ub5ae\u6963\u2852\u47df\uace0\u5cb2\ua59c\u8f1b\u1c34\ua7c9\u328e\u3db1\u2608\u29f0\ud55e\u04b5\u0afc\u5283\u4e9d\u477d\u5848\ua446", "\udb24\ude80\udbd8\udc47\ud85c\udc30\ud8ac\ude31\ud939\udcde\uda6d\ude20\ud9aa\ude9d\ud8e3\udd47\ud9b7\udece\udb1f\udc42\uda7c\udf09\ud8ca\udf7c\ucdd2\ud9f2\udc2b\udb94\udc36\udb79\udc87\ud80c\udd4c",
        46, 46461, 1152686456, -1827767186474522760L, 50403L, true, false, (char) 53140, (char) 17195,
        Double.longBitsToDouble(0x3fed7bfe49ea6b80L), Double.longBitsToDouble(0x3fecd3ca9472b194L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 8, 13, 0, "\udbbc\udd29\ud873\udd19", "\ud269\ud03f\ua7b1\u168d\uc376\u7e3b\u9c19\u5fdc\u8179\ud174\u2ed7\ub5ae\u6963\u2852\u47df\uace0\u5cb2\u4892\u8eb5\u06ee\uc109\u3224\u3db1\u2608\u29f0\u4df7\ub9d7\u0ac1\u5283\u4e9d\u477d\u5848\u419b", "\ud813\udff8\udbd8\udc45\ud85c\udc30\ud8ac\uded0\ud938\uddc6\uda6d\ude20\ud9aa\ude9d\uda76\udd9b\udbea\udc8f\uda36\udd8b\ud814\udf55\ud8ca\udf6b\ucdd2\ud9f2\udc2b\udb94\udc36\udb79\udc87\udae8\udd5b",
        55, 46461, 1152686456, 7411530176811462869L, -86045L, true, false, (char) 53140, (char) 23561,
        Double.longBitsToDouble(0x3fe544db51728437L), Double.longBitsToDouble(0x3fe9b43cd0c35f87L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 12, 12, "\u6f2d\ud9e2\ude15", "\ud269", "\ud80e\udcd6\ud8c8\udc01\uda92\udd29\u37ff\ud8c6\ude5f\udaca\udedf",
        15, 40031, -951138080, 1870826310982812311L, -54447L, true, true, (char) 16828, (char) 174,
        Double.longBitsToDouble(0x3fe81e002f7ecca4L), Double.longBitsToDouble(0x3fdfce37b2ee72d4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 11, 15, 0, "\u6ac3\ud9e2\ude15", "\u67ed\u86ee\u2d98\u168d\ud7b6\u7e3b\u9c19\u5fdc\u81bd\ud174\u2ed7\ub5aeZ\u2852\u47df\uace0\u5cb2\u4892\u8eb5\u1e75\uc109\u3224\u3db1\ub2c5\u1e21\u4e34\ub9d7\u0ac1\u5283\u4e9d\u477d\u5848\u419b", "\udb24\ude80\udbd8\udc47\ud85c\udc30\ud8ac\ude31\ud938\uddc6\uda6d\ude20\udb2e\udc71\ud92b\udd6f\udb23\udf64\udb3d\udd2f\ud814\udf55\ud8ca\udf6b\ucdd2\uda46\udd95\udb30\udc04\udb79\udc70\ud80c\udd4c",
        1, 33825, 1152686464, -2029422017055152264L, -44061L, true, false, (char) 53140, (char) 17195,
        Double.longBitsToDouble(0x3fdd7b5092401862L), Double.longBitsToDouble(0x3fecd3ca9472b194L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.exceptions.Reporter|exceptionCauseMessageIfAvailable|java.lang.Exception|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|noMoreInteractionsWanted|org.mockito.invocation.Invocation,java.util.List|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|noMoreInteractionsWantedInOrder|org.mockito.invocation.Invocation|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|argumentsAreDifferent|java.lang.String,java.lang.String,org.mockito.invocation.Location|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|atMostAndNeverShouldNotBeUsedWithTimeout||new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotCallAbstractRealMethod||new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotInitializeForInjectMocksAnnotation|java.lang.String,java.lang.Exception|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotInitializeForSpyAnnotation|java.lang.String,java.lang.Exception|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotInjectDependency|java.lang.reflect.Field,java.lang.Object,java.lang.Exception|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotMockFinalClass|java.lang.Class|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotStubVoidMethodWithAReturnValue|java.lang.String|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotStubWithNullThrowable||new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotVerifyToString||new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|checkedExceptionInvalid|java.lang.Throwable|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|createTooLittleInvocationsMessage|org.mockito.internal.reporting.Discrepancy,org.mockito.invocation.DescribedInvocation,org.mockito.invocation.Location|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|createTooManyInvocationsMessage|int,int,org.mockito.invocation.DescribedInvocation,org.mockito.invocation.Location|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|exceptionCauseMessageIfAvailable|java.lang.Exception|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|noMoreInteractionsWanted|org.mockito.invocation.Invocation,java.util.List|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|noMoreInteractionsWantedInOrder|org.mockito.invocation.Invocation|new:org.mockito.exceptions.Reporter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
