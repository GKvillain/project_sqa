package org.mockito.internal.stubbing.defaultanswers;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReturnsEmptyValues_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 1, 1, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\ud959\udd50\ud83c\ude50\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udb9f\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\ud877\udfd8\udbbd\udd08", "\u1547\u3f36\u5f5f\uaaf6\u33e6\u8eed\u461c\u3c08\u7c3e", "\ud855\udf4a\udb88\ude1c\udab1\udfb0\ud9ed\ude2f\ud9d4\udc86\ud899\udf24\udadd\udd07\ubdf5\udab7\udcdc\ud948\udd9b\ud846\udfc7\ud96e\udd18\ud99b\udd79\ud940\udd43",
        42, 12521, 346152144, 162842937367264548L, -61853L, false, false, (char) 26517, (char) 532,
        Double.longBitsToDouble(0x3fc3a5f18f633398L), Double.longBitsToDouble(0x3fea17f45d7ea9b2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.util.LinkedList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 1, 1, "\udbd9\uddb4\ucb02\udb36\udf4b", "\u1884", "\udab4\udd38",
        18, 93804, -1473006555, -5414859775212621463L, -73314L, true, false, (char) 60878, (char) 8599,
        Double.longBitsToDouble(0x3fd98964ccc44408L), Double.longBitsToDouble(0x3fe3c6ea89ff8a81L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 2, 1, "\udb2f\udf37\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\ud8d4\udcce\ud9de\ude1e\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udb9f\udf0b\udb58\udeb4\ud960\uddb0\ua2cb\ud877\udfd8\udbbd\udd08", "\u1547\u3f36\u5f5f\uaaf6\u33e6\u8eed\u461c\u3c08\u7c3e", "\ud855\udf4a\ud81d\udda6\uda24\udc38\ud9ed\ude2f\ud9d4\udc86\ud899\udf24\udb4b\udfdf\ud8b5\ude82\udad2\ude7f\ud948\udcfb\ud846\udfc7\ud96e\udd18\ud99b\udd79\ud9ce\ude8b",
        13, 12521, 346152144, 162842937367264548L, -61853L, false, false, (char) 26517, (char) 532,
        Double.longBitsToDouble(0x3fc3a5f18c251328L), Double.longBitsToDouble(0x3fea17f45d7ea9b2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\ud959\udd50\ud83c\ude50\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udb9f\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\ud877\udfd8\udbbd\udd08", "\u1547\u3f36\u5f5f\uaaf6\u33e6\u8eed\u461c\u3c08\u7c3e", "\ud855\udf4a\udb88\ude1c\udab1\udfb0\ud9ed\ude2f\ud9d4\udc86\ud899\udf24\udadd\udd07\ubdf5\udab7\udcdc\ud948\udd9b\ud846\udfc7\ud96e\udd18\ud99b\udd79\ud940\udd43",
        42, 12521, 346152144, 162842937367264548L, -61853L, false, false, (char) 26517, (char) 532,
        Double.longBitsToDouble(0x3fc3a5f18f633398L), Double.longBitsToDouble(0x3fea17f45d7ea9b2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.lang.Integer:0 |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 1, 1, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\ud817\uded1\ud83c\ude50\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udb9f\ude60\ud848\uddab\udb49\udd10\ud902\udd52\ud877\udfd8\udbbd\udd08", "\u1547\u3f36\u5f5f\uaaf6\u33e6\u9a4d\u0f41\ubdbe\u9065", "\ud926\udd23\ud951\udfdf\udab1\udfb0\ud9ed\ude2f\ud9d4\udc86\ud899\udf24\udadd\udd07",
        15, 49047, -874793810, 5854286538302172007L, 66090L, false, true, (char) 58755, (char) 64802,
        Double.longBitsToDouble(0x3faf3df7f87e00e0L), Double.longBitsToDouble(0x3fe87ff8209d2f8cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 1, "\ue22b\u5c0e\udb70\udca6\ud9ab\uddda\u33d1\ud959\udd50\ud83c\ude50\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udb9f\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\ud877\udfd8\udbbd\udd08", "\u1547\u3f36\u5f5f\uaaf6\u33e6\u8eed\u461c\u3c08\u7c3e", "\ud855\udf4a\udb88\ude1c\udab1\udfb0\ud9ed\ude2f\ud9d4\udc86\ud899\udf24\udadd\udd07\ubdf5\udab7\udcdc\ud948\udd9b\ud846\udfc7\ud96e\udd18\ud994\udf79\ud940\udd43",
        42, 12521, 346152144, 162842937363070244L, -61853L, false, false, (char) 26517, (char) 532,
        Double.longBitsToDouble(0x3fc3a5f18f633398L), Double.longBitsToDouble(0x3fea17f45d7ea9b2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.util.ArrayList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 1, 1, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\ud959\udd50\ud83c\ude50\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udb9f\udf0b\ud8b0\udc5f\udbac\udc5b\uda84\ude5b\uda48\udf37\udbbd\udd08", "\u1547", "\ud8f9\udc1e\udbb6\ude3c\udb19\udfa0\ud900\udd41\ud95a\udcb1\ud9f3\udd76\udb1d\udd78\u8151\ud855\udf4a\udb88\ude1c",
        37, 68314, -278218476, 681631482760261584L, -41679L, true, true, (char) 35906, (char) 18830,
        Double.longBitsToDouble(0x3fca0c4963285284L), Double.longBitsToDouble(0x3fd24024231fd7e8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Character:\000 |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.lang.Character:\000 |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 1, 1, 2, "\ud849\udeee\uda13\udce3\udb36\udf4b\ud922\udca6\uda2e\udd09\ud94a\ude33\ud83d\udf8f\udafc\udd87\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udbaf\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\uda54\udc05\udbbd\udd08", "\u1547\u3f36\u5f5f\uaaf6\u33e6\u8eed\u461c\u9708\u7c0d", "\ud855\udf4a\udb88\ude1c\udab1\udfb0",
        -1, 88513, 2093657810, -2475388740478942714L, 19961L, true, false, (char) 55474, (char) 36082,
        Double.longBitsToDouble(0x3fe08b13ec6daf00L), Double.longBitsToDouble(0x3fc9429434900908L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\ud959\udd50\ud83c\ude50\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udb9f\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\ud877\udfd8\udbbd\udd08", "\u1547\u3f36\u5f5f\uaaf6\u33e6\u8eed\u461c\u3c08\u7c3e", "\ud855\udf4a\udb88\ude1c\udab1\udfb0\ud9ed\ude2f\ud9d4\udc86\ud899\udf24\udadd\udd07\ubdf5\udab7\udcdc\ud948\udd9b\ud846\udfc7\ud96e\udd18\ud99b\uddec\ud940\udd43",
        42, 12521, 346152144, 162842937367264548L, -61853L, false, false, (char) 26517, (char) 532,
        Double.longBitsToDouble(0x3fc3a5f18f633398L), Double.longBitsToDouble(0x3fea17f45d7ea9b2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\ud959\udd50\ud83c\ude50\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udb9f\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\ud86f\udf6e\udbbd\udd11", "\u1547\u3f36\ucda8\uc37a\u33e6\u8eed\u461c\u3c08\uc3ca", "\ud83f\uded1\udb88\ude1c\udab1\udfb0",
        29, 87908, -575355949, -5692498761931013626L, 32721L, true, false, (char) 42644, (char) 26673,
        Double.longBitsToDouble(0x3fe87ff8209d2f8cL), Double.longBitsToDouble(0x3feec6673742fe8bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.util.LinkedList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\ud959\udd50\ud83c\ude50\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\uda3b\udc2b\ud9f3\udcb2\udbd2\udf83\udb9f\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\ud877\udfd8\udbbd\udd08", "\u80a9\u3f36\u5f5f\u9b37\ubb02\u8f16\u461c\u3c08\u7c3e", "\ud855\udf4a\udb88\ude1c\udab1\udfb0\ud9ed\ude2f\ud9d4\udc86\ud899\udf24\udb2c\udc2f\udb15\ude53\udab7\udcdc\ud948\udd9b\ud846\udfc7\ud96e\udd18\ud99b\udd79\ud940\udd43",
        32, 28851, 346152144, -2647403230111949667L, -61853L, false, false, (char) 26517, (char) 532,
        Double.longBitsToDouble(0x3fc3a5f18f633398L), Double.longBitsToDouble(0x3fea17f45d7ea9b2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 1, 1, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\udb93\ude0e\udbd8\udc69\uad7a\ud99f\ude28\uda39\udcc1\ud818\uddf1\uda5e\uddd3\ud8ed\udd57\udbd2\udf94\udb9f\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\ud877\udfd8\udbbd\udd08", "\u1547\u0533\u541d\u54a0\uac4a\ua8af\u4626\u29f5\u6bac", "\ud855\udf4a\ud953\udd59\udab1\udfb0\ud9ed\ude2f\ud9d4\udc86\ud899\udf24\udadd\udd07\ubdf5\udab7\udd95\ud948\udd9b\ud846\udfc7\ud96e\udd18\ud99b\udd79\ud940\udd43\ud889\udc67\udb9b\udc02",
        34, 38826, -336271068, -7915646375378851075L, 49661L, false, true, (char) 42445, (char) 65328,
        Double.longBitsToDouble(0x3fe7ce2c4381a828L), Double.longBitsToDouble(0x3fe30a11b732b0d3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 1, 2, 1, 1, "\udbd9\uddb4\ucb02\ud98e\uddd6\ud9ab\uddda\u33e0\uda97\udf84\ud86b\udd2b\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud83d\ude3b\u49c5\ud9ff\udcb3\ud9c3\udc4a\ud9e2\udf3a\ud9b5\udd20\udb2f\ude60\udbaf\ude49\ud939\udf8b\ud8ac\udf99\uda3f\ude55\u44ff\ud893\ude2f\ud9f1\udd7a\udbb6\ude3c\ud955\udfd0\ud922\udd41\ud95a\udcb1\uda11\udcbf\ud8d2\udd43\udafd\uddab", "\u19b4\u1ddc\ud5f5\u7464\ud738\u0619\uce92\u25c9", "\ud99b\udd79\ud906\udf46",
        0, 14201, 1252142897, 8915382104975801636L, -61853L, false, false, (char) 65034, (char) 42275,
        Double.longBitsToDouble(0x3feaf9eed07d53faL), Double.longBitsToDouble(0x3fea008f2f710204L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=java.util.ArrayList:[] |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 1, 1, 2, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\udb51\ude07\udb66\udea6\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud893\ude79\ud993\udeea\ud908\udd4b\udbad\udd94\udb9f\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\ud8a8\udcf0\ud87b\udc2c", "\u1547\u2621\u0275\uaaf6\u33e6\u8eed\u461c\u44b5\u4d78", "\ud855\udf4a\udb88\ude1c\udab1\udfb0\ud9ed\udecf\ud9d4\udc86\ud899\udf24\udadd\udd07\ubdf5\ud8ca\udd26\udbca\ude1b\udbb8\udeb2\ud96e\udd18\udb1a\udf83\udbcc\udf32\udada\udf36\udbd1\udcdb\ud8e7\ude07\ud828\udcec\udb43\udc44\udaa7\udc8d\udaf8\ude4a\ud83b\ude5c\ud885\udf78\ud91d\udddc\ud80d\udd9a\ua3c2\udbfc\ude2b\udb7f\udf33\ud8c1\udfcc\udb29\udcbb\udb71\udd72\uda78\udee3\u4567\udbec\udec0\ud893\udf16\ud8e3\udf07\uda6c\uddcb\ud868\udfb2\ud8b6\udd37\udba0\udc9d",
        23, 93306, -1369745845, 1468937986513527164L, -67777L, true, false, (char) 18088, (char) 645,
        Double.longBitsToDouble(0x3fcbd7283cc3193cL), Double.longBitsToDouble(0x3fe454c16bbfa5d9L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 1, 2, 1, 1, "\udbb8\udfa4\u7201\udb36\udf4b\ud9ab\uddda\u33d1\ud919\udcd4\ud83c\ude50\ud88b\udc46\ud96a\udfc7\ud95f\udd4d\udb62\udd65\ud98b\udf04\ud908\udd4b\udbd2\udf94\ud932\udd72\ud81c\uddbc\udb49\udd3d\ud902\udd52\ud877\udfd8\udbbd\udd08", "\u1547\u3f36\u5f5f\uaaf6\u33e6\u8eed\u461c\ua4ee\u8a82", "\ud855\udf4a\udb88\ude1c\udab1\udfb0\ud9ed\ude2f\ud9d4\udc86\ud899\udf24\udadd\udd07\udbe1\udd0e\ud8cc\udd0d\udbaf\udcb4\ud846\udf53\ud96e\udd8f\ud833\udef3\uda6b\udc06",
        42, 12521, 1176214480, 162707414086647076L, -61853L, false, false, (char) 26517, (char) 532,
        Double.longBitsToDouble(0x3fc3a5f18f633398L), Double.longBitsToDouble(0x3fea17f45d7ea9b2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=null |this=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 2, 1, 1, "\udbd9\uddb4\ucb02\udb36\udf4b\ud9ab\uddda\u33d1\ud959\udd50\ud83c\ude50\ud88b\udc46\ud86f\udc29\uda39\udd6d\ud818\uddf1\ud993\udef8\ud908\udd4b\udbd2\udf94\udb9f\udf0b\ud848\uddab\udb49\udd10\ud902\udd52\ud877\udfd8\udbbd\udd08", "\u1547\u3f36\u5f5f\uaaf6\u33e6", "\ud95a\udcb1\ud9f3\udd76\udb1d\udd78\uf351\ud855\udf4a\udb88\ude1c\udab1\udfb0\ud9ed\ude2f",
        38, 89963, -576346354, 4809916997452424767L, -41679L, true, true, (char) 35906, (char) 18830,
        Double.longBitsToDouble(0x3fca0c4963285284L), Double.longBitsToDouble(0x3fd24024231fd7e8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues|answer|org.mockito.invocation.InvocationOnMock|new:org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues|returnValueFor|java.lang.Class|new:org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:",
    "C|org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues|<init>|",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues|answer|org.mockito.invocation.InvocationOnMock|new:org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
