package org.mockito.internal.matchers;
import org.junit.Test;
import static org.junit.Assert.*;
public class Equality_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 2, "\ud9ca\udd32", "\u7e4f\u9522\u0a21", "\ud9c3\udcc6\udbfc\uddde\ud9c7\udf05\ud9a4\udd34\ud9e1\udf30\udbe5\udd83\ud91f\udcab\ud92e\udd9c\udbf9\ude99\ud8de\udc33\ud921\udcf1",
        16, 73593, -161769624, -8448108351865330430L, 66229L, false, false, (char) 2459, (char) 61608,
        Double.longBitsToDouble(0x3fefd6af3e5bde81L), Double.longBitsToDouble(0x3fd6811aea3847c2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 2, "\ud9ca\udd32", "\u7e4f\u9522\u0a21", "\ud9c3\udcc6\udbfc\uddde\ud9c7\udf05\ud890\ude33\ud9e1\udf30\udbe5\udd83\ud91f\udcab\ud92e\udd9c\udbf9\ude99\ud8de\udc33\ud921\udcf1",
        16, 73593, -161769624, -8448108351865330430L, 66229L, false, false, (char) 2459, (char) 61608,
        Double.longBitsToDouble(0x3fefd6af3e5bde81L), Double.longBitsToDouble(0x3fd6811aea3847c2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 3, 2, "\ud9ca\udd32\udb81\udcdd\ud8c8\uddb5\uda29\udf4e", "\u6439\uacfc\ua53f\uad33\u9dd9\u36e1\u80a9\u4318\u1d7c\u841c\u81c2\u6088\ucbc4\u0583\uc0c4\u5bfa\u2239\u71c0", "\udb85\udf97\udb72\udf8b\udb8a\udcad\uda9d\ude00\udb13\udf65\ud913\udf85\udbfb\uded1\uda95\udedd\uda52\udf65\ud841\udda1",
        59, 14428, 426153781, -6398758915556436340L, 60659L, true, false, (char) 58647, (char) 26529,
        Double.longBitsToDouble(0x3fe5d9ee8ae9fdb4L), Double.longBitsToDouble(0x3feeebefae654d42L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 4, 5, "\ud9ca\udd32", "\ub260\u94ae\u0a21\u8f13\uca61\u2a64", "\udb79\udc82\ud9e4\uddc0",
        6, 46440, 1844725131, 5081820513130796805L, 85250L, true, true, (char) 48041, (char) 21323,
        Double.longBitsToDouble(0x3fe8145616470f2eL), Double.longBitsToDouble(0x3fe55d73d6d88a4dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 4, "\ud8df\udd76\ud9d8\udfb8\ud90c\udc38\ud894\udf40", "\u8f13\u9284\ua53f\u34f0\u1dd8\u0de0\u88ee\uc19b\u3cfd\u936b", "\ud937\udd13",
        43, 73593, 73111400, -4962178294447319617L, 32475L, false, true, (char) 23753, (char) 61608,
        Double.longBitsToDouble(0x3fefd6af3e5bde81L), Double.longBitsToDouble(0x3fd6811aed86d3c2L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 5, 2, "\ud9ca\udd32", "\u7e4f\u9522\u0a21", "\ud9c3\udcc6\udbfc\uddde\ud9c7\udf05\ud9a4\udd34\ud9e1\udf30\udbe5\udd83\ud91f\udcab\ud92e\udd9c\udbf9\ude99\ud8de\udc33\ud921\udcf1",
        16, 73593, -161769624, -8448108351865330430L, 66229L, false, false, (char) 2459, (char) 61608,
        Double.longBitsToDouble(0x3fefd6af3e5bde81L), Double.longBitsToDouble(0x3fd6811aea3847c2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.matchers.Equality:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\ud9ca\udd32", "\uc07b\u4cfc\u0a5f", "\ud9c3\udcc6\udbfc\uddde\udb92\udca7\ud840\udc89\ud83a\ude57\ud8a7\udc40\ud930\udc1a\ud92e\udd9c\udbf9\ude99\ud8de\udc33\ud921\udcf1",
        16, 73593, -161769624, -8448108351865330430L, 66229L, false, false, (char) 2459, (char) 61608,
        Double.longBitsToDouble(0x3fefd6aeb65bde81L), Double.longBitsToDouble(0x3fd6811aea3847c2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 2, "\ud9ca\udd51\udb81\udcdd\ud8c8\uddb5\uda29\udf4e\ud94b\udc89\udaea\udf9f\u64f7\uda05\udd69\ud9c3\udcc6\udbfc\uddde\ud9c7\udf05\ud9a4\udd34\ud9e1\udf30\udbe5\udd83", "\u5134\u9188\ua96d\u05a6", "\ud8c0\udf4e",
        20, 82874, -1974634837, -8865301953727462237L, -70298L, true, false, (char) 28438, (char) 20774,
        Double.longBitsToDouble(0x3fe0ceaaae1a0eb5L), Double.longBitsToDouble(0x3fa0621bf9a37510L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 2, 2, "\ud9ca\udd32", "\u7e4f\u6d22\u0a21", "\ud85e\uddd4\ud8a4\udeb2\ud9c7\udf05\uc79b\ud9e1\udf30\udbe5\udd83\ud91f\udcab\ud92e\udd9c\u0089\ud8de\udc33\ud921\udcf1",
        2, 6617, 0, -8448108351865330430L, -100000L, false, false, (char) 34203, (char) 61481,
        Double.longBitsToDouble(0x3fefd6af3e5bde81L), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.mockito.internal.matchers.Equality:@?\0121=new org.mockito.internal.matchers.Equality:@?\012",
        Z.run(T, 2, 5, 5, 0, "\ud9ca\udd32", "\u4472\u88d8\ub4bd", "\ud961\ude96\ud89c\udefb\uc6a1\ud98d\udf72\ud863\udd47",
        1, 97968, -1158396498, -1294849734240034226L, 85250L, true, true, (char) 47960, (char) 16531,
        Double.longBitsToDouble(0x3fd81e4c2e46fa4cL), Double.longBitsToDouble(0x3fe016cffed88a4dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 2, "\uda63\udc4e\udb81\udcdd\u5c3e\ud95a\udeec\ud83e\ude52\udaea\udf9f", "\ua53f\u34f0\u9dd9\u36e1\ubc83\u5993\ud19d\u371b\u01a6\ub69f\uc504", "\ud9dd\udc42\ud8b9\uddbc\udba2\udda6\udadd\ude34\udb74\udf42\udbb9\uddfe\udbdf\udf82\ud80b\udcc5\uda93\uddaf",
        35, 19149, 1526667548, 3657713047274918161L, -74883L, false, true, (char) 9768, (char) 50865,
        Double.longBitsToDouble(0x3fe90ac29318d980L), Double.longBitsToDouble(0x3fe78eab72f6144cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=new org.mockito.internal.matchers.Equality:@?\012",
        Z.run(T, 2, 4, 5, 0, "\ud9ca\udd32\udb81\udcdd\ud8c8\uddb5\uda29\udf4e\ud918\udd89\uda6e\ude9e\u64f7\udaf4\udf61\ud9c3\udcc6\udbfc\uddde\ud9c7\udf05\ud9a4\udd34\ud9e1\udf30\udbe5\udd83\ud91f\udcab\ud92e\udd9c\udbf9\ude99\ud8de\udc33\udb3c\udd02\ud9d3\udf42\uda0f\udfe4\uda03\uded6\ud8c0\udf4e\udba2\udda6\udafa\ude23\ud93d\udfec\udb85\udf97\udb72\udf8b\udb8a\udcad\uda9d\ude00\udb13\udf65\ud913\udf85", "\ud2f2", "\udb2c\ude8c\ud8f1\udf45\udb57\udf03\ud90b\udf53\ud8db\udda3\ud814\udf22\ud89b\udc41",
        11, 58988, 1227005771, 2946362783288873574L, -58515L, false, true, (char) 23048, (char) 40425,
        Double.longBitsToDouble(0x3fdf72c48136e7a6L), Double.longBitsToDouble(0x3fe17c1b32b02a81L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=new org.mockito.internal.matchers.Equality:@?\012",
        Z.run(T, 2, 0, 5, 4, "\ud9ca\udd32", "\u1b59\u2d79\u98ff", "\ud9cd\udeb4\udbfc\uddde\udbf2\udd73\ud98f\udcda\ud9e1\udf30\udbe5\udd83\ud91f\udcab\ud92e\udd9c\udbf9\ude99\uda07\udf89\ud921\udcf1",
        16, 73593, -161769573, -8448108351865330430L, 66229L, false, true, (char) 60978, (char) 61608,
        Double.longBitsToDouble(0x3fefd6af3e5bde81L), Double.longBitsToDouble(0x3fe5208d751c4fd0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.mockito.internal.matchers.Equality:@?\012",
        Z.run(T, 1, 5, 1, 2, "\udb09\udee1", "\u8969", "\u64f7\udaf4\udf61\udbd7\udc70\u81ba\ud87d\udd9f\u38ee\udba5\udd01\udb68\udfbc\udac9\udf0a",
        -5, 73512, -314278211, -5343106095553106850L, 64990L, true, true, (char) 5602, (char) 54492,
        Double.longBitsToDouble(0x3fd6811aea3847c2L), Double.longBitsToDouble(0x3fc91aeb06f3b958L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 4, "\ud9ca\udd32", "\u3b59\u8440\u8d20", "\ud85c\udd7b\uda62\udfb5\ud86f\udcda\udaf1\udeae\ud9e1\udf30\udbe5\udd83\ud91f\udcab\ud92e\udd9c\udbf9\udec0\ud8de\udc33\ud942\uddd2\uda3e\udfc2\uda0f\udfe4\uda03\uded6\ud8c0\udf4e",
        20, 82874, -1974634837, -8865301953727462237L, 80230L, true, false, (char) 26181, (char) 61944,
        Double.longBitsToDouble(0x3feade29e12fc29aL), Double.longBitsToDouble(0x3fe6579d0199ca49L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 2, "\udae6\udc5b", "\u4171\u9aa0\ud68b", "\ud86d\uddc7\udb1f\udc80\ub2e8\udb73\ude3b\ud97c\uded3\udbe5\udd83\ud91f\udcab\ud92e\udd9c",
        29, 55887, 1524922704, -4991931474957545989L, 12073L, false, true, (char) 8426, (char) 1658,
        Double.longBitsToDouble(0x3fe5660caca384f8L), Double.longBitsToDouble(0x3fe94f6bfffad5e7L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.matchers.Equality|areEqual|java.lang.Object,java.lang.Object|static",
    "M|org.mockito.internal.matchers.Equality|areArrayElementsEqual|java.lang.Object,java.lang.Object|static",
    "M|org.mockito.internal.matchers.Equality|areArrayLengthsEqual|java.lang.Object,java.lang.Object|static",
    "M|org.mockito.internal.matchers.Equality|areArraysEqual|java.lang.Object,java.lang.Object|static",
    "M|org.mockito.internal.matchers.Equality|isArray|java.lang.Object|static",
    "C|org.mockito.internal.matchers.Equality|<init>|",
    "M|org.mockito.internal.matchers.Equality|areEqual|java.lang.Object,java.lang.Object|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
