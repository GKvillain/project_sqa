package org.mockito.exceptions;
import org.junit.Test;
import static org.junit.Assert.*;
public class Reporter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 4, "\ud980\udf18\ufdc8\ud8ee\udeed\udaf8\udddd", "\u5d63\ua99c\u1ebf\u6df8\u0856\u9bd4", "\udb24\udc51\udb36\ude1a\ud95d\udc19",
        53, 59746, 442525804, -9010620600525018715L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5638L), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 4, "\ud980\udf18\ud95a\ude15\udb85\ude4b\udaf8\udd1d", "\u5d63\ua99c\u1ebf\u6df8\u0856\u9bd4", "\udb24\udc51\udb36\ude1a\ud95d\udc19",
        53, 59746, 442525804, -9010620600525018715L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5638L), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 5, 14, 4, "\ud980\udf18\ufdc8\ud8ee\udeed\udaf8\udddd", "\u5d63\ua99c", "\ud90f\udfaa\ud822\udfbb\ud8ca\udc8c\udb82\udcdc\udb24\udc51\udb36\ude1a\ud95d\udc19",
        53, 22854, 442525746, -9010620600525018715L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5380L), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 5, 14, 4, "\ud8da\udc44\uda2b\udc0e\ud8ee\udeed\udbb4\udc1a\ud8a9\udda6\ud9ab\ude7c\ud846\udd69", "\u4be0\ub485\u8f2c\ub86a\u9611\u7a5f\ubdaa\u90c7\u4d4f\u5d29\u642c\uceed", "\uda68\udff5\uda5e\udfef\udb5c\ude6a\ud934\udf12\udab5\ude30\udbed\udf62\uda32\udc12\ud890\udc3b\ud88e\ude58\udaae\udd70\udb3c\udc9c\uda0b\udf38\uda1b\udf0f\ud978\uddab\ud847\ude1c\udb36\udf73\ud88a\udd83",
        42, 78841, -1368213251, -1213052332251607259L, 7557L, true, false, (char) 4389, (char) 9165,
        Double.longBitsToDouble(0x3fcb1ed1b4378c38L), Double.longBitsToDouble(0x3fe25bc2aa1afa15L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 14, 4, "\ud980\udf18\ufd4f\ud8ee\udeed\udaf8\udddd", "\u301c\ubc47\u7366\u6df8\u0856\u9bd4", "\udb24\udc51\udb36\ude1a\ud95d\udc19",
        53, 59746, 442525804, -9010620600525018715L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5638L), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 2, 14, 4, "\ud980\udf18\ufdc8\ud8ee\udeed\udaf8\udddd", "\u5d63\ua99c\u1ebf\u6df8\u0856\u0f89", "\udb24\udc51\ud987\udc63\udb33\ude38",
        53, 59746, 442525804, 8571432345150634292L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5638L), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 7, 14, 11, "\ud980\udf18\ufdc8\ud8ee\udeed\udaf8\udddd", "\u5d63\ua99c\u037f\u890e\u6c26\u9bd4", "\udb24\udc51\udb36\ude1a\ud965\udf92",
        53, 82145, 437989740, -9010620600532817499L, -91796L, false, true, (char) 5090, (char) 26310,
        Double.longBitsToDouble(0x3fd94c06962975eeL), Double.longBitsToDouble(0x3fba9a5adae1c228L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 4, 4, "\ud980\udf18\ufdc8\ud8ee\udeed\udaf8\udddd", "\u5d63\ua99c\u1ebf\u6df8\u0856\u535b", "\udb24\udc51\udb36\ude1a\ud95d\udc19",
        53, 4506, 442525804, -9010620600525018715L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5638L), Double.longBitsToDouble(0x3fed234b58a6ff45L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 4, "\ud980\udf18\ud914\udeb3\ud8b7\udd72\udaf8\udda1\ud942\udcfa", "\ua99c\u6da4\u0cfb\u0856\u9bd4\u2596\ud79d\uc74f\ub408\u3a79\u62ef\uc454\ubd58\ubef4", "\ud9db\udd29\ud848\udd99\udb5c\udee3\uda99\udc09\udb53\udc9b\ud97a\udd67\udbc0\udef4\ud86d\udf78\uda4a\udc73\udbe2\udf17\udb3b\ude67\ud914\udc78\udb50\udf83\udab1\udcb3\ud8ac\udc70\ud9e1\udfec\ud8ac\udeba\udac5\ude81\udbc9\ude48",
        0, 74316, -1146024780, -5229783329612626577L, -91721L, true, true, (char) 13240, (char) 59879,
        Double.longBitsToDouble(0x3fef508750c54a9cL), Double.longBitsToDouble(0x3fd4812faaf5b73cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 13, 14, 4, "\ud980\udf9a\udb77\udd43\ud887\udf57\udb1f\udfdd", "\u5d63\ua99c\u8d2f\u8ca7\u0856\u9bd4", "\udb24\udc51\udb36\uddde\udb93\udc14",
        30, 13645, -1245999190, -9019955630338496091L, -26395L, true, false, (char) 4832, (char) 63557,
        Double.longBitsToDouble(0x3fbf13ec3bf1c638L), Double.longBitsToDouble(0x3fecedd2975438abL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 14, 4, "\ud980\udf18\ufdc8\ud8ee\udeed\udaf8\udddd", "\u5d63\ua99c\uc886\u4f38\u0856\u9bd4", "\udb24\udc51\udb36\ude1a\ud95d\udc19",
        53, 59746, 442525804, -9010620600525018715L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5638L), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 6, 14, 4, "\ud980\udf18\ufdc8\ud8ee\udeed\udaf8\udddd", "\u446e\u3c1b\u1e8a\u6df8\u0856\u9bd4", "\udaed\udd51\udb36\ude2c\ud8ca\udfdd",
        53, 42, 436611132, -9010620600525018715L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5638L), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 9, 14, 4, "\ud980\udf18\ufdc8\ud8ee\udeed\udaf8\udddd", "\u5d63\ua99c\u1ebf\u6df8\u0856", "\uda01\udcd9\udb24\udc51",
        14, 56313, 750654963, 4968223151176986647L, -77893L, true, false, (char) 32201, (char) 6704,
        Double.longBitsToDouble(0x3fe1884d7a54bff5L), Double.longBitsToDouble(0x3fbf25509b109638L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 8, 14, 4, "\ud980\udf18\ufdc8\ud8ee\udeed\uda50\udd27", "\ubdea\u9300\u49b0\ucb8c\u0856\u9b9d", "\udb98\udd6c\udbbd\udf04\ud8f3\udf65",
        51, 89322, 442525804, -9010620600525018715L, -18742L, true, false, (char) 45023, (char) 34633,
        Double.longBitsToDouble(0x3fb861fad98d5638L), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 7, "\udb0a\udf1d\ufdc8\ud8ee\udeed\udaf8\udddd", "\ub962\ua99c\u1ebf\u6df8\u0856\u3fd1", "\udb24\udc51\udb36\ude1a\ud95d\udc19",
        53, 55402, 811624556, -8534792963492382908L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5638L), Double.longBitsToDouble(0x3fc48d2d7950e1e4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 14, 4, 14, "\ud980\udf18\ud971\udd80\ud8ee\udeed", "\u45c0\u1b83\u7baf\u51e2", "\ud822\udf70\ud8ca\udc8c\uda01\udcd9",
        52, 11474, -168612687, 3224038517424165794L, -85273L, false, true, (char) 6704, (char) 45023,
        Double.longBitsToDouble(0x3fe2a5ffac7c9542L), Double.longBitsToDouble(0x3fe98d563fa4696bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 14, 4, "\ud980\udf18\ufdc8\uda35\udf0c\udaf8\udd7a", "\u5d63\u4ab2\u3920\u4993\u0856\u9bd4", "\udb24\udc51\udb36\ude1a\ud95d\udc19\ua596\uda3b\ude4c\udbb6\uddf9",
        46, 82533, 1080018468, -9218519436612363745L, -22061L, false, false, (char) 54776, (char) 57615,
        Double.longBitsToDouble(0x3fd5438457a72148L), Double.longBitsToDouble(0x3fd603cd58756ebcL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 15, 12, 4, "\ud980\udf18\ufdc8\ud8ee\udeed\udaf8\udddd", "\u5d63\ua99c\u1ebf\u6df8\u0856\u9bd4", "\udb24\udc51\udb36\ude1a\ud95d\udc19",
        53, 59746, 442525804, -9010620600525018715L, 46794L, true, false, (char) 45023, (char) 53065,
        Double.longBitsToDouble(0x3fcfa0ba8cc6ab1cL), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 4, "\ud980\udf18\ufdc8\ud94c\udefc\udaad\ude85", "\u5d63\ua99c\u1ebf\ub0ee\u0856\u9bd4", "\udb24\udc51\udb36\ude1a\ud95d\udc19",
        53, 59746, 442525804, -9010620600525018715L, -18742L, true, false, (char) 45023, (char) 31305,
        Double.longBitsToDouble(0x3fbf2550998d5638L), Double.longBitsToDouble(0x3fed234b5b543845L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.exceptions.Reporter|smartNullPointerException|java.lang.Object,org.mockito.internal.debugging.Location|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|argumentsAreDifferent|java.lang.String,java.lang.String,org.mockito.internal.debugging.Location|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotCallRealMethodOnInterface||new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotInitializeForInjectMocksAnnotation|java.lang.String,java.lang.Exception|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotInitializeForSpyAnnotation|java.lang.String,java.lang.Exception|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotMockFinalClass|java.lang.Class|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotStubVoidMethodWithAReturnValue|java.lang.String|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotStubWithNullThrowable||new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|cannotVerifyToString||new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|checkedExceptionInvalid|java.lang.Throwable|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|createTooLittleInvocationsMessage|org.mockito.exceptions.Discrepancy,org.mockito.exceptions.PrintableInvocation,org.mockito.internal.debugging.Location|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|createTooManyInvocationsMessage|int,int,org.mockito.exceptions.PrintableInvocation,org.mockito.internal.debugging.Location|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|createWantedButNotInvokedMessage|org.mockito.exceptions.PrintableInvocation|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|extraInterfacesAcceptsOnlyInterfaces|java.lang.Class|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|extraInterfacesCannotContainMockedType|java.lang.Class|new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|extraInterfacesDoesNotAcceptNullParameters||new:org.mockito.exceptions.Reporter:",
    "M|org.mockito.exceptions.Reporter|smartNullPointerException|java.lang.Object,org.mockito.internal.debugging.Location|new:org.mockito.exceptions.Reporter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
