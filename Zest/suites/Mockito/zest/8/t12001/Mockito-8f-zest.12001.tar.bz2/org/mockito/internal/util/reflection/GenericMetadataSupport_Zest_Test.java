package org.mockito.internal.util.reflection;
import org.junit.Test;
import static org.junit.Assert.*;
public class GenericMetadataSupport_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 6, "\ud979\udeed\udabd\udd51\uda24\udfe5\ud900\udd56", "\u9695\u1803\u0ed4", "\udae8\ude5c",
        16, 92877, 1899985560, -1118633684486849847L, 32211L, false, true, (char) 21001, (char) 56458,
        Double.longBitsToDouble(0x3fc9970b06b6f6fcL), Double.longBitsToDouble(0x3fc016389f7e3e40L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 11, "\uda7c\uddee\udabd\udcf6\uda24\udfe5\ud917\udc42\uda8e\udc18", "\u1803\ua281\u9317\ub3fd\u67fd\u6735\u6b0f\uc0d0\ua630\u65c9\u9926\ub0a7\uc3b7\u17db\uc64c\u5646\u24f4\u433d\ud67e\u52d7\u60ac\u6019\u2c32\u7303\ube26\u4a2c\u6930\u6a2c\u0d8f\ub765\u2939\u29cc\uc794\u8719\u874b\u28c9\u05ba\u5bd2\u21ac\u859c\uceea\u6f35\uc209\u98e4\u688a\ud1cd\u7f40\u7eb6\u33d9", "\ud9b0\udc4c\udb47\udfcb\ud898\udd7b\uda70\udf3b\ud866\udf9e\ud9f5\ude61",
        24, 59995, 867396274, -7421534778906652712L, -45543L, true, false, (char) 14032, (char) 33799,
        Double.longBitsToDouble(0x3fde6118afe302a4L), Double.longBitsToDouble(0x3fe87cbb250ea801L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 7, "\ud866\udc12\ud92e\udf10\udbb5\udcc0\udb61\udc58\uda96\udf18\ud9ae\udc98\udb75\udea9\uda29\udc1b", "\u702f\u3ebb\ucd7f\u05e9\uc0d0\ua630\u97ab\u0a74\u9e30\uc3fd", "\u1021\uda89\udd54\ua0b8\udae8\udc87",
        40, 13914, 871337577, 4475371728268412122L, 56898L, true, true, (char) 38553, (char) 35056,
        Double.longBitsToDouble(0x3fe6487c73c59728L), Double.longBitsToDouble(0x3fef923c9eb81222L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 6, "\ud979\udeed\udabd\udd51\ud8ae\udde7\ud900\udd56", "\u9695\u1803\u0ed4", "\udae8\ude5c",
        16, 92877, 1899985560, -1118633684486849847L, 32211L, true, true, (char) 54324, (char) 56514,
        Double.longBitsToDouble(0x3fc9970b06b6f6fcL), Double.longBitsToDouble(0x3fc016389f7e3e40L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 6, "\ud97a\uddde\udabd\udd51\uda24\udfe5\ud900\udd56", "\u8523\u5bbe\u0ed3\u574b\ub3fd\u67fd\u6735\u6b0f\uc0d0\u8368\u97f8\u0a74", "\udb40\udf99\udb35\udf53\ud8a3\udfc6\udacb\udd15\ud9c6\ude1a\udb85\udc52\uda0b\udf0e\udb5f\udeac\u9255\uda31\udc3d\ud88c\udc4b\ud9cb\udcba\udb2a\udeb1\udb12\udd01\ud93b\uddce\udb1b\udff5\udb10\uded9\udb3e\uddb6\uda02\udfed\udbf7\udfdf\uff16\ud8cd\udda3\ud82b\udd1f\uda1f\ude29\ud973\udd2f\ud825\udc01\ud831\udd18\ud990\udd5c\udb0d\udcc5\uda48\udfa5\ud8e8\ude8e\uda88\ude34\udbef\uddc7\ud92f\udd0d\uda52\udcc5\udacf\udf4a\ud88d\udd0a\u3626\udbe5\udf69\ud8bb\udf4a\udb34\udd3f\uda8d\udea5\ud838\udf48\udbe7\udc3d\udaee\udf46\udb32\udf93\udb7d\udfa4\ud9c8\ude73\u36b6",
        4, 16354, -1959128912, -1195975185577558694L, 77418L, true, true, (char) 35545, (char) 22343,
        Double.longBitsToDouble(0x3fb8fc491aeb3b00L), Double.longBitsToDouble(0x3fb7c067764d4098L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.Collections$EmptyList:[] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 10, 4, 6, "\ud979\udeed\udabd\udd51\uda24\udfe5\ud900\udd56", "\u9695\u1803\ub345", "\udae8\ude5c\ud836\udc8c\udbcc\udd85\ud9fa\udd44\udb1f\udfac\udaa1\ude39\ud8e3\udebd",
        31, 36888, -1856965878, -5163294261411605300L, 84919L, false, true, (char) 52735, (char) 48539,
        Double.longBitsToDouble(0x3fea3cf94709d36eL), Double.longBitsToDouble(0x3fe4cb59c2df6e79L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 12, "\ud979\udeed\udac9\udd0c\uda24\udfe5", "\u35eb\u9695\u1803\u2803\u576c\u6d90", "\ud886\udd82\ud9fa\udd44",
        46, 55787, -1788488499, 4372644280804744087L, 6144L, false, true, (char) 42724, (char) 63822,
        Double.longBitsToDouble(0x3fc104aae1097834L), Double.longBitsToDouble(0x3fe180300b187664L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 1, "\ud979\udeed", "\u1cc1\u1fda\u63d8\u9695\u050c", "\ud92b\udce8\udae8\ude5c",
        39, 92877, 1601545880, -1118816362330850615L, 32211L, true, true, (char) 20928, (char) 56458,
        Double.longBitsToDouble(0x3fc99a0b068ccafcL), Double.longBitsToDouble(0x3fe70d8e27df8f63L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.Collections$EmptyList:[] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 10, 4, 6, "\ud979\udeed\ud86a\ude3f\uda1c\ude71\ud900\udd56", "\u9695\u1803\u0ed4", "\udabb\udd65",
        34, 61244, 2099132050, -1118633478328419639L, 51862L, false, true, (char) 21001, (char) 56458,
        Double.longBitsToDouble(0x3fc9970b0b9aeefcL), Double.longBitsToDouble(0x3fe0b49f49e837d3L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.Collections$EmptyList:[] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 8, 4, 6, "\ud979\udeed\udabd\udd51\uda24\udfe5\ud900\udd56", "\u9695\u1803\u0ed4", "\udae8\ude5c",
        16, 92877, 1899985560, -1118633684486849847L, 32211L, false, true, (char) 21001, (char) 56458,
        Double.longBitsToDouble(0x3fc9970b06b6f6fcL), Double.longBitsToDouble(0x3fd51b1c4fbf1f20L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.Collections$EmptyList:[] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 10, 4, 8, "\ud979\udeed\udabd\udd51\uda24\udfe5\udb9f\ude85", "\u9695\u1803\u0ed4", "\udae8\ude5c",
        25, 16992, 1899993205, 1996036101325658420L, 32211L, false, false, (char) 21001, (char) 56458,
        Double.longBitsToDouble(0x3fc9970b06b6f6fcL), Double.longBitsToDouble(0x3fc016389f7e3e40L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 6, "\ud979\udeed\udabd\udd51\uda24\udfe5\ud900\udd56", "\u9695\u1803\u0ed4", "\udae8\ude5c",
        16, 92877, 1899985560, -1118633684486849847L, 32211L, false, true, (char) 21001, (char) 52741,
        Double.longBitsToDouble(0x3fc9971f06b6f6fcL), Double.longBitsToDouble(0x3fc016389f7e3e40L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.Collections$EmptyList:[] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 6, 4, 3, "\ud979\udeed\udabd\udd51\uda24\udfe5\ud900\udd56", "\u8610\u1803\u20e7", "\udae8\ude5c",
        16, 92877, 1899983256, -1118633684486849847L, 32211L, false, true, (char) 21001, (char) 10369,
        Double.longBitsToDouble(0x3fc56290296af6fcL), Double.longBitsToDouble(0x3fc01391fff23e40L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 6, "\udbdf\uddef\udabd\udd51\uda24\udfe5", "\000", "\ud9bf\udf86",
        -5, -1000, 0, -3170534138837406307L, 18935L, true, false, (char) 16940, (char) 59786,
        Double.longBitsToDouble(0x3fa011fcb0a5eff0L), Double.longBitsToDouble(0x3fe9d48a84ccb858L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.Collections$EmptyList:[] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 5, 4, 6, "\ud979\udeed", "j\u1fc4\u63d8", "",
        -5, -1000, -831701313, -1687441670071551199L, -65848L, true, false, (char) 60226, (char) 16940,
        Double.longBitsToDouble(0x3d1f200000000000L), Double.longBitsToDouble(0x3fe85000033a9150L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.LinkedHashMap:{} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 0, 1, 6, "\ud979\udeed\udabd\udd51\ud952\udc5c\000", "\u9695\u1803\u0ed4", "\udae8\ude5c",
        16, 92877, 1899985560, -1118633684486849847L, 32211L, false, true, (char) 21001, (char) 56458,
        Double.longBitsToDouble(0x3fc9970b06b6f6fcL), Double.longBitsToDouble(0x3fc016389f7e3e40L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 12, 6, "\ud878\ude9a\ud900\udfb2\ud859\udc4d\udbeb\udebe", "\u1c43\u22da\u6e10\u574b\uc084\u7841\u9b78", "\uda9f\udf1b",
        1, 99641, 481276240, 807729870159269074L, -49775L, true, true, (char) 62020, (char) 25758,
        Double.longBitsToDouble(0x3fe67c7169d6a5cfL), Double.longBitsToDouble(0x3feeed728141ca84L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.lang.Class:int |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 7, 9, 4, "\uda93\udc99\udbb3\udde7\ud913\udc63\udb45\udeef", "\u9f61\u8f0b\u0ed4", "\udae8\ude5c",
        16, 92877, 1899985560, -1118633684486849847L, 32211L, false, true, (char) 15385, (char) 56378,
        Double.longBitsToDouble(0x3fc9970b06b6f6fcL), Double.longBitsToDouble(0x3fc016388f7e3e40L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 6, "\ud979\udeed", "\u2cce\u721e\u63d8\u9695\u4645\u1d5e\u676d\u559c\u54ca\u6743\u6b0f\uc0d0\u747e\u97ef\u0a74\u9e30\u09e5\ua5a4\uc64c", "\udace\udddfn\ud835\udfad\uda55\udc88\ud92d\udca3\udbc9\udcf4",
        -5, 50941, -1546265382, -4335401944877570332L, 13364L, true, true, (char) 32068, (char) 23579,
        Double.longBitsToDouble(0x3fe8d24c4bf2ba0cL), Double.longBitsToDouble(0x3fefbaa8e251fd02L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 2, "\ud8e7\udccc\ud848\udc1e\udb05\ude17\ud8f4\udc43\uda8e\udc18\uda0b\uddc7\ud9e2\udea2\uda20\udfd3\ud9bf\udf86\ud974\udfe8\udb07\ude19\udbb2\udef6\uda99\ude26\ud826\uded1\udaf7\ude5b\ud82c\ude2b\uda9c\udd64\ud827\ude9f\ud957\udee1\udab3\udefa\uda53\uddd5\udbdf\udf35\ud9d6\udce4\ud9c1\udfc7\uda2f\udd1d", "\u6b54\u8035\u2b22\u4b64\u3816\u4447\u6d0b\u8b1b\u0828\u3c38\u56b6\u6219\ua922\u9460\u0295\u29dd", "\ud987\udecd\uda33\udd8a\udb49\uddf2\ud92c\udfc1\uda9d\ude81\uda84\udc56\ud994\ude50\u33ce\uda6c\udf8b\udad7\udefd\ud9bf\udeec\udbc9\udcfe\udb89\udf5e\udba3\udc2e\udb6b\ude35\udb86\udd5d\udbe1\ude85\ud8aa\udfaa\udba6\uddea",
        13, 11373, 1612724587, 1719069165668310601L, 85067L, true, true, (char) 54067, (char) 37301,
        Double.longBitsToDouble(0x3fe0db61cabb1008L), Double.longBitsToDouble(0x3fe36fbfebcbba89L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap:{T={firstBound=class java.lang.Object, interfaceBounds=[]}} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 10, "\ud991\udeb5\ud82e\udc08\uda24\udfe5\ud900\udd56", "\u4495\u1803\u0ed4", "\udae8\ude5c",
        8, 92877, 1899985560, -1118633686512409900L, 75045L, true, false, (char) 26633, (char) 14583,
        Double.longBitsToDouble(0x3fd8651c80709952L), Double.longBitsToDouble(0x3fc0163895029a40L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=void |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 0, 0, 4, "\ud979\udeed\udabd\udd51\uda24\udfe5\ud900\udd56", "\u9695\u1803\u0ed4", "\udae8\ude5c",
        16, 92877, 1899985560, -1118633684486849847L, 32211L, false, true, (char) 24329, (char) 0,
        Double.longBitsToDouble(0x3e20000000000000L), Double.longBitsToDouble(0x3fc016389f7e3e40L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 4, "\ud979\udeed\udabd\udd2a\uda10\udee5\udadb\udc03\udaba\udf0e\udb1b\uddcf\ud85b\udf7d\ud934\udd1e\ud9bf\udf86", "\u63d7", "\ud9fa\udd44\udb1f\udfac\ud894\udc73",
        46, 81886, -1297921013, 1124929831216234789L, -5759L, false, false, (char) 50008, (char) 17743,
        Double.longBitsToDouble(0x3fe5cd1c383a883eL), Double.longBitsToDouble(0x3fe4984d84afebf5L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 11, "\ud95e\ude3f\udac4\udffe\uda24\udfb6\ud900\udd56", "\u4736", "\u64a5\ud942\udd90\udbc3\udc6c\ud983\udd89\udbd4\ude09\udada\udcd5\ud83c\udf95\uda10\udfac",
        47, 60916, 595627005, -6234305310976634143L, 93894L, false, false, (char) 8047, (char) 4843,
        Double.longBitsToDouble(0x3fe5456399ab6dfbL), Double.longBitsToDouble(0x3fe8894500f222f2L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 6, "\ud979\udeed\udabd\udd51\uda24\udfe5\ud900\udd56", "\u9695\u1803\u07b8", "\ud8fd\udd42",
        51, 92877, 1899985560, 7411184009758243529L, 32211L, false, false, (char) 41898, (char) 56458,
        Double.longBitsToDouble(0x3fc9970b06b6f6fcL), Double.longBitsToDouble(0x3fc016389f7e3e40L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 10, 8, 10, "\uda8d\ude96\udbc1\udcfa\udb5e\ude42\udb38\udc3d\uda73\udead\udbca\udfc6\ud872\uddc9\ud855\udfc6\ud9bf\udf86\ud974\udfe8", "\u5043\u18b1\ud1b5\ubaee\u8ebe\uba3b\u9e30\uc3b7\u17db\u351e\u69a9\u24f4\u433d\u5b65\uc47c\u7f1e\u3868\u470f\uae5a\u24c0\ud6fa\uab65\u30ad\u6a03\u8000", "\ud851\ude2d\u3291\ud9a2\udf2f\uda8e\udf16\ud863\udcec\udbbb\udec3\udbef\udfcd\udadd\udeb3\udaf4\udeb5\ud83f\udf16\ud8be\uddd4\ud8ea\uded0\ud81b\udff1\ud843\udee6\udb1a\uddf0",
        33, 48836, -236810169, -2194269469149316551L, 82180L, true, false, (char) 6045, (char) 14502,
        Double.longBitsToDouble(0x3fe6475bf5783cf4L), Double.longBitsToDouble(0x3feb6a0b4ee21c85L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 1, 7, 0, 4, "\ud979\udeed\udabd\udd51\ud952\udc5c\ud900\udcec", "\000\000\u8578", "",
        -5, -1000, -1168637952, 652835028992L, 96608L, true, true, (char) 48152, (char) 62472,
        Double.longBitsToDouble(0x3fe9d48a80000058L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 7, 7, 6, "\ud979\udeed\udabd\udd51\uda24\udfe5\ud900\udd56", "\u2d19\u1836\u1f6c", "\udae8\ude5c",
        16, 92877, 1899985560, -1118633684486849847L, 32211L, false, true, (char) 21001, (char) 56458,
        Double.longBitsToDouble(0x3fc9970b06b6f6fcL), Double.longBitsToDouble(0x3fc016389f7e3e40L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.lang.Class:java.lang.String |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 9, 9, 12, "\ud816\udf3b\udb88\udd04\udb6e\udf07\ud900\udda5\uda8e\udc18\udb1b\uddcf\ud85b\udf7d\ud934\udd1e\udbd6\udcd2\ud974\udfe3\ud838\udfd3\ud86e\ude5f\ud836\udc8c\ud886\udd82\ud9fa\udd44", "\u0a74\u9e30\uacb5\uada0\u2988\u5646", "\udbc8\udca3\ud8fe\ude8c\uda1a\ude69\udb4e\udc82\udbfb\udffc\udb32\udd45",
        14, 34828, -1046717794, -4485866327769862185L, 12175L, true, true, (char) 36850, (char) 19027,
        Double.longBitsToDouble(0x3fe12c10adb33629L), Double.longBitsToDouble(0x3fc8a8e959e82194L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=null |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 5, 5, 11, "\uda7c\uddee\udabd\udcf6\ud8ed\udfc9\uda93\udda9\uda8e\udc48", "\u1803\ua281\u9317\ub3fd\u892d\u6c60\u6b0f\uc0d0\ua630\u65c9\u9926\ub0a7\uc3b7\u17db\uc64c\u5646\u24f4\u433d\ud67e\u52d7\u60ac\u6019\u2c32\u7303\u4a61\u7bf7\u056c\u6a2c\u0d8f\ub765\u2939\uc2fc\u1082\u8719\u874b\u6dc9\u05ba\u5bf4\u21ac\u30f5\ub563\ucab5\u174d\u11ef\u684d\ud1cd\u7f40\u7eb6\u33d9", "\ud9b0\udc4c\udb47\udfcb\ud898\udcd3\uda70\udf3b\ud866\udf9e\ud9f5\ude61",
        24, 59995, -1112315214, -7397937665941712936L, -45543L, true, false, (char) 39289, (char) 11529,
        Double.longBitsToDouble(0x3fde6c247fe302a4L), Double.longBitsToDouble(0x3fe87cbb250ea801L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=void |a0=[Ljava.lang.reflect.TypeVariable;:[[]] |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 10, 10, 6, "\ud97a\uddde\udabd\udd51\udad0\udfdb\ud900\udd56", "\u8523\u5bbe\u0ed3\u574b\ub3fd\u67fd\u6064\u1400\uc063\u8368\u97f8\u0a74", "\udb40\udf99\udb35\udf53\ud803\udcc9\udacb\udd15\ud9c6\ude1a\udb85\udc52\uda0b\udf0e\udb5f\udeac\u9255\uda30\udf4f\ud88c\udc4b\ud9cb\udcba\udb2a\udeb1\udb12\udd01\ud93b\uddce\udb1b\udff5\udb10\uded9\udb3e\uddb6\uda02\udfed\udbf7\udfdf\uff16\ud8cd\udda3\ud82b\udd1f\uda1f\ude29\ud973\udd2f\ud825\udc01\ud831\udd18\ud832\udeac\uda5d\uddf7\ud83f\udc00\udbf3\udf14\uda88\ude34\udbef\uddc7\ud92f\udd0d\uda52\udcc5\udacf\udf4a\ud88d\udd0a\u3626\udbe5\udf69\ud8bb\udf4a\udb34\udd3f\uda8d\udea5\ud838\udf48\udbe7\udc3d\udaee\udf46\udb32\udf93\udb7d\udfa4\ud9c8\ude73",
        12, 98384, 471586354, -8414394605966521624L, 73695L, false, true, (char) 62617, (char) 35545,
        Double.longBitsToDouble(0x3fc20456e18fc490L), Double.longBitsToDouble(0x3feaeb3b045f019dL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 6, "\ud97a\uddde", "\u1cc1\ubd85\ubb32\000\u5639", "\ud838\udfd3\udae8\ude5c\ud836\udc8c\uf59d\ud9db\udeac\uda9e\udd35\udaa1\ude39\ud8e3\udebd\udafd\uddab\ud8a4\udcb9\udb40\udf99\ud829\udf4d\ud8a3\udfc6",
        -5, 38240, -491657715, -1081639064448442294L, -52132L, false, true, (char) 108, (char) 17713,
        Double.longBitsToDouble(0x3fd68312b0756ab2L), Double.longBitsToDouble(0x3fef36b76c6344ebL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap:{T={firstBound=class java.lang.Object, interfaceBounds=[]}} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.util.LinkedHashMap:{T={firstBound=class java.lang.Object, interfaceBounds=[]}} |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 1, 1, 8, "\ud918\uddcd\uda9f\udfef", "\u1fda\u63d8", "\ud8a5\udf59\ud971\udfc3\ud838\udfd3\udacd\udf5c\ud836\udc8c\udbcc\udd85\ud9fa\udd44\udb1f\udfac\udb12\udf92\ud91f\udcec\ud850\uddb4",
        50, 43719, -1668728102, -1933006920724783136L, 94534L, true, true, (char) 10178, (char) 14605,
        Double.longBitsToDouble(0x3fdca0c77621e450L), Double.longBitsToDouble(0x3fe2c0cf664becbdL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.util.reflection.GenericMetadataSupport$FromClassGenericMetadataSupport:@?\012",
        Z.run(T, 2, 6, 6, 2, "\ud979\udeed\udbd9\udcd5\udb54\ude3f\ud900\udd56\uda8e\udc18\uda04\udc2a\ud85b\udf7d\ud934\udd1e\ud9bf\udf86\ud974\udfe8\ucbd1\udabb\udd65\uda28\udd66\ud8b4\udd28\uda4f\uddf1\udb8c\ude14\ud92a\udee0\udb1f\uddbc\udaea\udce8\ud8a6\udeed\ud871\udc84", "\u33a6", "\udac0\udd6a\ud96e\ude81\ud9b1\udc01\ud913\ude6b\ud9de\udd70\ud884\udc0c\ud923\ude29\ud81d\udcee\u2893\ud997\udc8a\ud967\udf3f",
        18, 56174, 1743420057, -3370812006897409867L, -31614L, false, false, (char) 10705, (char) 58219,
        Double.longBitsToDouble(0x3fdbba8394a52960L), Double.longBitsToDouble(0x3f9d7c84e9063e00L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 6, "\ud979\udeed\udabd\udd51\uda24\udfe5\ud900\udd56", "\u9695\u1803\u0ed4", "\udae8\ude5c\ud836\udc8c\ud811\udcfd",
        58, 67983, 979368649, -1297872539959559283L, -37782L, false, true, (char) 19748, (char) 10093,
        Double.longBitsToDouble(0x3fc016389f7e3e40L), Double.longBitsToDouble(0x3fe9786ad3460075L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|registerTypeVariablesOn|java.lang.reflect.Type|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|actualTypeArguments||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|boundsOf|java.lang.reflect.TypeVariable|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|boundsOf|java.lang.reflect.WildcardType|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|extraInterfaces||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|getActualTypeArgumentFor|java.lang.reflect.TypeVariable|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|hasRawExtraInterfaces||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|inferFrom|java.lang.reflect.Type|static",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|rawExtraInterfaces||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|rawType||fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|registerTypeParametersOn|[Ljava.lang.reflect.TypeVariable;|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|registerTypeVariableIfNotPresent|java.lang.reflect.TypeVariable|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|resolveGenericReturnType|java.lang.reflect.Method|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
    "M|org.mockito.internal.util.reflection.GenericMetadataSupport|registerTypeVariablesOn|java.lang.reflect.Type|fac:org.mockito.internal.util.reflection.GenericMetadataSupport:inferFrom:java.lang.reflect.Type",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
