package org.mockito;
import org.junit.Test;
import static org.junit.Assert.*;
public class Matchers_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 31, 13, 7, "\ud891\ude57\ud95c\udee6\udb8d\udff5\ud932\udcd3\ud8ce\ude45\uda72\udc35\uda46\udf6a", "\u0391\u42d4\u1223\ub63e\u16f1\u5793\uafab\ua733\ub9dd\u972f\u83ca\u974c\u6c07\ua9f9\u369f\u79cb\u9405\u32e3\u848a\u9b2e\ua4bf\u08ce\uac14\uc2ed\u85e1", "\ud841\udf4f\udad7\udf0d\ud825\udcff\udbef\udf71\ud97f\udc46\udba9\udf18",
        3, 9132, -540725869, -835108284059711428L, -59171L, false, false, (char) 55110, (char) 54736,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3fd9beb96381043aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 31, 13, 7, "\ud891\ude57\ud95c\udee6\udb8d\udff5\ud932\udcd3\ud8ce\ude45\uda72\udc35\uda46\udf6a", "\u0391\u42d4\u1223\ub63e\u16f1\u5793\uafab\uac89\ud035\u972f\u83ca\u974c\u6c07\ua9f9\u369f\u79cb\u9405\u32e3\u848a\u9b2e\ua4bf\u08ce\uac14\uc2ed\u85e1", "\ud841\udf4f\udad7\udf0d\ud825\udcff\udbef\udf71\ud97f\udc46\udba9\udf18",
        50, 48463, 2022646643, -834901657478068164L, -59171L, false, false, (char) 55110, (char) 54736,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3fd9beb96649fdc4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 12, 32, 7, "\ud891\ude57\ufa17\000\ud947\udd02\u00db\000\000", "", "\udad1\udda7\ud8b7\ude4c\000\ub3b9",
        -5, 68360, -1572984579, 0L, -85610L, false, true, (char) 0, (char) 14592,
        Double.longBitsToDouble(0x3fe83f62a7007036L), Double.longBitsToDouble(0x3fd4fb8c2ebdf7f4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 25, 13, 7, "\udb8a\udc7f\udb97\udc7c\udb73\udd47\udaed\ude06\ud8ce\ude1e\uda72\udc35\uda46\udf6a", "\u0391\u42d4\u91d6\ud4c3\u4918\u56e3\uafab\ua733\ub9dd\u7f7b\u1c68\u974c\uc2ae\ua9f9\u369f\u79cb\u9405\u32e3\u848a\u9b2e\u3075\u08da\uac14\uc2ed\u85e1", "\udbc8\udd55\udad7\ude63\ud835\udce7\udbef\udf74\udbc9\ude10\udba9\udf18",
        3, 9020, -1471950457, -835108060721412036L, -59171L, false, false, (char) 34876, (char) 54736,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3feabf5cb1c082eaL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 31, 13, 7, "\ud891\ude57\ud95c\udee6\udb8d\udff5\ud932\udcd3\ud8ce\ude45\uda72\udc35\uda46\udf6a", "\u0391\u42d4\u1223\ub63e\u16f1\u5793\u4b3a\ua73c\ub9dd\u972f\u83ca\u974c\u6c07\ua9f9\u369f\u9cc1\u812d\u32e3\u848a\u7dd9\ucf55\u29db\uac14\uc2ed\u85e1", "\ud841\udf4f\udad7\udf0d\ud825\udcff\udbef\udf71\ud97f\udc46\udba9\udf18",
        18, 85187, -540725941, 8467016344393393638L, -59171L, false, false, (char) 53672, (char) 54736,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3fd9beb96381043aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 17, 13, 7, "\ud951\udf38\udb9d\udd65\udb8d\udff5\ud932\udcd3\ud8ce\udf45\ud8f6\uddd8\udbbb\udfa3", "\u9be9\u42d4\u1223\u1b98\u16f1\u5793\uafab\ua733\ub9dd\u972f\u83ca\u974c\u6c07\ua9f9\u539f\u79cb\u2177\u025d\u3906\u9b2e\u90e6\u1581\uac14\u1b65\u34c1", "\ud841\udf4f\udad7\udf0d\ud825\udcff\udbef\udf71\ud97f\udc46\udba9\udf18",
        3, 9132, -540725869, 4528288198049517447L, -59171L, false, true, (char) 21068, (char) 54736,
        Double.longBitsToDouble(0x3f94594fb90e1f00L), Double.longBitsToDouble(0x3fd9beb96381043aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Float:0.0\012",
        Z.run(T, 1, 8, 15, 7, "\ud891\ude57\ud95c\udee6\uda58\udefa\ud932\udc80\ud8ce\ude45\uda72\udc35\uda46\udf6a", "\u0391\u42d4\u6bd8\u3c24\u16f1\u5793\uafab\ua733\ucb1b\u62d6\u2c62\u974c\uae22\ua9f9\u369f\u79cb\u1ba1\u414d\u84be\u9b2e\u6e67\u7d93\ud7f2\uc2ed\u85e1", "\ud841\udf4f\udad7\udf0d\ud825\udcff\udbef\udf71\udb6e\ude5f\ud91d\ude3a",
        48, 9057, -540725869, -8931925105141708559L, -59171L, false, false, (char) 41855, (char) 17012,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3fd9beb96913043aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 23, 13, 7, "\ud948\uded2\ud95c\udf7c\udaa1\ude9e\udb5b\udfc9\udbd0\uddda\udafc\udc1a", "\u3df8", "\ud9f6\uded9\uda39\udc9e\ud934\udd7f\ud85c\udf0f",
        41, 7728, -1572984579, 6498821385668458125L, -3690L, false, true, (char) 6554, (char) 58048,
        Double.longBitsToDouble(0x3fe83f62a7537036L), Double.longBitsToDouble(0x3fd4fb8c2ebdf7f4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Byte:0\012",
        Z.run(T, 1, 19, 13, 13, "\ud891\ude57", "\ub0a1\ud4de\u9f95\u9295\u5dc9\u3df8", "\ud961\uddaf\udaae\udca7\ud934\udd7f\u8b13",
        41, 7728, -1572984579, -1746099333847432694L, -100000L, false, true, (char) 6393, (char) 0,
        Double.longBitsToDouble(0x3fe8000000000036L), Double.longBitsToDouble(0x3fd4fb8c2e01f7f4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 30, 13, 7, "\ud891\ude57\ud95c\udee6\udab1\uddc7\ud932\udca5\ud8ce\ude45\uda72\udc35\uda46\udf20", "\u0415\u42d4\u3c05\ub2bd\u16f1\u5793\u8f97\ua733\u0c89\u472d\u84a4\u974c\u6c07\ua9f9\u098d\u5a31\u1435\u65f7\u92d7\u6aa9\ub59f\uc919\uac14\uc2ed\u9dc8", "\ud835\udc99\ud966\ude60\ud825\udcff\ud9d0\udd62\ud97f\udc46\udba9\udf18",
        -2, 9132, -540725869, -835108284059711428L, -59171L, false, false, (char) 55110, (char) 54736,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3fd9beb96e53043aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 16, 17, 27, "\ud891\ude57\ud95c\udee6\udb8d\udff5\ud932\udcd3", "\u9295\u5dc9\u3df8", "\ud961\uddaf\udaae\udca7\ud934\udd7f\u8b13",
        41, 7728, -1572984579, -1746099445516582390L, 93835L, false, true, (char) 6554, (char) 58048,
        Double.longBitsToDouble(0x3fe83f62a7c27036L), Double.longBitsToDouble(0x3fe9c1c2bfc0facdL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 17, 21, 7, "\ud915\udfaa\ud9dc\udd73\uda62\udf10\ud9dd\udd51\uda3e\ude80\udae3\udd90\uda46\udf1b", "\u0391\u42d4\u1223\ub63e\u16f1\u5793\uafab\ua733\ub9dd\u972f\u83ca\u974c\u6c07\ua9f9\u369f\u413c\u9405\u32e3\u848a\u473e\u79b2\u044e\uac14\uc2ed\u85e1", "\ud841\udf4f\udad7\udf0d\ud825\udcff\udbef\udf71\ud97f\udc46\udba9\udf18",
        44, 9132, -540725869, -835108284059711428L, -59171L, false, false, (char) 55110, (char) 54736,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3fd9beb96381043aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 2, 1, 7, "\udacf\udd56\ud95c\udee6\udb8d\udff5\ud932\udcd3\ud8ce\ude45\udb31\udf17\ud8c7\udc5a", "\u0391\u42d4\u1223\ub63e\u929c\u5793\uafab\ua733\ub9dd\u941a\u83ca\u974c\u6c07\ua9f9\u369f\u765a\u9405\ua784\u0ebd\u9b2e\ua4bf\u08ce\uac14\u9012\u85e1", "\ud85c\udd85\udad7\udf0d\ud825\udcff",
        16, 25073, -1748845970, -1279052226494267556L, 90095L, false, false, (char) 9990, (char) 19190,
        Double.longBitsToDouble(0x3feea19da3b24bf4L), Double.longBitsToDouble(0x3fc08338f051653cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.LinkedList:[]\012",
        Z.run(T, 1, 5, 13, 24, "\ud891\ude57\ud8a4\udce9\udb95\udc29\ud932\udcd3\ud8ce\ude45\uda72\udc35\uda46\udf6a", "\u0391\ud08c\ucc00\u554a\u16f1\u0f3a\uafab\ua733\ub9dd\ubd08\u83ca\u974c\u6c07\ua9f9\u369f\u79cb\u9405\u32e3\u848a\uc524\ua4bf\u08ce\uac14\uc2ed\uc8d7", "\uda4d\udc10\ud84e\udf70\ud9be\udeaa\udbc3\udfb8\udabe\udfbe\ud866\udfa8",
        22, 84535, -540725869, -835108284059711375L, -59171L, false, false, (char) 55110, (char) 54639,
        Double.longBitsToDouble(0x3f94594f355f26c0L), Double.longBitsToDouble(0x3fc8542427020874L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 31, 13, 7, "\udb98\ude3a\ud95c\udee6\ud9a1\udd73\ud862\udc74\ud8ce\ude45\uda72\udc35\uda46\udf6a", "\u30f0\u42d4\u1223\ub63e\u16f1\u5793\u41ce\u6682\u16c2\u5deb\u43f7\u5cd5\u6c07\ua9f9\u369f\ubfec\u0c12\u32e3\uc595\u9b2e\u76fa\uc84f\u529f\ua456\u85e1", "\ud841\udf4f\udad7\udf0d\udbe4\udca8\udb36\udd99\ud9a1\udf8e\uda10\udf43\udba6\ude0d\ud9da\udf43\uda19\udee8\uda62\udcbe\udba0\udfbb\uba84\ud8be\udf55\udb8c\udeec\uda21\udfa9\ud94a\uddd6\udb9e\udeb0\ud805\udc94\udb3c\ude2f\ufe3c",
        -4, 66450, -899433726, -1613272387401141791L, 82449L, false, true, (char) 49806, (char) 58132,
        Double.longBitsToDouble(0x3fe042de1d62ac65L), Double.longBitsToDouble(0x3fb9e3dac74b6910L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.LinkedList:[]\012",
        Z.run(T, 1, 22, 29, 31, "\ud8af\ude26\ud95c\udf72\udb8d\udff5\ud932\udcd3\ud8ce\ude45\udabd\ude44\ud93d\udd87", "\ud1ea\u4277\u1223\ub63e\u0bae\u57c5\uafab\u54a6\u23cf\u971a\u7628\u4a8a\u6c07\ua9f9\u34f0\u5f15\u9405\u32e3\u848a\ubd36\u317a\uce95\uab53\ua3f7\u6efd", "\ud841\udfc4\uda95\udf0c\ud825\udcff\udbef\udf71\ud97f\udc46\udba9\udf18",
        3, 9132, 835005843, -835108743621212100L, -21435L, false, false, (char) 15943, (char) 54736,
        Double.longBitsToDouble(0x3fe1e2ca7972158cL), Double.longBitsToDouble(0x3fd9beb63381043aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.HashSet:[]\012",
        Z.run(T, 1, 33, 31, 16, "\ud891\ude57\ud95c\udee6\udb8d\udff5\ud932\udcd3\ud8ce\udda3\uda72\udc35\uda46\udf6a", "\u0391\u42d4\u1223\ub63e\u16f1\u5793\uafab\ua733\ub9dd\u972f\u83ca\u974c\u6c07\ua9f9\u369f\u79cb\u9405\u32e3\u848a\u9b2e\ua4bf\u08ce\u8ebf\ua70a\u85e1", "\ud841\udf4f\udad7\udf0d",
        28, 34576, 1135872073, -4155737790121094787L, 84941L, true, true, (char) 31909, (char) 28358,
        Double.longBitsToDouble(0x3fc07eaca778bf7cL), Double.longBitsToDouble(0x3fe35c33ec93d13dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null\0121=java.util.LinkedList:[]\012",
        Z.run(T, 2, 16, 11, 24, "\ud899\udf77\ud95c\udee6\ud8f5\udd69\ud935\ude28\ud8ce\ude45\uda72\udc35\udb18\udf73\ud879\udd1e\udb8d\udd11\ud9aa\udf43", "\ub63e\u16f1\u5793\u4714\u2002\u6fe6\u972f\u83ca\u6f00\u395b\u2764", "\udb93\udda3\ud8f4\udeab\ud91c\udd12\ud96f\uddd4\udace\ude03\ud989\udd51",
        -3, 84781, -580563531, 6186596548051643241L, -35373L, true, false, (char) 53959, (char) 19323,
        Double.longBitsToDouble(0x3fd1b4af6e77a5d6L), Double.longBitsToDouble(0x3feae3c15593d6a2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Character:\000\012",
        Z.run(T, 1, 20, 9, 12, "\ud891\ude57\ud95c\udee6\udb8e\udc05\ud932\udcd3\ud8ce\ude45\uda72\udc35\uda46\udf6a", "\u0391\u42d4\u1223\ub63e\u0cf1\u5793\u888f\ua72e\ud7be\u972f\u83ca\u974c\u6c07\ua9f9\u8ba8\u79cb\u9405\u32e3\u848a\u9b2e\ua4bf\u08ce\uac14\uc2ed\u85e1", "\ud841\udf4f\udaa5\udcb4\udb58\udec8\udb38\udf61\ud93a\udec2\udba9\udf18",
        43, 9132, -540733939, -835108284059711428L, -59171L, false, false, (char) 55110, (char) 54736,
        Double.longBitsToDouble(0x3f94594fa86e9400L), Double.longBitsToDouble(0x3fd9beb96381043aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.util.LinkedList:[]\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 10, 13, 7, "\ud891\ude57\ud95c\udee6\udb5d\udcf5\ud932\udcd3\ud8ce\ude45\uda72\udc35\uda46\udf6a", "\u0391\u42d4\u1223\ub63e\u16f1\u5793\uafab\ua733\ub9dd\u972f\u83ca\u974c\u6c07\ua9f9\u2711\u3704\ua588\u32e3\u1b2d\u6e32\ua4bf\u9966\u3a48\uc2ed\u85e1", "\ud841\udf4f\udad7\udf0d\ud825\udcff\udbef\udf71\ud97f\udc46\udba9\udf18",
        3, 9132, -540725869, -835108284059711428L, -59171L, false, false, (char) 55110, (char) 54736,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3fc37d72c7020874L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Short:0\012",
        Z.run(T, 1, 34, 8, 7, "\ud891\ude57\ud95c\udee6\udb8d\udff5\ud932\udcd3\ud8ce\ude45\uda72\udc35\uda46\udf6a", "\uabdd\u42e9\u1223\ub63e\u16f1\u5793\uafab\u6112\u4fad\u21e3\u83ca\u974c\u6c07\ua9f9\u369f\u79cb\u9405\u9e47\u84b7\u9b2e\ua4bf\u08ce\uac14\uc2ed\u85e1", "\ud841\udf4f\udad7\udf0d\ud825\udcff\udbef\udf71\ud97f\udc46\udba9\udf18",
        3, 9132, -540725869, -835108284059711428L, -59171L, false, false, (char) 55110, (char) 60174,
        Double.longBitsToDouble(0x3fc686a76076fdb8L), Double.longBitsToDouble(0x3fea24f1f16911fdL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.LinkedList:[]\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 26, 9, 6, "\ud891\ude57\udb12\udee1\udb8d\udff5\ud876\udc31\ud8ce\ude45\udbaa\udf2f\ud985\udf2b", "\u0391\u42d4\ud0b4\u0ff0\u9ba5\u8997\ud403\uac89\ud035\u972f\u28c9\u1d5e\u8a73\u0d65\ua4e1\u8d3f\ucce2\u6f8d\u66c6\u4069\u909f\u8362\u0e92\u28be\u85b1", "\ud841\udf4f\udad7\udf0d\ud9f3\udf27\udaf0\ude00\ud97f\udc6b\udba9\udf18",
        50, 6159, 1713651289, 3401960985289442047L, -59171L, false, false, (char) 34813, (char) 62676,
        Double.longBitsToDouble(0x3f94594fb90cf360L), Double.longBitsToDouble(0x3fd9beb9685b0a04L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 30, 8, 16, "\ud95f\ude5c\ud95c\udee6\udb8d\udff5\udbd2\udd24\ud8b2\uddf2\uda72\udc35\uda46\udf6a\ud8b5\udd1c\udb8d\udd11\ud9aa\udf43\udac5\udfbf", "\u16f1\u5793", "\uda02\uddce\ud98c\ude7a",
        58, 40792, 399755210, 7827626935451005433L, 72281L, true, true, (char) 39831, (char) 41664,
        Double.longBitsToDouble(0x3fef7c4dc0c6d276L), Double.longBitsToDouble(0x3fee1097c8202f82L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 17, 17, 31, "\ud891\udeaa\ufa17\000\ud958\udf01", "\u85a0\u375a\u94d1\ucaa5\uc1df\uc600\u32ce\u4922\u357c\u158c\u00f0\u42b9", "\udb25\udfac\ud9c2\udd31\ud9a1\udea5\uda4f\ude17\ud8bd\udfd7\ud9fa\udf57\ud89c\udecd\udb85\udf9c\ud802\udcca\u6f2b\ud803\ude21\uda0d\ude41\udbaa\uddbf\ud8ba\udde9\uda13\udc6c\udb29\udebf\uda9c\udf60",
        4, 39148, -343648662, -9015660946580720387L, -98528L, true, false, (char) 42901, (char) 20910,
        Double.longBitsToDouble(0x3fcef24fde098d20L), Double.longBitsToDouble(0x3febfb7bf0d32746L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 30, 13, 32, "\ud891\ude57\ud95c\udee6\udb8d\udff5\ud9ea\uded0\ud8ab\udc9e", "\u82c7\u09a4\u0391\u42d4\u1223\ub63e\u16f1\u5793\u4b3a\ub33a\ub9dd\u972f\u83ca\u974c\u6c07\ua9f9\u369f\u9cc1\u812d", "\ud899\ude5f\ud953\udd13",
        55, 88227, -1821146219, 5360776372679336226L, 22541L, true, true, (char) 18636, (char) 35508,
        Double.longBitsToDouble(0x3fb27f3cd3fa1da0L), Double.longBitsToDouble(0x3fd7dc6538768c54L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 23, 23, 28, "\ud948\udf3d\ud82e\udd84\udaa1\ude9e\udb5b\udfc9\udbd0\uddda", "\u31f7\u5e5f\u386f\ub4ad\u4450\u4f03", "\udae5\udc61\uda6a\udc31\ud9fc\udf76\udbfe\udccb\u21d2\udb23\udc54\ud8de\udd27\udb63\udfa0\ud87d\udfe2",
        14, 71463, -1489959085, -289829824222550178L, 43485L, false, false, (char) 43808, (char) 9872,
        Double.longBitsToDouble(0x3fd54106b2a5d212L), Double.longBitsToDouble(0x3fde91b560cb5b66L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 15, 31, 13, "\ud891\ude57", "\u0825\u6dd0\uc3bb\u932e\u5dc9\u3df8", "\ud961\uddaf\udaae\udca7\ud934\udd7f\u8b13",
        41, 7728, -1572984579, -1746099333847432694L, -100000L, false, true, (char) 6393, (char) 0,
        Double.longBitsToDouble(0x3fe8000003720036L), Double.longBitsToDouble(0x3fd2998fe4b42720L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 16, 0, 30, "\ud9db\udd55", "\ub025\u3363\ua036\u9295\u5dc9\u3df8\u0391\ud693\u6415\u70b7\u7b15\ub309\uafab\ua733\ub9dd\u972f\u83ca\u2eb5\u3662\ud13a\uacf9", "\ud89a\udfcd",
        40, 22928, 1730177843, 5763885747163888851L, -24432L, false, true, (char) 62949, (char) 33476,
        Double.longBitsToDouble(0x3fe8698d85dadedfL), Double.longBitsToDouble(0x3fe0d7d9e1ad14a1L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.util.LinkedList:[]\0121=java.util.LinkedList:[]\012",
        Z.run(T, 2, 26, 11, 16, "\udaf6\udecb\ud90d\udc3e\ud824\udead\ud935\udeba\ud8ce\ude45", "\u75f0\u3df8\u0391\u42d4\u1223\ub63e\u16f1\u5793\ubaa2\u3731\u6fe6\u7013\u5223\u6f00\u395b\u2764\u369f\u79cb\u3b21", "\ud96f\uddd4\ud9de\ude8b\ud989\udd51",
        -3, 84730, -580563531, 6186596547483970409L, -35373L, true, false, (char) 10696, (char) 37029,
        Double.longBitsToDouble(0x3fd1b4af6e77a5d6L), Double.longBitsToDouble(0x3feae3215593d6a2L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.util.LinkedList:[]\0121=java.util.LinkedList:[]\012",
        Z.run(T, 2, 27, 11, 3, "\udb26\udca6\ud95c\udee6\ud9dd\udf3d\ud935\ude28\ud8ce\ude45\uda72\udc35\udb18\udf73\ud8f4\udd1c\udba6\udebd\ud9aa\udf43", "\ub63e\u16f1\u5793\u4714\u480b\u474f\u9743\u83ca\u091c\u395b\u2764", "\udb93\udda3\udb95\udcdc\udb7a\udc74\uda28\udf2d\udace\ude03\ud989\udd51",
        -3, 84781, -580563531, 6186596548051643241L, -35373L, true, false, (char) 27225, (char) 19278,
        Double.longBitsToDouble(0x3fd1b4af6e84c646L), Double.longBitsToDouble(0x3feae3c15593d6a2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.util.LinkedList:[]\012",
        Z.run(T, 2, 25, 6, 24, "\ud899\udf77\ud95c\udee6\ud8f5\udd69\ud935\ude28\ud8ce\ude45\uda72\udc35\udb18\udf73\ud879\udd1e\udb8d\udd11\ud9aa\udf43", "\ub63e\u16f1\u5793\u4714\u2002\u2ae7\u972f\u83ca\u6f00\u395b\u2764", "\udb93\udda3\ud8f4\udeab\ud91c\udd12\ud96f\uddd4\udace\ude03\ud989\udd51",
        -3, 84781, -580563531, 6186596548051643241L, -35373L, true, false, (char) 53959, (char) 19323,
        Double.longBitsToDouble(0x3fd1b4af6e77a5d6L), Double.longBitsToDouble(0x3feae3c15593d6a2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.util.LinkedList:[]\0121=java.util.LinkedList:[]\012",
        Z.run(T, 2, 5, 6, 24, "\uda28\udc83\ud95c\udee6\ud8f5\udd69\ud935\ude28\udbdd\udce1\udb68\uddea\ud94a\udd5b\ud88e\udcf1\ud9f9\udf32\ud9aa\udf43", "\ub63e\u16f1\u5793\u4714\u2002\u6fe6\u972f\u5a03\u1ae6\ud119\u2764", "\udb93\udda3\ud8f4\udeab\ud9ee\udfbc\ud979\udd8d\ud990\udcca\ud9cd\uddc6",
        39, 84781, -580563531, 6186596548051643241L, -19671L, true, false, (char) 15139, (char) 46315,
        Double.longBitsToDouble(0x3fd1b4ad4e77a5d6L), Double.longBitsToDouble(0x3feae3c15593d6a2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.lang.Character:\000\012",
        Z.run(T, 2, 30, 4, 16, "\ud95f\ude5c\ud95c\udee6\udb8d\udff5\udbd2\udd24\ud8b2\uddf2\uda72\udc35\uda46\udf6a\ud8b5\udd1c\udb8d\udd11\ud9aa\udf43\udac5\udfbf", "\u16f1\u5793", "\uda02\uddce\ud98c\ude7a",
        58, 40792, 399755210, 7827626935451005433L, 72281L, true, true, (char) 39831, (char) 41664,
        Double.longBitsToDouble(0x3fef7c4dc0c6d276L), Double.longBitsToDouble(0x3fee1097c8202f82L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 17, 17, 31, "\ud891\udeaa\ufa17\000\ud958\udf01", "\u85a0\u375a\u94d1\ucaa5\uc1df\uc600\u32ce\u4922\u357c\u158c\u00f0\u42b9", "\udb25\udfac\ud9c2\udd31\ud9a1\udea5\uda4f\ude17\ud8bd\udfd7\ud9fa\udf57\ud89c\udee4\udb85\udf9c\ud802\udcca\u6f2b\ud803\ude21\uda0d\ude41\udbaa\uddbf\ud8ba\udde9",
        -2, 87051, 1209560865, -7930085797719927228L, 35133L, true, false, (char) 3686, (char) 35223,
        Double.longBitsToDouble(0x3fc7f1eef4336a24L), Double.longBitsToDouble(0x3fad02ba0f7927e0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 25, 25, 33, "\ud899\udf77\ud920\udce6\ud8f5\udd69\udb70\udf74\ud8d5\udd36\ud88a\udfe2\udbe7\udeea\uda43\udf0a\udb08\udd1a\ud859\udec4", "\ub63e", "\ud89d\udf97\udbc7\udc8e\udb35\udcb8\ud975\udec2\udbdb\udd4e\ud8c6\udce5\ud8dc\udd50\udacb\udfba\ud87d\udfd1\ud8bd\udff3\udb93\udda3\ud8f4\udeab\udb59\udc68\ud96f\uddb2\udbed\ude5f\ud989\udd51\ud91a\ude08\ud955\udd2f",
        19, 67256, 1330031465, 8814850809161841779L, -27915L, false, false, (char) 54133, (char) 10791,
        Double.longBitsToDouble(0x3fed9559564ed6a2L), Double.longBitsToDouble(0x3fd4eb239993aca2L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.util.LinkedList:[]\0121=java.util.LinkedList:[]\012",
        Z.run(T, 2, 6, 6, 24, "\uda28\udc83\ud95c\udee6\udb48\udf4c\u9881\udbdd\udce1\uda95\ude61\ud94a\udd5b\ud88e\udcf1\ud9f9\udf32\ud9aa\udf43", "\ub63e\u16f1\u5793\u4714\u2002\u6fe6\u972f\u5a03\u1ae6\ud119\u612a", "\udb93\udda3\ud8f4\udeab\ud9ee\udfbc\ud979\udd8d\ud990\udcca\ud9cd\uddc6",
        39, 84781, -580563531, 6186596277468703593L, -19671L, true, false, (char) 20086, (char) 42469,
        Double.longBitsToDouble(0x3fd1b4ad4e77a5d6L), Double.longBitsToDouble(0x3f965e5cad155f00L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 29, 4, 21, "\ud891\ude57\ud897\udd83\ud9ae\udfe5\ud8ad\ude9b\ud899\ude73\uf8c9\uda46\udf6a", "\ua01b\u1d74\uc312\ub63e\u16f1\u5793\uafab\ua733\ub9dd\u972f\u83ca\u974c\u2bbc\u0cc0\u369f\u41cc\uc8cf\u32e3\u848a\u8d2a\u588a\u08ce\uab87\uc2ed\u85e1", "\ud841\udf4f\udad7\udf0d\ud825\udcff\udbef\udf71\ud97f\udc46\udba9\udf18",
        3, 9132, -540725869, -835108284059711428L, -68176L, false, false, (char) 37638, (char) 54851,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3fd9beb96381043aL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Float:0.0\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 8, 8, 31, "\udb8a\udc03\udb97\udc7c\udb73\udd47\udaed\ude06\udafc\ude33\uda72\udc35\uda46\udf6a", "\u0391\u42d4\u94aa\ud4c3\u4918\u56e3\uafab\ua733\ub9dd\u7f7b\u2b68\u974c\uc2ae\ua9f9\u369f\u79cb\u9405\u32e3\u3bb5\u9b2e\u3075\u08e8\uac14\uc2ed\u85e1", "\udbc8\udccb\udad7\ude63\ud835\udce7\udbef\udf74\udbc9\ude10\udba9\udf18",
        3, 95108, -1461276219, -835108060721412036L, -59171L, false, false, (char) 34876, (char) 54736,
        Double.longBitsToDouble(0x3f94594fb90e06c0L), Double.longBitsToDouble(0x3feabf5cb1c082eaL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.util.HashSet:[]\0121=java.util.HashSet:[]\012",
        Z.run(T, 2, 32, 32, 26, "\udbc4\udf66\ud95c\udee6\udb6e\udc04\udac8\ude5d\ud8b0\udf87\uda72\udc35\udb18\udf73\ud96d\udea5\ud904\udf14\ud9aa\udf43", "\u8c76\u2d49\u5793\u4714\u2002\u4459\u19ba\u83ca\u6f00\u395b\u2764", "\udb93\udda3\ud8f4\udf48\ud9e3\udd5e\ud8a2\udd77\udb64\udf7a\ud989\udd51",
        -3, 84781, -580560971, 6186596548051643241L, -35373L, true, false, (char) 53959, (char) 31611,
        Double.longBitsToDouble(0x3fd1b4ad5e77a5d6L), Double.longBitsToDouble(0x3feae3c15451d6a2L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 18, 2, "\ud899\udf77", "\ubdf6\ud4de", "\ud879\udd1e\ud9cd\udd11\ud9aa\udf43\udac5\udfbf\ud961\uddaf\udaae\udca7\ud934\udd7f\u8b13\ud89d\udebd\udbc7\udc8e\ud9f8\udf09\ud97e\udd8a\udbee\udf4e\ud9f2\udcbc\udb98\ude09\ud8dd\udf14\udaa8\udc43\ud8bd\udff3\udb93\udda3",
        25, 86735, -1995713321, -4911353481072904068L, -68192L, true, false, (char) 55676, (char) 324,
        Double.longBitsToDouble(0x3fc8e9e8d1cde950L), Double.longBitsToDouble(0x3fe24b1107e5ade2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Byte:0\0121=java.lang.Byte:0\012",
        Z.run(T, 2, 3, 19, 3, "\uda78\udf0f\udbb6\udfaf\u4036\udb9b\udf0d\uda6e\udc60\udb87\udc60\uda46\udf6a\udb41\udd22\udb5f\ude1d\ud9aa\udf43\udae3\udfbd", "\u03fe\u575b", "\udb39\udeee\ud8f7\udc4c\udbdb\udd71\ud9e5\udc3a\ud9c2\udd31\udb63\udfa0",
        8, 8900, -941324404, -1106470082366291093L, 39061L, false, false, (char) 31022, (char) 1,
        Double.longBitsToDouble(0x3fdc308599e2ac52L), Double.longBitsToDouble(0x3fe817260c5c9286L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 30, 30, 27, "\ud256\udb3f\udcc9\udb8d\udff5\ud9ea\uded0", "\u9295\u6f84\u9dbe", "\ud9de\uddb1",
        59, 43103, 2080420793, 3294072017149332665L, -73712L, false, false, (char) 11989, (char) 6593,
        Double.longBitsToDouble(0x3fd1ca9a478f56a8L), Double.longBitsToDouble(0x3fea9b84714fb8c2L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Short:0\0121=java.lang.Short:0\012",
        Z.run(T, 2, 34, 34, 30, "\ud9db\udd55", "\ub025\u3363\ua036\u9295\u5dc9\u3df8\u0391\ud693\u6415\u2a96\u289e\u3815\u9256\ua733\ub9dd\u972f\u83ca\u2eb5\u3662\ud13a\uacf9", "\ud89a\udfcd",
        40, 22928, 1730177843, 5763885747163888851L, -24432L, false, true, (char) 62949, (char) 33476,
        Double.longBitsToDouble(0x3fe8698d85dadedfL), Double.longBitsToDouble(0x3fe0d7d9e1ad14a1L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 28, 12, 17, "\ud256\udb21\ude3b\udb5d\udd51\udab6\udd42\u7d5c\uda92\ude5c\uda46\udf6a\ud826\udf35", "\u0bf7\uc85f\u6914\u1668\u06b1\u4b3a\u5279\ub9dd\u972f\u5294\u06ec\ubab1\u5852", "\ud80a\ude69\udbe7\udf71\udae2\udcc4\ud9ad\udd86\udab1\udc9f\u61b5",
        45, 45878, -1670560643, 7240117652955684399L, -17181L, true, false, (char) 11172, (char) 54868,
        Double.longBitsToDouble(0x3fe18e9d081266d9L), Double.longBitsToDouble(0x3fe60b9165e0ccd1L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Character:\000\0121=java.lang.Character:\000\012",
        Z.run(T, 2, 4, 4, 33, "\ud899\udf77\ud95c\udee6\ud8f5\udd69\ud935\ude28\udac1\ude7f\u84c0\ud953\udf4c", "\ucd08\u42d4\u60a1\u0f99\u79d6\u5793\u4714\ubf1d\u6fe6\u972f\u83ca\u6f00\u3923\u2764\u369f\u79cb\u56c2\u1298\u848a\u4a09\u1bc3\u08ce\u8493\uca5f\u1dcc\uc2af\u5152\u9518\u78c0\u68f6\u7147", "\udb81\ude4f\uda67\udc0e\ud9e4\ude49\udb29\ude2d\uda26\udd61\ud94b\udccd\ud81f\udf50\ud9bf\udc82\ud8b3\ude5f\udaf6\udece\uda75\ude77\ud916\udeb5\udae7\udf21",
        16, 81857, 19667617, -6910018406648876867L, -35719L, true, true, (char) 21902, (char) 44672,
        Double.longBitsToDouble(0x3fcf56466791d17cL), Double.longBitsToDouble(0x3fe8fab85572ac4bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.Matchers|any||static",
    "M|org.mockito.Matchers|any|java.lang.Class|static",
    "M|org.mockito.Matchers|anyBoolean||static",
    "M|org.mockito.Matchers|anyByte||static",
    "M|org.mockito.Matchers|anyChar||static",
    "M|org.mockito.Matchers|anyCollection||static",
    "M|org.mockito.Matchers|anyCollectionOf|java.lang.Class|static",
    "M|org.mockito.Matchers|anyDouble||static",
    "M|org.mockito.Matchers|anyFloat||static",
    "M|org.mockito.Matchers|anyInt||static",
    "M|org.mockito.Matchers|anyList||static",
    "M|org.mockito.Matchers|anyListOf|java.lang.Class|static",
    "M|org.mockito.Matchers|anyLong||static",
    "M|org.mockito.Matchers|anyMap||static",
    "M|org.mockito.Matchers|anyMapOf|java.lang.Class,java.lang.Class|static",
    "M|org.mockito.Matchers|anyObject||static",
    "M|org.mockito.Matchers|any||static",
    "M|org.mockito.Matchers|any|java.lang.Class|static",
    "M|org.mockito.Matchers|anyBoolean||static",
    "M|org.mockito.Matchers|anyByte||static",
    "M|org.mockito.Matchers|anyChar||static",
    "M|org.mockito.Matchers|anyCollection||static",
    "M|org.mockito.Matchers|anyCollectionOf|java.lang.Class|static",
    "M|org.mockito.Matchers|anyDouble||static",
    "M|org.mockito.Matchers|anyFloat||static",
    "M|org.mockito.Matchers|anyInt||static",
    "M|org.mockito.Matchers|anyList||static",
    "M|org.mockito.Matchers|anyListOf|java.lang.Class|static",
    "M|org.mockito.Matchers|anyLong||static",
    "M|org.mockito.Matchers|anyMap||static",
    "M|org.mockito.Matchers|anyMapOf|java.lang.Class,java.lang.Class|static",
    "M|org.mockito.Matchers|anyObject||static",
    "M|org.mockito.Matchers|anySet||static",
    "M|org.mockito.Matchers|anySetOf|java.lang.Class|static",
    "M|org.mockito.Matchers|anyShort||static",
    "M|org.mockito.Matchers|anyString||static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
