package org.mockito.internal;
import org.junit.Test;
import static org.junit.Assert.*;
public class MockHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 1, 2, 0, "\ud938\udd45\ud91a\udfdc", "\u494b\u0d0b\uaf86\ubb9a", "\ud85a\uddda\udbad\udcc4\uda8c\udc45\u683b\ud8b4\udc0d\udadc\udd82\u87bc\uda48\udc7b\udbc2\udf52\ud8b3\udd92\ud967\udc2e",
        24, 26499, -1233804885, -1797557063713114404L, 84206L, true, true, (char) 29847, (char) 14599,
        Double.longBitsToDouble(0x3fe9ae9226e1f345L), Double.longBitsToDouble(0x3fd9ce7b5c5b1884L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 7, 2, 0, "\ud938\udd45\ud91a\udfdc\uda0a\ude9b\u4728\uda54\udec0\ud9b7\udeca\ud9c7\udd17\ud8ad\ude9d\ud811\udd1b\ud90b\udcde", "\u9a2f\u042a", "\ud85b\udd77\uda48\udc7b\udbc2\udf52\ud8b3\udd92\ud967\udc2e",
        24, 89640, -1233804813, 5558248487149287085L, 84206L, true, true, (char) 30934, (char) 14706,
        Double.longBitsToDouble(0x3fe9ae9226e1f345L), Double.longBitsToDouble(0x3fd39e0b5c5b1884L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 1, 2, 0, "\ud938\udd45\ud97d\ude93\uda1a\udf93\u4728\uda0e\udf38\ud86d\udedf\uda4a\udfc7\uda40\ude4c", "\u9842\u1e62\uaa22\uc62a\ua314\u25ca\u789d\u6abf\u199f\ud1df\ua9fd\u7873\ud2c4", "\ud8db\udeb2\ud87a\ude43\udba0\ude1d\udb88\uddc7\udaef\udcd3\udac6\udcfb\ud938\udfba\ud81c\udc5d\udb79\udfc9\ue328\ud82d\uded4\u3e28\ud9fb\udf1e\udb7d\udf71\uda46\udc4c\ud8dc\udcba\udac7\ude60",
        28, 9111, 502613998, 6016058076821156158L, 70739L, false, true, (char) 16812, (char) 34675,
        Double.longBitsToDouble(0x3fc9f95d55b55924L), Double.longBitsToDouble(0x3fc47cb89a75d1e8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 1, 2, 0, "\ud9ad\ude79\ud821\udf97", "\u494b\u2335", "\ud811\udd1b\ud90b\udcde\ud85a\uddda\udbad\udcc4",
        40, 88491, -2019611951, 7896988252247557296L, -6327L, true, false, (char) 56672, (char) 33072,
        Double.longBitsToDouble(0x3feb05b3aedce70dL), Double.longBitsToDouble(0x3fdcfd9e29f25340L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 3, 4, 7, "\udb3a\udd9d\ud91a\udef9\ud84c\udd1d\udaef\udf4e\uda1f\udd95\uda7f\udef7\ud9c7\uddff\ud8ad\udf4f\ud811\udd1b\ud917\uddc4", "\ud1fd\ud1ff\ua314\u25ca\ub08f\uc5bf\u199f\ud1df\u8d59\ubbb2\u6c84\u6957\u05cf\u0bb8\u9cea\ubb68\ua73f\u15ba\ub1f7\u181f\u2217\u506e\u1a95\u6d93", "\uda29\udc9d\ud9cc\udedc\udaed\udf0b\uda6b\udcf5\ud9c8\udd8c\udabf\udebc\udb9c\udf0e\udb46\ude90",
        36, 62488, -238141420, 3275933848967417072L, -61499L, true, false, (char) 57805, (char) 39144,
        Double.longBitsToDouble(0x3fe9a9de6491bbd6L), Double.longBitsToDouble(0x3fef026a16d4ded8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 0, "\ud938\udd45\ud91a\udfdc", "\u494b\u0d0b\uaf86\ubb9a", "\ud85a\uddda\udaba\ude2c\uda8c\udc45\u683b\ud8b4\udc0d\udadc\udd82\u87bc\udb18\udce4\udbc2\udfa9\ud9e9\udd8d\uda9c\udd69",
        28, 45581, -1523425925, 3828110358166942325L, 84206L, true, true, (char) 29847, (char) 14599,
        Double.longBitsToDouble(0x3fe9ae9226e1f345L), Double.longBitsToDouble(0x3fd9ce7b5c5b1884L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 3, "\ud938\udd45\ud91a\udfdc", "\u494b\u0d0b\uaf86\ubb9a", "\ud92d\udc5c\ud9d5\ude08\ud9c8\ude32\ufc78\ud8b4\udc0d\udac6\udc82\u87bc\uda48\udc7b\udbc2\udf52\ud8b3\udd92\ud967\udc2e",
        24, 26499, -1354522197, 3031140092964480220L, 84206L, true, true, (char) 8343, (char) 49324,
        Double.longBitsToDouble(0x3fc30b4242cbf774L), Double.longBitsToDouble(0x3fdf3d4dac5b1884L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 4, 2, 2, "\ud808\udfd8\ud96b\udf66\uda20\udf0c\uda1b\udd4c\uda35\udd50\ud84a\udf51\udb87\udf50\ud8ad\udf4f\uc561\ud90b\udcde\udbb0\udcd8\udbad\udc99\uda8c\udc45\u683b\ud8b4\udc0d\ud8a1\udce6\udbdb\udcb0", "\u6f34\ub970\ua902\u777d\uba9e", "\ud814\udf0f\uda49\uddd0\ud831\udd03\uda58\udfc0\ud9f8\udea2\udbe5\ude74\ud9e7\uddb9\udb5c\udedc\ud913\uddfc\u8296\udb63\udd39\ud91b\udef1\udbae\udfa7\udac6\udf02",
        25, 7534, 799564992, -2627808671667399821L, 7236L, false, false, (char) 20578, (char) 59337,
        Double.longBitsToDouble(0x3fdbce781d74c868L), Double.longBitsToDouble(0x3fd9610dc8d71192L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 4, 2, 0, "\ud938\udd45\ud91a\udfdc", "\u494b\ub84d\uaf85\ubb9a", "\ud85a\uddda\udbad\udcc4\ud95a\udc4c\u683b\ud8b4\udc0d\udadc\udd82\u87bc\ud937\udef3\udbad\udc4c\ud8b3\udd92\ud967\udc2e",
        24, 26499, -1233804885, -1797557063713114404L, 84206L, true, true, (char) 29847, (char) 14599,
        Double.longBitsToDouble(0x3fe59ee4e13f378dL), Double.longBitsToDouble(0x3f7b661f16c62300L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 6, 6, 0, "\ud938\udd45\ud91a\udfdc", "\u48b3\u0d0b\uaf86\u2be7", "\ud85a\uddda\udbad\udcc4\uda0c\udd24\ud8af\udf44\ud85b\ude0f\ud8ad\udc07\u8853\uda48\udc52",
        49, 21382, -663985518, -3625290781657531565L, 75665L, false, false, (char) 48262, (char) 29847,
        Double.longBitsToDouble(0x3fa6046df35d2440L), Double.longBitsToDouble(0x3fe70f9a299ce7b5L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\ud938\udd45\ud91a\udfdc", "\u494b\u0d0b\uaf86\ubb9a", "\ud85a\uddda\udbad\udcc4\uda8c\udc45\u683b\ud8b4\udc0d\udadc\udd82\u87bc\uda48\udc7b\udbc2\udf52\ud8b3\udd92\ud967\udc2e",
        24, 26499, -1233804885, -1797557063713114404L, 84206L, true, true, (char) 29847, (char) 14599,
        Double.longBitsToDouble(0x3fe9ae9226e1f345L), Double.longBitsToDouble(0x3fd9ce7b50011884L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 0, "\ud938\udd45\ud91a\udfdc", "\u494b\u6fb6\u15cd\ubb9a", "\udb12\udf95\udbbd\ude59\uda8c\udc45\u683b\ud8b4\udc0d\udadc\udd82\ud9f4\udfa3\uda48\udc7b\udbc2\udf52\ud8b3\udd92\ud967\udc2e",
        24, 26499, -1233804885, -1797557063713114404L, 84206L, true, true, (char) 29847, (char) 14599,
        Double.longBitsToDouble(0x3fe9ae9226e1f345L), Double.longBitsToDouble(0x3fd9ce7b5c5b1884L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 7, 2, 0, "\ud938\udd45\ud91a\udfdc\uda0a\ude9b\u4728\uda54\udec0\ud9b7\udeca\ud9c7\udd17\ud8ad\ude9d\ud811\udd1b\ud90b\udcde\ud85a\udd5e\ud908\udc51\ud88a\udce7\uda00\udd9a\uda86\uded6\udaed\ude9d\uda0c\udff9\uda48\udc70\udbc2\udf52\ud8b3\udd92\ud967\udc2e\udbfb\udd18\uf0e2\ud9fd\udd9d\udad0\ude18\udaa0\udf85\ud814\udf0f", "\u15ba\ub262\ubdef\ud513\u500b\u36b8\u3d7a\u924b\u273e\u03ba\u6b1b", "\ud8a6\ude4c\ud886\udc9c\ud85a\udecd\ud893\udc29\ud808\udda4",
        51, 94794, -2111217423, -3678835681466962490L, -21228L, false, false, (char) 37091, (char) 1813,
        Double.longBitsToDouble(0x3fed03359d490d6fL), Double.longBitsToDouble(0x3fce32aeefae9ffcL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 7, 1, 0, "\ud938\udda2\ud920\udf1e\uda0a\ude9b\ud94d\ude29\uda54\udec0\ud9b7\udeca\udba8\udfcd\ud8ad\ude9d\ud811\udd1b", "\u32ee\u9a2f\uca16\u0604", "\uda48\udc7b",
        49, 8822, -492212759, -3625212914701394536L, -25645L, true, false, (char) 11186, (char) 48617,
        Double.longBitsToDouble(0x3fd29d35d677217aL), Double.longBitsToDouble(0x3fc2e11b60d74910L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 7, 4, 0, "\ud947\udf88\ud91a\udfed\udb8a\uded1\uda14\udd5d\udb39\udfea\ud9b7\uddc5\ud9c7\udd17\ud8ad\ude9d\ud9ec\ude9b\ud90b\udcde", "\u1bf4\u84d8\u347b\u6b9a\u97f3\u6abf\u199f\ud1df\ub272\u7fb4", "\udad0\uddd6",
        27, 64607, 853764309, 6590791536864093396L, 57899L, true, false, (char) 59886, (char) 23151,
        Double.longBitsToDouble(0x3febe9ead9793accL), Double.longBitsToDouble(0x3fbe3b559e231640L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\0121=new org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 3, 7, 2, "\ud938\ude24\ud91a\udfdc\uda0a\ude9b\ud9de\udc0d\ud970\udc1d\uda34\udc02\udbde\ude49\ud9c2\udce4\ud812\udd68\udaa5\udf39", "\u9a2f\u042a\u0611\u6b9a\uad26\u6abf\u28da\u2e6e", "\ud80c\ude8a\ud9fd\udcfb\udad0\ude18\udbef\udc6d\ud814\udf0f",
        -5, 82673, 148583227, -3295455602443708619L, 28711L, true, false, (char) 45676, (char) 23739,
        Double.longBitsToDouble(0x3fe94917c951913aL), Double.longBitsToDouble(0x3fcd760f8da39a18L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\uda3b\ude07\000\000\uda28\udd92\ud82d\udcd5\ud86d\udedf\uda4a\udfc7\uda40\ude4c", "\u9842\016\u7cc5\uc62a\ua314\000\uab8d\uab0a\000\ud139\ua9fd\u7873\u0c2d", "",
        38, 43322, 3791, 7569706550770070908L, 31072L, true, false, (char) 115, (char) 18656,
        Double.longBitsToDouble(0x3fc0b1bfc0000000L), Double.longBitsToDouble(0x3fc410c00696da60L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud9e7\udcb8\ud97d\ude93\uda1a\udf93\ud80b\udca3\ud997\udda1\udaed\udfe0\uda4a\udfc7\ud8ea\udd01", "\u958c\u77cc", "\udbbe\udc12\udadc\udd82",
        33, 65017, -1693734586, 8464619568697507049L, 17600L, false, false, (char) 21870, (char) 12770,
        Double.longBitsToDouble(0x3fecbd831db985e1L), Double.longBitsToDouble(0x3fe6cbe4c796e05dL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=void |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 6, 3, 0, "\uda8c\udd04\ud8da\udf65\uda1a\udf93\u4728\uda0e\udf38\ud86d\udedf\uda4a\udfc7\udb47\ude46\udb42\ude27", "\uba54\uaa22\uc62a\u5285\u5c45\u295d\u606e", "\ud979\udc25\udbcb\udcbb\ud889\udc45\ud88d\udcbf\ud83d\ude1a\ud8db\udeb2\ud87a\ude43\udba0\ude1d\udb88\uddc7\udaef\udcd3\udb05\udc87\ud938\udfba\ud81c\udc5d\udb79\udfc9",
        14, 1834, -381724018, 5300667910193183L, 45857L, true, true, (char) 23613, (char) 29415,
        Double.longBitsToDouble(0x3fd3e537d4af2416L), Double.longBitsToDouble(0x3fed2e8b3d087b5aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 0, "\ud938\udd45\ud97d\ude93\uda1a\udf93\u4728\uda0e\udf38\ud86d\udedf\uda4a\udfc7\uda40\ude4c", "\u9842\u1e62\uaa22\uc62a\ua314\u25ca\u789d\u6abf\u199f\ud1df\ua9fd\u7873\u36c4\u44fe", "\ud87a\ude43\udba0\ude1d\udb88\uddc7\udaef\udcd3\udac6\udcfb\ud938\udfba\ud81c\udc5d\udb79\udfc9\ue328\ud9bf\udcde\ud8ee\uddcf\ud9fb\udf90\udb7d\udf71\ud90f\ude79",
        20, 14930, -619562742, 1463656612244047854L, 7538L, true, true, (char) 15408, (char) 13261,
        Double.longBitsToDouble(0x3fc6211002217bacL), Double.longBitsToDouble(0x3fc9f95d55b55924L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 3, 4, 5, "\udb3a\udd9d\ud91a\udef9", "\u8b04", "\ud8ad\udf4f\ud811\udd1b\ud917\uddc4\u5fa5\ud837\udc03\udbb7\udfee",
        19, 77324, 1851286274, -3091216020164583295L, -32374L, true, false, (char) 61781, (char) 43348,
        Double.longBitsToDouble(0x3feee7386cea7601L), Double.longBitsToDouble(0x3fb40f30094e9ae8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\0121=void |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 3, 3, 0, "\udbd4\udd14\ud91d\udf56", "\ud34d\u0d0b\u1a7d\u2be3\ua96a\u114d\u7403", "\ud958\ude18",
        7, 66052, -1297742622, 7310541039159978310L, 15353L, true, true, (char) 54007, (char) 15680,
        Double.longBitsToDouble(0x3fdcfd9571557c42L), Double.longBitsToDouble(0x3fd29d35d7dd0eb8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=new org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 7, 6, 4, "\ud938\udda2", "\u6e71\uafd2\u1fdc\u3d4c\ubadd\u6fa2\u1839\ub98b\u0e71", "\uda51\udd5a\uda6a\ude7d\ue571\ud972\udf36\udbc2\udf52",
        45, 36793, -1006432918, -5759930828868705796L, 77837L, true, false, (char) 43866, (char) 57653,
        Double.longBitsToDouble(0x3fee7c85e89708dbL), Double.longBitsToDouble(0x3faae9220c4c1980L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "\000\ud91a\udfdc\uda0a\ude9b\u008b\ud950\udfc8\uda34\udc02\udbde\ude49\ud9c2\udce4\ud812\udd68\udaa5\udf39", "\u9a2f\u042a\u0611\u6b9a\uad26\uab0a\u28da\u00e0", "\ud80c\ude8a\ud9fd\udcfb\udad0\ude18",
        1, 64887, -748867470, 5015858972458693435L, 57899L, false, false, (char) 2304, (char) 23151,
        Double.longBitsToDouble(0x3fed60360ad7a9e4L), Double.longBitsToDouble(0x3fa4917c951913a0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 0, "\ud938\udd45\ud97d\ude93\uabbd\u4728\uda0e\udf38\ud86d\udedf\uda4a\udfc7\uda40\ude4c", "\ubfba\u1e62\uaa22\uc62a\036\u267f\u7887\u6abf\u199f\ud1df\ucce4\u4461\u5076\u44fe", "\ud87a\ude43\udba0\ude1d\udb88\uddc7\udaef\udcd3\udac6\udcfb\ud97c\uddfc\ud8a3\udd16\udb79\udfc0\ue328\ud9bf\udcde\ud8ee\uddcf\ud9fb\udf90\udb7d\udf71\ud90f\ude79",
        20, 14930, -1804257014, 1452187662289291246L, 7538L, true, true, (char) 15408, (char) 13261,
        Double.longBitsToDouble(0x3fc6211018d17bacL), Double.longBitsToDouble(0x3fc9f95d55b55924L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 4, 4, 7, "\000\ud91a\udfdc\uf4d5\uda66\uddf7\ud84f\udd6d\uda34\udc02\udbde\ude49\ud9c2\udce4\ud812\udd68\udaa5\udf39", "\u932f\u042a\u4592\u9b35\uad26\uab0a\u2e7b\u4fc6", "\udb0e\udf80\ud9fd\udcfb\udad0\ude18",
        1, 38967, 1003945722, 5015858972458693435L, 57899L, false, false, (char) 2304, (char) 17930,
        Double.longBitsToDouble(0x3fed60360b1362ffL), Double.longBitsToDouble(0x3fa4b55f951913a0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud926\udef2\uda9d\udc3c", "\u2c8b\u6969\ua7c2\u0a6d", "\ud818\udd9d\uda45\ude87",
        7, 96882, 929660004, -7605068510177632568L, -27226L, false, false, (char) 0, (char) 27483,
        Double.longBitsToDouble(0x3fe73e1b414fb5f7L), Double.longBitsToDouble(0x3fd8df3fdd5a9a44L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 1, 2, 0, "\udafd\udea9\u8080", "\u494b", "\ud8ad\udf4f\ud811\udd1b\ud90b\udcde\ud85a\uddda\udbad\udcc4",
        40, 59819, 521805368, 7951214001065952331L, 49372L, false, false, (char) 51459, (char) 33072,
        Double.longBitsToDouble(0x3feb05b3aedce70dL), Double.longBitsToDouble(0x3fdcfd9e20e51aeeL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.MockHandler|handle|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.MockHandler:",
    "M|org.mockito.internal.MockHandler|getInvocationContainer||new:org.mockito.internal.MockHandler:",
    "M|org.mockito.internal.MockHandler|getMockSettings||new:org.mockito.internal.MockHandler:",
    "M|org.mockito.internal.MockHandler|setAnswersForStubbing|java.util.List|new:org.mockito.internal.MockHandler:",
    "M|org.mockito.internal.MockHandler|voidMethodStubbable|java.lang.Object|new:org.mockito.internal.MockHandler:",
    "C|org.mockito.internal.MockHandler|<init>|org.mockito.internal.MockHandlerInterface",
    "C|org.mockito.internal.MockHandler|<init>|",
    "C|org.mockito.internal.MockHandler|<init>|org.mockito.internal.creation.MockSettingsImpl",
    "M|org.mockito.internal.MockHandler|handle|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.MockHandler:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
