package org.mockito.internal;
import org.junit.Test;
import static org.junit.Assert.*;
public class MockitoCore_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 8, 14, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud8e5\udd92\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\ubdaf", "\ud95b\udca2\uda09\ude03\udb92\udf46\ud85d\udce7\ud9f3\ude47\udb7f\udfa4\udb6d\udcdf\uda97\udc19\ud9a4\uddd6\ud963\ude0b\ud9be\ude17\ud8d9\udd29\ud9f6\udc26\uda65\udc95\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8a3\udf13\udb60\ude68\ud942\udf85\udb2e\udcdd\udb8d\ude96\ud867\uddf2",
        51, 54724, 398726830, -2080038684842622015L, -30085L, false, false, (char) 21204, (char) 57068,
        Double.longBitsToDouble(0x3fd42765bc1e9034L), Double.longBitsToDouble(0x3fbe483c9b83cff0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.UnfinishedStubbingException\012",
        Z.run(T, 2, 8, 20, 12, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud827\udcad\ud90b\udc59", "\u7cbb\u99b9\ub5a9\ua1b2\u16f1\u99c7", "\ud85d\udce7\udbd2\udcd5\ud8c0\udf07\udb6d\udc9f\uda97\udc19\ud9a4\uddd6\udbde\udf09\ud9e8\ude14\ud8d9\udd29\ud9f6\udc26\uda65\udc95\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34",
        57, 48927, 955098947, 2213107680711857217L, 2185L, false, false, (char) 5842, (char) 28151,
        Double.longBitsToDouble(0x3feeb0be220208dfL), Double.longBitsToDouble(0x3fc834efe6eb7fb8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 14, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\u1104\ud907\udfdb\ud8e5\udd92\ud90b\udc59\ud9b4\udda9\ud892\uddf1", "\ubdaf", "\ud95b\udca2\uda09\ude03\udb92\udf46\ud80c\uddbf\ud8ca\udf97\udb7f\udfa4\ud8b5\udf74\udb90\udd3c\ud82c\ude60\ud94c\udfe8\ud9be\ude17\udae6\udc2e\ud981\ude3c\uda65\udc95\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud826\udf42\ud8a3\udf13\udb60\ude68\ud942\udf85\udb2e\udcdd\udb8d\ude96\ud852\udcf2",
        51, 54724, 398726830, -2080038683943074879L, 84762L, false, true, (char) 60311, (char) 60656,
        Double.longBitsToDouble(0x3feb6013602c8e59L), Double.longBitsToDouble(0x3fd42765b0d7cc06L)));
  }
  @Test
  public void test3() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test3() throws Throwable {
//     assertEquals("0=$java.lang.Number$$EnhancerByMockitoWithCGLIB$$1d89b35:!toString:java.lang.NullPointerException\0121=!org.mockito.exceptions.base.MockitoException\012",
//         Z.run(T, 2, 5, 7, 10, "\udabb\uddbe\ud951\uddb5", "\u4ff2\u6df8", "\udbf3\udd46\udae8\udcf3\udbec\udf4e",
//         7, 88419, 1269765840, 3557159999517956249L, -48581L, false, false, (char) 2165, (char) 28837,
//         Double.longBitsToDouble(0x3fe7b5e7415ae3d1L), Double.longBitsToDouble(0x3fef217522139724L)));
//   }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d]] |this=org.mockito.internal.MockitoCore:@?\012",
        Z.run(T, 1, 7, 14, 17, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d", "\u720e\u4574\u7d45", "\udba8\udfdf",
        0, 14852, 1149180057, 56089785295567289L, -71442L, true, false, (char) 8511, (char) 8357,
        Double.longBitsToDouble(0x3fc4cef52dd66744L), Double.longBitsToDouble(0x3fde32be748206f4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 1, 14, 11, "\ud962\udd93\udb10\udf17\udb19\udf4a\udab4\udd6e\udb5f\udc1d\ud907\udfdb\ud8e5\udd92\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\ubdaf", "\ud95b\udca2\uda09\ude03\udbdd\udc04\ud875\uddd7\ud9f3\ude47\ud8d9\udc0f\ud86a\udf01\ud87b\udd98\ud9a4\uddd6\udac1\udcbb\ud8ed\udfec\ud8d9\udce2\ud9f6\udc26\uda65\udc95\ud936\udd0a\ud954\uddb9\ud9dd\udc85\ud164\ud93c\udd69\ud8a3\udf13\udb60\ude68\ud942\udf85\udb2e\udcdd\uda77\ude8b\ud875\udcd0",
        44, 54783, 398726830, -2080038684842622015L, -30085L, false, false, (char) 18633, (char) 584,
        Double.longBitsToDouble(0x3fd42765bc1e9034L), Double.longBitsToDouble(0x3fbe483c9b83cff0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 19, 13, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud9d8\udff9\uda1e\udde7\ud8e5\udd47\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\ube7b", "\ud95b\udca2\ud91d\udd51\udb92\udf22\ud85d\udce7\ud9f3\ude47\ud83f\udebc\udb6d\udcd5\uda97\udc19\ud9a4\uddd6\ud963\ude0b\ud9be\ude17\udafd\udeb3\ud9d2\udd84\uda64\udff3\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8a3\udf13\udb60\ude68\ud942\udf85\ud902\ude26\udb8d\ude96\ud867\uddf2",
        51, 54724, 398726830, -2080038684842622015L, 15737L, false, false, (char) 21204, (char) 57068,
        Double.longBitsToDouble(0x3fd42765bc1e9034L), Double.longBitsToDouble(0x3fbe483cbb83cff0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.UnfinishedStubbingException\012",
        Z.run(T, 2, 8, 16, 17, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud8e5\udd92\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\ubdaf", "\ud95b\udca2\uda09\ude03\udb92\udf46\ud85d\udce7\uda5a\ude27\udb27\ude7f\udb54\udf8e\uda97\udc19\ud9a4\uddd6\ud963\ude0b\ud9be\ude17\ud8d9\udd29\ud9f6\udc26\uda65\udc95\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8a3\udf13\udb60\ude68\ud942\udf85\udb2e\udcdd\udb8d\ude96\ud867\uddf2\uda7d\uded8\udb7e\udf68\uda14\udc14\ud9e7\ude22\ud929\ude84\udb60\udcc1\u1f63\ud89f\udd53\udb95\udcb2\uda48\udc2a",
        20, 51172, 1209704770, 2374098558513976441L, -80071L, false, false, (char) 60220, (char) 63277,
        Double.longBitsToDouble(0x3fdcb459cbcfae04L), Double.longBitsToDouble(0x3fb6edba4a289388L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 11, "\udabb\uddbe\ud951\uddb5\udb23\udd82\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud8e5\udd92\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\u992b", "\ud95b\udca2\uda09\ude03\udb92\udf46\ud85d\udce7\ud9f3\ude47\udb7f\udfa4\udb6d\udcdf\uda97\udc19\ud9a4\uddd6\ud963\ude0b\ud9be\ude17\ud8d9\udd29\ud8dc\udeb9\udab9\udde4\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8a3\udf13\udb60\ude68\ud942\udf85\udb2e\udcdd\udb8d\ude96\ud867\uddf2",
        51, 54724, 398726830, -2080038685664198023L, 86624L, false, false, (char) 21204, (char) 57068,
        Double.longBitsToDouble(0x3fd42765bc1e9034L), Double.longBitsToDouble(0x3fbe483c9b83cff0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 6, 3, 6, "\ud846\udd44\uda48\ude4b\ud9a6\udef4\uda1e\ude3d\ud91f\udc1d\ud907\udfdb\ud8e5\udd92\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\u01b1", "\ud95b\udc93\uda09\ude03\ud9f8\udc7a\ud9b1\udc84\ud9f3\ude47\udb7f\udfa4\udb6d\udcdf\uda97\udc19\ud9a4\uddd6\udbf1\ude99\ud9be\ude17\ud8d9\udd29\ud9f6\udc26\uda65\udc95",
        2, 46314, -1843280955, -358732712582240044L, 53842L, false, true, (char) 51517, (char) 63803,
        Double.longBitsToDouble(0x3fd2941bf5250b2aL), Double.longBitsToDouble(0x3fe2224476ae5749L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.UnfinishedStubbingException\012",
        Z.run(T, 2, 8, 5, 1, "\ud8d6\udf87\ud9ce\udedb\ud905\udf5b\ub818\udacc\udc60\ud907\udfdb\ud8e5\udd92\udbc1\udf59\uda33\ude11\uda4b\ude4d", "\u5a08", "\ud95b\udca2",
        48, 74117, 254855757, -6168476477596118464L, 66627L, true, true, (char) 17282, (char) 23398,
        Double.longBitsToDouble(0x3fe5abc8471b535eL), Double.longBitsToDouble(0x3fd5aaf3878aa5b0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\udabb\uddbe\ud951\uddb5\udb29\udd82\udbf5\udc2f\ud91f\udc1d\uda69\udcac\ud8e5\udda2\ud90b\udc59\uda33\ude11\uda4b\ude4d]] |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 7, 14, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udbf5\udc2f\ud91f\udc1d\uda69\udcac\ud8e5\udda2\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\ubdaf", "\ud95b\udca2\ud8c0\udfbe\udb92\udfcd\ud85d\udce7\ud9f3\ude47\udb7f\udfa4\udb6d\udcdf\uda97\udc19\ud9a4\uddd6\ud963\ude0b\ud9be\ude17\ud8d9\udd29\ud9f6\udc26\uda65\udc95\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\udb72\udfe7\ud8a3\udf13\udb60\ude68\ud942\udf85\udb2e\udcdd\udb8d\ude96\ud877\ude29",
        -1, 54724, 398726830, -2080038684842622015L, 75183L, true, false, (char) 60311, (char) 55024,
        Double.longBitsToDouble(0x3fba809b01660bb8L), Double.longBitsToDouble(0x3fd42765bc1e9034L)));
  }
  @Test
  public void test12() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test12() throws Throwable {
//     assertEquals("0=void |this=org.mockito.internal.MockitoCore:@?\0121=$java.util.ArrayList$$EnhancerByMockitoWithCGLIB$$8b3b4d9f:!toString:java.lang.NullPointerException\012",
//         Z.run(T, 2, 15, 4, 15, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud9f5\udf1a\ud84c\udeec\ud816\udee0\ud982\udc51", "\ubdaf", "\ud982\ude7b\uda09\ude03\udb92\udf46\ud85d\udce7\ud9f3\ude47\udb7f\udfa4\udb6d\udcdf\uda97\udc19\ud9a4\uddd6\ud963\ude0b\ud9e2\udd32\ud8d9\udd29\ud9f6\udc26\uda65\udc95\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8a3\udf13\udb60\ude68\ud942\udf85\udb2e\udcdd\udb8d\ude96\ud867\uddf6",
//         51, 54724, 398726830, -2080038684842622015L, -30085L, false, false, (char) 21204, (char) 57068,
//         Double.longBitsToDouble(0x3fd42765bc1e9034L), Double.longBitsToDouble(0x3fbe483c9b83cff0L)));
//   }
  @Test
  public void test13() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test13() throws Throwable {
//     assertEquals("0=$java.util.ArrayList$$EnhancerByMockitoWithCGLIB$$8b3b4d9f:!toString:java.lang.NullPointerException\0121=$java.util.ArrayList$$EnhancerByMockitoWithCGLIB$$8b3b4d9f:!toString:java.lang.NullPointerException\012",
//         Z.run(T, 2, 20, 20, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud8e5\udd92\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\ubdaf", "\ud95b\udca2\uda09\ude03\udb92\udf46\ud85d\udce7\ud9f3\ude47\udb7f\udfa4\udb6d\udcdf\uda97\udc19\ud9a4\uddd6\ud963\ude0b\u00e3\ud8d0\udee8\ud9f6\udc26\uda65\udc95\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8a3\udf13\udb60\ude68\ud942\udf85\udb2e\udcdd\udb8d\ude96\ud867\uddf2",
//         51, 51804, 0, -2080100077105151039L, -30085L, false, false, (char) 21204, (char) 57068,
//         Double.longBitsToDouble(0x3fd42765bc1e9034L), Double.longBitsToDouble(0x3fbe483c9b83cff0L)));
//   }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 10, 1, 11, "\uda3a\udf25\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud8e5\udd92\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\ubdaf", "\ud95b\udca2\uda09\ude03\udb92\udf46\ud85d\udce7\ud9f3\ude47\udb7f\udfa4\udb6d\udcdf\uda91\udc21\ud9a4\uddd6\ud963\ude0b\ud9be\ude17\udbb6\udf01\uda00\udffb\uda65\udc95\ud981\udd0f\udb59\ude0e\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8a3\udf13\uda83\udedd\udb95\ude61\udb2e\udd21\udb8d\ude96\ud867\uddf2",
        51, 54724, 398726830, -2080038684842622015L, -30085L, false, false, (char) 21204, (char) 57068,
        Double.longBitsToDouble(0x3fd42765bc1e9034L), Double.longBitsToDouble(0x3fbe483c9b83cff0L)));
  }
  @Test
  public void test15() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test15() throws Throwable {
//     assertEquals("0=$java.util.ArrayList$$EnhancerByMockitoWithCGLIB$$8b3b4d9f:!toString:java.lang.NullPointerException\0121=!java.lang.IndexOutOfBoundsException\012",
//         Z.run(T, 2, 20, 9, 20, "\uda3a\udf25\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d\ud91f\udedb\ud8e5\udd92\ud90b\udc59\uda33\ude11\uda4b\ude4d", "\ubdaf", "\ud95b\udca2\uda09\ude03\udb92\udf46\ud85d\udce7\ud9f3\ude47\udb7f\udfa4\udb6d\udcdf\uda97\udc19\ud9a4\uddd6\ud963\ude0b\ud9be\ude17\ud87a\udf07\uda00\udffb\uda65\udc95\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8a3\udf13\udb60\ude68\ud942\udf85\udb2e\udcdd\udb8d\ude96\ud867\uddf2",
//         51, 54724, 398726830, -2080038684842622015L, -30085L, false, false, (char) 21204, (char) 57068,
//         Double.longBitsToDouble(0x3fd42765bc1e9034L), Double.longBitsToDouble(0x3fbe483c9b83cff0L)));
//   }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 7, 19, 2, "\uda96\udfcd\uda16\udffa\ud966\udd21\udab4\udd6a\ud91e\udc1d\udaf1\udd70\ud8e5\udd92\ud90b\udc59\uda33\ude11\uda4b\ude4d\udbdd\ude0e\ud9bd\udf84\udba8\udfdf\ud9ed\udd01\udbb0\udf7f\ud95b\udca2\uda09\ude03", "\u08b1\u76bb\uc522\ud2f8\u3405\ubee6\u2d27\ucd95\u0c25", "\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8e3\udf18\udb14\uddc4\udb57\uddff\udb2e\udcbd\udb8d\ude96\ud867\uddf2\uda7d\uded8\udb7e\udf68\uda14\udc14\ud9e7\ude22\ud923\udc84\udb60\udcc1",
        7, 34596, -1689718072, 1993319129783205252L, 72354L, true, false, (char) 13675, (char) 34125,
        Double.longBitsToDouble(0x3fdbcbfb1b064902L), Double.longBitsToDouble(0x3fede05787eccd9cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 11, 14, 16, "\udabb\uddbe\ud951\uddb5", "\ub6f6\u89ac", "\uda30\udc32",
        56, 13697, 1178151988, -6388540556180515096L, -57335L, true, true, (char) 17127, (char) 41004,
        Double.longBitsToDouble(0x3fea987986d5aa65L), Double.longBitsToDouble(0x3fd00a781060d06cL)));
  }
  @Test
  public void test18() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test18() throws Throwable {
//     assertEquals("0=org.mockito.internal.creation.jmock.ClassImposterizer$ClassWithSuperclassToWorkAroundCglibBug$$EnhancerByMockitoWithCGLIB$$80c40454:\udbfb\udfbf\udaef\ude73\0121=org.mockito.internal.creation.jmock.ClassImposterizer$ClassWithSuperclassToWorkAroundCglibBug$$EnhancerByMockitoWithCGLIB$$80c40454:!toString:java.lang.NullPointerException\012",
//         Z.run(T, 2, 2, 20, 11, "\udbfb\udfbf\udaef\ude73", "\u85ab\u819d\uad26\u7b9d\u2c96\u7d45\u738f\u1931\ubdaf", "\udae4\ude60\ud9e9\ude00\u25db\udbcc\udfa2\ud955\udcf7\ud852\udcea\udaa8\udc0a\ud9f6\udf20\ud917\udfae\ud814\udf96\ud8ac\udd0d\ud94a\udd0a\ud963\udd44\udafb\udc36\udb02\udc0c\ud890\udeae\ud845\udea6\ud87f\udf0d\ud9a6\udc90\ud9d7\udee7\udb59\ude6e\ud9c9\udccf\udbfb\udfd3\udb78\udc0c\udacd\udc86",
//         17, 18841, -1179835693, 6989818660468879407L, -6962L, true, true, (char) 43467, (char) 29614,
//         Double.longBitsToDouble(0x3fe098bdfbbcc3efL), Double.longBitsToDouble(0x3f6c1a0ac5185700L)));
//   }
  @Test
  public void test19() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test19() throws Throwable {
//     assertEquals("0=$java.lang.Number$$EnhancerByMockitoWithCGLIB$$1d89b35:!toString:java.lang.NullPointerException\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
//         Z.run(T, 2, 20, 14, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud87d\udd8b\ud907\udfdb\ud8e5\udd92\ud90b\udcbc\uda33\ude11\udb42\udc49", "\ubdaf\u6883\u1cae\uc474\u2600\uc240\u5602\u55dd\u76bb\uc522\ua8a1\u2628\u6f7e\u2e02\ub3d4\u0d0d\u64d1\u0610\uc805\u3c8f\u683f\u707f\u6ea0\uaa86\u5547\u6820\u60a3\u2c12\uc090\u55b8\uc2d8\u7d9f\uc2ce\u6640", "\ud9d6\udcfb",
//         49, 81152, 1985734716, 5195642425517984271L, -74544L, false, false, (char) 63984, (char) 50730,
//         Double.longBitsToDouble(0x3fdabeaf35e36c06L), Double.longBitsToDouble(0x3fd5b724f39e247cL)));
//   }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 2, 12, 5, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud87d\udd8b\ud907\udfdb\udb97\udd8b\ud90b\udcbc\uda33\ude11\udb42\udc49", "\ubdaf\u6883\u1cae\uc474\u2600\uc240\u5602\u55dd\u76bb\uc522\u4826\u658d\u81d1\u1f9a\u3792\u0cd6\u64d1\u0610\uc805\u3c8f\u683f\u707f\u6ea0\uaa86\uafd7\u68ce\u60a3\u2c12\uc090\u55b8\uc2d8\u7d9f\uc2ce\u0395", "\ud9d6\udcfb",
        49, 81152, 1985734716, 5195642425517964815L, -9008L, true, false, (char) 63984, (char) 50730,
        Double.longBitsToDouble(0x3fdabeaf35e36c06L), Double.longBitsToDouble(0x3fd5b724f39e247cL)));
  }
  @Test
  public void test21() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test21() throws Throwable {
//     assertEquals("0=$java.util.Date$$EnhancerByMockitoWithCGLIB$$5d9394fe:\ud86b\udf45\ud924\ude44\udbff\udd32\udaaa\ude42\udaa4\udc04\ud907\udfdb\ud8e5\udd92\udaff\udf94\udb22\udc18\ud8f8\udfb5\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
//         Z.run(T, 2, 2, 14, 11, "\ud86b\udf45\ud924\ude44\udbff\udd32\udaaa\ude42\udaa4\udc04\ud907\udfdb\ud8e5\udd92\udaff\udf94\udb22\udc18\ud8f8\udfb5", "\u41aa\u6883\u1cae\u99c7\u2600\u886c\u8bb5\uce1a\u80b7\u4a6c\u7644\u2628\u6f7e\u0190\u7418\u2fbd\uab7d\u0610\u338a\u818d\ub178\u5057\u08ed\uaa86\u9e1c\ub492\ub518\ud4cd\uc002\u6368\u695e\u7d9f\u6352\u6640\u305a\u826e\uc066\ud3a0\u45bf\u3473\u8cfe\u851b\u150f\u076a\u5fc4\u1afc\uae97\u67ed\u4a89\ubd71\u22b1\u5b43\u998d\u4222\u7371\u9d15\ua286\ub47c\ubb23\u3aaa", "\ud825\udcee\ue5ac\udb58\ude48\udba8\udd55\ud951\ude3e\udb45\uddf8\ud9d2\ude89\ua536",
//         38, 81988, -1203294668, 6521859900149735809L, 54532L, true, false, (char) 45981, (char) 15003,
//         Double.longBitsToDouble(0x3fe799ae9aa236cdL), Double.longBitsToDouble(0x3fd1667bff397666L)));
//   }
  @Test
  public void test22() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test22() throws Throwable {
//     assertEquals("0=$java.util.Date$$EnhancerByMockitoWithCGLIB$$5d9394fe:\ud86b\udf45\ud924\ude44\udbff\udd32\udaaa\ude42\udaa4\udc04\u3bbf\ud8e5\udd92\ud90b\udc59\udb31\udd7f\ud8f8\udfb5\0121=$java.util.Date$$EnhancerByMockitoWithCGLIB$$5d9394fe:\ud86b\udf45\ud924\ude44\udbff\udd32\udaaa\ude42\udaa4\udc04\u3bbf\ud8e5\udd92\ud90b\udc59\udb31\udd7f\ud8f8\udfb5\012",
//         Z.run(T, 2, 2, 2, 11, "\ud86b\udf45\ud924\ude44\udbff\udd32\udaaa\ude42\udaa4\udc04\u3bbf\ud8e5\udd92\ud90b\udc59\udb31\udd7f\ud8f8\udfb5", "\u98a9\u6883\u1cae\u091d\u2600\u886c\u8bb5\uce1a\u84f3\u9e90\u77aa\u2628\u88ad\u014e\u7418\u7005\ub561\u0610\u338a\u818d\ub178\u5057\u3a2f\uaa86\u9e1c\ub492\ub518\ud4cd\uc002\u5ad1\ua353\u4edf\u6352\u6640\u8b8f\uc54c\uc066\ud3a0\u45bf\u3473\u8cfe\u0d93\u150f\u076a\u5fc4\u1afc\uae97\u67ed\u4a89\ubd71\u22b1\u5b43^\uaca5\u16d5\u9d15\ua286\ub47c\ubb23\u3aaa", "\ud825\udcee\ue5ac\udb58\ude48\udba8\udd55\ud951\ude3e\udb45\uddf8\ud9d2\ude89\ua536",
//         38, 81988, -1203294668, 6521859898141240159L, 54532L, true, false, (char) 38991, (char) 14821,
//         Double.longBitsToDouble(0x3fe799ae9aa236cdL), Double.longBitsToDouble(0x3fd1667bff397666L)));
//   }
  @Test
  public void test23() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test23() throws Throwable {
//     assertEquals("0=$java.util.Date$$EnhancerByMockitoWithCGLIB$$5d9394fe:\ud86b\udf45\ud924\ude44\udad9\ude3f\udaaa\ude6d\udaa4\udc04\ud907\udfdb\ud8e5\udd92\ud90b\udc59\udb31\udd7f\ud8f8\udfb5\0121=org.mockito.internal.stubbing.OngoingStubbingImpl:@? |this=org.mockito.internal.MockitoCore:@?\012",
//         Z.run(T, 2, 2, 12, 11, "\ud86b\udf45\ud924\ude44\udad9\ude3f\udaaa\ude6d\udaa4\udc04\ud907\udfdb\ud8e5\udd92\ud90b\udc59\udb31\udd7f\ud8f8\udfb5", "\u41aa\u6883\u1cae\u99c7\u2600\u886c\u4c1e\uce1a\u84f3\u9e90\u77aa\u2628\u6f7e\u0190\u7418\u7005\uab7d\u0610\u338a\u818d\ub178\uc8fa\u0928\uaa86\u9e1c\ua95b\u0a0e\ud480\uc002\u5ad1\u2308\u7d9f\u39f3\u65cf\u8b8f\uc54c\uc066\u4928\ube56\u3473\u8cfe\u851b\u2c24\u076a\u5fc4\u1afc\u4d9b\u67ed\u4a89\ubd71\u22b1\u87b5\uc85e\u7a7d\u7371\u7315\ua286\ub47c\ubb23\u3aaa", "\ud825\udcee\ue5ac\udb58\ude48\udba8\udd55\ud951\ude3e\udb45\uddf8\ud9d2\ude89\ua536",
//         38, 81988, -1203294668, -6054440959770746495L, -8257L, true, true, (char) 57651, (char) 39885,
//         Double.longBitsToDouble(0x3fc1f6ec38b7e250L), Double.longBitsToDouble(0x3fe73637de9628bcL)));
//   }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 2, 12, 8, 11, "\ud832\ude45", "\000\u1f8e\u6daa\000\u7b9d\u243f", "\ud987\udddc",
        50, 93840, 828215852, 27044455510272L, -36600L, false, true, (char) 31909, (char) 43760,
        Double.longBitsToDouble(0x3ecf3f90b8000000L), Double.longBitsToDouble(0x3febacca49e32be7L)));
  }
  @Test
  public void test25() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test25() throws Throwable {
//     assertEquals("0=$java.util.Date$$EnhancerByMockitoWithCGLIB$$5d9394fe:!toString:java.lang.NullPointerException\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
//         Z.run(T, 2, 20, 11, 11, "\ud86b\udf45\ud924\ude44\udbff\udd32\udaaa\ude42\udaa4\udc04\ud907\udfdb\ud8e5\udd92\ud90b\udc59\udb31\udd7f\ud8f8\udfb5", "\u41aa\u6883\u1cae\u99c7\u2600\u886c\u8bb5\uce1a\u84f3\u9e90\u77aa\u2628\u6f7e\u0190\u7418\u7005\uab7d\u0610\u338a\u818d\ub178\u5057\u08ed\uaa86\u9e1c\ub492\ub518\ud4cd\uc002\u5ad1\u2308\u7d9f\u36c0\u44be\u8b4a\uc54c\uc066\ud3a0\u45bf\u3473\u8cfe\u851b\u150f\u076a\u5fc4\u1afc\uae97\u67ed\u4a89\ubd71\u22b1\u5b43\u998d\u47b1\u7459\uc8c2\ua286\ub47c\ubb23\u3aaa", "\ud825\udcee\ue5ac\udb58\ude48\udba8\udd55\ud951\ude3e\udb45\uddf8\ud9d2\ude89\ua536",
//         38, 81988, -1203294668, 6521859900149735809L, 54532L, true, false, (char) 45981, (char) 15003,
//         Double.longBitsToDouble(0x3fe799ae9aa236cdL), Double.longBitsToDouble(0x3fd1667bff397666L)));
//   }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.UnfinishedStubbingException\012",
        Z.run(T, 2, 8, 8, 11, "\udabb\uddbe\ud861\udd7e\udbcc\udfa0\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud8e5\udd92\udadc\udce7\udab3\udc03\uda4b\ude4d\udbdd\ude0e\ud9bd\udf84\udba8\udfdf\udb32\udf45\udb3a\udf97\uda91\udea5\uda09\ude03", "\u562f\u76bb\uc522\ua8a1\uae98\u6f46\u2e02\u94d5", "\udacd\udd14\udb5c\udebc\ud966\udd7e\ud942\ude8a\ud85e\udf3e\ud8b4\uddfa\udb1c\ude29\ud9f3\udfe8\ud99a\udfb5\udb95\uddba\ud867\uddf2\udbf4\udff5\uc613\uda26\ude44\ud9e7\ude22\ud929\ude84\udb23\udf84\udbf5\udf43\ud87b\udd32\udb95\udcf1\uda48\udc2a\ud85f\udd0c\uda59\udf25\udb53\ude36\u9380\ud9a8\udfa9",
        15, 31598, -1333873312, 7832464810628210616L, 85774L, false, false, (char) 17049, (char) 714,
        Double.longBitsToDouble(0x3f884a31afc53940L), Double.longBitsToDouble(0x3fa4c4a99e455010L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 15, 6, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud8e5\udd92", "\u7d45\u738f\ub830", "\udb3a\udf97\ud95b\udca2\ud935\ude98\ud9b3\udf00\ud85d\udce7\ud9f3\ude99\udb7f\udfa4",
        26, 74714, -1723203612, 3163729762774045155L, -45169L, false, true, (char) 55135, (char) 55651,
        Double.longBitsToDouble(0x3fee2a96c6809221L), Double.longBitsToDouble(0x3f8c380aec284e40L)));
  }
  @Test
  public void test28() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test28() throws Throwable {
//     assertEquals("0=$java.util.ArrayList$$EnhancerByMockitoWithCGLIB$$8b3b4d9f:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
//         Z.run(T, 2, 4, 0, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud8db\udc1b\ud907\udfdb\ud8e5\udd92\udadc\udce7\udab3\udc03\uda4b\ude4d\udbdb\ude0e\ud9bd\udf84\ub382\udb32\udf6e\udb3a\udf97\ud86d\udccb\ud8f9\udf90", "\u562f\uc960\u19dd\ua8a1\u6596\ub5bf\uab89\u954f\u27c5\u9b52\u1037\u400b\u818d\u7931", "\udb5c\udddc\ud922\udd75\ud99a\udff3\udb95\uddba\ud94b\udc62",
//         51, 54724, 398726830, 5702181471255410720L, -87661L, false, true, (char) 21204, (char) 9274,
//         Double.longBitsToDouble(0x3fd42f374299b434L), Double.longBitsToDouble(0x3fbe48041fc3cff0L)));
//   }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 2, 8, 12, 8, "\udabb\uddbe\ud951\uddb5\udb29\udd82", "\u6daa\u1904\u93b0\uab5c\u7d45\u411c", "\udb32\udf39\udb3a\udf97\ud95b\udca2\uda09\ude03\udb92\udf46\ud85d\udce7\uda9f\udf8e\udb7f\udfa4",
        26, 79818, -1014067243, 3163531949465293283L, -59978L, true, true, (char) 5789, (char) 6305,
        Double.longBitsToDouble(0x3fca9f60aec284e4L), Double.longBitsToDouble(0x3fe8758dd9b638edL)));
  }
  @Test
  public void test30() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test30() throws Throwable {
//     assertEquals("0=$java.lang.Comparable$$EnhancerByMockitoWithCGLIB$$a28d8114:\udabb\uddbe\0121=$java.lang.Comparable$$EnhancerByMockitoWithCGLIB$$a28d8114:!toString:java.lang.NullPointerException\012",
//         Z.run(T, 2, 18, 20, 12, "\udabb\uddbe", "\u3462\u67f1\ucca8\u8377\u7b9d\u6faf\u23a9\u7cbb", "\uda22\uddbd\udaf5\udf57\ud95b\udca2\uda09\ude03\udbd0\udd45\ud983\udd42\udaf7\udcf2\ud888\udc22\udb6d\udc9a\uda97\udc19\ud9a4\uddd6\udbde\udf09",
//         8, 24049, -474273327, -1616187639265169971L, 15653L, false, false, (char) 54316, (char) 43287,
//         Double.longBitsToDouble(0x3fd6a96c3ef44eb0L), Double.longBitsToDouble(0x3fb047ad95be3420L)));
//   }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 0, 1, 14, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\u10e3\ud907\udfdb\ud93b\udf2c\uda12\udecc\ud9b4\udda9", "\ub830\ubdaf\u6883\u1cae\u99c7\u2600\uc240\ub686\ub9fb\u76bb\ua98f\u4971\u9811\u155b\u2e02\ud17c\u7e50\u9b52\u0610\u338a\u9a8c\u254e\u0d73", "\ud942\udf85\udb2e\udcdd",
        44, 1337, 1217313426, 6289785146451433134L, -66283L, false, false, (char) 14860, (char) 54834,
        Double.longBitsToDouble(0x3fe72fe59606deeaL), Double.longBitsToDouble(0x3feb6013602c8e59L)));
  }
  @Test
  public void test32() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test32() throws Throwable {
//     assertEquals("0=$java.util.ArrayList$$EnhancerByMockitoWithCGLIB$$8b3b4d9f:\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\u1104\ud907\udfdb\ud8e5\udd92\ud90b\udc59\ud9b4\udda9\ud892\uddf1\012",
//         Z.run(T, 1, 18, 15, 21, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\u1104\ud907\udfdb\ud8e5\udd92\ud90b\udc59\ud9b4\udda9\ud892\uddf1", "\ube11", "\ud95b\udca2\uda09\ude03\uda64\ude22\u2667\ud8a7\udcbb\udb7f\udfa4\ud8b5\udf74\udb90\udd3c\ud82c\ude60\ud94c\udfe8\ud9be\ude17\udae2\udc01\ud8bb\ude39\uda65\udc95\ud936\udd0a\ud866\udc5d\ud9bd\udcfb\ud923\ude80\udb03\udea6\ud8a3\udf13\udb60\ude68\ud8aa\udef9\udb2e\udcdd\udb8d\ude96\ud852\udcf2",
//         51, 54724, 482612910, 1613385800948657301L, 92693L, true, false, (char) 60311, (char) 60656,
//         Double.longBitsToDouble(0x3fe06b7ee09c3cffL), Double.longBitsToDouble(0x3fd6abfe80d7cc06L)));
//   }
  @Test
  public void test33() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test33() throws Throwable {
//     assertEquals("0=$java.lang.Number$$EnhancerByMockitoWithCGLIB$$1d89b35:!toString:java.lang.NullPointerException\0121=!org.mockito.exceptions.base.MockitoException\012",
//         Z.run(T, 2, 5, 7, 10, "\udabb\uddbe\ud951\uddb5", "\u4ff2\u6df8", "\udbf3\udd46\udae8\udcf3\udbec\udf4e",
//         7, 88419, 1269765840, 3557159999517956249L, -48581L, false, false, (char) 2165, (char) 28837,
//         Double.longBitsToDouble(0x3fe7b5e740000000L), Double.longBitsToDouble(0x3fef200002139724L)));
//   }
  @Test
  public void test34() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test34() throws Throwable {
//     assertEquals("0=org.mockito.internal.creation.jmock.ClassImposterizer$ClassWithSuperclassToWorkAroundCglibBug$$EnhancerByMockitoWithCGLIB$$80c40454:!toString:java.lang.NullPointerException\0121=!java.lang.IndexOutOfBoundsException\012",
//         Z.run(T, 2, 5, 9, 10, "\ud975\udd4b\ud878\ude16", "\u4ff2\u6df8\ud3ae", "\udae8\udcf3\udb35\udf13\ud9d4\udd42\ud86b\udd60\udb50\udca6\udb91\udf45\ud90f\udc99\u94a5\udb92\udfa6\ud912\udfd6\udb69\udf1c\ud9c8\ude97\udbc5\uddf9\uda97\udc26\ud824\uddb6\udb5d\udf4a\ud809\udebc\ud839\ude51\uda4c\udfd7\uda67\udec4\ufc8d\u24bd\uf19d\ud9fb\ude25\ud899\udf88\udb57\ude42\ud90e\udc84\uda94\uddac\ub1fb\udbcd\udce8\udbdb\udfee\uda0f\udc57\ud98d\udf0c\ud8b7\udf56\udb77\udf37\ud819\ude6f\udb23\udfa4\ud80a\udce9\udbc4\udc5d\ud980\udc07\ud807\udf59\udbe2\udeef\uda72\udf26\udab8\udc86",
//         17, 91108, 1613869539, -1638059613951503767L, -59096L, true, false, (char) 12536, (char) 28708,
//         Double.longBitsToDouble(0x3febdbd679629a6bL), Double.longBitsToDouble(0x3fca628fb047d5e8L)));
//   }
  @Test
  public void test35() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test35() throws Throwable {
//     assertEquals("0=$java.lang.Comparable$$EnhancerByMockitoWithCGLIB$$a28d8114:!toString:java.lang.NullPointerException\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
//         Z.run(T, 2, 5, 10, 0, "\udabb\uddbe\ud8e3\udc1f", "\u4ff2\u6df8\u5d75\u776b\u718a\u4ebb\ub6c0\u3a31\u3c58\u8bd7\u1cae\u99c7\u112c\u4833\u5602\u4bd0\uaebb\uc58f\ub138\u6ae3\u899b\u17d7\ub311\u91cf\u8241\u584c\ub439\u9fe2\u8930\uc473\u9cd5\u6522\u852e\u17e1\ucd26", "\ud95b\udf08",
//         22, 63043, 926969773, 7313866173784655283L, -52474L, true, false, (char) 23404, (char) 64787,
//         Double.longBitsToDouble(0x3feaee287a67b716L), Double.longBitsToDouble(0x3feb4f0b8b6b1e36L)));
//   }
  @Test
  public void test36() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test36() throws Throwable {
//     assertEquals("0=$java.lang.Comparable$$EnhancerByMockitoWithCGLIB$$a28d8114:!toString:java.lang.NullPointerException\0121=$java.lang.Comparable$$EnhancerByMockitoWithCGLIB$$a28d8114:!toString:java.lang.NullPointerException\012",
//         Z.run(T, 2, 5, 21, 10, "\uda51\ude38\ud854\udd34", "\u4ff2\u6df8", "\udbfa\udd46\udae8\udcf3\udbec\udf4e",
//         22, 88564, 364555472, 4561052860577421465L, -48581L, false, true, (char) 2246, (char) 28837,
//         Double.longBitsToDouble(0x3fe7b5e7415ae3d1L), Double.longBitsToDouble(0x3fef2175231e9724L)));
//   }
  @Test
  public void test37() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test37() throws Throwable {
//     assertEquals("0=$java.lang.Number$$EnhancerByMockitoWithCGLIB$$1d89b35:!toString:java.lang.NullPointerException\0121=$java.lang.Number$$EnhancerByMockitoWithCGLIB$$1d89b35:!toString:java.lang.NullPointerException\012",
//         Z.run(T, 2, 5, 21, 0, "\udaa5\udec7\ud951\udd2d", "\u4ff2\u3387", "\udbf3\udd46\udae8\udcf3\udbec\udf4e",
//         7, 88419, 1269765840, 3557159999517956249L, -48581L, false, false, (char) 2165, (char) 28837,
//         Double.longBitsToDouble(0x3fe7b5e7415ae3d1L), Double.longBitsToDouble(0x3fef217522139724L)));
//   }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.UnfinishedStubbingException\012",
        Z.run(T, 2, 8, 16, 17, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud91f\udc1d\ud907\udfdb\ud8e5\udd92\udbdd\udf02\uda33\ude11\uda4b\ude4d", "\ubdaf", "\ud95b\udca2\uda09\ude03\udb92\udf46\ud85d\udce7\uda5a\ude27\udb27\ude7f\udb54\udf8e\uda97\udc19\ud9a4\uddd6\ud963\ude0b\ud9be\ude17\ud8d9\udd29\ud9f6\udc26\uda65\udc95\ud936\udd0a\udb59\ude3b\ud9bd\udd4b\udb8b\ude34\ud85e\udf3e\ud8a3\udf13\ud828\uddf7\ud960\udc97\udb2e\udcdd\udb8d\ude96\ud867\uddf2\ud86d\uded1\udb7e\udf67\uda14\udc14\ud9e7\ude22\ud929\ude84\udb60\udcc1\udb1a\ude4d\ud871\uddea\udaa3\ude84\ub1a5",
        20, 22522, 1213920806, 2374098558513976366L, -80071L, false, false, (char) 60220, (char) 63277,
        Double.longBitsToDouble(0x3fdcb459cbcfae04L), Double.longBitsToDouble(0x3fb6edba4a289388L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 10, 14, 16, "\ud846\udd44\uda48\ude4b\ud9a6\udef4\uda1e\udde6\ud91f\udc1d\ud907\udfdb\ud8e5\udd92", "\u7d45\u738f\u5948", "\udaae\ude3c\ud80a\ude56\udab5\ude4d\ud9f8\udc7a\ud9b1\udc84\ud9f3\ude47\udb7f\udfa4",
        26, 11706, 1586106515, -8998610072256958131L, 66509L, false, false, (char) 9178, (char) 27003,
        Double.longBitsToDouble(0x3fea2bac29b638edL), Double.longBitsToDouble(0x3fb17d3e149e3420L)));
  }
  @Test
  public void test40() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test40() throws Throwable {
//     assertEquals("0=$java.util.List$$EnhancerByMockitoWithCGLIB$$965d34c4:!toString:java.lang.NullPointerException\0121=$java.util.List$$EnhancerByMockitoWithCGLIB$$965d34c4:!toString:java.lang.NullPointerException\012",
//         Z.run(T, 2, 20, 20, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\ud8fe\udf1d\ud907\udfdb\ud8e5\udd92\ud901\udf61\uda33\ude11\uda4b\ude4d", "\u17c9", "\ud95b\udca2\uda09\ude03\uda40\udc79\udaf7\udedd",
//         46, 22840, -472777079, 3360909463283957732L, -99882L, false, false, (char) 54118, (char) 2468,
//         Double.longBitsToDouble(0x3fdcde9922b55e70L), Double.longBitsToDouble(0x3fee2a96c6809221L)));
//   }
  @Test
  public void test41() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test41() throws Throwable {
//     assertEquals("0=$java.util.ArrayList$$EnhancerByMockitoWithCGLIB$$8b3b4d9f:!toString:java.lang.NullPointerException\0121=!org.mockito.exceptions.base.MockitoException\012",
//         Z.run(T, 2, 20, 10, 0, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\udb15\ude78\000\ud8ba\udf1c\ud804\udd76\uda03\udcd8\uda4b\ude39", "\u53a9", "\ud95b\udca2\uda09\ude03\udb92\udf46\ud85d\udce7\u2b53\udb4b\udd64\udb6d\udcdf\uda97\udc19\ud9a4\uddd6\ud963\ude0b\u00e3\ud8d0\udee8\u81dc\000\000\000\000\udb8b\ude34\ud952\udc03\ud886\udf63\ua70e\ud942\udecf\udb2e\udcdd\udb8d\ude96\ud867\uddf2",
//         51, 51804, 0, 9570149208162304L, -100000L, false, false, (char) 61156, (char) 57066,
//         Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb09d96f07a40d0L)));
//   }
  @Test
  public void test42() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test42() throws Throwable {
//     assertEquals("0=org.mockito.internal.creation.jmock.ClassImposterizer$ClassWithSuperclassToWorkAroundCglibBug$$EnhancerByMockitoWithCGLIB$$80c40454:\udbfb\udfbf\udaef\ude73\0121=org.mockito.internal.creation.jmock.ClassImposterizer$ClassWithSuperclassToWorkAroundCglibBug$$EnhancerByMockitoWithCGLIB$$80c40454:\udbfb\udfbf\udaef\ude73\012",
//         Z.run(T, 2, 2, 2, 11, "\udbfb\udfbf\udaef\ude73", "\u85ab\u819d\uad26\u7b9d\u2c96\u7d45\u738f\u1931\ubdaf", "\udae4\ude60\ud9e9\ude00\u25db\udbcc\udfa2\ud955\udcf7\ud852\udcea\udaa8\udc0a\uda43\uddd3\udb33\udd46\ud814\udf96\ud8ac\udd0d\ud94a\udd0a\ud9ef\udc29\udb11\ude9f\udb02\udc0c\ud890\udeae\ud845\udea6\ud87f\udf0d\ud9a6\udc90\ud9d7\udee7\udb59\ude6e\ud9c9\udccf\udbfb\udfd3\ud9a0\udc0e\udacd\udc3a",
//         17, 18841, -1179835693, 6989818660468879407L, -6962L, true, true, (char) 43467, (char) 29614,
//         Double.longBitsToDouble(0x3fe098bdfbbcc3efL), Double.longBitsToDouble(0x3f6c1a0ac5185700L)));
//   }
  @Test
  public void test43() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test43() throws Throwable {
//     assertEquals("0=org.mockito.internal.stubbing.OngoingStubbingImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
//         Z.run(T, 2, 12, 12, 11, "\udabb\uddbe\ud951\uddb5\udb29\udd82\udab4\udd6e\udbee\ude85\ud901\udda5\udb6d\ude57\ud90b\udcbc\uda33\ude11\udb42\udc49", "\ubdaf\u6883\u1cae\uc474\u2600\uc240\u5602\u55dd\u76bb\uc522\ua8a1\u2628\u6862\u896f\ub406\u0d0d\u64d1\u0610\uc805\u3c8f\u683f\u707f\u6ea0\uaa86\u5547\u6820\ucfab\ubbd5\u7c13\ua75f\uc2d8\u7d9f\uc2ce\u6640", "\ud9d6\udcfb",
//         49, 81152, 1985734716, 5195642425517964815L, -74544L, false, false, (char) 63984, (char) 50730,
//         Double.longBitsToDouble(0x3fdabeaf35e36c06L), Double.longBitsToDouble(0x3fd6a724f39e247cL)));
//   }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\ud86b\udf45\ud924\ude44\udbff\udd68\udaaa\ude42\udaa4\udc04\ud907\udfdb\ud8e5\udd92\udaff\udf94\udb22\udc18\uda7b\ude0e]] |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 7, 11, 11, "\ud86b\udf45\ud924\ude44\udbff\udd68\udaaa\ude42\udaa4\udc04\ud907\udfdb\ud8e5\udd92\udaff\udf94\udb22\udc18\uda7b\ude0e", "\u41aa\u6883\u1cae\u99c7\u2600\u886c\u8bb5\uce1a\u80b7\u4a6c\u7644\u2628\u6f7e\u0190\u7418\u2fbd\uab7d\u0610\u338a\u818d\ub178\u5057\u08ed\u9b69\u3447\uccdc\ub518\ud4cd\uc002\u6368\u695e\u7d9f\u6352\u6640\u305a\u826e\uc066\ud3a0\u45bf\u3473\u8cfe\u851b\u150f\u076a\u5fc4\u1afc\uae97\u237c\u4a72\ubd71\u22b1\u5b43\u998d\u4222\u7371\u9d15\ua286\u1dda\u9785\u6dc9", "\ud825\udcee",
        12, 24182, 1628823473, -7057576007066928275L, -98269L, false, false, (char) 30858, (char) 24307,
        Double.longBitsToDouble(0x3fd06b847302b504L), Double.longBitsToDouble(0x3fe7a2fa535f17efL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockitoCore:@?\0121=void |this=org.mockito.internal.MockitoCore:@?\012",
        Z.run(T, 2, 15, 15, 11, "\udbc4\ude55\ud8ef\ude30", "\u2029\u6daa", "\ud9b4\uddd0\udacc\uddee\u5b0f",
        42, 88419, 4386256, 3557160355099057022L, -95380L, false, true, (char) 8799, (char) 863,
        Double.longBitsToDouble(0x3fe64165056e4093L), Double.longBitsToDouble(0x3fe935008952a3acL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\udabb\uddbe]] |this=org.mockito.internal.MockitoCore:@?\0121=void |a0=[Ljava.lang.Object;:[[\udabb\uddbe]] |this=org.mockito.internal.MockitoCore:@?\012",
        Z.run(T, 2, 7, 7, 3, "\udabb\uddbe", "\u4f0c\u9803\ub891\u2200\u7c00\u2c96\u6c4e\ub0ed", "\udb32\udf45\udaf7\udd14",
        37, 88453, 1176450853, 1094449483395443539L, -34839L, true, true, (char) 11912, (char) 27838,
        Double.longBitsToDouble(0x3fde32be748206f4L), Double.longBitsToDouble(0x3fdd1a995f7d2d76L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 2, 13, 13, 3, "\ud962\ude09\udb10\udf17\udb19\udf4a\ud8d4\udf2f\ud833\udc6b\uda81\udc66\ud9d5\uddda\uda91\udd65\uda33\ude11\uda4b\ude4d", "\ubdaf", "\ud95b\udca2\ud9eb\udefd\udbdd\udc04\ud875\uddd7\ud9f3\ude47\ud8d9\udc0f\ud86a\udf01\ud87b\udd98\ud9a4\uddd6\udac1\udcbb\ud8ed\udfec\ud8d9\udce2\ud9f6\udc26\uda65\udc95\ud936\udd0a\ud954\uddb9\ud9dd\udc85\ud164\ud93c\udd69\ud8a3\udf13\udb60\ude68\ud942\udf85\udb04\udcdd\uda77\ude8b\ud875\udcd0",
        17, 42215, -306103039, -2080038684842622015L, -30085L, false, false, (char) 18633, (char) 584,
        Double.longBitsToDouble(0x3fd42765bc1e9034L), Double.longBitsToDouble(0x3fbe483c9b83cff0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.MockitoCore|mock|java.lang.Class,org.mockito.MockSettings,boolean|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.Mockito|mock|java.lang.Class|static",
    "M|org.mockito.Mockito|mock|java.lang.Class,java.lang.String|static",
    "M|org.mockito.Mockito|mock|java.lang.Class,org.mockito.MockSettings|static",
    "M|org.mockito.Mockito|mock|java.lang.Class,org.mockito.ReturnValues|static",
    "M|org.mockito.Mockito|mock|java.lang.Class,org.mockito.stubbing.Answer|static",
    "M|org.mockito.Mockito|spy|java.lang.Object|static",
    "M|org.mockito.internal.MockitoCore|assertMocksNotEmpty|[Ljava.lang.Object;|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|doAnswer|org.mockito.stubbing.Answer|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|getLastInvocation||new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|inOrder|[Ljava.lang.Object;|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|reset|[Ljava.lang.Object;|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|stub||new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|stub|java.lang.Object|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|stubVoid|java.lang.Object|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|validateMockitoUsage||new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|mock|java.lang.Class,org.mockito.MockSettings,boolean|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.Mockito|mock|java.lang.Class|static",
    "M|org.mockito.Mockito|mock|java.lang.Class,java.lang.String|static",
    "M|org.mockito.Mockito|mock|java.lang.Class,org.mockito.MockSettings|static",
    "M|org.mockito.Mockito|mock|java.lang.Class,org.mockito.ReturnValues|static",
    "M|org.mockito.Mockito|mock|java.lang.Class,org.mockito.stubbing.Answer|static",
    "M|org.mockito.Mockito|spy|java.lang.Object|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
