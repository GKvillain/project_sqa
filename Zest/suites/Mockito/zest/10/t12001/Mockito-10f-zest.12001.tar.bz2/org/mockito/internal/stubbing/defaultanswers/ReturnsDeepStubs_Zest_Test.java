package org.mockito.internal.stubbing.defaultanswers;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReturnsDeepStubs_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 0, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud824\udf8c\ud9e6\udfa6\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u70e1\u40b8\u18a7\ucae1\u8a9e\u17bf\u6f1f\u2665\uc22e\u1238\u468a\u8cd3\u4670\u3a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23",
        33, 84561, 2121074897, -4633198541387569537L, -87891L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd89318fdf21b8L), Double.longBitsToDouble(0x3fe020593938b7f3L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 0, "\ud80c\udc1c\ud98c\udc45\ud84b\udc47\000\000\000\000\ud950\udec8\u00f5\000\ub604\000\uda84\udda2", "\u70e1\u40b8\u18a7\ucae1\u8a9e\u17bf\u6f1f\u2665\uc22e\u78c3\u468a\u8cd3\u4670\u3bda", "\000",
        43, 73150, -1408690882, -2212403962048608047L, -87891L, true, false, (char) 36321, (char) 0,
        Double.longBitsToDouble(0x3fcd89318c000000L), Double.longBitsToDouble(0x3fe020593838b7f3L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 0, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud824\udf8c\ud9e6\udfa6\u0266\u97ba\ud965\udf53\ud8e8\udda9u\udafb\udf47\udb3f\udd3f\udaa2\uddbd", "\u70e1\u40b8\u18a7\ucae1\u8a9e\000\000\u2658\uc22e\000\000\u8c32\u4670\u3a30", "\ud86f\uded9\u8dea\ud95a\udf4d",
        33, 84561, 2121074897, -4633198541387569537L, -87891L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd89318fdf21b8L), Double.longBitsToDouble(0x3f064e4e2dfcc000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 0, "\udab6\udd1c\uda3b\ude63\u941e\ud824\udf8c\ud9e6\udfa6\udbd7\uddfd\uda25\ude60\ud964\udc31\ud8e8\udda9\udab8\udda1\udb4a\udef2\udb4b\udd52\udaa2\uddbd", "\u589e\u4b6f\u18a7\ucae1\u8a9e\u17bf\ua172", "\ud8e6\udd69\ud8ae\ude49\udaf0\ude7e\uda9b\ude92\udb25\udffb\udba3\udf86\ud9b8\udfc2\uda74\udea9\ud997\udfc1\udb70\udfd3\ud8e6\ude84\udb1f\udc81\ud92c\udc44\udb75\udcc0\ud90e\udcb8\udb17\udc7f\uda50\udfc1\ud97b\uddfa",
        21, 40604, 916034231, 803628670961036804L, 83820L, false, false, (char) 1377, (char) 38150,
        Double.longBitsToDouble(0x3fea8ca550f34854L), Double.longBitsToDouble(0x3fe99800a7a798e3L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.mockito.internal.MockitoCore:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 0, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud824\udf8c\ud8d7\udcde\u02b6\u97ba\ud965\udf53\ud8e8\udda9\udbf2\udd9e\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u70e1\u40b8\u18a7\ucae1\u8a9e\u17bf\u3e3c\u2665\uc22e\u1238\u468a\u8cd3\u4670\u3a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23",
        0, 84505, 2121074897, -4633198541387569537L, -87891L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd89318fdf21b8L), Double.longBitsToDouble(0x3fe020593938b7f3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 0, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud824\udf8c\ua0c7\u0266\u97ba\u008b\u00f5\udab8\udda1\udafb\udf4b\udb3f\udd3f\u3813", "\u70e1\u40b8\u18a7\ucae1\u8a9e\u00d6\000\u2658\uc22e\u1238\u468a\u8cd3\u4670\u3a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23",
        33, 84561, 2121074897, -4633198541387569537L, -87891L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd893183df21b8L), Double.longBitsToDouble(0x3fe020593938b7f3L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.mockito.internal.MockitoCore:@?\012",
        Z.run(T, 1, 7, 5, 0, "\ud80c\udc14\ud98c\udd2a\ud8dd\udcd0\ud824\udf8c\ud9e6\udfa6\uf263\ucfac\uda69\udf55\ud8e8\udda9\udab8\udda1\udafb\udf4b\uda18\udc4c\ud8f2\udfb9", "\u70e1\u4191\u18a7\ua4eb\uaf08\u7569\u588f\u1a95\u759d\u2a9d\u49f1\uc39c\u2022\u1fdb\uc05a\ua05f\ud71e\u20e3\u8206\u11ba\u31ed\u36a8\ud643\u99bd\u22ef\u2d96\u4803\u735f\u97e5\u1eac\uc411\uba75\u6986\u5077\ua362", "\ud97a\udc35\ud9ee\udd47\udaeb\ude86\ud806\udea6\ud9a0\uddce\ud966\udc3d\uda84\udc77\ud975\ude39\udb9e\udf3b",
        5, 10484, 2092450408, 2475961207124562800L, -82369L, true, false, (char) 49041, (char) 10078,
        Double.longBitsToDouble(0x3fe8d50a45c2cc70L), Double.longBitsToDouble(0x3fe329adee2c6f27L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "", "\u0298\uacd5\u00b9\u00ad\ub7fa\ubb9d\u363a", "\ud907\udec4\uda84\udda2\udbd9\udc50|\000\000\udb4f\udde8\uda98\ude23\ud95d\udf03\udb8f\ude37\ud9a1\udd6c\udbca\udf20\ud90c\udec1",
        39, 58563, -322776159, 456771134065661333L, 96608L, true, true, (char) 45074, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 0, "\ud80c\udc1c\ud98c\udd2a\u93b4\udb15\udde0\uda18\udfc1\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u70e1\u40b8\u05fe\uba67\u8a9e\u17bf\u6f1f\u2665\uc22e\u1238\u468a\u8cd3\u4670\u9a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23\ud8e0\udc4b\udb1f\udc81\ud92c\udc44\udbcf\udeae",
        37, 62713, -1407201101, -843458822830584425L, 78566L, false, true, (char) 42880, (char) 7058,
        Double.longBitsToDouble(0x3fb9ba59110cbc88L), Double.longBitsToDouble(0x3feeec8aefcb9eebL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$ReturnsDeepStubsSerializationFallback:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 9, 6, 0, "\ud80c\udc1c\ud98c\udd2a\uf420\ud95d\udc36\ud9e6\udfa6\u0266\u97ba\ud965\udf53", "\u5cfc", "\udbd9\udc50\ud851\ude65\ud97e\udd79\uda9f\udf7c\udb4f\udde8\uda98\ude23\ud95d\udf03\udad0\uded2\uda9d\udd89\ud9f5\udc29\udbbb\udf19\ud99a\udc16",
        -2, -319, 106363071, 2711964761172435009L, 58607L, false, true, (char) 26224, (char) 50567,
        Double.longBitsToDouble(0x3fe3047848d1e14bL), Double.longBitsToDouble(0x3fdcd7e6dcffc78eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 6, 4, 4, "\udb79\uddd2\udad3\udfed\udb43\udd5b\ud824\udf8c\ud94e\udf9a\udaea\udc59\uda23\ude2c\udb56\uddeb\udac5\udc1f\udab8\udd41\udafb\udf4b\ud8d0\udd49\uda84\udf67\ud97d\udcbc\ud9a7\udf79\ud880\udc79\ud87f\udc6c\udb45\udce8\uda98\ude23\uda2a\ude08\ud9c8\ude61\udaed\ude95\ud906\udcaa\udb02\udebd\udb8c\udd0a\ub3de\ud8d9\udc85\uda44\ude8d\ud932\uddce\ud814\ude3f\udb10\ude84\udb70\ude1a", "\u00c0", "\ud802\udf8e\udb25\udc13\udaff\udc19\uda50\udfc1",
        49, 53328, -242215868, 1878292329624145293L, 27934L, false, false, (char) 60006, (char) 40145,
        Double.longBitsToDouble(0x3f52a00e2e78b800L), Double.longBitsToDouble(0x3fe0592b3188dc31L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$ReturnsDeepStubsSerializationFallback:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 0, "\ud80c\udc1c\ud98c\udd2a\udbaf\ude2b\ud824\udf8c\ud9e6\udfa6\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u70e1\u40b8\u18a7\ucae1\u8a9e\u17bf\u6f1f\u2665\uc22e\u1238\u33ad\ubd27\u4670\u3a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23",
        54, 84708, 2121074897, -4633198541387569537L, -87906L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd89318fdf21b8L), Double.longBitsToDouble(0x3fe0245b4938b7f3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.mockito.internal.MockitoCore:@?\0121=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud824\udf8c\ud9e6\udfa6\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u70e1\u40b8\u50a6\ucae1\u8a9e\u17bf\u0bcf\u26e0\uc22e\u1238\u468a\u8cd3\u4670\u3a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23",
        45, 63271, -498860335, -3778502033758460294L, -87891L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd89318fdf21b8L), Double.longBitsToDouble(0x3fe020593938b7f3L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$ReturnsDeepStubsSerializationFallback:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 9, 1, 10, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud824\udf8c\ud9e6\udfa6\u0266\u97ba\ud92f\udde9\ud8e8\udcd3\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\ub37b\u40b8\u0c80\u09fd\u8a9e\u17bf\u6f1f\u2665\u53f6\u9305\u348a\u8cd3\u4670\u3a30", "\ud840\udc21\uda2d\udeb0\udab4\ude6e",
        8, 84561, 1814102481, -4633198107607247095L, 84499L, true, true, (char) 25628, (char) 22023,
        Double.longBitsToDouble(0x3fcd89318fdf21b8L), Double.longBitsToDouble(0x3fe020593938b7f3L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.mockito.internal.MockitoCore:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 0, "", "\ud541", "\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f",
        38, 28405, 1682698364, -2085277480440914175L, 22227L, true, true, (char) 58061, (char) 43514,
        Double.longBitsToDouble(0x3fd0d3a1808dbec4L), Double.longBitsToDouble(0x3fd9a2a1cd56814aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 1, 9, 13, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud92c\udcef\ud9e6\udfa6\u0266\u97ba\ud965\udf53\ud958\ude3a\uda84\udda3\udafb\udfd3\udb3f\udd3f\udaa2\uddbd", "\ucc30\u40b8\u18a7\u07a0\u1f5c\u17bf\u6f1f\u2665\uc22e\u1238\u468a\u1615\ucac5\u3a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23",
        45, 35041, -1577633113, -8212345278864447119L, 3082L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd89318fdf21b8L), Double.longBitsToDouble(0x3fcaf104ede015b0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 0, "\ud80c\udc1c\ud98c\udd2a\udb82\udd63\udae2\udcc7\ud859\udfea\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u711a\u40b8\u18a7", "\udb8f\ude37\ud9a1\uddb1\udbca\udf20\ud90c\udec1\ud8e6\udd69\ud8ae\ude49\udaf0\ude7e\uda71\udf4c\udb25\udfcc\udba3\udee6\ud902\udc26\ud86f\uded9\ud9df\ude27\ud973\ude23\ud8e0\udc4b\udb1f\udc81\ud92c\udc44\udbcf\udeae\uda69\udd05\udb17\udc7f\uda50\udfc1\ud99e\ude4b\ud8c2\udf6b\uda4e\udfeb\uda75\udda5\ud8fd\udc9f\ub1c5\ud936\udd9c\ud871\udf51\ud8b5\udcc8\ud958\udc0a",
        56, 6082, 441482222, 770155165257326031L, 2554L, false, false, (char) 8133, (char) 13415,
        Double.longBitsToDouble(0x3fcc7e462b72c190L), Double.longBitsToDouble(0x3fd19f863ac3cdd8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.mockito.internal.MockitoCore:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 0, "\ud8ae\udcfe\ud98c\udd2a\u93b4\ud824\udf8c\ud9e6\udfa6\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u70e1\u40b8\u18a7\ucae1\u8a9e\u17bf\u6f1f\u7781\uc22e\u1238\u468a\ub9a9\u697c\u42f5", "\ud893\udd70\ud9df\ude27\ud973\ude23\ud8e0\udc4b\udb1f\udc81\ud92c\udc44\udbcf\udeae\ud9b3\udd2a\udb17\udc70\uda50\udfc1",
        4, 23631, 1233946518, -4004253208793338889L, -14296L, false, true, (char) 760, (char) 6809,
        Double.longBitsToDouble(0x3f5478d8f3ac6e00L), Double.longBitsToDouble(0x3f9f0b7c586e81c0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$ReturnsDeepStubsSerializationFallback:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 0, "\ud845\udded\udb9f\udcf6\uda21\uddb1\uda2b\udc5d\uda03\udc86\ud80d\udf14\ud81a\uddcc\ud965\udf53\ud8e8\udda9\u44dd\ud8d1\udc7c\uda24\udc57\udbc4\udd69", "\u70e1\u18ae\u270b\u1fab\u0b0f\u6cb2", "\ud84e\ude5c\ud8e6\udd69\ud8ae\ude49\udaf0\ude7e\uda71\udf4c\udadb\udd07\udb92\udc26\uda18\udfb1",
        38, 12378, -1337367850, -5988638248978876847L, 91089L, true, false, (char) 6859, (char) 33250,
        Double.longBitsToDouble(0x3fecb3141dd7498cL), Double.longBitsToDouble(0x3fdb78c52c97bc34L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.mockito.internal.MockitoCore:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 11, "\ud80c\udc1c\ud98c\udd2a\u93b4\udb41\uddba\udae2\udf2b\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u70e1\u49c0\u321f\ud70d\u8a9e\u17bf\u6f1f\u2665\uc22e\u02a1\u468a\u8cd3\u4670\u3a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23\uda4e\udde2\udb1f\udc45\ud92c\udc44\udbcf\udeae",
        37, 62713, -1407201101, -843458822830584425L, 33356L, true, true, (char) 47402, (char) 26923,
        Double.longBitsToDouble(0x3fe877fba5d9acc6L), Double.longBitsToDouble(0x3fedadb2f763c61cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$ReturnsDeepStubsSerializationFallback:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$ReturnsDeepStubsSerializationFallback:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 9, 9, 8, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud824\udf8c\ud9e6\udfa6\u0266\ud8b9\udd64\ud965\udf53", "\u66db", "\udbd9\udc50\ud851\ude65\ud97e\udd79\uda9f\udf7c\udb4f\udde8\uda98\ude23\ud95d\udf03\000\000\udbca\udf13\ud90c\udec1\000",
        -5, 18680, 106350317, 2711964761172435009L, 58607L, false, true, (char) 212, (char) 50567,
        Double.longBitsToDouble(0x3fe28d6048d1e14bL), Double.longBitsToDouble(0x3fe3cbf36e7fbfb3L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 10, 4, 0, "\ud82a\udf05\udba7\udc8d\u941e\ud824\udf8c\ud9e6\udfa6\udbd7\uddfd\uda25\ude60\ud964\udc31\u783b\u782b\ud99f\udd13\udbfb\udf3f\udaa2\uddbd", "\u589e\u4b6f\u18a7\ud1b2\u8a0f\u17bf\ua172", "\ud8e6\udd69\ud8ae\ude49\udaf0\ude7e\uda9b\ude92\udb25\udffb\udba3\udf86\ud9b8\udfc2\uda74\udea9\ud997\udfc1\udb70\udfd3\ud8e6\ude84\udb1f\udc81\ud944\ude51\udb75\udc9b\ud90e\udcb8\ud941\udc34\uda42\ude0f\ud97b\uddfa",
        21, 40604, 916034231, 803628670961036804L, 83820L, false, false, (char) 1377, (char) 38150,
        Double.longBitsToDouble(0x3fea8ca550f34854L), Double.longBitsToDouble(0x3fe99800a7a798e3L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 2, 10, 10, 9, "\udab6\udd1c\uda3b\ude63\u941e\ud824\udf8c\udbde\udfa3\udbd7\uddfd\ud898\udf1a\uda57\uded7\ud8e8\udda9\ud82d\udefa\udb4a\udfcf\udb4b\udd52\uda17\udec2", "\ub8d3\u4b6f\u18a7\ucae1\u8a9e\u17bf\ua172", "\ud8e6\udd69\ud8ae\ude49\uda92\ude6f\uda9b\uddf6\udb25\udffb\udba3\udf86\ud9b8\udfc2\uda74\udea9\ud997\udfc1\udb70\udfd3\udbea\udc46\udb1f\udc81\ud92c\udc44\udb75\udcc0\ud90e\udcb8\udb17\udc7f\uda50\udfc1\u2833",
        25, 40604, 916034231, 803628670961036804L, 83820L, true, true, (char) 53863, (char) 38150,
        Double.longBitsToDouble(0x3fea8c1020f34854L), Double.longBitsToDouble(0x3fe99800a7a798e3L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\012",
        Z.run(T, 1, 10, 5, 0, "\udab6\udd1c\uda3b\ude63\u941e\ud824\udf8c\ud9e6\udfa6\udbd7\uddfd\uda25\ude60\ud964\udc31\ud8e8\udda9\udab8\udda1\udb4a\udef2\udb4b\udd52\udaa2\uddbd", "\u589e\u4b6f\u18a7\ucae1\u8a9e\u17bf\ua172", "\ud8f0\udd7a\ud7ad\udac1\uddae\uda9b\ude92\udb25\udffb\udba3\udf86\ud9b8\udfc2\ud800\udda2\udb3f\udc53",
        12, 62831, -2023754159, 6826188834979680806L, 91089L, true, false, (char) 22955, (char) 41751,
        Double.longBitsToDouble(0x3fd9492ee56fa5deL), Double.longBitsToDouble(0x3f74da6702059380L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.mockito.internal.MockitoCore:@?\0121=org.mockito.internal.MockitoCore:@?\012",
        Z.run(T, 2, 7, 7, 0, "\udab6\udd1c\uda3b\ude63\u941e\ud824\udf8c\ud9e6\udfa6\udbd7\uddfd\uda25\ude60\ud964\udc31\ud8e8\udda9\udab8\udda1\udb4a\udef2\udb4b\udd52\udaa2\uddbd", "\u589e\u4b6f\u18a7\ucae1\u6238\u17bf\ua172", "\ud8e6\udd69\ud8ae\ude49\udaf0\ude7e\uda9b\ude92\udb25\udffb\udba3\udf86\ud9b8\udfc2\uda74\udea9\ud997\udfc1\udb70\udfd3\ud8e6\ude84\udb1f\udc81\ud932\udc18\udb75\udcc0\ud90e\udcb8\udb17\udc7f\uda50\udfc1\ud97b\uddfa",
        21, 40604, 1520014007, 4000907801517496329L, 83820L, false, true, (char) 45737, (char) 17402,
        Double.longBitsToDouble(0x3fbaef3f879e2b48L), Double.longBitsToDouble(0x3fe99800a7a798e3L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\0121=org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues:@?\012",
        Z.run(T, 2, 6, 6, 9, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud824\udf8c\ua0c7\u0266\u97ba\u008b\u00f5\udab8\udda1\udafb\udf4b\udb3f\udd3f\u3813", "\u70e1\u40b8\u18a7\ucae1\u8a9e\u00d6\000\u2658\u28e5\u1238\u468a\u8cd3\u4670\u3a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23",
        33, 84561, -1289025327, -4633198541387569537L, -87891L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd893183df21b8L), Double.longBitsToDouble(0x3fe3205939d402a4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 4, "\ud80c\udc1c\ud98c\udd2a\u93b4\ud824\udf8c\ud9e6\udfa6\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u70e1\u40b8\u18a7\ucae1\u8a9e\u17bf\u6f1f\u2665\uc22e\u1238\u468a\u8cd3\u4670\u3a30", "\ud86f\uded9\ud9df\ude27\ud922\udeda",
        36, 84561, 2121074897, -4633198541387569537L, -87891L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd89318fdf21b8L), Double.longBitsToDouble(0x3fe020593938b7f3L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs$ReturnsDeepStubsSerializationFallback:@? |this=org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 0, "\ud80c\udc1c\ud98c\udd2a\udbaf\ude2b\ud824\udf8c\ud9e6\udfa6\u0266\u97ba\ud965\udf53\ud8e8\udda9\udab8\udda1\udafb\udf4b\udb3f\udd3f\udaa2\uddbd", "\u70e1\u40b8\u18a7\ucae1\u8a9e\u17bf\u6f1f\u2665\uc22e\u1238\u37b0\u1205\u4670\u3a30", "\ud86f\uded9\ud9df\ude27\ud973\ude23",
        54, 84708, 2121074897, -4633198541387569537L, -87906L, true, false, (char) 33250, (char) 59928,
        Double.longBitsToDouble(0x3fcd89318fdf21b8L), Double.longBitsToDouble(0x3fe0245b4938b7f3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|deepStub|org.mockito.invocation.InvocationOnMock,org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|newDeepStubMock|org.mockito.internal.util.reflection.GenericMetadataSupport,java.lang.Object|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|propagateSerializationSettings|org.mockito.MockSettings,org.mockito.mock.MockCreationSettings|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|withSettingsUsing|org.mockito.internal.util.reflection.GenericMetadataSupport,org.mockito.mock.MockCreationSettings|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|actualParameterizedType|java.lang.Object|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|answer|org.mockito.invocation.InvocationOnMock|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|delegate||static",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|mockitoCore||static",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|recordDeepStubAnswer|java.lang.Object,org.mockito.internal.stubbing.InvocationContainerImpl|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|returnsDeepStubsAnswerUsing|org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "C|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|<init>|",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|deepStub|org.mockito.invocation.InvocationOnMock,org.mockito.internal.util.reflection.GenericMetadataSupport|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|newDeepStubMock|org.mockito.internal.util.reflection.GenericMetadataSupport,java.lang.Object|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|propagateSerializationSettings|org.mockito.MockSettings,org.mockito.mock.MockCreationSettings|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
    "M|org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs|withSettingsUsing|org.mockito.internal.util.reflection.GenericMetadataSupport,org.mockito.mock.MockCreationSettings|new:org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
