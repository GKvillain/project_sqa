package org.mockito.internal.configuration;
import org.junit.Test;
import static org.junit.Assert.*;
public class SpyAnnotationEngine_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 3, 3, 0, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8\ud881\udc59\udb12\udeaf\udb18\ude1e\uda1f\ude12\ud8cb\udd23\ud82f\udf50\udabb\udcd8", "\u7bb8\u1bf7\ub127\u5355\u3f97\u4128\u44bf\u1c2d\u5599\ub40e\033\u12a4\uc8a5", "\udbcd\udf2f\ud9d7\uddc1",
        24, 15803, -1421738645, -2448590845532645881L, -74016L, true, false, (char) 34720, (char) 14088,
        Double.longBitsToDouble(0x3fe6ebdab763bb22L), Double.longBitsToDouble(0x3feb563bc3e6f986L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud8fd\udddd\ud97b\udfdc\ud97f\udf88\uda21\udd6d\udb5d\uddfd\uda57\udcf9\ud924\ude25\uda8f\udc58\uda50\udc5d\ud892\udfb8\udaa3\udf10\uda20\ude02\udb18\ude1e\udb17\ude0e\udb0e\udd65\ud997\udf36\uda91\uddcc", "\u38c5\u89e4\ub17e\u5355\u3f97\ud1d1\u44bf\u1c2d\u5599\u256a\u5214\u620b\u3caa", "\udb65\udf00\ud9de\ude42\ud8c7\udc49",
        1, 37355, 365419417, 7187980805985583280L, 96891L, false, false, (char) 6012, (char) 34720,
        Double.longBitsToDouble(0x3fed093b3add7b56L), Double.longBitsToDouble(0x3feb1dd9172a92c2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 3, 3, 0, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\udab6\uddf9\ud881\udc59\udb12\udeaf\udb18\ude1e\uda1f\ude12\ud8cb\udd23\ud82f\udf50\udabb\udcd8", "\u7bb8\u1bf7\ub127\u5355\u3f97\u4144\u44bf\u1c2d\u5599\ub40e\033\u12a4\uc8a5", "\udbcd\udf2f\ud9d7\uddc1",
        24, 71323, 246245860, -2448590845532645881L, -74016L, true, false, (char) 34720, (char) 14088,
        Double.longBitsToDouble(0x3fe6ebdab763bb22L), Double.longBitsToDouble(0x3feb563bc3e6f986L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 0, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8\ud881\udc59\udb12\udeaf\udb2b\udd3f\uda1f\ude12\udbe3\udd30\ud825\udfa2\udabb\udcd8", "\u7bb8\ucaf6\ub127\u5355\u3f97\u4128\u44bf\u1c2d\u5599\u1a73\ud776\u12a4\uc8a5", "\udbcd\udf2f\ud84c\udfc1",
        24, 15803, -1421738645, -2448590845532645881L, -92616L, true, true, (char) 22244, (char) 25992,
        Double.longBitsToDouble(0x3fe45a3cee2ecbedL), Double.longBitsToDouble(0x3fe6ebdc3763bb22L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 0, 1, 1, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8\ud881\udc59\udb12\udeaf\ud85c\udd00\uda3a\udd83\ud953\udf49\uda29\udf6b\udae3\udc8c", "\u7bb8\u1bf7\ub127\u5355\u3f97\u4128\u44bf\u1c2d\u5599\ub40e\033\u12a4\uc8a5", "\udbcd\udf2f\ud9d7\uddc1",
        24, 15803, -1421738645, -2448590845532645881L, -74016L, true, false, (char) 34720, (char) 14088,
        Double.longBitsToDouble(0x3fe6ebdab763bb22L), Double.longBitsToDouble(0x3feb563bc3e6f986L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 0, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8", "\uaf60", "\ud992\udf0a\udaeb\udc66\ud83c\udc0e\ud878\ude41",
        32, 12081, 1462161051, 3191940540632135336L, 19766L, false, false, (char) 8888, (char) 23853,
        Double.longBitsToDouble(0x3fe5c0a17ddfc177L), Double.longBitsToDouble(0x3fc8968d8d064fdcL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=new org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 2, 3, 3, 0, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9", "\u22ef\u0b9a\u06f7\u25f5\uaf60", "\ud82f\udf50\udabb\udcd8\ud83c\udc0e\ud878\ude41",
        32, 65385, -1865167997, -6139504989492742414L, 42378L, false, false, (char) 49848, (char) 26741,
        Double.longBitsToDouble(0x3fe61c476ddfc177L), Double.longBitsToDouble(0x3fc8968d8d064fdcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 2, 3, 2, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\ud9a1\udf9e\udb1d\ude13\uda57\udc44\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8\ud881\udc59\udb12\udeaf\udb18\ude1e\uda1f\ude12\ud8cb\udd23\ud82f\udf50\udabb\udcd8", "\u7bb8\u1bf7\ub127\u5355\u3f97\u4128\u44bf\u1c2d\u5599\ub40e\033\u1270\uc8a5", "\udbcd\udf2f\ud9d7\uddc1",
        24, 15803, -1421738645, -2448590845532645881L, 23688L, false, true, (char) 22244, (char) 25992,
        Double.longBitsToDouble(0x3fe40c48ffa12767L), Double.longBitsToDouble(0x3fe6ebdab763bb22L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 0, "\ud9e6\udd8b\udaee\udc42\ud9d9\udfee\uda17\udd56\udb5d\uddfd\ud9c3\udd2f\ud8e7\udc61\uda8f\udc58\uda50\udc5d\udae6\ude85\udad2\udfd5\udb0e\udf48\udb18\ude1e\uda1f\ude12\ud8cb\udd23\ud82f\udf50\udb13\udc63", "\ub7b8\u1bf7\ub127\u5355\u3f97\u4128\u44bf\u1b53\u5599\ub449\033\u2230\u5a0e", "\udbcd\udf2f\ud8e4\udc28\ud847\udeeb\ud816\udeb2\uda3b\ude79\uda07\udf5d",
        42, 36608, 192406312, -4871767681160022742L, -99617L, true, true, (char) 36403, (char) 55941,
        Double.longBitsToDouble(0x3feb563bc3e6f986L), Double.longBitsToDouble(0x3fcd629ef036c84cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |a2=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 1, 3, 1, "\ud193\udaee\udc42\udb3e\udefa\uda4e\ude24\uda9d\udd9a\uda57\udcf9\ud8e7\udc26\uda8f\udc66\ud9eb\ude56\ud892\udfbb\ud881\udc59\udba0\udff7\udb91\udc93\uda16\udf12\ud949\udf42\ud82f\udf50\udabb\udcd8", "\u7bb8\u1bf7\ub127\u5355\u3f97\u4222\u0d0b\u1b8a\u5599\ub40e\u7e52\u12b0\uc8a5", "\udbcd\udf2f\ud9d7\uddc1",
        24, 15936, -1421738645, -2448590845532682745L, -44832L, true, false, (char) 34720, (char) 23455,
        Double.longBitsToDouble(0x3fe6ebdab763bb22L), Double.longBitsToDouble(0x3fb8b1de020f25b0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 2, 3, 0, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\udab6\uddf9\ud881\udc59\udb12\udeaf\udb18\ude1e\uda1f\ude12\ud83e\udc5d\ud86d\udca7\udabb\udcd8", "\u7bb8\u1bf7\ub127\u5355\u3f97\u26e5\u44bf\u1c2d\u4ea6\u1cc1\033\u12a4\uc8a5", "\udbcd\udf2f\ud9d7\uddc1",
        24, 71323, 246245860, -2448590845532645881L, -40776L, false, false, (char) 22163, (char) 56091,
        Double.longBitsToDouble(0x3feb563bc0e6f986L), Double.longBitsToDouble(0x3fe9066e4b5c9801L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=new org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 2, 0, 3, 0, "\ud9f4\udccf\udaee\udc42\ud8cf\udfe9\udb6e\ude64\ud967\udf61\ud98b\udc40\udaae\udd17\uda64\udf6c\ud904\udc57\udac7\udd2c\ud881\udcbf\udb12\udeaf\udb18\ude1e\uda1f\ude12\ud8cb\udd23\ud82f\udedc\udabb\udcd8", "\u7bb8\u1bf7\ub127\u0c9c\uc0db\u26a6\u1da6\u87d4\u118a\ub40e\033\u12a4\uc8a5", "\uda7e\uded4",
        42, 56894, -275455677, 1057617914905287577L, 66832L, true, false, (char) 11327, (char) 9538,
        Double.longBitsToDouble(0x3fed4e98d94b726fL), Double.longBitsToDouble(0x3fe3063fde317b23L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u68bb\000\uda57\udcf9\u351d\uda61\ude58\uda50\udc5d\ud870\udf58\000\000\udbab\ude95\uda1f\ude12\ud9ce\udde5\ud82f\udf50\udabb\udcd8", "\u77d3\u1bf7\ud6c8\000\ubf97\000\000\000\000\000\u1a7a\u12a4\uc8a5", "A\000",
        25, 56667, 246245632, -2448590845532645881L, -100000L, false, false, (char) 35201, (char) 0,
        Double.longBitsToDouble(0x3fe6ebd80763bb22L), Double.longBitsToDouble(0x3feb563bc3e6f986L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 0, 1, 2, "\ud81d\ude06\ud82b\udebe\ud8dd\udc33\udbc8\udefd\ud8a6\udfad\ud8a1\udca9\udbe1\udf3d\udb7d\udc4d\uda50\udc5d\ud889\udfd0\ud881\udc59\udb12\udeaf\udb2b\udd3f\uda1f\ude12\udbe3\udd30\uce69\udabb\udcd8", "\u1c17\u5b77\u2d2b\ubbdf\u7e74\u4128\u2b90\u9cf5\u3429\u894e\uaec6\u2a1e\u9eee", "\ud8e2\udebe\udaf0\ude4c",
        35, 51230, 202120915, -2448590849827613177L, -92616L, true, true, (char) 46711, (char) 26017,
        Double.longBitsToDouble(0x3fe4023cec3ed8e6L), Double.longBitsToDouble(0x3fcfdf6a59066bc0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 3, "\uda00\udd5f\udaed\udfc2\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8", "\u2282", "\ud825\udfe2\ud922\ude0c\uda78\udfbe\uda53\udfb7",
        33, 52073, 36097691, -6139505457644177678L, 42378L, false, false, (char) 13552, (char) 26741,
        Double.longBitsToDouble(0x3fe61c476ddf11d2L), Double.longBitsToDouble(0x3fc8968d83e86c08L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=null |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 2, 0, 2, 3, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\ud99e\ude9d\udb7f\udf74\uda57\udc99\ud8e7\udc26\ud893\udc5a\ud81c\ude03\ud92b\udd0e\udb7e\udc19\udafb\udffb\udb2b\udd3f\uda1f\ude12\u805d", "\u744e\u118c\u7bb8\u511e\u3f06\uc13b\u3f97\u4128\u44bf\u1c2d\u5599\u1a73\ud776\uaaef\u5bb6\ua94b\u5756\ub409", "\ud816\udeb2\uda02\udc6c\udbbe\uded9\uda4b\uddf2\uda40\udc1d\u4bd5\ua758\ud883\udc2e\udbc1\udd2a\udb5d\ude6c\uda1f\uddba\u96ce\udaa0\udd02\udb35\udd79\ud8f4\ude0e\uda10\udd2d\ud940\ude1e\u6166\uda6a\ude09",
        0, 95191, 1017495481, -3490922009676749285L, 84141L, false, false, (char) 47864, (char) 33764,
        Double.longBitsToDouble(0x3fdfe25c604a0f00L), Double.longBitsToDouble(0x3feaf30e0e8ce854L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8\uda6e\udc0f\uf3b0\ud85c\udcdb\uda3a\udd83\ud953\udf49\uda29\udf6b\udae3\udc8c", "\u7bb8\u1bf7\ub127\u5355\u3f97\u4128\u06a8\u4508\u833c\u1515\033\u12a4\uc8a5", "\udbcd\udf2f\ud9d7\uddc1",
        24, 15803, -1421738645, 3243959083457584640L, -74016L, true, false, (char) 34720, (char) 14088,
        Double.longBitsToDouble(0x3fe6ebdab063bb22L), Double.longBitsToDouble(0x3feb563bc3e6f986L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=void |a2=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 2, 0, 1, 1, "\ud9e6\udd8b\udaee\udc42\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8\ud881\udc59\udb12\udeaf\ud85c\udd00\uda3a\udd83\ud953\udf49\udabc\ude95\udaa0\udea0", "\u387a\u1bf7\ub127\u5355\u3f97\u4128\u44bf\u1c2d\u5599\ub40e\033\u12a4\uc8a5", "\udbcd\udf2f\ud9d7\uddc1",
        24, 2860, 1176108761, -2444712541603965433L, -71524L, true, true, (char) 8226, (char) 62111,
        Double.longBitsToDouble(0x3fe522e01fa12767L), Double.longBitsToDouble(0x3fe6ebdab763bb22L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 1, "\uead5\udb80\uddb9\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8\ud881\udc59\udb12\udeaf\ud85c\udd00\uda3a\udd83\ud953\udf49\uda29\udf6b\udae3\udc8c", "\u7bb8\u1bf7\ub127\u5355\u3f97\u4128\u44bf\u1c2d\u55a6\ub40e\u1f13\u125f\uc8a5", "\udbcd\udf2f\ud9d7\uddc1",
        24, 15803, -520028821, -987209720349579875L, -74016L, true, false, (char) 47579, (char) 47053,
        Double.longBitsToDouble(0x3fe6ebdab163bb98L), Double.longBitsToDouble(0x3fd43c7787cdf398L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udbf5\udd08\udaee\udc42\udb3e\udefa\uda51\udce0\uda9d\udd9a\uda57\udcf9\ud8e7\udc26\uda8f\udc66\ud9eb\ude56", "\u16d8\u61bd\u8933\u6def\ub907\uadda\u744e\u118c\u7bb8\u1bf7\ub127\u5355\u3f97\u7f2c\ud012\u1b8a\u5599", "\uda5e\udccb\uda51\udf13\udb44\udd6a",
        6, 48016, -1732894132, -3656273517418847800L, -4935L, false, true, (char) 28306, (char) 58624,
        Double.longBitsToDouble(0x3fc8b2987a06247cL), Double.longBitsToDouble(0x3fac13b3add7b560L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud9f4\udccf\ud9cd\ude11\udac3\udcfa\udacd\udef5\udb6b\ude12\ud9e5\udc46\udaae\udd17\uda64\udf6c\ud904\udc57\udac7\udd2c\ud881\udcbf\udb12\udeaf\uda11\udf3b\ud96f\ude33\ud8b8\udeb5\ud901\ude5c\uda00\udce5", "\uc10e\u1bf7\ub127\u0c9c\uc0db\u26a6\u1da6\u87d4\u118a\ub40e\033\u12a4\u2350", "\uda7e\uded4\udbf8\uddfa\ud9ed\udf40\ud90a\udc4b\ud996\udec1",
        7, 5304, 1399753648, 6716761041901309705L, -79433L, true, true, (char) 49755, (char) 31639,
        Double.longBitsToDouble(0x3fe3925b9f080d47L), Double.longBitsToDouble(0x3fd456d0f0be1e54L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=null |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 2, 2, 2, 3, "\uda00\udd5f\udaed\udfc2\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8", "\u2282", "\udb19\ude7b\ud922\udd8f\uda78\udfbe\uda53\udfb7",
        58, 52073, 36097691, -6139505457644177678L, 17546L, true, false, (char) 13552, (char) 26741,
        Double.longBitsToDouble(0x3fe61c476ddf11d2L), Double.longBitsToDouble(0x3fc8968d83e86c08L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=void |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 2, 0, 0, 3, "\uda00\udd5f\ud821\udd77\ud8cf\udf77\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud8b4\udf57", "\u2282", "\ud825\udfe2\ud922\ude0c\uda78\udfbe\uda53\udfb7\ud9e4\udf4a\ud8d2\udf3d\ud9b5\udebb",
        38, 82394, -875413760, 5339093149076819172L, -79188L, false, true, (char) 26741, (char) 19376,
        Double.longBitsToDouble(0x3fddf11d2d53fdbeL), Double.longBitsToDouble(0x3fe76fd41a7d00ddL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |a2=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\0121=void |a2=[Ljava.lang.Class;:[[]] |this=org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda00\udd5f\udaed\udfc2\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud8e7\udc26\uda8f\udc58\uda50\udc5d\ud892\udfb8", "\u2282", "\ud825\udfe2\ud922\ude0c\uda78\udfbe\uda53\udfb7",
        33, 85128, 700020767, -6139505457644177678L, 42378L, true, true, (char) 13370, (char) 26741,
        Double.longBitsToDouble(0x3fe61c476ddf11d2L), Double.longBitsToDouble(0x3fc8967de3e86c08L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.SpyAnnotationEngine:@?\012",
        Z.run(T, 1, 3, 3, 0, "\ud9e6\udd8b\udaed\udf73\ud8cf\udfe9\u9c62\udb5d\uddfd\uda57\udcf9\ud950\udffc\uda8e\udfba\uda50\udc5d\udbea\udee4\ud881\udc59\udb12\udeaf\udb18\ude1e\uda1f\ude12\ud8cb\udd23\ud9f5\udcb4\ud9c0\udc28", "\u18a6\u23f5", "\udb92\udc9c\udb28\udfec\udb4e\udd4b\ud8c0\udfaf\ud8ea\ude3c\ud9b8\udfb4\uda4d\ude65\udb02\udd87",
        29, 14218, -1812492094, -4972322253930124468L, -4848L, false, true, (char) 3218, (char) 22244,
        Double.longBitsToDouble(0x3fc8b2987a06247cL), Double.longBitsToDouble(0x3fed093b3add7b56L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.configuration.SpyAnnotationEngine|process|java.lang.Class,java.lang.Object|new:org.mockito.internal.configuration.SpyAnnotationEngine:",
    "M|org.mockito.internal.configuration.SpyAnnotationEngine|assertNoAnnotations|java.lang.Class,java.lang.reflect.Field,[Ljava.lang.Class;|new:org.mockito.internal.configuration.SpyAnnotationEngine:",
    "M|org.mockito.internal.configuration.SpyAnnotationEngine|createMockFor|java.lang.annotation.Annotation,java.lang.reflect.Field|new:org.mockito.internal.configuration.SpyAnnotationEngine:",
    "C|org.mockito.internal.configuration.SpyAnnotationEngine|<init>|",
    "M|org.mockito.internal.configuration.SpyAnnotationEngine|process|java.lang.Class,java.lang.Object|new:org.mockito.internal.configuration.SpyAnnotationEngine:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
