package org.mockito.internal.matchers;
import org.junit.Test;
import static org.junit.Assert.*;
public class Same_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 2, "\ud9e6\udc26\udb34\udc78\uda10\udc69\uda66\udc05\ud959\udc2b\u5321\udb11\udde2", "\u592c\u3ffc\u9b4d\u33c7\ubfad\u248e\u35df\u77e3", "\udb68\udf14\ud862\udf13\ud836\uddca\udbcc\uded5\ud8f1\uded8\ud82f\ude7c\ud961\uddf0\udaef\udc12\udab8\ude53\ud990\udc81\ud9d7\udee8\ud9d8\udedb",
        11, 66786, -1898861665, 1910471225915968879L, 53280L, false, false, (char) 31475, (char) 3203,
        Double.longBitsToDouble(0x3fe625e2e47cd174L), Double.longBitsToDouble(0x3fd8df9ffd46f72eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 2, "\ud9e6\udc26\udb34\udc78\uda10\udc69\uda66\udc05\ud959\udc2b\u5321\ud8c4\uded9", "\u592c\u3ffc", "\uda1d\udfce\ud8cc\udc95\ud8ef\udc9e\ubabc\ud83a\udce3\uda1d\uddeb\udb68\udf14\ud862\udf13\ud988\udc13\udbcc\uded5\ud8f1\uded8\ud82f\ude7c\ud961\uddf0\udaef\udc12\udab8\ude53\ud990\udc81\udad1\udd05\udbe4\udffb",
        9, 66809, -1898861665, 1910471225915968879L, 53280L, false, false, (char) 31475, (char) 3203,
        Double.longBitsToDouble(0x3fe625e2e47cd174L), Double.longBitsToDouble(0x3fd8df9ffd46f72eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.matchers.Same:same(\"\uda27\udc46\udab1\udc24\ud89f\udd31\ud8ba\ude40\ud906\ude92\uda6d\udc18\udb1d\udfc1\")\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\uda27\udc46\udab1\udc24\ud89f\udd31\ud8ba\ude40\ud906\ude92\uda6d\udc18\udb1d\udfc1", "\u592c\u3ffc\u9b4d\u33c7\u1fad\u53ab\u4045\u9bab\u06e6\u5adf", "\ud836\uddca\udbe8\uddf6\udb6f\udcd1\udac1\ude18\ud9f2\uddf6\udaef\udc12\udb8d\udf8e\ud990\udc62\ud868\udc11\udbff\udc06\ud8ee\udf82\uda80\udea6\ud8cf\udc50",
        36, 45873, -886724438, -2490783805693386076L, -11038L, true, true, (char) 43361, (char) 35374,
        Double.longBitsToDouble(0x3fd2f753d43577eaL), Double.longBitsToDouble(0x3fe19338a065612dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.matchers.Same:same(null)\0121=java.lang.Boolean:true |this=org.mockito.internal.matchers.Same:same(null)\012",
        Z.run(T, 2, 1, 2, 2, "\ud9e6\udc26\udb34\udc78\uda10\udc69\uda66\udc05", "\u8fcc\uc0cf\u3b56", "\ud8c8\uddcc",
        32, 92538, -655844637, 1615705175720432247L, 3607L, true, false, (char) 29181, (char) 44297,
        Double.longBitsToDouble(0x3fdf243d33929a0eL), Double.longBitsToDouble(0x3fe371e18c95b815L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.mockito.internal.matchers.Same:same(\"\ud9e6\udc26\uda24\udfc0\ud94a\ude14\uda65\udf7e\ud959\udc2b\u5321\udb32\uddd2\")\0121=java.lang.Boolean:false |this=org.mockito.internal.matchers.Same:same(\"\ud9e6\udc26\uda24\udfc0\ud94a\ude14\uda65\udf7e\ud959\udc2b\u5321\udb32\uddd2\")\012",
        Z.run(T, 2, 3, 2, 2, "\ud9e6\udc26\uda24\udfc0\ud94a\ude14\uda65\udf7e\ud959\udc2b\u5321\udb32\uddd2", "\u592c\u3ffc\u9b4d\u33c7\ubfad\u9500\u724e\u60a7", "\udb68\udf14\udbcd\udc28\ud866\udee4\udbd6\udcd5\ud9a2\udced\u35da\ud84d\ude47\ud8d4\ude1f\udad2\udde6\ud990\udc81\uda39\udd18\ud821\udd6d",
        -1, 46530, -1780672991, 1910471225923326831L, 53280L, false, false, (char) 31475, (char) 3203,
        Double.longBitsToDouble(0x3fef7cbae222a286L), Double.longBitsToDouble(0x3fd0096bd5206716L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.matchers.Same:same(null)\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 2, "\ud9e6\udc26\udb34\udc78\uda10\udc69\ud8a1\ude01\ud958\udfc7\u5321\udb11\udde2", "\u592c\u3ffc\u9b4d\u33c7\ubfad\u248e\u35df\u23c3", "\uda18\udd2a\ud89a\udc6e\ud917\uded5",
        17, 94962, 1292329458, 5079006810474553087L, -10682L, true, false, (char) 7393, (char) 62369,
        Double.longBitsToDouble(0x3fe8177df39ff6e5L), Double.longBitsToDouble(0x3fe3ac768d6f1a2cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.matchers.Same:same(\"\ud9e6\udc26\udb34\udc78\uda10\udc69\uda66\udc05\ud959\udc2b\ud827\ude6a\udb11\udde2\")\0121=java.lang.Boolean:true |this=org.mockito.internal.matchers.Same:same(\"\ud9e6\udc26\udb34\udc78\uda10\udc69\uda66\udc05\ud959\udc2b\ud827\ude6a\udb11\udde2\")\012",
        Z.run(T, 2, 2, 2, 2, "\ud9e6\udc26\udb34\udc78\uda10\udc69\uda66\udc05\ud959\udc2b\ud827\ude6a\udb11\udde2", "\u592c\u9aa6\u9b81\u33c7\u4268\u248e\u35df\ub09b", "\udb68\udf14\ud862\udf13\ud836\uddca\ud9fa\udfab\ud8f1\uded8\ud821\udf8e\ud961\uddf0\udaef\udc12\udab8\ude53\ud990\udc81\ud9d7\udee8\ud9d8\udedb",
        11, 66786, -1898861665, 1910471225915968879L, 53280L, false, false, (char) 14952, (char) 3203,
        Double.longBitsToDouble(0x3fe625e2e37cd174L), Double.longBitsToDouble(0x3fd8df9ccd46f72eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.mockito.internal.matchers.Same:same(null)\012",
        Z.run(T, 1, 3, 2, 2, "\ud9e6\udc26\ud8f7\udf4a\ud859\udecc\uda2b\ude38\ud959\udc2b\udb7a\ude61\uda70\udcfb", "\u592c\u3ffc\u4fb6\uaa52\u273d\u4aa2\u35df\u6c8c", "\udb68\udeca\ud862\udf13\ud900\udf08\udbcc\uded5\ud8f1\uded8\ud82f\ude7c\ud847\uddc3\ud891\udeb3\udab8\ude53\ud990\udc81\ud9d7\udee8\ud9d8\udedb",
        11, 66786, -1743638113, -1418016041059340059L, 53280L, false, false, (char) 31475, (char) 46490,
        Double.longBitsToDouble(0x3fe625e2e17cd174L), Double.longBitsToDouble(0x3fd8df9d4d25b52eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.mockito.internal.matchers.Same:same(\"\ud9e6\udc26\udb34\udc78\udb15\ude6c\udae3\udc9e\udbc2\udc6d\u5321\udb11\udde2\")\012",
        Z.run(T, 1, 3, 2, 2, "\ud9e6\udc26\udb34\udc78\udb15\ude6c\udae3\udc9e\udbc2\udc6d\u5321\udb11\udde2", "\u592c\u3ffc\u9b4d\u33c7\ubfad\u248e\u31b9\u733e", "\udb68\udf14\ud862\udf13\ud836\uddca\udbcc\uded5\ud8f1\uded8\ud82f\ude7c\ud961\uddf0\ud8ff\udc1a\udab8\ude53\ud990\udc81\ud9d7\udee8\ud9d8\udedb",
        11, 66786, -1869763681, 1910497867598105967L, 53280L, false, false, (char) 31475, (char) 3203,
        Double.longBitsToDouble(0x3fe625e2e47cd174L), Double.longBitsToDouble(0x3fd8df9ffe0af72eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.matchers.Same:same(null)\0121=void |this=org.mockito.internal.matchers.Same:same(null)\012",
        Z.run(T, 2, 1, 1, 0, "\ud9c2\udf5d\udb3c\udc31\uda10\udc69\ud8e6\udc05\ud959\udc2b\u5321\ud93d\udd38\ud838\udf75\udafb\udc65\ud8e7\ude85\udaa3\udfc4\ud9a3\udf6b\ud9af\uddcc\uda1d\udfce\ud8cc\udc95\ud8ef\udc9e\uda58\ude70\uda00\udd88\uda1d\udd6d\udb68\udf14\udac9\udfdb\uda5e\uddbe\udbcc\uded5", "\u2553\u7c36\u3931\u5d71\u9f97\u3d87\u4ed0\u8837\u5d7a\u5ae1\u45d2\u35aa\ub955\u5409\u7f8e\u4c61\ubf99\u6d5f\uac08\u55c8\ua9dd\u86de\u294e\u037a\u72c4\ube72\ua3fd\u8296\u8100\u97cc", "\udb54\udd09\udb37\udc2e\udba6\udcb5\ud94b\udead\ud9a0\udff6\udae7\udce1\udac9\udf1b\ud847\udfc8\ud9f9\udc23\ud8c3\udcfe\ud800\udf3b\uda27\uddf8\uda74\udcb7\ud940\udc07",
        39, 87024, 756159215, 3957124889977889296L, 21185L, false, true, (char) 54092, (char) 15789,
        Double.longBitsToDouble(0x3fdd7867eeec92daL), Double.longBitsToDouble(0x3fcfd51a081005ecL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.mockito.internal.matchers.Same:same(null)\0121=java.lang.Boolean:true |this=org.mockito.internal.matchers.Same:same(null)\012",
        Z.run(T, 2, 2, 2, 2, "\uda27\udc46\uda91\udfb4\udb2c\udec2\ud92f\udfe9\ud820\udd7f\uda3f\udc4c\udb1d\udfc1", "\u592c\u3ffc\u9b4d\u33c7\u1fad\uc24a\ua382\uc314\u06e6\u5b7e", "\ud821\udd5f\udab1\udd1e\ud9b5\uddb3\udaf2\udc4c\ube3b\udaee\udf56\udb8d\udf8e\ud990\udc62\ud868\udcf0\udbff\udc06\ud8ee\udf82\uda80\udea6\ud993\udf0e",
        48, 63306, -874691986, -2467139907649690972L, 59186L, true, false, (char) 2996, (char) 64395,
        Double.longBitsToDouble(0x3fd33261a0fafd8eL), Double.longBitsToDouble(0x3fec102e3fbbe3e5L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.mockito.internal.matchers.Same:same(null)\0121=new org.mockito.internal.matchers.Same:same(null)\012",
        Z.run(T, 2, 3, 3, 2, "\ud9e6\udc26\udb34\udc78\ud80e\udc08\uda66\udc05", "\u8fcc\uc0cf\u3b56", "\ud8c8\uddcc",
        32, 92538, -655844637, 1615705175720432247L, 3607L, true, false, (char) 29181, (char) 44297,
        Double.longBitsToDouble(0x3fdf243d33929a0eL), Double.longBitsToDouble(0x3fe371e18c95b815L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 2, "\ud9e6\udc26\udb34\udc78\uda10\udc69\uda66\udc05\ud959\udc2b\u5321\udb11\udde2", "\u592c\u3ffc\u9b4d\u33c7\ubfad\u248e\u35df\ub95e", "\udb68\udf14\ud862\udf13\ud836\uddca\udbcc\uded5\ud8f1\uded8\ud82f\ude7c\ud961\uddf0\udaef\udc12\udab8\ude53\ud990\udc81\ud9d7\udee8\ud9d8\udedb",
        11, 66786, -1898861665, 1910471225915968879L, 53280L, false, false, (char) 31475, (char) 3203,
        Double.longBitsToDouble(0x3fe625e2e47cd174L), Double.longBitsToDouble(0x3fd8df9ffd46f72eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.matchers.Same|describeTo|org.hamcrest.Description|new:org.mockito.internal.matchers.Same:java.lang.Object",
    "M|org.mockito.internal.matchers.Same|appendQuoting|org.hamcrest.Description|new:org.mockito.internal.matchers.Same:java.lang.Object",
    "M|org.mockito.internal.matchers.Same|matches|java.lang.Object|new:org.mockito.internal.matchers.Same:java.lang.Object",
    "C|org.mockito.internal.matchers.Same|<init>|java.lang.Object",
    "M|org.mockito.internal.matchers.Same|describeTo|org.hamcrest.Description|new:org.mockito.internal.matchers.Same:java.lang.Object",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
