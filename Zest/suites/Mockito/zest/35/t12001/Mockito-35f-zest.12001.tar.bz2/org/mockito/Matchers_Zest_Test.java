package org.mockito;
import org.junit.Test;
import static org.junit.Assert.*;
public class Matchers_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 11, 4, 4, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -8142902566705002067L, -31597L, false, false, (char) 6734, (char) 28806,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=null\012",
        Z.run(T, 2, 13, 12, 4, "\u93d9\ud81c\uddf0", "\u5c09\u1fb2\u9797", "\000\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 5781, -765984768, 71663153618782637L, -31597L, false, false, (char) 57448, (char) 28806,
        Double.longBitsToDouble(0x3fc24580045814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 11, 4, 4, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -8142902566705002067L, -31597L, false, false, (char) 6734, (char) 28806,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 25, 4, 4, "\u93d9\ud8b1\udf7a\udb07\udd71\u697c", "\u9797\u1c62\ud67c", "\udb83\udfc2",
        9, 21295, -1575041030, -9154228223089162696L, 47277L, false, false, (char) 31413, (char) 34600,
        Double.longBitsToDouble(0x3fd42d25835b1dfcL), Double.longBitsToDouble(0x3fcf45ddcccd4038L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 4, "\u93d9\udbd5\udf4c", "\u93d0\u5ef5\u4ea9", "\ud800\ude6c\udbc2\udc1f\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud9df\udebe\ud82c\udfc9\udbc4\udf6e\udbd6\udcb8\ud954\ude4c\udb5d\udebc\uda40\udf29",
        49, 74168, -765932475, -8142902566705002067L, -31597L, false, false, (char) 6734, (char) 28806,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 0, 4, "\ud9a9\udeda\udbd5\udf4c", "\u5bf5\u1fb2\u9797", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\ud93c\udf88\ud8b3\udd48\ud8bd\ude76\udbd7\udccd\udbca\udc6c\ud8a4\udd83\ud935\uddad\udbbc\ude50\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -8142902566706683177L, -31597L, false, false, (char) 11342, (char) 28806,
        Double.longBitsToDouble(0x3fc2459440a6c760L), Double.longBitsToDouble(0x3fcb00b8a2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Byte:0\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 17, 4, 4, "\udaa1\udd69\udbd5\udf0f", "\u5c3f\u1fb2\u9797", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\ud8ca\ude26\udb12\udecb\uda0f\udc0a\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86\ud969\udf65\ud86f\udf34\ud8d2\udd94\ud811\udeaf\u84a0\ud9d1\udfbc\ud869\ude78\ud9cb\udfcb\udac7\udd70\uda46\udd9a\udbc8\udcdf\ud964\udd70\udba4\udf1f\ud931\udf36",
        3, 57689, -70308864, -2825322567008652633L, 38169L, false, false, (char) 24623, (char) 43700,
        Double.longBitsToDouble(0x3fddeac65e76ffceL), Double.longBitsToDouble(0x3fe6ea741f6581ceL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Short:0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 8, 3, 1, "\udbff\udcd8\udbd5\udf4c", "\u5538\u80d0\u0a55", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\uda49\ude37\ud8a8\udeed\udaab\udfc0\udbd6\udfcc\ud86f\udf34\ud8d2\udd94\udaf3\udcee\u80da\ud805\udece\ud87d\udd8c\ud9cb\udfcb\udac7\udd70\udb9f\ude08",
        16, 18070, -1628153640, -872334276990222570L, -40655L, true, false, (char) 19291, (char) 64226,
        Double.longBitsToDouble(0x3fc735714c8f9654L), Double.longBitsToDouble(0x3feb795f9a469a63L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 16, 4, 7, "\u93d9\udbd5\udf4c", "\u2de9\ua28c\u104c", "\udbfb\udc2f\udbc2\udc72\udb83\udfc2\ud951\udc3b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udb60\udebf\ud97f\ude22\udb55\udfa9\ud81a\ude06\ud969\udf65\ud86f\udf34\ud8d2\udd94\uda13\udf56\uac71\ud9dd\udfc1\ud8a4\udd23\ud9cb\udfcb\udb53\udc55\ud96d\udd8d\udafd\udea2\ud964\udd70\udba4\udf1f\udbca\udf4f\ueb84",
        44, 49661, 475455393, -3097893387611534451L, -51197L, true, true, (char) 5618, (char) 27621,
        Double.longBitsToDouble(0x3fe440b748f71023L), Double.longBitsToDouble(0x3fe592ebc17255f6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Float:0.0\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 4, 20, 4, "\udbc2\udcdf\udbd5\udf4c", "\ud391\u1f96\u9797", "\udbfa\udfe8\udbc2\udc72",
        28, 35801, 941272063, -5173505246530001425L, 31311L, true, true, (char) 63794, (char) 12949,
        Double.longBitsToDouble(0x3fead20399f6f595L), Double.longBitsToDouble(0x3fc9b0398815bfa4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Character:\000\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 15, 4, 4, "\udbf3\uded9\ud81c\uddf0", "\u93bd\u1f47\u22f6", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\000\000\000\000\ud9be\udedf\ud82c\udfa6\uda3a\udcef\udbbb\udd8c\ud933\udf4c\udb5d\udebc\u00f6",
        -5, -1000, -771751936, 284255226112L, -31597L, false, false, (char) 229, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcb00a0000003d0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 11, 5, 15, "\ud987\udd29\udbd5\udeee", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud977\udd0c\uda3a\udc60\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -8142902566705002067L, -31597L, false, false, (char) 6734, (char) 28806,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfb2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Character:\000\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 2, 4, 4, "\u93d9\udbd5\udf4c\ud81a\udf1a\u697c\ud99a\udda7\ud838\ude1b", "\u0aef\ua1ac\u7a50\u0be7\ua86d\ud738\u90b5\uabf3\ub304\u9b39\u7846\ud173\ua853\u6b01\u5c63", "\ud8d2\udd94\ud854\ude99\uac71\udafe\uddb1\ud836\udf84\ud9cb\udfcb\uda9f\udef1\ud96d\udd8d\udbc8\udcdf\udbab\udf14\ud9ab\udd07\udb8a\udd63\uda41\udf27\ud820\udfa7\ud92a\udd78\ud824\udd66\ud86f\udf84\ud844\udedd\uda2b\udd10\ud9d8\udc30\ud89e\udfa7\udac5\ude08\udb01\ude40\ud9c3\udebb\uda7d\udfe1\ue88a\ud928\udd48\udaba\udd1a\udb5b\uddbf\udb90\udf24\udb45\udd23\ud99e\ude39\udbf2\uddc6\ud803\uddb9\ud919\udd08\udaf4\udf9e\udb63\ude8f",
        34, 35459, 2021517150, 6259680220008415643L, -36466L, false, true, (char) 45540, (char) 18106,
        Double.longBitsToDouble(0x3fd17260c5a0c354L), Double.longBitsToDouble(0x3fcace5d5b14a11cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 5, 5, 2, "\u93b6\udbea\udf43", "\u1dd4\u07dc\u76f6", "\udbfa\udfe8\udbbe\udfec\ud86e\udf15\uda99\udd8e\ud89b\udc6d\udae0\ude71\ud96f\ude72\ud854\udd5a\ud821\udc02\uda64\udf67\ud806\udd0e\uda22\udd91\udb35\udf15\uda9e\udfd4",
        48, 83629, -2040032546, 4009738032362114809L, -21476L, false, true, (char) 27461, (char) 49965,
        Double.longBitsToDouble(0x3fe9046931160517L), Double.longBitsToDouble(0x3fcb00bfa80e7bd0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Byte:0\012",
        Z.run(T, 2, 19, 14, 4, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -8142902566705002067L, -31597L, false, false, (char) 6734, (char) 28806,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 9, 3, 4, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\uda21\udf03\udbfe\udf34\uda9b\ude97\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -4968621551106750145L, -31597L, false, false, (char) 40526, (char) 28806,
        Double.longBitsToDouble(0x3fc24594585814a8L), Double.longBitsToDouble(0x3fc0e0b562667bd0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 11, 14, 4, "\uda83\udc57\ud8a0\udc0b", "\u5d16\u1fb2\u9797\u1c62\ud6ef\u47d8#\ua837\u74fd\u1067\u1ea4\u7cf0\u4124\u9b39", "\ud933\udf4c\udb59\udf2b\ud81a\ude86\ud969\udf65\ud86f\udf34\ud84a\udd90",
        23, 80486, 196416762, 4210998091883535458L, -10499L, true, false, (char) 48833, (char) 24277,
        Double.longBitsToDouble(0x3fc333de9f97cc40L), Double.longBitsToDouble(0x3fdf881c6ced5364L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 6, 4, 21, "\u93d9\udbd5\udf4c", "\u5c09\u1453\u3830", "\udbfa\udfd8\udbc2\udc72\ud909\udfc5\udb87\udfe0\ud895\udd1e\ud898\udc6f\ud96f\uddd1\ud8ec\udd25\ud82c\udfa6\uda3a\udcef",
        14, 97936, -174760102, -9093636302919051059L, -47707L, false, true, (char) 6315, (char) 25576,
        Double.longBitsToDouble(0x3fe99a80766c3b19L), Double.longBitsToDouble(0x3fba4e6bd7666cd0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 7, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\uda2a\uddf6\ud8e2\udce5\u76d2\ud847\udc20\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -8142902566705002067L, 93760L, false, false, (char) 6734, (char) 28806,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 11, 12, 10, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u1421\u9d7f\ud67c\u5bb1\u9fc8\ua837\u482a\u086d\u6c44\u216c\u5329\u4f10\u828d\u9f58\u837e\u84f3\u5c63\u8126\ubb3c\uba44\u7845\u3c5c\u5d81\u5742\u4324\u045b\uc7d2\u1cb2\uaedd\u8f69\u5ead\u7dfd\u95e8\u7c22\u585f\u799a\u5252\ua7f5\u6997\u97f7\uaa3f\ua161\u40e8\ub388\u9438\ub178\u69af\u7ad3\u3908\u092a\u6b7d\u7420\u10b4\u09f1\u3f44\u2da5\u1596\u0330\u393b\u5eb5\u16ef\u13b7\ud08d\u1b5e\u4ad0\uce98\u0d11\u7a47\uc95c", "\udb85\udce4\u5b5c\ud88b\ude17\udb02\udc35\ud9eb\udeba\ud93b\udcd7\udaf4\udd57\udb80\ude7e\udbf5\ude2b\ud950\ude6e\ud9ca\udfdb\udb45\ude31\ud8aa\ude86\uf478\ud84d\udd13\uda94\ude5b\u514a\ud9d9\udc50\ud8d9\udf75\ud8ea\udc67\ud9fb\udefb\ud920\uddb1\ud870\udfb1",
        56, 44298, -695665563, 5197871034019210774L, 52396L, true, false, (char) 3392, (char) 7227,
        Double.longBitsToDouble(0x3fe05faeb836ca9bL), Double.longBitsToDouble(0x3fe823f66fabe2dcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 25, 6, 4, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud945\udcfe\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -8142902566705002067L, -31597L, false, false, (char) 6734, (char) 28806,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Byte:0\012",
        Z.run(T, 2, 7, 1, 4, "\u93d9\udbd5\udf4c", "\u5c09", "\udbcc\udc74\ud8cc\udced\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\ud807\udca4\ud814\udf35\ud901\uddbc\ud82c\udfa6\uda3a\udcef",
        14, 97936, -174760102, 1627791739476925980L, -4173L, false, false, (char) 23361, (char) 46711,
        Double.longBitsToDouble(0x3fdc999a05d8c8f6L), Double.longBitsToDouble(0x3fc24594402e74a8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 13, 20, "\u93d9\udbd5\udf4c\ud81a\udf1a\uda08\udc14\udbb3\udea5\udac8\udf53\udb1e\udcb1\udbcc\udc74\ud8cc\udced\ud974\udcce\udbc2\udc7b\udb83\udfc2\uda77\ude1b\ud895\uddf9\udaa0\ude71\ud868\udde0\ud912\udd05\ud82c\udfa6\uda16\udeef\ud825\udd34\ud933\udf9c\ud9da\ude7b\ud9f7\udcf7\uda9f\ude30\u6258\ud8aa\udd0d\uda83\udfed\ud9c3\udd46\udb9e\udd22\ud9d9\udffe\udadf\udf36\u91db\ud96d\udcf2\udbc8\udcdf\uda4c\udd64\udba4\udf1f\udad2\ude86\ud839\udc14\ud9aa\udd9c\udb8e\udfc8\udb31\udcea\u97ea\ud9f3\udf09\udbd2\udd9c\ud9a3\udfe5\ud98b\udebe\udbf4\ude9a\ubb74\uda7c\udf13\udb95\uddd0\ud800\udf73\udb0b\ude4f\udbaa\ude51\uda5d\udcc3\uda96\ude0f\uda16\udc3d\ud98b\udf01\ud87e\udc4e\uda6b\uddb1\ud99a\udebf\ud81d\udffb\u21e4\ud861\udce3\udac5\udde2\ud890\uddf1\uda7f\udd62\uda77\udf8d\udb10\udc6d\ud979\ude93\u2aa0", "\uab04\ub909\u6b8b\uc6d1\u6398\u3989\uba27\u95da\u4999\u8450\u7ec2\u38a4\u76b4\ua1e9", "\uda51\udf00\uda4b\udc3b\ud9e7\ude8d\uda9a\udc9e\udb4e\ude5d\uda4d\udf1c",
        45, 65406, 976848154, 692806026778965860L, 86131L, true, true, (char) 41896, (char) 32136,
        Double.longBitsToDouble(0x3fe1f3a460e87f49L), Double.longBitsToDouble(0x3fbc57b93c77ee58L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Byte:0\0121=null\012",
        Z.run(T, 2, 17, 25, 1, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797\u1c62\u2e18\u1122#\u4382\u8230\u8004\u14d5\u3ed4\uc5f7\u9b39\u7d80\uc939\u27e3\u1eeb\u5c63\ud570\u1a48\u4591\u8afa\u98ee\ubbdb\u2ef0\u9f4e\u6cae\u599a\u797b\uc87a\u967f\u6065\u1d03\u67b3", "\ud8bd\udfb8\ud8eb\udf11\udaaf\udfa3\ud95f\ude5b",
        6, 12999, 557114158, 1338256987474656522L, -49607L, false, false, (char) 11367, (char) 54735,
        Double.longBitsToDouble(0x3fef9b1485502321L), Double.longBitsToDouble(0x3fed60183c16751cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 11, 10, 17, "\u9361\udb38\udff0\ud8d1\uddcc\ud96b\udc32\ud9b7\udd5f\ud838\ude1b\udb1e\udcb1\udbcc\udc74\ud8cc\udced\udbfa\udfe8\udbc2\udc72\ud8a7\udc94\ud9df\uddc1\ue7b0\udaae\uddf8\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\ud84a\ude06\ud933\udf79\udb5d\udebc\ud81a\ude86", "\u9c55", "\udafe\uddb1\ud869\udea5\ud9cb\udfcb\udac7\udd70\ud96d\udd8d\udbf8\ude18\ud99a\udf04\u21ed",
        32, 87047, -69430990, 6309214605586249376L, 92969L, true, false, (char) 22704, (char) 51622,
        Double.longBitsToDouble(0x3fcf4bae39020bb4L), Double.longBitsToDouble(0x3fea5070758a539dL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=null\012",
        Z.run(T, 2, 9, 10, 22, "\u93d9\udbe0\ude6c", "\u5c09\u1fb2\ua81a\ua77b\ud67c\u4336\u30c1\ua837", "\uda84\uddf6\ud96f\ude72\ud8ec\udd25\ud9e9\udca4",
        -1, 57260, -102148770, 1085504591309510796L, -29845L, true, false, (char) 43676, (char) 6315,
        Double.longBitsToDouble(0x3fcf45ddcccd4038L), Double.longBitsToDouble(0x3fe5069b5721f37cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Character:\000\0121=java.lang.Character:\000\012",
        Z.run(T, 2, 18, 2, 4, "\udb17\udeae\u0bb9", "\u5c09\u1fb2\u9797", "\udb0c\udff1\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3e\uddef\udbd6\udc8c\ud933\udf4c\udb9d\udc1b\u878f",
        22, 72573, -765932475, -8142902566705002067L, 33939L, true, false, (char) 6719, (char) 28806,
        Double.longBitsToDouble(0x3fc245944d6014a8L), Double.longBitsToDouble(0x3fcb157cc2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 16, 4, "\ud968\udeba\udbd5\udf4c", "\u7bec\u4da7\u1a16", "\ud81e\ude48\udb04\udf4d\udaf3\udfae\udaaa\udc1b\uda07\uddb1\uda3f\udc19\udafa\ude37\ud8ec\udd25\ud93f\udf91\ud9ea\udc9a\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86\udaf2\udc0a\ud92e\ude23\uda27\udf99",
        -2, 27364, -293266585, 1114935054891295960L, -10636L, false, false, (char) 48703, (char) 15457,
        Double.longBitsToDouble(0x3fef693b03ed5339L), Double.longBitsToDouble(0x3fcadfa27d3a827cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 7, 7, 4, "\u93d9\ud902\udc47", "\u90c7\u6c2e\u4154\u1c62\ud67c\u47d8\u39cd\u3273\u74fd\u2834\u8fd2\u3f5d\ua030", "\udb3a\udd9d\ud933\udf4c\udb5d\udebc\ud934\ude2c\ud916\udd27\ud888\ude4c",
        43, 19498, -1015772755, 5768605644646583091L, 76724L, false, true, (char) 42267, (char) 42079,
        Double.longBitsToDouble(0x3fee6bca39baf4e4L), Double.longBitsToDouble(0x3fd4a60ba0bde474L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 9, 12, 25, "\u93d9\udb9e\uddd1", "\u5c09", "\udbe4\udf61\ud927\udd11\000\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef",
        14, 97936, -174760102, -9093636302919051059L, -100000L, false, true, (char) 35498, (char) 55430,
        Double.longBitsToDouble(0x3fcb5648c58b38c0L), Double.longBitsToDouble(0x3fba403bd7666cd0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 19, 3, 4, "\u93d9\ud81c\uddf0", "\u5c09\u1fb2\u9797", "\000\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 5781, -765984768, 71663153618782637L, -31597L, false, false, (char) 57448, (char) 28806,
        Double.longBitsToDouble(0x3fc24580045814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Byte:0\0121=java.lang.Byte:0\012",
        Z.run(T, 2, 17, 1, 16, "\u93d9\ud81c\uddf0", "\u5c09\u1fb2\u9797", "\000\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\udadb\udffe\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 5781, -765984768, 71663153618782637L, -31597L, false, false, (char) 57448, (char) 28806,
        Double.longBitsToDouble(0x3fc24580045814a8L), Double.longBitsToDouble(0x3fb45a6c04ccf7a0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 22, 4, "\u93d9\ud81c\uddf0", "\u2700\u1fb2\ud052", "\000\ud9cf\udd14\udb84\udc20\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 5781, 1196949504, 71523021720816045L, -31597L, false, false, (char) 57448, (char) 33137,
        Double.longBitsToDouble(0x3fc24580045814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 13, 4, "\u93d9\ud81c\uddf0", "\u5c09\u1fb2\u8e84", "\000\udbc2\udc72\udb9d\uddc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud91d\udfbd\udbee\udc4e\ud9d3\ude46\ud981\ude22\ud98b\udd1e\udb5d\udebc\ud81a\ude86\ud969\udf65\uda6c\ude13\ud89f\udd4f\u1151\uac71\udafe\uddb1\ud869\udea5\ue462\udac7\udd70\udb33\udc88\udbc8\udcdf\ud964\udd70\udba4\udf1f\udad4\udf47\udaff\udce9\ud9df\ude72\uee61\udba1\udc76\udbb9\ude6a\ud9da\udc99",
        23, 25630, -1172148754, 3931041382110800812L, 79219L, false, true, (char) 19263, (char) 858,
        Double.longBitsToDouble(0x3fea10cace787ff0L), Double.longBitsToDouble(0x3fd48ba3a4a4c77eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 7, 9, 4, "\ud805\udfe9\ud81c\uddf0", "\u5c09\u1fb2\u45c9", "\000\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud9ec\ude51\udab3\udf97\ud96f\ude78",
        54, 65077, -1916549205, -3512126633828719744L, -40106L, true, false, (char) 43502, (char) 248,
        Double.longBitsToDouble(0x3fd423d5835a01fcL), Double.longBitsToDouble(0x3fcf45ddc4cd4038L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 11, 11, 20, "\u93d9\ud94a\udce7\uda50\udef6\udb4d\udd20", "\u9403\u3ddd\ua687", "\udb83\udfc2",
        9, 2503, -1575041030, -9154228223089173232L, -80252L, false, true, (char) 46329, (char) 32479,
        Double.longBitsToDouble(0x3fcd8df9367be11cL), Double.longBitsToDouble(0x3fd42d2b535b1cacL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 25, 12, 20, "\udb37\udf41\ud8c0\udcb7\udb07\udd71\u697c\ud855\ude44\uda1a\ude4c\ud864\ude8f\udbcc\udc74\ud8cc\udced\udbfa\udfe8\udbc2\udc72\uda53\udc2a\udbec\udc67\uda8f\udec9\ud83b\udfd0\udbe6\udca8\udbd8\udf3e\ud888\udd40\uda26\udc96\uda24\udc72", "\ua2fc\u752f\u4049", "\uac71\udafe\uddb1\ud9bd\udd4f\ud81b\udff3\ud9c6\udcd0\udb7f\udff4\ud807\ude92\ud930\udc85\ud8d6\ude2a\ud8e1\udc66\ud97c\udd82\ud85a\udfb9\ud891\ude4a",
        51, 61628, 758186653, 3038403420123808156L, -70364L, true, false, (char) 11318, (char) 2814,
        Double.longBitsToDouble(0x3fe3a0362b13349aL), Double.longBitsToDouble(0x3fe363854dd48f30L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 22, 6, 20, "\ud958\udfd2\ud8b1\udf7a\udb07\udd71\u697c\ud99a\udda7\ud844\udcfb\udb89\ude70\udaf0\uddef\ud8c3\udf16\ud996\udd79\ud9b8\udca5\udb4b\udc8d\udaaa\udc37\ud895\uddf9\udaa0\ude71\udb6d\udd0f\ud8ae\ude3b", "\u8231\u1093\u7347\u7739\u2d8b\u5c0d\u36c5", "\udafe\uddb1\ud8e4\udf34\udb4c\ude71\ud922\udc1a\u0f9e\ud92d\udd77\ud808\udd20\ud9c2\udc56",
        5, 44677, -1451047666, 1180770670940563770L, -49380L, false, false, (char) 12377, (char) 58912,
        Double.longBitsToDouble(0x3fe78451a17866f7L), Double.longBitsToDouble(0x3fe598cabc79224aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Short:0\0121=java.lang.Short:0\012",
        Z.run(T, 2, 8, 24, 10, "\000", "\u1d37", "",
        7, 51181, -1159741825, -7254885191657717706L, -47647L, true, false, (char) 20474, (char) 18445,
        Double.longBitsToDouble(0x3fe1c407a83408eaL), Double.longBitsToDouble(0x3e3cda4800000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 4, "\u93d9\000", "\u93d0\000\000", "",
        -5, -1000, 0, 4406996533754823935L, -100000L, false, false, (char) 0, (char) 44250,
        Double.longBitsToDouble(0x3fe800000000cf14L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 9, 9, 4, "\ud9a9\udeda\udbd5\udf4c", "\u8737\u1741\u9797", "\ud9c9\ude36\ud88c\ude72\udb84\udc07\ud93c\udf88\ud90f\uddd3\ud8bd\ude8a\udbd7\udccd\ud94a\udee1\uda23\udff9\udb4e\udf93\udbbc\ude50\ua448\udbbe\udc40\u9831",
        55, 72573, -765960891, -8142902566270475561L, -85839L, false, false, (char) 18074, (char) 27675,
        Double.longBitsToDouble(0x3fe972b5176c0eefL), Double.longBitsToDouble(0x3fc8b1af0eb44480L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 10, 4, "\udaa1\uddd1\udbd5\udf0f", "\u1d59\u53bf\u9797", "\udbfa\udfd1\ud8b5\udc0b\ud85c\udd34\ud99a\ude80\ud895\uddf9\ud8ca\ude26\udb12\udecb\uda0f\udc0a\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86\ud969\udec2\ud86f\udf34\ud8d2\udd94\ud811\udeaf\udbef\udc27\udba1\ude77\ud869\udebf\u0807\uda14\udef1\ud8f8\udd2a\udbc8\udcdf\ud964\udd70\udba4\udf1f\ud931\udf36",
        3, 57689, -70308864, -2825322567008652633L, 38169L, false, false, (char) 24623, (char) 43700,
        Double.longBitsToDouble(0x3fddeac65e76ffceL), Double.longBitsToDouble(0x3fe6ea741f6581c6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Byte:0\0121=java.lang.Byte:0\012",
        Z.run(T, 2, 14, 14, 4, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\ud9e3\udc52\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -8142902566705002067L, -31597L, false, false, (char) 6734, (char) 28806,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 9, 9, 4, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797\u1c62\ud67c\u47d8\u1a62\u3fbb\u3b79\u6fc2\u90b5\u3f5d\ua030\u9b39\u7846\ud173\u27e3\u6b01\u5c63\ud570\u1a48\u3629\u874c\u98de\ubbdb\u5880\ud100\uc8ad\uc7d2\u8eb1\u44ce\u7582\uc6eb\u5612", "\ud851\ude2d\ud89e\udf9e\ud84c\ude9e\u68bb\ud9d0\udf61\ud981\udddf\ud9cf\udfa2\udb6c\udfcf\ud8dd\ude50\ud913\udd75\udb50\udcfd",
        43, 85185, 622239360, 6514759929731041148L, 10349L, true, false, (char) 44188, (char) 4638,
        Double.longBitsToDouble(0x3fe6807beccf8bf8L), Double.longBitsToDouble(0x3fdb240d1d7609a4L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 11, 4, 4, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\udb20\udf6e\udb84\udc9a\uda8f\ude8f\ud895\uddca\ud91e\udf90\ud984\ude9f\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\ud9ec\udef7\ud933\udfae\udb5d\udebc\ud8ce\udca2",
        55, 72573, -760519403, -8142902566705002067L, -31597L, false, false, (char) 6734, (char) 48005,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Character:\000\0121=java.lang.Character:\000\012",
        Z.run(T, 2, 15, 15, 16, "\u93d9\udbd5\udf4c", "\u5c09\u1fb2\u9797", "\udbfa\udfe8\udbc2\udc72\udb83\udfc2\udaaa\udc1b\ud895\uddf9\udaa0\ude71\ud96f\ude72\ud8ec\udd25\ud82c\udfa6\uda3a\udcef\udbd6\udc8c\ud933\udf4c\udb5d\udebc\ud81a\ude86",
        55, 72573, -765932475, -8142902566705002067L, -31597L, false, false, (char) 6734, (char) 28806,
        Double.longBitsToDouble(0x3fc24594445814a8L), Double.longBitsToDouble(0x3fcb00bfa2667bd0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.Matchers|eq|boolean|static",
    "M|org.mockito.Matchers|eq|byte|static",
    "M|org.mockito.Matchers|eq|char|static",
    "M|org.mockito.Matchers|eq|double|static",
    "M|org.mockito.Matchers|eq|float|static",
    "M|org.mockito.Matchers|eq|int|static",
    "M|org.mockito.Matchers|eq|java.lang.Object|static",
    "M|org.mockito.Matchers|eq|long|static",
    "M|org.mockito.Matchers|eq|short|static",
    "M|org.mockito.Matchers|isA|java.lang.Class|static",
    "M|org.mockito.Matchers|same|java.lang.Object|static",
    "M|org.mockito.Matchers|any||static",
    "M|org.mockito.Matchers|any|java.lang.Class|static",
    "M|org.mockito.Matchers|anyBoolean||static",
    "M|org.mockito.Matchers|anyByte||static",
    "M|org.mockito.Matchers|anyChar||static",
    "M|org.mockito.Matchers|eq|boolean|static",
    "M|org.mockito.Matchers|eq|byte|static",
    "M|org.mockito.Matchers|eq|char|static",
    "M|org.mockito.Matchers|eq|double|static",
    "M|org.mockito.Matchers|eq|float|static",
    "M|org.mockito.Matchers|eq|int|static",
    "M|org.mockito.Matchers|eq|java.lang.Object|static",
    "M|org.mockito.Matchers|eq|long|static",
    "M|org.mockito.Matchers|eq|short|static",
    "M|org.mockito.Matchers|isA|java.lang.Class|static",
    "M|org.mockito.Matchers|same|java.lang.Object|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
