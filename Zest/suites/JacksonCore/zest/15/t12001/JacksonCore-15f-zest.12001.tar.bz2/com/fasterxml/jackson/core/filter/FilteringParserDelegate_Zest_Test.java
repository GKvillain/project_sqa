package com.fasterxml.jackson.core.filter;
import org.junit.Test;
import static org.junit.Assert.*;
public class FilteringParserDelegate_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 7, "\ud9cf\udfc0\uda34\udc5c\udbac\udc6a\ud9c9\udd93\udb14\udd53\udb24\uddeb\ud8ce\udd3e\ud8b1\uddaf\udac5\udd35\ud86f\udca6\udbf8\udceb\ud975\udc30\ue339\udbca\udfbd\uda7d\ude5d\ud8e5\udec8\u11a7\ud921\udfd8\udafa\udf32\udb57\uded2\uda99\udef3\ud8af\udf00\udb1e\udc96\ua680\ud9c3\udfc1\udad9\udd5a", "\u4fb1\u8956\ua44f", "\u6d8a\ud818\udf3e",
        32, 51410, -851702736, -8233845926419092421L, -42774L, true, false, (char) 36537, (char) 4505,
        Double.longBitsToDouble(0x3f9601ca6bf7eea0L), Double.longBitsToDouble(0x3fe32a92430f56adL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 3, 7, "\ud9cf\udfc0\uda34\udc5c\udbac\udc6a\ud8fe\udc6e\udb00\udc4a\udb3b\udcb8\ud8d0\udffe\ud8b1\uddaf\udac5\udd35\ud86f\udca6\udbf8\udceb\ud975\udc30\ue339\udbca\udfbd\uda7d\ude5d\ud8e5\udec8\u11a7\ud921\udfd8\udafa\udf32\uda1e\udc94\uda99\udf41\ud8af\udf00\udb1e\udc96\ua680\ud9c3\udfc1\udad9\udd5a", "\u7763\u8956\ua44f", "\u6d8a\ud818\udf3e",
        32, 51410, -851702736, -8233845926419092421L, -42774L, true, false, (char) 36537, (char) 4505,
        Double.longBitsToDouble(0x3f9601ca6bf7eea0L), Double.longBitsToDouble(0x3fe32a92430f56adL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 1, 1, 3, 7, "\ud9cf\udfc0\uda34\udc5c\udbac\udc6a\ud9c9\udd93\udb14\udd53\udb24\uddeb\ud8ce\udd3e\ud8b1\uddaf\udac2\udc6e\ud86f\udca6\udbf8\udceb\ud858\udd39\ue339\udbca\udfbd\uda7d\ude5d\ud8e5\udec8\u11a7\ud921\udfd8\udafa\udf32\udb57\uded2\ud86f\udefe\ud8af\udf00\udb1e\udc96\ua680\ud9c3\udfc1\udad9\udd5a", "\u81b9\ub959\ua44f", "\u6d8a\ud818\udf3e",
        32, 51410, -851702736, -8233845926419092264L, -42774L, true, false, (char) 36537, (char) 4505,
        Double.longBitsToDouble(0x3f9601cacf0b8ea0L), Double.longBitsToDouble(0x3fe32a92430f56adL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 2, "\udb4d\ude42\uda42\udd6a\udbac\udc6a\ud9c9\udd93\udb14\udd53\udb24\uddeb\ud8ce\udd3e\ud8b1\uddaf\udac5\udd35\ud86f\udca6\udbf8\udceb\ud975\udc30\ue339\udbca\udfbd\uda7d\ude5d\ud8e5\udec8\u11a7\ud921\udfd8\udafa\udf32\udb57\uded2\uda99\udef3\ud8af\udf00\u5343\ua680\ud9c3\udfc1\udad9\udda0", "\u8480\u469c\ua44f\ub0a6\u11e2\u6e19\u8377\ud22a\u1db5\u1805\ua152\u0272\u4957\u98e8\u690d\u8630\u8ebc\uc397\uc4e4\u7120\u1bde\u4fe3\u1f03\u6bde\u780b\u673f\u8dd5\u219a\u8c3a", "\udb81\uded3\udaa3\udd44\ud865\udd51\ud1d0\uda62\udf23\ud901\udeba\ud8d7\udfc9\ufd71",
        40, 81285, 1237103245, -4703423552638532899L, -30751L, true, true, (char) 48128, (char) 24403,
        Double.longBitsToDouble(0x3f8999926e010980L), Double.longBitsToDouble(0x3fa30767f6d023b0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 12, "\ud9cf\udfc0\uda34\udc5c\udbac\udc6a\ud9c9\udd93\ud93e\udd08\udb24\uddeb\ud915\udde2\ud8b1\uddaf\udac5\udd35\ud86f\udca6\udbf8\udceb\ud975\udc30\ue339\udbca\udfbd\uda7d\ude5d\uda96\udc12\u11dc\ud921\udfd8\udafa\udf32\udb57\uded2\uda99\udef3\ud8af\udf00\udb1e\udc96\udb91\ude92\ud9ba\udcce\udad9\udd8f", "\u4fb1\u8956\ua44f", "\u6d8a\ud818\udf3e",
        32, 51410, -851702736, -8233845926419092421L, -42774L, true, false, (char) 36537, (char) 4505,
        Double.longBitsToDouble(0x3fe8b00e56c1971eL), Double.longBitsToDouble(0x3febb619b30f56adL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 11, 5, 7, "\udaa9\udf92\uda34\udc36\udbac\udc6a\ud9c9\udd93\udb14\uddf5\udb24\uddeb\ud8ce\udd3e\ud8b1\uddaf\ud851\ude7c\ud978\uddfb\udb59\ude9a\ud982\uddaa\ue339\udbca\udfbd\uda7d\ude5d\ud8e5\udec8\udb6e\udec2\ud921\udfd8\udafa\udf32\udb57\uded2\uda99\udef3\ud8af\udf00\udb1e\udc96\ud82b\ude80\ud9c3\udfc1\udad9\udd5a", "\u4fb1\u8947", "\uda71\udd87\u6d8a\ud9aa\udefd\uda00\udd59\ud905\udce0\ud848\udd32\ud828\ude05\udbbb\udf52",
        10, 34302, -1094835983, 6700459022594258077L, 63058L, true, true, (char) 37332, (char) 27732,
        Double.longBitsToDouble(0x3fdd2bd472ff2b44L), Double.longBitsToDouble(0x3fdc8d0dd1d1e0ceL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 1, 5, 5, 7, "\udbc3\udc50\ud88e\udf43\udbac\udc7c\ud9c9\udd93\udae6\uddd4\ud973\udcb2\ud8ce\udd3e\ud8b1\udd89\udac5\udd35\udb75\udeeb\udb36\udd9a\ud975\udc30\udb0e\udcc5\ud8f6\udd58\uda7d\ude5d\ud8e5\udec8\udb24\udd57\udbad\udc51\ud947\udd4d\ud9e8\udf16\uda99\udee4\ud8af\udf00\udb1e\udc96\ud9a1\udcbb\uda12\udd9d\uda1c\udff9", "\ua999\u16cd\ua4ca", "\uda63\udd8a\ud818\udf3e",
        32, 69145, 973762153, 3734588993950329915L, -30998L, true, false, (char) 10519, (char) 55206,
        Double.longBitsToDouble(0x3fe1cb191b5fbf75L), Double.longBitsToDouble(0x3fe32a92400f56adL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 7, "\ud9cf\udfc0\uda34\udc5c\udbac\udc6a\ud9c9\udd93\udb14\udd53\udb24\uddeb\ud8ce\udd3e\ud8b1\uddaf\udac2\udc6e\ud86f\udca6\udbf8\udceb\ud858\udd39\ue339\udbca\udfbd\ud9cc\udc20\ud8e5\udec8\u11a7\ud8bc\udf2b\uda64\udd57\ud88c\udd9c\ud842\udc8c\ud8af\udf00\udb1e\udc96\ua680\udbbf\ude4e\udb76\udc75", "\u81b9\u7703\u08da", "\u6d8a\ud818\udf3e",
        3, 51410, -851702736, -8233845926419092264L, -42774L, true, false, (char) 36537, (char) 4505,
        Double.longBitsToDouble(0x3f9601cacf0b8ea0L), Double.longBitsToDouble(0x3fe32a92430f56adL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 1, 13, 7, "\ud9cf\udfc0\uda34\udc5c\udbac\udc6a\ud9c9\udd93\udb14\udd53\udad2\udf23\ud8ce\udd3e\ud8b1\uddaf\udad0\udf6e\ud86f\udca6\uda50\ude56\ud858\udcbe\ud86f\udcf4\ud8ef\udf87\uda7d\ude5d\ud8e5\udec8\udb01\udce4\ud8f5\uddcb\udafa\udf32\udb57\uded2\ud86f\udefe\ud9f8\udda4\udb1e\udc96\ua680\ud9c3\udfc1\udad9\udd5a", "\u81b9\ub959\ua44f", "\udbc7\uddd6\ud818\udf3e\uda00\uddaf\ud905\udce0\ud848\udd32\ud828\ude05\udbbb\udfef\ud942\udf1b",
        15, 24893, 1560072187, -1727358088808076237L, 19397L, true, true, (char) 42963, (char) 51000,
        Double.longBitsToDouble(0x3fe9308d072fdf90L), Double.longBitsToDouble(0x3fbd0df3b3a2d2c0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 13, "\ud9cf\udfc0\uda34\udc5c\ud9d7\udddf\ud9d0\udcd1", "\ubea3\uc6a0\u6941\u15fe\u3068\u10ee\u5d09\ub514", "\u11a7\ud921\udfd8\udafa\udf32\udb57\uded2\ud86f\udefe\uda61\uddf9",
        24, 38424, 772407776, -7074958045841965735L, -56812L, false, true, (char) 45025, (char) 55890,
        Double.longBitsToDouble(0x3fc1a095f70f32f0L), Double.longBitsToDouble(0x3fb7f3e8357d57b0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 2, "\udb4d\ude42\ud850\udc1f\udbac\udc6a\ud9c9\udd93\udb14\udd53\udb24\uddeb\ud8ce\udd3e\ud8b1\uddaf\ud86e\udfa7\ud8f0\ude5a\udbf8\udceb\ud975\udc30\ue339\udbca\udfbd\uda7d\ude5d\udb72\udccc\udbf2\udce7\ud921\udfd8\ud8cd\ude9b\ud8a3\ude7e\uda99\udef3\ud8af\udf00\u5343\ua680\ud9c3\udfc1\udad9\udda0", "\u8480\u469c\ua44f\ub0a6\u11e2\u6e19\u8377\ud22a\u1db5\u1805\ua152\u0272\u4957\u98e8\u690d\u8630\u8ebc\ubee5\uc4e4\u7120\u1bde\u4fe3\u1f03\u28e8\u780b\u673f\u8dd5\u219a\u8c3a", "\udb81\uded3\udaa3\udd44\ud865\udd51\ud1d0\uda62\udf23\ud901\udeba\ud8d7\udfc9\ufd71",
        40, 81285, 1237103245, -4703423552638532899L, -30751L, true, true, (char) 48128, (char) 24403,
        Double.longBitsToDouble(0x3f8999926e010980L), Double.longBitsToDouble(0x3fa30767f6d023b0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 5, 5, 11, "\udaa9\udf92\uda34\udc36\udbac\udc6a", "\u6a11\u9626\u11e1\u25ae\u2f31\ud536\u2946\u045a", "\udb7d\udfb2",
        44, 79113, 422399817, -7346650219423714483L, 27682L, false, true, (char) 53223, (char) 36654,
        Double.longBitsToDouble(0x3feaccee80715ca1L), Double.longBitsToDouble(0x3fd0adc795dda5faL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 2, 7, "\ud839\udf61\ud9c8\uddd6\udbac\udc6a\ud9c9\udd93\udbaf\uddea\udb24\udd7c\udab4\udcb2\ud8b1\udd01\udb9f\udf03\ud978\uddfb\udb59\ude9a\uda5a\udfad\ue339\udbca\udfbd\uda7d\ude5d\ud8e5\udec8\u843c\ud921\udfd8\udafa\udf32\uda78\ude41\uda99\udef3\ud8af\udf00\udba8\udd9a\ud822\ude54\ud9c3\udee8\udad9\udd5a", "\ucbe2\u8947", "\ud800\ude13\ud80b\udc6a\ud9aa\udefd\uda00\udd59\udb71\ude19\ud848\udd32\ud828\ude05\udbbb\udf52",
        10, 34302, -1715304008, -5765504745967313076L, -62052L, true, true, (char) 64621, (char) 3808,
        Double.longBitsToDouble(0x3fe876d65d57921dL), Double.longBitsToDouble(0x3faf7404d8faf7e0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 11, 12, 7, "\udaa9\udf92\uda34\udc36\udbac\udc6a\ud9c9\udd93\udb14\uddf5\udb24\uddeb\ud8ce\udd3e\ud8b1\uddaf\ud851\ude7c\ud978\uddfb\uda0d\ude19\ud982\uddaa\ue339\udbca\udfbd\uda7d\ude5d\ud8e5\udec8\udb6e\udec2\ud8a9\udfd8\udafa\udf32\udb57\uded2\udaa5\udef3\ud8af\udf00\uda89\uddcb\ud83d\udcd1\ud9c3\udfc1\udad9\udd5a", "\u4fb1\u8947", "\uda71\udd87\ud803\ude8a\ud9aa\udefd\ud94b\udd7d\ud908\udc60\ud848\udd32\ud828\ude05\udbbb\udf52",
        10, 34302, -1094835983, 6700459022594258077L, -57953L, false, false, (char) 2117, (char) 60741,
        Double.longBitsToDouble(0x3fea1d8956e40ffcL), Double.longBitsToDouble(0x3fcaa77972929aa0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 11, 11, 12, "\udaa9\udf92\uda34\udc36\udbac\udc6a\udb82\uddef\udb14\uddf5\udb24\uddeb\ud8ce\udd3e\ud8b1\uddaf\ud851\ude7c\ud978\uddfb\udb59\ude9a\ud982\uddaa\ue339\udbca\udfbd\uda7d\ude5d\ud8e5\udec8\udb6e\udec2\ud921\udfd8\udafa\udf32\udb57\uded2\uda99\udef3\ud8af\udf00\udb1e\udc96\ud82b\ude80\ud9c3\udfc1\udad9\udd5a", "\u4fb1\u8947", "\uda71\udd87\u6d8a\ud9aa\udefd\uda00\udd59\ud905\udce0\ud848\udd32\ud828\ude05\udbbb\udf52",
        10, 34302, -1094835983, 6700459022594258077L, 63058L, true, true, (char) 37332, (char) 27732,
        Double.longBitsToDouble(0x3fdc0bd472ff2b44L), Double.longBitsToDouble(0x3fdc8d0dd1d1e0ceL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 1, 1, 15, "\ud9cf\udffc\uda34\udc5c\ud9e3\udce5\ud9c9\udd93\udb14\udd53\ud90a\udfd9\ud8ce\udd3e\udbe8\udc86\udae2\udd2e\udbc9\uddfa\udbef\udcd0\ud858\udd39\ue339\udbca\udfbd\ud9cc\udc20\ud8e5\ude52\u11a7\ud8bc\udf2b\ud961\udc95\ud807\udde6\ud834\udf51\ud8af\udf00\udb1e\udc96\ua680\udbbf\ude4e\udb14\ude45", "\u1677\u4411\ua2b5\u827c\ud3b3\ubd44\u823a\u6dba\u1e2a\u1805\ua152\ua1b7\u4957\u264d\u690d\u8630\u8ebc\u9dab\u97fd\u7120\u2f10\ua0f1\ud6f2\u8b3f", "\ud926\udfdd\udadb\udc50\udab3\udcd0\ud98b\udfc8",
        29, 79771, -445773347, -2204895813274558577L, 72829L, true, true, (char) 62357, (char) 40915,
        Double.longBitsToDouble(0x3fe87451eb9e25e9L), Double.longBitsToDouble(0x3fe8fb8074d6bc72L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 7, "\ud9cf\udfc0\uda34\udc5c\udbac\udc6a\ud9c9\udd93\udb14\udd53\udb24\uddeb\ud8ce\udd3e\ud8b1\uddaf\udac5\udd35\ud86f\udca6\udbf8\udceb\ud975\udc30\ue339\udbca\udfbd\uda7d\ude5d\ud8e5\udec8\u11a7\ud921\udfd8\udafa\udf32\udb57\uded2\uda99\udef3\ud8af\udf00\udb1e\udc96\ua680\ud9c3\udfc1\udad9\udd5a", "\u4fb1\u8956\u5bb8", "\u6d8a\ud818\udf3e\uda00\uddaf\ud905\udce0\ud848\udd32\ud828\ude05\udbbb\udf52\udaea\udfaf\ud8d3\udd17\ud9ec\ude8c\udb6b\udd75\u8cb8\ud91f\udc48\ud95c\udc38\udaad\udf80\udb73\udc1c\uda59\udcdf\ud8cc\udde7\udaaf\uded4\ud933\udccd\ud95e\ude94",
        25, 24557, -522621450, -5696656537555808226L, -96757L, true, true, (char) 41556, (char) 7678,
        Double.longBitsToDouble(0x3fe8db4b051351f6L), Double.longBitsToDouble(0x3fecdefb14f1805cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|nextToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_filterContext||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextBuffered|com.fasterxml.jackson.core.filter.TokenFilterContext|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextToken2||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextTokenWithBuffering|com.fasterxml.jackson.core.filter.TokenFilterContext|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|clearCurrentToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getBigIntegerValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getBinaryValue|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getBooleanValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getByteValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentLocation||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentName||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentTokenId||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getDecimalValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getDoubleValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|nextToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
