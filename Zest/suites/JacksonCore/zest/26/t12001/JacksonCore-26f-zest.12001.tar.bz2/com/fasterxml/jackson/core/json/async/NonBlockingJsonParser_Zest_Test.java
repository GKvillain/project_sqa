package com.fasterxml.jackson.core.json.async;
import org.junit.Test;
import static org.junit.Assert.*;
public class NonBlockingJsonParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 3, "\ud881\ude5b\ud8ce\udf04\udae5\udda0\ud830\udd1c\ud9dd\udf05\uda54\udcde\ud8bc\udfa5\udb5e\udc98\udb94\udede\udaf9\ude10\ud9e1\uddca\ud824\udd6d\ud99f\udf8e", "\u8299\u9e18\ud138\u6a74\u9b4c\u2c0f\u5d79", "\ud9fd\udc63\ud89e\udd30\ud9a5\udc0e\uda2f\udcee",
        11, 43589, -339749673, 6106657922784052032L, -84671L, true, false, (char) 19486, (char) 18527,
        Double.longBitsToDouble(0x3fdcf49c0b59cc8aL), Double.longBitsToDouble(0x3fcc54136af647e4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 3, "\ud881\ude5b\ud9d5\udde7\udae5\udcda\ud830\udd1c\ud9dd\udf05\uda54\udcde\ud8bc\udfa5\udb5e\udc98\udb94\udede\udaf9\ude10\ud9e1\uddca\ud824\udd6d\ud99f\udf8e", "\u8299\u9e18\u0e42\u6a74\u9b4c\u2c0f\u5d2e", "\ud9fd\udc63\ud89e\udd30\ud9a5\udc0e\uda2f\udcee",
        11, 43589, -339749673, 6106657922784052032L, -84671L, false, false, (char) 0, (char) 12355,
        Double.longBitsToDouble(0x3fdcf49c0b59cc8aL), Double.longBitsToDouble(0x3fcc54136af647e4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 6, "\ud881\ude5b\ud8ce\udf04\udae5\udda0\ud830\udd1c\ud9db\udda0\uda54\udcde\ud8bc\udfa5", "\u8f51\ua8cc\ua6b9\u81a1\u5c80\ub44d\ua7b7\ua7a5\uaa67\ud502\u9b4c\u2c0f\u5d79\u7559\u9f19", "\ud9a5\udc0e\uda2f\udcee\udb90\udd78\udbab\udc47\ud9d2\udfa5\uda0c\ude05\uda97\udf43\ud880\udc9c\ud875\udd73\uda13\udfff\udae6\udde1\uda7f\udc9b\udb69\udc4a\udb6e\udc0c\ud842\ude66\ud9fb\udcfd\udb72\udf00\ud89e\udff2\udab8\ude85\ud9ee\udf04\ud835\udebc\ud881\ude33\uda84\udea1",
        10, 95426, 493183177, -7129591516544744044L, 83791L, false, false, (char) 45595, (char) 32689,
        Double.longBitsToDouble(0x3fe318c0d6cf914dL), Double.longBitsToDouble(0x3fefd92105714962L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 3, 3, "\udba5\udc7f\udb28\ude35\uda63\udf26\ud818\udd6e\ud9dd\udf05\udb44\uddb5\ud8bc\udf48\ud9ae\udee1\udb94\udede\udbc3\udcd5\ud9e1\uddca\ud824\udd6d\udb59\udff4", "\u0414\u78e9\u1e4b\u6a4b\u1c7c\u669b\u4fd7", "\ud888\udc82\ud88f\udd81\ud9a5\udc0e\uda2f\udcee",
        4, 96007, -339749673, 6106657922784038926L, -62518L, true, false, (char) 25165, (char) 47238,
        Double.longBitsToDouble(0x3fdcf71c4b59cc8aL), Double.longBitsToDouble(0x3fca34137dc34db4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 2, "\udba4\ude3d\ud840\udfe5\udab9\udd7a\ud830\udd1c\uda3b\uddf8\uda54\udd41\ud8bc\udfa5\udb5e\udc98\ud9c8\udd38\udaf9\udd59\uda52\udcf5\ud9fb\udd6e\uda34\udd5c", "\u6533\u9e18\ud138\u0080\u3ddc\u2c0f\u5d79", "\uda72\udd5b\ud89e\udd30\ud9a5\udc0e\uda2f\udcee",
        11, 43589, -339749673, 6106658803252347712L, -85546L, true, false, (char) 3983, (char) 39921,
        Double.longBitsToDouble(0x3fedc196f278ffeaL), Double.longBitsToDouble(0x3fe3b355c53130f3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 3, "\ud99f\udca9\ud836\udc54\uda2d\ude1e\ud937\ude96\uda00\udd13\uda54\uddc0\ud840\udfa7\udb5e\udc98\ud82e\udf1f\ud99c\udef3\udb83\udd31\ud974\udcc3\uda66\uddaf\uf6a5\ud9cb\udc79", "\ud138\u8ee5\u735f\u0159\u5d79\u7559\u9f19", "\ud9a5\udc0e\uda8b\udc59\ud9f1\udfe8\udb9b\udddd\udb6e\udef3\uda36\udef7\udb7e\udf87\ud920\udc17\udbc8\uddb1\ud8af\udf86\udaf8\udfd2\uda7f\udc9b\udb87\udd50\udb6e\udc00\ud8a8\uddf8\udbde\udc87\udaff\udc86\udbe6\udeea\ud967\udf57\udaaa\ude8b\ud831\udf22\ud98f\udf2c\ud80f\udff6",
        3, 44554, 394901411, 1011504929743694080L, 93076L, false, true, (char) 30711, (char) 55718,
        Double.longBitsToDouble(0x3fde71c376361890L), Double.longBitsToDouble(0x3f465ed5600ba800L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\udb7b\udd78\ud8ce\udf04\ubbc6\uda84\udf86\000\uda4a\udfc5\ud8bc\udfa5\udb5e\udc98\udb94\udede\udaf9\ude10\udb98\udd4b\ud824\udd6d\ud99f\udf8e", "\u4aa6\000\uc2f6\u6a74\u28f3\u7bda\u5d79", "\ud88b\udd5a",
        18, 29412, 0, -3611354737523294208L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e473c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 3, "\ud881\ude5b\ud8ce\udf04\u00c6\000\000\udb51\udd1c\ud8ad\uddf5\ud94a\ude4e\udb6a\ude75\udaf9\ude10\ud9e1\uddca\021\000", "", "\uda13\udc28\u00d1\ub6d6\ud879\udd06\udaf2\ude8f\uda69\udcaf\u3cc9",
        6, -839, 1497300992, -8422856301987371923L, -100000L, true, true, (char) 17407, (char) 30579,
        Double.longBitsToDouble(0x3f377376b8d00000L), Double.longBitsToDouble(0x3ec5010c00000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 3, "\ud881\ude5b\ud8ce\udf04\udad8\udcda\ud830\udd8d\ud9dd\udf05\uda54\udcde\ud8bc\udfa5\udb5e\udc98\udb94\udede\udb16\ude3e\ud9cb\udd2b\udbe3\udd40\ud99f\udf8e", "\u8299\u9e18\ud138\u6a74\u9b4c\u2c0f\u5d79", "\ud9fd\udc63\ud89e\udd30\ud9a5\udc0e\uda2f\udcee",
        11, 43589, -339749673, 6106657922784052032L, -84671L, true, false, (char) 19486, (char) 18527,
        Double.longBitsToDouble(0x3fdcf49c0b59cc8aL), Double.longBitsToDouble(0x3fcc54136af647e4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|feedInput|[B,int,int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeCharEscape||new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeEscaped||new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeFastCharEscape||new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeSplitEscaped|int,int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeSplitMultiByte|int,int,boolean|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeSplitUTF8_3|int,int,int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeSplitUTF8_4|int,int,int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeUTF8_2|int,int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeUTF8_3|int,int,int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_decodeUTF8_4|int,int,int,int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_fastParseName||new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_finishAposName|int,int,int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_finishAposString||new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_finishBOM|int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|_finishCComment|int,boolean|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
    "M|com.fasterxml.jackson.core.json.async.NonBlockingJsonParser|feedInput|[B,int,int|new:com.fasterxml.jackson.core.json.async.NonBlockingJsonParser:com.fasterxml.jackson.core.io.IOContext,int,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
