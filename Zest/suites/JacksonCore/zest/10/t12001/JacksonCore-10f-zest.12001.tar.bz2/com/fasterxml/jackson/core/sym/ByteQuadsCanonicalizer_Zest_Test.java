package com.fasterxml.jackson.core.sym;
import org.junit.Test;
import static org.junit.Assert.*;
public class ByteQuadsCanonicalizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 8, 14, "\ud99b\udddb\ud990\udcb4", "\u2204\ubb8d\u6586\u44ca\u5ecd", "\uda98\uddac",
        59, 76817, -1131394570, 6441578366921788381L, 22796L, false, true, (char) 63680, (char) 7343,
        Double.longBitsToDouble(0x3fb9cb47ddc17258L), Double.longBitsToDouble(0x3fe448386b4c6729L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 8, 14, "\ud99b\udddb\ud990\udcb4", "\u2204\ubb8d\u6586\u44ca\u5ecd", "\uda98\uddac",
        59, 2145, -1131394715, 6441578366921788381L, 22796L, false, true, (char) 39941, (char) 19907,
        Double.longBitsToDouble(0x3fb9cb45ddc17258L), Double.longBitsToDouble(0x3fe448386b4c6729L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 2, 13, "\u2174\ud973\uddb8", "\u2204\ubb8d\u6586\u445c\u5ecd", "\ud8f3\ude91\udbef\udcdc\udb55\udf47\ud80e\uddb3\ud917\udc36\ud8ee\udee0",
        7, 60428, 1277590800, 4848314781341309287L, 10864L, true, false, (char) 10869, (char) 52780,
        Double.longBitsToDouble(0x3fd30274e1a1a65cL), Double.longBitsToDouble(0x3fec4f9bca1579f6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 14, "\ud99b\udddb\ud990\udcb4", "\u2204\ubb8d\u6586\u44ca\u5ecd", "\uda98\uddac",
        59, 76817, 9456118, 6413125870738131933L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3dc17000000000L), Double.longBitsToDouble(0x3fe4483868000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:[com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer: size=0, hashSize=0, 0/0/0/0 pri/sec/ter/spill (=0), total:0]\012",
        Z.run(T, 1, 13, 8, 14, "\ud99b\udddb\ud990\udcb4", "\u2204\ubb8d\u6586\u44ca\u8574", "\uda98\uddac",
        59, 76817, -1131394570, 6441578366921788381L, 22796L, false, false, (char) 32384, (char) 7343,
        Double.longBitsToDouble(0x3fb9cb47ddc17258L), Double.longBitsToDouble(0x3fe448386b4c6729L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 6, "\ud99b\udddb", "\u2b2d\u2204\ubb8d\ucb9f\u44f9\u5ecd\u65ce\u94d7", "\udb55\udf47\uda5f\uddfc",
        27, 54629, -786207717, -1079750954716563744L, -90119L, true, false, (char) 2563, (char) 7574,
        Double.longBitsToDouble(0x3fea63394d0a894dL), Double.longBitsToDouble(0x3fefdd3c86f9082aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:4\012",
        Z.run(T, 1, 7, 14, 19, "\ud9c2\uddc7\ud8f1\udc11\udb13\ude6d\uda02\ude24", "\u6586", "\udac4\ude8d\ud862\udcbe\u8eaa\udb4e\udd9c\udb55\udff5\uda56\udffc\udb4c\ude27\ud8da\ude78",
        8, 24980, -534348390, 4848314781341309287L, 21784L, true, false, (char) 10869, (char) 41486,
        Double.longBitsToDouble(0x3fef03e1d28ef56fL), Double.longBitsToDouble(0x3fd2072d35599c84L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:4\012",
        Z.run(T, 1, 7, 8, 14, "\ud99b\udddb\ud990\udcb4", "\u2204\u1c72\u6586\u44ca\ub9fd", "\uda98\uddac",
        59, 55033, -1131394789, 6441578366930575581L, 22796L, false, true, (char) 63680, (char) 7343,
        Double.longBitsToDouble(0x3fb9cb47ddc17258L), Double.longBitsToDouble(0x3fe448386b4c6729L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 4, 11, "\udac1\ude95\ud990\udc4b\udb13\udd9d\udbf0\udfcf\ud9ca\udd54\uda64\udf70\ud8a7\uddc2\ud965\uddb2\uda22\udcea\udacc\udd8d\ud862\udcbe\uda0a\udc64\udab2\udf0c", "\u6fd6\u5377\u7c90\u6a77\ub3e3\u89fc\u46e2\uc228\u0414", "\udb25\udfd3",
        44, 65433, 660500738, -6992760067113760481L, -31632L, true, true, (char) 11510, (char) 12864,
        Double.longBitsToDouble(0x3fe9f95163f620e4L), Double.longBitsToDouble(0x3fe44bb320cc22c8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=java.lang.Integer:4\012",
        Z.run(T, 2, 7, 7, 6, "\ud99b\udddb\ud990\udcb4\udb13\udd9d\ud9f8\udfc0\ud9ca\udd54\ud930\uddd7\ud8b2\ude78\ud965\uddb2\uda22\udcea\udacc\udd8d\ud862\udcbe", "\u520a\uca08", "\u5158\udbb8\udf57\ud9dc\ude4e\udbe8\udf3a\udb09\udc0f",
        14, 76728, 1730745993, -8552965387605488374L, -16295L, true, true, (char) 32227, (char) 42702,
        Double.longBitsToDouble(0x3fe9688e2719ec69L), Double.longBitsToDouble(0x3fb0f67ac4988c28L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=java.lang.Integer:4\012",
        Z.run(T, 2, 7, 7, 6, "\ud99b\udddb\ud990\udcb4\udb13\udd9d\ud9f8\udfc0\ud9ca\udd54\ud930\uddd7\ud8b2\ude78\ud965\uddb2\uda22\udcea\udacc\udd8d\ud862\udcbe", "\u520a\uca08", "\u5158\ud85e\udfec\ud9dc\ude4e\udbe8\udf3a\udb09\udc0f",
        14, 76728, 1076434569, -8552965198634544374L, -16295L, true, true, (char) 32227, (char) 44494,
        Double.longBitsToDouble(0x3fdf7f48aaed26beL), Double.longBitsToDouble(0x3fd1c1288bd79a26L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 0, "\ud99b\udc0c\ud990\udcb4", "\000\uba9d\u6586\u44ca\u5ecd", "\uda98\uddac",
        59, 76817, -1131394570, 6441578366921788381L, 22796L, false, true, (char) 63680, (char) 72,
        Double.longBitsToDouble(0x3e3dc00000000000L), Double.longBitsToDouble(0x3fe4483868000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findOffsetForAdd|int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|calcHash|int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|calcHash|int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|calcHash|int,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|calcHash|[I,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_appendLongName|[I,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_calcOffset|int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_calcTertiaryShift|int|static",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findSecondary|int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findSecondary|int,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findSecondary|int,int,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findSecondary|int,int,[I,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_reportTooManyCollisions||new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_spilloverStart||new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_verifyLongName|[I,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_verifyLongName2|[I,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findOffsetForAdd|int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|calcHash|int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|calcHash|int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|calcHash|int,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|calcHash|[I,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
