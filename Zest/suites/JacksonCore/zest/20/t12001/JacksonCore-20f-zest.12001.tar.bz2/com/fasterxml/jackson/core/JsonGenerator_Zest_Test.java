package com.fasterxml.jackson.core;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonGenerator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 10, "\ud923\ude8a", "\uaf9f\u3bc6\ud46a", "\ud843\ude96\ud942\udc93",
        20, 62986, -2043124274, -5346899727983751626L, 21604L, false, true, (char) 15018, (char) 47573,
        Double.longBitsToDouble(0x3fe445e6b09cdf63L), Double.longBitsToDouble(0x3fed81dffa4b864eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 10, "\ud923\ude8a", "\uaf9f\u3bc6\ud46a\u38c2\u217e\u9ccf\ub77f\u29a4\ud7fb\u6578\uaf14\u33b7", "\u10a1\uda70\ude7c\udb11\udd50\u1c9c",
        35, 14592, 265081419, -4412611267431590758L, -60112L, false, false, (char) 39934, (char) 48560,
        Double.longBitsToDouble(0x3feedbcf90b4c81dL), Double.longBitsToDouble(0x3fee5a0f72f0252cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 10, "\udab5\udc94", "\uaed1\u3bc6", "\uda67\udcb2\ud843\ude96\udac5\ude36\uda8d\udf69\udbf5\udf2f",
        51, 2895, -941273546, -5957780000251697924L, -66856L, false, false, (char) 24495, (char) 22681,
        Double.longBitsToDouble(0x3fab741fd79e2060L), Double.longBitsToDouble(0x3fc02a5b9005f874L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\012",
        Z.run(T, 1, 9, 1, 10, "\ud923\ude8a", "\uaf9f\ua64a\u6aa3", "\ud91b\udf74\udac5\uddad\udb0f\uddcc",
        31, 3726, -1244922105, -4042739098047105368L, -45690L, true, true, (char) 47573, (char) 62977,
        Double.longBitsToDouble(0x3fd925a5e960775cL), Double.longBitsToDouble(0x3fe25df8d5a400ceL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 2, 9, 10, "\udb65\udd9a", "\u7e6f\u3bc6\ud46a\u38c2\u41c9\u8c26\u14ab\u1dd0\uad7a\u5c00\u9132\u99a8\u8075\u1083", "\udb11\udde6\udb6f\udcae\ud85f\udc25",
        52, 46531, 97454891, 1642049570581848674L, 23818L, false, false, (char) 53110, (char) 3137,
        Double.longBitsToDouble(0x3fe56cdce12b930bL), Double.longBitsToDouble(0x3feb80fd331bc023L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 9, 10, "\ud8c8\udf5e", "\uaf9f\u3bc6\ud46a", "\udb64\udc47\ud8e2\udf92",
        55, 62986, -2043124274, -5346899727983751626L, 21604L, false, true, (char) 15018, (char) 47573,
        Double.longBitsToDouble(0x3fb5d2f586e7e878L), Double.longBitsToDouble(0x3fed819cd24b86c2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\012",
        Z.run(T, 1, 5, 1, 10, "\udb91\udd13", "\uaf9f\u3b2f\ud46a", "\ud843\ude96\ud942\udc93",
        46, 62986, -2043099954, -5346899727983751626L, 21604L, false, true, (char) 15018, (char) 47573,
        Double.longBitsToDouble(0x3fe445e6b09cdf63L), Double.longBitsToDouble(0x3fed81dbf14b864eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 7, 1, "\ud923\ude8a\udb24\udcc6\ud9cf\udea4\ud93e\udc2e\u8dad\udad7\udd26\udbf6\udca4\udb23\udcc2\ud843\ude96\ud942\udc93\udade\udfcc\udb88\udec1\ud934\udedb\udbc4\uddf3", "\u0957\u303d\ub102\u66f9\u3fe1\ua7b7\u3374\u9d4e\u639d\u72aa\ud35c\uc325\u11cc", "\ud804\udc02\udb1a\udfdd\ud8fe\udfa3\ud968\ude17\uda26\udd07\uda6e\udc6c\ud81f\udee8\ud846\udd14",
        16, 42607, 1488421101, 19291254320593702L, 6820L, true, true, (char) 8442, (char) 18369,
        Double.longBitsToDouble(0x3fe1b47cd67ebf69L), Double.longBitsToDouble(0x3fe0bf08867d06c2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.RuntimeException\012",
        Z.run(T, 1, 3, 13, 8, "\ud923\ude8a\udb1f\udec6\ud925\udc1c\ud96d\uddc4\ud8f3\ude81\ud85e\udfa5\ud90e\udcde\udb23\udcc2\ud843\ude96\ud942\udc93\udb0f\uddcc\uf933\ud995\udcd8\uda00\udea7\uda36\udee7\uda98\ude7d\ud893\udc88", "\u9252\u3fe1\ua7b7", "\ud934\uddf5\ud9b9\udde0\ud869\udc38\ud960\udef5\ud8aa\udc26\ud925\ude8a\ud8da\udedd\ud959\udf4a\udaed\uded9",
        -4, 71397, 1828590498, -8762207735118120256L, 30310L, true, false, (char) 45968, (char) 58554,
        Double.longBitsToDouble(0x3fea171219696d29L), Double.longBitsToDouble(0x3fe1c5d35d778364L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 9, 10, "\ud923\uded1", "\uaf9f\u3bc6\ud46a", "\ud8cd\ude99\udaf5\udf44",
        4, 62986, -2043124274, -5346899725774336458L, 21604L, false, true, (char) 15018, (char) 47573,
        Double.longBitsToDouble(0x3fe442f6b09cdf63L), Double.longBitsToDouble(0x3fed8167fa4b864eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!com.fasterxml.jackson.core.JsonGenerationException\012",
        Z.run(T, 1, 1, 9, 1, "\ud906\uddca\ud840\uddfd", "\u19e7\u9ba6\ubdd8\u9430\u2007\ub7cb\u8ebf\u2055\u55b6\uaf14\u7ad3\u7c40\u5b87\ub842\u5c0c\u91ac\u136f\u2197\u4dea\u4a26\ua420", "\u70d3\udb27\udd68\ud91a\udf55\udba3\udca9\udbdc\udecc\udbeb\udd4a\ud88c\udc3f\ud984\udc22\udb65\udece\udb60\uddc2",
        49, 3266, 650162339, -7013456297582025836L, 46108L, true, true, (char) 38660, (char) 10849,
        Double.longBitsToDouble(0x3fe27177c86966e2L), Double.longBitsToDouble(0x3f73aa1f4e803600L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\012",
        Z.run(T, 1, 4, 7, 10, "\ud923\ude8a", "\uaf9f\u3bc6\ud46a", "\ud843\ude96\ud942\udc93",
        20, 62986, -2043124274, -5346899727983751626L, 21604L, false, true, (char) 15018, (char) 47573,
        Double.longBitsToDouble(0x3fe445e6b09cdf63L), Double.longBitsToDouble(0x3fed81dffa4b864eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\012",
        Z.run(T, 1, 5, 0, 0, "\ud923\ude8a", "\uaf9f\u3bc6\ud46a", "\ud843\ude96\ud942\udc93",
        20, 41994, -1387492525, -5346899727983751626L, 87140L, false, true, (char) 15018, (char) 47573,
        Double.longBitsToDouble(0x3fe445e6b2d1ff63L), Double.longBitsToDouble(0x3fed81dffa4b864eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 9, 10, "\uda2a\udfb8", "\u658d\u00d1\ud46a\u38c2\u217e", "\udb0f\uddcc\udb88\udec1\udafd\udea0\ud9fe\udda7\uda36\udee7\uda6e\uddc8\ud869\ude8c\u10a1\uda70\ude7c",
        52, 89328, 1006577820, -8769032187745414581L, -73667L, false, true, (char) 28884, (char) 460,
        Double.longBitsToDouble(0x3fb28dfb887078f8L), Double.longBitsToDouble(0x3fe9d6b140327a77L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 9, 10, "\ud89b\udc37", "\uaf9f\u3bc6\u8973\u93e8\u36aa\u7d60\ub77f\u29a4\ud7fb\u6578\u27f4\u328a\u737d\u92cb", "\ud8d0\udfa9\u1c9c\ud85f\udc25",
        52, 54507, -1770187079, 4570195595115787941L, 41869L, true, false, (char) 56833, (char) 41384,
        Double.longBitsToDouble(0x3fcce59a3e0eda0cL), Double.longBitsToDouble(0x3fd1f495fd7f9d1aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\012",
        Z.run(T, 2, 4, 5, 5, "\ud914\ude8a\ud8bd\udf96\ud924\udffc\ud96d\uddc4\u943a\ud8de\udfc6\udbf6\udc1e\udb23\udcc2\ud89a\udf98\ud96c\udcf4\udb6c\ude39\udb74\udff9\ud86c\udc96\ud95b\udd61\udb1b\udcc8\udbff\ude35", "\uaed6\u7be5\u0246\u5fd0\u3374\ucd04\ub0d9\u00e0\u755d\u8e84\u052b\u49b2\u03e0\u919e\u0ed8", "\ud97b\ude30\udab0\ude7e\ud95a\ude61\ud8c0\udd01",
        46, 3562, -1608000814, 3887983815962750072L, 10778L, true, false, (char) 54096, (char) 49143,
        Double.longBitsToDouble(0x3fda30e6c518d208L), Double.longBitsToDouble(0x3fdd0f08ce8ddb72L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\012",
        Z.run(T, 2, 4, 9, 10, "\ud8c8\udf5e", "\uaf9f\u3bc6\ud46a", "\udb64\udc47\ud8e2\udf92",
        55, 89106, -2043124274, -5346899727983751626L, 21604L, false, true, (char) 15018, (char) 47573,
        Double.longBitsToDouble(0x3fb5d2f586e7e878L), Double.longBitsToDouble(0x3fed819cd24b86c2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 10, "\ud8c8\udf72", "\uaf9f\u3bc6\ud46a", "\udb64\udc47\ud8e2\udf92",
        55, 62986, -2043124274, -5346899724951371466L, 21604L, false, true, (char) 26794, (char) 47573,
        Double.longBitsToDouble(0x3fb5d2f583c7e878L), Double.longBitsToDouble(0x3fed819cd24b86c2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!java.lang.RuntimeException\012",
        Z.run(T, 2, 5, 3, 3, "\ud844\udcbb\ufbda\ud8fb\udc24\udb95\udf0f", "\u38c2\u9334\u026b\u11cc\ud360\u177e\uc274\ua12c\u7d46\u0ce2\u885c\u57dc\ud73b\ubbc7\ua93a\ua6c5\uabfd\uab9a\uad8d\u93f9\u8fcb\u8a46\u41b8\u3c58\u2f5e\uc59a\u2fe0\u963a\u39d4\ube2d\u14b3\u2bc1\uc18b\u4e2b\u0949\ua986\u59c1\u0a5b\u1db3\u816a", "\ud8fb\udc8b\uda58\udf91",
        8, 42623, 76263232, 9012780490986219073L, 55898L, false, false, (char) 5728, (char) 9494,
        Double.longBitsToDouble(0x3fcc6c22d51567dcL), Double.longBitsToDouble(0x3faaaf5a530450f0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!com.fasterxml.jackson.core.JsonGenerationException\012",
        Z.run(T, 2, 5, 1, 10, "\udb05\ude2e", "\uaf9f\u3b2f\ud46a", "\ud843\ude96\ud942\udc93\udad6\udfab\udb88\udec1\udb15\udda0\uda00\udea7\uda36\udee7\uda6e\uddc8\ud869\ude8c\ud8ad\udc6b\uda4c\udc82",
        52, 15896, 1003497628, -8769032185404298933L, 68359L, true, false, (char) 57588, (char) 41127,
        Double.longBitsToDouble(0x3fe5c87fd9a0b96aL), Double.longBitsToDouble(0x3fcd497bfaece940L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\012",
        Z.run(T, 2, 5, 5, 11, "\udb91\udc87\udb1f\udec6\udb89\uddaf\u2a27\ud893\ude9d\ud8de\udfc6\udba5\udfc1", "\ub77f\u1f82", "\ud924\udc79\uda36\udee7\udb48\udd1a\uda2f\udd92\u10a1\uda70\ude7c\udb11\udd50\u1c9c\uda0f\udc1d\ubc84\uda64\uddef\ud9e8\udf7b\udbd0\udd68",
        43, 58036, -1325970633, 8994837068549791713L, 48933L, false, true, (char) 6082, (char) 6660,
        Double.longBitsToDouble(0x3f80515247aa9a80L), Double.longBitsToDouble(0x3fec5fec498ebdfaL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 8, "\ud923\ude8a\udb1f\udec6", "\ud0b3\u5421\ubfc9\u217e\u9ccf", "\uf933\ud9d0\udfe4\ud80f\ude94\ud800\udde1\ud997\udc9a\ud893\udc88\udb25\ude71\udac2\udd9c\udb11\uddf6\udb4e\udc5e\udb6e\udd91\uda87\udf7e\udabf\udf0f\ud896\udcd1\ud92d\udc01\ud8cd\udf9d\ud8b9\uddfc\ud8aa\udc26\ud925\ude8a\ud8da\udedd\ud959\udf4a",
        18, 86891, 1319839397, 7853736386909943677L, 98897L, false, true, (char) 38400, (char) 63093,
        Double.longBitsToDouble(0x3f8fe957d0b890c0L), Double.longBitsToDouble(0x3fd69022947174d6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 8, "\ud923\ude1e\udb1f\udec6\ud925\udc1c\ud96d\uddc4\ud8f3\ude81\ud85e\udfa5\ud90e\udcde\udb23\udcc2\ud843\ude96\ud942\udc93\udb0f\uddcc\uf933\ud995\udcd8\uda00\udea7\uda36\udee7\uda98\ude7d\ud893\udc88", "\u9252\u3e66\u62e5", "\ud934\uddf5\ud9b9\udde0\ud869\udc38\ud960\udef5\ud8aa\udc26\ud925\ude8a\ud8da\udedd\ud959\udf4a\udaed\uded9",
        53, 71397, 1828590498, -8762207735118120256L, 30310L, true, false, (char) 45968, (char) 58554,
        Double.longBitsToDouble(0x3fea171219696d29L), Double.longBitsToDouble(0x3fe1c5d35d778364L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 15, 6, "\ud90a\udc1a\udb5b\udc4b\uda92\udcc2", "\u9ba6\u3e6d\u5757\u499a", "\ud876\udf34\ud841\udefe\uda00\udea7\udafc\uddaa\u0328\ud978\uddab\udb8c\udee5\u737c\udb11\udd50\ud8d6\udc03",
        30, 44117, -1380705457, 6331999031498005031L, -81401L, true, false, (char) 49822, (char) 49800,
        Double.longBitsToDouble(0x3fe6a512266a4368L), Double.longBitsToDouble(0x3fec6ba5cd2f130fL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 7, 10, "\ud98d\ude7f", "\uaf9f\u3bc6\ud46a", "\000",
        -5, -1000, 0, -8775151939738665209L, 49848L, false, false, (char) 0, (char) 14785,
        Double.longBitsToDouble(0x3fd46c88fd1179acL), Double.longBitsToDouble(0x3e16077fe0000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\012",
        Z.run(T, 2, 4, 4, 1, "\udbb0\udf8b\ub1f4\ud80f\udc00", "\ud46a", "\ud836\udca4\ud9aa\udc07",
        18, 82298, -1112562416, -8644832813344330988L, 6732L, false, true, (char) 15018, (char) 47573,
        Double.longBitsToDouble(0x3fe445e6b489df63L), Double.longBitsToDouble(0x3fee4990329f7b4eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 2, 0, "\udaa9\udeb5\ud9cc\udd99\udba6\uddfd\ud975\udcea\u943a\ud8c8\uddeb\ud934\ude58\udb23\udcc2\ud998\udf97\ud96c\udcf4\udb6c\ude39\udb74\udff9\ud896\udd4b\ud95b\udd39\udb2b\udc12\udbff\ude35\ud915\udf7e\ud97b\ude71\ud8b9\udcff\udb64\ude89", "\u2ea5\u21ba\u6eec\uae42\u755d", "\u2635\udaee\ude87\udb5e\ude1d\u75a6\ud912\udf3b\ud9c0\udd95",
        3, 18281, -474432465, -7239056911029686256L, -88782L, true, false, (char) 41580, (char) 39033,
        Double.longBitsToDouble(0x3fea37974477fa8aL), Double.longBitsToDouble(0x3fece2639a0fedbbL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\012",
        Z.run(T, 2, 5, 5, 5, "\ud914\ude8a\ud8bd\udf96\ud924\udffc\udb3c\udd0b\u9389\ud8de\udfc6\udbf6\udc1e\udb23\udcc2\ud89a\udf98\ud96c\udcf4\udb6c\ude39\udb74\udff9\ud86c\udc96\ud95b\udd61\udb1b\udcc8\udbdd\udc35", "\u28d2\u7be5\u0246\ub8ff\u5e25\ucda2\ub0d9\u00e0\u755d\uc0b9\ub670\u49b2\u03e0\u919e\u0ed8", "\ud97b\ude30\udab0\ude7e\ud95a\ude61\ud8c0\udd01",
        37, 3562, -1608000814, 3869969417453268088L, 10778L, true, false, (char) 16610, (char) 49143,
        Double.longBitsToDouble(0x3fda30e6c518d208L), Double.longBitsToDouble(0x3fdd0f08ce8ddb72L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 4, 10, "\ud9e4\ude8d\ud9d9\uddec\udbb6\udea9\uda57\udc28\ud955\udd9f\udaec\udd30\uda9d\udfaa\udbdf\udce0\udb1c\udfa3\ud9c4\udd3e\udad6\udfab", "\u3e8b\u33c0\u6ddf\u03d0\u6eb3\u3ccc\u91ac\u978c\u6489\u3374\u30b6\u3dc7\ud046", "\ud85c\udf95\ud9d2\udcbe\ud898\udc5b\udb1a\udfbf\uda45\ude03\ud92e\udd2b\udb22\udd02\uda95\udf64\ud842\udd2d\udba4\ude82\udb15\udcea\udaf0\udc5d\udbff\udcd1\udbe2\udf23\uda9d\udecf\udac4\udde8\ud971\uddb3\uda4e\udca6\ud864\udf26\ud988\udc79\uda91\udf9b\ud9f3\udf20\ud938\uddf7",
        54, 60259, 190237369, -9086709099850118947L, -94463L, false, false, (char) 55406, (char) 53098,
        Double.longBitsToDouble(0x3fef5fce135e1f66L), Double.longBitsToDouble(0x3fc7e057b1229e14L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 4, 10, "\ud9e4\ude8d\ud9d9\uddec\udbb6\udea9\uda57\udc28\ud955\udd9f\udaec\udd30\uda9d\udfaa\udbdf\udce0\udb1c\udfa3\ud9c4\udd3e\udad6\udfab", "\000\000\u6ddf\u03d0\u6eb3\u3ccc\u9166\u978c\u6489\u3374\u30b6\u3dc7\ud046", "\ud85c\udf95\ud9d2\udcbe\ud898\udc5b\udb1a\udfbf\uda45\ude03\ud92e\udd2b\udb22\udd02\uda95\udf64\ud842\udd2d\udba4\ude82\udb15\udcea\udaf0\udc5d\udbff\udcd1\udbe2\udf23\uda9d\ude08\udac4\udde8\ud971\uddb3\uda4e\udca6\ud864\udf26\ud988\udc79\ud9cd\udf99\ud9f3\udf20\ud938\uddf7",
        50, -1000, 190237369, -9086709099850118947L, -94463L, false, false, (char) 55406, (char) 53098,
        Double.longBitsToDouble(0x3fef5fce10000000L), Double.longBitsToDouble(0x3fc7e04011229e14L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 10, "\ud923\ude8a", "\uaf49\u3bc6\ud46a", "\ud843\ude96\ud942\udc93",
        20, 62986, -2043124274, -5346899727983751626L, 21604L, false, true, (char) 39594, (char) 11018,
        Double.longBitsToDouble(0x3fe445e6b09cdf63L), Double.longBitsToDouble(0x3fed81dffa4b864eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 5, "\ud914\ude8a\ud8bd\udf96\ud924\udffc\ud96d\uddc4\u943a\ud8de\udfc6\udbf6\udc1e\udb23\udcc2\ud89a\udf98\ud96c\udcf4\udb0e\ude2a\uda43\udf2f\ud87e\udd25\ud95b\udd61\udb1b\udcc8\udae6\udc68", "\uaed6\u7be5\u0246\u5fd0\u3374\ucd04\ub0d9\u7adf\u755d\u8e84\u052b\u49b2\u03e0\u919e\u0ed8", "\ud97b\ude30\udab0\ude7e\ud95a\ude61\ud8c0\udd01\uda8e\udd78\udbfa\udc5a\ua52c\u57dc\ud9c6\ude4c\udb1c\udf92\uda6f\udef3\ud970\udcf8\udb9a\udd19\uda68\udefb\ud95b\udfd3",
        46, 14024, -348217530, 4593155327039179671L, -56812L, true, true, (char) 55012, (char) 54180,
        Double.longBitsToDouble(0x3fecba3ad4f2661bL), Double.longBitsToDouble(0x3fe1deaa528f4199L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 10, "\ud923\ude8a", "\uaf9f\u3bc6\000", "\u7725\ud942\udc8c",
        20, 62986, -2043124274, -5346899727983751626L, 21604L, false, true, (char) 15018, (char) 0,
        Double.longBitsToDouble(0x3fe44000009cdf63L), Double.longBitsToDouble(0x3fed81dffa4b864eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.JsonGenerator|writeEmbeddedObject|java.lang.Object|new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|_reportError|java.lang.String|new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|_reportUnsupportedOperation||new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|_throwInternal||new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|_verifyOffsets|int,int,int|new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|_writeSimpleObject|java.lang.Object|new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|canOmitFields||new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|canUseSchema|com.fasterxml.jackson.core.FormatSchema|new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|canWriteBinaryNatively||new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|canWriteFormattedNumbers||new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|canWriteObjectId||new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|canWriteTypeId||new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|close||new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|configure|com.fasterxml.jackson.core.JsonGenerator$Feature,boolean|new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|copyCurrentEvent|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|copyCurrentStructure|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.JsonGenerator|writeEmbeddedObject|java.lang.Object|new:com.fasterxml.jackson.core.filter.FilteringGeneratorDelegate:com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
