package com.fasterxml.jackson.core.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultPrettyPrinter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 11, 9, 6, "\ud912\udd54\ud8bb\udcb8\ud879\udc3d", "\u4e9b\u6584\u06d1\u9b65\u55ce", "\uda68\udf66\ud831\udff0",
        13, 24044, -308772448, -1708931947244802280L, 91371L, false, true, (char) 25372, (char) 40299,
        Double.longBitsToDouble(0x3fecc60b4f7fcf14L), Double.longBitsToDouble(0x3fd284bbfeffc016L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 1, "\ud901\udfbf\ud8bb\udcb8\udbdc\ude6d", "\u4e9b\u2900\u2ca6\ub6dc\uc644", "\uda68\udf66\ud931\udef0",
        7, 24044, -308772448, -1708931947244802280L, 69485L, true, true, (char) 7514, (char) 46766,
        Double.longBitsToDouble(0x3fdc24908eff9e28L), Double.longBitsToDouble(0x3fd284bbfeffc016L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 11, 6, 7, "\ud912\udd54\ud8bb\udcb8\ud879\udc3d\udbe4\udc44\ud9d4\udd49\ud900\udccc\udb99\udd43\ud8d6\uddd6\udb86\udc1e\ud989\udfe1\ud8d0\udc3f\udbb0\ude1d", "\u422f\u368d", "\ud820\udf82\udb47\udeea\ud9d2\udc9b\u9169\udbab\udc00\udaf3\udd50",
        47, 72551, 353074472, -4281587210557923655L, 9898L, true, false, (char) 20962, (char) 42414,
        Double.longBitsToDouble(0x3fd27460570bb608L), Double.longBitsToDouble(0x3feacfd45a2d2510L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 1, "\ud8c5\ude85\ud8bb\udcb8", "\u2ea5\u4e9b\u6584\u06d1\u9b65\u55ce\ubf38\u0786", "\ud965\uddda\ud9b1\udf63",
        0, 46663, -298134556, -4470620430026337163L, -88674L, true, true, (char) 51431, (char) 40842,
        Double.longBitsToDouble(0x3fd7b46622ad4a78L), Double.longBitsToDouble(0x3fd852be504a71caL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 11, 9, 6, "\ud912\udd54\ud8bb\udcb8\ud879\udc3d", "\u4e9b\u6584\u06d1\u9b65\u55ce\u96fa\u3a75", "\ud9b8\udceb\ud853\udfa7",
        37, 47275, -1020776680, -2102371086440262539L, -79221L, false, true, (char) 5136, (char) 30991,
        Double.longBitsToDouble(0x3fc271c837bd46f8L), Double.longBitsToDouble(0x3fddb41d4d53fdf4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 12, 7, 8, "\ud92a\udc54\ud8bb\udcb8\ud879\udc3d", "\uc044\ua728", "\uda37\udfe5\ud8d0\udc3f",
        10, 98838, -1527323499, 8022723808786001859L, 6313L, false, false, (char) 48187, (char) 25372,
        Double.longBitsToDouble(0x3fae3817d95083c0L), Double.longBitsToDouble(0x3fbecd78c9425df8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\udbbb\ude68\udb0f\udcef\udb27\udeda", "\ua7a5\u6584\u5a5f\u82f9\u6855\ub55c\uab0d", "\uda49\udf28\ud9a3\udc57\ud915\ude7a\ud87f\udcfb\ud923\udf45\uda08\udfdf\ud850\uddba\udbdd\ude94\ud9b5\ude81\udafa\udce0\ud810\udf59\ud983\udc4a\udbb6\udd25\ud91e\udcb0\ud97a\udf66\ud81d\udddc\ud89d\udc2f\uda23\udd7f\udb75\udcc6\ud85e\ude2f\ud84d\ude4e\ud8ff\udd76\uda76\udd3d\uda90\udf7b\ud8d7\udd45",
        45, 92150, 1627198563, 3416123905685040332L, -19085L, true, true, (char) 29134, (char) 31694,
        Double.longBitsToDouble(0x3f9f5a6f3ab690c0L), Double.longBitsToDouble(0x3febc84171636898L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=void |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 11, 5, 6, "\ud912\udd54\ud8bb\udcb8\ud879\udc3d", "\u9f21\u55d6\u06a9\u9b65\u55ce", "\uda68\udf66\ud873\uddb1",
        29, 24044, -308772448, -1708931947244802280L, 91371L, false, true, (char) 25372, (char) 26269,
        Double.longBitsToDouble(0x3fc7f11c7dff3fd4L), Double.longBitsToDouble(0x3fd284bbfeffc016L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 9, 9, 6, "\ud92b\ude7d\ud8bb\udcb8\ud879\udc3d", "\u4e9b\u6584\u060c\u9b65\u8e49", "\uda77\ude66\ud831\udff0",
        13, 24044, -308772448, 6617593709240781839L, 91371L, false, true, (char) 25372, (char) 40299,
        Double.longBitsToDouble(0x3fecc60b4f7fcf14L), Double.longBitsToDouble(0x3fd284bbfeffc016L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=void |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 6, 4, 1, "\ud912\udd54\ud8bb\udcb8\ud879\udc3d", "\u4e9b\u6584\u06d1\u9b65\u55ce", "\uda68\udf66\ud831\udff0",
        13, 24044, -308772448, -1708931947244802280L, 7854L, false, true, (char) 25372, (char) 40299,
        Double.longBitsToDouble(0x3fecc60b4f7fcf14L), Double.longBitsToDouble(0x3fd284bbfe75c016L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 12, "\ud9b3\udf3e\ud7bd\udbe6\udee9\ud8df\udd49\ud9d4\udd49\ud900\udccc\uda41\udff8\uda6c\udcc6\ud9cb\udc5a\ud968\udee3", "\u898c\u852d", "\ud8f8\ude8b\ud89f\ude0d\uda65\udca6\udb04\ude7d\ud9fb\udee7\u9169\ud9e4\udd15\uda5c\udc5c\udb18\udee4\udad4\udcc7\udb79\udc4b\u101d\udb8e\udeca\ud9da\udf8b\ud934\udc6c\uda0e\uddc1\ud946\udd79\uda5a\udc51\udb64\udcbc\ud919\ude61\ud98e\udfbf\udb49\udf93\uda6a\udf48\ud878\udfdc\ud9af\udf7b\ud8ce\udc69\ud968\udc85\uda75\udc88\ud9f4\udf79\udb40\udf61",
        56, 59248, 872512186, 1549113511221981064L, -85139L, true, false, (char) 35980, (char) 8171,
        Double.longBitsToDouble(0x3fd636aa0e6c71deL), Double.longBitsToDouble(0x3fce09742df83344L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 8, 8, 13, "\ud912\udd54\ud8bb\udcb8\ud879\udc3d", "\u219b\u5ced\u8bc8\u78e2\u55ce", "\uda68\udf66\ud8b1\udff0",
        0, 24044, -308772436, -1708931947244802280L, 91371L, false, true, (char) 25372, (char) 40299,
        Double.longBitsToDouble(0x3fecc60b4b084f25L), Double.longBitsToDouble(0x3fe38115a77f12c7L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 11, 1, 9, "\u59fa\uda80\udc80\udac1\udc08\u413b\ud9d4\udd49\ud900\udccc", "\u9b13\u6b86\u6aca\u062e\uc1ce\u9eeb\u7a83\u922d\u5eb2\u6e02\ube3e\u28c9\ube24\u8cb9\u80da\ucb8c\uc248\u2b99\u9f50\ucdf7\u7af3\u819e", "\ud889\uded6\udafd\udce8\ud80c\udc19\uda47\udd75\ud94e\udfd6\udb44\udeb6\ud87b\ude08\ud990\ude6c\ud82e\uddb0\ud9e6\udcb8\udb69\udf44\ud8f2\udd9a\uda10\udc9f\ud838\udef3\udb9a\udde9\ud857\udfd9\udad0\udc9a\ud9f4\udf7c\udacc\udf4a\uda58\ude05\udb29\udf96\ud89e\udffa\udbed\ude83\ud932\udf20\ud971\udf2f\udbb1\udc4b\ud828\udca2\uda74\udd59",
        43, 36575, 1201683239, 8689693529415014858L, 19403L, false, false, (char) 27136, (char) 41929,
        Double.longBitsToDouble(0x3fe6ff700c869f76L), Double.longBitsToDouble(0x3fd43cac06b54138L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 6, "\ud912\udd54\ud8bb\udcb8\ud879\udc3d", "\u4e9b\u6584\u06d1\u9b65\u55ce", "\uda68\udf66\ud831\udff0",
        13, 24044, -308772448, -1708931947244802280L, 91371L, false, true, (char) 25372, (char) 40299,
        Double.longBitsToDouble(0x3fecc60b4f7fcf14L), Double.longBitsToDouble(0x3fd284bbfeffc016L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 1, 7, 6, "\uda26\udec6\udbe2\ude85", "\u8a83\ud768\u7978\u0758\u38f3\u61ed\uaa91\u3a75", "\ud9b8\udceb\ud853\udfa7",
        53, 47275, -1020776680, -2102371086440262539L, 78701L, true, false, (char) 930, (char) 44115,
        Double.longBitsToDouble(0x3fb847094c7a4490L), Double.longBitsToDouble(0x3fe8a52d377da9b2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 12, 12, 12, "\ud8e8\udedf\udbba\udc63\ud879\udc3d\u413b\ud9d4\udd49\ud84c\udd73", "\u9b65\u55ce\u96fa\u3a75\u7f7a\u5e6e\u422f\u8eed\uc3cf\u2b57\u5efb\u760e\ubd8d\u8c9a\u19cc\u8b0d\u259d", "\udb2d\udc55\uda38\udc69\ud966\ude28\ud85c\udc62\udaf7\ude9e\ud8c3\udd4e\udb37\ude1b\ud800\ude8f\ud84c\udf43\ud957\ude08\ud937\udf1b\ud96b\udd47\udb35\ude63\ud8cd\udd87\ud8c2\udd66\ud8a1\udcc9\ud8f4\udc7a\udad6\ude4e\udb23\udc26\ud9d6\ude58\ud8ce\ude96\u690c\ud974\uddf4\uda41\udce6\ud858\udd27\u71e2\uda6e\udd3d",
        48, 60160, -719847403, -8826444928978934736L, -23641L, true, false, (char) 346, (char) 9529,
        Double.longBitsToDouble(0x3fe9f534bce7073dL), Double.longBitsToDouble(0x3fecd8145e2168e0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 6, "\ud912\udd54", "\u1426\u2ea5\u4e9b\u6584", "\ud9fe\udc6d",
        5, 25363, -612750735, -45319855307424418L, 8893L, false, false, (char) 11685, (char) 41952,
        Double.longBitsToDouble(0x3fbd78b49b15f568L), Double.longBitsToDouble(0x3fcaacc8f4f1c0bcL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=void |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 4, 4, 6, "\uda5b\udd97\uda8a\udee7\u4d0d", "\u4e8e\u8d81\u13f9", "\ud8d4\udc2c\udbca\udf41\uda9a\udf8a\ud831\udff0",
        13, 24044, -308772448, -1708931945684521192L, -29717L, false, false, (char) 45719, (char) 53355,
        Double.longBitsToDouble(0x3fecc789277fcf14L), Double.longBitsToDouble(0x3fd284bbfeffc016L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 9, "\udbbb\ude68\ud9de\uded8\ud8f7\udca1\uda48\udecd\uda47\udf63\ud916\uddd6\ud923\udd7b", "\u6855\ua26e\uab0d\u5180\u076c\u4630\u0dd9\u9ab7\u37cd\u14a6", "\udbdd\ude94\ud9b5\ude81\udafa\udce0\ud810\udf59\ud983\udc4a\udbb6\udd25\udb42\udf37\ud97a\udf66",
        36, 39404, -472002776, 9149304860152940697L, -44657L, true, false, (char) 63841, (char) 4234,
        Double.longBitsToDouble(0x3fb8ea13d4c307e8L), Double.longBitsToDouble(0x3fc985ed14530c4cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 1, 1, 6, "\ud912\udd54\ud8bb\udcb8\ud879\udc3d", "\u9f21\u55d6\u06a9\u9b65\u55ce", "\uda68\udf66\ud873\uddb1",
        29, 24044, -308772448, -1708931947244802280L, 91371L, false, true, (char) 25372, (char) 26269,
        Double.longBitsToDouble(0x3fc7f11c71ff3fd4L), Double.longBitsToDouble(0x3fd284bca85b1416L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 11, 9, 6, "\ud912\udd54\ud8bb\udcb8\ud879\udc3d", "\u4e9b\u6584\u7b00\u305d\u55ce", "\uda68\udf66\ud831\udff0",
        13, 24044, -308772448, -1708931947244802280L, 91371L, false, true, (char) 25372, (char) 40299,
        Double.longBitsToDouble(0x3fecc60b4f7fcf14L), Double.longBitsToDouble(0x3fd284bbfeffc016L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@?\012",
        Z.run(T, 2, 11, 1, 11, "\ud92b\udc92\ud8bb\udcb8\udbe1\ude03\u0ec9\ud9d4\udd49\ud900\udccc\ud915\udee2\uda1a\udf4c\ud9cb\udc5a\udb55\ude99\ud8e1\uddca\udb5d\ude3b\ud945\udc7e\ud9bc\udc6f\ud9e5\udfc1\uda6a\udf4d\udab6\ude6b\ud884\udde4\ud821\udc4a\ud994\udc1e", "\u196a\u9ea8\u42a5\u623f\u5748\u1e18\u5c98\u1530\u9ccc\ua1d6\u88b0", "\uda0b\udd90\uedac\uda3b\udfed\ud8be\udd78\ud967\udc81\ud8ea\udc51\udb3b\udf2d",
        31, 39407, 1222832652, 6448724806481139362L, 90719L, false, false, (char) 16863, (char) 62417,
        Double.longBitsToDouble(0x3fd769708b9cf8b2L), Double.longBitsToDouble(0x3fe2f3c9a3261fa6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|createInstance||new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|_withSpaces|boolean|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|beforeArrayValues|com.fasterxml.jackson.core.JsonGenerator|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|beforeObjectEntries|com.fasterxml.jackson.core.JsonGenerator|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|indentArraysWith|com.fasterxml.jackson.core.util.DefaultPrettyPrinter$Indenter|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|indentObjectsWith|com.fasterxml.jackson.core.util.DefaultPrettyPrinter$Indenter|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|withArrayIndenter|com.fasterxml.jackson.core.util.DefaultPrettyPrinter$Indenter|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|withObjectIndenter|com.fasterxml.jackson.core.util.DefaultPrettyPrinter$Indenter|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|withRootSeparator|com.fasterxml.jackson.core.SerializableString|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|withRootSeparator|java.lang.String|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|withSeparators|com.fasterxml.jackson.core.util.Separators|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|withSpacesInObjectEntries||new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|withoutSpacesInObjectEntries||new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|writeArrayValueSeparator|com.fasterxml.jackson.core.JsonGenerator|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|writeEndArray|com.fasterxml.jackson.core.JsonGenerator,int|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|writeEndObject|com.fasterxml.jackson.core.JsonGenerator,int|new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
    "M|com.fasterxml.jackson.core.util.DefaultPrettyPrinter|createInstance||new:com.fasterxml.jackson.core.util.DefaultPrettyPrinter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
