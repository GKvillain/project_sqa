package com.fasterxml.jackson.core;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonPointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 10, 4, 8, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud9bc\ude16\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\u061f\u7239\u77a3\u74c5", "\ud9dd\udd0b\u5438\u2f9c\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -945684626, -5561235177398640580L, 79262L, false, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba320527b2L), Double.longBitsToDouble(0x3fe26efbbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 10, 4, 6, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud9bc\ude16\ud801\udf50\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\u061f\u7239\u77a3\u74c5", "\ud9dd\udd0b\u5438\u2f9c\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -945684626, -5561235177398640580L, 79262L, false, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba320527b2L), Double.longBitsToDouble(0x3fe26efbbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 4, 8, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud9bc\ude16\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u423a\u061f\u7239\u77a3\u74c5", "\ud9dd\udd0b\udaca\ude1f\ud96b\udc9a\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -945684626, -5561235177398640580L, 79262L, false, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba320527b2L), Double.longBitsToDouble(0x3fe26efbbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 13, 4, 8, "\udb27\udd91\ud867\udf8b\ud8a7\udcbd\ud857\udf62\ud90b\udd20\udbb8\udc14\u0fc3\ud824\udc47\ud801\udfb4\uda2a\udc25\udaf1\udda9\ud9d3\uddda\udbe9\udd2f\udbf3\ude62", "\u42f4", "\udbad\udea3\uda03\udd59\uda1c\udc9b\uda80\uddf5\ud9dd\udd0b\u5438\u2f9c\ud923\ude5b\udafa\udf42\ud847\udcfb\udab5\udc73\ud850\udede\ud9b9\udd89\udbe5\uddac\ud8b2\ude48\ud925\udd3c",
        56, 76692, -946939527, 1991689514318951682L, 79035L, true, true, (char) 4215, (char) 59940,
        Double.longBitsToDouble(0x3fec7883aae7570dL), Double.longBitsToDouble(0x3fe95f827d6c4632L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 10, 0, 8, "\udb27\udd91", "\000", "\u0fc3\000\000\ud97a\udfca\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a\ud95b\udefa\ud881\udfbb\uda49\udfc0\uda3d\udf6d\uda32\udf5c\u00d8\000\ud9e1\udeb0\uda80\uddf5d\ud90c\udd66\u2f9c\ud830\udfb8\ud9cb\ude96\ud8f6\udf74\udab5\udc73\ud850\uded1\uda5b\udc1b\uda88\udd85",
        31, 25931, 0, -946939527L, 28258L, false, true, (char) 42436, (char) 58410,
        Double.longBitsToDouble(0x3fc092dcc4830070L), Double.longBitsToDouble(0x3fe0442067eeb5dcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 4, 8, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\ud938\uded9\ud8d6\udc4b\udb52\ude94\ud9b4\udef5\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\udb18\udfa5", "\u41c1\ub4a2\uafd3\ua5bf\u74c5\u9790\u5b79\u2701\u4e95\u606e", "\ud8f6\udf74\udab5\udc73\ud850\uded1\uda9a\ude1b\ud845\udc6b\udb4d\uddb2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8c5\udca5\ud871\udf17\uda65\udd46\ud90f\udc77\ud8dd\udef9\udad5\udd83\udb42\udec8",
        13, 73998, -83013788, 3295889156724642054L, 91605L, true, true, (char) 22571, (char) 48854,
        Double.longBitsToDouble(0x3fb2dd500d5736c8L), Double.longBitsToDouble(0x3feeded321728f19L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.JsonPointer:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 4, 6, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\ud9ba\udee2\udb6d\udece\uda2d\udc44\ud9bd\udec2\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\u061f\u592e\ud24c\u421a", "\ud9dd\udd0b\u5438\u2f9c\ud86c\udd04\ud9cb\ude96\u5be5",
        54, 76229, -945684626, -5561235177398640580L, 79262L, false, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba320527b2L), Double.longBitsToDouble(0x3fe26efbbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 11, 4, 8, "\udb27\udd91\ud867\udfc7\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud992\udf16\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\uda35\udf73", "\u41c1\u061f\u7239\u77a3\ub71b\u9790\u8641\u8cb5\uc756\u6024", "\ud8f6\udf74\udab5\udc73\ud850\uded1\uda5b\udc1b\uda88\udd85\ud8e2\udf81\ud9e8\ude37\uedd5\ud9a6\ude82\udba1\udc97\uda43\udf5c\ud987\ude0f\ud870\udfd3\uda65\udd46\ud93c\udcad\ud908\udf34\udbed\udec6\u2218",
        7, 77171, -2139325867, -5848709603521742738L, -58404L, false, false, (char) 12060, (char) 26209,
        Double.longBitsToDouble(0x3fec26ab203820abL), Double.longBitsToDouble(0x3fdfb3c8812fa89eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\ud810\udc3c\udab8\udd5a\u0fc3\ud994\ude52\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\udbe9\udd2f\ud983\udf7a~\u74a5\012",
        Z.run(T, 1, 1, 15, 8, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\ud810\udc3c\udab8\udd5a\u0fc3\ud994\ude52\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\u061f\u7239\u58c8\u5c66", "\ud9dd\udd0b\u5438\u2f9c\ud94c\ude85\udb60\udda7\udb7c\udf5b",
        13, 29434, 533376901, -5561372959949496260L, 79262L, false, true, (char) 29861, (char) 13539,
        Double.longBitsToDouble(0x3fcd12d1ddc86390L), Double.longBitsToDouble(0x3fd43a6beb1fdd84L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 5, 11, 14, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\u3778\ud801\udd34\u58e0\u75fb\ud9d3\ude5e\udbe9\udd2f\ud983\udf7a", "\u9c82\u061f\u7239\u77a3\u74c5", "\ud9dd\udd0b\u0911\u2f9c\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -945684626, -5561235177410763019L, 79262L, false, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fe7e4a2f119a2c4L), Double.longBitsToDouble(0x3fe26efbbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 4, 8, "\udb8d\udf0c\ud867\udf8b\ud893\udf54\ud9e8\udc6a\uda7e\udc7a\ue6b2\u0fe5\ud9bc\ude16\ud801\udfb4\ud978\ude5c\ud990\ude03\ud9d3\ude08\udbe9\udd2f\ud983\udf7a", "\ubb15\u061f\u7239\u77a3\u74c5", "\ud90b\udfb8\u53a2\u94c8\u5bf0\ud9cb\udea6\ud8f6\udf74",
        54, 76229, -945684626, -8738948129564434304L, 79262L, false, true, (char) 29861, (char) 49822,
        Double.longBitsToDouble(0x3fdac5a3620527b2L), Double.longBitsToDouble(0x3fdc56da7b1fdd36L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 12, 4, 5, "\ud852\udfbf\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\udbde\udedd\udb8c\udede\ud9ad\udf95", "\ucff1\u1ca1\u52cc\ucd46\uba5f\u41c1\u061f\u7239\u77a3", "\uda80\uddf5\udba2\ude6f\udbbe\ude61",
        46, 18292, 1252451694, -7363397977850114212L, 20689L, true, true, (char) 16809, (char) 3393,
        Double.longBitsToDouble(0x3fd799b2ce218f1cL), Double.longBitsToDouble(0x3fd021ba320527b2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 9, 12, 8, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud9bc\ude16\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\u061f\u7239\u77a3\u74c5", "\ud9dd\udd0b\u5438\u2f9c\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, 251591395, -2915634365008467785L, 79262L, false, true, (char) 29861, (char) 17107,
        Double.longBitsToDouble(0x3fd021ba320527b2L), Double.longBitsToDouble(0x3fe26efbbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.JsonPointer:\0121=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 7, 14, 13, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud9bc\ude16\ud801\udfb4\ud97b\udc63\ud812\udde4\udb10\udcb0\ud904\udc1e\ud984\udc41\ud95b\udefa\ud881\udfbb\uda49\udfc0\uda3d\udf6d\ud8e4\udf55\ud97c\udcac\udbfe\uddad\ud974\udc0b\uda80\uddf5", "\u606e\ud734\u8cb8\ub85b\u2dc7\ua1c6\u649f\u9023\u9773", "\udb87\udda2\ud81c\udd08\udbfc\udcb0\ud943\udec4\ud872\udc00\uda2f\udd4b\ud93f\udfb0",
        50, 64692, -828359690, 6433898577510913100L, -37985L, false, false, (char) 30751, (char) 20393,
        Double.longBitsToDouble(0x3fbf53355902e670L), Double.longBitsToDouble(0x3fe6fbe3b3e715cdL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 3, "\udb0c\udd9b\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\uda53\udff8\ud9e1\udd55\ud990\ude2f\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u064c\u0fa9\ua9c8\u23a0\u74df", "\ud8a2\udc8d\ud874\udf78\u2f9c",
        2, 17886, -1714484870, 6226806321159004133L, 89166L, true, true, (char) 4173, (char) 3267,
        Double.longBitsToDouble(0x3fee7b0d69f89f1cL), Double.longBitsToDouble(0x3fe8863c73021ba3L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 0, 0, "", "\u9095", "\udbb8\udc14\u0fc3\ud9bc\ude16\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a\ud95b\udefa\ud881\udfbb\uda49\udfc0\uda3d\udf6d\uda32\udf5c\ud97c\udcac\ud808\udf9b\uda1c\udc9b\uda80\uddf5\ud9dd\udd0b\u5438\u2f9c\000\ud9cb\ude28",
        40, 36324, -1445535771, -4061684542294817262L, 67371L, false, true, (char) 3220, (char) 29861,
        Double.longBitsToDouble(0x3fe8863c75021ba3L), Double.longBitsToDouble(0x3fd0293d9c9bbeeeL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 5, 8, "\udb44\udd91\ud867\udf8b\ud8de\ude19\udba4\udf31\uf3d5\udbed\udf14\u0fc3\ud9bc\ude16\ud801\udfb4\uda7e\udcff\ud92c\uddb3\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\uca31\u7239\u4855\u5d9a", "\ud9dd\udd0b\u623e\u2f9c\ud86c\udd04\ud9cb\ude96",
        40, 36324, -969744411, 3801533393254039717L, 68893L, false, true, (char) 3393, (char) 29861,
        Double.longBitsToDouble(0x3fe8863c75021ba3L), Double.longBitsToDouble(0x3fd0293d949bbeeeL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud9bc\ude16\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a\012",
        Z.run(T, 1, 3, 4, 8, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud9bc\ude16\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\u061f\u7239\u77a3\u74c5", "\ud9dd\udd0b\u5438\u2f9c\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -945684626, -5561235177398640580L, 79262L, false, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba320527b2L), Double.longBitsToDouble(0x3fe26efbbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 8, 4, 8, "\udbb5\udd98\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\udbe9\ude2d\ud9bc\ude16\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udfb0", "\u41c1\u6795\u726e\u77a3\u74c5\u9790\u57a9\u2ae2\u4ef3\u606e\ud734\u97eb\u4447\u2dc7\ua1c6\u649f\u4299\ub96a\u034e\u5786\u3414\ua693", "\ud871\udf17\uda65\udd46\ud928\udc03\udbb8\udca3\udabd\udf10\uda72\udfc0\ud8c4\udd73\udabb\udd96\udbc9\udfb7\ud986\udc6b\udbe8\udf23\uda58\udcb6\udb34\ude02\ud87e\ude60\ud802\udffa\udb9f\udc92\u01a0\ud8fe\udc88\udad0\udffb\uda97\udebd\udb96\udc9c\udbeb\udcbb\u95f1",
        53, 71579, -423685325, 7019402430896053266L, 56528L, false, true, (char) 7111, (char) 18106,
        Double.longBitsToDouble(0x3feed049d5202ac1L), Double.longBitsToDouble(0x3fe3b0c8d076fc81L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 6, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\ud830\udd9f\u0f6a\ud9bc\ude16\ud801\udf50\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\u061f\u7239\u170d\u7cdf", "\ud9dd\udd0b\ud8be\ude2e\u2f9c\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -945684626, 5948558095276793916L, 79262L, false, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba3c0527b2L), Double.longBitsToDouble(0x3fe26fdfbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 9, 4, 8, "\ud897\udcb7", "\u4fd2\u50c4\u233d\u9501\u54b2\u1cda\u2e9c\u14c2\ubcab\ub935\u5299\ucd46\uba5f\u423a\u061f\u7239\uad91\ud1b5", "\ud9dd\udd0b\udaca\ude1f\ud96b\udc9a\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        56, 34580, -945684621, -5561235177398612932L, 79262L, false, true, (char) 29861, (char) 56167,
        Double.longBitsToDouble(0x3fd021ba320527b2L), Double.longBitsToDouble(0x3fe26efbbd8fee9dL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 0, 0, "\000", "\u4fd2", "\u0fc3\ud9bc\ude16\ud801\udfb4\ud97b\udc63\udb83\ude3d\ud9d3\uddc6\udbe9\udd2f\ud983\udf7a\ud95b\ude54\ud881\udfbb\u7384\udb7b\udd5c\uda32\udf5c\ud97c\udcac\ud808\udf9b\uda1c\udc9b\uda80\uddf5\ud9dd\udd0b\u57c6\ud954\udc09\ud86c\udd04\udb4d\udd77\ud8f4\uddfa\udab5\udc73\ue7e5\uda5a\udfad\uda88\udd85\ud8b2\ude48",
        -4, 94298, -1694454892, -4067074299290982640L, -34464L, true, false, (char) 58410, (char) 42401,
        Double.longBitsToDouble(0x3fd17e61c3336a3cL), Double.longBitsToDouble(0x3fe50ba13e005f2fL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 8, "\udb27\udd91\ud867\udf8b\uda73\udd42\ud85d\udd8c\udbfa\udf3a\udbb8\udc14\uda10\ude37\ud975\udda4\udb10\udfab\udb88\udf8f\ud928\udfa0\udb21\uddd6\ud844\udd0f\ud605", "\u423a\u061f\u6ff0\ub9ca\u747a\u2f82", "\ud9f8\ude16\ud96b\udc9a\ud86c\udd04",
        44, 90130, 1182868316, -6208528862588829842L, -59100L, true, true, (char) 16809, (char) 3393,
        Double.longBitsToDouble(0x3fe845316367feb5L), Double.longBitsToDouble(0x3fd021ba320527b2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 4, 4, 8, "\udb55\udca9\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud9bc\ude16\udabc\ude2c\ud894\udcc7\ud914\ude30\ud9d3\uddda\udbe9\udd2f\ud983\udf7a\ud95b\udefa", "\u061f\u7239", "\uda1c\udc9b\uda80\uddf5\ud9dd\udd0b\udaca\ude1f\ud96b\udc9a\ud86c\udd04\ud9cb\ude96\ud8f6\udf74\udab5\udc73",
        4, 61545, -1294825966, 2503825728620367307L, -56076L, true, true, (char) 23561, (char) 19699,
        Double.longBitsToDouble(0x3fd0293d9c9bbeeeL), Double.longBitsToDouble(0x3fd8fee9b02ed186L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 4, 5, 6, "\udb27\udd91\ud867\udf8b\ud8a7\udcbd\ud857\udf62\ud90b\udd20\udbb8\udc14\u0fc3\ud824\udc47\ud801\udfb4\uda2a\udc25\udaf1\udda9\ud9d3\uddda\udbe9\udd2f\udbf3\ude62\udb2f\udc51\ud950\udd59", "\u326d\u5888\u4ef4\u9790\u5b79\u2ae2\u4ef3\u606e\ua889\u396a\u5ff4\u2dc7\ua1d3\u7241\ua6c6\ub96a\u02df\u7d27\uba68\u5843", "\ud871\udf17\ud902\udf9d\ud85e\udc7f\u7d7f\ud930\uddc2\ud90f\udcb0\ud918\uddfa\ub34e\ud83d\udeeb\udbb3\udda2\ud95f\ude03\ud877\udfd6\udacb\udd3e\ud91e\uddf6\udaa6\udcd4\udab2\udde7\uda24\udf68\udba7\ude41\ud864\udd9e\udaec\udde0\udbe6\udd2c\udabe\udf9e\udb06\udc2c",
        23, 44220, 1890112112, 1848783341916273921L, 31403L, true, false, (char) 8707, (char) 6861,
        Double.longBitsToDouble(0x3fa81f672ed10ad0L), Double.longBitsToDouble(0x3fe33aa6636b6c71L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Integer:-1 |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 6, 6, 4, "\udb27\uddf0\ud867\udf8b\ud88a\udcce\ud85d\udcbe\ud90b\udd20\udbb8\udc14\u6b2e\ud82e\udcde\ud820\udf97\ud9d5\udebb\ud829\udd29\ud9b5\udefe\ud91d\udeb9\uda0a\udfbc", "\uc755\u59e8\u3d83\u02e8\u8700\u024f\u4338\u66a4\u7bd0\u847c", "\ud982\udf25\udab5\udc60\ud850\udede\ud9b9\udd89\u3da2\ud8b2\ude48\ud925\udd3c",
        56, 76692, -946939527, 1991689514318951682L, -38213L, true, true, (char) 4215, (char) 59940,
        Double.longBitsToDouble(0x3fe9c80baae7570dL), Double.longBitsToDouble(0x3fad1238f1453720L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 9, 0, 8, "\ud850\udf78\ubc0f\ud893\udee1", "\ub2a5", "\000\ud97a\udfca\ud928\udf4f",
        -1, 99913, -1090032015, 403009109290060541L, 27706L, false, true, (char) 9049, (char) 0,
        Double.longBitsToDouble(0x3e3c774e18000000L), Double.longBitsToDouble(0x3fb9393b80000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 9, 8, "\udb27\udd91", "\000", "\udb69\udfca\000\000\ud9cd\ude64\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a\ud95b\udefa\ud881\udfbb\uda49\udfc0\uda3d\udf6d\uda32\udf5c\u00d8\000\ud9e1\udeb0\uda80\uddf5d\ud90c\udd66\u2f9c\ud830\udfb8\ud9cb\ude96\ud8f6\udf74\udab5\udc73\ud850\uded1\uda5b\udc1b\uda88\udd85\ud8b2\ude48\uda93\udf42\udb7a\udf0a\ud919\ude76\ud9c6\udc65\udbfc\udcb0\ud97d\udea2\ud871\udf17\uda65\udd46\udbc7\udf33\uda2a\udf25\ud924\udec7\ud91d\udcf4\ud83f\udcf3\udb26\ude12\ud92a\udd1a\ud8bd\ude49\uda6d\udc54",
        37, 21342, 1720278580, 6311775175811537920L, -55567L, false, false, (char) 62217, (char) 13273,
        Double.longBitsToDouble(0x3fcc03d6b02f38d0L), Double.longBitsToDouble(0x3fdeccba423ef7e2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\0121=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 5, 9, 8, "\ud8aa\udd7d\ud8fc\udf01\udb69\udf7b\ubcbf\udbd3\ude0d\udbeb\udcd5\u0fc3\000", "\u62fa\u90f3\u7bc0", "\ud897\udec8\uda49\udfc0\uda3d\udf6d\uda32\udf5c\u00d8\u008e",
        37, 81582, -617771194, -8070450534077180015L, -27662L, false, true, (char) 43307, (char) 13903,
        Double.longBitsToDouble(0x3feb754eb612c7a1L), Double.longBitsToDouble(0x3fc807b1b72c8afcL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udad6\udfd5\uda0f\ude13\ud8ac\udde3\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 3, 12, 0, "\udad6\udfd5\uda0f\ude13\ud8ac\udde3", "\u353b", "\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda",
        33, 4745, -1608838298, -550337114627674544L, 75358L, false, true, (char) 65051, (char) 10977,
        Double.longBitsToDouble(0x3fec774e1f5ed192L), Double.longBitsToDouble(0x3fe138f52f9190c6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 10, 4, 8, "", "\u5d07", "\ud801\udfc0\udb52\ude94\ud9b4\udef5\u49fe\000\ud8f5\udd19\ud9d3\uddda\udbe9\udd2f\udb18\udfa5\uda6e\udf2f\ufdcb\udb51\udca7\udb71\udd68\u6745\ud987\udec8\ud808\udf9b\uda1c\udc9b\uda80\uddf5\ud8f5\uded7\u53da\u2f9c\ud86c\udd04\ud9cb\ude96",
        40, 36324, -1445535771, -6506857662438703094L, -5024L, true, true, (char) 20964, (char) 29861,
        Double.longBitsToDouble(0x3fe8863c75021ba3L), Double.longBitsToDouble(0x3fd02f9d9c9bbeeeL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb27\udd91\0121=com.fasterxml.jackson.core.JsonPointer:\udb27\udd91\012",
        Z.run(T, 2, 3, 3, 8, "\udb27\udd91", "\u4fd2\u374b\u62b0\u50f0\u3591", "\ud928\udf4f\ud9d3\uddda\udbe9\udd2f",
        25, 18998, 1349604555, 5758260089084310030L, 46924L, false, true, (char) 5715, (char) 9956,
        Double.longBitsToDouble(0x3fec8c86364c00fbL), Double.longBitsToDouble(0x3fd6e3b995b5cf4cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 0, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\ud98d\udde2\udb6d\udece\uda2d\udc44\ud9bd\udec2\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\u061f\u592e\ud24c\u451c", "\ud9dd\udd0b",
        36, 22881, -1218646708, 1416071391874648442L, 88389L, false, true, (char) 19891, (char) 4879,
        Double.longBitsToDouble(0x3fdcb22bf0000000L), Double.longBitsToDouble(0x3feca30d69799b2cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.String: |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 8, 15, 2, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\ud9ba\udee2\udb6d\udece\uda2d\udc44\ud9bd\udec2\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u41c1\u64ef\u3221\ud24c\u421a", "\ud9dd\udd0b\u5438\u2f9c\ud86c\udd04\ud9cb\ude96\u5be5",
        54, 76229, -945684626, -5561235177398640580L, 79262L, false, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba320527b2L), Double.longBitsToDouble(0x3fe26efbbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 8, 8, 11, "\udb27\udd91\ud9ca\udf5b\ud893\udf62\ud857\udf62\udbfa\udf9c\udbb8\udc14\ud897\udc10\ud81f\ude35\uda3d\ude05\ud9bd\udec2\ud928\udf4f\ud9d3\uddda\udbe9\udd71\ud983\udf7a", "\u8aba\u4505\u592e\ud24c\ud6d0", "\ud9bd\udf03\ud949\udeb4\u2f9c\ud86c\udd04\ud9cb\ude96\ud9b1\udeb0",
        42, 76229, -945684626, -5561235177398640580L, -17118L, false, true, (char) 2258, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba35bffa7aL), Double.longBitsToDouble(0x3fe26efcdd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\ud866\udd31\udaec\udca4\ud893\udf94\ud857\udf62\udbfa\udf3a\udbb8\udc14\ud9ba\udee2\udb6d\udece\uda2d\udc44\ud9bd\udec2\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a\ud95b\udefa\ud881\udfbb\uda49\udfc0\uda3d\udf6d\ud90b\ude89\ud951\ude16\uf0f0\uda1c\udc9b\uda80\uddf5\ud9dd\udd0b\u5438\u2f9c\ud86c\udd04\ud9cb\ude96\u5be5\udab5\udc73\ud850\uded1\uda5b\udc1b\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 9, "\ud866\udd31\udaec\udca4\ud893\udf94\ud857\udf62\udbfa\udf3a\udbb8\udc14\ud9ba\udee2\udb6d\udece\uda2d\udc44\ud9bd\udec2\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a\ud95b\udefa\ud881\udfbb\uda49\udfc0\uda3d\udf6d\ud90b\ude89\ud951\ude16\uf0f0\uda1c\udc9b\uda80\uddf5\ud9dd\udd0b\u5438\u2f9c\ud86c\udd04\ud9cb\ude96\u5be5\udab5\udc73\ud850\uded1\uda5b\udc1b", "\uab3c\u0dfa\u3414\ua693\u57d2\u44d4\u7272\u29b0\u2792\u57d3\u6cec\ub1da", "\udbab\udf82\u12d5\ud91a\udf25\udb85\udd9a\ud87f\udd36",
        25, 60649, 436896808, -2223329774734277853L, -48297L, false, true, (char) 38133, (char) 39406,
        Double.longBitsToDouble(0x3fd4654b829394deL), Double.longBitsToDouble(0x3fdde4e9393f55a0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 12, 12, 0, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\ud9ba\udee2\udb6d\udece\uda2d\udc44\uda16\uddb2\ud928\udf47\udbbc\udda0\uda28\ude34\ud920\ude90", "\u41c1\u140c\ua9a2\ud24c\u421a", "\ud9dd\udd0b\u5438\uda8a\udcba\ud895\udc2d\ud9cb\ude96\u5ba5\udadd\udc73\ud850\uded1\ud835\udd3b\uda4a\udf44\ud9de\udda0\udb16\udd2f\udb57\udefc\udb87\udda2\ud813\udf66\udbfc\udcb0",
        40, 61058, -1376139699, -7933661618777305277L, -80489L, true, true, (char) 2961, (char) 38140,
        Double.longBitsToDouble(0x3feec5fc183e1efcL), Double.longBitsToDouble(0x3f894e23f42caec0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\ud817\udfc3\udb7d\udcff\ud8bc\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud992\udf16\012",
        Z.run(T, 1, 3, 4, 8, "\ud817\udfc3\udb7d\udcff\ud8bc\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud992\udf16", "\u14c2\ubcab\ub935", "\udbfe\ude41\uda49\udfc0\udba5\udebb\uda42\ude19\ud97c\udcac\udb4b\ude05\uda1c\udc9b\udac9\udfaa\udbaf\udf4c\ud96b\ude14\ud96e\uddc1\udacd\udc54\uda50\udcb8\ud922\ude0e\udab5\udc73\ud850\uded1\uda5b\udc1b\uda88\udd85",
        46, 17658, 333677737, 4649446225480826848L, -37101L, false, true, (char) 42436, (char) 58410,
        Double.longBitsToDouble(0x3fd6634eaf3c3d48L), Double.longBitsToDouble(0x3fe49bcbfdd13f69L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\ud810\udc3c\udab8\udd5a\u0fc3\ud994\ude52\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\udbd8\ude48\ud983\udf73/\012",
        Z.run(T, 1, 1, 12, 9, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\ud810\udc3c\udab8\udd5a\u0fc3\ud994\ude52\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\udbd8\ude48\ud983\udf73", "\u9ccc\ub824\u16e3\uc196\u5c66\u525e\u5b79\u0f09\u95ab\u606e\u29ea\u17c1\u4d8e\u93b9\u8bf6\u3cb7\u7336\uba21\u034e\u3e60\u3f6d\u3944", "\ud9ba\ude38\udb9a\udc3e\ud8ff\udf2f\ud93c\udc0b\ud8c2\udd8f\ud919\ude30\ud9d2\udca7\ud813\udcd9\udbbe\udc5a",
        -4, 78957, -593292670, 1542501096276733501L, 90741L, true, true, (char) 49, (char) 51133,
        Double.longBitsToDouble(0x3fbac8bdbcabc880L), Double.longBitsToDouble(0x3fd675bc187d8c32L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 4, 0, "\000\ud838\udf7c", "\ucd88\u233d\034\u3c71\u7439\u2edc\uca11", "\u3b54\000\ud881\udebe\udaf8\udf18\000",
        36, 15112, 1089894343, -1602179847341292658L, -100000L, false, false, (char) 62604, (char) 43307,
        Double.longBitsToDouble(0x3fef2ab3518ea9d6L), Double.longBitsToDouble(0x3f4265823f4ab400L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 0, "\000", "\u3158\u11d7\u3ce4\u2e5b\u54b2\u38ff\u6b62\u14c2\ubcab\u1282\u5299\ucd46\ub930\ucd36\u06ca\uacc3\u77a3\ud138", "\ud9dd\udd0b\u5438\u2f9c\ud8b1\ude77",
        55, 90130, 1449791324, -6208528862588829842L, -59100L, true, true, (char) 16809, (char) 46047,
        Double.longBitsToDouble(0x3fd799b2ce218f1cL), Double.longBitsToDouble(0x3fd021ba332127b2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 0, "\000\ud867\udf8b\ud9ad\udf81", "\u233d\u9501\u54b2\u1cda", "\ud9d3\ude42\udbe9\udd2f\ud983\udf7a\ud95b\udefa\ud881\udfbb\uda49\udfc0\uda3d\udf6d\uda32\udf5c\ud97c\udcac",
        13, 56435, -454114454, 4468188084005423814L, -100000L, false, true, (char) 7456, (char) 43307,
        Double.longBitsToDouble(0x3fef2ab3576ea9d6L), Double.longBitsToDouble(0x3fe0963d0c3cb2d2L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb27\udd91\012",
        Z.run(T, 1, 3, 4, 8, "\udb27\udd91", "\u4fd2\ucd88\u233d\u9501\u54b2\u1cda\u2e9c\u14c2\ubcab\ub935\u5299\ucd46\uba5f\u41c1\u061f\u7239\u77a3\u74c5", "\ud9dd\udd0b\u5438\u2f9c\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -945684626, -5561235177398640527L, 79262L, false, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba320527b2L), Double.longBitsToDouble(0x3fe26efbbd8fee9bL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb27\udd91\ud867\udf8b\ud9e2\udf93\ud910\udd6d\udbfa\udf53\udbb8\udc14\u0fc3\udad3\udc22\ud8f2\udf2f\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a\ud96a\udfaa\ud881\udfbb\uda49\udfc0\uda3d\udfa0\uda32\udf5c\ud97c\udcac\ud808\udf9b\uda1c\udc9b\ud9fb\uddf2\udbe7\uddea\ud878\udd75\ud9b1\udf0b\ud940\ude23\uda1c\uddf9\ud86b\udfef\ud83f\udd76\ud903\udff1\ud8dd\udf46\uda88\udd85\ud8d3\udd48\ud925\uddab\uda54\ude83\udb87\udda2\ud9cf\ude25\udbfc\udcb0\012",
        Z.run(T, 1, 3, 4, 13, "\udb27\udd91\ud867\udf8b\ud9e2\udf93\ud910\udd6d\udbfa\udf53\udbb8\udc14\u0fc3\udad3\udc22\ud8f2\udf2f\ud97b\udc63\ud928\udf4f\ud9d3\uddda\udbe9\udd2f\ud983\udf7a\ud96a\udfaa\ud881\udfbb\uda49\udfc0\uda3d\udfa0\uda32\udf5c\ud97c\udcac\ud808\udf9b\uda1c\udc9b\ud9fb\uddf2\udbe7\uddea\ud878\udd75\ud9b1\udf0b\ud940\ude23\uda1c\uddf9\ud86b\udfef\ud83f\udd76\ud903\udff1\ud8dd\udf46\uda88\udd85\ud8d3\udd48\ud925\uddab\uda54\ude83\udb87\udda2\ud9cf\ude25\udbfc\udcb0", "\u29b0\u8587\uc32e\u7196\u6eac\u2ee3\u1791\u2dd3\ub5f5\ubd88\u90ea\u1d01\u2b4a\u489c\u89d9\u5861\u500b\u510a\u0a4a\u57cf\u9172\u9f7f\u7464\u6642\u8284\u8865\u31ac\u918b\ubab4\u6d41\u2507\ua9f8", "\udbff\udddd\u54b1\ud9de\udeda\ud82b\udf68\udb99\udc4f\ud9bf\udf1c\uda2d\udde8\ud8b2\udf19\udbbe\ude0d\uda7d\udf58",
        -1, 9388, -1735435172, -4007840536609298005L, -51171L, true, true, (char) 47876, (char) 62777,
        Double.longBitsToDouble(0x3fe421195b366a50L), Double.longBitsToDouble(0x3feadb62dad0c560L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 5, 5, 6, "\udb27\udd91\ud867\udf8b\ud8a7\udcbd\ud857\udf62\ud90b\udd20\udbb8\udc14\u0fc3\ud824\udc47\ud801\udfb4\uda2a\udc25\udaf1\udda9\ud9d3\uddda\udbe9\udd2f\udbf3\ude62\udb2f\udc51\ud950\udd59", "\u326d\u4599\u663d\u1e1e\u16e3\u5735\u4ef3\u606e\ua889\u396a\u5ff4\u2dc7\ua1d3\u7241\ua6c6\ub96a\u02df\u7d27\uba68\u5843", "\ud871\udf17\ud902\udf9d\ud85e\udc7f\u7d9a\ud930\uddc2\ud90f\udcb0\ud918\uddfa\ub34e\ud83d\udeeb\udbb3\udda2\ud95f\ude03\ud877\udfd6\udacb\udd3e\ud91e\uddf6\udaa6\udcd4\udab2\udde7\uda24\udf68\udba7\ude41\ud864\udd9e\udaec\udde0\udbe6\udd2c\udabe\udf9e\udadf\udfe0",
        23, 44220, 1890112112, 1848783341916273921L, 31403L, true, false, (char) 8707, (char) 6861,
        Double.longBitsToDouble(0x3fa81f672ed10ad0L), Double.longBitsToDouble(0x3fe33aa6636b6c71L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 10, 10, 8, "", "\u5d07", "\ud9c4\udec1\uda88\ude0f\ud9b4\udef5\u49fe\000\ud8f5\udd19\ud9d3\uddda\udbe9\udd2f\udb18\udfa5\uda6e\udf2f\ufdcb\udb51\udca7\udb71\udd68\u6745\ud987\udec8\ud808\udf9b\uda1c\udc9b\uda80\uddf5\ud8f5\uded7\u53da\u2f9c\ud86c\udd04\ud9cb\ude96",
        40, 36324, -1445563419, -6506857662438703094L, -5024L, true, true, (char) 20964, (char) 29861,
        Double.longBitsToDouble(0x3fe8863c75021ba3L), Double.longBitsToDouble(0x3fd02f9d9c9bbeeeL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\u2683\0121=com.fasterxml.jackson.core.JsonPointer:\u2683\012",
        Z.run(T, 2, 3, 3, 8, "\u2683", "\u1e7a\000\000\u0ded\u3591", "\ud928\udf4f\ud9d3\uddda\udbe9\udd2f",
        25, 18998, 1349604555, 5758260089651724302L, 46924L, false, true, (char) 5715, (char) 9956,
        Double.longBitsToDouble(0x3fec8c86364c00fbL), Double.longBitsToDouble(0x3fd6e3b995b5cf4cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 5, 5, 6, "\udb27\udd91\ud867\udf8b\ud8a7\udcbd\ud857\udf62\ud90b\udd20\udbb8\udc14\u0fc3\ud824\udc47\ud801\udfb4\uda2a\udc25\udaf1\udda9\ud9d3\uddda\udbe9\udd2f\udbf3\ude62\udb2f\udc51\u034f", "\u326d\u4599\u663d\u1e1e\u16e3\u5735\u4ef3\u606e\ua889\u396a\u5ff4\u2dc7\ua1d3\u7241\u47ab\u74ee", "\udb6d\udfcf\udb73\udf61\udbfc\udd3b\ud97d\udea2\ud871\udf17\ud902\udf9d\ud85e\udc7f",
        26, 31858, 1460479887, -1130470682875750613L, 48722L, false, true, (char) 55568, (char) 60165,
        Double.longBitsToDouble(0x3fe47688f22fb212L), Double.longBitsToDouble(0x3fde0e90b3197944L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 10, 4, 8, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\udbbc\udf1e\uda14\udeea\ud800\udf70\ud97b\udc63\ud992\udf45\udaa3\ude6e\ud9be\udfef\ud99e\udceb\uda86\udf33", "\u061f\u7239", "\uda1c\udc9b\udb9a\ude22\ud9e3\udcda\u5438\u2f9c\udb3b\udc35",
        2, 44906, 1449791324, 276654602128620971L, -59100L, true, true, (char) 16809, (char) 3393,
        Double.longBitsToDouble(0x3fd799b2ce21631cL), Double.longBitsToDouble(0x3fd021ba320527b2L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 13, 13, 8, "", "\u5d07", "\ud801\udfc0\udb52\ude94\ud8f2\ude53\ud801\ude31\000\ud8f5\udd19\ud9d3\uddda\udb29\udef0\ud91c\udda5\ud868\udf67\ufdcb\udb51\udca7\udb71\udd68\u6745\ud987\udec8\ud808\udf9b\uda9a\udf03\ud9c1\udc79\udafe\udf9d\u53da\u2f9c\ud86c\udd04\ud9cb\ude96",
        40, 36324, -1445535771, -6506857664472285174L, -5024L, true, true, (char) 111, (char) 26767,
        Double.longBitsToDouble(0x3fe8863c75021ba3L), Double.longBitsToDouble(0x3fd02f928ea4b152L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 4, 0, "6\ud838\udf7c", "\ucd88\u233d\034\u3c71\u7439\u2edc\uca11", "\u3b54\000\ud881\udebe\udbd6\udde7\uba89",
        36, 15112, -1334872121, -1602180255363185778L, -100000L, false, false, (char) 62604, (char) 43307,
        Double.longBitsToDouble(0x3fef2ab3518ea9d6L), Double.longBitsToDouble(0x3f4265823f4ab400L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:6\012",
        Z.run(T, 1, 0, 4, 0, "6", "\u4fd2\ucd88\u8197\034\u3c71\u7439\u2edc\uca11\ucff1\u1ca1\u3b54\000\u3116\u977e\uba89\u7239\u77a3\u117a", "\udba2\ude6f\u00fb\000\000\000\ud931\ude87",
        54, 76229, -1825801842, -3265954154120009585L, 47741L, true, false, (char) 21501, (char) 12628,
        Double.longBitsToDouble(0x3fa2a0c387628190L), Double.longBitsToDouble(0x3fced2fa77f4f308L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 4, 0, "6\000", "\u802e\000\000\u0b01\u733b\ub34d\u35db", "\u3b54\000\ud881\udebe\udbb9\udee7\uba89",
        36, 15112, -1334872121, -1602180255363185778L, -100000L, false, false, (char) 62604, (char) 43307,
        Double.longBitsToDouble(0x3fef2ab3518ea9d6L), Double.longBitsToDouble(0x3f4265823f4ab400L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 10, 4, 8, "\udb23\ude91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\u0fc3\ud8ca\ude1d\ud801\udfb4\ud97b\udc63\ud928\udf4f\ud9d3\uddda\uda02\uddfd\ud975\udfd0", "\u41c1\u061f\u7239\u77a3\u06c6", "\ud9dd\udd0b\uda50\udcb3\u2f7a\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -945684626, -5561235177398640580L, 79262L, false, true, (char) 13989, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba3afb27b2L), Double.longBitsToDouble(0x3feed9adcd8feee6L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 9, 9, 6, "\udb27\udd91\ud867\udf8b\ud893\udf54", "\u233d\u9501\ua609\u69e2\u669c\u14c2\uabab\u10e4\uc51c\u2c8f\u5b73\ub215\u0675\u7239\u274e\u505c\u3af7\ua884\u2ae2\ud6dc\ud25d\ud734\u8cb8", "\ud850\uded1\ud8c4\udfc5\uda20\udf9b\ud8c4\udec3\ud925\uddab\uda56\udd83",
        -3, 2161, -1824833327, 1012057941018841971L, 11476L, true, false, (char) 47903, (char) 58392,
        Double.longBitsToDouble(0x3fe257957e234c9aL), Double.longBitsToDouble(0x3fc6b8b862044f6cL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 11, 11, 5, "\udb27\udd91\ud9d9\udd53\ud9cb\udda7\ud950\udf32\udb40\udd73\udbb8\udc14\udab8\udcf1\ud9d8\udc70\ud8dc\udc88\ud95c\udd84\ud905\udd85\ud9d3\uddda\udaa6\udf7e\udb94\udfbb\ud95b\udefa", "\ucc56\u804a\u0732\u01dc\ua6f2\u5b79\u2ae2", "\ud86c\udd04\ud9cb\ude96\ud90f\udfa0",
        54, 76229, -945684626, -1697869329657274268L, 86631L, false, true, (char) 48036, (char) 55590,
        Double.longBitsToDouble(0x3fcbe926bda722f4L), Double.longBitsToDouble(0x3fee16f65b97883aL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 6, "\udb27\udd8e\ud878\ude72\ud883\ude79\ud864\udf2a\ud97a\udd0d\udbbb\udd74\u0fc3\ud824\udc47\ud801\udfb4\uda2a\udc25\udaf1\udda9\ud9d3\uddda\udbb8\udf5c\ud83a\udf30\ud9ea\uddf6\ud950\udd59", "\u9a3c\u500f\u6e7b\u9790", "\u5438\u2f9c\ud923\ude5b",
        48, 78954, 1885998940, -6228632253197320338L, -59100L, false, true, (char) 16809, (char) 13408,
        Double.longBitsToDouble(0x3fd8bad11a6c1324L), Double.longBitsToDouble(0x3fd020ff720527b2L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 4, 4, 8, "", "\u5d07", "\ud801\udfc0\udb52\ude94\ud9b4\udef5\udaf2\udd4cE\ud8f5\udd19\ud8a9\udd45\ud91f\udf02\udb56\ude31\uda6e\udf8a\ufdcb\udb51\udca7\udaae\udf86\u6801\uda3b\udf4a\ud977\udd32\ud9b2\udc83\udbe1\udc36\ud9c0\ude9e\udaeb\udffe\uda8b\ude1a\uda9a\udd7b\ud988\udfaf",
        -2, 50717, -1445200710, -6477606257440167901L, -65989L, true, false, (char) 56487, (char) 58989,
        Double.longBitsToDouble(0x3fd6af430a39589aL), Double.longBitsToDouble(0x3fd02f9b1c9b6054L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\ud9ba\udee2\udb6d\udece\ud8bb\udc8c\uda31\ude71\ud9cb\udd49\udbbc\udda0\uda28\ude34\ud920\ude90\ud95b\udefa\ud881\udfbb\uda49\udfc0\u4fb9\ueec6\ud951\ude16\uf0f0\ud983\udcaf\uda89\udd3a\ud9dd\udd0b\u5438~\u0339\0121=com.fasterxml.jackson.core.JsonPointer:\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\ud9ba\udee2\udb6d\udece\ud8bb\udc8c\uda31\ude71\ud9cb\udd49\udbbc\udda0\uda28\ude34\ud920\ude90\ud95b\udefa\ud881\udfbb\uda49\udfc0\u4fb9\ueec6\ud951\ude16\uf0f0\ud983\udcaf\uda89\udd3a\ud9dd\udd0b\u5438\012",
        Z.run(T, 2, 1, 2, 5, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udbfa\udf3a\udbb8\udc14\ud9ba\udee2\udb6d\udece\ud8bb\udc8c\uda31\ude71\ud9cb\udd49\udbbc\udda0\uda28\ude34\ud920\ude90\ud95b\udefa\ud881\udfbb\uda49\udfc0\u4fb9\ueec6\ud951\ude16\uf0f0\ud983\udcaf\uda89\udd3a\ud9dd\udd0b\u5438", "\u8cb8\u7139\ucdc7\ua1c6\u0bff\u1038\u2b68\u4cbb\u5e38\u3414\u80a7\u8299\u44d4\u7272\ua515\u1fc1\ub1b0\u48c5\ucc80\u187f\ucc69\u1396\u4891\u76d6\ub577\ub4b9", "\ud81b\udd6d\uda97\udce2\u60cf\ud803\udcc7\udb3f\udd59\udbfa\udc4f\uda1f\udcdd\ud8d7\udc22\ud9ac\udd6e\ud971\udeb7\ud880\udc21\ud981\udda3\ud909\udfce\ud853\udf22\udabc\ude46\ud82b\ude48\ud961\udc91\udb5d\uddab\udb47\udcf6\ud8e1\udf45\u4d1b\udb1d\udd4b",
        31, 32881, -228107743, -1405639273316500255L, -1616L, true, true, (char) 825, (char) 10692,
        Double.longBitsToDouble(0x3fe5b6d4a9f9b242L), Double.longBitsToDouble(0x3fdaee0e91a1e636L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 15, "6\000", "\u802e\000\u2373\u0b8f\u733b\ub34d\u35db", "\u3b54\000\ud881\udebe\udbb9\udee7\uba89",
        -4, 37868, -1334872121, -1602180255363185778L, -100000L, false, false, (char) 30366, (char) 40773,
        Double.longBitsToDouble(0x3fef2ab0d18ea9d6L), Double.longBitsToDouble(0x3f4265823f4ab400L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udb0c\udc3a\udab8\udd5a\udb7b\udefe\ud994\udeb9\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\udbe9\udd2f\ud983\udf7a~\u74a5\0121=void |a0=java.lang.StringBuilder:\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udb0c\udc3a\udab8\udd5a\udb7b\udefe\ud994\udeb9\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\udbe9\udd2f\ud983\udf7a~\u74a5\012",
        Z.run(T, 2, 1, 1, 8, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\udb0c\udc3a\udab8\udd5a\udb7b\udefe\ud994\udeb9\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\udbe9\udd2f\ud983\udf7a", "\u7129\uc76a\ubdb8\u5353\u33a4", "\ud9dd\udd0b\u5438\u2f9c\ud94c\ude85\ud9f0\udfaa\udb7c\udf5b",
        45, 37978, 533376901, -5561372959949496260L, 79262L, false, true, (char) 29861, (char) 13539,
        Double.longBitsToDouble(0x3fcd12d1ddc86390L), Double.longBitsToDouble(0x3fd43a6beb1f4384L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\012",
        Z.run(T, 2, 10, 4, 8, "/", "\uc4d6\u1520\u27c1\u5051\u3591\u49fe\000\u1e8b\ubcab\u73df\u758f\uc900\u1dfa\u85a1\ub4a2\uafd3\u48c8\u74c5", "\ud8f5\udeca\u53da\u2f9c\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -1514995858, 5354779999379236737L, -75733L, true, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba32051670L), Double.longBitsToDouble(0x3fe26efbb88d91aeL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:/\0121=com.fasterxml.jackson.core.JsonPointer:/\012",
        Z.run(T, 2, 4, 4, 8, "/", "\uc4d6\u1520\u27c1\u5051\u3591\u49fe\000\u1e8b\ubcab\u73df\u758f\uc900\u1dfa\u85a1\ub4a2\uafd3\u48c8\u74c5", "\ud8f5\udeca\u53da\u2f9c\ud86c\udd04\ud9cb\ude96\ud8f6\udf74",
        54, 76229, -1514995858, 5354779999379236737L, -75733L, true, true, (char) 29861, (char) 44702,
        Double.longBitsToDouble(0x3fd021ba32051670L), Double.longBitsToDouble(0x3fe26efbb88d91aeL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 15, "6\ucf00", "\u77d1\010\u2373\u5ded\u73e7\ub34d\u35db", "\u3be8",
        -5, 71768, -323682293, 205096390590804L, 87701L, false, false, (char) 31505, (char) 38156,
        Double.longBitsToDouble(0x3fef2ab0d7506189L), Double.longBitsToDouble(0x3fc57476423f4ab4L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Integer:6\0121=java.lang.Integer:6\012",
        Z.run(T, 2, 0, 0, 15, "6", "\u4fd2", "\ud814\ude29",
        9, 65344, 6460121, 4205718587171061215L, -13900L, false, false, (char) 3399, (char) 20614,
        Double.longBitsToDouble(0x3fe44f65a9540000L), Double.longBitsToDouble(0x3fef673c8f476debL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u49fe\000\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\udb56\uddc8\ud808\udf9b\uda0c\udd9b\uda80\uddf5\ud8f5\udeca\ud931\udfb5\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udace\udfdd\ud850\uded1\uda9a\ude1b\ud845\udc6b\udb4d\uddb2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\udaaf\udfcc\udbdd\udd07\ud85f\udfba\udb7f\udccb\ud9fb\udfbc\ud986\ude51\udb11\udea1\ud989\udefc\udaa2\udf74\ud9b1\udf56\ud8f5\ude97\udbd9\udd53\udab1\udf44\udbf4\ude1c\udb50\udc86\u2bc5\udbc2\ude91\uda98\udf39\uda41\udfe0\uda71\udd66\uda3d\udceb\ud8e4\udc68\uda62\udd61\udb4e\ude82\udae5\ude76\ud87c\ude42\ud9e1\udc3d\ud9a4\ude9b\ud913\udd7d\uda7e\udff0\ud940\udda0\ud939\udce3\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69\012",
        Z.run(T, 2, 10, 4, 14, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u49fe\000\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\udb56\uddc8\ud808\udf9b\uda0c\udd9b\uda80\uddf5\ud8f5\udeca\ud931\udfb5\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udace\udfdd\ud850\uded1\uda9a\ude1b\ud845\udc6b\udb4d\uddb2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\udaaf\udfcc\udbdd\udd07\ud85f\udfba\udb7f\udccb\ud9fb\udfbc\ud986\ude51\udb11\udea1\ud989\udefc\udaa2\udf74\ud9b1\udf56\ud8f5\ude97\udbd9\udd53\udab1\udf44\udbf4\ude1c\udb50\udc86\u2bc5\udbc2\ude91\uda98\udf39\uda41\udfe0\uda71\udd66\uda3d\udceb\ud8e4\udc68\uda62\udd61\udb4e\ude82\udae5\ude76\ud87c\ude42\ud9e1\udc3d\ud9a4\ude9b\ud913\udd7d\uda7e\udff0\ud940\udda0\ud939\udce3\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69", "\u1200", "\udb05\ude41\ud895\udf26\ud8ec\udd9b",
        43, 31370, 2095799416, 7104378408938681231L, -1949L, false, false, (char) 35882, (char) 62617,
        Double.longBitsToDouble(0x3fcdf92517f108a8L), Double.longBitsToDouble(0x3fe9bd3542b13aa2L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\ud96f\uddb4\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\udb4d\uddb2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\udaaf\udfcc\udbdd\udd07\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud989\udefc\udaa2\udf74\ud9b1\udf56\ud8f5\ude97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\ud91d\udcdc\ud832\ude80\ud82b\ude1e\uda3d\udceb\udaa6\udf69\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\uda06\udc54\ud9a4\ude9b\ud91b\udf63\uda7e\udff0\ud940\udda0\ud939\udce3\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69\012",
        Z.run(T, 2, 10, 4, 14, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\ud96f\uddb4\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\udb4d\uddb2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\udaaf\udfcc\udbdd\udd07\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud989\udefc\udaa2\udf74\ud9b1\udf56\ud8f5\ude97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\ud91d\udcdc\ud832\ude80\ud82b\ude1e\uda3d\udceb\udaa6\udf69\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\uda06\udc54\ud9a4\ude9b\ud91b\udf63\uda7e\udff0\ud940\udda0\ud939\udce3\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69", "\u1200\u2e62\u7f75\ud40a", "\ud930\udd5d\uf0e1\uda52\udfd4\ud990\udf2d\udb49\udf3d",
        9, 23661, 1856723616, -3063822691117555938L, -90276L, true, true, (char) 21843, (char) 33830,
        Double.longBitsToDouble(0x3fed65f22f745dd4L), Double.longBitsToDouble(0x3fee57a9b73a267dL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\ud96f\uddb4\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\012",
        Z.run(T, 2, 10, 4, 14, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\ud96f\uddb4\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef", "\u68a4\u2b32\u5df4\u1568\u4999\ua693\u57d2\u2a9a\u8395\u438d\u2aa8\u05e7\u68c9\ua9cf", "\ud989\udefc\udaa2\udf74\ud9b1\udf56\ud8f5\ude97\udbd9\udd53\udabc\ude44",
        47, 12297, 1449460426, -8401553783796371588L, -7050L, true, true, (char) 20768, (char) 8135,
        Double.longBitsToDouble(0x3feb5b5c99afa945L), Double.longBitsToDouble(0x3fdbc66d0e4cded4L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud833\udc14\000~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\u7167\ud8f5\ude73\ud96f\uddb4\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\udb4d\uddb2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\uc64d\000\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud989\udefc\udaa2\udf74\ud9b1\udf56\ud8f5\ude97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\000\000\ud82b\ude1e\uda3d\udceb\udaa6\udf69\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\uda06\udc54\u00a8\000\000\ud940\udda0\ud939\udce3\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69\012",
        Z.run(T, 2, 10, 4, 14, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud833\udc14\000~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\u7167\ud8f5\ude73\ud96f\uddb4\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\udb4d\uddb2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\uc64d\000\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud989\udefc\udaa2\udf74\ud9b1\udf56\ud8f5\ude97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\000\000\ud82b\ude1e\uda3d\udceb\udaa6\udf69\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\uda06\udc54\u00a8\000\000\ud940\udda0\ud939\udce3\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69", "\u01c6\u2e62\u7f75\ud40a", "\ud930\udd5d\uf0e1\uda52\udfd4\ud990\udf2d\udb49\udf3d",
        9, 23661, 1856723616, -3063822691117555938L, -90276L, true, true, (char) 21843, (char) 33830,
        Double.longBitsToDouble(0x3fed65f22f745dd4L), Double.longBitsToDouble(0x3fee57a9b73a267dL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\012",
        Z.run(T, 2, 10, 4, 14, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~", "\u73df\u758f", "\udb51\udca7\udb71\udd68",
        36, 97020, 1089894346, 7891501642823893337L, 34238L, true, false, (char) 55680, (char) 33348,
        Double.longBitsToDouble(0x3fccfc94931adbe8L), Double.longBitsToDouble(0x3fe9e23fe928c30aL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\012",
        Z.run(T, 2, 10, 4, 8, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5", "\u85a1\ub4a2", "\ud808\udf9b\ud8bb\udd63",
        25, 79967, -755889058, -4932216888204321293L, -20359L, false, false, (char) 20752, (char) 1075,
        Double.longBitsToDouble(0x3fbfe206bc0a52f8L), Double.longBitsToDouble(0x3fd00e15d26b7a9cL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\uda0d\udc41\udac9\ude6a\u70a3\uda37\udc22\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\ud96f\uddb4\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\udb4d\uddb2\ud950\udc55\u7d1c\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\uda60\ude7b\ud9ad\udea2\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud998\udce2\udaa2\udf74\ud9b1\udf56\uda75\udc97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\ud91d\udcdc\ud832\ude80\ud90d\udc0f\ud895\ude3a\uda53\udf73\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\ud90f\udc6a\udb6b\ude0c\udb08\udcba\udbd2\udef5\ud8d0\udec3\ud931\udd91\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\uda0d\udc41\udac9\ude6a\u70a3\uda37\udc22\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\ud96f\uddb4\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\udb4d\uddb2\ud950\udc55\u7d1c\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\uda60\ude7b\ud9ad\udea2\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud998\udce2\udaa2\udf74\ud9b1\udf56\uda75\udc97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\ud91d\udcdc\ud832\ude80\ud90d\udc0f\ud895\ude3a\uda53\udf73\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\ud90f\udc6a\udb6b\ude0c\udb08\udcba\udbd2\udef5\ud8d0\udec3\ud931\udd91\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69\012",
        Z.run(T, 2, 3, 4, 9, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\uda0d\udc41\udac9\ude6a\u70a3\uda37\udc22\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\ud96f\uddb4\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\udb4d\uddb2\ud950\udc55\u7d1c\udb8c\udf27\ud9cf\ude25\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\uda60\ude7b\ud9ad\udea2\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud998\udce2\udaa2\udf74\ud9b1\udf56\uda75\udc97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\ud91d\udcdc\ud832\ude80\ud90d\udc0f\ud895\ude3a\uda53\udf73\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\ud90f\udc6a\udb6b\ude0c\udb08\udcba\udbd2\udef5\ud8d0\udec3\ud931\udd91\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69", "\u1200\u2e62\u0864\ud4d0", "\ud930\udd5d\uf0e1\uda52\udfd4\ud990\udf2d\udb49\udf3d",
        9, 23661, 1856723616, -3063822691117555938L, -90276L, true, true, (char) 21843, (char) 33830,
        Double.longBitsToDouble(0x3fed65f22f745dd4L), Double.longBitsToDouble(0x3fee57a9b73a267dL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\012",
        Z.run(T, 2, 10, 4, 14, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00", "\uafd3\ucbac\u74c5\ua0bb\u7143\u26f4\uae5f\uc5be\u6a86\u1271\u925b\uaed7\u2d7c\u7b0d\u68a4\u2b32\u5df4\u1568\u4999\ua693\u57d2", "\udaaf\udfc8\udbdd\udcb1\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb1b\udf62\udbb1\ude5f\udaa2\udf74\ud9b1\udf56\ud8f5\ude97\udbd9\udd53\udaa1\udc72\ud8d2\udf2b\ud810\ude5c\ud971\udfe1",
        5, 44212, 1792760884, -6074956679684834459L, -59216L, true, true, (char) 25332, (char) 8332,
        Double.longBitsToDouble(0x3fe9337e4ba8140dL), Double.longBitsToDouble(0x3fdb1755795b2a12L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:/\ua00f\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\udbf3\udca8\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\u2db2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9fd\udcfb\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\udaaf\udfcc\udbdd\udd07\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud989\udefc\udaa2\udf74\ud9b1\udeb6\ud8f5\ude97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\ud91d\udcdc\ud832\ude80\ud82b\ude1e\uda3d\udceb\uda87\udfeb\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\ud86d\ude08\ud8f3\udc80\ud91b\udf63\uda7e\udff0\ud940\udda0\ud939\udce3\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69\0121=com.fasterxml.jackson.core.JsonPointer:/\ua00f\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\udbf3\udca8\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\u2db2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9fd\udcfb\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\udaaf\udfcc\udbdd\udd07\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud989\udefc\udaa2\udf74\ud9b1\udeb6\ud8f5\ude97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\ud91d\udcdc\ud832\ude80\ud82b\ude1e\uda3d\udceb\uda87\udfeb\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\ud86d\ude08\ud8f3\udc80\ud91b\udf63\uda7e\udff0\ud940\udda0\ud939\udce3\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69\012",
        Z.run(T, 2, 3, 4, 14, "/\ua00f\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9b\ud8bb\udd63\uda4f\udfc0\ud8f5\udeca\udbf3\udca8\ud93e\uded6\ud874\ude28\ud8d6\udd41\ud957\udc99\udb73\uddef\ud946\udfea\ud86e\ude17\u5ce1\u2db2\udb46\udd11\ud90c\udea7\udb8c\udf27\ud9fd\udcfb\udbfc\udcb0\ud8b9\ude20\ud9ad\udeb4\udaaf\udfcc\udbdd\udd07\ud85f\udfba\udb7f\udccb\ud97c\udc38\ud986\ude51\udb11\udea1\ud989\udefc\udaa2\udf74\ud9b1\udeb6\ud8f5\ude97\udbd9\udd53\udabc\ude44\ud8d2\udf2b\ud810\ude5c\ud971\udfe1\udbec\udc79\ud91d\udcdc\ud832\ude80\ud82b\ude1e\uda3d\udceb\uda87\udfeb\udbc7\udf06\uda23\ude4e\ud84f\udfbe\udb92\udc4c\ud86d\ude08\ud8f3\udc80\ud91b\udf63\uda7e\udff0\ud940\udda0\ud939\udce3\ud85c\ude71\udb9e\udef4\ud9fc\ude8f\ud9c1\udd04\udb8a\udd69", "\u1200\u2e62\u7f75\ud40a", "\ud930\udd5d\uf0e1\uda52\udfd4\ud990\udf2d\udb49\udf3d",
        9, 23661, 1856723616, -3063822691117555938L, -90276L, true, true, (char) 55992, (char) 33810,
        Double.longBitsToDouble(0x3fed6636af745dd4L), Double.longBitsToDouble(0x3fee57a9b73a267dL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\udaf4\udd54\udad4\uddc9\ud847\uddf7\udb25\udd38\ud801\udfc0\udb52\ude94\ud9d0\udf03\u70a3~\udb1f\udd6f\012",
        Z.run(T, 2, 10, 4, 14, "/\udaf4\udd54\udad4\uddc9\ud847\uddf7\udb25\udd38\ud801\udfc0\udb52\ude94\ud9d0\udf03\u70a3~\udb1f\udd6f", "\u758f\u922e", "\ud854\udeac\u6789",
        0, 2346, 1837383407, -1950620105289485993L, 68737L, true, true, (char) 33348, (char) 17036,
        Double.longBitsToDouble(0x3fc8d6df5cf11ff4L), Double.longBitsToDouble(0x3fd28c30ae7999a0L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb65\udd39\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9e\ud8bb\udd63\012",
        Z.run(T, 2, 10, 4, 14, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb65\udd39\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\udb51\udca7\udb71\udd68\u6745\ud9cd\udcc7\ud808\udf9e\ud8bb\udd63", "\uae5f\uc5be\u4a92", "\ud804\udd04\ud946\udfa4",
        52, 36016, -1227434501, 3094929519507441331L, -11535L, true, true, (char) 53958, (char) 27325,
        Double.longBitsToDouble(0x3fdc69ff11c646eeL), Double.longBitsToDouble(0x3fe11acf8c5a64ffL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\udb44\ude17\udb25\udd38\ud801\udfc0\udb98\udcf1\ud986\udd01\u70a3~\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\udb44\ude17\udb25\udd38\ud801\udfc0\udb98\udcf1\ud986\udd01\u70a3~\012",
        Z.run(T, 2, 3, 4, 14, "/\ud868\udc0e\uda47\udf37\udb44\ude17\udb25\udd38\ud801\udfc0\udb98\udcf1\ud986\udd01\u70a3~", "\u73df\u758f", "\udb51\udca7\udb71\udd68",
        36, 97020, 1089894346, 7891501642823893337L, 57563L, false, false, (char) 44427, (char) 52160,
        Double.longBitsToDouble(0x3fef123fe928c30aL), Double.longBitsToDouble(0x3fee7ce29bf7fc57L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Integer:62\012",
        Z.run(T, 1, 0, 4, 0, "62", "\u63dd\000\000\u0b01\u733b\u923a\ud6b9", "\u3b54\000\ud881\udebe\udbb9\udee7\uba89\uda0b\uddc8\ud97c\udcac\uda7c\udf16\uda1c\udc3c\uda64\udcf5\udba2\ude6f\u00fb\u3d0f\u91d4\000\ud931\ude87\udab5\udc73\ud850\uded1\ud88a\udf24\ud8a9\udd54\udb85\udd6c\udb32\udfeb",
        30, 40940, -1058712799, 3414241724163673352L, -5202L, true, true, (char) 26076, (char) 19176,
        Double.longBitsToDouble(0x3fe84782f1eaa86dL), Double.longBitsToDouble(0x3fdd5572f95631feL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9d2\uddf6\012",
        Z.run(T, 2, 10, 4, 14, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\u70a3~\udb1f\udd6f\ud9d2\uddf6", "\u922e\ud792\u85a1\ub4a2\ub103\ucb17\u74c5\ua0bb\u7143\u26f4\uae5f\uc5be\u4a92\u1271\u925b\uaed7\u8f42\u7b0d\u68a4\u2b32\u8a9d\ub0b9\u4999\ua693\u57d2\u2a9a\u8395\u438d\u2aa8\u05e7\u68c9\u1e8d\uc030\u8877\ub119\u3833\u94c6", "\ud964\udf18\udb08\ude41\udb1c\udef9\uda43\udff9\udbc5\udef0",
        22, 9884, -1414436074, 1865540712038545213L, -4917L, true, true, (char) 33383, (char) 25616,
        Double.longBitsToDouble(0x3fe90ed8ee7f26d5L), Double.longBitsToDouble(0x3fc6c0e07572e2e0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\uda7d\udf33/\012",
        Z.run(T, 2, 10, 4, 8, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\uda7d\udf33/", "\u73df\u758f", "\udb51\udca7\udb71\udd68",
        36, 97020, -1510462518, 7891699267154084185L, 99774L, true, false, (char) 55680, (char) 33348,
        Double.longBitsToDouble(0x3fccfc94831adbe8L), Double.longBitsToDouble(0x3fe9e4788928c30aL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\uda7d\udf33/\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\uda7d\udf33/\012",
        Z.run(T, 2, 3, 4, 8, "/\ud868\udc0e\uda47\udf37\uda88\uddf9\udb25\udd38\ud801\udfc0\udb52\ude94\ud9b4\udef5\uda7d\udf33/", "\u73df\u758f", "\udb51\udca7\udb71\udd68",
        36, 97020, 2029530058, -437940382355029672L, 99774L, true, false, (char) 55680, (char) 58667,
        Double.longBitsToDouble(0x3fcce078831adbe8L), Double.longBitsToDouble(0x3fe9e4788928c30aL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 12, 9, "\udb27\udd91\ud867\udf8b\ud893\udf54\ud857\udf62\ud810\udc3c\udab8\udd5a\u0fc3\ud994\ude52\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\ud84c\udfc2\ud983\udf73", "\u9ccc\ub824\u6ef2\uc196\u5c66\u525e\u5b79\u0f09\u95ab\u606e\u0e91Q\u4d58\u93b9\u0e56\u3ce7\u7336\uba21\u034e\u3e60\u3f6d\u3944", "\ud9ba\ude38\udb9a\udc3e\ud8ff\udf2f\ud953\ude0b\udacd\udf56\ud904\udc36\ud9d2\udca7\ud813\udcd9\ud996\ude06",
        8, 78957, -1475171005, -2187725407374341370L, -28743L, false, false, (char) 48, (char) 51133,
        Double.longBitsToDouble(0x3fec9917b7957929L), Double.longBitsToDouble(0x3fd67a6ed87d8c32L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb2f\ude78\ud9e9\udddc\udb5f\ude26\ud857\udf2a\udbed\udfd9\udac7\udeda\u0fc3\ud994\ude52\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\ud84c\udfc2\ud983\udf73~\012",
        Z.run(T, 1, 1, 10, 3, "\udb2f\ude78\ud9e9\udddc\udb5f\ude26\ud857\udf2a\udbed\udfd9\udac7\udeda\u0fc3\ud994\ude52\udb40\udc2c\udb9f\udc98\ud90f\udc75\ud9d3\uddda\ud84c\udfc2\ud983\udf73", "\u9ccc\u96ee\ua354\u160e\u6a3b\ud10a\uae26\u0f60\u8a4e\u709a\u0e91Q\u4d58\u93b9\u0e56\u3ce7\u7336\uba21\u034e\u3e60\u3f6d\u3944", "\ud8e4\udecd\udb9a\udc1d\ud8ff\udf2f\ud953\ude0b\udacd\udf56\ud904\udc36\ud9d2\udca7\ud813\udcd9\udba8\ude09",
        8, 78957, -1469403837, -2187725408716518650L, -20295L, false, false, (char) 48, (char) 51133,
        Double.longBitsToDouble(0x3fec9917b7957929L), Double.longBitsToDouble(0x3feb3d37685639fcL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\ud8d7\udfde\uda88\uddf9\uda65\uddea\ud801\udfc5\udb52\ude94\ud9b4\udf85\uda7d\udf33/\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\0121=com.fasterxml.jackson.core.JsonPointer:/\ud868\udc0e\ud8d7\udfde\uda88\uddf9\uda65\uddea\ud801\udfc5\udb52\ude94\ud9b4\udf85\uda7d\udf33/\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00\012",
        Z.run(T, 2, 3, 4, 8, "/\ud868\udc0e\ud8d7\udfde\uda88\uddf9\uda65\uddea\ud801\udfc5\udb52\ude94\ud9b4\udf85\uda7d\udf33/\udb1f\udd6f\ud9db\uddf6\ud970\ude94\udb18\udfa5\u557c\uda8b\udf00", "\uba7b\ucb74\u9329\ud056\u7142\u26f4\u7e31\ub1be\u4a92\u3a3d", "\ud923\udd1c\udbbd\udedf\uda94\udd7b\udba5\udd9e\udb0e\udcba",
        6, 50604, -1335130736, 5633088668031380210L, 11268L, false, false, (char) 31664, (char) 48017,
        Double.longBitsToDouble(0x3fcc09309213e718L), Double.longBitsToDouble(0x3fe9d8895684ac8fL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 9, 9, 6, "\udb27\udd91\ud867\udf8b\ud893\udf54", "\u233d\u9501\ua609\u69e2\u669c\u14c2\uabab\u10e4\uc51c\u2c8f\u5b73\ub215\u737d\uc0d4\u274e\u505c\u3af7\ua884\u2ae2\ud6dc\ud25d\ud734\u8cb8", "\ud850\uded1\ud8c4\udfc5\uda20\udf9b\ud805\udc84\ud925\uddab\uda67\uddcc",
        -1, 2161, -1824833327, 1012057940002921843L, 90890L, false, false, (char) 13626, (char) 47745,
        Double.longBitsToDouble(0x3fea021ef8836b95L), Double.longBitsToDouble(0x3fe257957e234c9aL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb27\udd91\ud86f\ude8b\ud893\udf54\ud857\udf62\ud810\udc3c\udab8\udd5a\ud9ae\udf17\udb69\udd4e\uda0e\udcea\udb8b\udc4f\ud90f\udc75\ud9d3\uddda\ud84c\udfc2\ud983\udf73~\0121=void |a0=java.lang.StringBuilder:\udb27\udd91\ud86f\ude8b\ud893\udf54\ud857\udf62\ud810\udc3c\udab8\udd5a\ud9ae\udf17\udb69\udd4e\uda0e\udcea\udb8b\udc4f\ud90f\udc75\ud9d3\uddda\ud84c\udfc2\ud983\udf73~\012",
        Z.run(T, 2, 1, 1, 9, "\udb27\udd91\ud86f\ude8b\ud893\udf54\ud857\udf62\ud810\udc3c\udab8\udd5a\ud9ae\udf17\udb69\udd4e\uda0e\udcea\udb8b\udc4f\ud90f\udc75\ud9d3\uddda\ud84c\udfc2\ud983\udf73", "\u9ccc\ub824\u09f3\u9148\u5c66\u525e\u5b79\ucb12\u9609\u606e\u0e91Q\u4d58\ua3ba\u891b\u3ce7\u7336\uba21\ub529\u5af9\u3f3f\u7d30", "\ud9ba\ude38\uda0f\udfa7\ud8ff\udf2f\ud953\ude0b\udacd\udf56\ud904\udc36\ud9d2\udca7\ud813\udcd9\uda38\udd98",
        50, 47338, -757740087, -2187671290786411770L, -28743L, false, true, (char) 48, (char) 51133,
        Double.longBitsToDouble(0x3fec9917b7957929L), Double.longBitsToDouble(0x3fd67a6ed87d8c32L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.JsonPointer|_parseIndex|java.lang.String|static",
    "M|com.fasterxml.jackson.core.JsonPointer|_appendEscape|java.lang.StringBuilder,char|static",
    "M|com.fasterxml.jackson.core.JsonPointer|_parseQuotedTail|java.lang.String,int|static",
    "M|com.fasterxml.jackson.core.JsonPointer|_parseTail|java.lang.String|static",
    "M|com.fasterxml.jackson.core.JsonPointer|compile|java.lang.String|static",
    "M|com.fasterxml.jackson.core.JsonPointer|equals|java.lang.Object|new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|getMatchingIndex||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|getMatchingProperty||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|hashCode||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|matchElement|int|new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|matchProperty|java.lang.String|new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|matches||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|mayMatchElement||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|mayMatchProperty||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|tail||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|toString||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|_parseIndex|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
