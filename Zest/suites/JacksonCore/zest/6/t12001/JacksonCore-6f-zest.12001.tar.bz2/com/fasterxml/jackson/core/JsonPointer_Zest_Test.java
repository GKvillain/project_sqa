package com.fasterxml.jackson.core;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonPointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 9, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud973\udea4\udb74\ude95\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51", "\u7841\ua0ed", "\udbdd\udcaf\udb6e\udde9\udb8d\udd11\udbae\udcc4\udbe6\ude65\udb83\udf54",
        25, 39984, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 31759, (char) 54705,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fe760808f42dbf6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 9, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud973\udea4\udb74\ude95\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udb56\udcce\ud85e\udd1a\uec03\ud8d3\ude67\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51", "\ua293\ua113\ud5da", "\udb6e\udde9\udb8d\udd11\udbae\udcc4\udbe6\ude65\udb83\udf54\uda22\uddf5\udbd8\udc6b\ud911\uddd0\uda5e\udc3d\ud96e\ude98\uda61\ude48\ud98d\udea7\ud97f\udf4a\udaa6\udf8a\ud848\ude10\ud9ce\udec9\ud9a0\ude0c",
        51, 81232, 1613654320, 7821755014798434695L, -64028L, true, true, (char) 7322, (char) 26811,
        Double.longBitsToDouble(0x3fe6e797ddae4b2eL), Double.longBitsToDouble(0x3fe03484bd794f5aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 5, 5, 12, "\udb03\udfb1\ud9bd\uddf2", "\ucc08\u2c42\u6fb2\ub36a\u22a7\u76db\u38a1\u5671\uc7c1\ud337\u3c0a\ub773", "\uda3b\ude92",
        18, 38831, 354685715, 1779525517371716151L, 54162L, false, true, (char) 50303, (char) 45692,
        Double.longBitsToDouble(0x3fe290c7e0c5b538L), Double.longBitsToDouble(0x3fd99c1389bfe3e2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 0, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\000\ue57b\u3d43\udb12\udc8f\ud835\udf8e\ud9be\ude04\000\ud90c\udc45\ud861\uddec\ud818\udf02\ud8a7\udc76\ud822\udf10\uec03\uf4bc\000\ud984\udf01\udb64\udd93\udaa4\udeea\ud84a\udf15", "\u3d51", "\udb0c\udf48\udbdd\udcaf",
        12, 52445, 22784, 0L, -100000L, false, false, (char) 9984, (char) 42998,
        Double.longBitsToDouble(0x3feafae7ef30754cL), Double.longBitsToDouble(0x3fa039f95b56e5a0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 11, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud973\udea4\udb74\ude95\udb51\udc03\udae6\udc68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51", "\u7841\ua0ed", "\udbdd\udcaf\udb6e\udde9\ud87a\udc26\ud88c\udf67\udae4\udf93\udb83\udf54",
        25, 39984, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 31759, (char) 54705,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fe760808f42dbf6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud973\udea4\udb74\ude95\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud9b2\udee6\uda3b\ude92\ud90c\udd20\uda6e\ude26\udbc3\udc51\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud973\udea4\udb74\ude95\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud9b2\udee6\uda3b\ude92\ud90c\udd20\uda6e\ude26\udbc3\udc51", "\u7841\ua0ed", "\udbdd\udcaf\udb6e\udde9\uda48\udd57\udbae\udc34\udb29\udf77\udac8\udc6a",
        54, 39984, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 31759, (char) 30624,
        Double.longBitsToDouble(0x3fd8b023cdc64e98L), Double.longBitsToDouble(0x3fdc083e9c0c7cd6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 9, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud973\udea4\udb74\ude95\000\udadf\udc8f\ud94f\udfbb\ud9be\ude06\000\000\udbb5\udd3a\u956a\uda71\udc58\ud85e\udd80\uec03\ud8d3\ude67\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51", "\000\ua0ed", "\udbdd\udcaf\udb6e\udde9\udb8d\udd11\udbae\udcc4\udbe6\ude65\udb83\udf54",
        -5, -1000, 15513792, 0L, -100000L, false, false, (char) 31759, (char) 54705,
        Double.longBitsToDouble(0x3fec0006f91af3e6L), Double.longBitsToDouble(0x3fe7608088000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 9, 5, 12, "\udb03\udfb1\ud9c6\udcf2\ud8bc\udf05\ud870\udde2\ud933\udc86\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\ud82c\udd50\ud924\udf74\ud828\udf30\ud83d\udcde\ud895\udeed\uda4e\uddef\udb1e\uddc0\ud977\uded6\u3d08\udb6f\uddcf\udb64\udd93\uda19\udfe4\udbd2\udc89", "\u437a\ua0ed", "\udbdd\udcaf\udb6e\udde9\udb8d\udd11\udbae\udcc4\udbe6\ude65\udb83\udf54",
        25, 39984, 1441577152, -7371318699938924508L, 61584L, false, false, (char) 31759, (char) 45722,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fed693196829e82L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 12, "\udb03\udfb1", "\u22cc\000\000\uc8c5\000", "\ud924\udf74\ud8ac\udcb1\ud818\ude98\udb56\udcce\ud85e\udd80\uec03\000\000\000\000\000\000\000\000\u0091\ud9f8\udcbb\udad4\udff1",
        10, -1000, 0, -235841280L, -55837L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fed9aaf66868170L), Double.longBitsToDouble(0x3feafae7e830754cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 10, 5, 12, "\udb03\udfb1\ud9bd\uddf2\udb7c\ude44\ud973\ude13\udb74\ude95\ud8f8\udcc7\udb12\udd68\ud950\udc29\udad5\udc12\uda80\udde6\ud924\udf74\udadb\udf88\ud8de\udc7f\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud9c9\udca2\udacd\uddfb\udb64\udd93\udaa4\udeea\udbc3\udc51", "\u7841\ua0ed", "\udbdd\udcaf\udb2f\udeb6\udb8d\udd11\udbae\udcc4\udbe6\ude65\udb83\udf54",
        28, 31248, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 31797, (char) 54705,
        Double.longBitsToDouble(0x3fe406eef91af3c9L), Double.longBitsToDouble(0x3fe760808f42dbf6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 9, 5, 13, "\ud8dd\ude4b\ud999\udfc6\udb78\udd5c\ud973\udea4\ud801\ude4c\udb51\udc6d\udb12\udd68\ud94b\udc98\udb3c\udd08\uda80\udda9\ud924\udf74\ud861\uddec\ud818\udf02", "\ub773\u3ac4\uceb9\u1a47\u4c40\u3756\u55ee\u0b43", "\uda0e\udeed\ud8fe\udfa6\ud91d\udebd\uda56\udc68\ud9f1\udf68\ud93d\ude27\udb55\ude93\uda2c\udd6a\udb83\udfb9\uda22\uddf5\ud83f\udd1f\ud998\udd93\uda5b\ude0b\udb81\udc00\ud9fd\udfa2\udb8e\udf67\u2bd3\ud824\udc25\ud848\ude10\ud9ce\udec9\ud9a0\ude0c\uda35\udff0\ud88a\ude30\udbc6\udf4c\ud8c3\uddf6",
        2, 31544, 2059973293, 3762560307728611541L, -14800L, true, false, (char) 2283, (char) 17117,
        Double.longBitsToDouble(0x3fca27a03fac1bdcL), Double.longBitsToDouble(0x3fd942c4d79c2482L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 0, 0, "\udb03\udfb1", "\ub034\uc40f\u2c30\u6fb2\ub36a", "\ud924\udf74\ud861\uddec\u956a\uda71\udc58\ud85e\udd80\uec03\ud8d3\ude67\uf71d\ud984\udf01\udb64\udd93\udaa4\udeea\udbc3\udc51\uda33\ude7c\uda39\udc4d\u0091\000\udb33\udc00",
        45, 61087, -1254556078, -4523636281402369639L, -55837L, false, false, (char) 46272, (char) 50212,
        Double.longBitsToDouble(0x3e4a1a0400000000L), Double.longBitsToDouble(0x3feafae7ef30754cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 13, 5, 12, "\udb03\udfb1\udb6c\udfa9\ud8bc\uded6\ud973\udea4\udb74\ude95\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51", "\u7841\ua0ed", "\udbdd\udcaf\udb6e\udde9\udb8d\udd11\udac7\udff1\udbe6\udd90\udb83\udf54",
        25, 39984, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 31759, (char) 54705,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fe760808cece5f6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 12, 5, 12, "\udbf9\ude05\uda93\udfc2\ud8bc\ude59\ud973\udea4\udb84\uddbe\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud961\udfaf\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51", "\u7841\ua0ed", "\ud84b\udcc7\ud9b8\udc25\udb8d\udd25\udbae\udcc4\udbe6\ude65\udb83\udf54",
        25, 8767, 1441577152, -9119745594112530810L, -12617L, false, false, (char) 31759, (char) 54705,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fe760808f42dbf6L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 9, 5, 12, "\uda38\udcab\ud9bd\uddf2\ud8bc\udf05\ud973\udea4\udb74\ude95\udb51\udc03\udb12\udd68\ud94f\udfbb\ud9c7\udde0\uda80\udde7\ud8ee\udd98\ud865\udfec\ud818\udf02\udb56\udcce\ud85e\udd80\udbda\udff3\uda91\udd68\ud9cc\udf8b\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51", "\u7841\ua0f3", "\udbdd\udcaf\udb6e\udde9\udb8d\udd11\udbae\udcc4\udbe6\ude65\udb83\udf54",
        -1, 84141, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 31800, (char) 55490,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fe760808f42dbf6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 8, 9, 12, "\udb03\udfb1\ud9bd\uddf2\ud8f5\udfee\ud973\udea4\udb74\ude95\uda4f\uddd2\ud80f\udf51\udb84\udcda\udad5\udcfd\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\ud9c7\udd27\ud85e\uddea\ud807\udf02\ud8d3\ude67\ud94a\ude83\ud887\udc38\udbbe\uddd2\udaa4\udeea\udbc3\udc51", "\u112e\uc182\u7dd6\ua37a\u6544", "\udbae\udcc4\udbe6\ude65\udb83\udf54\udadc\udf38\ud950\udc67\ud911\uddd0\uda5e\udc3d\ud907\udf72\uda61\ude48\ud8cb\ude05\udb50\udea0\ud824\udc25",
        19, 38760, 17951002, -6311623605485177260L, 26049L, false, false, (char) 32387, (char) 55041,
        Double.longBitsToDouble(0x3fe9e7dca53edd7eL), Double.longBitsToDouble(0x3fdb26bfd2cc10c4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 10, 7, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ua20d\udb74\ude95\udb51\udc03\udb12\udd68\ud94f\udfbb\udb53\udc1e\ud948\uded5\ud924\udf74\ud9dc\ude7d\ud98a\uddd3\udb56\udcce\udbc0\udc12\uebd4\ud8d3\ude67\ud9c9\udca2\ud88c\udcdb\uda58\udc2b\udaa1\udc52\udab8\udf8f", "\u7841", "\udb0c\udf48\udbdd\udcaf\udb89\udec1\udb76\udda6\udb39\udc6d",
        -5, 53821, -591688106, 4245092103618738061L, 53556L, true, false, (char) 60540, (char) 6886,
        Double.longBitsToDouble(0x3fdbce470827433cL), Double.longBitsToDouble(0x3fec06eefea92be6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 11, 12, 12, "\udb71\udfa8\ud9bd\uddf2\ud8bc\udf05\ud973\udea4\ud9a6\udd66\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\ud912\udc4f\udaee\udfbd\ud9f6\udc0f\ud85d\udf8a\udb6f\uddcf\ud85e\udd80\uec03\ud8d3\ude67\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51", "\u2113\ua0ed", "\udbdd\udcaf\udb6e\udde9\udb8d\udd11\udbae\udcc4\udbe6\ude65\udb83\udf54",
        25, 39984, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 13810, (char) 15097,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fec859cf742dbf6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 12, 2, "\udb03\udfb1\ud935\udd2e\ud8bc\udf05\ud973\udea4\udb74\ude95\udb51\udc03\udb0b\udc8e\ud94f\udfbb\udad5\udc12\uda9e\udde0\ud924\udf74\ud861\uddec\ud818\udf02\ud81c\udd2b\udad6\uddee\udbe9\udd4b\ud8d3\ude67\ud9c9\udca2\uda1e\ude96\udb4a\udd94\udaa4\udeea\udbc3\udc51", "\u281f\ua0ed", "\uda59\udcad\udb6e\udde9\udb8d\udd11\uda9e\udfdd\udbe6\udda6\udb83\udf54",
        -4, 3056, 1441577152, -9119745594112530810L, -3952L, true, true, (char) 31714, (char) 54705,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fe767f88f42dbf6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 4, 6, "\udb03\udfb1\ud9bd\uddf2\udad9\udf33\udb59\udd7c\udb74\udef7\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\uda28\udf2b\ue711\ud85e\udd80\uec03\ud8d3\ude67\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51", "\u7841\ua0ed\ud5da\ua37a\u50d4\u7db1\u465d\ub8ef\ud323\u9ce4\u4650", "\udb4c\udcad\udba1\udc30\uda61\ude48\ud8cb\ude05\udb50\udea0\ud824\udc25\ud848\ude10\ud9ce\udec9\ud948\ude81\ud926\udc33\u993e\udba6\udc01\uda34\udc32\ud869\udc78\ud870\uddb0\ud899\uddb8\udb18\udf7e\ud8a0\udfe8",
        32, 30061, -601665054, 944296040614615672L, 20794L, true, true, (char) 14197, (char) 2572,
        Double.longBitsToDouble(0x3feadf1a4c671d0cL), Double.longBitsToDouble(0x3fd711d9bfd5f6a0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 5, 5, 12, "\udad6\ude2a", "\ub509\ucc08", "\ud94f\udfbb\udad5\udc12\udba5\uded9\ud924\udf74\u29c2\ud809\udcd9\uda71\udc58\ud85e\udd80\uec03\ud9c9\ude62\ud9c9\udca2\ud878\udf91",
        27, -1000, 0, 1729382255227253303L, 54162L, false, true, (char) 50303, (char) 45692,
        Double.longBitsToDouble(0x3fe290c7e0000038L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:\udad4\ude85\ud994\ude04\012",
        Z.run(T, 2, 5, 3, 12, "\udad4\ude85\ud994\ude04", "\ud2c3\u2c42\u6fb2\ub36a\u22a7\u76db\u38a1\u3702\u9de3\u1263\u3c0a\ub773\u8e4c\u5401\ub88f\ub9ee\u50dd\u0e84\ucfd2\ua114\u77ce\ua0ed\u2c13\ua329\u50d4\u3981\u8e7e", "\u352a\udb21\uded7\ud909\udc75\uda49\uddb6\ud8cb\uddf1\ud9ff\udd26\uda9f\udd7e",
        52, 81965, 567814404, -4852164124741158501L, 87530L, true, false, (char) 52339, (char) 50362,
        Double.longBitsToDouble(0x3fed092f55368158L), Double.longBitsToDouble(0x3fc4cd42db71b360L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 4, 5, 15, "\udb03\udf90", "\ub034\ucc08\u2c42\u6fb2\ub36a", "\ud924\udf74\u29c2\ud809\udcd9\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\udb85\udea1\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51\uda33\ude7c\uda39\udc4d\ud8b8\ude79\uda0e\udeed\udb4a\udd59",
        45, 7383, 1927166164, -1744831225147244303L, 43863L, true, true, (char) 37313, (char) 24092,
        Double.longBitsToDouble(0x3fe6c4f943aa94e7L), Double.longBitsToDouble(0x3fc0d234d669b53cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 5, 5, 7, "\uda05\udc0e\udb98\udfb1\ud880\udc26\ud973\udea4\ud970\udcfe\udb51\udc15\udb12\udcb3\ud94f\udfbb\udb40\udecd\uda80\udde6\ud8ef\udc77\ud867\udd96\ud8e3\udd56\udaca\udd5a\uda9c\udcb5\udad4\udccf\ud8d3\ude67", "\uad5f\u6928\uce34\ub6c0\u6339\u2406\u616d\u1f16\u1407\u6741\u886c\u6380\u8a0a\uc08e\u9ec7\u3eb9\u32b9\uc1d9\u6d36\u6c05\u154b\u2ce9\u4654\u185a\u0fcf", "\udafb\udfc6\uda37\udc56\uda4f\udeaf\ud8e7\udc63\ud849\udd58\ud96d\udd92\ud9b4\udc22\udbf8\udf20\udb10\udfb8\udba9\udef0\ud94d\uddee\ud941\udc3e\udacb\ude3e\udabf\udfbe\ud9b4\udda0\udbe0\udd32\u8103\ud8f8\udf49\ud9c1\udd03\ud969\udd8e\udbad\ude1e\ud8a9\udc8f\udae9\udc5a\udb6e\udc6c\uda88\udc72\udbf6\ude49\ud955\udcdb\ud892\uddf0\uda3a\udec3\udb8a\ude25\ud88b\udf5d\udb7e\udfbb",
        31, 25036, 880801151, -4146061632416561604L, 57841L, true, true, (char) 6596, (char) 36274,
        Double.longBitsToDouble(0x3fd084d74ecdfa6aL), Double.longBitsToDouble(0x3fea70b4bcd20efcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\uda72\udca8\ud8c2\udfb5\ud82f\udc12\ud8e2\udf4a\ud98a\udff0\uda6d\udde4\ud920\udeca~\u9a26\012",
        Z.run(T, 1, 1, 13, 0, "\uda72\udca8\ud8c2\udfb5\ud82f\udc12\ud8e2\udf4a\ud98a\udff0\uda6d\udde4\ud920\udeca", "\ub00c\u415c\u5678\uc7c1\ud337\u408f\uaae6\u8c29", "\udb18\ude45\uda7b\udc5a\udbc3\udc51\uda33\ude7c\uda39\udc4d\uda72\ude76",
        27, 17656, -280575269, 1800502202498350674L, 73671L, true, false, (char) 39462, (char) 1768,
        Double.longBitsToDouble(0x3fd0c719b783472cL), Double.longBitsToDouble(0x3fa3340379eb0c60L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 5, 5, 12, "\udb03\udfb1\ud9bd\uddf2", "\u12a6\u2c42\u6fb2\ub36a\u22a7\u76db\u38a1\u5671\uc7c1\ud337\u3c0a\ub773", "\uda3b\ude92",
        18, 38831, -685501677, -751792387811988019L, 7969L, false, true, (char) 50303, (char) 45692,
        Double.longBitsToDouble(0x3fe290c7e0c5b538L), Double.longBitsToDouble(0x3fd99c1389bfe3e2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 12, "\udb03\udf32\ud9bd\uddf2\ud8bc\udf05\000\ue57b\u3d43\udb12\udc8f\ud835\udf8e\ud9be\ude04\000\ud90c\udc45\ud861\uddec\ud818\udf02\ud8a7\udc76\ud822\udf10\uec03\uf4bc\ufc00\ud8fc\ude3d\udb64\udd93\udaa4\udeea\u531b", "\u3d51", "\udb0c\udf48\udbdd\udcaf",
        12, 52445, 2137178368, 0L, -100000L, false, false, (char) 9984, (char) 42998,
        Double.longBitsToDouble(0x3feafae7ef30754cL), Double.longBitsToDouble(0x3fa039f95b56e5a0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 0, 0, "", "\u1d85", "\udb51\udc03\udae6\udc68\ud94f\udfbb\udad5\udc12",
        37, 31727, -777168729, 6840006215531396211L, -77134L, false, false, (char) 2926, (char) 2363,
        Double.longBitsToDouble(0x3fd6133682ee06bcL), Double.longBitsToDouble(0x3fe898c510001524L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\udaa6\udff9\uda15\udf41\udb60\udcc5\udb74\udf42\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud90a\udcc0\ud818\udf87\udb56\udcce\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\udaa6\udff9\uda15\udf41\udb60\udcc5\udb74\udf42\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud90a\udcc0\ud818\udf87\udb56\udcce", "\u731f\u946b\u1879\u77e3\u9211\u5cc9\u0a4d\ucb51\u7841\ua0ed\ud5da\ua37a\u50d4\u5beb\u0509\ub85f\uce6d\u3c60\u8e89\u5d42\u8e96\u69b2\u04bc\u8264\ub89b\u46ea\u15d8\uc8a8\u841e\u6bd1\u03bb\ub0fa\u61f7\u2e13\u2d74\u5ae8\u6b14\u7e0c\u2618\u8fa9\u5404\u8c15\u2223\u5a0f\u456e\uc27d\u3fd9\u70fd\u1118", "\udb86\ude5b\uda92\udca2\ud807\udc8e\ufa8d\ud92f\udd83\ud8fa\udc79\ud898\ude6c\udab1\udda5\ud86f\udf3b\ud9d3\udf8f\udb5e\udd2d\ud806\udf4b",
        -3, 1879, -1300541404, -750097822693996639L, -39812L, false, true, (char) 6318, (char) 35314,
        Double.longBitsToDouble(0x3f9c56e06ad91160L), Double.longBitsToDouble(0x3fe1318e312b4cfcL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\ud8bd\udfdb\ud9bd\ude22\ud8bc\udf05\ud973\udea4\012",
        Z.run(T, 1, 3, 3, 8, "\ud8bd\udfdb\ud9bd\ude22\ud8bc\udf05\ud973\udea4", "\u8bfd\u0ffd\u22a7\u1f9a\u77d5\u3503", "\ud8ac\udce5",
        48, 25929, 1571853665, 3704399308352531553L, -11374L, false, true, (char) 50558, (char) 27768,
        Double.longBitsToDouble(0x3faf3565638b5380L), Double.longBitsToDouble(0x3fe849a80485dfd3L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddf2\ud965\udeea\ud9ac\udc14\udb74\udf47\udb51\udc03\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud965\udeea\ud9ac\udc14\udb74\udf47\udb51\udc03", "\u22a7\u76db\u38a1\u09c0\u2deb\u1597", "\ud97c\udc88\ud940\udc6f\uda3b\ude85\ud902\udc20\uda6e\ude26\udb4a\ude54\uda33\ude7c\uda39\udc4d\ud8b8\ude79\uda0e\udeed\udbfc\udce4\udb0c\udf48\uda68\udfa2\udb6e\udde9\ud9f9\ude47\uda28\udf9b\udb29\udf77\udac8\udd01\uda34\ude2e\udbce\udd6b\ud911\udde1\uda5e\udc3d\udb81\udc00\udb6e\udd51\ud8c5\udea0\udb50\udea0\ud824\udc25\udaf9\ude23\ud95c\uded8\udbd1\udf92\udabd\udd6d\udbb2\udc77\ud8bf\udc26\udb6a\ude8c",
        24, 53240, -1798805189, 7347008755822677936L, -45897L, false, false, (char) 26921, (char) 3214,
        Double.longBitsToDouble(0x3fbad37e029a9890L), Double.longBitsToDouble(0x3fec890a56abf61fL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\012",
        Z.run(T, 1, 3, 5, 0, "\udb03\udfb1", "\ub034\uc40f\u2c30\u6fb2\ub36a", "\ud924\udf74",
        -4, 95050, -1036616589, 3745286729939026002L, -61759L, true, true, (char) 24521, (char) 26945,
        Double.longBitsToDouble(0x3fe898c515081524L), Double.longBitsToDouble(0x3fe1b8c595919bafL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 9, 10, 12, "\udb03\udfb1\ud9c6\udcf2\ud8bc\udf05\ud870\udde2\udb71\udc85\udb51\udc03\udb12\udd68\ud86e\udf6b\udad4\udf0d\ud8d2\ude0f\ud82e\udd14\uda05\udfbd\ud83d\udcf6\ud895\udeed\uda4e\uddef\ud9a4\uddc3\ud977\uded6\u3d08\udb6f\uddcf\udb64\udd93\uda19\udfe4\udbd2\udc89", "\u437a\u2d5f", "\udbdd\udcaf\udb6e\udde9\udb8d\udd11\udbae\udcc4\udbe4\udd65\ud96a\udc86\ud867\ude62\uda66\udc72\ud911\uddd0\udaa4\udeab\ud9ae\udcd4\uda73\ude7f\ud8cb\ude05\udb50\udea0\ud9f7\udeae\ud864\udc0e\ud9ce\udec9\ud8fc\udf5a\ud8be\uddee\uda08\ude52\ud938\uddcf\ud98a\udf88",
        9, 36159, -1427023773, -1451602479688305220L, -30613L, true, true, (char) 40490, (char) 54239,
        Double.longBitsToDouble(0x3fc1cf334c5750acL), Double.longBitsToDouble(0x3f999d9c93016200L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 9, 9, 12, "\udb03\udfb1\ud9c6\udcf2\ud8bc\udf05\ud870\udde2\ud933\udc86\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\ud82c\udd50\ud924\udf74\ud828\udf30\ud83d\udcde\ud895\udeed\uda4e\uddef\udb1e\uddc0\ud977\uded6\u3d08\udb6f\uddcf\ud881\udc41\ud9d9\udeed\ud9fd\udf34", "\u437a\ua0ed", "\udbdd\udcaf\udb6e\udde9\udb8d\udd11\udbae\udcc4\udbe6\ude65\udb83\udf54",
        42, 77780, 1441577152, -7397777347749726172L, 61584L, false, false, (char) 31759, (char) 45722,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fed693196829e82L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 10, 10, 12, "\udb03\udfb1", "\u22cc\000\000\uc8c5\000", "\ud924\udf74\ud8ac\udcb1\ud818\ude98\udb56\udcce\ud85e\udd80\uec52\000\000\000\000\ud96a\udf0e\000\ud828\ude67\000\u0091\ud9f8\udcbb\udad4\udff1",
        10, -1000, 0, -235841280L, -55837L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fed9aaf66868170L), Double.longBitsToDouble(0x3feafae7e830754cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 13, "\ud8dd\ude4b\ud999\udfc6\udb78\udd5c\ud973\udea4\ud801\ude4c\udb51\udc6d\udb12\udd68\ud94b\udc98\udb3c\udd08\uda80\udda9\ud924\udf74\ud861\uddec\ud818\udf02", "\ub773\u3ac4\uceb9\u1a47\ucb5b\uc1ab\ua6fd\u4c35", "\uda0e\udeed\ud8fe\udfa6\ud91d\udebd\uda56\udc68\ud9f1\udf68\ud93d\ude27\udb55\ude93\uda2c\udd6a\udb83\udfb9\uda22\uddf5\ud83f\udd1f\ud998\udd93\uda5b\ude0b\udb81\udc00\ud9fd\udfa2\udb8e\udf67\u2bd3\ud824\udc25\ud848\ude10\ud9ce\udec9\ud9a0\ude0c\uda35\udff0\ud88a\ude30\udbc6\udf4c\udaec\udfee",
        2, 31544, 2059973293, 3762560307728611541L, 469L, true, false, (char) 2283, (char) 17117,
        Double.longBitsToDouble(0x3fca27a03fac1bdcL), Double.longBitsToDouble(0x3fdf32c4d79c832cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 0, 0, "\000", "", "\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12",
        37, 31727, -788529152, 164281458884608L, -77134L, false, false, (char) 2926, (char) 0,
        Double.longBitsToDouble(0x3fd6133002ee06bcL), Double.longBitsToDouble(0x3fe898c515081524L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 0, "\udb03\udfb1", "\ub034\uc40f\u2c30\u6fb2\ub36a", "\ud924\udf74\ud861\uddec\u956a\uda71\udc58\ud85e\udd80\uec03\ud8d3\ude67\uf71d\ud984\udf01\udb64\udd93\udaa4\udeea\udbc3\udc51\uda33\ude7c\uda39\udc4d\u0091\uda12\udc08\udb33\udc00",
        45, 61087, -1254556078, -4523636281402369639L, -55837L, false, false, (char) 46272, (char) 50212,
        Double.longBitsToDouble(0x3e4a19cc80000000L), Double.longBitsToDouble(0x3feafae7ef30754cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 5, 12, "\000\uda93\udfc1", "\ud247\u2c30\u6fb2\ub36a\u22a7\u76db\u3872\u6174\u2deb\ud2c4\u3b9a\ub773", "\uda3b\ude92\ud91a\udd8e\udaa4\udeea\023\uda33\ude74\uda39\udc4d\u9591\ud9f8\udcbb\udb33\udc00",
        45, 3663, 178444165, -4523636195503023719L, -100000L, false, false, (char) 46523, (char) 0,
        Double.longBitsToDouble(0x3e10c00000000000L), Double.longBitsToDouble(0x3feafae002a9cf4cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 4, 12, 2, "", "\u1d85\ub034\uc40f", "\ud94f\udfbb\udad5\udc12\uda9e\udde0\ud924\udf74\ud861\uddec\ud818\udf02\ud81c\udd2b\udad6\uddee\udbe9\udd4b\ud8d3\ude67\035\uda1e\ude0b",
        45, 38831, 354685715, 1779525517360234551L, 54162L, false, true, (char) 49828, (char) 45692,
        Double.longBitsToDouble(0x3fe290c6a0c5b538L), Double.longBitsToDouble(0x3fd99c1388413d7aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 13, 13, 0, "\uda72\udca8\ud8c2\udf46\ud82f\udc12\ud8e2\udf4a\ud98a\udff0\uda6d\udde4\ud920\udeca", "\u980d\ub898\u5678\uc7c1\ud337\u408f\u6fcc\u8c29", "\udb18\ude45\uda7b\udc5a\udbc3\udc51\uda33\ude7c\uda39\udc4d\uda72\ude76",
        27, 17656, -280575269, 1800502202498350674L, 73671L, true, false, (char) 39462, (char) 1768,
        Double.longBitsToDouble(0x3fd0c719b783472cL), Double.longBitsToDouble(0x3fb55a01bcf58630L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 0, "", "\u1d85", "\udb51\udc03\udae6\udc68\ud94f\udfbb\udad5\udc12",
        37, 31727, -777168729, 6840006215531396211L, -77134L, false, false, (char) 2926, (char) 2363,
        Double.longBitsToDouble(0x3fd6133682ee06bcL), Double.longBitsToDouble(0x3fe898c510001524L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddf2\ud965\udeea\ud9ac\udc14\udb74\udf47\udb51\udc03\udb12\udd68\ud84c\udef9\udac4\ude45\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udab1\udc1b\udb08\udc4c\ud9f9\ude41\ub6a9\ue9d5\uda3b\ude85\ud902\udc20\uda6e\ude26\udb4a\ude54\uda33\ude7c\ud8b5\udfa6\ud8b8\uded8\uda0e\udeed\ue5d4\udb0c\udf48\uda68\udfa2\udb6e\udde9\ud9f9\ude47\uda28\udf9b\udaec\udd78\udac8\udcd4\ud8a6\ude27\udbce\udd6b\ud911\udde1\udbb3\udc03\udb80\udfab\ud850\ude03\ud997\udf4a\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud965\udeea\ud9ac\udc14\udb74\udf47\udb51\udc03\udb12\udd68\ud84c\udef9\udac4\ude45\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udab1\udc1b\udb08\udc4c\ud9f9\ude41\ub6a9\ue9d5\uda3b\ude85\ud902\udc20\uda6e\ude26\udb4a\ude54\uda33\ude7c\ud8b5\udfa6\ud8b8\uded8\uda0e\udeed\ue5d4\udb0c\udf48\uda68\udfa2\udb6e\udde9\ud9f9\ude47\uda28\udf9b\udaec\udd78\udac8\udcd4\ud8a6\ude27\udbce\udd6b\ud911\udde1\udbb3\udc03\udb80\udfab\ud850\ude03\ud997\udf4a", "\uc8a8\u36d8\u0b86\u5ddc\u4732\u8ed4\u283f\u12b4\u369b\u056d\u0a62\u56ca", "\udbc9\udd95\udb17\udd27\ud8fa\udc02\ud8ee\udd50\ud8c4\ude49\udbdc\udefb\ud80c\udf05\udbcf\udd92\ud83a\ude00\ud92a\udc36\ud840\udc2d\ud915\udf98\udb1a\udefb",
        56, 80254, 694676265, 8449810490425293495L, -1560L, true, true, (char) 49019, (char) 9753,
        Double.longBitsToDouble(0x3fe8fc432a7a1210L), Double.longBitsToDouble(0x3feeb1fefab0f722L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 0, "\000", "", "\udb71\udfc0\udadf\udf63\ud94f\udfbb\udad5\udc12",
        15, 99262, -788529086, 164281458884608L, -77134L, false, false, (char) 26410, (char) 0,
        Double.longBitsToDouble(0x3fe3099801eedbf9L), Double.longBitsToDouble(0x3fe89dc511fc26caL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 0, "\000\ud9bd\udd6d\ud8bc\udf05", "\u82ad\ub0f8\ub3b1\u22a7", "\ud861\uddec\udb7a\udcfd",
        45, 83615, 766269778, 2040672399945428765L, 94913L, true, true, (char) 33146, (char) 5481,
        Double.longBitsToDouble(0x3feafd87cb116589L), Double.longBitsToDouble(0x3fce4d3fcc346464L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 9, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud973\udea4\udb74\ude95\udb51\udc03\udb12\udd68\ud94f\udfbb\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud9c9\ude63\udb76\udf1b\udb64\udd93\udaa4\udeea\udbc3\udc51", "\u7841\ua0ed", "\ud80f\udf57\ud96d\ude5a\udb7c\uddc5\udbae\udcc4\udbe6\ude65\udb83\udf54",
        25, 39984, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 31759, (char) 54705,
        Double.longBitsToDouble(0x3fec06eef91af3e6L), Double.longBitsToDouble(0x3fe760808f42dbf6L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\uda6a\udfd4\ua511\000\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda80\udd1e/\ud84b\udd45\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud9b2\udee6\uda3b\ude92\ud90c\udd20\uda6e\ude26\udbc3\udc51\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\uda6a\udfd4\ua511\000\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda80\udd1e/\ud84b\udd45\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud9b2\udee6\uda3b\ude92\ud90c\udd20\uda6e\ude26\udbc3\udc51", "\u7841\ua0ed", "\udbdd\udcaf\udb6e\udde9\uda48\udd57\udbae\udc34\udb40\udee2\udac8\udc5e",
        54, 39984, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 31759, (char) 30624,
        Double.longBitsToDouble(0x3fd8b023cdc64e98L), Double.longBitsToDouble(0x3fdc083e9c0c7cd6L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 11, 11, 12, "\udb03\udfb1\ud9c6\udcf2\ud8bc\udf05\ud870\udde2\ud933\udc86\udb51\udc03\uda31\udd62\ud94f\udfbb\udad5\udc12\ud82c\udd50\ud924\udf74\ud828\udf30\ud83d\udcde\ud895\udeed\uda4e\uddef\udb1e\uddc0\ud977\uded6\u3d08\udb6f\uddcf\udb64\udd93\uda19\udfe4\ud84b\udda5", "\u437a\ua0ed", "\udad2\udf0a\uda0d\udd18\ud842\ude57\ud9fb\udfc3\udbe6\ude65\udb83\udf54",
        25, 39984, 1441577152, -7371318699938924508L, 61584L, false, false, (char) 31759, (char) 45722,
        Double.longBitsToDouble(0x3fef3eeef91af3e6L), Double.longBitsToDouble(0x3fddf993247cc9e0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 4, 4, 6, "\udb03\udfb1\ud9bd\uddf2\udad9\udf33\udb59\udd7c", "\u6fb2\u8933\u22e3\u76db\u38a1\u09c0", "\ud979\udced\ufa9c\ud8d3\ude67\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea",
        15, 6512, -1683017077, 3340145299794319922L, 80955L, true, true, (char) 5966, (char) 27546,
        Double.longBitsToDouble(0x3feea66db7b1f1e8L), Double.longBitsToDouble(0x3fbc3582b2f1b2c0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:5\012",
        Z.run(T, 1, 0, 0, 10, "5", "\u0211\uc40f\u1186\u82ab\ub377", "\ud94b\udcde\ud93a\ude27\ud887\ude3e\u082a\ud85e\udd34\uec03\ud8d3\ude67",
        45, 57675, 56555873, -6589908136273568703L, 96717L, true, false, (char) 16986, (char) 43977,
        Double.longBitsToDouble(0x3fe42f5a432a14c7L), Double.longBitsToDouble(0x3fe817d19a1cdc17L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 0, 0, 0, "0", "", "\udb4d\udec0\udadf\udf63\ud94f\udfbb\udad5\udc12",
        15, 99262, -788529086, 164281458884608L, -77134L, false, false, (char) 26410, (char) 0,
        Double.longBitsToDouble(0x3fe3099801eedbf9L), Double.longBitsToDouble(0x3fe89dc5116d26caL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=java.lang.Integer:5\012",
        Z.run(T, 2, 0, 0, 10, "5", "\u0211\uc40f\u1186\u82ab\ub377", "\ud94b\udcde\ud93a\ude27\ud81e\udc62\ud8ec\udfba\ud85e\udd34\uec03\ud8d3\ude67",
        45, 57675, 56555873, -1329703770305644605L, 96717L, true, false, (char) 472, (char) 43977,
        Double.longBitsToDouble(0x3fe42f5a432a14c7L), Double.longBitsToDouble(0x3fe817d19aebdc17L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 0, 10, "5\ud9bd\udd6d", "\uc40f\u1186\u82ab\ub377\u391e\u68d7\u0b2d\ucd22\ub0dc\ub82e\u3bbe\ub773", "\uda3b\ude92",
        18, 58447, 49617985, -7194657560710021229L, 80924L, true, false, (char) 48589, (char) 61424,
        Double.longBitsToDouble(0x3fe817d19a1cdc17L), Double.longBitsToDouble(0x3fe7129d03d2fa68L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 4, "5\ud9bd\udd6d\ud841\udf07", "\u1186\u82ab\ub377\u391e", "\ud93a\ude27\udbce\uddc9\ud836\udcf1\ud85c\udd1b\udb68\ude9b\udb43\udc26\ud81f\udcd2\uda3b\ude92\udb64\udd93\ud8f5\udc13\uda61\udc6d\uda96\udfc5\ud9ec\udfa8",
        49, 81196, -2099978142, -4535706105810239771L, -45244L, true, true, (char) 19193, (char) 7119,
        Double.longBitsToDouble(0x3fe18cdf0dc1d404L), Double.longBitsToDouble(0x3fda8932f40851d6L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 0, 11, 1, "0", "\uaf6f", "\udadf\udf63\ud94f\udfbb\udad5\udc12\udab3\udf52\udbca\udcfe\ud849\udd88\u956a\uda73\udf58\ud850\udd3a\uec03\ud9ce\uddc3",
        47, 66016, -604415391, -5142281819348397293L, -52935L, false, true, (char) 46170, (char) 37718,
        Double.longBitsToDouble(0x3fe4b33d134ebad7L), Double.longBitsToDouble(0x3fd5126459c84ecaL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.String: |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 15, 15, 0, "\177\000\000\ud973\uddd9\udacb\udfc1\ud9b4\udc1f", "\u4ba3\u148a\ud55b\u0d77\u16e0\u5684\u2599\ub773\u301a\u17e5\ud684\u58be\uc76c\ua38a\u593c\u9ed3", "\udb3f\udf21\ud8ea\udef9\uda0e\udd34\uda75\udcd3\ud846\ude3e\ud857\ude13\ud942\udf47\uda95\ude2f\ud90d\udd47\udb3a\udcef\ud82e\udf59\udae6\udd61\uda6c\udc43\ud92f\udd6c\ud930\uddd9",
        12, 56935, 1652830421, -4322066466310529462L, -86288L, false, false, (char) 12629, (char) 37252,
        Double.longBitsToDouble(0x3fcf43b05d160a78L), Double.longBitsToDouble(0x3fe541fd773b7ee6L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 0, 0, 10, "5\000", "\uc40f\u1186\u82ab\ub377\u391e\u68d7\u0b2d\ucd22\ub0dc\ub82e\u3bbe\ub773", "\uda3b\ude92",
        18, 58447, 49617985, -7194657560710021229L, -100000L, false, false, (char) 48517, (char) 61424,
        Double.longBitsToDouble(0x3fe817d19a1cdc17L), Double.longBitsToDouble(0x3fe7129d03d2fa68L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 10, "5\000", "\uc40f\u1186\u82ab\ub377\u391e\u68d7\u0b2d\u9bbb\u1b6b\u4de3\u3bbe\ub773", "\uda3b\ude92",
        18, 58447, 49617985, -7194657560710021229L, -100000L, false, false, (char) 48517, (char) 61424,
        Double.longBitsToDouble(0x3fe817d19b7041a9L), Double.longBitsToDouble(0x3fe7127ffbd2fa68L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 1, 9, 15, 12, "\udb03\udfb1\udbbe\udc73\udae2\ude24\ud973\ude1b\udb74\ude95\ud9e9\udfa6\ud82a\uddbc\ud94f\udfbb\udad5\udc12\ud9d8\udfbc\u2477\ud846\udefa\ud818\udf02\ud95e\udf01\udb4a\udf43\ud825\ude7e\ud8bb\udd67", "\uad5f\uaf17\u5c21\u0a4d", "\uda0e\udeed\udb33\udc00\udb0c\udf48\udb4f\udca8\udaa1\udef5\udb8d\udd11\udbae\udcc4\udbe6\ude65\udb83\udf54\uda6d\udcba\udac1\ude55\ud8f8\ude63\ud84c\ude9d\ud83e\ude47\ud97f\udd04\udaeb\udc02\udb50\udea0\udaac\udf09\udadb\ude3a\uda2e\ude83\udbc4\udfa4\ud893\ude97\ua98e\u8201\ud8bf\udfca",
        56, 17296, -1267858738, 7524027042917223319L, 9090L, true, false, (char) 14603, (char) 58080,
        Double.longBitsToDouble(0x3fdf7248c870b380L), Double.longBitsToDouble(0x3fa1ff4b24ce36d0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 12, 12, 13, "\ud8dd\ude09\ud999\udfc6\udb78\udd5c\ud973\udea4\ud801\ude4c\udb51\udc6d\udb12\udd68\ud981\udc93\udb3c\udd08\uda80\udda9\ud9ca\udcb1\ud861\ude0e\ud818\udf02", "\ub773", "\udb15\udd2f\u0e53\uda7a\udf97\ud9af\ude65\ud8c2\udeb2\uda39\udc4d\ud8b8\ude79\uda0e\udeed\ud8fe\udfa6\ud91d\udebd\uda1f\udf40\ud9cb\udcd4\ud916\udd6c\udad4\ude11\udb34\udd44\udb83\udf1a\uda22\uddf5\ud83f\udd1f\ud99c\udd93\uda5b\ude0b\udb81\udc00\ud9fd\udfa2\udb8e\udf67\ud9ee\udced\ud82c\udf11\ud848\ude10\ud9ce\udec9\ud9a0\ude0c\uda35\udff0\ud88a\ude30\udbc6\udf4c",
        35, 19897, 1991373856, 8847473596587003050L, -92515L, true, true, (char) 50304, (char) 19955,
        Double.longBitsToDouble(0x3fb24e6f99c4ad90L), Double.longBitsToDouble(0x3fc9b8421344f404L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.JsonPointer:\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 8, 8, 10, "\ud951\udee9\ue27b\udac8\ude4e\ud937\udc6f\udb71\udc74\udaba\udffe", "\u37d1\u76db\u38a1\u0188\u4551\u733d\u4734\u9e41\u3a4f\uafa2\u5c76", "\udbc3\udc51\udb54\udef0\udbc9\udd05\uda26\udf66\udb36\udf43\udbab\udfe3\udbb2\udd76\udb9c\udde7\uda4c\udce8\ud847\udf80\uda43\uddb3\ud84d\udc3b\udaf9\udeff\ud92e\udee6\udbb5\udfd1\ud9f4\ude95\udb47\udded\ub2da\uda57\udd8f",
        39, 99083, 1088511369, -2973718541436531095L, 1999L, true, true, (char) 50816, (char) 58434,
        Double.longBitsToDouble(0x3fe42f4f60bde1cbL), Double.longBitsToDouble(0x3fef2a44a66685b7L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\uda44\udda2\000\000\ud973\uddd9\ud97e\udc3a\udbc9\udfcf\uda18\udc2d\ud896\udfcb\ud94e\udd95\udaed\udfb3\uda5b\udeb0\udbc1\udd37\u956a\uda71\udc58\ud822\udf10\uec03\ud9ce\uddc3\uf7e4\ud984\udf01\uda5f\udee1~\u8db2\0121=void |a0=java.lang.StringBuilder:\uda44\udda2\000\000\ud973\uddd9\ud97e\udc3a\udbc9\udfcf\uda18\udc2d\ud896\udfcb\ud94e\udd95\udaed\udfb3\uda5b\udeb0\udbc1\udd37\u956a\uda71\udc58\ud822\udf10\uec03\ud9ce\uddc3\uf7e4\ud984\udf01\uda5f\udee1~\u8db2\012",
        Z.run(T, 2, 1, 1, 0, "\uda44\udda2\000\000\ud973\uddd9\ud97e\udc3a\udbc9\udfcf\uda18\udc2d\ud896\udfcb\ud94e\udd95\udaed\udfb3\uda5b\udeb0\udbc1\udd37\u956a\uda71\udc58\ud822\udf10\uec03\ud9ce\uddc3\uf7e4\ud984\udf01\uda5f\udee1", "\ubbd7\u46e9", "\udbe6\udeef\ud9bf\udc9c\ud8eb\ude77\ud91a\udd71\udabf\udf13\ud8e6\ude34\udb29\ude21\ud97c\udde0\ud946\udc8f\uda64\udffb\udacb\udc3c\udad4\udc0a\ud9a6\udeeb\ud8e8\ude23\ud9b2\udead",
        13, 26963, 1076926087, -416886697078018094L, 73581L, false, true, (char) 36274, (char) 61666,
        Double.longBitsToDouble(0x3fe34b5e5db4c7deL), Double.longBitsToDouble(0x3fc3b1e6a1bf3a58L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:0\0121=com.fasterxml.jackson.core.JsonPointer:0\012",
        Z.run(T, 2, 3, 3, 0, "0", "", "\udb4d\udec0\udadf\udf63\ud94f\udfbb\udad5\udc12",
        15, 99262, 201326658, 3153821591329850296L, -77134L, false, false, (char) 26410, (char) 0,
        Double.longBitsToDouble(0x3fe3099801eedbf9L), Double.longBitsToDouble(0x3fe89dc5116d26caL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\uda51\udd4a\uda86\udd7a\udac6\uddae\ud973\udea8\udb84\uddbe\udb51\udc03\uda2c\ude00\uda4b\udff3\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\u57dc\ud85e\udd80\ud9e8\ude78\ud961\udfaf\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51\uda33\ude7c\uda39\udc4d\ud8b8\ude79\uda0e\udeed\udb33\udc00\udb4e\udd31\udbe6\udd43\uda2b\uddbd\udb37\udd90\udbae\udcc4\ud923\udea1\udab2\udc43\ud98b\udee9\ud929\ude55\ud874\ude72\ud870\udcfc\udb81\udc00\ud8cf\udc80\ud8d8\udd7e\udb50\udea0\ud824\udc25\ud848\ude10\ud9ce\udec9\ud9a0\ude0c\ud92f\udccc\udb40\udd2b\uce5d\udbc8\udfd9\ud81b\uddd6\ud9d1\udfc8\uda43\udcf2\ud8a1\udd03\ud85f\udf4d\ud9bb\udd2d\uda9c\udc81\ud8f4\udf4f\udb2a\udd7d\uda14\ude40\uda9e\udcdc\udb8b\udd4c\udb2c\udc4b\udbd9\udec3\uda54\ude3a\ud93c\udd24\udad8\udc48\udbf5\udf69\udbb5\udd6e\ud9e7\ude20\ud9ae\udd97\udb76\udd61\uda7b\udf94\ud850\udf7f\ud935\udfed\udb59\udcd3\uda81\udf10\012",
        Z.run(T, 1, 3, 14, 4, "\uda51\udd4a\uda86\udd7a\udac6\uddae\ud973\udea8\udb84\uddbe\udb51\udc03\uda2c\ude00\uda4b\udff3\udad5\udc12\uda80\udde6\ud924\udf74\ud861\uddec\ud818\udf02\u57dc\ud85e\udd80\ud9e8\ude78\ud961\udfaf\ud9c9\udca2\uda3b\ude92\udb64\udd93\udaa4\udeea\udbc3\udc51\uda33\ude7c\uda39\udc4d\ud8b8\ude79\uda0e\udeed\udb33\udc00\udb4e\udd31\udbe6\udd43\uda2b\uddbd\udb37\udd90\udbae\udcc4\ud923\udea1\udab2\udc43\ud98b\udee9\ud929\ude55\ud874\ude72\ud870\udcfc\udb81\udc00\ud8cf\udc80\ud8d8\udd7e\udb50\udea0\ud824\udc25\ud848\ude10\ud9ce\udec9\ud9a0\ude0c\ud92f\udccc\udb40\udd2b\uce5d\udbc8\udfd9\ud81b\uddd6\ud9d1\udfc8\uda43\udcf2\ud8a1\udd03\ud85f\udf4d\ud9bb\udd2d\uda9c\udc81\ud8f4\udf4f\udb2a\udd7d\uda14\ude40\uda9e\udcdc\udb8b\udd4c\udb2c\udc4b\udbd9\udec3\uda54\ude3a\ud93c\udd24\udad8\udc48\udbf5\udf69\udbb5\udd6e\ud9e7\ude20\ud9ae\udd97\udb76\udd61\uda7b\udf94\ud850\udf7f\ud935\udfed\udb59\udcd3\uda81\udf10", "\u91ce", "\uda1c\udc24\ud97a\udfda",
        39, 77547, -176864139, -7580219399214266694L, 46973L, false, true, (char) 29037, (char) 25887,
        Double.longBitsToDouble(0x3fee82bfecd1d52eL), Double.longBitsToDouble(0x3f621495ee72d000L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Integer:55\012",
        Z.run(T, 1, 0, 0, 10, "55", "\u3c4c\u3e3f\u4c53\ub90b\u391e\u68d7\u0b2d\u06ca\ub0dc\ub82e\u3bbe\uca73\u8dfa\u80bb\u1879\u52b5\u313f\u47c2\u62ba\ua1b5\u037e\000\u471c\u1326\ud44a\u4473\u1539\u2441", "\ud8c9\udee0\ud94d\uded0\ud8eb\udf1d",
        22, 1153, 335504612, -6018477880579768653L, 99422L, false, false, (char) 40946, (char) 53033,
        Double.longBitsToDouble(0x3fd2b2b2658ce176L), Double.longBitsToDouble(0x3fe8a31695155feeL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Integer:55\0121=java.lang.Integer:55\012",
        Z.run(T, 2, 0, 0, 10, "55", "\u3c4c\u3e3f\u4c53\ub90b\u391e\u68d7\u0b2d\u443e\u345f\u1cd1\u3bbe\uca73\u8dfa\u80bb\u1879\u52b5\u313f\u47c2\u62ba\ua1b5\u037e\000\u471c\u1326\ud44a\u4473\u1539\u2441", "\ud8c9\udee0\ud94d\uded0\ud8eb\udf1d",
        22, 1153, 335504612, -6018477880579768653L, 99422L, false, false, (char) 40946, (char) 53033,
        Double.longBitsToDouble(0x3fd2b2b2658ce176L), Double.longBitsToDouble(0x3fe8a31695155feeL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 10, "55\udbc3\udd43\ud8fd\udedf\ud8d0\udd99", "\ub982\u391e\u68d7\u0b2d\u443e\u345f", "\uff03\ud8d3\ude15\ud81b\udf9d",
        -5, 95593, -1527456473, 213107621813580049L, 60971L, false, false, (char) 0, (char) 48517,
        Double.longBitsToDouble(0x3fe950a63f02fa33L), Double.longBitsToDouble(0x3fe0e6e0bae253a0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud8f2\uded9\ud98c\udd25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda5c\udf3e~\ud84b\udd45\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud94b\udc32\ud8a8\udcaf\ud90c\udd20\uda6e\ude26\udbc3\udc51\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud8f2\uded9\ud98c\udd25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda5c\udf3e~\ud84b\udd45\ud818\udf02\udb56\udcce\ud85e\udd80\uec03\ud8d3\ude67\ud94b\udc32\ud8a8\udcaf\ud90c\udd20\uda6e\ude26\udbc3\udc51", "\u7841\ua0ed", "\uda2b\udf84\uda27\udd6c\uda48\udd57\udb7f\udd8c\udb01\udec7\udae2\udca9",
        43, 61505, 1441577152, -9119745594112530810L, 61584L, false, false, (char) 29199, (char) 64748,
        Double.longBitsToDouble(0x3feb55748ee32709L), Double.longBitsToDouble(0x3fdc083e9c0c7cd6L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddf2\ud994\udfbb\ud8f2\udefb\ud98c\udd25\uda22\udce9\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda5c\udf3e~\ud84b\udd45\udb3a\udefa\uda77\udca9\ud85e\udd80\uec03\ud8d3\ude67\ud94b\udc32\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud994\udfbb\ud8f2\udefb\ud98c\udd25\uda22\udce9\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda5c\udf3e~\ud84b\udd45\udb3a\udefa\uda77\udca9\ud85e\udd80\uec03\ud8d3\ude67\ud94b\udc32", "\u5647\u5c21\u0a4d\ucb51\u7841\ua0ed\ud5da\ua37a\u4dc2\u118e\u0509\u1c82\u5f3d\u200d\u9e5e\u892b\u8e96\u69b2\u04bc\u8264\ub89b\ucd21\u837d\u76ca\u26e8\u62bf\u838b\u9cd8\u7626\ua598\ubca1\ubed1\u69e7\u64de\ud784\ua832\ud28c", "\ud8fb\ude51\udb30\udd51\udaa2\udf5e",
        31, 29983, 1291017246, -5200348762136384118L, 91010L, true, false, (char) 4370, (char) 61104,
        Double.longBitsToDouble(0x3fd302d104a75b8cL), Double.longBitsToDouble(0x3fe2ee41f7e32c21L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud959\ude04\ud8bc\udf05\ud8f2\uded9\ud98c\udd25\u18dc\udb8b\udd5e\ud980\udcf4\udad5\udc7c\uda5c\udf3e~\ud84b\udd45\ud818\udf02\udb6d\udcf9\ud85e\uddc8\uec03\ud8d3\ude67\ud94b\udc32\ud8a8\udcaf\ud90c\udd20\uda83\udc03\udb76\udc25\ud87a\udc7f\ud804\udff3\ud992\ude62\udba3\udf5b\udabd\udf19\udaf1\ude30\uda2b\udf84\uda27\udd6c\udae3\udf65\udb87\udc0d\udb01\udec7\udae2\udca9\ud9e1\udd33\ud856\udc7e\ud911\uddd0\uda39\udcc9\ud947\udf7f\ud87f\udda7\ub58e\ud861\udd98\ud902\ude35\ud9ac\udd8e\udbc4\uddb6\udbd1\udf92\udabd\udd6d\ud9ef\udf16\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\ud959\ude04\ud8bc\udf05\ud8f2\uded9\ud98c\udd25\u18dc\udb8b\udd5e\ud980\udcf4\udad5\udc7c\uda5c\udf3e~\ud84b\udd45\ud818\udf02\udb6d\udcf9\ud85e\uddc8\uec03\ud8d3\ude67\ud94b\udc32\ud8a8\udcaf\ud90c\udd20\uda83\udc03\udb76\udc25\ud87a\udc7f\ud804\udff3\ud992\ude62\udba3\udf5b\udabd\udf19\udaf1\ude30\uda2b\udf84\uda27\udd6c\udae3\udf65\udb87\udc0d\udb01\udec7\udae2\udca9\ud9e1\udd33\ud856\udc7e\ud911\uddd0\uda39\udcc9\ud947\udf7f\ud87f\udda7\ub58e\ud861\udd98\ud902\ude35\ud9ac\udd8e\udbc4\uddb6\udbd1\udf92\udabd\udd6d\ud9ef\udf16", "\u9468\ub6e8\u7dca\u5a78\u2d75\uab6c\u9d0d\u77a4\u1fe1\ua745\uce9c\u87a7\u541d\u573c\ub0e4\u34f9\uacf6\u5a48\ub0ae\u1b9e\ube87\uc366\u321f\u03ec", "\uda2e\udc4e\ud88a\udd2c\ud929\ude3e\ud9d7\udc4b\ud946\uddfd\ud826\udf54\uaf23\udb2c\udf29\ud8fd\udc0f\uda90\udea9\ud817\udfcc\udb40\udec1\ud91b\ude24\ud921\udeff\ud8ab\ude67\u5a2b",
        55, 53613, 942286435, 1628024472135666608L, 49350L, true, false, (char) 59560, (char) 58278,
        Double.longBitsToDouble(0x3fee2500b09b8f74L), Double.longBitsToDouble(0x3fc32736c0f2df54L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud8f2\uded9\ud98c\udd25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda5c\udf3e~\ud84b\udd45\ud818\udf02\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud8f2\uded9\ud98c\udd25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda5c\udf3e~\ud84b\udd45\ud818\udf02", "\ub773\u8e4c\ua67e\u7327\u73da\u05e5\u5c21\u0a4d", "\uda0e\udeed\uec04\udb0c\udf48\uda2b\udf84\uda27\udd6c\uda48\udd57\udb7f\udd8c\udb01\udec7\udae2\udca9\ud9e1\udd33\u565f\udb25\udfda\uda5e\udc3d\udb81\udc00\uda61\ude48\ud8cb\ude05\udb50\udea0\ud902\ude35\ud9ac\udd8e\udbc4\uddb6\udbd1\udf92\udabd\udd6d\uda8e\udc86\ud923\udcf7\udaf9\udfb3",
        58, 39701, -107064217, 7496035054551120748L, -38837L, false, true, (char) 62464, (char) 52076,
        Double.longBitsToDouble(0x3fdca11faf741e00L), Double.longBitsToDouble(0x3fe08e87b04d143eL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud8f2\uded9\ud983\ude25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\ud949\udf54~\012",
        Z.run(T, 1, 3, 11, 0, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud8f2\uded9\ud983\ude25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\ud949\udf54~", "\u4f95\u3c0a\u4bb7\u6393\ua6e6\u7327\u73da", "\uda33\ude7c\uda39\udc4d",
        0, 93642, 27591656, 524170909262083246L, 86746L, true, true, (char) 60540, (char) 43026,
        Double.longBitsToDouble(0x3fedab72d65be691L), Double.longBitsToDouble(0x3feb55748ee32709L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud8f2\uded9\ud98c\udd25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda5c\udf3e~\ud84b\udd45\ud818\udf02\udb78\udf33\ud85e\udd80\uec03\ud8d3\ude67\ud934\udf32\ud8a8\udcaf\ud90c\udd20\uda6e\ude26\udbc3\udc51\uda33\ude7c\ud949\udcd5\ud909\udc4f\uda0e\udefe\udb33\udc00\udb0c\udf48\uda2b\udf84\uda27\udd6c\uda48\udd57\ud987\ude22\udb01\udec7\udae2\udca9\ud9e1\udd33\012",
        Z.run(T, 1, 3, 5, 12, "\udb03\udfb1\ud9bd\uddf2\ud8bc\udf05\ud8f2\uded9\ud98c\udd25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda5c\udf3e~\ud84b\udd45\ud818\udf02\udb78\udf33\ud85e\udd80\uec03\ud8d3\ude67\ud934\udf32\ud8a8\udcaf\ud90c\udd20\uda6e\ude26\udbc3\udc51\uda33\ude7c\ud949\udcd5\ud909\udc4f\uda0e\udefe\udb33\udc00\udb0c\udf48\uda2b\udf84\uda27\udd6c\uda48\udd57\ud987\ude22\udb01\udec7\udae2\udca9\ud9e1\udd33", "\u69b2\u04bc\u8264\u2a83\u6f46\u1d78\u15d7\u75ae\u6bd1\u03bb", "\ud903\udd2d\ud9ef\udc4d",
        40, 16789, -1990640497, -150325963556474530L, -69845L, true, false, (char) 9884, (char) 12302,
        Double.longBitsToDouble(0x3fac60889101e1b0L), Double.longBitsToDouble(0x3fe3e94297fb050dL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud957\udebe\ud8bc\udf05\ud8f2\uded9\ud983\ude25\ud9ee\ude25\udb90\udf0c\ud94f\udfbb\udad5\udc12\ud949\udf54~\ud9ae\udd2f\udaaa\udf6b\udb6b\udd2b\ud85e\udd80\012",
        Z.run(T, 1, 3, 11, 0, "\udb03\udfb1\ud957\udebe\ud8bc\udf05\ud8f2\uded9\ud983\ude25\ud9ee\ude25\udb90\udf0c\ud94f\udfbb\udad5\udc12\ud949\udf54~\ud9ae\udd2f\udaaa\udf6b\udb6b\udd2b\ud85e\udd80", "\ua6e6\u7327\u73da\u05e5\u5c21\u0a4d\ua85b\u136d\u9226\u35e6\u1b49\u4dc2\u118e\u0509\uc4bc\u91f2\u5ef3\ud4f4\u89e0\u1653\u69b2\u0be9\u8264\ub89b\u46ea\u1d90\u15d7\u75ae", "\ud9a4\ude09\udbb4\udefc\ud9a7\ude00\ud9b7\udf36\ud8a2\ude3a\uda8e\udc0a",
        3, 61744, 1942177733, 7242226184539876133L, 92611L, false, false, (char) 41267, (char) 61399,
        Double.longBitsToDouble(0x3fd61ac799ab4b6eL), Double.longBitsToDouble(0x3fd0666705c5204aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9bd\uddbe\ud8bc\udf05\ud8f2\uded9\ud983\ude25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\ud949\udf54~\ud9ae\udd2f\012",
        Z.run(T, 1, 3, 11, 0, "\udb03\udfb1\ud9bd\uddbe\ud8bc\udf05\ud8f2\uded9\ud983\ude25\u18dc\udb8b\udd5e\ud94f\udfbb\udad5\udc12\ud949\udf54~\ud9ae\udd2f", "\u3c0a\uc7dc\u6452\ua6e6\u7327\u73da", "\uda33\ude7c\uda39\udc4d",
        0, 93642, 27591656, 524149097816913070L, 86708L, true, true, (char) 60540, (char) 50818,
        Double.longBitsToDouble(0x3fedaff03e5be691L), Double.longBitsToDouble(0x3fe4f5748f985f4cL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\0121=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 4, 4, 8, "", "\u1d85\u6d29\uc40f", "\ud9df\udf2a\udad5\udc12\uda9e\udde0\ud924\udf74\ud861\uddec\ud818\udf02\ud81c\udd2b\ud880\udde3\udbe9\udd4b\ud8d3\ude67\035\uda1e\ude0b",
        -2, 38831, 354894828, 1779525517360234551L, 54162L, false, true, (char) 49828, (char) 26832,
        Double.longBitsToDouble(0x3fe458d5a7f50ecaL), Double.longBitsToDouble(0x3fd99c17b8413d7aL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 0, 0, 10, "55\000\ud8fd\uddfd\ud8d0\udd99", "\ub982\u391e\u68d7\u0b2d/\u7aaa", "\uff03\ud8d3\ude15\ud81b\udf9d",
        -5, 95593, -1527456473, 31065498451968L, 60971L, false, false, (char) 0, (char) 48517,
        Double.longBitsToDouble(0x3fe950a63f02fa33L), Double.longBitsToDouble(0x3fe0e6e0bae253a0L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=null |this=com.fasterxml.jackson.core.JsonPointer:\012",
        Z.run(T, 2, 9, 9, 0, "\udb03\udfb1\ud9c6\udcf2\000\000\ud90f\udd86\udb51\udc03\udb12\udd68\ud94f\udfbb\000\ud82c\udd50\ud93a\udc3c\ud828\udf30\ud83d\udcde\ud895\udeed\uda4e\uddef\udb1e\uddc0\ud977\uded6\u3d08\ud984\udfc1\ud881\udc41\ud807\udcc3\000", "\u9591\u46bb", "\000\udb6e\udd97",
        -1, 93873, -703961889, -5116088639821971456L, -52704L, true, false, (char) 53625, (char) 64392,
        Double.longBitsToDouble(0x3fe983aa642073f2L), Double.longBitsToDouble(0x3fdb56e5a0000114L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9d7\udff2\ud8bc\udf05\uda6a\udfd4\ua511\000\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda80\udd1e/\ud84b\udd45\ud818\udf02\udb56\udcce\udba4\udc6c\ud8b8\udca3\ud8d3\ude67\udb22\udee6\uda3b\ude92\ud90c\uddb8\uda6e\ude26\udbc3\udc51\0121=com.fasterxml.jackson.core.JsonPointer:\udb03\udfb1\ud9d7\udff2\ud8bc\udf05\uda6a\udfd4\ua511\000\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda80\udd1e/\ud84b\udd45\ud818\udf02\udb56\udcce\udba4\udc6c\ud8b8\udca3\ud8d3\ude67\udb22\udee6\uda3b\ude92\ud90c\uddb8\uda6e\ude26\udbc3\udc51\012",
        Z.run(T, 2, 3, 3, 11, "\udb03\udfb1\ud9d7\udff2\ud8bc\udf05\uda6a\udfd4\ua511\000\udb8b\udd5e\ud94f\udfbb\udad5\udc12\uda80\udd1e/\ud84b\udd45\ud818\udf02\udb56\udcce\udba4\udc6c\ud8b8\udca3\ud8d3\ude67\udb22\udee6\uda3b\ude92\ud90c\uddb8\uda6e\ude26\udbc3\udc51", "\u7841\ua0ed", "\udbea\udd64\udb6e\udde9\uda48\udd57\udbae\udc34\udb40\udee2\udac8\udc5e\uda34\ude2e\udbd8\udc6b\ud911\uddd0\uda5e\udc3d\udb81\udc2f\uda61\ude48\ud8cb\ude05\udb50\udea0\ud823\udfa6",
        38, 51515, 1951596515, 4497830631788918278L, -12078L, false, false, (char) 19561, (char) 36850,
        Double.longBitsToDouble(0x3fc940eeaeeb6324L), Double.longBitsToDouble(0x3fe0d4f86b14219bL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.JsonPointer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 13, "\ud8dd\ude4b\ud999\udfc6\udb78\udd5c\uda6b\udc9f\ud801\ude4c\udb51\udc6d\uccd9\ud94b\udc0e\udb3c\udc7d\000\000\ud861\udd45\ud818\udf02", "\u7d55", "\udb15\udd2f\ud9df\udd21\uda45\udf91\ud9ca\udd06\000\ud8d8\ude0c\ud8b8\ude79\uda0e\udeed\ud8fe\udfa6\ud91d\udebd\uda56\udc4b\ud9f1\udf68\ud90e\udc27\udb55\ude93\uda2c\udd6a\udb83\udfb9\uda22\uddf5\ud83f\udc5f\ud998\udd93\uda5b\ude0b\udb81\udc00\ud9fd\udfa2\udb8e\udf67\u2bd3\ud824\udc25\ud848\ude10\uf380\ud9a0\ude0c\uda35\udff0\ud88a\ude30\udbc6\udf4c",
        29, -1000, 1412416544, 196456099086336L, -100000L, true, true, (char) 48, (char) 20364,
        Double.longBitsToDouble(0x3fb24e400004ad90L), Double.longBitsToDouble(0x3e4344f404000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.JsonPointer|_parseIndex|java.lang.String|static",
    "M|com.fasterxml.jackson.core.JsonPointer|_appendEscape|java.lang.StringBuilder,char|static",
    "M|com.fasterxml.jackson.core.JsonPointer|_parseQuotedTail|java.lang.String,int|static",
    "M|com.fasterxml.jackson.core.JsonPointer|_parseTail|java.lang.String|static",
    "M|com.fasterxml.jackson.core.JsonPointer|compile|java.lang.String|static",
    "M|com.fasterxml.jackson.core.JsonPointer|equals|java.lang.Object|new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|getMatchingIndex||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|getMatchingProperty||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|hashCode||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|matchElement|int|new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|matchProperty|java.lang.String|new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|matches||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|mayMatchElement||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|mayMatchProperty||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|tail||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|toString||new:com.fasterxml.jackson.core.JsonPointer:",
    "M|com.fasterxml.jackson.core.JsonPointer|_parseIndex|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
