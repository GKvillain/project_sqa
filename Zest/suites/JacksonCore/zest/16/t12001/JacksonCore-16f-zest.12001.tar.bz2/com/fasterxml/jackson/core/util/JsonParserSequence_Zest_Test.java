package com.fasterxml.jackson.core.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonParserSequence_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 7, 1, "\ud8ba\udf3a\ud9ca\udfc2\ud91b\udcd1", "\u16de\ud4cf\u4990\u7816\u7dd6\u9fd3\u75cb\ucbd6\u3ddc", "\udab6\udcd9",
        56, 35746, -411932765, -4472671277313358932L, -48075L, true, false, (char) 32109, (char) 47298,
        Double.longBitsToDouble(0x3fdbeec29d074ec6L), Double.longBitsToDouble(0x3fde506974e50ee6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 1, 2, "\ud8b0\udd45\ud837\udd00\ud926\udf4d", "\ud2dc\ud4cf\u4990\uc4d3\u2d8a\u9fd3\u2658\u2f8c\u3fd5", "\uda83\udfd9\uda4a\udc04\ud992\udf6a",
        9, 35088, -1499135060, 898070133455479253L, -40496L, false, true, (char) 566, (char) 29882,
        Double.longBitsToDouble(0x3fd89bfb3768a26aL), Double.longBitsToDouble(0x3fdc1f8f17bcc474L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 7, 1, "\ud8ba\udf3a\ud9ca\udfc2\ud91b\udcd1", "\u16de\ud4cf\u4990\u7816\u7dd6\u9fd3\u75cb\ucbd6\u3ddc", "\udab6\udcd9",
        38, 35746, -410895844, -4472671277313358932L, -48075L, true, false, (char) 32109, (char) 47298,
        Double.longBitsToDouble(0x3fdbeec29d074ec6L), Double.longBitsToDouble(0x3fde506974e50ee6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 7, 1, "\ud8ba\udf3a\ud9ca\udfc2\ud91b\udcd1", "\u41d5\ud545\u4990\uc627\u7da8\u7fd3\u0d6a\ucbd6\u84f8", "\udbf6\udc53\udad9\udea0\udb08\udd35\uda35\ude30\uda27\udd83\udbb7\ude67\u76c3\udbe9\udc8f\udbbd\udd31\ud843\udf13\udae3\udc63\ud854\udc85\ud94b\udf5b\ud92c\ude90\ud871\udd95",
        39, 5107, 1824779526, 8735526682373013400L, -22331L, true, false, (char) 40314, (char) 65050,
        Double.longBitsToDouble(0x3fe248ff1a62a7c2L), Double.longBitsToDouble(0x3fe49f76b4a1e8b8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 7, 1, "\ud973\udf4c\ud9ca\udfc0", "\u0834\ud7b6\u2aa3\u0b51\u77f8\uab02\u9fd3", "\uda29\uddc4\udb3c\udc05\udab2\udead\udbf0\udf16\uda04\udfb3\ud970\udded\uda35\ude30\uda27\udd83\udbb7\ude30\u76c3\ud9c8\udd7f\udaa9\udd31\ubafe\ud904\udf14\ud854\udc85\ud844\uddd9\ud930\udeca\ud9e6\udc10\uda84\ude72\udb81\uddb3\udbc8\udc0a\ud9cf\udf03\ud9ef\udfd4\udbbd\ude3f\udad3\udee7\uda55\udfc1\uda1f\udf90\udadf\udd08",
        34, 94339, 816135054, -6773072675234813027L, 12441L, true, false, (char) 25074, (char) 39476,
        Double.longBitsToDouble(0x3fe9cdce94d6e568L), Double.longBitsToDouble(0x3fe7ffe3bef21282L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 1, "\ud8ba\udf3a\ud9ca\udfc2\ud91b\udcd1", "\u16de\ud4cf\u6bdd\u7816\u0108\u9fd3\u206e\ucb9c\u3ddc", "\uda26\udc74",
        35, 80159, -541243909, -4536670550631316564L, -40030L, true, false, (char) 41091, (char) 10725,
        Double.longBitsToDouble(0x3fd0d18848ec79d6L), Double.longBitsToDouble(0x3fe7abd0fd30d307L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 1, "\ud866\udf10", "\u277e\u9ffe\u68e2\u5f66\u7ea4\u7b23\u7d7e", "\ud8c9\uddae\uda29\udd55\udb3c\udc05\udbb9\udf17\udab6\udcd9\uda4a\udc04\u5480\uda35\ude30\uda27\udd83\udbb7\ude67\udb1a\udfa9\uc1f3\u1c18\ud843\ude66\udae3\udc63\ud854\udc60\ud9a3\udee6\ud930\udeca\udbe8\udfd1\ud92a\udcca\udb9f\ude62\ud9ae\udc3b\ud9f0\uddb2\udac9\udc33\ud8f0\udd2b\ud94a\uddc1\ud9ac\ude92\udbde\udfe2\udb0f\uddc1\ud829\ude0d\u2115\udbd3\udce1\ud858\udca0\ud97c\udd8d\udb2e\udcfc\udb87\udf57\uda6d\udca3",
        39, 25685, -653748746, 7233988747119091123L, 4094L, false, false, (char) 6105, (char) 47812,
        Double.longBitsToDouble(0x3f83a722477720c0L), Double.longBitsToDouble(0x3fef5f70939e08ddL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 7, 5, "\uda65\udc4f\ud9ca\udff5\ud91b\udcd1", "\ud220\u62dc\u4990\u9145\u588c\u9fd3\u75cb\ucbd6\u3ddc", "\ud963\udeb0",
        12, 59239, -411921299, -4472671277313358932L, -40030L, true, false, (char) 32146, (char) 10832,
        Double.longBitsToDouble(0x3fd0674c88ddce42L), Double.longBitsToDouble(0x3fc845d159d74978L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 0, "\ud8ba\udee3\udbb0\uddec\ud803\udc6a", "\u16de\u1662\u4990\u7816\u7dd6\u9fd3\ud7bf\ucbd6\u3ddc\uc53f\u621f\ua8bf\u85df", "\udaa4\udc21\ud943\udcd9\ua590\udbe9\udc8f\udbbd\udd31\ud843\udf13\ud8f9\udece",
        49, 49719, -2019865448, 4622560676363186413L, -31780L, true, false, (char) 44013, (char) 48303,
        Double.longBitsToDouble(0x3fa2ddfcc62fe370L), Double.longBitsToDouble(0x3fec12ff06df8432L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 1, "\ud8d2\udf3a\ud9ca\udfc2\ud859\udf88", "\u16de\ud4cf\u4990\u2062\u7de7\u9fd3", "\ud94d\udcf3\ud84a\udec4\udbb9\udf17\udab6\udcd9\uda4a\udc04\ud935\udc2c\uda35\ude1b\uda27\udd83\udbb7\ude67\u76c3\udbe9\udc8f\ud8d3\udf3d\ucbf5\ud877\udefd\udbd5\udf81\ud9a3\udee6\ud930\udeca\udb76\ude98\udbed\udd65\ud93c\ude91\ud989\udc0a\ud847\ude68\udacf\ude85\udae8\uddfd\udad0\udeb4\udbfa\udea8\ud9a9\udd07\ud8ed\uddad",
        43, 82569, -1539941686, 3843377083466000706L, -52514L, true, true, (char) 9274, (char) 19572,
        Double.longBitsToDouble(0x3fbca7e6c93dbfd8L), Double.longBitsToDouble(0x3fe688223c5148b0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 4, "\ud899\ude3a\ud9ca\udfc2", "\u3c26\u16de\u0fcb\u5ed3\u7be0\u7dd6\ua86a", "\ud8b6\udeec\ud9c8\udf42\ud94b\udc1a\ud9cd\udf9c\ud888\udd85\ud970\udeb0\uda35\ude30\ud899\uddcb\ud89e\udf20\u76c3\ud892\udf84\ud87b\udd11\ud99f\udf13\udae3\udc58\ud9bf\udd39\ud985\udec0\ud930\udeca\ud9fc\uddba\udb1e\udf27\uda4d\udf5f\udbcb\udd97\ud8a3\udf7b\udaa4\ude8f\udafa\uddec\ud88a\uddf8\udbdb\ude8a\ud917\udc2a\uda94\udf5b\ud92c\udfb6\udb5d\udf2b\ud91d\udf7c",
        13, 90010, 1188548114, 4743934774989019082L, 6479L, true, false, (char) 9645, (char) 47705,
        Double.longBitsToDouble(0x3fd439a620881a50L), Double.longBitsToDouble(0x3fdd0b9684808f5eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 1, "\ud813\udd3b\ud9ca\udfc2", "\u73f2\u3f5a\ud4cf\u4990\u7816\u7dd6\u9fd3", "\uda29\udd55\udb3c\udc05\udbb9\udf17\udab6\udcd9\ud8e8\udf33\ud8aa\udd01\ud882\ude14\uda1f\uddc7\udaed\udf83\u7748\udbe9\udc8f\ud839\udc37\ud961\udd61\udae3\udc0a\ud8b9\udcd6\udabb\udf36\uda39\udeab\ud981\udcac\uda6d\udd63\udb8e\ude79\udba0\ude60\udbad\uddad\ud976\udc31\ud83e\ude74\udbd8\udc05\u37e1\udb44\udc96\udacb\udfbb",
        31, 8652, -1175769837, 3063130635626025724L, -1586L, true, true, (char) 10388, (char) 27698,
        Double.longBitsToDouble(0x3fddb75409b2957eL), Double.longBitsToDouble(0x3fe12468786181ceL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 4, 7, "\uda0d\udd39\udae0\udee0\ud997\ude71", "\u16de\u7533\u28a5\u7816\u7dd6", "\ud923\udf9c\uda29\udd55\ud806\udc8b\ud92d\udfd5\uda70\uddb9\udb20\udd64\uda72\udf93\uda35\ude30\ud9d9\udd7c\udbb7\udd67\u76c3\uda22\udf6d\ud8a9\udd30\ud843\udf13\ud8a1\udc62\ud894\udcdf\ud9b1\ude41\ud83a\uddc8\udb92\udcb7\ud971\uddb5\ud981\udfec\ud85d\udceb\uda88\udeb4\uda81\udd8e\ua07d\udb72\uddbf\uda30\udc3b\ud84b\udcae\ud810\ude20\udbd7\udf91\ud8d2\udf1a\udbd2\udff9\ud9cf\udeb9\udbbb\udc7e\ud8f7\udd4b\uda0b\udf51\udbda\udee1",
        58, 37054, 1133163429, -4863414618516263505L, 51676L, false, true, (char) 52189, (char) 38378,
        Double.longBitsToDouble(0x3fde7a0ed49168c6L), Double.longBitsToDouble(0x3fde9663fa1744ecL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 1, "\ud8ba\udf3a\ud814\udffc\ud9bf\udc8b", "\u754c\ud4cf\uac3b\u7816\u7dd6\u2c4e\u75cb\u4d7f\u3ddc\uc53f\u8b0d\uac0b", "\uda35\ude30\ud8e6\udec2\ua402\udac3\udef4\uc5f8\uda59\udfaa\udad2\udfb7\udab7\udc49\ua1e9\ud840\udf17\ud930\udeca\ud9ad\ude4f\uda01\ude32\udb60\udca7\ud8d9\udf8d",
        17, 83895, 1717642788, 6605736964424412850L, 59184L, false, false, (char) 13742, (char) 980,
        Double.longBitsToDouble(0x3fe3fa5703be7147L), Double.longBitsToDouble(0x3fcf8a5e26cce470L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 1, "\udb91\udc41\ud9cb\udc1a\ud91b\udcd1\ud828\udcc6\ud9cd\udd94\udaaa\udc63\ud818\ude83\u7f33\u059d\udb99\udea4\udbbf\udefc\udba7\udf0e\ud923\udf9c\uda29\udd55\udb3c\udc05\udbb9\udf17\udab6\udcd9\ud91d\ude8d\ud970\ude6d\uda35\ude30\uda27\udd83\udbb7\ude67\u76c3\udbe9\udc8f\udbbd\udd31\ud843\udf13\udae3\udc63\ud854\udc85\ud9a3\udee6\ud9e2\uddc7\ud909\ude82", "\ud1de\ube14\u5bb9\u0f1b\uaead\uc11c\u39e4", "\ud991\udf75",
        23, 16358, -484688265, -2598856743625161100L, -10568L, false, true, (char) 7517, (char) 49352,
        Double.longBitsToDouble(0x3fe9ea95d7bd9d70L), Double.longBitsToDouble(0x3fe4a2323b83b7a6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 6, 1, "\ud8ba\udf3a\ud9ca\udfc2\ud91b\udcd1", "\u16de\ud4cf\u4990\u7816\u7dd6\u9fd3\u75cb\ucbd6\u3ddc", "\ud93e\udffb",
        41, 11000, -411932896, -4472671277771087956L, -85589L, true, true, (char) 32109, (char) 47298,
        Double.longBitsToDouble(0x3fdbeec29d074ec6L), Double.longBitsToDouble(0x3fde50697c678ee6L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 2, "\ud816\udd94\ud80d\udcad\udb29\udc51", "\u72a3", "\uda03\ude54\ud860\udd93\udbbf\uded4\uda49\udd6d",
        7, 71736, -116392536, 3010333002746281516L, 23200L, false, true, (char) 54883, (char) 27174,
        Double.longBitsToDouble(0x3fb5ce001962ad68L), Double.longBitsToDouble(0x3fe24cd76bc08e0cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud8b0\udd45\ud8c5\ude48\udb9a\udefa", "\ud2dc\ud4cf\u3177\u92f3\u9cb2\u721d\u25f2\u2f8c\u3fd5", "\ud895\udfe2\udbbc\udc88\ud8da\udc68",
        34, 35088, -1499135060, 898070133234546133L, 16L, false, true, (char) 566, (char) 29882,
        Double.longBitsToDouble(0x3fc137f66ed1440cL), Double.longBitsToDouble(0x3fdc1f8f17bcc474L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 1, "\uda2b\udce3\ud87e\udda4\udb86\udfd0\udaf3\udcdd\ud9cd\udd94\udaaa\udc63\ud818\ude83\uda08\udd90\udbad\udfe4\udbff\udec7\udbbf\uded4\uda2d\uddec\ud923\udf62\uda29\udd55", "\uc61d", "\ud905\udc14\ud875\ude76\ud863\udd5c\ud830\udddc\ud8bb\udd5b\uda6c\udec8\ud843\udf13\uf290\ud853\udfe3\ud9a3\udee6\ud930\uded2\udb8c\udfe3\ud9b1\ude2a\ud842\udfc4\ud9f7\udc4e\udbb7\udede",
        35, 89610, 1552433221, 8356189456878956425L, 26030L, false, false, (char) 46394, (char) 63945,
        Double.longBitsToDouble(0x3fe94610980692e3L), Double.longBitsToDouble(0x3f9e12be73493de0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 5, "\udaa1\udcd0\ud9ca\udfc2\ud91b\udcd1", "\u16de\ud4cf\u6bdd\ub1d1Y\ub60c\ua830\ucb9c\u3ddc", "\uda26\udc74",
        35, 80159, 38999630, 5016310084200151043L, 6008L, true, false, (char) 64003, (char) 38386,
        Double.longBitsToDouble(0x3fdbeec29d074ec6L), Double.longBitsToDouble(0x3fdff4b974e50ee6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 1, "\ud8ba\udf3a\ud9ca\udfc2\udac3\ude46", "\u16de\ud4cf\u6bdd\u7816\u0108\u9fd3\u206e\ucb9c\uc628\u1434\u3187\u2b63\u5eba\u6a4e", "\udbb7\ude67\ud937\udcef\udbe9\udc96\udbbd\udd31\udafb\udedf\udae3\udc63\ud854\udc85\ud9a3\udee6\ud930\uded2\udb83\udd3e\uda8c\udddc\ud96d\udc0a\ud9f7\udc4e\uda5c\udc2e\udaa2\ude54\ud9dd\ude43\ud950\udea8\ud8ab\udd7c\ud970\udf3b\ud95c\udf93\udb72\udc23\u2763\ud8ff\udde1\udbe0\udca2\udb8f\udc7b\udafa\ude05",
        8, 50745, 1341494764, -6320750505206731940L, 37858L, true, true, (char) 40480, (char) 35347,
        Double.longBitsToDouble(0x3fe3c2d54fcbcbbdL), Double.longBitsToDouble(0x3fc567e4713107fcL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 1, "\ud92f\udc5c\udb04\udfe0\udbbd\ude00", "\u16de\u46c9\uaec6\u1d7a\u0108\u9fd3\u206e\ucb9c\u3ddc", "\uda26\udc74",
        35, 80159, -541243909, -4536670550631316564L, -9847L, true, false, (char) 65453, (char) 13033,
        Double.longBitsToDouble(0x3feace11d0a6d514L), Double.longBitsToDouble(0x3fdc4d53f4e50ea6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 1, "\ud8ba\udf3a\ud9ca\udfc2\ud91b\udcd1", "\u16de\u6f11\ud7fd\u7816\u0108\u9fd3\u206e\ucb9c\u3ddc", "\uda26\udc74",
        35, 80159, -541243909, -4536670550631316564L, 34466L, true, false, (char) 41091, (char) 10725,
        Double.longBitsToDouble(0x3fd0d18848ec79d6L), Double.longBitsToDouble(0x3fe7abd0fd30d307L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 2, "\ud8ba\udf3a\ud9ca\udfc2\ud91b\udcd1", "\u16de\ud4cf\u6bdd\u7816\u0108\u9fd3\u206e\ucb9c\u3ddc", "\uda26\udc74",
        35, 80159, -541243909, -4536670550631316564L, -40030L, true, false, (char) 41091, (char) 10725,
        Double.longBitsToDouble(0x3fd5d18848ec79d6L), Double.longBitsToDouble(0x3fe7abd0fd30d307L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 4, "\ud866\udf10", "\u1a2a\u9ffe\u68e2\u5f66\u7ea4\u7b23\u79a4", "\ud900\udcfd\udbe3\udda3",
        57, 88649, -431818146, 886460683259944346L, 86612L, false, true, (char) 1439, (char) 39618,
        Double.longBitsToDouble(0x3fe16dd5e6e4b6adL), Double.longBitsToDouble(0x3fd8fa56fb33d852L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 1, "\ud866\udf10\uda5c\ude84\ud91b\udcd1\ud828\udcc6\ud9a2\udcff\ud8c2\udf16\udb57\ude7a\ud9d6\uded9\ud91a\udc3c\udb99\ude41\udbbf\uded4\udba7\udf0e\ud8c9\uddae\uda29\udd55\udb3c\udc05", "\u85df", "\uda27\udd83\udbb7\ude67\udb1a\udfa9",
        31, 39265, -751621878, -1429359005857016423L, 85550L, false, false, (char) 46892, (char) 54503,
        Double.longBitsToDouble(0x3fd56c110f546144L), Double.longBitsToDouble(0x3feef0cc4dcb200aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 7, 1, "\ud8ba\udf3a\ud9ca\udfc2\ud91b\udcd1", "\u16de\ud4cf\u4990\u7816\u7dd6\u9fd3\u75cb\ucbd6\u3ddc", "\udab6\udcd9",
        56, 35746, -411932765, -4472671277313358932L, 8221L, true, true, (char) 37312, (char) 27288,
        Double.longBitsToDouble(0x3fdbeec29d074ec6L), Double.longBitsToDouble(0x3fde506974e50ee6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 1, "\ud866\udf10", "\u277e\u7a19\u68e2\u5f66\u7ea4\u7b23\u7d7e", "\ud84c\udf33\uda0c\udc1e\udb3c\udc05",
        -1, 56854, 206434379, 8434993173938464675L, 95668L, true, true, (char) 39618, (char) 41389,
        Double.longBitsToDouble(0x3fd0acfadb1fa666L), Double.longBitsToDouble(0x3fd99ec29d074ec6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 1, "\udaf4\udf08\ud87e\udda4\udb86\udfd0\udaf3\udcdd\ud9a9\udd63\ud93e\udea4\ud818\udee6\uda2b\ude23\udbdd\udcb8\u256d\udbec\udfc1\ud3a2\ud824\ude23\uda29\udccb", "\uc61d", "\ud904\udf95\udbd7\udf29\ud863\udd5c\udbc9\udf81\udad2\udc14\ud9f9\udcd7\udaf0\udfcc\ud949\udd1e\udae1\udf2a\ud9a3\udee6\ud930\uded2\udb8c\udfe3\udabe\udcd1\ud8f1\udef9\ud9f7\udfa4\udbb7\udede",
        -5, 89479, 1552433221, -918411022831464717L, 36114L, false, false, (char) 4454, (char) 48244,
        Double.longBitsToDouble(0x3fe13d1980bccab4L), Double.longBitsToDouble(0x3f9e12be73493de0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 1, "\ud932\udd11\uda5c\ude84\ud91b\udcd1", "\u68e2\u5f66\u7ea4\u7b23\u7d7e\u6f3b\u3dbf\u02f1\ua0a4", "\ud921\udcae",
        29, 79890, -411932765, -4472671277233142868L, -71832L, false, false, (char) 63617, (char) 47298,
        Double.longBitsToDouble(0x3fd99ec29d074ec6L), Double.longBitsToDouble(0x3fe614341bec52ecL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 7, 1, "\ud8ba\udf3a\ud9ca\udfc2\ud91b\udcd1", "\u16de\ud4cf\u4990\u7816\u7dd6\u9fd3\u75cb\ucbd6\u3ddc", "\udab6\udcd9",
        56, 35746, -411932765, -4472671277313358932L, -64511L, true, false, (char) 32109, (char) 47298,
        Double.longBitsToDouble(0x3fdbeec29d074ec6L), Double.longBitsToDouble(0x3fde506974e50ee6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.util.JsonParserSequence|nextToken||new:com.fasterxml.jackson.core.util.JsonParserSequence:[Lcom.fasterxml.jackson.core.JsonParser;",
    "C|com.fasterxml.jackson.core.util.JsonParserSequence|<init>|[Lcom.fasterxml.jackson.core.JsonParser;",
    "M|com.fasterxml.jackson.core.util.JsonParserSequence|addFlattenedActiveParsers|java.util.List|new:com.fasterxml.jackson.core.util.JsonParserSequence:[Lcom.fasterxml.jackson.core.JsonParser;",
    "M|com.fasterxml.jackson.core.util.JsonParserSequence|close||new:com.fasterxml.jackson.core.util.JsonParserSequence:[Lcom.fasterxml.jackson.core.JsonParser;",
    "M|com.fasterxml.jackson.core.util.JsonParserSequence|containedParsersCount||new:com.fasterxml.jackson.core.util.JsonParserSequence:[Lcom.fasterxml.jackson.core.JsonParser;",
    "M|com.fasterxml.jackson.core.util.JsonParserSequence|createFlattened|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.JsonParser|static",
    "M|com.fasterxml.jackson.core.util.JsonParserSequence|switchToNext||new:com.fasterxml.jackson.core.util.JsonParserSequence:[Lcom.fasterxml.jackson.core.JsonParser;",
    "M|com.fasterxml.jackson.core.util.JsonParserSequence|nextToken||new:com.fasterxml.jackson.core.util.JsonParserSequence:[Lcom.fasterxml.jackson.core.JsonParser;",
    "C|com.fasterxml.jackson.core.util.JsonParserSequence|<init>|[Lcom.fasterxml.jackson.core.JsonParser;",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
