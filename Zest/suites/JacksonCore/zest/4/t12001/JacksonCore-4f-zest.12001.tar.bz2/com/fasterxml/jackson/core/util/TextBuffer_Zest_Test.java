package com.fasterxml.jackson.core.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class TextBuffer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 13, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\ud841\udefb\uc6fb\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\ud961\udc89\udac9\udfcb\ud9bd\udee7\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\ub38c\uba3e\u6304\ub11a\u81bd\u6414\u170e\u16a4\u9e77\ucd3c\u1755\u2938\u6128\ucfd7\u8b8a\u9f96\ub67c\u7947\uc958", "\ud811\udfa8\ud88f\udd9e",
        2, 93657, 879548343, 4678558194066084640L, 16756L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f161594b221L), Double.longBitsToDouble(0x3fe2e5bccdc61ed0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 13, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0f\udd22\uda4b\udfc8\ud959\udc66\ud841\ude56\udb77\udca7\udb2a\udd43\u722e\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\ud9fc\udcb6\ud9cf\udd0d\ud9bd\udee7\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\ub38c\uba3e\u6304\ub11a\u81bd\u6414\u170e\u16a4\u9e77\ucd3c\u1755\u2938\u6128\ud6c1\u8b8a\u6422\ub67c\u7947\u6d44", "\ud811\udfa8\ud88f\udd9e\ud9ef\udef8\ud95a\udc2f\udb60\udc8c\uda0e\udd7f\udb2b\ude8b\ud833\udeda\ud821\udc54\u4c37\udb32\udd45\udb88\uddba\ud898\udc6c\udad8\udd4f\udb71\udc2c\ud879\udff2\udb2f\udc61\ud83f\uddb8\udbb8\udca3\ud9b0\udd25\ud885\udebc\udb25\udd65\ud906\ude0e\uda4a\udc07\udad8\udfb6\udaac\ude85\ud8b5\udd3e\ud99d\udd16\ud8fe\ude02\u6d9b\udb0a\udc1a\uda8b\udd35\ub683\ud8e9\udf8d\ud82a\udf27\udb92\uddd8\uda2d\ude4b",
        38, 74273, -1423462886, -8082992441797710278L, 92904L, false, true, (char) 42427, (char) 32824,
        Double.longBitsToDouble(0x3fe99eb776f151c4L), Double.longBitsToDouble(0x3fe4ce6bc0a88633L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 13, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbbb\udc86\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\ud841\udefb\uc6fb\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\udbb4\udfd4\udac9\udfcb\ud9bd\udee7\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\ub38c\uba3e\u6304\ub11a\u81bd\u6414\u170e\u4ff1\u9e77\ucd3c\u1755\u2938\u6128\ubf34\u8b8a\u9f96\ub67c\u7947\uc958", "\ud811\udfa8\ud88f\udd9e",
        2, 93657, 879548343, -298763819108445396L, 16756L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f161594b221L), Double.longBitsToDouble(0x3fd90b799b8c3da0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 8, 13, 7, "\udae5\udf88\ud83d\udfc9\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\u83cc\udbfc\udcfe\uda55\udce6\ud994\ude2a\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\ud961\udc89\udac9\udfcb\ud9bd\udee7\uda83\udce3\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\ub38c\uba3e\u6304\ub11a\u81bd\u6414\u170e\u16a4\u9e77\ucd3c\u1755\u28c3\u6128\u5bfe\u8b8a\u9f96\ub67c\u78a7\uc958", "\ud811\udfa8\ud88f\udd9e",
        2, 93657, 879548343, 4678558194066084640L, 16756L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f161594b221L), Double.longBitsToDouble(0x3fe2e5bcc80000d0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 13, 7, "\udae5\udf88\ud83d\udffb\u290b\udba6\udec0\ud88c\udc12", "\u855d\u3684\uc367\u900d\u522a\u07eb\ud52e\u1e53\uaf2e\u2bd5\u1121\u7a15\u2f66\u1228\uab96\ucf80\uc1c8\u0a3f\u19f3", "\ud8ea\ude96\ud90a\udf4c\ud918\udc94\ud818\udddf\ud91b\udf6f",
        46, 22609, -2023847315, 9047708417863416534L, 98385L, true, false, (char) 22266, (char) 32744,
        Double.longBitsToDouble(0x3fed89d6d5d9895eL), Double.longBitsToDouble(0x3fd45afabd7f0ea2L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 10, 3, 7, "\udae5\udf88\ud937\udff8\udb88\udc49\ud821\udc76\udad2\uddda\ud9d2\udec0\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\ud99c\udc91\udaab\udf88\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\ud841\udefb\udb99\udf0d\uda55\udd30\udbf7\ude5b\udbdb\udde4\uda8a\udd9a\udb51\ude86\ud808\udfee\udb17\udc60\ud961\udc89\udac9\udfcb\ud8b0\udf80\udbfb\ude09\ud831\uddc5\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\u5212\u8111\ud530\u6f8b\ud5a2\u9198\u55d9\u16a4\u357a\u9304\u1755\u2938\u6128\ucfd7\u8b8a\ucb33\ub658\u0278\u4d24", "\ud811\udfa8\ud88f\udd9e",
        44, 93657, 879548343, 4678558194066084640L, -51794L, false, true, (char) 28101, (char) 20630,
        Double.longBitsToDouble(0x3fe2e5bccdc61ed0L), Double.longBitsToDouble(0x3fdbfa77d2313b32L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 4, 10, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\ud841\udefb\uc6fb\uda55\udce6\udbf7\ude5b\000\000\udab6\uddb3\ud808\udfee\udb17\udc60\ud961\udc89\udac9\udfcb\ud9bd\udee7\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\ub38c\uba3e\u6304\ub11a\u81bd\u6414\u170e\u16a4\u9e77\ucd3c\u1755\u2938\u6128\ucfd7\u8b8a\u9f96\ub67c\u7947\uc958", "\000\ud86d\uded5",
        2, 93657, 879548343, 66872176942252032L, 45388L, false, true, (char) 12131, (char) 6900,
        Double.longBitsToDouble(0x3fe818000594b221L), Double.longBitsToDouble(0x3fe2e5bccdc61ed0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 10, 7, "\udae5\udf56\u26ad\udacb\ude3b\u4091\udae5\udde9\ud845\udd04\uda11\udff5\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0d\ude22\ud94e\udf8a\udbf2\udc24\ud882\ude76\uc6fb\uda55\udce6\ud851\udd3e\udbf8\udc8b\ud864\udf46\udae1\udeac\ud8f8\udfe6\udacc\udde8\ud9b8\udffa\udae8\udc04\ud9bd\udee7\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u3bd7\u77df\ucb64\ub38c\uba3e\u6304\ub11a\u81bd\u356f\u3abd\ubed3\u1309\u3c99\u4097\u2938\u6128\ucfd7\u8b8a\u6550\u869f\u2670\u306c", "\ud811\udfa8\ud88f\udd9e",
        15, 93657, 879548343, 400326488900132706L, 2331L, false, true, (char) 65505, (char) 62089,
        Double.longBitsToDouble(0x3fe8181db594b221L), Double.longBitsToDouble(0x3fe2e5bccdc61ed0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 11, 13, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0f\udd22\uda68\udfb7\ud861\udfaf\ud841\udefb\uc6fb\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\ud961\udc89\udac9\udfcb\ud9bd\udee7\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\ub38c\uba3e\u6304\ub11a\u81bd\u6414\u170e\u16a4\u9e77\ucd3c\u1755\u2938\u6128\ucfd7\u8b8a\u9f96\ub67c\u7947\uc958", "\ud811\udfa8\ud88f\udd9e",
        2, 93657, 879548343, 4678558194066084640L, 16756L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f161594b221L), Double.longBitsToDouble(0x3fe2e5bccdc61ed0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 12, 5, 1, "\udae5\udf88\ud83d\udffb\udb77\udf36\ud15f\ud81e\udd0d\ud9a6\ude58\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\udb2c\udf70\ud94f\udc03\ud87d\udd09\ud841\udefb\uc6fb\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\ud961\udc89\udac9\udfcb\ud9bd\udee7\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u88e7\ua04f\u2ecc\ub38c\uba3e\u6304\ub11a\u81bd\u6414\u170e\u16a4\u9e77\ucdda\u1755\ud13b\u72dd\ucfd7\u8b8a\u9f96\ub67c\u7947\uc958", "\ud811\udfa8\ud88f\udd9e\ud9ef\udef8\ud95a\udc2f\udba4\udecd\uda0d\udfb7",
        4, 78447, 1254504428, -1752808837754107978L, 10381L, false, true, (char) 35650, (char) 3207,
        Double.longBitsToDouble(0x3fef43759b2b2c42L), Double.longBitsToDouble(0x3fd574a61b4332d6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 8, 9, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\ud841\udefb\uc6fb\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\ud961\udc89\udac9\udfcb\ud9bd\udee7\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\ub38c\uba3e\u6304\ub11a\u81bd\u6414\u170e\u16a4\u9e77\ucd3c\u1755\u2938\u6128\ucfd7\u8b8a\u9f96\ub67c\u7947\u14cc", "\ud811\udfa8\ud88f\udd9e\ud9ef\udef8\ud95a\udc2f",
        58, 25716, -1303555296, -6519114189128714260L, 61021L, false, true, (char) 61941, (char) 40086,
        Double.longBitsToDouble(0x3fe7987bb910335cL), Double.longBitsToDouble(0x3fd47a1a81874f98L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 5, 12, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58", "\u8241\ua509\u1e53\uaf2e\u2bd5\u1121\u6e3b\u2f6c\u1228\uab96\ucf80", "\ud961\udc89\ud80e\udfcc\ud990\udc91\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b",
        46, 22613, -2023847305, 9047708418182183638L, -96675L, false, false, (char) 29141, (char) 39326,
        Double.longBitsToDouble(0x3fd6ea4b825f1446L), Double.longBitsToDouble(0x3fe9c9218dd989bcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u16f1\012",
        Z.run(T, 1, 2, 13, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\ud8c0\udf73\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\udabf\uddea\udaab\udfd9\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\ud841\udefb\uc6fb\ud8a2\udeae\udbf7\ude5b\uda9b\udee3\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\ud961\udc89\udac9\udfcb\ud972\uddf0\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud814\udd49\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\u8a10\u538e\u6842\ub11a\u81bd\u6414\u170e\u16a4\u9e77\ucd3c\u1755\u2938\u4eca\ud059\u8b8a\u9f96\ub67c\u7947\uc958", "\ud811\udfa8\ud908\udc5c",
        35, 93657, -965945417, -6808727534422895840L, 16756L, true, true, (char) 5873, (char) 18285,
        Double.longBitsToDouble(0x3fe81f160d94b221L), Double.longBitsToDouble(0x3fe2e5bccdc61ed0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 11, 13, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d1\udcef\uda00\udeb2\ud8c6\uddf6\ud927\udebd\udb8d\udd26\udba9\udd28\udaab\udfd9\udb34\udce7\udbd2\uddc6\ud8de\udcaa\ud87d\udd19\ud841\udefb\ud82e\ude97\uda55\udce6\udbf7\ude5b\udbe7\udee4\ud866\udf88\udab2\udd31\ud808\udf39\udb17\udc60\udb05\udd5b\u485a\uda92\udd11\udb7e\udc78\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud95c\udd6f", "\u27b0\ub0d4\u2eb4\ub38c\uba3e\u6304\u7fb0\u81bd\u6414\u170e\u4ff1\u9e77\ucd3c\u1755\u2938\u6128\ubf34\u8b8a\u9f96\u96e4\u7e64\ub732", "\ud410\ud877\udf6f",
        50, 95882, -1514807217, 1981972516394849068L, 26727L, false, true, (char) 28101, (char) 14261,
        Double.longBitsToDouble(0x3fd90b799b8c3da0L), Double.longBitsToDouble(0x3feaf25b35b6b2beL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 13, 8, 8, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda06\uddb2\ud8c0\udcf6\udbbb\udc86\udb67\udd58\ud87f\udc4a\ud9f6\udddd\uda50\udf50\udbb7\ude97\ud94e\udf8a\ud9f0\uddc3\ud841\udedb\uc6fb\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\udbb4\udfd4\udac9\udfcb\ud9bd\udee7\udb99\udcee\udb34\udc38\udb18\ude0a\ud924\uddd3\ud9a2\udcd1\ud93e\udc6f", "\u26f5\ub0d4\u2eb4\u9b66\uba3e\u6304\ub11a\u81bd\u6414\u170e\uc50c\u9e77\ucd3c\u1755\u2938\u92f0\ud7b5\u313f\u9f96", "\ud855\udec8\udb38\udc0f\udb8f\udc2a",
        17, 48521, 2055663552, -542700657033275064L, 47924L, true, false, (char) 56691, (char) 4204,
        Double.longBitsToDouble(0x3fedb73d63741a80L), Double.longBitsToDouble(0x3fe81f161594b221L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 13, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\ud8c6\uddf6\udbbb\udc86\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\ud841\udefb\uc6fb\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\udbb4\udfd4\udac9\udfcb\ud9bd\udee7\udb99\udcee\uea4b\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\ub38c\u553e\u6304\ub11a\u81bd\u6414\u170e\u4ff1\u9e77\ucd3c\u1755\u2938\u6128\ubf34\u609d\000\uc17b\u7947\uc958", "\ud811\udfa8\ud88f\udd9e",
        2, 93657, 55223, -360287970184572116L, 16756L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f161594b221L), Double.longBitsToDouble(0x3fd90b799b8c3da0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 13, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\udb2f\udf5e\uda00\ude3d\ud8c6\uddf6\udbbb\udc86\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\ud841\udefb\uc6fb\ud97e\udf3d\ud907\uded3\udaa6\uddf9\ud99e\ude4a\ud9ca\udd02\udb60\udcc9\udb2a\udedb\udbb4\udfd4\udac9\udfcb\ud9bd\udee7\udb99\udcee\udb8b\udd74\udbfe\ude75\uda65\udf4d\ud9a2\udc1b\ud927\udd04", "\u27b0\ub0d4\u2eb4\ub38c\uba3e\u6304\u7dc5\u4088\u93ea\u12ce\u50bc\u9e77\ucd3c\u1755\u2938\u6128\u7682\u8b48\u9f96\ua2bf\ud11c\uc958\ua3d1\u8f01\u688e\ua033\u40f8\uca21\u655e\ud6f9\u5f15\ud0f4", "\udb32\udd45\udb88\uddba\ud8b5\ude6c\udad8\udd4f\udb77\udf60\uda61\udf67\u125f\udbcf\udc6e\udabe\udf1e\uda49\udde3\ud804\udf43\ud912\udfc1",
        -1, 40503, -168874223, -1154031320503171786L, -36497L, false, true, (char) 16204, (char) 47414,
        Double.longBitsToDouble(0x3fe40a2783fd0b5aL), Double.longBitsToDouble(0x3fe16651775157ceL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=void |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 5, 13, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udf24\ud96b\udd28\ud855\udeb8\udbbb\udc86\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\udeea\uda0f\udd22\ud94e\udf8a\ud87d\udd09\udb00\udebb\ud84d\udf5f\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\uda9e\ude43\udbaa\udd21\udac9\udfcb\ud9bd\udee7\udb91\udf46\udb8b\udd74\udb42\ude57\ud937\udfe2\ud9a2\udc1b\ud83e\udc6f", "\u13b0\ub0d4\u6501\ub38c\ucc6e\u6304\ub11a\u81bd\u6414\u170e\u8b80\u9e97\ucd3c\u1755\u2197\uc974\ubf34\u8b8a\u9f96\ub67c\u7947\uc958", "\ud811\udfa8\ud88f\udd9e",
        2, 93657, -601827401, -298764051036679380L, -33674L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f1614faa2f0L), Double.longBitsToDouble(0x3fe30ed675e1cc9cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=void |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 13, 13, 7, "\udae5\udf88\ud83d\udffb", "\ud4ff\u6d62\ub74e\u2501\ub710\uc224\u75b0\ub1f7\u8241\ua509\u67cf\uaf3c", "\uda55\udce6\udbf7\ude5b\ud8af\udf5a\udb1e\udd0c\udbb4\ude63\ud808\udfee\udb17\udc60\udbb4\udfd4\ud98f\udd8e\ud917\udca8\ud91f\udfd7\udb8b\udd74\ud9d7\udee1\ud937\udfe2",
        33, 10716, -1013309387, -3748929852236894575L, -69722L, true, true, (char) 45022, (char) 13820,
        Double.longBitsToDouble(0x3fd4afc41b714970L), Double.longBitsToDouble(0x3fd2f8a236724862L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u56fa\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\u56fa\012",
        Z.run(T, 2, 2, 15, 7, "\udae5\udf88\ud83d\udffb\u290b\udba6\udec0\ud8a4\udd12", "\u855d\u3684\u8a4e\ubb20\u522a\u07eb\ud52e\u1e53\uaf2e\u8370\u1121\u7a15\u2f66\u1228\uab96\u9ed2\uc1c8\u0a3f\u19f3", "\ud8ea\ude96\ud8cd\udefa\ud918\udd1e\ud818\udddf\u40bf",
        38, 62708, -2023847289, 9047708417863416534L, 98385L, true, false, (char) 22266, (char) 32744,
        Double.longBitsToDouble(0x3fed89d6d5d9895eL), Double.longBitsToDouble(0x3fd45afabd7f0ea2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 13, 8, 11, "\ud945\udee5\ud83e\udc9b\u290b\ud89c\udebb\ud894\udd0b\uda47\ude5a\uda00\udeb2\uda51\uddbc\udbc5\udc7f\uda47\udca7\uda4b\uddf0", "\ud52e\u1e53\u4b3d\u476d\ub8c5\ubd26\uc0fb\u1228\u9f96\u1835\u18d3\u0a3f\u56f2\u653e\u1703\u4533\u2504\u8b37\u0d60|\u4ce1\u689b\u1374\u27b0\ud24f\ub273\uc729\ua026\ud62c\u1278\u57b5\uc471\ud4ce", "\ud808\udc90\udadd\udc4d\ud8ea\udc05\ud811\udfba\ud847\udf52\ud84c\udf9e\ud95d\uddb2\uda79\udf1d\ud873\udf7d\udb7f\udc74\uda7e\udd5f\ud849\udc79\uda2f\udffe\ud935\udc5d\uda08\udc91\udb4d\udd74\udaa9\udee5\ud8a4\udc79\uda35\udf73\udb8f\udd68\udba0\udebe\udb01\udc19\uda75\udf4e\ud9d0\udd80",
        -3, 11201, 443865791, -5398620659891309003L, 1844L, false, false, (char) 52921, (char) 36005,
        Double.longBitsToDouble(0x3f9f7dfd65043440L), Double.longBitsToDouble(0x3fe46d39f5cf52a3L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=void |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 11, 13, 7, "\000\000\u290b\udba6\udec0\ud88c\udc12", "\u855d\u3684\000\000\000\000\000k\u8000\u2bd5\u1121\ub1f0$\u118e\u96d8\ucf80\uc1c8\u0a3f\u31da", "\uda12\udc08\u5b6b\ud918\udc94\000\ud91b\udf56",
        46, 22609, -2030043027, 9047708417863416534L, 98385L, true, false, (char) 22266, (char) 32744,
        Double.longBitsToDouble(0x3fed89d6d5d9895eL), Double.longBitsToDouble(0x3fd45afab17f0e00L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u7fe8\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 2, 9, 14, "\udae5\udf88\ud83d\udffb\u290b", "\ua836\ub74e\u855d\u3ed0\uc367\u900d\u1552\u07eb\ud52e\u1e53\u9454\ub677\u1121\u7a15\u5ece\u88c6\u3fa0\uabec\uc1c8", "\udac9\udfcb\ud910\udf5f\ud8ea\ude96\ud90a\udf4c\ud918\udc94\ud818\udddf",
        31, 10716, -1013309391, -3111553664673649953L, -56641L, true, false, (char) 32744, (char) 2699,
        Double.longBitsToDouble(0x3fdd9895e28b5f56L), Double.longBitsToDouble(0x3fe5fc3a8b3cb3e4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 8, "\udae5\udecf\ud83d\udffb\u290b\udba6\udec0\ud88c\udc12", "\u855d\u3684\uc367\u900d\u522a\u07eb\ud52e\u1e53\u2f2e\u8008\u1121\u7a15\u2f66\u1228\u363c\000\uc0ed\u0a3f\u19f3", "\ud8ea\ude96\ud90a\udf4c\ud918\udc94\000\ud91b\udf6f",
        46, 22609, -2023847315, 9047708417863416534L, -34464L, true, false, (char) 22266, (char) 32744,
        Double.longBitsToDouble(0x3fed89d6d5d9895eL), Double.longBitsToDouble(0x3fd45afabd7f0ea2L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u102c\012",
        Z.run(T, 2, 12, 2, 7, "\udae5\udf88\ud83d\udffb\ud815\udd67\udbb4\udedc\ud88c\udc12", "\u855d\u3684\u8d5b\ubbda\u947f\u07eb\uae7d\u6c74\uaf2e", "\u76bb\ud931\ude92\udbdb\ude01\ud864\udf46",
        30, 39165, -58190644, 2213517196027292689L, 8406L, true, true, (char) 4140, (char) 34107,
        Double.longBitsToDouble(0x3f9954ea09471400L), Double.longBitsToDouble(0x3fa8e702a6dc39a0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 13, 1, 7, "\udb0a\udf08\ud847\udea2\u290b\udba6\udec0\ud88c\udc12", "\u0ae6\u4c52", "\uda29\udd38\udbca\udda5\ud919\ude1e\ud94e\udf8a\ud87d\udd09\ud851\udffb\uc6fb\ud8a9\udd19\udbf7\udef1\udbdb\udde4\ud864\udf46\udabb\ude38\ud872\udd34\udb17\udc2a\ud8e9\udc8d\udac9\udfcb\ud910\udf5f\ud8ea\ude96\ud90a\udf4c\udb69\udcdd\ud92d\udc79",
        31, 38291, -981673598, 5697153882641132255L, -8397L, true, false, (char) 49019, (char) 29401,
        Double.longBitsToDouble(0x3fd841664e5475b4L), Double.longBitsToDouble(0x3fc8ae4bd13cdff0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u56fa\012",
        Z.run(T, 2, 5, 2, 7, "\udaf0\udd88\ud83d\udffb\u290b\udba6\udec0\ud88c\udc12", "\u0238\u36a8\uc367\u900d\u522a\u07eb\ud52e\u1e53\uaf2e\u71b3\u1836\u7acb\u2f66\u1228\uab96\u0819\u8d27\ucb1f\u19f3", "\ud8ea\ude96\ud90a\udf4c\udb65\udebc\uda7c\udd42\ud93e\udf71",
        9, 36411, -2090956179, -6012328890682344954L, 98385L, true, false, (char) 22266, (char) 32744,
        Double.longBitsToDouble(0x3fed89d6d5a8895eL), Double.longBitsToDouble(0x3fd45af09d7f0ea2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\ue4fe\0121=[C:[[\ue4fe, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\ue4fe\012",
        Z.run(T, 2, 2, 0, 9, "\udae5\udf88\ud83d\udffb\u292d\udba6\udec0\ud851\udcc8\ud9ae\udc5c\udbac\udf34\udbf6\udd10\udbc5\udc7f\uda37\udf5c\uda4b\uddf0\ud895\udc40\uda44\udec2\ud919\ude1e\udb3d\udde7\uc7c5\ud8ec\ude97\udbfc\udc66\udadc\udf82\udbfb\udf35\udbdb\udde4\ud864\udf46\udab6\ude16\uda39\udf07\udb16\udfff", "\u1703\u4533\u2504\u7fec\u5496\u7f36\u4ce1\u689b\u1374\u27b0\ud24f\u825b\u632d\ub9f3", "\udb5f\udf54\ud93a\udcb2\ud8bc\udd42\ud9e1\udc28\ud91e\ude28\ud8da\udd99\ud96f\udf00\ud84f\udf62\udb5a\ude25\uda42\udc40\udb9f\udc73\ud84c\udd06\ud8d6\udc09\udb57\udcdd\udb24\udf1e",
        51, 89512, 1151597834, 7349650646764179329L, -10776L, false, false, (char) 58622, (char) 34399,
        Double.longBitsToDouble(0x3fd14b45a3be25b6L), Double.longBitsToDouble(0x3fb50576b5267120L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 3, 7, "\udae5\udfb5", "\u7b49\u054c\u2633\ub74e\u2501\u3684\u9870\ud6e0", "\uda0f\udd22\uda3a\udf88\ud87d\udd09\ud841\udefb\udb99\udf0d\ud95c\udf31\udbc9\udd63\ud89f\udead\ud804\udd36\ud9f7\udcfb\ud9ac\ude13\udb16\udfe0\ud961\udc89\udac9\udfcb\ud8b0\udf80",
        3, 95162, -484312939, -4822879258116010219L, -94591L, false, false, (char) 8905, (char) 39094,
        Double.longBitsToDouble(0x3fd3805f41bbddfeL), Double.longBitsToDouble(0x3fbec5f9af2065a8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 12, 5, 15, "\ud86c\udfcc\ud8cf\ude16\udb77\udf36\ud15f\ud81e\udd0d\ud9a6\ude58\uda00\udeb2\ud8c6\uddf6\udbc5\udc7f\udb67\udd58\udb49\ude2d\ud8f8\udcdc\udb57\ude41\udb2c\udf70\ud94f\udc03\ud87d\udd1a\ud841\udefb\ud9a8\udc15\uda55\udd35\udbf7\ude5b\udbdb\udde4\ud864\udf46", "\u0aa0\u0e2b\ud56c\u06d5\uca6e\ub906\u3e5e\u15fd\u13b3\u4ce1\u689f\u137e\u88e7\ua04f\u2ecc\ub38c\uba3e\u6304\ub11a\u81bd\u6414\u5f5a\u16a4\u9e77\u07ee\u16da\ud13b\u72dd\u95d6\u8b8a\u9f96\ub67c\u7947\uc958\uab9b\u779f\u683a", "\ud95a\udc2f\udba4\udecd\uda0d\udfb7\udb2b\ude8b\ud833\udeda\ud821\udc54\u4c37\udb32\udd45\ud976\udda6\ud8be\ude96\ud95f\udcd2\ud88a\udd6a\ud82f\udc62\udae9\ude83\ud86f\udf8d\ud98f\udf4b\udb52\udd98\ud95f\ude66\udaa3\udc2b\uda30\udff4\ud9d7\udf12\udaf1\ude95\udbb4\ude29\ud8b7\udda1\ud90a\udfc2\udacb\udc29\udbab\udc95\udab7\udf3c\uda44\udc14\ud880\udfad\ud91a\ude9e\udbc9\ude67\udb39\udc96\ud90b\uded7\ud8a1\udf65\u8c57\ud862\udc0a\ud9d3\udc28\udb35\udfa5\ud90a\udee6\ud8fa\ude97",
        32, 73180, 797928181, -5463736282603917892L, 61447L, false, true, (char) 3893, (char) 44843,
        Double.longBitsToDouble(0x3fe01303a62b5912L), Double.longBitsToDouble(0x3fd95ccd1827b5f0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 4, 7, "\udbe2\ude59\ud9d1\ude7e\ud9a7\udcdf\ud845\udc0e\ud8a9\udfaa\ud8d1\udf32\ud875\udd07\ud93d\ude6e\ud900\udd1f\ud93a\udd40\ud87b\ude29\ud9e7\udcdf\uff73\udbd1\udda4\ud979\udf5a\ud9d1\udd4e\ud96b\udf50\uda90\udc5c\ud883\udef0\udbf7\udf20\udbdb\uddee", "\u55a9\u193c\u75f6\u71a8\u679b\uca84\u51ca\u130f\ucdfc\u477b\ud3d0\u689f\u7ec0\uac55\u5601", "\ud83f\udf73\udb2a\udeb4\u9b90\udb65\ude91\uda0c\udc70\ud95f\udc60\ud8b7\udca3\udad1\udc0f\ud92c\udf68\uda60\udc57\udbb1\udea4\udb7b\udc9e\udb67\ude99",
        13, 77005, 34248535, -7983490544145669821L, -72349L, true, true, (char) 28089, (char) 27696,
        Double.longBitsToDouble(0x3fdcc9099e19f010L), Double.longBitsToDouble(0x3fe1f40861a869e2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000]] |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 6, 6, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udf24\ud96b\udd28\ud855\udeb8", "\u900d\u9fe3\u828c\ua509\u1e53\uaf2e\uce68\u29d3\u6e3b\u2f6c\u1228\uab96\ucf80\ud665\ua901\u9ad9\u653e\u387a\uacc6\ub906", "\ud9a2\udc1b\ud83e\udc6f\udb29\udca5\ud9d4\udd0f\ud905\ude45\udbfb\udcc4\udaca\udeb4\ud979\udf00",
        5, 31277, -1531404982, -4200533067771581784L, -97734L, true, true, (char) 40352, (char) 14074,
        Double.longBitsToDouble(0x3fd75d8ff2419afaL), Double.longBitsToDouble(0x3fe7bfcc389d9e54L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 9, 4, "\udae5\udf88\udba9\udc71\udbf4\udf48\ud821\udc76\udb0f\udfd9\ud9d2\udf24\udaad\ude16\ud81b\udc38\udbbb\udc86\ud9f2\udf3d\uda4b\ude12\udaab\udfd9\udaad\udc94\uda0f\udd22\ud94e\udf8a\ud87d\udd09\udb1e\udcbb\ud84d\udf5f\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\uda9e\ude43\udbaa\udd21\udac9\udfcb\ud8e6\udf3b\ud9f2\ude35\udb8b\udd7b\udb42\ude57\ud937\udfe2\ud9a2\udc1b\ud854\udfda", "\u13b0\ub0d4\u6501\ub38c\ucc6e\u6304\ub11a\u81bd\u6414\u170e\ua63c\u9347\ucd2c\u1755\ud64d\uc974\ubf34\u8b8a\u9f96\ub673\u7947\u9fdc", "\ud811\udfa8\udbf6\ude94",
        55, 45659, -1891437322, -2998385664995798228L, -33674L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f1614faa2f0L), Double.longBitsToDouble(0x3fe30ed675e1cc9cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[C:[[\000, \000]] |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 10, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udf24\ud96b\udd28\udbd8\udca4\udbbb\udc86\udb67\udd58\uda4b\uddf0\ud8fa\udddc\udb57\udeea\uda0f\udd22\ud94e\udf8a\ud87d\udd09\udb00\udebb\ud927\udd5b\uda26\udfe6\uda40\udfb9\ud876\uddf2\ud953\udda7\udab6\ude16\ud808\udfee\udad0\ude3c\udbaa\udd21\udac9\udfcb\ud9bd\udee7\udb91\udf46\udb92\uddb6\udaff\udec1\ud937\udf8a\ud9a2\udc1b\ud83e\udc6f", "\u511d\ub0d4\u6501\ub38c\ucc6e\ua692\ub11a\u81bd\u6414\u170e\u8b80\u9e97\ucd3c\u1755\u2197\uc974\ubf34\u8b8a\u9f96\ub67c\u7947\uc958", "\ud817\ude25\ud88f\udd9e",
        2, 93657, -601827401, -298764051036679380L, -33674L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f1614faa2f0L), Double.longBitsToDouble(0x3fe30ed675e1cc9cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 15, "\udae5\udf88\ud834\ude6b\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udf24\ud95f\udf69\udbcd\udcfc\udba1\ude37\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\udeea", "\uaf2e\uce68\u29d3", "\udbdb\udde4\ud864\udf46\ud8b6\udd16\ud808\udfee\uda9e\ude43\udbaa\udd21\uf585\udb82\udf88\udb91\udf46\udb8b\udd74\ud987\ude89\ub3f4\ud9a2\udc28\ud83e\udc6f\udb29\udca5\ud9d4\udd0f\ud905\ude45",
        53, 52447, 1253307139, 5658904162524587892L, -80910L, true, true, (char) 39302, (char) 43518,
        Double.longBitsToDouble(0x3fd656f312fb0846L), Double.longBitsToDouble(0x3fd8fe16abf9b1feL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 13, 12, 5, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\udba7\udd0c\ud96b\udca0\ud855\udeb8\ud996\udf55\udb67\udc9b\uda4b\uddf0\udaab\udfd9\udb57\udeea\uda0f\udd22\ud94e\udf8a\ud87d\udd09\udb00\udebb\ud84d\udf5f\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf76\udb41\udcb0\udbde\udf15\uda9e\ude5e\udbaa\udd21\udac9\udfcb\ud9bd\udee7\udb91\udf46\ud934\udd20\udb42\ude57\ud937\udfe2\ud8bb\udfbf\udaa5\udd33", "\u13b0\ub0d4\u6501\ub38c\ucc6e\u6304\ub11a\u81bd\u6414\u170e\u8b80\u9e97\ucd3c\u1755\u2197\ud224\u6475\u8b8a\u9f96\ub67c\u7947\uc958", "\ufc58\ud88f\udd9e",
        2, 93657, -601827401, -298764050425752788L, -33674L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f1614faa2f0L), Double.longBitsToDouble(0x3fe30ed675e1cc9cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 11, 11, 7, "\udae5\udf88\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udf24\ud96b\udd28\ud855\udeb8\udbbb\udc86\udb67\udd58\uda4b\uddf0\udaab\udfd9\udb57\udeea\uda0f\udd22\ud94e\udf8a\ud87d\udd09\udb00\udebb\ud84d\udf5f\uda55\udce6\udbf7\ude5b\udbdb\udde4\udbdf\udee5\udaa1\udf20\udbd1\udc82\udacd\udd20\udbaa\udd21\udac9\udfcb\ud9bd\udee7\udb91\udf46\udb8b\udd74\udb42\ude57\ud937\udfe2\ud9a2\udc1b\ud83e\udc6f", "\u13b0\ub0d4\u6501\ub38c\ucc6e\u92b2\uc22e\u81bd\u6414\u170e\u8b80\u9e97\ucd3c\u67f1\ubd5b\uca3b\ubf34\u8b8a\u9f96\ub67c\u7947\uc958", "\ud811\udfa8\ud88f\udd9e",
        17, 43508, -853747785, -298806940580097236L, -33674L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f1614faa2f0L), Double.longBitsToDouble(0x3fb876b3af997208L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u73a6\0121=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u73a6\u73a6\012",
        Z.run(T, 2, 2, 2, 5, "\udae5\udfcb\ud83d\udffb\u290b\udba6\udec0\ud8a4\udd12\uda47\ude5a\uda00\udeb2\uda51\uddbc\udbc5\udc7f\uda01\ude69\ud8e8\udd30\ud895\udc40\udbad\uddb6\ud835\udc1b\ud94f\udc0d\ud87d\udd09\udb92\uddf1\uc6fb\u7780\udbf7\ude55\udbdb\udde4\ud864\udf46\u920e\ud8e9\udee7\udb16\udfff\ud961\udc89\udac9\udfcb\ud910\udf5f\ud8ea\ude96\ud8cd\udefa", "\ubb5c\u9ad8\u3cd8\ubfb8\u7f9f\ud24f\u825b\u0600\u605d\u9182\u1309\u988d\uaf44\034\ub82f\ub837\u8cf1\u8ed8\u09c6\u836f\u712f\uc98c\u18bc\u057e\u3a86\u7d4f\u7d0c", "\ud994\udef4\ud867\uddd3\ud23a\ud915\udd96\udb9e\udef4",
        30, 53976, 1526779020, 1928445702369049020L, -74485L, false, false, (char) 29606, (char) 5888,
        Double.longBitsToDouble(0x3feb64ab2b3ace2eL), Double.longBitsToDouble(0x3fe62251c358fa37L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 8, 8, 7, "\ud887\ude79\udb45\udf92\ud929\udc37\uda89\udee4\ud92a\udc67", "\u855d\u3684\u8a4e\ubb20\u522a\uc881\uccd1\u1e53\u0271\u4325\uca08\u8d9b\u209b\ud6f1\u3a50\uaa5c\u2308\u0a3f\u19f3\u653e\u1703\u4533", "\ud81e\udce8\ud81c\ude44\udba0\udd39\ud95c\udcca",
        51, 25775, -2045805866, 1352946209626213818L, -80409L, true, false, (char) 13674, (char) 24552,
        Double.longBitsToDouble(0x3fc55e9a97a98584L), Double.longBitsToDouble(0x3fd45afabd7f0ea2L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 12, 12, 2, "\udae5\udf88\udbfc\udfa4\ud815\udd67\udbb4\udedc\udadd\udd07\udbad\ude2e", "\u3684\u8d5b\ucc9b\u947f\u1a49\u0883\u6c74\uaf2e\uba98", "\ud931\udf35\uda7d\udf51\ud864\udf46\u6c46",
        14, 16017, 335560807, 9037858376182051784L, 973L, false, false, (char) 8997, (char) 48236,
        Double.longBitsToDouble(0x3fd89e9ed85d942aL), Double.longBitsToDouble(0x3fe770229910cd91L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u2f63\012",
        Z.run(T, 1, 2, 9, 14, "\ud91f\udf21\ud83d\udffb\udb88\udc49\ud821\udc76\udb0f\udfd9\ud9d2\udeef\uda00\udeb2\udbf1\udd03\ud805\ude9f\ud82c\udc45\uda4b\uddf0\udaac\udc03\udb57\ude9f\uda0f\udd22\ud94e\udf8a\ud87d\udd09\ud841\udefb\uc6fb\uda55\udce6\udbf7\ude5b\udbdb\udde4\ud864\udf46\udab6\ude16\ud808\udfee\udb17\udc60\ud961\udc89\udac9\udfcb\ud9bd\udee7\udb99\udcee\udb8b\udd74\ud9d7\udee1\ud937\udfe2\ud9a2\udc1b\ud93e\udc6f", "\u27b0\ub0d4\u2eb4\u71ab\uba3e\u6304\ub11a\u81bd\u6414\u170e\u16a4\u9e77\u438f\u1755\u2938\u6128\ucfd7\u8b8a\u9f96\ub67c\u7947\uc958", "\ud811\udfa8\ud88f\udd9e",
        2, 93657, 879548343, 4678558194066084640L, 16756L, false, true, (char) 12131, (char) 1524,
        Double.longBitsToDouble(0x3fe81f161594b221L), Double.longBitsToDouble(0x3fe2e5bccdc61ed0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.util.TextBuffer|expandCurrentSegment||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|expandCurrentSegment|int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|append|char|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|append|[C,int,int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|append|java.lang.String,int,int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|buf|int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|carr|int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|clearSegments||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsArray||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsDecimal||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsDouble||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsString||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|emptyAndGetCurrentSegment||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|ensureNotShared||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|expand|int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|finishCurrentSegment||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|expandCurrentSegment||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|expandCurrentSegment|int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
