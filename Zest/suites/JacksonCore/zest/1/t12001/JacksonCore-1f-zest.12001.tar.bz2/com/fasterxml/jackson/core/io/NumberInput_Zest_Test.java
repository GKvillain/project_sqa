package com.fasterxml.jackson.core.io;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberInput_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u8af4\ubc2e\ub6cd\uc124\ua866\ub0b3", "\udbf2\udc57\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\u0180\udaac\ude04\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207b3e859bL), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 1, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u8af4\ubc2e\ub6cd\uc124\ua866\ub0b3", "\udbf2\udc57\u00b5\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\u0180\udaac\ude04\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udd12\ud991\udd6d\ud9f7\udcc8\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207b3e859bL), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 14, 5, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u1d6b\u2dca\uc80e\u44fc\u8af4\ubc2e\ub6cd\uc124\ua866\ub0b3\uba8e\u6895\u23ba\u0696\u0086\u021d\u9446\u18f3", "\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd",
        53, 47888, -1042900058, 2566684967786385550L, 11878L, true, false, (char) 44364, (char) 52024,
        Double.longBitsToDouble(0x3fd7291faaef3e86L), Double.longBitsToDouble(0x3fe4cbc038908513L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 17, "\ud90c\udf57\udbb6\udf43\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u0bf9\u073d\ua485\u94da\ua866\ub0b3", "\udbf2\udc57\udb36\udf73\ud9f7\ude9c\uda5d\udc0a\u3f2c\ud842\ude7f\uda2b\ude4e\ud9a1\udd87\ud8b9\uddf9\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda78\ude0e\ud893\udffc\ud951\udc72\uda17\udcde\u0119\ud8a0\ude9e\udb62\udc44\ud877\udd38\ud86f\udfec\uda2d\udfbe\udb41\udc89\ud99d\udf09\udb39\ude9a\ud92a\udcd4\uda2e\udf64\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 50847, (char) 49647,
        Double.longBitsToDouble(0x3fe6057c3c5c45b1L), Double.longBitsToDouble(0x3fdeefed7ab49be2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 14, 5, 1, "\udb4b\udcdb\udbb6\udef4\udb81\uddd2\ud808\udd34\udb64\udce5\uda1e\udd1a\ud953\uded0\ud81a\udc0a\ud829\udd4d\ud807\udd03\ud961\uddfb\uda3a\uddd8\udac2\udf52\uda73\udf02\uda47\udd75\udb0f\udd0e\ud8d7\udd10\udbf2\udc57\udb36\udf73\udac0\ude82\ud9d1\udc60\u84cb\ud842\ude54\uda2b\ude4e\ud877\udc94\ud8df\udfb0", "\uc348", "\ud961\udc7a\udbfa\ude28\u0180\udaac\ude04\udabe\udcc8\ud851\udd2a\ud870\udc12\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udc3d\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41\udbec\udc09\udb23\udd99\ud87e\udf02\ud877\udeeb\udb2d\udcc5\udb73\udea5\udacc\udd88\uda94\udc14\ud9b7\udd4d\ud804\udc36\udaba\uddda\ud840\udc93",
        1, 63634, 903056845, -810491632534733937L, -10616L, false, false, (char) 56542, (char) 34606,
        Double.longBitsToDouble(0x3fd29f035c4e1178L), Double.longBitsToDouble(0x3fd5fb97e6d18cccL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 5, 17, "\ud88e\udf3e\ud802\udfa4\udb81\uddeb\ud808\udd34\udb64\udce5\uda1e\udd1a\udaf3\udd80\ud80c\ude66\uda4a\udfb4\udbf7\udc6f\udbdc\ude2a\ud98f\udd61\ud820\udc71\uda83\udc20", "\ua8f5\u43ff\u1a2e\u74ce\u0124\u2d1c\uc60e\u1c18\u509e\uc2c6\u1edb\ub2bd\u49ae\ud6dd\ua0bf\u7c4d\u98d7\ua269\u397a\u26e8\u9808\u2c02\u12e2\ucef2\u98e8\u1790\u8705\u7ae3\u7744\u1cb2\ub6cb\u3505\ubdc6\ub9dd\ud2e2\u7b7a\u4436\u9e11\u3a52\u6816", "\udb8a\ude85\ud9b0\uddc4\udaac\udfb7\ud922\uddcc\uda22\udc42",
        17, 65897, 1061955115, 7856339266490533626L, -7659L, false, true, (char) 16265, (char) 40848,
        Double.longBitsToDouble(0x3feb35a7950700c5L), Double.longBitsToDouble(0x3fe33bbcbba4a569L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 17, "\udb40\udfb1\udae7\udd8c\udb7b\udf02", "\u0d0c\u2dca\uc80e\u44fc\u8af4\ubc2e\u6a10\u9453\u21b9\u9978", "\udbf2\udc57\ud806\udf57\ud967\uded9\ud9c7\udf61\u3f2c\ud842\ude7f\uda2b\ude4e\ud83e\ude96\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udca6\u1db6\ud893\udffc\uda3e\udeec\uada0\u0180\udaac\ude04\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\ud82f\udc47\uda8d\udc70\udafa\udd04\uda32\udc16\ud90f\udd47\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 2503, (char) 30556,
        Double.longBitsToDouble(0x3fe5a1207b3eab61L), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u0d0c\u2dca\uc80e\u4c18\ua546\ubc2e\ub6cd\uc124\u427a\ub0b3", "\ud979\udd21\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda55\udfdc\uda22\udcc7\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\udb16\uddea\udaac\udeac\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048732517877275L, 86763L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207b3e859bL), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 14, 5, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u8af4\u50ea\u4fcd\uc501\ua866\u8f83", "\udbf2\udc57\udaff\ude7d\ue107\ud9ca\udc00\udbb0\udc63\udb27\uddab\uda2b\ude4e\ud877\udc94\ud81d\udf0e\ud8d4\ude5a\udaba\udcdc\u98ab",
        46, 24967, 597602913, 1963024690489494745L, -30159L, false, false, (char) 33593, (char) 64364,
        Double.longBitsToDouble(0x3fec1d0341a84b72L), Double.longBitsToDouble(0x3fca6c5109c86f30L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 1, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u8af4\ubc2e\ub6cd\uc124\ua866\ub0b3", "\udbf2\udc57\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\u0180\udaac\ude04\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207b3e859bL), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 10, 5, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u8af4\ubc2e\u881b\u2a03\u7fcf\uad40", "\udbf2\udc57\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\ud87a\ude00\ud846\udc9c\uda2b\ude4e\ud851\udf92\ud8df\udfb0\ud8ba\udec7\ud9ad\udf8f\uda21\udea6\uda78\ude0e\ud99e\udd00\ud8d7\udca0\udb25\udcfe\ud88f\udc31",
        44, 50995, 751940330, -7927850026141526670L, 71762L, false, false, (char) 886, (char) 8445,
        Double.longBitsToDouble(0x3fd6c5bdbd52bd98L), Double.longBitsToDouble(0x3fde51672bf5522cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 7, "\udb40\udfb1\udbb6\udef4\uf81a", "\u0d0c\u2dca\uc80e\u44fc\u8af4\ubc2e\ub6cd\uc124\ua813\ub0b3", "\udbf2\udc57\udb36\udf73\udb37\udd5b\ud9c9\udfca\u3f2c\ud842\ude7f\uda2b\ude4e\uf295\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\u0180\udaac\ude04\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207a97cb9bL), Double.longBitsToDouble(0x3fe791407d5a4d5cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 0, 13, "\udb40\udfb1\udbb6\udef4\u241f", "\u0caa\u2dca\u90cf\u457a\u8af4\ubc2e\ub6cd\uc124\ua866\u30a3", "\udbf2\udc57\ud8a6\udc15\ud9b1\udeea\udaaf\udf18\udbb2\udc80\ud875\udc95\uda2b\ude4e\ud877\udc94\u6faf\ud8ba\udec7\uda8a\uddbd\ud9a9\udcc7\ud9e0\udc1a\ud8a6\udd2e\ud961\udc7a\uda57\udcf7\ud815\ude7b\ud9f1\udcdd\ud8f8\uddb8\ud877\udd8e\ud807\udf4f\ua01c\udb41\udc89\ud9f6\udf5a\uda29\udd12\udb4c\udfea\ud84f\udf35\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1456225644, -5840764621864652315L, 57136L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207b3e859bL), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"\000\udb88\udd44\udb81\uddd2\" can not be represented as BigDecimal\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"\000\udb88\udd44\udb81\uddd2\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 0, 0, 16, "\000\udb88\udd44\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u8a05\ubc2e\u06fb\u1d3d\ua866\ub0b3", "\udbf2\udc57\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\u143c\ud8ac\udfb6\000\uda8b\udde4\uda22\udca6\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\udbcf\udd7f\udaac\ude04[\ud877\udd8e\ud86f\udfec\uda2d\udfbe\ud99b\udd77\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uda22\udec8\u9ef2\ud94b\ude41",
        30, 23768, 1590443264, -835048734515088923L, 31072L, false, false, (char) 0, (char) 28587,
        Double.longBitsToDouble(0x3fc68481ecf80000L), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u2cbc\ubc2e\ub6cd\uc124\ua866\ub0b3", "\udbf2\udc57\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\udad5\ude75\udb71\udfd7\ud893\udffc\ud961\udc7a\udbfa\ude28\uaa35\udaac\udef5\ud8f8\uddb8\ud9f0\udd15\ud870\udc26\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        55, 34424, 1590443372, -7824635356194098715L, 57136L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207b3e859bL), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:-835048734515088923\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 17, "\udb48\udeb1\udbb6\udef4\udb81\uddd2", "\u0d0c\u2d42\uc80e\u44fc\u8af4\ubc2e\ub6cd\uc124\ua866\ub0b3", "\udbf2\udc57\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u1dce\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\u0180\udaac\ude04\udb9b\uddf0\uda67\udeac\udb67\udda8\ud815\udca1\udb41\udc89\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207dc4cb9bL), Double.longBitsToDouble(0x3fdeef01eab49be2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 15, 6, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\ud327\uadc3\u8d32\ua453\u8af4\ubc2e\ub6cd\uc124\ua866\ub0b3", "\udbf2\udc57\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda0c\udfef\udac0\udc72\ud961\udc7a\udbfa\ude28\ud9e1\ude70\udab5\udf66\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\uda2d\udfbe\ud985\udc8b\ud9f6\udf5a\uda29\udd12\ud915\udd6f\udb1a\udfa5\uda7a\udf43\ud94b\ude41",
        30, 34424, 1590444652, -835048734515088923L, -8400L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207b3e859bL), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 18, 11, "\uda41\udd10\ud890\udcaf\udb81\uddd2\ud808\udd34", "\u2dd3\u0348\ua126\u66ab\u9822\ub6cd\uc124\u83e7\ua7d2", "\ud951\udc5a\udaef\udecf\ud9f7\ude9c\udb1b\udda8\ud8d4\udfee\ud849\udc12\uda2b\ude4e\ud918\udc88\udbcd\uddb1\ud910\ude91\ud84f\udce5\udb2b\udf25\uda78\ude0e\ud893\udffc\ud937\udd7a\udb87\udd0e\u0180\ud81d\uddf7\uda0c\udce3\ud9f5\ude4e\udbaf\ude24\uda26\udc67\udb41\udc89\udb67\uddf1\ud99d\udcfe\ud891\ude97\uda15\udcd6\ua940\ud944\udc6c",
        7, 16421, 1590484209, -835048734515088923L, 59910L, false, true, (char) 48267, (char) 64330,
        Double.longBitsToDouble(0x3feb49ecdb559e4bL), Double.longBitsToDouble(0x3fde8e8987ce57d4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 5, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u1d6b\u2dca\uc80e\u44fc\u333a\ubc2e\u8434\uc124\ua866\u8dbd\u61a5\u6895\u23ba\u0696\u0086\u021d\u9446\u18f3", "\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd",
        53, 81536, -1044313648, 2566684967786385550L, 11878L, true, false, (char) 44364, (char) 52024,
        Double.longBitsToDouble(0x3fd7291faaef3e86L), Double.longBitsToDouble(0x3fe4cbc038908513L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\0121=java.lang.Boolean:false |a0=[C:[[\udbcf, \udd37, \udbb6, \udef4, \udb81, \uddd2]]\012",
        Z.run(T, 2, 15, 5, 17, "\udbcf\udd37\udbb6\udef4\udb81\uddd2", "\u1d6b\u2dca\u2be9\u44fc\u8af4\ubc2e\ub6cd\u9208\ua866\u1a46\ubaea\ub042\u8664\u0696\u0086\u021d\u9446\u912b", "\ud8df\udfb0\ud95f\udf7a\uda23\udf71",
        53, 47888, 1779342246, -9156660782832829029L, 49251L, true, false, (char) 44364, (char) 52024,
        Double.longBitsToDouble(0x3fecaa9a75779f43L), Double.longBitsToDouble(0x3fe4cbc038908513L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 1, 1, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u1d6b\u2dca\uc80e\u44fc\u8af4\ubc2e\ub6cd\uc124\ua866\ub0b3\uba8e\u6895\u8f69\u286d\uc127\u021d\u9446\u1e49", "\ud842\udd91\ud8d6\uded5\uda8a\uddbd\udbc7\udfb8\udac2\udd80\ud893\udf8c\ud961\udc7a\udb8a\udc3f\u0156\ud9af\uddc6\udbde\udc1a\ud866\udc4f\ud86f\udfec\udb85\udf22\udb17\uddc9\udb44\udf8d\u9436\udb35\udee3\uac77\udb45\udf9c\ud96d\udeb1",
        43, 90644, 409812083, 3418848399174241622L, 43773L, false, false, (char) 60806, (char) 9120,
        Double.longBitsToDouble(0x3fdf2e9e32a3bf96L), Double.longBitsToDouble(0x3fc5e679cfb2eae0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 11, 8, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u1d6b\u2dca\uc80e\u44fc\u8af4\ua447\ub6cd\uc124\u8a24\ub0b3\uba8e\ub507\u23ba\u0696\u0086\u85b2\u68ac\u18f3", "\ud92d\udc77\ud8ba\udf07\uda8a\uddbd",
        53, 47888, -1042900058, 2566684967786385550L, 8024L, true, false, (char) 28892, (char) 35780,
        Double.longBitsToDouble(0x3feee65462058b39L), Double.longBitsToDouble(0x3fe4cbc038908513L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:15\0121=java.lang.Boolean:false |a0=[C:[[\udb40, \udfb1, \udbb6, \udef4, \udb81, \uddd2]]\012",
        Z.run(T, 2, 8, 5, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u1c80\u2dca\uc80e\u44fc\u8af4\ubc2e\ub6cd\uc124\u4427", "\ud978\udfa2\ub64d\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\udbc7\udfb8\u0d15\uda1a\udd95\ud961\udc7a\udbfa\ude28\u0180\ud9af\uddc6\udbde\udc1a\ud866\udc4f\ud86f\udfec\uda2d\udfbe\udb83\udc8b\ud8eb\udc08\udb1d\uddf1\ud86d\uddf1\ud8b3\ude41\ud81b\udc56\ud9ed\uddef\uda7f\uded4\udafc\udd97\udaba\udf9b\udaa5\ude1b\udbc2\udf7d\ud8ca\udd55\udaa2\udcbd\uda04\udf73\udbd1\udcc5\uda71\udc07",
        15, 28207, -749364678, -5444606650063452773L, -20246L, true, false, (char) 35835, (char) 3744,
        Double.longBitsToDouble(0x3fd743eac271bf6cL), Double.longBitsToDouble(0x3fe55e3236b609faL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 19, 16, 17, "\uda9b\udefe\ud994\udddf\udac0\udd02", "\u1d7c\u2dca\uc80e\u44fc\u8af4\u1ef6", "\uda73\udf02\udb2d\udcbb\udb0f\udc40",
        -2, 71241, -72490059, -6531455362860842500L, 31839L, false, true, (char) 55589, (char) 53713,
        Double.longBitsToDouble(0x3fe0a5b97bb4c801L), Double.longBitsToDouble(0x3fdc864546c1e3a0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 4, 5, 17, "\udb40\udfb1\udba2\udeaa\udb81\ude12", "\u0217\u2d1a\u71d5\u455b\u8af4\ubc2e\u93ec\u5b31\u0c8b", "\ud8c0\udf10\ud974\udf4f\udb36\udf73\ud9e1\udedc\ud801\udc7b\ud862\udf0e\ud842\ude21\uda2b\ude4e\ud877\udc94\udb76\udcce\ud8ba\udec7\uda8a\uddbd\udbc7\udfb8\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\u0180\ud9af\uddc6\ud845\udc6f",
        -1, 28702, -1622977166, 4785186165555160015L, -87719L, false, false, (char) 10888, (char) 26370,
        Double.longBitsToDouble(0x3fcbd87cc1f89bd0L), Double.longBitsToDouble(0x3fe3d57b88da1ed7L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false |a0=[C:[[\udb40, \udfb1, \udbb6, \udef4, \udb81, \uddd2]]\012",
        Z.run(T, 2, 6, 5, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u1d6b\u2dca\uc80e\u44fc\u8af4\ubc2e\uaa10\u3697\ua866\ub0b3\uba8e\u6895\u23ba\u0696\u0086\u021d\u9446\u18f3", "\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd",
        53, 47888, -1042900058, 2566684967786385550L, 11878L, true, false, (char) 44364, (char) 52024,
        Double.longBitsToDouble(0x3fd7291faaef3e86L), Double.longBitsToDouble(0x3fe4cbc038908513L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\012",
        Z.run(T, 1, 15, 7, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u1d6b\u2dca\uc80e\u44fc\u8af4\u98e6\u4cc0\uc124\ua866\u948b\uba93\u0e6e\u23ba\u0696\u0086\u021d\u9446\u18f3", "\ud8df\udfb0\ud8ba\udec7\uda5d\uddbd",
        53, 47888, -1042900058, 2566684967786385550L, 11878L, true, false, (char) 44364, (char) 1192,
        Double.longBitsToDouble(0x3fd6eea02aef3e9eL), Double.longBitsToDouble(0x3fe4cbc038908513L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Long:4707572857735425469\012",
        Z.run(T, 2, 6, 9, 11, "\ud801\udc93\udbb6\udef4\udb81\uddd2", "\u1d6b\u2dca\u060e\u788a\u11e5\u78cd\u7836\uc124\ua866\ub0b3\uba8e\u6895\u23ba\u0634\u0086\u021d\u9446\u18f3", "\ud8df\uded7\ud85a\udf8e\uda8a\uddbd\ud931\udfad\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\u0180\udaf4\ude53\udbf4\ude43\udb86\ude00\ud870\udc55\uda2d\udfbe\udb41\udc89\udafc\udf5d\ud9fa\udd81\udb24\ude4a",
        5, 96605, -39646088, 4707572857735425469L, -64795L, false, false, (char) 35756, (char) 45910,
        Double.longBitsToDouble(0x3fe6c3095896edf9L), Double.longBitsToDouble(0x3fa20a505c3672e0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 18, 9, "\ud906\udf89\udbb6\udf43\udb81\uddd2", "\u0d0c\u4d7f\u09c0\u38d8\u04c7\u60dc\ua485\u94da\ua866\ub0b3", "\uda47\udca1\udad7\ude85\udbe7\uddf4\ud9ad\udf98\ud8a8\udf06\ud84f\udc3d\uda2b\ude4e\ud9a1\udd87\ud8b9\uddf9\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda78\ude0e\ud893\udffc\ud951\udc72\uda17\udcde\udb30\udc1c\ud9ec\udc5d\ud829\udea8\udb0b\uddcf\ud86f\udfec\ud869\udfbc\udb41\udc89\ud81e\udf78\udb39\uddea\ud92a\udcd4\uda2e\udf64\ud9e4\udd4f\udb96\udd4a",
        2, 23376, 1590443498, -835048734508182027L, 57136L, false, false, (char) 215, (char) 49647,
        Double.longBitsToDouble(0x3fe6057c3c5c45b1L), Double.longBitsToDouble(0x3fdeed6d7ab49be2L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 1, 0, 0, "", "\u7ce9", "\udb3e\uddcb",
        -5, -1000, 218103808, -8889483133140129337L, -30284L, false, false, (char) 42005, (char) 773,
        Double.longBitsToDouble(0x3e16e48000000000L), Double.longBitsToDouble(0x3e3fa00000000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Long:5688543799843665158\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 17, 17, "\ud90c\udf57\udbb6\udf43", "\ucf62\u0d0c\u2dca\uc80e\u44fc\u0bf9\u073d\ua485\u94da\u7878\uaf38\ubf2b\u7637\u19bc\u0696\ub11e\u41b2\u9446\uae54\u03c2\u3329", "\udbd6\ude78\ud9dd\uded4\udb54\ude3a",
        43, 837, -985788331, 5688543799843665158L, 11252L, false, false, (char) 59244, (char) 1211,
        Double.longBitsToDouble(0x3fd8878071d4cadeL), Double.longBitsToDouble(0x3fd5cd8d0d95ee02L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[C:[[\ud90c, \udf57, \udbb6, \udf43, \ud941, \udf32]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 13, 1, "\ud90c\udf57\udbb6\udf43\ud941\udf32", "\u0d0c\u2dca\uc85f\u44fc\ua528\u9f3d\ua485\u5a8c\ua800\ub0b3\uba8e\u7637", "\ud9f7\ude9c\ud91d\ude18",
        37, 95647, -991327798, 360328908962982138L, -61952L, false, true, (char) 29751, (char) 13163,
        Double.longBitsToDouble(0x3fbcb14fa8327788L), Double.longBitsToDouble(0x3febf2f771935e21L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:6\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 10, 17, "\ud90c\udf57\udbb6\udf43\ud949\udf57", "\u1cf7\u2d79", "\udb41\udf37\ud92f\udf38\ud95b\udfa7\uda4b\udfb6\uda73\udf02\udb2d\udcbb\udb0f\udc40\ud8b1\udecc",
        6, 26941, -1520722956, 3603069200340863221L, 90714L, false, false, (char) 39893, (char) 63003,
        Double.longBitsToDouble(0x3feb076683a6e9a3L), Double.longBitsToDouble(0x3fe3080eb3a1d090L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:0.6691777750463851\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 13, 17, "\ud90c\udf57\udbb6\udf43\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u0bf9\u073d\ua485\u94da\ua866\u28a8", "\udbf2\udc57",
        16, 33044, -1691876868, 2373877743466447615L, 76620L, false, true, (char) 63003, (char) 50455,
        Double.longBitsToDouble(0x3fe569e7826118bbL), Double.longBitsToDouble(0x3fb548c5a39629f0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:0.688169591800195\012",
        Z.run(T, 1, 7, 2, 17, "\ud90c\udf57\udbb6\udf43\udb81\uddd2", "\u0d0c\u2dca\uc80e\u44fc\u0bf9\u073d\ua485\u94da\ua866\ub0b3", "\udbf2\udc57\udb36\udf73\ud9f7\ude9c\uda5d\udc0a\u3f2c\ud842\ude7f\uda2b\ude4e\ud9a1\udd87\ud8b9\uddf9\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda78\ude0e\ud893\udffc\ud951\udc72\uda17\udcde\u0119\ud8a0\ude9e\ud8ec\udcaa\ud86b\ude9b\ud86f\udfec\ud8d0\udec5\udb41\udc89\ud99d\udf09\ud949\udf71\udb91\udfac\uda2e\udea8\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 50847, (char) 49647,
        Double.longBitsToDouble(0x3fe6057c3c5c45b1L), Double.longBitsToDouble(0x3fdeefed7ab49be2L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:30\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 13, 17, "\ud90c\udf57\udbb6\udf43\udb81\uddd2", "\u0d0c\u2dca\uc80e\ua2ec\u18af\ubfaa\ua53c\u1131\ua866\ub0b3", "\udb75\ude0f\udb36\udf73\ud9f7\ude9c\uda5d\udc0a\u3f2c\ud842\ude7f\uda2b\ude4e\ud9a1\udd87\ud8b9\uddf9\ud8ba\udec7\uda8a\uddbd\uda22\udca6\ud80d\uddf9\ud935\uddc0\ud951\udc72\uda17\udcde\u0119\ud8a0\ude9e\udb62\udc44\ud877\udd38\ud86f\udfec\uda2d\udfbe\udb41\udc89\u7606\udb39\ude9a\udb2d\udff5\uda25\udf95\uda7a\udf9a\ud94b\ude41",
        30, 34412, 1590443372, -835048734515088923L, 72741L, true, false, (char) 41706, (char) 55077,
        Double.longBitsToDouble(0x3fe6057c3c5c45b1L), Double.longBitsToDouble(0x3fdeefed7ab49be2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Long:-835048732827474632\0121=java.lang.Integer:55\012",
        Z.run(T, 2, 9, 8, 15, "\ud90c\udf57\uda04\udc2d\udb81\udd90", "\u0d0c\u2dca\uc80e\u44fc\u0bf9\u073d\ua485\u94da\ub48e\u8602", "\udbf2\udc57\udb36\udf73\ud879\udeb0\uda5d\udc0a\u3f2c\ud842\ude7f\uda2b\ude4e\ud9a1\udd87\ud8b9\uddf9\ud8ba\udec7\uda8a\uddbd\ud89f\udf65\ud8ab\udca6\udb99\udef5\ud951\udc72\uda17\udcde\u0119\ud8a0\ude9e\ud998\udc3f\ud877\udd38\ud86f\udfec\uda2d\udfbe\udb41\udc89\ud99d\udf09\udb39\ude9a\ud92a\udcd4\udbac\udf63\udb85\udeb1\u1de3",
        55, 34424, 1590443372, -835048732827474632L, 57136L, false, false, (char) 50847, (char) 49647,
        Double.longBitsToDouble(0x3fdc0af878b88b62L), Double.longBitsToDouble(0x3fdeefed7ab49be2L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:776545769 |a0=[C:[[\udb4b, \udcdb, \udbb6, \udef4, \udb81, \uddd2, \ud808, \udd34, \udb74, \udce5, \uda1e, \udd1a, \ud953, \uded0, \ud81a, \udc0a, \ud829, \udd4d, \ud807, \udd03, \ud961, \uddfb, \uda3a, \uddd8, \udac2, \udf52, \uda73, \udf02, \uda5b, \udd75, \udb0f, \udd0e, \ud8d7, \udd10, \udbf2, \udc57, \udb36, \udf73, \udac0, \ude82, \ud9d1, \udc60, \u84cb, \udb1b, \udf25, \uda09, \udf01, \ud877, \udc94, \ud8df, \udfb0]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 13, 1, "\udb4b\udcdb\udbb6\udef4\udb81\uddd2\ud808\udd34\udb74\udce5\uda1e\udd1a\ud953\uded0\ud81a\udc0a\ud829\udd4d\ud807\udd03\ud961\uddfb\uda3a\uddd8\udac2\udf52\uda73\udf02\uda5b\udd75\udb0f\udd0e\ud8d7\udd10\udbf2\udc57\udb36\udf73\udac0\ude82\ud9d1\udc60\u84cb\udb1b\udf25\uda09\udf01\ud877\udc94\ud8df\udfb0", "\uc348", "\ud961\udc7a\udbfa\ude28\u0180\udaac\ude04\udabe\udcc8\ud851\udd2a\ud870\udc12\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\ud929\udf7d\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41\udbec\udc09\udb23\udd99\ud87e\udf02\ud8d2\uddd3\udb2d\udcc5\udb73\udea5\udacc\udd88\uda94\udc14\ud9b7\udd4d\ud985\udf17\udaaa\ude62\ud840\udc93",
        13, 63704, 903056845, -810491632534733937L, -10616L, false, false, (char) 56542, (char) 28924,
        Double.longBitsToDouble(0x3fd29f154c4e1178L), Double.longBitsToDouble(0x3fd5fb97e6d18cccL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 18, 5, 1, "\udb4b\udcdb\udbb6\udef4\udb81\uddd2\ud808\udd34\udb4d\udce5\uda1e\udd1a\ud953\uded0\ud81a\udc0a\ud829\udd4d\ud807\udd03\ud961\uddfb\uda3a\uddd8\udac2\udf52\uda73\udf02\uda47\udd75\udb0f\udd0e\ud8d7\udd10\uda38\udffb\ud8ea\udeed\udac0\ude82\ud9d1\udc60\u84cb\ud8a0\udf55\uda2b\ude4e\ud877\udc94\ud97b\uddbe", "\uc348\u379a\u8275\u7498\u98d7\ua269\u397a\u4085", "\ud905\udd2f\udb4a\udf2e\ud9da\udef9\uda29\udc3d\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41\udbec\udc09\udb23\udd99",
        7, -934, -1458130459, 820901953657005520L, -8361L, false, true, (char) 31216, (char) 50170,
        Double.longBitsToDouble(0x3fe2298e0255ea30L), Double.longBitsToDouble(0x3fd2877265090a9aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 1, 9, "\udb4b\udcdb\udbe2\udeb6\udb81\uddc0\ud808\udd34\udb64\udce5\uda1e\udd1a\ud953\uded0\ud81a\udc0a\ud829\udd4d\uda7b\udf96\ud9d5\udf85\uda3a\uddd8\udac2\udf52\ud8f8\udca5\ud87d\udc4d\ud85b\udc23\u1ef5\udab4\ude00\ud87b\ude93\uadf9\ud996\udf5a\u84cb\ud842\ude54\uda2b\ude4e\ud877\udc94\ud8df\udfb0", "\uc348", "\ud961\udc7a\udbfa\ude28\u0180\udaac\ude04\udabe\udcc8\ud851\udd2a\udb26\uddfa\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\udbce\udf6f\uda7c\udd86\uda2d\uddc8\ud991\udca6\ud946\ude50\udbec\udc09\udb23\udd99\ud87e\udeee\ud877\udeeb\ud928\udfab\udb57\udf96\udad0\udf72\uda94\udc14\udb8b\udf90\ucb7d\udaa0\udf18\ud8bb\udf63",
        23, 66250, 903056845, -810491631628764273L, 65234L, false, true, (char) 22452, (char) 34742,
        Double.longBitsToDouble(0x3fd29f035c4e1178L), Double.longBitsToDouble(0x3fd5fb97e6d18cccL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Boolean:false |a0=[C:[[\udba3, \udcdb, \udb9c, \uddb7, \udb81, \uddd2, \ud808, \udd34, \udb64, \udce5, \uda1e, \udd1a, \ud953, \uded0, \ud9d6, \ude87, \udb69, \ude05, \uc869, \ud961, \uddfb, \uda3a, \uddd8, \udac2, \udf52, \uda73, \udf02, \uda47, \udd75, \udb0f, \udd0e, \ud8d7, \udd10, \udbf2, \udc57, \udb36, \udf73, \udaa9, \udfa4, \ud9d1, \udc60, \u84cb, \ud842, \ude54, \uda2b, \ude4e, \ud877, \udc94, \ud8df, \udfb0]]\012",
        Z.run(T, 2, 8, 5, 1, "\udba3\udcdb\udb9c\uddb7\udb81\uddd2\ud808\udd34\udb64\udce5\uda1e\udd1a\ud953\uded0\ud9d6\ude87\udb69\ude05\uc869\ud961\uddfb\uda3a\uddd8\udac2\udf52\uda73\udf02\uda47\udd75\udb0f\udd0e\ud8d7\udd10\udbf2\udc57\udb36\udf73\udaa9\udfa4\ud9d1\udc60\u84cb\ud842\ude54\uda2b\ude4e\ud877\udc94\ud8df\udfb0", "\uc348", "\ud961\udc7a\udb92\udf74\udb59\udca8\udaac\ude1a\udabe\udcc8\ud851\udd2a\ud870\udc12\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udc3d\ud915\udd6f\uda22\udec8\uda7a\udf9a\ud94b\ude41\udbec\udc09\udb3a\udda6\ud87d\uddfa\ud877\udeeb\udb2d\udcc5\ud987\udea4\udacc\udd88\uda94\udc14\ud9b7\udd4d\ud804\udc36\udaba\uddda\udbb4\udfae",
        1, 63634, 782838591, -8752547381643887729L, -10616L, false, false, (char) 56542, (char) 34606,
        Double.longBitsToDouble(0x3fd29f035dd01178L), Double.longBitsToDouble(0x3fd5fb97e6d18cccL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 12, 19, 1, "\udb4b\udcdb\udbb6\udef4\uef90\ud93f\udee3\uda69\udfd6\uda1e\udcd6\ud953\uded0\ud81a\udc0a\ud829\udd4d\ud84c\udcae\u94a0\ud8fe\udeed\udac2\udf52\udb20\udf3c\uda47\udcb7\udb0f\udd0e\udb10\udf16\udbf2\udc57\udb36\udf73\udac0\ude82\ud9d1\udc60\u84cb\ud842\ude54\uda3a\uddc1\ud877\udc94\ud8df\udfb0", "\u88fb\u379a", "\ud9cf\udf26\u0180\udaac\ude04\udabe\udcc8\ud84f\udc2a\ud9c4\udc7c",
        19, 68583, -2062298386, 4598280864868430062L, 46359L, true, false, (char) 40112, (char) 14307,
        Double.longBitsToDouble(0x3fefab0ed9112058L), Double.longBitsToDouble(0x3fe0aa1dc591817eL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 4, 3, "\udb40\udfb1\udae7\udd8c\udb7b\udf02", "\u0d0c\u2dca\uc80e\u6cfc\u8af4\ubc2e\u24a4\ube81\ud50e\uc727", "\udbf2\udc57\ud806\udf57\ud881\ude06\ud9c7\udf61\u3f2c\ud842\ude7f\uda2b\ude4e\ud83e\ude96\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udc67\u1db6\ud893\udffc\uda3e\udeec\uada0\u0180\udaac\ude04\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\ud82f\udc47\uda8d\udc70\udafa\udd04\uda32\udc16\ud90f\udd47\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 2503, (char) 12815,
        Double.longBitsToDouble(0x3fe5a127bb3eab61L), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 17, "\udb40\udfb1\udb86\uddbb\000", "\u0d0c\u2dca\uc80e\u0c7b\000\000\000\u9417\000\u5093", "\udbf2\udc57\ud806\udf57\000\000\udb33\udee2\u00ff\udb2d\udc76\ud83e\ude96\uda3a\udffd\000\uda8a\uddbd\ud8e5\udf9a\u1db6\ud893\udffc\000\uad9b\u0180\006\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\ud82f\udc47\uda73\udf70\udafa\udd04\uda32\udc16\ud90f\udd47\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        36, -952, 0, 0L, 57136L, false, false, (char) 2503, (char) 30556,
        Double.longBitsToDouble(0x3fc68481e0000000L), Double.longBitsToDouble(0x3fdeefecf0b49be2L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[C:[[]]\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 1, 1, "", "\u7bda\u1b95\u33a6\u0d0c\u2dca\uc80e\u5be3\u8af4\ubc2e", "\uda8e\uddf7\ud9e3\udd4c\udb0f\udc40\ud8d7\udd10\udbf2\udc57\ud806\udf57\ud967\uded9\ud9c7\udf61\u3f2c\u00ff\000\ud83e\ude96",
        -5, 62428, 1683280852, -1441151880093537440L, -69023L, true, false, (char) 57366, (char) 46582,
        Double.longBitsToDouble(0x3feadaa60aea281eL), Double.longBitsToDouble(0x3fe3416689f491faL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[C:[[\udb40, \udfb1]]\0121=java.lang.Boolean:false |a0=[C:[[\udb40, \udfb1]]\012",
        Z.run(T, 2, 5, 5, 17, "\udb40\udfb1", "\u1b95\u33a6\ua00b\u2dca\uc80e\u44fc", "\udaf4\udc53\ud8b8\udda7\uda8e\uddf7\ud9f8\ude4c",
        3, 60633, -390348361, 3358023512510890374L, 50213L, false, false, (char) 57418, (char) 20274,
        Double.longBitsToDouble(0x3fefd028e614b73cL), Double.longBitsToDouble(0x3feea64009c86454L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 5, 10, "\udb40\udfb1\udae7\udd8c\udb7b\udf02", "\u0d0c\u6eca\uc80e\u44fc\u8af4\ubc2e\u6a10\u9453\u21b9\u9978", "\udbf2\udc57\ud806\udf57\ud967\uded9\ud9c7\udf61\u3f2c\ud842\ude7f\uda2b\ude4e\ud83e\ude96\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udca6\u1db6\ud893\udffc\uda3e\udeec\uada0\u0180\udaac\ude04\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\ud82f\udc47\uda8d\udc70\udafa\udd04\uda32\udc16\ud90f\udd47\ud868\udf06\uda7a\udf9a\ud94b\ude41",
        30, 34424, 1590443372, -835048734515088923L, 57136L, false, false, (char) 2503, (char) 30556,
        Double.longBitsToDouble(0x3fe5a1207b3eab61L), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 7, "\udb40\udef7\udbb6\udef4\ud9ec\ude48\udb47\udc2c\ud800\udf21", "\u8783\u44d1\u8af4\uafba", "\ud9df\udf3b\udbdc\udc99\ud82c\udf45\ud831\udf05\udb02\ude03\udb4e\udf8f\uda83\udc56\ud96c\ude9c\udae9\udefc\uda0b\uddce\u4083\udb97\udf6c\uf2a0\ud8d4\ude5a\udaba\udcdc\u98ab\ud90f\udc2f\uda58\ude83",
        2, 61915, 837958937, -2942781757979693265L, -9480L, false, true, (char) 54251, (char) 54553,
        Double.longBitsToDouble(0x3fca6c5100d46f30L), Double.longBitsToDouble(0x3fed6e4ce4cf1154L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Long:-4257720471927647172\0121=java.lang.Integer:56\012",
        Z.run(T, 2, 9, 8, 2, "\ud830\udd29\udbb6\udef4\udb81\uddd2", "\u2890\u2d73\uc80e\u44fc\u8af4\u50ea\u4fcd\uc501\uce63\ub878\u0ba2", "\ud86f\ude1a\ue107",
        56, 14123, -139877849, -4257720471927647172L, 21164L, true, false, (char) 14409, (char) 20571,
        Double.longBitsToDouble(0x3fc7fa346da8c0ccL), Double.longBitsToDouble(0x3fc1c473d3646cf8L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 3, "\udb40\udee0\udbb6\udef4\udb81\uddd2", "\u0aac\u2e9c\uc80e\u44fc\u8af4\u50ea\u4fcd\uc501\u68a9\u655b", "\ud905\ude00\udaff\udeb5\ud80d\udd71\ud9ca\udc00",
        33, 50471, -991327798, 421108813965872108L, 62208L, true, true, (char) 29751, (char) 13356,
        Double.longBitsToDouble(0x3fe648d9f39531f2L), Double.longBitsToDouble(0x3fe97eb94aea281eL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 12, 0, "\ud838\ude2e\udbb6\udf1d\udb81\uddd2\ud808\udd34\udb64\udce5\uda1e\udd1a\udaf3\udd80\udad2\ude29\uda1c\udc61\udb58\udcc9\ud89b\udf9b\udbbb\udfed\ud9d7\uddbb\ud992\udd8f", "\u1d13\u8619\u6627\ubb20\u81c3\u5c88\u3c79\u03c2\u2329\u71e3\u2687\u6bf4\u9b3e\u346d\u4a12\u7498\u98d7\u980b\u632e\u26bc\ud2b2\u2c02\u2b7e\uc214\u3e1e\u91c5\u2d8e\u4006\uad08\u0f6a\u2e80\u72e7\u65bb\u6b25\u9e97\u6e69\u2761\ua4db\u8607\u6219", "\ud8cf\udf88\udab4\udd70\ud8e8\udfcd\uda64\udd8f\ud925\ude84\ud96f\udd9f\ud944\udf32\ud9db\udec8\ud8d1\udca5\u02a1\ud8b8\udfbd\ud9bb\udd58\uda91\udeb2\uda7a\udd92\ud830\udfdc\udb04\uded2",
        35, 92538, -1777575545, 8182781845808494596L, 29502L, false, false, (char) 46721, (char) 48560,
        Double.longBitsToDouble(0x3fe8ef815e8a2d5eL), Double.longBitsToDouble(0x3fe1d479fc4b30ddL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\0121=new com.fasterxml.jackson.core.io.NumberInput:@?\012",
        Z.run(T, 2, 15, 15, 15, "\udb40\udfb1\ud94d\udd7f\udb85\udf9f", "\u0d0c", "\ud829\udd4d\ud807\udd03\ud927\udc2a\ud98f\udd61\udac2\udf52\uda73\udf02\udb2d\udcbb\udb0f\udc40\ud8d7\udd10\udbf2\udc57\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\uda22\udca6\uda78\ude0e\ud893\udffc\ud961\udc7a\udbfa\ude28\u0180\udaac\ude04\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uda22\udec8\uda7a\udf9a",
        11, 7136, 1541093424, 6830902268685537178L, -10912L, false, true, (char) 28782, (char) 43714,
        Double.longBitsToDouble(0x3fe9f42cddeefecfL), Double.longBitsToDouble(0x3fd5a4df13cd55a6L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:55895 |a0=[C:[[\ud89c, \udddf, \udbb6, \udef4, \udb81, \uddd2, \ud808, \udd34, \udb64, \udce5, \uda1e, \udd1a, \udaf3, \udd80, \udab5, \ude3a, \ud829, \udd4d, \ud807, \udd03, \ud927, \udc2a, \ud98f, \udd61, \udac2, \udf52, \uda73, \udf02, \udb2d, \udcbb, \udb0f, \udc40, \uda87, \udd08, \udbf2, \udc57, \udb36, \udf73, \ud9f7, \ude9c, \ud9ca, \udc00, \ud835, \udfbf, \uda5c, \udea9, \uda42, \udfeb, \ud877, \udc94, \ud8df, \udfb0, \ud8ba, \udec7, \uda8a, \uddbd]]\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 11, 1, 17, "\ud89c\udddf\udbb6\udef4\udb81\uddd2\ud808\udd34\udb64\udce5\uda1e\udd1a\udaf3\udd80\udab5\ude3a\ud829\udd4d\ud807\udd03\ud927\udc2a\ud98f\udd61\udac2\udf52\uda73\udf02\udb2d\udcbb\udb0f\udc40\uda87\udd08\udbf2\udc57\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\ud835\udfbf\uda5c\udea9\uda42\udfeb\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd", "\u49f9\u7498\u98d7", "\ud8f8\uddf6\ud877\udd8e\ud86f\udfec\uda2d\udfbe\udb41\udc89\ud9f6\udf5a\uda29\udd12\ud915\udd6f\ud9fe\udd34\ud8d5\udddc\ud946\udfce\udbec\udc09\udb23\udd99",
        32, -934, -1458130459, 820901952348382672L, 70514L, false, true, (char) 6825, (char) 41833,
        Double.longBitsToDouble(0x3fe02a93042d867bL), Double.longBitsToDouble(0x3feca6de8cc7bac0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 15, 19, 8, "\udb40\udfb1\udbb6\udef4\udab9\udd45", "\ud7d0\u98ba\u972b\u12c9\u8af4\uca24", "\uda73\udeaf\ud9ec\uddfa\udad5\udc3d",
        3, 15639, -72490059, 1718576204528489158L, 31839L, true, false, (char) 59011, (char) 53728,
        Double.longBitsToDouble(0x3fe0a5b9e3d4c801L), Double.longBitsToDouble(0x3fdc864546c1d9a0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 11, 0, "\udb40\udfb1\udbb6\udef4\u20c0", "\u970b\u2dca\uc80e\u44fc\u8af4\ubc2e\u19d7\u6f6f\ud10e\u3c58", "\udbf2\udc57\udb36\udf73\udb37\udd5b\ud9c9\udfca\u3f2c\ud842\ude7f",
        2, 52660, -1220752390, -4034857941657660460L, -61952L, false, true, (char) 29751, (char) 13356,
        Double.longBitsToDouble(0x3fcb2367d4193bc4L), Double.longBitsToDouble(0x3feadaa60aea281eL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:-5\0121=java.lang.Integer:-5\012",
        Z.run(T, 2, 8, 8, 17, "\udb8d\udeb5\udbb6\udef4\u241f", "\u1da9\u2dca\u90cf\u127b\u8af4", "\ud8bd\udfc7\uda73\udf02\udb43\udcaa\udb0f\udc40\ud8d7\udd10\udbf2\udc57\uda8f\udeab\ud9a8\udc4e\ud9c5\udf03\udb39\uddfa\ud875\udc95\uda2b\ude4e\ud877\udc94\u6faf\ud8ba\udec7\uda8a\uddbd\ud9a9\udcc7",
        -5, 98272, 597602913, -4386487836845894397L, -41016L, false, true, (char) 1168, (char) 19104,
        Double.longBitsToDouble(0x3fc470a27ccafb40L), Double.longBitsToDouble(0x3fca50a2a66539ccL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Long:-311342434210833420\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 3, 0, "", "\u7ce9", "\uda1e\udd1a\udaf3\udcf8\udab5\ude3a\ud829\udd4d\ud807\udd03\ud927\udc2a\ud98f\udd61\udac2\udf52\uda73\udf02\udb2d\udcbb",
        3, 60633, -390348361, -311342434210833420L, 58755L, true, false, (char) 63366, (char) 55589,
        Double.longBitsToDouble(0x3fefd02ec614b73cL), Double.longBitsToDouble(0x3feea64009c86454L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 6, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2\ud808\udd34\udb64\udce5\udb48\udf70\ud8d3\udd0f\u035d\udbad\udcba\ud807\udd03", "\uc124", "\ud959\ude05\ud8d7\udd10\udbf2\udc57\udb36\udf73",
        9, 92476, 552711483, -610797406213535286L, -47782L, false, false, (char) 39893, (char) 63003,
        Double.longBitsToDouble(0x3fc2dd9a00cfd3dcL), Double.longBitsToDouble(0x3feee8a0182c5083L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 12, 14, 16, "\000\udbb6\ude44\udb81\uddd2", "\ud226\u00ee\u8b3a\ua369\u00ef\000\000\000\u7176\ub0b3", "\udbdc\udc4c\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\u00ff\udb2d\udc76\ud877\udc94\ud8df\udfb0\ud8ba\udec7\udbfe\udfd8\ud8fe\uddd4\ud9f3\udf59\udac0\udc72\ud961\udc7a\udbfa\ude28\ud9e1\ude70\udab5\udf66\ud8f8\uddb8\ud877\udd8e\ud848\uddec\uda2d\udfbe\ud985\udc8b\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uae2e\uda53\udca8\ud94b\ude41",
        30, 34424, 1590444652, -835048734515088923L, -100000L, false, false, (char) 50847, (char) 28782,
        Double.longBitsToDouble(0x3fe5a1207b3e859bL), Double.longBitsToDouble(0x3fdeefecfab49be2L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 18, 4, "\uda41\udd10\ud890\udcaf\udb81\uddd2\ud808\udd34", "\u2dd3\u0348\ua126\u66ab\u9822\ub6cd\uc124\u75af\ub95c", "\ud951\udc5a",
        8, -236, 1046217212, -1589289928619582318L, -32476L, false, true, (char) 1390, (char) 18540,
        Double.longBitsToDouble(0x3fe200589b60cb5bL), Double.longBitsToDouble(0x3fed374d1b61c1d6L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:18\012",
        Z.run(T, 1, 8, 18, 12, "", "n\000\000\000", "\u7c99",
        18, 55782, -455473664, 66326830672072176L, -100000L, false, false, (char) 0, (char) 58111,
        Double.longBitsToDouble(0x3fefa1a569fca55bL), Double.longBitsToDouble(0x3fd3b3e5c925d3e2L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\0121=new com.fasterxml.jackson.core.io.NumberInput:@?\012",
        Z.run(T, 2, 15, 15, 8, "\udb33\udfca\udbb6\ude74\udb81\uddd2", "\u1d6b\u2dca\u2be9\u44fc\u8af4\ubc2e\ub6cd\ua466\ua82f\u1a46\u7541\ub042\u9513\u1588\u0086\u021d\u9446\u912b\u5aac\u2329\uc5bc\u7d31\u54f4", "\ua1e6\udb84\ude0a\ud89e\udcd1\udb9c\udeea\ud8ed\ude5c\uda1b\udd19\ud880\udd8d\udb3a\udf50\uda1b\udde1\udb41\udc89\uda0d\udec5\udbb1\udff0\uda0e\udf57",
        57, 26804, -1907317356, -6123968109026532884L, -65373L, false, false, (char) 45734, (char) 27933,
        Double.longBitsToDouble(0x3fedc85180347d5fL), Double.longBitsToDouble(0x3feeadd2be53e73dL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 5, 5, "\udb04\udfb3\udbb6\udef4\udb81\uddd2", "\u1d60\u2dca\uc80e\u09bf\u8a64\ubc2e\ub6cd\uc124\ua866\u3023\uba8e\u6895\u8f69\u286d\uc127\u021d\u9446\u3e49", "\ud842\udd91\ud8d6\uded5\uda8a\uddbd\udbc7\udfb8\udac2\udd80\ud893\udf8c\ud961\udc7a\u863c\u0156\ud9af\uddc6\udbde\udc1a\ud866\udc4f\udbb4\uddce\ud8e4\udcd2\udb17\uddc9\uda2a\udc4c\udb00\udd20\ud9e3\udcc5\uda12\udd39\udb4c\udcc4\ud96d\udeb1",
        43, 90644, 1835078259, 3418848399174241622L, 43773L, true, false, (char) 39728, (char) 9120,
        Double.longBitsToDouble(0x3fdf2e9e32a3bf96L), Double.longBitsToDouble(0x3fc5e679d15a52e0L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 11, 8, "\udb40\udfb1\udbb6\udef4\udb81\uddd2", "\u1d6b\u2dca\uc80e\u44fc\u8af4\ua447\ub6cd\uc124\u8a24\ub0b3\u040a\000\u102c\u0696\u0086\u85b2\u68ac\u18f3", "\ud92d\udc77\ud8ba\udf07\u00d4",
        -5, -1000, -1042900058, 2566684967786385550L, 8024L, true, false, (char) 28892, (char) 35780,
        Double.longBitsToDouble(0x3feee65462058b39L), Double.longBitsToDouble(0x3e1210a260000000L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Long:-6944908565970664199\0121=java.lang.Integer:3\012",
        Z.run(T, 2, 9, 8, 9, "\udb49\udeb1\udbb6\udef4\udb81\uddd2\ud95e\udf7e\udae6\ude9c\uda76\udc6f", "\u9769\u5d13\u4be8\ub6cd\uc124\u4427\ub0d1\uba8e\u6895\u23ba\u0696\u0086\u6c2b\u9446\u18f3\u03c2\u2329\u40d1\u5bb6\ub2bd\u6944\u6cd0\u82ae\u7498\u98d7\ua269\u83fe\u4fc5\u52c9\u2c02\ua2ca\u6afe\u2a8a\u54cd\u5010\u89a7\ud7b2", "\udafc\udd97\udaba\udf9b\udaa5\ude1b\udbc2\udf7d",
        3, 23971, 1109298951, -6944908565970664199L, 79303L, false, false, (char) 45678, (char) 47627,
        Double.longBitsToDouble(0x3fe129c9ef8a71b3L), Double.longBitsToDouble(0x3fc9a6e4a7afe840L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Integer:21\0121=java.lang.Boolean:false |a0=[C:[[\ud957, \udf04, \uda43, \udcb1, \ud934, \udd35, \ud857, \ude5c, \udae6, \ude9c, \udb58, \udf21, \udaf3, \udd80, \udab5, \ude3a, \ud829, \udd4d, \ud807, \udd03, \ud927, \udc2a, \ud98f, \udd61, \udac2, \udf52, \ud95d, \udfdd, \udb2d, \udcd9, \udb0f, \udc40, \ud978, \udfa2, \ub64d, \udb36, \udf73, \ud9f7, \ude9c, \ud9ca, \udc00, \u3f2c, \ud842, \ude7f, \uda2b, \ude4e, \ud877, \udc94, \ud8df, \udfb0, \ud8ba, \udec7, \uda8a, \uddbd, \udbc7, \udfb8, \u0d15, \udae0, \udc58, \ud961, \udc7a, \udbfa, \ude28, \u0180, \ud9af, \uddc6, \udbde, \udc1a, \ud866, \udc4f, \ud86f, \udfec, \uda2d, \udfbe, \udb83, \udc8b, \ud8eb, \udc08, \udb1d, \uddf1, \ud86d, \uddf1, \ud8b3, \ude41, \ud81b, \udc56, \ud9ed, \uddef, \uda7f, \uded4, \udafc, \udd97, \udaba, \udf9b, \udaa5, \ude1b, \udbc2, \udf7d, \ud8ca, \udd55...\012",
        Z.run(T, 2, 8, 5, 1, "\ud957\udf04\uda43\udcb1\ud934\udd35\ud857\ude5c\udae6\ude9c\udb58\udf21\udaf3\udd80\udab5\ude3a\ud829\udd4d\ud807\udd03\ud927\udc2a\ud98f\udd61\udac2\udf52\ud95d\udfdd\udb2d\udcd9\udb0f\udc40\ud978\udfa2\ub64d\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\udbc7\udfb8\u0d15\udae0\udc58\ud961\udc7a\udbfa\ude28\u0180\ud9af\uddc6\udbde\udc1a\ud866\udc4f\ud86f\udfec\uda2d\udfbe\udb83\udc8b\ud8eb\udc08\udb1d\uddf1\ud86d\uddf1\ud8b3\ude41\ud81b\udc56\ud9ed\uddef\uda7f\uded4\udafc\udd97\udaba\udf9b\udaa5\ude1b\udbc2\udf7d\ud8ca\udd55\udaa2\udcbd\uda04\udf73\udbd1\udcc5\uda71\udc07\udb7f\udf75\ud93d\ude0d\ud863\udf98\ud810\udea5\uda02\udcfa\ud940\udcd8\udbce\udec9\ud991\udc73\udbe5\udccb\ud9fe\udd37\udb9c\udf8c\ud86b\uddd1\ud9f5\udf41\ud9eb\udfec\ud9a8\udda4\ud934\udec8\ud9b6\udcb9\ud833\ude5a\udbc9\uddb9\ud8d7\udcf0\udbb1\udd08\u0883\ud9d4\udc08\ud86e\udc83\ud90f\ude15\uda83\uddcc\ud9d0\udfec\udb1c\udc92\udb29\udc8b\ud908\uddb7\udaf7\uddb3\ud9d9\ude09\u80b1\ud9a6\udcec\u4883\udac5\uddc3\ua184\udbb3\ude6d\uda84\udc87\ud974\udce2\u1bb5\ud961\udee7\ud9ff\udf19\ud8b0\udcd9\ud817\udd07", "\u611d", "\udb83\udfda\uda5e\ude7b\udb9b\udd42\ud8a7\udf02\ud973\udd91\uda3d\udcfe\ud978\udd8e\ud916\udee8\udb6b\udf30\ud921\uddfe\udad4\udc61\udb06\udf08\uda49\udd76\udb68\udefd\uda61\ude35\ud8b3\udfce\ud827\udf93\udbb1\udc78\udb46\udce2\ud8a9\udc7f\uda29\udead\udb08\udf61\ud88f\udef3\udb46\udd09\ud993\udd9e\ud856\udc6c\uda74\udc25\ud8cc\udf5e\udb8c\udeba\udb25\ude13\ud8a3\udd16\ud8c4\udd1f\udaf8\udc74\ud9d0\ude9b\udbad\udf4c",
        21, 76604, 1157763813, -4557255658790708481L, 79916L, true, false, (char) 5133, (char) 62240,
        Double.longBitsToDouble(0x3fe78a6b51118c2bL), Double.longBitsToDouble(0x3fe95032b18b3477L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Double:0.657962606627013\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 7, 10, 2, "\uda95\udc62\ud994\udddf\udac0\udd02\ud834\udc11", "\u5f66\ucf9b\u44fc\u8ab9\u77d0\ud2f7\u54e4\ub597\uafe2\uba8e\u6895\u23ba\u3b54\u7510\u021f", "\ud9cf\ude1f\ud877\udc65\ud9dd\udfaf",
        26, 13727, -237989432, -7185656621433845185L, -51656L, true, false, (char) 36857, (char) 64845,
        Double.longBitsToDouble(0x3fe50e0798ae86a0L), Double.longBitsToDouble(0x3fe8d23bab05a11bL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Double:0.6111760097426401\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 7, 0, 0, "", "\u7cf7\u1054\u3838\u949f\u8af8\ud596", "\ud92f\udf38\ud95b\udfa7\u3cf9",
        58, 42253, 58134, 2594073385365405879L, -74388L, false, true, (char) 48048, (char) 19280,
        Double.longBitsToDouble(0x3fe38ec0fdbe38a9L), Double.longBitsToDouble(0x3fec8096c79dafd7L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Long:8325877172389780489\0121=java.lang.Long:8325877172389780489\012",
        Z.run(T, 2, 9, 9, 16, "\ud897\udfdd\udae5\ude00\udbe1\udc82,\udb64\udc24\udb0a\udc6c", "\ud7b1\u9cb2\u073d\u8720\u27d1\ua7f6\ua2c6\u493d\u09e6\u9be9\u1359\u4e5c\u1555\uaad3\uc28f\u4854\uc875\u51cc\u62e5\u1dab", "\udafe\udf20\ud9aa\udf48\udb3a\ude39\udb73\udee4\udb2a\udda8\ud96b\udf9e\ud81c\udfc4\ud8b6\ude12\udae0\udc1e\udb1c\udd6e\ud8d3\uded0\uda30\udefc\ud977\udd5f\uda8f\udeaf\ud854\udef2\ud82d\ude2a\udb9b\ude22\udb07\udd6b\ud930\udea6\uda46\udd4a\ud96f\udf52\ud830\udca8\ud91b\udd18\udae1\udcf0\ud893\udd48\uda22\uddf0\ud8a4\udebb\ud915\ude0e",
        20, 83842, 1447709443, 8325877172389780489L, -36368L, true, true, (char) 28142, (char) 41080,
        Double.longBitsToDouble(0x3fe992b4ee4e9bd0L), Double.longBitsToDouble(0x3fef7c5121010083L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Double:0.2478519510923427\0121=java.lang.Double:0.2478519510923427\012",
        Z.run(T, 2, 7, 7, 10, "\ud8c7\udf68\ud81d\udeb5\udb66\udd08\ue66d\udbeb\udd79\ud804\udfc9\udb64\udc62\ud865\udec6\ud829\udd4d\ud837\udee5\ud92f\udf38\ud95b\udfa7\uda4b\udfb6\uda73\udf02\ud94c\udcc7\ud96e\udf36\ud8d7\udd10\udbf2\udc57\udb36\udf73", "\u7020\u87f2\u03c2\ua0c7", "\uda8a\uddbd\ud8fe\udc45\ud93f\udce8",
        39, 86025, -985788331, -3931989431511342482L, -10162L, false, false, (char) 18620, (char) 1554,
        Double.longBitsToDouble(0x3fcfb99cdc187fe8L), Double.longBitsToDouble(0x3fe1c7286543f950L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Integer:30\0121=java.lang.Integer:30\012",
        Z.run(T, 2, 8, 8, 17, "\ud90c\udf57\udbb6\udf43\udb81\uddd2", "\u0d0c\u2dca\uc80e\ua2ec\u18af\ubfaa\ua53c\u1131\ua866\ub0b3", "\udb75\ude0f\udb36\udf73\ud952\udde9\uda5c\udf29\u3f2c\ud842\ude7f\uda2b\ude4e\ud9a1\udd87\ud8b9\uddf9\ud891\udcb1\uda8a\uddbd\uda22\udca6\ud80d\uddf9\ud935\uddc0\ud951\udc72\uda17\udcde\u0119\ud8a0\ude9e\udb62\udc44\ud877\udd38\ud86f\udfec\udbe6\uddbb\udb41\udc89\u7606\udb39\ude9a\udae3\udd30\uda25\udf87\uda80\udfa4\ud94b\ude41",
        30, 34412, 1590443372, -835048734515088923L, 72741L, true, false, (char) 41706, (char) 55077,
        Double.longBitsToDouble(0x3fe6057c3c2e23b1L), Double.longBitsToDouble(0x3fdeefed7ab49be2L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 6, 11, "\udb4b\udcdb\udbe2\udeb6\udb81\uddc0\ud808\udd34\udb64\udce5\uda1e\udd1a\ud953\uded0\ud81a\udc0a\ud829\udd4d\uda7b\udf96\ud9d5\udf85\uda3a\uddd8\udac2\udf52\ud8f8\udca5\ud87d\udc4d\ud85b\udc23\u1ef5\udab4\ude00\ud87b\ude93\uadf9\ud996\udf5a\u84cb\ud842\ude54\uda2b\ude4e\ud877\udc94\ud856\ude2a", "\uc2ac\ubcb4\u8275\u7498\u98d7\u4173\u397a\u4085\u4666\u9b6f\ua2ca\u43b9\u98e8\u392c\u9093\u6b9f\ua1e7\ua2ef\ub471\u550e\uc561\ua7f9\ub6f5\u614b\u7089\u9e11\u39b4\u7e75\uc3df\ua2e3\u8744\u13d3\u8598", "\udb9f\udd17\udaee\udcd4",
        1, 11212, -264938706, 629612418812518036L, -17950L, true, true, (char) 4236, (char) 64032,
        Double.longBitsToDouble(0x3fc7bbd99e554398L), Double.longBitsToDouble(0x3fe7de964b3fd4f1L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 5, 17, "\udb40\udfb1\udb86\uddbb\000", "\u0d0c\u2dca\uc80e\u0c7b\000\000\000\u9417\000\u5093", "\udbf2\udc57\ud806\udf57\000\000\udb33\udee2\u00ff\udb2d\udc76\ud83e\ude96\uda3a\udffd\000\uda8a\uddbd\ud8e5\udf9a\u1db6\ud893\udffc\000\uad9b\u0180\006\ud8f8\uddb8\ud877\udd8e\ud86f\udfec\ud82f\udc47\uda73\udf70\udafa\udd04\uda32\udc16\ud90f\udd47\uda22\udec8\uda7a\udf9a\ud94b\ude41",
        36, -952, 0, 0L, 57136L, false, false, (char) 2503, (char) 30556,
        Double.longBitsToDouble(0x3fc68481e0000000L), Double.longBitsToDouble(0x3fdeefecf0b49be2L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Long:-311342434210833420\0121=java.lang.Long:-311342434210833420\012",
        Z.run(T, 2, 9, 9, 0, "", "\u7ce9", "\uda1e\udd1a\udaea\udff8\udab5\ude3a\ud829\udd4d\ud807\udd03\udba8\udccc\ud98f\udccd\udac2\udf52\uda73\udf02\udb2d\udcbb",
        3, 60633, -390348361, -311342434210833420L, 58755L, true, false, (char) 63366, (char) 55589,
        Double.longBitsToDouble(0x3fefd02ec614b73cL), Double.longBitsToDouble(0x3feea64009c86454L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Long:7\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"7\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "7", "\u4658\u7964\u8095\u0ef2\u2f99#", "\ud9bb\udd68\udac2\udf52",
        52, 29787, 345016961, -2729884361939019831L, 58755L, true, true, (char) 51655, (char) 17376,
        Double.longBitsToDouble(0x3fefd02ec614b73cL), Double.longBitsToDouble(0x3feea64009c86454L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 6, 17, "\udb40\udfb1\udbb6\udef4\udb81\uddd2\ud808\udd34\udb64\udce5\udb48\udf70\uda01\udf60\u035d\udbad\udcba\ud807\udd03", "\uc124", "\udb5f\udd68\ud8d7\udd10\udbf2\udc57\udb36\udf73",
        9, 92476, 552711483, -610798157832812086L, -47782L, false, false, (char) 39893, (char) 63003,
        Double.longBitsToDouble(0x3fc2dd9a07bcebdcL), Double.longBitsToDouble(0x3fedfa32002c5083L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.core.io.NumberInput:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 15, 12, 16, "\000\udbb6\ude44\udb81\uddd2", "\u74c9\u00ee\u8b3a\ua369\u8551\ud647\000\000\u7176\ub0b3", "\udbdc\udc4c\udb36\udf73\uda5f\udd50\ud9ca\udc00\u3f2c\u00ff\udb2d\udc76\ud877\udc94\ud8df\udfb0\ud8ba\udec7\udbfe\udfd8\ud8fe\uddd4\ud9f3\udf59\udac0\udc72\ud8f5\ude24\ud9c9\ude81\ud9e1\ude70\udab5\udf66\ud8f8\uddb8\ud877\udd8e\ud872\udf1f\ud895\udcc5\ud985\udc8b\ud9f6\udf5a\uda29\udd12\ud915\udd6f\uae2e\uda53\udca8\ud94b\ude41",
        30, 34424, 1590431384, -835048734515088923L, 70514L, false, true, (char) 29375, (char) 62291,
        Double.longBitsToDouble(0x3fed87804091c9d0L), Double.longBitsToDouble(0x3fe1ae04afcc62e7L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Long:5971955365319008163\0121=java.lang.Long:5971955365319008163\012",
        Z.run(T, 2, 9, 9, 16, "\ud897\udfdd\udae5\ude00\udbe1\udc82,\udb64\udc24\udb0a\udc6c", "\ud7b1\u9cb2\u073d\u8720\u27d1\ua7f6\ua2c6\u493d\u09e6\u9be9\u1359\u4e5c\u1555\uaad3\uc28f\u4854\uc875\u51cc\u62e5\u1dab", "\udafe\udf20\ud9aa\udf48\udb3a\ude39\udb73\udee4\udb2a\udda8\ud598\ud81c\udfc4\ud8b6\ude12\ud99e\udc1d\udb1c\udd6e\ud8d3\uded0\uda30\udefc\ud977\udd5f\uda8f\udeaf\ud854\udef2",
        42, 84484, -294951307, 5971955365319008163L, -62782L, false, true, (char) 16207, (char) 31538,
        Double.longBitsToDouble(0x3fe6e5770e7cf064L), Double.longBitsToDouble(0x3fb9d2043848e078L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Integer:7\012",
        Z.run(T, 1, 8, 12, 16, "7", "\u4658\u7964\u33d8\u0ef2\u2f99\u8342", "\ud9bb\udd68\udac2\udf52",
        52, 29787, 9472641, -2729884361939019831L, 58976L, true, true, (char) 51655, (char) 17376,
        Double.longBitsToDouble(0x3fefd02ec614b73cL), Double.longBitsToDouble(0x3feea64008000000L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Long:7\0121=java.lang.Integer:7\012",
        Z.run(T, 2, 9, 12, 16, "7", "\u4658\u7964\u9aca\u6385\u9bee\uc8c0", "\ud9bb\udd68\ud8be\uddf1",
        -5, 26850, 1438605409, -2729881595980081207L, 58755L, true, true, (char) 51655, (char) 17376,
        Double.longBitsToDouble(0x3fefd02ec614b73cL), Double.longBitsToDouble(0x3feea64009c8642eL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Long:-3271715100738928342\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"7\udb88\udd44\uda4e\udfae\ud9fa\uddc0\udb42\udfdc\udaf6\udc84\udbd4\ude44\u18a6\ud988\udf7a\udb26\ude89\ud93b\udc6d\ud9bb\udd68\udad7\ude5e\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "7\udb88\udd44\uda4e\udfae\ud9fa\uddc0\udb42\udfdc\udaf6\udc84\udbd4\ude44\u18a6\ud988\udf7a\udb26\ude89\ud93b\udc6d\ud9bb\udd68\udad7\ude5e", "\u7ae0\u3bbc\u0ccd\u90ce\uc076\u243c\ub759\u5a50", "\ud8df\udfb0\udbde\udd8d\uda8a\uddad\ud804\udf57\udadf\udd5d\ud814\udc0b",
        15, 54093, 1510248403, -3271715100738928342L, 48063L, true, false, (char) 42324, (char) 37680,
        Double.longBitsToDouble(0x3fbc198d645613a8L), Double.longBitsToDouble(0x3fda2f3843331682L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Long:6324058588700650776\0121=java.lang.Integer:-5\012",
        Z.run(T, 2, 9, 8, 19, "7\udb88\udd44\uda4e\udfae\ud9fa\uddc0\udb42\udfdc\udaf6\udc84\udbd4\ude44", "\u90ea\u79a4\u8ed5\uc124\u6e07", "\ud88d\udfa7\udbc7\ude69\udb36\udf73\ud912\ude88\ud9d2\ude1f\udae0\udcda\ud881\udc53\ud93a\udf58\uda9d\udf74",
        -5, 63860, 1683280864, 6324058588700650776L, -59796L, false, true, (char) 65452, (char) 156,
        Double.longBitsToDouble(0x3fe890fe5f6240e9L), Double.longBitsToDouble(0x3fe459d0b18896f1L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.math.BigDecimal:7 |a0=[C:[[7]]\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"7\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 1, 16, 16, "7", "\u4658\u7964\u8095\u0ef2\u2f99#", "\ud9bb\udd68\udac2\udf52",
        52, 29787, 345016961, -2729884361939019831L, 58755L, true, true, (char) 51655, (char) 17376,
        Double.longBitsToDouble(0x3fefd02ec614b73cL), Double.longBitsToDouble(0x3feea64009c86454L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Long:-2729884361939019831\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"+\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "+", "\u4658\u7964\u8095\u0ef2\u2f99#", "\ud99e\udd79\uda47\udd9c",
        47, 30236, 345016961, -2729884361939019831L, 58755L, true, true, (char) 51655, (char) 17376,
        Double.longBitsToDouble(0x3fefd02ec614b73cL), Double.longBitsToDouble(0x3feea64009c86454L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Long:-2729884361939019831\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"N\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "N", "\u4658\u7964\u8095\u0ef2\u2f99#", "\ud9bb\udd68\udac2\udf52",
        52, 29787, 345016961, -2729884361939019831L, 18796L, true, false, (char) 21907, (char) 2285,
        Double.longBitsToDouble(0x3fd1078dcfb90a8aL), Double.longBitsToDouble(0x3fc9084f3850cf50L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Long:8021246505872270363\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 12, 0, "7\udb88\udd44\uda4e\udfae\ud9fa\uddc0\ud8a7\udcce", "\u9bee\uc89e\u9071", "\ud882\udecf\ud8f1\udd86\ud93d\udf56\uda75\udd34",
        1, 73137, -1700568437, 8021246505872270363L, -96120L, false, true, (char) 1361, (char) 40603,
        Double.longBitsToDouble(0x3fcbec05cfb4ca6cL), Double.longBitsToDouble(0x3fe7056f75ddfaa3L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Long:7\0121=java.lang.Long:7\012",
        Z.run(T, 2, 9, 9, 8, "7", "\u4658\u7964\u4d41\ucc45\u6622\u52d5", "\u0b0d\udaa4\udd5d",
        24, 83378, 5877915, -2729881595980081207L, -47782L, false, false, (char) 39893, (char) 15680,
        Double.longBitsToDouble(0x3fd01e00171f0f84L), Double.longBitsToDouble(0x3fca0bd494831e58L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Long:-2533208840137544465\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"F\udb88\udd44\uda4e\udfae\ud9fa\uddc0\udb42\udfdc\udb81\udf69\uda23\udd07\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "F\udb88\udd44\uda4e\udfae\ud9fa\uddc0\udb42\udfdc\udb81\udf69\uda23\udd07", "\u1d21\ucad2\u8ed5\u3c31\u6e07\ua1e2", "\ud87d\udc03\udba9\udde4",
        25, 47434, -856583171, -2533208840137544465L, -47782L, false, false, (char) 13490, (char) 24452,
        Double.longBitsToDouble(0x3fea865042d2466aL), Double.longBitsToDouble(0x3fd165bad51b1fa4L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Long:-2424022801906035747\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"!\udb82\udcc0\uda6e\udf6e\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "!\udb82\udcc0\uda6e\udf6e", "\u3683", "\ud988\udf7a\udb26\ude89\ud862\udc60\uda4c\udf22\udad7\ude5e\ud9ab\udc1e\udbfd\udc34\ud8d0\udfb7\ud9a9\ude67",
        47, 81235, 1873056805, -2424022801906035747L, -1260L, false, true, (char) 53713, (char) 25424,
        Double.longBitsToDouble(0x3fee26a969c86454L), Double.longBitsToDouble(0x3fe598d39c2ae961L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Long:494964359466\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"7\000\uda40\udf40\ud9fa\uddc0\udb42\udfdc\udaac\udc7f\udbd4\ude44\u18a6\ud988\udf7a\udb26\ude89\ud93b\udc6d\ud9bb\udd68\udad7\ude5e\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "7\000\uda40\udf40\ud9fa\uddc0\udb42\udfdc\udaac\udc7f\udbd4\ude44\u18a6\ud988\udf7a\udb26\ude89\ud93b\udc6d\ud9bb\udd68\udad7\ude5e", "\u7ae0\u3bbc\000\u738e\uc076\u243c\ub759\u5a50", "\000\udbde\udd8d\uda8a\uddad\ud804\udf57\udad5\udeb8\000",
        58, 54093, 211, 494964359466L, -100000L, true, false, (char) 24201, (char) 2752,
        Double.longBitsToDouble(0x3fe5b004f2b7f079L), Double.longBitsToDouble(0x3fbc198d645613a8L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Long:-1546574880702615629\0121=java.lang.Integer:53\012",
        Z.run(T, 2, 9, 8, 16, "+\udbe3\udef0\uda4e\udfae\ud9fa\uddc0\udb4a\udf4a\udacb\udc4a\ud9b5\udfb4\udb8c\udc03\ud993\udf7a\udb52\udf1f\ud93b\udc6d\udbc8\udf2e\udaeb\udd52\ud920\udc6d", "\uc0f8\ub434\u0696\u65fc\u648a", "\ud974\udc0a\ud875\udf80\ud8df\udfb0",
        53, 13852, -665873976, -1546574880702615629L, -90576L, false, false, (char) 16338, (char) 17161,
        Double.longBitsToDouble(0x3fc5b7454f1ba3f0L), Double.longBitsToDouble(0x3feb2f32d7f5781cL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Long:-4512377028484816316\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 1, 16, "N\udb88\udd44\uda4e\udfae\ud9fa\uddc0\udafb\udd17\udb03\udcbc\udbd4\ude44\u18a6\udb1c\udf18", "\u8ed5\u47f3", "\udad5\udcad\ud8c0\ude6e\udbc7\ude69\udb36\udf73\ud87e\udc8c\ud8fa\ude63\ud893\udff4\ud913\udf82",
        -5, 39908, 869588168, -4512377028484816316L, -52865L, true, true, (char) 9136, (char) 46081,
        Double.longBitsToDouble(0x3fb9bedac1b3c440L), Double.longBitsToDouble(0x3f90e4a78ad674a0L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Long:-2729884361939019831\0121=java.lang.Integer:40\012",
        Z.run(T, 2, 9, 8, 14, "N", "\ub0bf\u7929\u8095\u0ef2\u9a04\ua660", "\ud985\ude5b\udac2\udf21",
        40, 29787, 345016961, -2729884361939019831L, 18796L, true, false, (char) 21907, (char) 45804,
        Double.longBitsToDouble(0x3fe5aa2b9fa79c07L), Double.longBitsToDouble(0x3fc9084f2050cf50L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Long:8021246505872270363\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 12, 0, "7\000\uda4e\udfae\ud9fa\uddc0\ud8a7\udcce", "\u9bee\u1f8d\u9071", "\ud882\udecf\ud8f1\udd86\ud93d\udf56\uda75\udd34",
        1, 73137, -1700568437, 8021246505872270363L, -96120L, false, true, (char) 1361, (char) 40603,
        Double.longBitsToDouble(0x3fcbec05cfb4ca6cL), Double.longBitsToDouble(0x3fe7056f75ddfaa3L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Long:-5243091589937589246\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"F\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "F", "\u4658\ua16f\uc340\u0b79\u2f99\uac22", "\ud9bb\udd68\uda99\udf6b\ud9aa\ude1e\000\ud8ae\udd36\000\u17c9\udba9\uddc9\ud8ec\udecb\ud9f5\udd34\udae0\udcfa",
        10, 77176, 98044892, -5243091589937589246L, -100000L, false, false, (char) 0, (char) 44054,
        Double.longBitsToDouble(0x3fe46c7e94e12a00L), Double.longBitsToDouble(0x3fde25d3a671e1a2L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Long:-6413403289867716768\0121=java.lang.Integer:30\012",
        Z.run(T, 2, 9, 8, 10, "F\udb88\udd44\uda2c\udead\ud9fa\uddc0\ud8aa\udeef\ueb89\uda23\udd07", "\u1d21\ucad2\u8ed5\u3c10\u6e07\ub1e1\uccc3\u5037\u0ccd\u6014\u5c30\ud399\ub779\u5a50\u4e16\u1ac9", "\ua47e\udb38\udc01\udbdd\udc7a\ud814\udc39\uda5a\ude79\uda61\udea4\ud992\udfbb\u3211\ud8ab\ude64\udb79\udd6a\ud9c0\udf00\u7542\udab5\udce6\udab9\ude25\ud866\udeef\udb7b\udfea",
        30, 84295, 2042669463, -6413403289867716768L, 6114L, true, false, (char) 7865, (char) 21241,
        Double.longBitsToDouble(0x3fa7413a98c629d0L), Double.longBitsToDouble(0x3fcd2e1f9ead849cL)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Long:-2533208840137544465\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"F\000\000\000\000\udb81\udf69\uda23\udd07\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "F\000\000\000\000\udb81\udf69\uda23\udd07", "\u1d21\ucad2\u8ed5\u3c31\u6e07\ua1e2", "\ud87d\udc03\udba9\udde4",
        25, 47434, -872414979, -2533208840137544465L, -47782L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e30000000000000L), Double.longBitsToDouble(0x3fd165bad51b1fa4L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Long:-2424022801906035747\0121=java.lang.Integer:47\012",
        Z.run(T, 2, 9, 8, 16, "!\udb82\udcc0\udb4a\uddbb", "\u4683", "\udb99\ude7f\uda2d\udc6c\ud862\udc60\uda4c\udf22\udad7\ude5e\ud9ab\udc1e\udbfd\udc34\ud8d0\udfb7\ud9a9\ude67",
        47, 81235, 1873056805, -2424022801906035747L, -1260L, false, true, (char) 53713, (char) 35408,
        Double.longBitsToDouble(0x3fe92ea969c86454L), Double.longBitsToDouble(0x3fe6cfe39db44c3dL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Long:-2424022801906035747\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 12, 16, ".\udb82\udcc0\uda6e\udf6e", "\u90e8", "\ud988\udf7a\udbae\udf4d\uda00\udebc\ud93b\udf1d\ud82d\udd24\uda4f\ude41\u6298\ud8d0\udfb7\ud9a9\ude67",
        26, 4696, 1873027061, -2424022801906035747L, -1260L, false, true, (char) 42061, (char) 34868,
        Double.longBitsToDouble(0x3fee26a969c86454L), Double.longBitsToDouble(0x3fe598d5842ae961L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Long:-2424022801906035747\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"E\ud8c3\udd9d\ud85f\udcd1\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "E\ud8c3\udd9d\ud85f\udcd1", "\u3683", "\ud988\udf7a\udb26\ude2c\ud88c\udc96\uda1c\uddcb\udad7\ude46\ud9ab\udc1e\udbdc\udf05\ud988\uddcd\ud86b\ude53",
        7, 81235, 1873056805, -2424022801906035747L, -1260L, false, true, (char) 53713, (char) 25424,
        Double.longBitsToDouble(0x3fb3f54b7e4322a0L), Double.longBitsToDouble(0x3fe4deebeefe99beL)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Integer:58\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"7\000\uda40\udf40\ud9fa\uddc0\udb42\udfdc\udaac\udc7f\udbd4\ude44\u18a6\ud988\udf7a\udb26\ude89\000\000\uda99\udf6b\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 8, 16, 16, "7\000\uda40\udf40\ud9fa\uddc0\udb42\udfdc\udaac\udc7f\udbd4\ude44\u18a6\ud988\udf7a\udb26\ude89\000\000\uda99\udf6b", "\u7ae0\000\000\u738e\uc076\u243c\ub759\u5a50", "\000\udbde\udd8d\uda8a\uddad\ud804\udf57\udad5\udeb8\000",
        58, 54093, 211, 494964359466L, -100000L, true, false, (char) 24201, (char) 2752,
        Double.longBitsToDouble(0x3fe5b004f2b7f079L), Double.longBitsToDouble(0x3fbc198d645613a8L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Long:-8791026381389774550\0121=java.lang.Integer:58\012",
        Z.run(T, 2, 9, 8, 16, "7\000\uda40\udf40\ud9fa\uddc0\udb42\udfdc\udaac\udc7f\udbd4\ude44\u18a6\ud988\udf7a\udb26\ude89\ud93b\udc6d\ud9bb\udd68\udad7\ude5e", "\u064b\u3bbc\000\u738e\uc076\u243c\ub759\u5a50", "\000\udaae\udd95\uda8a\uddad\uda1f\udf05\udaea\udce5\000",
        58, 54093, 201326803, -8791026381389774550L, 48063L, true, false, (char) 20308, (char) 37680,
        Double.longBitsToDouble(0x3fbc198d645613a8L), Double.longBitsToDouble(0x3fd2a3295c194134L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Long:4221280224134346892\0121=java.lang.Long:4221280224134346892\012",
        Z.run(T, 2, 9, 9, 2, "7\udb6f\udc97\uda40\udf40\ud957\udef0\ud842\ude87\udb8a\udd42\uda2d\udcbd\udb26\udf28\ud988\udf7a\udb26\ude89\ud93b\udc6d\ud9bb\udd68\udad7\ude5e", "\u7aa0\u3bbc\000\u738e\u6cd4\u6dc0\u2c16\u5a50\u8b9b\ub3a4\u9396\u5153\ub2ad\u9921\u1f26", "\udb5a\udf00\u00d3",
        45, 92426, 9710348, 4221280224134346892L, -90929L, false, false, (char) 24812, (char) 34885,
        Double.longBitsToDouble(0x3fc1584eb5d70400L), Double.longBitsToDouble(0x3fe433963d7e4da4L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 8, 8, 16, "+\udbe3\udef0\uda4e\udfae\ud9fa\uddc0\udb4a\udf4a\udacb\udc4a\ud9b5\udfb4\udb8c\udc03\ud993\udf7a\udb52\udf1f\ud93b\udc6d\udbc8\udf2e\udaeb\udd52\ud920\udc6d", "\uc0f8\ub434\u0696\u6508\000", "",
        1, 74736, -1224684550, -4034943789463972908L, 66313L, true, true, (char) 65457, (char) 23911,
        Double.longBitsToDouble(0x3fe7716679f15de1L), Double.longBitsToDouble(0x3fe507a340adba2aL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Long:-4512377028484816316\0121=java.lang.Long:-4512377028484816316\012",
        Z.run(T, 2, 9, 9, 16, "N\udb88\udd44\uda4e\udfae\ud9fa\uddc0\udafb\udd17\ud927\uddbe\udbd4\ude44\u18a6\udb1c\udf18", "\u8ed5\u47f3", "\udad5\udcad\ud8c0\ude6e\udbc7\ude69\udb36\udf73\ud87e\udc8c\ud8fa\ude63\ud893\udff4\ud913\udf82",
        -5, 39908, 869588168, -4512377028484816316L, -52865L, true, true, (char) 9136, (char) 46081,
        Double.longBitsToDouble(0x3fb9bedac1b3c440L), Double.longBitsToDouble(0x3f90e4a78ad674a0L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Long:-5243091589937589246\0121=java.lang.Integer:35\012",
        Z.run(T, 2, 9, 8, 0, "F", "\u4658\ua16f\uc340\u0b79\u2f99\uac22", "\ud9bb\udd68\uda99\udf6b\ud9aa\ude1e\000\ud8ae\udd36\ud8a9\ude2d\u17c9\udba9\uddc9\ud9f0\udfd1\ud9f5\udd34\uda6b\udd80",
        35, 77176, 98044864, -5243091589937589246L, -100000L, false, false, (char) 0, (char) 44054,
        Double.longBitsToDouble(0x3fe46c7e94e12a00L), Double.longBitsToDouble(0x3fde25d3a1a1e1a2L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Integer:47\0121=java.lang.Integer:47\012",
        Z.run(T, 2, 8, 8, 13, "!\udb82\udcc0\udb4a\uddbb", "\u4683", "\udb99\ude7f\uda2d\udc6c\ud8fa\udf8b\udaf1\udfa3\ud91b\udde6\ud9ab\udc1e\udbfd\udc34\ud9d7\udee0\ud9a9\ude67",
        47, 48659, 1873056805, -2424022801906035747L, -1260L, false, true, (char) 53713, (char) 35408,
        Double.longBitsToDouble(0x3fe92ea969c86454L), Double.longBitsToDouble(0x3fe6cfe39db44c3dL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Long:5168751150366151707\0121=java.lang.Long:5168751150366151707\012",
        Z.run(T, 2, 9, 9, 16, "!\udb82\udcc0\udb7c\udcdc", "\uc553", "\uda9a\udc45\uda90\udff3\udb8a\ude0d\udaf2\ude6d\udad2\udf45\ud894\udd92",
        49, 53117, -1836255940, 5168751150366151707L, -90757L, true, true, (char) 50924, (char) 24716,
        Double.longBitsToDouble(0x3fe94524a3fa05d8L), Double.longBitsToDouble(0x3fe8a5b9e325d52dL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Long:6069366653844948586\0121=java.lang.Integer:6\012",
        Z.run(T, 2, 9, 8, 16, "-\ud848\udcc3\ud97a\uddf4\ud8fd\ude5d\udb42\udfdc\ud8ef\udd97\uda5d\udf6f\udb5b\udf06\ud901\udefd\u9f8d\ud9dc\ude58\ud94d\udea6\ud918\ude0c\ud859\udf77\uda4b\udfbd\u2eab\udb99\udef0\ud8b5\udd39\udbcc\uddb1\ud9eb\ude32\udbe5\udf94\ud9f3\ude12\ud930\udc4a\udb73\udcdc\udaae\ude9d\udad1\udcae\udbdd\udd40\ud962\udf15\uda7f\udc9c\ud9e7\udf33\ud8ff\udde9\ud98a\ude80\uda47\udeaf\uda4b\udf82", "\u7856\u25e6\u593c\u361b", "\ud9f3\ude96\ud9e0\udf92\ud999\ude1f\ud8b5\udc32\ud19f\uda3c\udc10\uda32\uded3\uda65\udecc\ud8b4\udfdf\udb26\udd47",
        6, 9552, -1242715030, 6069366653844948586L, -84958L, false, true, (char) 9496, (char) 45819,
        Double.longBitsToDouble(0x3fb844486f397120L), Double.longBitsToDouble(0x3fd65ccff9e68b82L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Long:-2424022801914293283\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 12, 12, ".", "\u691f\u3683\u90e8", "\ud988\udf7a\udbae\udf4d\uda00\udebc\uda57\udd2f\ud82d\udc6c\ud94e\udfe2\u6322\ud8d0\udfb7\ud9a9\ude67",
        26, 4696, 1873027061, -2424022801914293283L, -1260L, false, true, (char) 4071, (char) 61709,
        Double.longBitsToDouble(0x3fee26a891c86454L), Double.longBitsToDouble(0x3fe598d584db3f61L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Integer:6\0121=java.lang.Integer:6\012",
        Z.run(T, 2, 8, 8, 7, ".\ud905\uddd3\uda5d\udcf2", "\ubb28\uc482\u2f99", "\uda00\udebc\udbb0\uded7\ud82d\udc90\uda4f\ude41\u6298\ud8d0\udfb7\ud9a9\ude67\ud96f\udc2b\udbde\udd74\ud8f3\ude89\ud9d2\ude1f\udac6\udf0c\ud841\udf9f\udb73\udcdc\ud92b\udd4c\udb1c\udfe7\udbde\udd8d\uda8a\uddad\uda8a\udf5a\udadf\udd5d\ud806\udfb4\udbff\udc43\udbf8\udc05",
        6, 89201, 2081173911, 516987420613913363L, -38572L, false, false, (char) 33452, (char) 56595,
        Double.longBitsToDouble(0x3fdea032817b2846L), Double.longBitsToDouble(0x3fd02aa063e2e538L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Long:-2424022801906035747\0121=java.lang.Long:-2424022801906035747\012",
        Z.run(T, 2, 9, 9, 16, "E\ud8c3\udd9d\ud85f\udcd1", "\u3683", "\ud988\udf7a\udb26\ude2c\ud88c\udc96\uda1c\uddcb\udad7\ude46\ud9ab\udc1e\udbdc\udf05\ud975\udc83\ud86b\uddeb",
        7, 81235, 1873056805, -2424022801906035747L, -1260L, false, true, (char) 53713, (char) 25424,
        Double.longBitsToDouble(0x3fb3f54b7e4322a0L), Double.longBitsToDouble(0x3fe4deebeefe99beL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Integer:-5\0121=java.lang.Integer:-5\012",
        Z.run(T, 2, 8, 8, 16, "", "\u2cd2", "",
        -5, -1000, -1445675590, 5160376690603717785L, -84663L, true, false, (char) 14336, (char) 3360,
        Double.longBitsToDouble(0x3feafdf38ee02941L), Double.longBitsToDouble(0x3fed43f3541b7778L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Long:31807647325880320\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"E\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "E", "\u7f1c\u7964\000\000\u49de", "\ud88c\udc96",
        42, 99155, -1375731712, 31807647325880320L, -55200L, true, false, (char) 52763, (char) 37823,
        Double.longBitsToDouble(0x3feeeef2e1fbccf1L), Double.longBitsToDouble(0x3e4ca0d400000000L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Long:-4691682137035613409\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 9, 8, 19, "E", "\u7f1c\u7964\u3683\u0f61\u2f99", "\ud88c\udc96\uda1c\uddcb\udad7\ude46\ud9ab\udc1e\udbdc\udf05\ud988\uddcd\ud86b\ude53\ud983\udeb2\ud984\ude79\ud910\udeb9\ud9d2\ude1f\udae0\udcda\ud938\udf17\udb73\udcdc\ud875\udf80\ud8df\udfb0\udbde\udd8d\ud9f4\ude40\ud961\uddbf\ud8f9\udc94\udbe2\udf74\udb9f\udf0f\ud9d1\ude85",
        1, 31800, 1262708897, -4691682137035613409L, -58406L, true, true, (char) 51416, (char) 28914,
        Double.longBitsToDouble(0x3fe650c1a26e61deL), Double.longBitsToDouble(0x3fe7c4044194d6b3L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Long:-7978877689886496088\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"-\ud848\udcc3\ud97a\uddf4\ud8fd\ude5d\udb42\udfdc\ud8e9\udd13\uda50\udea9\udb1a\udf15\udaff\udda4\ub8e3\ud9dc\ude58\ud94d\udea6\ud918\ude0c\ud859\udf77\uda4b\udfbd\u2eab\udb99\udef0\ud8b5\udd39\udbcc\uddb1\ud9eb\ude32\udbe5\udf94\ud9f3\ude12\ud930\udc4a\udb73\udcdc\udaae\ude9d\udad1\udcae\udbdd\udd40\ud962\udf15\uda7f\udc9c\ud9e7\udf33\ud8ff\udde9\ud98a\ude80\uda47\udeaf\uda4b\udf82\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 0, 13, "-\ud848\udcc3\ud97a\uddf4\ud8fd\ude5d\udb42\udfdc\ud8e9\udd13\uda50\udea9\udb1a\udf15\udaff\udda4\ub8e3\ud9dc\ude58\ud94d\udea6\ud918\ude0c\ud859\udf77\uda4b\udfbd\u2eab\udb99\udef0\ud8b5\udd39\udbcc\uddb1\ud9eb\ude32\udbe5\udf94\ud9f3\ude12\ud930\udc4a\udb73\udcdc\udaae\ude9d\udad1\udcae\udbdd\udd40\ud962\udf15\uda7f\udc9c\ud9e7\udf33\ud8ff\udde9\ud98a\ude80\uda47\udeaf\uda4b\udf82", "\u7856\u25e6\u593c\u361b", "\ud9f3\ude96",
        25, 27886, -1117942261, -7978877689886496088L, -14507L, false, false, (char) 64587, (char) 46327,
        Double.longBitsToDouble(0x3fe483e0d1ca978eL), Double.longBitsToDouble(0x3fca2add59a950e8L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Long:8942703966782682768\0121=java.lang.Integer:47\012",
        Z.run(T, 2, 9, 8, 16, "-\000\000\ud8fd\ude13\udb42\udfdc\ud8ef\udd97\uda5d\udf6f\udb5b\udf06\ud901\udefd\u9f8d\ud9dc\ude58\ud94d\udea6\ud918\ude0c\ud859\udf77\uda4b\udfbd\u2eab\udb99\udef0\ud8b5\udd39\udbcc\uddb1\ud9eb\ude32\udbe5\udf94\ud9f3\ude12\ud930\udc4a\udb73\udcdc\udaae\ude9d\udad1\udcae\udbdd\udd40\uda5c\udd32\udbcd\udc06\000\000\ud98a\ude80\uda47\udeaf\uda4b\udf82", "\u7856\u25e6\u593c\u361b", "\ud9f3\ude96\ud9e0\udf92\ud999\ude1f\ud8b5\udc32\ud9e3\udd55\uda11\udd68\uda32\uded3",
        47, 36172, -686365775, 8942703966782682768L, -16241L, false, false, (char) 48269, (char) 23752,
        Double.longBitsToDouble(0x3ea3800a40000000L), Double.longBitsToDouble(0x3fe14f8000001121L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Integer:6\0121=java.lang.Integer:6\012",
        Z.run(T, 2, 8, 8, 16, "-\ud848\udcc3\ud97a\uddcf\ud8fd\ude5d\udb42\udfdc\ud8ef\udd97\uda5d\udf6f\udb5b\udf06\uda96\udf28\ud9c1\ude83\ud915\udfb2\ud94d\udea6\u0843\u75c2\uda4b\udf89\u2eab\udb99\udef0\ud8b5\udd39\udbcc\uddb1\ud9eb\ude32\udbe5\udf94\ud9f3\ude12\ud930\udc4a\udb73\udcdc\udaae\ude9d\udad1\udcae\udbdd\udd40\ud962\udf15\uda7f\udc9c\ud9e7\udf33\ud8a7\ude5e\ud98a\ude80\uda47\udeaf\uda4b\udf82", "\u7856\u25e6\u593c\u361b", "\ud9f3\ude96\ud9e0\udf92\ud999\ude1f\ud8b5\udc32\ud19f\uda3c\udc10\uda32\uded3\uda65\udecc\ud8b4\udfdf\udb26\udd47",
        6, 9552, -1242715030, 2322371763872695914L, -84958L, false, true, (char) 9496, (char) 45819,
        Double.longBitsToDouble(0x3fb844486f397120L), Double.longBitsToDouble(0x3fd65ccff9e68b82L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Long:-3168657649480205430\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 12, 16, "-\ud93c\udd1e\ud97a\uddf4\uda1f\udf55\ud866\udf92\ud8de\udf6c\uda5d\udf6f\udb5b\udf06\ud901\udefd\ud96f\udf1b\ud9dc\ude21\ud94d\udea6\ud918\ude0c\ud859\udf77\uda4b\udfbd\u2eab\udb99\udef0\ud8b5\udd39\udbcc\uddb1\ud9eb\ude32\udbe5\udf94\ud9f3\ude12\ud930\udc4a\udb73\udcdc\udaae\ude9d\ud8bd\ude64\ud9a6\udcbe\ud962\udf08\uda7f\udc9c\ud9e7\udf33\ud8ff\udde9\ud98a\ude80\uda26\udd88\ud959\udd7c", "\u7856\u25e6\u593c", "\udb9c\udebe\ud9f3\ude96\ud9e0\udf92",
        41, 3273, -1041949368, -3168657649480205430L, -47372L, false, true, (char) 46398, (char) 29354,
        Double.longBitsToDouble(0x3fbaa5e3868daf68L), Double.longBitsToDouble(0x3fdba543ad0d2c0eL)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Long:-2424022801914293283\0121=java.lang.Integer:26\012",
        Z.run(T, 2, 9, 8, 13, ".", "\u691f\u3683\u90e8", "\ud988\udf7a\udbae\udf4d\uda00\udebc\uda57\udd2f\ud82d\udc6c\ud94e\udfe2\u6322\ud8d0\udfb7\ud9a9\ude67",
        26, 4696, 1873027061, -2424022801914293283L, -1260L, false, true, (char) 4071, (char) 61709,
        Double.longBitsToDouble(0x3fee26a891c86454L), Double.longBitsToDouble(0x3fe598d584db3f61L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Long:33209649205346304\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"-\000\000\ud8fd\ude13\uda15\ude65\ud9ea\udded\ud8f5\udd9b\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "-\000\000\ud8fd\ude13\uda15\ude65\ud9ea\udded\ud8f5\udd9b", "\ua5ee\ua4ce\u1ccb\u2695\u7505\u95fd", "\ud8b5\udd39\udaf4\uded9\ud839\udde0\ud8df\ude48\ud9f3\ude12\ud930\udc4a\udb73\udcdc\ud947\ude58",
        57, 84783, 15139109, 33209649205346304L, 49125L, false, false, (char) 25043, (char) 6982,
        Double.longBitsToDouble(0x3fd60cd16a5e2c6aL), Double.longBitsToDouble(0x3fdaeb1a9a34221eL)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Long:8365674197816558787\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 12, 16, "-", "\ud34e\u2031\u0fe2\ud007\ud3d2\ub314\u1ca4\ua497\u1ccb\u2695\u7505\u95fd\u90f9\u5b05\u1604\u2d68\ua956\ua537", "\udb73\udcdc\udaae\ude9d\ud8bd\ude64",
        43, 44008, 141949981, 8365674197816558787L, -94152L, false, false, (char) 38581, (char) 51820,
        Double.longBitsToDouble(0x3fd2f163535d6352L), Double.longBitsToDouble(0x3fd1a110fd7fd0faL)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.Long:2534028101453390472\0121=java.lang.Long:2534028101453390472\012",
        Z.run(T, 2, 9, 9, 5, "-\ud93c\udd1e\ud97a\uddf4\ud921\ude59\udbd0\udd8f\ud8e2\udce8\uda5d\udf6f\udb5b\udf06\ud901\udefd\ud96f\udf1b\ud9dc\ude21\ud94d\udea6\ud918\ude0c\ud859\udf77\uda38\ude73\udbd5\udfba\udb99\udef0\ud8b5\udd39\udbcc\uddb1\ud9eb\ude32\udbe5\udf94\ud9f3\ude12\ud930\udc4a\udb73\udcdc\udaae\ude9d\ud8bd\ude64\ud9a6\udcbe\udbc8\udefb\uda7f\udc9c\ud9e7\udf33\ud8ff\udde9\udade\ude8b\uda99\ude7d\udb7c\udd28", "\uc920\u25e6\u593c\u9e1b\ub213\u3b1c\ubd68\u8a5c\u191a\u0a71\u73ac\u9e89\u2535\uca19\ub51e\u8524\u08f8\u12c7\u9c9f\u25b7\u5fce", "\uda75\udf56\ud839\ude99\udb6e\udd35\ud8aa\ude4a",
        22, 63781, 1765590319, 2534028101453390472L, 17839L, false, false, (char) 46957, (char) 37962,
        Double.longBitsToDouble(0x3fb96f2fbb86c6c0L), Double.longBitsToDouble(0x3fe2faae0cf7ce6cL)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.Long:-5644772648084876882\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 12, 16, "-\ud93c\udd1e\ud97a\uddf4\uda1f\udf55", "\ua5d8\ud3e5\ub314\u1ca4\ua941\u1d20\uc305\u0c41\u95fd\u90f9\u5b05\u1604\u2d68\ua956\ua537\u3f0c\u5d84\u793f\uaeaf\ucb35\u3a42", "\udb1e\ude15\ud8ff\ude10\ud98a\ude80\uda26\udd88",
        4, 96088, 372575584, -5644772648084876882L, -13663L, false, true, (char) 26491, (char) 48069,
        Double.longBitsToDouble(0x3fe7e370864ec619L), Double.longBitsToDouble(0x3fe58a9add486869L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 14, 5, 7, "\udb40\udfb1\udbb6\udef4\udb81\uddd2\ud808\udd34\udb64\udce5\uda1e\udd1a\udaf3\udd80\udab5\ude3a\ud829\udd4d\ud807\udd03\ud927\udc2a\ud98f\udd61\udac2\udf52\uda73\udf02\udb2d\udcbb", "\u8623\u0696\u0086\u021d\u9446\u18f3\u03c2\u2329\uc5bc\u5bb6\u2a2f\ua9d4\u28df\u49f9\ud0bd\u993b\ua269\u397a\u26e8\u9808\u2c02\ua2ca\u196e\u6a1e\u9b6d\u03ca\u7ac4\ua4a3\u1cb2", "\ud87e\udf02\ud96a\udfc4\udb20\udfc0",
        55, 24192, 1161733120, -4013409434405456455L, -49630L, false, true, (char) 47947, (char) 60080,
        Double.longBitsToDouble(0x3fe79a384e23284aL), Double.longBitsToDouble(0x3fe781faab739b1aL)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[C:[[\ud957, \udf04, \uda43, \udcb1, \ud934, \udd35, \ud857, \ude5c, \udae6, \ude9c, \udb58, \udf21, \udaf3, \udd80, \udab5, \ude3a, \ud829, \udd4d, \ud807, \udd03, \ud927, \udc2a, \ud98f, \udd61, \udac2, \udf52, \ud95d, \udfdd, \udb2d, \udcd9, \udb0f, \udc40, \ud978, \udfa2, \ub64d, \udb36, \udf73, \ud9f7, \ude9c, \ud9ca, \udc00, \u3f2c, \ud842, \ude7f, \uda2b, \ude4e, \ud877, \udc94, \ud8df, \udfb0, \ud8ba, \udec7, \uda8a, \uddbd, \udbc7, \udfb8, \u0d15, \udae0, \udc58, \ud961, \udc7a, \udbfa, \ude28, \u0180, \ud9af, \uddc6, \udbcf, \uded9, \ud866, \udc4f, \ud86f, \udfec, \uda2d, \udfbe, \udb83, \udc8b, \ud8eb, \udc08, \udb1d, \uddf1, \ud86d, \uddf1, \ud8b3, \ude41, \ud81b, \udc56, \ud9ed, \uddef, \uda7f, \uded4, \udafc, \udd97, \udaba, \udf9b, \udaa5, \ude1b, \udbc2, \udf7d, \ud8ca, \udd55...\0121=java.lang.Boolean:false |a0=[C:[[\ud957, \udf04, \uda43, \udcb1, \ud934, \udd35, \ud857, \ude5c, \udae6, \ude9c, \udb58, \udf21, \udaf3, \udd80, \udab5, \ude3a, \ud829, \udd4d, \ud807, \udd03, \ud927, \udc2a, \ud98f, \udd61, \udac2, \udf52, \ud95d, \udfdd, \udb2d, \udcd9, \udb0f, \udc40, \ud978, \udfa2, \ub64d, \udb36, \udf73, \ud9f7, \ude9c, \ud9ca, \udc00, \u3f2c, \ud842, \ude7f, \uda2b, \ude4e, \ud877, \udc94, \ud8df, \udfb0, \ud8ba, \udec7, \uda8a, \uddbd, \udbc7, \udfb8, \u0d15, \udae0, \udc58, \ud961, \udc7a, \udbfa, \ude28, \u0180, \ud9af, \uddc6, \udbcf, \uded9, \ud866, \udc4f, \ud86f, \udfec, \uda2d, \udfbe, \udb83, \udc8b, \ud8eb, \udc08, \udb1d, \uddf1, \ud86d, \uddf1, \ud8b3, \ude41, \ud81b, \udc56, \ud9ed, \uddef, \uda7f, \uded4, \udafc, \udd97, \udaba, \udf9b, \udaa5, \ude1b, \udbc2, \udf7d, \ud8ca, \udd55...\012",
        Z.run(T, 2, 5, 5, 1, "\ud957\udf04\uda43\udcb1\ud934\udd35\ud857\ude5c\udae6\ude9c\udb58\udf21\udaf3\udd80\udab5\ude3a\ud829\udd4d\ud807\udd03\ud927\udc2a\ud98f\udd61\udac2\udf52\ud95d\udfdd\udb2d\udcd9\udb0f\udc40\ud978\udfa2\ub64d\udb36\udf73\ud9f7\ude9c\ud9ca\udc00\u3f2c\ud842\ude7f\uda2b\ude4e\ud877\udc94\ud8df\udfb0\ud8ba\udec7\uda8a\uddbd\udbc7\udfb8\u0d15\udae0\udc58\ud961\udc7a\udbfa\ude28\u0180\ud9af\uddc6\udbcf\uded9\ud866\udc4f\ud86f\udfec\uda2d\udfbe\udb83\udc8b\ud8eb\udc08\udb1d\uddf1\ud86d\uddf1\ud8b3\ude41\ud81b\udc56\ud9ed\uddef\uda7f\uded4\udafc\udd97\udaba\udf9b\udaa5\ude1b\udbc2\udf7d\ud8ca\udd55\udaa2\udcbd\uda04\udf73\udbd1\udcc5\uda71\udc07\udb7f\udf75\ud93d\ude0d\ud863\udf98\ud810\udea5\uda02\udcfa\ud940\udcd8\udbce\udec9\ud991\udc73\udbe5\udccb\ud9fe\udd37\udb9c\udf8c\ud86b\uddd1\ud9f5\udf41\ud9eb\udfec\ud9a8\udda4\ud934\udec8\ud9b6\udcb9\ud833\ude5a\udbc9\uddb9\ud8d7\udcf0\udbb1\udd08\u0883\ud9d4\udc08\ud86e\udc83\ud90f\ude15\uda83\uddcc\ud9d0\udfec\udb1c\udc92\udb29\udc8b\ud908\uddb7\udaf7\uddb3\ud9d9\ude09\u80b1\ud9a6\udcec\u4883\udac5\uddc3\ua184\udbb3\ude6d\uda84\udc87\ud974\udce2\u1bb5\ud961\udee7\ud9ff\udf19\ud8b0\udcd9\ud817\udd07", "\u611d", "\udb83\udfda\uda5e\ude7b\udb9b\udd42\ud8a7\udf02\ud973\udd91\uda3d\udcfe\ud978\udd8e\ud916\udee8\udb6b\udf30\ud921\uddfe\udad4\udc61\udb06\udf08\uda49\udd76\udb68\udefd\uda61\ude35\ud8b3\udfce\ud827\udf93\udbb1\udc78\udb46\udce2\ud8a9\udc7f\uda29\udead\udb08\udf61\ud88f\udef3\udb46\udd09\ud993\udd9e\ud856\udc6c\uda74\udc25\ud8cc\udf5e\udb8c\udeba\udb25\ude13\ud8a3\udd16\ud8c4\udd1f\udaf8\udc74\ud9d0\ude9b\udbad\udf4c",
        21, 76604, 1157763813, -4557255658790708481L, 79916L, true, false, (char) 5133, (char) 62240,
        Double.longBitsToDouble(0x3fe78a6b51118c2bL), Double.longBitsToDouble(0x3fe95032b18b3477L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Double:0.6111760097426401\0121=java.lang.Double:0.6111760097426401\012",
        Z.run(T, 2, 7, 7, 12, "", "\u7cf7\u1054\u56c8\u93ca\u8af8\ud596", "\ud92e\uddc9\ud95b\udfa7\u3cf9",
        58, 42253, 58134, 2594073385365405879L, -74388L, false, true, (char) 14001, (char) 19463,
        Double.longBitsToDouble(0x3fe38ec0fdbe38a9L), Double.longBitsToDouble(0x3fec8096c69dafd7L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Double:0.2478519510923427\0121=java.lang.Double:0.2478519510923427\012",
        Z.run(T, 2, 7, 7, 10, "\ud8c7\udf68\ud81d\udeb5\udb66\udd08\ue66d\udbeb\udd79\ud804\udfc9\udb64\udc62\ud865\udec6\ud829\udd4d\ud837\udee5\ud92f\udf38\ud95b\udfa7\uda4b\udfb6\uda73\udf02\ud94c\udcc7\ud96e\udf36\ud8d7\udd10\udbf2\udc57\udb36\udf73", "\u7020\u87f2\u03c2\ua0c7", "\uda8a\uddbd\ud8fe\udc45\ud93f\udce8",
        39, 81286, -985780621, -3931989431511342482L, -10162L, false, false, (char) 18620, (char) 1554,
        Double.longBitsToDouble(0x3fcfb99cdc187fe8L), Double.longBitsToDouble(0x3fe1c7286543f950L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.math.BigDecimal:7 |a0=[C:[[7]]\0121=java.math.BigDecimal:7 |a0=[C:[[7]]\012",
        Z.run(T, 2, 1, 17, 16, "7", "\u4658\u7964\u8095\u0ef2\u2f99#", "\ud9bb\udd68\udac2\udf52",
        52, 42051, -602906876, -2729884361939019831L, 58755L, true, true, (char) 51655, (char) 61693,
        Double.longBitsToDouble(0x3fc3b1fb03700c68L), Double.longBitsToDouble(0x3feea64009c86454L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Long:494964359466\0121=java.lang.Long:494964359466\012",
        Z.run(T, 2, 9, 9, 18, "7\000\uda40\udf40\ud9fa\uddc0\udb42\udfdc\udaac\udc7f\udbd4\ude44\u18a6\ud988\udf7a\udb04\udc89\ud93b\udc6d\ud9bb\udd68\udad7\ude5e", "\u7ae0\u3bbc\000\u738e\uc076\u243c\ub759\u5a50", "\000\udbde\udd8d\uda8a\uddad\ud804\udf57\udad5\udeb8\000",
        58, 54093, 211, 494964359466L, -100000L, true, false, (char) 24201, (char) 2752,
        Double.longBitsToDouble(0x3fe5b004f2b7f079L), Double.longBitsToDouble(0x3fbc198d645613a8L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.Long:3294315452542253484\0121=java.lang.Long:3294315452542253484\012",
        Z.run(T, 2, 9, 9, 16, "+\udbd7\udeea\uda4e\udfae\ud9fa\uddc0\udb4a\udf4a\udacb\udc4a\ud9b5\udfb4", "\u90ea\u79a4\u1afc\uabd7\u3815\u7d5b\u7ae0\u1816\ub434\u0696\u65fc\u648a\u7629\u67e1\u19c9", "\ud8ba\udec7\uda8a\uddbd\ud8b7\udf71\ud897\udd13\ud874\udcb6\ud967\udf1b",
        53, 33462, -186913156, 3294315452542253484L, -69346L, false, false, (char) 26977, (char) 27151,
        Double.longBitsToDouble(0x3fe97796a9b332d2L), Double.longBitsToDouble(0x3fe5ab62c363919fL)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.Long:-2424022801906035747\0121=java.lang.NumberFormatException:java.lang.NumberFormatException: Value \"E\u2200\000\" can not be represented as BigDecimal\012",
        Z.run(T, 2, 9, 16, 16, "E\u2200\000", "\u3683", "\ud988\udf7a\udb26\ude2c\ud88c\udc96\uda1c\uddcb\udad7\ude46\ud9ab\udc1e\udbdc\udf05\ud988\uddcd\ud86b\ude53",
        7, 81235, 1873056805, -2424022801906035747L, -1260L, false, true, (char) 53713, (char) 25424,
        Double.longBitsToDouble(0x3fb3f54b7e4322a0L), Double.longBitsToDouble(0x3fe4deebeefe99beL)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.Long:6069254181536368234\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 12, 16, "0\ud848\udcc3\ud97a\uddf4\ud927\udcd6\udb42\udfdc\ud8ef\udd97\uda5d\udf6f\udb5b\udf06\ud901\udefd\u9f8d\ud969\udfcc\ud858\udf70\ud918\ude0c\uda5d\ude98\uda76\udef7\u2eab\udb80\udc23\ud8d8\udea0\u44b8\udb95\udda4\udbe5\udf94\ud9f3\ude12\ud9f2\udcec\udb2d\udf56\udaae\ude60\ud872\udf9f\uda5a\udd7e\udb68\udc1d\uda7f\udc9c\ud9e7\udf0e\ud8ff\udde9\ud98a\ude80\uda47\udeaf\uda4b\udf82", "\uc89d\u9974\u593c\u361b", "\ud8fb\ude9a\ud9e0\udf92\udb13\udc37\udbd1\udfe5\ud19f\ud8cc\udc58\udb0f\udfe5\udae3\udcc9\ud8b9\udddf\udb26\udd47",
        6, 9552, 39521638, 6069254181536368234L, -84958L, false, true, (char) 9496, (char) 45819,
        Double.longBitsToDouble(0x3fb844486f397120L), Double.longBitsToDouble(0x3fd65ccff9e68b82L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.Integer:-5\0121=java.lang.Integer:-5\012",
        Z.run(T, 2, 8, 8, 16, "-", "\ud34e\u2031\u0fe2\ud007\u26c4\ub314\u97a3\u044c\u1ccb\u2695\u7505\u95fd\025\000\ucd03\u2d68\ua956\ua537", "\udb73\udcdc\u00fc\000",
        -5, 44008, 141949981, 8365674197816558787L, -94152L, false, false, (char) 62127, (char) 51820,
        Double.longBitsToDouble(0x3fd2f16350000152L), Double.longBitsToDouble(0x3f9a110f001d0fa0L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.Long:169744144107459206\0121=java.lang.Integer:30\012",
        Z.run(T, 2, 9, 8, 8, "0\ud848\udcc3\ud97a\uddf4\ud927\udcd6\udb42\udfdc\ud8ef\udd97\uda5d\udf6f\udb5b\udf06\ud901\udefd\u9f8d\ud969\udfcc\ud858\udf70\ud918\ude0c\uda5d\ude98\uda76\udef7\u2eab\udb80\udc23\ud8d8\udea0\u44b8\udbac\udd0f\udbe5\udf94\ud9f3\ude12\ud9f2\udcec\udb2d\udf56\udaae\ude60\ud872\udf9f\uda5a\udd7e\ud884\ude5e\udac1\udf1f\ud9e7\udf0e\ud8ff\udde9\ud98a\ude80\uda47\udeaf\uda4b\udf82", "\uc89d\u9974\u593c\u1dbd", "\ud8fb\ude9a\ud9e0\udf92\udb13\udc37\udbd1\udfe5\ud19f\ud8cc\udc58\udb0f\udfe5\udae3\udcc9\ud8b9\udddf",
        30, 19521, -1752238448, 169744144107459206L, 21210L, false, true, (char) 7629, (char) 9496,
        Double.longBitsToDouble(0x3fe14f8690611121L), Double.longBitsToDouble(0x3fde72e242cb99feL)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.math.BigDecimal:7\0121=java.math.BigDecimal:7\012",
        Z.run(T, 2, 3, 19, 16, "7", "\u9e57\u08b3\uc175\u30aa\u8eda\ua190", "\uda54\ude78\udac2\udf66",
        30, 29787, 345016961, -2729884361939019831L, -37268L, true, false, (char) 37239, (char) 791,
        Double.longBitsToDouble(0x3feafbcedf2834b8L), Double.longBitsToDouble(0x3feab82ec614b73cL)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.Long:169744144107459206\0121=java.lang.Integer:30\012",
        Z.run(T, 2, 9, 8, 8, "0\000\000\000\000\000\000\000\ud8f2\udd78\u9f8d\ud969\udfcc\ud858\udf70\ud918\ude0c\uda5d\ude98\uda76\udef7\u2eab\udb80\udc23\ud8d8\udea0\u44b8\udbac\udd0f\udbe5\udf94\ud9f3\ude12\ud9f2\udcec\udb2d\udf56\udaae\ude60\ud872\udf9f\uda30\uddb7\ud884\ude5e\udac1\udf1f\ud9e7\udf0e\ud8ff\udde9\ud98a\ude80\uda47\udeaf\uda4b\udf82", "\uc89d\u9974\u593c\u1dbd", "\ud8fb\ude9a\ud9e0\udf92\udb13\udc37\udbd1\udfe5\ud19f\ud8cc\udc58\udb0f\udfe5\udae3\udcc9\ud8b9\udddf",
        30, 19521, -1752238448, 169744144107459206L, 21210L, false, true, (char) 7629, (char) 9496,
        Double.longBitsToDouble(0x3fe14f8690611121L), Double.longBitsToDouble(0x3fde72e242cb99feL)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=java.lang.Long:169744142041756038\0121=java.lang.Integer:30\012",
        Z.run(T, 2, 9, 8, 8, "0\000\000\000\u9700\ud9e8\udd77\u9a94\u41f0\ud8f2\udd78\udb0d\ude1e\ud969\udf88\ud858\udf70\ud918\ude0c\uda5d\ude98\uda76\udef7\u2eab\udb80\udc23\ud8d8\udea0\u44b8\ud829\udd14\udbe5\udf94\udbb7\uddb5\ud8da\udc10\udb2d\udf56\udaae\ude60\ud872\udf9f\uda30\uddb7\ud884\ude5e\udac1\udf1f\ud9e7\udf0e\ud8ff\udde9\ud98a\ude80\uda47\udeaf\uda4b\udf82", "\uc89d\u9974\u593c\u1dbd", "\ud8fb\ude9a\ud9e0\udf92\udb13\udc37\udb49\udf21\ud84e\udc8a\ud8a5\udf27\udb0f\udfe5\udae3\udcc9\ud8ae\udfdf",
        30, 19521, -1752238448, 169744142041756038L, 84742L, false, true, (char) 45819, (char) 14722,
        Double.longBitsToDouble(0x3fe31ff13add753aL), Double.longBitsToDouble(0x3fd7a1e47e5bd832L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=java.lang.Integer:7\0121=java.lang.Integer:7\012",
        Z.run(T, 2, 12, 12, 16, "7", "\u4658\u7964\u9aca\u6385\u9bee\uc8c0", "\ud9bb\udd68\ud8be\uddf1",
        -5, 26850, 1438605409, -2729881595980081207L, 58755L, true, true, (char) 51655, (char) 17376,
        Double.longBitsToDouble(0x3fcf40bb1852dc00L), Double.longBitsToDouble(0x3feea64009c8642eL)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=java.lang.Integer:7\0121=java.lang.Integer:7\012",
        Z.run(T, 2, 8, 8, 14, "7", "\u4658\u7964\u9aca\u6385\u8e87\u79cb", "\ud9bb\uddf8\ud8be\uddf1\ud8f1\udd86\udbca\udc9c\uda75\udd6e\ud9aa\udceb\udbc7\ude69\udb25\udc91\ud912\ude24\ud9d2\ude1f\udae0\udcda\ud82c\udee9\ud993\uddde\uda04\udd3d\ud8df\udfb0\ud8ca\udff1\ud986\uddbb\ud929\udfea\ud91a\ude8a\uda47\uddce\ud8a7\udf71\udb96\udf3d\u2ff1\udaca\udde5\udb23\ude51\ud87c\udc7c\uda3e\udd2f\uda9f\udc78\ud9cf\udf9c\ud879\udf1f",
        10, 15311, 288627574, 4968999525110157523L, 81088L, false, false, (char) 59396, (char) 45959,
        Double.longBitsToDouble(0x3fcc7b77cb7929d8L), Double.longBitsToDouble(0x3fc2a8a43056ec80L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=java.lang.Integer:14\0121=java.lang.Integer:14\012",
        Z.run(T, 2, 8, 8, 16, "7\000\uda40\udf40\uda28\udc96\u07c4\uda8b\udeac\ubbe4\u181f\ud988\udf7a\udb26\ude73\ud82c\udec1\000\uda99\udf6b", "\u7ae0\u2897y\u9db6\uc6fd\u243c\u3118\ucf36", "\000\udbde\udd8d\uda8a\uddad\ud804\udf5e",
        14, -1000, -1216727672, 553320954118275283L, 38006L, false, true, (char) 17644, (char) 52649,
        Double.longBitsToDouble(0x3fe802cbb28823a6L), Double.longBitsToDouble(0x3fe8d2351ef3c625L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=java.lang.Long:-4512377028484816316\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 1, 16, "I\udb88\udd44\uda66\udcae\ud9fa\uddc0\udafb\udd17\udb03\udcbc\udbd4\ude44\u18a6\udb1c\udf18", "\u8ed5\u47f3", "\udad5\udcad\ud8c0\ude6e\udbc7\ude69\udb36\udf73\ud87e\udc8c\ud8fa\ude63\ud893\udff4\ud913\udf82",
        -5, 39908, 869588168, -4512377028484816316L, -52865L, true, true, (char) 9136, (char) 46081,
        Double.longBitsToDouble(0x3fb9bedac1b3c440L), Double.longBitsToDouble(0x3f90e4a78ad674a0L)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=java.lang.Long:3089957146402086364\0121=java.lang.Long:3089957146402086364\012",
        Z.run(T, 2, 9, 9, 14, "I\033\uda66\udcae\ud961\udf20\udafb\udd17\ud808\udec3\udbd4\ude44\u18a6\ud9b8\udc26", "\u8f65", "\udb9f\udc25\udad5\udcad\ud8c0\ude6e\udbc7\ude69\udb36\udf73\ud87e\udc8c",
        44, 58965, 559904136, 3089957146402086364L, -46496L, false, false, (char) 44531, (char) 58421,
        Double.longBitsToDouble(0x3fd8132183e08380L), Double.longBitsToDouble(0x3fe4feeb1066fb6bL)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=java.lang.Double:7.0\0121=java.lang.Double:7.0\012",
        Z.run(T, 2, 10, 10, 14, "7", "\u4658\u245b\u9a65", "\ud8fd\ude03\udb52\udea6",
        30, 24429, -555834173, -2458943339668908231L, -2633L, true, true, (char) 19271, (char) 47042,
        Double.longBitsToDouble(0x3f9b6fcb8d1bcb80L), Double.longBitsToDouble(0x3feea0ebecefdcd8L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=java.lang.Long:7\0121=java.lang.Long:7\012",
        Z.run(T, 2, 14, 14, 13, "7", "\u9bb7\u245b\u165d", "\ud8fd\udda2\udb52\udea6",
        -3, 24500, -555834173, -2458943339374117121L, -2633L, true, true, (char) 19271, (char) 47042,
        Double.longBitsToDouble(0x3f9b6fcb8d1bcb80L), Double.longBitsToDouble(0x3feea0ebecefdcd8L)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Integer:-249305850 |a0=[C:[[\udb40, \udfb1, \udbb6, \udef4, \udb81, \uddd2, \udad0, \udcec, \ud91d, \ude7e, \udb59, \udc0c, \udaf3, \udd80, \udab5, \ude3a, \ud829, \udd4d, \ud9f1, \udcb1, \uee8f, \ud98f, \udd61, \ud8b9, \udfae, \uda25, \udcc6, \udb2d, \udc0b, \ud852, \udf22, \000, \ud843, \udfb7, \udb36, \udf73, \ud9f7, \uddb0, \uda69, \udeb6, \udb9a, \udef6, \udb6c, \udd26, \uda2b, \uddc2, \ud877, \udcf0, \ud92d, \udc76, \ud8ba, \udf07, \u00d4, \000, \ub200, \ud893, \udffc, \ud961, \udc7a, \udbfa, \ude28, \udb5a, \udf1a, \ud80f, \ude64, \ud9b0, \udd75, \uda77, \udffc, \uda59, \udca3, \ud8f2, \udcfa, \u2a05]]\012",
        Z.run(T, 2, 6, 11, 8, "\udb40\udfb1\udbb6\udef4\udb81\uddd2\udad0\udcec\ud91d\ude7e\udb59\udc0c\udaf3\udd80\udab5\ude3a\ud829\udd4d\ud9f1\udcb1\uee8f\ud98f\udd61\ud8b9\udfae\uda25\udcc6\udb2d\udc0b\ud852\udf22\000\ud843\udfb7\udb36\udf73\ud9f7\uddb0\uda69\udeb6\udb9a\udef6\udb6c\udd26\uda2b\uddc2\ud877\udcf0\ud92d\udc76\ud8ba\udf07\u00d4\000\ub200\ud893\udffc\ud961\udc7a\udbfa\ude28\udb5a\udf1a\ud80f\ude64\ud9b0\udd75\uda77\udffc\uda59\udca3\ud8f2\udcfa\u2a05", "\u2581\u3ebf\u9a2b", "\ud945\ude9f\uda40\udcba\ud843\ude0d\u088e\ud8e9\uddf9\ud9d8\udfd1\ud93e\ude8a\ud8e6\udc10\udbfa\ude17\ud934\udff0\uf75a\uda52\uddcd\udaee\ude77\ud830\udf5b",
        5, 11, -1272803065, 1411535894690715283L, 90866L, false, false, (char) 7327, (char) 21576,
        Double.longBitsToDouble(0x3febcaab74297e1dL), Double.longBitsToDouble(0x3fae87da82185050L)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 12, 0, "7\000\ud9c0\ude66\udb99\uded7\ud8a3\udccc\ud867\udc68\udbe0\udc28\ud9e5\uddeb\udaa1\uddf5", "\u84ca\u448a", "\uda75\udd34\ud9aa\udceb\udbc7\ude69",
        38, -13, -564386789, -3678996843777737733L, -96120L, false, true, (char) 1361, (char) 40603,
        Double.longBitsToDouble(0x3fcbec05cfb4ca6cL), Double.longBitsToDouble(0x3fe7056f75ddfaa3L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 12, 0, "7\000\ud9c0\ude66\udb99\uded7\ud8a3\udccc\ud867\udc68\udabc\udd56\ud939\udcf6\udaa1\uddf5", "\u7c08\u0df9", "\udbb1\udd32\ud87b\uddf7\udbc7\ude69",
        28, -13, -564386789, -3678996843777737733L, -96120L, false, true, (char) 1361, (char) 40603,
        Double.longBitsToDouble(0x3fcbec05cfb4ca6cL), Double.longBitsToDouble(0x3fe543d73dddfa9dL)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 11, 0, "\ud9d9\ude7d\udb71\udf42\ud9c0\udead\udb99\uded7\ud8a3\udccc\ud816\udcbf\udabc\udd42\ud9b7\udcf5\udaa1\uddf5", "\u7c08\u0df9", "\ud8bd\udd38\ud87b\uddf7\udbc7\ude69",
        28, -13, -564386789, -3678996843779965957L, -52550L, false, false, (char) 63756, (char) 11912,
        Double.longBitsToDouble(0x3fe543d73dddfa9dL), Double.longBitsToDouble(0x3fccea0b6015f70cL)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 13, 0, "7\000\ud9c0\ude66\udb99\uded7\ud85e\ude89\ud867\udc68\udabc\udd56\ud939\udcf6\udaa1\uddf5", "\u7c08\u0df9", "\udbb1\udd32\ud87b\uddf7\udbc7\ude69",
        28, -13, -564386789, -3678996843777737733L, -96120L, false, true, (char) 1361, (char) 40603,
        Double.longBitsToDouble(0x3fcbec05cfb4ca6cL), Double.longBitsToDouble(0x3fe543d73dddfa9dL)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Integer:1940657556 |a0=[C:[[\udb40, \udfb1, \udbb6, \udef4, \udb81, \uddd2, \udad0, \udcec, \ud91d, \ude7e, \udb59, \udc0c, \udaf3, \udd80, \udab5, \ude3a, \ud829, \udd4d, \ud9f1, \udcb1, \uee8f, \ud98f, \udd61, \ud8b9, \udfae, \uda25, \udcc6, \udb2d, \udc0b, \ud852, \udf22, \000, \ud843, \udfb7, \udb36, \udf73, \ud9f7, \uddb0, \uda69, \udeb6, \udb9a, \udef6, \udb6c, \udd26, \uda2b, \uddc2, \ud877, \udcf0, \ud92d, \udc76, \ud8ba, \udf07, \u00d4, \000, \ub200, \ud893, \udffc, \ud961, \udc7a, \udbfa, \ude28, \udb5a, \udf1a, \ud80f, \ude64, \ud930, \udcca, \uda77, \udffc, \uda59, \udca3, \ud8f2, \udcfa, \u2a05]]\012",
        Z.run(T, 2, 6, 11, 8, "\udb40\udfb1\udbb6\udef4\udb81\uddd2\udad0\udcec\ud91d\ude7e\udb59\udc0c\udaf3\udd80\udab5\ude3a\ud829\udd4d\ud9f1\udcb1\uee8f\ud98f\udd61\ud8b9\udfae\uda25\udcc6\udb2d\udc0b\ud852\udf22\000\ud843\udfb7\udb36\udf73\ud9f7\uddb0\uda69\udeb6\udb9a\udef6\udb6c\udd26\uda2b\uddc2\ud877\udcf0\ud92d\udc76\ud8ba\udf07\u00d4\000\ub200\ud893\udffc\ud961\udc7a\udbfa\ude28\udb5a\udf1a\ud80f\ude64\ud930\udcca\uda77\udffc\uda59\udca3\ud8f2\udcfa\u2a05", "\u2581\u3ebf\u9a2b", "\ud945\ude9f\uda40\udcba\ud843\ude0d\u088e\ud8e9\uddf9\ud9d8\udfd1\ud93e\ude8a\ud8e6\udc10\udbfa\ude17\ud934\udff0\uf75a\uda52\uddcd\udaee\ude77\ud830\udf5b",
        10, 6, -1272803065, 1411535894690715283L, 90866L, false, false, (char) 7327, (char) 21576,
        Double.longBitsToDouble(0x3febcaab74297e1dL), Double.longBitsToDouble(0x3fae87da82185050L)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 12, 0, "7\ua400\ud9c0\ude66\udb99\uded7\ud8a3\udccc\ud867\udc68\udbe0\udc28\ud9e5\uddeb\udaa1\uddf5", "\u84ca\ud1d2", "\uda75\udd34\ud9aa\udceb\udafc\ude03",
        4, 16, -564386789, -3678996843777700613L, -96120L, false, true, (char) 1361, (char) 40603,
        Double.longBitsToDouble(0x3fcbec05cfb4ca6cL), Double.longBitsToDouble(0x3fe7056f75ddfaa3L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=java.lang.Long:623361478962681 |a0=[C:[[\udb40, \udfb1, \udbb6, \udef4, \udb81, \uddd2, \udadc, \udee1, \ud91d, \ude7e, \udb59, \udc0c, \udbf4, \udc9f, \ud943, \udc0f, \ud84f, \udf80, \ud9f1, \udcb1, \udaa7, \udcc6, \ud98f, \udd61, \ud8b9, \udfae, \uda25, \udcc6, \udb2d, \udc0b, \ud852, \udf22, \ud89e, \uddaf, \ud826, \udd40, \udb36, \udf73, \ud9f7, \uddb0, \uda69, \udeb6, \udb9a, \udef6, \ud9e4, \uddc1, \uda19, \udf29, \ud877, \udcf0, \ud92d, \udc76, \ud8ba, \udf07, \u00d4, \000, \ub200, \ud893, \udffc, \ud961, \udc7a, \udbfa, \ude28, \udb5a, \udf1a, \ud80f, \ude64, \ud9b0, \udd75, \uda77, \udffc, \uda59, \udca3, \ud8f2, \udcfa, \u2a05]]\0121=java.lang.Integer:371696495 |a0=[C:[[\udb40, \udfb1, \udbb6, \udef4, \udb81, \uddd2, \udadc, \udee1, \ud91d, \ude7e, \udb59, \udc0c, \udbf4, \udc9f, \ud943, \udc0f, \ud84f, \udf80, \ud9f1, \udcb1, \udaa7, \udcc6, \ud98f, \udd61, \ud8b9, \udfae, \uda25, \udcc6, \udb2d, \udc0b, \ud852, \udf22, \ud89e, \uddaf, \ud826, \udd40, \udb36, \udf73, \ud9f7, \uddb0, \uda69, \udeb6, \udb9a, \udef6, \ud9e4, \uddc1, \uda19, \udf29, \ud877, \udcf0, \ud92d, \udc76, \ud8ba, \udf07, \u00d4, \000, \ub200, \ud893, \udffc, \ud961, \udc7a, \udbfa, \ude28, \udb5a, \udf1a, \ud80f, \ude64, \ud9b0, \udd75, \uda77, \udffc, \uda59, \udca3, \ud8f2, \udcfa, \u2a05]]\012",
        Z.run(T, 2, 13, 11, 8, "\udb40\udfb1\udbb6\udef4\udb81\uddd2\udadc\udee1\ud91d\ude7e\udb59\udc0c\udbf4\udc9f\ud943\udc0f\ud84f\udf80\ud9f1\udcb1\udaa7\udcc6\ud98f\udd61\ud8b9\udfae\uda25\udcc6\udb2d\udc0b\ud852\udf22\ud89e\uddaf\ud826\udd40\udb36\udf73\ud9f7\uddb0\uda69\udeb6\udb9a\udef6\ud9e4\uddc1\uda19\udf29\ud877\udcf0\ud92d\udc76\ud8ba\udf07\u00d4\000\ub200\ud893\udffc\ud961\udc7a\udbfa\ude28\udb5a\udf1a\ud80f\ude64\ud9b0\udd75\uda77\udffc\uda59\udca3\ud8f2\udcfa\u2a05", "\uc847\u3ebf\u9a2b", "\ud945\ude9f\uda40\udcba\ud843\ude0d\u088e\ud8e9\uddf9\ud9d8\udfd1\ud93e\ude8a\ud8e6\udc10\udbfa\ude17\ud934\udff0\udb01\udd5d\ud8c8\udd6a\udaee\ude77\udbd5\udfaf",
        5, 11, -1272803065, 1411535895579907731L, -98533L, true, true, (char) 7327, (char) 21576,
        Double.longBitsToDouble(0x3febcaab76297e1dL), Double.longBitsToDouble(0x3fae878282185050L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=java.lang.Integer:1940688535 |a0=[C:[[\udb40, \udfb1, \udbb6, \udef4, \udb81, \uddd2, \udad0, \udcec, \ud91d, \ude7e, \udb59, \udc0c, \udb12, \udd7a, \udb27, \udc09, \ud829, \udd4d, \ud9f1, \udcb1, \uee8f, \ud98f, \udd61, \ud8b9, \udfae, \uda25, \udcc6, \udb2d, \udc0b, \ud852, \udf22, \000, \ud843, \udfb7, \udb36, \udf73, \ud9f7, \uddb0, \uda69, \udeb6, \udb9a, \udef6, \udb6c, \udd26, \uda2b, \uddc2, \ud877, \udcf0, \ud92d, \udc76, \ud8ba, \udf07, \u00d4, \000, \ub200, \ud8bb, \udf2f, \ud961, \udcd0, \udbfa, \ude28, \ud88f, \udd15, \ud86a, \uddca, \ud930, \udcca, \uda77, \udffc, \uda59, \udca3, \ud8f2, \udcfa, \ud8e9, \udfb9]]\0121=java.lang.Integer:1940688535 |a0=[C:[[\udb40, \udfb1, \udbb6, \udef4, \udb81, \uddd2, \udad0, \udcec, \ud91d, \ude7e, \udb59, \udc0c, \udb12, \udd7a, \udb27, \udc09, \ud829, \udd4d, \ud9f1, \udcb1, \uee8f, \ud98f, \udd61, \ud8b9, \udfae, \uda25, \udcc6, \udb2d, \udc0b, \ud852, \udf22, \000, \ud843, \udfb7, \udb36, \udf73, \ud9f7, \uddb0, \uda69, \udeb6, \udb9a, \udef6, \udb6c, \udd26, \uda2b, \uddc2, \ud877, \udcf0, \ud92d, \udc76, \ud8ba, \udf07, \u00d4, \000, \ub200, \ud8bb, \udf2f, \ud961, \udcd0, \udbfa, \ude28, \ud88f, \udd15, \ud86a, \uddca, \ud930, \udcca, \uda77, \udffc, \uda59, \udca3, \ud8f2, \udcfa, \ud8e9, \udfb9]]\012",
        Z.run(T, 2, 11, 11, 8, "\udb40\udfb1\udbb6\udef4\udb81\uddd2\udad0\udcec\ud91d\ude7e\udb59\udc0c\udb12\udd7a\udb27\udc09\ud829\udd4d\ud9f1\udcb1\uee8f\ud98f\udd61\ud8b9\udfae\uda25\udcc6\udb2d\udc0b\ud852\udf22\000\ud843\udfb7\udb36\udf73\ud9f7\uddb0\uda69\udeb6\udb9a\udef6\udb6c\udd26\uda2b\uddc2\ud877\udcf0\ud92d\udc76\ud8ba\udf07\u00d4\000\ub200\ud8bb\udf2f\ud961\udcd0\udbfa\ude28\ud88f\udd15\ud86a\uddca\ud930\udcca\uda77\udffc\uda59\udca3\ud8f2\udcfa\ud8e9\udfb9", "\u2581\u3ebf\u9a2b\u59f2\ub8c3\u847a\u0f4f\u6f42\ubfa3\u2580\u07a1\u3aef\ud47c", "\ud806\ude06\udb80\ude42\udaee\ude77\ud830\udf5b",
        10, 6, -1272803065, 1411535894690715283L, 90866L, false, false, (char) 62140, (char) 21576,
        Double.longBitsToDouble(0x3febcaab74297e1dL), Double.longBitsToDouble(0x3fae87da82185050L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.io.NumberInput|_badBigDecimal|java.lang.String|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseBigDecimal|[C|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseBigDecimal|[C,int,int|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseBigDecimal|java.lang.String|static",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsDecimal||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.io.NumberInput|inLongRange|[C,int,int,boolean|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|inLongRange|java.lang.String,boolean|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseAsDouble|java.lang.String,double|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseAsInt|java.lang.String,int|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseAsLong|java.lang.String,long|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseDouble|java.lang.String|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseInt|[C,int,int|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseInt|java.lang.String|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseLong|[C,int,int|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseLong|java.lang.String|static",
    "C|com.fasterxml.jackson.core.io.NumberInput|<init>|",
    "M|com.fasterxml.jackson.core.io.NumberInput|_badBigDecimal|java.lang.String|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseBigDecimal|[C|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseBigDecimal|[C,int,int|static",
    "M|com.fasterxml.jackson.core.io.NumberInput|parseBigDecimal|java.lang.String|static",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsDecimal||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
