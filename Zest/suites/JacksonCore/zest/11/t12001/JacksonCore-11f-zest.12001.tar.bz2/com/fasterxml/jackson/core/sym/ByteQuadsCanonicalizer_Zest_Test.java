package com.fasterxml.jackson.core.sym;
import org.junit.Test;
import static org.junit.Assert.*;
public class ByteQuadsCanonicalizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 12, "\ud916\udc00\ud9fb\uddd5\udb8b\udca8\udb8f\udcb7\ud9e3\ude95\ud839\udd99\udb3b\ude85\udb47\udd39\ud94c\udc0f", "\u4f13\u567d\ua3a0\u313a\u73f7\u8e2e", "\ud839\udc20\uda2d\ude7f\ud839\udfac\ud918\uddb5\ud888\udd28\udaf8\udcaa\uda8a\udcee\udb66\udd75\uda69\udd2a\ud841\udd85\ud86c\udcdf\uda05\udcd7\ud8a1\udf35\u0c36\uda7a\ude08\ud9e6\udcc4\udb6d\udd72\uf613\ud990\ude56\udb3b\udfa8\udad5\udce5\ud9f8\udfed\ud929\uddee\udaa9\ude31\udba1\udee6\udb2a\udeb5",
        52, 77299, 1455865074, -2702075862735176436L, -87279L, true, false, (char) 18577, (char) 24091,
        Double.longBitsToDouble(0x3fc6454cc34eb358L), Double.longBitsToDouble(0x3fee2bd6e8c0a002L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 12, "\ud916\udc00", "\u5348\u4081\ub801\ua713", "\ud9c3\uddda\ud982\udc0a\udb0c\ude86\uda4e\ude3e",
        23, 99447, 1537783637, -8821892749629548470L, 24353L, false, false, (char) 18112, (char) 32701,
        Double.longBitsToDouble(0x3fe8c1fdc2ee9b42L), Double.longBitsToDouble(0x3fe5bb0ad1246980L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:[com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer: size=0, hashSize=0, 0/0/0/0 pri/sec/ter/spill (=0), total:0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 14, 12, "\ud916\udc00\ud9fb\uddd5\udb8b\udca8\udb8f\udcb7\ud9e3\ude95\ud839\udd99\udb3b\ude85\udb47\udd39\ud94c\udc0f", "\u4f13\u567d\u25a0\u313a\u73f7\u8e2e", "\ud83e\udc20\uda2d\ude7f\ud839\udfac\ud918\uddb5\ud888\udd28\udaf8\udcaa\uda8a\udcee\udb66\udd75\uda69\udd2a\ud841\udd85\ud86c\udcdf\uda05\udcd7\ud8a1\udf35\u0c36\uda7a\ude08\ud9e6\udcc4\udb6d\udd72\uf613\ud990\ude56\udb3b\udfa8\udad5\udce5\ud9f8\udfed\ud929\uddee\udaa9\ude31\udba1\udee6\udb2a\udeb5",
        52, 77299, 1449658610, -2702075862735176436L, -87279L, true, false, (char) 18577, (char) 24091,
        Double.longBitsToDouble(0x3fc6454cc34eb358L), Double.longBitsToDouble(0x3fee2bd6e8c0a002L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:[com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer: size=0, hashSize=0, 0/0/0/0 pri/sec/ter/spill (=0), total:0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 4, 8, "\ud916\udc00", "\u5348\u4081\ub801\u9e7c", "\ud9c3\uddda\ud982\udc0a\udb0e\udda9\uda4e\ude3e\udbe0\uded6\udaac\udf4b\udb3d\udcbb\udbe6\udc11\udb9f\ude26\ud879\udc41\ud839\udc20",
        40, 45976, 1069042984, -7259064722306436370L, -32124L, true, true, (char) 43000, (char) 21159,
        Double.longBitsToDouble(0x3fb6dbbe95e40408L), Double.longBitsToDouble(0x3fc4588500ffe35cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 12, "\ud916\udc00\ud9fb\uddd5\udb8b\udca8\udb8f\udcb7\ud9e3\ude95\ud839\udd99\udb3b\ude85\ud84b\udfc2\ud94c\udc0f", "\u4f13\u2784", "\udb3d\udca7\udbe6\udc11\udb9f\ude26\ud8ee\uded6\ud839\udc20\uda2d\ude7f\ud839\udfac\ud918\uddb5\ud88e\udf73\udaf8\udcaa\ud921\udfdb\uda0b\udd28\uda40\udcb5\ud841\udd85\ud86c\udcdf\uda05\udcd7",
        19, 89322, 327659746, 7090401907298723801L, -11837L, true, false, (char) 36160, (char) 22948,
        Double.longBitsToDouble(0x3fbcecb85b32e820L), Double.longBitsToDouble(0x3fd1ba7b0260c4b8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 12, "\ud916\udc00\ud9fb\uddd5\udb8b\udca8\udb8f\udcb7\ud827\udc18\ud856\udd61\ud93a\udfd4\udb43\udf0f\ud94c\udc0f", "\u4f13\u567d\ua3a0\u313a\u73f7\u8e2e", "\ud839\udc20\uda2d\ude7f\ud813\udc3a\uda94\udd07\ud888\uddef\udaf8\udcaa\uda8a\udcee\udb66\udd75\uda69\udd2a\ud841\udd85\ud86c\udcdf\uda05\udcd7\ud8a1\udf35\u0c36\uda7a\ude08\ud9e6\udcc4\udb6d\udd72\uf613\ud990\ude56\udb3b\udfa8\udad5\udce5\ud9f8\udfed\ud929\uddee\udaa9\ude31\udba1\udee6\udb2a\udeb5",
        52, 77299, 1455865074, -2702008826885620468L, -87279L, true, false, (char) 21335, (char) 24091,
        Double.longBitsToDouble(0x3fc6454cc34eb358L), Double.longBitsToDouble(0x3fee2bd6e8c0a002L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 12, "\ud916\udc00\ud9fb\uddd5\udb8b\udca8\ubeb3\ud9e3\ude95", "\uba64\u40fa\u1731\u28bd\u4f13\u2784\ua3a0\u4302\ua374\u0e27\u051e\u5e24\u9c9b\ud4b8\uc7be\u6179\u51fd\ub650", "\uda40\udcb5\ud841\udd85",
        53, 10330, -1003963716, -515824188942470942L, 90425L, true, true, (char) 26204, (char) 18545,
        Double.longBitsToDouble(0x3feb50ceb079192bL), Double.longBitsToDouble(0x3fbcecb85b32e820L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=void |this=com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:[com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer: size=0, hashSize=0, 0/0/0/0 pri/sec/ter/spill (=0), total:0]\012",
        Z.run(T, 2, 3, 13, 12, "\ud82b\ude40\ud9fb\uddd5\udb8b\udca8\udb8f\udcb7\ud9e3\ude95\ud839\udd99\udb3b\ude85\ud84b\udfc2\ud94c\udc0f", "\u4f13\u2784", "\udb3d\udca7\udbe6\udc11\udb9f\ude26\udac1\udd00\ud839\udc20\uda2d\ude7f\ud839\udfac\ud918\uddb5\ud88e\udf73\udaf8\udcaa\ud921\udfdb\uda2b\udf38\udba6\uddfc\ud841\udd85\ud86c\udcdf\uda05\udcd7",
        19, 89322, 327659746, 7090401907298723801L, -11837L, false, true, (char) 36053, (char) 18340,
        Double.longBitsToDouble(0x3fe74c47f62bd9c6L), Double.longBitsToDouble(0x3fd1ee5d77e423c4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:4\012",
        Z.run(T, 1, 3, 14, 12, "\ud916\udc00\ud9fb\uddd5\udb8b\udca8\udb8f\udcb7\ud9e3\ude95\ud839\udd99\udb3b\ude85\ud84b\udfc2\ud94c\udc0f", "\u4f13\u2784", "\udb3d\udca7\udbe6\udc11\udb9f\ude26\ud8ee\uded6\ud839\udc20\uda2d\ude7f\ud839\udfac\ud918\uddb5\ud88e\udf73\udaf8\udcaa\ud921\udfdb\uda0b\udd28\uda40\udcb5\ud841\udd85\ud86c\udcdf\uda05\udcd7",
        19, 89322, 327659746, 7090401907298723801L, -11837L, true, false, (char) 36160, (char) 22948,
        Double.longBitsToDouble(0x3fbcecb84f72e820L), Double.longBitsToDouble(0x3fc9bd3a24c18a80L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=java.lang.Integer:4\012",
        Z.run(T, 2, 3, 3, 0, "\ud916\udc00\ud9fb\uddd5\udb8b\udca8\udb8f\udcb7\ud9e3\ude95\ud839\udd99\udb3b\ude85\ud84b\udfc2\ud94c\udc0f", "\u4f13\u2784", "\udb3d\udca7\udbe6\udc11\udb9f\ude26\ud8ee\uded6\ud839\udc20\uda2d\ude7f\ud839\udfac\ud918\uddb5\ud88e\udf73\udaf8\udcaa\ud921\udfdb\uda0b\udd28\uda40\udcb5\ud841\udd85\ud86c\udcdf\uda05\udcd7",
        19, 89322, 327659746, 7090401907298723801L, -11837L, true, false, (char) 36160, (char) 22948,
        Double.longBitsToDouble(0x3fbcecb85b32e820L), Double.longBitsToDouble(0x3fd1ba7b0260c4b8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=java.lang.Integer:4\012",
        Z.run(T, 2, 3, 3, 12, "\udba6\udea3\ud9ee\udd8f\udb8b\udca8\ubeb3\ud9e3\ude95", "\uba64\u035a\u8993\u28bd\u4f13\uac40\u8b59\u4302\u93ed\u6c6d\u4dd3\u2dc3\u9029\ud4b8\ua4be\u6179\u3bc3\uba84", "\uda40\udcb5\ud841\udd85",
        53, 10330, -1003963716, -515824187348635422L, 90215L, true, true, (char) 26204, (char) 24383,
        Double.longBitsToDouble(0x3feb547eb079192bL), Double.longBitsToDouble(0x3fbcecb877af8940L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 12, "\ud916\udc00\ud9fb\uddd5\udb8b\udca8\udb76\udeda\ud9e3\ude95\ud839\udd99\udb3b\ude85\udb47\udd39\ud94c\udc0f", "\u4f13\u567d\ua3a0\u313a\u73f7\u8e2e", "\ud839\udc20\uda2d\ude7f\ud839\udfac\ud918\uddb5\ud888\udd28\udaf8\udcaa\uda71\udeee\udb66\udd75\uda69\udd2a\ud841\udd85\ud86c\udcdf\uda05\udcd7\ud8a1\udf35\u0c36\uda7a\ude08\ud9e6\udcc4\udb6d\udd72\uf613\ud990\ude56\udb3b\udfa8\udad5\udce5\ud9f8\udfed\ud929\uddee\udaa9\ude31\udba1\udee6\udb2a\udeb5",
        52, 77299, 1455865074, -2702075862735176436L, -87279L, true, false, (char) 18577, (char) 24091,
        Double.longBitsToDouble(0x3fc6454cc34eb358L), Double.longBitsToDouble(0x3f3eb74000000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_verifySharing||new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_appendLongName|[I,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_calcOffset|int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_calcTertiaryShift|int|static",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findOffsetForAdd|int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findSecondary|int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findSecondary|int,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findSecondary|int,int,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_findSecondary|int,int,[I,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_reportTooManyCollisions||new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_spilloverStart||new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_verifyLongName|[I,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_verifyLongName2|[I,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_verifyNeedForRehash||new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|addName|java.lang.String,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|addName|java.lang.String,int,int|new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
    "M|com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer|_verifySharing||new:com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer:int,boolean,int,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
