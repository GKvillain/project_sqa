package com.fasterxml.jackson.core.json;
import org.junit.Test;
import static org.junit.Assert.*;
public class UTF8StreamJsonParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 8, 15, "\udb41\udfbd\udb86\udf7e\ud925\udfaf\udaba\udf2b\udbcc\uded8\ud80f\udc62\udb4e\udcec\udb4f\udf14", "\u6705", "\udb2c\udc5c\uda7d\udfe0\uda1e\udcf1\udaa4\uddb8\ud9a7\udc55\ud88d\udc32\u8f8b\udb83\udcf5\uda75\udc25\ud8b3\udc0a\uda65\udee5\ud883\udf2a\udab4\udc4e\u2be6\udb23\ude0e\ud95e\udf8c",
        23, 99887, 1759594013, 1081365689436251530L, 48L, false, true, (char) 32544, (char) 32753,
        Double.longBitsToDouble(0x3feb62d80da526b5L), Double.longBitsToDouble(0x3fe58f5397b9a6c0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 15, 15, "\udb41\udfbd\udb86\udf7e\ud848\udf51\ud84a\udfe4\udbb5\udfd8\ud80f\udc62", "\u65fc", "\uda43\udd97\ud964\uded8\ud811\udc0f\uda7d\udfe0\ud820\uddd1\ud912\udc4b\udb76\udc23\udb70\udc0f\ud93c\udc11\udb83\udcf5\uda75\udc25\ud8b3\udc0a\uda65\udee5\ud867\udc5c\ud910\ude6b\ud997\udf86\ud8b9\udf4e\ud958\udc54\uc18f\udb4e\udd81\ud8f1\udc4b",
        34, 88106, -1794528378, 7822322851772762934L, -34300L, false, true, (char) 48217, (char) 4103,
        Double.longBitsToDouble(0x3fb8fdb962627678L), Double.longBitsToDouble(0x3fe41ff9caec94e2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 15, "\ud8c9\udeb2\udb86\udf7e\ud925\udfaf\ud9e2\uddd4\udb95\udd5d\ud80f\udc62\udb4e\udcec\udb4f\udf14\udbff\ude85\ud87a\udff9", "\u2157\u979d\u6ab2\u5c7c\u6ff5\u794c\uc919\ub00c\ub8dd\uce58\u479c\u1c6a\uce8b\u3d3d\uc07b\uaa0a\u8b76\u355f\ua642\uca6a\u4226\ubc3a\u3cc0\u61d9\uca91", "\udbe4\uddb3\udb5b\udc5f\ud9fc\udd6e\ud8c2\udce2\uda43\uddad\udb19\udffa\ud874\udfd9\uda08\udc89\uda58\udc1b\udbf4\udc01\uda43\udf32\udbe6\ude8a\udad0\ude52\ud917\udff5\udbf3\udf06\ud8f3\udcdb\udac7\udd03",
        48, 13753, -1381977176, 6131628096786976953L, 74145L, true, true, (char) 29454, (char) 44577,
        Double.longBitsToDouble(0x3fe7ac499609c6b1L), Double.longBitsToDouble(0x3fe91a9dfd389644L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 0, "\udb41\udfbd\udb78\udfbf\ud925\udfaf\udaba\udf2b\udbcc\uded8\ud825\udd62\ud80d\udd2b\udb4f\udf14\udbff\ude85\ud87a\udff9", "\ud20c\u979d\u6ab2\u5c7c\u6ff5\ud526\ua315\uafe6\u689b\uce58\u479c\u1c6a\uc03c\u1e72\u5f5d\ucc39\u8b76\u355f\ua642\uca6a\u4226\ubc3a\u3cc0\u61d9\uca91\ua3cb\ua47f\ubc3d\u3a22", "\ud8f1\udc68\ud894\udcb5\ud9d4\udd96\udbdf\udebb\ud836\ude46\ud94c\udc0f\udadd\ude7c\udbdc\udc3f\ud98b\udf62\ud8e4\udfdb\udb71\udffe\ud9c5\ude25",
        50, 53992, 1983721030, 2002016293853153604L, -79211L, false, false, (char) 34933, (char) 65178,
        Double.longBitsToDouble(0x3fe1233ebce92d80L), Double.longBitsToDouble(0x3fd73bb7aead8cfeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 15, "\udb41\udfbd\udb86\udf7e\ud925\udfaf\udaba\udf2b\udbcc\uded8\ud80f\udc62\udb4e\udcec\udb4f\udf14", "\u6705", "\udb2c\udc5c\uda7d\udfe0\uda1e\udcf1\udaa4\uddb8\ud9a7\udc55\ud88d\udc32\u8f8b\udb83\udcf5\uda75\udc25\ud8b3\udc0a\uda65\udee5\ud883\udf2a\udab4\udc4e\u2be6\udb23\ude0e\ud95e\udf8c",
        23, 99887, 1759594013, 1081366333681345930L, 48L, false, true, (char) 32544, (char) 32753,
        Double.longBitsToDouble(0x3feb62d80da526b5L), Double.longBitsToDouble(0x3fe58f5397b9a6c0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 9, 15, "\udb41\udf66\udbce\udc22\udacd\udef8\udaba\udf2b\udbcc\uded8\ud80f\udc62\uda7a\udcac\udb31\udf21\ud8e7\udc88\ud852\udfda\uda83\udc6b\udb38\udf29\udaf7\udca6\uda67\udc04\ud854\ude01\udb14\udc21\udaa4\uddb8", "\uafe6\u689b\uce58\u5049\ubc1e\u4c33\u362a", "\ud908\udf84\ud80d\ude49\uda6b\udecf\udb99\udc62\ud978\uddd2",
        46, 38622, 1821276464, 8229496222781345003L, -14132L, true, true, (char) 34449, (char) 2928,
        Double.longBitsToDouble(0x3fe23906c973bdf8L), Double.longBitsToDouble(0x3fe58345b20d9b18L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|<init>|com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_closeInput||new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_decodeBase64|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_decodeCharForError|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_decodeEscaped||new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_decodeUtf8_2|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_decodeUtf8_3|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_decodeUtf8_3fast|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_decodeUtf8_4|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_finishString||new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_finishString2|[C,int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_getText2|com.fasterxml.jackson.core.JsonToken|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_handleApos||new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_handleInvalidNumberStart|int,boolean|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_handleOddName|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_handleUnexpectedValue|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "C|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|<init>|com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
