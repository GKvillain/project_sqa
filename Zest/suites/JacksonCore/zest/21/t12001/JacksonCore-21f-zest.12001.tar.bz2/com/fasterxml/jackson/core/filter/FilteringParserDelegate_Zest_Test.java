package com.fasterxml.jackson.core.filter;
import org.junit.Test;
import static org.junit.Assert.*;
public class FilteringParserDelegate_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 5, "\ud832\udc02\ud972\udc6d\uda10\ude4a\udba0\udcf7", "\u8815\u8ff0\uc923\u188a", "\udb5d\uddce\ud96c\udc32\ud8db\udec4",
        28, 61576, 853876173, 1458735177489356363L, 1651L, true, true, (char) 49858, (char) 38167,
        Double.longBitsToDouble(0x3fee3ea72dddc013L), Double.longBitsToDouble(0x3fcc6bb997ec78acL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 5, "\ud832\udc02\ud972\udc6d\uda10\ude4a\udba0\udcf7", "\uc3f4\uc409\ua5d6\u188a", "\udb5d\uddce\ud96c\udc32\ud8db\udec4",
        28, 61576, 853876173, 1458735177489356363L, 1651L, true, true, (char) 49858, (char) 38167,
        Double.longBitsToDouble(0x3fee3ea72dddc013L), Double.longBitsToDouble(0x3fcc6bb997ec78acL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 5, "\ud832\udc02\ud972\udc6d\uda10\ude4a\udba0\udcf7", "\u8815\u8ff0\uc923\u188a", "\udb5d\uddce\ud96c\udc32\ud8db\udec4",
        40, 61637, 853876173, 1458735177489356363L, 1651L, true, true, (char) 49858, (char) 38167,
        Double.longBitsToDouble(0x3fee3ea72dddc013L), Double.longBitsToDouble(0x3fcc6bb997ec78acL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 6, 14, 15, "\ud82a\udc7a\ud99f\udf43\udbf3\udd2c\udb76\udf45\udadf\udd4c\uda77\udeb5\udae7\ude91\uda4c\udec2\ud93c\ude5b\ud8e6\ude78\ud918\uddc8\ud825\udfab\udb5d\ude9d\ud96c\udc32\ud8db\udec4\uda5a\ude65\udb55\udd3b\udb48\udccc\ud982\udd1b\udb50\udebf\ud880\udcfa\ud89a\ude78\uae5f\udb5f\udc43\udaab\udf8f\uda3b\udc02\ud83a\udf64\ud883\udeaa\uda42\udf05\udaf8\udf09\ud835\udccc\u96e9\udbe5\uddb2\udaf1\udd13\ud846\udcac\udad0\udeef\ud92f\udd8a\udb6e\udd66\ud99f\udde5\uda3a\udd99\uda62\udee7\ud853\udfda\uda05\udf43\ud812\udce6", "\u087c\ua564\u3270\u35b8\u7b28\uc3ba\u0351\u9150\u4e1d\u05cf\ub63a\u6d93\u03f3\ubc79\uc51e", "\ud8ab\udd7b\ud94e\udf78\ud8ea\udef6\udb10\udf0f\ud9db\ude9d\udb6d\udc70\ud800\udf08\ud95c\udc3b\ud8f8\udfd4\udb87\udc47\uda33\ude6c\udae1\udffb\ud894\udcb4\ud950\ude0f\udb2f\udc9e\udb40\udea9\ud923\udc58\ud916\udcd5\ud93a\udd38\udbd8\udc3e\uda60\udde8\udabe\uddfc\udb9d\udfd6\ud8ee\udf5c\udb4d\udd0b\udbfb\udff8\ud905\udc68\udb20\udf64\ud8a9\udc9c\uda14\udc88\ud960\udfce\udab9\udfb7\udbbf\udcb0\udaca\udc7b\ud98b\uddf9\uda69\udf26\ud828\udff3",
        41, 39775, 829469929, 6335617894358125169L, -25359L, false, false, (char) 20718, (char) 3889,
        Double.longBitsToDouble(0x3fcc5cd2d65c3194L), Double.longBitsToDouble(0x3fd775641d230822L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 6, 13, 3, "\ud832\udc02\ud972\udc6d\ud81c\udc4e\udba0\udce4\udbb0\udd71\udb92\udcba\ud82a\ude5a\uda5a\udd9b\ud93c\ude5b\ud879\udc42\ud94f\udc21\ud802\udcaf\udb5d\uddce\ud96c\udc32", "\u48ef\u6c1f\u3fe8\uc7ea\u721b\ucb1f", "\udabf\ude93",
        31, 853, 288083176, -1705434012594733823L, 48323L, true, false, (char) 25935, (char) 24141,
        Double.longBitsToDouble(0x3fcb6c59f2792decL), Double.longBitsToDouble(0x3fc24f85080bec7cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 5, "\036\udad6\udf00\uda4e\udc06\udb98\udd4b", "\u8815", "\ud8e6\ude78\ud918\uddc8\000\000\000",
        -5, 56000, 0, 3602879702236035050L, -34411L, true, true, (char) 53120, (char) 0,
        Double.longBitsToDouble(0x3fd1e4300f8fa9caL), Double.longBitsToDouble(0x3fdddc0139c6bb98L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 6, 7, 6, "\uda80\uddcc\ud820\udd7c\ud80e\uddf5\udb97\ude9d", "\ud06e\uaff9\u48d8\u13a9\ub541", "\ud9b7\uded5\ud8db\udec4\uda5a\ude65\udb55\udd3b\u76b9\udaa5\udc0c\udb50\udebf\uda9d\udf22\ud89a\ude2e\ud890\udd8d\ud84f\ude53\udabf\ude93",
        49, 10893, 506186979, -2137320884689458657L, -61855L, true, false, (char) 12776, (char) 22711,
        Double.longBitsToDouble(0x3fe2de8f8c96ae24L), Double.longBitsToDouble(0x3fe6a9334084b398L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 5, "\ud832\udc02\ud972\udc6d\uda10\ude4a\udba0\udcf7", "\u8815\u8ff0\u7942\u188a", "\ud9f5\udec2",
        29, 16102, 1622068403, -8464308618804257331L, -61525L, true, false, (char) 26532, (char) 30607,
        Double.longBitsToDouble(0x3fee4fa8c8668452L), Double.longBitsToDouble(0x3fee3ea7f5ddc013L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 7, "\ud83a\udcc0\ud972\udc6d\uda10\ude4a\udba0\udcf7\ucd58\ud8b4\udf77", "\uc923\u188a\u9bc6\u03bc\u76ad\ucd4c\u7e2a\uaeb1\u8c62\u2a1f\u3fe8\u4d40\u0202\u5b25\ua973\u4274\u8607\u2403\u997a", "\ud8ac\ude00\ud8cc\ude9b\ud9b7\udf96\udb95\ude63\ud8c9\udcef\ud928\udf49\ud902\udc42\ud88e\udee6",
        22, 57022, -182103717, 6475580856714217170L, -27097L, false, false, (char) 1257, (char) 26474,
        Double.longBitsToDouble(0x3fe48e44fcba8e6aL), Double.longBitsToDouble(0x3fd0198c18c8d180L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 6, 5, 11, "\ud832\udc02\ud972\udc6d\uda10\ude4a\uda55\udeef", "\u8815\u8ff0\uc923\u188a", "\udb5d\uddce\ud96c\udc32\ud8db\udec4",
        28, 61576, 853876173, 1458735177489356363L, 1651L, true, true, (char) 14442, (char) 12793,
        Double.longBitsToDouble(0x3fee3ea72dddc013L), Double.longBitsToDouble(0x3fcc6bb997ec78acL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 6, 1, 2, "\ud832\udc02\ud972\udc6d\uda10\ude4a\udae2\udeda\udb0c\udd83\uda29\udcf7\udafc\udc23\uda5a\udd9f\udad1\ude0e\ud8b4\udedc\udaff\udd10\u18a2\udac6\udda6", "\u36d3\u7410\u2a1f\u3fe8\uc7ea\u0bc5\u5ae0", "\ud496\uda3b\udc02\ud83a\udec8\ud883\udeaa\u35a9\uda07\ude83",
        19, 1362, 1355649533, -8749738043082666593L, 1343L, true, true, (char) 51445, (char) 2975,
        Double.longBitsToDouble(0x3fdeb88a25735d36L), Double.longBitsToDouble(0x3fe15aa9b7668889L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 4, "\ud832\udc02\ud972\udc6d\ud9d6\udde9\ud8e4\udc84", "\u0f45\ucdd9\u3a44\u1855\u9bc6\u03bc\u9f40", "\uda5a\ude65",
        41, 21173, 339638250, 5448957850083196981L, 55556L, false, true, (char) 22746, (char) 58540,
        Double.longBitsToDouble(0x3fdddc0137c6bb98L), Double.longBitsToDouble(0x3fc79a5b05847a60L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 1, 15, 5, "\ud832\udc02\ud972\udc6d\uda10\ude4a\ud92d\udfd2", "\u6b57\u2a60\uc923\u7410", "\udb5d\uddce\ud96c\udc32\ud8db\udec4",
        28, 80176, 853876173, 3074515459226113611L, -5308L, false, true, (char) 5293, (char) 12,
        Double.longBitsToDouble(0x3fcc6bb997ec78acL), Double.longBitsToDouble(0x3fe9859f17251de5L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 13, 13, 3, "\ud832\udc02\ud972\udc6d\ud81c\udc4e\udba0\udce4\udbb0\udd71\udb92\udcba\ud82a\ude5a\uda5a\udd9b\ud93c\ude5b\ud879\udc42\ud94f\udc21\ud802\udcaf\udb5d\uddce\ud96c\udc32", "\u48ef\u6c1f\u3fe8\uc7ea\u721b\ucb1f", "\udabf\ude93",
        31, 853, 288083176, -1705434012594733823L, 48323L, true, false, (char) 25935, (char) 24141,
        Double.longBitsToDouble(0x3fcb6c59f2792decL), Double.longBitsToDouble(0x3fc24f85080bec7cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 5, 5, 3, "\ud832\udc02\ud972\udc6d\ud81c\udc4e\udba0\udce4\udbb0\udd71\udb92\udcba\ud82a\ude5a\uda5a\udd9b\ud93c\ude5b\ud879\udc42\ud94f\udc21\ud802\udcaf\udb5d\uddce\ud96c\udc32", "\u48ef\u6c1f\u3fe8\uc7ea\u721b\ucb1f", "\udabf\ude93",
        31, 853, 288083176, -1705434012594733823L, 48323L, true, false, (char) 25935, (char) 24141,
        Double.longBitsToDouble(0x3fcb6c59f2792decL), Double.longBitsToDouble(0x3fc24f85080bec7cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 1, 1, 5, "\u5e32\udad6\udf00\uda4e\udc06\ub0f6", "\u8815", "\udb49\udeb7\ud804\udf8f\ud9a0\udeac\000\000",
        -5, 56000, 0, 3602879702236035050L, -34411L, true, true, (char) 53120, (char) 17956,
        Double.longBitsToDouble(0x3fd1e430001ec844L), Double.longBitsToDouble(0x3fe48b8ebce3b427L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 5, "\ud832\udc02\u3cee\udae8\udd35\udba0\udcca", "\u8815\u8ff0\ud688\u940b", "\udb5d\uddce\ud96c\udc32\ud8db\udec4\uda5a\ude65\udb55\udd3b\udb48\udccc\ud982\udd1b\udb50\udebf\uda9d\udf22\ud9de\udf10\uda73\udcea\ud9e1\udd42\udabf\ude93\uda3b\udc02\uda5a\udf7d\ud883\udeaa\ud86d\udf1a",
        51, 22424, 506490586, 7133381262946450801L, 31081L, false, false, (char) 2817, (char) 6357,
        Double.longBitsToDouble(0x3fe03819414f71efL), Double.longBitsToDouble(0x3fe02b38a744869bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|nextToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_filterContext||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextBuffered|com.fasterxml.jackson.core.filter.TokenFilterContext|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextToken2||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextTokenWithBuffering|com.fasterxml.jackson.core.filter.TokenFilterContext|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|clearCurrentToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|currentToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|currentTokenId||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getBigIntegerValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getBinaryValue|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getBooleanValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getByteValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentLocation||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentName||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentTokenId||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|nextToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
