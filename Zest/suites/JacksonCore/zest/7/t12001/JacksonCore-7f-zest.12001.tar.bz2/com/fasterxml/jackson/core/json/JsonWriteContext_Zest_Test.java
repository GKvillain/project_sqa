package com.fasterxml.jackson.core.json;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonWriteContext_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\u90f7\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\012",
        Z.run(T, 2, 8, 9, 11, "\udbcd\ude4d\uda5b\udcc6\uda3b\udce8\udbd1\udefc\ud8f6\ude1b\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\udb2e\ude3c\ud931\uddf9", "\ub590\ud08a\u98d7\ua2ed\uacc8\uc75d\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\u82e6\u9944\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 6142200510086525476L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 10, "\udbcd\ude4d\udb61\udfa9\ud966\udd22\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\u0894\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud8fc\udfe3\udbe0\udee5\ud956\uddcf\uda29\udf5c\ud913\udf22\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=void |a0=java.lang.StringBuilder:\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud814\udd71\ud931\ude7d/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 0, 2, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud814\udd71\ud931\ude7d", "\ub590\ud08a\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\u55a8\ubddd\u2443\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\udadd\ude53\ud85a\uddea",
        24, 74881, 1459752565, -9000855776835958009L, 49787L, true, false, (char) 47414, (char) 28191,
        Double.longBitsToDouble(0x3fb0cf9ca3a41b40L), Double.longBitsToDouble(0x3fb5fa0818c092d8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 8, 11, 8, "\uda31\udc5b\udb18\uddaa\ud830\udd99\udbd1\udee2\ud8f6\ude1b\udac2\udf9a\ud90b\udfe4\ud843\udec1\udb1a\udd9f\u8017\udadd\ude64\ud81f\udc63\ud931\ude7d", "\ub590\ub6b3\u04c0\u9e7f\u40cf\u4bbd\ua512\u522c\uc2a0\u874b\u2d26\u1e54\u680f\u81a1\u85c0\u38e7\u0f50\u57f0\u6107\ua909\ud088\ua10e\u2914", "\ud8d4\udc38\uda64\ude2f",
        35, 23154, 1873626092, 941204642053885557L, 49787L, false, false, (char) 47414, (char) 28191,
        Double.longBitsToDouble(0x3fecd72cac7c838aL), Double.longBitsToDouble(0x3fd40e8206302556L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 8, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbcd\udcdb\ud8db\udceb\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9e1\udcf8",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fdc2d29cac8012cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u55d3\ud001\u1e54\uae79\ua703\u86e0\uc9e6\u0f50\u57f0\u60d9\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 8, 6, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d\ua87f\ud86c\udfba\uda86\uddfc\ud9d3\udd74\ud988\udde3\ud862\ude67\uda51\udd67\ud91e\udf2b\ud8ef\udd26\ud8fa\udc7a\ud924\udf59\ud983\udfc4\uda0b\udcf4\udb79\udd47\ud8cd\udd40\udb74\udca5\ud992\udc01\udb88\ude71\uda4b\udf34\udaae\udefa\udb56\udf2a\ua65b\ud8e9\udce6\ud80a\udec6\udb3e\ude44\udb54\udeb1", "\ua7cf\u5299\u2dc6", "\ud8fb\uddd0\ud8c5\udefa\uda8d\ude28\udbf6\udfbb\ud867\ude1d\ud83c\udf8a",
        -1, 55068, 824738377, 4499726010280405059L, -41719L, false, true, (char) 38749, (char) 3423,
        Double.longBitsToDouble(0x3fd64001d5da3f1cL), Double.longBitsToDouble(0x3fd20c5512cb3942L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 8, 0, 1, "\udbcd\ude4d\uda5b\udcc6\uda80\udd3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u98d7\ua2ed\u7472\ubde1\u2b52\u522c\uc2a0\u86f1\ud0a5\u1e54\ubd96\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\u5b7d\ub120\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb4b\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fee1694e564f268L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\0121=void |a0=java.lang.StringBuilder:\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd6\ude60\ud8e8\udc45\ud8e5\udf99\udbc4\udd55\uda3a\udd1c\ud924\udf9f\uda35\udcd2\ud87b\udeae\ud81f\udd1c\ud931\ude7d{?} |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\012",
        Z.run(T, 2, 8, 2, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd6\ude60\ud8e8\udc45\ud8e5\udf99\udbc4\udd55\uda3a\udd1c\ud924\udf9f\uda35\udcd2\ud87b\udeae\ud81f\udd1c\ud931\ude7d", "\ub590\u74e7\ua2d7\ua2ed\u7472\u5fd5\u2b52\u1f2c\uc2a0\u874b\ud0a5\u1e54\u4e2e\u6915\u85ba\uc9e6\u0f50\u57f0\uce4a\ub038\ud088\u8b7f\u410e", "\udaf9\udf09\ud9e5\udd5d\udb8f\udfea\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf\uda8a\udf8c\ud867\ude1d\uda97\udf13\ud910\udf4a\ud8c1\udcd3\uda6d\udd2e\ud82e\udca5\ud9a5\udcee\udb52\udf13\uda2e\udd56\uefb2\ud8da\udebe\uda44\udf90\udb73\ude0c\ud9e5\udf6d\ud8fc\udd1d\ud889\udc34\uda07\ude46",
        2, 84835, 2136169143, -1343472493325832115L, -6113L, false, false, (char) 21260, (char) 59984,
        Double.longBitsToDouble(0x3fe48edd1e2a2e21L), Double.longBitsToDouble(0x3fa9c67a5c581ef0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:{?} |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 8, 4, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\u03e2\uda33\uded2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\u6c2a\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\udb7b\udff9\ud869\udd02\udbe0\udee5\udb3c\ude80\ud807\udf68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 1, 8, 0, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud99f\udf96\udbc4\udd55\ud843\udec1\016\uda35\udc85\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u2924\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ub1d5\000\000\ua66b\u00f0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\ud8a6\udff6\ud84a\udcc4\uda86\udf95\ud9e8\uddff\007",
        14, 72861, -687129100, 6185050758848590372L, 46432L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fc85a5394000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 10, "\udbcd\ude4d\uda5b\udcc6\ud97f\udf0b\uda3e\ude62\ud8f6\ude4b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\ud8a3\udec8\udadd\ude33\ud81f\udc63\udbcd\udf79", "\ub590\ud08a\u78d8\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\ucb5c\uae79\ua703\u85c0\uc9e6\u9196\u8de3\u81da\ua578\ua120\u1216\u9257", "\ud8d4\udf48\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud85d\udd76\uda86\udf95\ud9e8\uddff\ud841\udc42\udb7b\udda2\ud867\ude1d\ud83c\udf8a\udbcc\udff3",
        52, 47570, 1047674103, -8962941426269057924L, 11448L, false, true, (char) 53545, (char) 34176,
        Double.longBitsToDouble(0x3fe4d2febbcd732aL), Double.longBitsToDouble(0x3fd416b4afb76ed8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:[0] |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 3, 15, 6, "\udbcd\ude4d\uda5b\udcc6\ud93a\udf79\udbd1\udefc\udb44\udc43\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\u3ef4\ud0d4\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\u5820\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\uda9f\ude11\udb39\udf5b\ud801\udd68\ud928\udd27\ud9e8\uddff\ud9f4\udfaf\uda8a\udf8c\ud867\ude1d\ud83c\udf8a\udbcc\udff3\udac7\udd60\uda6d\udd2e\ud82e\udca5\ud9a5\udcee\udb52\udf13\udbb1\udd6b\udac7\udfb8\ud8da\udebe",
        31, 85045, -809370944, 3607377670058159855L, 81423L, false, false, (char) 3128, (char) 19263,
        Double.longBitsToDouble(0x3f736145d262a280L), Double.longBitsToDouble(0x3fdde2a25cffe9e8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\u9061\u3233\u98d7\uc2c2\uca70\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\ud0e9\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\uddab\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\udbb9\ude4e\udab9\ude10\ud82f\ude39",
        52, 72861, -687129100, 3449958410151146106L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:[0]\0121=com.fasterxml.jackson.core.json.JsonWriteContext:[0] |this=com.fasterxml.jackson.core.json.JsonWriteContext:[0]\012",
        Z.run(T, 2, 0, 11, 10, "\ud990\udde3\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55", "\ub575\u24e3\u0620\u6df5\u5b72", "\ud9d3\udd74\ud988\uddd3\ud862\ude67\uda51\udd67\udab3\udf56\udb57\udebf",
        1, 14769, 2018855085, -5905677300227912283L, -60728L, false, true, (char) 18246, (char) 52582,
        Double.longBitsToDouble(0x3fcb80e647799f60L), Double.longBitsToDouble(0x3fa5dd05e0382170L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=void |a0=java.lang.StringBuilder:\udbfa\udcff\uda5b\udc9f\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\u0267\udbc4\udd55\ud843\udec1\ud934\ude2b\ud81b\ude04/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 5, 2, 6, "\udbfa\udcff\uda5b\udc9f\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\u0267\udbc4\udd55\ud843\udec1\ud934\ude2b\ud81b\ude04", "\u1ed8\u5b92\u8424\ub590\ud08a\u98d7\ubec7\u7472\u5fd5\u2b52\u522c\uc2a0\u01aa", "\ud8f5\udc02\udb74\udca5\ud992\udc01\udb88\ude71\uda4b\udf34\udaae\udefa\udb56\udfdb",
        55, 77486, -1657072535, 9087672890317329695L, -35115L, false, true, (char) 51219, (char) 45873,
        Double.longBitsToDouble(0x3fe76213dca39de0L), Double.longBitsToDouble(0x3fe3a8687c5c5702L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:[0] |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:[0] |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 3, 3, 11, "\udbcd\ude4d\uda5b\udcc6\ud9c9\udcc1\udbc6\udc2d\ud8f6\ude1b\ub4e9\udb32\uddc0\ud843\udec1\ud934\ude2b\ud9de\udcc6\udb88\udd8e\ud81f\udc63\ud931\ude7d", "\ud666\uc3ea\u98d7\uc24b\u7472\u03b0\u6ea9\ucec0\uc2a0\u874b\uaab9\u0bc3\u8f1c\u25ab\u1cd2\u47a4\uc7b4\u3397\ub83f\u8152\ud265\u8b7f\u410e", "\ud9cb\udceb\udb5d\udef7\ud869\udc90\udbe0\udee5\udb3c\ude80\ud801\udd68\ud9d8\udd5d\udb1d\udf13\ufdb2",
        52, 72861, -214417932, 6167197988548391460L, -82345L, false, true, (char) 3972, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092df6ba856L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=java.lang.Integer:3 |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 0, 0, 10, "\udbcd\ude4d\000\000\udbd1\ude72\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\udd7b\ud81f\udc63\uda4f\udccb", "\u506a]\u6fb3\ua2ed\u7472\u5fd5\u2b52\u522c\u0989\000\ud0a5\u06a0\u17b4\u66b8", "\uda4b\udf34",
        32, 42046, -2105092864, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fef6213dca36fadL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 10, "\udaa0\udcd6\uda5b\udd88\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud932\udf7d", "\ub590\ud08a\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\u2c75\u2c52\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e727001dL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 5, 6, 14, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\udb0e\udc08\udbcd\udfee\udbf2\udfc3", "\u9189\u344b\u873f\u5dd2\u3e1f", "\ud9d3\udd74\ud988\udde3\udbde\udf5d\uda50\udc6d\ud91e\udf2b\ud8ef\udd26",
        6, 14769, 2018855085, -5905677300227912283L, -60728L, false, true, (char) 18197, (char) 52582,
        Double.longBitsToDouble(0x3fef703991de67d8L), Double.longBitsToDouble(0x3fdc09a0bc07050cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 6, 11, 15, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\ud8dd\udea6\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\ucfd3\ua84a\uaa14\u4f15\u8b94\ua6b5\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\udb3c\udefd\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3feb281ada46ef56L), Double.longBitsToDouble(0x3fe611bfb564001dL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:{?} |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 4, 14, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u9379\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8bbc\u410e", "\ud89d\udd38\u3763\udbf1\udfee\ud85c\ude22\udbbe\ude8b\udbda\udf9c\uda9c\uddf8\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -2089075212, 6185050110308528676L, 15465L, false, false, (char) 12455, (char) 16020,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udbbb\uddc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\udb2e\ude3c\ud931\uddf9\"}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udbbb\uddc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\udb2e\ude3c\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 9, 11, "\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udbbb\uddc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\udb2e\ude3c\ud931\uddf9", "\u19cc\ud08a\u98d7\ua2ed\uacc8\uc75d\u2b52\u522c\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ub213\u9944\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 6142200510807945764L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\0121=java.lang.Integer:5 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\012",
        Z.run(T, 2, 8, 0, 11, "\udbcd\ude4d\udbc6\udc3c\uda3b\udc74\udbd1\udefc\udbfa\udc11\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\udb2e\ude3c\udae2\uddb1", "\u6526]\000\000\uaca1\uc75d\u2b52\u21fe\u0089\u874b\ud0a5\u00a5\uae79\ua703\u00f0\000\000\000\000\uab48\u82e6\u9944\u6b80", "\udb8e\udea6\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\udbb7\udca3\000\ud884\udca2\ud9f4\udfaf",
        2, 72861, 360726004, 6142200510086525476L, 46679L, true, false, (char) 157, (char) 1112,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e5000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbb5\udd80\uda5b\udcc6\uda3b\udce8\udbd1\udefc\ud96d\ude13\ud8b9\udeaf\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\ud96b\udf3b\ud931\ude50\"}\012",
        Z.run(T, 2, 8, 15, 11, "\udbb5\udd80\uda5b\udcc6\uda3b\udce8\udbd1\udefc\ud96d\ude13\ud8b9\udeaf\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\ud96b\udf3b\ud931\ude50", "\ub590\u579c\uba30\ube32\u555c\u890a\u926d\uc964\uc2a0\u874b\ud0a5\u1e54\u2168\ua703\u85c0\uc9e6\u0f50\u57f0\u744a\u6505\u6d65\u9944\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 561528308, 6142200510086525476L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\0121=java.lang.Integer:5 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\012",
        Z.run(T, 2, 0, 0, 11, "\udbcd\ude4d\uda5b\udcc6\uda3b\udce8\udbd1\udefc\ud8f6\ude1b\udbba\ude24\udb20\udfa1\000\000\uda0b\udd85\udb73\udcf0\udb2e\ude3c\ud931\uddf9", "\u506a\ud08a\u98d7\ua2ed\uacc8\uc75d\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\u82e6\u7544\u6b80", "\udb8e\udf31\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9d2\udca8",
        2, 72861, 360726004, 6142200510086525476L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 10, "\udbcd\ude4d\udb61\udfa9\ud966\udd22\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\udae8\uddc8\uda96\udd92", "\ub590\u0894\u98d7\u3622\u38e3\u5fd5\u2b52\u1ac3(\u86b0\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\ud7e7\u8a41\u7adc\ub62c\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud8fc\udfe3\udbe0\udee5\ud956\uddcf\uda29\udf5c\ud913\udf22\ud9e8\uddff\ud9f4\udfaf",
        47, 1241, -687129100, -6199285266466830226L, 15465L, true, false, (char) 36184, (char) 1144,
        Double.longBitsToDouble(0x3fe8c0905d6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 12, 15, 5, "\ud824\udd46\udb61\udfa9\ud824\udde2\uda2b\udc4a\udad1\ude3a\udb04\uddc1\ud9b1\udc45\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\u0894\u992e\ua2ed\u7472\u5fd5\u2b52\u522c\uc22a\u5404\u12dd\u6c1a\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd91\uda64\ude2f\ud8fc\udfe3\udbe0\udee5\ud956\uddcf\uda74\ude21\ud8c5\ude9b\ud9b9\udebe\ud9f4\udfaf",
        52, 72861, -401916428, 6142221714340065828L, -84393L, true, false, (char) 4008, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=void |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 12, 12, 10, "\udbcd\ude4d\udb61\udfa9\uda2f\ude24\udbd1\udefc\ud8f6\ude1b\ud9ff\udfc6\udaa8\udff8\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\u0894\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\u4fa3\ubaa2\uaebc\ua703", "\ud83a\uddac\udbc1\udcaa\udb56\udfdb",
        53, 54379, -465879959, -6219559753416190685L, -35115L, false, true, (char) 3092, (char) 25644,
        Double.longBitsToDouble(0x3fe31cfdf3ce3102L), Double.longBitsToDouble(0x3fc6b693657285b8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=void |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 12, 12, 10, "\ubc7e\uda8d\udc93\ud966\udd22\udbd1\udefc\ud8f6\ude1b\udb35\udfa1\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\u0894\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\uda51\udc0e\udac0\uddea\ud80a\udc0e\uda50\udfe7\uda42\udec6\ud90d\udef4\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 10, "\udbcd\ude4d\udb61\udfa9\ud94b\udcf8\uda87\udeb2\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\u0894\u9912\ua2ed\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u5ea4\u4153", "\ud89d\udd38\uda64\ude2f\ud9d3\udd8d\udbe2\uded2\ud956\uddcf\uda29\udf5c\ud913\udf22\udb37\udff6\uda19\udc13",
        13, 62355, -679292695, 6185050157553168932L, 46679L, true, false, (char) 4121, (char) 59511,
        Double.longBitsToDouble(0x3fdfcbe7a39830feL), Double.longBitsToDouble(0x3fe611c21d64001dL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 11, 11, 8, "\uda31\udc46\udb32\udeaa\udb2b\udd99\udbd1\udee2\ud8f6\ude1b\udac2\udf9a\ud90b\udfe4\ud843\udec1\udb1a\udd9f\u5826\udb47\udf88\ud828\udeeb\ud9e9\udf9a", "\u196b\ub6b3\u1b44\u9e85\u40cf\ubb5d\u2da2\u7acd\uc2a0\u874b\u9466\u1b1d\u680f\ub9a1\u85c0\u3f9c\u0f47\u57f0\u9314\ua909\ud088\ua10e\u5ee1", "\ud8d3\ude95\uda64\ude2f",
        56, 15114, -590186057, 941017901170822773L, 1234L, false, false, (char) 51180, (char) 40214,
        Double.longBitsToDouble(0x3fef9046f256bbe9L), Double.longBitsToDouble(0x3fe249b770f73128L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 1, 8, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbcd\udcdb\ud8db\udceb\ud8c1\udfc7\udb41\udfa0\ud843\udeb3\ud934\ude2b\uda35\udcd2\udadd\uddde\ud81f\udc63\ud9dc\udc92", "\ub590\ud08a\u98d7\ua2ed\u7472\u5fd5\u8c5b\u5239\u6656\u400c\ub866\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9e1\udcf8",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fdc2d29cac8012cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:{?} |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:{?} |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 4, 4, 11, "\udbcd\ude4d\ud8b3\udfb3\uda7b\ude3a\udbcd\udcdb\ud8db\udceb\ud8e5\udf99\udbc4\udd55\udb8e\udd27\ud934\udecb\uda35\udcd2\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u98d7\ua2ed\u43c8", "\ud8fa\udc7a",
        -1, 66085, -1375022647, -444785830064683621L, -43152L, false, true, (char) 52588, (char) 50189,
        Double.longBitsToDouble(0x3fddeab19b813416L), Double.longBitsToDouble(0x3fe01c14346974e0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 5, 5, 10, "\udbcd\ude4d\uda5b\udcc6\ud97f\udf0b\uda3e\ude62\ud8f6\ude4b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud9a6\ude24\ud9d7\udda2\ud910\udcb3\udbaa\ude31\udbcd\uded4", "\ub590\ud08a\u716f\u8f46\u7472\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u0193\u4713\ua707\u85c0\uc219\u9196\u8de3\u81da\u8d71\ua120\u1216\u9257", "\ud8d4\udf48\uda64\ude2f\ud88d\udf02\udbe0\udee5\udb3c\ude80\uda36\udd7c\ud856\udcbd\ud9e8\uddff\ud8d9\udc2f\udae2\ude19\uef33\ud860\udde3\udbcc\udff3",
        52, 47570, 1047674103, -8962941426269057835L, 11448L, false, true, (char) 47089, (char) 34138,
        Double.longBitsToDouble(0x3fa42febbcd9d530L), Double.longBitsToDouble(0x3fcf773bbeb5a104L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=java.lang.Integer:4 |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 15, 15, 13, "\udbcd\ude4d\uda5b\udcc6\ud931\udc15\udb16\udc55\udb44\udc43\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\uda35\udcd2\ud89d\uddde\ud81f\udc63\uda9a\udece", "\u3ef4\u0ad5\u98d7\ua2ed\u8144\u5fd5\u2b52\u522c\uc2a0\u874b\u5820\u1e54\uae79\u71be\u2d66\u720e\u0f0d\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud9bf\ude1b\uda9f\uddb5\udb39\udf5b\ud801\udd68\ud928\udd27\ud9e8\ude9a\ud9f4\udfaf\udb3a\udfb2\ud867\ude1d\ud83c\udf8a\udbcc\udff3\udac7\udd60\uda6d\udd2e\ud82e\udca5\ud9a5\udcee\udb52\udf13\udbb1\udd6b\udac1\udfb8\ud8da\udebe",
        31, 85045, -809370944, 3607377670058159855L, 81423L, false, false, (char) 62263, (char) 32761,
        Double.longBitsToDouble(0x3f736145d262a280L), Double.longBitsToDouble(0x3fdde2a25cfe04a4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:[0] |this=com.fasterxml.jackson.core.json.JsonWriteContext:[0]\0121=com.fasterxml.jackson.core.json.JsonWriteContext:[0] |this=com.fasterxml.jackson.core.json.JsonWriteContext:[0]\012",
        Z.run(T, 2, 14, 11, 10, "\ud9e8\udf9c\uda5b\udcc6\ud81e\udd38\udbdc\udc95\ud9aa\ude15\udac3\ude0a\u1a3f", "\ub575\u600e\ua409\u13cd\u7a63\ub958", "\ud9b8\udd1a\uda5c\udee3\ud80e\ude01\udaca\udfaa\ud926\udf92\uda02\udcd7\udb61\uded5\udaeb\udef8\uda8e\udc68",
        1, 74995, 868318360, -4804441996963806585L, -39876L, true, false, (char) 51867, (char) 11112,
        Double.longBitsToDouble(0x3fe9835d1025c2e8L), Double.longBitsToDouble(0x3fe4982402ce58dcL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:[0]\0121=java.lang.Integer:1 |this=com.fasterxml.jackson.core.json.JsonWriteContext:[1]\012",
        Z.run(T, 2, 0, 0, 10, "\ud990\udde3\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55", "\ub575\u24e3\u0620\u6df5\u5b72", "\ud9d3\udd74\ud988\uddd3\ud862\ude67\uda51\udd67\udab3\udf56\udb57\udebf",
        1, 14769, 2018855085, -5905677300227912283L, -60728L, false, true, (char) 18246, (char) 43622,
        Double.longBitsToDouble(0x3fa9f6b91dee0d80L), Double.longBitsToDouble(0x3fd1eb40bdfeb48cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 11, 11, 15, "\udbcd\ude4d\uda5b\udcc6\ud9ae\udead\udbc5\udd88\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\ud8dd\udea6\udadd\uddde\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\u98d7\ua2ed\u7472\u5fd5\u2b52\u522c\ucfd3\ua84a\uaa14\u4f15\u8b94\ua6b5\ub4a3\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u44e9", "\udb3c\udefd\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848590372L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3feb281ada46ef56L), Double.longBitsToDouble(0x3fe611bfb564001dL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udba7\udcc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ue50e\uda0b\udd85\ud86d\udced\udb2e\ude3c\ud931\uddf9\"}\0121=java.lang.Integer:2 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udba7\udcc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ue50e\uda0b\udd85\ud86d\udced\udb2e\ude3c\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 0, 0, "\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udba7\udcc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ue50e\uda0b\udd85\ud86d\udced\udb2e\ude3c\ud931\uddf9", "\u506a\ud08a\u98d7\ua204\uacc8\uc75d\u2b52\u522c\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\u672a\u0f50\u57f0\u6107\uae5f\ub119\u9944\u6b80", "\ud90e\ude91\uda64\ude2d\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 6142200509164945408L, 46679L, true, false, (char) 4121, (char) 7287,
        Double.longBitsToDouble(0x3eb6c00000000000L), Double.longBitsToDouble(0x3fe000000564001dL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udbbb\uddc7\udb8b\udcea\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\udb2e\ude3c\ud931\uddf9\"}\0121=java.lang.Integer:4 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udbbb\uddc7\udb8b\udcea\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\udb2e\ude3c\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 15, 11, "\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udbbb\uddc7\udb8b\udcea\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\udb73\udcf0\udb2e\ude3c\ud931\uddf9", "\u19cc\ud08a\u98d7\ua2ed\uacc8\u97ac\015\u522c\uc2a0\u86f4\ud0a5\u38fe\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\u65f0\u9c6e\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 84357, 360726004, -5531129723336379693L, 46679L, true, false, (char) 4121, (char) 29890,
        Double.longBitsToDouble(0x3fe8c0f73d6bc656L), Double.longBitsToDouble(0x3fe61694e78df41dL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9\"}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 9, 11, "\udbcd\ude4d\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9", "\u19cc\ud08a\u98d7\ua2ed\uacc8\uc75d\u2b52\u522c\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\u00c0\u4119\u9944\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 6142200510807945764L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3f4a539590000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ud969\udd4a\uda5b\udcee\udb3b\udd96\udbbb\udd9e\ud8f6\ude1e\ud91a\udd06\ud9e1\udcef\ud9ee\udfe8\uda20\udf82\ud90f\udcc3\udb30\ude38\udb2e\ude3c\ud931\uddf9\ua87f\ud86c\udfba\uda95\ude37\ud9d3\udd74\ud9e7\udda7\ud986\udee7\ud9eb\udff7\ud902\udeb4\ud8ef\udd26\udb9f\ude2d\ud8e9\udc62\ud983\udf6d\"}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ud969\udd4a\uda5b\udcee\udb3b\udd96\udbbb\udd9e\ud8f6\ude1e\ud91a\udd06\ud9e1\udcef\ud9ee\udfe8\uda20\udf82\ud90f\udcc3\udb30\ude38\udb2e\ude3c\ud931\uddf9\ua87f\ud86c\udfba\uda95\ude37\ud9d3\udd74\ud9e7\udda7\ud986\udee7\ud9eb\udff7\ud902\udeb4\ud8ef\udd26\udb9f\ude2d\ud8e9\udc62\ud983\udf6d\"}\012",
        Z.run(T, 2, 15, 9, 11, "\ud969\udd4a\uda5b\udcee\udb3b\udd96\udbbb\udd9e\ud8f6\ude1e\ud91a\udd06\ud9e1\udcef\ud9ee\udfe8\uda20\udf82\ud90f\udcc3\udb30\ude38\udb2e\ude3c\ud931\uddf9\ua87f\ud86c\udfba\uda95\ude37\ud9d3\udd74\ud9e7\udda7\ud986\udee7\ud9eb\udff7\ud902\udeb4\ud8ef\udd26\udb9f\ude2d\ud8e9\udc62\ud983\udf6d", "\uae79\ua703\u85c0\u4575\u0f74\u57f0\u6107\ua909\u4247\u993c\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\uda4a\udc2f\ud9f4\udfaf",
        2, 72861, 360726004, 6142200509525733924L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\u00b5\ud8f6\udd85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\ua74d\000\udaf3\ude19<\"}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\u00b5\ud8f6\udd85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\ua74d\000\udaf3\ude19<\"}\012",
        Z.run(T, 2, 15, 9, 0, "\udbcd\ude4d\uda5b\udcee\udb04\udc1b\u00b5\ud8f6\udd85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\ua74d\000\udaf3\ude19<", "\u19cc\ud08a\u98d7\ua2ed\uacc8\u6ae1\u62ad\u522c\uc2a0\u86f4\ud1c9\ucda5\ua979\u404b\u85c0\uc9e6\u0f50\u57f0\000\000\000\000\u6b80", "\u008b\uda64\ude2f\ud896\udfd8\000\000\000\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 8404468, 6142065468446224932L, 46679L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe80000006bc656L), Double.longBitsToDouble(0x3fe000000564001dL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udbbb\uddc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\udb2e\ude3c\ud931\uddf9\"}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udbbb\uddc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\udb2e\ude3c\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 9, 11, "\udbcd\ude4d\uda5b\udcee\udb04\udc1b\udbbb\uddc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\udb2e\ude3c\ud931\uddf9", "\u19cc\ud08a\u98d7\ua2ed\uacc8\uc75d\ub13e\000\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ub213\u9944\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 6142200510807945764L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:{?} |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\0121=com.fasterxml.jackson.core.json.JsonWriteContext:{?} |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\012",
        Z.run(T, 2, 4, 4, 11, "\udbcd\ude4d\ud8b3\udfb3\uda7b\ude3a\udbcd\udcdb\ud8db\udceb\ud8e5\udf99\udbc4\udd55\udb8e\udc99\ud934\udecb\uda35\udcd2\ud894\udfde\ud81f\udc63\ud931\ude7d", "\ub5d1\ud08a\u98d7\ua2ed\u43c8", "\ud8fa\udc7a\uda05\udf4a\ud983\udf94\uda0b\udcf4\udb79\udd47\udaed\udc10\udb74\udca5",
        2, 82734, 120768200, -6117650965200801314L, -81169L, true, false, (char) 5356, (char) 44329,
        Double.longBitsToDouble(0x3fee39045c06d1a1L), Double.longBitsToDouble(0x3fe203f2422e8d15L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ufdff\uda5b\udcee\udb8f\udf00\000\000\000\000\000\000\000\ud86d\udced\udb2e\ude3c\ud931\uddf9\"}\0121=java.lang.Integer:2 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ufdff\uda5b\udcee\udb8f\udf00\000\000\000\000\000\000\000\ud86d\udced\udb2e\ude3c\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 0, 0, "\ufdff\uda5b\udcee\udb8f\udf00\000\000\000\000\000\000\000\ud86d\udced\udb2e\ude3c\ud931\uddf9", "\u506a\ud08a\u98d7\ua204\u4e14\u00e1\u2b52\u522c\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\u672a\u214f\u57f0\u6107\uae5f\ub119\u2448\000", "\ud90e\ude91\uda64\ude2d\ud869\udd02\udbe0\udee5\udb3c\ude80\udbb7\udca3\000\ud9c6\udca3\ud9f4\udfaf",
        2, 72861, 360726004, 6142200509164945408L, -84640L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe0000005640000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\ud8e1\udf72\uda2b\udef8\ud988\udfcc\udaa9\udce0\udbba\ude24\udb1f\ude20\udaa2\udc53\ud934\ude2b\ud9c5\ude5b\u318e\000\ud931\uddf9\"}\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 15, 5, 0, "\udbcd\ude4d\ud8e1\udf72\uda2b\udef8\ud988\udfcc\udaa9\udce0\udbba\ude24\udb1f\ude20\udaa2\udc53\ud934\ude2b\ud9c5\ude5b\u318e\000\ud931\uddf9", "\u19cc\ud08a\u6c6d\u249e\u0f26\u3026\u130b\u522c\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\uc2dd\uc9e6\u1862\ub44c\u6107\u00c0\u7622\ub1fc\u6b80", "\ud89d\udd38\uda64\ude2f\ud875\udfb7\udbe0\udee5\uda32\udea8\ud801\udd9f\ue8e9\ud945\udc2d\ud9f5\udc75",
        2, 72861, 360726004, 6142200510807945764L, -70428L, true, true, (char) 16587, (char) 37825,
        Double.longBitsToDouble(0x3f4a539590000000L), Double.longBitsToDouble(0x3fcc0defb1dcf6bcL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9\"}\0121=java.lang.String:{\"\udbcd\ude4d\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9\"} |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 13, 11, "\udbcd\ude4d\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9", "\u19cc\ud08a\u98d7\ua2ed\u20da\u0f5e\u2b52\u522c\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\u00c0\u4119\u9944\u6b42", "\ud89d\udd38\uda64\ude2f\ud8b1\ude24\udb64\udc94\ud958\ude29\uda3c\udfdd\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 6142200510807945764L, 46679L, false, false, (char) 4219, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3f4a539590000000L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"F\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9\"}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"F\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 9, 11, "F\uda5b\udcee\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2c\000\ud931\uddf9", "\u19cc\ud08a\u98d7\ua2ed\uacc8\uc75d\u2b52\u522c\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\u00c0\u4119\u9944\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 6142200510807945764L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3f4a539590000000L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\udb14\udc8b\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\012\000\ud931\uddf9\"}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\udb14\udc8b\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\012\000\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 9, 14, "\udbcd\ude4d\udb14\udc8b\udb8f\udf00\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\012\000\ud931\uddf9", "\u19cc\ud08a\u98d7\ua2ed\uacc8\uc75d\u2b52\u522c\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\uc9e6\u0f50\u57f0\u6107\u00c0\u4119\u99cb\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 4552148365301105548L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3f4a539590000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ufdff\ud05c\000\000\000\000\000\000\000\000\000\udb2e\ude3c\ud931\uddf9\"}\0121=java.lang.Integer:2 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ufdff\ud05c\000\000\000\000\000\000\000\000\000\udb2e\ude3c\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 0, 0, "\ufdff\ud05c\000\000\000\000\000\000\000\000\000\udb2e\ude3c\ud931\uddf9", "\u506a\ud08a\u98d7\ua204\u4ded\u00e1\u62ad\u522c\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\u672a\u214f\u57f0\u6107\uae5f\ub119\u2448\000", "\ud90e\ude91\uda64\ude2d\ud869\udd02\udbe0\udee5\udb3c\ude80\udbb7\udca3\000\ud9c6\udca3\ud9f4\udfaf",
        2, 72861, 360726004, 6142200509164945408L, -84640L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe0000005640000L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\udb14\udc8b\ud845\udc9a\ud9b1\ude98\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\012\000\ud931\uddf9\"}\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 15, 5, 14, "\udbcd\ude4d\udb14\udc8b\ud845\udc9a\ud9b1\ude98\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\012\000\ud931\uddf9", "\u19cc\ud08a\u98d7\ua2ed\uacc8\u787b\u2b52\u522c\uc2a0\u86f4\ud0a5\u1e54\u3254\ud44d\uc6a9\uca62\u0f50\u57f0\u2129\u00c0\u4119\u99cb\u6b80", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud853\uddd4\ud9d0\uddaf",
        2, 72861, 360726004, 4552148365301105548L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3f4a5cb590000000L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ud840\udf30\udb14\udc8b\udb8f\udf00\"}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ud840\udf30\udb14\udc8b\udb8f\udf00\"}\012",
        Z.run(T, 2, 15, 9, 14, "\ud840\udf30\udb14\udc8b\udb8f\udf00", "\ucb97\u7ac8\u3c00\ua44a\ub575\012\u0b42", "\ud86c\udfba\uda95\ude37\ud9d3\udd74\ud988\udde3\ud862\ude67\ud818\uddaa",
        2, 19220, 1931973041, 2011993617084654934L, -87109L, true, true, (char) 13326, (char) 20560,
        Double.longBitsToDouble(0x3faa1179f5a38450L), Double.longBitsToDouble(0x3fddc07df0951922L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\\\000\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\012\000\ud931\uddf9\"}\0121=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\\\000\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\012\000\ud931\uddf9\"}\012",
        Z.run(T, 2, 15, 9, 14, "\udbcd\ude4d\\\000\000\ud8cd\udf85\udbba\ude24\udb20\udfa1\ud843\udec1\ud934\ude2b\uda35\udcd2\012\000\ud931\uddf9", "\u19cc", "\ud862\ude67\ud818\uddaa",
        2, 19220, 1931973041, 2011993619561793622L, -87109L, true, true, (char) 24725, (char) 20235,
        Double.longBitsToDouble(0x3fe072283ec8069fL), Double.longBitsToDouble(0x3fcb80e647799f60L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 10, "\udbcd\ude4d\uda5b\udcc6\uda7b\ude3a\udbd1\udefc\ud8f6\ude1b\ud8e5\udf99\udbc4\udd55\ud843\udec1\ud934\ude2b\ud817\udd62\ud92a\ude3a\ud81f\udc63\ud931\ude7d", "\ub590\ud08a\ub522\u4013\u235c\u5fd5\u2b52\u522c\uc2a0\u874b\ud0a5\u1e54\ud257\u6c40\u85c0\uc9e6\u0f50\u57f0\u6107\ua909\ud088\u8b7f\u410e", "\ud89d\udd38\uda64\ude2f\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\uda86\udf95\ud9e8\uddff\ud9f4\udfaf",
        52, 72861, -687129100, 6185050758848641409L, 46679L, true, false, (char) 4121, (char) 1144,
        Double.longBitsToDouble(0x3fe8c092dd6bc656L), Double.longBitsToDouble(0x3fe61694e564001dL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.json.JsonWriteContext:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\0121=com.fasterxml.jackson.core.json.JsonWriteContext:/ |this=com.fasterxml.jackson.core.json.JsonWriteContext:/\012",
        Z.run(T, 2, 14, 11, 10, "\ud9e8\udf9c\uda5b\udcc6\ud81e\udd38\udbdc\udc95\ud9aa\ude15\udac3\ude0a\u1a3f", "\ub575\u600e\ua409\u13cd\u7a63\ub958", "\ud9b8\udd1a\uda5c\udee3\ud80e\ude01\udaca\udfaa\ud926\udf92\uda02\udcd7\udb61\uded5\udaeb\udef8\uda8e\udc68",
        0, -95, 868318281, -4804441996963806585L, -39876L, true, false, (char) 51867, (char) 11112,
        Double.longBitsToDouble(0x3fe9835d1780c2e8L), Double.longBitsToDouble(0x3fe4982402ce58dcL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\ud8ec\udc97\"}\0121=void |a0=java.lang.StringBuilder:\udbcd\ude4d\ud8ec\udc97{\"\udbcd\ude4d\ud8ec\udc97\"} |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\ude4d\ud8ec\udc97\"}\012",
        Z.run(T, 2, 15, 2, 0, "\udbcd\ude4d\ud8ec\udc97", "\u39d9\u0535\ua011\u3c00\u4efd\u4cbf\u4149\u6a74\u21da\u86d4\u113e\u506a\ud08a\u98d7\ua204\ua20b\u133e\u2b87\u522c\u5523\u86f4\ud0a5\u91e2\ucf38\ua703\u85c0\u2a06\u15fa\u57f0\ua403\u9c4f\ub119\u9944\u6b96", "\ud90e\ude91\uda64\ude2d\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 6142200509164945408L, 46679L, true, true, (char) 4014, (char) 7287,
        Double.longBitsToDouble(0x3eb6c00000000000L), Double.longBitsToDouble(0x3fe000000711c91dL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\udeec\uda5b\udcee\udb04\udc1b\udba7\udcc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ue50e\uda0b\udd85\ud86d\udced\udb2e\ude3c\udbb4\udf19\ua87f\u00fc\uda6d\udcd6\ud9d3\udd74\ud988\udde3\ud862\udd7e\ud818\uddaa\ud94f\udef8\ud9f6\udcba\ud8f9\udfc9\ud8ce\udf2e\ud983\udf6d\uda0b\udcf4\udb79\udd47\ud8cd\udd40\udb74\udca5\ud992\udc01\ud9f6\udc68\uda4b\udf34\udaae\udefa\udb56\udfdb\"}\0121=java.lang.Integer:2 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\udbcd\udeec\uda5b\udcee\udb04\udc1b\udba7\udcc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ue50e\uda0b\udd85\ud86d\udced\udb2e\ude3c\udbb4\udf19\ua87f\u00fc\uda6d\udcd6\ud9d3\udd74\ud988\udde3\ud862\udd7e\ud818\uddaa\ud94f\udef8\ud9f6\udcba\ud8f9\udfc9\ud8ce\udf2e\ud983\udf6d\uda0b\udcf4\udb79\udd47\ud8cd\udd40\udb74\udca5\ud992\udc01\ud9f6\udc68\uda4b\udf34\udaae\udefa\udb56\udfdb\"}\012",
        Z.run(T, 2, 15, 0, 0, "\udbcd\udeec\uda5b\udcee\udb04\udc1b\udba7\udcc7\ud8f6\ude1e\udbba\ude24\udb20\udfa1\ud843\udec1\ue50e\uda0b\udd85\ud86d\udced\udb2e\ude3c\udbb4\udf19\ua87f\u00fc\uda6d\udcd6\ud9d3\udd74\ud988\udde3\ud862\udd7e\ud818\uddaa\ud94f\udef8\ud9f6\udcba\ud8f9\udfc9\ud8ce\udf2e\ud983\udf6d\uda0b\udcf4\udb79\udd47\ud8cd\udd40\udb74\udca5\ud992\udc01\ud9f6\udc68\uda4b\udf34\udaae\udefa\udb56\udfdb", "\u9944\u6b80", "\ud90e\ude91\uda64\ude2d\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ue8e9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, 6142200509164945408L, 74840L, true, false, (char) 4121, (char) 7287,
        Double.longBitsToDouble(0x3eb6c00000000000L), Double.longBitsToDouble(0x3fe000000664001dL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ue80d\"}\0121=java.lang.Integer:2 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ue80d\"}\012",
        Z.run(T, 2, 15, 0, 0, "\ue80d", "\u3eb0\u2ff4\ub113\u7ac8\u84bf\u8f39\u0e28\u2ecc\ucdf0\u1e54\u8c2a\u00fc\u80f8\u60b4\u98d7\ua954\u387e\u9f20\u2b52\u5215\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\u672a\u0f50\u57f0\u6107\uae5f\ub119\u9944\u6b80", "\u092b\ud8d9\ude1a\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ud9d9\udfd9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, -5029673359368137611L, 46679L, true, false, (char) 4121, (char) 7287,
        Double.longBitsToDouble(0x3eb6c00000000000L), Double.longBitsToDouble(0x3fe000000564001dL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.json.JsonWriteContext:{\"\ue80d\"}\0121=com.fasterxml.jackson.core.json.JsonWriteContext:{?} |this=com.fasterxml.jackson.core.json.JsonWriteContext:{?}\012",
        Z.run(T, 2, 15, 11, 0, "\ue80d", "\u3eb0\u2ff4\ub113\u7ac8\u84bf\u8f39\u8086\u1f09\ucdf0\u1e54\u8c2a\u00fc\u80f8\u60b4\u98d7\ua954\ua433\u9f48\u2b52\u5215\uc2a0\u86f4\ud0a5\u1e54\uae79\ua703\u85c0\u672a\u0f50\u57f0\u6107\uae5f\ub119\u9944\u6b80", "\u092b\ud8d9\ude1a\ud869\udd02\udbe0\udee5\udb3c\ude80\ud801\udd68\ud9d9\udfd9\ud9e8\uddff\ud9f4\udfaf",
        2, 72861, 360726004, -5029673359368137611L, 46679L, true, false, (char) 4121, (char) 7287,
        Double.longBitsToDouble(0x3eb6c05800000000L), Double.longBitsToDouble(0x3fe000000564001dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|writeValue||new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|_checkDup|com.fasterxml.jackson.core.json.DupDetector,java.lang.String|new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|appendDesc|java.lang.StringBuilder|new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|createChildArrayContext||new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|createChildObjectContext||new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|createRootContext||static",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|createRootContext|com.fasterxml.jackson.core.json.DupDetector|static",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|getCurrentName||new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|getCurrentValue||new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|getDupDetector||new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|getParent||new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|reset|int|new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|setCurrentValue|java.lang.Object|new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|toString||new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|withDupDetector|com.fasterxml.jackson.core.json.DupDetector|new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|writeFieldName|java.lang.String|new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
    "M|com.fasterxml.jackson.core.json.JsonWriteContext|writeValue||new:com.fasterxml.jackson.core.json.JsonWriteContext:int,com.fasterxml.jackson.core.json.JsonWriteContext,com.fasterxml.jackson.core.json.DupDetector",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
