package com.fasterxml.jackson.core.io;
import org.junit.Test;
import static org.junit.Assert.*;
public class IOContext_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\uda9e\udda1\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8c1\udf19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7\uda24\ude3e\uda18\udd64\ud8d5\udfab\ud984\udcda\ud82a\udc6d",
        43, 2796, 370410927, -1655641510220752655L, -92780L, true, false, (char) 15889, (char) 10178,
        Double.longBitsToDouble(0x3fdc7ec74e265baeL), Double.longBitsToDouble(0x3fe762c4c7783f6aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 17, 1, "\udbe3\udc3e\ud9ba\udee0\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\ud9d4\udc53\uda7e\udf9f\ucaaa\udbb1\udc77\ud83f\uddbd", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8c5\udeab\ud898\ude54\udbb4\ude07\udb8f\udca1\udafc\udeb3\ud8a6\udde7",
        25, 96306, -209897268, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 58589,
        Double.longBitsToDouble(0x3fc9bc60e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=void |a0=[C:[[\udbe3, \udc3e, \ud9a9, \udcdb, \ud81b, \udc1e, \udb8f, \udfa4, \ud992, \udeb9, \udaff, \uddf6, \udabc, \udfec, \uda7e, \udf9f, \ucaaa, \ud8f5, \udd19, \ud857, \udf08]] |a1=[C:[[\ud437, \u2eb5, \u2396, \ud2d9, \u7be9, \ub01e, \u1cee, \u2f07, \u8564, \u8fff, \u306b, \u74b1, \ua126, \u8a76, \ua466]] |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 14, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\ud2d9\u7be9\ub01e\u1cee\u2f07\u8564\u8fff\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -17692L, false, true, (char) 37606, (char) 8,
        Double.longBitsToDouble(0x3feeb583e3ccbb7aL), Double.longBitsToDouble(0x3fc87af0e91f6f24L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\ub195\u3305\u321a\ucbbe\uc106\u99b0\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud804\udf38",
        42, 61762, -209897368, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fef6f2be102393dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |a0=[C:[[\ud437, \u2eb5, \u2396, \u79aa, \u8046, \ub01e, \u1cee, \u2f07, \u8564, \ub0d3, \u306b, \u74b1, \ua126, \u8a76, \ua466]] |a1=[C:[[\ud8ce, \udc9c, \ud898, \ude54, \udbcc, \ude72, \udb8f, \udc8d, \udafc, \udeb3, \ud8a6, \udde7]] |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=void |a0=[C:[[\udbe3, \udc3e, \ud9a9, \udcdb, \ud81b, \udc1e, \udb8f, \udfa4, \ud992, \udeb9, \udaff, \uddf6, \udabc, \udfec, \uda7e, \udf9f, \ucaaa, \ud8f5, \udd19, \ud857, \udf08]] |a1=[C:[[\ud437, \u2eb5, \u2396, \u79aa, \u8046, \ub01e, \u1cee, \u2f07, \u8564, \ub0d3, \u306b, \u74b1, \ua126, \u8a76, \ua466]] |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 17, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 5, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa", "\u4b3a\u18b5\ud437\u2eb5\u44c6\u79aa\u1c20\u1b03\u1cee\u2f07", "\ud819\udebf\ud8b3\udcc7",
        44, 37196, -100594814, 7907467572586019729L, -95829L, false, false, (char) 7596, (char) 29549,
        Double.longBitsToDouble(0x3faaa5c609595080L), Double.longBitsToDouble(0x3fd084f350d0f610L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 7, 1, "\udbe3\udc3e\udbce\udd2d\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\u938b\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829356323202512L, 88597L, false, false, (char) 53547, (char) 40883,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\udb7e\uded0\udb99\udd9c\udbb9\udd61\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437", "\uda93\udc42\ud978\udf6d",
        59, 26541, 1158659934, -3387363088851230281L, -48405L, true, false, (char) 44653, (char) 63293,
        Double.longBitsToDouble(0x3feeefd00b915d7bL), Double.longBitsToDouble(0x3fe798ab68514fe8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |a0=[B:[[7, -48, -88, 122, 22, -18, -66, 16]] |a1=[B:[[-98, 108, 104, 36, -100, 66, 95, 93]] |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=void |a0=[B:[[-77, 14, 121, -85, -21, -18, 95, 116]] |a1=[B:[[7, -48, -88, 122, 22, -18, -66, 16]] |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 0, 0, 12, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\u00db\uca90\ud8f5\udd19\ud857\udf08", "\ud437\000\u3cd8\u79aa\u8046\ub01e\u1cee\ua540\000\u0f1c\u306bu\000\u89fa\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\udae2\uddb1",
        18, 61762, -209897368, 8245809562907781310L, -100000L, false, false, (char) 35922, (char) 0,
        Double.longBitsToDouble(0x3fc87ae0011f6f24L), Double.longBitsToDouble(0x3fe800000102393dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\udb3c\udd6d\udb90\udfc9\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\ud97d\udf15\ud9b1\udcdf\uda7e\udf37\ucaaa\ud8f5\udd19\ud857\udf08 |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 10, 1, "\udb3c\udd6d\udb90\udfc9\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\ud97d\udf15\ud9b1\udcdf\uda7e\udf37\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u555d\u2e7b\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8da\udc82\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 3, 8, "\ud887\udef1\ud9de\udcec\uda84\ude8a\udb78\udc87\ud992\udeb9\udaff\uddf6\udabc\udff4\ud8ae\udccc\ucaaa\ud8f5\udd19\ud88f\udc83\uda37\uddb9\uda0d\udca4\ud8bc\udc57", "\u79aa\u8046", "\ud96d\ude2a\ud934\udeaa\udb57\ude2d\ud823\ude07\ud8b3\udcc7\uda76\uddac\ud8c2\udd4a\ud8e7\ude54\uda5a\ude90\udad7\udd7d\ud8ce\udc9c\ud9e2\udd04\ud8b3\udf7b\udb8f\udc8d\ud9cf\udf9d\u9766\udba8\udecc\uda18\udd5b\ud8d5\udfab\ud87d\uddf7\ud927\udcab\uda6e\udcad\ud99c\udf4a\ud81d\udefc\ud849\udede\ud97e\udd52\ud8e3\udfcc\ud9b4\udd69\uda7c\udea0\ud859\udce6\uda3f\udea5\udad9\ude3c\udae9\udee8\udbd5\udd90\ud8ad\udc76",
        43, 21254, 837914971, 6897262146231871502L, 91615L, false, true, (char) 22917, (char) 6707,
        Double.longBitsToDouble(0x3fe37a77d77464ddL), Double.longBitsToDouble(0x3fe78ce9e2b49e29L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\ud9ff\udf2a\udabd\udc0e\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\u9567\uc986\u0e25\u0664\u8046\u9103\u7fe4\u2f07\u8564\u3333\u3f55\ua0ec\u43be\u8a76\uc7ba", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udae5\udef8\uda21\udf4f\udaff\udd3e",
        -1, 61762, -209897368, 1184185139175112775L, -77245L, false, true, (char) 20966, (char) 8,
        Double.longBitsToDouble(0x3feeb583e3ccbb7aL), Double.longBitsToDouble(0x3fc87af0f11f6f24L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 3, "\udbe3\udc3e\ud9a9\udcdb", "\uc985", "\uda7e\udf9f\ucaaa\uda12\udcc7\ud857\udf08\ud907\udedb\ud804\udc63\uda5e\udf12\ud8f9\udfa0\uda24\udc37\uda93\udc42\ud948\ude10\uda95\ude62\ud903\udfba",
        9, 12139, -1145015957, -916659000559061387L, 98691L, true, true, (char) 13933, (char) 16426,
        Double.longBitsToDouble(0x3fa0114625d6b4f0L), Double.longBitsToDouble(0x3fe59b4bc1354b8cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.TextBuffer: |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=void |a0=[C:[[\udbe3, \udc3e, \ud9a9, \udcdb, \ud81b, \udc1e, \udb8f, \udfa4, \ud992, \udeb9, \udaff, \uddf6, \udabc, \udfec, \uda7e, \udf9f, \ucaaa, \ud8f5, \udd19, \ud857, \udf08]] |a1=[C:[[\ud437, \u2eb5, \u2396, \u79aa, \u8046, \ub01e, \u1cee, \u2f07, \u8564, \ub0d3, \u306b, \u74b1, \ua126, \u8a76, \ua466]] |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 13, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.TextBuffer: |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 16, 9, "\udbe3\udc3e", "\u33d8\u8b0b\u81f6\u5978\ucf8f\ub1a8\u9e14\uac4d\u4b3a\u18b5\ud437", "\u7270\udbc2\uddfb",
        15, 30855, -440201909, 4109514581925611743L, 45095L, false, true, (char) 45968, (char) 53967,
        Double.longBitsToDouble(0x3feeefd00bb575bcL), Double.longBitsToDouble(0x3fefb4c7404b2fdfL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 17, 17, "\udbe3\udc3e\ud9a9\udcdb", "\u859c", "\uda7e\udf9f\ucaaa\ud8d8\udd2a",
        2, 18223, 781269380, -8627786239365118476L, 23362L, true, true, (char) 33163, (char) 60201,
        Double.longBitsToDouble(0x3fc1c974d9ce2258L), Double.longBitsToDouble(0x3fe650e9377f65b6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.TextBuffer: |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=void |a0=[B:[[-77, 14]] |a1=[B:[[111]] |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 13, 0, 0, "\udbe3\udc3e", "\u7d9f", "\udabc\udfec\ud93e\udcde\u8090\ud8f5\udd19\ud857\udf08",
        40, 33248, 33, 147283018514432L, 26347L, false, false, (char) 60201, (char) 0,
        Double.longBitsToDouble(0x3fd00000036fa168L), Double.longBitsToDouble(0x3fbfeef033af9800L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.TextBuffer: |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 13, 3, 15, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec", "\ub08a\u0d84\ud3e4\u54f7\ud437\u2eb5\u2396\u79aa\u8046\ua871\ubf6d\u2f07\u3351\u4783\u3034\u786f", "\uda0e\udf27\uda2b\uddd3\uda33\udd78\ud967\udcb8\udbd5\udfd4\uda0b\udcda\udaf1\uddb0\udafc\udf3f\ud8a6\udde7\uda24\ude3e\uda18\udd64\ud8d5\udfab\ud984\udcda\ud82a\udc6d\uda6e\udcad\ud99c\udf4a\ud81d\udefc\ud850\udcde\ud97e\udd52\udaaf\uddda\ud9b4\udce4\uda7c\udea0\ud859\udce6\uda05\uddcb\udbbd\udf2e\udad7\udcc6\udb2a\udfc8\ud947\udf26\uda6e\udc56\ud822\udee8\u610d\ud9b7\udc63\u238c\ud81e\udee3\udb79\udc60\ud943\udeca\ud800\udffe\ud812\udd32\ud84a\ude01\udbb0\udc0a\ud947\udd31",
        -5, 53707, -1162948578, 2409249395807894971L, -57844L, false, true, (char) 58658, (char) 17990,
        Double.longBitsToDouble(0x3fbcfb61b0697720L), Double.longBitsToDouble(0x3fa94dc1fdb8fe80L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08 |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=java.lang.IllegalArgumentException:java.lang.IllegalArgumentException: Trying to release buffer smaller than original |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 15, 2, 5, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, -8818911066850085900L, -2510L, false, false, (char) 23024, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e5a05542L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |a0=[B:[[7, -123, 102, 122, 22, -18, -66, -41]] |a1=[B:[[-98, 108, 104, 36, -100, 66, 95, 93]] |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=void |a0=[C:[[\udbe3, \udc3e, \ud9a9, \udcdb, \ud81b, \udc1e, \udb8f, \udfa4, \ud992, \udeb9, \udaff, \uddf6, \udabc, \udfec, \uda7e, \udf9f, \udbd1, \udc79, \ud8f5, \udcfb, \ud857, \udf08]] |a1=[C:[[\ud437, \u2eb5, \u2396, \u79aa, \u8046, \ub01e, \u1cee, \u2f07, \u8564, \ub0d3, \u306b, \u74b1, \ua126, \u8a76, \ua466]] |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 0, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\udbd1\udc79\ud8f5\udcfb\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 40602,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |a0=[C:[[\ud437, \u2eb5, \u2396, \u79aa, \u8046, \ub01e, \u1cee, \uaf07, \u8564, \ub0d3, \u306b, \u74b1, \ua126, \u8a76, \ua466]] |a1=[C:[[\ud8ce, \udc9c, \ud898, \ude54, \udbcc, \ude72, \udb8f, \udc8d, \udafc, \udeb3, \ud8a6, \udde7]] |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 1, 1, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\uaf07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0fedb6f24L), Double.longBitsToDouble(0x3fe18f666eb2a2abL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 1, "\udbe3\udc3e\uda63\udcd8\ud81b\udc1e\uda52\udda5\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud946\udc62\ud850\udd08", "\ud437\u2eb5\u2396\u6fcd\ua7a0\ud33e\u57c0\u2f07\ubada\ub0d3\u4597\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -2510L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\uda37\uddc2\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396", "\uda95\ude62",
        26, 53894, -793504397, -4917752985950920833L, -11943L, false, false, (char) 63293, (char) 61918,
        Double.longBitsToDouble(0x3fec8b6de5ca98e8L), Double.longBitsToDouble(0x3fb2cbf7e1011460L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.TextBuffer: |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 8, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud49a\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\udb62\ude6c",
        8, 61762, -209897368, 8245829354117081278L, -17888L, true, false, (char) 35922, (char) 10055,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\ud9c8\udce0\ud88e\ude49\udaf7\udd8b\ud8d5\udf02\ud992\udeb9\ud9e8\udfea\udabc\udfec\uda00\udfa0\ucaaa\ud8f5\udd19\ud857\udf08 |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 6, "\ud9c8\udce0\ud88e\ude49\udaf7\udd8b\ud8d5\udf02\ud992\udeb9\ud9e8\udfea\udabc\udfec\uda00\udfa0\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u0654\ub0d3\u306b\u9206\u5d08\u8a76\ua466", "\ud8ce\udc9c\ud937\udde3\udbcc\udf02\udb8f\udc8d\udafc\udeb3\udb32\udf5b\uda24\ude3e\uda18\udd64",
        42, 28676, -1079826242, 3302491289464816004L, -25206L, true, false, (char) 56394, (char) 15889,
        Double.longBitsToDouble(0x3fea3163e102393dL), Double.longBitsToDouble(0x3f9dd4d426223580L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.TextBuffer: |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=com.fasterxml.jackson.core.util.TextBuffer: |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 13, 13, 9, "\udbe3\udc3e\ud9a9\udcdb\ud91a\udebf\uda6b\udc66\ud8e5\udfb2\udaff\udd97\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08\udb24\udfca\ud9af\udc33\uda54\udce9\ud8f9\udfa0\uda24\udc37\uda93\udc42\udbc2\ude0d\uda95\ude62\ud903\udfba\ud9e1\udd84\ud9b2\udea9\udb1a\udc2e\udaac\udc53\ud8b3\udcc7\uda76\uddac", "\uc77e\u378e\u5e87\u093d\u6b4f\u5e6d\u37ca\u496d\u9203\u5d15\u237d\u99bc\u07b8\ud043\u3aab\u8dd5\u30e8\u67c4\u1aa0\u1bd5\ud1d6\u7f00\ud71d\u8011\u1af4\ua7e4", "\udaf1\udeac\ud8a6\udd15\ud802\ude1c\uda5e\udf2d\ud863\udd02",
        9, 88120, -1662242010, -6429693914356252887L, 32729L, true, false, (char) 59547, (char) 26701,
        Double.longBitsToDouble(0x3fd17629869fdc08L), Double.longBitsToDouble(0x3fe4630d05ec4458L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\udbd6\udecc\ud9a9\udcdb\ud81b\udc53\ud9bf\udfa0\ud992\udeb9\uda05\udfd9 |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 17, 5, "\udbd6\udecc\ud9a9\udcdb\ud81b\udc53\ud9bf\udfa0\ud992\udeb9\uda05\udfd9", "\ua8ad\u3b05\u2691\u4b3a\u9bf6\ua944\ub7a3\u2c1e\u5054\u8046\ub01e\u1cee\u2f07\ucd39\ub0d3\u306b\u1f1c\ua126\u8a76\u9d79\ud1ec\u2962\u5e87\u3efe\ud60a", "\ud8a6\udde7\uda24\ude3e\ud9f4\udd87\ud85b\udc35",
        57, 36098, 771360248, -6746601681215814225L, -92780L, false, false, (char) 34770, (char) 2487,
        Double.longBitsToDouble(0x3fda6713d42710c6L), Double.longBitsToDouble(0x3fe615552b3aac93L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.IllegalArgumentException:java.lang.IllegalArgumentException: Trying to release buffer smaller than original |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 9, "\ud8b1\udfa6\ud8a2\ude08\ud96f\udc25\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f", "\u2a28", "\uda5e\udf12\ud8f9\udfa0\uda24\udc37\uda93\udc42\udbab\udc41\uda89\udc29\ud903\udfba\udab0\udc95\ud94a\udf65\ud8b3\ude45\ud81a\udd86\ud8b3\udcc7\uda5c\udd84\ud8c2\udd4a\uda0e\udf27",
        5, 62289, 803184074, 2489382610138010656L, -79968L, true, false, (char) 47142, (char) 4083,
        Double.longBitsToDouble(0x3fba1edea4879be8L), Double.longBitsToDouble(0x3fe26cdfbdf8fad6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08 |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 6, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u3327\u4efd\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 5003237622410320159L, -18089L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:\udbe3\udc3e\uda4d\udccd\udb48\ude3b\udb90\udc05\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud91d\udfea\udae8\udf8d |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 4, 1, "\udbe3\udc3e\uda4d\udccd\udb48\ude3b\udb90\udc05\ud992\udeb9\udaff\uddf6\udabc\udfec\uda7e\udf9f\ucaaa\ud91d\udfea\udae8\udf8d", "\ud437\u3f93", "\udbc2\ude0d\uda95\ude5b\ud903\udfba\ud9e1\udd84",
        -2, 32407, -213426305, -2052737128558647289L, 28126L, false, false, (char) 26911, (char) 14002,
        Double.longBitsToDouble(0x3fb2cbf7e1011460L), Double.longBitsToDouble(0x3fe2eb5a7e40252dL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 1, 14, 17, 5, "\udbe3\udc79\ud9a9\udcdb\udbf0\udfbe\udafa\ude80\ud817\udf0f\ud9b8\udfc5\udb0f\udf5a\ud86b\udd14\udb9a\udd8d\ud8e7\udc77\udb8d\udc16", "\u2e4e\u2eb5\u2396\u79aa\uc67d\ucbd6\u99ed", "\ud95d\udd72\ud819\udebf",
        13, 44559, -340028804, 4013739917405124573L, 56214L, true, false, (char) 33196, (char) 7596,
        Double.longBitsToDouble(0x3fe205a28ff9d83fL), Double.longBitsToDouble(0x3fc2b2a1088870d4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 1, 3, 5, 14, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\uda9e\udda1\udaff\uddf6\udabc\udfec", "\ua813\uac4d\u4b3a\u18b5\ud437\u2eb5\u2396\u79aa\u8046\ub01e\u1cee\u2f07\u8564\ub0d3\u306b\u74b1", "\uda0e\udf27\uda0f\udc44\uda56\udd96\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\ud9c0\udeb5\ud8a6\udde7\uda24\ude3e\uda18\udd64\ud8d5\udfab\ud984\udcda\ud82a\udc6d\uda6e\udcad\ud99c\udf4a\ud81d\udefc\ud94a\udd77\udb04\udda0\ud92a\udc8f\ud9b4\udd69\uda7c\udca0\ud859\udce6\ud872\ude1f\u847c\uda63\udc4b\udad0\udea8\ud99a\udc52\udabc\udcd8\udbc1\udff9\ud957\udde9\u02e3\ud86f\uddbc\ud8b1\udcc3\udb5b\ude27\u89ec\ud9a0\udf2f\uda7a\udc8d\udaa6\udcb2\uda3d\udcab\udb81\udd34\ud8d6\ude15",
        23, 89910, -2128701456, 1110969427813473972L, -66325L, true, false, (char) 6896, (char) 8480,
        Double.longBitsToDouble(0x3fe3e4736d1278cdL), Double.longBitsToDouble(0x3fe9b98ab729ee11L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 1, "\udbe3\udc3e\ud9ba\udee0\ud81b\udc1e\udb8f\udfa4\udba9\udfb6\udaff\uddf6\ud9d4\udc53\uda7e\udf9f\ucaaa\udbb1\udc77\ud83f\uddbd", "\ud437\u9015\ua2a0\uac38\u62f3\ub01e\u1cee\u2f07\u68eb\u6766\u306b\u74b1\ua126\u8a76\ua050", "\ud8c5\udeab\ud898\ude54\udbb4\ude07\udb8f\udc87\uda62\udf43\ud8a6\udde7",
        25, 96306, -209897268, 8245829355650099390L, 64654L, false, false, (char) 30987, (char) 58608,
        Double.longBitsToDouble(0x3fc9a62da91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 7, "\udbe3\udc3e\ud9ba\udee0\ud90a\udf78\ud93e\udd87\udabf\udc78\ud9d5\udfa0\ud9fd\udf3e\uda7e\udf9f\ud86c\uddf8\udb79\udefc\udaf3\udd97", "\ud437\u6c08\u2396\ua95d\ub2b9\u4e7c\u688a\u448c\u5463\uce6e\u82be\u9b87\u9283\ubccc\u3d72\ud1ec\u7904\u68d1\u914e\ubafb\u13ed\u691e\u5158\ud1e2\ucd06\u09f8\u99bc\ub862\uc4752\u6f42\ud3e9\u67c4\u26d5\u43e2\u3fe0\u08a0\u5b63\u69e6\ubc66\u7417\uc9c7\uc0c0", "\u9bb8\ud8aa\udff4",
        41, 86393, 560081480, -7525977067165218983L, 35784L, false, false, (char) 58484, (char) 27513,
        Double.longBitsToDouble(0x3fb32c9785a27340L), Double.longBitsToDouble(0x3fd897767c6d98daL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 7, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\uda11\udc67\ucaaa\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\ud2d9\u7be9\ub01e\u1cee\u2f07\u8564\u8fff\u1b62\u0e99\ua126\u8a76\ua466", "\ud8ce\udc9c\ud898\ude54\udbf7\udd29\udb8f\udc89\udafc\udeb3\ud8a6\udde7",
        49, 61762, -209897368, 8245829354117081278L, -17692L, false, true, (char) 27622, (char) 59464,
        Double.longBitsToDouble(0x3fbe968ae2768f88L), Double.longBitsToDouble(0x3fc87af0e91f6f24L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 0, "\udbe3\udc3e", "\u7d9f\uc985\u987a\u0fe4\u87a2\ud56a", "\udb24\udfca\uda0d\udc42\uda5e\udf12\ud8f9\udfa0\ud87b\udec2\000\udb8b\uddb1\uda95\ude62\ud903\udfba\ud9e1\udd84",
        -2, 17463, -213426305, -2052737128542853113L, 93662L, true, false, (char) 26957, (char) 14002,
        Double.longBitsToDouble(0x3fb2cbf7e1011460L), Double.longBitsToDouble(0x3fe2eb5a7e40252dL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=null |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 14, 14, 2, "\udbe3\udc3e\ud9a9\udcdb\ud8c8\uddfd\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\ud827\uded2\uda95\udf74\ud9b4\uddb0\ud864\udd1d", "\ud437\u2eb5\u2396\ud2d9\u7be9\ub01e\u1cee\u2f07\u8564\u8fff\u7cdd\uac2f\ua126\u7550\ua4cf", "\udb09\udf99\ud898\ude54\ud88a\udd92\ud96f\udf98\udae1\uddc8\ud8a6\udde7\uda24\ude3e\uda18\udd64\ud8d5\udfab\udac4\udf9b\udbe3\udc25",
        25, 90581, 370410944, -2248003395943365435L, -92780L, true, false, (char) 50894, (char) 7500,
        Double.longBitsToDouble(0x3fd2d5462cd1b7a6L), Double.longBitsToDouble(0x3fa1378cf06e16d0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=void |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 3, 3, 16, "\ud88f\udc64\udb8a\udd2b\ud81b\udc1e\udb8f\udfa4\udb7e\udf90\ud8e6\udc5b\ud8d0\udda9\uda5a\udcd0\ucaaa\ud8f5\udd19\udb27\udd70\udafc\ude19\u17bb\uda51\ude36\ud8dc\udca1\uda24\udc37\uda93\udc42\udbc2\ude0d\uda95\ude62\ud903\udfba\ud9e1\udd84\ud9b2\udea9\ud94f\udcb1\uda99\udebf\ud8b3\udcc7\ud89e\udcda", "\ud1ec\ub9f6\u4e34\u1729\uc103\u5e6d\ud43a\u496d\u9203\u2424\ud270\u10ab\u2b4e\uc2a6\u4ba4\u3d7b\u1c5e\u7eab\u4321\u1bd5\ud1d6\u7f00\ud71d\u08d0\u5921\u1aab", "\udbcf\ude94\ud8af\udda9\ud818\udd03\udb48\ude93\uda12\udea0\uda18\udf67\ud887\udc45\u0ff9\ud932\udcd8\ud975\uddf5\ud879\udce3\ud8c3\udcfa\uda7f\udc34\ud85e\udd60\udb06\udc3f\ud86f\ude73\ud84d\udcab\uda4e\udf63\ud8d8\udca0\ud832\udefb\ud804\udf69\udb33\udd2a\ud912\udd9a\ud8b4\ude1c",
        33, 29363, -975538991, -8126557645587448776L, 57323L, true, true, (char) 14021, (char) 27742,
        Double.longBitsToDouble(0x3fabe6dda58973d0L), Double.longBitsToDouble(0x3feafdc3dce74285L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |a0=[B:[[-37]] |a1=[B:[[]] |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 3, 13, "\000\uda40\udf1f", "\013", "",
        36, -1000, 61952, 0L, -38048L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e43f80000000000L), Double.longBitsToDouble(0x3fb163f900000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 17, 1, "\udbe3\udc3e\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\udaff\uddf6\udabc\udfec\u6c28\ucaa3\ud8f5\udd19\ud857\udf08", "\ud437\u2eb5\u2396\u79aa\u94a7\u86d0\uae4e\u2f07\u8564\ub0d3\u306b\u74b1\ua126\u8a76\ua466", "\uda55\udd4b\ud898\ude54\udbcc\udedf\udb8f\udc8d\udafc\udeb3\ud8a6\udde7",
        49, 24618, 28928369, 8245829702009432254L, -2510L, false, false, (char) 35922, (char) 40774,
        Double.longBitsToDouble(0x3fc87af0e91f6f24L), Double.longBitsToDouble(0x3fea3163e102393dL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.TextBuffer: |this=com.fasterxml.jackson.core.io.IOContext:@?\0121=void |a0=[C:[[\ud93c, \udee9, \ud9a9, \udcdb, \ud81b, \udc1e, \udb8f, \udfa4, \ud992, \udeb9, \ud862, \udc56, \udabc, \udfec, \ud901, \ude5d, \ucae0, \ud8f5, \udd19, \ud857, \udf08, \udb66, \udfcb, \uda0d, \udc42, \uda5e, \udf12, \ud8f9, \udfa0, \uda24, \udc37, \uda93, \udc42, \udbc2, \ude0d, \uda95, \ude62, \ud903, \udfba, \ud9e1, \udd84, \ud9b2, \udea9, \ud95d, \uddb1, \ud819, \udebf, \ud8b3, \udcc7, \uda76, \uddac, \ud8c2, \udd4a, \uda0e, \udf27, \uda2f, \ude54, \udad7, \udd7d, \ud8ce, \udc9c, \ud898, \ude54, \udbcc, \ude72, \udb8f, \udc8d, \udafc, \udeb3, \ud8a6, \udde7, \uda24, \ude3e, \uda18, \udd64, \ud8d5, \udfab, \ud984, \udcda, \ud9b1, \ude31, \ud9ab, \udc71, \ud9bd, \uddaf, \ud81d, \udefc, \ud837, \uddde, \ud97e, \udd52, \ud8e3, \udfcc, \ud9b4, \udd69, \uda7c, \udea0, \ud859, \udce6, \uda49... |a1=[C:[[\u2e63, \u0a9f, \u8bac, \u7776, \ube44, \u2dca, \ua316, \u3b5c, \u82c7, \u3315, \u9847, \u925f, \u9c60, \uc691, \u108a, \u13a5, \u46e0, \u7334, \uc462, \u7bf3, \u197b, \u6b2c, \ub2c4]] |this=com.fasterxml.jackson.core.io.IOContext:@?\012",
        Z.run(T, 2, 13, 17, 16, "\ud93c\udee9\ud9a9\udcdb\ud81b\udc1e\udb8f\udfa4\ud992\udeb9\ud862\udc56\udabc\udfec\ud901\ude5d\ucae0\ud8f5\udd19\ud857\udf08\udb66\udfcb\uda0d\udc42\uda5e\udf12\ud8f9\udfa0\uda24\udc37\uda93\udc42\udbc2\ude0d\uda95\ude62\ud903\udfba\ud9e1\udd84\ud9b2\udea9\ud95d\uddb1\ud819\udebf\ud8b3\udcc7\uda76\uddac\ud8c2\udd4a\uda0e\udf27\uda2f\ude54\udad7\udd7d\ud8ce\udc9c\ud898\ude54\udbcc\ude72\udb8f\udc8d\udafc\udeb3\ud8a6\udde7\uda24\ude3e\uda18\udd64\ud8d5\udfab\ud984\udcda\ud9b1\ude31\ud9ab\udc71\ud9bd\uddaf\ud81d\udefc\ud837\uddde\ud97e\udd52\ud8e3\udfcc\ud9b4\udd69\uda7c\udea0\ud859\udce6\uda49\udd4a\uda3f\udead\u244a\ud97e\udc2c\udba2\ude59\uda20\udc2a\ud8b7\ude67\udadd\udc75\ud868\udeed\ud92f\uddcd\udae6\udce5\udaf0\uddc8\ud99a\ude92\udbf7\ude41\ud9aa\udcad\udb2e\udf1d\ud9fb\udc3e\u74a5\ud943\udfba\udada\udda6\ud852\udc3c\ud9bf\udd6d", "\u2e63\u0a9f\u8bac\u7776\ube44\u2dca\ua316\u3b5c\u82c7\u3315\u9847\u925f\u9c60\uc691\u108a\u13a5\u46e0\u7334\uc462\u7bf3\u197b\u6b2c\ub2c4", "\ud83a\udf1b\udade\udfb5\udb2b\ude48\ud8a5\udedf\ud9dd\udd9f",
        15, 1878, -1783868398, 3793319705219171323L, -24445L, false, true, (char) 12919, (char) 34416,
        Double.longBitsToDouble(0x3fc40553c3114108L), Double.longBitsToDouble(0x3fc94f6fa6a7b628L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.io.IOContext|_verifyRelease|[B,[B|new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|_verifyRelease|[C,[C|new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|wrongBuf||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|_verifyAlloc|java.lang.Object|new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|allocBase64Buffer||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|allocConcatBuffer||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|allocNameCopyBuffer|int|new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|allocReadIOBuffer||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|allocReadIOBuffer|int|new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|allocTokenBuffer||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|allocTokenBuffer|int|new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|allocWriteEncodingBuffer||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|allocWriteEncodingBuffer|int|new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|constructTextBuffer||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|getEncoding||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|getSourceReference||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|_verifyRelease|[B,[B|new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|_verifyRelease|[C,[C|new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.core.io.IOContext|wrongBuf||new:com.fasterxml.jackson.core.io.IOContext:com.fasterxml.jackson.core.util.BufferRecycler,java.lang.Object,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
