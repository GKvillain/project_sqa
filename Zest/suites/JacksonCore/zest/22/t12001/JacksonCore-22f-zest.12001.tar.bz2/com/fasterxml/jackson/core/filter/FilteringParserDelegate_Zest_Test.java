package com.fasterxml.jackson.core.filter;
import org.junit.Test;
import static org.junit.Assert.*;
public class FilteringParserDelegate_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 14, 8, "\udb25\udf03\ud9c2\uddcb\udb5d\udf8c\ud882\udf81\ud989\udc22\ud9ad\udc5a\ud9aa\udd67\udb93\udcef\uda71\uddd9\ud892\udf04\udaf9\udc87\ud8fb\udcbb\ud804\udd30\uda35\udc1d", "\u5969\u4665\u8217\u39b7", "\udbd5\udc33\uda40\ude3e\ud8c6\udc82\ud8fc\udc27\udb89\uddef\udbb1\ude6d\ud87b\udd04\udba3\udfff\udbd8\udf87\ud87f\udef4\udb87\udd9f\udbb2\udd33\uda19\udd36\udbc3\udf04\ud8b1\udf88\ud917\udf6e\udaa5\udcb1\udb50\udcfe\udb65\ude4f\ud8a8\udef6\ud8d8\udcb8\ud927\udfe5\ud87d\ude88\ud88f\udd9c\u26a9",
        5, 86063, 921886656, -8587195336411393499L, -68916L, true, false, (char) 22215, (char) 31937,
        Double.longBitsToDouble(0x3f7bf1b1ea36cb00L), Double.longBitsToDouble(0x3fe97baf6b371414L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 14, 8, "\udb25\udf03\ud9c2\uddcb\udb5d\udf8c\ud882\udf81\ud989\udc22\ud9ad\udc5a\ud9aa\udd67\udb93\udcef\uda71\uddd9\ud892\udf04\udaf9\udc87\ud8fb\udcbb\ud804\udd30\uda35\udc1d", "\u5969\u4665\u8217\u39b7", "\udbd5\udc33\uda40\uddd9\ud8c6\udc82\ud8fc\udc27\udb89\uddef\udbb1\ude6d\ud87b\udd04\udba3\udfff\udbd8\udf87\ud87f\udef4\udb87\udd9f\udbb2\udd33\uda19\udd36\udbc3\udf04\ud8b1\udf88\ud917\udf6e\udaa5\udcb1\udb50\udcfe\udb65\ude4f\ud8a8\udef6\ud8d8\udcb8\ud927\udfe5\ud87d\ude88\ud88f\udd9c\u26a9",
        5, 86063, 921886656, -8587195336411393499L, -68916L, true, false, (char) 22215, (char) 31937,
        Double.longBitsToDouble(0x3f7bf1b1ea36cb00L), Double.longBitsToDouble(0x3fe97baf68371414L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 1, 8, 14, 8, "\udb25\udf03\ud9c2\uddcb\udb5d\udf8c\ud882\udf81\ud989\udc22\ud9ad\udc5a\ud9aa\udd67", "\ud342\u7c5d\ub376", "\udb44\udf33\udbbd\udfe8\uda76\udc41\ud8a6\ude54\ud82c\udcb0",
        25, 98584, -1482680448, 6724804639773177445L, -90374L, false, true, (char) 44822, (char) 54516,
        Double.longBitsToDouble(0x3fc5e538bb2df094L), Double.longBitsToDouble(0x3fe5c2833711c01dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 14, 8, "\udaa8\udd15\uf3cb\udb5d\udf8c", "\u4316\ub44e\ua8ea", "\udbcf\udff4\ud8e4\udd7b\ud804\udc9e\uda35\udc1d\udb44\udf33\udbbd\udfe8\uda76\udc41\ud8a6\udc0e\ud82c\udcb0\ud9b0\ude0f\ud8bf\udfbc\ud912\ude90\udbd4\udf9e\uda40\ude3e\ud8cd\udcc4",
        42, 60670, 1275698011, 3009867977373057199L, -27624L, true, true, (char) 41897, (char) 64076,
        Double.longBitsToDouble(0x3fe72aa9b0fabe3eL), Double.longBitsToDouble(0x3feab73be8a0019cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 1, 4, 10, 7, "\udb25\udf03\ud9c2\uddcb\udb5d\udf8c\ud882\udf81\ud989\udc22\ud87c\udcc2\ud9aa\udd67\udb93\udcef\uda71\uddd9\ud892\udf04\udaf9\udc87\ud8fb\udcbb\ud804\udd30\ud98f\udf6a", "\u5969\u4665\u8217\u39b7", "\ud8d7\udeb5\uda40\ude13\ud8c6\udc82\ud8fc\udc27\udb89\uddef\udbb1\ude6d\ud87b\udd04\udba3\udfff\udbd8\udf87\ud87f\udef4\udb87\udd9f\ud8b2\udf42\uda19\udd36\udbc3\udf04\ud8b1\udf88\ud917\udf6e\udaa5\udcb1\udb50\udcfe\udb65\ude4f\ud8a8\udef6\ud8d8\udcb8\ud927\udfe5\ud87d\ude88\ud88f\udd9c\u26a9",
        5, 86063, 921886656, 8644139788498719663L, 2544L, true, false, (char) 40847, (char) 33521,
        Double.longBitsToDouble(0x3fed7a18c4e687dbL), Double.longBitsToDouble(0x3f7bf1b1ea36cb00L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 16, 8, "\udb25\udf03\ud9c2\uddcb\udb5d\udf8c\ud882\udf81\ud989\udc22\ud9ad\udc5a\ud8f1\udf6a\ud9d5\udecf\u4a6f\ud892\udf04\udaf9\udc87\ud8fb\udcbb\ud804\udd30\uda35\udc1d", "\u5969\u4665\u8217\u1d92", "\udbd5\udc33\uda40\ude3e\ud8c6\udc82\ud8fc\udc27\udb89\uddef\udbb1\ude6d\ud87b\udd04\udba3\udfff\udbd8\udf87\ud87f\udef4\udb87\udd9f\udbb2\udd33\uda28\udf36\udbc3\udf04\ud8b1\udf88\udb83\udd43\ud915\udc4c\udb50\udcfe\ud9a5\ude4f\ud8a8\udef6\ud8d8\udcb8\ud927\udfe5\ud87d\ude88\ud88f\udd9c\u26a9",
        5, 86063, 921886656, -8587195336411393499L, -68916L, true, false, (char) 22215, (char) 31937,
        Double.longBitsToDouble(0x3f7bf1b253b91c00L), Double.longBitsToDouble(0x3fe97ba873371414L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 1, 14, 14, 8, "\udb25\udf03\ud9c2\uddcb\ud8d8\udfe9\ud87e\udfee\ud989\udc22\udbc7\udc68\udb6c\ude9e\udb16\ude34\ud940\ude1e\ud85b\udcfe\udaf9\udc87\ud8fc\udf9b\ud804\udd30\uda35\udc1d", "\u5969\u4665\u8217\u39b7", "\ud963\uddda\udb7d\udf5e\udbd8\ude82\ud906\udf68\udb68\udd80\udbb1\ude6d\ud87b\udd04\udba3\udfff\udbd8\udf87\ud87f\udef4\udb87\udd9f\udbb2\udd33\udbc4\uddbd\udbc3\udf04\uda6c\udd2d\ud901\ude80\udaa5\udcb1\udb50\udcfe\udb65\ude4f\ud8a8\udef6\ud8d8\udcb8\ud927\udfe5\ud87d\ude88\ud88f\udd9c\u26a9",
        5, 86063, 921886656, -8587195336411393499L, -68916L, true, false, (char) 22215, (char) 41358,
        Double.longBitsToDouble(0x3f7bf1b1ea36cb00L), Double.longBitsToDouble(0x3fe97baf6b371414L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 14, 14, 8, "\udb25\udf03\ud9c2\uddcb\udb5d\udf8c\ud882\udf81\uda03\udc1f\ud9ad\udc5a\ud9aa\udd67\udb93\udcef\uda71\uddd9\udacb\udc22\ud99b\udcf2\ud8b5\ude22\uda63\udc29\uda35\udc1d", "\u5969\u4665\u8217\u39b7", "\udbd5\udc33\uda40\ude3e\ud8c6\udc82\ud8cb\udf27\udb89\uddef\udbb1\ude6d",
        10, 34493, 1348892363, -4603493864659443951L, -46801L, true, false, (char) 52965, (char) 6887,
        Double.longBitsToDouble(0x3fc40039596ef530L), Double.longBitsToDouble(0x3fef0b6066d06ef8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 6, 10, "\udbbf\udf31\ud9c2\udde1\udbfe\udd1e", "\u8a05\u2405\u8b33\u28a0", "\ud8fb\udcbb\ud804\udd30\uda35\udc1d\ud875\udccb\udbbd\udfce\uda76\udc41\ud8a6\ude54\ud82c\udcb0\ud9b0\ude0f\ud8bf\udfbc\ud912\ude90\udbd5\udc33\uda40\ude3e\ud8c6\udc82\ud8fc\udc27\udb89\uddef\udbb1\ude6d\ud87b\udd04\udba3\udfff\udbd8\udf87\ud87f\udef4\udb87\udd9f\ud92f\udf92\uda19\udd36\udbc3\udf04\ud8b1\udf88\ud917\udf6e\udaa5\udcb1\udb51\udefe\udb65\ude4f\ud8a8\udef6\ud808\udf50\udb19\udfe1\ud82c\udf4b\ud837\uddcd\u26a9\ud891\udcbf\udb60\udfe0\udbf2\udefc\ud809\udeb6\udb6c\udd27",
        47, 92440, -1232016765, 3304649732472241803L, 99450L, false, false, (char) 22890, (char) 38172,
        Double.longBitsToDouble(0x3f80282876fe6d40L), Double.longBitsToDouble(0x3feb4093934eeaf9L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 1, 6, 14, 8, "\udb25\udf03\ud8bb\udee8\ud98a\udc7a\ud882\udf81\ud989\udc22\ud9ad\udc5a\ud9aa\udd67\udb93\udcef\uda71\uddd9\ud892\udf04\udaf9\udc87\ud8fb\udcbb\ud804\udd30\uda35\udc1d\udb44\udf33\udbbd\udfe8\uda76\udc41\ud8a6\ude54\ud82c\udcb0\ud9b0\ude0f\ud8bf\udfbc\ud912\ude90\ud82f\udc6b\udb87\udfdd\udb75\udfae\udbba\udcb8\udacf\udd87\udb33\udfcb\ud87b\udd04", "\u0f00", "\ud895\udeeb\ud9f6\uddec\ud90b\udfb9\ud917\udf6e\udaa5\udcb1\udb50\udd7b\uda29\ude72\ud86f\ude27\ud8d8\udcb8\ud927\udfe5\ud87d\ude88\ud88f\udd9c\uda7e\udf53\ud89a\udf64\udb60\udfe0\udbf6\udf97\ud83e\udc51",
        23, 12186, 362251024, 2748298044659038572L, -1750L, false, true, (char) 38172, (char) 1867,
        Double.longBitsToDouble(0x3faf6fa565bce600L), Double.longBitsToDouble(0x3fea393c79075709L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 10, "\udb25\udf03\ud9c2\uddcb\udb5d\udf8c\ud882\udf81\ud97f\udf22\ud9ad\udc5a\ud8ff\udc94", "\u2800\u6451\ub2c6", "\udb44\udf33\udbbd\udf9f\uda76\udc41\ud8f3\udc7b\ud8d3\ude51",
        25, 8968, -1482680343, 6724804639722845797L, -90374L, false, false, (char) 44822, (char) 54516,
        Double.longBitsToDouble(0x3fc5e538bb2df094L), Double.longBitsToDouble(0x3fe5c2833711c01dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 8, 2, 8, "\udaa3\udec3\udbe2\ude4b\udb52\udd8c\ud882\udf81\ud989\udc22\ud9ad\udc5a\ud9aa\udd67", "\ud342\u60ce\u717e", "\ud858\udf3d\uda92\udeb2\uda73\udca1\uda69\udeac\ud82c\udcfb",
        25, 98584, -1482680448, 6724804639773177445L, -90374L, false, true, (char) 44822, (char) 51794,
        Double.longBitsToDouble(0x3fd17f9b83527d5eL), Double.longBitsToDouble(0x3fe5c5f577565197L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=void |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 6, 6, 8, "\udb25\udf03\ud9c2\uddcb\udb5d\udf8c\ud882\udf81\ud97f\udf22\ud9ad\udc5a\ud8ff\udc94", "\u2800\u6451\ub2c6\ub856\u4d65\u2ddf\ub8a4\u5969\uc0cb\ub7bf\u39b7\u76c8\ud72a\u1ccd\u1760", "\udb56\udc6f\udbb1\ude6d\ud87b\udd04\udba3\udfff\udbd8\udf87\ud87f\udef4\uda7b\udf3a\uda03\udddd\udb54\udd44\ud966\udf3f\udb64\ude0a\ud85a\udeeb\ud8cd\udf68\udaae\ude58\udb04\udc1b\udb08\udddb\udaba\ude54\udacb\udc6c\udb4c\udf33\udb35\udcc7\udbd9\udf8d\ud98b\udeb7\u1cc0\ud95e\udfc4\uda1b\udf50\udbf8\udf3c\ud8aa\udd4f\uda91\ude57\ud9b1\ude12\udb17\udda0\udace\udfa4\ud873\udcc8\ud936\udeb1\ud9fe\udc70\ud8e7\udc0c\ud865\udcb5\ud83f\udee3\udb29\uddd7\ud950\ude0b\udad9\udc39\ud8dd\udfcd\ud947\udd39\u9e6d\ud946\udc31\udb95\udccc\ud84c\udc87\ud81e\udf62\udba2\uddb8\uda18\udd4d",
        36, 36789, -1994236710, 2157321028705344416L, 94105L, true, false, (char) 3098, (char) 33281,
        Double.longBitsToDouble(0x3fd3722ad7dd2e12L), Double.longBitsToDouble(0x3fe3b99587635a3dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 14, 8, "\udb25\udf03\ud9c2\uddcb\udb5d\udf8c\ud882\udf81\ud989\udc22\ud9ad\udc5a\ud9aa\udd67\udb93\udcef\uda71\uddd9\ud892\udf04\udaf9\udc87\ud8fb\udcbb\ud804\udd30\uda35\udc1d", "\u5969\u4665\u8217\u3fb8", "\udbd5\udc33\uda40\ude3e\ud8c6\udc82\ud8fc\udc27\udb89\uddef\udbb1\ude6d\ud87b\udd04\udba3\udfff\udbd8\udf87\ud87f\udef4\udb87\udd9f\udbb2\udd33\uda19\udd36\udbc3\udf04\ud8b1\udf88\ud917\udf6e\udaa5\udcb1\udb50\udcfe\udb65\ude4f\ud8a8\udef6\ud8d8\udcb8\ud927\udfe5\ud87d\ude88\ud88f\udd9c\u26a9",
        5, 86063, 921886656, -8587195336411393499L, -68916L, true, false, (char) 22215, (char) 31937,
        Double.longBitsToDouble(0x3f7bf1b1ea36cb00L), Double.longBitsToDouble(0x3fe97baf6b371414L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\0121=com.fasterxml.jackson.core.filter.TokenFilterContext:/ |this=com.fasterxml.jackson.core.filter.FilteringParserDelegate:@?\012",
        Z.run(T, 2, 4, 4, 8, "\udb25\udf03\ud936\udee6\ud9df\udc5a\ud882\udf81\uda03\udc1f\ud9ad\udc5a\ud9aa\udd67\udb93\udcef\uda71\uddd9\udacb\udc22\ud99b\udcf2\udb42\udebd\uda63\udc29\ud96d\udc19", "\ub340\u46d6\u8217\u6425", "\udb40\ude3b\udbd2\ude13\ud8c6\udc82\ud8cb\udf27\udb89\uddef\udbb1\ude6d",
        25, 30072, 578506602, -4603494010688332015L, -46801L, true, true, (char) 32654, (char) 6887,
        Double.longBitsToDouble(0x3fc40039596ef530L), Double.longBitsToDouble(0x3fef0b6066d06ef8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextToken2||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextTokenWithBuffering|com.fasterxml.jackson.core.filter.TokenFilterContext|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_verifyAllowedMatches||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|nextToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_filterContext||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextBuffered|com.fasterxml.jackson.core.filter.TokenFilterContext|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|clearCurrentToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|currentToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|currentTokenId||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getBigIntegerValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getBinaryValue|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getBooleanValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getByteValue||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentLocation||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentName||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|getCurrentToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextToken2||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_nextTokenWithBuffering|com.fasterxml.jackson.core.filter.TokenFilterContext|new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|_verifyAllowedMatches||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
    "M|com.fasterxml.jackson.core.filter.FilteringParserDelegate|nextToken||new:com.fasterxml.jackson.core.filter.FilteringParserDelegate:com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.core.filter.TokenFilter,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
