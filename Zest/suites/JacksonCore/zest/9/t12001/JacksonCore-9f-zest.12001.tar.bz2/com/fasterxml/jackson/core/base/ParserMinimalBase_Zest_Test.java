package com.fasterxml.jackson.core.base;
import org.junit.Test;
import static org.junit.Assert.*;
public class ParserMinimalBase_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 19, 2, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\udaea\ude24\uda0b\udca8\ud920\udd75\udb35\udcd2\uda7b\uddac\uda95\ude13\ud80f\udff3\ud94e\uddfd\uda82\udcbd\udb73\udcc4\ud828\udd2d\ud922\udc7a", "\u3641\u89bc\u8532\u9141\u4380\u0fc1\u805a\uc3db\u34d7\u6743", "\ud83a\udc25\ud8be\udf64\udaeb\udcb0\udbc5\udca7\udaf7\udc77\uda68\ude96\udb5e\udddb\udb1a\udc74\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud876\udff8",
        49, 67361, -590575723, 7021181358407568846L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3f9745db3e9cfaa0L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 19, 2, "\uda7f\udfd2\uda10\udd71\ud913\udede\ud951\udd5b\udaea\ude24\uda0b\udca8\udaf2\udfbd\udb35\udcd2\uda7b\uddac\uda95\ude13\ud80f\udff3\ud958\udca2\ud915\ude9f\udb73\udcc4\ud828\udd2d\ud922\udc7a", "\u3641\u89bc\u8532\u9141\u4380\u0fc1\u805a\uc3db\ua998\u0a91", "\ud83a\udc25\ud8be\udf64\udaeb\udcb0\udbc5\udca7\udaf7\udc77\uda68\ude96\udb5e\udddb\udb1a\udc74\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud880\udf73",
        56, 12067, -590575723, 7021181358407568846L, -85307L, false, false, (char) 48626, (char) 27081,
        Double.longBitsToDouble(0x3fdee43494104bf8L), Double.longBitsToDouble(0x3fec4b0b13470b3aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 13, 2, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\udaea\ude24\uda0b\udca8\ud920\udd75\udb35\udcd2\uda7b\uddac\uda95\ude13\ud80f\udff3\ud94e\uddfd\uda82\udcbd\udb73\udcc4\ud828\udd2d\ud922\udc7a", "\u3641\u89bc\u8532\u9141\u4380\u0fc1\u805a\uc3db\u34d7\u6743", "\ud83a\udc25\ud8be\udf64\uda53\udcc3\udbc5\udc11\udaf7\udc77\uda68\ude96\udb5e\udddb\udb1a\udc74\ud983\udc15\ud878\uddb5\ud9ad\udfa2\ud876\udff8",
        49, 67361, 1942652821, 7021318793066073550L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3f9745db3e9cfaa0L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 19, 2, "\udabe\udd40\ud916\ude93\ud901\ude08\udb98\udec2\udaea\ude24\ud9e6\udea8\ud920\udd75\udb35\udcd2\udace\ude86\uda95\ude13\ud80f\udff3\ud8d1\udc74\uda99\udd09\udb73\udcc4\ud9c3\ude03\uda1c\udd34", "\u9b11\u89bc\u8532\u9141\u039c", "\ud815\udf1e\ud8cc\udfde\udb7f\udc80\udb17\ude7d\ud89b\udf5d\ud83a\udc25\ud8be\udf64\udaeb\udcb0\ud819\udc11\udaab\udfba\udb4d\uddd4\udb78\ude00\udb1a\udc74\ud983\udc15\ud821\udef2",
        23, 16262, -391999216, -1697567092495120491L, -971L, false, false, (char) 39552, (char) 11239,
        Double.longBitsToDouble(0x3fed1bfa56d1c802L), Double.longBitsToDouble(0x3f97a8ea3e9cfaa0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 19, 2, "\ud8db\udf6a\udaa6\ude8d\ud913\udede\ud951\udd5b\udaea\ude24\ud9ee\ude9c\ud86b\ude89\udb55\ude99\uda7b\uddac\uda95\ude13\ud823\udc73\udaad\udcf3\uda82\udcbd\udb73\udcc4\udb22\udc4a\ud8f7\udde1", "\u781c\u1a26\ucd35\u3577\u9880\uc189\u805a", "\udb7f\udc80\udb17\ude7d\ud830\udd57\ud950\uddb4\ud8e9\ude4a\udaeb\udcb0\udbc5\udca7\udaf7\udc77\uda68\ude96\udb5e\udddb\udb1a\udc74",
        16, 98345, 871249043, 2876113089753944336L, -42843L, true, true, (char) 16544, (char) 63378,
        Double.longBitsToDouble(0x3fc25ff30f9bc230L), Double.longBitsToDouble(0x3fd54a2353e9cfaaL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 1, 18, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\udaea\ude24\uda0b\udca8\ud920\udd75\udb35\udcd2\uda7b\uddac\uda10\udd77\ub71e\udb94\udf18\ud172\udbec\udf38\uda88\udf2c\ud957\ude7a", "\u5d27\u89bc\u8532\ua76f\u4334\u0fc1\u805a\uc3db\u34d7\u6743", "\ud83a\udc25\ud8be\udf64\udaeb\udcb0\udbc5\udca7\udaf7\udc77\uda68\ude96\udb5e\udddb\udb1a\udc74\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud876\udff8",
        49, 67361, -590575723, 7021181358407590509L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3f9745db3e9cfaa0L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\ufffd\020\ufffdA\ufffd\ufffd!+ |a0=[B:[[-114, 16, -32, 65, -29, -82, 33, 43]]\012",
        Z.run(T, 1, 6, 4, 2, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\ud901\udc8f\ud9cf\udc06\ud920\udd75\udb35\udcd2\uda7b\uddac\uda95\ude13`\ud94e\uddfd\uda82\udcbd\udbda\udf78\000\ud922\udc7a", "\u09c7\u89bc\u8532\u9141\u4380\u0fc1\u805a\uc3db\u34d7\u00cd", "\ud83a\udc25\ud919\ude57\udaeb\udcb0\udbc5\udca7\udb5b\udd0a\uda68\ude96\udb5e\udddb\udb1a\udc74\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud876\udff8",
        49, 67361, -590575723, 7021181358407568846L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3f9745db3e9cfaa0L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 11, 2, "\udae5\udc36\uda10\udd71\ud913\udede\ud951\udd5b\udbfe\udd27\uda0b\udca8\ud920\udd75\udbe9\udeac\udba0\udc0d\uda95\ude13\ud80f\udff3\ud94e\uddfd\uda14\udebb", "\uaad0\u3096\u51dd\ua76d\u89b8\u949a\u91a2\u4380\u0fc1\u805a\uc3db", "\udb17\ude7d\ud9ee\udd58\udae2\udc19\ud8c1\udd5d\udaeb\udcb0\udbc5\udca7\udaf7\udc77\uda68\ude96\udb5e\udddb\udb1a\udc74\ud983\udc15",
        52, 22043, 669647262, -1683623813172885575L, -87818L, true, true, (char) 47972, (char) 47279,
        Double.longBitsToDouble(0x3fb1c2860006f2d8L), Double.longBitsToDouble(0x3fdf4e7d57dc8692L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 20, 19, 2, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\udaea\ude24\uda0b\udca8\ud920\udd75\udb35\udcd2\uda7b\uddac\uda95\ude13\u9193\ud94e\uddfd\uda82\udcbd\udb73\udcc4\ud828\udd2d\ud922\udc7a", "\u3641\u89bc\u8532\u9141\u4380\u0fc1\u805a\uc3db\u34d7\u6743", "\ud83a\udc25\ud8be\udf64\udaeb\udcb0\udbc5\udca7\007\uda5a\udc4c\udb74\udd1a\udb19\udfee]\ud902\udec1\ud9ad\udfa2\ud876\udff8",
        16, -1000, 0, 7021181087824629198L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3e2f4e7000000000L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[B:[[-66, 64, 16, 113, 19, -34, 81, 91, -22, 36, 11, -88, 32, 117, 53, -46, 123, -84, -107, 19, 15, -13, 78, -3, -126, -67, 115, -60, 40, 45, 34, 122]]\012",
        Z.run(T, 1, 7, 3, 2, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\udaea\ude24\uda0b\udca8\ud920\udd75\udb35\udcd2\uda7b\uddac\uda95\ude13\ud80f\udff3\ud94e\uddfd\uda82\udcbd\udb73\udcc4\ud828\udd2d\ud922\udc7a", "\u3641\u89bc\u8532\u9141\u4380\u0fc1\u805a\u0b36\u346b\u3d7c", "\ud83a\udc25\ud8be\udf64\udaeb\udcb0\udbc5\udca7\udaf7\udc77\udbb8\udffa\ud9c6\udf3f\udb1a\udc74\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud876\udff8\ud9e3\udfaf\uda3b\ude55\udbbb\udd29\u34fd",
        -4, -998, -572173407, 9172387129833568613L, -49471L, true, false, (char) 30007, (char) 43011,
        Double.longBitsToDouble(0x3fe81eac3bec9c59L), Double.longBitsToDouble(0x3fd2a0b25a703cf8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:'1' (code 49)\012",
        Z.run(T, 1, 10, 5, 2, "\udabe\udd40\uda84\udd0e\ud8e8\udfc8\ud951\udd5b\udaea\ude24\uda0b\udca8\ud920\udd75\udb35\udcd2\uda7b\uddac\uda95\ude13\ud80f\udff3\ud94e\uddfd\udb3b\udc12\udb73\udcc4\ud828\udd2d\ud922\udc7a", "\u3641\u89bc\u8532\u9141\u4380\u0fc1\u805a\u6c72\u34d7\u67e3", "\ud8d1\udf84\ud8bf\udc0c\udaeb\udcb0\ud8e5\udcc7\udbed\udec1\uda2e\udd17\udbf1\udd8c\udb1a\udc11\ud983\udc15\ud821\udef2\ud9ad\udfc3\ud912\ude06",
        49, 67361, -603092460, 7021181358407568846L, -13055L, true, true, (char) 61108, (char) 50531,
        Double.longBitsToDouble(0x3fe72414a17bcb81L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:(CTRL-CHAR, code 5)\012",
        Z.run(T, 1, 10, 19, 12, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\udaea\ude24\ud9d1\udc85\ud920\udd75\udb35\udcd2\ud92d\ude25\uda95\ude13\ud9e6\udc3e\ud935\udc39\uda82\udcbd\udb29\udfbf\u7fe8\ud9a9\udc9b", "\u3641\u89bc\u8532\u9141\u4380\u0fc1\u805a\uc3db\u34d7\u6743", "\ud83a\udc25\ud8be\udf64\udaeb\udcb0\ud85a\udc31\u3a8c\uda97\udecf\udb5e\udddb\ud851\udf09\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud950\udf98",
        5, 60229, -592918291, 7021181358407568846L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3f9745db3e9cfaa0L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\ufffd\020 |a0=[B:[[-114, 16]]\012",
        Z.run(T, 1, 6, 19, 2, "\udabe\udd40", "e\u14bc\u8997", "\uda7b\uddac\uda95\ude13\ud80f\udff3\ud944\udf58\uda82\udcdb\udb90\udda2\ud881\udc2e",
        47, 11988, -639536490, 4318112182414333807L, -26117L, true, true, (char) 45438, (char) 4981,
        Double.longBitsToDouble(0x3fdb3631bd2cfd62L), Double.longBitsToDouble(0x3fee367f4ecda6a6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[B:[[-66, 64, 22, -109, -87, -96, 4, -22, 30, -9, 118, 67, 87, 41, 21, -115, 65, 8, 15, -13, -9, 48, -103, 9, 115, -60, 52, 92, 8, 4]]\012",
        Z.run(T, 1, 7, 13, 8, "\udabe\udd40\ud916\ude93\udba9\udea0\ub104\udaea\ude1e\ud8f7\ude76\uac43\uda57\udc29\udb15\udc8d\udb41\udf08\ud80f\udff3\ud8f7\ude30\uda99\udd09\udb73\udcc4\ud834\ude5c\uda08\udf04", "\u9b6f\u8daa\u852f", "\uda86\udcf5\ud871\udf26\udaba\uddc7\ud8cc\udfde\udb68\udca9\udb6c\udc73\ud89b\udf5d\udbcb\udc23\uda1e\ude1d\ud82c\uddaf\ud819\udc11\udaab\udfba\udb4d\uddd4\udb78\ude00\udb08\ude1d\ud983\udc15\ud86c\udd77\udb03\udcab\ud877\udc1d\ud9e3\udfaf\uda3b\ude55",
        3, 39992, -478511829, 5107029656500966817L, 72963L, true, false, (char) 8450, (char) 27081,
        Double.longBitsToDouble(0x3fc4dd642160f9a8L), Double.longBitsToDouble(0x3fea4ffd9f13d7e3L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 1, 5, "\udabe\udd56\uda10\udd71", "\u3e8c", "\udb35\udcd2\uda7b\uddac\uda10\udd77\ub71e\ud8bc\udf1c\ubeb3\udbec\udf38\uda88\udf2c\ud957\ude7a\udb8f\udd2d\udb9e\udc56\udb2d\udd4e\uda92\udf18\udbd8\uddb8",
        53, 78799, 990669253, 7483932832678669747L, -57275L, false, true, (char) 13312, (char) 21669,
        Double.longBitsToDouble(0x3fe01904a5072156L), Double.longBitsToDouble(0x3fe253f208bc0514L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[B:[[-66, 64]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 15, "\udabe\udd40", "\u217a", "\ub5dd\ud83b\udccb\ud8e6\udd1e\ud8f9\udf17\udb9f\udc2d\uda81\udc48\ud8f4\uddd9\uda70\uddaf\ud8d2\udd2a\ud957\ude7a\udb8a\udee3\udbfa\udf84\ud995\udc7a\uda3a\udcaf\uda87\udd02\uda35\udff4\ud9a2\udd41\udb51\udd3f\udb90\udf60\ud96d\udd2a\ud8ea\udd74\udb7f\udc80\udb17\ude7d\udb4a\udfb5\ud83a\udc25",
        16, 36033, 358947046, -1324133594681500891L, -95526L, true, true, (char) 16972, (char) 56412,
        Double.longBitsToDouble(0x3fd9e33ee2204fd4L), Double.longBitsToDouble(0x3fedcf451795e871L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 18, 18, "\000", "e\u14bc\u7196", "\uda7b\uddac\uda10\udd77\ub71e\udb94\udf18\ud172\udbec\udf38\uda88\udf2c",
        7, 11988, -639536490, -841610181219299815L, 26387L, false, false, (char) 2168, (char) 31977,
        Double.longBitsToDouble(0x3fd1bfabfe01c4e6L), Double.longBitsToDouble(0x3efb540000000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\ufffd\020\ufffdA\ufffd\ufffd!+ |a0=[B:[[-114, 16, -32, 65, -29, -82, 33, 43]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 2, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\ud901\udc8f\ud9cf\udc06\ud920\udd75\uda41\udd40\ud884\udd29\uda95\ude71`\ud94e\uddfd\uda82\udcbd\udbda\udf78\000\ud922\udc7a", "\u0a7e\u89bc\u8532\u9141\u4380\ub9b3\u4df5\uc3db\u34d7\u00cd", "\ud83a\udc25\udb63\udc7b\udae7\udea3\ud978\udc01\udb73\udcfa\uda68\uded9\udb5e\udddb\udb1a\udc74\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud876\udff8",
        49, 67361, -590575723, 7021181359680108813L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3f9745db3e9cfaa0L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[B:[[-66, 64, 16, 113, 19, -34, 81, 91]]\012",
        Z.run(T, 1, 7, 19, 0, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b", "\u9ec9\u732e", "`\ud94e\uddfd\uda82\udcbd\udbda\udf78\000\ud922\udc7a\udb8f\udd2d\udaeb\udfcd\uda51\udc7e\uda92\udf96\udbd8\uddb8\u0195\ud860\ude8a\udb51\udd3f\udb90\udf60\ud96d\udd2a\ud8ea\udd74\u00cd\udae1\udfb0\ud89b\udf5d\ud83a\udc25\ud919\ude57",
        8, 68699, 2945108, 365981557268447420L, -17731L, true, false, (char) 56445, (char) 13708,
        Double.longBitsToDouble(0x3fd1027ea659d144L), Double.longBitsToDouble(0x3fecaf43e73fdcccL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[B:[[0]]\012",
        Z.run(T, 1, 7, 0, 3, "\000", "e\u14bc\u8997", "\uda7b\uddac\uda95\ude13\u9193\ud94e\uddfd\uda82\udcbd\udb73\udcc4\ud828\udd2d",
        47, 11988, -639536490, -841605675798606311L, -26117L, true, true, (char) 61919, (char) 32846,
        Double.longBitsToDouble(0x3fdb367dcd70fd62L), Double.longBitsToDouble(0x3fdcda6aad9b4c38L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:(CTRL-CHAR, code 30)\0121=java.lang.String:\ufffd\020\ufffdA\ufffd\ufffd!+ |a0=[B:[[-114, 16, -32, 65, -28, -82, 33, 43]]\012",
        Z.run(T, 2, 10, 6, 2, "\udabe\udd40\uda10\udd71\ud914\uddde\ud951\udd5b\udaea\ude24\uda0b\udca8\ud920\udd75\udb35\udcd2\uda7b\uddac\uda95\ude13\u9193\ud94e\uddfd\uda82\udcbd\udb73\udcc4\ud828\udd2d\ud922\udc7a", "\u8097\u89bc\u8532\u9141\u4380\u0fc1\u65ed\u76f6\u343b\u6743", "\ud885\udd9e\ud8be\udf64\udaeb\udcb0\ud935\udfdeb\uda5a\udc4c\udb74\udd1a\udb19\udfee]\ud9cf\uddc6\uda09\udeac\ud876\udff8",
        30, -899, 33233, 7021181087824629198L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3e2f4e7000000000L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[B:[[-66, 15, -107, -85]]\012",
        Z.run(T, 1, 7, 3, 9, "\udabe\udd0f\udb95\udeab", "\u4341\u2b21", "\ud867\udf62\uda95\ude13\ud80f\udff3\ud94e\uddfd\ud88c\udf43\udb73\udc91\ud828\udd2d",
        47, 11988, -639536490, -841605675798606311L, -26117L, true, true, (char) 11658, (char) 49919,
        Double.longBitsToDouble(0x3fc931aac708ec64L), Double.longBitsToDouble(0x3fa9d2c34a5971c0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[B:[[85, -52, -59, 81, -11, 69, -11, -3, -22, -71, 11, -88, 32, 117, -9, 116, 123, 125, -107, 19, 40, -65, 25, -25, -92, 88, 26, -61, -51, -124, 63, -128, 42, 16, -98, 86, 32, 104, -110, 24, 79, 78, 12, 105, -47, 68, 89, -116, -112, 96, -99, -119, -22, 8, 58, -98, 72, 0, 24, 49, 84, -124, -66, 100, -21...\012",
        Z.run(T, 1, 7, 18, 19, "\udb55\uddcc\ud9c5\udd51\ud9f5\ude45\udaf5\uddfd\udaea\uddb9\uda0b\udca8\ud920\udd75\udbf7\ude74\uda7b\udd7d\uda95\ude13\udb28\uddbf\ud819\udfe7\ud9a4\udc58\ud81a\udfc3\ud9cd\udc84\ud93f\ude80\udb2a\udc10\udb9e\udc56\udb20\udf68\uda92\udf18\udb4f\ude4e\udb0c\ude69\ud9d1\udc44\uda59\udd8c\udb90\udf60\ud99d\udc89\ud8ea\udd08\uda3a\udf9e\udb48\ude00\uda18\udc31\ud954\udf84\ud8be\udf64\udaeb\udcb0\udbc5\udca7\udaf7\udc77", "\uc512\uc012\u8bbc\u521f\u60ec\u268e", "\udad3\udcff\udab7\udc1f",
        47, 91593, 2135612799, 5194965276524479192L, 13821L, false, true, (char) 8359, (char) 11403,
        Double.longBitsToDouble(0x3fef64e2ce00dd25L), Double.longBitsToDouble(0x3fea1aafe765a452L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:(CTRL-CHAR, code 28)\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 2, "\udabe\udd40\uda84\udd0e\ud8e8\udfc8\ud951\udd5b\udb0b\udc34\ud9ed\udf9a\ud920\udd75\udb35\udcd2\uda7b\uddac\uda95\ude13\udb09\udfe3\ud94e\uddb3\udb31\udd6d\ud98d\udeeb\udb89\uddb9\udaa5\udd6f", "\u3641", "\udbdc\ude45\ud860\ude8a\udb51\udd3f",
        28, 14475, -1498754658, -6439195507859401011L, -20100L, false, true, (char) 62069, (char) 27480,
        Double.longBitsToDouble(0x3fd5d20cb8465c52L), Double.longBitsToDouble(0x3f627f509e33ee00L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:(CTRL-CHAR, code 5)\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 19, 12, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\udaea\ude24\ud9d1\udc85\ud920\udd75\udb35\udcd2\ud92d\ude25\uda95\ude13\ud9e6\udc3e\ud935\udc39\uda82\udcbd\udb38\uded4\u7fe8\ud9a9\udc9b", "\u3641\u89bc\u8532\u9141\u4380\u0fc1\u805a\uc3db\u34d7\u6743", "\ud83a\udc25\ud8be\udf64\udaeb\udcb0\ud87a\udc31\u3a8c\uda97\udecf\udb5e\udddb\ud851\udf09\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud950\udf98",
        5, 60229, -592918291, 7420813153173917134L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3f971fbf3e9cfaa0L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[B:[[-66, 64]]\0121=[B:[[-66, 64]]\012",
        Z.run(T, 2, 7, 7, 15, "\udabe\udd40", "\u217a", "\ub5dd\ud83b\udccb\udbf6\ude60\ud8f9\udf17\udb9f\udc2d\uda81\udc48\ud8f4\uddd9\uda70\uddaf\ud8d2\udd2a\ud957\ude7a\udb8a\udee3\udbfa\udf84\ud995\udc7a\uda3a\udcaf\uda87\udd02\uda35\udff4\ud9a2\udd41\udb51\udd3f\udb90\udf60\ud96d\udd2a\ud966\uded6\udb7f\udc80\udb17\ude7d\udb4a\udfb5\ud848\udd25",
        16, 36033, 1298471142, -1324190872365360347L, -95526L, true, true, (char) 16972, (char) 56412,
        Double.longBitsToDouble(0x3fd9e33ee2204fd4L), Double.longBitsToDouble(0x3fedcf451795e871L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:(CTRL-CHAR, code 16)\0121=java.lang.String:(CTRL-CHAR, code 16)\012",
        Z.run(T, 2, 10, 10, 9, "\udabe\udd40", "\u8a4c", "\ub5dd\ud83b\udccb\ud8e6\udd1e\ud8f9\udf17\udb9f\udc2d\uda81\udc48\ud8f4\uddd9\udb6d\udded\ud8d2\uddbc\ud957\ude7a\udb8a\udee3\udbfa\udf84\ud995\udc7a\uda3a\udcaf\ud8eb\udd11\udbbc\udf89\ud9a2\udd41\ud97b\udcf4\ud81a\udf90\ud87b\udfc6\ud8ea\udcfb\udb7f\udc80\udb17\ude7d\ud89f\udf5d\ud944\udedd",
        16, 36033, 358947046, -1324133594681500891L, -29309L, true, false, (char) 13708, (char) 47353,
        Double.longBitsToDouble(0x3fedcf451795e871L), Double.longBitsToDouble(0x3fefefa23af6eb29L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:\ufffd\020\ufffd\ufffdA\032M\ufffd |a0=[B:[[-114, 16, -116, -41, 65, 26, 77, -72]]\0121=java.lang.String:\ufffd\020\ufffd\ufffdA\032M\ufffd |a0=[B:[[-114, 16, -116, -41, 65, 26, 77, -72]]\012",
        Z.run(T, 2, 6, 6, 15, "\udabe\udd40\ud9bc\udc07\udb71\udf4a\uda7d\udfe8\ud901\udc8f\udbcb\udc04\ud920\udd75\udb9c\udd8d\uda42\uddb3\uda3e\udfbe\ud80d\udfff\udaf0\udf40\u6f92\ud523\u1ee4\ud922\udc7a", "\u0a7e\uc7ae\ubb63\u34ba\u02a4\ub9b3\u4df5\u8801\u03b3\u2e7a", "\ud83a\udc00\udb1e\ude3a\udae7\udea3\ud978\udc01\udb73\udcfa\uda65\udcb8\ud821\udf4b\ud820\udf57\udbb3\udc57\uda25\udcdd\ud849\udc21\ud849\udda3\ud9e3\udfaf",
        0, 62169, 1634746175, 3410272809524383850L, -25631L, true, true, (char) 52695, (char) 12729,
        Double.longBitsToDouble(0x3fdf4e7ba3dc8692L), Double.longBitsToDouble(0x3fe0412fe7f7cac7L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:'6' (code 54)\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 2, "\udabe\udd40", "e\u7637\u1489\u9ec9\u732e", "\udb09\udfe3\ud94e\uddb3\udb31\udd6d\ud98d\udeeb\udb89\uddb9\udaa5\udd6f\ud8e1\udff4\udb68\udc98\u0419\uda92\udf18\udbd8\uddb8\udbdc\ude45\ud860\ude8a\udb51\udd3f\udb90\udf60\uda0e\udd7b\ud8ed\udc5a\udb4f\udc88\ud90d\uded8\000\u31f3\ud8bf\udc0c",
        54, 79167, -322517020, 4344361251660740140L, -17731L, true, false, (char) 33772, (char) 11404,
        Double.longBitsToDouble(0x3fe94566ad7f8c2cL), Double.longBitsToDouble(0x3fe7c9d020abc880L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:(CTRL-CHAR, code 5)\0121=java.lang.String:(CTRL-CHAR, code 5)\012",
        Z.run(T, 2, 10, 10, 12, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\udaea\ude24\ud9d1\udc85\ud920\udd75\udb35\udcd2\ud92d\ude25\uda95\ude13\ud9e6\udc3e\ud935\udc39\uda82\udcbd\udb38\uded4\u7fe8\ud9a9\udc9b", "\u913d\u45d3\u8532\u9141\u4380\u0fc1\u805a\uc3db\u34d7\u6743", "\ud83a\udc25\ud8be\udf64\udaeb\udcb0\ud87a\udc31\u3a8c\uda97\udecf\udb5e\udddb\ud851\udf09\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud950\udf98",
        5, 60229, -592918291, 7420813153173917134L, 52333L, false, false, (char) 46134, (char) 50438,
        Double.longBitsToDouble(0x3f971fbf3e9cfaa0L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:'\ufffd' (code -3)\0121=java.lang.String:'\ufffd' (code -3)\012",
        Z.run(T, 2, 10, 10, 16, "\ua36f\ud998\udc15\ud9fa\ude64\ud80a\udddb\ud893\udcc7\ud9d1\udc85\ud920\udd75\ud965\ude46", "\u83bc\uc167\uaa7c\u7d62\u0a6d\uc63d\u7986\u73b2\ubd5d\u8a77\u102c\ua6d3\u970e\u0f37\u805a\uc3db\u34d7", "\ud9ba\udcd4\ud93e\udc6b\ud8be\udff1\udaeb\udcb0\udbc7\udf64\udab3\udf39\udbcd\udf8a\udb5e\udddb",
        -3, 87645, -1477833693, 3741986146634721950L, 96467L, true, false, (char) 53171, (char) 21066,
        Double.longBitsToDouble(0x3fbab8cb5d0a36f8L), Double.longBitsToDouble(0x3fd7fdde52cafe94L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 19, 2, "\udabe\udd40\uda10\udd71\ud913\udede\ud951\udd5b\udb7e\udd4e\ud8b4\udc87\ud920\udd75\udb35\udcd2\ud9bf\udd8e\ud992\udf2a\ud810\udc7f\ud94e\uddfd\uda82\udcbd\udb73\udcc4\ud828\udd2d\ud922\udc7a", "\u3641\u89bc2\u9141\u4380\u0fc1\u805a\uc3db\u34d7\u6743", "\ud83a\udc25\ud8be\udf64\udaeb\udcb0\udbc5\udca7\udaf7\udc77\uda68\ude96\udb5e\udddb\udb1a\udc74\ud983\udc15\ud821\udef2\ud9ad\udfa2\ud876\udff8",
        49, 67361, -590575723, 7021181360736259534L, -13055L, true, true, (char) 47279, (char) 50438,
        Double.longBitsToDouble(0x3f9745db3e9cfaa0L), Double.longBitsToDouble(0x3fdee43494104bf8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[B:[[85, -52, -59, 81, -11, -90, -11, -3, -22, -71, 11, -88, 32, 117, -9, 116, 123, 125, -107, 19, 40, -65, 25, -25, -92, 88, 26, -61, -51, -124, 63, -128, 42, 16, -98, 86, 32, 104, -110, 24, 79, 78, 12, 105, 74, -5, 124, 36, -47, 33, -99, -119, -107, -67, 9, 101, 4, 24, 49, 84, -124, 107, 89, 55, 84, ...\012",
        Z.run(T, 1, 7, 18, 19, "\udb55\uddcc\ud9c5\udd51\ud9f5\udea6\udaf5\uddfd\udaea\uddb9\uda0b\udca8\ud920\udd75\udbf7\ude74\uda7b\udd7d\uda95\ude13\udb28\uddbf\ud819\udfe7\ud9a4\udc58\ud81a\udfc3\ud9cd\udc84\ud93f\ude80\udb2a\udc10\udb9e\udc56\udb20\udf68\uda92\udf18\udb4f\ude4e\udb0c\ude69\uda4a\udcfb\uda7c\udc24\ud8d1\udc21\ud99d\udc89\uda95\udfbd\u3e09\udb65\udc04\uda18\udc31\ud954\udf84\ud96b\udc59\ud837\udf54\udbc5\udca7\ud9c5\udc7e\udbb8\udffa\ud82d\udd45\udbca\udcda\udb6f\udfcb\ud821\udef2\udbc8\udc9c\ud8ad\uddf9\uda6f\ude94\ud8d2\udf63\ud9c2\udff5\udad3\udcfb\udab7\udc1f\ud8d1\udc97\ud9d0\udd9e\ud97b\udcff\uda8f\udda4\u343e\udb29\udedc\ud860\udc94\ud919\uddb3\ud8f7\ude2a\uda56\udd23\uda05\udef3\ud97d\udc4e\udb8d\udc58\ud9c2\udcde\ud8b6\udda6\ud920\udfad\udb2d\ude10\udafc\ude85\ud9b7\udf29", "\u7e15\ub1f6\u371f\uc1cd\u6751\u8499\u34f9\u7610\u9e02\u0d70\u9e47\u37d7\ua421\u7d42\u887e\u50f5\u02a2\u353c\u6fe1\u0a59\ucc68\u58fc\uc17d\u62fe", "\udacc\udc6c\ud8f3\udcca\ud987\ude02\ud9c0\udfcb\ud9f2\udd5b",
        20, 60842, -383936053, -9004286464103151245L, 73093L, false, false, (char) 47893, (char) 41462,
        Double.longBitsToDouble(0x3fec4fd3afbef36cL), Double.longBitsToDouble(0x3fde4fb6cd162eeeL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[-66, 64, -63, -22, -100, -16, 107, -22, 36, 16, -53, 27, 59, -53, -26, 30, -7, 23, -97, 45, -127, 72, -12, -39, 112, -81, -46, 42, 87, 122, -118, -29, -6, -124, -107, 122, -88, 38, 40, 112, 53, -12, -94, 65, -101, -91, 119, -17, -83, -24, -101, 104, 107, 23, 125, 74, -75, 58, 37, -66, 100, -122, 6...\0121=[B:[[-66, 64, -63, -22, -100, -16, 107, -22, 36, 16, -53, 27, 59, -53, -26, 30, -7, 23, -97, 45, -127, 72, -12, -39, 112, -81, -46, 42, 87, 122, -118, -29, -6, -124, -107, 122, -88, 38, 40, 112, 53, -12, -94, 65, -101, -91, 119, -17, -83, -24, -101, 104, 107, 23, 125, 74, -75, 58, 37, -66, 100, -122, 6...\012",
        Z.run(T, 2, 7, 7, 3, "\udabe\udd40\udbc1\udcea\uf49c\udbf0\udf6b\udaea\ude24\uda10\uddcb\ue71b\ud83b\udccb\ud8e6\udd1e\ud8f9\udf17\udb9f\udc2d\uda81\udc48\ud8f4\uddd9\uda70\uddaf\ud8d2\udd2a\ud957\ude7a\udb8a\udee3\udbfa\udf84\ud995\udc7a\ud9a8\udd26\uda28\udc70\uda35\udff4\ud9a2\udd41\ud89b\udea5\u0777\udaef\udcad\ud9e8\ude9b\uda68\udc6b\udb17\ude7d\udb4a\udfb5\ud83a\udc25\ud8be\udf64\ud886\udd3c\udb0c\ude28", "\u37e7\uc564\ua217\u7b95\u7f35", "\uda3b\ude55\ud9c5\udca6\ud84d\ude95",
        10, 94260, 554530002, 1841067210050746374L, 45306L, true, true, (char) 3270, (char) 2965,
        Double.longBitsToDouble(0x3fe26b4efe4b9fc4L), Double.longBitsToDouble(0x3feb1440e8761652L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|getValueAsString||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|getValueAsString|java.lang.String|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|getValueAsString||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|getValueAsString|java.lang.String|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|getValueAsString||new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|getValueAsString|java.lang.String|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_ascii|[B|static",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_asciiBytes|java.lang.String|static",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_constructError|java.lang.String,java.lang.Throwable|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_decodeBase64|java.lang.String,com.fasterxml.jackson.core.util.ByteArrayBuilder,com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_getCharDesc|int|static",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_handleEOF||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_handleUnrecognizedCharacterEscape|char|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_hasTextualNull|java.lang.String|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_reportBase64EOF||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|_reportError|java.lang.String|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|getValueAsString||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.base.ParserMinimalBase|getValueAsString|java.lang.String|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|getValueAsString||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|getValueAsString|java.lang.String|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|getValueAsString||new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|getValueAsString|java.lang.String|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer,[B,int,int,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
