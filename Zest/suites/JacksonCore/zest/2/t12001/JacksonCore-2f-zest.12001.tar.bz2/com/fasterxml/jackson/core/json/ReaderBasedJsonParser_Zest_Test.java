package com.fasterxml.jackson.core.json;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReaderBasedJsonParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\udb15\udfeb\ud8c0\udcb3\uda8f\uddf8\udb08\udf60\ud903\udc3d", "\u5c96\uabd7\u1e7b\u5ede\u4342\u4ed1\u8d93\ua440\u0af7\u4138\u1766", "\udafd\udfa9\ud9c9\uddd3\uda61\udcb4\ud801\ude84\ud8eb\udcc8\ud8a2\udef0\udb4c\udfbd\udace\udc6a\uda51\udf6d",
        20, 59670, -153974812, -8732642762946629527L, -65210L, false, false, (char) 57849, (char) 37004,
        Double.longBitsToDouble(0x3f97609e39aa3280L), Double.longBitsToDouble(0x3fe92486f933f431L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 9, "\ud8b4\udcbb\uda07\ude72\ud96f\udddd\udb08\udfdd\ud903\udc3d", "\ubf96\u794b\uc1e7\ua629\u4c8e\ud2b5\u549e\u2a8e\u0af7\u4138\u1766\u8281\u27a5\uca7e", "\ud801\ude84\ud8eb\udcc8\ud8a2\udef0\udb4c\udfbd\udace\udc6a\uda51\udf6d\uda28\ude2e\ud87c\udc6a\ud9b9\ude81\u4489",
        0, 93272, -1619349310, -7793239105841836511L, 55323L, true, true, (char) 61455, (char) 11621,
        Double.longBitsToDouble(0x3fcbc08022714a40L), Double.longBitsToDouble(0x3fd0b52e2bbb130eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 1, 8, "\u53ec\ud87e\udc8a\uda8f\uddf8\udbbe\udfdf\ud903\udc3d", "\u5c96\ua767\u1e7b\000\u4342\u4ed1\u8d93\ua440\u0af7\000\000", "\udafd\udfa9",
        49, 72959, 58624, 889880320L, -2836L, true, true, (char) 32398, (char) 40986,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e27bb42e0000000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 7, 8, "\udb15\udfeb\ud94e\uddfb\uda30\ude6b\udb74\udd8b\ud8bc\uddd2", "\u5c96\uabd7\u8b05\u6bc0\u4342\u4ed1\u8d93\ua440\u54d7\u6c57\u7a45\u0f23", "\ud9cd\udedb\ud97e\udd15\udbe9\udefb\ud98a\uddd1\udb2e\udfb2\udb48\udf3e\udae0\ude6a\uda51\udf6d\uda6b\udc8d\ud852\ude30\uda0d\udf59\uda91\udc88\ud85c\udff1\ud905\udde3\ud817\udf51\uda24\udf79\uda72\udfb0\uda93\udfa0\udaeb\udce5\udbe0\udc1b\udb92\uddf2\udb99\udf18\ud8b0\udfb0\ud9a3\ude76\ud8c3\udd93\udaa8\udcb2\udbbb\ude36\uda65\udc07\u7ec9",
        29, 8883, -441418144, 4514052408258651856L, 30472L, true, true, (char) 2644, (char) 1544,
        Double.longBitsToDouble(0x3fe6f37c84a41294L), Double.longBitsToDouble(0x3fe47632822c7dbdL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 18, 8, "\udb15\udfeb\ud8c0\udcb3\uda8f\uddf8\udb08\udf60\ud903\udc3d", "\u5c96\uabd7\u1e7b\u5ede\u4342", "\udaf9\udeeb\uda7b\ude08\udbe5\udd90\uda62\udd97\udb71\udcc0\ud8a2\udc31\udafd\udfa9\ud9c9\uddd3\uda61\udcb4\ud801\ude84\ud8eb\udcc8\ud8a2\udef0",
        42, 1684, -1598474997, 8218187328118795790L, -62029L, true, false, (char) 17833, (char) 46725,
        Double.longBitsToDouble(0x3fe76262462193d8L), Double.longBitsToDouble(0x3fdefd69d02ec13cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\udbb2\ude62", "\uccac\ub2f4\u87d6\u4f16\u5c96\uabd7\u1e7b", "\ud992\udf25\ud8b1\udf18\udbf7\udff4\uda7b\ude08\udbed\udc10\uda62\udd97\udb71\udcc0\u4029\udafd\udfa9",
        49, 38527, 288089473, 8665468507687387088L, -2836L, true, true, (char) 54645, (char) 40986,
        Double.longBitsToDouble(0x3fef22311badf6d2L), Double.longBitsToDouble(0x3fba61b3cbdbbed8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 22, 21, 8, "\udb15\udfeb\ud8c0\udd1e\uda8f\uddf8\udb08\udf60\ud903\udc3d", "\u5c96\uabd7\u1e7b\u5ede\u4342\u4ed1\u9a45\u3ac0\u3231\u4138\u1766", "\udafd\udfa9\ud9c9\uddd3\uda61\udcb4\ud801\ude84\ud8eb\udcc8\ud8a2\udef0\udb4c\udfbd\udace\udc6a\uda51\udf6d",
        -5, 10253, -153974812, -8732642762946629527L, -65210L, false, false, (char) 57849, (char) 37004,
        Double.longBitsToDouble(0x3f97609e39aa3280L), Double.longBitsToDouble(0x3fe92486f933f431L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 8, "\udb15\udfeb\ud8c0\udcb3\uda8f\uddf8\udb08\udf60\ud903\udc3d", "\u5c96\uabd7\u1e7b\u5ede\u4342\u4ed1\u8d3e\ua440\u0af7\u4138\u1766", "\uda2e\udf60\ud9c9\udd65\uda61\udcb4\ud801\ude84\ud8eb\udcc8\ud8a2\udef0\udb4c\udfbd\udace\udc6a\uda51\udf6d",
        -2, 59670, -153974812, -8732642762946629527L, -65210L, false, false, (char) 23033, (char) 59011,
        Double.longBitsToDouble(0x3fede92da72e9293L), Double.longBitsToDouble(0x3fe92486f933f431L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 9, 8, "\udb15\udfeb\ud8c0\udcb3\uda8c\udea3\udb08\udf60\ud903\udc3d\ud9b5\udd65\udad6\udea5\ud9b8\udfbf\ud821\udda9", "\u4342\u4ed1\u8d93", "\udb0c\udc6b\uda62\udd97",
        -3, 74365, -1428532043, -8752626044136764049L, 26386L, false, true, (char) 11872, (char) 37348,
        Double.longBitsToDouble(0x3fd0bbb82bb26572L), Double.longBitsToDouble(0x3fe0739067e44623L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 16, "\udb15\udfeb\ud8c0\udcb3\uda8f\uddf8\udb08\udf60", "\u4f16", "\udaa1\udfae\uda26\udfe8\udbaa\ude70\ud992\udf12",
        43, 67183, -1714086898, -2837223909365026379L, 89085L, true, false, (char) 5990, (char) 54263,
        Double.longBitsToDouble(0x3fd817b65b642256L), Double.longBitsToDouble(0x3fee83c20956350aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_parseNumber|int|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_parseNumber2|boolean|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_verifyRootSpace|int|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_parseFloat|[C,int,int,boolean,int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_parseNumber|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_parserNumber2|[C,int,boolean,int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_skipWSOrEnd||new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_verifyRootSpace|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_closeInput||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_decodeBase64|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_decodeEscaped||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_finishString||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_finishString2||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_getText2|com.fasterxml.jackson.core.JsonToken|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_handleApos||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_handleInvalidNumberStart|int,boolean|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_parseNumber|int|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_parseNumber2|boolean|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_verifyRootSpace|int|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_parseFloat|[C,int,int,boolean,int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_parseNumber|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_parserNumber2|[C,int,boolean,int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_skipWSOrEnd||new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_verifyRootSpace|int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer,[B,int,int,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
