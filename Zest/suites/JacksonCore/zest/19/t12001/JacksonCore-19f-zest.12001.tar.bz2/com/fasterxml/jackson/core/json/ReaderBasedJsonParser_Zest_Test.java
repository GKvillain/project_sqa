package com.fasterxml.jackson.core.json;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReaderBasedJsonParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 13, 8, "\ud8c5\uddd5\ud85e\ude6e\uda0b\udf20\ud92b\udf8a\udb1a\udf30\uda6e\udd4b\udaa8\udfbc\udad5\ude0b\uda27\udeb4\ud843\ude7a\udb75\uddc2\ud823\uddb2", "\u98e3\u2453\u95fa\uac8c\u51f8\u8df6\u5dc4\ucd62\u8239\u73f2\uac51\uc518\u80e9\ub20b\u8bd5\u05cb\u0f70\u4b5b\ucd07\u2513\u816b\uc94c\u5aed\u4225\uabae\u75fb\uc8fd\u678e\u6c72", "\uda53\uddb5\uda6d\udf32\ud910\ude66\ud950\udf5a\u26b9\udb30\udf73\ud908\udf4c",
        23, 86647, -361910905, -8888641780923322865L, 19789L, false, true, (char) 35888, (char) 62949,
        Double.longBitsToDouble(0x3fe0124825288d5dL), Double.longBitsToDouble(0x3fe46878d4fbfc55L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 13, 8, "\ud8c5\uddd5\ud85e\ude6e\uda0b\udf20\ud92b\udf8a\udb1a\udf30\uda6e\udd4b\udaa8\udfbc\udad5\ude0b\uda27\udeb4\ud843\ude7a\udb75\uddc2\ud823\uddb2", "\u98e3\u0408\u3713\u93f3\u512d\u8df6\u5dc4\ucd62\u8239\u73f2\uac51\uc518\u80e9\ub20b\u8bd5\u05cb\u0f70\u4b5b\ucd07\u2513\u816b\uc94c\u5aed\u4225\uabae\u75fb\uc8fd\u678e\u6c72", "\uda53\uddb5\uda6d\udf32\ud910\ude66\ud950\udf5a\u26b9\udb30\udf73\ud908\udf4c",
        23, 86647, -361910905, 4802301086282962257L, 19789L, false, true, (char) 35888, (char) 62949,
        Double.longBitsToDouble(0x3fe0124825288d5dL), Double.longBitsToDouble(0x3fe46878d4fbfc55L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 9, 12, "\ud9fa\udc01\ud85e\ude9f\uda0b\udf20\ud92b\udf8a\udae8\ude30\uda6e\udd4b\ud97c\udf78\udb24\udf9a\ud9f7\udeed\ud843\ude7a\udb94\uddc2\uda9a\uddae", "\ub487\u45d8\u80b6\u735d\u51f8\u8df6\ube0f\uaa58\u407a\uada7\u513e\u49a7\u34e6\ub20b\u1eaa\ua8c1\u0f70\u4b5b\ubd5d\ud2df", "\udaa7\udf81\ud8f4\ude14\ud9c4\ude69\uda23\udda8\uda05\udf70\ud926\udfa3\udb61\udcc9\udab2\udcc9\ud941\udd14\uda53\uddb5\uda50\udd51\ud8c3\udd98\udb90\udcc4\ud96d\udf68\udb30\udf58\ud908\udf4c\u3080",
        35, 54818, -1812051233, 5972461961869863313L, 23984L, false, false, (char) 62831, (char) 28422,
        Double.longBitsToDouble(0x3fe94367b7443c6aL), Double.longBitsToDouble(0x3fd79d6c314f99beL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 13, 5, "\ud9e8\udfdf\ud90f\ude6d\uda0b\udfa2\ud92b\udf8a\uda34\ude5d\ud916\udf56\udaa8\udfbc", "\u25ff\u1c94\u76f2\u9c67\u0dab\u98e3\u2453\u95fa\uac8c\u51f8\u9927\u5dc4\ucd62\u8239\u73f2\uac51\uc518\u80e9\ub20b\u8bd5\uabb7\u0fb9\u4b5b\ucd07\u2513\u4a05\u9fce\u5b08\u4225\uc64f", "\ud926\udfa3\udb5c\udcc9\ud998\udc3a\ud97b\ude7c\uda53\uddb5\uda6d\udf32\ud8f1\udc2f\ud950\udf5a",
        1, 29376, 921122832, 8252416448685988815L, 83451L, true, false, (char) 32086, (char) 2796,
        Double.longBitsToDouble(0x3fee831c2a55f1dbL), Double.longBitsToDouble(0x3fe2263d0a024904L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 8, "\ud8c5\uddd5\ud85e\ude6e\uda0b\udf20\ud92b\udf8a\ud9ed\ude79\uda96\udf3b\ud8bc\udc06\udbf9\udcc1\uda99\ude67\ud843\ude7a\udb75\uddc2\ud823\uddb2", "\u4d46\u1777\u95fa\uac8c\u51f8\u8df6\u5dc4\ucd62\u8239\u73f2\uac51\uc518\u80e9\ub20b\u8bd5\u05cb\uc1ce\u0ff0\ucd07\u56bb\u816b\uc94c\u5aed\u4225\uabae\u75fb\uc8fd\u678e\u6c72", "\uda53\uddb5\uda6d\udf32\ud910\ude66\ud950\udf5a\u26b9\udb30\udf73\ud908\udf4c",
        23, 86647, -361910905, -8888641781728629233L, 19789L, false, true, (char) 35888, (char) 62949,
        Double.longBitsToDouble(0x3fe0124825288d5dL), Double.longBitsToDouble(0x3fe46878d4fbfc55L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 2, "\ud8c5\uddf2\ud85e\ude6e\uda0b\udf20\ud92b\udf8a\uda7f\udd22\uda5e\udfa5\udaa8\udfbc", "\u9b53\u0c68\u76f2\u9c67\u131d\u98e3\u2453\u95fa\uac8c\ub4ee\u11c5\u5d96\ucd62\uc4e4\u27d9\u4f77\u9f34\u815f\ub20b\u1de8\u05cb\u986f\u4b5b\ucd07\u2513\u816c\uc94c\u5aed\u4225\uabae", "\ud926\udfa3\udb5c\udcc9\ud998\udc3a\ud97b\ude7c\uda53\uddb5\uda6d\udf32\udbe8\udefd\uda53\ude65",
        32, 66288, 921122832, -1430041278906719402L, -31728L, true, false, (char) 32086, (char) 2796,
        Double.longBitsToDouble(0x3fee864c2a55f149L), Double.longBitsToDouble(0x3fe7563d0d22211fL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 3, "\ud8c5\uddf2\ud98f\ude06\ud9e9\udeb4", "\u88c5\ucc6e\ua4d7\u88b9\u9b53\u0c68\u76f2\u9c67\u131d\u98e3", "\ud8fc\udc38\udb31\udfa3",
        27, 8848, 442854938, 6427651706698567580L, 43563L, true, false, (char) 4229, (char) 21047,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4b34c000000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 4, "\ud8c5\uddf2", "\uc8d4\u5617\u88c5\ua950\uaf85\u88f2\u9b53\u0c68\u76f2\u9c67\u131d\u98e3\u2453\u0d00\u1118\u4618\u11c5", "\udaec\udc6d\udac2\udc6a\ud88b\ude41\ud897\uddaa",
        9, 78869, -40744759, 659516699090438416L, -69017L, false, false, (char) 63804, (char) 57198,
        Double.longBitsToDouble(0x3fe5aa968e43eddaL), Double.longBitsToDouble(0x3fd0fb9077f34e2eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 6, "\ub7e7", "\uc8d4", "\udaa8\udfbc",
        9, 66546, 128213573, -4170077072773788469L, 50239L, true, false, (char) 35504, (char) 22905,
        Double.longBitsToDouble(0x3fa0542e00000a20L), Double.longBitsToDouble(0x3fe0000000000065L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 13, 8, "\ud8c5\uddd5\ud85e\ude6e\uda0b\udf20\ud92b\udf8a\udb1a\udf30\uda6e\udd4b\udaa8\udfbc\udad5\ude0b\uda27\udeb4\ud843\ude7a\udb75\uddc2\ud823\uddb2", "\u98e3\u2453\u95fa\uac8c\u51f8\u8df6\u5dc4\ucd62\u8239\u73f2\uac51\uc518\u80e9\ub20b\u8bd5\u05cb\u1e8d\u4b69\ucd07\u2513\u816b\uc94c\u5aed\u4225\uabae\u75fb\uc8fd\u678e\u6c72", "\uda53\uddb5\uda6d\udf32\ud910\ude66\ud950\udf5a\u26b9\udb30\udf73\ud908\udf4c\udb1f\udfc8\udab8\ude8e\uda21\udc41\u0420",
        22, 81432, 1669714925, -1019084758331581867L, -3230L, false, true, (char) 64934, (char) 45392,
        Double.longBitsToDouble(0x3fe8f163176b4c49L), Double.longBitsToDouble(0x3fe665a81f880e57L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_parseNumber2|boolean,int|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_parseFloat|[C,int,int,boolean,int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer,[B,int,int,boolean",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_closeInput||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_decodeBase64|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_decodeEscaped||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_finishString||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_finishString2||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_getText2|com.fasterxml.jackson.core.JsonToken|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_handleApos||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_handleInvalidNumberStart|int,boolean|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_handleOddName|int|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_handleOddName2|int,int,[I|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_handleOddValue|int|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_isNextTokenNameMaybe|int,java.lang.String|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_isNextTokenNameYes|int|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_matchFalse||new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.ReaderBasedJsonParser|_parseNumber2|boolean,int|new:com.fasterxml.jackson.core.json.ReaderBasedJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.Reader,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer",
    "M|com.fasterxml.jackson.core.json.UTF8StreamJsonParser|_parseFloat|[C,int,int,boolean,int|new:com.fasterxml.jackson.core.json.UTF8StreamJsonParser:com.fasterxml.jackson.core.io.IOContext,int,java.io.InputStream,com.fasterxml.jackson.core.ObjectCodec,com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer,[B,int,int,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
