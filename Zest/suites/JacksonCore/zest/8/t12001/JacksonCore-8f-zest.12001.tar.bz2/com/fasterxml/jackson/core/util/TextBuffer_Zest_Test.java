package com.fasterxml.jackson.core.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class TextBuffer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\ua715\uca22\u3d5c\uc585\u776f\ucaa6\u753e\ud637\u86c6\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\ud9f6\udfc4\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f",
        42, 52677, 1208524339, -8598200716846814868L, -76505L, true, true, (char) 57361, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\ua715\uca22\u3d5c\u2d86\u02ab\ucaa6\000\ud637\u86c6\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud890\udfd5\ud966\udd65\ud852\ude17\ud9f6\udfc4\ud992\udd3f\ud8b2\udeb5\ud978\udd7b",
        42, 52677, 1208524339, -8598200716846814868L, -76505L, true, true, (char) 57361, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 8, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\ua715\uca22\u3d5c\uc585\u776f\u69c6\u4bc8\ud696\u86c6\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\ud9f6\udfc4\ud992\uddba\ud8b2\udeb5\ud9af\ude0f",
        42, 52677, 1208524339, -8598200716846814868L, -76505L, true, true, (char) 57361, (char) 18317,
        Double.longBitsToDouble(0x3fe1ea4e4f4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 13, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb4c\udcdd", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\ua715\uca22\u3d5c\ub7fd\u74bd\ucaa6\u753e\ud637\u86c6\u0682\u45e1", "\uda91\ude6c",
        2, 36818, 376343315, -5195950732316833334L, -51052L, false, false, (char) 36971, (char) 9880,
        Double.longBitsToDouble(0x3fe19d0536014808L), Double.longBitsToDouble(0x3fd6c88add81a9acL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 0, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\ua715\uca22\u3d5c\uc585\u776f\ucaa6\u753e\u612e\u86c6\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\ud9f6\udfc4\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f",
        -1, 4240, 1208524339, -8598200716846814868L, -76505L, true, true, (char) 57361, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\ud8b7\udfea", "\u2222\u2878\u937e\u725b\u3568\u7ba6\ud15f\uab32\u7000\u4d30\ua715\uca22\u3d5c\uc585\u776f", "\uda2e\udd1c\u822d\udb79\udcf9\udbae\udeb7\udbbc\ude2d\ud820\ude84",
        44, 61992, -1766856182, 1616382228783449687L, 77599L, false, true, (char) 49930, (char) 36992,
        Double.longBitsToDouble(0x3fd356963c67414cL), Double.longBitsToDouble(0x3fe00a40416c88adL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 11, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\u6757\u56a7\u68e8\uc585\u776f\ucaa6\u753e\ud637\u86c6\ube4d\u45e1", "\ud878\udf1a\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\ud9f6\udfc4\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f",
        42, 52677, 1208524339, -8598200716846814868L, -76505L, true, true, (char) 57361, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u08af\012",
        Z.run(T, 1, 1, 13, 15, "\ud9a9\ude50\ud8f9\udfa7", "\u7dd8\u576b\u5e37\u15ff\u1c02\u1a90\u3905\u725b\u3568\u7ba6\u7203\ua933\u7000\u4d30\ua715", "\udaf0\udee8",
        35, 69833, -775407091, 838575998279701416L, -54744L, false, false, (char) 2223, (char) 23749,
        Double.longBitsToDouble(0x3fdcab7e448333a6L), Double.longBitsToDouble(0x3fe9a3b56c94b3b8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 10, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2226\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u6926\u146f\ua715\uca22\u57c5\uaf8c\u776f\ucaa6\u753e\ud637\u86c6\u0682\u45e1", "\uda91\udd9a\uda67\udd84\uda79\ude29\udadc\udef5\ud94f\udee9\uda03\udf61\uda8c\udd3c\ud8b2\udeb5\udbf3\ude11",
        42, 52677, 1208524339, -8598200716846814868L, -76505L, false, true, (char) 49937, (char) 65322,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 5, 15, 12, "\ud9a9\ude50\ud8f9\udfa7\ud8b1\udfdd\uda89\udedc\ud89e\ude1c", "\u15ff\u2222\u9cbe\u3905\u725b\uad20\u7a0f\ua83c\uab32\u7000\u4d30\ua715\uca22", "\ud9b4\udc2e",
        13, 39214, 195246189, 7971744795988240018L, 39630L, true, true, (char) 23002, (char) 47845,
        Double.longBitsToDouble(0x3fe05283031396afL), Double.longBitsToDouble(0x3fe2b8b375e34be4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 0, 15, "\ud9a9\ude50\udae9\udd86\udadc\ude19\uda93\udf54\ud957\udc19\ud9cc\udd04", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u7aae\ua715\uca22\u3d5c\uc585\u776f\ucaa6\u753e\u5e14\u86c6\u481f\u45e1", "\uda91\udd9a\uda67\udd84\ud88a\udf51\ud8d6\udfa2\ud852\uddfb\ud9e7\udd7c\u5560\ud89b\udfbb\ud9af\ude0f",
        42, 52677, 1208524339, -8598125950056126100L, -76505L, true, true, (char) 57361, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fa7891566a72b80L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 7, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\u9cbe\u9c35\u725b\uc372\u7bd2\ua83c\uab32\u7000\u42c0\ua704\uca22\u3d5c\uc585\u776f\ucaa6\u753e\ud637\u86c6\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\ud9f6\udfc4\ud8c5\ude3a\udb55\udc22\ud97a\uddc4",
        42, 52677, 1636212275, -8598200716846814868L, -76505L, true, true, (char) 47633, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fd61d9cdcd559a4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 10, 9, 15, "\ud9a9\ude50\ud8f9\udfa7\uc1dc\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u99c3\ud207\ua9e9\u2417\u3568\u7ba6\ua829\u36ba\u7000\u12d1\u36d1\uca22\u6658\uc585\ucdf3\u3da4\uc006\ud5e2\u86c6\u0682\u45e1", "\udb8a\udc97\ud8d3\udf38\ud890\udfd5\ud989\udc65\udb3c\ude0b\udb01\udfea\udb23\udc07\ud8b2\udeb5\ud9af\ude0f",
        51, 50103, -2066205911, -8598200437673940628L, -76505L, true, true, (char) 57361, (char) 18082,
        Double.longBitsToDouble(0x3fe1ea4cdf6088cdL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 9, 15, 15, "\ud9a9\ude50\uda92\uddf3\udaf0\udf6c\ud99f\udd72\ud89a\ude82\udb67\udc42", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\ua715\uca22\u96d6\ub117\u776f\ucaa6\u753e\ua9b8\u43a9\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\ud9f6\udfc4\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f",
        42, 52677, 1208524339, -8598200716846814868L, -33891L, false, true, (char) 37653, (char) 6973,
        Double.longBitsToDouble(0x3fac26cf7f54be30L), Double.longBitsToDouble(0x3fe751ecf29229acL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 10, 10, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\ua715\uca22\uca5d\u0a0c\u776f\ucaa6\u0d13\ud637\u86c6\u0682\u45e1\u0a73\u71b9\u3900\u880b\u9d38", "\ud9f6\udfc4\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f\ud84b\udd7a\ud9f1\udf96\udae6\ude71\ud92e\udfe2\udb33\udee0",
        38, 73100, 308491611, 4475367047632193529L, 51709L, true, true, (char) 38692, (char) 30018,
        Double.longBitsToDouble(0x3fdb3ffd79b3926eL), Double.longBitsToDouble(0x3feb1a207b9968b2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 15, 15, "\ud973\udce5\udb67\udfdf\ud981\udd83\ud8a5\udf4a\ud89e\ude1c\ud9d1\udea1", "\u12b5\u9c0c\u686d\u31a5\u3535\u7ba6\ua83c\u2b7d\ua4f8\u4d30\ua715\uca22\u3d5c\uc585\u776f\ucaa6\u753e\ud637\u86c6\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\udb62\udfba\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f",
        48, 46622, 40668428, 9035143400272069266L, -76505L, true, true, (char) 57361, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 12, 15, 15, "\ud9a1\ude41\ud8f9\udfa7\udaa5\udfb4\uda60\udfa4\ud89e\uddcd\udbff\uddd5", "\u5a78\u9cbe\u90d4\u725b\u3568\u7b86\ua83c\uab32\u373f\u4d30\ua715\uca22\u3d5c\u19f8\u43ce\u9df7\u4bf6\u252e\u86c6\u0682\u45e1\u0a73", "\uda2c\udde8\udb50\udf15\ud989\udc65",
        15, 84458, 1991068251, 3150478168014121970L, 79509L, true, false, (char) 63395, (char) 45593,
        Double.longBitsToDouble(0x3fe606a6b3c777b8L), Double.longBitsToDouble(0x3fd779bd8677e8e8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 12, 15, 15, "\ud9a9\ude50\ud9c3\udd73\ud981\udd7d\ud928\udd7e\ud89e\ude1c\udb84\udc9f", "\u4b9c\u7ee6\ucec2\u88df\u355c\u7ba6\u6461\uaad9\u7000\u4d30\ua715\uca22\u3d5c\uc585\u776f\u69c6\u44ac\u4d37\ua794\u0682\u45e1", "\ud8ef\udca9\uda67\udd84\ud890\udfd5\ud989\udc65\uda2c\udcfb\ud852\ude29\ud992\uddba\ud8b2\udeb5\ud9af\ude0f",
        17, 27829, 1208524339, -8598200716846814868L, 65404L, false, true, (char) 57361, (char) 18317,
        Double.longBitsToDouble(0x3fe1ea4e4f4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 1, 4, 13, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\ud8fa\udf39", "\u2222\u9cbe\u106e\ubfca\u3568\u7ba6\ua83c\u4ddd\ubfa6\u4d30\ua715\uca22\uab91\uc3fa\u74bd\ucaa6\u753e\u78e2\uc12a\u6057\u45e1\u0165\u6d37\u39d2\u92d6\ud1fe", "\ud9f6\udfc4\ud992\udd3f\ud8ba\udefc\udb71\udfa3\ud84f\udf94\udb62\ude39\ud9fa\ude8b\udb31\udef8\udb33\udee0",
        40, 50768, -1804752733, -602092985720067157L, -56049L, true, false, (char) 3195, (char) 53823,
        Double.longBitsToDouble(0x3fe71218f7187116L), Double.longBitsToDouble(0x3feba891f5b246dcL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 8, 6, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42\ud882\udf52\ud9e6\udf10\uda83\udd79\udae4\udc02\udada\udc87\udb18\udf78\u1e75\ud80b\ude92\ud9e3\udd3b\udbea\udca6\uda6b\ude3b\ud9a5\udeb5\udb9f\uddb6\uda5e\udc7c", "\u776f", "\uda62\udc76\u822d\udb79\udcf9\udbae\udeb7\udbbc\ude2d\uda3a\udd52",
        52, 30472, -1766856182, 1616382228783449687L, 77599L, false, true, (char) 36940, (char) 6507,
        Double.longBitsToDouble(0x3e48ce8298000000L), Double.longBitsToDouble(0x3fe00a40416c88adL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 11, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\ucb9c\u5953\uafd4\u3568\u7ba6\u724e\u7e1f\u6a7b\u3955\ua715\u28a7\u8711\u474e\u776f\ucaa6\u753e\u612e\u86c6\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\ud9f6\udfc4\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f",
        -1, 4240, 1208524339, -8598200716846814868L, -76505L, true, true, (char) 57361, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdbc256adL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\ue011\0121=[C:[[\ue011, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\ue011\012",
        Z.run(T, 2, 1, 15, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude38\udb67\udc42", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\ud2de\u6757\u56a7\u68e8\uc585\u776f\ucaa6\u753e\ud637\u86c6\ube4d\u45e1", "\ud878\udf1a\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\ud9f6\udfc4\ud992\udd3f\ud85e\udd4b\ud9af\ude0f",
        42, 52677, 1208524339, -8598200716846814868L, -76505L, true, true, (char) 57361, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 11, 15, 15, "\ud9a9\ude50\u8b9e\ud981\udd70\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\u9cbe\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\u67dd\u56a7\uad59\uc585\u776f\ucaa6", "\ud9d3\udf07\udb7c\udc19\udbae\udeb7\udbbc\ude2d\ud954\udc7f\ud8f1\udfcf\uda67\udd84\ud890\udfd5\ud989\udc65\ud852\ude17\uda0f\udec4\ud992\udd3f\ud8b2\udeb5\u8d17\udb60\udc7c\ud9f1\udf96\udae6\ude71\ud9a7\udcd4\uda47\udc70\ud86b\uddce\u1de0\udb06\udc24\udbff\ude46\ud96c\ude0e\ud93d\udf0f\udb5d\udc9f\udb56\uddeb\udb94\udde6\ud9be\udfb1\u7618\udae2\udc29\uda73\udce8\uda21\uddb3",
        32, 98541, -789900230, -6033869708814595555L, -56926L, false, false, (char) 41194, (char) 13820,
        Double.longBitsToDouble(0x3fe047b714cf4ec2L), Double.longBitsToDouble(0x3fe027e9838c1409L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u59da\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 1, 8, 4, "\ud9a9\udea6\ud8f9\udfa7\uda0f\ude69\ud874\udce2\ud89e\ude1c\ud8a7\udeeb", "\u2253\u9cbe\u3905", "\udb21\udd9d\ud9e3\udc7f\uda86\uddb3\ud82b\udc84\ud818\udc41\udb9f\uddb6\uda5e\udc7c\ud810\udc9c",
        12, 36807, -842090972, -9370698214328211L, 59269L, true, true, (char) 23002, (char) 16294,
        Double.longBitsToDouble(0x3fdea2760d35e400L), Double.longBitsToDouble(0x3fec124fa567b202L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 2, 15, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud8af\udda5\udb23\udcfb", "\u2226", "\ud949\udcce\uda56\udc33",
        18, 96598, -796259469, -7658468892417914216L, -88136L, false, false, (char) 32682, (char) 51941,
        Double.longBitsToDouble(0x3fe121fa1d66cdceL), Double.longBitsToDouble(0x3fbb7ff79d405d18L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 12, 7, 13, "\ud98f\udf42\udaf6\udf1a\ud8b1\udfdd\ud928\ude0b\ud87c\udf58\ud861\udd50", "\u6763\u40b4\u1ed6\u71eb\uad20\u5fb0\ua83c\u9f6e\u7000\u2830\ua715\u09bb\u8c18\uc585\u409e\ucaa6\u753e\u4f8f\u86c6\u0682", "\uda1e\ude97\uda91\udd9a\uda67\udd84",
        40, 95784, -1797063593, 4583015313516541168L, -62567L, false, false, (char) 1591, (char) 48363,
        Double.longBitsToDouble(0x3fed97e9169b783eL), Double.longBitsToDouble(0x3fe53bd4722ab26dL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000]] |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 9, 4, "\ud831\udc54\udb6e\udd50\ud899\udc74\uda89\udedc\ud89e\ude1c", "\u15ff\u2222\u9cbe\u3905\u725b\uad20\u7a0f\ua83c\uab32\u7000\u4d30\ua715\uca22", "\ud9b4\udc2e",
        13, 39214, -2069677971, 7935200143332255378L, 39630L, true, true, (char) 40313, (char) 53144,
        Double.longBitsToDouble(0x3fe05283031396afL), Double.longBitsToDouble(0x3fe2b8b375e34be4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 10, 11, 15, "\ud9a9\ude50\ud8f9\udfa7\u5cdf\udad7\uddc2\ud89e\ude1c\ud883\udcef\ud882\udf50\ud9f2\udc56\udb0e\udd87\ud8ff\ude90\udba2\udf9d\ud894\ude85\ud86f\udede\udb21\udd9d\ud945\udd91\u0b82\ud9e9\udc63", "\uca22\u66ea\u98c8\u4e1b\u3da4\uc006\u5009\u86c6\u5e36\u45e1\u0a73\u999a\u57ad\u0a25\u9d38", "\udb0b\ude8f\ud941\udf2b\udac8\udfc0\ud8ea\udd19\uda0b\udd3d\udb7c\uddc7\u1be7\udb31\udf39\udb33\udee0",
        11, 9749, 1055213342, -1203132737668839431L, 1395L, true, false, (char) 31292, (char) 24216,
        Double.longBitsToDouble(0x3fc46d3367ddcfe8L), Double.longBitsToDouble(0x3fb275196a4854f8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 10, 5, 15, "\ud9a9\ude50\uda92\uddf3\udaf0\udf6c\ud99f\udd72\ud89a\ude82\udb67\udc42", "\u2222\u9cbe", "\u1e75\udb21\udd9d\ud9e3\udc7f\udbea\udca6\uda6b\ude3b\ud9a5\udeb5\udb9f\uddb6\uda5e\udc7c\ud81c\udc1f\uda97\udd10\ud9b4\udc2e\udb02\udf2e\ua564\ud817\udd7c\udb78\udfbe\udb79\udcf9\udbae\udeb7\udbbc\ude2d\uda3a\udd52\uda91\udd9a\uda67\udd84",
        8, 16315, -1209776553, 6075179741409766939L, 58372L, true, true, (char) 9880, (char) 16089,
        Double.longBitsToDouble(0x3fe00a40416c88adL), Double.longBitsToDouble(0x3fe606a6b7c777b8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 4, 4, 10, "\ud9a9\ude50\ud8f9\udfa7\ud981\udd83\uda89\udedc\ud89e\ude1c\udb67\udc42", "\u2222\u897b\u3905\u725b\u3568\u7ba6\ua83c\uab32\u7000\u4d30\ua715\uca22\uca5d\u0a0c\u776f\ucaa6\u0d13\ud637\u86c6\u0682\u45e1\u0a73\u71b9\u3900\u87b2\u9d38", "\ud9f6\udfc4\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f\ud84b\udd7a\ud9f1\udf96\udae6\ude71\ud92e\udfe2\udb33\udee0",
        38, 73100, 308491611, 4475367047632193529L, 51709L, true, true, (char) 38692, (char) 30018,
        Double.longBitsToDouble(0x3fdb3ffd736de26eL), Double.longBitsToDouble(0x3fee4294739968b2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 3, 15, "\ud973\udce5\udb67\udfdf\ud981\udd83\ud8a5\udf4a\ud89e\ude1c\ud9d1\udea1", "\u12b5\u9c0c\u1f47\u7a33\u5a8b\uabfa\ua83c\u2b7d\ua4f8\u4d30\ua715\uca22\u4b24\uc585\u776f\u23c7\uc2cd\ud68a\u86c6\u0682\u45e1", "\uda91\udd9a\ud8f9\udf3a",
        57, 16315, -1209776553, -806081839534093726L, -4645L, true, true, (char) 20593, (char) 54607,
        Double.longBitsToDouble(0x3fe86da02a927d63L), Double.longBitsToDouble(0x3fe49b1f73c777b8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 2, 15, "\ud973\udce5\udb67\udfdf\ud981\udd83\ud8ec\udc36\ud80e\udf9c\ud9d9\udf8c", "\u12b5\u9c0c\u686d\u31a5\u3535\u735b\ua117\u7474\ua4f8\u4d30\ua715\uca22\u3d5c\uc585\u20eb\u6f2b\u753e\ud151\u3588\u299d\uc2df", "\uda91\uddad\uda67\udd84\uda54\udfd7\ud989\udc65\ud874\udc51\udb62\udfba\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f",
        48, 46622, -1199025652, 9035143400272069266L, -76505L, true, true, (char) 53405, (char) 2657,
        Double.longBitsToDouble(0x3fea56996c9d50d5L), Double.longBitsToDouble(0x3fdeb53fbcd559a4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 10, 10, 1, "\ud973\udce5\udb67\udfdf\ud981\udd83\ud8a5\udf4a\ud89e\ude1c\ud9d1\udea1", "\u12b5\u9c0c\u041b\u3e62\u3535\u7ba6", "\uda78\udf33\ud9a5\udeb5\udb9f\uddb6\uda5e\udc7c\ud984\udd32\uda9c\udd7e",
        10, 46028, -2181786, 838575998279701416L, 96901L, false, true, (char) 35287, (char) 24793,
        Double.longBitsToDouble(0x3fe86a6b5b260362L), Double.longBitsToDouble(0x3fe89cb57fec166eL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=null |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 0, 0, 0, "\u0900\000\ud945\udce2\ud8a5\udf4a\177\udac5\uddc2", "\u12b5\u9c0c\u686d\u31a5\u3535\u7ba6\000\u2b7d\ua4f8\u4d30\ua715\uca22\u0f4f\uc4e3\u776f\ucaa6\ub566\ud5ca\u86c6\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud856\uddcb\ud989\udc65\ud852\ude17\udb62\udfba\ud992\udd3f\ud95c\udeaa\ud9af\ude0f",
        43, 46622, 40668428, 9035143400272069266L, -76704L, true, true, (char) 45683, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=void |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 11, 12, 8, "\ud973\udce5\udb67\udfdf\ud981\udd83\ud8a5\udf4a\ud9dd\udee1\ud9f2\ude50", "\u06f3\u64f2\u686d\u31a5\u8077\u691a\ub477\u5462", "\udbfe\uddb8\uda5e\udc7c\ud984\udd32\udab6\udf0a\udbc9\udee6",
        36, 39365, 195246189, 7971744795988240018L, 39632L, true, false, (char) 23002, (char) 47845,
        Double.longBitsToDouble(0x3fe05283031396afL), Double.longBitsToDouble(0x3fe2b8b371cab7e4L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 10, 8, 10, "\ud973\udce5\udb67\udfdf\ud981\udd83\ud8a5\udf4a\ud89e\ude1c\ud9d1\udea1", "\u12b5\u9c0c\u686d\u31a5\u3535\u7ba6\ua83c\u2b7d\ua4f8\u4d30\ua715\u9ad1\u3d5c\uc585\u6310\ucaa6\u3d92\u17c8\u7fd3\u0682\u45e1", "\uda91\udd9a\uda67\udd84\ud890\udfd5\ud990\udec5\ud852\ude17\udb62\udfba\ud992\udd3f\ud8b2\udeb5\ud9af\ude0f",
        48, 46622, 40668428, 9035143400272069266L, -76505L, true, true, (char) 57361, (char) 17940,
        Double.longBitsToDouble(0x3fe1ea4cdf4e7eadL), Double.longBitsToDouble(0x3fdebd52adf2c5a8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 3, 5, "\ud9a1\ude41\ud8f9\udfa7\udaa5\udfb4\uda60\udfa4\ud89e\uddcd\udbff\uddd5\udacc\udd3f\udb78\udd32", "\u2c9d\u0b2e\u113f\u0502\u1d56\u8bc6\u45a3\ubff8\u3d98\u88de\u5801\ud4a2\u43ce\u9df7\u4bf6\u9451\u3f44\u8c68\u45aa\u0a73\u71b9\u0fc6\u990a\uc26c\u8d6f\ub635\u8794\u1703\u9b05\u89b2\u342d\ud432\u9afa", "\ud9bb\udfb8\u1de0",
        -2, 52691, 1787118293, -6196355004722722418L, -26366L, false, false, (char) 16682, (char) 20811,
        Double.longBitsToDouble(0x3f70ff3b2f617300L), Double.longBitsToDouble(0x3fdddf35a88e0744L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 12, 0, 15, "\uda78\uddae\ud9c3\udd73\ud981\udd7d\ud928\udd7e\ud89e\ude1c\udb84\udc9f", "\u4b9c\u7ee6\u6cfc\u5734\u355c\u7b38\u6461\u1005\u56c4\ua044\ua715\uca22\u3d5c\uac56\u8891\u69c6\u44ac\u4d37\ua794\u0682\u45e1", "\ud8ef\udca9\uda67\udd84\ud9e5\udfdf\ud989\udca3\udbfa\udd02\ud9d0\udee9\ud992\uddba\ud8b2\udeb5\ud9af\ude0f",
        49, 27829, -1442275789, -8598200399019234964L, 65404L, false, true, (char) 57361, (char) 21757,
        Double.longBitsToDouble(0x3fe1e88baf4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u1b3d\012",
        Z.run(T, 2, 12, 1, 15, "\ud965\ude4e\ud9c3\udd73\ud981\udd7d\udbd1\udd52\ud8d5\udcaa\udb84\udc9f", "\u73a5\u7ee6\ucec2\u88df\u7308\u427e\u6461\uaad9\u7000\u4d30\ua715\uca22\u3d5c\u3174\u70ec\u69c6\u44ac\u4d37\ua794\u0682\u45e1", "\udb43\udf13\uda56\udeca\ud890\udfd5\ud989\udc65\uda2c\udcfb\ud852\ude29\ud992\uddba\ud940\ude8c\ud9af\ude00\udbcb\udde3\uda20\udd2d\udae6\ude71\udb31\udef8\udb33\udee0",
        11, 7916, -1867502364, -6308057868427231606L, 92334L, true, true, (char) 6973, (char) 63475,
        Double.longBitsToDouble(0x3fc1c3d9c06155a0L), Double.longBitsToDouble(0x3fede5acba4bf221L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 12, 11, 15, "\ud9a9\ude50\ubeee\ud981\udd7d\uda78\udd87\uda05\uddef\uda5e\ude4a", "\u4bbd\u7ee6\ucec2\u88df\u2541", "\u4c24\uda6b\ude3b\udbb6\ude70\udb9f\uddb6\uda5e\udc7c\ud986\udc3c\uda9c\udd4b\ud9b4\udc2e\uda3e\udd1d",
        3, 61812, -1797155190, -1949312541520507941L, -73978L, false, true, (char) 43651, (char) 14954,
        Double.longBitsToDouble(0x3fe89cb57b80166eL), Double.longBitsToDouble(0x3fd33d54837820a0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 12, 14, 15, "\ud9a9\ude50\ud9c3\udd73\u9b86\ud928\udd7e\ud89e\ude1c\udb84\udc9f", "\u4b9c\u7ee6\ucec2\u88df\u355c\u7ba6\u6461\uaad9\u7000\u4d30\ua715\uca22\u3d5c\u255e\u776f\u69c6\u44ac\u4d37\ua794\u0682\u45e1", "\ud8ef\udca9\ud8ad\udc60\ud890\udfd5\ud989\udc65\uda2c\udcfb\ud9ce\udc86\ud996\udd3e\ud8b2\udeb5\ud9af\ude0f",
        17, 27829, 2098190643, 9127967920443938474L, 65617L, false, true, (char) 57361, (char) 18317,
        Double.longBitsToDouble(0x3fe1ea4e4f4e7eadL), Double.longBitsToDouble(0x3fdebd52acd559a4L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[]] |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 7, 7, 6, "\ud997\udc75\ud9c3\udd73\ud984\udf9e\ud928\udd62\ud89e\ude1c\udb84\udc9f\ud882\udf52\ud9e6\udf10\ucd80\ud80c\uddfe\ud927\udd2b\uda98\udea5\u1e69\udb1b\udd9d\udbbb\udf2d\udbea\udc4d\uda6b\ude3b\ud8bf\udd03\udb85\ude70\uda2a\udf78\ud984\udd32\uda9c\udd7e\ud9f7\udd04\udad0\udd74\ud810\ude56\ud941\ude48\udbc4\udc39\udb79\udcf9\udbae\udeb7\udb4b\udcd4", "\uc4cc\u19fe\u19c9\u7c84\ubd8d\ucfb8\u77de\u5064\u3496\u2c2d\ucb92\u7894\u8e43\u461d\u2afe\u76bf\u198f\ucde4\u1060\u1c8a\u1356\u1043\u0299\u2ee8\u919a\u1927\u014b\u8bd1\u69d6\u2696\ud665", "\ud978\udcfc\ud84c\udf86\uda03\udebd\u5101\udbc6\udf5f\ud899\udd54",
        47, 87585, 1846500942, -5649234554729878766L, -67072L, false, false, (char) 46743, (char) 52084,
        Double.longBitsToDouble(0x3fb9fea633a2a5b0L), Double.longBitsToDouble(0x3fe557bd643aa700L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u4d4a\0121=void |this=com.fasterxml.jackson.core.util.TextBuffer:\u4d4a\u4d4a\012",
        Z.run(T, 2, 1, 1, 4, "\ud9a9\udea6\ud8f9\udfa7\uda0f\ude69\ud874\udce2\ud89e\ude1c\uda13\ude01", "\u2253\u9cbe\uc1f2", "\udb21\udd9d\ud9e3\udc7f\uda86\uddb3\ud82b\udc84\ud818\udc41\udb9f\uddb6\uda5e\udc7c\ud810\udc9c",
        12, 36807, -842090972, -9370698214328211L, -930L, false, true, (char) 19786, (char) 32922,
        Double.longBitsToDouble(0x3fec124fa567b202L), Double.longBitsToDouble(0x3fecad9c92c53622L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\012",
        Z.run(T, 2, 11, 11, 4, "\ud9a9\udea6\ud8f9\udfa7\uda0f\ude69\uda57\uddf3\udb09\udfee\ud8a7\udeeb", "\u2b6b\u9cbe\u3905", "\udb21\udd9d\ud9e3\udc7f\ud98e\uddb7\ud82b\udc84\ud818\udc41\udb9f\uddb6\uda1c\udf00\u7e57\ufa51\uda28\udd53\udb02\udf2e\ua564\ud8fb\udf12",
        47, 52203, 1953811419, -5570268683344401802L, -34584L, false, true, (char) 32922, (char) 61813,
        Double.longBitsToDouble(0x3fd5ed8c99b6597eL), Double.longBitsToDouble(0x3fed53459d4e84f3L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 15, 0, "\udb0a\udf21\u390e\ud981\udd47\uda74\udefb\ud84b\udc41\udb7f\udecf\udad5\udebb\ud817\udce2\uda7b\udf93\udae4\udc02", "\u4866\u8842\ua83c\uab32\u4ae6\u4d49\ua715\uca22\u755b\uc531\u19c6\u93b9\u0ce5\ud637\u86c6\u0682\u45e1\u0a73\u71b9\ua44d\u09ce", "\ud852\ude17\ud9f6\udfc4\udaf7\udc36\udadb\udf53\ud9af\ude0f\udbcb\udd7a\ud9f1\udf96\udae6\ude71\udb31\udef8\udb33\udee0",
        16, 6506, 762635559, 4475367047632193529L, 92334L, true, true, (char) 6973, (char) 62024,
        Double.longBitsToDouble(0x3fcdaf5104e557e8L), Double.longBitsToDouble(0x3fd2b128542f4930L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=void |a0=[C:[[\ud9a9, \ude50, \ubeee, \ud8dc, \udcca, \ud851, \uddf3, \u4f25, \uda5e, \ude4a, \udb53, \uddf7, \udb66, \udfa8, \uda0c, \udc9b, \ud80c, \uddfe, \ud927, \udd2b, \uda98, \udea5, \ub303, \ud922, \udd3d, \ud817, \udc26, \ud80f, \udf98, \uda41, \uddaa, \ud87e, \ude10, \uda32, \udfa0, \ud9c5, \udfbb, \uda02, \udf2b, \udb1e, \udc7b, \ud9b4, \udc2e, \uda3e, \udd1d, \ud802, \udec9, \ud9ac, \udddb, \ud9aa, \udd78, \udb79, \udcf9, \udbc2, \udc01, \ud89b, \udc3d, \ud9a2, \udc6a]] |this=com.fasterxml.jackson.core.util.TextBuffer:\udc2e\uda3e\012",
        Z.run(T, 2, 10, 2, 8, "\ud9a9\ude50\ubeee\ud8dc\udcca\ud851\uddf3\u4f25\uda5e\ude4a\udb53\uddf7\udb66\udfa8\uda0c\udc9b\ud80c\uddfe\ud927\udd2b\uda98\udea5\ub303\ud922\udd3d\ud817\udc26\ud80f\udf98\uda41\uddaa\ud87e\ude10\uda32\udfa0\ud9c5\udfbb\uda02\udf2b\udb1e\udc7b\ud9b4\udc2e\uda3e\udd1d\ud802\udec9\ud9ac\udddb\ud9aa\udd78\udb79\udcf9\udbc2\udc01\ud89b\udc3d\ud9a2\udc6a", "\u9e09\u15a9\u78df\u1489\u8dcd\u5b04\u0cb4\u388c\uce8f\ubc23\ud346\u9d9e\u87da\uac69\u9e74\u7d37", "\udbbd\udcd7\udb6e\udf78\ud9fc\udfc5\udb26\uddc4\udb50\ude3f\udb78\udf7f",
        42, 2, 340240641, -3690248147293907299L, 44707L, true, true, (char) 58639, (char) 39538,
        Double.longBitsToDouble(0x3fedcfc2217d3b5eL), Double.longBitsToDouble(0x3fe64581c8cdbb04L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=[C:[[\000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000, \000... |this=com.fasterxml.jackson.core.util.TextBuffer:\0121=void |a0=[C:[[\ud9a9, \ude50, \ubeee, \ud8dc, \udcca, \ud851, \uddf3, \u4f25, \uda5e, \ude4a, \udb3f, \ude77, \udb66, \udfa8, \uda0c, \udc9b, \ud80c, \uddfe, \ud927, \udd2b, \uda98, \udea5, \ub303, \ud922, \udd3d, \ud817, \udc26, \ud80f, \udf98, \uda41, \uddaa, \ud87e, \ude10, \uda32, \udfa0, \ud9c5, \udfbb, \uda02, \udf2b, \udb1e, \udc7b, \ud9b4, \udc2e, \uda3e, \udd1d, \ud802, \udec9, \ud9ac, \udddb, \ud9aa, \udd78, \udb79, \udcf9, \udbc2, \udc01, \ud89b, \udc3d, \ud9a2, \udc6a]] |this=com.fasterxml.jackson.core.util.TextBuffer:\udc2e\uda3e\012",
        Z.run(T, 2, 4, 2, 8, "\ud9a9\ude50\ubeee\ud8dc\udcca\ud851\uddf3\u4f25\uda5e\ude4a\udb3f\ude77\udb66\udfa8\uda0c\udc9b\ud80c\uddfe\ud927\udd2b\uda98\udea5\ub303\ud922\udd3d\ud817\udc26\ud80f\udf98\uda41\uddaa\ud87e\ude10\uda32\udfa0\ud9c5\udfbb\uda02\udf2b\udb1e\udc7b\ud9b4\udc2e\uda3e\udd1d\ud802\udec9\ud9ac\udddb\ud9aa\udd78\udb79\udcf9\udbc2\udc01\ud89b\udc3d\ud9a2\udc6a", "\u9e09\u15a9\u78df\u1489\u8dcd\u5b04\u0cb4\u08d9\uce8f\ubc23\ud346\u6ef5\u87da\uac69\u9e74\u7d37", "\udbbd\udcd7\udb6e\udf78\ud9fc\udfc5\udb26\uddc4\udb50\ude3f\udb78\udf7f",
        42, 2, 340240641, -3690248147293907299L, 44707L, true, true, (char) 58639, (char) 39538,
        Double.longBitsToDouble(0x3fedcfc2217d3b5eL), Double.longBitsToDouble(0x3fe64581c8cdd004L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |a0=[C:[[\ud9a9, \ude50, \ubeee, \ud8dc, \udcca, \ud851, \uddf3, \ubae2, \uda5e, \ude4a, \udb53, \uddf7, \udb66, \udfa8, \uda0c, \udc9b, \ud80c, \uddfe, \udab5, \udd32, \uda98, \udea5, \ub303, \ud922, \udd3d, \ud817, \udc26, \ud88b, \udf96, \uda41, \uddaa, \ud87e, \ude10, \uda32, \udfa0, \ud9c5, \udfbb, \uda02, \udf2b, \udb1e, \udc7b, \ud9b4, \udc2e, \uda3e, \udd1d, \ud802, \udec9, \ud9ac, \udddb, \ud9aa, \udd78, \udb79, \udcf9, \udbc2, \udc01, \ud89b, \udc3d, \ud9a2, \udc6a]] |this=com.fasterxml.jackson.core.util.TextBuffer:\udc2e\uda3e\0121=void |a0=[C:[[\ud9a9, \ude50, \ubeee, \ud8dc, \udcca, \ud851, \uddf3, \ubae2, \uda5e, \ude4a, \udb53, \uddf7, \udb66, \udfa8, \uda0c, \udc9b, \ud80c, \uddfe, \udab5, \udd32, \uda98, \udea5, \ub303, \ud922, \udd3d, \ud817, \udc26, \ud88b, \udf96, \uda41, \uddaa, \ud87e, \ude10, \uda32, \udfa0, \ud9c5, \udfbb, \uda02, \udf2b, \udb1e, \udc7b, \ud9b4, \udc2e, \uda3e, \udd1d, \ud802, \udec9, \ud9ac, \udddb, \ud9aa, \udd78, \udb79, \udcf9, \udbc2, \udc01, \ud89b, \udc3d, \ud9a2, \udc6a]] |this=com.fasterxml.jackson.core.util.TextBuffer:\udc2e\uda3e\udc2e\uda3e\012",
        Z.run(T, 2, 2, 2, 8, "\ud9a9\ude50\ubeee\ud8dc\udcca\ud851\uddf3\ubae2\uda5e\ude4a\udb53\uddf7\udb66\udfa8\uda0c\udc9b\ud80c\uddfe\udab5\udd32\uda98\udea5\ub303\ud922\udd3d\ud817\udc26\ud88b\udf96\uda41\uddaa\ud87e\ude10\uda32\udfa0\ud9c5\udfbb\uda02\udf2b\udb1e\udc7b\ud9b4\udc2e\uda3e\udd1d\ud802\udec9\ud9ac\udddb\ud9aa\udd78\udb79\udcf9\udbc2\udc01\ud89b\udc3d\ud9a2\udc6a", "\u9d43\u15a9\u78df\u1489\u8dcd\u4be7\u0cb4\u751e\u8637\ubc23\ud346\u9d9e\u87da\uac69\u9e74\u7d37", "\udbbd\udcd7\udb6e\udf78\ud9fc\udfc5\udb26\uddc4\udb50\ude3f\udb78\udf7f",
        42, 2, -756111103, -3690248473711421795L, 44707L, true, true, (char) 58639, (char) 39538,
        Double.longBitsToDouble(0x3fedcfc2217d3b5eL), Double.longBitsToDouble(0x3fe64581cbc7c917L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.core.util.TextBuffer|getTextBuffer||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|append|char|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|append|[C,int,int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|append|java.lang.String,int,int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|buf|int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|carr|int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|clearSegments||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsArray||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsDecimal||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsDouble||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|contentsAsString||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|emptyAndGetCurrentSegment||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|ensureNotShared||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|expand|int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|expandCurrentSegment||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|expandCurrentSegment|int|new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
    "M|com.fasterxml.jackson.core.util.TextBuffer|getTextBuffer||new:com.fasterxml.jackson.core.util.TextBuffer:com.fasterxml.jackson.core.util.BufferRecycler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
