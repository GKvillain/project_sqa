package com.fasterxml.jackson.dataformat.xml.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class FromXmlParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\udbd2\udc48\uda9b\uded9\ud823\udce6\udb06\udfef\uda2f\ude8a\udbe7\udfd5\udb00\udd61\uda5a\udde0\ud947\udf53\udaca\ude7f", "\ubeae\u52cf\ua16a\u7933\u7b97\ud6c6\u1df3\u2cda\u9c19\u4a06\u2085\u24b0\ucc00\u1224\ub4f8\u56c3\u42e5\uac8e\ubb03\u45b1\u7285\u1e03\u3ee6\u0e5f\u4d92", "\udafa\udf6e\uda5a\udf22\ud928\udc60\ud8df\udd6f\udbb4\ude62\ud96b\udd3f\uda14\udec2",
        34, 61066, -769673518, -1304881674217328691L, -47215L, false, true, (char) 45514, (char) 20014,
        Double.longBitsToDouble(0x3fe5c0bcb2ee070eL), Double.longBitsToDouble(0x3fb5d11eef270490L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\udbd2\udc48\uda9b\uded9\ud823\udce6\udb06\udfef\uda2f\ude8a\udbe7\udfd5\udb00\udd61\uda5a\udde0\ud947\udf53\udaca\ude7f", "\ubeae\u52cf\ua16a\u7933\u7b97\u2028\u5baf\u2c83\u9c19\u4a06\u2085\u24b0\ucc00\u1224\ub4f8\ucbf5\u42d3\uac8e\ubb03\u45b1\u7285\u1e03\u3ee6\u0e5f\u4d92", "\udafa\udf6e\uda5a\udf22\ud928\udc60\ud8df\udd6f\udbb4\ude62\ud96b\udd3f\uda14\udec2",
        34, 61066, -769673518, -1304881674217328691L, -47215L, false, true, (char) 45514, (char) 20014,
        Double.longBitsToDouble(0x3fe5c0bcb2eec40eL), Double.longBitsToDouble(0x3fb5d11eef270490L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\udbd2\udc48\uda9b\uded9\ud823\udce6\udb06\udfef\uda2f\ude8a\udbe7\udfd5\udb00\udd61\uda5a\udde0\ud947\udf53\udaca\ude7f", "\ubeae\u52cf\ua16a\u7933\u6639\u2353\u1395\u2ca1\u9c19\u4a06\u2085\u24b0\ucc00\u1224\u9a99\u2f6d\uca34\uac8e\u5988\u1eae\u7285\u1e03\u3ee6\u0e5f\u4d92", "\udafa\udf6e\uda5a\udf22\ud928\udc60\ud8df\udd6f\udbb4\ude62\ud96b\udd3f\uda14\udec2",
        34, 61066, -769661998, -1304881674217328691L, -47215L, false, true, (char) 27837, (char) 25766,
        Double.longBitsToDouble(0x3fe5c0bcb2ee070eL), Double.longBitsToDouble(0x3fb5d11eef270490L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 6, "\udbd2\udc48\uda9b\uded9\ud823\udce6\udb06\udfef\uda2f\ude8a\udbe7\udfd5\udb00\udd61\uda5a\udde0\ud947\udf53\udaca\ude7f", "\ubeae\u52cf\ua16a\u2475\u7c27\ud6c6\u1df3\u2cda\u9c19\u4a06\u2085\u24b0\ucc00\u1224\ub4f8\u56c3\u42e5\uac8e\ubb03\u45b1\u7285\u1e03\u3ee6\u0e5f\u4d92", "\udafa\udf6e\uda5a\udf22\ud928\udc60\ud8df\udd6f\udbb4\ude62\ud96b\udd3f\uda14\udec2",
        34, 61066, -769673518, -1304881674217328691L, -47215L, false, true, (char) 63946, (char) 20014,
        Double.longBitsToDouble(0x3fe5c0bcb2ee070eL), Double.longBitsToDouble(0x3fb5d11eef270490L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 6, "\ud940\udf17\udbd3\udde5\uda87\udf3a\ud897\udeed\uda2f\ude15\udbe7\udfd5\udb00\udd61\udb7f\udf59\ud8ab\udf25\ud9ab\udf39\udbc9\uddb5\uda6d\uddd3\ud9a8\udecc\udb67\udf99\udb78\udce1\udacc\udf32", "\u1df3\u2cda\uae2c\u131d\u40d0\ud6e2\u21cc\u1224", "\ud8fa\udfe8\ud9c6\udccb\udb7b\udf7e\udbb2\udc16\udb80\udf29\ud84d\udf66\udb2d\udcce\ud83d\udc9c\ud9d8\udf8d\ud922\udc92\ud96a\ude3f\udbe1\ude20\ud900\udcd2\ud928\udc60\ud8df\udd6f\udb1a\ude3c\udaaa\udfac\uda14\udeec\ud825\udc47\ud967\ude16\ud8b5\udc50\udbaa\udf8d\ud86e\udcb0\ud8cc\udf0a",
        50, 67552, 502062983, 7604944101624291131L, -94990L, false, true, (char) 3366, (char) 24234,
        Double.longBitsToDouble(0x3fed1130517d6935L), Double.longBitsToDouble(0x3feb077e1623cb8dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\udbd2\udc48\uda9b\uded9\ud823\udce6\udb06\udfef\ud95a\udf20\uda58\udc59\udb85\udc04\uda5a\ude14\ud99f\udede\udaca\ude7f", "\ubeae\ucef4\u2ba9\ub579\u7b97\u77cb\u4fbb\u6209\u18a6\u5d89\u8c2d\u24b0\ucc00\u1224\ub4f8\u56c3\u42e5\ub52b\u562d\u45b1\u7285\u1e03\u3ee6\u0e5f\u4d92", "\udafa\udf6e\uda5a\udf22\ud928\udc60\uda99\udfcc\udbb4\ude62\ud96b\udd3f\uda14\udec2",
        34, 61066, -769673518, -1304881674217328691L, -47215L, false, true, (char) 45514, (char) 20014,
        Double.longBitsToDouble(0x3fe5c0bcb2ee070eL), Double.longBitsToDouble(0x3fb5d11eef270490L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|nextTextValue||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_decodeBase64|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_getByteArrayBuilder||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_handleEOF||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_isEmpty|java.lang.String|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_releaseBuffers||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_updateState|com.fasterxml.jackson.core.JsonToken|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|addVirtualWrapping|java.util.Set|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|close||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|configure|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser$Feature,boolean|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|disable|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser$Feature|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|enable|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser$Feature|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|getBigIntegerValue||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|getBinaryValue|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|getCodec||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|getCurrentLocation||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|nextTextValue||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
