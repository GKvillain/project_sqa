package com.fasterxml.jackson.dataformat.xml.ser;
import org.junit.Test;
import static org.junit.Assert.*;
public class XmlSerializerProvider_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\udb61\udcd5\ud886\udf04\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udb84\udcc6\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u54e0\u5ed5\ua5f5\u2182\u684d\u3a59\u5a0e\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        26, 76809, 1405175936, 1720839260574497390L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\udb61\udcd5\ud886\udf04\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udb84\udcc6\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u54e0\u5ed5\ua5f5\u2182\u684d\u3a59\u5a0e\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda20\udf8a",
        26, 76809, 1405175936, 1720839260574497390L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 13, "\udabc\udc33\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\udaf0\ude49\ud8f2\udffd\ud912\udd09\ud968\uddce\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\ud9b0\uddcc\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u0db3", "\u82ff\u167b\u131d\u49b8\ud454\u5976\ucfdc\u6c35\u7f72\u54e0\u5ed5\u9808\u2b5c\ub49a\u3a59\u5a0e\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        26, 77849, 1405175936, 1720839260574497390L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3fe3a4ee40fc83d2L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udb96\udd4e\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\ud88f\udfae\ud804\udfc5\ud92d\udfb4\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\udb61\udcd5\ud886\udf04\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\ud81b\udd9b\udb84\udcc6\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u2307\u70ff\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u54e0\u5ed5\ua5f5\u2182\uc769\u3a59", "\ud8b2\udc0c\udba0\udf74\ud9bb\udde2\ud8c9\udfeb\udb67\udc42\uda15\udd2a\ud9fa\udcd2\ud8ec\udf5b\ud908\udc56\u5f90",
        16, 97113, -1441351058, -4152790913099061862L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 12, 13, "\udabb\udff3\udba7\udec6\ud984\ude22\ud809\ude7b\ud957\udd6b\udafb\uddc0\uda48\udd39\uda44\udfc1\ud88a\udcb8\ud830\udc75\uc913\udad6\udca8\ud974\udc9d\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\udb61\udcd5\ud94b\ude66\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udb84\udcc6\u7c65\ud9f0\udfad\udb1e\udd55\udbae\udc91\udae1\udc93\udbd9\udc16\u54b3", "\u8368\u0854\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u54e0\u5ed5\ub808\u4950\u8eed\ub8f4\u2698\u9cbc\u7637\u6bd1", "\uda56\uddf6\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        26, 76809, 1405175936, 1720839262570986094L, 53191L, false, true, (char) 8294, (char) 62893,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\udb61\udcd5\ud886\udf04\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udb84\udcc6\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\uda44\udfcc", "\u82ff", "\udbe4\ude13\uda3e\udea1\ud829\udd65\udae9\udd79\ud837\udf03\ud930\udede\ua0ca\udb90\udd1c\udaca\udff1\udb90\udc5c\udb6b\ude5d\udba6\udd5a\udae9\udc36\uda39\ude67\udaaa\udde9\udba0\udf74\ud9bb\udde2\ud8c9\udfeb\udb67\udc42\uda15\udd2a",
        49, 34532, 1431558991, -5659779872583497600L, 78798L, true, true, (char) 37277, (char) 18567,
        Double.longBitsToDouble(0x3fe339d2395cba32L), Double.longBitsToDouble(0x3fd636fd0850634aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 11, 1, "\uda6e\udfcc\ud8a6\udf28\ud819\udd58\ud9f6\ude22\ud8aa\ude8a\ud839\uddf3\uda48\udd39\uda04\udf62\u7b6f\udaf1\udc2d\ud936\udd49\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\uda2b\ude4f\udad9\uddd3\ud886\udf04\ud968\ude8a\udb07\ude38\udb10\ude14\ud899\ude9a\udaf1\udc18\udb84\udcc6\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u34c7\ud5f4\u1e18\u1584\u3230\u5976\u1287\u6c1c\u7f72\u54e0\u5ed5\ua5f5\uc903\u6902\u3a59\u25f9\u66ea\u4a73\u0387", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\udb8e\udcd7",
        30, 76809, 1405175936, 1720839260574497390L, 34391L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 12, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\udb61\udcd5\ud886\udf04\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udb84\udcc6\u7c65\udb26\udf49\udb06\udf51\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\u1792\u49b8\ud454\u5976\u1287\ub1e8\u7f72\u54e0\u5ed5\ua5f5\u2182\u684d\u223a\u5a00\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        26, 76809, 1405175936, 1720839260574497390L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 1, 1, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud945\udf6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\ud88b\uddf2\udb98\udd4b\udb61\udcd5\ud886\udf04\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udb84\udcc6\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udb99\udc16\u54b3", "\u82ff\u2248\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u54e0\u5ed5\ua5f5\u2182\u684d\u3a59\u5a0e\u4daa\u8366\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\ud8ef\udd77",
        26, 76809, 1405175936, 1720839260574497390L, 53191L, false, true, (char) 54579, (char) 64551,
        Double.longBitsToDouble(0x3feba4ee40350000L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\udb61\udcd5\ud886\udf04\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udb84\udcc6\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u54e0\u5ed5\ua5f5\u2182\u684d\u3a59\u5a0e\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        26, 76809, 1405175936, 1720839260574497390L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@? |this=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\udb61\udcd5\ud9c1\udd41\ua56e\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udb84\udcc6\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u54e0\u5ed5\ua5f5\u2182\u684d\u3a59\u5a0e\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        26, 76809, 1405175936, 1720839260574497390L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3fe0562bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@? |this=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 13, "\ud9f5\ude96\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39", "\u3ee5\u4fa5\u6625\u0404\u3517\u8406\u3c5a\u7be0\u2773\u6267\u3f77", "\ud9d1\udf7e\ud843\udd47\udb03\udc45\ud995\ude98",
        34, 51660, 641692196, -1123379600378281425L, -59320L, false, true, (char) 37055, (char) 21921,
        Double.longBitsToDouble(0x3fd7e87b50e69ba0L), Double.longBitsToDouble(0x3fcfe4a0c8f12a90L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 1, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\uda49\udfbe\ud9c0\udd47\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udb68\udd20\ud999\ude1b\udb61\udcd5\ud886\udf04\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\ud80b\udf4f\ud893\udd82\u7911\udb57\ude58\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u8aa2\u5ed5\ua5f5\u2182\u4493\u3a59\u025a\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        26, 76809, 420911190, 1720839402448009838L, 4042L, false, false, (char) 37038, (char) 15246,
        Double.longBitsToDouble(0x3fd636fd0850634aL), Double.longBitsToDouble(0x3feba4ee403548d9L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\012",
        Z.run(T, 2, 0, 13, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfcb\u7b6f\udaf1\udc2d\ud866\udfc1\ud939\udd70\ud81e\udc5f\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\ud997\udc4c\udaf1\ude1f\ud999\ude46\udb6d\ude6a\uc45d\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udabc\udcc2\u33d6\udb26\udf49\uf884\ud9bb\udf9a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\u46e0\ud24f\ud455\u5951\u1287\u6c1c\u7f72\u54e0\ua84d\uc279\u4bd1\u0b13\u32c9\ud435\u4daa\u7e69\ub9c2", "\ud8ef\udd03\ud9fe\ude42\ud96b\ude93\uda35\udd44",
        26, 76809, 1405175936, 1720839260574497390L, 60908L, true, false, (char) 24452, (char) 20626,
        Double.longBitsToDouble(0x3fe2215482f4e650L), Double.longBitsToDouble(0x3fde0087ea44399aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 10, "\udabb\udff3\udba7\udec6\udba3\udedc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39", "\u3ee5\u5ddd\u0f78\u311e\u454d\ucab9\u6879\u7be0\u2773\u6267\u3f77", "\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98",
        34, 51660, 641692196, -1123379600378281425L, -1561L, false, true, (char) 3668, (char) 29170,
        Double.longBitsToDouble(0x3fca3bfdd8937df0L), Double.longBitsToDouble(0x3fd7e87b50e69ba0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\012",
        Z.run(T, 1, 13, 12, 13, "\udabb\udff3\uda87\ude15\udb70\udeb8\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\u00fc\u7ac5\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udba5\ude11\ud8bd\udd6f\uda38\udc5d\udbdf\ude0f\ud999\ude46\udb61\udcd5\ud886\udf04\ud968\ude8a\udb07\ude38\udb57\udeb8\000\udaf0\udf2e\udb84\udcc6\u7c65\udb26\udf49\uda36\udfc2\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\000\u49b8\ud454\u5976\u1287\u6c1c\000\u54a6\u5ed5\ua5f5\u2182\u684d\u3a59\u5a0e\u4daa\u7e69\ud400", "\udb67\udc42",
        33, 85259, -721104468, 6148499047321988145L, 8081L, false, false, (char) 61377, (char) 5533,
        Double.longBitsToDouble(0x3fcbd3ec799ce91cL), Double.longBitsToDouble(0x3fd5cba32ac6dfa0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 5, "\udabc\udc33\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8", "\u4fa5", "\ud927\udff5\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\uda0e\udfd0\udafb\udec1",
        31, 76229, 1402655772, -7702272350882590969L, 28653L, false, true, (char) 64228, (char) 54748,
        Double.longBitsToDouble(0x3faa931fa2ff0680L), Double.longBitsToDouble(0x3fe7a49c419817c2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@? |this=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@? |this=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\012",
        Z.run(T, 2, 9, 9, 13, "\udabc\udc33\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\udaf0\ude49\ud8f2\udffd\ud912\udd09\ud968\uddce\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\ud9b0\uddcc\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u0db3", "\u82ff\u167b\u131d\u49b8\ud454\u5976\ucfdc\u6c35\u7f72\u54e0\u5ed5\u9808\u2b5c\ub49a\u3a59\u5a0e\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        0, 77849, 1405175936, 1720839260574497390L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3fe3a4be40fc83d2L), Double.longBitsToDouble(0x3fe13a8bd3ba0cd8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@? |this=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udb96\udd4e\uda48\udd39\uda04\udfe8\u7b6f\udaf1\udc2d\ud936\udd29\ud88f\udfae\ud804\udfc5\ud92d\udfb4\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\uda47\udca8\ud955\udcfe\udab7\udf9a\udb07\ude38\udb10\ude14\ud995\ude98\ud81b\udd9b\udb83\udfea\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\uda47\udcac\u54b3", "\u2307\u70ff\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u54e0\u5ed5\uae1c\u2182\uc769\u3a59", "\ud8b2\udc0c\udba0\udf74\ud9bb\udde2\ud8c9\udfeb\udb67\udc42\uda15\udd2a\ud9fa\udcd2\ud8ec\udf5b\ud908\udc56\u5f90",
        16, 97113, -1441351058, -4152790913099061862L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3fe0562bd61e0cd8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 11, 8, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\ud8d2\udd24\uda48\udd39\uda04\udfe8\u7b6f\udaf0\udfcf\ud936\udd29\ud88f\udfae\ud804\udfc5\ud8f7\udd70\ud886\udf26\ud8bd\udfc4\udb38\udf6e\udb86\udfd7\udb07\udd78\ud999\ude46\udb89\udfd5\udbe4\udcc2\udb6a\ude8b\udb07\ude38\udb10\ude14\ud995\ude98\ud81b\udd9b\udb84\udcc6\u7c65\udb26\udf49\udb30\udebe\ud9b4\udc5a\udae1\udc93\u2683\ud823\udfc3", "\u2389\u70ff", "\udbac\udc30\ud829\udd65",
        43, 99719, -102080083, -8360599412101919528L, 91506L, false, true, (char) 41788, (char) 21213,
        Double.longBitsToDouble(0x3fd308bc6458294eL), Double.longBitsToDouble(0x3fb5f57d3f7bf438L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 5, "\udabb\udfd7\udba7\udec6\ud984\ude22\ud809\ude7b\ud957\udd6b\udafb\uddc0\uda48\udd39", "\u92dd\u7cef\u2ad3\u4a43\u3517\u8406\u3c5a", "\udbdf\udefd\ud999\ude46\udb61\udcd5\ud94b\ude66\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\ud897\udf01\u7c65\ud9f0\udfad\udb1e\udd55",
        12, 57368, -603890122, 2287968770241383782L, 39627L, true, false, (char) 21931, (char) 25834,
        Double.longBitsToDouble(0x3fbcd37407f92830L), Double.longBitsToDouble(0x3fe1e25524a7af3fL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@? |this=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@? |this=com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\012",
        Z.run(T, 2, 9, 9, 4, "\udabb\udff3\udba7\udec6\ud9c6\udcc2\udb65\udecd\ud8f5\uded8\uda49\udf66\ud9c0\udd47\uda04\udfe8\ufc64\udaf1\udc2d\ud936\udd29\udb4a\udc15\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udb68\udd20\ud999\ude1b\udb61\udcd5\ud9db\ude7b\ud968\ude8a\udb65\ude47\udb10\ude14\ud995\ude98\ud80b\udf4f\ud893\udd82\u7911\udb57\ude58\uda46\udfca\ud9b4\udc62\ud822\udee7\udbd9\udc8b\u54b3", "\u82ff\u2248\u1792\u49b8\ud454\u5976\u1287\u6c1c\u7f72\u8aa2\u5ed5\ua5f5\u2182\u4493\u3a59\u025a\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        26, 76809, 420911190, 1720839402448009838L, 4042L, false, false, (char) 37020, (char) 15246,
        Double.longBitsToDouble(0x3fd636fd0850634aL), Double.longBitsToDouble(0x3feba4ee403548d9L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfe8\u7b6f\udaf0\udf9c\ud936\udd29\ud93c\udc0e\udbea\udefe\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\udb55\udeab\udbdf\udefd\ud999\ude46\udb61\udcd5\ud886\udf04\ud968\ude8a\ud87c\udf60\udb10\udd71\ud995\ude98\udaf1\udc18\udb84\udcc6\u7c65\udb26\udf49\uda46\udfca\ud9b4\udc5a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\u1792\u49b8\ud454\u5976\u1287\u38cc\u26ee\u54e0\u5ed5\ua5f5\u2182\u684d\u3a59\u5a0e\u4daa\u7e69\u01f7", "\udb67\udc42\uda15\udd2a\ud9fa\udcd2\uda23\udf23",
        26, 76809, 1405175936, 1720839260574497390L, 53191L, false, true, (char) 54579, (char) 11725,
        Double.longBitsToDouble(0x3feba4ee403548d9L), Double.longBitsToDouble(0x3feb1543d7777b71L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\012",
        Z.run(T, 2, 0, 13, 13, "\udabb\udff3\udba7\udec6\udb78\udcdc\ud886\udf69\ud957\udd6b\udafb\uddc0\uda48\udd39\uda04\udfcb\u7b6f\udaf1\udc2d\ud866\udfc1\ud939\udd70\ud81e\udc5f\ud8f9\ude47\ud8d1\uddeb\udaea\udc35\ud8bd\udd6f\ud997\udc4c\u1d6a\ud999\ude46\udb6d\ude6a\uc45d\ud968\ude8a\udb07\ude38\udb10\ude14\ud995\ude98\udaf1\udc18\udabc\udcc2\u33d6\udb26\udf49\uf884\ud9bb\udf9a\udae1\udc93\udbd9\udc16\u54b3", "\u82ff\u2248\u46e0\ud24f\ud455\u5951\u9c4e\u6bf2\u7f72\u54e0\ua84d\uc279\u4bd1\u0b13\u32c9\ud435\u4daa\u7e69\ub9c2", "\ud8ef\udd03\ud9fe\ude42\udb24\udf0f\uda91\udf9a",
        29, 76809, 1405175936, 1720840089517800046L, 60908L, true, false, (char) 24452, (char) 20626,
        Double.longBitsToDouble(0x3fe22154815ff9e7L), Double.longBitsToDouble(0x3fd70dac8a44971eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|<init>|com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "C|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|<init>|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider",
    "C|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|<init>|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider,com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.ser.SerializerFactory",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_asXmlGenerator|com.fasterxml.jackson.core.JsonGenerator|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_initWithRootName|com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator,javax.xml.namespace.QName|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_rootNameFromConfig||new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_serializeXmlNull|com.fasterxml.jackson.core.JsonGenerator|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_startRootArray|com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator,javax.xml.namespace.QName|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_wrapAsIOE|com.fasterxml.jackson.core.JsonGenerator,java.lang.Exception|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|copy||new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|createInstance|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.ser.SerializerFactory|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|serializeValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|serializeValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonSerializer|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "C|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|<init>|com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "C|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|<init>|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider",
    "C|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|<init>|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider,com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.ser.SerializerFactory",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
