package com.fasterxml.jackson.dataformat.xml.ser;
import org.junit.Test;
import static org.junit.Assert.*;
public class XmlSerializerProvider_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 2, "\udb16\udd42\udbb6\udfca\ud8f3\udc56\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\u1dba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udb54\udd34\udabb\udf6b\udb57\udcdf", "\u1d0d\u2915\u6f21\uc613\u4ac1\u65f0", "\udaff\ude55\ud8e8\uddad\udbb8\udf45\udb89\udd1b\udb06\udc5f\ud999\udfaa\uda43\udc3e\ud831\udffe\u3bd8\uda65\udcd5\ud8a4\udfbd\udaf1\ude28\udb33\udeea\udb66\udcec\udb84\uddee\udaaf\udcce\udaf9\udddd",
        16, 52982, 581651709, -2045739929819077901L, -78282L, false, true, (char) 7588, (char) 52069,
        Double.longBitsToDouble(0x3fe46b0878cdbaf5L), Double.longBitsToDouble(0x3fef02e9df987e68L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 0, "\udbea\udecd\udbb6\udf7a\ud80a\udda3\ud999\uded4\ud876\ude36\ud87e\udce4\udbbc\udf80\ud829\udcc5\udbab\udd3f\ud858\udfa1\udbc2\udfb7\ud835\udfae\uda9d\udcfa\ud8ca\udcd0\u1dba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udb54\udd34\udabb\udf6b\udb57\udcdf", "\u1d0d\u2915\u6f21\uc613\u4ac1\u65f0", "\udaff\ude55\ud85f\udc10\ud97f\udcec\udb76\uddfc\udb06\udc5f\ud999\udfaa\uda43\udc3e\ud831\udffe\u3bd8\uda65\udcd5\ud8a4\udfbd\udaf1\ude28\ub73d\udb66\udcec\ud939\ude29\udaaf\udcce\udaf9\udddd",
        16, 52982, 581651709, -2075857752327118093L, -78282L, true, false, (char) 7588, (char) 52069,
        Double.longBitsToDouble(0x3fde536dbacb4342L), Double.longBitsToDouble(0x3fbc9c2a7b70f760L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 2, "\uda05\udcf1\uda58\ude7e\ud8fa\uddf9\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd", "\u2454\u34c1\u7428\u4644\u15c6\u4c67\u2c34\u6295\uaef4\uabc9\u3cd5\u6653\u8eb0", "\ud9f0\udd27\ud844\udc4d\ud86d\ude00\ud817\uddf6\u5bc2\u02b0\udbb8\udef2\uda5a\udd23\ud9a5\udeb1\uda64\udcde\udaff\ude55\ud8e8\uddad\udbb8\udf45\udb89\udd1b\udb06\udc5f\ud999\udfaa\uda43\udc3e\udb5f\ude75\udbf8\uddae\udb75\ude5d\ud8a4\udfbd\udaf1\ude28\udb33\udeea\udb66\udcec\udb84\uddee\ud95b\udcf6\ud9a0\udd62\ud9e2\udf6b\ud884\udd3f\ua708\udaac\udcb2\ud936\udcc9\ud9b7\udca9\uda00\udf8b\udb50\udc20\udb9d\udeb2\ud91f\udecf\ud95d\ude7b\uda2f\ude4b\ub753\uda64\udd1c\ud881\udd2d\ud968\ude55\udaec\udfb1\udaa9\udcd9\ua028\udbdb\uddaf\ud88d\udf94\ud989\udf76\ud9cf\udfcd\udac9\udc07\ud8b6\udca4",
        9, 63307, -247158882, 2744758178330580571L, 98494L, false, true, (char) 63082, (char) 42348,
        Double.longBitsToDouble(0x3fcacfb537cacb48L), Double.longBitsToDouble(0x3fe3997db1430b6aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 2, "\udb16\udd42\udbb6\udfca\uda8b\udea2\ud9ba\udce4\000\ud98a\udf85\ud85c\ude27\ud987\udf96\000\000\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\u14ba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud875\udebcU\000\udb1d\udd4d\udb82\udd66\udb54\udd34\udabb\udf6b\udb57\udcdf", "\u1d0d\u2915\u6f21\uc613\u4ac1\uc2dd", "",
        -5, 22536, 2752512, -2856971011800751614L, 15914L, false, true, (char) 41281, (char) 626,
        Double.longBitsToDouble(0x3f4bfcc000000000L), Double.longBitsToDouble(0x3fd6ef600a5d8956L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 2, "\udb16\udd42\udbb6\udfca\ud8f3\udc56\ud999\uded4\ud97a\udf62\udbab\udc2e\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\u1dba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udb54\udd34\udabb\udf6b\udb57\udcdf", "\u1d0d\u2915\u4cdc\u272c\u5409\u65f0", "\udaff\ude55\ud8e8\uddad\udbb8\udf45\udb89\udd1b\udb06\udc5f\ud999\udfaa\uda43\udc3e\ud831\udffe\u3bd8\uda65\udcd5\ud8a4\udfbd\udaf1\ude28\udb33\udeea\uda9d\ude08\udb84\uddee\udaaf\udcce\udaf9\udddd",
        16, 52982, 581651709, -2045739929819077901L, -78282L, false, true, (char) 7588, (char) 33126,
        Double.longBitsToDouble(0x3fd8d610f19b756cL), Double.longBitsToDouble(0x3fef02e9df987e68L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 4, 2, "\udb16\udd42\udbb6\udfca\ud8f3\udc56\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\u1dba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud875\udebc\udafd\ude6d\ud9d0\ude90\udab9\udf82\udb82\udd66\udb54\udd34\udabb\udf6b\udb57\udcdf", "\u1d0d\u2915\u6f21\uc613\u4ac1\ua468", "\udae3\udf98\ud8e8\uddad\udbb8\udf45\ud893\ude17\udac8\udc60\ud999\udfaa\uda43\udc3e\ud831\udffe\udbdd\udee0\uda65\udcd5\ud8a4\udfbd\udaf1\ude28\udb33\udeea\ud803\udc5b\udb84\uddee\udaaf\udcce\udaf9\udddd",
        37, 39428, 581651709, -2045739929819077901L, -78282L, false, true, (char) 32423, (char) 52069,
        Double.longBitsToDouble(0x3fe46b0878cdbaf5L), Double.longBitsToDouble(0x3fecd2e9df394ebbL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 2, "\udb31\ude42\udbb6\udfca\ud8f9\ude50\udbbe\udc05\ud99c\udeeb\ud879\uded1\ud85c\ude27\u9ce3\udbf8\udedf\udb98\udf54\ud9da\udd6f\ud85e\udc6a\udabd\udc9e\ud888\udccf\ud816\ude6b\uda36\udf13\udb42\udefd\ud9e5\ude9d\ud875\udf4f\ud8fe\udccb\ud9d0\ude90\udb6c\udddd\u0e13\udb54\udd34\udabb\udf6b\udb57\udcdf", "\u1d0d$\u6f38\uc613\u4ac1\u65f0", "\udaff\ude55\ud8e8\uddad\udbb8\udf45\uda25\udf0f\ud923\udf3a\ud98c\uddcb\ud89c\udd48\ud832\udcaf\u3bd8\uda65\udcd5\ud8a4\udfbd\udaf1\ude28\udb33\udeea\udb66\udcec\udb84\uddee\udaaf\udcce\udaf9\udddd",
        16, 52982, 581651709, -2045739929817060621L, -37830L, true, true, (char) 25500, (char) 31682,
        Double.longBitsToDouble(0x3fef02e9df987e68L), Double.longBitsToDouble(0x3f935af2c1727ae0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 0, 2, "\udb16\udd42\ud8af\udfe7\uda98\udda1\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf", "\u4c67\u2c34\u82e0\uaef4\uabc9\u5d9d\u237a\ua7ae\u9704\u517b\u9ad5", "\ud817\uddf6",
        19, 56282, 2123513022, -5163162717408959667L, 1640L, false, true, (char) 64092, (char) 61813,
        Double.longBitsToDouble(0x3fdf225e086ee2beL), Double.longBitsToDouble(0x3fc9465d6fd9ded4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 2, "\udb09\udf42\udbb6\udfca\ud8f3\udc56\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\u1dba\ud9e0\ude28\ud858\udf3e\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udad0\udd12\udabb\udfd8\udb57\udcdf", "\u1d0d\u2915\u6f21\uc613\u4ac1\u65f0", "\udaff\ude55\ud8e8\uddad\udbb8\udf45\udb89\udd1b\udb06\udc5f\ud999\udfaa\uda42\udfc1\ud831\udffe\u3bd8\uda65\udcd5\udb18\udfd7\udb0d\udf7d\ud90f\uddbf\ud898\udd97\uda49\udfb1\uda5a\udcfc\udaf9\udddd",
        16, 52982, 581651709, -2045739929819077901L, -78282L, false, true, (char) 7588, (char) 52069,
        Double.longBitsToDouble(0x3fe46b0878cdbaf5L), Double.longBitsToDouble(0x3fef02e9df987e68L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 10, "\udb16\udd42\ud9f4\udd19\ud8e2\udcf2\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\u1dba\uda36\udf13", "\u82e0\uaef4\uabc9", "\ud8fe\udc18\ud817\udda9\udb82\ude47\ud9f0\udd3b\udb77\udc86\ud86d\ude00\ud817\uddf6\u5bc2\u02b0\ud9fd\udc33\udbfd\udea3",
        37, 84176, 476812457, -7564323489055078408L, -43170L, true, true, (char) 52177, (char) 33803,
        Double.longBitsToDouble(0x3fefb9906c368946L), Double.longBitsToDouble(0x3fe4db47480d1a65L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 0, 2, "\udb16\udd42\udbb6\udfca\ud8f3\udc56\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\u1dba\udb2c\udf0f\udb42\udefd\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udb54\udd34\udacf\ude62\udbfc\udceb", "\u1d0d\u2915\u6f21\uc41a\u4ac1\u65f0\u34d7\ua7bd", "\udbb8\udf45\udb89\udd1b",
        16, 79215, 1596171762, 3606580131762914506L, 89905L, true, false, (char) 28521, (char) 16237,
        Double.longBitsToDouble(0x3fd6ef60ca5d8956L), Double.longBitsToDouble(0x3febe7cd70526c4aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\012",
        Z.run(T, 1, 9, 0, 2, "\udb16\udd42\udbb6\udfca\ud8f3\udc56\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\u1dba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udb54\udd34\udabb\udf6b\udb57\udcdf", "\u1d0d\u2915\u6f21\uc613\u4ac1\u65f0", "\udaff\ude55\ud8e8\uddad\udbb8\udf45\udb89\udd1b\udb06\udc5f\ud999\udfaa\uda43\udc3e\ud831\udffe\u3bd8\uda65\udcd5\ud8a4\udfbd\udaf1\ude28\udb33\udeea\udb66\udcec\udb84\uddee\udaaf\udcce\udaf9\udddd",
        16, 52982, 581651709, -2045739930389503245L, -78282L, false, true, (char) 7588, (char) 52069,
        Double.longBitsToDouble(0x3fe46b0878cdbaf5L), Double.longBitsToDouble(0x3fef02e9df987e68L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 0, 2, "\000\udbb6\udfca\ud8f3\udc56\ud999\uded4\ud97a\udf62\ud98a\udfdb\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97F\udabd\udc9e\ud888\udccf\u1dba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udb9c\ude34\udac6\udc02\000\udb7b\udd5c\udb57\udcdf", "\u88fb\u282b\u6f21\uc613\u456b\u7b12", "\u94a9\ud8e8\udcd0\udbb8\udf45\udb89\udd1b\udb06\udc5f\ud999\udfaa\uda43\udc3e\u250b\u3b0e\u9bf6\ud8a4\udfbd\udaf1\ude28\udb33\udeea\udb66\udcec\udb84\uddee\udaaf\udcce\ucf7c",
        -5, -1000, 0, -2045739929819077901L, -78282L, false, true, (char) 7588, (char) 52069,
        Double.longBitsToDouble(0x3fe46b0878cdbaf5L), Double.longBitsToDouble(0x3fef02e9df987e68L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 5, 3, "\udbea\udecd\udbb6\udf7a\ud80a\udda3", "\u9d49\u7bb0\u6f23\ube3f\u2c72", "\ud913\udc26\udb17\ude81\udbc4\uddac\uda36\udf13\udb42\udefd\udb82\udfd3\ud84c\uddbc\ud8fe\udccb\ud9d0\udebb\udab9\udf82\udb82\udd66\udb54\udd34\udabb\udf7d\udb57\udcdf\udb78\udc05\ud8c1\udf2d\ud86d\udd6c\ud817\uddf6\ud8a7\udda9\ud9ba\udeb9\ud883\udc36\ud810\udeef",
        28, 85331, 476812420, -978445653279692686L, 26294L, true, true, (char) 52177, (char) 2095,
        Double.longBitsToDouble(0x3fc94641afd9ded4L), Double.longBitsToDouble(0x3fe17c38900d1448L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\012",
        Z.run(T, 1, 9, 6, 2, "\ud973\udc9e\udaa0\udf71\ud8fa\udde6\ud999\uded4", "\u8e9c\u9a11\u975c\u8562\u3ca7\u2454\u34c1\u7428", "\udb4c\udd87",
        36, 35627, -875542955, -3249249725965749400L, -37881L, false, false, (char) 21759, (char) 54871,
        Double.longBitsToDouble(0x3fc95f7c92fa61d8L), Double.longBitsToDouble(0x3fed170c97115d6fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 3, "\udb16\udd42\udbb6\udfca\uda8b\udea2\ud9ba\udce4\000\ud98a\udf85\ud85c\ude27\ud9fe\ude71\000\000\udbd9\udefe\uda74\udc68\udabd\udc9e\ud888\udccf\u14ba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud93e\ude61\ud8e2\udedaz\udb1d\udd4d\udadf\udf16\udb6a\udc92\udabb\udf6b\udb57\udcdf", "\u1d0d\u2915\u6f21\uc613\u4ac1\uc2dd", "",
        -5, 22536, 2752512, -2856971011800751614L, 15914L, false, true, (char) 8513, (char) 35667,
        Double.longBitsToDouble(0x3f4bfcc000000000L), Double.longBitsToDouble(0x3fd6ef600a5d8956L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 9, "\ud8cb\udebd\ud982\udd9c\ud8f3\udc56\ud999\uded4\ud97a\udf62\udbab\udc2e\ud85c\ude27\ud814\udc52\ud815\udccf\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\uda1c\uddca\uda26\ude65\ud9be\udefb\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udb54\udd34\udabb\udf6b\udb57\udcdf", "\u76d3\u28b0\u4cdc\u272c\u5409\u7ea1\u34d7\u5547\u914a\uac7d\u853d\u0f17\ud6d1\u4df0\u3bbd\u37e0\u0098\u1471\ua192\uc689\u37b7\u6b55\ucf1b\u25b1", "\ud976\ude4c",
        57, 4171, 1682776819, 6722421968824980694L, 34438L, false, false, (char) 22172, (char) 12114,
        Double.longBitsToDouble(0x3feaa81cc7987e68L), Double.longBitsToDouble(0x3fbb50ea7c72bf40L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 2, "\udb16\udd42\udbb6\udfca\ud8f3\udc56\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud9bc\udf0a\ud9eb\udfb9\uda74\udc68\udabd\udc9e\ud888\udccf\u1dba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udaec\udd40\udacc\udd16\udbbe\udf93", "\u1d0d\u2915\u6f21\uc613\u4ac1\ub632", "\udaff\ude55\ud8e8\uddad\udbb8\udf45\udb89\udd1b\udb06\udc5f\ud999\udfaa\uda43\udc3e\ud831\udffe\u3bd8\uda65\udcd5\ud8a4\udfbd\udaf1\ude28\udb33\udeea\udb66\udcec\udb84\uddee\udaaf\udcce\udaf9\udddd",
        16, 52982, 581651709, -1829567149775118430L, -78282L, false, true, (char) 7588, (char) 52069,
        Double.longBitsToDouble(0x3fe46b0878cdbaf5L), Double.longBitsToDouble(0x3fef0541df987e68L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 8, "\ud98c\ude15\udbbb\ude55\ud80a\udda3\uda8b\udfed\udbc6\udf57\ud898\ude9e\ud8e9\udd01", "\u2c72\uc46e\u6758\u5c0a\uc067\u93f8\u15c6\u4c67\ucb40\ub5df\u8efc\uac4c\u5d9d\u0b7a\u7993\u974f\u517b\ubecc\u9d48\u1c79\u2915\u8567\u369c\u92f6", "\udbe8\udd35\udaff\ude30\uda5f\udcd4\udbf8\uddb5\ud8cd\udeba\ud95e\udf78\udb85\udf0b\uda23\udd4a\ud831\udffe\u3ca0\ud8fa\udd5f\udbee\udc05\u1c96\uda90\udcd1\ud82f\udf82\ud855\udf71\ud8a5\udfc0",
        52, 67636, -589833512, 3375204644666875058L, -99596L, false, true, (char) 47244, (char) 10234,
        Double.longBitsToDouble(0x3f9684522f543660L), Double.longBitsToDouble(0x3fd984de94313bdcL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 6, "\udb69\udef9\udaa0\udf71\ud8fa\udde6\ud999\uded4", "\u8e20\u9a11\u975c\u8562\u3ca7\u2454\u34c1\u7428", "\udb4c\udd87",
        36, 35627, -875542955, -3249249725965749400L, -37881L, false, false, (char) 21759, (char) 54871,
        Double.longBitsToDouble(0x3fc95f7c92fa61d8L), Double.longBitsToDouble(0x3fd33e192e22bb7aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 6, 2, "\ud973\udc9e", "\u674e\u3ade\u0736", "\ud85e\ude4f\ud871\udef0\ud9e6\udf62\uda62\ude55\uda19\udd9e\ud84f\udccf\udbc3\udedd\ud963\udfa6\udb42\udce2\ud936\udd7c",
        -3, 25045, -35104677, -6419361978408526284L, 83249L, false, true, (char) 27913, (char) 53840,
        Double.longBitsToDouble(0x3fb88ba6c5c0bd00L), Double.longBitsToDouble(0x3f414ae32bef9000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 6, 2, "\ud973\udcd7\udbce\udee8\ud8fa\udde6\ud999\uded4", "\u2e9c\u9a11\u975c\u8562\u3ca7\u2454\u34c1\u7428\uc934\u35f5\u72f1\u1af9\u6295\ud07a\u5325\u4079\u5c82\uc5e8\u0660\u90d5\u48f4\ucf95\ucb33\u5ceb\u6f21", "\uda5a\udd23\ub86d",
        16, 18672, -728240310, -4435412164249621327L, -5317L, true, true, (char) 18730, (char) 59750,
        Double.longBitsToDouble(0x3fd24b50eae68da0L), Double.longBitsToDouble(0x3f9268b562e6ed20L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 7, 10, "\ud820\udd30\u32ed\ub700\uda3e\ude4b\udb16\udc75\udbe2\udd7a\udbf1\udf1c\ud99b\udd2a\ud94a\udc43\ud93f\udd5d\udb5f\udd54\ud9ee\udf09\uda73\udc29\udb6d\udee1\ud806\udcb1\uda36\udf13\ud897\udcc6\ud80c\udd8f\udb12\ude69\udaf7\udf47\ud84b\udeb8\ud8d2\ude0e\ud8bc\udc5d\udb8d\udd82\ud979\uddbc\udb57\udd10", "\u1d0d\uc1c7\u6f99\ud660\uabb0\uad93", "\udaa9\udc47\udb21\udfb6\udba8\udcd0\udae1\udfe4\ud88d\udff8\u1ee5\udbc0\udee5\udab6\udd45\ud84d\udd4f\u1d1a\ud8fc\ude30\udac5\ude3c\ud985\uddb7\udaf4\udd0e\ud990\udc4f\udb97\udc01\ud99f\udfae\udb8b\udeec\ud844\ude62",
        33, 89352, -1300203564, 6799026607531793289L, 6712L, true, false, (char) 40462, (char) 7227,
        Double.longBitsToDouble(0x3fe841273e87528aL), Double.longBitsToDouble(0x3fba888ab5d1e7c8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\012",
        Z.run(T, 2, 9, 9, 9, "\udb79\ude7d\udb04\udeed\ud8f3\udc56\ud999\uded4\ud97a\udf62\udbab\udc2e\ud85c\ude27\ud814\udc52\ud815\udccf\ud94e\udfd2\ud9da\udd97\uda9e\udd4a\udabd\udcb0\ud888\udccf\uda1c\uddca\uda26\ude65\ud9be\udefb\ud8d3\udcd3\udb18\udf73\udb55\udf07\ud80a\udc8b\udabf\ude22\u9574\udb7c\udfa9\udabb\udf6b\udb57\udcdf", "\u6529\u28b0\u4cdc\u272c\u5409\u7ea1\u5bf3\u5547\ucd4a\u2440\u853d\u0f17\uc473\u0960\u6d44\ua43b\u0098\u1471\ua192\uc689\u37b7\u6b55\ucfab\ud694", "\ud976\ude4c\ua508\udaac\udd26\ud89e\udcdc\ud9b7\udca9\uda00\udf8b\udb50\udc20\ud844\udd26\ud927\udc9c\ud97c\udeab\ud8e4\udcad\ud994\ude1c\udb14\udf94\ud8d1\udd9b\ud948\udc23\ud9d1\udc61\udae4\udcd8\udb9a\udd4a\ud872\ude1b\ud8cc\uded1\ud9e7\udf23\uda64\udca2\ud92e\udc44\ud8fa\uddc5\uda89\udefc\uda0b\udc0f\ud8a4\ude1e\udb2f\udc96\ud8fd\udc87\ud932\udcb3\udad6\udfdf\udab2\udf00\udb77\udc12\ud930\udddf\udbfa\udecf\udbf0\udc0e\ud813\ude45\udb82\ude4c",
        40, 1055, 1933777426, 7237542766661548349L, 59256L, true, false, (char) 24354, (char) 19460,
        Double.longBitsToDouble(0x3fe58ebd76536e79L), Double.longBitsToDouble(0x3fe67784ddc71727L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 3, "\ud8cb\udebd\ud982\udd9c\ud8f3\udc56\ud999\uded4\ud97a\udf62\udbab\udc2e\ud85c\ude27\ud814\udc52\ud815\udccf\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\uda1c\uddca\uda26\ude65\ud9be\udefb\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udb54\udd34\udabb\udf6b\udb57\udcdf", "\u76d3\u28b0\u4cdc\u272c\u7d43\u113c\u34d7\u5547\u914a\uac7d\u853d\u0f17\ud6d1\u1ddf\ud285\u37e0\u0098\u1471\ua192\uc689\u37b7\u6b55\ucf1b\u25b1", "\ud976\ude4c",
        57, 74883, 1682776819, 6722421968824980673L, 34438L, false, false, (char) 22172, (char) 12114,
        Double.longBitsToDouble(0x3feaa81cc7987e68L), Double.longBitsToDouble(0x3fbb50ea7c72bf40L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 2, "\ud8cb\udddb", "\u775f\u248a\u969f", "\ud815\udccf\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\uda1c\uddca\uda26\ude65\ud9be\udefb\ud8d3\udcd3",
        29, -1000, 0, 6532471445764611034L, 51098L, false, true, (char) 13251, (char) 44400,
        Double.longBitsToDouble(0x3fc991409ffdb034L), Double.longBitsToDouble(0x3fe0375873007e92L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 2, "\udb16\udd42\udbb6\udfca\ud8f3\udc56\ud999\uded4\ud97a\udf62\ud87e\udce4\ud85c\ude27\ud82c\udf49\ud815\udcdd\ud94e\udfd2\ud9da\udd97\uda74\udc68\udabd\udc9e\ud888\udccf\u1dba\uda36\udf13\udb42\udefd\ud8d3\udcd3\ud875\udebc\ud8fe\udccb\ud9d0\ude90\udab9\udf82\udb82\udd66\udb54\udd34\udabb\udf6b\udb57\udcdf", "\ub7b7\u2849\u6f21\uc613\u4ac1\u65f0", "\udaff\ude55\ud8e8\uddad\udbb8\udf45\udb89\udd1b\udb06\udc5f\ud999\udfaa\uda43\udc3e\ud831\udffe\udaaf\ude28\uda6d\udcc3\ud8a4\udfbd\udaf1\ude28\udb33\udeea\udb66\udcec\udb84\uddee\udaaf\udcce\udaf0\udfdd",
        16, 52982, 581651709, -2045739929819077901L, -78282L, false, true, (char) 7588, (char) 52069,
        Double.longBitsToDouble(0x3fe46b0878cdbaf5L), Double.longBitsToDouble(0x3fef02e9df987e68L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 9, "\ud8eb\udf4d", "\u775f\u248a\u861d\uc30a\u298d\u974e\ua93d\u3ca7", "\ud888\udccf\uda1c\uddca\ud84e\udc10\ud117",
        50, 13979, 0, -2305843008433335854L, 99533L, false, false, (char) 39541, (char) 32824,
        Double.longBitsToDouble(0x3fc9a7fc67d6afccL), Double.longBitsToDouble(0x3fc0b613d7322810L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_serializeXmlNull|com.fasterxml.jackson.core.JsonGenerator|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_asXmlGenerator|com.fasterxml.jackson.core.JsonGenerator|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_initWithRootName|com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator,javax.xml.namespace.QName|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_rootNameFromConfig||new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_startRootArray|com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator,javax.xml.namespace.QName|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|createInstance|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.ser.SerializerFactory|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|serializeValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|serializeValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|serializeValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonSerializer|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "C|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|<init>|com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
    "C|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|<init>|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider,com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.ser.SerializerFactory",
    "M|com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider|_serializeXmlNull|com.fasterxml.jackson.core.JsonGenerator|new:com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider:com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
