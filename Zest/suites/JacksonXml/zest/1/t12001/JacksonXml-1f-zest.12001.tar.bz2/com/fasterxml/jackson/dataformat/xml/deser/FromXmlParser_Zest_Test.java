package com.fasterxml.jackson.dataformat.xml.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class FromXmlParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 1, 11, "\udb0c\udebe\ud9d4\udee3\udb09\udc38\ud974\ude07", "\u06e4\u32b4\u33c1\u5de7\u88fa\u3a4f\ua045\u9944\u7d3b\u05fe\u4c4e\uac02\u4421\u3942\u80a8\u5a08", "\ud910\udccb\ud98c\ude2a\udb89\ude9f\udb8a\udf51\udbf4\ude01\ud8ae\udede\ud8b1\uddfa\udb21\udf10",
        4, 13020, 1392350378, 4791712798695772341L, -48274L, true, false, (char) 23595, (char) 11510,
        Double.longBitsToDouble(0x3fc39e01d09c9484L), Double.longBitsToDouble(0x3fd3fcf385ff1eb0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 1, 11, "\udb0c\udebe\ud9d4\udee3\udb09\udc38\ud974\ude07", "\u06e4\u32b4\u33c1\u5de7\uc0d5\u3a4f\ua045\u9944\u7d3b\u05fe\u4c4e\uac02\u4421\u3942\u80a8\u5a08", "\ud910\udccb\ud98c\ude2a\udb89\ude9f\udb8a\udf51\udbf4\ude01\ud8ae\udede\ud949\udd67\udb3c\udcdf",
        4, 13020, 1392350378, 4791712798695772341L, -48274L, true, false, (char) 23595, (char) 11517,
        Double.longBitsToDouble(0x3fc39e01d09c9484L), Double.longBitsToDouble(0x3fd3fcf385ff1eb0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 11, "\udb0c\udebe\ud9d4\udee3\udb09\udc38\ud974\ude07\ud9b8\ude32\ud9e0\udf68\ud8b3\udf22\ud9c7\udcba\uda33\udc4e\ud821\udee5\ud83b\uddeb\udbb3\udd5a\ud870\udf78\ud92c\udc79\udb1e\udc6d\udb80\udd96\ud938\udf7e\ud979\udc4b\ud957\uddfc\udb07\udece\ud9fd\udc8e\ud931\udf1e\udaad\udfde\ud911\uddaf\ud9fb\ude41\ud99e\ude08\uda6c\udcbc\u2f1d\ud9b6\ude9b\ud900\udee0\ud947\ude89\udbda\udd3b\udb12\udd6c\ud974\uddc1\ub98e\ud9a1\udc04\ud823\udebf\uda05\udc51\uda6b\udf4a", "\u20e9\u0c9e\u7174\u47ba\u9df2\u8530\ucea8\u7cb9\u588d\u9485\u9ec5\u9db7\uc8da\ud0f3\u3658\ub9bc\u6e4b\u1345\u1c0f\u339b\u2540", "\ud839\udee9\ud929\udda2",
        8, 4260, -303671881, 3844034324865333195L, 60252L, true, false, (char) 29536, (char) 29092,
        Double.longBitsToDouble(0x3fc34b71c2350e40L), Double.longBitsToDouble(0x3fe7ea1774e7b2b6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 11, 11, "\ud959\udded\ud9b8\udd93\udb09\udc38\ud974\ude07\uda16\ude42\udbd3\udfa2\udab3\udf9f\ud815\udfaa\ud8d4\udd13\uda38\udc44\ud9e1\udf38\udbf5\udcbd\u305c\uef65\udbf6\udd6e\ud9f1\ude10\udb80\udea3\udb48\ude01\udbba\udf00\ud93c\ude3e\ud9c5\udfca\udbe3\udc5d\ud9fc\udcb5\ud99d\ude32\uda79\ude1b\udbfc\udde4\udb89\ude9f\udb8a\udf51\ud80a\udf6c\ud899\ude4e\ud943\udec4\ud833\udf0f\ud9c5\udfa8", "\u6437\u4e94\ud709\u9a7b\ud3e3\u894f\u153f\u0c9e\u4257\u47ba\u5018\u57ab\u34b3\u25c1\uad14.\u576f\u0f9c\u36c3", "\ud884\udd35\ud983\ude3e\ud898\udeb3\udb12\udd0c\ud8a6\ude98\ud9eb\uddbc\ub2c0",
        39, 92016, 2115819779, 2540840016683388809L, -34057L, false, false, (char) 7310, (char) 48544,
        Double.longBitsToDouble(0x3f90ff8496cdf7e0L), Double.longBitsToDouble(0x3fee879fa8de3adaL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 11, "\udb0c\udebe\ud9d4\udee3\udb09\udc38\udab0\udec9", "\u06e4\u0674\u61f1\u42ad\u88fa\u3183\u5259\u160e\uafbd\u1dc0", "\ud957\uddfc\ud97c\udf58\udbfc\udcc6\udb5b\ude0b\udbec\udd4c\ud911\uddaf\ud910\udccb\ud8bd\udcc2\udaba\udfaf\udb8a\udf51\udbf4\ude01",
        -3, 44293, -906558912, -8876877987917110996L, -10212L, false, false, (char) 25391, (char) 23595,
        Double.longBitsToDouble(0x3fa28a6889cf00e0L), Double.longBitsToDouble(0x3fa39290d3fcf380L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 1, 11, "\ud847\udd78\ud83e\udf54\udaf9\udc62\ud974\ude07", "\u06e4\u32b4\u33c1", "\udbed\uddf2\uda00\udd61",
        56, 46729, 695114979, 3655295824185980718L, 91620L, false, true, (char) 56285, (char) 47135,
        Double.longBitsToDouble(0x3fd57e2fae0dbb72L), Double.longBitsToDouble(0x3fa19951c1d72380L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|nextToken||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_decodeBase64|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_getByteArrayBuilder||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_handleEOF||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_isEmpty|java.lang.String|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_releaseBuffers||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|_updateState|com.fasterxml.jackson.core.JsonToken|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|addVirtualWrapping|java.util.Set|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|close||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|configure|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser$Feature,boolean|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|disable|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser$Feature|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|enable|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser$Feature|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|getBigIntegerValue||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|getBinaryValue|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|getCodec||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|getCurrentLocation||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
    "M|com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser|nextToken||new:com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser:com.fasterxml.jackson.core.io.IOContext,int,int,com.fasterxml.jackson.core.ObjectCodec,javax.xml.stream.XMLStreamReader",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
