package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class Lexer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 4, "\udaf8\udd6d\uda47\udf4d\uda10\udf32\uda58\udcc4\ud82d\ude9f", "\u6665\ua51c\ubd3b\uaffc\u6b6e\ua2bb\ub29a\u103c\u1121\u26cf\uae7e\uacea\uc491\u57dc\ubfd2\uab1b\u24d4\ucd6a\u9385\u09ce\u1025\u6791\u1d5b\u90e6\ua0b7\ua955\u1b5a\u213c\u8ecc\u84f1\u61cc\u9cf4\u8a4d\u3dd9\u7be7", "\udb09\udc29\ud9b6\udec2\u9101\ud84d\udf1b\udac2\ude23\ud99f\udd44\ud90a\ude9d\uda2e\udf00\udb90\udeee\udb67\udead\ud855\udca6\ud996\udce5\ud850\udcc9\ud945\udda4\ud96b\uddf9\udb5a\udf01\udb0f\ude88\u8221\uda38\udeb7\udb2e\udf62\udaab\udc06\uda86\udef9\udb68\udeb5\ud848\udc85\ud845\udc91\uda7f\uddcd\uda27\ude03\uda3a\udff2\ud99f\udc45\uda7a\udfd8\ud836\udf3a\ud9a3\ude61\ud9cb\udc6e\ud8ef\udc79\u380c\ud9b5\udec9\udbfd\udc56\uda7d\udfb9\udbe9\udff9\udbda\uddf8\ud993\udfe0\udaa4\udc63\ud893\udc10\udba7\ude97\ue66b\udaaf\udd47\uda4a\udc1e\udb50\uddbe",
        9, 94583, -77530848, 6394797792578001024L, 66514L, false, false, (char) 48190, (char) 4296,
        Double.longBitsToDouble(0x3fea824a14986a11L), Double.longBitsToDouble(0x3fdc31624319b0bcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 11, 4, "\udaf8\udd6d\uda47\udf4d\uda10\udf32\uda58\udcc4\ud82d\ude9f", "\u6665\ua51c\ubd3b\uaffc\u6b6e\ua2bb\ub29a\u103c\u1121\u725c\uae7e\uacea\uc491\u57dc\ubfd2\uab1b\u24d4\ucd6a\u9385\u09ce\u1025\u6791\u1d5b\u90e6\ua0b7\ua955\u1b5a\u213c\u8ecc\u84f1\u61cc\u9cf4\u8a4d\u3dd9\u7be7", "\udb09\udc29\ud9b6\udec2\u9101\ud84d\udf1b\udac2\ude23\ud99f\udd44\ud90a\ude9d\udae8\udefe\ud91f\udeb0\udaaa\ude34\udae7\udddd\udb08\udeac\ud850\udcc9\ud945\udda4\ud96b\uddf9\udb5a\udf01\udb0f\ude88\u8221\uda38\udeb7\udb2e\udf62\udaab\udc06\uda86\udef9\udb68\udeb5\ud848\udc85\ud845\udc91\uda7f\uddcd\uda27\ude03\uda3a\udff2\ud99f\udc45\uda7a\udfd8\ud836\udf3a\ud9a3\ude61\ud9cb\udc6e\ud8ef\udc79\u380c\ud9b5\udec9\udbfd\udc56\uda7d\udfb9\udbe9\udff9\udbda\uddf8\ud993\udfe0\ud935\udecc\ud893\udc10\udba7\ude97\ue66b\uda5c\udef8\uda1f\udc85\uda6e\udd01",
        9, 94583, -77530848, 6394797792578001024L, 66514L, false, false, (char) 48190, (char) 4296,
        Double.longBitsToDouble(0x3fea824a14986a11L), Double.longBitsToDouble(0x3fdc31624377b0bcL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 4, "\udaf8\udd6d\uda47\udf4d\uda10\udf32\uda4e\ude1f\ud9ab\ude45", "\u6665\ua51c\ubd3b\uaffc\u6b6e\ua36c\ub29a\u103c\u1121\u26cf\u246c\u11aa\uc491\u57dc\ubfd2\uab1b\u24d4\ucd6a\u9385\u09ce\u1025\u6791\u1d5b\u90e6\ua0b7\ua955\ud3a5\u213c\u8ecc\u84f1\u61cc\u9cf4\u8a4d\u3dd9\u7be7", "\udb09\udc29\ud9b6\udec2",
        12, 19586, -948914823, -2639180382830741905L, -80336L, true, false, (char) 7138, (char) 47981,
        Double.longBitsToDouble(0x3fd01b001c6e711cL), Double.longBitsToDouble(0x3fef97b23a2bde8dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 4, "\udaf8\udd6d\uda47\udf4d\uda10\udf32\uda58\udcc4\ud82d\ude9f", "\u6665\ua51c\ubd3b\uaffc\u6b6e\ua2bb\ub29a\u103c\u1121\u26cf\uae7e\uacea\uc491", "\uda9e\ude02\ud911\udc15\uda56\ude64\ud91f\udd97\ud8c5\udcb5\uda14\udd8a\udb76\udec4\ud937\udc84",
        54, 13790, -1365530404, -7407504327596100167L, -36518L, true, false, (char) 55160, (char) 50723,
        Double.longBitsToDouble(0x3fd6a9a643f287baL), Double.longBitsToDouble(0x3fd3aed619b907f0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 9, 4, "\udaf8\udd6d\uda47\udf4d\uda10\udf32\uda58\udcc4\ud82d\ude9f", "\u6665\ua51c\ubd3b\uaffc\u6b6e\ua2bb\ub29a\u103c\u1121\u26cf\uae7e\uacea\uc491\u57dc\ubfd2\uab1b\u24d4\ucd6a\u9385\u09ce\u1025\u6791\u1d5b\u90e6\ua0b7\ua955\u1b5a\u213c\u8ecc\u84f1\u61cc\u9cf4\u8a4dj\u19ee", "\udb09\udc29\ud9b6\udec2\u00b4\000\ud809\udca4\ud99f\udd44\ud90a\ude9d\uda2e\udf00\udb90\udeee\udb67\udead\ud855\udca6\ud996\udce5\ud850\udcc9\ud945\udda4\ud96b\uddf9\udb5a\udf01\udb0f\ude88\u8221\uda34\udeb5\udb2e\udf62\udaab\udc06\uda86\udef9\udb68\udeb5\ud848\udc85\ud845\udc91\uda7f\uddcd\uda27\ude03\uda3a\udff2\ud99e\udfbf\uda7a\udfd8\ud836\udf3a\ud9a3\ude61\ud9cb\udc6e\ud8ef\udc79\u380c\ud9b5\udec9\udbfd\udc56\uda7d\udfb9\udbe9\udff9\udbda\uddf8\ud993\udfe0\udaa4\udc63\ud893\udc10\udba7\ude97\ue66b\udaaf\udd47\uda4a\udc1e\udb50\uddbe",
        9, 94583, -77530848, 6394797792576952448L, 66514L, false, false, (char) 48190, (char) 4296,
        Double.longBitsToDouble(0x3fea824a10000000L), Double.longBitsToDouble(0x3fdc30000319b0bcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 4, "\udaf8\udd6d\udb63\udf9c\udb5e\ude17\udae9\udc38\ud9f8\udc00", "\u6665\ua51c\ubd3b\uaffc\u6b6e\ua2bb\ub29a\u1fa4\u106c\u26cf\uae7e\u6551\uc491\u57dc\ubfd2\uab1b\u0c4b\u0232\u9385\u09ce\u1025\u6791\u1d5b\u3162\ua0b7\ua955\u8ad0\u213c\u7de9\u84f1\u61d9\u9cf4\u8a4d\u0d8b", "\ud802\udd74\udb09\udc29\ud9b6\udec2\u9101\ud84d\udf1b",
        22, 933, -1087261073, 6617869876123684048L, 26523L, false, true, (char) 54285, (char) 6884,
        Double.longBitsToDouble(0x3fef97b23a2bde8dL), Double.longBitsToDouble(0x3fd7f0e3d8ab13baL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.Lexer|readEscape||new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|getLineNumber||new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|isCommentStart|int|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|isDelimiter|int|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|isEndOfFile|int|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|isEscape|int|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|isQuoteChar|int|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|isStartOfLine|int|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|isWhitespace|int|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|mapNullToDisabled|java.lang.Character|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|nextToken|org.apache.commons.csv.Token|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|readEndOfLine|int|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|trimTrailingSpaces|java.lang.StringBuilder|new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
    "M|org.apache.commons.csv.Lexer|readEscape||new:org.apache.commons.csv.CSVLexer:org.apache.commons.csv.CSVFormat,org.apache.commons.csv.ExtendedBufferedReader",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
