package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 13, 2, "\ud94a\ude72\udae0\udec3\ud9be\udeb2\ud9c4\udf23\udbbe\udcf8\uda81\udc9f\ud9e3\udd46\u6877\udbd5\udffd\uda8d\udce2\udaf1\ude7a", "\u9876\u7b39\u80de\u9a52\u57f3\u7665\ua366\u667c\u1921\u48d9\u6bce\uc0ac\u8825\u1565\u8b6c\u424e\ub5ac\u1f5c\u1068\u8567\u08ce\u8305\u14c2\ub56d\u3ba3\ub9f6\u231f\u681c", "\ud888\udda8\ud99d\udc3f\udb87\udd51\uda4f\udfe5\ud810\ude0c\ud80a\udc44\udbd1\udeee\ud8a1\udc7f\ud9a3\udf5d\uda80\udc46\udb83\udc25\udb41\udc16\ud991\udc44",
        26, 82456, 16967966, -5705443514945288642L, -71613L, false, false, (char) 35462, (char) 19465,
        Double.longBitsToDouble(0x3fec36620718b55bL), Double.longBitsToDouble(0x3febc8e01b2653a4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 13, 2, "\ud94a\ude72\udae0\udec3\ud9be\udeb2\ud9c4\udf23\udbbe\udcf8\ud87c\udfc5\ud9e3\udd46\u6877\udbd5\udffd\uda8d\udce2\udaf1\ude7a", "\u9876\u7b39\u80de\u9a52\u78f4\uc88c\ua366\u667c\u1921\u48d9\u6bce\uc0ac\uc76d\u1565\u8b6c\u424e\ub5ac\u1f5c\u8c27\u8597\u08ce\u8305\u14c2\ub56d\u3ba3\ub9f6\u231f\u681c", "\ud888\udda8\udab3\udc6a\ud8df\uddd4\uda4f\udf1e\ud810\ude0c\ud973\udc98\udbd1\udeee\ud8a1\udc7f\ud9a3\udf5d\uda80\udc46\ud94e\ude23\udb73\ude16\ud991\udc44",
        26, 34336, 16967966, 1572373482885432894L, -71613L, false, false, (char) 35462, (char) 19465,
        Double.longBitsToDouble(0x3fec36620718b55bL), Double.longBitsToDouble(0x3febc8e01b2653a4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 6, 2, "\ud94a\ude72\udae0\udec3\udbae\uddfb\ud876\udd11\udbb1\udd98\uda81\udc9f\ud9e3\udd39\u6877\udbd5\udffd\ud983\udeda\udaf1\ude7a", "\u9876", "\ubbc8\ud8d3\udf5e\ud832\udf86\udbec\udf21\udb09\udebe\ud93d\ude10\ud994\uddfb\ud940\udc4c\uda12\udfc7\ud9cd\udc63\ud8c5\udc8b\ud9bf\udc5d",
        8, 39320, -892895632, 5921599101607128631L, -29996L, true, false, (char) 10958, (char) 3334,
        Double.longBitsToDouble(0x3fe81f031d5571ddL), Double.longBitsToDouble(0x3fecf9d7173efd09L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 1, 3, "\udabb\udea7\u6bb0\udbd1\ude9d\ud818\udf8d\udab9\ude66\ud8c5\udc60", "\uba73\u2038\u8462\u6cad", "\udb77\udc80\u42f1\udab0\udf07\ud836\uddad\ud832\udf2d\ud8f8\udc07",
        1, 29198, 1174816219, -1822856369574305533L, 99915L, false, true, (char) 57527, (char) 33398,
        Double.longBitsToDouble(0x3fe3868f7e8f8ecdL), Double.longBitsToDouble(0x3fe1ba90e43c4990L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 11, 3, "\udbf3\udf9f\udae0\udec3\ud9be\udeb2\ud9c4\udf23\udbbe\udcf8", "\u6d63\u44b6", "\ud9fe\udc57\ud9eb\udc2a\uda7f\udeaa\udb77\udc80\u42f1\udaa6\udc07\udb80\ude91\ud832\udf2d\ud8f8\udc07\ud9d4\uddef\ud93a\udc89\ud994\uddfb\ud940\udc4c",
        29, 71638, -106492693, -6202141202969455693L, -66832L, false, true, (char) 100, (char) 42444,
        Double.longBitsToDouble(0x3fe46710dea7b986L), Double.longBitsToDouble(0x3fbd480988d67190L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 13, 6, "\ud876\udef3\udac7\uddb7\ud9be\udeb2\ud9c4\udf23\udbbe\udcf8\uda81\udc9f\ud9e3\udd46\u6877\udbd5\udffd\uda8d\udce2\udaf1\ude7a\ud9fe\udc57\ud9eb\udc2a\uda7f\udeaa\udb77\udc80\u42f1\udab0\udf07\udb80\ude91\ud832\udf2d\ud8f8\udc07\udb2c\udea0\ud93d\ude10\ud994\uddfb\ud940\udc4c\uda12\udfc7\ud859\udc69\ud8c5\udc8b\ud9bf\udc5d\udb1f\ude71\ud808\udd8e\ud9f4\uddb9\udb21\udc1d\udb58\ude8c\u4279\udb2c\ude64\ue88c\uda6d\udd85\ud845\udf3d\udb3c\uddb8\ud946\udccd\ud920\udf72\uda1b\ude40\ud927\udf5d\ud888\udda8\ud99d\udc3f\udb87\udd51\uda4f\udfe5\ud810\ude0c\ud80a\udc44\udbd1\udeee\ud8a1\udc7f\ud9a3\udf5d", "\u7bb4\u55e3\u5a6f\u1820", "\ud91f\udf84\udabd\udc1a\uda6c\udcab",
        -4, 79693, -868180369, -5378512339433466088L, 15494L, true, false, (char) 39465, (char) 52592,
        Double.longBitsToDouble(0x3fca69c86e4219f8L), Double.longBitsToDouble(0x3fea5beb69d15e9bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 13, 2, "\ud94a\ude72\udae0\udec3\ud84a\udeb8\ud9c4\udf23\udbbe\udcf8\uda81\udc9f\ud9e3\udd46\u6877\udbd5\udffd\uda8d\udce2\udaf1\ude7a", "\ube08\u08c2\u9f37\u9a52\u57f3\u7665\ua366\u667c\u1921\u4924\uc68e\uaa09\u8825\u1565\u8b6c\u424e\ub5ac\u1f5c\u1068\u8567\u1f16\u99e3\u14c2\ub56d\u3ba3\ub9f6\u231f\u681c", "\ud888\udda8\ud99d\udc3f\udb87\udd51\uda4f\udfe5\ud810\ude0c\ud80a\udc44\udbd1\udeee\ud8a1\udc7f\ud9a3\udf5d\uda80\udc46\udb83\udc25\udb41\udc16\ud991\udc44",
        26, 82456, 16967966, -5705443514945288642L, -71613L, false, false, (char) 35462, (char) 19465,
        Double.longBitsToDouble(0x3fec36620718b55bL), Double.longBitsToDouble(0x3febc8e01b2653a4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 13, 2, "\ud94a\ude72\ud9d4\udebd\ud9be\udeb2\ud9c4\udf23\udbbe\udcf8\uda81\udc9f\ud9e3\udd46\u6877\udbd5\udffd\uda8d\udce2\udaf1\ude7a", "\u9876\u7b39\u80de\u9a52\u57f3\u7665\ua366\u667c\u1921\u48d9\u6bce\uc0ac\u8825\u1565\u8b6c\u424e\ub5ac\u1f5c\u1068\u8567\u08ce\u8305\u14c2\ub56d\u3ba3\ub9f6\u231f\u681c", "\ud888\udda8\ud99d\udc3f\udb87\udd51\uda4f\udfe5\ud810\ude0c\ud80a\udc44\udbd1\udeee\ud8a1\udc7f\ud9a3\udf5d\uda80\udc46\udb83\udc25\udb41\udc16\ud991\udc44",
        26, 82456, 16967966, -5705443514945288642L, -71613L, false, false, (char) 35462, (char) 19465,
        Double.longBitsToDouble(0x3fec36620718b55bL), Double.longBitsToDouble(0x3febc8e01b2653a4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVParser|getHeaderMap||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|addRecordValue||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|close||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getCurrentLineNumber||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getRecordNumber||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getRecords||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|initializeHeader||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|isClosed||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|iterator||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|nextRecord||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|parse|java.io.File,org.apache.commons.csv.CSVFormat|static",
    "M|org.apache.commons.csv.CSVParser|parse|java.lang.String,org.apache.commons.csv.CSVFormat|static",
    "M|org.apache.commons.csv.CSVParser|parse|java.net.URL,java.nio.charset.Charset,org.apache.commons.csv.CSVFormat|static",
    "C|org.apache.commons.csv.CSVParser|<init>|java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getHeaderMap||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
