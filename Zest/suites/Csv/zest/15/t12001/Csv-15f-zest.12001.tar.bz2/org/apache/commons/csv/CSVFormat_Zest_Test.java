package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 2, "\ud8de\udc51\ud97a\uddd3\ud88f\udda2\ud98d\ude0e\ud9b9\udc0c\udbbe\ude8e\udb09\ude78\udac5\udf37\udb95\ude51\uda46\udfa3\udbc3\udc80\ud9ff\udc4b\ud849\udea6", "\ucda2", "\ua459\udac1\udcfe\udb41\uddf5\ud9bc\uddf7\ud9c6\udc74\ud937\udfb9\ud8e7\udf39\uda2d\ude64\ud847\udd22\u8dee\ud8cd\udc03\uda5e\udcc7\uc8c7\udbd8\udf64\ud901\udd12\uda32\udd10\uda35\udd1a\udbcb\udfe2\ud8ee\udfba\ud95c\udcc4",
        6, 72717, 605460305, -5179712446705377418L, 31202L, false, false, (char) 22167, (char) 11997,
        Double.longBitsToDouble(0x3fc45cbbb1855e20L), Double.longBitsToDouble(0x3fe1705f8337385aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 2, "\ud924\udcfe\ud97a\uddd3\ud88f\udda2\udb13\ude14\ud9b9\udc5d\udbbe\ude8e\udb09\ude78\udac5\udf37\udb95\ude51\uda46\udfa3\udbc3\udc80\ud9f3\uddc3\u8732", "\ucda2", "\ua459",
        -1, 93024, 366387374, 3913524477919971074L, 74712L, false, true, (char) 4527, (char) 31419,
        Double.longBitsToDouble(0x3fdb51e94bb55c5cL), Double.longBitsToDouble(0x3feff98d30e1f5caL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 2, "\000\000\ud88f\udda2\ud98d\ude0e\ud9b9\udc0c\ud930\udc46\udb09\uddd3\uda9d\udc37\udb95\ude51\uda46\udfa3\udbc3\udc80\ud9ff\udc4b\ud849\udea6", "\000", "\ua459\udac1\udcfe\udb41\uddf5\uda5a\udcba\000\000\ud8e7\udf39\uda2d\ude64\ud847\udd22\u8dee\ud8cd\udc03\u0d9a\uc7ed\u33ff\ud861\udc2f\ud86f\ude0f\000\000\000\uda33\ude59",
        9, -1000, 0, 393535350L, 31202L, false, false, (char) 22167, (char) 39645,
        Double.longBitsToDouble(0x3e41840000000000L), Double.longBitsToDouble(0x3fa705f833738000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 8, 2, "\ud8de\udc51\ud97a\uddd3\ud88f\udda2\ud98d\ude0e\ud9b9\udc0c\udbbe\udf8e\udb09\ude78", "\u6a99\u40a7\u0136\u72b6\ub66f\u873a\u2f97\u492e\u74e9", "\udb41\uddf5\udbd3\ude62\ud9c8\udc5c\ud937\udfb9\ud8e7\udf39\uda2d\ude64\ud847\udd22\u8dee\ud8cd\udc03\uda5e\udcc7",
        11, 98207, 1193570529, 3737791987055710779L, -52548L, true, true, (char) 6212, (char) 6927,
        Double.longBitsToDouble(0x3febb5c0ec7f1774L), Double.longBitsToDouble(0x3fc04f1d3bd1a268L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 2, "", "\u8f68", "\uda50\ude48\ud9e5\udfa6\000\000\uda46\udfa3",
        11, 84280, 0, 1739578934472736768L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e15c3d380000000L), Double.longBitsToDouble(0x3fdc715d632ce29eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 8, 2, "\udb1f\udc63", "\u0cac\u6949\u7eba", "\000",
        52, 38031, 277822474, 6123604744287304180L, -100000L, false, true, (char) 13, (char) 0,
        Double.longBitsToDouble(0x3e316c0800000000L), Double.longBitsToDouble(0x3fee30f4e792f89aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 2, "\ud8de\udc51\ud970\uddae\ud88f\udda2\ud98d\ude0e\ud9b9\udc0c\udbbe\ude8e\udb09\ude78\udac5\udf37\udb95\ude51\uda46\udfa3\udb67\udf47\ud9ff\udc4b\ud849\udea6", "\ucda2", "\ua459\udac1\udcfe\udb41\uddf5\ud9bc\uddf7\ud9c6\udc74\ud937\udfb9\ud8e7\udf39\uda2d\ude64\ud847\udd22\u8dee\ud8cd\udc03\uda5e\udcc7\uc8c7\ud84f\udcf3\ud90c\udd5b\uda32\udd10\uda35\udd1a\udbcb\udfe2\ud8ee\udfba\ud95c\udcc4",
        6, 18935, 605453165, -5179712446705377418L, 21703L, true, false, (char) 22167, (char) 11997,
        Double.longBitsToDouble(0x3fc45cbbb1855e20L), Double.longBitsToDouble(0x3fe1705f8337385aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 2, "\000\000\ud88f\udda2\ud98d\ude0e\ud9b9\udc0c\ud930\udc46\udb09\uddd3\ud801\udeca\ud850\udf9c\uda46\udfa3\udbc3\udc80\ud9ff\udc4b\ud849\udea6", "\000", "\ua459\udac1\udcfe\udb41\uddf5\uda5a\udcba\000\000\ud8e7\udf39\uda2d\ude64\ud847\udd22\u8dee\ud8cd\udc03\u0d9a\ud8bf\udf34\ud800\udd38\ud861\udc2f\ud842\udc59\ua576\udad9\udd0b,\uda33\ude59",
        9, -1000, 1309081600, 393535350L, 31202L, false, false, (char) 22167, (char) 32733,
        Double.longBitsToDouble(0x3e41840000000000L), Double.longBitsToDouble(0x3fa705f833738000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 8, 2, "\udb1f\udc63", "\u0cac\u6949\u7eba", "\uda50\ude87",
        -5, 55857, 277822474, 6123604744287304180L, -100000L, false, true, (char) 10, (char) 0,
        Double.longBitsToDouble(0x3e316c0800000000L), Double.longBitsToDouble(0x3fee30f4e792f89aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 2, "\ud890\udc20,\ud885\udefd\ud979\ude3d\ud9b9\udc0c\ud930\udc46\udb09\uddd3\ud976\udd85\ud850\udf9c\udb9d\uddcf\udbc3\udc80\ud9ff\udc4b\uda5b\udfc5", "\ub16e", "\ua491\udac1\udcfe\udb41\uddf5\uda5a\udcb2\000\000\ud8e7\udf39\ud944\udc9f\ud80d\udd2d\udb18\udf6c\ud858\ude82\uda29\udc4c\ud824\ude61\uda32\udd5f\ud82d\ude10\udac1\udd9c\ud9d9\udeb0\udafc\ude23,\uda33\ude59",
        9, -1000, 1309081600, 393535350L, 30823L, true, true, (char) 22073, (char) 15622,
        Double.longBitsToDouble(0x3fd2800d5e4cef12L), Double.longBitsToDouble(0x3fb57e2319bbca40L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVFormat|printAndQuote|java.lang.Object,java.lang.CharSequence,int,int,java.lang.Appendable,boolean|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|equals|java.lang.Object|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|format|[Ljava.lang.Object;|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getAllowMissingColumnNames||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getAutoFlush||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getCommentMarker||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getDelimiter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getEscapeCharacter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getHeader||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getHeaderComments||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreEmptyLines||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreHeaderCase||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreSurroundingSpaces||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getNullString||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuoteCharacter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuoteMode||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|printAndQuote|java.lang.Object,java.lang.CharSequence,int,int,java.lang.Appendable,boolean|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
