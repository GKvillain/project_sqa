package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVPrinter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 3, 2, "\ud97a\uded7", "\u76f9\ud367\u9319", "\uda43\udc7a\ud974\udc8e\udb19\udcc9\ud8ce\uddd7\ud8bd\udfaf\ud895\udc8c\ud968\ude96\uda88\udecf\ud89e\udd44\udbdd\udd2f\ud8ff\udd12\udb2c\udd85\udb7c\udcdb\udac1\udf16\udbef\udc42",
        27, 35111, -751591160, 2599500310291682191L, 71522L, true, false, (char) 60645, (char) 51958,
        Double.longBitsToDouble(0x3fd9079fb2771bfaL), Double.longBitsToDouble(0x3feaf633a3cff4a7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 2, "\u75bb", "\u76f9\uc8e4\ud40d", "\ud85b\udc97",
        42, 38020, 1231328632, 5183365483244986422L, -89977L, false, true, (char) 19571, (char) 32347,
        Double.longBitsToDouble(0x3fd5d78f5ad46d0eL), Double.longBitsToDouble(0x3fd1aec718cf628eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 3, 2, "\ud97a\uded7", "\u76f9\ud367\u9319", "\uda43\udc7a\ud974\udc8e\udb19\udcc9\ud8ce\uddd7\ud8bd\udfaf\ud8a5\udd8c\ud968\ude96\uda88\udecf\ud89e\udd44\udbdd\udd2f\ud8ff\udd12\udb2c\udd85\udb7c\udcdb\udac1\udf81\udbef\udc42",
        27, 90940, -751624451, 2599500310291682191L, 71522L, true, false, (char) 60645, (char) 51958,
        Double.longBitsToDouble(0x3fd9079fb2771bfaL), Double.longBitsToDouble(0x3feaf633a3cff4a7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 3, 2, "\ud97a\uded7\udb12\udfa1\ud8d2\ude0e\udbd0\udf7c\uda45\udc96\ud8d2\ude97\udb0c\udd5c\ud932\udc4e\uda43\udc7a\ud974\udc8e\udb19\udcc9\ud8ce\uddd7\ud8bd\udfaf\ud895\udc8c\ud968\ude96\uda88\udecf", "\u41b1\u019a\ud117\u172c\uae3c\u2fcd\uac72\u83ef\u9a83\u2419\u9148", "\uda37\udeea\udb6c\udef0\udb33\udfa6\ud908\udda0\udbd3\uded7\udb4f\uddd6\udb5d\udeb2\uda01\udf8f\ud80d\udd18",
        54, 20817, -1666875039, -3129890688368485485L, -21231L, true, false, (char) 3407, (char) 60533,
        Double.longBitsToDouble(0x3fe03a612bc53fcaL), Double.longBitsToDouble(0x3febec8cda4ba65bL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 5, 2, "\ud97a\uded7", "\u76f9\ud367\u9319", "\uda43\udc7a",
        24, 38020, 1231328644, 5183365482932248630L, -64622L, true, true, (char) 62890, (char) 45831,
        Double.longBitsToDouble(0x3feb0de891bb9ca0L), Double.longBitsToDouble(0x3fd5d78f5ad52b0eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 3, 2, "\ud97a\uded7", "\u76f9\ud367\u9319", "\uda1d\udd6d\ud974\udc8e\udb19\udcc9\ud8ce\uddd7\ud8bd\udfaf\ud895\udc8c\ud968\ude96\uda88\udecf\ud89e\udd44\udbdd\udd2f\ud8dd\udc12\udb2c\udd85\udb7c\udcdb\udac1\udf16\udbef\udc42",
        27, 35111, -751591160, 2599500310291682191L, -100000L, true, false, (char) 47916, (char) 24031,
        Double.longBitsToDouble(0x3fb4b224d381c438L), Double.longBitsToDouble(0x3f3e7ec9dc680000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVPrinter|println||new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|close||new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|flush||new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|getOut||new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|print|java.lang.Object,java.lang.CharSequence,int,int|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|print|java.lang.Object|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|printAndEscape|java.lang.CharSequence,int,int|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|printAndQuote|java.lang.Object,java.lang.CharSequence,int,int|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|printComment|java.lang.String|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|printRecord|java.lang.Iterable|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|printRecord|[Ljava.lang.Object;|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|printRecords|java.lang.Iterable|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|printRecords|[Ljava.lang.Object;|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|printRecords|java.sql.ResultSet|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "C|org.apache.commons.csv.CSVPrinter|<init>|java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|println||new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
