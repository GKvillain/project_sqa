package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVRecord_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]] |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 1, 14, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u9d35\u1555\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\ud99b\udfe7\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        41, 44606, 1937466488, 7430824023382776562L, -20961L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]] |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 1, 14, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u9d35\u1555\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\u7785\udade\udcfb\udb48\udf3f\ud99b\udfe7\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        41, 44606, 1937466488, -351396132713440526L, -20961L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]] |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 1, 14, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u9d35\u1555\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\ud8a8\udfb9\udb48\udf38\ud99b\udfe7\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        41, 44606, 1937466488, 6494075301191703282L, 69610L, false, false, (char) 19110, (char) 41625,
        Double.longBitsToDouble(0x3fc7ed319c6765a4L), Double.longBitsToDouble(0x3fe4ac2507326a69L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud933\ude80\udaef\udc6b\ud96a\udcdf", "\ubfe7\uba78\u757d\u09ad\u9507\u1558\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\ud99b\udfe7\ud9ec\uddca\ud891\udd10\ud98c\udedf\u5dfe\udb10\udd0f\ud8f6\udc16\udad6\udccb\u51cd\udb2d\uddde\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        41, 44606, 1937466488, 7430824023382776562L, -20961L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe712ec81bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 1, 6, 10, 6, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u9cb3\u1555\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\ud99b\udfe7\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\ud856\udda0\ud837\udf6f\udb7c\udfc5\ud971\udd9a\udb26\udcc8\udb26\udcff\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        13, 323, 1937466488, -414603190447689856L, -20961L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 1, 12, 4, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u9d35\u1555\u683f\ub96f\u436c", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\ud99b\udfe7\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\udaf9\udcd5\ud908\udd79\ud8f4\ude27\udaa9\udf6c\udbcd\udf28\uda01\udef6",
        10, 44606, 1937466488, 7430824023382776562L, -20961L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud840\udc13\ud96a\udcdf]] |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud840\udc13\ud96a\udcdf]\012",
        Z.run(T, 1, 14, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud840\udc13\ud96a\udcdf", "\ubf15\uba78\u42dc\ub186\u9d35\u1555\u683f\u74fe\u0bd1\u7ba9\u9b82\u2145\u8daf\u29e6\u7a8f\ucaea\u0577\u378d\u2883\u6fda\u7de8\ud779\u4d58\u4fc8\u43ac\u3e75", "\udb50\ude74\ud9a1\udd7c\uda89\ude46\udaf5\udf27\udac6\udda7\udace\udefb\uda16\uddf6\udb0f\udd79\udbab\ude9b\udacb\udd1b\ud8cc\ude2f",
        5, 10279, 1770830257, -2780633299232469223L, 6290L, false, false, (char) 64361, (char) 15336,
        Double.longBitsToDouble(0x3feeb1d456c667afL), Double.longBitsToDouble(0x3fd5a8793d5c538cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u9d35\u1555\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\udb0f\udde0\udb48\udf38\ud99b\udfe7\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\ud8ad\ude7b\ud880\udf15\ud943\udfd3\ud888\udf3a\ud89a\uddb6\udaf5\udf27",
        41, 44606, 1937466488, 7430824023382776562L, -20961L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 1, 8, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u9d35\u1555", "\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc",
        33, 62546, -1110733413, 8861695560047954920L, -46641L, false, true, (char) 64790, (char) 53736,
        Double.longBitsToDouble(0x3fef43ec76bbee76L), Double.longBitsToDouble(0x3fca3e6f204d9ea0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud975\ude45\ud823\udddf\udbc9\ude6a\ud9f3\uddfc\uda53\udf65\udb87\udd83\uda43\udd59\udb3a\udf08\udaf8\udced\ud97f\udd7e\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\u7b29\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\udad6\udccb\ud880\udf15\udb26\udd25]\012",
        Z.run(T, 1, 7, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud975\ude45\ud823\udddf\udbc9\ude6a\ud9f3\uddfc\uda53\udf65\udb87\udd83\uda43\udd59\udb3a\udf08\udaf8\udced\ud97f\udd7e\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\u7b29\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\udad6\udccb\ud880\udf15\udb26\udd25", "\ubb95\u0d62\u9165\u9d56\ua94e", "\ud8cc\ude2f\ud8c0\udf83\udb49\udd86\ud961\udfe9\udb40\ude78\ud8d8\uddba\udb5f\udfa2\udad7\udee9\udbcd\udc26\udb47\udc5d\ud88e\udea4\ud815\udf18\ud9ec\udc92\udba4\ude09\ud94b\udeae\ud880\udd23\ud87b\udfc7\udad6\ude91\ud8dd\udc75\uda2e\udc17\ud884\udc12\ud940\udcda\ud8db\udfff\udb49\udc0f\ud9e0\udd8a\ud855\udd29\ud8c3\udfbb\udb60\udd5a\ud96c\udc33\udab8\udc89\udbed\udc10\uda05\udca0",
        9, 67790, -112488418, -3282253989764473005L, 83203L, false, false, (char) 50472, (char) 15608,
        Double.longBitsToDouble(0x3fd520f305e43126L), Double.longBitsToDouble(0x3fe6dd79e2dfa70cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\ud823\udc37\ud884\udc25\ud894\udd8a\ud896\uddb4\ud946\udc68\ud87b\udd93\uda88\udda6\udb5f\uddf4\uda68\udf68\ud9f9\udca7\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud921\udd31\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udaf5\udf27 |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 10, "\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47", "\ua278\uba78\ubb59\u0b99\u1b47\u0cf6\u683f\ub96f\u0bd1", "\ud823\udc37\ud884\udc25\ud894\udd8a\ud896\uddb4\ud946\udc68\ud87b\udd93\uda88\udda6\udb5f\uddf4\uda68\udf68\ud9f9\udca7\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud921\udd31\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        41, 44606, 1937466488, -1792548012890735916L, 83182L, true, false, (char) 52465, (char) 58905,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fd31a4b7fac7514L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 1, 0, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u3a2f\ub186\u9d35\u1555\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\ud99b\udfe7\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        41, 44606, 1937466488, 7430824023382776562L, -20961L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 6, 10, "\udb5e\udc59\ud8bd\udf56\ud884\udcdf\udaef\udc6b\udb1d\udf62", "\ud195\ua792\ub06c\u5611\u0c5d\u6557\u682b\uba42\u2bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\uda89\udcfc\ud9ec\uddca\ud8ca\ude10\ud97e\udf33\u5dfe\udb5d\udeec\udb7e\udf42\udb02\udd37\ud880\udf15\udb26\udd25\ud9bd\ude15\udbad\ude42\ud94f\ude82",
        51, 44598, 1937466488, 7430824023382776562L, 78177L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a928d1aaL), Double.longBitsToDouble(0x3fe98d25bfd63ab3L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udacc\udc82\udae8\udfc6\ud8c0\udfcd\udaef\udc6b\ud96a\udcdf]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udacc\udc82\udae8\udfc6\ud8c0\udfcd\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 2, 12, 6, 10, "\udacc\udc82\udae8\udfc6\ud8c0\udfcd\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u9d35\u184b\u689f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\udbd5\udff6\ud92f\uddcb\ud956\ude40\ud87b\udcbd\udbc4\udebb\udb48\udf38\ud9ec\udcde\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\ud896\udd61\ud880\udfd3\udb26\udd25\udaa9\udf6c\uda89\ude46\ud87a\udfcc",
        41, 44606, 1937466488, 7430824023382776562L, 22559L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fe98ca5bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 1, 9, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ucdab\u998b\u9998\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\udbd9\udd43\udbc4\udebb\udb48\udf38\ud99b\udfe7\ud9ec\uddca\ud8ca\ude10\ud98c\udedf\ud993\udf77\udb5d\udf0e\ud8d3\udd2a\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        14, 87131, -1091475855, -5355111845203322126L, 83105L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc7c\ud96a\udcdf] |a0=[Ljava.lang.String;:[[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc7c\ud96a\udcdf]]\012",
        Z.run(T, 1, 15, 6, 14, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc7c\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u0135\u1555\u683f\u4e76\u0c03", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud87b\udd93\uda3c\udeb7\udb48\udf38\uda12\udee2\ud8ef\udca9\ud9a5\udd19\ud98c\udee6\u5dfe\udb5d\udeec\ud8d3\udd2a\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udbf7\udd48",
        44, 44606, -1434753928, 7493265138400320242L, -20961L, true, true, (char) 13484, (char) 24387,
        Double.longBitsToDouble(0x3fe1bf59a9bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbb6\udf85\ud908\ude1b\ud866\udedf\udaef\udc6b\ud96a\udcdf\udbbc\uddd5\udbb1\udc39\ud9f3\uddfc\uda53\udf65\udb87\udd83\uda43\udd59\ud882\udc0b\ud875\udf79\uda96\udf93\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc\ud942\udd4e]] |this=org.apache.commons.csv.CSVRecord:[\udbb6\udf85\ud908\ude1b\ud866\udedf\udaef\udc6b\ud96a\udcdf\udbbc\uddd5\udbb1\udc39\ud9f3\uddfc\uda53\udf65\udb87\udd83\uda43\udd59\ud882\udc0b\ud875\udf79\uda96\udf93\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc\ud942\udd4e]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbb6\udf85\ud908\ude1b\ud866\udedf\udaef\udc6b\ud96a\udcdf\udbbc\uddd5\udbb1\udc39\ud9f3\uddfc\uda53\udf65\udb87\udd83\uda43\udd59\ud882\udc0b\ud875\udf79\uda96\udf93\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc\ud942\udd4e]\012",
        Z.run(T, 2, 14, 6, 0, "\udbb6\udf85\ud908\ude1b\ud866\udedf\udaef\udc6b\ud96a\udcdf\udbbc\uddd5\udbb1\udc39\ud9f3\uddfc\uda53\udf65\udb87\udd83\uda43\udd59\ud882\udc0b\ud875\udf79\uda96\udf93\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc\ud942\udd4e", "\ucaea\u0577\u378d\u2883\u55da\u307a\u1030\ucf1e\u4fe2\u43ac\u3e75\ua31b\u1650\u7248\u1779\u7d37\ubb95\uc76d\ua20d\u7e0e\u3d68\ua6a9\uba16", "\uda5f\udcd2\ud961\udfe9\udb40\ude78\ud8d8\uddba\udb5f\udfa2\udad7\udee9\udbcd\udc26\udb47\udc5d\ud844\udc13",
        55, 76846, 385618583, -4458257770670075929L, 49731L, false, false, (char) 15602, (char) 25014,
        Double.longBitsToDouble(0x3febe78223692464L), Double.longBitsToDouble(0x3fe69f86d8c456ebL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.csv.CSVRecord:[]\012",
        Z.run(T, 1, 0, 6, 10, "", "", "\000\000\udbb6\udf64\ud9f3\uddfc",
        51, -773, 0, 1376452608L, 38419L, true, true, (char) 10544, (char) 64637,
        Double.longBitsToDouble(0x3fec13829800e3a4L), Double.longBitsToDouble(0x3d8ebec000000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud99e\udd5c\ud884\udcdf\udaef\udc6b\ud96a\udcdf\udbbc\uddd5\udbb7\udc3c\ud9f3\uddfc\uda53\udf65\udb25\udd82\uda43\udd59\udb3a\udf08\udaf8\udced\ud97f\udd7e\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc]\012",
        Z.run(T, 1, 0, 6, 10, "\udbcb\udf23\ud99e\udd5c\ud884\udcdf\udaef\udc6b\ud96a\udcdf\udbbc\uddd5\udbb7\udc3c\ud9f3\uddfc\uda53\udf65\udb25\udd82\uda43\udd59\udb3a\udf08\udaf8\udced\ud97f\udd7e\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc", "\u7f23", "\udbc4\udebb\udb48\udf38\ud99b\udfe7\udba6\udc3f\ud8ca\ude10\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\uda5e\udc7f\ud931\udd45\udb26\udd99\udaa9\udf6c",
        10, 61933, 78356441, 2969500043469087864L, 31810L, false, false, (char) 33981, (char) 43533,
        Double.longBitsToDouble(0x3fe17f63b5b1e8e8L), Double.longBitsToDouble(0x3fc7e0d9fc6765a4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\udb25\udf9e] |a0=[Ljava.lang.String;:[[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\udb25\udf9e]]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\udb25\udf9e]\012",
        Z.run(T, 2, 15, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\udb25\udf9e", "\ubf82\uba78\u42dc\ub186\u9d35\u1555\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\ud9e6\udd09\udbc4\udea8\udb48\udf38\udac3\udcda\ud9ec\uddca\ud8ca\ude10\udb79\ude95\u5e2b\ud87b\udcb4\ud8d3\udd56\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        41, 81440, -277126024, 2728832052654463730L, -20961L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fe717d9a8c46982L), Double.longBitsToDouble(0x3fe98843c7d63a8aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\udbca\udfbd\ud884\udcdf\udb0a\ude19\udafa\udcf1]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\udbca\udfbd\ud884\udcdf\udb0a\ude19\udafa\udcf1]\012",
        Z.run(T, 2, 6, 6, 10, "\udbcb\udf23\udbca\udfbd\ud884\udcdf\udb0a\ude19\udafa\udcf1", "\ubf82\uba78\u42dc\ub186\u9d35\u631e\u6871", "\ud995\ude1a\udaa3\udf7a",
        49, 30871, -475747454, -4770563681346186967L, 35686L, true, false, (char) 61450, (char) 64790,
        Double.longBitsToDouble(0x3fe55739f3e87d8eL), Double.longBitsToDouble(0x3fe5df73b0d1f379L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\uda8b\udf5d\ud938\udf80\udaef\udc6b\ud96a\udcdf]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\uda8b\udf5d\ud938\udf80\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 2, 7, 8, 10, "\udbcb\udf23\uda8b\udf5d\ud938\udf80\udaef\udc6b\ud96a\udcdf", "\u9bc1\u1cd6\u757d\u09ad\u9507\u1558\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud81c\uddb7\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\ud99b\udfe7\ud9ec\uddca\ud891\udd10\ud98c\udedf\u5dfe\udb10\udd0f\ud8f6\udc16\udad6\udccb\u51cd\udb2d\uddde\ud965\udf6a\uda89\ude46\udaf5\udf27",
        41, 44606, 1937466488, 7430824023382776562L, -20961L, true, true, (char) 31071, (char) 7630,
        Double.longBitsToDouble(0x3fe712ec81bfd1aaL), Double.longBitsToDouble(0x3fe98d25bfd63a8aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\udbab\udf0d\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\uda32\uddee\udbc4\udebb\ud861\udcd4\ud99b\udfb8\ud9ec\uddca\ud898\udc19\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\udaf9\udcd5\ud908\udd79\ud8f4\ude27\uda93\udca3\ud98c\ude08\ud9ff\udf68 |this=org.apache.commons.csv.CSVRecord:[\uda81\udf1e\udba7\udf4a\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 3, 11, "\uda81\udf1e\udba7\udf4a\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u1538\u1555\u683f\ub96f\u436c", "\udbab\udf0d\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\uda32\uddee\udbc4\udebb\ud861\udcd4\ud99b\udfb8\ud9ec\uddca\ud898\udc19\ud98c\udedf\u5dfe\udb5d\udeec\ud8d3\udd2a\udaf9\udcd5\ud908\udd79\ud8f4\ude27\uda93\udca3\ud98c\ude08\ud9ff\udf68",
        10, 44606, 1937466488, 7430824023382776562L, -20961L, true, true, (char) 12308, (char) 58924,
        Double.longBitsToDouble(0x3fde2fb35ed8333cL), Double.longBitsToDouble(0x3fea981d5759185fL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udccb\ud96a\udcdf] |a0=[Ljava.lang.String;:[[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udccb\ud96a\udcdf]]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udccb\ud96a\udcdf]\012",
        Z.run(T, 2, 15, 8, 8, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udccb\ud96a\udcdf", "\ubf82\u3d6e\u421b\u8edb\ubb34\u8fc5\u8216\u6274\u4a85", "\uda53\ude22\udad8\udf05",
        2, 55532, 2063274281, 2040284461647777588L, 85716L, false, true, (char) 65381, (char) 33973,
        Double.longBitsToDouble(0x3fe9e0d3b1ccc049L), Double.longBitsToDouble(0x3f9367df3173ec40L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.Arrays$ArrayList:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud9ba\uddf1\ud80d\udf5b] |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud9ba\uddf1\ud80d\udf5b]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 1, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud9ba\uddf1\ud80d\udf5b", "\u6523\u8b9b\u42dc\ub186\u9d35\u1555", "\ud96a\udd28",
        46, 40425, -202481894, 8123736777969412994L, -38915L, false, true, (char) 59523, (char) 16193,
        Double.longBitsToDouble(0x3fd742f5068143acL), Double.longBitsToDouble(0x3fd6736dd7d0fb42L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud89e\udee6\ud884\udd61\udaef\udc6b\ud96a\udcdf]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud89e\udee6\ud884\udd61\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 2, 8, 7, 12, "\udbcb\udf23\ud89e\udee6\ud884\udd61\udaef\udc6b\ud96a\udcdf", "\u303b\u209e\u42dc\ub186\u8a8f\u15b5", "\ud895\udf25\udb91\ude18\ud849\udd4e\uda14\ude26\ud9ad\udf84\ud894\uddd6\ud896\uddb4\uda69\udf3a\uda91\udf9c\udbcd\udcc1\uda81\ude42\ud9e7\ude2c",
        16, 61186, -294226968, -902612479599144751L, 32510L, false, false, (char) 49891, (char) 62653,
        Double.longBitsToDouble(0x3febed7af06e7065L), Double.longBitsToDouble(0x3fc11944fa3b87f4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud6ce\udb1f\udea3\uda13\udd09\udbb7\udc3c\ud9f3\uddfc\uda53\udf65\udb87\udd83\uda43\udd59\udbf3\udfaa\udaf8\udced\ud97f\udd7e\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc\udb5f\ude33\ud894\uddd6\ud896\uddb4\u220b] |a0=[Ljava.lang.String;:[[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud6ce\udb1f\udea3\uda13\udd09\udbb7\udc3c\ud9f3\uddfc\uda53\udf65\udb87\udd83\uda43\udd59\udbf3\udfaa\udaf8\udced\ud97f\udd7e\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc\udb5f\ude33\ud894\uddd6\ud896\uddb4\u220b]]\012",
        Z.run(T, 1, 15, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud6ce\udb1f\udea3\uda13\udd09\udbb7\udc3c\ud9f3\uddfc\uda53\udf65\udb87\udd83\uda43\udd59\udbf3\udfaa\udaf8\udced\ud97f\udd7e\udbc0\udd43\ud895\udf08\ud995\ude1a\ud9b4\udcc4\udbab\udedc\udb5f\ude33\ud894\uddd6\ud896\uddb4\u220b", "\u2883\u55da\u7de8\ud779", "\udb5d\udeec\uda65\udc14\ud8d8\udc0f\ud99b\udd37\uda3d\udd0e\ud858\udda5\ud883\udddf\udbeb\ude2e\udb52\udcbd\ud8a8\udf04",
        8, 43490, 1831024314, 7520112087589062003L, 6184L, true, true, (char) 47852, (char) 63302,
        Double.longBitsToDouble(0x3fdc2055abe2b846L), Double.longBitsToDouble(0x3fda5e64bc00dd2eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47]] |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47]\0121=new org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47] |a0=[Ljava.lang.String;:[[\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47]]\012",
        Z.run(T, 2, 14, 15, 10, "\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47", "\u2a79\uba70\ubb59\u0b99\u108e\u0cb9\u683f\ub96f\u56d0", "\ud80b\udf37\ud884\udc25\ud894\udd8a\ud896\uddb4\ud946\udc68\ud87b\udd93\uda88\udda6",
        47, 59488, -415330787, 9047426717005018088L, -81943L, false, false, (char) 2036, (char) 20581,
        Double.longBitsToDouble(0x3fd26d56c14bef66L), Double.longBitsToDouble(0x3feecb73d0b804abL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47]\0121=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47]\012",
        Z.run(T, 2, 0, 0, 10, "\udbcb\udf23\ud9b4\udeb1\uda25\udee8\udbec\ude3c\ud96a\udc47", "\ua278\uba78\ubb59\u0b99\u1b47\u0cf6\u683f\ub96f\u0bd1", "\ud823\udc37\ud884\udc25\ud894\udd8a\u8d9b\000\000\000\udb5f\uddf4\uda68\udec8\ud9f9\udca7\ud890\udc10\ud98c\udedf\u5dfe\udb5d\udeec\ud921\udd31\udad6\udccb\ud880\udf15\udb26\udd25\udaa9\udf6c\uda89\ude46\udaf5\udf27",
        41, 44606, 1937466488, -1792548012890735916L, 83182L, true, false, (char) 52465, (char) 58905,
        Double.longBitsToDouble(0x3fe717d9a9bfd1aaL), Double.longBitsToDouble(0x3fd31a4b7fac7514L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbb2\uddca\uda8b\udf5d\ud938\udf80\udaef\udc6b\ud96a\udcdf]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udbb2\uddca\uda8b\udf5d\ud938\udf80\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 2, 8, 8, 10, "\udbb2\uddca\uda8b\udf5d\ud938\udf80\udaef\udc6b\ud96a\udcdf", "\u9bc1\u1cd6\u282b\u1aa9\u9507\u1558\u683f\ub96f\u0bd1", "\udae8\udfeb\uda41\udf2d\uda29\ude01\u1378\ud946\udc68\ud87b\udd93\udb5f\ude6a\udb48\udf85\ud99b\udfe7\u09f9\ud891\udc97\udb9f\udcba\ud95e\udf00\ud866\udf0a\ud9e0\ude8c\uda24\udd88\u51cd\udb2d\uddde\ud965\udf6a\uda89\ude46\udaf5\udf27",
        41, 44606, 1937466488, 7430824023382776562L, 19076L, true, true, (char) 31071, (char) 30670,
        Double.longBitsToDouble(0x3fd93291f2fc83f0L), Double.longBitsToDouble(0x3fe97525b82fa7feL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.csv.CSVRecord:[]\0121=null |this=org.apache.commons.csv.CSVRecord:[]\012",
        Z.run(T, 2, 0, 0, 11, "", "\u8640\u6059", "\udbb7\udc3c\ud9f3\uddfc\uda23\udf65\udb87\udd83",
        41, 45018, 0, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fec1000059be3a4L), Double.longBitsToDouble(0x3fd29bdcb7d0f5f6L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\ud853\udde7\udb82\udcdd\ud890\udc43\ud9ba\uddf1\ud80d\udf5b] |a0=[Ljava.lang.String;:[[\ud853\udde7\udb82\udcdd\ud890\udc43\ud9ba\uddf1\ud80d\udf5b]]\0121=new org.apache.commons.csv.CSVRecord:[\ud853\udde7\udb82\udcdd\ud890\udc43\ud9ba\uddf1\ud80d\udf5b] |a0=[Ljava.lang.String;:[[\ud853\udde7\udb82\udcdd\ud890\udc43\ud9ba\uddf1\ud80d\udf5b]]\012",
        Z.run(T, 2, 15, 15, 10, "\ud853\udde7\udb82\udcdd\ud890\udc43\ud9ba\uddf1\ud80d\udf5b", "\u6523\u8b9b\u42dc\ub186\u9d35\u1555", "\ud96a\udd28\ud98f\ude86\ud9b4\udcc4\udbab\ude63\udb5f\ude33\ud894\uddd6\udb43\udc4e\ud946\udca2\ud87b\udd93\udba7\udfbb\udb48\udf38\ud84b\udf50\udacf\ude7b\ud926\udcce\ud8b5\uddb4\ud8e2\udca1",
        1, 23795, -1600829789, -5885751442746612622L, 45260L, false, false, (char) 9169, (char) 38081,
        Double.longBitsToDouble(0x3fe92ba437fc96c8L), Double.longBitsToDouble(0x3fb14124a8204ef8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 1, 9, 6, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\u5c29\u42dc\u5f46\u9d35\u1555\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud836\uddc7\ud896\uddb4\ud946\udc68\ud87b\udd93\udbc4\udebb\udb48\udf38\udba5\udf8c\udb0e\udf5c\ud894\ude84\ud98c\udedf",
        -1, 81369, 1449297939, -7017656566592227268L, -16197L, true, true, (char) 52536, (char) 36269,
        Double.longBitsToDouble(0x3fc36ac6cd269dd0L), Double.longBitsToDouble(0x3fe497afdecd6ef0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.util.HashMap:{=\udb3b\udddd} |this=org.apache.commons.csv.CSVRecord:[, \udb3b\udddd]\012",
        Z.run(T, 1, 0, 6, 10, ",\udb3b\udddd", "\000\000", "\uda53\udf65\u00e3",
        -5, -1000, 1376452608, -5204790511559705449L, 38419L, true, true, (char) 10544, (char) 64637,
        Double.longBitsToDouble(0x3fec13829800e3a4L), Double.longBitsToDouble(0x3d8ebec000000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\0121=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf]\012",
        Z.run(T, 2, 12, 12, 6, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\udaef\udc6b\ud96a\udcdf", "\ubf82\uba78\u42dc\ub186\u9cb3\u1555\u683f\ub96f\u0bd1", "\udbab\udedc\uda41\udf2d\ud894\uddd6\ud896\uddb4\ud946\udc68\udbde\udc84\ud84d\uddf2\udaa7\udeb1\ud99c\udc4b\ud984\udf16\ud8ca\udd9a\ud98c\udedf\ud856\udda0\ud99a\udc71\udb7c\udfc5\ud971\udd9a\udb26\udcc8\udb26\udcff\ud851\udcdf\uda89\uddcd\udaf5\udf27",
        13, 323, 1937466488, -414603190445068416L, -81089L, false, false, (char) 19110, (char) 61849,
        Double.longBitsToDouble(0x3fc7f1759c6765a4L), Double.longBitsToDouble(0x3feba165073246fbL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.util.HashMap:{=\udb3b\udddd} |this=org.apache.commons.csv.CSVRecord:[, \udb3b\udddd]\0121=new org.apache.commons.csv.CSVRecord:[, \udb3b\udddd] |a0=[Ljava.lang.String;:[[, \udb3b\udddd]]\012",
        Z.run(T, 2, 0, 15, 10, ",\udb3b\udddd", "\000\000", "\uda53\udf65\u00e3",
        -5, -1000, 1376452608, -3098952700412756932L, 38419L, true, true, (char) 10544, (char) 64637,
        Double.longBitsToDouble(0x3fec13829800e3a4L), Double.longBitsToDouble(0x3d8ebec000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud9ba\uddf1\ud80d\udf5b]\0121=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud9ba\uddf1\ud80d\udf5b]\012",
        Z.run(T, 2, 9, 9, 10, "\udbcb\udf23\ud8bd\udf56\ud884\udcdf\ud9ba\uddf1\ud80d\udf5b", "\u9c26\u5d4a\u1390\ub186\u9d35\u8255", "\ud96a\udd28",
        46, 40425, 401018629, -136323434976873219L, -38915L, false, true, (char) 59523, (char) 30923,
        Double.longBitsToDouble(0x3fd742f5068143acL), Double.longBitsToDouble(0x3fc740424fa1efa0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 0, 6, 10, "\ud9f6\udc98\ud9f0\udc12", ",\000\u1599\ubf82\uba78\u00e3\000\u6f33\uc1ce\u9928", "\ud995\ude1a",
        49, 22227, 1884489871, -2043319756085264384L, -34464L, true, true, (char) 14507, (char) 35080,
        Double.longBitsToDouble(0x3fc89413780a1d8cL), Double.longBitsToDouble(0x3fd2e541eae0d05cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[\ud9f6\udc98\ud9f9\udcd7]\012",
        Z.run(T, 1, 6, 6, 10, "\ud9f6\udc98\ud9f9\udcd7", ",\000\u1599\ubf82\uba78\u00e3\000\u6f33\uc1ce\u9928", "\ud995\ude1a",
        49, 22227, 1887398799, -2084105040405987328L, -34464L, true, true, (char) 14507, (char) 35080,
        Double.longBitsToDouble(0x3fc89413780a1d8cL), Double.longBitsToDouble(0x3fd2e541eae0d05cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 0, 6, 10, ",\ud9f0\udc12", ",\000\u1599\ubf82\uba78\u00e3\000\u6f33\uc1ce\u9928", "\ud995\ude1a",
        49, 22227, 0, -2089670227099910144L, -34464L, true, true, (char) 14507, (char) 35080,
        Double.longBitsToDouble(0x3fc8941378021d8cL), Double.longBitsToDouble(0x3fd2e541eae0d05cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[\ud9f6\udc98\ud9f9\udcd7]\0121=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[\ud9f6\udc98\ud9f9\udcd7]\012",
        Z.run(T, 2, 6, 6, 10, "\ud9f6\udc98\ud9f9\udcd7", ",\000\u24a1\ubf82\uba78\u00e3\000\u6f33\uc1ce\u9928", "\udb90\ude37",
        32, 22227, 1887398799, -2084105040405987328L, -34464L, true, true, (char) 14507, (char) 35080,
        Double.longBitsToDouble(0x3fc894137c161d8cL), Double.longBitsToDouble(0x3fd81839cae00388L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[]\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 0, 0, "", "\u1c60\u6e27,\000", "\uda53\udf65\u00e3",
        -5, 14272, 1376452754, -7748424900512514921L, 79849L, true, true, (char) 10598, (char) 62589,
        Double.longBitsToDouble(0x3d9c600000000000L), Double.longBitsToDouble(0x3d8ebec000000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVRecord|putIn|java.util.Map|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|get|int|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|get|java.lang.Enum|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|get|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|getComment||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|getRecordNumber||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|isConsistent||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|isMapped|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|isSet|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|iterator||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|size||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|toList||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|toMap||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|toString||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|values||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "C|org.apache.commons.csv.CSVRecord|<init>|[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|putIn|java.util.Map|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
