package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 2, 6, "\udbba\udef3\udb87\ude4b\uda0d\udf8f\udaf8\udc71\uda6e\ude24\udb24\udc32\ud837\udce2\uda25\udd66\uda56\udeb2\uda6e\udf40\ud9f2\udc42\uda94\udfbc\udbcd\udfce\ud9ca\udece\ud954\udff7\udb32\udf87\udb48\udce1\ud9ba\udcc8\udb8c\udf43\udba1\uddf3\uda37\udec6\uda37\ude5a\ud883\ude7a", "\u7a16\ub20d", "\ud862\udfe4\udaec\udedc\udb0c\udcb0\ud960\udf70\ud8fb\udfcf\ud80f\udc21\ud8c0\udcef\udaab\udcb1",
        3, 58498, -584878579, -5232933779183414281L, 25399L, false, true, (char) 36521, (char) 55038,
        Double.longBitsToDouble(0x3fe9b6a6ef05efe3L), Double.longBitsToDouble(0x3fa80717c7a43550L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 2, 6, "\udbba\udef3\udb87\ude4b\uda0d\udf8f\udaf8\udc71\uda6e\ude24\udb24\udc32\ud837\udce2\uda25\udd66\uda56\udeb2\uda6e\udf40\ud9f2\udc42\ud850\udf9a\uda3e\udf67\udb84\udfd3\ud983\udc8d\udb32\udf87\udb48\udce1\ud9ba\udcc8\udb8c\udf43\udba1\uddf3\uda37\udec6\uda37\ude5a\ud883\ude7a", "\u045e\ub20d\u24cc\u8bbf\u0856\u9da9\uaea9\u9882\u3fbd\u1dfd\u0a18", "\uda87\udd48\ud802\udfff\ud969\ude2c\ud92c\udfe2\udaeb\udea8\udb04\udd8b\ud8c0\udc9e\udb2b\ude4f\ud897\udc5a\udb1b\ude78\udab9\udc43\udbd0\ude42\udbf1\udfda\udbf3\uddb7\ud92f\udd6f\u01b0\ud998\ude6d\ud85e\udc9a",
        24, 42505, -50816203, 6100550759700040452L, 56307L, true, true, (char) 6968, (char) 30841,
        Double.longBitsToDouble(0x3fd4bfe79e4d064eL), Double.longBitsToDouble(0x3fa261eb6d603f40L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 1, 2, "\udbba\udef3\udb87\ude4b\uda0d\udf8f\udaf8\udc71\uda6e\ude24\udb24\udc32\ud837\udce2\uda25\udd5c\uda56\ude8e\uda6e\udf40\ud9f2\udc42\uda94\udfbc\udbcd\udfce\udbae\udc5e\ud955\udcc2\udb32\udf87\udb48\udce1\ud9ba\udcc8\udb8c\udf43\udba1\uddf3\uda37\udec6\uda37\ude5a\ud883\ude7a\udae5\udc68\ud9fa\udd9d\ud847\ude24\udb05\udf15\ud85b\udd59\ud824\ude7e\ud862\udfe4\udaec\udedc\udb0c\udcb0\ud960\udf70\ud8fb\udfcf\ud80f\udc21\ud8c0\udcef\udaab\udcb1\ud975\udf83\uda87\udd48\ud802\udfff\ud969\ude2c\ud92c\udfe2\udaeb\udea8\udb04\udd8b\uda92\udca7\udb2b\ude4f\ud897\udc5a\ud96f\udee2", "\u7fd4\u0bfe\u3172", "\ud86c\udfc1\udb15\udd86\ud8f4\udef4\udb1b\udfb1\udb80\uddcc\ud9a0\uddb3\uda5f\ude23\udb6b\ude21",
        45, 7560, 286632107, -6293760409701732196L, 7513L, false, false, (char) 56362, (char) 36078,
        Double.longBitsToDouble(0x3fe1b7f9aea09d99L), Double.longBitsToDouble(0x3fe89f8677dda48cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 2, 6, "\udbba\udef3\udb87\ude4b\uda0d\udf8f\udaf8\udc71\ud97e\udc0a\ud9e8\ude94\ud837\udce2\uda25\udd66\uda56\udeb2\uda6e\udf40\ud9f2\udc42\uda94\udfbc\udbcd\udfce\ud9ca\udece\ud954\udff7\udb32\udf87\udb48\udce1\ud9ba\udcc8\udb8c\udf43\udba1\uddf3\uda37\udec6\uda37\ude5a\ud883\ude7a", "\u7a16\ub20d", "\ud862\udfe4\udaec\udedc\udb0c\udcb0\ud960\udf70\ud8fb\udfcf\ud80f\udc21\ud8c0\udcef\udaab\udcb1",
        3, 58498, -584878579, -5232933779183414281L, 25399L, false, true, (char) 36521, (char) 55038,
        Double.longBitsToDouble(0x3fe9b6a6ef05efe3L), Double.longBitsToDouble(0x3fa80717c7a43550L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 9, 0, "\udbba\udef3\udb87\ude4b\uda0d\udf8f\udaf8\udc71", "\ub602\u7641\ua198\u479a\ub7e2", "\ud9f0\udfa2\ud954\udff7\udb32\udf87\udb48\udce1\ud9ba\udcc8\ud8b3\udd9c\ud813\ude06\uda37\udec6\uda37\ude5a\ud883\ude7a\udae5\udc68\ud9fa\udd9d\ud847\ude24\udb05\udf15\ud85b\udd59\ud824\ude7e\ud862\udfe4\uda85\udc28\ud8ca\udcaf\ud9f8\udefd\ud8fc\udc51\ud80f\udc21\ud8c0\udcef\udaab\udcb1\ud975\udf83\uda87\udd48\ud802\udfff\ud969\ude2c\ud92c\udfe2\udaeb\udea8\udb04\udd8b\uda92\udca7\udb2b\ude4f\ud897\udc5a\ud96f\udee2\ud8da\udd84\udafc\ude38\udbf1\udfda\udb54\udc27\uda71\udf5b\udbcf\udea5\uda93\udef0\ud824\udf77\ud8c4\udd96\udaee\udf29\uf0de\u4d85\udb81\udf05\ud97e\ude1f",
        -5, 92897, -1547540680, 6870904341367520160L, 3687L, false, true, (char) 8561, (char) 57099,
        Double.longBitsToDouble(0x3fc4cdec91cec764L), Double.longBitsToDouble(0x3fd1c06e9b9c80b6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 13, 5, "\udbba\udef3\udb87\ude4b\uda0d\udf8f\udaf8\udc71\uda6e\ude24\udb24\udc32\ud837\udce2\uda25\udd66\uda56\udeb2\uda6e\udf40\ud9f2\udc42\uda38\udfe1\uda88\ude90\udbd4\ude73\ud954\udfe6\udb32\udf87\udb48\udce1\ud9ba\udcc8\udb8c\udf43\udba1\uddf3\uda37\udec6\uda37\ude5a\ud883\ude7a", "\u7a16\ub20d", "\ud862\udfe4\udaec\udedc\udb0c\udcb0\ud960\udf70\ud8fb\udfcf\ud80f\udc21\ud8c0\udcef\udaab\udcb1",
        3, 58498, -584878579, -5232933779183414281L, 25399L, false, true, (char) 44713, (char) 55038,
        Double.longBitsToDouble(0x3fe9b6a6ef05efe3L), Double.longBitsToDouble(0x3fa80717c7a43550L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 15, 2, "\000\u280d\000", "", "\u84da\uda49\ude44\000\000\000\u00e7\udbae\udc49\ud955\udcc2\000\udb48\udce1",
        45, -1000, 0, -1683255378401464019L, 69216L, false, false, (char) 275, (char) 15598,
        Double.longBitsToDouble(0x3ec4400000000000L), Double.longBitsToDouble(0x3febc80007524afaL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 3, "\ud800\uddf5\000\uda0d\udf8f\udaf8\udc71\ud96b\udf74\ud9e8\ude7a\ud837\udce2\uda25\udd66\uda56\udeb2\000\ud9f2\udc42\000\000\ud9b2\uddb9\ud954\udff7\ud966\udde1\000\000\udb8c\ude97\udba1\uddf3\000\uda37\ude5a\ud883\ude7a", "\u7a16\ub20d", "\ud862\udfe4",
        59, 75142, 1148073832, -5634622798690184291L, -58191L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe3a6e803f7b760L), Double.longBitsToDouble(0x3ddadc0000000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 2, 6, "\udbba\udef3\udb87\ude4b\uda0d\udf8f\udaf8\udc71\uda6e\ude24\udb24\udc32\ud837\udce2\uda25\udd66\uda56\udeb2\uda6e\udf40\ud9f2\udc42\uda94\udfbc\udbcd\udfce\ud9ca\udece\ud954\udff7\udb32\udf87\udb48\udce1\ud9ba\udcc8\udb8c\udf43\udba1\uddf3\uda37\udec6\uda37\ude5a\ud883\ude7a", "\u7a16\ub20d", "\ud862\udfe4\udaec\udedc\udb0c\udcb0\ud960\udf70\ud8fb\udfcf\ud80f\udc21\ud8c0\udcef\udaab\udcb1",
        3, 58498, -584878579, -5232933779183414281L, 25399L, false, true, (char) 36521, (char) 6911,
        Double.longBitsToDouble(0x3fe9b6a00705efe3L), Double.longBitsToDouble(0x3fa80717c7a43550L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 3, "\ud800\uddf5\000\uda0d\udf8f\udaf8\udc71\ud96b\udf74\ud9e8\ude7a\ud837\udce2\uda25\udd66\uda56\udeb2\000\ud9f2\udc42\000\000\ud9b2\uddb9\ud954\udff7\ud966\udde1\000\000\udb8c\ude97\udba1\uddf3\000\uda37\ude5a\ud883\ude7a", "\u7a16\ub20d", "\ud862\udfe4",
        59, 75142, 1148073832, -5634622798690184291L, 42673L, true, true, (char) 13, (char) 0,
        Double.longBitsToDouble(0x3fe3a6e803f7b7f0L), Double.longBitsToDouble(0x3ddadc0000000000L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 3, "\ud800\uddf5\u5b6b\udaae\udd25\udb04\udf59\ud96b\udf74\ud9e8\ude7a\ud837\udce2\uda25\udd66\uda56\udeb2\000\ud9f2\udc42\000\000\ud9b2\uddb9\ud954\udff7\ud966\udde1\000\000\udb8c\ude97\udba1\uddf3\000\uda37\ude5a\ud883\ude7a", "\u7a16\ub20d", "\ud862\udfe4",
        59, 75142, 1148073832, -5634622798690184291L, -58191L, true, true, (char) 10, (char) 0,
        Double.longBitsToDouble(0x3fe3a6e803f7b760L), Double.longBitsToDouble(0x3ddadc0000000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 9, "\udaca\udcf9", "\u908f\u767f\uca66\ud48c\u7641\ua198\000", "\udb9e\uddcf\udb05\ude90\udaef\udf40\udba1\udcec\udad7\udc32P\udb8c\ude97\udba1\uddf3\udaae\ude57\uda37\ude8d\udb5f\ude67\udb9a\udf6d\udbbe\uddf6\ud83a\udda0\udb02\udfed,\uda5a\udced\ud94a\udf3a\udad5\udc1d\udbcd\udd99\ud955\udebe\udbf9\uddad\ud8a0\udf00\udb60\udd6b\uda88\udd1b\ud847\udf92",
        0, 39584, -471544677, 91399001210880L, -83828L, false, false, (char) 12715, (char) 54981,
        Double.longBitsToDouble(0x3feb128a1a51ed70L), Double.longBitsToDouble(0x3fd90bb548703746L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 9, "\udaca\udcf9", "\u908f\u767f\uca66\ud48c\u7641\ua198\000", "\udb9e\uddcf\udb05\ude90\udaef\udf40\udba1\udcec\udad7\udc32P\udba0\ude2a\udba1\uddf2\udaae\ude57\uda37\ude8d\udb5f\ude67\udb9a\udf6d\udbbe\uddf6\ud83a\udda0,,\uda5a\udced\ud94a\udf3a\udad5\udc1d\udbcd\udd99\ud955\udebe",
        30, 482, 1418828912, 1684372351474332302L, -34464L, true, false, (char) 14085, (char) 0,
        Double.longBitsToDouble(0x3fafbe8072c5ef50L), Double.longBitsToDouble(0x3fe6948d41001a8fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVPrinter|print|java.lang.Object,java.lang.CharSequence,int,int|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|print|java.lang.Object|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVFormat|equals|java.lang.Object|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|format|[Ljava.lang.Object;|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getAllowMissingColumnNames||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getCommentMarker||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getDelimiter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getEscapeCharacter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getHeader||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getHeaderComments||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreEmptyLines||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreHeaderCase||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreSurroundingSpaces||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getNullString||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuoteCharacter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuoteMode||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVPrinter|print|java.lang.Object,java.lang.CharSequence,int,int|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVPrinter|print|java.lang.Object|new:org.apache.commons.csv.CSVPrinter:java.lang.Appendable,org.apache.commons.csv.CSVFormat",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
