package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVRecord_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 5, 9, 11, "\ud9c0\udfdf", "\u9b52\uc212\u5d78\uc031\u847e\u9519\u3542\u78f9\u4af2\u2151\u8fe5\uc9c8\ubd04\u9e4f\ub72b\u65fe\u4fb2\u2a14\u9280\u038b\u8554\u87e0\u9779\u8ef4\u7df1\ub7f8\u7fce\u0a94\u682d\u5759\u8b73\uc9c2\ub180\u8e60\ub55a\ub5f2\u9b03\u1ff1\ucb69\ub4ec\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3888\ud927\udf2d",
        -5, 58020, 2064183985, -5077576839878279858L, -85947L, true, false, (char) 18829, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fd7ffc494068d8aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 5, 12, 11, "\ud9c0\udfdf", "\ubca3\uc212\u5d78\uc031\u847e\u9519\u3542\u78f9\u8f18\u2151\u8fe5\uc9c8\ubd04\u9e4f\ub72b\u65fe\u4fb2\u2a14\u9280\u038b\u8554\u6f53\u6510\u3b58\u2b93\ub7f8\ud0a1\u7158\u682d\u5759\u8b73\uc9c2\ub180\u8e60\u95d2\u83fc\u9b03\ub24f\uc3a8\ub4ec\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef\ud9ce\udddd\ud80d\ude87\ud927\udedf",
        -5, 58020, -1391922511, -4033023742470914738L, -85947L, true, false, (char) 18829, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fbe41d251dddee8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud9c0\udfdf]] |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 10, 9, 11, "\ud9c0\udfdf", "\u9b52\uc212\u5d78\uc031\u847e\u9519\u3542=\u4a09\u2151\u8fe5\u9a0d\ubc86\u9e4f\ub72b\u65fe\u4fb2\u2a14\u9280\u346e\000\u8767\u83eb\000\u7cf9\ub7f8\u7fce\u0a94\u682d\u5759\u8b73\000\000\u18e4\ub55a\u1244\u9ad4\000\u204b\ub4ec\ub03c\ua2a7\u91b1\u26e8\u3978\ucdd1", "\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3888\ud927\udf2d",
        -5, 58020, 2064183985, -5077576839878279858L, -85947L, true, false, (char) 18829, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fd7ffc494068d8aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 6, 2, 1, "\ud9c0\udfdf", "\u9b52\u4a13\u5d78\uc431\u847e\u9519\u3542\u0bf1\u4af2\u2151\u8fe5\uc9c8\ubd04\u9e4f\u47c3", "\udbec\udf30\udba1\udde6\uda51\udfef\udb84\udcef\ud950\udcfd\uca6c\uda78\udf08\uda0a\udd86\ud843\udd6e\udb62\ude16\ud9ec\udd1e\uda06\udf7b\udb17\udebf\ud8c8\udf93\ud9af\udd47\ud924\ude62\ud954\udf02\udb0b\udd6c\uda08\udc04\ud9f9\udf32\u0305\ud8d6\udf4f\udaf9\udf5c\ud9fd\udc3e\u22ad\udb4b\ude3b\uda28\udd88\udb04\udccc\ud93a\udd62\ud95a\udf6d\ud9bc\udc68\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3888\u7f8a\udaeb\udd32",
        35, 58489, -1182215484, 3120428629172040212L, 79451L, true, false, (char) 49042, (char) 56682,
        Double.longBitsToDouble(0x3fdd2a0ffafff892L), Double.longBitsToDouble(0x3fe01a362c0fe722L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 1, 9, 11, "\ud9c0\udfdf", "\u9b52\uc212\u5d78\uc031\u847e\u9519\u3542\u78f9\u4af2\u2151\u8fe5\uc9c8\ubd04\u9e4f\ub72b\u65fe\u4fb2\u2a14\u9280\u9c62\u86cf\u8896\u9779\u8ef4\u7df1\ub7f8\u7fce\u0a94\u682d\u5759\u6073\uc9c2\ub180\u8e60\ub55a\ub5f2\u9b03\u1ff1\ucb69\ub4ec\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3888\ud927\udf2d",
        -5, 58020, 2064183985, -5077576839867663026L, -85947L, true, false, (char) 18829, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fd7ffc494068d8aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 5, 3, 11, "\ud9c0\udfdf", "\u9b52\uc212\u5d78\uc031\u847e\u9519\u3542\u78f9\u4af2\u2151\u8fe5\uc9c8\ubd04\u9e4f\ub72b\u65fe\u4fb2\u2a14\u9280\u038b\u8554\u87e0\u9779\u8ef4\u7df1\ub7f8\u7fce\u0a94\u682d\u54e3\u8bca\uc9c2\ub180\u8e60\ub55a\ub5f2\u9b03\u1ff1\ucb69\ub4ec\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3888\ud927\udf2d",
        -5, 58020, 2064183985, 4273236291217128782L, 95651L, false, true, (char) 18829, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fd7ffc494068d8aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\ud996\udfea]\012",
        Z.run(T, 1, 7, 11, 9, "\ud996\udfea", "\uad9d\u0c5b\u5d78\uc031\u847e\u9519\u3542\u78f9\u4af2\u2151\u8fe5\uc9c8\ubd04\u9e4f\ub72b\u3cfd\u4fb2\u2a14\u9280\u038b\u8554\u87e0\u9779\u8ef4\u7df1\ub7f8\u7fce\u0a94\u682d\u5759\u8b73\uc9c2\ub180\u8e60\ub55a\ub5f2\u9b03\u1ff1\ucb69\ub4ec\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3888\ud927\udf2d",
        54, 4258, 151581361, -5091657254503056050L, -85947L, true, false, (char) 18829, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fd7ffc494068d8aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 5, "\ud9c0\udfdf", "\u78a0\u3063\u5e36\uc078\u847e\u9519\u3542\u9071\u4af2\u2151\u8d3a\uc9c0\ubd04\u9e4f\ua69a\u65fe\u4fb2\u2a14\u9280\u038b\u8554\u87e0\u9779\u8ef4\u1692\u2f8c\ud7db\u0a2c\u682d\u5759\u8b73\uc9c2\u96c8\u8e60\ub55a\ub5f2\u9b03\u1ff1\ucb69\u8e30\u11ae\ube32\u78e0\u26cf\u877b\u3530", "\ud916\udc5a\udba2\uddef\udb46\ude19\u8d3f\ud908\ude06\uda6c\udce6\ud9a8\udf6a\udb45\udff3\udba5\ude9c\ud91b\udfdb\udbc5\udd2f\ud904\ude3f\uda86\udd66\u1d1d\uda3f\udfcd\udb3f\udd90\udbd5\udd99\uda9c\uddaa\udbd1\udedb\udb56\udce1\ud8b2\uddd3",
        11, 40707, 1038496282, 6378581596237104009L, -85842L, true, true, (char) 56762, (char) 3757,
        Double.longBitsToDouble(0x3fe1493339fb0d92L), Double.longBitsToDouble(0x3fea71b88fc5a849L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 4, 9, 11, "\ud9c0\udfdf", "\u9b52\uc212\u5d78\uc031\ub05f\ubdb3\u3542\u78f9\u4af2\u2151\u8fe5\uc9c8\ubd04\u57b9\ub730\u65fe\u4fb2\u2a14\u9280\u038b\u8554\u87e0\u9779\u8ef4\u7df1\ub7f8\u7fce\u0a94\u682d\u5759\u8b73\uc9c2\ub180\u8e60\ub55a\ub5f2\u9b03\u1ff1\ucb69\ua532\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3888\ud927\udf2d",
        26, 25436, -1296271202, -5077577230720303794L, -85947L, true, false, (char) 18829, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fd7ffc494068d8aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udf27]\0121=java.lang.Long:3120428629172040212 |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udf27]\012",
        Z.run(T, 2, 5, 3, 1, "\ud8e7\udf7d\u074f\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udf27", "\uc759\u69a2\u3e3d\ua84a\u2151\u8fe5\uc9c8\ubd04\u46ac\u0cf9", "\ud9ce\udd8b\udab1\udf66\u2b80\udb84\udcef\ud950\udcfd\uca6c\uda78\udf08\uda0a\udd86\ud843\udd6e\udb62\ude16\ud9ec\udd1e\uda03\ude65\ud8ab\udd3b\ud8c8\udf93\udb59\udc7c\ud924\udde2\ud954\udf02\udb0b\udd6c\uda08\udc04\ud9f9\udf32\ud952\udf9a\ud9c3\udd99\ud8e7\udefb\ud9ea\udd7b\u22ad\udb46\ude3b\uda28\udd88\udb04\udccc\udbd1\udd59\ud95a\udf6d\ud9bc\udc68\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3888\ud927\udf2d\ud97c\udf9b",
        22, 16124, -1182239627, 3120428629172040212L, 79451L, true, true, (char) 31154, (char) 26366,
        Double.longBitsToDouble(0x3fdd2568e3aecc92L), Double.longBitsToDouble(0x3fe0211c299793f0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\udade\udd2e] |a0=[Ljava.lang.String;:[[\udade\udd2e]]\012",
        Z.run(T, 1, 11, 7, 11, "\udade\udd2e", "\u9b01\u25b7\u5d78\u6b10\ubb6f\u9519\u3542\u78f9\u4af2\uc039\u689d\uca49\ubd04\u9e4f\ub72b\u65fe\u4fb2\u29f6\u926a\u038b\u8554\u87e0\u9779\u8ef4\u7df1\ub7f8\u7fce\u499c\u102d\u5759\u8b73\u992a\ub100\u8e60\ub55a\u7672\u9b6c\u1ff1\ucb69\ub4ec\ub03c\ube70\u2eb1\u26e8\u398e\u65ed", "\udb10\udf30\udb8c\udccb\ud9ce\udddd\u3888\ud9cc\udee0",
        -5, 58020, 2064183985, -5077576839878279858L, 21317L, false, true, (char) 18829, (char) 43154,
        Double.longBitsToDouble(0x3fef55dc05d2566cL), Double.longBitsToDouble(0x3fd7ffc494068d8aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf\u11d1\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udeb9\ufc99]\0121=java.lang.String:[\ud9c0\udfdf\u11d1\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udeb9\ufc99] |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf\u11d1\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udeb9\ufc99]\012",
        Z.run(T, 2, 5, 9, 11, "\ud9c0\udfdf\u11d1\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udeb9\ufc99", "\uba76\u4621\u78ac\ubacb", "\udb2c\udc40\ud9da\ude66",
        26, 44943, 1873261579, 1437574547685034576L, 52379L, true, true, (char) 39502, (char) 58224,
        Double.longBitsToDouble(0x3fd23c7f3b718c4eL), Double.longBitsToDouble(0x3fc9816a5a22314cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud9c0\udfdf]] |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 10, 9, 11, "\ud9c0\udfdf", "\u9b52\uc212\u5d78\uc031\u847e\u9519\u3542\u7dcd\u4af2\u2151\ube43\uca9f\ubcd5\u9e4f\u0a1a\uce29\u4fb2\u2a14\u9280\u038b\u8554\u87e0\u9779\u8ef4\u7df1\ub7f8\u7fce\u0a94\u877f\u5759\u8b73\uc9c2\ub180\u8e60\ub55a\ub5f2\u9b03\u1ff1\ucb69", "\ud8a7\udf22",
        10, 35718, 487937814, -993670260725395142L, -64398L, false, false, (char) 27084, (char) 4507,
        Double.longBitsToDouble(0x3fde8561a594f320L), Double.longBitsToDouble(0x3fbd0c9f558aa220L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:[\ud94e\udfa5\ud8fb\udc95\ud988\ude22\udbf0\udca4\udb89\udff0\ud988\udd87\udbde\udfd9\udaea\udc8c\ud871\udf90\ud965\uddbb] |this=org.apache.commons.csv.CSVRecord:[\ud94e\udfa5\ud8fb\udc95\ud988\ude22\udbf0\udca4\udb89\udff0\ud988\udd87\udbde\udfd9\udaea\udc8c\ud871\udf90\ud965\uddbb]\0121=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\ud94e\udfa5\ud8fb\udc95\ud988\ude22\udbf0\udca4\udb89\udff0\ud988\udd87\udbde\udfd9\udaea\udc8c\ud871\udf90\ud965\uddbb]\012",
        Z.run(T, 2, 9, 7, 3, "\ud94e\udfa5\ud8fb\udc95\ud988\ude22\udbf0\udca4\udb89\udff0\ud988\udd87\udbde\udfd9\udaea\udc8c\ud871\udf90\ud965\uddbb", "\u55bb\u9004\uc9c8", "\udba6\ude54\udb8e\udc06\udb46\ude96\udbec\udf9b\uda11\uddff\ud877\udd57\ud847\udc9b\ud87c\udd04\udb46\udfb6\uda78\udf08\uda0a\udc93\ud843\udd6e",
        39, 10230, 1377585627, -7072563725948692980L, -69408L, true, false, (char) 26421, (char) 57456,
        Double.longBitsToDouble(0x3fe1c6b9a528b412L), Double.longBitsToDouble(0x3fe605bce721646aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 12, 11, "\ud9c0\udfdf", "\ubca3\uc212\u5d78\uc031\u847e\u9519\u3542\u1189\u5b58\u3cf9\u85ca\uc9c8\ubd04\u9e4f\ub72b\u65fe\u4fb2\u2a14\u9280\u038b\u8554\u6f53\u6510\u3b58\u2ac3\u3e7e\ubf39\u2ef9\u682d\u5759\u7d86\uc9c2\u7b53\u74b7\u95d2\u83fc\u4303\ub24f\uc3a8\ub4ec\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef\ud860\udc46\ud80d\ude87\ud927\udedf",
        -5, 58020, -1391922511, 5125890524717121019L, -85947L, true, false, (char) 18829, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fbe41d251dddee8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\ud9aa\udc74] |a0=[Ljava.lang.String;:[[\ud9aa\udc74]]\012",
        Z.run(T, 1, 11, 2, 4, "\ud9aa\udc74", "\u7832\uc212E\uc031\u847e\u9519\u3542\u78f9\u8f18\u2151\u8fe5\uc9c8\ubd04\u9e4f\ub72b\u65fe\u4fb2\u2a14\u9280\u038b\u8554\u6f53\u6510\u3b58\u2b93\ub7f8\ud0a1\u7158\u682d\u5759\u8b73\uc9c2\ub180\u8e60\u95d2\u83fc\u9b03\ub24f\uc3a8\ub4ec\ub03c\u87b7\u68e6\u26e8\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef\udba1\udc07\ud80d\uded6\ud927\udedf",
        7, 53976, -1391922546, -4033023742470914738L, -85947L, true, false, (char) 18829, (char) 65425,
        Double.longBitsToDouble(0x3fdeabb1bba4ad1cL), Double.longBitsToDouble(0x3fbe41d251dddee8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\ud94c\udc65] |a0=[Ljava.lang.String;:[[\ud94c\udc65]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 0, 0, "\ud94c\udc65", "\u2a59\u3f32\u7f74", "\udb23\uddb7\ud95c\udeef\ud9da\ude76\ud923\ude36\udbbc\udfc3\ud9b5\uddb8\uda57\ude22\ud93f\udd03\udb8a\udca1\udbcd\udc19",
        25, 75787, 921913967, 2245306631594636500L, -64518L, false, false, (char) 4048, (char) 7704,
        Double.longBitsToDouble(0x3fd4dd74533457d2L), Double.longBitsToDouble(0x3fc284129032745cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 12, 11, "\ud9c0\udfdf", "\ubca3\uc212\u5d78\uc031\u847e\u9519\u3542\u78f9\u8f18\u2151\u8fe5\uc9c8\ubd04\u9e4f\ub72b\u3e98\u3664\u83ed\u1544\u038b\u8554\u6f53\u6510\u3b58\u2b93\ub7f8\ud0a1\u7158\u682d\u4921\u8b73\uc9c2\ub180\u8e60\u9c10\u83fc\u9b03\ub24f\u62d7\u8df9\ub03c\u8131\u10b6\u26e8\u398e\ua0d1", "\udaa5\ude37\udb93\uddef\ud9ce\udddd\ud80d\ude87\ud927\udedf",
        -5, 58020, -1391922511, -4033023742470914738L, -69727L, false, false, (char) 34948, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fbe41d251ddda38L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\uda4f\udd27\udbc4\udce3\ud992\udf1b\udbea\udc20\uda34\udda8\ud868\udeb9\udb79\udea5\uda40\udeea\udb02\udcd8]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\uda4f\udd27\udbc4\udce3\ud992\udf1b\udbea\udc20\uda34\udda8\ud868\udeb9\udb79\udea5\uda40\udeea\udb02\udcd8]\012",
        Z.run(T, 2, 4, 4, 12, "\uda4f\udd27\udbc4\udce3\ud992\udf1b\udbea\udc20\uda34\udda8\ud868\udeb9\udb79\udea5\uda40\udeea\udb02\udcd8", "\u3898\ucf1e\u9cc7\ud1d2\ubcce", "\udb8e\udc06\udb46\ude96\udbec\udf30\udafc\udd33\ud978\udf80\udacc\udd4c\ud950\uddbe\uc9a6\uda78\udf08\uda0a\udd86\udb57\ude17\ud9fb\ude13\ud9ec\udd10\uda06\udf7b\udb17\udebf\ud8c8\udf93\ud9af\udd47\ud924\ude62\ud985\udd7b\udb0d\ude85\uda08\udc04\ud9f9\udf32\u0305",
        -3, 78281, -2134679924, 8430162117359770367L, 74314L, true, true, (char) 22220, (char) 60624,
        Double.longBitsToDouble(0x3fecc4e078b7d1fbL), Double.longBitsToDouble(0x3fe738ffcb757626L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud9c0\udfdf]] |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\0121=new org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf] |a0=[Ljava.lang.String;:[[\ud9c0\udfdf]]\012",
        Z.run(T, 2, 10, 11, 9, "\ud9c0\udfdf", "\uc1bf\u4a13\u5d78\uc431\u847e\u9519\u8933\u0bf1\u4af2\u2151\u8fe5\uc9c8\ubd04\u9e4f\u74cd", "\udbec\udf30\udba1\udde6\uda51\udfef\udb84\udcef\ud950\udcfd\uca6c\udbbc\udfea\uda0a\udced\ud843\udd6e\udb62\ude16\ud9ec\udd1e\uda06\udf7b\udb17\udebf",
        19, 54180, 821065600, 7381114984729477319L, 65356L, true, true, (char) 15241, (char) 52405,
        Double.longBitsToDouble(0x3fc98e9fbe206184L), Double.longBitsToDouble(0x3fe8b4d1ca2a1d15L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.csv.CSVRecord:[\ud8ca\udce7\u1170\ud988\ude22\udb5b\uded8\udb89\udff0\ud86a\udeb9\udb78\udea5\uda40\udeea\udb23\uddb7]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud8ca\udce7\u1170\ud988\ude22\udb5b\uded8\udb89\udff0\ud86a\udeb9\udb78\udea5\uda40\udeea\udb23\uddb7]\012",
        Z.run(T, 2, 1, 5, 9, "\ud8ca\udce7\u1170\ud988\ude22\udb5b\uded8\udb89\udff0\ud86a\udeb9\udb78\udea5\uda40\udeea\udb23\uddb7", "\u4af2\u2151\u8fe5\uc9c8\ubd04", "\udb8e\udc06\ud850\udd98\uda1f\udda2\udb08\udcf4\ud913\udc5c\udb97\ude39\ud950\uddb3\uca6c\uda78\udf08\uda0a\udd86\ud843\udd6e\udb62\ude16\ud9ec\udd1e\uda06\udf7b\ud826\udcc2\ud8be\udc93\ud9af\udd47\ud924\ude62\ud954\udf02\udb0b\udd6c\uda08\udc04\ud9f9\udf32\ud87f\ude6b",
        9, 48036, -655532404, 8430162118235499724L, 74314L, false, false, (char) 50031, (char) 4561,
        Double.longBitsToDouble(0x3fcdd7e8abcaee3cL), Double.longBitsToDouble(0x3fdfceee46eaed66L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud994\uddc9]\0121=new org.apache.commons.csv.CSVRecord:[\ud994\uddc9] |a0=[Ljava.lang.String;:[[\ud994\uddc9]]\012",
        Z.run(T, 2, 5, 11, 9, "\ud994\uddc9", "\uad9d\u0c5b\u25bd\uc031\u847e\u9519\u3542\u78f9\u4af2\uae59\u9b71\u5508\ubd04\u9e4f\ub72b\ua1ca\ucb52\u1f43\u9694\u7cb2\u8554\u87e0\u9779\u8ef4\ubba5\ub810\u7fce\u0a94\u682d\u5759\u9e32\u8c7b\ubacc\u6252\ub55a\ub5f2\u9b03\u1ff1\ucb69\ub4ec\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud9da\udef4\udba2\uddef\ud9ce\udddd\u3888\ud927\udf2d",
        54, 4258, 2030629553, -5091657649640047282L, -85947L, true, false, (char) 18829, (char) 56978,
        Double.longBitsToDouble(0x3fdeabb80ba4ad1cL), Double.longBitsToDouble(0x3fd7ffc494068d8aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 8, 9, 5, "\ud9c0\udfdf", "\u9b52\uc212\u5d78\uc031\u1714\ub012\u00e7\uada4\u4af2\u2151\u8fe5\uc9c8\ubd04\u8ab9\ub730\u65fe\u9485\u3fc2,\u433c\u776a\u3e2c\u578f\u8ef4\u7df1\ub7f8\u7fce\u0a94\u682d\u5759\u8b73\ubb5b\ub180\u8e60\ub4ff\ub63e\u9b03\u1ff1\ucb69\u4bb8\u4eb3\ube70\u91b1\u548a\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef",
        9, 81309, 361786856, -5433974236050552388L, 43892L, true, false, (char) 62942, (char) 7054,
        Double.longBitsToDouble(0x3feebb9829eabb80L), Double.longBitsToDouble(0x3fdd2568eafff892L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udf27]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udf27]\012",
        Z.run(T, 2, 5, 5, 0, "\ud8e7\udf7d\u074f\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udf27", "\uc759\u69a2\u3e3d\uc6cf\u2151\u8fe5\uc9c8\ubd04\u46ac\u0cf9", "\ud9ce\udd8b\udab1\udf66\u2b80\udb84\udcef\ud950\udcfd\uca6c\uda78\udf08\uda0a\udd86\ud843\udd6e\udb62\ude16\ud9ec\udd1e\uda03\ude65\ud8ab\udd3b\ud8c8\udf93\udb59\udc7c\ud924\udde2\ud954\udf02\udb0b\udd6c\uda08\udc04\ud9f9\udf32\ud952\udf9a\ud9c3\udd99\ud8e7\udefb\ud9ea\udd7b\u22ad\udb46\ude3b\uda28\udd88\udb04\udccc\udbd1\udd59\ud95a\udf6d\ud9bc\udc68\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3888\ud927\udf2d\ud97c\udf9b",
        22, 16124, -1182239627, 3120428629172040212L, 79451L, true, false, (char) 5849, (char) 26366,
        Double.longBitsToDouble(0x3fdd2568e3aecc92L), Double.longBitsToDouble(0x3fe0211c299793f0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\ud988\ude22\udbf0\udca4\udb89\udff0\uda14\udfbc]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\ud988\ude22\udbf0\udca4\udb89\udff0\uda14\udfbc]\012",
        Z.run(T, 2, 5, 5, 6, "\ud8e7\udf7d\u074f\ud988\ude22\udbf0\udca4\udb89\udff0\uda14\udfbc", "\uc759\u69a2\u3e3d\ua84a", "\udb14\udda3\udb2c\udc40\uda2b\udc21\udb9f\udeeb\udb8e\udcc9\uda76\udd66\ud9ce\udd8b\udab1\udf66\u2b80\udb84\udcef",
        39, 71077, -2086630819, -1764651327146349998L, 33496L, false, false, (char) 17921, (char) 31238,
        Double.longBitsToDouble(0x3fe623fdf7c16118L), Double.longBitsToDouble(0x3fcf261e031d99b8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\udafa\uddda\u09d2\udb17\udf8e\ud86a\udf11]\0121=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\udafa\uddda\u09d2\udb17\udf8e\ud86a\udf11]\012",
        Z.run(T, 2, 7, 7, 1, "\ud8e7\udf7d\u074f\udafa\uddda\u09d2\udb17\udf8e\ud86a\udf11", "\uc759\u69a2\u2438\ua84a\u2151\u8fe5\uc9c8\ubd04\u7837\u38fc", "\ud9ce\udd8b\udab1\udf66\u2b80\udb84\udcef\udb60\udfe4\uc9b6\uda78\udf08\uda0a\udd86\ud843\udd6e\udb62\ude16\ud9ec\udd1e\uda03\ude65\ud8ab\udd3b\udb9a\udcbc\udaa8\uddc6\ud924\udde2\ud954\udf02\udb0b\udd6c\uda08\udc04\ud9f9\udf32\ud952\udf9a\ud9c3\udd99\ud8e7\udefb\ud9ea\udd7b\u22ad\udb46\ude3b\uda28\udd88\udb24\udfcc\udbd1\udd89\ud95a\udf6d\ud9bc\udc68\ud9cc\udce5\udba2\uddef\ud9ce\udddd\u3e2e\ud927\udf2d\ud97c\udf9b",
        50, 48741, -1182239522, 3120428629172040212L, 79451L, true, true, (char) 31154, (char) 26366,
        Double.longBitsToDouble(0x3fdd2568e3aecc92L), Double.longBitsToDouble(0x3fe0211c299793f0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\ud988\ude22\ud8b7\ude9e\udb7c\udcdf\ud86a\udf27]\0121=null |this=org.apache.commons.csv.CSVRecord:[\ud8e7\udf7d\u074f\ud988\ude22\ud8b7\ude9e\udb7c\udcdf\ud86a\udf27]\012",
        Z.run(T, 2, 1, 1, 7, "\ud8e7\udf7d\u074f\ud988\ude22\ud8b7\ude9e\udb7c\udcdf\ud86a\udf27", "\u6896\u4118\u3e3d\ua84a\ucaae\u9071\uc9c8\ubd04\u46ac\u0cf9", "\udaad\udea3\udaa4\udfe8\u2b80\ud908\udd2b",
        39, 71077, -2086645411, -1764651324294223278L, 33539L, false, false, (char) 17921, (char) 31238,
        Double.longBitsToDouble(0x3fc6eff7dc02da84L), Double.longBitsToDouble(0x3fcf261e031d99b8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf\u11d1\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udeb9\ufc99] |a0=[Ljava.lang.String;:[[\ud9c0\udfdf\u11d1\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udeb9\ufc99]]\0121=new org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf\u11d1\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udeb9\ufc99] |a0=[Ljava.lang.String;:[[\ud9c0\udfdf\u11d1\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udeb9\ufc99]]\012",
        Z.run(T, 2, 11, 11, 11, "\ud9c0\udfdf\u11d1\ud988\ude22\udbf0\udca4\udb89\udff0\ud86a\udeb9\ufc99", "\uba76\u4621\u8244\ubacb", "\ud95d\ude19\ud9da\ude47",
        26, 44943, 1873261579, 1437574547685034576L, 52379L, true, true, (char) 39502, (char) 58224,
        Double.longBitsToDouble(0x3fd23c7f31718c4eL), Double.longBitsToDouble(0x3fa3fa09e888c530L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud84d\udc31\u2ecf\ud988\ude22]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud84d\udc31\u2ecf\ud988\ude22]\012",
        Z.run(T, 2, 6, 6, 8, "\ud84d\udc31\u2ecf\ud988\ude22", "\u5d78\u6444\u847e\u9519\uba76\u4621\u78ac\ubacb\u41b3\u4526", "\ud9e0\udd32\udb8e\udc81\udafb\uddba\udb8a\udeae\ud920\udde9\udbbc\udd55\udbe3\udff1\ud935\uddc5\ud9fe\udd78\udaa1\uddb8\ud90a\udca8\ud924\udc64",
        27, 48430, -1772569120, -6870114711971084168L, 6921L, true, false, (char) 55133, (char) 61427,
        Double.longBitsToDouble(0x3fd383f3122ea0ccL), Double.longBitsToDouble(0x3f8cac2c0b8ba940L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\ud94c\udc65] |a0=[Ljava.lang.String;:[[\ud94c\udc65]]\0121=new org.apache.commons.csv.CSVRecord:[\ud94c\udc65] |a0=[Ljava.lang.String;:[[\ud94c\udc65]]\012",
        Z.run(T, 2, 11, 11, 0, "\ud94c\udc65", "\u2a59\u1e02\u9889\u954d\u141a\ud362\ua556\u9c16\u8f18\u2151\ua783\u6c5e", "\udbcd\udc19\udb8e\udc06\udb46\ude96\u35ac\ud82a\udc52\uda52\udc5d\udb84\udcef",
        29, 7772, 10521242, 3927898603329214798L, 62483L, false, true, (char) 9512, (char) 31011,
        Double.longBitsToDouble(0x3fd2d9ccbc7c2e94L), Double.longBitsToDouble(0x3fd74ba05016efe2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 1, 4, 9, 12, "\ud9c0\udfdf", "\u9b52\uc212\u5d78\uc031\u1714\ub012\u7d6f\uada4\u9b16\uc12f\u8fe5\uc9c8\ubd04\u8ab9\u32bf\u2d2a\u9550\u3fc2,\u433c\u776a\u3e2c\u578f\u0fa9\u34c4\ub7f8\u7fce\u0a94\u682d\u5759\u8b73\ubb5b\ub180\u8e60\ub4ff\ub63e\u9b03\u1ff1\u447b\u4bb8\u4eb3\ube70\u91b1\u5a2b\u79ce\u4371", "\ud9cc\udce5\udba2\uddef",
        9, 81309, 361786856, -5001628673316095899L, 43892L, true, false, (char) 62942, (char) 7054,
        Double.longBitsToDouble(0x3feebb9829eabb80L), Double.longBitsToDouble(0x3fdd2568eaffb492L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud997\udcdf]\012",
        Z.run(T, 1, 5, 9, 6, "\ud997\udcdf", "\u2a15\u06fa\u1720\u59fd\u847e\u9519\u3542\u78f9\u4af2\u2151\u8fe5\uc9c8\ubd04\u9e4f\ud0d6\u32dd\u4fb2\u2a14\u9280\u038b\u8554\u87e0\u9779\ua495\u7df1\ub7f8\u7fce\u0a94\u682d\u5759\u8b73\uc9c2\u2681\u8e60\ub55a\ub5f2\u9b03\u8d22\u4fe4\ub355\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef\ud9ce\udddd\udbb0\udc78\ud927\udea1",
        -5, 58020, 2064183985, -5077576839878279858L, -85947L, true, false, (char) 18829, (char) 49042,
        Double.longBitsToDouble(0x3fdeabb80ba5191cL), Double.longBitsToDouble(0x3fd7ffc494068d8aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\u1363 |this=org.apache.commons.csv.CSVRecord:[\u1363]\0121=java.lang.String:\u1363 |this=org.apache.commons.csv.CSVRecord:[\u1363]\012",
        Z.run(T, 2, 0, 12, 11, "\u1363", "\u3122\uc162\u5d78\uc031\u847e\u9519\u3542\u78f9\u4af2\u2151\u8fe5\uc9c8\ubd04\u9e4f\ub72b\ua776\u4fb2\u8fff\ucbff\u038b\u8554\u87e0\u1eb7\uae19\u32df\u3d55\u511c\u7a5f\ub4ea\u0a69\ua186\uc9c2\ua086\u8e60\ub530\ub5f2\u9b03\u1ff1\ucb69\u9b12\ub03c\ube70\u91b1\u26e8\u398e\ucdd1", "\ud90f\udd46\udb35\ude12\ucb2b\u3888\ud927\udf2d",
        0, 97423, 2064183985, 4273236291217128782L, 17888L, false, true, (char) 53645, (char) 49042,
        Double.longBitsToDouble(0x3fe755dc05d27c8eL), Double.longBitsToDouble(0x3fd7ffc49e068d8aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf] |a0=[Ljava.lang.String;:[[\ud9c0\udfdf]]\0121=java.lang.String:[\ud9c0\udfdf] |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 2, 11, 9, 5, "\ud9c0\udfdf", "\u8cc6\u3ddd\u2ce1\uc031\u1714\ub012\u5868\u2089\u9d05\u7658\u6509\uca11\ubd04\u8ab9\u03a6\u6590\u952a\u6f8a,\u433c\u68ee\ua1da\ub3dd\u9ea1\u7d4e\ub7f8\u7fce\u0a94\u682d\u5759\u8b73\ubbf3\ub180\u2750\u5a33\ub679\u9b03\u0df1\ucb69\u4ed1\u43da\ube70\u91b1\u548a\u398e\ucdd1", "\ud9cc\udce5\udba2\uddef",
        9, 40266, 354898906, -5433974236050552388L, 43892L, true, false, (char) 62942, (char) 7054,
        Double.longBitsToDouble(0x3feebb9829eabb80L), Double.longBitsToDouble(0x3feff45dd57ffc96L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\0121=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[\ud9c0\udfdf]\012",
        Z.run(T, 2, 4, 4, 10, "\ud9c0\udfdf", "\u9b52\uc212\u5d78\uc031\u1714\ub012\u7d6f\uada4\u9b16\uc12f\u8fe5\uc9c8\ubd04\u1b93\u5ad1\u2d2a\u9550\u3fc2,\u433c\u776a\u3e2c\u724d\u46b1\u34c4\ub7f8\u7fce\u0a94\u682d\u5759\u8b73\ubb5b\ub180\u8e60\ub4ff\ub63e\u9b03\u1ff1\u447b\u4bb8\u4eb3\ube70\u91b1\u5a2b\u79ce\u4371", "\ud9cc\udce5\udba2\uddef",
        9, 81309, 361786856, -5001628673316095899L, 28538L, true, false, (char) 62942, (char) 7054,
        Double.longBitsToDouble(0x3feebb9829eabb80L), Double.longBitsToDouble(0x3fdd2568eaffb492L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVRecord|get|int|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|get|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|getComment||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|getRecordNumber||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|isConsistent||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|isMapped|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|isSet|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|iterator||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|size||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|toString||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|values||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "C|org.apache.commons.csv.CSVRecord|<init>|[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|get|int|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|get|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
