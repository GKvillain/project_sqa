package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 5, 10, "\ud89f\uddc8\u5337\udb48\udd45\ud992\udc61\uda87\uddc8\ud8f7\udee1\ud992\udcfd\ud846\udfd4\ud934\udc8d\ub3ce\udb84\udf54\ud95e\udd9d\ud873\udfe1\udb7f\udd2a\udbd5\uddce\ud9f0\udd4f\ud886\udd01\ud96b\ude42\uda58\udc1f\uda65\uddce\ud8a0\udd01\ud3ac\uda1f\udc26\uda1a\ude2b\udaa6\udd95\ud895\ude31\ud9a0\udfad\ud88f\ude0c\uda4b\ude02\u567f\u4d55\udb61\udfdf\udafe\ude87\ud8e9\udf8b\udae4\udd80", "\ua34b\u6e73\uba41\u6b21\u4db0", "\ud97b\udf43\udbcc\udc0e\ud5d2\ud8c9\udfe1\udaa8\udef1\udb38\udf08\ud9dd\udd47\udb40\ude2a\udbdf\ude55\udb03\udfe2\uda88\udfb6",
        45, 75193, 143935976, -949217798094507376L, 30306L, true, false, (char) 56633, (char) 30209,
        Double.longBitsToDouble(0x3fe0823646390d0aL), Double.longBitsToDouble(0x3fe920207151f0d3L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 5, 10, "\ud89f\uddc8\ud81c\udf39\udb48\udd45\ud992\udc61\uda87\uddc8\ud8f7\udee1\ud992\udcfd\ud846\udfd4\ud934\udc8d\ub3ce\udb84\udf54\ud95e\udd9d\ud95d\udde8\udb7f\udd2a\udbd5\uddce\ud9f0\udd4f\ud886\udd01\ud96b\ude42\uda66\udf1f\uda65\uddce\ud824\udcbd\ud971\ude31\uda1e\udfe9\uda1a\ude2b\udaa6\udd95\udb0b\udc9a\udaf3\udf2b\ud88f\ude0c\uda4b\ude02\u567f\u4d55\udb61\udfdf\udafe\ude87\ud8e9\udf8b\udae4\udd80", "\ua34b\u6e73\uba41\uadf5\u4e19", "\ud97b\udf43\udbcc\udc0e\ud5d2\ud8c9\udfe1\udaa8\udef1\udb38\udf08\ud9dd\udd47\udb40\ude2a\udbdf\ude55\udb03\udfe2\uda88\udfb6",
        5, 75193, 143935976, -949217798094507376L, 30306L, true, false, (char) 56633, (char) 30356,
        Double.longBitsToDouble(0x3fe082364639c5beL), Double.longBitsToDouble(0x3fe920207151f0d3L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 10, "\ud89f\uddc8\u5337\udb48\udd45\ud992\udc61\udb34\ude3e\udad2\udc28\ud992\udcfd\ud846\udfd4\ud934\udc8d\ub3ce\udb84\udf54\udb8e\udd95\ud873\udf1e\ud81f\udc30\udbd5\uddce\udb06\udd5a\ud886\udd01\uda48\udc70\uda87\udc72\uda65\uddce\ud8a0\udd01\ud3ac\uda1f\udc26\uda1a\ude2b\udaa6\udd95\ud895\ude31\ud963\uddae\uda6b\udd50\uda4b\udd3c\u567f\u4d55\udb61\udfdf\udafe\ude87\ud8e9\udf8b\udae4\udd80", "\ua401\u6e73", "\udb18\uddbf\uda6d\udc59\uda43\uddae\ud839\udf7a\ud8e9\udd06\ud629\ub7d4\udaa8\udef1\ud9b0\ude00\ud829\udd36\udb40\ude2a\udbdf\ude55\udb03\udfe2\udaa6\ude03\udbc5\ude63\ud84a\udf4c",
        49, 65433, 437858960, 5944940057983319298L, 43888L, true, false, (char) 30514, (char) 31549,
        Double.longBitsToDouble(0x3fe201ad5941a641L), Double.longBitsToDouble(0x3fedbb04dd646f7bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u1204", "\udbb3\udfff\ud992\udcfd\ud846\udfd4\ud934\udc8d\ub3ce\udb84\udf54\ud95e\udd9d\ud873\udfe1r\000\u1884\u00a3",
        -5, 91371, 1891198762, 1844619319294989701L, -51977L, false, false, (char) 43625, (char) 42539,
        Double.longBitsToDouble(0x3fbc89fff65270c0L), Double.longBitsToDouble(0x3fc34f5100208098L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 5, 10, "\ud89f\uddc8\u5337\udb48\udd45\ud992\udc61\uda87\uddc8\ud8f7\udee1\ud992\udcfd\ud846\udfd4\ud934\udc8d\ub3ce\udb84\udf54\ud95e\udd9d\ud873\udfe1\udb7f\udd2a\udbd5\uddce\ud9f0\udd4f\ud886\udd01\ud96b\ude42\uda58\udc1f\uda65\uddce\ud8a0\udd01\ud3ac\uda1f\udc26\uda1a\ude2b\udaa6\udd95\ud895\ude31\ud9a0\udfad\ud88f\ude0c\uda4b\ude02\u009a\000\udb61\udfdf\udafe\ude87\ud8e9\udf8b\udae4\udd80", "\ua34b\u6e73\u0082\000\000", "\ud97b\udf43\udbcc\udc0e\ud5d2\ud8c9\udfe1\udaa8\udef1\udb38\udf08\ud9dd\udd47\udb40\ude2a\udbdf\ude55\udb03\udfe2\uda88\udfb6",
        46, -1000, 143917056, -949217798094507376L, 30306L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe0823646000d0aL), Double.longBitsToDouble(0x3fe920207151f0d3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 5, 10, "\ud89f\uddc8\u5337\udb48\udd45\ud992\udc61\uda87\uddc8\uda0a\udc83\ud992\udd58\ud846\udfd4\ud934\udc8d\ub3ce\udb84\udf54\uda9c\udcfd\ud873\udfc4\udb7f\udd2a\udbd5\uddce\ud9f0\udd4f\ud886\udd01\ud96b\ude42\uda58\udc1f\uda65\uddce\udb3c\udc0f\ud37c\uda1f\udc26\uda1a\ude2b\udbc0\udd81\ud895\ude31\ud9a0\udfad\ud88f\ude0c\uda4b\ude02\udb89\udf99\u4d55\udb61\udfdf\udafe\ude87\ud8e9\udf8b\udae4\udd80", "\ua34b\u6e73\uba41\u6b21\u4db0", "\ud97b\udf43\udbcc\udc0e\ud5d2\ud8c9\udfe1\udaa8\udef1\udb38\udf08\ud9dd\udd47\udb40\ude2a\udbdf\ude55\udb03\udfe2\uda88\udfb6",
        52, 75151, 143935976, -949217798094507376L, 30306L, true, false, (char) 56633, (char) 30209,
        Double.longBitsToDouble(0x3fe082364639370aL), Double.longBitsToDouble(0x3fe920207151f0d3L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udbba\udfaa", "\ubd15", "\ud992\udcfd\ud841\uded4\udb5e\uddc3",
        38, 26817, 459704320, 19887815999357042L, -100000L, true, false, (char) 13, (char) 15963,
        Double.longBitsToDouble(0x3fe954b66f7f70b9L), Double.longBitsToDouble(0x3fd8519990dad0ccL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u1204", "\udbb3\udfff\ud992\udcfd\ud846\udfd4\ud934\udc8d\ub3ce\udb84\udf54\ud95e\udd9d\ud873\udfe1,\000\u1884\u00a3",
        -5, 91371, 1891198762, 1844619319294989701L, -51977L, false, false, (char) 43625, (char) 42539,
        Double.longBitsToDouble(0x3fbc89fff65270c0L), Double.longBitsToDouble(0x3fd8fab884d32e14L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 5, 0, "\udbba\udfaa", "\u493b", "\ud992\udcfd\ud841\uded4\udb5e\uddc3",
        38, 26817, 459704320, 19887815999357042L, -76448L, false, false, (char) 10, (char) 28889,
        Double.longBitsToDouble(0x3fd8d41bfe367b1aL), Double.longBitsToDouble(0x3fd8519d49b65cccL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVFormat|printAndQuote|java.lang.Object,java.lang.CharSequence,int,int,java.lang.Appendable,boolean|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|equals|java.lang.Object|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|format|[Ljava.lang.Object;|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getAllowMissingColumnNames||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getCommentMarker||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getDelimiter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getEscapeCharacter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getHeader||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getHeaderComments||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreEmptyLines||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreHeaderCase||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreSurroundingSpaces||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getNullString||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuoteCharacter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuoteMode||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getRecordSeparator||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|printAndQuote|java.lang.Object,java.lang.CharSequence,int,int,java.lang.Appendable,boolean|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.Object;,[Ljava.lang.String;,boolean,boolean,boolean,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
