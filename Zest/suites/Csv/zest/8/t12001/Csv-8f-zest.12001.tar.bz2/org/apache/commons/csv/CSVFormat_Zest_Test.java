package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Character:\u01ad |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u97fb> Escape=<\u01ad> QuoteChar=<\u01ad> CommentStart=<\u97fb> NullString=<\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udb24\udeef\udbfa\udc54> SkipHeaderRecord:false Header:[\ud8d4\udf76]\012",
        Z.run(T, 1, 11, 9, 2, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udb24\udeef\udbfa\udc54", "\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd", "\ud8d4\udf76",
        47, 73823, 667669011, 1639371006149026012L, 78945L, false, false, (char) 38907, (char) 429,
        Double.longBitsToDouble(0x3fd5217314fcdd12L), Double.longBitsToDouble(0x3fec6cc263db224dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Character:\u0184 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ua5fb> Escape=<\u0184> QuoteChar=<\u0184> CommentStart=<\ua5fb> NullString=<\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd> RecordSeparator=<\000\000\ud9de\udf0e\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udb24\udeef\udbfa\udc54> SkipHeaderRecord:false Header:[\ud8d4\udf76]\012",
        Z.run(T, 1, 11, 9, 2, "\000\000\ud9de\udf0e\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udb24\udeef\udbfa\udc54", "\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd", "\ud8d4\udf76",
        47, 73823, 667669011, 54103939250913280L, 31072L, false, false, (char) 42491, (char) 388,
        Double.longBitsToDouble(0x3fd5217314fcdd12L), Double.longBitsToDouble(0x3fec6cc26000224dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Character:\u3bbb |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u65e7> Escape=<\u3bbb> QuoteChar=<\u3bbb> CommentStart=<\u65e7> NullString=<\u1bd5\ub375\u05f4\u3828\u23fb\u0467\u127f\u4ec7\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\udadc\uddd7\udadd\udc3e]\012",
        Z.run(T, 1, 11, 1, 13, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c", "\u1bd5\ub375\u05f4\u3828\u23fb\u0467\u127f\u4ec7\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176", "\udadc\uddd7\udadd\udc3e",
        26, 58150, -1971564239, -5508838951905554773L, -20573L, true, true, (char) 26087, (char) 15291,
        Double.longBitsToDouble(0x3fb3dee1109cd4a8L), Double.longBitsToDouble(0x3fe9f93e58dc16c0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Character:\u55ac |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ub6a3> Escape=<\u55ac> QuoteChar=<\u55ac> CommentStart=<\ub6a3> NullString=<\uc0e4\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828> RecordSeparator=<\uda7e\udd9d> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\012",
        Z.run(T, 1, 11, 9, 2, "\uda7e\udd9d", "\uc0e4\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828", "\uda43\udfe7\udb81\ude8e\udb22\udfc0",
        41, 13409, -2093016555, 3060523903212733742L, -15931L, true, true, (char) 46755, (char) 21932,
        Double.longBitsToDouble(0x3fedbbc1c74ee39eL), Double.longBitsToDouble(0x3fd31cae185314f8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda56\udd2d\udb3e\ude11\udb56\ude98\uda77\udc2c\ud83a\ude44\uda67\udfa7]] |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u82e5> Escape=<\u3bbb> QuoteChar=<\u3bbb> CommentStart=<\u82e5> NullString=<\u1bd5\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\uda56\udd2d\udb3e\ude11\udb56\ude98\uda77\udc2c\ud83a\ude44\uda67\udfa7]\012",
        Z.run(T, 1, 7, 3, 8, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c", "\u1bd5\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176", "\uda56\udd2d\udb3e\ude11\udb56\ude98\uda77\udc2c\ud83a\ude44\uda67\udfa7",
        26, 77343, -1937612308, 7020968373667214091L, -20573L, true, true, (char) 33509, (char) 15291,
        Double.longBitsToDouble(0x3fb3dee1109da4a8L), Double.longBitsToDouble(0x3fe9f93e58dc16c0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 0, 11, 2, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\ude9c\udb7c\uddac\ud983\udc64\uf65c\udaf5\ude53\udb24\udeef\udbfa\udc54", "\u4a27\u84fa\u0467\u00b3\uba07\u4db8\ua407\u7bce\000\000\000\u14be\u7a96\ua9ae\u8549)\000\000\u49c4\uc963\u3382\u5b27\000\u1e0e\000\000", "\ud8d4\udf76",
        47, 73823, 667669011, 54103937314611420L, 78945L, false, false, (char) 42491, (char) 429,
        Double.longBitsToDouble(0x3fd5217314fcdd12L), Double.longBitsToDouble(0x3eb3000000000000L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ub6a3> Escape=<\u55ac> QuoteChar=<\u55ac> CommentStart=<\ub6a3> NullString=<\000> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\000\u7700\000\udb24\udeef\udbfa\udc54> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\012",
        Z.run(T, 1, 7, 9, 2, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\000\u7700\000\udb24\udeef\udbfa\udc54", "\000", "\uda43\udfe7\udb81\ude8e\udb22\udfc0",
        41, 13409, -2093016555, 3060523903212733742L, -15931L, true, true, (char) 46755, (char) 21932,
        Double.longBitsToDouble(0x3fedbbc1c74ee39eL), Double.longBitsToDouble(0x3fd31cae185314f8L)));
  }
  @Test
  public void test7() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test7() throws Throwable {
//     assertEquals("0=java.lang.Integer:-1447067384 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u97fb> Escape=<\u01ad> QuoteChar=<\u01ad> CommentStart=<\u97fb> NullString=<\u3828\u23fb\u0467\u5a77\ubb01\uaf33\ua407\u7b90\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\ua286\uac4a\u0614\u6059\u85e9\uc98c\u3b6f\u53ef\u425b\u6151\u3c95\u83dd> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud963\udcac\ud8a2\uddb8\ud958\udf64\uf65c\ud92e\ude61\ud9e2\udff4\ud975\udedf> SkipHeaderRecord:false\012",
//         Z.run(T, 1, 15, 9, 2, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud963\udcac\ud8a2\uddb8\ud958\udf64\uf65c\ud92e\ude61\ud9e2\udff4\ud975\udedf", "\u3828\u23fb\u0467\u5a77\ubb01\uaf33\ua407\u7b90\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\ua286\uac4a\u0614\u6059\u85e9\uc98c\u3b6f\u53ef\u425b\u6151\u3c95\u83dd", "\ud8d4\udf76",
//         47, 73823, 659804691, 1639371006149026012L, 78945L, false, false, (char) 38907, (char) 429,
//         Double.longBitsToDouble(0x3fd5217314fcdd12L), Double.longBitsToDouble(0x3fec6cc263b4f6b0L)));
//   }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u01ad> Escape=<\u2083> QuoteChar=<\u2083> CommentStart=<\u01ad> NullString=<\u3828\u23fb\uc293\uc903\ubb01\u4db8\ua407\ub8ce\u2639\ucc9c\uc122\u3f3a\u7a5c\ua9ae\u8549\uaba5\u0614\u6059> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9c5\udced\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udbac\udfb3\udbdb\udfc5> SkipHeaderRecord:false Header:[\ud9ab\udf4e\ud9c1\udf9c\uda69\udc6e\udbdc\udf47\uda04\udfb7\ud881\udc2e\ud8d3\udca2\u2c6a\ud8d4\udf76\ud825\udfe8]\012",
        Z.run(T, 1, 2, 15, 1, "\udb8d\udea4\uda8c\ude80\ud9c5\udced\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udbac\udfb3\udbdb\udfc5", "\u3828\u23fb\uc293\uc903\ubb01\u4db8\ua407\ub8ce\u2639\ucc9c\uc122\u3f3a\u7a5c\ua9ae\u8549\uaba5\u0614\u6059", "\ud9ab\udf4e\ud9c1\udf9c\uda69\udc6e\udbdc\udf47\uda04\udfb7\ud881\udc2e\ud8d3\udca2\u2c6a\ud8d4\udf76\ud825\udfe8",
        58, 58011, 381695807, -8316353162804089390L, -4696L, false, false, (char) 429, (char) 8323,
        Double.longBitsToDouble(0x3fe3f3744f8d984cL), Double.longBitsToDouble(0x3fdaac4be8ac21b4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 3, 9, 2, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udb24\udeef\udbfa\udc54", "\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\u43ee\u5710\ua564\uac09\u4649\u5539\u0614\u6059\u85e9\u9e4a\u37c7\u53ef\u425b\u2905\u87b4\u83dd", "\ud8d4\udf76",
        47, 73823, 667669011, 7764266499372900439L, 78945L, false, false, (char) 38907, (char) 429,
        Double.longBitsToDouble(0x3fea90b9887e4408L), Double.longBitsToDouble(0x3fec6cc263db224dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVFormat:Delimiter=<\u97fb> Escape=<\u01ad> QuoteChar=<\u01ad> CommentStart=<\u97fb> NullString=<\u3828\u13d1\uc9a2\u0ce8\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udb24\udeef\udbfa\udc54> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\uda92\udd55] |a9=[Ljava.lang.String;:[[\uda92\udd55]]\012",
        Z.run(T, 1, 1, 1, 2, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udb24\udeef\udbfa\udc54", "\u3828\u13d1\uc9a2\u0ce8\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd", "\uda92\udd55",
        19, 73823, 667669011, 1639371006149026012L, -89599L, true, true, (char) 38907, (char) 429,
        Double.longBitsToDouble(0x3fb8cc0c613f6598L), Double.longBitsToDouble(0x3fec6cc263db224dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVFormat:Delimiter=<\ueca3> Escape=<\u55ac> QuoteChar=<\u55ac> CommentStart=<\ueca3> NullString=<\uc5b7> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\udb82\udfff\udb76\udcc1\ud9cd\udda9\udbd9\udea5\udaf5\ude69\ud8be\udc36\udaf5\udf3f> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\012",
        Z.run(T, 1, 1, 2, 2, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\udb82\udfff\udb76\udcc1\ud9cd\udda9\udbd9\udea5\udaf5\ude69\ud8be\udc36\udaf5\udf3f", "\uc5b7", "\uda43\udfe7\udb81\ude8e\udb20\udebd",
        41, 13409, -2093016555, 3060523903212733742L, -15931L, true, true, (char) 60579, (char) 21932,
        Double.longBitsToDouble(0x3fc6ef07113b8c10L), Double.longBitsToDouble(0x3fd31cae185314f8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.csv.Quote:NONE |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u97fb> Escape=<\u5dad> QuoteChar=<\u5dad> CommentStart=<\u97fb> NullString=<\u3828\u23fb\u0467\u127f\ubb01\u4db8\ub29f\u54b9\u2639\ucc9c\uc122\u967f\ua717\u97c7\u8161\u433d\u8d30\u4f87\u85e9\uc98c\u3382\u08ef\u425b\u2905\u87b4\ub6f7> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud895\ude53\ud996\udc45\udb7c\uddac\ud91b\uddb0\ud92e\udd07\u0579\ud89d\udc01\udbfa\udc54> SkipHeaderRecord:false Header:[\ud8d4\udf76]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u97fb> Escape=<\u5dad> QuoteChar=<\u5dad> CommentStart=<\u97fb> NullString=<\u3828\u23fb\u0467\u127f\ubb01\u4db8\ub29f\u54b9\u2639\ucc9c\uc122\u967f\ua717\u97c7\u8161\u433d\u8d30\u4f87\u85e9\uc98c\u3382\u08ef\u425b\u2905\u87b4\ub6f7> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud895\ude53\ud996\udc45\udb7c\uddac\ud91b\uddb0\ud92e\udd07\u0579\ud89d\udc01\udbfa\udc54> SkipHeaderRecord:false Header:[\ud8d4\udf76]\012",
        Z.run(T, 2, 12, 9, 2, "\udb8d\udea4\uda8c\ude80\ud895\ude53\ud996\udc45\udb7c\uddac\ud91b\uddb0\ud92e\udd07\u0579\ud89d\udc01\udbfa\udc54", "\u3828\u23fb\u0467\u127f\ubb01\u4db8\ub29f\u54b9\u2639\ucc9c\uc122\u967f\ua717\u97c7\u8161\u433d\u8d30\u4f87\u85e9\uc98c\u3382\u08ef\u425b\u2905\u87b4\ub6f7", "\ud8d4\udf76",
        47, 73823, 667669011, 1639371006149026012L, 67937L, false, false, (char) 38907, (char) 23981,
        Double.longBitsToDouble(0x3fd7817314fdd312L), Double.longBitsToDouble(0x3fd6600e0d490ea6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\u3828\u23fb\u0467\u60bd\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ufead> Escape=<\u926f> QuoteChar=<\u926f> CommentStart=<\ufead> NullString=<\u3828\u23fb\u0467\u60bd\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd> RecordSeparator=<\udbb9\udfa2\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udb28\uddcb\udb35\udd2a\udbfa\udc54> SkipHeaderRecord:false\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ufead> Escape=<\u926f> QuoteChar=<\u926f> CommentStart=<\ufead> NullString=<\u3828\u23fb\u0467\u60bd\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd> RecordSeparator=<\udbb9\udfa2\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udb28\uddcb\udb35\udd2a\udbfa\udc54> SkipHeaderRecord:false\012",
        Z.run(T, 2, 10, 9, 2, "\udbb9\udfa2\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udb28\uddcb\udb35\udd2a\udbfa\udc54", "\u3828\u23fb\u0467\u60bd\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd", "\ud8d4\udf76",
        47, 73823, 666564115, 1639371006149026012L, 78945L, false, false, (char) 65197, (char) 37487,
        Double.longBitsToDouble(0x3fd5217314fcdd12L), Double.longBitsToDouble(0x3fec6cc263db224dL)));
  }
  @Test
  public void test14() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test14() throws Throwable {
//     assertEquals("0=java.lang.Integer:1456883192 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u6ca8> Escape=<\u6b64> QuoteChar=<\u6b64> CommentStart=<\u6ca8> NullString=<\ub375\u05f4\u3828\u23fb\u0467\u81e7\u4a25\ud038\u7d45\u9039\ucdc0\u9830> RecordSeparator=<\ud9ca\ude0d\ud85f\udd09\uda6c\ude7d\udb30\udc51\udadb\udcff\ud864\uddd1\uda9f\udd94\udb0f\udd3e> SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\ud813\udf44\ud9ad\ude46\udade\ude8b\udadd\udc3e\ud82c\udd12\uda7c\udedc\ud885\udd09\uda67\udff8\ud9ab\udf4e\u866d\ud810\udd46]\012",
//         Z.run(T, 1, 15, 9, 2, "\ud9ca\ude0d\ud85f\udd09\uda6c\ude7d\udb30\udc51\udadb\udcff\ud864\uddd1\uda9f\udd94\udb0f\udd3e", "\ub375\u05f4\u3828\u23fb\u0467\u81e7\u4a25\ud038\u7d45\u9039\ucdc0\u9830", "\ud813\udf44\ud9ad\ude46\udade\ude8b\udadd\udc3e\ud82c\udd12\uda7c\udedc\ud885\udd09\uda67\udff8\ud9ab\udf4e\u866d\ud810\udd46",
//         48, 11635, 542477707, 8380414142695712121L, -91653L, true, false, (char) 27816, (char) 27492,
//         Double.longBitsToDouble(0x3f9a16c0b28f8fa0L), Double.longBitsToDouble(0x3fe80a02ee9a26d2L)));
//   }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Character:\u01ad |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ufb86> Escape=<\u01ad> QuoteChar=<\u01ad> CommentStart=<\ufb86> NullString=<\u3828\ud29c\u9198\u4825\ubb01\u4db8\ua407\u7bce\u2716\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u556c\u85e9\uc98c\u3382\u3402\uaaed\u40e1\u87b4\u83dd> RecordSeparator=<\udb90\udf51\uda8c\ude80\ud9de\udff7\ud948\udf00\udb84\udffe\ud91b\uddb0\uf65c\udaf5\ude53\uc278\udbfa\udc54> EmptyLines:ignored SkipHeaderRecord:false\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ufb86> Escape=<\u01ad> QuoteChar=<\u01ad> CommentStart=<\ufb86> NullString=<\u3828\ud29c\u9198\u4825\ubb01\u4db8\ua407\u7bce\u2716\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u556c\u85e9\uc98c\u3382\u3402\uaaed\u40e1\u87b4\u83dd> RecordSeparator=<\udb90\udf51\uda8c\ude80\ud9de\udff7\ud948\udf00\udb84\udffe\ud91b\uddb0\uf65c\udaf5\ude53\uc278\udbfa\udc54> EmptyLines:ignored SkipHeaderRecord:false\012",
        Z.run(T, 2, 11, 9, 7, "\udb90\udf51\uda8c\ude80\ud9de\udff7\ud948\udf00\udb84\udffe\ud91b\uddb0\uf65c\udaf5\ude53\uc278\udbfa\udc54", "\u3828\ud29c\u9198\u4825\ubb01\u4db8\ua407\u7bce\u2716\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u0614\u556c\u85e9\uc98c\u3382\u3402\uaaed\u40e1\u87b4\u83dd", "\ud8d4\udf76",
        8, 73823, 667651859, 1639371008447504604L, 78945L, false, true, (char) 64390, (char) 429,
        Double.longBitsToDouble(0x3fd521731efcdd12L), Double.longBitsToDouble(0x3fec6cc29bdb224dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Character:\u01c8 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u5cc4> Escape=<\u01c8> QuoteChar=<\u01c8> CommentStart=<\u5cc4> NullString=<\u3828\u23fb\u0467\u127f\ubb01\u4db8\u061e\u6f8f\ucec4\ucc9c]\u2386\ub2b5\ucab7\u7d1e\uaba5\u0614\u881a\u85e9\uc98c\u0840\ub623\u425b\u2905\u7093\ud215> RecordSeparator=<\ud99f\ude3c\ud889\ude75\ud9de\udf41\udab3\udeda\ud88d\udd10\uda48\udf0a\udbb3\udcb4\udaf5\ude53\udb24\udefc\udb68\udceb> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\ud8d4\udf76]\0121=[Ljava.lang.String;:[[\ud8d4\udf76]] |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u5cc4> Escape=<\u01c8> QuoteChar=<\u01c8> CommentStart=<\u5cc4> NullString=<\u3828\u23fb\u0467\u127f\ubb01\u4db8\u061e\u6f8f\ucec4\ucc9c]\u2386\ub2b5\ucab7\u7d1e\uaba5\u0614\u881a\u85e9\uc98c\u0840\ub623\u425b\u2905\u7093\ud215> RecordSeparator=<\ud99f\ude3c\ud889\ude75\ud9de\udf41\udab3\udeda\ud88d\udd10\uda48\udf0a\udbb3\udcb4\udaf5\ude53\udb24\udefc\udb68\udceb> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\ud8d4\udf76]\012",
        Z.run(T, 2, 11, 7, 2, "\ud99f\ude3c\ud889\ude75\ud9de\udf41\udab3\udeda\ud88d\udd10\uda48\udf0a\udbb3\udcb4\udaf5\ude53\udb24\udefc\udb68\udceb", "\u3828\u23fb\u0467\u127f\ubb01\u4db8\u061e\u6f8f\ucec4\ucc9c]\u2386\ub2b5\ucab7\u7d1e\uaba5\u0614\u881a\u85e9\uc98c\u0840\ub623\u425b\u2905\u7093\ud215", "\ud8d4\udf76",
        47, 73823, 667669011, 1639371006149026012L, 78945L, true, true, (char) 23748, (char) 456,
        Double.longBitsToDouble(0x3fd5217314fcdd12L), Double.longBitsToDouble(0x3fec6cc263db224dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\uf473> Escape=<\u7b59> QuoteChar=<\u7b59> CommentStart=<\uf473> NullString=<\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2c79\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u8604\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd\u581a/\u9203\u52ff\u281c\u913d\uc235\u4812\u621b\u3e55\u6157\ua55e\u4401\ub453\u4795\u1035\ud6ca\u3e41\ua455\u37f8\u589c\u573c\u0308\u3a4a\uac68\u3bc6> RecordSeparator=<\udb8d\udea4\uda8c\ude80> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\0121=org.apache.commons.csv.Quote:ALL |this=org.apache.commons.csv.CSVFormat:Delimiter=<\uf473> Escape=<\u7b59> QuoteChar=<\u7b59> CommentStart=<\uf473> NullString=<\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2c79\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u8604\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd\u581a/\u9203\u52ff\u281c\u913d\uc235\u4812\u621b\u3e55\u6157\ua55e\u4401\ub453\u4795\u1035\ud6ca\u3e41\ua455\u37f8\u589c\u573c\u0308\u3a4a\uac68\u3bc6> RecordSeparator=<\udb8d\udea4\uda8c\ude80> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\012",
        Z.run(T, 2, 2, 12, 1, "\udb8d\udea4\uda8c\ude80", "\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2c79\ucc9c\uc122\u0176\u7a96\ua9ae\u8549\uaba5\u8604\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd\u581a/\u9203\u52ff\u281c\u913d\uc235\u4812\u621b\u3e55\u6157\ua55e\u4401\ub453\u4795\u1035\ud6ca\u3e41\ua455\u37f8\u589c\u573c\u0308\u3a4a\uac68\u3bc6", "\ud93f\udf23\ud803\udeb6\udab4\udc76\udaca\udd05\ud9a7\udc03",
        -4, 96744, -1991831821, -2876568996303885200L, 26342L, true, true, (char) 62579, (char) 31577,
        Double.longBitsToDouble(0x3fe3d8c769360750L), Double.longBitsToDouble(0x3fd4dd00a20598c2L)));
  }
  @Test
  public void test18() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test18() throws Throwable {
//     assertEquals("0=java.lang.Integer:-1781592671 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u6fe6> Escape=<\u3bbb> QuoteChar=<\u3bbb> CommentStart=<\u6fe6> NullString=<\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\uda77\udc2c]\012",
//         Z.run(T, 1, 15, 0, 9, "\udb8d\udea4\uda8c\ude80\ud9de\udff7", "\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176\u7a96\ua9ae\u8549", "\uda77\udc2c",
//         26, 72481, 181767851, -4329829345615799491L, -20573L, true, true, (char) 28646, (char) 15291,
//         Double.longBitsToDouble(0x3fb3dee1109cd4a8L), Double.longBitsToDouble(0x3fe9f93e58dc16c0L)));
//   }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\u9700\u2bc6\u14b2\u7026\u3131\u0467\u127f\u4ec7\u843c\uae8c\u41cc\ua577\u478d\uc122\u0176 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u65e7> Escape=<\u3bbb> QuoteChar=<\u3bbb> CommentStart=<\u65e7> NullString=<\u9700\u2bc6\u14b2\u7026\u3131\u0467\u127f\u4ec7\u843c\uae8c\u41cc\ua577\u478d\uc122\u0176> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\uda5c\ude1b\ud86a\udd2f\udb0e\udf37> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\udadc\uddd7\udadd\udc3e]\0121=new org.apache.commons.csv.CSVFormat:Delimiter=<\u65e7> Escape=<\u3bbb> QuoteChar=<\u3bbb> CommentStart=<\u65e7> NullString=<\u9700\u2bc6\u14b2\u7026\u3131\u0467\u127f\u4ec7\u843c\uae8c\u41cc\ua577\u478d\uc122\u0176> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\uda5c\ude1b\ud86a\udd2f\udb0e\udf37> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\udadc\uddd7\udadd\udc3e] |a9=[Ljava.lang.String;:[[\udadc\uddd7\udadd\udc3e]]\012",
        Z.run(T, 2, 10, 1, 13, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\uda5c\ude1b\ud86a\udd2f\udb0e\udf37", "\u9700\u2bc6\u14b2\u7026\u3131\u0467\u127f\u4ec7\u843c\uae8c\u41cc\ua577\u478d\uc122\u0176", "\udadc\uddd7\udadd\udc3e",
        28, 58150, -1971564239, -5508838951905554773L, -20573L, true, true, (char) 26087, (char) 15291,
        Double.longBitsToDouble(0x3fb3dee1109cd4a8L), Double.longBitsToDouble(0x3fe9f93e58dc16c0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 16, 9, 13, "\udb8d\udea4\udbc7\udcbd\000\000\udb7c\uddac\ud91b\uddb0\uf65c", "\u1bd5\ub375\u05f4\u3828\u23fb\u8467\u271c\u4ec7\u4db8\ua407\u7bce\u2639\ucc9c\uc122\u0176", "\udadc\udce6",
        36, 70311, 14804814, -8467803929750754263L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe84c1806432056L), Double.longBitsToDouble(0x3fd79744dfbbdc12L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Character:\u8292 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u4e7c> Escape=<\u8292> QuoteChar=<\u8292> CommentStart=<\u4e7c> NullString=<\u7618\ub6f3\u5874\u41c9> RecordSeparator=<\uda7e\udd5a\uda8c\ude80\ud9de\udff7\ud940\udc00\udb7c\uddac\udaa3\udd15\uf65c\udaf5\ude53\ud92d\udc35\udbf9\udfb3\ud9b2\udea0\ud973\udf29\udacf\udc72\udb5b\udf31\udb83\udd6c\uda43\udfe7\udb81\ude8e\udb22\udfc0\ud9fd\udd94\ud89a\ude85\udb90\udeba\udb0d\udcc6\ud9f8\uddc0\u90c8\ud813\udf44\udac4\udfff\udadc\uddd7\udadd\udc3e\udb4f\ude0a\uda77\udc2c\ud835\udda3\ud964\udee4\ud99e\ude4c\ud9ba\udc4c\udbf6\udcfd\udb25\udf5d\ud9d1\uddd3\ud87e\udc87\udb1b\ude6b\uda27\udd9b\uc47a\uda0f\ude9a\ud9d5\udcc1\u9ad3\udbe1\uddc4\ud88e\udeeb\uda6c\udd5a\uda98\udfd2\ud828\udd06\ud985\udced\ud8c4\udc88\ud96b\udcce\udb0e\uddb9\udb64\udf82\udb87\udd15\ud85e\udd0f\udae0\udf37\ud954\udd81\udafe\udf26\udaa8\udc1f\udb02\udf83\ud87a\udc4f\uda15\uded9\ud8d7\ude58\udbbe\udc97\uda10\ude93> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\udbbf\udef3\u458a\ud941...\012",
        Z.run(T, 1, 11, 9, 2, "\uda7e\udd5a\uda8c\ude80\ud9de\udff7\ud940\udc00\udb7c\uddac\udaa3\udd15\uf65c\udaf5\ude53\ud92d\udc35\udbf9\udfb3\ud9b2\udea0\ud973\udf29\udacf\udc72\udb5b\udf31\udb83\udd6c\uda43\udfe7\udb81\ude8e\udb22\udfc0\ud9fd\udd94\ud89a\ude85\udb90\udeba\udb0d\udcc6\ud9f8\uddc0\u90c8\ud813\udf44\udac4\udfff\udadc\uddd7\udadd\udc3e\udb4f\ude0a\uda77\udc2c\ud835\udda3\ud964\udee4\ud99e\ude4c\ud9ba\udc4c\udbf6\udcfd\udb25\udf5d\ud9d1\uddd3\ud87e\udc87\udb1b\ude6b\uda27\udd9b\uc47a\uda0f\ude9a\ud9d5\udcc1\u9ad3\udbe1\uddc4\ud88e\udeeb\uda6c\udd5a\uda98\udfd2\ud828\udd06\ud985\udced\ud8c4\udc88\ud96b\udcce\udb0e\uddb9\udb64\udf82\udb87\udd15\ud85e\udd0f\udae0\udf37\ud954\udd81\udafe\udf26\udaa8\udc1f\udb02\udf83\ud87a\udc4f\uda15\uded9\ud8d7\ude58\udbbe\udc97\uda10\ude93", "\u7618\ub6f3\u5874\u41c9", "\udbbf\udef3\u458a\ud941\ude90\udba4\ude03\ud885\ude6d",
        42, 76211, 399975545, 463109245692431820L, 40145L, true, true, (char) 20092, (char) 33426,
        Double.longBitsToDouble(0x3fefd83aceaad74aL), Double.longBitsToDouble(0x3fe16598e0037778L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Character:\u55ac |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ub6a3> Escape=<\u55ac> QuoteChar=<\u55ac> CommentStart=<\ub6a3> NullString=<\uc0e4\uaaee\ub777\u1798\ub25a\u630f\u1bd5\ub375\u05f4\u3828> RecordSeparator=<\udaa8\udf9d> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\uda43\udfe7\ud9b0\udead\uda9d\udcff]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 16, 5, "\udaa8\udf9d", "\uc0e4\uaaee\ub777\u1798\ub25a\u630f\u1bd5\ub375\u05f4\u3828", "\uda43\udfe7\ud9b0\udead\uda9d\udcff",
        22, 29164, -2092957931, 3060523903205038524L, -15931L, true, true, (char) 46755, (char) 21932,
        Double.longBitsToDouble(0x3fedbbc1c74ee39eL), Double.longBitsToDouble(0x3fd31cae18531542L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ub6a3> Escape=<\u55ac> QuoteChar=<\u55ac> CommentStart=<\ub6a3> NullString=<\uc0e4\uaaee\ub777\u1798\ub25a\ua0f7\ud0d3\u82d8\u05f4\u3828> RecordSeparator=<\uda7e\udd9d> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\0121=null |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ub6a3> Escape=<\u55ac> QuoteChar=<\u55ac> CommentStart=<\ub6a3> NullString=<\uc0e4\uaaee\ub777\u1798\ub25a\ua0f7\ud0d3\u82d8\u05f4\u3828> RecordSeparator=<\uda7e\udd9d> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\012",
        Z.run(T, 2, 7, 7, 3, "\uda7e\udd9d", "\uc0e4\uaaee\ub777\u1798\ub25a\ua0f7\ud0d3\u82d8\u05f4\u3828", "\uda43\udfe7\udb81\ude8e\udb22\udfc0",
        41, 13409, -2093016555, 3060523903212733742L, -15931L, true, true, (char) 46755, (char) 21932,
        Double.longBitsToDouble(0x3fedbbc1c74ee39eL), Double.longBitsToDouble(0x3fd31cae185314f8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVFormat:Delimiter=<\ub6a3> Escape=<\u55ac> QuoteChar=<\u55ac> CommentStart=<\ub6a3> NullString=<\uc0e4\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\ua8f3\u3828> RecordSeparator=<\uda7e\udd9d> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\0121=java.lang.Boolean:true |this=org.apache.commons.csv.CSVFormat:Delimiter=<\ub6a3> Escape=<\u55ac> QuoteChar=<\u55ac> CommentStart=<\ub6a3> NullString=<\uc0e4\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\ua8f3\u3828> RecordSeparator=<\uda7e\udd9d> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\012",
        Z.run(T, 2, 1, 9, 2, "\uda7e\udd9d", "\uc0e4\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\ua8f3\u3828", "\uda43\udfe7\udb81\ude8e\uda67\udcf2",
        41, 13409, -2093016555, -2070521930151900515L, -15931L, true, true, (char) 46755, (char) 21932,
        Double.longBitsToDouble(0x3fe5bbc1c7237cb7L), Double.longBitsToDouble(0x3fe8b25fb790fde2L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbd0\udd2a\udb3e\ude11\udb56\ude98\uda77\udc2c\ud83a\ude44\uda67\udfa7]] |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u82e5> Escape=<\u3bbb> QuoteChar=<\u3bbb> CommentStart=<\u82e5> NullString=<\u1bd5\ub375\u3aff\u3828\u23fb\u0467\u2f80\u129d\u2262\ua407\u7bce\u2639\ucc9c\uc122\u0176> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\udbd0\udd2a\udb3e\ude11\udb56\ude98\uda77\udc2c\ud83a\ude44\uda67\udfa7]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 3, 11, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c", "\u1bd5\ub375\u3aff\u3828\u23fb\u0467\u2f80\u129d\u2262\ua407\u7bce\u2639\ucc9c\uc122\u0176", "\udbd0\udd2a\udb3e\ude11\udb56\ude98\uda77\udc2c\ud83a\ude44\uda67\udfa7",
        26, 77343, -1937612308, 7020968376250905355L, -80038L, true, true, (char) 33509, (char) 15291,
        Double.longBitsToDouble(0x3fb3dee13add1ca8L), Double.longBitsToDouble(0x3fe9f93e58dc16c0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVFormat:Delimiter=<\u5c94> Escape=<\u10db> QuoteChar=<\u10db> CommentStart=<\u5c94> NullString=<\u3828\u13d1\uc9a2\u0ce8\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\u496e\u75ce\u7ab8\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\udf11\ud855\udf2d\udbef\uddf6> SkipHeaderRecord:false Header:[\uda92\udd55] |a9=[Ljava.lang.String;:[[\uda92\udd55]]\0121=new org.apache.commons.csv.CSVFormat:Delimiter=<\u5c94> Escape=<\u10db> QuoteChar=<\u10db> CommentStart=<\u5c94> NullString=<\u3828\u13d1\uc9a2\u0ce8\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\u496e\u75ce\u7ab8\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd> RecordSeparator=<\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\udf11\ud855\udf2d\udbef\uddf6> SkipHeaderRecord:false Header:[\uda92\udd55] |a9=[Ljava.lang.String;:[[\uda92\udd55]]\012",
        Z.run(T, 2, 1, 1, 2, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\udf11\ud855\udf2d\udbef\uddf6", "\u3828\u13d1\uc9a2\u0ce8\ubb01\u4db8\ua407\u7bce\u2639\ucc9c\u496e\u75ce\u7ab8\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd", "\uda92\udd55",
        19, 73823, 667669011, -4815694634882070143L, 34602L, false, false, (char) 23700, (char) 4315,
        Double.longBitsToDouble(0x3fd9aec76099a2b2L), Double.longBitsToDouble(0x3fc0283faf3acc38L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVFormat:Delimiter=<\u1c13> Escape=<\u36a5> QuoteChar=<\u36a5> CommentStart=<\u1c13> NullString=<\uc5b7> RecordSeparator=<\ud8d9\udd36\ud9cd\udfa9\uda81\ude25\ud8a4\udecc\ud8ee\uddad\ud9cd\udda9\udbd9\udea5\udaf5\ude69\ud8be\udc36\udae3\uddf7> SkipHeaderRecord:false\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u1c13> Escape=<\u36a5> QuoteChar=<\u36a5> CommentStart=<\u1c13> NullString=<\uc5b7> RecordSeparator=<\ud8d9\udd36\ud9cd\udfa9\uda81\ude25\ud8a4\udecc\ud8ee\uddad\ud9cd\udda9\udbd9\udea5\udaf5\ude69\ud8be\udc36\udae3\uddf7> SkipHeaderRecord:false\012",
        Z.run(T, 2, 1, 2, 2, "\ud8d9\udd36\ud9cd\udfa9\uda81\ude25\ud8a4\udecc\ud8ee\uddad\ud9cd\udda9\udbd9\udea5\udaf5\ude69\ud8be\udc36\udae3\uddf7", "\uc5b7", "\uda43\udfe7\udb81\ude8e\udb20\udebd",
        41, 13409, -2093016555, 3060523903212733742L, -38377L, false, false, (char) 7187, (char) 13989,
        Double.longBitsToDouble(0x3fe3f28dcdb50915L), Double.longBitsToDouble(0x3fc1feeee9f0e3e4L)));
  }
  @Test
  public void test28() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test28() throws Throwable {
//     assertEquals("0=java.lang.Integer:-1872987342 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u9789> Escape=<\ue9a0> QuoteChar=<\ue9a0> CommentStart=<\u9789> NullString=<\u3828\u23fb\u0443\ua4de\ud44d\u5ffc\u7c50\u54aa\u2639\u1489\u316b\u2b91\ua6fc\u97c7\u8161\u433d\u8d30\u8c10\u6279\u025f\u3301\u08ef\u425b\u2905\u3679\u4b22> RecordSeparator=<\ud90e\udf85\uda7e\udd46\ud892\udff0\ud999\udd79\ud87a\udde5\ud91b\udda7\ud92e\udd07\u0579\ud9b2\udd0d\udbe4\udc36> EmptyLines:ignored SkipHeaderRecord:false Header:[\ud9dc\udefa]\0121=java.lang.Integer:-1872987342 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u9789> Escape=<\ue9a0> QuoteChar=<\ue9a0> CommentStart=<\u9789> NullString=<\u3828\u23fb\u0443\ua4de\ud44d\u5ffc\u7c50\u54aa\u2639\u1489\u316b\u2b91\ua6fc\u97c7\u8161\u433d\u8d30\u8c10\u6279\u025f\u3301\u08ef\u425b\u2905\u3679\u4b22> RecordSeparator=<\ud90e\udf85\uda7e\udd46\ud892\udff0\ud999\udd79\ud87a\udde5\ud91b\udda7\ud92e\udd07\u0579\ud9b2\udd0d\udbe4\udc36> EmptyLines:ignored SkipHeaderRecord:false Header:[\ud9dc\udefa]\012",
//         Z.run(T, 2, 15, 15, 14, "\ud90e\udf85\uda7e\udd46\ud892\udff0\ud999\udd79\ud87a\udde5\ud91b\udda7\ud92e\udd07\u0579\ud9b2\udd0d\udbe4\udc36", "\u3828\u23fb\u0443\ua4de\ud44d\u5ffc\u7c50\u54aa\u2639\u1489\u316b\u2b91\ua6fc\u97c7\u8161\u433d\u8d30\u8c10\u6279\u025f\u3301\u08ef\u425b\u2905\u3679\u4b22", "\ud9dc\udefa",
//         18, 73823, 382456339, 1593025981152911580L, 91385L, false, true, (char) 38793, (char) 59808,
//         Double.longBitsToDouble(0x3fb5d5899db98e28L), Double.longBitsToDouble(0x3fd6600e0cfb0ea6L)));
//   }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud8d4\udf76\ud999\udfe2\udbf0\ude54\ud967\udc6b\ud8be\udc96\udb3c\ude0e\ud99a\udd10\ud951\udff1\ud977\ude32\ud997\udd50\udba4\udde1\uda4b\udfd5\ud9d1\udc61\ud9f6\udd92\udac9\ude8b\udb6a\udcb9\uda27\uddd1]] |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u875e> Escape=<\ub381> QuoteChar=<\ub381> CommentStart=<\u875e> NullString=<\u3828\u23fb\u0467\u127f\ubb01\u4db8\u061e\u6f8f\ucec4\ucc9c]\u2386\ub2b5\u27fc\u7d1e\ua1a5\u0614\u881a\u85e9\uc98c\u0840\ub623\u425b\u2905\u7093\ud215> RecordSeparator=<\ud99f\ude3c\ud889\ude75\ud9de\udf41\ud8a9\udf35\ud8b8\udcb0\uda48\udf0a\udbb3\udcb4\udaf5\ude53\udb24\udefc\udb68\udceb> SkipHeaderRecord:false Header:[\ud8d4\udf76\ud999\udfe2\udbf0\ude54\ud967\udc6b\ud8be\udc96\udb3c\ude0e\ud99a\udd10\ud951\udff1\ud977\ude32\ud997\udd50\udba4\udde1\uda4b\udfd5\ud9d1\udc61\ud9f6\udd92\udac9\ude8b\udb6a\udcb9\uda27\uddd1]\0121=[Ljava.lang.String;:[[\ud8d4\udf76\ud999\udfe2\udbf0\ude54\ud967\udc6b\ud8be\udc96\udb3c\ude0e\ud99a\udd10\ud951\udff1\ud977\ude32\ud997\udd50\udba4\udde1\uda4b\udfd5\ud9d1\udc61\ud9f6\udd92\udac9\ude8b\udb6a\udcb9\uda27\uddd1]] |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u875e> Escape=<\ub381> QuoteChar=<\ub381> CommentStart=<\u875e> NullString=<\u3828\u23fb\u0467\u127f\ubb01\u4db8\u061e\u6f8f\ucec4\ucc9c]\u2386\ub2b5\u27fc\u7d1e\ua1a5\u0614\u881a\u85e9\uc98c\u0840\ub623\u425b\u2905\u7093\ud215> RecordSeparator=<\ud99f\ude3c\ud889\ude75\ud9de\udf41\ud8a9\udf35\ud8b8\udcb0\uda48\udf0a\udbb3\udcb4\udaf5\ude53\udb24\udefc\udb68\udceb> SkipHeaderRecord:false Header:[\ud8d4\udf76\ud999\udfe2\udbf0\ude54\ud967\udc6b\ud8be\udc96\udb3c\ude0e\ud99a\udd10\ud951\udff1\ud977\ude32\ud997\udd50\udba4\udde1\uda4b\udfd5\ud9d1\udc61\ud9f6\udd92\udac9\ude8b\udb6a\udcb9\uda27\uddd1]\012",
        Z.run(T, 2, 7, 7, 2, "\ud99f\ude3c\ud889\ude75\ud9de\udf41\ud8a9\udf35\ud8b8\udcb0\uda48\udf0a\udbb3\udcb4\udaf5\ude53\udb24\udefc\udb68\udceb", "\u3828\u23fb\u0467\u127f\ubb01\u4db8\u061e\u6f8f\ucec4\ucc9c]\u2386\ub2b5\u27fc\u7d1e\ua1a5\u0614\u881a\u85e9\uc98c\u0840\ub623\u425b\u2905\u7093\ud215", "\ud8d4\udf76\ud999\udfe2\udbf0\ude54\ud967\udc6b\ud8be\udc96\udb3c\ude0e\ud99a\udd10\ud951\udff1\ud977\ude32\ud997\udd50\udba4\udde1\uda4b\udfd5\ud9d1\udc61\ud9f6\udd92\udac9\ude8b\udb6a\udcb9\uda27\uddd1",
        2, 16224, -2107873618, -4062720903940094539L, -84380L, false, false, (char) 34654, (char) 45953,
        Double.longBitsToDouble(0x3fe47336451b0e11L), Double.longBitsToDouble(0x3f9d809e6acd0ec0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u88af> Escape=<\ubd00> QuoteChar=<\ubd00> CommentStart=<\u88af> NullString=<\uaaee\ub777\u1798\ub25a\uad3e\u2c6d\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\uccb7\ua44a\u7bce\u2c79\u94e8\uc12a\u0176\u7a96\ua9ae\u8549\uaba5\u8604\u3f85\u85e9\ud6c5\u1b13\u53ef\u32eb\u2905\u87b4\u83dd\u211b/\u9203\u52ff\u281c\u913d\ua1d5\u4812\u621b\u3e55\u1e8b\ua55e\u4401\ub453\u4795\u1035\ud6ca\u3e41\ua455\u4672\u93e0\u5503\u642a\u0ae2\u36c5\u3ba8> RecordSeparator=<\udb8d\udea4\uda8c\ude80> SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\ud93f\udf23\ud803\udeb6\udab4\udc76\udaca\udd05\ud9a7\udc03]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u88af> Escape=<\ubd00> QuoteChar=<\ubd00> CommentStart=<\u88af> NullString=<\uaaee\ub777\u1798\ub25a\uad3e\u2c6d\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\uccb7\ua44a\u7bce\u2c79\u94e8\uc12a\u0176\u7a96\ua9ae\u8549\uaba5\u8604\u3f85\u85e9\ud6c5\u1b13\u53ef\u32eb\u2905\u87b4\u83dd\u211b/\u9203\u52ff\u281c\u913d\ua1d5\u4812\u621b\u3e55\u1e8b\ua55e\u4401\ub453\u4795\u1035\ud6ca\u3e41\ua455\u4672\u93e0\u5503\u642a\u0ae2\u36c5\u3ba8> RecordSeparator=<\udb8d\udea4\uda8c\ude80> SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\ud93f\udf23\ud803\udeb6\udab4\udc76\udaca\udd05\ud9a7\udc03]\012",
        Z.run(T, 2, 2, 2, 13, "\udb8d\udea4\uda8c\ude80", "\uaaee\ub777\u1798\ub25a\uad3e\u2c6d\ub375\u05f4\u3828\u23fb\u0467\u127f\ubb01\uccb7\ua44a\u7bce\u2c79\u94e8\uc12a\u0176\u7a96\ua9ae\u8549\uaba5\u8604\u3f85\u85e9\ud6c5\u1b13\u53ef\u32eb\u2905\u87b4\u83dd\u211b/\u9203\u52ff\u281c\u913d\ua1d5\u4812\u621b\u3e55\u1e8b\ua55e\u4401\ub453\u4795\u1035\ud6ca\u3e41\ua455\u4672\u93e0\u5503\u642a\u0ae2\u36c5\u3ba8", "\ud93f\udf23\ud803\udeb6\udab4\udc76\udaca\udd05\ud9a7\udc03",
        -4, 85416, 562695923, -3337125486279545744L, 26822L, true, false, (char) 34991, (char) 48384,
        Double.longBitsToDouble(0x3fca09f49d710ff4L), Double.longBitsToDouble(0x3fe3d8c76e360750L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\uf473> Escape=<\u7b59> QuoteChar=<\u7b59> CommentStart=<\uf473> NullString=<\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828\u8f88\uc1a5\u548b\u02ea\u4db8\ua407\u7bce\u2c79\ucc9c\uc122\u0176\u1d41\ua9fa\u8549\uaba5\u8604\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd\u581a\u0ca1\u65fe\u3c3d\uc1e1\u41a1\uc235\u4812\u621b\u3e55\u6157\ua55e\u4401\ub453\u4795\u1035\ud6ca\u3e41\ua455\u37f8\u589c\u573c\u0308\u3a4a\uac68\u3bc6> RecordSeparator=<\udb8d\udea4\uda8c\ude80> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVFormat:Delimiter=<\uf473> Escape=<\u7b59> QuoteChar=<\u7b59> CommentStart=<\uf473> NullString=<\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828\u8f88\uc1a5\u548b\u02ea\u4db8\ua407\u7bce\u2c79\ucc9c\uc122\u0176\u1d41\ua9fa\u8549\uaba5\u8604\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd\u581a\u0ca1\u65fe\u3c3d\uc1e1\u41a1\uc235\u4812\u621b\u3e55\u6157\ua55e\u4401\ub453\u4795\u1035\ud6ca\u3e41\ua455\u37f8\u589c\u573c\u0308\u3a4a\uac68\u3bc6> RecordSeparator=<\udb8d\udea4\uda8c\ude80> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true\012",
        Z.run(T, 2, 2, 2, 1, "\udb8d\udea4\uda8c\ude80", "\uaaee\ub777\u1798\ub25a\uad3e\u1bd5\ub375\u05f4\u3828\u8f88\uc1a5\u548b\u02ea\u4db8\ua407\u7bce\u2c79\ucc9c\uc122\u0176\u1d41\ua9fa\u8549\uaba5\u8604\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd\u581a\u0ca1\u65fe\u3c3d\uc1e1\u41a1\uc235\u4812\u621b\u3e55\u6157\ua55e\u4401\ub453\u4795\u1035\ud6ca\u3e41\ua455\u37f8\u589c\u573c\u0308\u3a4a\uac68\u3bc6", "\ud93f\udf23\ud803\udeb6\udab4\udc76\udaca\udd05\ud9a7\udc03",
        -4, 96744, -1991831821, -2876568996303885200L, 26342L, true, true, (char) 62579, (char) 31577,
        Double.longBitsToDouble(0x3fe3d8c769360750L), Double.longBitsToDouble(0x3fd4dd00a20598c2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Character:\ubd68 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u3cae> Escape=<\ubd68> QuoteChar=<\ubd68> CommentStart=<\u3cae> NullString=<\u7618\ub6f3\u5874z\u0861> RecordSeparator=<\ud831\udd5f\uda8c\ude80\ud9de\udff7\uda75\udffb\udbd1\udf18\uda9e\ude5c\uf65c\udaf5\ude53\ud92d\udc35\udbf9\udfb3\ud9b2\udea0\ud973\udf29\udad4\udc72\udb5b\udf31\udb23\udef7\udacf\udd2b\udb81\ude8e\udb22\udfc0\ud9fd\udd94\ud89a\ude85\udb90\udeba\udb0d\udcc6\ud9f8\uddc0\u90c8\ud813\udf44\udac4\udfff\udadc\uddd7\udadd\udc3e\udb4f\ude0a\udbdf\udd3f\ud86f\udd92\ud92d\udeb4\ud8b6\ude49\ud9ba\udc4c\udbf6\udcfd\udb25\udf5d\ud9d1\uddd3\ud87e\udc87\udb1b\ude6b\uda27\udd9b\uc47a\uda0f\ude9a\ud9d5\udcc1\u9ad3\udbe1\uddc4\ud88e\udeeb\uda6c\udd5a\uda98\udfd2\ud828\udd06\ud985\udced\ud9ec\udf6c\ud96b\udcce\uda4f\udf38\ud9ba\udedf\udb55\ude19\ud85e\udd0f\udae0\udf37\ud954\udd81\udafe\udf26\udaa8\udc1f\udb02\udf83\ud87a\udc4f\uda15\uded9\ud842\udc94\ufa26\ud914\udedb> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\uda3b\udd1a\ud952\udcad...\0121=java.lang.Boolean:true |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u3cae> Escape=<\ubd68> QuoteChar=<\ubd68> CommentStart=<\u3cae> NullString=<\u7618\ub6f3\u5874z\u0861> RecordSeparator=<\ud831\udd5f\uda8c\ude80\ud9de\udff7\uda75\udffb\udbd1\udf18\uda9e\ude5c\uf65c\udaf5\ude53\ud92d\udc35\udbf9\udfb3\ud9b2\udea0\ud973\udf29\udad4\udc72\udb5b\udf31\udb23\udef7\udacf\udd2b\udb81\ude8e\udb22\udfc0\ud9fd\udd94\ud89a\ude85\udb90\udeba\udb0d\udcc6\ud9f8\uddc0\u90c8\ud813\udf44\udac4\udfff\udadc\uddd7\udadd\udc3e\udb4f\ude0a\udbdf\udd3f\ud86f\udd92\ud92d\udeb4\ud8b6\ude49\ud9ba\udc4c\udbf6\udcfd\udb25\udf5d\ud9d1\uddd3\ud87e\udc87\udb1b\ude6b\uda27\udd9b\uc47a\uda0f\ude9a\ud9d5\udcc1\u9ad3\udbe1\uddc4\ud88e\udeeb\uda6c\udd5a\uda98\udfd2\ud828\udd06\ud985\udced\ud9ec\udf6c\ud96b\udcce\uda4f\udf38\ud9ba\udedf\udb55\ude19\ud85e\udd0f\udae0\udf37\ud954\udd81\udafe\udf26\udaa8\udc1f\udb02\udf83\ud87a\udc4f\uda15\uded9\ud842\udc94\ufa26\ud914\udedb> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\uda3b\udd1a\ud952\udcad...\012",
        Z.run(T, 2, 11, 9, 2, "\ud831\udd5f\uda8c\ude80\ud9de\udff7\uda75\udffb\udbd1\udf18\uda9e\ude5c\uf65c\udaf5\ude53\ud92d\udc35\udbf9\udfb3\ud9b2\udea0\ud973\udf29\udad4\udc72\udb5b\udf31\udb23\udef7\udacf\udd2b\udb81\ude8e\udb22\udfc0\ud9fd\udd94\ud89a\ude85\udb90\udeba\udb0d\udcc6\ud9f8\uddc0\u90c8\ud813\udf44\udac4\udfff\udadc\uddd7\udadd\udc3e\udb4f\ude0a\udbdf\udd3f\ud86f\udd92\ud92d\udeb4\ud8b6\ude49\ud9ba\udc4c\udbf6\udcfd\udb25\udf5d\ud9d1\uddd3\ud87e\udc87\udb1b\ude6b\uda27\udd9b\uc47a\uda0f\ude9a\ud9d5\udcc1\u9ad3\udbe1\uddc4\ud88e\udeeb\uda6c\udd5a\uda98\udfd2\ud828\udd06\ud985\udced\ud9ec\udf6c\ud96b\udcce\uda4f\udf38\ud9ba\udedf\udb55\ude19\ud85e\udd0f\udae0\udf37\ud954\udd81\udafe\udf26\udaa8\udc1f\udb02\udf83\ud87a\udc4f\uda15\uded9\ud842\udc94\ufa26\ud914\udedb", "\u7618\ub6f3\u5874z\u0861", "\uda3b\udd1a\ud952\udcad\udba4\ude03\ud885\ude6d\ud989\uddcf\ud9a4\udce1\uda99\udde0\udbd4\udfc8\udbdc\ude10\ud9ee\udfd5",
        13, 3454, -1784288566, 529715547341498363L, -41269L, true, true, (char) 15534, (char) 48488,
        Double.longBitsToDouble(0x3feb936832027abcL), Double.longBitsToDouble(0x3fb0ae8aaec09f20L)));
  }
  @Test
  public void test33() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test33() throws Throwable {
//     assertEquals("0=java.lang.Integer:-638327095 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u5afb> Escape=<\ua41a> QuoteChar=<\ua41a> CommentStart=<\u5afb> NullString=<\u193b\u6fd5\u09da> RecordSeparator=<\udaa8\udf9d\uda4f\udc81\ud80c\udce9\ud948\udf00\udb6f\udfac\uf762\uf627\ud82e\udd37\ud828\udf96\ud924\uddd8\udab2\udd9b\ud9be\udd79> SkipHeaderRecord:false\0121=java.lang.Integer:-638327095 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u5afb> Escape=<\ua41a> QuoteChar=<\ua41a> CommentStart=<\u5afb> NullString=<\u193b\u6fd5\u09da> RecordSeparator=<\udaa8\udf9d\uda4f\udc81\ud80c\udce9\ud948\udf00\udb6f\udfac\uf762\uf627\ud82e\udd37\ud828\udf96\ud924\uddd8\udab2\udd9b\ud9be\udd79> SkipHeaderRecord:false\012",
//         Z.run(T, 2, 15, 15, 9, "\udaa8\udf9d\uda4f\udc81\ud80c\udce9\ud948\udf00\udb6f\udfac\uf762\uf627\ud82e\udd37\ud828\udf96\ud924\uddd8\udab2\udd9b\ud9be\udd79", "\u193b\u6fd5\u09da", "\ud91c\udd44\u9308\udb0d\udcc6\uda4f\ude47\udbda\ude43\uda84\udf7d\udb1b\udfcc\ud940\udfc0\ud9d7\udc3b\udb3a\udeff\ud86e\udc77\ud8f5\ude46\udab0\udd6b\ud9ec\udf6c\ue39e\udaa7\udef7",
//         1, 37807, -562628276, 6880861240136116893L, -56489L, false, false, (char) 23291, (char) 42010,
//         Double.longBitsToDouble(0x3fdab4dd5c8cc046L), Double.longBitsToDouble(0x3fc0ffadfa08831cL)));
//   }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Character:\000 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\000> Escape=<\000> QuoteChar=<\000> CommentStart=<\000> NullString=<\uc0e4\uaaee\ub777\u1798\ub25a\u0dbf\u1b26\ub375\u8d81\u3764> RecordSeparator=<\udaa8\udf9d> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\uda43\udfe7\ud9b0\udead\uda9d\udcff]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 16, 5, "\udaa8\udf9d", "\uc0e4\uaaee\ub777\u1798\ub25a\u0dbf\u1b26\ub375\u8d81\u3764", "\uda43\udfe7\ud9b0\udead\uda9d\udcff",
        22, 29164, -2092957931, 3060523901911095740L, -15931L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4d380000000000L), Double.longBitsToDouble(0x3fd31cae18531542L)));
  }
  @Test
  public void test35() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test35() throws Throwable {
//     assertEquals("0=java.lang.Integer:741798655 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u9789> Escape=<\ue9a0> QuoteChar=<\ue9a0> CommentStart=<\u9789> NullString=<\u3828\u23fb\u0443\ua4de\ud44d\u5ffc\u73b9\u54aa\u267f\u1489\u316b\u460d\u0159\u9836\u8161\u433d\u8d30\u8c10\u6279\ucb04\u3301\u08ef\u425b\u2905\u7279\u4b22> RecordSeparator=<\ud90e\udf85\uda7e\udd46\ud892\udff0\ud999\udd79\ud87a\udde5\ud91b\udda7\ud92e\udd07\u0579\ud9b2\udd0d\udbe4\udc36> SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\ud9d2\ude53]\0121=java.lang.Integer:741798655 |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u9789> Escape=<\ue9a0> QuoteChar=<\ue9a0> CommentStart=<\u9789> NullString=<\u3828\u23fb\u0443\ua4de\ud44d\u5ffc\u73b9\u54aa\u267f\u1489\u316b\u460d\u0159\u9836\u8161\u433d\u8d30\u8c10\u6279\ucb04\u3301\u08ef\u425b\u2905\u7279\u4b22> RecordSeparator=<\ud90e\udf85\uda7e\udd46\ud892\udff0\ud999\udd79\ud87a\udde5\ud91b\udda7\ud92e\udd07\u0579\ud9b2\udd0d\udbe4\udc36> SurroundingSpaces:ignored SkipHeaderRecord:true Header:[\ud9d2\ude53]\012",
//         Z.run(T, 2, 15, 15, 14, "\ud90e\udf85\uda7e\udd46\ud892\udff0\ud999\udd79\ud87a\udde5\ud91b\udda7\ud92e\udd07\u0579\ud9b2\udd0d\udbe4\udc36", "\u3828\u23fb\u0443\ua4de\ud44d\u5ffc\u73b9\u54aa\u267f\u1489\u316b\u460d\u0159\u9836\u8161\u433d\u8d30\u8c10\u6279\ucb04\u3301\u08ef\u425b\u2905\u7279\u4b22", "\ud9d2\ude53",
//         18, 73823, 382456339, 1593025984566354140L, 33293L, true, false, (char) 38793, (char) 59808,
//         Double.longBitsToDouble(0x3fb5d5899db98e28L), Double.longBitsToDouble(0x3fd6600e0cfb0ea6L)));
//   }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Character:\u01ad |this=org.apache.commons.csv.CSVFormat:Delimiter=<\u97fb> Escape=<\u01ad> QuoteChar=<\u01ad> CommentStart=<\u97fb> NullString=<\u3828\u23fb\u7bce\u6f0d\u3706\ub868\u478c\uc040\u5ca0\u0136\ub255\u088e\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd> RecordSeparator=<\uda1d\udeac\udacb\udea6\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udb55\udd84\udb24\ude68\udbfa\udc54> SkipHeaderRecord:false Header:[\ud8d4\udf76]\012",
        Z.run(T, 1, 11, 8, 2, "\uda1d\udeac\udacb\udea6\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udb55\udd84\udb24\ude68\udbfa\udc54", "\u3828\u23fb\u7bce\u6f0d\u3706\ub868\u478c\uc040\u5ca0\u0136\ub255\u088e\u7a96\ua9ae\u8549\uaba5\u0614\u6059\u85e9\uc98c\u3382\u53ef\u425b\u2905\u87b4\u83dd", "\ud8d4\udf76",
        -2, 6728, 667669011, 1639371006149026012L, 78953L, false, false, (char) 38907, (char) 429,
        Double.longBitsToDouble(0x3fd5217314fcdd12L), Double.longBitsToDouble(0x3fec6cc263db224dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 0, 7, "\ud9d7\udddb\uda8c\ude80", "\uaaee\uce23\u65fa\ub2de\u353f\u1b51\ub375\u05f4\u3828\u23fb\u0467\u127f\u9b01\u3e41\ua3e6\u7bce\u2639\ucc9c\ua85b\u0176\u7a96\ua9ae\ubcb2\uaba5\u0614\u6059\u312c\uc98c\u3382\u53ef\u425b\uc374\ub9db\u83b0\u581a/\u9203\u52ff\u281c\u913d\uc235\ua921\ud32a\ubd9b\u97ae\u8667\u731b\ua637\u888e\u54e4\u5733\u3698\u2332\u6121\ua033\u24ef\u80fb\u6771\ubc5b\u8cb2", "\udb2c\uddbb\ud918\udc93\ud8c5\udeda\ud8eb\udd73",
        7, 7464, 274034769, -5422359744726006820L, -92747L, true, true, (char) 10, (char) 40124,
        Double.longBitsToDouble(0x3fc6feae6516ea90L), Double.longBitsToDouble(0x3fe784a3771d4621L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 8, 6, "\udb8d\udea4\uda8c\ude80\ud9de\udff7\ud948\udf00\udb7c\uddac\ud91b\uddb0\uf65c\udaf5\ude53\udb24\udeef\udbfa\udc54\ud9b5\udc38\uda16\udf7a\udacf\udc72\udb5b\udf31\udb83\udd6c\udaf6\udef5\ud8c1\udd81\uda10\ude47\ud9fd\udd94\ud89a\ude85\uda9a\udebf\udb3a\udc02\ud9f8\uddc0\u90c8\ud9f0\udcea\udaa4\uddb0\udbd0\udd2a\udb3e\ude11\udb56\ude98\uda88\udf74\ud83a\ude44\udb23\udf44\ud9ab\udee2\u107a\uda7a\udf1d\udbdc\udf47\udb6d\udcca\ud856\udd01", "\u9203\u52ff\uc2c6\u9e85\uc235\u215e\u943b\u17e6\u778a\ua906\u8b53", "\udb38\udff5\ud902\udc8a\ud834\udceb\ud960\uddbf\u9b89\uda95\udf75\ud9c4\udec3\ud8ee\udca5\udb3e\uddfb\ud861\udd76\uda7c\udeb0\ud868\uddca\ud8ea\ude21",
        28, 99728, -1271487167, -2330235846850226412L, 25780L, true, true, (char) 13, (char) 24186,
        Double.longBitsToDouble(0x3fdaeb72fa4795b0L), Double.longBitsToDouble(0x3fccc1e48126fc24L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVFormat|validate||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "C|org.apache.commons.csv.CSVFormat|<init>|char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|equals|java.lang.Object|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|format|[Ljava.lang.Object;|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getCommentStart||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getDelimiter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getEscape||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getHeader||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreEmptyLines||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreSurroundingSpaces||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getNullString||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuoteChar||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuotePolicy||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getRecordSeparator||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|getSkipHeaderRecord||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|hashCode||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "M|org.apache.commons.csv.CSVFormat|validate||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
    "C|org.apache.commons.csv.CSVFormat|<init>|char,java.lang.Character,org.apache.commons.csv.Quote,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
