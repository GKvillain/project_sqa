package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 9, 0, "\udb71\udf4f\ud8fe\udcea\ud81e\udc54\ud84f\udc16\ud8d0\udf77\ud98b\uddd9\ud80a\udf86\ud921\udf06\u63b8\uda3a\udfe2\ud8e1\uddc7\udadc\ude9f\ud95a\udc06\udac1\udcb2\udb00\ude13\ud999\udd5a\udbdf\udebe\uda4c\udcf0", "\u67dd\u8000\u2103\ub42d\u6d7a\u5c91\u6a8c\u346a\u6967\u41d4\u0a84\u224f\u6514\u878e\uc2f0\u1ac1\u45a4\u3c43\ucf4d\u1e0c\u159e\u2f64\u90c3\u86f7\ua96e\u4ffc\u9444\u44c1\u248f\u50e1\u1051\u4f98\ucd37", "\udadc\uddce\udb00\udf72",
        59, 64118, -1400938842, 61462431234952380L, -23048L, false, false, (char) 34155, (char) 16343,
        Double.longBitsToDouble(0x3fe26d228108d596L), Double.longBitsToDouble(0x3f7977198729d780L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 11, 13, "\ud99f\udfa4\udb1e\udfd5\ud82e\ude6d\uda32\udd27\ud8d0\udf77\ud98b\uddd9\ud80a\udf86\ud921\udf06\u63b8\u1e2d\ud853\udc20\udb00\udd8e\ud95a\udc06\udac1\udcb2\udb00\ude13\udbd5\udd68\udb90\udd80\uda4c\udcf0", "\u67dd\u8000\u2103\ub42d\u6d7a\u21a1\u61e0\u346a\u679d\u41d4\u0a84\u224f\u6514\u878e\uc2f0\u1ac1\u45a4\u3c43\u8624\ub585\u2440\ub7d0\u90c3\u86f7\ua96e\ubd2f\ub06a\u44c1\u6d8f\u68b0\u5118\ucd98\ucd37", "\udadc\uddce\ud87f\uddf0",
        -1, 23588, -1400938957, 61461731155283132L, -23048L, false, false, (char) 34155, (char) 58744,
        Double.longBitsToDouble(0x3fd9ea450211aab8L), Double.longBitsToDouble(0x3f7977198729d780L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 9, 0, "\udb71\udf4f\ud8fe\udcea\ud81e\udc54\ud84f\udc16\ud8d0\udf77\ud98b\uddd9\ud80a\udf86\ud921\udf06\u63b8\uda3a\udfe2\ud8e1\uddc7\udadc\ude9f\ud95a\udc06\udac1\udcb2\udb00\ude13\ud999\udd5a\udbdf\udebe\uda4c\udcf0", "\u67dd\u8000\u2103\ub42d\u6d7a\u5c91\u7d8c\u346a\u6967\u41d4\u0a84\u224f\u6514\u878e\uc2f0\u1ac1\u45a4\u3c43\u287c\u382b\u62a7\u1837\u90c3\u86f7\ua96e\u4ffc\u9444\u44c1\u248f\u50e1\u1051\u4f98\ucd37", "\udadc\uddce\udb00\udf72",
        59, 64118, -1401332058, 61462431234952380L, -23048L, false, false, (char) 34155, (char) 16343,
        Double.longBitsToDouble(0x3fe26d228108d596L), Double.longBitsToDouble(0x3f7977198729d780L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 9, 0, "\udb71\udf4f\ud8fe\udcea\ud81e\udc54\ud865\udf81\ud8a1\udcf3\ud98b\uddd9\ud80a\udf86\ud921\udf06\u63b8\uda3a\udf50\ud8e1\uddc7\udadc\ude9f\udbb0\uddd8\udabb\udd8f\udb00\ude13\ud999\udd5a\udbdf\udebe\uda4c\udcf0", "\u67dd\u8000\u2103\ub42d\u6d7a\u5c91\u928c\u346a\u6967\u41d4\u0a84\u224f\u6514\u878e\uc2f0\u1ac1\u45a4\u299a\ucf4d\ub86b\u030c\u5e47\u6828\u48a4\ua96e\u95ed\u9444\u81e4\ubf43\u50e1\u1051\u4f98\ucd37", "\udadc\uddce\udb00\udf72",
        26, 64118, -1400938842, 61462431234952380L, -23048L, false, false, (char) 34155, (char) 16343,
        Double.longBitsToDouble(0x3fea6d228108d5e5L), Double.longBitsToDouble(0x3f7977198729d780L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 0, 3, "\udb71\udf4f\ubd83\ud917\udf75\ud84f\udc16\ud9af\udc02\ud98b\uddd9\uc81b\udae1\udd0f\uda26\udd25\uda3a\udfe2\ud8e1\uddc7\udadc\ude9f\ud95a\udc06\udb02\udcd2\udb00\ude13\ud999\udd5a\udbdf\udebe\uda4c\udcf0", "\u67dd\u8000\uc3e5\ub42d\u6d7a\u5c91\u587f\u9870\u3cb5\u41d4\u0a84\u9932\ube43\u878e\u7535\u7117\u9219\u3ca4\ucf4d\u1e0c\u159e\u2f64\u19c4\u86f7\ud13b\u4fea\u9444\u1f32\ud620\u1fbd\u1054\u4f98\ucd37", "\ud95b\udc42\udb00\udf72",
        59, 64118, -1394516314, 61462431234952380L, 44761L, false, true, (char) 35207, (char) 37081,
        Double.longBitsToDouble(0x3fc2d9dfacb6d2a8L), Double.longBitsToDouble(0x3fe340b286bd2e96L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 14, 0, "\udb71\udf4f\ud8fe\udcea\ud81e\udc54\ud84f\udc16\ud8d0\udf77\ud98b\uddd9\uda7f\udd82\ud921\udf06\ud90b\udf50\uda3a\udfc7\ud8e1\uddc7\udadc\ude9f\ud95a\udc06\udac1\udcb2\udb00\ude13\ud999\udd5a\udbdf\udebe\uda4c\udcf0", "\u301e\u9505\u2103\ub42d\u6d7a\u5c91\u6a8c\u346a\u6967\u41d4\u0a84\u224f", "\ud90f\udfd3",
        44, 68103, -25143798, 6644729209190102711L, 95463L, true, true, (char) 58413, (char) 20593,
        Double.longBitsToDouble(0x3fea26629825e23bL), Double.longBitsToDouble(0x3fdf289fb84cbafcL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 4, 14, "\udb71\udf4f\ud8fe\udcea\ud81e\udc54\ud84f\udc16\ud8d0\udf77\ud98b\uddd9\ud80a\udf86\ud921\udf06\u63b8\uda3a\udfe2\ud8e1\uddc7\udadc\ude9f\ud95a\udc06\udac1\udcb2\udb00\ude13\ud999\udd5a\udbdf\udebe\uda4c\udcf0", "\u67dd\u8000\u2103\ub42d\u6d7a\u5c91\u6a8c\u346a\u6967\u41d4\u0a84\u224f\u6514\u878e\uc2f0\u1ac1\u45a4\u3c43\ucf4d\u1e0c\u159e\u2f64\u90c3\u86f7\ua96e\u4ffc\u9444\u44c1\u248f\u50e1\u1051\u4f98\ucd37", "\udadc\uddce\udb00\udf72",
        59, 64118, -1166057818, 61462534314167484L, -23048L, false, false, (char) 34155, (char) 16343,
        Double.longBitsToDouble(0x3fe26d228108d596L), Double.longBitsToDouble(0x3f7977198729d780L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 9, 14, "\udb71\udf4f\ud8fe\udcea\ud81e\udc54\ud84f\udc16", "\ucdad\ud08c\u1a27\u6564\u4e4e\u70cb\u74f4\u94d4\u38d4\ua393\u3005\ua115\u0983", "\ud841\udef4\ud804\ude42\udaf5\ude77\u09b5\ud8c6\udd35\ud8e5\udc78\udb9f\udeb4\udb12\ude0f\ud891\udd44\ud93e\udcd0\u7c74\ud931\udcf0\ud801\ude04\ud90f\udfd3\ud86b\udeab\udb34\ude2b\ud969\uddf3\ud84b\udcad\uda0d\uddf2\ud943\ude6e",
        -3, 56204, 1438589271, -9215976970086411965L, -1170L, false, false, (char) 44188, (char) 63109,
        Double.longBitsToDouble(0x3fe7fa3e17cadbb5L), Double.longBitsToDouble(0x3fb255651be243d0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 12, 5, "\udb71\udf4f\ud8fe\udcea\ud81e\udc54\ud84f\udc16\ud8d0\udf77\ud98b\uddd9\ud80a\udf86\ud921\udf06\u63b8\uda3a\udfe2\ud8e1\uddc7\ud930\udd88\ud931\udf83\udac1\udcb2\uda9e\ude6a\udb48\udc90\udbdf\ude70\uda4c\udcf0", "\u78c9\u333c\u2103\ub42d\u6d7a\u5c91\u38ad\u346a\u6967\u41d4\u0a84\u224f\u6514\u878e\uc2f0\u1ac1\u45a4\u3c43\ucf4d\u19e6\u159e\u2f64\u90c3\u98f7\u5902\u4ffc\ud2c9\u44c1\u248f\u50e1\u1051\u4f98\ucd37", "\udadc\uddce\udb00\udf72",
        59, 64118, -1400938842, 61462431234952380L, -23048L, false, false, (char) 34155, (char) 16266,
        Double.longBitsToDouble(0x3fe26d228108d596L), Double.longBitsToDouble(0x3f7977198729d780L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVParser|initializeHeader||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|addRecordValue||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|close||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getCurrentLineNumber||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getHeaderMap||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getRecordNumber||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getRecords|java.util.Collection|new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getRecords||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|isClosed||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|iterator||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|nextRecord||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|parse|java.io.File,org.apache.commons.csv.CSVFormat|static",
    "M|org.apache.commons.csv.CSVParser|parse|java.lang.String,org.apache.commons.csv.CSVFormat|static",
    "M|org.apache.commons.csv.CSVParser|parse|java.net.URL,java.nio.charset.Charset,org.apache.commons.csv.CSVFormat|static",
    "C|org.apache.commons.csv.CSVParser|<init>|java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|initializeHeader||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
