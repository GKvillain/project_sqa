package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 14, 8, "\u595b\ud839\uddb4\ud862\udf15\ud99f\udc1c\ud813\uddef\uda26\udfff\udb4e\udc3a\udb91\udc62", "\u204c\u8ac4\uc900\u96c1\ub370\ud52d\u39f9", "\ud89f\ude07\ud88e\uddcf\udab6\udda0\ud8ee\udc4b\udb82\udf5f\udb0b\udc08\udac5\ude1c\ud97c\uddcd\udbe5\udddc\udb4d\udcef\uc856\ud9ec\udc45\udb88\udffd\ud8ad\udcc1\uaa1d\udaeb\udc5a\ud95e\ude9d\uda29\udefe\ud8e0\ude77\udb3f\udf01\udb84\udff2\uda34\udf88\uf9b5\ud888\udcf7\ud8ba\udec2\udb7d\udcdc\udb2a\udd18\u925c\udb58\udecb\uda90\udf85\ud97e\udd67\uda0c\udd8c\ud9d8\uddfa",
        48, 33855, -1830419246, 1162612722388561286L, -40634L, true, true, (char) 4413, (char) 3958,
        Double.longBitsToDouble(0x3fedfd73c1e839d7L), Double.longBitsToDouble(0x3fc7056c00a95b2cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 14, 8, "\u595b\ud839\uddb4\ud862\udf15\ud972\ude06\uda34\udc26\ud94c\udc16\udb5a\udc03\udb91\udc62", "\u204c\u8ac4\uc900\u96c1\ub370\ud52d\u39f9", "\ud89f\ude07\ud88e\uddcf\udab6\udda0\ud8ee\udc4b\udb82\udf5f\udb0b\udc08\udac5\ude1c\ud97c\uddcd\udbe5\udddc\udb4d\udcef\uc856\ud9ec\udc45\udb88\udffd\ud8ad\udcc1\uaa1d\udaeb\udc5a\ud95e\ude9d\uda29\udefe\ud8e0\ude77\udb3f\udf01\udb84\udff2\uda34\udf88\uf9b5\ud888\udcf7\ud8ba\udec2\udb7d\udcdc\udb2a\udd18\u925c\udb58\udecb\uda90\udf85\ud97e\udd67\uda0c\udd8c\ud9d8\uddfa",
        48, 33855, -1830419246, 1162612722388561286L, -40634L, true, true, (char) 4413, (char) 3958,
        Double.longBitsToDouble(0x3fedfd73c1e839d7L), Double.longBitsToDouble(0x3fc7056c00a95b2cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 14, 8, "\u595b\ud92b\udc1d\ud861\udc46\ud99f\udc1c\udbde\udcef\uda97\udf37\udb5a\udc21\udb91\udc62", "\u204c\u8ac4\uc900\u96c1\ub370\ud52d\u39f9\u5905\u09a1\u9522\ua41d\u93ea\u8429\u3bc9\u2cec\ub617\u35d2", "\ud880\udc5c\ud9ec\udc45\udb88\udffd\ud8ad\udcc1\uaa1d\ud949\udd28\ud95e\ude9d\uda29\udefe\ud8e0\ude77\udb3f\udf01",
        36, 66761, -1260168510, 2510094078083804491L, 3314L, true, true, (char) 4587, (char) 13816,
        Double.longBitsToDouble(0x3fe9fa284de82e5dL), Double.longBitsToDouble(0x3fedbfc704d25857L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 6, 1, "\u8e0b\ud839\uddb4\ud862\udf15\ud99f\udc1c", "\u19c4\ub045\u72df\u5568\u204c\u8ac4\uc900\u96c1\ub370\ub50a\u39f9\u5905\u09a1\u9522\ua41d\u93ea\u7a62\ud3fb\u2cdb\ub617\u35d2\u334d", "\ud9ec\udc42",
        32, 52640, 1732236450, -3578647254301299451L, 50802L, true, false, (char) 34811, (char) 28610,
        Double.longBitsToDouble(0x3fc24c15da055ca8L), Double.longBitsToDouble(0x3fd4ba205099a9feL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 14, 8, "\u595b\ud839\uddb4\ud862\udf15\ud99f\udc1c\ud813\uddef\uda26\udfff\udb4e\udc3a\udb91\udc62", "\u204c\u8ac4\uc900\u96c1\ub370\ud52d\u39f9", "\ud89f\ude07\ud88e\uddcf\udab6\udda0\ud8ee\udc4b\udb82\udf5f\udb0b\udc08\udac5\ude1c\ud97c\uddcd\udbe5\udddc\udb4d\udcef\uc856\ud9ec\udc45\udb88\udffd\ud8ad\udcc1\uaa1d\udaeb\udc5a\ud95e\ude9d\ud9fa\udefe\ud8e0\ude77\udb3f\udf01\udb84\udff2\uda34\udf88\uf9b5\ud888\udcf7\ud8ba\udec2\udb7d\udcdc\udb2a\udd18\u925c\udb58\udecb\uda90\udf85\ud97e\udd67\udaee\udccc\ud9f0\udc95",
        48, 33855, -1830419246, 1162612722388561286L, -40634L, true, true, (char) 4413, (char) 41539,
        Double.longBitsToDouble(0x3fedfd73c1e839d7L), Double.longBitsToDouble(0x3fc7056c00a95b2cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 8, 8, "\u595b\ud839\uddb4\u9717\ud987\udc26\ud813\uddef\uda26\udfff\udb4e\udc3a\udb91\udc62\udbab\udd28\udb4e\udf2e\ub334", "\u433d", "\ud90f\udeaf\u2347\udb30\ude0e\ud89f\udd7e\ud88e\uddcf\udac0\udc45\udac8\udddf\udb33\ude2a\ud8bd\udcc0\ud87a\uddb0\ud97c\uddac\udbe5\udddc\udb4d\udcef\udb16\udf27\ud9ec\udc45\udb88\udffd\ud8ad\udcc1\uaa1d\udaeb\udc5a\ud95e\ude9d\udaa0\udd06\uda44\udeec\ud9ee\udfe3\udafa\udd4d\ud818\ude86",
        29, 54781, -726456124, -2469537972947729056L, 3314L, false, true, (char) 48334, (char) 13816,
        Double.longBitsToDouble(0x3fe11a284de82e47L), Double.longBitsToDouble(0x3fedbfc704d25857L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 14, 2, "\ud819\udcc5\ud821\uddb0\ud862\udf15\ud99f\udc1c\ud813\uddef\uda26\udfff\udb4e\udc3a\udb91\udc62", "\u204c\u8ac4\u3029\u96c1\u6acf\uafe0\u39f9", "\ud89f\ude07\ud88e\uddcf\udab6\udda0\ud93e\udf94\ud9e3\udce8\udabf\udf1e\udac5\ude1c\ud97c\uddcd\udbe5\udddc\udb4d\udcef\uc856\ud9ec\udc45\udbf1\uddc2\ud9e5\udda1\uaa1d\udac0\udfa5\uda5f\udfa6\uda29\udefe\ud8e0\ude77\udb3f\udf01\udb84\udff2\uda34\udf88\uf9b5\ud888\udcf7\ud8ba\udec2\udb7d\udcdc\udb2a\udd18\u925c\ud84c\udee9\udb25\ude49\u4e2a\uda0c\udd8c\ud9d8\uddfa",
        48, 33855, -1830419246, 1162612722388561286L, -40832L, true, true, (char) 30348, (char) 35401,
        Double.longBitsToDouble(0x3fc8a2228dce9390L), Double.longBitsToDouble(0x3fc7056c00a95b2cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 0, 10, "\u595b\udadc\udeaf\ud862\udef5\ud99f\udc1c\ud813\uddef\udb65\udc9e\ud9ba\udd5a\udb8b\udc56", "\u7e47\u0cfd\uc900\u96c1\ub370\ud52d\u39f9", "\ud89f\ude07\ud88e\uddcf\ud9d0\udccd\uda6f\udfeb\udb82\udf5f\udb0b\udc08\udac5\ude1c",
        53, 38678, 1379887127, -4250663779673987995L, -19788L, false, false, (char) 60551, (char) 31579,
        Double.longBitsToDouble(0x3fe01af7881210acL), Double.longBitsToDouble(0x3fe7233512843080L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 14, 8, "\udaa8\udd63\ud839\uddb4\ud862\udf15\ud8df\udc1c\ud813\uddef\uda26\udfff\udb4e\udc3a\udb91\udc62", "\u204c\u8ac4\uc900\u9c62\u2191\ud52d\u39f9", "\ud89f\ude07\ud88e\uddcf\udab6\udda0\ud8ee\udc4b\udb82\udf5f\udb0b\udc08\udac5\ude1c\ud97c\uddcd\udbe5\udddc\udb13\udcf2\uc856\ud9ec\udc45\udb88\udffd\ud8ad\udcc1\uaa1d\uda7d\udd63\ud95e\ude9d\ud9a5\udc62\ud8ff\udd05\udb3f\udf01\ud9d1\ude19\ud8e2\udcc9\udb54\udf98\ud888\udcf7\ud8ba\udec2\udb7d\udcdc\udb2a\udd18\u925c\ud92a\udd6e\uda8e\udf7c\ud97e\udd67\uda0c\udd8c\ud9d8\uddfa",
        48, 33855, 50660562, 1162613581382020486L, -40634L, true, true, (char) 4413, (char) 3958,
        Double.longBitsToDouble(0x3fedfd73c4eb39d7L), Double.longBitsToDouble(0x3fc7056c0ca95b2cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVParser|initializeHeader||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|addRecordValue||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|close||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getCurrentLineNumber||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getHeaderMap||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getRecordNumber||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getRecords|java.util.Collection|new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|getRecords||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|isClosed||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|iterator||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|nextRecord||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|parse|java.io.File,java.nio.charset.Charset,org.apache.commons.csv.CSVFormat|static",
    "M|org.apache.commons.csv.CSVParser|parse|java.lang.String,org.apache.commons.csv.CSVFormat|static",
    "M|org.apache.commons.csv.CSVParser|parse|java.net.URL,java.nio.charset.Charset,org.apache.commons.csv.CSVFormat|static",
    "C|org.apache.commons.csv.CSVParser|<init>|java.io.Reader,org.apache.commons.csv.CSVFormat",
    "M|org.apache.commons.csv.CSVParser|initializeHeader||new:org.apache.commons.csv.CSVParser:java.io.Reader,org.apache.commons.csv.CSVFormat",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
