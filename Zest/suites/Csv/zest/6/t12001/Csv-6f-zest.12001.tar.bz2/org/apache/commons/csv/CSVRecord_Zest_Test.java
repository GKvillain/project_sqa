package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVRecord_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\012",
        Z.run(T, 1, 12, 0, 11, "\udb53\udeae\uda6a\udf0e", "\u4e42\u01c8\ua9e7\ucc98", "\ud9c8\ude63\uda88\udfa1",
        10, 24886, -454388988, -5153342812938413640L, 76607L, false, false, (char) 27839, (char) 19994,
        Double.longBitsToDouble(0x3fe14fcec03e14f8L), Double.longBitsToDouble(0x3fe3638305de8218L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\012",
        Z.run(T, 1, 12, 0, 11, "\udb53\udeae\uda6a\udf0e", "\u4e42\u01c8\ua9e7\ucc98", "\ud9c8\ude63\uda88\udfa1",
        10, 24886, -454388988, -5153342812938413640L, 76607L, false, false, (char) 51646, (char) 19994,
        Double.longBitsToDouble(0x3fe14fcec03e14f8L), Double.longBitsToDouble(0x3fe3638305de8218L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\ude53]\012",
        Z.run(T, 1, 12, 0, 11, "\udb53\ude53", "\u97f9\u4e42\u01c8\ua9e7\ucc98\u5a24\uc00e", "\u355c",
        31, -996, 0, -2017612631574879037L, -52216L, false, false, (char) 19994, (char) 55297,
        Double.longBitsToDouble(0x3faf0a7c66c00600L), Double.longBitsToDouble(0x3fdde82182928ed0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\012",
        Z.run(T, 1, 12, 0, 11, "\udb53\udeae\uda6a\udf0e", "\u4e60\u01c8\u1e1f\ucc6a\u5a24\uc00e\u72dd", "\udb2e\ude4c\ud87f\udd2d\udb16\udd5a\udb11\ude1d\ud8ce\udde5\ud953\ude2e\ud979\udecc\udaa4\udcdb\ud873\udcd0\ud971\udf65\ud975\udedd\uda00\udd00\udbcc\ude41\ud8e6\udf2d\ud812\udc85\ud8f1\udff6\ud955\udedc\udb3b\udcb3\uec86\ud8cf\udd72\ud963\udf49\udb4e\udf64",
        56, 37098, -1910191709, -3500531591936570185L, -83767L, true, false, (char) 37088, (char) 15351,
        Double.longBitsToDouble(0x3fa4934374161240L), Double.longBitsToDouble(0x3fcc988310a79f48L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\012",
        Z.run(T, 1, 8, 15, 11, "\udb53\udeae\uda6a\udf0e", "\u718a\u89c8", "\udaa5\udd87\udb4f\udd76\ud9c8\ude63\uda88\udfa1\udab5\udf2f",
        6, 9012, 808215300, -1945861725584598589L, -29802L, false, false, (char) 3616, (char) 55297,
        Double.longBitsToDouble(0x3faf5c7c22d70600L), Double.longBitsToDouble(0x3fd49802f0a1323cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb4b\udc1d\ud945\udeee]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udb4b\udc1d\ud945\udeee]\012",
        Z.run(T, 2, 12, 6, 3, "\udb4b\udc1d\ud945\udeee", "\u8113\u9e7f\u5329\uae35", "\ud931\uded5\ud998\udcb4",
        10, 18316, 204888137, 5059130659250284434L, 82115L, false, true, (char) 19084, (char) 33086,
        Double.longBitsToDouble(0x3fe363825ede8218L), Double.longBitsToDouble(0x3fdb5da8212d6f2aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 12, 11, "\udb53\udeae\uda6a\udf0e", "\ud05a\u01c8\ua9e7\uc9ed", "\ud9c8\ude63\udba2\udfce\udbf5\udc3f\ud9d2\udd8f\ud974\udd6b\u5fcd\uda28\udc20\ud8da\uddf9\u8852\ud979\udecc\uda94\udcdb\ud873\udcd0\ud971\udf65",
        28, -748, 11605470, 8290691801059209982L, -91055L, false, true, (char) 62027, (char) 50362,
        Double.longBitsToDouble(0x3fd88d8b92e46190L), Double.longBitsToDouble(0x3fe5fb595e354f4dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\udb33\udd4a\uda6a\udf0e\ud83f\ude6e\ud9b1\udf4d\udb87\udfda\ud80e\udce3\ud9ce\udf8a\uda31\udde1\udaef\udcd1\ud9bd\udf37\ud9c8\ude63\uda88\udfa1\u355c\ud8a9\udd05\ud974\udd6b\udb91\udef8\uda28\udc20\ud8ce\uddfc\ud94e\udc2e\ud979\udecc] |a0=[Ljava.lang.String;:[[\udb33\udd4a\uda6a\udf0e\ud83f\ude6e\ud9b1\udf4d\udb87\udfda\ud80e\udce3\ud9ce\udf8a\uda31\udde1\udaef\udcd1\ud9bd\udf37\ud9c8\ude63\uda88\udfa1\u355c\ud8a9\udd05\ud974\udd6b\udb91\udef8\uda28\udc20\ud8ce\uddfc\ud94e\udc2e\ud979\udecc]]\012",
        Z.run(T, 1, 15, 9, 9, "\udb33\udd4a\uda6a\udf0e\ud83f\ude6e\ud9b1\udf4d\udb87\udfda\ud80e\udce3\ud9ce\udf8a\uda31\udde1\udaef\udcd1\ud9bd\udf37\ud9c8\ude63\uda88\udfa1\u355c\ud8a9\udd05\ud974\udd6b\udb91\udef8\uda28\udc20\ud8ce\uddfc\ud94e\udc2e\ud979\udecc", "\u2f04\u05dc\u2933\u9f19\u8e1d\u52de\u776e\u380f\ua66d\u2f0e\u80f4", "\uda16\udecc",
        50, -817, -994789016, -5201090373087588177L, -96648L, true, false, (char) 58512, (char) 60103,
        Double.longBitsToDouble(0x3fe6bfca20e33380L), Double.longBitsToDouble(0x3fd2cc27843acb94L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\ude9b]\012",
        Z.run(T, 1, 0, 0, 11, "\udb53\udeae\uda6a\ude9b", "\ua652", "\ubacc\udaef\udc15\ud9f1\udc30\ud9c8\ude63\udb0a\udfe1\ud913\udf7a\ud8b3\udd0a\ud97f\udefc\uf1cd\uf66b",
        34, 124, -1238582616, 5943982799455960743L, 95435L, false, false, (char) 50810, (char) 60113,
        Double.longBitsToDouble(0x3fe104d625fd21abL), Double.longBitsToDouble(0x3fe11f02ea0d6d86L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\012",
        Z.run(T, 1, 4, 0, 11, "\udb53\udeae\uda6a\udf0e", "\u4e42\u01c8\ua9e7\ucc98", "\udaaa\udcd5\uda88\udfa1",
        9, 24811, 60449284, 5837881155004582986L, 76607L, false, false, (char) 27839, (char) 20176,
        Double.longBitsToDouble(0x3fe14fcec03e14f8L), Double.longBitsToDouble(0x3fe78def45de8227L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 11, "\udb53\udeae\uda6a\udf0e", "\u5323\u01b8\ua9e7\u8fd6\u6f83\uc00e\u72dd\u2da5", "\ud8c5\udf6a\uf1cd\uda28\udc20\ud8ce\uddfc\ud94e\udc2e\ud979\udecc\uda94\udcdb\ud873\udcd0\ud971\udf65\ud975\udedd\uda11\udf00\udbb3\ude3a",
        34, 69500, -1304849987, 4350739743919959628L, 8127L, true, false, (char) 53757, (char) 26587,
        Double.longBitsToDouble(0x3fb4e173d7881eb8L), Double.longBitsToDouble(0x3fdde754604c0280L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:[\u9680\uda6a\udf0e] |this=org.apache.commons.csv.CSVRecord:[\u9680\uda6a\udf0e]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\u9680\uda6a\udf0e]\012",
        Z.run(T, 2, 13, 7, 9, "\u9680\uda6a\udf0e", "\uc9c1\u19d3\uc214\u84b0\u5a2b\ub246\u9653\uc564\u35ec\u89e5\u62ea", "\ud9bc\udde6\udba2\udfe2",
        58, 32246, -348036892, 1511201944543219774L, 91010L, false, false, (char) 33135, (char) 65312,
        Double.longBitsToDouble(0x3f98a2a99dba4b80L), Double.longBitsToDouble(0x3fd246ebee9da3a0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\0121=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\012",
        Z.run(T, 2, 12, 0, 11, "\udb53\udeae\uda6a\udf0e", "\u4e42\u01c8\ua9e7\ucc98", "\ud9c8\ude63\uda88\udfa1",
        10, 24886, -454388988, -5153342812938413640L, 76607L, false, false, (char) 27839, (char) 19994,
        Double.longBitsToDouble(0x3fe14fcec03e14f8L), Double.longBitsToDouble(0x3fe3638305de8218L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 0, 11, "\uda30\udda2\uda6a\udf0e", "\u4e42\u01c8\ua9e7\u0872", "\ud9c8\ude63\uda88\udfa1",
        10, 16870, -454388988, -5153342812946277960L, 76607L, false, true, (char) 56234, (char) 63046,
        Double.longBitsToDouble(0x3fe14c853dbb14f8L), Double.longBitsToDouble(0x3fde87052bbd0406L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae]\012",
        Z.run(T, 1, 9, 0, 11, "\udb53\udeae", "\u97f9\u4e42", "\uda15\udfe1\udaef\udcd1\ud9bd\udf37\ud9c8\ude63",
        5, 77422, 191521796, -2949620244827372499L, -78471L, true, false, (char) 55101, (char) 30143,
        Double.longBitsToDouble(0x3fd2df25dc53f3b0L), Double.longBitsToDouble(0x3fe0f707c46cd87fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e\ud83f\ude6e\ud9b1\udf69\uda69\uddfd\ud8cf\udc21\ud9ce\udeee\uda31\udde1\udaef\udcd1] |a0=[Ljava.lang.String;:[[\udb53\udeae\uda6a\udf0e\ud83f\ude6e\ud9b1\udf69\uda69\uddfd\ud8cf\udc21\ud9ce\udeee\uda31\udde1\udaef\udcd1]]\012",
        Z.run(T, 1, 15, 10, 13, "\udb53\udeae\uda6a\udf0e\ud83f\ude6e\ud9b1\udf69\uda69\uddfd\ud8cf\udc21\ud9ce\udeee\uda31\udde1\udaef\udcd1", "\u2dac\u6d76\u59d4\u6359", "\ud8a0\udf26\ud9af\ude38",
        7, 21142, -103240403, 1511201944543219774L, 25474L, true, false, (char) 11767, (char) 58288,
        Double.longBitsToDouble(0x3fbc0c23f78e7720L), Double.longBitsToDouble(0x3fefed6e84efde9dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\0121=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\012",
        Z.run(T, 2, 12, 0, 11, "\udb53\udeae\uda6a\udf0e", "\uc07c\u8862\u3d42\u3ce4", "\ud9c8\uddf6\ud800\udddd\u92e5\ud8b3\udd0a\udab2\uddc9",
        -5, 95967, 1331993179, 7715493841717541544L, 18846L, true, true, (char) 570, (char) 53671,
        Double.longBitsToDouble(0x3fe955afdd1384fcL), Double.longBitsToDouble(0x3fb5a1618171ac20L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 0, "\ud9a6\udeb3\ud9c9\ude69", "\u9511\u4c25\u8b38\u5e89\u0885\uc00e", "\u355c\udae1\udee2\udb9f\udf96",
        55, 4872, 1491558500, 7715424684154141352L, -46690L, false, false, (char) 53870, (char) 58240,
        Double.longBitsToDouble(0x3fc9060452c89958L), Double.longBitsToDouble(0x3fcbf8a1aa935dc0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 7, 11, "\udb53\ude53", "\u97f9\u4e42\u01c8\ua9e7\ucc98\u5a24\uc00e", "\u355c",
        31, -996, 0, -2017612631574879037L, -52216L, false, false, (char) 19994, (char) 55297,
        Double.longBitsToDouble(0x3faf0a7c66c00600L), Double.longBitsToDouble(0x3fdde82182928ed0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udaae\udd81]] |this=org.apache.commons.csv.CSVRecord:[\udaae\udd81]\0121=null |this=org.apache.commons.csv.CSVRecord:[\udaae\udd81]\012",
        Z.run(T, 2, 14, 4, 3, "\udaae\udd81", "\u97f9\u7d5f\u2ea3\ub2eb\ucc98\u5a24\uc00e", "\ud9a7\udc8c",
        31, -996, 0, -2017612633582786377L, -97842L, false, false, (char) 15386, (char) 55297,
        Double.longBitsToDouble(0x3fda830fbcd8006cL), Double.longBitsToDouble(0x3febc58961497953L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\ud8fd\udd81\udb87\udc64\udb1f\udc9d\ud9ba\udf32\udb7c\udf8c\ud80e\udce3\ud9ce\udf8a\ud8a9\udefe\ud9b3\udd16\ud9bd\udf37\ud816\udd8a\udb1f\udcc2\u2d1d\ud8b3\udd0a]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 14, "\ud8fd\udd81\udb87\udc64\udb1f\udc9d\ud9ba\udf32\udb7c\udf8c\ud80e\udce3\ud9ce\udf8a\ud8a9\udefe\ud9b3\udd16\ud9bd\udf37\ud816\udd8a\udb1f\udcc2\u2d1d\ud8b3\udd0a", "\u5ed0", "\ubacb\udac2\udfcd",
        26, 72911, 1027206720, -276904181121936069L, 24943L, true, true, (char) 54424, (char) 10103,
        Double.longBitsToDouble(0x3fe51658470d1f0eL), Double.longBitsToDouble(0x3fd0eb2f999e3cd8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 0, 11, "\udb53\udeae\ua6ef", ",", "\uda31\uddb3\udb54\udccf\000\ud9c8\ude63",
        5, 92430, -1157872034, -2005202648509667836L, -60236L, true, true, (char) 9658, (char) 44223,
        Double.longBitsToDouble(0x3fd2da0edc53f3b0L), Double.longBitsToDouble(0x3ecf000000000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udb4c\ude66\ud8a6\uded9]\0121=null |this=org.apache.commons.csv.CSVRecord:[\udb4c\ude66\ud8a6\uded9]\012",
        Z.run(T, 2, 8, 0, 11, "\udb4c\ude66\ud8a6\uded9", "\ucf5f\u999c\u0628\u8b07\u5a24\u31bb", "\u355c\udb2e\ude4c\ud965\ude00",
        -5, 15511, -588028756, -1961360032162792792L, 408L, false, false, (char) 58507, (char) 52195,
        Double.longBitsToDouble(0x3fdde822f1118580L), Double.longBitsToDouble(0x3fc9ac7c9fadf76cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:[\udbee\udd76\udbaf\udf13] |this=org.apache.commons.csv.CSVRecord:[\udbee\udd76\udbaf\udf13]\0121=new org.apache.commons.csv.CSVRecord:[\udbee\udd76\udbaf\udf13] |a0=[Ljava.lang.String;:[[\udbee\udd76\udbaf\udf13]]\012",
        Z.run(T, 2, 13, 15, 11, "\udbee\udd76\udbaf\udf13", "\u2a23\u6f69", "\udaa5\udd87\udb4f\udd76\ud9c8\ude63\ud8e5\udfb0\ud907\udd5a",
        29, 9012, 1026319108, -2134246383532624199L, -29802L, false, false, (char) 13461, (char) 4218,
        Double.longBitsToDouble(0x3fbd20f1d08b8300L), Double.longBitsToDouble(0x3fd49802f2a1323cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udb78\uddbb\udb20\ude59]\0121=new org.apache.commons.csv.CSVRecord:[\udb78\uddbb\udb20\ude59] |a0=[Ljava.lang.String;:[[\udb78\uddbb\udb20\ude59]]\012",
        Z.run(T, 2, 8, 15, 10, "\udb78\uddbb\udb20\ude59", "\u718a\u89c8", "\udaa5\udd87\udb4f\udd76\ud9c8\ude63\uda88\udfa1\uda0e\udcd0\uda9f\uddd1\udb65\udf14\ud97f\udffb",
        -3, 38859, 1273278943, 5064599281093518966L, 72184L, false, true, (char) 61860, (char) 29150,
        Double.longBitsToDouble(0x3fefaa4388771af7L), Double.longBitsToDouble(0x3fc82ec971250dbcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\012",
        Z.run(T, 2, 8, 7, 12, "\udb53\udeae\uda6a\udf0e", "\u8ad0\u256e", "\udafb\ude35\udb28\udf21\ud9c8\udda9\ud338\ud857\ude70\ud80a\udc52\u13ed\udb27\udd24\udae0\udddb\ud927\udd46\uda8d\uddc7\ud92b\udf3c\ud970\uddba\ud964\ude8d\ud998\uddf9",
        41, 44430, -467776183, -5811759573834122321L, -2976L, false, true, (char) 61538, (char) 44999,
        Double.longBitsToDouble(0x3fc0088f925cb15cL), Double.longBitsToDouble(0x3fe03365a2e0542aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud84b\ude7b\udb27\udec1]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 1, 0, "\ud84b\ude7b\udb27\udec1", "\u0c07\u2f6d", "\udaa5\udd87\udb4f\udd49",
        19, 88461, -581544437, 7956429882369151848L, -40334L, true, true, (char) 41058, (char) 28091,
        Double.longBitsToDouble(0x3fd76bc51b8141e8L), Double.longBitsToDouble(0x3fe14fcec03ebef8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud8aa\udc38\ud84f\udc28\ud80e\udcd1\uda5b\udde5\udaa6\udfee\udb54\udc15\udbdc\udd50\uda31\udde1\udaa5\udd87\uda0d\udc47\u0a18\udbd9\udeaa\udaa3\udfc4]\0121=new org.apache.commons.csv.CSVRecord:[\ud8aa\udc38\ud84f\udc28\ud80e\udcd1\uda5b\udde5\udaa6\udfee\udb54\udc15\udbdc\udd50\uda31\udde1\udaa5\udd87\uda0d\udc47\u0a18\udbd9\udeaa\udaa3\udfc4] |a0=[Ljava.lang.String;:[[\ud8aa\udc38\ud84f\udc28\ud80e\udcd1\uda5b\udde5\udaa6\udfee\udb54\udc15\udbdc\udd50\uda31\udde1\udaa5\udd87\uda0d\udc47\u0a18\udbd9\udeaa\udaa3\udfc4]]\012",
        Z.run(T, 2, 8, 15, 11, "\ud8aa\udc38\ud84f\udc28\ud80e\udcd1\uda5b\udde5\udaa6\udfee\udb54\udc15\udbdc\udd50\uda31\udde1\udaa5\udd87\uda0d\udc47\u0a18\udbd9\udeaa\udaa3\udfc4", "\u5c1c\u7910", "\ud94f\ude5a\uda23\udd9a\udb3b\ude86\ud9d5\udc35\ud975\udedd\uda56\udc6a",
        7, 4059, 1599045504, 4733043020228567126L, 73693L, true, true, (char) 54613, (char) 493,
        Double.longBitsToDouble(0x3fc8eee0e11cc44cL), Double.longBitsToDouble(0x3fee397518385746L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb4b\udc1d\ud945\udeee]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 3, 12, "\udb4b\udc1d\ud945\udeee", "\u8113\uc25a\u5329\u4690", "\ud93a\udfd5\ud987\udfb4\u1d47\udbfa\udf84\udb32\udfeb",
        56, 66716, -1388802797, 1599384557048674926L, 16348L, false, false, (char) 34110, (char) 28721,
        Double.longBitsToDouble(0x3fe51512ab04e469L), Double.longBitsToDouble(0x3fd7dab8767c1efcL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.csv.CSVRecord:[\u34c6\000]\0121=null |this=org.apache.commons.csv.CSVRecord:[\u34c6\000]\012",
        Z.run(T, 2, 0, 0, 0, "\u34c6\000", "\u8113", "\ud853\udf35\u00d3\udabb\udde1\ud931\uded5",
        32, 6390, 0, 1177920648L, -100000L, false, false, (char) 34109, (char) 5823,
        Double.longBitsToDouble(0x3febb74b88000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\ue702\ud86e\udd80]\0121=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\ue702\ud86e\udd80]\012",
        Z.run(T, 2, 12, 12, 6, "\ue702\ud86e\udd80", "\u8113\u9e7f\u5329\uae35", "\ud931\uded5\ud998\udcb4\udaac\udd79\ud87f\udc5f\ud8c8\udd01\ud8b2\udcab\ud948\udf61\udafa\udc1d\ud9f0\udf7b\uc06f\udaa5\udf48\udb94\ude8b\ud864\udd36\ud863\ude4d\uda11\udf00",
        -2, 5685, 408971414, -1386681416133268664L, -11288L, false, true, (char) 61567, (char) 6542,
        Double.longBitsToDouble(0x3fec94c4ba26f335L), Double.longBitsToDouble(0x3fe680069d074a81L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.csv.CSVRecord:[\udb4b\udc1d\uda86\uddaf] |a0=[Ljava.lang.String;:[[\udb4b\udc1d\uda86\uddaf]]\0121=new org.apache.commons.csv.CSVRecord:[\udb4b\udc1d\uda86\uddaf] |a0=[Ljava.lang.String;:[[\udb4b\udc1d\uda86\uddaf]]\012",
        Z.run(T, 2, 15, 15, 9, "\udb4b\udc1d\uda86\uddaf", "\uc5df\u7c5f\u49e1\u8c69\uc9c5\u4a6f", "\u1d47\udbf6\ude22\ud8c8\udd01\ud8b2\udcab\ud948\udf61\ud884\udc22\uda11\udd8b\uc06f\uda1e\ude46\udb4d\udde7\ud864\udd92\ud8ba\ude1a\ud8d1\udc3f\ud96d\udc63\ud9e1\udd97\ud86b\udf71\udb37\udf3f\udb79\udd47\ud93f\udf9f\ud8e8\udcaf\uda38\udf65\udadd\udcc9\udab1\udc2f\ud93a\udca1\ud9f5\udf77\uda0d\udcf2\uda23\udeac\ud9ec\ude05\ud902\uddf0\udbae\ude3f\ud801\ude95\udb12\udd6f\ud88e\udfe7\udbc3\udd62\u9066\udbeb\udf2a\uda2f\udf06\udbaa\udf6d",
        58, 3977, 341358264, -3410220459257843604L, -61778L, true, false, (char) 18510, (char) 28388,
        Double.longBitsToDouble(0x3fe7a93a2015d0a6L), Double.longBitsToDouble(0x3fe42ef59bef564eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\uda26\ude2a\uec55]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\uda26\ude2a\uec55]\012",
        Z.run(T, 2, 6, 6, 7, "\uda26\ude2a\uec55", "\u8e05\u9e7f\u5329\uae35\u5a3c\u4aae\u0ed2\ua868\u36ec\u1627\u4ec2", "\udafa\udc1d\uda11\udd8b\uc06f\udaa5\udf48\udbbb\udd1f\ud864\udd89\ud863\ude4d\uda11\udf00",
        59, 74257, 1567910038, -3126991421740931145L, 20470L, false, false, (char) 22595, (char) 48733,
        Double.longBitsToDouble(0x3fe11f3e83d210a6L), Double.longBitsToDouble(0x3fed47d05f9877d2L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud9a9\udda2\uda6a\uded7\udad5\udd1a\udb7e\udc5e\udbbd\ude11\ud86d\udcd7\ud970\udeaa\ud9a7\ude2e\ud800\uded3\u9f3d\ud98f\udea9\udab0\udd2e\udb4d\udf40\ud81f\udef3\ud974\udd6b\udb61\uddbf\udbc5\udced]\0121=java.lang.Boolean:false |this=org.apache.commons.csv.CSVRecord:[\ud9a9\udda2\uda6a\uded7\udad5\udd1a\udb7e\udc5e\udbbd\ude11\ud86d\udcd7\ud970\udeaa\ud9a7\ude2e\ud800\uded3\u9f3d\ud98f\udea9\udab0\udd2e\udb4d\udf40\ud81f\udef3\ud974\udd6b\udb61\uddbf\udbc5\udced]\012",
        Z.run(T, 2, 8, 8, 5, "\ud9a9\udda2\uda6a\uded7\udad5\udd1a\udb7e\udc5e\udbbd\ude11\ud86d\udcd7\ud970\udeaa\ud9a7\ude2e\ud800\uded3\u9f3d\ud98f\udea9\udab0\udd2e\udb4d\udf40\ud81f\udef3\ud974\udd6b\udb61\uddbf\udbc5\udced", "\u8f24\u3239", "\udaf2\udf13\ud953\udfa1\ud8d6\udc6d\ud855\udfca\udaea\udc5a\udbfb\udea0\udb0d\udc5f\uda13\ude4f\ud9c9\ude49\udb4b\udd98\ud87c\udc5b\udbbe\udc57\udb3a\udf97\ud9a7\udecf\uda0a\udc55",
        57, 74108, 934569664, -3312899686394914643L, 55139L, false, true, (char) 34754, (char) 45176,
        Double.longBitsToDouble(0x3feb8ac0ddc0fe7eL), Double.longBitsToDouble(0x3fc81633ddb648f8L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\ua6ef]\012",
        Z.run(T, 1, 10, 0, 11, "\udb53\udeae\ua6ef", ",", "\ud9ec\ude39\udb54\udccf\000\ud9c8\ude1e",
        5, 92430, -1157872034, -2005202648509667836L, -60236L, true, true, (char) 9658, (char) 44223,
        Double.longBitsToDouble(0x3fd2da0edc53f3b0L), Double.longBitsToDouble(0x3ecf000000000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[\udb53\uded8\ua6ef]\012",
        Z.run(T, 1, 6, 10, 11, "\udb53\uded8\ua6ef", ",", "\uda31\uddb3\udad9\udcd1h\ud88b\ude25",
        30, 91281, -1157872034, 5873189593303540293L, -94747L, true, true, (char) 55458, (char) 44221,
        Double.longBitsToDouble(0x3fd2da0edc53f3b0L), Double.longBitsToDouble(0x3ecf12903c200000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\ua6ef]\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 10, 0, 11, "\udb53\udeae\ua6ef", ",", "\ud9ec\ude39\udb54\udccf\000\ud9c8\ude1e",
        5, 92430, -1157872034, -2005202648509667836L, -60236L, true, true, (char) 9658, (char) 44223,
        Double.longBitsToDouble(0x3fd2da0edc53f3b0L), Double.longBitsToDouble(0x3ecf000000000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\ud8b7\udf76]\0121=new org.apache.commons.csv.CSVRecord:[\udb53\udeae\ud8b7\udf76] |a0=[Ljava.lang.String;:[[\udb53\udeae\ud8b7\udf76]]\012",
        Z.run(T, 2, 10, 15, 11, "\udb53\udeae\ud8b7\udf76", ",", "\ud9ec\ude39\udb54\udccf\000\ud9c8\ude1e",
        5, 92430, -1157872034, -2005202648509667836L, -60236L, true, true, (char) 9658, (char) 44223,
        Double.longBitsToDouble(0x3fd2da0edc53f3b0L), Double.longBitsToDouble(0x3fe80007c443180cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:2 |this=org.apache.commons.csv.CSVRecord:[\u4a42\ua6ef\uda30\ude98\udb19\udf2c, \udacc\udffe\ud9bd\udc80]\0121=new org.apache.commons.csv.CSVRecord:[\u4a42\ua6ef\uda30\ude98\udb19\udf2c, \udacc\udffe\ud9bd\udc80] |a0=[Ljava.lang.String;:[[\u4a42\ua6ef\uda30\ude98\udb19\udf2c, \udacc\udffe\ud9bd\udc80]]\012",
        Z.run(T, 2, 10, 15, 11, "\u4a42\ua6ef\uda30\ude98\udb19\udf2c,\udacc\udffe\ud9bd\udc80", "\ub230", "\ud916\udf9f\ud8f0\udd6e\uda0b\udf43",
        42, 75039, 1487103148, 7715448872101329576L, -84113L, true, false, (char) 44097, (char) 0,
        Double.longBitsToDouble(0x3fee8b5f2220473fL), Double.longBitsToDouble(0x3fa255aeffdfb1b0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.util.HashMap:{} |this=org.apache.commons.csv.CSVRecord:[\udb53\udeae\uda6a\udf0e]\012",
        Z.run(T, 1, 12, 14, 12, "\udb53\udeae\uda6a\udf0e", "\u1687\uc096\ua9e7\uab87", "\ud9c8\ude63\uda88\udfa1\ud97d\udd3f\ud8b3\udceb\ud974\udd6b\uf1cd\uda28\udc20\ud8ce\uddfc\ud94e\udc2e\ud979\udecc\uda94\udcdb",
        2, 70121, 1885392958, -9072318468533643810L, 28442L, true, false, (char) 53714, (char) 45697,
        Double.longBitsToDouble(0x3fd9ba2b24d879d6L), Double.longBitsToDouble(0x3fcf16a1abe106ccL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\udb81\udd84\uda6a\ude4b]\0121=java.util.Arrays$ArrayItr:@? |this=org.apache.commons.csv.CSVRecord:[\udb81\udd84\uda6a\ude4b]\012",
        Z.run(T, 2, 9, 9, 11, "\udb81\udd84\uda6a\ude4b", "\u4e42\u01c8\ua9e7\ucc98", "\ud9c8\ude63\uda88\udfa1\u355c\ud8b3\udd0a",
        7, 22879, -453092936, 6387059487019282716L, -24618L, true, true, (char) 55297, (char) 58677,
        Double.longBitsToDouble(0x3fe363830196e0ceL), Double.longBitsToDouble(0x3fe82b5d7b78108bL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:\ud84b\ude7b\udb27\udec1\ud9b6\udf9a\uda5b\udde5\udac4\udec7\ud99b\udf33\udaaa\udfe6\uda31\udde1\udaa5\udd87\udb4f\udd49 |this=org.apache.commons.csv.CSVRecord:[\ud84b\ude7b\udb27\udec1\ud9b6\udf9a\uda5b\udde5\udac4\udec7\ud99b\udf33\udaaa\udfe6\uda31\udde1\udaa5\udd87\udb4f\udd49]\0121=java.lang.String:\ud84b\ude7b\udb27\udec1\ud9b6\udf9a\uda5b\udde5\udac4\udec7\ud99b\udf33\udaaa\udfe6\uda31\udde1\udaa5\udd87\udb4f\udd49 |this=org.apache.commons.csv.CSVRecord:[\ud84b\ude7b\udb27\udec1\ud9b6\udf9a\uda5b\udde5\udac4\udec7\ud99b\udf33\udaaa\udfe6\uda31\udde1\udaa5\udd87\udb4f\udd49]\012",
        Z.run(T, 2, 1, 1, 0, "\ud84b\ude7b\udb27\udec1\ud9b6\udf9a\uda5b\udde5\udac4\udec7\ud99b\udf33\udaaa\udfe6\uda31\udde1\udaa5\udd87\udb4f\udd49", "\ubcf5\u1db1\ub00b\u5c1c\u9e55\u7c21\u6b87\u57fc\u88f0\u8674\u9916\u8715", "\udb93\udc0e\udad1\udf7c\ud943\udf14\ud8b1\udd54",
        0, 90153, -1616649583, 6995605880661855881L, -83786L, false, false, (char) 54471, (char) 64683,
        Double.longBitsToDouble(0x3fcedabc768755b0L), Double.longBitsToDouble(0x3fed30234718d3ebL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[\udb02\udce9\ua6ef]\0121=java.lang.Boolean:true |this=org.apache.commons.csv.CSVRecord:[\udb02\udce9\ua6ef]\012",
        Z.run(T, 2, 6, 6, 11, "\udb02\udce9\ua6ef", ",", "\ud86f\udfae\udb54\udccf\000\ud9c8\ude1e",
        30, 92430, -1157872034, -2005202648509667836L, -60268L, true, true, (char) 9658, (char) 44223,
        Double.longBitsToDouble(0x3fd2da0edc53f3b0L), Double.longBitsToDouble(0x3ecf000000000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVRecord|putIn|java.util.Map|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|get|int|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|get|java.lang.Enum|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|get|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|getComment||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|getRecordNumber||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|isConsistent||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|isMapped|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|isSet|java.lang.String|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|iterator||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|size||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|toList||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|toMap||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|toString||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|values||new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "C|org.apache.commons.csv.CSVRecord|<init>|[Ljava.lang.String;,java.util.Map,java.lang.String,long",
    "M|org.apache.commons.csv.CSVRecord|putIn|java.util.Map|new:org.apache.commons.csv.CSVRecord:[Ljava.lang.String;,java.util.Map,java.lang.String,long",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
