package org.apache.commons.csv;
import org.junit.Test;
import static org.junit.Assert.*;
public class CSVFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 13, 2, "\ud974\uddee\udb34\ude32\udac1\ude90\udbc9\ude18\ud90b\ude94\udbcb\udc63\uda4a\udd9f\ucab5\udbfb\udd05\ud926\udc01\uda62\uddf5\udb96\udf62\uda17\udc92\ud889\udefc\uda98\uddbb\uda2b\udc0e\udac9\ude47\udbc2\udfdd\udbfa\udf57\ud9c2\udcac", "\u2f90\u35b1\ud463\u65a1\u3472", "\udb0a\ude73\ud8c7\udc69\ud995\ude3f\uda34\udf88\u8f41",
        17, 64084, 1168364018, 3623584702466517527L, 63600L, false, true, (char) 31117, (char) 9126,
        Double.longBitsToDouble(0x3fe2a35cc191cb7fL), Double.longBitsToDouble(0x3fdb3fbe6b2a7accL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 13, 2, "\ud974\uddee\udb34\ude32\udac1\ude90\udbc9\ude18\ud90b\ude94", "\uce0f\u881d\u2d2b\u9be4\u197b\u280a\u822d\u72cc\ua71f\u1c2d\u55c6\u6500\u3b96", "\udb27\udcd8\ud96d\ude54\ud8e8\ude52\udae9\ude20\udb32\udffe",
        44, 38937, -459533295, -6843252608725217320L, -58458L, true, false, (char) 14093, (char) 41120,
        Double.longBitsToDouble(0x3fe8ba2d1a173249L), Double.longBitsToDouble(0x3fe95ce070f0fb17L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 10, 2, "\ud974\uddee\udb34\ude32\uda7a\uddec\udbc9\ude18\ud90b\ude94\udbcb\udc63\ud9fc\udd90\ucab5\udbfb\udd05\ud926\udc01\uda62\uddf5\udb96\udf62\uda17\udc92\udaee\udc8f\uda98\udcde\uda2b\udc0e\udac9\ude47\udbc2\udfdd\udbfa\udf57\ud9c2\udcac", "\u2f90", "\000\udaf7\udeba",
        44, -943, -459533312, 0L, -100000L, false, false, (char) 14093, (char) 52747,
        Double.longBitsToDouble(0x3fe8ba2802173249L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 13, 8, "\ud974\udda4\udab0\udd51\udac1\ude90\udbc9\ude18\ud9e0\uddff\ud98c\udd88\ud800\udfa2\ucab7\u0d2a\ud9ef\udde0\uda62\uddfb\udb96\udf62\uda17\udc92\ud889\udefc\uda98\uddbb\uda2b\udc0e\uda5e\udd72\udbc4\udefc\udbfa\udf57\ud9c2\udcac", "\uba90\u35b1\ud463\ub3d9\ua398", "\udb37\udd9c",
        44, 99035, -716638707, -7914128866200843069L, -88210L, true, true, (char) 40032, (char) 37689,
        Double.longBitsToDouble(0x3fce1f62e65060f4L), Double.longBitsToDouble(0x3fdfe5f8f8837ec8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 13, 2, "\ud974\uddee\udb34\ude32\udac1\ude90\udbc9\ude18\ud90b\ude94\udbcb\udc63\uda4a\udd9f\udb70\ude12\000\ud925\udfb0\ud867\udcb3\udb96\udf62\uda17\udc92\ud889\udefc\uda98\uddbb\uda2b\udc0e\udac9\ude47\udbc2\udfdd\udbfa\udf57\ud9c2\udcac", "\u2f90\u35b1\ud463\u65a1\u3472", "\udb0a\ude73\ud8c7\udc69\ud995\ude3f\uda34\udf88\u8f41",
        17, 64084, 1168364018, 3623584702466517527L, 63600L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fdb3fbe6b2a7accL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 5, 8, "\ud974\uddee\udb34\udd8b\udb57\udc1a\udbc9\ude18\ud90b\ude94\udbcb\udc63", "\u881d\u9bcc\ud161\ua7eb\u280a\u80fd\u71ef\u7e08\uac81\ud37b\u652a\u3b96\u5500\u3a81", ",\000\udaf7\udeba\ud9d6\udc4c\u1cee\ud92b\udd72\ud186\000\uda99\udec6\000\u64d0\ud933\udc49\udbe3\udc15\uda92\ude0d\ue617\ud947\udd02\uda9b\udda8\ud880\udffb\udad2\udf08\ub802\ud9bc\ude0a\udb80\udd0e\ud841\udfe2\ud8e2\udffc\udb39\udc2d\ud85b\ude3b\udb78\udc40\uda36\udea8\ud8e1\ude88\udb39\udc61\ud8b2\udf02\udbd8\udc15\udae2\udcd0",
        30, 67396, -1804416302, -4278487474462558581L, -56999L, true, false, (char) 52490, (char) 28708,
        Double.longBitsToDouble(0x3fea65e66078b059L), Double.longBitsToDouble(0x3fe8ee9863eaea48L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 13, 2, "\ud974\uddee\udb34\ude32\udac1\ude90\udbc9\ude18\ud90b\ude94\udbcb\udc63\uda4a\udd9f\ucab5\udac6\ude4e\ud926\udc01\uda62\uddf5\udbc4\ude38\uda17\udc92\ud889\udefc\uda98\uddbb\uda2b\udc0e\udac9\ude47\udbc2\udfdd\udbfa\udf57\ud9c2\udcac", "\u2f90\u35b1\ud463\ua374\u6709", "\udb0a\ude73\ud8c7\udc69\ud995\ude3f\uda34\udf88\u8f41",
        17, 64084, 1168364018, 3623584702466517527L, 25517L, true, true, (char) 64440, (char) 53666,
        Double.longBitsToDouble(0x3fe790f35ccf52dbL), Double.longBitsToDouble(0x3f94d5cf38774260L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 1, 2, "\ud974\uddee\udb34\ude32\udac1\ude90\udbc9\ude18\ud90b\ude94\udbcb\udc63\uda4a\udd9f\ud934\udf6f\ud8b0\udcdc\ud961\udc8d\ud867\udcb3\udb96\udf62\uda17\udc92\ud889\udefc\uda98\uddbb\uda2b\udc0e\udac9\ude47\udbc2\udfdd\udbfa\udf57\ud9c2\udcac", "\u767f\u67f9\ud463\u7da0\u9116", "\udb0a\ude73\ud8c7\udc69\ud995\ude3f\uda34\udf88\u8f41",
        4, 27640, -610211484, -1671834136414741746L, 63600L, false, true, (char) 10, (char) 0,
        Double.longBitsToDouble(0x3e0e6be8c0000000L), Double.longBitsToDouble(0x3fdb3fbe6b2a7accL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 10, 2, "\ud98a\udc3a\ud993\udc69\uda69\udcc1\udbc9\ude18\ud828\udfe4\udbcb\udc0c\ud9fc\udd90\ucab5\udbfb\udd05\ud926\udc01\uda62\uddf5\udb96\udf62\uda17\udc92\udaee\udc8f\uda98\udcde\uda2b\udc0e\udac9\ude47\udbc2\udfdd\udbd2\udf63\ud9c2\udcac", "\uba73", "\000\udaf7\udeba",
        44, -943, -459533312, 0L, -100000L, false, false, (char) 13, (char) 9426,
        Double.longBitsToDouble(0x3fe8ba2802173249L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 4, 5, "\ud974\uddee\udb34\udd8b\udb57\udc1a\udbc9\ude18\ud90b\ude94\udbcb\udc63", "\u4042\u22a8\u2081\ua7eb\u280a\u80fd\u71ef\u7e08\uac81\ud37b\u9618\u3b96\u5500\u3a81", ",",
        -5, 44888, -710063413, -2063487860619340800L, 38445L, false, true, (char) 34400, (char) 1733,
        Double.longBitsToDouble(0x3fdb7668b00adf06L), Double.longBitsToDouble(0x3fe8ba2806173249L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.csv.CSVFormat|equals|java.lang.Object|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|format|[Ljava.lang.Object;|new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getAllowMissingColumnNames||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getCommentMarker||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getDelimiter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getEscapeCharacter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getHeader||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreEmptyLines||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getIgnoreSurroundingSpaces||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getNullString||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuoteCharacter||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getQuoteMode||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getRecordSeparator||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|getSkipHeaderRecord||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|hashCode||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
    "M|org.apache.commons.csv.CSVFormat|isCommentMarkerSet||new:org.apache.commons.csv.CSVFormat:char,java.lang.Character,org.apache.commons.csv.QuoteMode,java.lang.Character,java.lang.Character,boolean,boolean,java.lang.String,java.lang.String,[Ljava.lang.String;,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
