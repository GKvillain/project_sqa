package org.joda.time.field;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnsupportedDurationField_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 22, 1, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\ubabc\u26ef\u2732\ucba1\u18b4\u88d6\u215c\u7545\u9224\u79ab\u93a7", "\ud8b2\udec3\uda3d\udc95\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud802\udf69\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud917\uddff\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\uda8c\udeee\udb9a\udc68\udaba\udc7f\udace\udd2f\u7ab6\uda3a\udd70\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2954edb7cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 22, 1, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\ubabc\u26ef\u2732\u6e4c\u9343\u88d6\u215c\u7545\u9224\u79ab\u93a7", "\ud8b2\udec3\uda3d\udc95\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud802\udf69\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud917\uddff\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\uda8c\udeee\udb9a\udc68\udaba\udc7f\udace\udd2f\u7ab6\uda3a\udd70\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\udaff\uddcf\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2954edb7cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 22, 17, 24, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\u52fe\u26ef\u5930\ucba1\u18b4\u680b\u2119\u7545\u1c25\u79ab\u4194", "\udbab\udece\uda3c\udfd4\ud855\ude1d\udb57\udd05\ub7b0\udb95\udf5c\ud892\udf25\ud997\udcd5\ud802\udf69\udb43\udc5d\udad0\udd29\ud8f5\udef7\uda8b\udc16\ud90a\udc67\ud989\udfcc",
        -4, 6067, -1527773373, -3084708092426102283L, 84327L, false, false, (char) 16806, (char) 47559,
        Double.longBitsToDouble(0x3f8a8d4b71477b00L), Double.longBitsToDouble(0x3f7b2e5d2428f980L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 15, 1, 16, "\udb54\udcd0\udae1\udfb0\ud88b\ude07", "\ubabc\u402c\u54e9\ucba1\u18b4\u88d6\u215c\u7545\u9224\u79ab\u93a7", "\udaaa\udf5e\uda3d\udc95\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud802\udf69\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud8a2\ude98\ud9a7\udc49\udad7\udd8e\ud9f7\udeba\ud86f\udfcf\ud997\udf54\uda8c\udeee\udb9a\udc68\udaba\udc7f\udace\udd2f\u7ab6\udb2e\udf29\ud987\ude98\udbbe\udd28\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\ud8a3\udf90\ud8d8\udc4d\udbe2\udc42\ud854\ude76\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, -38173L, false, true, (char) 15635, (char) 41162,
        Double.longBitsToDouble(0x3fef996b19121c63L), Double.longBitsToDouble(0x3fef65d26458a207L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 1, 22, "\ud918\udcd2\udae1\udfb0\ud83f\udd62", "\ubabc\u26ef\u2732\ucba1\u298e\ua529\ua029\u33e1\u5925\u79ab\u93a7", "\ud8b2\udec3\uda8d\udfde\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud802\udf69\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud85b\udf44\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\udb0a\udeed\udb9a\udc68\udaba\udc7f\udace\udd2f\ud9dc\udeb4\ud8be\udc2f\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2977fdb7cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\u33ab\u8a9a\ubce2\ucdcd\u8992\u768d\u9452\u7545\u9224", "\udbc5\udc12",
        9, 69174, 1590900479, -5778642966797132963L, -22972L, true, false, (char) 51602, (char) 15514,
        Double.longBitsToDouble(0x3fda779e6e094c9cL), Double.longBitsToDouble(0x3fe895f76758248cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 20, 1, 22, "\ud918\udcd2\ud8d4\uddea\ud88b\udd60", "\ubabc\u26ef\u2732\ucba1\u18b4\u88d6\u215c\ube38\ua9f2\u79ab\u93a7", "\ud8b2\udec3\uda3d\udc95\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\ud84b\udfc7\ud892\udfbf\ud997\udcd5\ud802\udf69\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud917\uddff\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\uda8c\udeee\udb9a\udc68\udaba\udc7f\udace\udd2f\u7ab6\uda3a\udd70\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2954edb7cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]] |a2=[I:[[19018]]\012",
        Z.run(T, 1, 2, 13, 22, "\uda1f\udf0b", "\u4a7a", "\uda58\udd3f\udaa5\ude35",
        23, 22442, 2144541015, 4409886988687024790L, 20621L, false, false, (char) 11875, (char) 62214,
        Double.longBitsToDouble(0x3fbf9be0cdb24cb0L), Double.longBitsToDouble(0x3fcdabd7cd7635f4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\012",
        Z.run(T, 1, 3, 1, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\ubabc\u26ef\u2732\ucba1\u18b4\u88d6\u215c\u7545\u9224\u79ab\u93a7", "\ud8b2\udec3\uda3d\udc95\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\udb00\udf35\uda18\udfb5\u504f\udb43\udc3e\ud89a\udf2e\ud856\udd35\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud917\uddff\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\uda8c\udeee\udb9a\udc68\udaba\udc7f\udace\udd2f\u7ab6\uda3a\udd41\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\ud857\udfb7\ud99e\udeee\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, 1946643845, -3531563755442881934L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2954edb7cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 23, 1, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\ubabc\u26ef\uac66\ucba1\u18b4\u172c\u215c\u7545\u9224\u79ab\u93a7", "\ud8b2\udec3\uda3d\udc95\ud855\ude1d\uda6d\udc68\udb3b\udf86\udbcc\uddc5\udaf5\udd06\ud9a1\udc22\ud802\udf69\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\udb80\udd28\ud917\uddff\ud926\ude0d\udb38\udd9b\ud86f\udfcf\ud997\udf54\ud8e0\udf58\ud839\udd6d\udbe4\udfde\udace\udd2f\u7ab6\uda3a\udd70\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbff\uddb6\udaa0\udd56\uda5e\ude2e\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\ud83b\udc72\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2954edb7cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\012",
        Z.run(T, 1, 24, 12, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\ubabc\u26ef\u2732\ucba1\u18b4\u88d6\ub066\u7545\u9224\u79ab\u93a7", "\ud8b2\udec3\uda3d\udc95\ud855\ude1d",
        32, 11182, -273755364, -6303763053894688498L, 54023L, false, true, (char) 62974, (char) 27451,
        Double.longBitsToDouble(0x3fe568a1706d9591L), Double.longBitsToDouble(0x3fcd1eab79704a0cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]]\012",
        Z.run(T, 1, 2, 21, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\ubabc\u26ef\u2732\ucba1\u18b4\u88d6\u215c\u7545\u9224\u79ab\u93a7", "\ud8b2\udec3",
        59, 75335, 0, -6689449436815371492L, -77049L, false, false, (char) 62738, (char) 27451,
        Double.longBitsToDouble(0x3fe568a1706d9591L), Double.longBitsToDouble(0x3fcd1ea001704a0cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 25, 17, 19, "\ud918\udcd2\udae1\udfb0\udb8e\ude2a", "\u5ce4\u637d\uba49\ucba1\u18b4\u88d6\u215c\u9685\u91d0\u85b7\u93a7\u8ab9", "\udb10\udcf2\ud876\udc39\ud86a\udd05\ud9a1\udfb5\ud8d1\udce9\ud89c\udfed\ud997\udcd5",
        42, 77329, -1091823868, 4298160355515713199L, -44813L, false, false, (char) 8927, (char) 39929,
        Double.longBitsToDouble(0x3fe2ad2781f5d530L), Double.longBitsToDouble(0x3fdb25b2bb39a23aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 1, 22, "\ud918\udcd2\ud9ca\udf24\ud88b\ude07", "\ubabc\u26ef", "\ud948\udf6e\ud99a\udcdf\uda29\ude9d\udbda\udc6b\ud809\udde2\ud96f\ude9f\ud821\udc38\uda4c\udf2b",
        9, 69174, 1590900479, -5778642963448767651L, -58170L, true, true, (char) 29323, (char) 15450,
        Double.longBitsToDouble(0x3fda779e6e094c9cL), Double.longBitsToDouble(0x3fe895f766af248cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 21, 3, 18, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\u8724\u76d8\u9c18\ucba1\u18b4\u88d6\u215c\u7545\u9224\u79ab\u93a7\u3e2a\u181e\u685f\u1f62\ubbca\u6d21\u9f26\u27c5", "\ud802\udf69\udb43\udc5d",
        41, 97914, 338577071, -7669253388823690977L, 19132L, false, true, (char) 52820, (char) 58809,
        Double.longBitsToDouble(0x3fdb25b2bb39a23aL), Double.longBitsToDouble(0x3fe4117c279e9a08L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 8, 2, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\u71f9\u26ef\u2732\ucba1\u6737\u88d6\u215c\u7545\u9224\u79ab\u93a7", "\ud906\ude90\ud838\udd76\ud855\ude1d\ud86a\udd05\ud954\ude8d\ud92f\ude42\ud892\udfbf\ud97a\udce6\ud802\udfa6\udb43\udc5d\ud89a\udf2e\ud95c\udef2\udbd2\udcaf\ud909\udffb\uda25\uddda\ud92a\ude68\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\uda8c\udeee\udb9a\udc68\udaba\udc7f\udace\udd2f\ud8a9\udf9a\uda12\udc7c\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbfb\uddb4\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\ucd3b\ud8b1\udc2d\ud9fe\uddd9",
        35, 33012, -1862239161, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2954edb7cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[] |a1=[Lorg.joda.time.DateTimeFieldType;:[[]] |a2=[I:[[51602, 1060, 11185]]\012",
        Z.run(T, 1, 18, 2, 13, "\ud918\udcd2\udae1\udfb0\udba8\udd97", "\uc9c2\u0454\u2be1", "\ud99a\udcdf\uda29\ude9d\udbda\udc6b\ud809\udde2\ud96f\ude9f\ud821\udc38\uda4c\udf2b\ud95e\ude85\ud8b2\udec3\uda3d\udc95\ud855\ude1d",
        32, 11182, -273755364, -6303763053894688498L, 54023L, false, true, (char) 62974, (char) 27451,
        Double.longBitsToDouble(0x3fe568a1706d9591L), Double.longBitsToDouble(0x3fcd1eab61704a0cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 1, 18, "\ud97c\udc04\uda3e\udd0c\ud8b0\udf92\ud80a\udfcf\ud869\udc3a\ud990\udeab\uda54\uddf9\uda10\udfeb\ud92a\ude68\ud969\udc12\ud92d\udc16", "\u9224\u79ab\u93a7\u3e2a\u181e\u685f\u1f62", "\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud802\udf69\udb59\udd5d",
        42, 97914, 338577071, -7669253389584488339L, -30276L, true, true, (char) 9734, (char) 24116,
        Double.longBitsToDouble(0x3fdb25b2bb39a23aL), Double.longBitsToDouble(0x3fe4117c279e9a08L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 11, 1, 22, "\udb82\udee9\udb88\uddb3\ud88b\uddfd", "\u1c53\u2ec9\uab6b\u704d\u3e0b\u3021", "\ud809\udde2\ud9ba\udea6\ud975\uddc6\uda4c\udf2b\ud95e\ude85\ud8b2\udec3\udadc\ude91",
        39, 94517, -1557508818, -1175770336952284953L, -2778L, true, true, (char) 48466, (char) 62974,
        Double.longBitsToDouble(0x3fe5792466ad142eL), Double.longBitsToDouble(0x3fbb656466a7aad8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 14, 1, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\ubabc\u26ef\u2732\u6e4c\u9343\u88d6\u215c\u7545\u9224\u79ab\u93a7", "\ud8b2\udec3\uda3d\udc95\ud855\ude1d\000\000\000\ud892\uded8\ud997\udcd5\ud802\udf69\u00a7\ud895\udc2a\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\uffc7\ud917\uddff\000\000\ud86f\udfcf\ud997\udf54\uda8c\udeee\udb9a\udc68\udaba\udc7f\udace\udd2f\u7ab6\ud8cf\uddfa\ud913\udce9\udbbe\udcd2\udaf4\udd37\uda30\udc91\ud925\udce5\udaff\uddcf\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\ud801\ude52\udbe4\udf71\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862270905, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2954edb7cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\012",
        Z.run(T, 1, 19, 17, 0, "\ud8f1\ude21\udae1\udfb0\ud88b\ude07\ud80a\udfcf\udb25\udd52\uda1f\udcc6\ud99a\ude40\ud8bf\udc10\uda57\udfdf\ud948\udf6e\uda75\uddfa", "\u1c25\u79ab\u4194\u1a22\u79b6\u9ab4\u1ea1", "\ub7b0\udb95\udf97\ud892\udf25\ud997\udcd5\ud802\udf69\udb43\udc5d\udad0\udd29\ud8f5\udef7\uda8b\udc16\ud9b3\udf51\udb34\udda9\udb96\udf95\ud8d9\udedb\ud870\uddb1\ud86f\udfcf\ud997\udf54\uda86\ude6a\ud9b2\udf06\udb98\udd3e\udace\udd05\udb3c\udf51\ud9a7\uddd0\ud94a\udeae\ud94e\udcda\ud99a\uddc9\udb10\udfd3\udb43\udfe1\ud8d1\uded0\ud9f2\udc4a",
        31, 95523, -1731128532, 7768800663085727412L, -59955L, true, true, (char) 7489, (char) 53317,
        Double.longBitsToDouble(0x3fdc00c313b3ed26L), Double.longBitsToDouble(0x3fe62cf0378e1960L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 25, 24, "\ud916\udd3d\udae1\udfb0\ud88b\ude07\ud856\udc4b\ud9d7\udd25\udb1b\udd83", "\ucba1\u18b4\u680b", "\ud821\udfe2\ud81d\udee9\udba9\udf9d\ud911\ude7c\udb40\uddeb\udba1\ude3d\uda3c\udfd4",
        39, 45079, 690638147, -2111580097990064051L, -75000L, true, true, (char) 48466, (char) 32553,
        Double.longBitsToDouble(0x3fe93e23f6a3c3e2L), Double.longBitsToDouble(0x3fd6d9591a43ca74L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 13, 15, 12, "\ud918\udcd2\udae1\udfb0\ud83f\udd62", "\ubabc\u26ef\u2732\ucba1\u298e\ua529\ua029\u33e1\u5925\u79ab\u93a7", "\ud8b2\udec3\uda8d\udfde\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud802\udf69\udb43\udc5d\ud8c2\udc2e\udaa4\ude1d\ud9b3\udf68\ud90a\udc67\ud989\udfcc\ud85b\udf44\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\ud824\ude1a\uda2d\udff0\udaba\udc7f\udace\udd2f\ud9dc\udeb4\ud8be\udc2f\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2977fdb7cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=new org.joda.time.Partial:[]\012",
        Z.run(T, 2, 13, 8, 15, "\ud918\udd12\udae1\udfb0\ud83f\udd62", "\u9363\u26ef\u2732\ucba1\u298e\ua529\u1a8e\u33c8\ub524\u79ab\u93a7", "\ud8b2\udec3\uda8d\udfde\udb25\udc3b\ud8b7\udeb8\udb7d\udc8f\uda59\udc10\ud89a\udf27\ud997\udd9c\udb6c\udf5e\ud826\udccd\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud85b\udf44\ud926\ude0d\udac6\udde1\ud86f\udfcf\ud997\udf54\udb0a\udeed\udb9a\udc68\udaba\udc7f\udace\udd2f\udaae\udcbc\ud8a9\udff4\ud94a\udeae\udbbe\udcd2\udaf4\udd37\udaae\udeb0\uda52\udfe6\ud964\udcad\u2a86\uda42\udc78\ud9a1\udc92\udb27\udde4\udb2c\udc16\uda6c\udf15\ud8d8\udcab\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\ud913\ude5b\ua7a1\ud85c\udfdb",
        18, 54580, -1846444985, 1891109214859735359L, -6715L, true, false, (char) 57106, (char) 14723,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2977fdb7cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 23, 22, "\ud918\udcd2\udb75\udfba\ud83f\udd62", "\ubabc\ub998\u2732\ucba1", "\udba6\uddba\ud938\udf3f\udae0\uded0\ud96a\udf9f\ud821\udc38",
        11, 23227, -1916661649, -2542260685172626272L, 50830L, false, true, (char) 30869, (char) 51602,
        Double.longBitsToDouble(0x3fad5c301a779e60L), Double.longBitsToDouble(0x3fe824e27712beecL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 1, 22, "\ud918\udcd2\udae8\udfb0\ud83f\udd62", "\ubabc\u26ef\u2732\ucba1\u298e\ua529\ua029\u33e1\u5925\u79ab\u93a7", "\ud8b2\udec3\uda8d\udfde\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud836\udec3\udb2f\udcac\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud961\udf36\uda10\ude92\ud8fc\ude7c\ud926\ude0d\ud886\udda2\uda7a\uddd0\ud99e\udd3f\udb0a\udeed\udb9a\udc68\udaba\udc7f\udbaa\udf5d\udabc\udd44\ud97e\udd79\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbff\uddb6\udacf\udd22\udaf5\udea2\udaf0\ude12\udba0\udc07\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 32936, 1056996423, 1891138927443489087L, -6715L, true, false, (char) 11026, (char) 14807,
        Double.longBitsToDouble(0x3fe9873f276e50a8L), Double.longBitsToDouble(0x3fe60bd2971233fcL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 24, "\ud918\udcd2\udae1\udfb0\ud83f\udd62", "\ubabc\u26ef\u2732\ucba1\u298e\ua529\ua029\u33e1\u5925\u79ab\u93a7", "\ud8b2\udec3\uda8d\udfde\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud950\udfc1\ud997\udcd5\ud802\udf69\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud85b\udf44\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\udb0a\udeed\udaa7\udcce\ud9a6\udc62\ud9b4\udd88\ud894\udef7\ud8be\udc2f\ud94a\udeae\ud900\udcd3\udaf4\udd37\uda30\udc91\udb71\uddea\ud93e\udda6\udbe3\udff1\uda74\udc3a\udad3\uddc5\udb46\ude86\ud8cc\udce6\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2977fdb7cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 22, "\ud918\udcd2\udae1\udfb0\ud83f\udd62", "\ubabc\u26ef\u2732\ucba1\u298e\ua529\ua029\u7e84\u5925\u6798\u93a7", "\ud8b2\udec3\uda8d\udfde\ud855\ude1d\ud86a\udd05\udbb5\udfbf\ud974\udf7b\ud892\udfbf\ud997\udcd5\u8869\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud85b\udf44\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\udb0a\udeed\udb9a\udc21\udaba\udc7f\udace\udd2f\ud9dc\udeb4\ud8be\udc2f\ud94a\udeae\udbbe\udcd2\ud811\ude05\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\u71a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2977fef00L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 22, "\ud918\udcd2\udae1\udfb0\ud83f\udd62", "\ub2b7\u26ef\u2732\ucba1\u298e\ua529\ua029\u33e1\u5925\u79ab\u93a7\u3e2a\u181e\u685f\u1891\ubbca\u6d21\u9f26\u27c5\ua137\u2c2a\u24b4\u9758\u79e2\u0a63\u169a\u1088\u6bcf\u83e1\u8182\u6b12", "\udb0a\udeed\udb9a\udc68\udaba\udc7f\ud87e\udd27",
        41, 75547, -879239739, 5869751646442246728L, -24078L, true, false, (char) 42042, (char) 62878,
        Double.longBitsToDouble(0x3fa710b479686cb0L), Double.longBitsToDouble(0x3fd679f9849bd36eL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 21, 19, "\ud918\udcd2\udae1\udfb0\ud83f\udd62", "\ubabc\u26ef\u2732\ucba1\u298e\ua529\ua029\u33e1\u5925\u79ab\u93a7", "\ud8b2\udec3\uda8d\udfde\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud802\udf69\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud85b\udf44\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\udb0a\udeed\udb9a\udc68\udaba\udc7f\udace\udd2f\ud9dc\udeb4\ud8be\udc2f\ud94a\udeae\udb02\udcb4\udaf4\udd09\uda30\udc91\ud9c5\ude54\udb17\ude67\udbe2\udfa5\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 33012, -1862239161, 1891109214859735359L, 68859L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2977fdb7cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null]] |a2=[I:[[47756, 9919, 9986, 52081, 6276, 23251, 22395, 48648]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 5, 25, "\ud918\udcd2\ud8d4\uddea\udafe\udcda", "\ubabc\u26ef\u2732\ucba1\u18b4\u5b03\u57ab\ube38\u23d5\u79df\u93a7", "\ud8b2\udec3\uda3d\udc95\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\ud84b\udfc7\udadd\udf84\udad2\uddcb\udbd2\udc72\udb54\ude37\ud89a\udf2e\ud960\udf37\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud917\uddff\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\uda8c\udeee\udb9a\udc68\udaba\udc7f\u188e\u7ab6\uda3a\udd70\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\ud83d\udfdf\u858b\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\ud9cc\udc58\ua818\udaf6\udc28",
        41, 58075, -1862239161, -3253690409457635009L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fdb927e4edca040L), Double.longBitsToDouble(0x3fe60bd293fd6b97L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null]]\0121=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 1, "\ud92c\udd9b", "\u5574\u3959", "\uda85\udd1a\ud9c0\udf3f\ud8f0\uddd6\udbe5\udfbd\ud9f6\ude76\udbea\uded6\udada\udff7",
        42, 85618, 403187960, 1720697240898646654L, 95450L, true, false, (char) 49742, (char) 53965,
        Double.longBitsToDouble(0x3fe20c40a635f780L), Double.longBitsToDouble(0x3fec0c48bc40c2c9L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]] |a2=[I:[[19041]]\0121=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 13, 25, "\uda1f\udf0b", "\u4a91", "\uda58\udd3f\udaa5\ude35",
        23, 22442, 2144541015, 4409886988686989718L, 71949L, true, false, (char) 851, (char) 62214,
        Double.longBitsToDouble(0x3fbf9be0cdb24cb0L), Double.longBitsToDouble(0x3fcdabd7cd7635f4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null]] |a2=[I:[[34290, 32519, 32619]]\0121=new org.joda.time.Partial:[]\012",
        Z.run(T, 2, 2, 8, 21, "\u02dc\uda2c\udc1a\uda4b\udea5", "\u8622\u7f37\u7f9b", "\ud9ce\udedf\udb07\udc1a\ud995\udebb\udab3\udfc7\ud923\udce3\uc3da\ud8b0\udd14\udb65\udfaa\udbcb\udde9\udbd9\udc40\udbcf\ude6c\udaed\ude46\u944c\udbb4\udfc6\ud8e4\ude72\udb52\udfa1\udb5c\udc05\uda57\uded7\ud812\udc12\ud9ca\udf2e\udad9\uddde\ud916\udf2f\ud94a\udf63\udba0\udf5c",
        13, 4671, 1372641653, 8065581390835620997L, 3687L, true, true, (char) 36746, (char) 25747,
        Double.longBitsToDouble(0x3fed43786715a86fL), Double.longBitsToDouble(0x3fec56981e49b107L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 21, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\ubabc\u26ef\u2732\ucba1\u18b4\u88d6\u215c\u7545\u9224\u79ab\u93a7", "\ud8b2\udec3",
        59, 75335, 0, -6689449436815371492L, -77049L, false, false, (char) 62738, (char) 27451,
        Double.longBitsToDouble(0x3fe568a1706d9591L), Double.longBitsToDouble(0x3fcd1ea001704a0cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[] |a1=[Lorg.joda.time.DateTimeFieldType;:[[]]\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 11, 4, "\ud918\udcd2\ud927\uddb6\ud91d\udd70", "\ubabc\u26ef\u9db6\u6d76\ud520\u054f\u0f43\u6644\uc65d\u79ab\u93a7", "\u264f\uda3d\udc0d\ud862\udee3\000\ud9a1\udfb5",
        -4, 21791, -1201659634, 8783853508723825063L, -12275L, true, false, (char) 27778, (char) 8927,
        Double.longBitsToDouble(0x3feb061c8afb09b3L), Double.longBitsToDouble(0x3fed481f95c8e7bbL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 13, "\uf8a5\ud815\udd84\udb3a\ude5f\uda2c\udc0d", "\u26ef\ubf31\ud2bd\ud366\u88d6\u5ee2\u207c\u298d\u534f", "\uda3f\udd00\ud93a\udf87\ud91e\udd04\ud88c\udf08\u623c\ua69c",
        31, 18957, -882892530, 8747433774015909543L, -85902L, true, true, (char) 18137, (char) 15692,
        Double.longBitsToDouble(0x3f88e2a41704a0c0L), Double.longBitsToDouble(0x3fd63988cda0673eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 21, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07\ud80a\udfcf\ub036\uda03\udc85\uda58\udd3f\ud91e\ude10\ud823\udf85\ud948\udf6e\ud99a\udcdf\uda29\ude9d\udbda\udc6b\ud809\udde2\ud96f\ude9f\ud821\udc38\ue9c2\ud95e\udd92\ud8b2\udec3\uda3d\udc95\ud862\udee3\000\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud802\udf69\u59a7\ud8f9\udc1c\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ucfc7", "\u56b4\u02e5\u41dd\u4733\ub1ca\u2437\u06bb\u547c\u866c\ucd82", "\uda1a\ude06\ud8b6\uddfa\udb90\udfe5\ud92f\udeaa\u19e0\ud888\udc07\udb16\udfaa\udb7b\ude39\uda66\udf86\udad7\udd3c\udb11\udcf8\ud8ab\uddcf\u0d66",
        47, 4236, -517624688, 6569129880658019709L, -23006L, false, true, (char) 7547, (char) 19847,
        Double.longBitsToDouble(0x3fbc7106e07e2fa8L), Double.longBitsToDouble(0x3fe98fb312cf9f6eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]] |a2=[I:[[53225, 51412, 53455]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 21, 18, "\ud950\udcce\udae1\udfb0\udb77\udf9e\ud80a\udfe0\ub036", "\ud019\uc904\ud0ff", "\udbda\udc6b\ud809\udde2\ud96f\ude9f\u7437\ue9c2\ud95e\udd92\ud8b2\udec3\uda47\ude95\ud8e6\udee5\000\ud9a1\udfb5\udb48\ude25\uda7d\uddc2\ud997\udcd5\ud802\udf69\u59a7\ud8f9\udc1c\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ucfc7\ud917\uddff\ud96a\udf0e\uda48\uddfa\udbfd\udfa3\ud950\udd54\ud8ad\udfcf\ud9f9\udd88\udb48\udd45\uda28\udd07",
        -1, 78443, 2027932990, -8200838355125819574L, -11388L, true, false, (char) 55330, (char) 60228,
        Double.longBitsToDouble(0x3fb21672db393f90L), Double.longBitsToDouble(0x3fd4bcf2d59d2b08L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null]] |a2=[I:[[50628, 11360, 53015, 52081, 6276, 34982, 1585, 932]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 23, 25, "\ud918\udcd2\udae1\udfb0\ud8a6\ude07", "\uc5f4\u2c90\ucf47\ucba1\u18b4\u88d6\u0661\u03d4\u917f\u79ab\u93a7\u3e2a\u181e\u685f\u1f62\ubbca\u7cce\u6daa\uc295", "\ud980\udf02\udb43\udc5d\ud99b\udfdc\ud95e\udd39\ud9b3\udfdf",
        22, 94239, 1546273377, -7711902692028774656L, 16685L, false, true, (char) 10288, (char) 34185,
        Double.longBitsToDouble(0x3fe93a85184a8550L), Double.longBitsToDouble(0x3fa6ebbb3e63c090L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=new org.joda.time.Partial:[]\012",
        Z.run(T, 2, 3, 3, 12, "\ud918\udcd2\udae1\udfb0\ud83f\udd62", "\ubabc\u26ef\u2732\ucba1\u298e\ua529\ua029\u33e1\u5925\u79ab\u93a7", "\ud8b2\udec3\uda8d\udfde\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud892\udfbf\ud997\udcd5\ud802\udf69\udb43\udc5d\ud8c2\udc2e\udaa4\ude1d\ud9b3\udf68\ud90a\udc67\ud989\udfcc\ud85b\udf44\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\ud824\ude1a\uda2d\udff0\udaba\udc7f\udace\udd2f\ud9dc\udeb4\ud8be\udc2f\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud964\udcad\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\udaeb\udc6a\uda04\udf1a\udafc\udff0\ua7a1\udaf6\udc28",
        41, 93564, -1861643820, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4fe2f640L), Double.longBitsToDouble(0x3fe3ed9ddf7fdbb2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]] |a2=[I:[[37125, 7408, 19350, 52081]]\0121=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]] |a2=[I:[[37125, 7408, 19350, 52081]]\012",
        Z.run(T, 2, 18, 2, 2, "\ud918\udcd2\udb75\udfba\ud83f\udd62", "\u9135\u1d20\u4bc6\ucba1", "\udba6\uddba\ud938\udf3f\udbac\uded6\ud96a\udf9f\ud821\udc38",
        11, 23227, -1803743121, -2582293774456050528L, 50830L, false, true, (char) 31893, (char) 22803,
        Double.longBitsToDouble(0x3fe34dc4d1a779e6L), Double.longBitsToDouble(0x3fe824e27712beecL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 13, 12, 22, "\ud918\udcd2\udb75\udfba\udaf2\udcdb", "\ubabc\ub998\u2732\ucba1", "\udba0\uddd1\uda69\uded7",
        29, 77668, -1076064621, 461809441809095667L, -76492L, false, true, (char) 30278, (char) 30869,
        Double.longBitsToDouble(0x3fe87544226e9d62L), Double.longBitsToDouble(0x3fda779e6e09389cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 10, 19, "\ud918\udcd2\udae1\udfb0\ud83f\udd62", "\ubabc\u26ef\u0cde\u17aa\u298e\ud333\u02af\u33e1\ud62f\u5f53\u93a7", "\ud8b2\ude51\uda8d\udfde\ud855\ude1d\ud86a\udd05\ud9f5\udd41\udac4\udd53\uda8c\udf44\ud997\udd44\udb77\ude84\udb43\udc5d\uda89\udfca\ud8a2\udf53\ud8ed\udce7\ud90a\udc67\ud989\udfcc\ud85b\udf44\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\udb0a\udeed\udb9a\udc68\udaba\udc7f\udace\udd2f\ud9dc\udeb4\udbd3\ude7d\ud938\uddb5\udb02\udcb4\ud852\uddca\uda27\udf58\udb7b\udc8f\ud916\ude34\udacd\udf2f\udb9f\udde1\ud9a9\udd09\uda5e\udde7\udb2c\udc16\uda5f\ude4f\ud8d8\udc4d\udbe2\udc42\u1670\uda90\uddb1\uda04\udf1a\udafc\udff0\ud816\udc56\udb97\udc73",
        45, 93747, -1862239161, 1891109214869958975L, 96550L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e44e29a40L), Double.longBitsToDouble(0x3fddb5540effb6f8L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 3, 14, 22, "\uf290", "\u4a7a", "\uda58\udd3f\ud91e\ude10",
        19, 87434, 2144541015, 2734736523614117931L, 86308L, true, true, (char) 21142, (char) 8634,
        Double.longBitsToDouble(0x3febf37c1effafbeL), Double.longBitsToDouble(0x3fe6baf69a0000ceL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[] |a1=[Lorg.joda.time.DateTimeFieldType;:[[]]\0121=new org.joda.time.Partial:[] |a1=[Lorg.joda.time.DateTimeFieldType;:[[]]\012",
        Z.run(T, 2, 2, 18, 4, "\ud918\udd27\ud927\uddb6\ud930\udc70", "\ubabc\u26ef\u6896\u6d1c\ud520\u054f\u0f43\u6644\u0825\u9e98\u92f2", "\u264f\uda3d\udc0d\ud862\udee3\000\ud97a\udd7d",
        36, 60898, -1201659634, 1722209293006887335L, -12275L, true, true, (char) 34187, (char) 8959,
        Double.longBitsToDouble(0x3fe4de1c8afb09ccL), Double.longBitsToDouble(0x3fed481f95c8e7bbL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 14, 1, 22, "\ud918\udcd2\udae1\udfb0\ud88b\ude07", "\ubabc\u26ef\u2732\ucba1\u18b4\u88d6\u215c\u7545\u9224\u79ab\u93a7", "\ud8b2\udec3\uda3d\udc95\ud855\ude1d\ud86a\udd05\ud9a1\udfb5\udb48\ude25\ud892\udfbf\udb70\udf41\ud802\udf53\udb43\udc5d\ud89a\udf2e\ud95e\udd39\ud9b3\udfdf\ud90a\udc67\ud989\udfcc\ud917\uddff\ud926\ude0d\ud886\udda2\ud86f\udfcf\ud997\udf54\uda8c\udeee\udb9a\udc68\udaba\udc7f\udace\udd2f\udacf\ude58\ud95b\udd80\ud94a\udeae\udbbe\udcd2\udaf4\udd37\uda30\udc91\uda67\udce6\ud9af\udcb4\u2a86\udbff\uddb6\ud9a9\udd09\uda5e\udde7\udb2c\udc16\udb06\udc51\ud8a4\ude53\udb7a\udfee\ud8b9\udf83\udaeb\udc6a\uda04\udf1a\uda40\udfd2\ua7a1\udaf6\udc28",
        41, 33012, -1862247884, 1891109214859735359L, -6715L, true, false, (char) 47890, (char) 14807,
        Double.longBitsToDouble(0x3fd8327e4edca040L), Double.longBitsToDouble(0x3fe60bd2954edb7cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[] |a0=[Lorg.joda.time.DateTimeFieldType;:[[]] |a1=[I:[[]]\012",
        Z.run(T, 1, 4, 7, 0, "\ud918\udcd2\000\000", "", "",
        48, 56694, 7271434, 0L, -78071L, false, false, (char) 0, (char) 7339,
        Double.longBitsToDouble(0x3e4df80000000000L), Double.longBitsToDouble(0x3fe7f80002d75ed3L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[] |a0=[Lorg.joda.time.DateTimeFieldType;:[[]] |a1=[I:[[]]\0121=new org.joda.time.Partial:[] |a0=[Lorg.joda.time.DateTimeFieldType;:[[]] |a1=[I:[[]]\012",
        Z.run(T, 2, 4, 5, 22, "\ud9d1\udfcd\000\000", "", "\ud8ab\udef4\ud823\udf85\uda0b\udc10\000\000\udbda\udc40\uda3f\udddd\ud91a\udf78\ud80c\udda5\uda47\udc65\uda5a\uddcc\ud859\udcaf",
        52, 86495, -2130430320, 8739469863265292020L, 82061L, false, false, (char) 53501, (char) 64272,
        Double.longBitsToDouble(0x3fd6a7abce0a9676L), Double.longBitsToDouble(0x3fd4bd0466162f9eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.field.UnsupportedDurationField|compareTo|org.joda.time.DurationField|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.Partial|with|org.joda.time.DateTimeFieldType,int|new:org.joda.time.Partial:",
    "C|org.joda.time.Partial|<init>|org.joda.time.Chronology,[Lorg.joda.time.DateTimeFieldType;,[I",
    "C|org.joda.time.Partial|<init>|",
    "C|org.joda.time.Partial|<init>|[Lorg.joda.time.DateTimeFieldType;,[I,org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|[Lorg.joda.time.DateTimeFieldType;,[I",
    "C|org.joda.time.Partial|<init>|org.joda.time.DateTimeFieldType,int,org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|org.joda.time.DateTimeFieldType,int",
    "C|org.joda.time.Partial|<init>|org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|org.joda.time.Partial,[I",
    "C|org.joda.time.Partial|<init>|org.joda.time.ReadablePartial",
    "M|org.joda.time.field.UnsupportedDurationField|add|long,int|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|add|long,long|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|equals|java.lang.Object|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|getDifference|long,long|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|getDifferenceAsLong|long,long|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|compareTo|org.joda.time.DurationField|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.Partial|with|org.joda.time.DateTimeFieldType,int|new:org.joda.time.Partial:",
    "C|org.joda.time.Partial|<init>|org.joda.time.Chronology,[Lorg.joda.time.DateTimeFieldType;,[I",
    "C|org.joda.time.Partial|<init>|",
    "C|org.joda.time.Partial|<init>|[Lorg.joda.time.DateTimeFieldType;,[I,org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|[Lorg.joda.time.DateTimeFieldType;,[I",
    "C|org.joda.time.Partial|<init>|org.joda.time.DateTimeFieldType,int,org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|org.joda.time.DateTimeFieldType,int",
    "C|org.joda.time.Partial|<init>|org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|org.joda.time.Partial,[I",
    "C|org.joda.time.Partial|<init>|org.joda.time.ReadablePartial",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
