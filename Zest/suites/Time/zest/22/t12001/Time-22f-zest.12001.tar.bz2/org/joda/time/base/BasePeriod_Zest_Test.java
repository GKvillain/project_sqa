package org.joda.time.base;
import org.junit.Test;
import static org.junit.Assert.*;
public class BasePeriod_Zest_Test {
  @Test
  public void test0() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test0() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=!java.lang.NullPointerException\012",
//         Z.run(T, 2, 2, 10, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\u47bc", "\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19",
//         24, 66833, -1125164901, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 47014,
//         Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd273aa81390394L)));
//   }
  @Test
  public void test1() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test1() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=!java.lang.NullPointerException\012",
//         Z.run(T, 2, 2, 10, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\u47bc", "\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19",
//         24, 66833, -1125164901, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 47014,
//         Double.longBitsToDouble(0x3ec0288c80000000L), Double.longBitsToDouble(0x3fd273aa81390394L)));
//   }
  @Test
  public void test2() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test2() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=!java.lang.IllegalArgumentException\012",
//         Z.run(T, 2, 2, 1, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\ub880\u771d\u3351\ua2d9\u3e85\u47bc", "\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19",
//         24, 66833, -1125164901, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 47014,
//         Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd273aa81390394L)));
//   }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 8, 13, "\udbb2\udf1f\uda59\ude90\ud9eb\udf6e\ud912\udea7\ud8df\udc25\ud82d\udce0\udb5d\udfe6\uda23\udd14", "\u9d09\u64c8\u1758\u3e85\u47bc\u31c3\ub867\uc35d\u36fb\u2576\u8505\uce29\u79d3\ucabf\u6b53\ub8c8\ub340\u07ed\ucf82\u1954\u3e1a\u3920\uc212\u281d\u2e51\uacb8\u2388\u6b48\uc7a8\u1b4a", "\u07a4\udb8c\udc5b\udb50\udde8\uda75\ude8a\ud850\uddd9",
        -3, 26737, 928364417, 2405801327191703014L, 89675L, false, false, (char) 14114, (char) 29098,
        Double.longBitsToDouble(0x3fde5e5272d4030eL), Double.longBitsToDouble(0x3febb738b7689e65L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 3, "\ud884\uddf0\uda76\udffc\ud927\ude13\udb7e\udf40\ud980\udc95\ud82d\udcdf", "\u9bd3\u6a18\u9d09\u64c8\u1758\u383b\u47bc", "\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19",
        24, 66833, -1125164901, -6539777430113699177L, 55054L, true, false, (char) 25482, (char) 47014,
        Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd273aa81390394L)));
  }
  @Test
  public void test5() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test5() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=!java.lang.NullPointerException\012",
//         Z.run(T, 2, 2, 3, 13, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7", "\u1689\u620a\ub0cf\u879a\u9d09\u64c8\u1758\u3e85\u47bc\u31c3\u7268", "\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19\uda34\udfc6\udb60\udff8\ud8af\udca7\udb0f\uddba\ud834\ude19\uda11\uded6\uda92\ude70\ud898\ude67\ud876\udf94\ud87c\udf0b\uda46\udf27\ud92f\udda9\udad3\udf13\ud881\udeff",
//         31, 12052, 1820204417, 1117406688881705637L, 14160L, false, true, (char) 57731, (char) 16067,
//         Double.longBitsToDouble(0x3feb1d9fc7bc17d4L), Double.longBitsToDouble(0x3fcecc5e20a03944L)));
//   }
  @Test
  public void test6() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test6() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=void |this=org.joda.time.Period:PT0S\012",
//         Z.run(T, 2, 2, 9, 13, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\u47bc", "\ud84a\udf14\ud875\udc83\udadd\udc18\udb95\udfb2\udb8b\udc60\udafe\udc1b\uda6a\ude0c\ud8dd\udc19",
//         24, 66833, -1125164901, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 47014,
//         Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd273aa81390394L)));
//   }
  @Test
  public void test7() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test7() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:PT0S\012",
//         Z.run(T, 2, 2, 5, 11, "\ud884\uddf0", "\u1bd5\u84de\ub3ba\ua68d\u7f06\u9bd3\u6a18\u2c26\u6f8c\u5958\u3e85\u47bc\u31c3\ub867\uc35d\u36fb\u2576\u4763\u019b", "\ud8dd\udc19",
//         24, 63385, -1139648357, -6539575119974188393L, 86900L, true, false, (char) 25482, (char) 47014,
//         Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd273aa81390394L)));
//   }
  @Test
  public void test8() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test8() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P24Y60513M543964251W24DT60513H543964251M84.513S\0121=!java.lang.NullPointerException\012",
//         Z.run(T, 2, 2, 10, 3, "\ud85e\udf3f\ud864\udfe2\udad7\udf39\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u3ef5\u79ba\u6435\u1758\u3e85\u47bc", "\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19",
//         22, 66833, -1125164901, 4353260188123576983L, 86900L, true, false, (char) 25482, (char) 47014,
//         Double.longBitsToDouble(0x3fb6cae079990360L), Double.longBitsToDouble(0x3fd27fe711390394L)));
//   }
  @Test
  public void test9() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test9() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P24Y60513M543964251W24DT60513H543964251M84.513S\0121=void |this=org.joda.time.Period:P24Y60513M543964251W24DT60513H543964251M84.513S\012",
//         Z.run(T, 2, 2, 9, 9, "\udba2\udd3e", "\u1bd5\u84de\ub3ba\u7725\ud2f1\u9bd3\u6a18\u9d09\u5c9b\u1758\u3e85\ucbc0\u31c3\ub867\uc35d\u36fb\u2576\u4763\u47c2", "\ud8dd\udc19",
//         24, 44113, 495219354, -6551931719409943913L, -38718L, true, true, (char) 38524, (char) 5259,
//         Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd4d3aa81390394L)));
//   }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 12, 3, "\ud884\uddf0\uda76\udffc", "\u84de\ub3ba\u7725\u7e33\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\u47bc\uc0ca\ub867\u0e09\u1595\u2576\u4763\uc865\u72a0\ud566\u6b53", "\ud8af\udcfa\udb0f\uddba\udb79\udc5b\udb23\udd7b\ud896\udfb0\ud914\udd41\udab1\udf8d\ud8ad\udc44\uda46\udf27",
        38, 78251, 984136227, -9094310095224813412L, 9848L, true, false, (char) 10955, (char) 58515,
        Double.longBitsToDouble(0x3fec1471a4739ae4L), Double.longBitsToDouble(0x3fe099f67e6aac05L)));
  }
  @Test
  public void test11() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test11() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P24Y60513M543964251W24DT60513H543964251M84.513S\012",
//         Z.run(T, 1, 2, 10, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\u47bc", "\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19",
//         24, 66833, -1125164901, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 47014,
//         Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd273aa813902f6L)));
//   }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud8e4\udca7\uda32\ude0e\ud82d\udd94", "\ubd81\u1a83\u9d09\u64c8\u1758\u3e85\u47bc", "\ud84a\udf14\ud875\udc83\uda6b\udebf\udad4\udd0c\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud98f\udd92",
        50, 66833, -1125173606, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 13457,
        Double.longBitsToDouble(0x3fcab6b0288c82d0L), Double.longBitsToDouble(0x3fd27e71e1390394L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P55Y17283M1108460081W55DT17283H1108460081M72.283S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 9, "\ud8f8\uddac\uda76\udffc\ud92a\udc76", "\ub3ba\u53cb\u1882\uc0eb\u6a18\u9d09\u64c8\u1758\u3e2f\u47bc\u31c3\ub867\uc35d\u36fb\u2576\u4763\u019b\u7235\ud566\u6b53\ub8c8\ub340\u341e\u4edd\ub9df\u6465", "\ud876\udf94\ud9cb\udeb3\ud84c\udc49\ud8d5\udfbf\ud863\ude44\udbd9\udd97\udbbf\uddb6\udabb\udd90\u569e\ud881\uddfc\udaa4\udeff\ud99d\udfe0\ud801\ude3f",
        55, 17283, 1108460081, -5209758390227491210L, -6408L, false, true, (char) 63258, (char) 7773,
        Double.longBitsToDouble(0x3fa654a6ce7ba160L), Double.longBitsToDouble(0x3fe1ac709cfc99b8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 3, 12, "\ud884\uddf0\udab9\udebe\uda67\uddf3\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\u47bc", "\ud84a\udf14\udadd\udc37\ud9f9\udf10\udb4d\uddf5\uda2f\udd00\ud9d2\udf5d\ud92e\ude34\ud8dd\udc21",
        24, 66833, -1125164901, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 47014,
        Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fe7c546589c81caL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 1, 2, "\udafa\udec9\uda76\udf8d\udb2a\udd76\ud8e6\udd8c\ud99a\udf74\ud9bd\uddaf", "\uc00b\ud3a8\u15bf\u7239", "\udac0\udea7\uda87\udf14",
        7, 57158, 1584403266, 707880001783526430L, -34102L, true, true, (char) 5679, (char) 6712,
        Double.longBitsToDouble(0x3fb2b87204dbb8c0L), Double.longBitsToDouble(0x3fe4a5e77f6784f2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P55Y17283M1108460081W55DT17283H1108460081M72.283S\0121=void |this=org.joda.time.Period:P55Y17283M1108460081W55DT17283H1108460081M72.283S\012",
        Z.run(T, 2, 2, 2, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u6a18\u9d09\u64c8\ud7c4\ub393\u47bc", "\ud84a\udf14\ud875\udc83\udadd\udc18\ufd24\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19",
        24, 66833, -1125164901, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 47014,
        Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd273aa81390394L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P55Y17283M1108460081W55DT17283H1108460081M72.283S\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 12, 8, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud84c\udd35\uda4e\ude0a\udb09\udf0d", "\u9bd3\u6a18\u2f70\u355c\u6abe\ubc1e\u47cd\u6aa5", "\ud875\udc83\udbe3\udefb\ud911\udd01\ud859\udf0b\ud8d8\udf9f",
        29, 2610, 429500994, 1489498236060129435L, -43460L, true, false, (char) 12206, (char) 16442,
        Double.longBitsToDouble(0x3fe8a12d220991b6L), Double.longBitsToDouble(0x3fe37088e05d848dL)));
  }
  @Test
  public void test18() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test18() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:PT0S\012",
//         Z.run(T, 2, 2, 7, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "", "\ud8e5\udfd5\000\uc139\uda19\udd7e\ud959\ude13\000\uda64\ude6d\ud84a\udf14\ud875\udc83\000\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19\uda34\udfc6\udb60\udff8\ud834\udca9\udb0f\uddba\ud92b\udc75\udb19\uded6\uda92\ude70\ud898\ude67\ud876\udf94\ud87c\udf0b\uda46\udf27\ud92f\udda9\ud863\ude44\udbd9\udd97\u8527",
//         57, 71451, -798389542, 1791230799591662684L, 56274L, false, false, (char) 13718, (char) 17200,
//         Double.longBitsToDouble(0x3fab993100239750L), Double.longBitsToDouble(0x3feebceee44ea053L)));
//   }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 10, 3, "\ud884\uddf0", "\uabdf\u847e\ub97a\u7725\u7d32\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\u192f\u81c2\ub867\uc35d\u36fb\u2576\u4763\u019b", "\ud8dd\udc19",
        24, 66833, -1125164901, -6539777430113699177L, 86900L, true, false, (char) 0, (char) 46873,
        Double.longBitsToDouble(0x3fb6cae040000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P4Y66833M-1125164901W4DT66833H-1125164901M70.833S\0121=void |this=org.joda.time.Period:P4Y66833M-1125164901W4DT66833H-1125164901M70.833S\012",
        Z.run(T, 2, 13, 9, 11, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud8e5\udea7\ud86d\udcaa\ud82d\udcdf", "\u3c9d\ud57c\u7e5f\u2034\u8a88\u3e85\u47bc", "\ud84a\udf14\ud9ae\udd5c\uda2d\udc23\udbaf\udc1e\ud98f\ude05\udae4\udf9b\ud878\uddda\uda05\udffa",
        4, 66833, -1125164901, -6539777430113699177L, 23668L, false, true, (char) 65315, (char) 19862,
        Double.longBitsToDouble(0x3fc1c36ed077bc2cL), Double.longBitsToDouble(0x3fb6f9fed1190360L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P4Y66833M-1125164901W4DT66833H-1125164901M70.833S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 8, "\u63f2\udaea\ude93\ud92a\udc68\udb4c\udcc4\uda2b\udd73\u1eef", "\u5bde\u6f2f\u18ca\u64c8\u1758\u3e85\u47bc", "\udbc7\udd6c\ud875\udc83\udadd\udc18\udbbe\udf31\ud98f\ude05\ud82b\udd11\uda6a\udec9\udbdc\udcd7",
        24, 66833, -1125164901, -6539777430113699177L, -79717L, false, false, (char) 65315, (char) 27583,
        Double.longBitsToDouble(0x3fbb844718cc2238L), Double.longBitsToDouble(0x3fb6cae051190360L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P4Y66833M-1125164901W4DT66833H-1125164901M70.833S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 5, "\uda5a\udef5\udb42\ude24\ud8fe\udd0f\ud912\udda7\ud86d\udcaa\ud82d\udcdf\udb5d\udfe6\ud93c\udf02\udbd5\udffe\uda2c\udc92\ud8a4\udfb5\udbac\udfa9", "\u4892\uad7a\u0487\uc35d\u36fb", "\ud907\udf85\ud8fb\udf07\ud877\udea2\ud963\uddca",
        45, 96689, -1125164901, -3163990791902360978L, -1225L, true, false, (char) 25482, (char) 47014,
        Double.longBitsToDouble(0x3febec540a2329b7L), Double.longBitsToDouble(0x3fd273aa81390394L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P34Y-795M2019578778W34DT-795H2019578778M33.205S\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P34Y-795M2019578778W34DT-795H2019578778M33.205S\012",
        Z.run(T, 2, 13, 7, 3, "\ud884\uddf0\uda5c\udff0\udb50\ude62\udb02\udfee\udbea\udc64\ud82d\udcdf\udb5d\udfe6\ud93c\udf02", "\u52e9\u3cc0\ud325\u4ad3\u74a9\u31c3\u9913\u32a7\ua4c4\ubd48\u4749\u013c\ud435\ud566\u6b53\u3d5b\u45eb\u211f\ucf82\u9746\u639c\u3920\u3c26\u5644\ud402\uc4e8\u21e4\u6b69\uc7a8\u7fb0", "\ud8b8\udff6\ud995\udc98\udb5f\udf62\uda53\uddbb\ud9a1\udc0f",
        34, -795, 2019578778, 2668625325191388983L, 9967L, true, true, (char) 41727, (char) 11499,
        Double.longBitsToDouble(0x3fec2af2ee9ef676L), Double.longBitsToDouble(0x3fe19f3ea7af6d1eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P34Y-795M2019578778W34DT-795H2019578778M33.205S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 3, "\ud884\uddf0\uda76\udffc\uda18\udd3d\ud811\udde6\ud86d\udcc5\ud898\udeec\udb5d\udfe6", "\u6a18", "\udb12\udc49\uda19\udd7e\udbce\udfdf\udb8a\udc2e\uda64\ude6d\ud84a\udf14\ud875\udc83\ud873\udc23",
        31, 19140, 336665197, -3880118014311907340L, -89311L, true, false, (char) 52862, (char) 24533,
        Double.longBitsToDouble(0x3fde697f4341982aL), Double.longBitsToDouble(0x3fac430a21425100L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P34Y-795M2019578778W34DT-795H2019578778M33.205S\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 13, "\udb5c\udc3b\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf\udb5d\udfe6\ud93c\udf02\udbd5\udffe", "\u64c8\u1758\u3e85\u47bc\u31c3\ub867\uc35d\u36fb\u2576\u4763\u019b\u7235\ud566\u6b53\ub8c8\ub340\u811e\ucf82\u9746\u645e\u50f6\ucea3\ubf5d\u2e51\u401e\ubea8\u6ac8\uc7a8\u7f91\u8f11\u8cbb\u49bb", "\ud9c1\udf4d\udb2e\ude9d\ud95d\udc0a\ud887\uddaa\ud952\udc53\u14bf\uda49\udf13\uda84\uddd3\uda12\udde9\udb9e\udff0\ud884\udc20\uda41\udd38\udbad\udcb7\udb39\ude9f\udac8\ude6f\ud96a\udff0\udb67\udcfe\udae2\ude05\uda59\udf66\ud9eb\udffe\udb94\udfb4\uf345\udbae\ude73\udb46\udc92\ud879\udfb3\ud800\udfed\udac0\udd91\ud9ef\uddec\ud919\udf23",
        -3, 11071, 1172030460, -7747898460822308897L, -65880L, false, false, (char) 38776, (char) 1610,
        Double.longBitsToDouble(0x3fe43c3415046740L), Double.longBitsToDouble(0x3fe7dd79c84eaba1L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P34Y-795M2019578778W34DT-795H2019578778M33.205S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 12, "\u3c1a", "\u1bd5\u0402\ub3ba\u7725\u18c5\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\u47bc\u31c3\ub867\uc35d\u36fb\u2576\u4763", "\uef6d\ud8dd\udc19\uda34\udfc6\udb60\udff8\ud8c4\udf72\udb0f\uddba",
        16, 99102, -2045458016, 2667089833296845332L, -13362L, true, true, (char) 26588, (char) 55950,
        Double.longBitsToDouble(0x3fd273aa81390394L), Double.longBitsToDouble(0x3fe5a44bb2313554L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P15Y8846M336665197W15DT8846H336665197M23.846S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud9ce\udec5\ud86d\udcaa\udb37\udee3", "\u9c88\u6a18", "\udb12\udc49\uda19\udd7e\udb18\udef3\udb8a\udc2e\uda64\ude6d\ud84a\udf14\ud875\udc83\uda1b\udc17",
        15, 8846, 336665197, -3861693497965264908L, 28236L, true, false, (char) 31194, (char) 38325,
        Double.longBitsToDouble(0x3fac430a21425100L), Double.longBitsToDouble(0x3fe04c8db26e111cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P15Y8846M336665197W15DT8846H336665197M23.846S\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 11, 10, "\ud884\uddf0\uda44\udd11\ud803\ude3c\ud912\udea7\ud86d\udcaa\ud8ee\uddd2", "\u9bd3\uaa18\u4e08\u64c8\u1758\u3e85\u47bc", "\ud84a\udf14\ud868\udf3d\u6379\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud946\udf6e",
        34, 66833, -1125147749, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 47014,
        Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd273aa81390394L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=void |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 14, 14, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\udbd6\udc0a\ud802\udfc1", "\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\015", "\ud84a\udf14",
        15, 38970, 167838600, 7906763547908053613L, -100000L, false, false, (char) 56449, (char) 27974,
        Double.longBitsToDouble(0x3fe8a5e77a00003eL), Double.longBitsToDouble(0x3fde697f4341982aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=org.joda.time.DurationFieldType$StandardDurationFieldType:weeks |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 2, 6, 10, "\ud95f\ude32\ud8c2\ude9d\ud8a2\udd88\ue218\ud86d\udcaa\ud863\uddea", "\u9bd3\u74c0", "\udb12\udc49\uda19\uddbe\udb18\udef3\udb8a\udc2e\uda64\ude6d\udb38\udd29\ud874\udfc3\udadd\udc18\udabb\ude85\ud878\ude5f",
        2, 33625, 1180188660, 1855951719929201345L, 33976L, true, false, (char) 31194, (char) 11190,
        Double.longBitsToDouble(0x3fac4321a1425100L), Double.longBitsToDouble(0x3fe04c8db26e111cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:PT0S\0121=void |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 5, 2, 9, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud8f0\ude6f\udbab\udec1\udb58\udf2d\ud93c\udf02\udbd5\udffe\ud9f0\udd3f\ud9f6\udd5d\udbe3\udc03\ub15b\uda19\uddb2\udb18\udef3\udb2b\uddb7", "\u36fb\ucaac\u479b\u019b\u7235", "\uda34\udfc6\udb60\udff8\ud8af\udca7\udb0f\uddba\ud99a\udfad\udaed\udf79\uda92\ude70\ud898\ude67\ud876\udf94\ud87c\udf0b\ud99b\udd54\ud92f\udda9\udb29\udedf\ud952\udc07\udbbf\uddb6",
        40, 68023, 2132033790, -7820587732173389904L, 56923L, true, true, (char) 12736, (char) 29832,
        Double.longBitsToDouble(0x3fec1c1069f2f661L), Double.longBitsToDouble(0x3fe59522f2ddfa60L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:PT0S\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 7, 7, 3, "\ud884\uddf0\uda77\udc59\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\u4396", "\udb0e\udc74\u259d\udadd\udc18\udbaf\udc1e\ud888\udf22\udae4\udfa4\uda6a\ude0c\udb17\udcf7",
        43, 66833, -1964025701, -5232314085844665705L, -44172L, true, false, (char) 25482, (char) 47014,
        Double.longBitsToDouble(0x3fb6cae051190150L), Double.longBitsToDouble(0x3fd273aa81390394L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 3, "\ud884\uddf0\uda76\udffc\ud9c6\udcbf\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\ub8b6\u7caa\u263a\u1b1f\u1779\u61eb\ud4ec", "\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\udb85\udf31",
        0, 4153, 1180188660, 6850443707573477622L, 28236L, false, false, (char) 11683, (char) 54395,
        Double.longBitsToDouble(0x3fdbd42824284a20L), Double.longBitsToDouble(0x3fe23b8850b6eec4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=void |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 9, 9, 3, "\udbff\udef6\ud9df\udc8d\udad2\udfad\ud8f5\ude68\udae8\udd0d\ud830\ude0a", "\u9bd3\u6a18\u9d09\u8d3f\u1758\u3ee4\u47bc", "\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19",
        24, 66833, -1125164901, -6539777430113699177L, 86900L, true, false, (char) 25482, (char) 47014,
        Double.longBitsToDouble(0x3f9da78144640d80L), Double.longBitsToDouble(0x3fd273aa81390394L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.joda.time.DurationFieldType$StandardDurationFieldType:millis |this=org.joda.time.Period:PT0S\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 11, 10, "\ud964\udcaa\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u6a18\ua9d2\u64c8\uc784\u3ed5\u2ad7", "\ud84a\udf14\ud875\udc83\udadd\udc18\ud8a0\udd22\ud98f\ude05\uda05\udd7e",
        7, 16958, -721704382, 1465242939607177371L, -17719L, false, true, (char) 18293, (char) 42221,
        Double.longBitsToDouble(0x3fe33d98420991b6L), Double.longBitsToDouble(0x3fe37088e36fd28dL)));
  }
  @Test
  public void test36() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test36() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P14Y21020M966258863W14DT21020H966258863M35.020S\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P14Y21020M966258863W14DT21020H966258863M35.020S\012",
//         Z.run(T, 2, 2, 7, 13, "\ud884\uddf0\uda76\udffc\ud92a\udc76\u7f0f\ud86d\udc8e\ud82d\udcdf", "\u00d4\u6a18\u9c86\uade7\u1a71\u0929\u4937", "\ud84a\udf14\ud8f9\udc85\udadd\udc18\udbaf\udc1e\ud98f\ude05\uc3a2\uda6a\ude0c\ud8dd\udc19\uda34\udfc6\udb60\udff8",
//         44, 14412, -1745569129, -3740835539548059232L, 45158L, true, false, (char) 62857, (char) 36422,
//         Double.longBitsToDouble(0x3ec0288c80000000L), Double.longBitsToDouble(0x3fd273aa8f390394L)));
//   }
  @Test
  public void test37() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test37() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P14Y21020M966258863W14DT21020H966258863M35.020S\0121=!java.lang.IllegalArgumentException\012",
//         Z.run(T, 2, 2, 1, 3, "\udb5e\udfeb\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u3e6c\uc805\u771d\u3351\u7ac2\u3774\u47c0", "\ud84a\udf14\ud875\udc83\udadd\udc18\ud8c0\ude0a\ud8db\udcc4\udbef\ude5b\uda6a\ude0c\ud8dd\udc19",
//         0, 66833, -1125164901, -6539777430113699327L, 86900L, true, false, (char) 25482, (char) 47014,
//         Double.longBitsToDouble(0x3fa5f7c0a23206c0L), Double.longBitsToDouble(0x3fa39d542fd87450L)));
//   }
  @Test
  public void test38() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test38() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P14Y21020M966258863W14DT21020H966258863M35.020S\0121=!java.lang.IllegalArgumentException\012",
//         Z.run(T, 2, 2, 11, 7, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf\ud80f\udfdf\uda01\udf3e\uda11\ude8f\uda2d\udec0\ud8a4\udfb5\udbac\udfa9\udb12\udc49\uda19\udd7e\udb18\udef3\udb8a\udc2e\uda89\udc6d\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19\uda34\udfc6\udb60\udff8\ud8af\udca7\udb0f\uddba\ud834\ude19\uda11\uded6\uda92\ude70\ud898\ude67\u9a4c\ud982\udfe2", "\u1b17\u5633", "\udb12\udfe5\udbc9\udc60\uda6b\udc8a\udbd7\udf8c\ud851\ude6f\udbd6\udccc\udb28\udd1d",
//         0, 72707, 1325479706, 1031659432592513064L, -20328L, true, true, (char) 53960, (char) 53964,
//         Double.longBitsToDouble(0x3fd5ae0531c34468L), Double.longBitsToDouble(0x3fe4ce2710ab1352L)));
//   }
  @Test
  public void test39() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test39() throws Throwable {
//     assertEquals("0=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P14Y21020M966258863W14DT21020H966258863M35.020S\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P14Y21020M966258863W14DT21020H966258863M35.020S\012",
//         Z.run(T, 2, 5, 5, 6, "\ud884\uddf0\ud9e6\ude02\ud92a\udc76\ud912\udea7", "\u1689\u620a\ub0cf\u879a\u0980\u68ee\u2b38\u6bb0\u174a\u31c3\u50ec", "\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19\ud896\udcf6\udb52\udefa\ud8af\udca7\udb0f\uddba\ud834\ude19\udbd9\udcb9\uda2f\udf93\uda98\udee6\ud883\udd06\uda95\udf69\udbe0\udcb8\ud92f\udda9\udad3\udf13\ud881\udeff",
//         31, 43236, -491995998, 1148849616174744229L, 14160L, false, true, (char) 57731, (char) 16067,
//         Double.longBitsToDouble(0x3fd92b3f8301ec68L), Double.longBitsToDouble(0x3fcecc5e20a03944L)));
//   }
  @Test
  public void test40() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test40() throws Throwable {
//     assertEquals("0=org.joda.time.DurationFieldType$StandardDurationFieldType:years |this=org.joda.time.Period:P14Y21020M966258863W14DT21020H966258863M35.020S\0121=org.joda.time.DurationFieldType$StandardDurationFieldType:years |this=org.joda.time.Period:P14Y21020M966258863W14DT21020H966258863M35.020S\012",
//         Z.run(T, 2, 6, 6, 6, "\ud828\udc22\ud8bc\udd0a\ud86c\ude0d\ud912\ude72\ud86d\udcaa", "\u7e33\u9bd3\u6a18\u97b8\u646c\u1758\u3e85\u9d4d\u31c3\ub867\uc35d\u36fb\u2576\u9674\u1480\ud658\ud566\u6b53\u2f74\ub340\u811e\ucf82\u9746\ub766\u7628\u3c26\ubf5d\u2e51\u401e\ubea8\uccf6\uc7a8\u7f91\u3134\u3a36\u5a76\u221b\u6681\uc164\u74de\u0c87\u0674\uc2a6", "\ud82a\ude28\ud8d3\ude1c\udb73\uddf9\ud802\ude7b\ud902\udcb3\udb97\udc8f\uda7e\ude98\udb05\ude20\udbe1\udebb\uda33\uddbe\uda1e\uddb2",
//         0, 40867, -976123067, -5990283365576581130L, 13832L, true, false, (char) 49083, (char) 29746,
//         Double.longBitsToDouble(0x3fe80d5840f77b54L), Double.longBitsToDouble(0x3fe91857c716c748L)));
//   }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P24Y60513M543964251W24DT60513H543964251M84.513S\0121=void |this=org.joda.time.Period:P24Y60513M543964251W24DT60513H543964251M84.513S\012",
        Z.run(T, 2, 13, 13, 13, "\ud884\uddf0\uda76\udffc\ud92a\udc76\uda00\udd9f\ud86d\udcaa\ud82d\udcdf\udb5d\udfe6\ud93c\udf02\udbee\udeb6\ud9f0\udd3f", "\u1758\u3e85\u47bc\u31c3\ub867\uc35d\u36fb\u2576", "\udafe\udc1b\uda6a\ude0c\ud8dd\udc19\uda34\udfc6\udb60\udff8\ud8af\udca7\udb0f\uddba\ud92b\udc75\udb19\uded6\uda92\ude70\ud898\ude67\ud876\udf94\ud87c\udf0b",
        24, 60513, 543964251, 4226832907656398119L, -54611L, false, false, (char) 43364, (char) 62051,
        Double.longBitsToDouble(0x3fa849133c9d34b0L), Double.longBitsToDouble(0x3fc52897af36e5a8L)));
  }
  @Test
  public void test42() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test42() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P41272M1245878773WT41272H1245878773M41.272S\0121=void |this=org.joda.time.Period:P41272M1245878773WT41272H1245878773M41.272S\012",
//         Z.run(T, 2, 2, 2, 7, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u4d69\u079e\u9c44\u8db7\uccfd\u3e85\uc08b", "\ud84a\udf14\ud875\udc83\uf794\ud9dc\udeb7\ud98f\uddbd\udae4\udf9b\ud899\ude59\udb69\ude4f\ud993\udca9\ud834\udc29\ud8af\udca7\udb0f\uddba\ud907\udf19\udb19\uded6\uda92\ude70\ud898\ude67\udb2c\uddb2\ud99f\ude70",
//         59, 60513, 543964251, 4226832909267010855L, -56445L, true, true, (char) 45655, (char) 42735,
//         Double.longBitsToDouble(0x3fe830c8f6c63c5bL), Double.longBitsToDouble(0x3fe98a86caaa6b3bL)));
//   }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P3Y76600M1840936846W3DT76600H1840936846M79.600S\0121=void |this=org.joda.time.Period:P3Y76600M1840936846W3DT76600H1840936846M79.600S\012",
        Z.run(T, 2, 13, 13, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud9aa\udd4a\udafd\udf01", "\u9bd3\u6a18\u9d09\u64c8", "\udb6d\udeab\uda99\udc5b\uda64\ude1e\ud928\udfc8\ud92c\udc15",
        3, 76600, 1840936846, 1505375924229644601L, -97591L, false, true, (char) 63632, (char) 47183,
        Double.longBitsToDouble(0x3fe4bd29f1e697f4L), Double.longBitsToDouble(0x3fda0cc150710c28L)));
  }
  @Test
  public void test44() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test44() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P24Y60513M91W24DT60513H91M84.513S\0121=!java.lang.IllegalArgumentException\012",
//         Z.run(T, 2, 2, 1, 6, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9bd3\u6a18\u9d09\u64c8\u1758\u3e85\uc08b", "\ud84a\udf14\ud875\udc83\udadd\udc18\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19\uda34\udfc6\udb60\udff8\ud8af\udca7\udb0f\uddba\ud92b\udc75\udb19\uded6\uda92\ude70\ud898\ude67\ud870\udf10\ud87c\udf19",
//         24, 60513, 543964251, 4226832907656398119L, 54168L, true, true, (char) 45655, (char) 42703,
//         Double.longBitsToDouble(0x3fe830c8f6c63c5bL), Double.longBitsToDouble(0x3fe98a86caaa6b3bL)));
//   }
  @Test
  public void test45() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test45() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P6Y884M1059081130W6DT884H1059081130M6.884S\0121=void |this=org.joda.time.Period:P6Y884M1059081130W6DT884H1059081130M6.884S\012",
//         Z.run(T, 2, 2, 2, 13, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud84c\udd35\uda4e\ude0a\udb09\udf0d\ud96f\udfc7\ud85f\ude57\udbd6\udc95\ud9e8\udf9c\ud963\udd7d\udb5e\udf7c\udaa3\udd05", "\u06f9\u65c9\uc34c\u36fb\u5789\ub281", "\udb6b\udc37\ud8fb\udf33\ud8b0\udfc4\udae5\udffa\ud836\ude0b\ud98f\udf37\uda09\udf43\ud95c\uddb5\ud843\udcdc\udba5\uddd5\ud861\udc94\uda35\udfc5\uda67\udc27\ud8ef\udecf\ud846\udda7\udb85\udf9b\ud820\udf0d",
//         29, 54719, 1660873301, 4425141311296313443L, 96322L, false, true, (char) 34280, (char) 11214,
//         Double.longBitsToDouble(0x3fe4ba230630c7b2L), Double.longBitsToDouble(0x3fd745bb7c781dfcL)));
//   }
  @Test
  public void test46() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test46() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P6Y884M1059081130W6DT884H1059081130M6.884S\012",
//         Z.run(T, 1, 2, 11, 3, "", "\u222f\ud3d9\u2e7e", "\000\000\000\000\000\000\000\ud959\ude13\000\uda64\ude6d\ud84a\udf14\ud875\udc83\000\udbaf\udc1e\ud98f\ude05\u086e\ud926\ude0a\ud89b\udff9\uda0a\udd84\ud846\udecb\ud834\udca9\udb0f\udda6\ud92b\udc75\udb19\uded6\uda92\ude70\ud898\ude67\ud876\udf94\ud87c\udf0b\uda46\udf27\000\000\udbaa\udf74\u8527\udbd9\udcbf\udb02\ude4e\ud808\udc0c\u7463\u9462\uda5d\udf52\000\000\udb1f\udf6e\020",
//         39, 5258, 5472215, 5183080219730423417L, 32583L, true, true, (char) 41552, (char) 43920,
//         Double.longBitsToDouble(0x3fbc1f1ecee38af0L), Double.longBitsToDouble(0x3fe644e1dd622801L)));
//   }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P19Y-1000M19DT-1000H18S\012",
        Z.run(T, 1, 13, 9, 11, "\ud884\uddf0\uda76\udffc}\ud8e5\udea7\ud86d\udcaa\ua91e", "\u3c9d\ud57c\u7e5f\u2034\u8a88\000\u19af", "\ud84a\udf14",
        19, -1000, 0, 0L, -84321L, true, false, (char) 239, (char) 47766,
        Double.longBitsToDouble(0x3ece93b275f40000L), Double.longBitsToDouble(0x3ea1000000000000L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |a1=[I:[[55883, 56736, 56010, 56864, 55546, 56390, 55477, 56951]] |this=org.joda.time.Period:P19Y-1000M19DT-1000H18S\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P19Y-1000M19DT-1000H18S\012",
        Z.run(T, 2, 4, 5, 6, "\uda7b\uddd0\udafa\ude50\ud92a\udc76\ud8e5\udea7\ud86d\udcaa\ud82d\udcdf", "\u3c9d\ud57c\u7e5f\u1600\u8a88\u3e85\u47bc", "\ud84a\udf14\ud9ae\udd5c\uda2d\udc23\udbaf\udc1e\ud98f\ude05\udae4\udf9b\udbd4\udcc6\u5567\udba7\uddbc\ud880\ude18\udbc0\udcf5\udb0f\uddba\ud92b\udc75\udb36\uddb6\ud82e\udf1e\ud87e\uddb5\uda0c\udd3d\ud91b\udf1c\ud894\udf8e\uda76\udeb2\ud863\ude44\ud8cc\udd71\uda79\udf63\uda3b\udded",
        0, 47824, 2115770808, -5472753978288406441L, 28862L, true, false, (char) 45707, (char) 22469,
        Double.longBitsToDouble(0x3fee759a5c29d2efL), Double.longBitsToDouble(0x3fc0a0d91630bd20L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P48Y94M2019578778W48DT94H2019578778M48.094S\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P48Y94M2019578778W48DT94H2019578778M48.094S\012",
        Z.run(T, 2, 13, 7, 7, "\ud884\uddf0\uda5c\udff0\udb50\ude62\udb02\udfee\udbea\udc64\ud82d\udcdf\udb5d\udfe6\ud93c\udf02", "\u52e9\u3cc0\ud325\u4ad3\u74a9\u31c3\u9913\u3e40\u381e\u1cca\u07ec\u81ce\u04bc\ud566\u6b53\u3d5b\u45eb\u211f\ucf82\u9746\u639c\u3920\u3c26\u5644\ud402\uc4e8\u21e4\u6b69\uc7a8\u7f6a", "\ud8b8\udff6\u2b75\udaa8\udccd\uda53\ude79\ud9a1\udc0f",
        48, 94, 2019578778, 2668625325191388983L, 9967L, true, true, (char) 41727, (char) 25583,
        Double.longBitsToDouble(0x3fed6ef5469ef676L), Double.longBitsToDouble(0x3fd33e7d4f5eda3cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P-5Y-1000M-5DT-1000H-6S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud9ce\udec5\ud86d\udcaa\udb37\udee3", "\u9c88\u6a18", "\udb12\udc49\uda19\udd7e\udb18\udef3\udb8a\udc2e\uda64\ude6d\ud84a\udf14\ud875\udc83\uda1b\udc17",
        -5, -1000, 0, -3861693497965264908L, 28236L, true, false, (char) 31194, (char) 38325,
        Double.longBitsToDouble(0x3fac430a21425100L), Double.longBitsToDouble(0x3fe04c8db26e111cL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P-5Y-1000M-5DT-1000H-6S\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 0, 3, "\ud884\uddf0\uda76\udffc\ud9c6\udcbf\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\ub8b6\u7caa\u263a\u1b1f\u1779\u61eb\ud4ec", ".\000\udadc\udfd6\udbaf\udc1e\udb85\udf31",
        0, 4153, 1180188660, 6850443707573477622L, 28236L, false, false, (char) 11683, (char) 54395,
        Double.longBitsToDouble(0x3fdbd42824284a20L), Double.longBitsToDouble(0x3fe23b8850b6eec4L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P45Y-991M45DT-991H44.009S\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 11, 3, "\udbe8\udfb2", "\u3514\u5a86\u462d", "\uda23\ude03\ud96e\udeca\ud8a4\udfb5",
        45, -991, 0, 0L, 98098L, true, true, (char) 38383, (char) 53715,
        Double.longBitsToDouble(0x3fc1c1403697bca4L), Double.longBitsToDouble(0x3fd3b8f61ea2f208L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |a1=[I:[[55883, 56736, 56010, 56864, 55546, 56390, 55477, 56951]] |this=org.joda.time.Period:P45Y-991M45DT-991H44.009S\0121=void |a1=[I:[[55883, 56736, 56010, 56864, 55546, 56390, 55477, 56951]] |this=org.joda.time.Period:P45Y-991M45DT-991H44.009S\012",
        Z.run(T, 2, 4, 4, 2, "\uda7b\uddd0\udafa\ude50\ud92a\udc76\ud8e5\udea7\ud86d\udcaa\ud82d\udcdf", "\u3c9d\ud57c\u7e5f\u1600\u8a88\u3e85\u47bc", "\ud84a\udf14\ud9ae\udd5c\uda2d\udc23\udbaf\udc1e\uda06\udfe2\udae4\udf5e\udbd4\udcc6\u5567\udba7\uddbc\ud880\ude18\udbc0\udcf5\udb0f\uddba\ud92b\udc75\udb36\uddb6\ud82e\udf1e\ud87e\uddb5\uda0c\udd3d\ud91b\udf1c\ud894\udf8e\uda76\udeb2\ud879\udd44\ud8cc\udd71\uda79\udf63\uda3b\udded",
        0, 47824, 2115770808, -5472753978288406441L, 28862L, true, false, (char) 45707, (char) 22469,
        Double.longBitsToDouble(0x3fee759a5c29d2efL), Double.longBitsToDouble(0x3fc0a0d91630bd20L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P45Y-991M45DT-991H44.009S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\u9c06\u6a18\u9d09\u385e\ud43e\u6059\uc59f", "\ud84a\udf14\udb61\udeda\udadd\udc79\udbaf\udc1e\ud98f\ude05\udae4\udf9b\uda6a\ude0c\ud8dd\udc19",
        24, 66816, -1125164901, -6539777429745602665L, 86900L, true, false, (char) 25482, (char) 47014,
        Double.longBitsToDouble(0x3fb6cae051190360L), Double.longBitsToDouble(0x3fd273aa81390394L)));
  }
  @Test
  public void test55() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test55() throws Throwable {
//     assertEquals("0=void |this=org.joda.time.Period:P41272MT41272H41.272S\0121=void |this=org.joda.time.Period:P41272MT41272H41.272S\012",
//         Z.run(T, 2, 4, 4, 0, "\ud884\uddf0\uda76\udffc\ud94a\udce6\ud912\udea7\ud86d\udcaa\ud82d\udcdf", "\ub8b6\u7caa\ucc71\u1b29\u1779\u0c10\ud4ec", "\ud84a\udf14\udb96\udf44\udadd\udc18\udbaf\udc1e\udb85\udf31",
//         0, 4153, 1180188660, 6850443709029980406L, 28236L, false, false, (char) 11683, (char) 54395,
//         Double.longBitsToDouble(0x3fdbd42824284a20L), Double.longBitsToDouble(0x3fe23b8850b6eec4L)));
//   }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P34Y-795M154W34DT-795H154M33.205S\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P34Y-795M154W34DT-795H154M33.205S\012",
        Z.run(T, 2, 13, 5, 13, "\ud884\uddf0\u4de3\udb50\ude62\udb02\udfee\udbea\udc64\ud82d\udcdf\udb5d\udfe6\ud93c\udf02", "\uc251\ub900\ud325\u4ad3\u74a9\u31c3\u9913\u32a7\ua4c4\u64d9\u4749\u013c\ud435\ud566\u6b53\u3d5b\u45eb\ud09b\000\u8b8d\u639c\u3920\u3c26\u5644\ud402\u3213\u21e4\u6b69\uc7a8\u7fb0", "\ud8b8\udff6\ud995\udc98\udb5f\udf62\uda53\uddbb\ud9a1\udc0f",
        34, -795, 154, 2668382779798249271L, 9967L, true, true, (char) 41727, (char) 11499,
        Double.longBitsToDouble(0x3fec2af2ee9ef676L), Double.longBitsToDouble(0x3fe19f3ea7af6d1eL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P1Y-1000M336658432W1DT-1000H336658432M\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 3, "\ud884\uddf0\uda76\udffc\ud92a\udc76\ud9ce\udec5\ud86d\udcaa\udb37\udee3", "\u9c88\u6a18", "\udb12\udc49\uda19\udd7e\udb18\udef3\udb8a\udc2e\udad9\udde7\ud84a\udee6\ud875\udc83\uda1b\udc17",
        1, -1000, 336658432, 143181324746752L, 28236L, true, false, (char) 57843, (char) 38325,
        Double.longBitsToDouble(0x3fac430a21425100L), Double.longBitsToDouble(0x3fe04c8db26e111cL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P1Y-1000M336658432W1DT-1000H336658432M\0121=void |this=org.joda.time.Period:P1Y-1000M336658432W1DT-1000H336658432M\012",
        Z.run(T, 2, 13, 9, 3, "\ud884\uddf0\ud8b8\udcfa\ud92a\udc76\uda84\ude5f\ud891\udc9b\udb37\udee3", "\u9c88\u6a18", "\udb12\udc49\uda19\udd7e\udb18\udef3\udb8a\udc2e\udad9\udde7\ud84a\udee6\ud875\udc83\uda1b\udc17",
        1, -1000, 336658432, 143181336739840L, 28236L, true, false, (char) 57843, (char) 38325,
        Double.longBitsToDouble(0x3fac435ba1425100L), Double.longBitsToDouble(0x3fe04c8db26e111cL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P1Y-1000M1DT-1000H\0121=void |this=org.joda.time.Period:P1Y-1000M1DT-1000H\012",
        Z.run(T, 2, 13, 2, 3, "\ud689\000\000\000\000\udb0d\uddc5", "\u9bb4\u6a18", "\udb12\udc49\uda19\udd7e\000\uda23\udf30\udad9\udde7\ud84a\udee6\ud875\udc83\uda1b\udc17",
        1, -1000, 0, 0L, 31072L, true, false, (char) 57843, (char) 21,
        Double.longBitsToDouble(0x3e30a12880000000L), Double.longBitsToDouble(0x3f83236c00000000L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:P1Y-1000M1DT-1000H\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P1Y-1000M1DT-1000H\012",
        Z.run(T, 2, 2, 7, 8, "\ud689\000\udbf7\udc7b\ud912\udea7\ud897\udcd0\ud82d\udcdf\udb5d\udfe6\037\udbc9\udffe\ud9f0\udd3f\ud9c2\udda1\ud89e\udfef\u672a\ud9fa\ude1c", "\ub785\uc35d", "\ud9a1\udc54\u1a50\ud99c\udc61\ud813\udcf2\ud8aa\udf60\ud9dc\uddc7\udaac\ude36\udabc\udf8a\ud965\udd7d\ud8bb\udcf6",
        38, 59561, -4804146, -7003861776860150314L, -38374L, false, false, (char) 64531, (char) 6374,
        Double.longBitsToDouble(0x3fc18dac5454171cL), Double.longBitsToDouble(0x3fd269aad367481eL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P1Y-1000M1DT-1000H\0121=org.joda.time.PeriodType:PeriodType[Standard] |this=org.joda.time.Period:P1Y-1000M1DT-1000H\012",
        Z.run(T, 2, 7, 7, 8, "\ua84f\000\udaba\ude7e\ud912\udea7\ud897\udcd0\ud82d\udcdf\udb5d\udfe6\ud8b3\udc5e\uda6d\ude2c\uda07\udf2d\ud9c2\udda1\uce77\ud993\ude60\uda26\udcba", "\u8d86\uc35d", "\ud9a1\udc54\u1a50\ud99c\udc61\ud813\udcf2\ud8aa\udf60\ud9dc\uddc7\udaac\ude36\udabc\udf8a\ud965\udd7d\ud8bb\udcf6",
        38, 59561, -4804146, -8405223250932473909L, -44006L, false, false, (char) 64531, (char) 6374,
        Double.longBitsToDouble(0x3fc18dac5454171cL), Double.longBitsToDouble(0x3fd269aad367481eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.base.BasePeriod|addField|org.joda.time.DurationFieldType,int|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|addFieldInto|[I,org.joda.time.DurationFieldType,int|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|addPeriod|org.joda.time.ReadablePeriod|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|addPeriodInto|[I,org.joda.time.ReadablePeriod|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|checkAndUpdate|org.joda.time.DurationFieldType,[I,int|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|checkPeriodType|org.joda.time.PeriodType|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|getFieldType|int|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|getPeriodType||fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|getValue|int|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|mergePeriod|org.joda.time.ReadablePeriod|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|mergePeriodInto|[I,org.joda.time.ReadablePeriod|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|setField|org.joda.time.DurationFieldType,int|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|setFieldInto|[I,org.joda.time.DurationFieldType,int|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|setPeriod|int,int,int,int,int,int,int,int|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|setPeriod|org.joda.time.ReadablePeriod|fld:org.joda.time.Period:ZERO",
    "M|org.joda.time.base.BasePeriod|setPeriodInternal|int,int,int,int,int,int,int,int|fld:org.joda.time.Period:ZERO",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
