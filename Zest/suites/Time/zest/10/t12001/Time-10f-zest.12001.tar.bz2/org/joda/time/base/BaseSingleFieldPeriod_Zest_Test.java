package org.joda.time.base;
import org.junit.Test;
import static org.junit.Assert.*;
public class BaseSingleFieldPeriod_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udba0\ude42\ud9d6\udc9f\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u18cc\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u4db3\u0473\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude68\ud9a6\udf5f",
        24, 29480, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\ud909\udc6f\ud90d\udd5d\uda01\udec2\ud88f\ude9a\udb18\udcd3\udb3a\udfab\u6571\uda10\ude57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\udbf4\uddf2\udb5d\udeff\ud9d6\ude43\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u276f\u9844\ud28f\u03fc\u75f5\u4c95\u29ab\u32ea\u1a87\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u5235\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u4db3\u0473\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude68\ud9a6\udf5f",
        24, 66808, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe20628401e8a10L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 13, 4, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\uda9a\udc18\u1ed3\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u18cc\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u4db3\u0473\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude68\ud9a6\udf5f",
        24, 29480, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 14, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\ud8a6\uddc5\uda19\udd74\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udba0\ude42\ud9d6\udc9f\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda23\udca5\ud8cd\udd31\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u7017\u980e\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u4db3\u7e0b\u7cc3\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude68\ud9a6\udf5f",
        24, 29480, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 11, 1, 6, "\ud998\udda7\uda43\udc9b\uda85\ude8d\udaa8\ude7f\uda91\udf3e\uda5f\ude21\ud952\udd97\udb5a\ude55\u2070\ud8ce\udd43\uda65\udf91\udbda\udc82\ud869\udfac\udbdf\udfa1\udba0\ude42\ud9d6\udc9f\ud80a\udee3\udaef\udd61\ud8af\udca1\uda17\udc6a\udb34\udc6f\udbb9\udc7b\udbbd\udf97\ud841\udcdf\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udba8\udf8c\ud8b5\uddb3", "\u503f\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u18cc\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\u849f\u7e85\ubf69\u65c5\u1ca6\u1cbe\u83d4\u0b3d\u72c9\u3460\u2028\u1088\u2e0d\ua3c4\ua03f\ud65c\u24fd\u4e03\u46e4\uc9b9\u4ccf\ua15e\u5905\u7b55\ua566\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\udbbe\udf9e\ud9b4\ude08\uda33\ude68\udb07\udf37",
        53, 29480, -331337169, -1592166261212331243L, -68729L, true, true, (char) 54581, (char) 8299,
        Double.longBitsToDouble(0x3fefa8bf1398d956L), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udb49\udee0\uda91\udfbf\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udbc3\udf42\ud9d6\udc9f\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud8fd\udf9f\ud864\udc55\ud83b\udc60\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u3de1", "\ud84d\udeba\udb9b\uddd8",
        10, 25171, -798215845, -7135621020359679591L, 69856L, false, true, (char) 30503, (char) 52660,
        Double.longBitsToDouble(0x3fd39a9658085d72L), Double.longBitsToDouble(0x3fbe11e3c53de6a0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.joda.time.PeriodType:PeriodType[Days] |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 7, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udba0\ude42\ud9d6\udc9f\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u18cc\u9844\ud28f\u03fc\uc6b1\u58f7\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\ua12f\ua10b\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u4db3\u0473\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude68\ud9a6\udf5f",
        24, 29480, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.joda.time.DurationFieldType$StandardDurationFieldType:days |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 5, 4, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\ud9c4\udd73\udb01\udd63\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\ud934\udf2c\u3789\udb99\udda4\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u90fb\uc1db\u09fd\u04cd\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\u1cbe\u83d4\ub711\uc002\ud78d\u11c8\u1fd0\u868e\uc785\u0817\ud6d3\u3bf6\u4e28\u46e4\u8ab9\u05d4\u9511\u5905\u48e0\u0473\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\uda66\udfa4\ud9ed\ude4a\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude68\ud9a6\udf5f\ud90a\ude43\ud865\udf5c",
        1, 64905, -1747395819, 3910592712623535221L, 9705L, true, true, (char) 37570, (char) 26418,
        Double.longBitsToDouble(0x3fe2062840024c57L), Double.longBitsToDouble(0x3fefd9a1ae9d62f2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P5D |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 15, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udba0\ude42\ud9d6\udc9f\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc60\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u18cc\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\u4a69\u829e\u313b\u2182\u7184\u0c7c\uc002\u21c7\u58db\ua842\u80ef\ua15f\u7f80\u56ec\u3c8d\u4e28\u4f71\ua7ad\u0bd4\u8200\u5905\u4db3\u0473\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude54\ud9a6\udf5f",
        24, 29480, -331337169, -9141888086685204734L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fa9196eba39b8f0L), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P5D |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 15, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udba0\ude42\ud9d6\udc9f\udbc7\udde8\ud915\udef5\udb6b\udd0e\uda17\udccf\ud904\ude4c\ud9c0\udeb0\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u01fb\ub579\uce52\u64b7\u0f62\ucfc7\u8b95\u46d5\u18cc\u9844\ud28f\ua3ca\u5cf9\u58f7\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u2db2\u1a0b\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u4db3\u0473\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\u2640\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda13\udc58\ud9a6\udf5f",
        24, 29480, -331337169, -1592166258000806123L, -86571L, true, true, (char) 10502, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 3, 5, 4, "\udbd2\udfbe\ud8fb\uddb5\udb31\ude0e\udac3\udee9\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb32\udd26\ud95e\udc1b\udb42\udc79\udba0\ude06\ud9d6\udc9f\ud9a4\udf1b\udb71\udd42\udb6b\udd0e\uda17\udccf\udbe9\udc70\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u1656\ua9cb\u41a0\u9844\ud28f\u03fc\u5cf9\u58f7\ub887\u180f\u7e85\u13ce\u829e\u2c75\u1cbe\u83d4\u0c7c\uc002\u21c7\u53d6\u246f\ud0bf\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u2837\u4db3\u0cbe\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud8da\uddca\ue896\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude68\ud9a6\udf5f",
        24, 29480, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 35618,
        Double.longBitsToDouble(0x3fcc7a346e8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 4, 4, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\udb47\uded8\ud8a0\udd8b\ud952\uddc0\udb5a\ude55\u6571\udb08\udf09\uda4a\udff2\udac2\udf15\ud95e\udc1b\ud8fa\uded5\uda08\udcaf\uf16e\udabf\udc3c\uda76\udc5b\udb69\udfdf\ud9e3\udd75\udb34\udc6f\ud9c0\udc41\udbbd\udf97\udaeb\ude48\uda9a\udd71\udbcb\udc99\udb46\udd10\uda25\udc71\ud8a0\uddf2", "\u9561\ud77f\u9f0d\ud65e\u5466\u2dc8\ub564\ud561\u3fd1\u18d9\ub747\u51fc\u611f\u5939\u091f\ucd54\u4e4d\u4655\ubc80\u2b3b\u1cbe\u83d4\u0c7c\u1baf\u21c7\u58db\u3b85\u8e13\u71be\u4f58\ud65c\u3bf6\u4e28\u5357\u7abf\ud0cb\ua15e\u1234\u4db3\u0473\u3232\u34e8", "\ud98c\udd92\udb05\ude09\u7f0a\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude14\uda33\ude68\ud9a6\udf5f",
        24, 29480, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062843d7044eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:12656 |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 10, 5, 13, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\ud8bd\udd30\ud958\udddc\ud900\udcf8\ud80d\udc45\uda05\udc3e\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5", "\ud5d9\ubbd4\u330a\ucd91\ubc81\ubf76\u8a1b\u6ef9\u1857\u23bb\ua8f1\u23a4\u72df\u4b03", "\ud8c5\ude07\udb9d\udd2b\ud991\udcb1\uda85\udfbe\ud87f\ude05\u1d69\udb33\ude70\ud1e5\ud84d\udeba\udb9b\uddd8\ud835\udfa3",
        29, 87155, -1661391235, -745731010482112502L, -95008L, true, true, (char) 16855, (char) 52498,
        Double.longBitsToDouble(0x3fcee5d721e11e3cL), Double.longBitsToDouble(0x3fc4f79a946cd6acL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 16, 4, "\u58d5\ud8fb\uddb5\uda81\udcab", "\u3cba", "\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\uda9a\udc18\u1ed3\ud80a\udee3\ud915\udef5",
        9, 2289, 1013992672, -6192584377300417511L, -40042L, false, true, (char) 24595, (char) 38400,
        Double.longBitsToDouble(0x3f9ecbb2b7ab3a80L), Double.longBitsToDouble(0x3fdc247f354b77daL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.Days:P5D\012",
        Z.run(T, 1, 3, 4, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\udabb\udc54\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\uda9a\udc18\u1ed3\ud80a\udee3\ud915\udef5\uda76\udc25\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u011c\u202e\u1220\u48c3\u40db\u2d75\u3de1\u46d5\u18cc\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\ubf69\u6d95\u2b3b\u1cbe\u83d4\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5d2b\u4dcd\u0473\u9ce5\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\udbb0\udc5d\ud93c\udc3d\ud954\ude12\ud98a\udf44\uda57\udda6\uda33\ude68\ud9a6\udf5f",
        31, 29480, -297782737, -1592165672941469931L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3be77baa3cL), Double.longBitsToDouble(0x3fe54d5a48028a10L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 14, 14, 9, "\udbd2\udfbe\ud8fb\uddb5\udaa2\uddab\udac3\udefd\uda91\udf3e\ud8a6\uddc5\uda19\udd74\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udba0\ude42\ud9d6\udc9f\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\u6f53\uda9a\udd73\uda23\udca5\ud8cd\udd31\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u4408\ua20b\u2dc8\u3de1\u46d5\u7017\u980e\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u4db3\u7e0b\u7cc3\u34ef", "\ud85b\udfce\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud807\udead\uda33\ude68\ud9a6\udf5f",
        24, 29480, -333854577, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Days:P24D\012",
        Z.run(T, 1, 12, 8, 11, "\udbd2\udfbe\ud8fb\uddb5\ud9f2\udebb\udac3\udefd\ud95a\udf0a\ud8a6\uddaa\uda19\udd74\udb5a\ude55\u6571\uda26\udc57\udb33\udcc7\udb87\udd11\ud95e\udc6f\ud8c4\udf18\udba0\ude42\ud9d6\udd05\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda23\udca5\ud8cd\udd31\ud87a\ude2c\ud8b5\uddb2", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u7017\u980e\ud28f\u03fc\u5cf9\u58f7\u5cad\ucce7\u7e85\ubf69\u829e\u5c1e\u07b1\u83d4\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\u4c5c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u8be2\u7e0b\u7cc3\u34ef", "\ud907\udcda\udb3f\udde7\udb23\udeac\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\uda34\udf9f\ud8e0\uddaf\uda33\ude68\ud9a6\udf5f",
        24, 29480, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\ud8a6\uddc5\uda19\udd74\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udba0\ude42\ud9d6\udc9f\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\ud9de\udca7\udb42\udea0\uda9a\udd73\uda23\udca5\ud8cd\udd31\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u556a\u2bb0\u0bef\u3d4e\u46d5\u7017\u980e\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u21c7\u58db\ua842\ub572\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\ubeb2\uc29a\ud725\u5905\u4db3\u7e0b\u8c2b\u34fb", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude68\ud9a6\udf5f",
        24, 29480, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 9, 2, 6, "\ud998\udda7\uda43\udc9b\uda85\ude8d\udaa8\ude7f\uda91\udf3e\uda5f\ude21\ud952\udd97\udb5a\ude55\u2070\ud8ce\udd43\uda65\udf91\udbda\udc82\ud869\udfac\udbdf\udfa1\udba0\ude42\ud9d6\udc9f\ud80a\udee3\udaef\udd61\ud8af\udca1\uda17\udc6a\udb34\udc6f\udbb9\udc7b\udbbd\udf97\ud841\udcdf\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udba8\udf8c\ud8b5\uddb3", "\u503f\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u18cc\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\u849f\u7e85\ubf69\u65c5\u1ca6\u1cbe\u83d4\u0b3d\u72c9\u3460\u2028\u1088\u2e0d\ua3c4\ua03f\ud65c\u24fd\u4e03\u46e4\uc9b9\u4ccf\ua15e\u5905\u7b55\ua566\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\udbbe\udf9e\ud9bb\udd08\uda33\ude68\udb07\udf37",
        53, 29480, -331337169, -1592166261212331243L, -68729L, true, true, (char) 54581, (char) 8299,
        Double.longBitsToDouble(0x3fefa8bf1398d956L), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.Days:P24D\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 6, "\ud998\udda7\uda43\udc9b\ud931\udf6b\uda49\udf4f\uda91\udfe4\ud8bd\udd30\ud927\udf97\ud584\udb8f\uded4\udb90\udc32\uda65\udf98\udbda\udc82\ud869\udfac\udbdf\udfa1\udba0\ude42\ud9d6\udc9f\ud80a\udee3\udaef\udd61\ud8af\udca1\uda17\udc6a\udb34\udc6f\udbb9\udc7b\udbbd\udf97\ud841\udcdf\ud945\udebf\udae1\ude1a\udb4a\udfc0\udba8\udf8c\ud8b5\uddb3", "\u503f\u202e\u1220\u48c3\u1de5\u53d2\u3de1\u4ea2\u760e\u5268\ud28f\u51e9\u5cf9\u58f7\u091f\u325a\uc9f7\ubf69\u65c5\u1ca6\u1cbe\ub0d1\u0b3d\u72a1\u3460\u2028\u2272\u4b17\ua356\u0856\u5b03\ubf8c\u7f7e\u473e\uc9b9\u4cc5\ua15e\u5905\u7b55\ua566\u7ce8\u34ef", "\udbcc\udcb6\udb42\udd8c\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12",
        6, 33233, -1097339987, 123091555976616579L, -87153L, true, true, (char) 41534, (char) 56349,
        Double.longBitsToDouble(0x3fe1382ce30d5da8L), Double.longBitsToDouble(0x3fcfa50724d7dcd4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P24D |this=org.joda.time.Days:P24D\012",
        Z.run(T, 1, 15, 1, 6, "\ud998\udda7\uda43\udc9b\uda85\ude8d\udaa8\ude7f\uda91\udf3e\uda5f\ude21\ud952\udd97\udb5a\ude55\u2070\ud8ce\udd43\uda65\udf91\udbda\udc82\ud869\udfac\udbdf\udfa1\udba0\ude42\ud9d6\udc9f\u84ed\udaef\udd61\ud8af\udca1\uda17\udc6a\udb34\udc6f\udbb9\udc7b\udbbd\udf97\ud841\udcdf\ud819\ude64\ueb7f\ud945\udd16\udba8\udf8c\ud8b5\uddb3", "\u503f\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u18cc~\ucce4\u0cdc\u5db9\u58f7\u08b0\u849f\u7e85\ubf69\u65c5\u1ca6\u1cbe\u83d4\u0b3d\u72c9\u3460\u2028\u1088\u2e0d\ua3c4\ua03f\ud65c\u24fd\u4e03\u46e4\uc9b9\u4ccf\ua15e\u5905\u7b55\ua566\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\udb78\ude42\ud8c8\uddc3\ud86b\udc27\udbbe\udf9e\ud9b4\ude08\ud893\ude6f\udb07\udf37",
        53, 29480, -331337169, -1592166261212331243L, -68729L, true, true, (char) 54581, (char) 8299,
        Double.longBitsToDouble(0x3fefa8bf1398d956L), Double.longBitsToDouble(0x3fe82e2840166becL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.joda.time.DurationFieldType$StandardDurationFieldType:days |this=org.joda.time.Days:P24D\0121=java.lang.Integer:0 |this=org.joda.time.Days:P24D\012",
        Z.run(T, 2, 5, 4, 4, "\udbd2\udfbe\udb97\udcc3\udae6\udcac\udb49\udebb\uda91\udfbf\uda89\uded6\ud85f\udc27\ud9cd\udc6b\uda0c\udd23\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\uda50\uddbe\udbbd\udd6b\ud9d6\udc9f\ud828\udc5c\uda66\udc23\udb6b\udc7f\uda17\udccf\ud821\udf51\ud996\udc13\ud854\ude76\ud83b\udc60\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\ud85e\ude2f\ud9f9\udc35", "\uc004\u202e\u1220\u48c3\ua20b\u89ed\ua19b\u7d0e\ub022\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\u8ced\u7e85\u4c8f\u829e\u2b3b\u1cbe", "\udb86\udff9\uda44\udc3b\uda61\udc82\uda17\udfac\ud874\udd42\udbf2\udc17\ud900\udd8d\uda62\udea3\ud80f\ude9c\udb73\udfcc",
        44, 61779, 93606023, -5115116583322083488L, 87480L, false, false, (char) 30989, (char) 16410,
        Double.longBitsToDouble(0x3fe14d0904da64b6L), Double.longBitsToDouble(0x3fe3a1cf15a3cac8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P24D |this=org.joda.time.Days:P24D\012",
        Z.run(T, 1, 15, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\uda4f\udcb2\udac3\udefd\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udba0\ude42\ud9d6\udc9f\ud80a\udee3\ub202\udb6b\udd0e\uda17\udccf\udb35\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc60\uda9a\udd73\uda6d\udf6a\uda5b\udc76\udb99\ude5c\ud8b5\uddb3", "\u01fb\u202e\u1220\u48c3\ua20b\u2dc8\u3de1\u46d5\u18cc\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\u4a69\u829e\u313b\u2182\u7184\u0c7c\uc002\u21c7\u58db\ua842\u80ef\ua15f\u7f80\u56ec\u958c\u1a1a\u4f71\ua7ad\u0bd4\u8200\u5905\u4db3\u0473\u7ce8\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud8e0\ude99\uda33\ude54\ud9a6\udf5f",
        29, 29345, -331337169, -9141888086685204734L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fa9196eba39b8f0L), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Days:P24D\0121=java.lang.Boolean:false |this=org.joda.time.Days:P24D\012",
        Z.run(T, 2, 4, 11, 16, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\udb47\uded8\ud8a0\udd8b\ud952\uddc0\udb5a\ude55\u6571\udb08\udf09\uda4a\udff2\udac2\udf15\ud95e\udc1b\ud8fa\uded5\uda08\udcaf\ud8ff\ude30\udb9e\udff6\udb48\udd13\udb69\udfdf\ud9e3\udd75\udb34\udc6f\ud9c0\udc41\udbbd\udf97\udaeb\ude48\uda9a\udd71\udbcb\udc99\udb46\udd10\uda25\udc71\ud8a0\uddf2", "\u9561\ud77f\u9f0d\ud65e\u5466\u2dc8\ub564\ud561\u3fd1\u18d9\ub747\u51fc\u611f\u5939\u091f\ucd54\u8a13\u4655\ubc80\u2b3b\u1cbe\u83d4\u0c7c\u1baf\u21c7\u6c31\u0889\u8e13\u71be\u4f58\ud65c\uad31\u4e28\u5357\u7abf\ud0cb\ua15e\u1234\u0313\u4e85\u3212\u34e8", "\ud98c\udd92\udb05\ude09\u7f0a\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\udb72\ude7d\udb0b\udf69\ud8d4\udf8e",
        42, 29480, -331337169, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe206284743f94eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.joda.time.Days:P24D\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 9, 1, "\udbd0\udd98\ud8fb\uddb5\udbbb\udee8\ud88e\uddd8\ud943\udfe0\ud8bd\udd30\ud958\udddc\ud900\udcf8\ud80d\udc45\uda05\udc3e\uda4b\udc18\udb0d\uddda\ud943\ude8f\ud8fa\uded5", "\ud5d9\ubbd4\u330a\ucd91\ubc81\u8b9d\u8ac9\u6ef9\u1857\u23bb\ua8f1\u7342\u961a\u853b", "\udb8d\udf91\udb38\udda5\ud991\udcb1\uda85\udfbe\ud87f\ude05\u1d69\udb33\ude70\ud93a\udc46\ud9b4\udcee\udb9b\uddd8\ud835\udfa3",
        29, 87155, -1398717571, -790067640051140598L, 89277L, false, false, (char) 31664, (char) 30727,
        Double.longBitsToDouble(0x3fda7bcd4a366b56L), Double.longBitsToDouble(0x3fdbfd8d514a26baL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:24 |this=org.joda.time.Days:P24D\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 16, 11, "\u58b8\udb97\udcc3", "\u6916", "\udbf5\uddcc\ud829\ude57",
        5, 95811, 745003424, 8951140045436809111L, -42293L, false, true, (char) 18288, (char) 15003,
        Double.longBitsToDouble(0x3fdd9bee69c0648eL), Double.longBitsToDouble(0x3fd523c70833541eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.Days:P24D\0121=java.lang.Integer:0 |this=org.joda.time.Days:P24D\012",
        Z.run(T, 2, 3, 4, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\ud999\udfa7\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\udabb\udc54\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\uda9a\udc18\u1ed3\ud80a\udee3\ud915\udef5\uda76\udc25\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\udb99\ude8c\ud8b5\uddb3", "\u011c\u202e\u1220\u48c3\u40db\u2d75\u3de1\u46d5\u18cc\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\ucd54\u7e85\ubf69\u6d95\u2b3b\u1cbe\u83d4\u0c7c\uc002\u90cf\uaade\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5d2b\u4dcd\u0473\u9ce5\u34ef", "\ud907\udcda\udb3f\udde7\u7eab\ud92a\ude07\udbb0\udc5d\ud93c\udc3d\ud954\ude12\ud98a\udf44\uda57\udda6\uda33\ude68\ud9a6\udf5f",
        31, 29480, -297782737, -1592165672941469931L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3be77baa3cL), Double.longBitsToDouble(0x3fe54d5a48028a10L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 14, 14, 5, "\udbd2\udfbe\ud8fb\uddb5\udaa2\uddab\udac3\udefd\uda91\udf3e\ud9f4\udec3\ud9f4\udc08\udb47\udd0b\udb92\udd88\uda5c\ude6d\ud934\udc4f\udb25\udff1\ud873\udc91\ud8d4\udc48\ud896\udecc\u20b5\ud826\uddcb\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\u6f53\uda9a\udd73\uda23\udca5\ud8cd\udd31\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u4408\ua20b\u2dc8\u3de1\u46d5\u7017\u980e\ud28f\u03fc\u2329\u0e4b\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u4db3\u7e0b\u7cc3\u34ef", "\ud85b\udfce\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud807\udead\uda33\ude68\ud9a6\udf5f",
        24, 63464, 974062867, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fb5b477f33ffc58L), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P24D |this=org.joda.time.Days:P24D\0121=java.lang.Integer:24 |this=org.joda.time.Days:P24D\012",
        Z.run(T, 2, 15, 8, 7, "\udbd2\udfbe\ud8fb\uddb5\ud9f2\udebb\udac3\udefd\ud95a\udf0a\ud8a6\uddaa", "\u85cc\u2aef\u5d24\u1429\ub01a\u4113\u3104\u3f1d\ud5d9\ubbd4\uabbc", "\ud9c0\udc41\udbbd\udf97\ud83b\udc59\ud973\udc80\uda23\udca5\ud8cd\udd31\ud87a\ude2c\ud8b5\uddb2\ud9be\uddfa",
        -4, 9077, 1819600803, -4289528365653288468L, 4698L, false, false, (char) 17573, (char) 42811,
        Double.longBitsToDouble(0x3fd2e5f936ec2d5aL), Double.longBitsToDouble(0x3fe2bd05f22bd223L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.Days:P24D\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 6, 6, "\ud998\udda7\uda43\udc9b\ud931\udf6b\uda49\udf4f\uda91\udfe4\ud8bd\udd30\ud927\udf97\ud584\udb8f\uded4\udb90\udc32\uda65\udf98\udbda\udc82\ud869\udfac\udbdf\udfa1\udba0\ude42\ud9d6\udc9f\ud80a\udee3\udaef\udd61\ud8af\udca1\uda17\udc6a\udb34\udc6f\udbb9\udc7b\udbbd\udf97\ud841\udd87\ud9de\udddf\udbf8\ude21\ud972\ude41\udba8\udf8c\ud8b5\uddb3", "\u503f\u2f9c\015\u48c3\u1de5\u53d2\u3de1\u4ea2\u760e\u524a\ud28f\u51e9\u5cf9\u58f7\u091f\u325a\uc9f7\ubf69\u65c5\u7424\u8a72\ub0d1\u7c7e\ubf28\u3460\u2028\u2272\u4b17\ua356\u0856\u1010\ubf8c\u7f7e\u473e\uc9b9\u4cc5\ub129\u484a\u7b55\ua566\u7ce8\u34ef", "\udbcc\udcb6\udb42\udd8c\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12",
        6, 33233, 1209265069, 123091555976616579L, -87153L, true, true, (char) 41534, (char) 56349,
        Double.longBitsToDouble(0x3fe1382ce30d5da8L), Double.longBitsToDouble(0x3fcfa50724d7dcd4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.joda.time.DurationFieldType$StandardDurationFieldType:days |this=org.joda.time.Days:P24D\0121=java.lang.Integer:24 |this=org.joda.time.Days:P24D\012",
        Z.run(T, 2, 5, 8, 4, "\udbd2\udfbe\udb97\udcc3\udae6\udcac\udb49\udebb\uda91\udfbf\uda89\uded6\ud85f\udc27\ud9cd\udc6b\uda0c\udd23\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\uda50\uddbe\udbbd\udd6b\ud927\udd47\ud828\udc5c\uda66\udc23\udb6b\udc7f\uda17\udccf\ud821\udf51\ud83c\udc6d\ud854\ude80\ud83b\udc60\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\ud85e\ude2f\ud9f9\udc35", "\uc004\u202e\u1220\u48c3\ua20b\u89ed\ua19b\u7d0e\u8944\u98a2\ud28f\u03fc\u5cf9\u58f7\u091f\u8ced\u7e85\u4c8f\u829e\u2b3b\u1cbe", "\udb86\udff9\uda44\udc3b\uda61\udc82\uda17\udfac\ud874\udd42\udbf2\udc17\ud900\udd8d\uda62\udea3\ud80f\ude9c\udb73\udfcc",
        44, 61779, 93606023, -5115116583322083488L, 87480L, false, false, (char) 30989, (char) 16410,
        Double.longBitsToDouble(0x3fe14d0901da64b6L), Double.longBitsToDouble(0x3fe570f1e5a3cae9L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.joda.time.DurationFieldType$StandardDurationFieldType:days |this=org.joda.time.Days:P24D\0121=org.joda.time.MutablePeriod:P24D |this=org.joda.time.Days:P24D\012",
        Z.run(T, 2, 5, 15, 9, "\udbd2\udfbe\udb97\udcc3\udae6\udcac\udb49\udebb\uda91\udfbf\uda89\uded6\ud85f\udc27\ud9cd\udc6b\uda0c\udd23\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\uda50\uddbe\udbbd\udd6b\ud9d6\udc9f\ud828\udc5c\uda66\udc23\udb6b\udc7f\uda17\udccf\ud821\udf51\ud996\udc13\ud854\ude76\ud83b\udc60\uda9a\udd73\uda6d\udf6a\udb4b\udc2f\ud85e\ude2f\udad1\udc31", "\uc004\u202e\u1220\u48c3\ua20b\u89ed\ua19b\u7d0e\ub022\u9844\ud28f\u03fc\u5cf9\u58f7\u091f\u8ced\u7e85\u4c8f\u829e\u3ac9\ub822", "\udb86\udff9\uda44\udc3b\uda61\udc82\uda17\udfac\ud874\udd42\udbf2\udc17\ud900\udd8d\uda62\udea3\ud80f\ude9c\udb73\udfcc",
        44, 61779, 93606023, -5115116583322083488L, 87480L, false, false, (char) 30989, (char) 16410,
        Double.longBitsToDouble(0x3fe14d0904da64b6L), Double.longBitsToDouble(0x3fe3a1cf14a3cac8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Days:P29D\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 9, 1, "\udbd0\udd98\ud906\uddb5\ud900\ude2a\udbc1\udf84\ub608\udae9\udde0\ud958\udddc\ud900\udcf8\ud920\udc70\udb3b\ude6d\uda70\udce5\udb0d\uddda\udb03\udedc\ud8fa\uded5", "\ud5d9\ubbd4\u330a\ucd91\ubc81\u8b9d\u8ac9\u5e1f\u1857\u23bb\ua8f1\u5a13\u7a62\ubbcf", "\udb7a\udfda\udb38\udda5\ud991\udcb1\uda85\udfbe\udafa\udf03\ud8d7\udd16\ud9b3\udf41\ud93b\udde0\ud924\uddab\udb98\udd1a\udb2e\udd57",
        29, 87155, -1398717571, -1582701174468341578L, 89277L, false, true, (char) 31664, (char) 30727,
        Double.longBitsToDouble(0x3fda7bcd4a9e7f56L), Double.longBitsToDouble(0x3fdbfd8d514a26baL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.Days:P29D\0121=java.lang.Boolean:false |this=org.joda.time.Days:P29D\012",
        Z.run(T, 2, 11, 11, 1, "\u58b8\ud8a0\ude5f\uda24\ude9c\ud80f\ude73\ud872\ude62\udb4e\udcf2\udb77\udc3b\udbf5\uddcc\ud85d\ude57\uda46\udcd7\uda37\udceb\udbb3\udc3d\ud81d\uddc4\uda2e\udcd0\uda9a\udc0d\u1ed3\ud811\udd9c\ud8bb\udfed\ud8e2\udf4a\udafd\udebc\ud96e\udf1f\ud851\udc30\uda36\ude5e", "\u2d2e\u6af9\u563c\u3d0f\u748e\ud3d1\u54e6", "\ud96e\udfbf\udbb5\uddba\ud8a7\udd31\udab6\udd8c\uda73\ude01\ud9a6\udf52\udaef\ude17\ud8f7\udcdf\udbc4\udde1\ud810\uded5",
        26, 13239, -465728137, -7613364352258867752L, -66152L, true, false, (char) 22954, (char) 3458,
        Double.longBitsToDouble(0x3fcfd1c4b88b17a4L), Double.longBitsToDouble(0x3fe5cf4ea67f0cf8L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P29D |this=org.joda.time.Days:P29D\0121=java.lang.Integer:0 |this=org.joda.time.Days:P29D\012",
        Z.run(T, 2, 15, 4, 14, "\u58b8\ud9fe\ude77", "\u6916", "\udbf5\uddcc\ud829\ude57",
        5, 95811, 745003424, -301233809623814249L, -40309L, false, true, (char) 23408, (char) 15003,
        Double.longBitsToDouble(0x3fdd9bee69c0648eL), Double.longBitsToDouble(0x3fd523c7036b541eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Days:P11D\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 9, 1, "\udbd0\udd98\ud906\uddb5\ud900\ude2a\udbc1\udf84\ub608\udae9\udde0\ud958\udddc\ud900\udcf8\ud920\udc70\udb3b\ude6d\udb72\udce6\udb0d\uddda\udb03\udedc\ud8fa\uded5", "\ud5d9\u5462\u3350\ucd91\ubc81\u8b9d\u8ac9\u5e1f\u1857\u23bb\ua8f1\u5a13\u7a62\ubbcf", "\udb7a\udfda\udb38\udda5",
        11, 25582, 580229370, 330782373803102010L, 28036L, true, true, (char) 33926, (char) 1525,
        Double.longBitsToDouble(0x3fe095a2b37c7ceaL), Double.longBitsToDouble(0x3fdabaca116dd412L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P11D |this=org.joda.time.Days:P11D\0121=org.joda.time.MutablePeriod:P11D |this=org.joda.time.Days:P11D\012",
        Z.run(T, 2, 15, 15, 0, "\ud8af\udfab\u6402", "\u6898\ub3e8\ub3cb\u801c\ud0c3\u8ea8", "\udbb5\udd32\ud8fa\uded5\uda9a\udc18\u2693\udb20\udd10",
        49, 14829, 843555289, 4355065363181831506L, -57404L, true, true, (char) 56190, (char) 155,
        Double.longBitsToDouble(0x3faffba446124870L), Double.longBitsToDouble(0x3fbf97829906c360L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P11D |this=org.joda.time.Days:P11D\0121=org.joda.time.MutablePeriod:P11D |this=org.joda.time.Days:P11D\012",
        Z.run(T, 2, 15, 15, 14, "\ud8bd\udc92\ud9fe\ude77", "\u7c52\u3d9c\u6bce\u8090\ud0c3\u4378\u6c84\u0788\u8026\u3ded\u138a\u175b\u228e\u8894\u6843\uc0b2\u5c03", "\ud9bc\udd5e\ud838\ude0e\u13af\udbf3\ude3f\udb36\udd90\ud964\udc7c\uda96\udda4",
        29, 30344, -1062740786, -4617728094068222346L, -30862L, false, false, (char) 351, (char) 10045,
        Double.longBitsToDouble(0x3feb20a4a444d96fL), Double.longBitsToDouble(0x3fe15627b93e6d4bL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.joda.time.DurationFieldType$StandardDurationFieldType:days |this=org.joda.time.Days:P11D\0121=org.joda.time.DurationFieldType$StandardDurationFieldType:days |this=org.joda.time.Days:P11D\012",
        Z.run(T, 2, 5, 5, 16, "\u20b1\ud9fe\ude77\uda7c\udd6f\udac3\udefd\uda43\udc8b", "\u801c\ud0c3\u8ea8", "\uda6a\udfcc\ud9b3\uded1\uda8e\ude3f\uda0c\udd8d\udb20\udd10",
        49, 22973, 1424138713, 6823403541448076738L, -54266L, false, true, (char) 54217, (char) 65354,
        Double.longBitsToDouble(0x3fcafcb356de1128L), Double.longBitsToDouble(0x3feb9ae8c30e214dL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Days:P11D\0121=java.lang.Integer:0 |this=org.joda.time.Days:P11D\012",
        Z.run(T, 2, 4, 4, 14, "\u393a\ud9fe\ude77", "\ub8c6\ub3e8\u7067\uaf33\ud0c3\u8ea8\u29fa\u3641\uad40", "\ud8c5\ude90\udb20\udd10\ud915\udef5\uda15\udd03\uda17\udccf\udb34\udc6f\ud9db\uddce\uda8a\udf14\uda18\udfdc\uda78\ude8f\ud833\udfa7\uda0f\ude39\ud9c3\uddc0\udb62\udcb0",
        20, 62901, 31741280, -8753353993982258825L, 936L, false, true, (char) 26958, (char) 31549,
        Double.longBitsToDouble(0x3fe02cafc223ed39L), Double.longBitsToDouble(0x3fdd93e9b286baf0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 1, 4, "\udbd2\udfbe\ud8fb\uddb5\uda81\udcab\udac3\udefd\uda91\udf3e\uda89\uded6\ud952\uddc0\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8cd\uddd5\udb9b\uddff\ud9d6\udc9f\ud80a\udee3\ud915\udef5\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\ud83b\udc59\ud99a\ude99\udbfa\uded3\uda91\udf6a\ud9c5\ude7b\udaac\ude02", "\u01fb\u202e\u1220\u48c3\ua20b\u59d2\u52d8\u46d5\u18cc\u9844\ud28f\u6f50\u43cc\u2873\u091f\ucd54\u7e85\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\ub938\ud0cb\ua15e\u5905\u4db3\u0473\u7ce8\u34ef", "\ud907\udcda\uda59\udc74\ud89e\ude9e\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud9e1\ude5a\ud830\udc17\ud971\udd12",
        9, 34354, -331337207, -1592166261351989483L, -86571L, true, true, (char) 5321, (char) 43119,
        Double.longBitsToDouble(0x3fcc7a2dee8e6e3cL), Double.longBitsToDouble(0x3fe2062843028a10L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 14, 14, 9, "\udbd2\udfbe\ud8fb\uddb5\udaa2\uddab\udac3\udefd\uda91\udf3e\ud8e8\udf0e\uda1f\udf78\udb5a\ude55\u6571\uda26\udc57\uda4b\udc18\udb0d\uddda\ud95e\udc1b\ud8fa\uded5\udba0\ude42\ud9d6\udc9f\ud9d3\udde7\udb41\ude79\udb6b\udd0e\uda17\udccf\udb34\udc6f\ud9c0\udc41\udbbd\udf97\u6f53\uda9a\udd73\uda23\udca5\ud8cd\udd31\udb99\ude8c\ud8b5\uddb3", "\u01fb\u202e\u1220\u4408\ua20b\u2dc8\u8ccf\u46d5\u7017\u980e\ud28f\u03fc\u5cf9\u58f7\u091f\u4097\u8af1\ubf69\u829e\u2b3b\u1cbe\u83d4\u0c7c\uc002\u21c7\u58db\ua842\u457c\uc785\u4f33\ud65c\u3bf6\u4e28\u46e4\u8ab9\ud0cb\ua15e\u5905\u4db3\u7e0b\u7cc3\u2702", "\ud85b\udfce\udb3f\udde7\u7eab\ud92a\ude07\ud9ec\ude3c\ud93c\udc3d\ud954\ude12\ud98a\udf44\ud807\udead\uda33\ude68\ud9a6\udf5f",
        24, 29480, -333854577, -1592166261351989483L, -86571L, true, true, (char) 10434, (char) 8299,
        Double.longBitsToDouble(0x3fcc7a3bee8e6e3cL), Double.longBitsToDouble(0x3fe2062840028a10L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.joda.time.PeriodType:PeriodType[Days] |this=org.joda.time.Days:P11D\0121=org.joda.time.PeriodType:PeriodType[Days] |this=org.joda.time.Days:P11D\012",
        Z.run(T, 2, 7, 7, 11, "\u58b8\udb97\udcc3", "\u6916", "\udbf5\uddcc\ud829\ude57",
        8, 95811, -450205280, 4967565360229838743L, 31517L, false, true, (char) 46404, (char) 15003,
        Double.longBitsToDouble(0x3fdd9bee69c0648eL), Double.longBitsToDouble(0x3fcf078e167ce994L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Days:P5D\0121=void |this=org.joda.time.Days:P5D\012",
        Z.run(T, 2, 12, 12, 14, "\udbf4\uddae\udb97\udcc3", "\u7163", "\udbf5\uddcc\ud829\ude57",
        5, 95811, -1513473120, 8951140633847328663L, -42293L, true, false, (char) 4100, (char) 15003,
        Double.longBitsToDouble(0x3fdd9bee69c0648eL), Double.longBitsToDouble(0x3fd523c70833541eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.Days:P5D\0121=java.lang.Boolean:false |this=org.joda.time.Days:P5D\012",
        Z.run(T, 2, 3, 3, 12, "\ud93d\udf24\udba5\udc17\udae6\udcac\udb49\udebb\udaef\udc6d\udac6\udfc5\ud85f\udc27\ud9cd\udc6b\uda0c\udd23\udb7c\udc56\uda4a\udff7\udb0d\uddda\ud95e\udc1b\uda50\uddbe\udbbd\udd6b", "\u3dfa\uab2d\u7570\ud117\u0c69\u6053\u1dc2\uc773\u708e", "\ud83d\udeb7",
        31, 58492, -913534834, 7815125939658393774L, 11579L, false, false, (char) 55067, (char) 37191,
        Double.longBitsToDouble(0x3fb5809aeb2379a0L), Double.longBitsToDouble(0x3fe8415d6a57a0beL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:12656 |this=org.joda.time.Days:P5D\0121=java.lang.Integer:12656 |this=org.joda.time.Days:P5D\012",
        Z.run(T, 2, 10, 10, 3, "\udb02\udd27\uda1d\ude6f", "\u6916", "\udbf5\uddcc\udae2\udcf4",
        5, 5835, 745003424, -301233809845194857L, -59487L, false, false, (char) 32647, (char) 47152,
        Double.longBitsToDouble(0x3fd09e7eb36b54faL), Double.longBitsToDouble(0x3fdb59fe1f925d8aL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P5D |this=org.joda.time.Days:P5D\0121=org.joda.time.MutablePeriod:P5D |this=org.joda.time.Days:P5D\012",
        Z.run(T, 2, 15, 15, 16, "\u58b8\ud9fe\ude77", "\u6916\ub3e8\ub3cb\u801c\ud0c3\u8ea8\uae6b\ub6dc\u8055\u8c5e\u3db4\u7206\u0c53", "\ud953\udf30\ud815\udc78\ud8b3\ude0c\ud9cb\uddd0\ud915\uddd4\ud821\udc45",
        35, 97106, 1373361255, 4031932947708694106L, 91159L, true, false, (char) 18079, (char) 6261,
        Double.longBitsToDouble(0x3fe6f6abe80b764cL), Double.longBitsToDouble(0x3f7012bd3055e900L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.joda.time.MutablePeriod:P5D |this=org.joda.time.Days:P5D\0121=org.joda.time.MutablePeriod:P5D |this=org.joda.time.Days:P5D\012",
        Z.run(T, 2, 15, 15, 16, "\u58b8\ud9d8\udc04", "\u6916\ub3e8\u730f\u8bf7\u28ae\u8ea8\u29fa\u3641\u807d\u40d1\u02d0", "\ud915\udef5\udb16\udfa4\ud983\udfd3\udb34\udc02\udb95\ude6c\u50f5\udafa\udf41\ud9a7\udc22\udb42\udd1e\ud8c5\uddc2\u92fe\uec23\udab3\udca0\ud8ce\ude33\udb4e\udc70\uda0d\udf8f\udb7c\uddd3\uda6a\udc31\udba2\udc91\uda92\udd43\uda16\udcfb\udb16\udfd2\ud86e\uddc2\ud9ee\udda2\ud8ac\udfb1\ud9e5\ude8f\udbbe\udcfa\ud86c\udf89\ud8db\ude0a\uda70\udf78\ud82e\udf83\ud9b2\ude06\udba6\uddd5\udbf3\udd2f\udb10\udfd0\ud85b\udced\ud8e7\udfa9\ud941\udc49\ud9d5\udca2\ud8ac\ude5a\udbe5\udd07\udbf6\uddb8\udb2e\udf5e\uda66\udff6\udb7b\udc1a\uda22\ude71\u731f\uda37\udd05\ud837\udd07\ud976\ude2f\udaf4\udfa3\ud955\uddeb\ud9e7\uddef\udb69\ude65\uda84\udc77\ud91b\udec8",
        22, 9824, 227573119, 445376753753581259L, 46985L, false, true, (char) 41226, (char) 31851,
        Double.longBitsToDouble(0x3fe2e3d5128efdf8L), Double.longBitsToDouble(0x3f9467252eea4dc0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.base.BaseSingleFieldPeriod|between|org.joda.time.ReadableInstant,org.joda.time.ReadableInstant,org.joda.time.DurationFieldType|static",
    "M|org.joda.time.base.BaseSingleFieldPeriod|between|org.joda.time.ReadablePartial,org.joda.time.ReadablePartial,org.joda.time.ReadablePeriod|static",
    "M|org.joda.time.base.BaseSingleFieldPeriod|compareTo|org.joda.time.base.BaseSingleFieldPeriod|fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|equals|java.lang.Object|fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|get|org.joda.time.DurationFieldType|fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|getFieldType||fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|getFieldType|int|fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|getPeriodType||fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|getValue||fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|getValue|int|fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|hashCode||fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|isSupported|org.joda.time.DurationFieldType|fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|setValue|int|fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|size||fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|standardPeriodIn|org.joda.time.ReadablePeriod,long|static",
    "M|org.joda.time.base.BaseSingleFieldPeriod|toMutablePeriod||fld:org.joda.time.Days:FIVE",
    "M|org.joda.time.base.BaseSingleFieldPeriod|between|org.joda.time.ReadableInstant,org.joda.time.ReadableInstant,org.joda.time.DurationFieldType|static",
    "M|org.joda.time.base.BaseSingleFieldPeriod|between|org.joda.time.ReadablePartial,org.joda.time.ReadablePartial,org.joda.time.ReadablePeriod|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
