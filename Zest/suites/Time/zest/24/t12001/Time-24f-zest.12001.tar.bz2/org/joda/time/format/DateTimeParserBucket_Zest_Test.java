package org.joda.time.format;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateTimeParserBucket_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Long:-2650485166145977565 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        43, 77628, 1909181739, -2650485166174355565L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Long:-2650485166145977565 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\u9bfc", "\ua75d\u4771\u0415\u5bc1", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\ud894\udffb\udad0\udda9\udb7d\udd22\ud8fe\ude81\ud8e6\ude73\udbbf\ude55\udb2d\udd5f",
        36, 77628, 1909181739, -2650485166174355565L, 26876L, true, false, (char) 7316, (char) 50032,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 7, 0, 15, "\udb0f\udeab", "\uc535\u44f0\ubab9\ub71e\u07c2\ua669\u433f\ub42f\u6f43\u3df8\ua3cb\u6f60", "\udadf\udfc9",
        -3, 21279, -777233140, 8499524722749263020L, -79751L, true, true, (char) 48831, (char) 9570,
        Double.longBitsToDouble(0x3fecf561a72d7082L), Double.longBitsToDouble(0x3fe0f91749f6f4a9L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Long:-2650529387471977949 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\uda38\udcfe\udb34\udfe8\ud9c1\udfd2", "\u9823\ub787\u07c2\ua669", "\ud898\ude80\udaf3\ude1d\ub9e3\udbc1\udcdd\u3b03\udbf4\ude71\ud87b\ude7b\uda38\udc22\udae1\udef1\ud9d8\uddd0\u0c8a\udb03\udd70\ud986\ude57\ud969\udc43",
        43, 87780, -1188939405, -2650529387500355949L, 26974L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fc8ba2d15e6c478L), Double.longBitsToDouble(0x3fe362e70be2e2b4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Long:1052210176 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\u00f0\000", "", "",
        -5, -1000, 0, 1023410176L, 54997L, false, true, (char) 37664, (char) 37320,
        Double.longBitsToDouble(0x3fd8d732f9257abaL), Double.longBitsToDouble(0x3fe53e89e4ac75f4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.joda.time.chrono.ISOChronology:ISOChronology[UTC] |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 4, 16, 1, "\udb1e\uddd1\uda61\udfcb\uda67\udf8b\udb4d\udfeb\udac8\udcea\uda9e\udffd\udb7e\ude4a\ud97b\udd2c\ud8e4\udcbd\uda54\udfde\ud96a\udfaf", "\u58d0\u36d2\u7f87\u4388\ud354", "\ud9d8\uddd0\ud8a9\udd1c\ud8a5\udd61\udb13\udca7\uda86\udfeb\ud853\udd15\uda7a\ude17\ud962\udc37\ud8d8\ude4a\udb35\udc05\uda2c\uddad\udbaa\udf6c\uda4b\udc4d\uda49\udcfb\ud837\udedb\udaba\ude89\ud8f6\udd71\udbda\udf75",
        25, 17175, 1065651895, 4857569779460359674L, 45215L, true, true, (char) 27274, (char) 14446,
        Double.longBitsToDouble(0x3feeee2f42ecd4f6L), Double.longBitsToDouble(0x3fd757cc6d947eccL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeParserBucket$SavedState:@? |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 14, 1, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\uda1e\udd6f\udb75\udc14\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        43, 77628, 1909181739, -2239531699325711300L, 26726L, true, true, (char) 33232, (char) 43028,
        Double.longBitsToDouble(0x3fef94642ab4bc1bL), Double.longBitsToDouble(0x3fde2ebfa678c05aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Long:-928294845760106929 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:-928294845760106929 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 16, 16, 3, "\udad0\ude30\ud92e\udcb8", "\u44f0\ua75d", "\ud8e4\udcbd\ud92a\udf4b\ud8a5\udf92\ud90b\udd26\udbb6\udd2c\ub9dc\udbd0\udddf\ud911\udcf3\udbf4\ude71\udae0\udc0e\udb05\udf62",
        20, 98802, 1978989223, -928294845788484929L, -86987L, true, true, (char) 53706, (char) 65147,
        Double.longBitsToDouble(0x3fcf5dbc1574a638L), Double.longBitsToDouble(0x3feb73a8619ad67aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Long:8300064400536908557 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 10, 16, "\u2748\000\uda12\udf1b", "\000", "\ud8e4\udcbd\uda54\udfde\000\ud898\udda1\000\000\uee00",
        -5, 90880, 0, 8300064400511708557L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fd2b96e0b92e396L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Long:1529468209540937068 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 17, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud906\udd70\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\ud898\ude80", "\u7af8\u7f87", "\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf\ud810\udf9e\udb35\udc05\ud8c0\udd3c\udbad\udcd4\udb71\udc42\uda49\udcfb\ud837\udedb",
        20, 89929, 1613565410, 1529468209512137068L, 45782L, true, true, (char) 29651, (char) 32634,
        Double.longBitsToDouble(0x3fe0d69cb6065b7aL), Double.longBitsToDouble(0x3feffd9c38d8bf1fL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\u8233\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\udad3\udfa9\udbf4\ude71\udae0\udc0e\udb05\udf62\ud95e\udd26\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        43, 77628, 1909181739, -2650485166174355565L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Long:3659804113846202468 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 17, 0, 4, "\udad9\ude63\ud8a7\udc89\ud993\udc6c\udb22\udc97\ud86a\uddef\ud809\udc81\ud8a4\ude7b\uda7d\udcc9\ud8e4\udcbd\uda54\udfde\ud87b\udc37\ud859\ude21\udaaf\udff1", "\ua90c\u5176\uc70d\uc705\u4e93", "\uda8c\udcd5\ud801\udc2f\ud968\udfab\udace\udc1c\ub9ba\udb1e\udfdf\ud82a\udf20\ud84e\udf3c\udb1e\udecf\ud850\udfa3\udb71\udc5c\ud9ef\udff8\ud837\ude6f\udad6\udec4\udae7\udc8b\udad8\udf68\ud838\uddde\udad6\udf5c\udb14\udfd2\udb17\ude5a\ud8c7\udcc0\udb17\udc4a\udb0a\ude5c\ud98d\udd9c\uda40\uddb6\udad9\udd7b\uda12\ude4a\ud877\ude2c\ud863\udde4\ud88d\uddfc\udb43\uddb8\ud82c\udeaf\uda67\udfc4\u4623\udb20\udc66\ud81b\ude85\udbc5\udc26\ud81d\udeae\ud975\udfa9\udb3c\udcaa\udbf0\ude3f\ud829\udc13\ud809\udcda\udb6c\udcd9\udb90\udcac\ud94a\udf3f\ud8d6\udc30",
        36, 60504, -63769895, 3659804113821002468L, 22094L, false, false, (char) 5352, (char) 44498,
        Double.longBitsToDouble(0x3fe4ad1105cbb56aL), Double.longBitsToDouble(0x3fa302045c583f30L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Long:-1061790426404455667 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669", "\ud898\ude3b\udada\udee6\ub9e3\ud9c9\udf84\ud843\udc9d\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\udb12\udca5\udaae\udff2\ud96b\udfa5\ud91e\udd7e\udacd\udcc7\ub9ba\udb1e\udfdf\ud810\udf9e\udb35\udc05\uda2c\uddad\udbaa\udf6c\udb71\udc42\uda49\udcfb\ud837\udedb",
        20, 89929, 1613565410, -1061790426432833667L, 36352L, true, true, (char) 15632, (char) 64002,
        Double.longBitsToDouble(0x3feeb6d55894d2b3L), Double.longBitsToDouble(0x3fdb54498ccf1238L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Long:4110815989786094474 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 12, 1, "\u12ff\ud88e\uddd9\ud90f\udcd0\udaf0\udd76", "\ub787\u07c2\uc06a\u30d8\ub9cd\u6fde\u8d90\u0cd0\u0498", "\udae0\udc0e\udb05\udf62\uda77\udf29\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud93e\udd46\udace\udc1c\ub9ba\udb1e\udfdf\udbea\udf0a",
        41, 37999, 697176314, 4110815989757294474L, -85605L, true, true, (char) 62921, (char) 9104,
        Double.longBitsToDouble(0x3fed8bbe55191ff6L), Double.longBitsToDouble(0x3fd77fe02dcaf702L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Long:4783436837579641489 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9ab\udf87", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\uda1f\udde6\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9c8\udea7\udab3\ude7b\udaae\udfe9\udbcd\uded5\ud969\udc43",
        43, 77628, 1909181739, 4783436837550841489L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fd6dd168b822b74L), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:3619736173173108506 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\u7633", "\ud898\ude80\udada\udee6\ub9e3\uda7d\uddc5\ud921\udc07\udbf4\ude97\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf\ud810\udf9e\udb35\udc05\uda2c\uddad\udbaa\udf6c\udb71\udc42\uda49\udcfb\ud837\udedb\udaf0\udfc4",
        3, 89410, 987743036, 3619736173144308506L, -71836L, false, true, (char) 46190, (char) 33466,
        Double.longBitsToDouble(0x3fe17f535efdc86eL), Double.longBitsToDouble(0x3fdbaefc9f39a55eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Long:2679876997667316235 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669\u30d8\ub9cd\ua1f1\u3d88\u58d0\u7af8\u7f87\u4388\ud354\u111e\u4e93\u44eb\ud7e7", "\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf\ud800\udd9e\udb35\udc05\uda2c\uddad\udbaa\udf6c\udb71\udc42\ud849\udcfb\ud837\udedb\udaf0\udfc4\udae7\udc8b\udbda\udf8c\uda12\ude2b",
        25, 25886, 7963816, 2679876997642116235L, -39457L, false, false, (char) 44415, (char) 45808,
        Double.longBitsToDouble(0x3fe56f07bf113042L), Double.longBitsToDouble(0x3faeef3b660d8610L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 10, 12, 1, "\udb1e\uddd1\ud8c3\ude61\udbaf\udd05", "\u63b1\ub7b7\u2d86\u4ca3", "\uda3c\udf0d\ud887\udc3c\uda23\uddae\udb6a\uddc2",
        53, 45129, -780954927, 8300064400511708557L, 32441L, false, true, (char) 22991, (char) 65489,
        Double.longBitsToDouble(0x3fed298d47ecc40fL), Double.longBitsToDouble(0x3fe2b0bf007fe3b6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:15645813257778067 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 6, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfbf", "7\000\ub554\ua669", "\ud898\ude80\udada\udee6\u00aa\000\ud920\udf7c\udbf4\ude71\udae0\udc0e\udbff\udf5f\udad0\udd9f\uda23\udc95\uda28\udcf3\udaae\udfe9\ud93b\ude6c\000",
        -5, 77628, 1909181696, 15645813228978067L, 35418L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b40c1bc1bL), Double.longBitsToDouble(0x3e39e00000000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 8, 16, 1, "\udb1e\uddd1\ud9a0\udd82\ud93f\uddba", "\ua75d\ub787\u07c2\ua669", "\udb37\uddd4\uda10\ude5d\ud8f8\udc14\ud97f\udfa2\ud921\udc07\ud9e4\udc47\ud930\udd94\uda1d\udf6e\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa9\ud969\udc43",
        13, 77628, 1908975954, -2650485166174355565L, -99226L, true, true, (char) 22456, (char) 42939,
        Double.longBitsToDouble(0x3fe62e8b44d712baL), Double.longBitsToDouble(0x3fde2ebbf678c05aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Long:2318607647283906225 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 6, 1, "\udb1e\uddd1\udb8c\uddd8\u35c3", "\ua747\ub787\u07c2\ua669\u30d8\ub9cd\u2789\u3e4e\u58d0\u7af8\u7f87\u4388\ud354\u111e\u4e93\u2d25\u8e74\u1d68\u0f32\u220e\u7c9a\u1354\u2c0a\u8230\uc825\uc543\u423a\u2817\u1638\u5d10\ucc45\u4d75\u07df\u9ff2\ub7fd\uade7\ud1cf\u815d\u8bf2\uc0ec\u5bf0\u9ad8\ucbc6\u5c96\u564f\u3bd8\u33c9\u2ec5", "\uda27\udd54\ud97a\udde9",
        7, 51381, -1124499209, 2318607647258706225L, 33247L, false, true, (char) 6627, (char) 25255,
        Double.longBitsToDouble(0x3fd18a03103b037eL), Double.longBitsToDouble(0x3fc4ffcdf8c11e18L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 3, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\udab1\udf9f\udb89\udc88",
        -3, 53668, -1772693407, -3120860020102665469L, -64196L, false, false, (char) 54280, (char) 65147,
        Double.longBitsToDouble(0x3fcf5dbc1574a638L), Double.longBitsToDouble(0x3feb73a8619ad67aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.DateTimeParserBucket:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 16, 1, "\udb1e\uddd1\ud978\ude49\udbc7\udfbd", "\ua75d\ub787\u07c2", "\ud96a\udfaf",
        43, 39835, 1771563946, -698086033183104373L, -72049L, true, false, (char) 8380, (char) 10736,
        Double.longBitsToDouble(0x3fe53e89e4ac75f4L), Double.longBitsToDouble(0x3fdc3971e3bc4a28L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Long:6098088558178630710 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 9, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2\uda49\udfce\ud86a\uddef\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\ud898\ude80", "\u7af8\u7f87", "\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf\ud810\udf9e\udb35\udc05\uda2c\uddad\udbaa\udf6c\udb71\udc42\uda49\udcfb\ud837\udedb",
        20, 89929, 1613565410, 6098088558153430710L, 65813L, true, false, (char) 30388, (char) 19977,
        Double.longBitsToDouble(0x3feda1a10748790bL), Double.longBitsToDouble(0x3fe11260ab0520e3L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Long:-4342526040374952369 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 1, 17, 4, "\uda65\udd15\ud85e\ude8c\ud9c1\udfd2\uda49\udfce", "\u096b\u892f\ua640\u30d8\ub9cd\u6fde\u1a40\u58d0\u7af8\u7f87\uaa3f\u8958\u94ba\u67aa", "\uda47\udef8\ud935\udfd3\udb26\udfcc\ud82d\udc47",
        -4, 78739, -617114167, -4342526040403330369L, -50020L, true, false, (char) 40090, (char) 28915,
        Double.longBitsToDouble(0x3faa6fbdd36ea750L), Double.longBitsToDouble(0x3fd0edb2cd505d62L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Long:616416389694941226 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        43, 77628, 77712683, 616416389669741226L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Long:-263577363639619494 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 2, 4, 1, "\ud9d6\udece\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\uaf3d\u67f4", "\ud898\ude80\udada\udee6\uda94\udfee\udbb9\udcd8\udadf\ude2e\udbf4\udedb\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udbe5\ude77\udbc3\udcba\ud969\udc43",
        1, 77141, 1909138249, -263577363667997494L, 26726L, true, false, (char) 17514, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b40c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 16, 13, "\udb1e\uddd1", "\u3357\u455b\ua75d\ub787\u07c2\ua669\u82eb\u4362\u6fde\u3a28\u58d0\u7af8", "\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\udb4c\udc6c",
        13, 19710, 682127838, -4319097570788880404L, -75893L, true, true, (char) 56443, (char) 53714,
        Double.longBitsToDouble(0x3fdacb18e615d76cL), Double.longBitsToDouble(0x3fd9ad6b6f8ba2d0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Long:2662094855277587082 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 12, 6, "\udb1e\uddd1", "\u5e16\u44f0\ua75d\ub787\u07c2\ua669\u6d98\u6170\u4b92\u77d6\u58d0\u7af8", "\udae0\udc0e\udb05\udf62\udad0\udd9f",
        37, 95223, -216085332, 2662094855252387082L, -63811L, false, true, (char) 10890, (char) 8465,
        Double.longBitsToDouble(0x3fee1e1f2de2eb0dL), Double.longBitsToDouble(0x3fe9e3016aee6de3L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Long:1272636437027406987 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\uda62\udc88\ud921\udc07\udbf4\uded0\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        43, 77628, 1930939691, 1272636437002206987L, 26726L, true, true, (char) 17151, (char) 49166,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Long:4011591026479444883 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\udb14\udef1\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        43, 77628, 1909189525, 4011591026450644883L, 26726L, true, true, (char) 11525, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ubd16\u81c6\u07c2\ua669", "\udb45\ude0d\udada\ude38\ub9e3\udb55\udde1\ud921\udc07\u111b\uda08\udf4a\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        43, 77628, 1909181739, -2650485166174355565L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Long:153819089433974341 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 4, 1, "\udb1e\udd9c\ud88e\ude19\ud9c1\udfd2\uda49\udfd8\ud86a\uddef\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\udbcf\udf9c\ud835\udd33\ub951\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\ud9e6\udcb5\udad0\udd9f\udbd2\uddcd\ud9c6\udd04\ud934\udd41\ud96b\udfa5\ud969\udc43\ud801\udfd5\u9ba7\udb1e\udfdf\ud9a0\udfa3\udb35\udc05\udb1f\udfa1\udbaa\udf6c\udb44\udc0d\uda27\udf42", "\u02e9\u9fde\uc68c\u3d30\u5102", "\ud982\udd16\uda61\udc5f\ud94e\udfe7\udaa2\udf0e\udacd\udc2b\udb29\udd07",
        7, 91808, 1747765198, 153819089405174341L, 36887L, true, true, (char) 37062, (char) 43522,
        Double.longBitsToDouble(0x3fe1234fbcaf522eL), Double.longBitsToDouble(0x3fd7b5352b9a7104L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Long:3231149320769159022 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 4, 0, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2\uda49\udfce\ud881\udd5a\uda05\udf46\udb6a\udf5f\udb69\udebf\udb83\udddb\uda54\udfde\ud96a\udfaf\ud8af\ude80\udad5\udd7f\ub9e3\udb55\udde1\ud921\udc07\udbc0\udd6a\udae0\udc0e\udb63\udf71\uda72\udcd5\ud9d8\uddd0\udbdd\udfd5\ud911\udec2\udaa9\udddf\ud969\udc43\uda37\udfc2\ub9ba\udb1e\udfdf\ud810\udf9e\uda1b\udfa8\ud814\udc5e\udbaa\udf6c\udb71\udc42\uda49\udcfb", "\u1020\u5475\u61a3\u32aa\u92a9", "\ud84f\udfcd\udba5\ude43\ud967\udfee\udad7\udc97\uda56\ude11\udb7e\ude0e\ud90d\udf56\ud9b5\udf4e\ud865\udf7d\ud8ca\udc56\uda11\udc79\uda3a\udcf5\ud935\uddbb\uda85\udcaf\ud83f\ude6b\udb53\udc04\ud853\udec6\ud951\udc36\ud95a\udc35\u2fe5\udba8\udde0\ud8d2\udf1c\ud96d\udfb7\udbb5\udf79\udb30\ude1e\uda24\udfcb\ufd53\ud8d4\udc8a\udafc\udc91\udb88\udd78\ud9cd\udf72\ud9ca\uddc7\ud84f\ude59\udbfc\udd21\udbb4\udd72",
        48, 64016, 752037258, 3231149320740359022L, 90878L, false, false, (char) 16823, (char) 32847,
        Double.longBitsToDouble(0x3fd50b0adc043516L), Double.longBitsToDouble(0x3febe639a1add51eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Long:7805557921476115381 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:7805557921476115381 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 16, 16, 11, "\udb1e\uddd1\ud88e\uddf1\udaf9\uddc4\uda49\udfce\ud86a\uddef\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\udbde\udc17\uda91\udc68\u8249\ud949\udd6f", "\u7f87\u4388\u3e6c\u5629\u4e44", "\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c",
        13, 78739, -617114167, 7805557921447315381L, -63811L, false, true, (char) 43028, (char) 39213,
        Double.longBitsToDouble(0x3fdc1bc5fbc5d700L), Double.longBitsToDouble(0x3fe95b016ba0a615L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Long:164690558502163 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\ub595\ua669", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        43, 77628, 1909181739, 164690533302163L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3f4a2d1706f06c00L), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Long:5419965365439430683 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669", "\udb0b\udc76\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\uda2a\udda4\udaec\udeb1\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        34, 28789, 1909181739, 5419965365414230683L, 95905L, false, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Long:3800624443295744170 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\uda55\udfd1\ud88e\ude19", "\u2d7e\u6617", "\ud940\uddc8",
        10, 78368, 1033307853, 3800624443266944170L, 7240L, false, true, (char) 8737, (char) 37320,
        Double.longBitsToDouble(0x3fd8d732f9257abaL), Double.longBitsToDouble(0x3fe53e89e4ac75f4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Long:1809377820527805608 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\uda20\ude33\uda1f\udec1\uda93\udedb", "\ua75d\ub787\u07c2\u4a44", "\ud898\ude80",
        20, 22946, -162535820, 1809377820502605608L, -69183L, true, true, (char) 10736, (char) 52195,
        Double.longBitsToDouble(0x3fc58ea7d97bcc78L), Double.longBitsToDouble(0x3fdde8df374a5150L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Integer:86819 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 15, 6, 9, "\udbf4\udd77\ud88e\udd98\ud9c1\udfd2\ud80f\udef0\ud96b\udd62\ud9a8\udffa\udbaa\uddcb\ud927\udc2d\udba9\ude36\ud977\udda3\ud924\uded4\udaae\udde3\ud8b7\udda9\uba2a\udb6d\udfad\ud923\udc75\udac9\udff6\udb3a\udd8d\ud9e7\udd04\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udad2\udf1c\ub947\udb1e\udfdf\ud810\udf9e", "\u4174", "\uda24\ude91\ud980\ude87\udae7\udc8b\udbda\udf8c",
        2, 86819, 1694035280, 6411457354185034576L, 34616L, false, false, (char) 45912, (char) 22712,
        Double.longBitsToDouble(0x3fe4e2e84fee17d3L), Double.longBitsToDouble(0x3fea85e1b3cd3592L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Long:736221756105219526 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 7, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\u250f", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\uce78\udb2b\udeda\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\uda93\udce9\uda91\udfa7\ud969\udc43",
        43, 77628, 1909181739, 736221756080019526L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b47f3971bL), Double.longBitsToDouble(0x3fde2eb3d678c05aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Long:2994349470164783837 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udbb6\uddbe\ud88e\ude19\ud9c1\udfd2", "\ua75d\u34ad\u07c2\u32d5", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf",
        53, 36867, -304072001, 2994349470139583837L, 15516L, false, false, (char) 37228, (char) 40986,
        Double.longBitsToDouble(0x3fa93560e8d9f940L), Double.longBitsToDouble(0x3fe9e2c42ec16330L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Long:2834042084265265453 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 2, 11, "\udb1e\uddba\ud88e\ude19\ud917\udded\uda49\udf42\ud86a\uddef\ud8c5\udf60\udad1\udfb4", "\u2e65\u5a9c\ubf99\u3dc5\u6b2e\ua73f\u4bc2\u43a6\u5dd1\ubfa6\uac52\u8933\uaaab\u71c6\u7bf6\u2f2f\u894f\uc0a3\u2c0a\u627c", "\udbaa\udf6c\udb71\udc42\uda49\udccc\ud837\udedb\udaf0\udfc4\udae7\udc8b\udbda\udf8c\ud8a5\ude96\uda70\udeef\uda33\udf16\u376d\uda78\udeb0\udba0\udee4\uda84\udf0b\ud84a\udf5e\ud994\udf74\ud8c6\udd55\ud871\uddf2\ud93d\ude49\ud8fa\ude51\udb95\uded3\u924c\uda03\ude8f\udbad\udd29\udb84\udd16\ud957\udd00",
        58, 84505, -1947997767, 2834042084240065453L, -37997L, true, true, (char) 8603, (char) 15647,
        Double.longBitsToDouble(0x3fec40a21a58ba18L), Double.longBitsToDouble(0x3fe671d3d065a011L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:6443689856699465341 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\udbcb\udfd7", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud90d\udf07\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        43, 25292, 170150417, 6443689856670665341L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 9, 11, 1, "\ufc39\ud886\udd1b\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\ud81d\udeff\udadc\ude75\udb09\udfac\ud856\udd4a\ud9d8\uddd3\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        12, 55387, 1909181739, -2650485165838811245L, 62152L, true, true, (char) 49815, (char) 46220,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Long:253385923462528 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\u00f0\u9be9", "\ua75d\000\000\000", "",
        -5, -1000, 0, 253385898262528L, -100000L, true, false, (char) 0, (char) 10736,
        Double.longBitsToDouble(0x3f03340000000000L), Double.longBitsToDouble(0x3fe8980002f6af97L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Long:1830619421280711347 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 7, "\udb45\udde4\udaa0\udc40\u9bfc\ud82a\udf43\udb67\udcaf\udab9\udd6d\u7112\ud91d\udd98\ud9a6\udc90\uda2c\udd53", "\u6475\u58e5\ubf1e\u7f7a\u4388\ud2f5", "\udb7d\udd22\ud8fe\ude81\ud8e6\ude73\udbbf\ude55\udb2d\udd5f\ud927\udd9c\ud895\udc1a",
        -4, 25397, -879848096, 1830619421251911347L, -85601L, true, true, (char) 63842, (char) 9065,
        Double.longBitsToDouble(0x3fd4a5f49b450648L), Double.longBitsToDouble(0x3fd5830333d20c84L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:-7631853177355453043 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 15, 16, 9, "\ud99f\udd11\ud90b\udc51", "\u1834\uc3fe\ud094\u7598", "\ud8e0\udcd1\ud8ab\udec6\udada\udee6\ub9e3\udb2b\udffd\udb9b\udc04\ud827\udc78\ud897\udc6a\ud894\udf89\udad0\udda9\uda56\udfee\ud8fe\udea4\ud8e6\ude73",
        44, 69534, -1946649656, -7631853177355383509L, 13308L, true, false, (char) 18323, (char) 4573,
        Double.longBitsToDouble(0x3fdc5d168e40795eL), Double.longBitsToDouble(0x3fde27190694c05aL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.joda.time.chrono.ISOChronology:ISOChronology[UTC] |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:8499560774729945644 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 4, 0, 15, "\udb0f\udeab", "\uc535\u44f0\ubab9\ub71e\u0777\u0ac1\u1ea2\ub42f\ubcc9\u3df8\ua376\u5c1a", "\ud978\udd89",
        -3, 5103, 531389708, 8499560774704745644L, -68734L, false, true, (char) 62478, (char) 27731,
        Double.longBitsToDouble(0x3fd72294e577f5aeL), Double.longBitsToDouble(0x3fcf95869e0a863cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Long:-705309908601505477 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\u00f0\000", "\ud012\000\000\000\000\000\u284c\u3e4e\u58d0", "\udb08\udd1a\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udbf6\uddec\udaf8\udd95\ud86c\udc1b\ua103\u2df0\udb7e\udf3a\ud993\uddc2\udbd2\udf96\udbcd\uddf5\ud9b7\udeca\ud855\udf7d\udab2\udd0f\ud82f\udcc3\ud9a5\udf92\udb69\udec5\ud9e0\ude9f\ud973\udce6\ud91c\ude2d\ud8fe\udc40\ud9b9\udd31\ud8a4\udf38\ueab3\ud8da\udeef\ud9c3\udc98\uda47\udd19\uda03\udf1d\udadf\udc4f\ud97a\udca2\ud9dc\udcfc\ue86c\uda1a\udd4e\udbf1\uded3\ud95c\udc8d\uda52\udf2e\ud9e4\uddca\ud990\udf9e\ud89a\udd81",
        22, 24816, -772794949, -705309908629883477L, 99779L, false, true, (char) 34689, (char) 22003,
        Double.longBitsToDouble(0x3fe94c73e1d5c0e4L), Double.longBitsToDouble(0x3fe8518ae6782e8aL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Long:-9223372036644188650 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 8, 5, "\udb1e\uddd1\u00f0\000", "\000", "",
        22, -1000, 0, -9223372036672566650L, 98378L, true, false, (char) 37383, (char) 8380,
        Double.longBitsToDouble(0x3fc257abaa9f44f0L), Double.longBitsToDouble(0x3fdac75f4f6b55c8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Long:115843103042078080 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb57\udcfc\udb1a\udf99-", "", "",
        -5, 43864, -130047550, 115843103016878080L, -10539L, true, true, (char) 37537, (char) 28059,
        Double.longBitsToDouble(0x3fd8d732f9257abaL), Double.longBitsToDouble(0x3fe53e89e4ac75f4L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 3, 16, 7, "\udafa\ude80\u00f0\000", "\u0083\000\000\000\000\000\u284c\u3e4e\u58d0\ubcf7\u7f87\ud175\ud354\u111e\u4e93\u5d86\u4577\u6687\u9c02\u92cd\u08d5\ud325\uca81", "\ud8c7\udf43\udb52\udd2b\ud9af\udc35\ud88e\udd02\udba3\udc68\udb24\udd77",
        39, 1302, -528867619, 7970262886978350298L, 87991L, false, true, (char) 35123, (char) 34862,
        Double.longBitsToDouble(0x3fdf8be21e2ca4ecL), Double.longBitsToDouble(0x3febc3fe25ce704fL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Long:981523694027698639 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Boolean:false |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 2, 9, 8, "\udb1e\uddd1\ud9d6\udcfa\0000\000\u4d4a\000\000\000\ue61d", "\u3e4e", "\udbb8\udf9d\ud9ca\udfdc\udadf\udfe4\udb05\udf62\udad0\udd9f\ud960\udff3\uda28\udd9a\uda8d\udd99\udaa9\udcb2\u0fa6\ud999\udd96\ud8ba\udec7\ud8fd\udf87\udb0f\udcf6\ua875\udbdb\udff5\ud951\udd8f\ud8c7\udfba\udb8c\udeb4\ud9d2\udd23\u6ae9\ud8e0\udcc6",
        41, 28577, 2050866182, 981523694002498639L, 51973L, false, false, (char) 62118, (char) 17367,
        Double.longBitsToDouble(0x3fef2886983a44b6L), Double.longBitsToDouble(0x3fe54a8b69fc509aL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.joda.time.chrono.ISOChronology:ISOChronology[UTC] |this=org.joda.time.format.DateTimeParserBucket:@?\0121=org.joda.time.chrono.ISOChronology:ISOChronology[UTC] |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 4, 4, 3, "\udad0\ude30\ud92e\udcb8\udb11\udcb6\ud8a4\udcee\ud86a\uddef\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\ud92a\udf4b\ud8a5\udf92\ud90b\udd26\uda85\ude19\ud9d9\ude74\uda14\udf97\ud911\udcf3\udbf4\ude71\udae0\udc0e", "\u2d25\u8e74\u317d\u2393\u220e\u7c9a\u1354\u65be\u63ab\uc825\uc543\u423a\u2817\u1638\u968f\u6a8e", "\ud9dd\ude60",
        44, 85899, 1113957349, 2804226891020613936L, -1961L, true, true, (char) 16747, (char) 23478,
        Double.longBitsToDouble(0x3fc87be142be8d44L), Double.longBitsToDouble(0x3fd040d298cd3c98L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.util.Locale:en_US |this=org.joda.time.format.DateTimeParserBucket:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 3, "\udad0\ude30", "\uc85b\u44f0\ua75d\ub787\u239c\ua6a5\u0c62", "\udbf0\udd0a\uda31\udcc6",
        56, 93959, -1882036700, -3373316167598882663L, -14466L, true, true, (char) 38511, (char) 61060,
        Double.longBitsToDouble(0x3fef6625752b96e0L), Double.longBitsToDouble(0x3fdc9713bf27246eL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeParserBucket$SavedState:@? |this=org.joda.time.format.DateTimeParserBucket:@?\0121=org.joda.time.format.DateTimeParserBucket$SavedState:@? |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 14, 14, 3, "\ua2b7\udae5\udfff\udb11\udcb6\ud8a4\udcee\ud86a\uddef\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\ud92a\udf4b\ud8a5\udf92\ua4a3\ud855\udea3\udb06\udd1c\udaf2\udf53\udaa2\ude72\udbf4\udf33\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a", "\u95c7\u2050\u39d2\u4490\u63ab\uc825\u00d2\u423a\u2817\u1638\u2dc4\u0b14\u65d8\ubd0f\u7e91", "\ud959\udcb7\uda9d\udfa7\ud8c3\udef1\uda8d\udd40\ud844\udc9d\ud9f4\udf02\ud86a\udef6\ud9b1\udf1e\ud893\udeb1\ud913\ude2c",
        33, 78178, 634651520, -2780752962363249508L, -23110L, false, true, (char) 25871, (char) 8300,
        Double.longBitsToDouble(0x3fb4b8af6258fcb8L), Double.longBitsToDouble(0x3fe7f959cd522114L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Long:1449605757488336959 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:1449605757488336959 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 16, 16, 13, "\udad0\ude30\ud92e\udcb8", "\u44f0\ua75d", "\ud8e4\udcbd\ud92a\udf4b\ud8a5\udf92\ud90b\udd26\udbb6\udd2c\ub9dc\udbd0\udddf\ud911\udcf3\udbf4\ude71\udae0\udc0e\udb05\udf62",
        20, 98802, 1978989223, 1449605757463136959L, -86987L, true, true, (char) 53706, (char) 65147,
        Double.longBitsToDouble(0x3fcf5dbc1574a638L), Double.longBitsToDouble(0x3feb73a8619ad67aL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.DateTimeParserBucket:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 12, 11, "\ud913\udf4d\ud87e\ude25\uda50\udcb8\uda85\udc9a\ud86a\ude68\ud8d4\udea7", "\ua669\u0c62\ub887", "\udbf7\udf59\udbd0\udddf\ud911\udcf3",
        58, 51233, 1940671067, 586976961763241128L, -51502L, true, false, (char) 15134, (char) 42061,
        Double.longBitsToDouble(0x3fef66207d2b96e0L), Double.longBitsToDouble(0x3fdc971cbf27246eL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Long:-7882260558266940637 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:-7882260558266940637 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 2, 1, 9, "\udad0\ude30\ud92e\udcb8\udb11\udcb6", "\u4eb9\ub787\u07c2\ua669\u0c62\ub887\u7607\uc44b\u29c9", "\udbf4\ude71\ud841\udffa\udb1f\udd9e\udad4\udfd7\ud9d8\uddd0\uda28\udd9a\uda7d\udfff\udacc\udc53\uda2a\udf84",
        29, 77411, 1908854571, -7882260558295318637L, 26726L, true, true, (char) 64633, (char) 38942,
        Double.longBitsToDouble(0x3fee5a2ed31cb331L), Double.longBitsToDouble(0x3fd353bad6a1a964L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Long:8306505928062939917 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 10, 16, "\ud8a3\udd2d\ud814\ude13\ud828\udfdf", "\000", "\ud8e4\udcbd\uda54\udfde\000\ud898\udda1\uccf8\udaf3\udc98\udbd4\uddf3",
        -5, 90880, 335544320, 8306505928037739917L, -100000L, false, false, (char) 38133, (char) 4480,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fd2b96e0b92e396L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Long:8300064403311440653 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 10, 16, "\u2748\ud95f\ude66\uda12\udf1b", "\000", "\ud8e4\udcbd\uda54\udfde\000\ud898\udda1\000\000\uee00",
        -5, 90880, 0, 8300064403286240653L, -100000L, false, false, (char) 61, (char) 0,
        Double.longBitsToDouble(0x3e4d900000000000L), Double.longBitsToDouble(0x3fd2b96e0b92e396L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Long:4200615767353923763 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 10, 16, "\u2748\000\uda12\udf1b", "\000\u6a12\u0781\ua669", "\ud898\udda1\000\000\uee00\000\udaca\udc04\000\udb05\udf62\udad0\udd9f\000\000\000\000\000",
        -5, 77392, 1909181739, 4200615767328723763L, -71756L, false, true, (char) 37806, (char) 58723,
        Double.longBitsToDouble(0x3fc55b424cb7a608L), Double.longBitsToDouble(0x3fda6dadf811a220L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=void |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 3, 10, 16, "\udb7f\udc81\ud896\udeaa\uda12\udf1b", "\u28cf", "\ud8e4\udcbd\uda54\udfde\000\ud898\udda1\000\uda6b\udfd5\ud81a\udfa2",
        24, 90880, 0, -470619667211516156L, -35232L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fd2b96e0b92e396L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.DateTimeParserBucket:@?\0121=void |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 10, 10, 0, "\udabf\ude02\ud89a\udd07\uda61\udcda\uda52\ude19\udac5\uddd3\ud8cf\udfb1\udb52\ude88\ud809\udf72\uda93\udce4\ud9bb\udc3d\ud96a\udfaf\ud898\ude80", "\u21e4\u7f87", "\udae5\udef3\udad0\udd9f\ud9d8\uddd0\udaa0\udd96",
        13, 19710, 682127838, -4319097570788880562L, 93345L, false, false, (char) 51448, (char) 18049,
        Double.longBitsToDouble(0x3fe6d007a3c5d168L), Double.longBitsToDouble(0x3feff5e0dde2eb61L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Long:6645557386230220524 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 17, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud906\udd70\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\ud898\ude80", "\u7af8\u7f87\u4388\u3bbd\u111e\ud6ab\u488c\u8461\u1d68\u0f32\u220e\u7c9a\u1354", "\udb35\udc05\ud8c0\udd3c\udbd8\udc2a\ud85c\udc39\uda49\udcfb\uda84\ude41",
        53, 37381, 1613587465, 6645557386205020524L, 45782L, true, true, (char) 29651, (char) 32634,
        Double.longBitsToDouble(0x3fe0d69cb6065b7aL), Double.longBitsToDouble(0x3feffd9c38d8bf1fL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Long:1529468210964772204 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 14, 17, "\ud887\udf82\uda71\udd51\uda22\uddf7\udb6c\ude90\ud906\udd70\ud8ce\udf44\ud989\udc12\ud8ca\udf81\ud8e4\udd21\uda54\udfde\ud96a\udfaf\ud898\ude80", "\u7af8\u7f87", "\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\u8090\ub8f0\udb1e\udfdf\ud810\udf9e\udb35\udc05\ud8c0\udd3c\udb98\udf67\ud992\udf45\ud91b\udc5f\ud9cf\udf1c",
        45, 55150, 1614249130, 1529468210935972204L, 49327L, true, true, (char) 28975, (char) 4264,
        Double.longBitsToDouble(0x3fef187dd6a805e4L), Double.longBitsToDouble(0x3feffd9c38d8bf1fL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Long:3170748798737169887 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 17, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\udbd1\uddb3\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e8\udecb\uda54\udfde\ud926\uddc9\ud89a\udf41", "\u6b3e3", "\udb05\udfc7\udad0\udd9f\ud9d8\uddd0\uda18\udc53\udaa3\udd31\ud96b\udfa5\ud969\udc43\udb41\udd0e\ub92f\udb1e\udfdf\ud810\udf9e\udb35\udc05\ud8c0\udd3c\udbad\udc7f\udaf1\udf9f\uda49\udcfb\ud837\udedb",
        20, 89929, 1613565410, 3170748798711969887L, 45782L, true, true, (char) 29651, (char) 32634,
        Double.longBitsToDouble(0x3fe0d69cb6065b7aL), Double.longBitsToDouble(0x3feffd9c3ddbbf1fL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Long:2922111369570398237 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 4, 2, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud91b\udfb1\ud9ef\udd3f\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\ud898\ude80", "\u7af8\u7f87", "\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf\ud810\udf9e\udb35\udc05\ud8c0\udd3c\udbad\udcd4\udb71\udc42\uda49\udcfb\ud837\udedb",
        20, 11641, -75447838, 2922111369541598237L, -62908L, true, false, (char) 29510, (char) 32634,
        Double.longBitsToDouble(0x3fe0d69cb6065b7aL), Double.longBitsToDouble(0x3feffd9c38d8bf1fL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Long:1528955283071612268 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 17, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud906\udd70\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\ud898\ude80", "\u7af8\u7f87", "\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf\ud810\udf9e\uda72\udf63\ud8c0\udd3c\udbad\udcd4\udb71\udc42\uda49\udcfb\uda3b\uddfc",
        49, 89815, -1490219550, 1528955283042812268L, 45782L, true, true, (char) 29651, (char) 32634,
        Double.longBitsToDouble(0x3fe0d69cb6065b7aL), Double.longBitsToDouble(0x3feffd9c38d8bf1fL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.DateTimeParserBucket:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 6, "\udad9\ude63\ud8a7\udc89\ud993\udc6c\udb22\udc97\ud86a\uddef\ud809\udc81\udb69\udf7b\ud84c\udecd\ud8d5\udef9\uda54\udfde\ub8df\ud853\udc7e\udaaf\udff1\udb29\udea6\udb55\udde1\uda94\udce0\udbd2\udde1\udbc0\udf3d\ud9a6\ude24\udaae\udf4c\ud908\udce0\udbcb\udc9b\uda8c\udcd5\ud801\udc2f\ud968\udfab\udace\udc1c\ub9ba\udb1e\udfdf\ud82a\udf20\ud84e\udf3c\udb1e\udecf\ud9cb\udefe\udb71\udc5c", "\u4e4d\u4c23\u8a9f", "\udb14\udfd2\udb17\ude5a",
        38, 90881, 782641053, -4583202773571348942L, 22334L, false, true, (char) 38290, (char) 21578,
        Double.longBitsToDouble(0x3fed5c13c43466baL), Double.longBitsToDouble(0x3fdd96df8756c8ecL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Long:4110816376329551114 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 12, 1, "\u12ff\ud88e\uddd9\ud90f\udcd0\udaf0\udd76", "\ub787\u07c2\uc06a\u30d8\ub9cd\u6fde\u8d90\u0cd0\u0498", "\udae0\udc0e\udafb\udc06\uda77\udf29\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud93e\udd46\udace\udc1c\ub9ba\udb1e\udfdf\udbea\udf0a",
        41, 37999, 1995182330, 4110816376304351114L, -85605L, true, true, (char) 62921, (char) 9104,
        Double.longBitsToDouble(0x3fed8bbe55191ff6L), Double.longBitsToDouble(0x3fd77fe02dcaf702L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Long:4110815990482677269 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 12, 1, "\u12ff\ud88e\uddd9\ud90f\udcd0\udaf0\udd76", "\ub787\ua4bd\u8b77\u30d8\u429f\u6fde\u5f96\u55d6\u0498", "\ud019\udb05\udf62\ud85c\udf23\ud92a\udcaa\uda28\udd9a\udb8f\udee0\ud96b\udfa5\ud93e\udd46\udace\udc1c\ub9ba\udb1e\udfdf\udbea\udf0a",
        41, 37999, 697176314, 4110815990453877269L, -85622L, true, true, (char) 62921, (char) 9104,
        Double.longBitsToDouble(0x3fed8bbe55191ff6L), Double.longBitsToDouble(0x3fd77feaadcaf702L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Long:4783436840543670752 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9ab\udf87", "\ua75d\ub787\u07c2\ua669", "\ud898\ude80\udada\udee6\ub9e3\uda1f\udde6\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\udb58\udeaf\udab3\ude7b\udaae\udfe9\udbcd\uded5\ud969\udc43",
        43, 77628, 1909181739, 4783436840518470752L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fd6dd168b822b74L), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Long:6862327011129338134 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\u7633", "\ud898\ude80\udada\udee6\ub9e3\uda7d\uddc5\ud921\udc07\udbf4\ude97\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf\ud810\udf9e\udb35\udc05\uda2c\uddad\udbaa\udf6c\udb71\udc42\uda49\udcfb\ud837\udedb\udaf0\udfc4",
        3, 89410, 987743036, 6862327011104138134L, 60012L, false, true, (char) 46190, (char) 33466,
        Double.longBitsToDouble(0x3fe17f535efdc86eL), Double.longBitsToDouble(0x3fdbaefc9f39a55eL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Long:-5716251353818497456 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 0, 9, "\udb1e\uddd1", "\u5b38\ud664\ua75d\ub787\u07c2\u7633\u1ffc\ub9cd\u036c\u3e56\u58d0\u0a17", "\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a",
        13, 19710, 615018974, -5716251353846875456L, -63811L, false, true, (char) 43028, (char) 39213,
        Double.longBitsToDouble(0x3fdc1bc1bbc5d60eL), Double.longBitsToDouble(0x3fe9e30169927cc9L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.DateTimeParserBucket:@?\0121=void |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 11, 11, 3, "\udb1e\uddd1\ud978\ude49\udbc7\udfbd", "\ua75d\ub787\u07c2", "\ud96a\udfaf",
        43, 39835, -241701974, -8736867121562803709L, -72049L, true, false, (char) 8380, (char) 39884,
        Double.longBitsToDouble(0x3fe53e8f74ac75f4L), Double.longBitsToDouble(0x3fdc3e9833bc4a28L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Long:-698330124938664421 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:-698330124938664421 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 17, 17, 16, "\udb1e\uddd1\ud978\ude49\ud9cf\udc86", "\ua775\ub787\u07c2", "\ud96a\udfaf",
        43, 39835, -2070418518, -698330124967042421L, -72049L, true, false, (char) 8358, (char) 10736,
        Double.longBitsToDouble(0x3fdced13c14eebe8L), Double.longBitsToDouble(0x3fc0456dfacdf99cL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Long:595544612953521118 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 9, "\ud9b1\uddff\ud88e\uddad\ud9c1\udfd2", "\ua75d", "\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\ud88e\udfdb\ud930\udffc\udbfa\ude9d\ud99d\udff5\ud8fc\ude44\udbf4\udeba\udae0\udc0e\udb05\udf62",
        20, 98802, 1978989223, 595544612928321118L, -86987L, true, true, (char) 26326, (char) 33680,
        Double.longBitsToDouble(0x3fa23bd9d5d298e0L), Double.longBitsToDouble(0x3fd6e750c700c6b6L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeParserBucket:@?\0121=null |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 7, 7, 4, "\ud978\udd9f\ud85e\ude8c\uda56\udd3c\uda49\udfe5\udab5\udd57", "\u5161\u3d2c\u01b1\u2f48\u6fde\ube66\uc977\u56eb\u88e0\ubf11\u0204\ub762\u67e8\u9e2e\u7030\u86e7\u35cf\u5d16\u70d8\u0377", "\udb35\udc05\uda2c\uddad\uda7a\udc0c\ud82b\ude37",
        -2, 76906, -1019890491, -3728921897735792397L, 29364L, true, true, (char) 3989, (char) 16144,
        Double.longBitsToDouble(0x3fd36ea7521db658L), Double.longBitsToDouble(0x3fd69e5b108f185eL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Long:5749042252331643540 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 2, 4, 1, "\ud9d6\udece\ud88e\ude19\ud9c1\udfd2", "\u1bd0\u3b74\u38ef\u67f4", "\ud898\ude80\udada\udee6\uda94\udfee\ud9d5\udfc7\udb0a\ude47\udbf4\udedb\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9f5\udcd0\uda28\udd9a\udbe5\ude77\udbc3\udcba\ud969\udc43",
        1, 77141, 1909138249, 5749042252306443540L, 26726L, true, true, (char) 311, (char) 57171,
        Double.longBitsToDouble(0x3fee2e8c90c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Long:-3373316167570504663 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:-3373316167570504663 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 2, 2, 1, "\u72d2\ud88e\ude19\ud9c9\udfd2", "\ua75d\ub787\uaf3d\u5faf", "\ud898\ude80\udada\udee6\uda94\udfee",
        7, 11030, -1890518656, -3373316167598882663L, -16017L, true, true, (char) 65464, (char) 42061,
        Double.longBitsToDouble(0x3fb753649a4f1158L), Double.longBitsToDouble(0x3fd8871cb995f8aeL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Long:8736808160045512741 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:8736808160045512741 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 2, 0, 3, "\udb1e\uddd1", "\u5e16\u44f0\ua75d\u0886\u07fe\ua669\u6d98\uc402\u4b92\u06bb\ua4c6\ub8aa", "\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0",
        -2, 53668, 619817259, 8736808160016712741L, -86987L, true, true, (char) 6859, (char) 64977,
        Double.longBitsToDouble(0x3fcf5dbc1574a638L), Double.longBitsToDouble(0x3feb73a8620fd87aL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Long:7608782820907244148 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 11, 1, "\udb1e\uddd1\ud88e\ude19", "\u4c67\ua513", "\ud8e4\udc4b\uda51\uded6",
        0, 30638, -1651341365, 7608782820878444148L, -36132L, true, false, (char) 9812, (char) 26574,
        Double.longBitsToDouble(0x3fc257abab8f44f0L), Double.longBitsToDouble(0x3fed63afa5a66574L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Long:3231149319965842542 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 12, 0, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2\uda9e\udd38\ud918\udec3\ud6e5\udb6a\udf5f\udb69\udebf\udb83\udddb\uda54\udfde\ud96a\udfaf\ud8af\ude80\udad5\udd7f\ub9e3\udb55\udde1\ud921\udc07\udbc0\udd6a\udae0\udc0e\udb63\udf71\uda72\udcd5\ud9d8\uddd0\udbdd\udfd5\ud911\udec2\udaa9\udddf\ud969\udc43\uda37\udfc2\ub9ba\udb1e\udfdf\ud810\udf9e\uda1b\udfa8\ud814\udc5e\udbaa\udf6c\udb71\udc42\uda49\udcfb", "\u1020\u5475\u61a3\u32aa\u92a9", "\ud84f\udfcd\udba5\ude43\ud967\udfee\udad7\udc97\uda56\ude11\udb7e\ude0e\ud90d\udf56\ud9b5\udf4e\ud865\udf7d\ud8ca\udc56\uda11\udc79\uda3a\udcf5\ud845\ude43\ud883\udcfd\ud923\udfc3\ud881\udf45\ud991\udf68\uda22\udec3\ud95a\udc35\u2fe5\udba8\udde0\ud8d2\udf1c\udb77\udd1c\udbb5\udf79\udb30\ude1e\uda24\udfcb\ufd53\ud8d4\udc8a\udafc\udc91\udb88\udd78\ud9cd\udf72\ud9ca\uddc7\ud84f\ude59\udbfc\udd21\udbb4\udd72",
        48, 64016, 752037258, 3231149319937042542L, 90878L, false, false, (char) 16823, (char) 32847,
        Double.longBitsToDouble(0x3fd50b0adc043516L), Double.longBitsToDouble(0x3febe639a1add51eL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Long:1933594640564210001 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 15, "\udb1e\uddd1\ud9df\udfc1\ud9c1\udfd2", "\ua75d\ub787\ub595\ua669", "\uda8e\udecc\udada\uded9\ub9e3\ud879\udd1c\ud950\udca8\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\u9c26\ud96b\udfa5\ud969\udc43",
        43, 25745, -1690120917, 1933594640535410001L, 9159L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fed268b4301a1dfL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Long:632616878503453996 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\uda16\udd3c", "\ua75d\ub787\ub595\ua669\u30d8\ub9cd\u6fde\u3e4e\u57cf", "\udbf4\ude71\udae0\udc0e\udb05\udf62\udbe1\udd73\ud94c\udc9c\udbf8\ude1f\udab4\udc55\ud96b\udfa5\ud969\udc43",
        23, 45132, 879959534, 632616878478253996L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3f4a2d1706f06c00L), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Long:164692280943763 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\ub595\u2401", "\ud898\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udb59\udc63\u85ee\udb05\udee7\udad0\udd9f\ud9d8\uddd0\uda0e\udebb\ud987\udef6\ud84c\udf74\ud969\udc43",
        43, 77628, 1909181739, 164692252143763L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3f4a2d1706f06c00L), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Long:5419965365439430683 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\ua75d\ub787\u07c2\ua655", "\udb0b\udc76\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\uda2a\udda4\udb03\ude1c\udb05\udf62\udad0\udd9f\ud9d8\uddd0\udaf4\udce1\udb4a\udfce\ud96b\udfa5\ud969\udc43",
        34, 28789, 1909181739, 5419965365414230683L, 95905L, false, true, (char) 11386, (char) 22820,
        Double.longBitsToDouble(0x3fee2873d5c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Long:5419965365439430683 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2", "\u8a5c\ub787\u07c2\ua669", "\udb0b\udc76\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\uda2a\udda4\udaec\udeb1\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        34, 28789, 1909181739, 5419965365414230683L, 95905L, false, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x3fe20dfb4569ad2fL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Long:5419965365439430683 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:5419965365439430683 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 16, 16, 1, "\ud95a\udc6d\ud88e\ude22\ud96b\udecf", "\ua75d\ub787\u07c2\ua669", "\udb0c\udd7e\ud0e5\ud80d\uddd2\udb40\udd39\ud921\udc07\udb63\udc36\ud89a\udf7e\uda8f\udf6f\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43",
        34, 28789, 1909181739, 5419965365414230683L, 95905L, true, true, (char) 11449, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fdf1028036226b2L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles |this=org.joda.time.format.DateTimeParserBucket:@?\0121=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 8, 8, 8, "\ud98e\udf9b\uda75\udd54\ud829\udd67", "\u897b\u29aa\u4e40\ua2a5\u7389\u6051\u1694\u4d5d\u6063\u57fa\u5e1e\u1b64\ua73f\u780f\u6843\u0159\u8e6d\u7c75\u0830\u7ea2\u289e\u85f1\ua6f7\ua826\u45d2\ub8bc\u3c4b\u776f\u78a6\u779d\u0df5\u6a35\u5714\u113f\u35aa", "\uda87\ude34\ud8b3\ude77\uda36\udd29\ud8d5\udf26",
        26, 19126, -62114963, -5957587149388042165L, 6413L, false, false, (char) 24201, (char) 44331,
        Double.longBitsToDouble(0x3fedf873c4c9a0bbL), Double.longBitsToDouble(0x3fca0411d2935e84L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.DateTimeParserBucket:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 12, 5, "\ud99f\udd11\ud818\udd38", "\ua7e7\ubc3f\u5267\u7598", "\ud8e0\udcd1\udb28\udd04\udada\udec9\ub9e3\udb2b\udffd\udb9b\udc04\ud827\udc78\ud897\udc6a\ud894\udf89\udad0\udda9\uda56\udfee\ud8fe\udea4\ud8e6\ude73",
        44, 69534, -1946649656, 9195431665890698989L, -50684L, true, false, (char) 58428, (char) 24131,
        Double.longBitsToDouble(0x3fe91ca933ec479bL), Double.longBitsToDouble(0x3fdc5d168e40795eL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 3, 3, 7, "\udb0f\udeab\u2b6c\ud981\udecb\uda64\uddcb\uda29\udf06\udb9f\udd4f\udad1\udf4b\ud89a\udf3d\udb06\udcd6\ud8b6\udd3d\uda83\udd67\udb36\udd92\udaba\ude0c\ud891\udd1e\uda90\udfb7\ud9d7\udca1\ud990\udf90\udb17\ude81\uda49\ude95", "\u14d1\u1d68\u0f32\uae3a\uc889\u4c6a\u4e96\u169f\u1f6a\u390d\u7b8c\u71d8\u38e4\u7dea\u2778\u8857\ubf19\u1d59\ubee3\uca3a\u362a\ua23f\u5b95", "\uda45\udf88\ud8e3\udd27\ud9d3\udc05\ud9ee\udd41",
        39, 66839, -180268105, -9189584437724231197L, 29356L, false, true, (char) 40110, (char) 64150,
        Double.longBitsToDouble(0x3fe00ed088f27dd1L), Double.longBitsToDouble(0x3fe0ab22ca0f55b5L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Long:9223372035837448198 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 8, 5, "\udb1e\uddd1\u00f0\000", "\000", "",
        22, 44648, -1090519040, 9223372035812248198L, 98378L, false, false, (char) 37383, (char) 52924,
        Double.longBitsToDouble(0x3fc257abaa9f44f0L), Double.longBitsToDouble(0x3fdac75f4f6b55c8L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Long:8303363007169503629 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 17, 1, 9, "\u2748\ud95f\ude66\ud8e5\udcde", "\000", "\ud864\udea9\ud817\udc33\uf493\ud898\udda1\000\000\uee00",
        -5, 90880, -156172288, 8303363007140703629L, -80112L, false, true, (char) 45590, (char) 17867,
        Double.longBitsToDouble(0x3fd1da030f9c492eL), Double.longBitsToDouble(0x3fd2b96e0b92e396L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Long:2922481256445297053 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 4, 2, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud91b\udfb1\ud9ef\udd3f\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\ud898\ude80", "\u7af8\u7f87", "\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf\ud810\udf9e\udb35\udc05\ud8c0\udd3c\udbad\udcd4\udb71\udc42\uda49\udcfb\ud837\udedb",
        20, 55759, -1445625556, 2922481256420097053L, -62908L, true, false, (char) 29510, (char) 32634,
        Double.longBitsToDouble(0x3fe0d69cb6065b7aL), Double.longBitsToDouble(0x3feffd9c38d8bf1fL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Long:4110815990482677269 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 12, 1, "\u12ff\ud88e\uddd9\ud90f\udcd0\udaf0\udd76", "\ub787\ua4bd\u8b77\u30d8\u429f\ub3e4\u9435\u1b49\u0498", "\ud019\udb05\udf62\ud85c\udf23\ud92a\udcaa\uda28\udd9a\udb8f\udee0\ud96b\udfa5\ud93e\udd46\udace\udc1c\ud864\udd34\udb1f\udc01\udbea\udf0a",
        41, 37999, 697176314, 4110815990453877269L, -85622L, true, true, (char) 62921, (char) 9104,
        Double.longBitsToDouble(0x3fed8bbe55191ff6L), Double.longBitsToDouble(0x3fd77feaadcaf702L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Long:3322954555559976347 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:3322954555559976347 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 2, 0, 3, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfd2\uda4a\udeac\ud86a\uddef\uda05\udf60\udb5b\uddb8\ud97b\udd31\ud8fd\udcbd\uda6c\udd6d\ud8c9\udc62\udadd\udced\ud8bb\udf98\ud862\udcb1\ud9eb\udd4b\udaa6\udf26\uda88\udcde\ud808\udd86\udb05\udf62\udad0\udd9f\ud9d8\uddd0\udafc\uddca\udb12\udd7a", "\ubf2d\u12c7\u2c0a", "\uda2c\udd03\udbaa\udf6c\udb71\udc42\udb05\udd19\ud9e2\udc55\ud81f\udc7a\ud9ef\udd26\ud840\udd32\ud999\udedc\ud8d7\udcd6\udac0\udc06\udbd8\udeb4\ud833\udc8e\udad7\ude9d\ud9be\udd5e\ud808\udeda",
        3, 11602, -1153018888, 3322954555531176347L, 53179L, true, false, (char) 56173, (char) 23656,
        Double.longBitsToDouble(0x3fd3acebae809558L), Double.longBitsToDouble(0x3fe03268e555c656L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Long:9223372035837448198 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 8, 5, "\udb1e\uddd1\u00f0\udb71\udc6c", "\000", "",
        7, 88928, -1090519040, 9223372035812248198L, 98378L, false, false, (char) 62983, (char) 52924,
        Double.longBitsToDouble(0x3fc257abaa9f44f0L), Double.longBitsToDouble(0x3fdac75f4f6b55c8L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Long:-2650485166145977565 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 12, 14, "\udb14\ude89\ud88e\ude19\ud9c1\udfd2", "\ua726\ub787\u07c2\ua669", "\ud8f3\udc77\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\u00ac\ud94e\udda5\ud969\udc43",
        43, 77628, 1895825408, -2650485166174355565L, 26726L, true, true, (char) 11386, (char) 43028,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e39e30000000000L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Long:7867968459919045523 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 3, "\udbd7\udc77\ud88e\ude19\u9bfc", "\u3faa\u97f3\u3d30\u5bc1", "\udb09\uddc3\ud88f\udd33\ub9e3\udb55\udde1\ud921\udc07\ud809\ude34\udae0\udc0e\udbb5\uddac\udaa8\udd74\ud949\udcc8\ud8fe\udef9\ud8e6\ude73\udbbf\ude55\ud993\udd41",
        28, 77628, 1909160747, 7867968459890245523L, 26876L, true, false, (char) 7316, (char) 50032,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Long:616416391495322282 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c2\udc22", "\ua75d\ub787\u07c2\ua669", "\ud887\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\ud85e\udf41\ud9e6\udd3c\uda28\udd9a\uda0b\ude17\ud96b\udf7b\ud969\udc43",
        43, 77628, 77712683, 616416391466522282L, 26726L, false, true, (char) 11465, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b44024041L), Double.longBitsToDouble(0x3fdd16180678dca6L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Boolean:false |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 9, 9, 17, "\udb0f\udeab\uda5a\udf73\ud981\udecb\uda64\uddcb\udb98\udd68\udb9f\udd93\udad1\udf4b\udb41\ude17\ud876\udc17\udbb0\udc5f\ud80d\udc4d\udae8\udd2c\udad7\udea9", "\u4e69\u3f7a\u154f", "\udb53\udee9\uda0a\udc71\udbbe\udc82\udb29\udcd7\udaf7\udc9e\ud916\udc8c\ud936\udd2a\ud993\udc50\ud9d1\udcf7\ud9f7\udd8a\ud89e\udf6b\u6216\u78ac\udbf4\udff6\ud821\udded\ud92b\udf36\udbfe\udf5b\udb30\udd9e\uda96\udf52\udb19\udf8f\ub6c4\ud876\uddd5\ud9ee\udfde\uda44\udd9e\ud85c\udc9d\udb75\ude8c\ud8aa\udd74\udbc8\udfef\udb73\uddf4\uda8d\udd6b\udadb\udc90\ud982\udc87\udace\udf4a\ud9b5\udd01\udb76\udf54\ud9de\udfa7",
        45, 15503, -1529212431, -106893817966870853L, 7449L, true, true, (char) 19534, (char) 2784,
        Double.longBitsToDouble(0x3fce8636990371a8L), Double.longBitsToDouble(0x3fe670fc56a4e3f0L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Long:5766958467517035487 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 8, 7, "\udb41\uded1\ud968\udd5c\udbcb\udf91", "\000\000\u62f6\u36ef\000\ubc25", "\ud832\uddd6\udb55\udde1\ud921\udc07\udb08\udd1a\udae0\udc0e\udb05\udfa1\udad0\udd9f\ud9d8\uddd0\udab5\uddcc\ud95f\udd83\ud9e4\ude79",
        27, 20808, -95664234, 5766958467488235487L, 77105L, false, false, (char) 30544, (char) 11616,
        Double.longBitsToDouble(0x3feb8921863d53beL), Double.longBitsToDouble(0x3fef7ffe0d1bf5cfL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Long:1576347744624183687 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 10, 4, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud906\udd70\uda05\udf60", "\ua669\u30d8\ub9cd\u9538\u6312\u8cf2\u7af8\u7f87\uc73c\u3b9b\u111e", "\ud9cb\udfc2\udaae\udfe9",
        10, 73838, -1005618267, 1576347744598983687L, -48140L, true, false, (char) 45497, (char) 29005,
        Double.longBitsToDouble(0x3feb758ee19ad67aL), Double.longBitsToDouble(0x3fe5d058e20dbc1bL)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Long:22518582121432448 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 1, 13, 13, "\u2748\ud95f\ude66\ud8e5\udcde\udabd\udfca", "\u8dfd\u0781\u99f1\u82b2", ":",
        -5, 91369, 1843689747, 22518582096232448L, -24645L, true, false, (char) 19888, (char) 36446,
        Double.longBitsToDouble(0x3fddcfea086ee328L), Double.longBitsToDouble(0x3fc4d4061f389278L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Long:7055080145000896511 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 17, 1, 1, "\u2748", "\u8024\u679b\000\u6a12\u0781\u99f1\u82b2\u1494\u4e00\000\000\u0e01\000\ub05e\u8cf7\ud13b\u645b\u00dd\uce80\ub0f6\u845f\u32a9\ub07b\u18d8\000\u9421\ub43f\u2bfd\ub0d6\u800c\u86d0\u9ffe\uad66\u153c", "\ud8b6\udd51\ud877\udd9e\udab5\uddb8\udb8b\udca7\ud991\udc8e\udb09\ude7c\ud8ea\udc1d\ud80b\udcb3",
        53, 60838, -1019959999, 7055080144972096511L, 38044L, true, false, (char) 31615, (char) 16841,
        Double.longBitsToDouble(0x3feddbb999ffc769L), Double.longBitsToDouble(0x3fc933a68cc719c0L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Long:7867967910159631635 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 3, "\udbd7\udc77\ud88e\ude19\u9bfc", "\u3faa\u97f3\u3d30\u5bc1", "\udace\udd2d\ud883\udd33\ub9e3\ud9e4\udfe9\ud8f0\udca3\ud842\ude34\udae0\udc0e\udaf9\udd8e\udaa8\udd74\ud949\udcc8\ud8fe\udef9\ud8e6\ude73\udbbf\ude55\ud993\udd41",
        28, 57196, -1190586327, 7867967910134431635L, 26876L, true, false, (char) 7316, (char) 50032,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb7d678c05aL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Long:616416391495322282 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:616416391495322282 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 16, 16, 1, "\udb1e\uddd1\ud88e\ude19\ud9c2\udc22", "\ua75d\ub787\u07c2\ua669", "\ud887\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\ud85e\udf41\ud9e6\udd3c\uda28\udd9a\uda0b\ude17\ud96b\udf7b\ud969\udc43",
        43, 77628, 77712683, 616416391466522282L, 26726L, false, true, (char) 11465, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b44024041L), Double.longBitsToDouble(0x3fdd16180678dca6L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Long:8286623970402574733 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 10, 16, "\000\000\uda12\udf1b", "\000", "\ud8e4\udcbd\uda54\udfde\000\ud898\udda1\000\000\uee00",
        -5, 90880, 0, 8286623970373774733L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fd2b96e0b92e396L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Long:3786832168766034474 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\uda55\udfd1\udac6\udc94", "\u2ddf\u6617", "\ud940\uddc8",
        10, 11352, 1033307853, 3786832168740834474L, 7240L, false, true, (char) 8737, (char) 37320,
        Double.longBitsToDouble(0x3fd8d732f9257abaL), Double.longBitsToDouble(0x3fe53e89e4ac75f4L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=org.joda.time.chrono.ISOChronology:ISOChronology[UTC] |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:8499561234291446316 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 4, 0, 15, "\udb0f\udeab", "\uc535\u44f0\ubab9\ub71e\u0777\u0ac1\u1ea2\ub42f\ubcc9\u3df8\ua376\u5c1a", "\udbea\udd82",
        -3, 5103, 531389708, 8499561234266246316L, -68734L, false, true, (char) 62478, (char) 27731,
        Double.longBitsToDouble(0x3fd72294e577f5aeL), Double.longBitsToDouble(0x3fcf95869e0a863cL)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Long:800745292937958541 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 17, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud906\udd70\uda27\udef1\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\ud898\ude80", "\u7af8\u7f87\u4388\u3bbd\u111e\u1fe9\ube4d\u8461\u1d68\u0f32\u220e\u7c9a\u82bc", "\udab7\udd5c\udabe\udd39",
        52, 14410, -696600722, 800745292912758541L, 70999L, false, true, (char) 40357, (char) 57723,
        Double.longBitsToDouble(0x3fd763f46e5b72fcL), Double.longBitsToDouble(0x3fe043c5baeea056L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Long:5419965365439430683 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:5419965365439430683 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 16, 16, 1, "\u41e9\ud88e\ude22\ud96b\udecf", "\u8d5d\ub787\u07c2\ua669", "\udb0c\udd7e\ud0e5\ud80d\uddd2\udb40\udd39\ud921\udc07\udb63\udc36\ud89a\udf7e\uda8f\udf6f\udad0\udd9f\ud9d8\uddd0\ud9d6\ude69\udaa3\udf04\ud96b\udfa5\ud969\udc43",
        34, 28789, 1909181739, 5419965365414230683L, 95905L, true, true, (char) 11449, (char) 43028,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fdf1028036226b2L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Long:8698782440520105026 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1", "\u5b38\u44f0\u4337\ub787\u07c2\ua669\u30d8\ub9cd\u2bde\u3e4e\u58d0\u7dee", "\udae0\udc0e\udb05\udf62\ud85e\udf41\ud9e6\udd3c",
        -2, 75444, -504138188, 8698782440491305026L, 87305L, true, true, (char) 7991, (char) 17403,
        Double.longBitsToDouble(0x3fcf5dae6cb035a8L), Double.longBitsToDouble(0x3feb73aad99ad67aL)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 16, 3, "\ud88e\udeef\uda8e\ude03\ud9c1\udfd2\uda49\udfce\ud86a\uddef\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8f1\udf6c\ud939\udff7\u0c6a", "\u58d0\u7af8\u7f87\u4282\u2df8\u111e\u4e93\u2d25\u8e74\u4e89\u8615\u220e\u40a0", "\udb04\ude37\udba1\udcbc\udaa3\udcc7\udad3\udd0a\udb71\udcab\ud881\udd80\udb23\ude71\ub9f1\uda1a\udfae\udbda\udf8c\ud8b8\udd9e\udbd0\udc23\ud867\udfd4",
        55, 6130, 1329650488, 1950862265318767500L, 95035L, true, true, (char) 24447, (char) 41668,
        Double.longBitsToDouble(0x3fee27a2b5a4a230L), Double.longBitsToDouble(0x3fecbd29af8ac5b7L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Long:5736019782644752660 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 2, 4, 9, "\ud9d6\udece\ud88e\ude19\ud9c1\udfd2", "\u1bd0\u52e2\u38ef\u67f4", "\udb6b\ude15\udbaa\uded5\udaa0\udc7d\ud996\udee5\udacc\udf26\ud990\udd2b\udadf\udfd5\udb05\udf62\udad0\udd9f\ud9f5\udcd0\uda28\udd9a\udbe5\ude77\udbc3\udcba\ud969\udc43",
        59, 31997, -875556392, 5736019782615952660L, 26726L, true, true, (char) 311, (char) 57171,
        Double.longBitsToDouble(0x3fee2e8c90c1bc1bL), Double.longBitsToDouble(0x3fde2eb80c89ac5aL)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Long:1678919602045398458 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 17, 1, 9, "\u2748\uda9b\ude33\udbc9\udd1a", "\000\u3418\u0781\u99f1\u82b2\u6fbf\u6eff\000\000\u0e01\000\ub05e\u8cf7\ud13b\u645b\u00dd\u5f18\ub0f6\u845f\u32a9\ub07b\u4b36\u2c22\u7035\u7b62\u65c7\ucf9a\u5254\u2b6b\u1ebe\uafa2\u53c6\ud0cb", "\uda2a\ude92\udbb6\udeb4\ud8c3\udfb4",
        53, 27441, 660176340, 1678919602020198458L, -95449L, true, false, (char) 18764, (char) 19291,
        Double.longBitsToDouble(0x3fdc34b72bf1e5d0L), Double.longBitsToDouble(0x3fb71e5d4fb60ba0L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Long:5418010263629360925 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 3, "\udbd7\udc77\ud88e\ude19\u9bfc", "\u3faa\u97f3\u541a\u5bc1", "\udb09\uddc3\ud88f\udd33\ub9e3\udb55\udde1\ud921\udc07\ud809\ude34\udae0\udc0e\udbb5\uddac\udaa8\udd74\ud949\udcc8\ud8fe\udef9\ud8e6\ude73\udbbf\ude55\ud993\udd41",
        28, 32652, 1909160813, 5418010263604160925L, 35381L, true, true, (char) 43869, (char) 46301,
        Double.longBitsToDouble(0x3fee2e8b45c1bc1bL), Double.longBitsToDouble(0x3fde2eb80678c05aL)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Long:35406743170774451 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\ud954\udfed\udb63\udc0c\ud9c2\udc22", "\ua75d\ub787\u07c2\ua669", "\ud887\ude80\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\ud85e\udf41\udb08\udc9d\ud981\ude8f\uda67\uddc8\ud883\udc22\ud9b9\udc54",
        -4, 77628, 77712683, 35406743141974451L, 26726L, false, true, (char) 28617, (char) 28221,
        Double.longBitsToDouble(0x3fee2e8b44024041L), Double.longBitsToDouble(0x3fdd16180678dca6L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Long:6837919901857876528 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 10, 4, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud906\udd70\uda05\udf60", "\ua669\u30d8\ub9cd\u9538\u6312\u8cf2\u7af8\u7f87\uc73c\u3b9b\u111e", "\ud9cb\udfbe\udaae\udfe9",
        10, 73838, -1005618267, 6837919901832676528L, -48140L, true, false, (char) 45497, (char) 29005,
        Double.longBitsToDouble(0x3feb758ee19ad67aL), Double.longBitsToDouble(0x3fe5d058e20dbc1bL)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 16, 3, "\ud88e\udeef\uda8e\ude03\ud9c1\udfd2\uda49\udfce\ud86a\uddef\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8f1\udf6c\ud939\udff7\u0c6a", "\u58d0\u7af8\u7f87\u4282\u2df8\u111e\u4e93\u2d25\u8e74\u4e89\u8615\u220e\u40a0", "\udb04\ude37\udba1\udcbc\udaa3\udcc7\udad3\udd0a\udb71\udcab\ud881\udd80\udb23\ude71\ub9f1\uda1a\udfae\udbda\udf8c\ud8b8\udd9e\udbd0\udc23\ud867\udfd4",
        55, 6130, 1329650488, 1950862265318767500L, 95035L, true, true, (char) 24447, (char) 41668,
        Double.longBitsToDouble(0x3fee27a2b5a4a230L), Double.longBitsToDouble(0x3fecbd29af8ac5b7L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeParserBucket$SavedState:@? |this=org.joda.time.format.DateTimeParserBucket:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 16, 3, "\ud88e\udeef\uda8e\ude03\ud9c1\udfd2\uda49\udfce\ud9ad\udf34\ud942\uddcc\udad1\udfb4\ud97b\udcf5\ud9c1\udc76\ud939\udff7\u0c6a", "\u58d0\u7af8\u7c91\u298a\u2df8\u111e\u4e93\u2d25\u8e74\u4e89\u8615\ud4b7\u40a0", "\udae7\udf37\udba1\udcbc\udaa3\udcc7\udad3\udd0a\udb71\udcab\ud881\udd80\udb23\ude71\ub9f1\udaa3\udc72\uda65\udc4e\ud86e\udda4\ud8de\udc2a\ud90b\udcba",
        4, 6130, 1329650488, 1950862265318767500L, 95035L, true, true, (char) 24447, (char) 41668,
        Double.longBitsToDouble(0x3fee27a2b417f6eeL), Double.longBitsToDouble(0x3fecbd29af8ac5b7L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeParserBucket$SavedState:@? |this=org.joda.time.format.DateTimeParserBucket:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 17, "\ud88e\udeef\uda8e\ude03\ud9c1\udfd2\uda49\udfce\ud9ad\udf34\ud942\uddcc\udad1\udfb4\ud92d\udfcd\ud8e8\udd8c\ud912\udf9c\u0c6a", "\u58d0\u7af8\u7c91\u298a\u2df8\u111e\u4e93\u2d25\u8e74\u4e89\u8615\ud4b7\u40a0", "\udae7\udf37\uda0c\udeca\uda30\udda5\udad3\udd62\udb71\udcab\udbdc\udecd\udb23\ude71\ub9f1\udaa3\udc72\uda65\udc4e\ud86e\udda4\ud8de\udc2a\ud90b\udcba",
        4, 6130, 1329650488, 1950862265318767500L, 95035L, true, true, (char) 24447, (char) 41668,
        Double.longBitsToDouble(0x3fed0949f417f6eeL), Double.longBitsToDouble(0x3fecbd29af8ac5b7L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Long:5458517906473352119 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 6, 7, "\udb1e\uddd1\ud88e\ude19", "\u44f0\ua75d", "\udae0\udfe3\ud93c\ude48\ud96a\udfaf\ud898\ude80\udada\udee6\ub9e3\uda7d\uddc5\udb28\udd49\udbe0\udc63\udae0\udc0e\udb05\udf62",
        20, 98802, -1557671001, 5458517906448152119L, -86987L, true, true, (char) 6859, (char) 65147,
        Double.longBitsToDouble(0x3fefd76f02a3e640L), Double.longBitsToDouble(0x3f87eef266b59e80L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Long:8856615815870541096 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 10, 4, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud906\udd70\uda05\udf60", "\ua669\u30d8\ub9cd\u9538\u6312\u8cf2\u7af8\u7f87\uc73c\u3b9b\u111e", "\ud9cb\udef5\uda77\ude6e",
        7, 81692, 722274817, 8856615815845341096L, -48140L, false, false, (char) 45497, (char) 29005,
        Double.longBitsToDouble(0x3fc6b05b8b2d8054L), Double.longBitsToDouble(0x3fe5d058e20dbc1bL)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Long:158227647394816 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb1e\uddd1\u00f0\000", "", "",
        -5, 84176, 1266182338, 158227618594816L, -11819L, false, true, (char) 61216, (char) 53013,
        Double.longBitsToDouble(0x3fd8d732f3257abaL), Double.longBitsToDouble(0x3fa24b3acac33eb0L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Long:4110816375262830289 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:4110816375262830289 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 0, 16, 13, "\u12ff\ud88e\uddd9\ud90f\udcd0\udaf0\udd76", "\u630f\u38a1\uc06a\ud2b0\u2e79\u6fde\u8d90\u0cd0\u0498", "\udae0\udc0e\udafb\udc06\uda77\udf29\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\udb7e\ude0e\ud942\udc61\udace\udc1c\ub9ba\udb02\udc4e\udbd4\ude74",
        41, 37999, 1995182330, 4110816375234030289L, -85605L, true, true, (char) 62921, (char) 9104,
        Double.longBitsToDouble(0x3fed8bbe55191ff6L), Double.longBitsToDouble(0x3fd77fe02dcaf702L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Long:5752188547799081876 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 2, 4, 16, "\ud9d6\udece\ud88e\ude19\ud8a3\udd12", "\u9d86\u3b68\u718a\u67f4\u7042\u51c4\ubf3e\u3e4e\ub887\u86a7\u29d3\u148a\u733c\uce3e", "\uda07\uddb4\udb35\udef0\uda88\udc15\udbfd\udd79",
        24, 95316, -410836165, 5752188547773881876L, 26796L, true, true, (char) 16710, (char) 21716,
        Double.longBitsToDouble(0x3fe3178588c1bc19L), Double.longBitsToDouble(0x3fef175c06cc5618L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.Long:1529468211306080917 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:1529468211306080917 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 16, 16, 17, "\udabf\ude02\uda71\udd51\uda22\udfc4\udb6c\ude90\ud906\udd70\uda05\udf60\udad1\udfb4\ud97b\udcf5\ud8e4\udcbd\uda54\udfde\ud96a\udfaf\ud898\ude80", "\u7af8\u7f87", "\udb05\udf62\udb9a\udda4\ud9d8\uddd0\uda28\udd9a\udaae\udfe9\ud96b\udfa5\ud969\udc43\udace\udc1c\ub9ba\udb1e\udfdf\ud810\udf9e\udb35\udc05\ud8c0\udd3c\udbad\udcd4\udb71\udc42\uda49\udcfb\ud837\udedb",
        20, 89929, 1613565410, 1529468211280880917L, -35716L, false, false, (char) 55728, (char) 24960,
        Double.longBitsToDouble(0x3feffd9c38d8bf1fL), Double.longBitsToDouble(0x3fe3c4fe00c8df25L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.Long:9105083547243172523 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 11, 1, "\ud8a4\udd7d\ud804\udf9a\uda29\ude1c", "7\000\ub554\ua625", "\ud8a0\ude38\udbf4\udcb1\uda83\udc67\udaea\udddb\udb39\ude02\ud9bb\udd67\udae0\udc0e\ud84f\udf67\udad0\udd9f\u8c96\uda28\udcf3\udaae\udfe9\ud93b\ude6c\uda37\udc67",
        59, 98218, 1212730767, 9105083547217972523L, -33399L, true, true, (char) 7034, (char) 10517,
        Double.longBitsToDouble(0x3feb904346b2b1ccL), Double.longBitsToDouble(0x3fe21e371b3c233dL)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.Long:4160289615682486165 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 12, 1, "\u12ff\ud88e\uddd9\ud90f\udcd0\udaf0\udd76", "\ub787\ua4bd\u8b77\u30d8\u429f\ub3e4\ub490\u847b\u0498", "\ud019\udb80\udc66\ud85c\udf23\ud92a\udcaa\uda28\udd9a\udb8f\udee0\ud96b\udfa5\ud93e\udd46\udace\udc1c\ud864\udd34\udb1f\udc01\udbea\udf0a",
        41, 77503, 697210023, 4160289615657286165L, -85622L, true, true, (char) 62921, (char) 9104,
        Double.longBitsToDouble(0x3fed8bbe55191ff6L), Double.longBitsToDouble(0x3fd77feaad4ef702L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.Long:4098725167913062279 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:4098725167913062279 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 16, 16, 1, "\udb1e\uddd1\udb1b\udf26\udab7\udd30", "\u391c\u0461\u07c2\ua669\u5bd0", "\udada\udee6\ub9e3\udb55\udde1\ud921\udc07\udbf4\ude71\udae0\udc0e\udb05\udf62\ud9c6\ude9a\udbab\udd52\uda28\udd9a\uda1c\udcf7\ud998\udff2\ud9f3\ude68\uda53\uddca\uf334\ud925\udd3f\ud9e8\udfe0\ud921\ude7c",
        36, 58664, 1896144107, 4098725167884262279L, 31691L, false, true, (char) 16647, (char) 17170,
        Double.longBitsToDouble(0x3fed4f8e51a5c7b6L), Double.longBitsToDouble(0x3fee457a23d45085L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.Long:2266787581514874617 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 16, 16, 1, "\udb17\udd56", "\u5b38\u44f0\ua75d\ub787\u07c2\ua669\u23d0\ub9cd\u6fde\u3e4e\u58d0\uc2f6\u43e2\uc104\u19b1\u10f9\u4e93\u2d25\u8e74\u1d68\u0f32\u220e\u7c9a\u1354\u9593\u96fd\u3158", "\udbf5\udd50\ud927\udcf2\ud837\udedb\udaf0\udfc4\udae7\udc8b\udbda\udf8c\ud9d9\udeef",
        15, 55270, -460420624, 2266787581486074617L, 32739L, true, true, (char) 26132, (char) 1312,
        Double.longBitsToDouble(0x3fb7b45984e1da50L), Double.longBitsToDouble(0x3fe8bbfc998722f4L)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.lang.Long:8182390553268897391 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 0, 6, 1, "\udb1e\uddd1\ud88e\ude19\ud9c1\udfbf", "7\000\ub554\ua669", "\ud898\ude80\udada\udee6\u00aa\000\ud920\udf7c\udbf4\ude71\udae0\udc0e\udbff\udf5f\udad0\udd9f\uda23\udc95\uda28\udcf3\udaae\udfe9\ud93b\ude6c\000\udbaf\udcd7\ub9ba\udb1e\udfb4\udb17\udf81\udb3c\ude22\ud8aa\udecc\udbaa\udf6c\udb71\udc42\uda49\udcfb\ud837\udedb\ud980\udfcc\u00c1\000\ud843\udd64\udb90\ude77\ud9d9\ude46\uf647\udbb5\udea2\udb68\udc57\ud9b8\udcf0\ud81e\udf89\ud931\udf6c\uda15\udd94",
        14, 68545, 1300694946, 8182390553243697391L, -77907L, false, true, (char) 54867, (char) 13752,
        Double.longBitsToDouble(0x3fd35362cd15a05aL), Double.longBitsToDouble(0x3fdf586e62465c3eL)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.Long:6206716426997064118 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 12, 7, "\udb1e\uddd1\u00f0\000", "\u4f3b", "\udb12\udda1\udb25\udc61\ud8b5\ude2b\udb1e\udf3b\ud9dd\udeeb\ub9e3\udb55\udde1\ud921\udc07\udb08\udd1a\udae0\udc0e\udb05\udfa5\udb82\udf18",
        49, 63632, -1427846766, 6206716426968264118L, 49251L, false, false, (char) 49695, (char) 11615,
        Double.longBitsToDouble(0x3fce628eab6d3a64L), Double.longBitsToDouble(0x3fbeda31c6228b38L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=java.lang.Long:3088893774415312138 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 1, 2, 17, 17, "\udabf\ude02\uda71\udd51\uda4e\udcc4\udb6c\uddeb\ud906\udd70\uda05\udf60\udad1\udfb4\ud974\udc97\ud8e4\udcbd\ud81c\udf50\udbbf\uddad\ud9fd\udc2a", "\u153a\u7f87", "\ud991\udc69\udad0\udd9f\ud9d8\uddd0\uda28\udd9a\u0192\uda7a\ude8e\u34cd\uda7d\udcba\ub9ba\udb1e\udfdf\ud814\udd46\ueb67\ud8c0\udd3c\udbad\udcd4\ud8de\udfd9\ud96a\udfe7\udab8\udd00",
        56, 9226, 1288113634, 3088893774386512138L, 45782L, true, true, (char) 61139, (char) 4277,
        Double.longBitsToDouble(0x3fe0d69cb17a767aL), Double.longBitsToDouble(0x3feffd9c38d8bf1fL)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=java.lang.Long:2994525237406405341 |this=org.joda.time.format.DateTimeParserBucket:@?\0121=java.lang.Long:2994525237406405341 |this=org.joda.time.format.DateTimeParserBucket:@?\012",
        Z.run(T, 2, 16, 16, 17, "\udad0\ude30\ud92e\udcb8", "\u0f9c\u148f", "\udb99\udfcb\ud92a\udf4b\ud8a5\udf92\ud90b\udd26\udbb6\udd2c\ub9dc\udbd0\udddf\ud911\udcf3\uda42\ude57\udae0\udc25\udb05\udf62\udad0\udd9f\uda36\udd47\uda28\udd27\uda7d\udfff\ud971\udc06\ud98c\udc35\udaa7\udce9\udaa4\udc23\udb1e\udfdf",
        45, 36867, -1226818881, 2994525237381205341L, -22586L, false, false, (char) 2628, (char) 61393,
        Double.longBitsToDouble(0x3fdca18ef59b1a4eL), Double.longBitsToDouble(0x3feb8be3bd1de378L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.format.DateTimeParserBucket|computeMillis||new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|computeMillis|boolean|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|computeMillis|boolean,java.lang.String|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|compareReverse|org.joda.time.DurationField,org.joda.time.DurationField|static",
    "M|org.joda.time.format.DateTimeParserBucket|getChronology||new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|getLocale||new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|getOffset||new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|getPivotYear||new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|getZone||new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|restoreState|java.lang.Object|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|saveField|org.joda.time.format.DateTimeParserBucket$SavedField|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|saveField|org.joda.time.DateTimeField,int|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|saveField|org.joda.time.DateTimeFieldType,int|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|saveField|org.joda.time.DateTimeFieldType,java.lang.String,java.util.Locale|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|saveState||new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|setOffset|int|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|computeMillis||new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|computeMillis|boolean|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
    "M|org.joda.time.format.DateTimeParserBucket|computeMillis|boolean,java.lang.String|new:org.joda.time.format.DateTimeParserBucket:long,org.joda.time.Chronology,java.util.Locale",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
