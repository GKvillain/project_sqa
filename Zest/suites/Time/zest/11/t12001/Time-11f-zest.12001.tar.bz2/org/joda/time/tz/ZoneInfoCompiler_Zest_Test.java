package org.joda.time.tz;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZoneInfoCompiler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 18797, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d87777e6L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 14, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\uda2f\udf32\ud9a1\udc41\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud9ab\ude6e\udaf6\udf63",
        56, 17635, -2049025729, -2423167328381468459L, -69993L, false, true, (char) 18797, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d87777e6L), Double.longBitsToDouble(0x3fd0753057f6fd30L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.joda.time.tz.ZoneInfoCompiler$DateTimeOfYear:MonthOfYear: 1\012DayOfMonth: 1\012DayOfWeek: 0\012AdvanceDayOfWeek: false\012MillisOfDay: 0\012ZoneChar: w\012\012",
        Z.run(T, 1, 2, 9, 3, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 18797, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d87777e6L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\012",
        Z.run(T, 1, 1, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\u2c9a\u76e7", "\udb1e\udd89\u39a0\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 59649, (char) 31144,
        Double.longBitsToDouble(0x3fe899a2ec3bbbb2L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 11, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud8c1\udc45\ud80b\udf4b\uda66\udf51\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u2bdc\ua581\u9ae1\u233f\u6f41\ua79e\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\ud95f\ude52\ud80c\uddb5\udb43\udd4d",
        8, -994, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 18797, (char) 6423,
        Double.longBitsToDouble(0x3fd34dd2c4d82344L), Double.longBitsToDouble(0x3fdd4304d7211330L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 9, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\ud8af\udcc5\ud8a2\ude13\ud953\udc03\ud9eb\udc7d", "\u7769\u2a3a\ub224\u0bbc\u286b\ua77f\uaa3d\u6f85\u77e9\ud79a\ub276", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 18797, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d87777e6L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\012",
        Z.run(T, 1, 1, 7, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167327857185804L, 98579L, true, false, (char) 44170, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345dce1c7e6L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.TreeMap:{} |a1=[Ljava.io.File;:[[]] |this=org.joda.time.tz.ZoneInfoCompiler:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda1d\ude52S\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\000\000", "\000\u1f96\ub224\ubcf5\uabf1\ua77f\u8657\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 18797, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d87777e6L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 8, 6, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud952\udffb\uda5c\uddd6", "\u7769\uc8cd", "\uda8e\udc1c\ud804\udc8b\ud8f5\udfb5\udb53\udf5a\u057b\udb37\ude52\udbb6\ude7a\udabe\uddea\u2498\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d\ud82f\ude71\udac0\udd75\ud9b0\ude0c\uda95\udc2b",
        5, 64330, 1067386803, -5289927425927114025L, 85655L, true, true, (char) 26105, (char) 39013,
        Double.longBitsToDouble(0x3f9dc1be8420e1e0L), Double.longBitsToDouble(0x3fb3f6c76c53a028L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 13, "\uda4a\uddd7\uda9e\udefb\uda1b\uddb7\ud80f\udf59\uda6c\uded8\uda48\ude70\uda8e\udd5f\udb15\udc87\ud8c2\udd4c", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uc61d\u5baf\u77e9\ud79a\ubb0d", "\udb9c\udc9d\udb0e\udc90\uec42\udb8e\udc12",
        10, 39638, -223716465, 7327081278103679870L, 98579L, false, true, (char) 50462, (char) 44930,
        Double.longBitsToDouble(0x3fdd8345df4777e6L), Double.longBitsToDouble(0x3f446000553ea000L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 14, "\uda1d\ude46\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42", "\u4198", "\udb3c\udf7c\udbce\udc67\ud814\udc70\ud939\udcad\ud95e\udcfc\uda8e\udc1c\ud954\udffe\ud902\udce0",
        14, 96501, 495734827, -667616825513284375L, 43505L, false, true, (char) 28081, (char) 42958,
        Double.longBitsToDouble(0x3fd3fac32c4f0bbcL), Double.longBitsToDouble(0x3fcabbcbe82901f4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\012",
        Z.run(T, 1, 1, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\uda39\udcd6\ud9f8\uddb8", "\u7408\u1f96\ub224\ubcf5\ub377\u6bff\u913d\u6f85\u77e9\u7363\ub2f6", "\udb9c\udcb4\u398c\ud80c\uddbb\udb43\udd4d\ud82f\ude71\udac0\udd75\ud9b0\ude0c\uda95\udc2b",
        5, 64330, 1067386803, -5289927424937258281L, 9805L, false, false, (char) 48140, (char) 48424,
        Double.longBitsToDouble(0x3fec8c5d6e7e619cL), Double.longBitsToDouble(0x3fece5419d5d7b21L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.joda.time.tz.ZoneInfoCompiler$DateTimeOfYear:MonthOfYear: 1\012DayOfMonth: 1\012DayOfWeek: 0\012AdvanceDayOfWeek: false\012MillisOfDay: 0\012ZoneChar: w\012\012",
        Z.run(T, 1, 2, 4, 11, "\uda1d\ude52\uda9e\udefb", "\u381c\u2e90\uca38\ud145\u72e6\uc4bc\ua83e\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa7b\u6f85\u34f3\ud727\ubb0d\u90b5\u826c\u0918\u1467\u8cbd\u93eb\u2c13\u8a73\u420e\ua64b\u2544\uc713\u6b1a\u9806\u0cef\u4e22\u7931\u5ea0\u6cb1", "\ud88c\udc48\udb3d\udc93\udb12\udeda\udb11\udfe5\uda33\ude35\udb90\ude39\udbf0\udd9e\ud838\ude77\ud81d\udca2\udaad\udd5e\ud8b1\udd5f\uda9e\ude90\ud8dd\udf9b\uda35\udf8c\u101e\ud8bc\ude0c\udbd6\uddc3\udb37\udeb8\uda2b\uddcd\ud8ff\udcd1\uda38\uddf5\udad7\ude26",
        51, 94186, 391109396, -6011174446072410444L, -26763L, false, false, (char) 41114, (char) 49087,
        Double.longBitsToDouble(0x3fe3ca1706aa232bL), Double.longBitsToDouble(0x3fc13a89c07bdf78L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Character:w\012",
        Z.run(T, 1, 10, 4, 11, "\uda1d\ude52\u3853\000\ud855\udeef\ud89b\udd26\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u8c84\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d",
        8, 45062, 14571839, -2423167328381468459L, 98579L, true, true, (char) 18647, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d00177e6L), Double.longBitsToDouble(0x3e3c844800000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud99a\uddad\ud953\udc03\ud9eb\udc7d\012",
        Z.run(T, 1, 7, 6, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud99a\uddad\ud953\udc03\ud9eb\udc7d", "\u7769\ud13a\u3923\ubcf5\u4198\u7ac6\uaa3d\u6f85\u8e61\u5ad1\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d",
        8, 55662, -2049025729, -2423167330898050859L, -98029L, true, true, (char) 18797, (char) 45334,
        Double.longBitsToDouble(0x3fece877581fc054L), Double.longBitsToDouble(0x3f7d4c16dcd31000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 6, 11, "\uda1d\ude52\uda9e\udefb\ud82f\uddb7\ud857\udc79\ud89b\udd42\uda66\udc20\ud994\udcad\ud979\ude9a\ud9eb\udc7d", "\u7769\u1f96\uc624\ubcf5\uabf1\ua77f\uaa3d\u5539\u77e9\ud79a\ubb0d", "\udbaa\udd5c\udbf7\udc8b\ud80c\uddbb\udb43\udd4d\ud82f\ude71\udac0\udd75\ud9b0\ude0c\uda95\udc2b\udbbb\udca1\ud991\uded8\udb42\udf72\ud9b2\udeb5\ud871\udf5d\u4328",
        10, 58979, -1986500345, -2413028283638290127L, -51904L, true, false, (char) 19867, (char) 7762,
        Double.longBitsToDouble(0x3fe48ec4fd769cb6L), Double.longBitsToDouble(0x3fc9a7736a2bc928L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 1, 6, 4, 11, "\uda1d\ude52\uda9e\udefb\ud8ba\udce6\ud9b3\udd5a\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9d5\udeb0", "\u545c\u1f96\u064b\u21fc\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d\u90b5\u826c\u4247\u1441\u8cbd\u93eb\u2c13\u3fd1\u2b5e\u49f5\u2544", "\ud9b2\udeb5\ud871\udf5d\u4328\ud973\uddd5\ud9d8\udd1f",
        10, 55096, -1835350257, 7281513352234750781L, 63347L, false, false, (char) 52078, (char) 59436,
        Double.longBitsToDouble(0x3fe6535f34bfa12dL), Double.longBitsToDouble(0x3fe2e0094ff2cc83L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 1, 5, 4, 11, "\ud89c\udfd2\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\u900f\udb25\udde7\udbe8\ude5f\ud9d7\udce3", "\u3d78\u1f96", "\uda8e\udc1c\ud9cc\udddb\ud933\udd39\ud880\udf3e",
        56, 98688, 949087196, 7363783367464003144L, 31201L, true, true, (char) 156, (char) 54781,
        Double.longBitsToDouble(0x3fac43d683fac320L), Double.longBitsToDouble(0x3fe6491ba0d5ee7aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 11, "\uda1d\ude52\uda9e\udf26\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u842c\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\ub381\ubb52", "\ud981\uddea\udb32\udd9a\ud9d9\udd75\udb43\udd54\ud82f\ude71\ud8e0\udc06\ud9b0\ude0c\uda95\udc2b\udbbb\udca1\ud991\uded8\udb42\udf72\ud928\udeb0\ud871\udf5d\u4328\ud973\uddd5\ud9d8\udd1f\udaa4\ude0c\udb7a\udefb\ud8e7\udc07\ud8f8\udd7b\udb31\udeb5\udb13\udca1\udb61\udd65\u3365\ud904\udceb\ud8c3\udca8\uda10\uddf4\udbff\uddc0\udab8\udc5b\ud94c\udf4a\ud8e1\udc2b\ud830\udc12\uda97\udf05\uda20\udf3e\uda4d\udefa\ud855\ude5e\ud898\udfa6\ud856\ude42\ud813\udd84\ud9da\uded4\ud913\ude84\ud985\uddf2\ud81d\udd58\ud8a6\uddf0\uda61\udcc3\ud885\udf4b\ub8c4\ud979\udc89\udb2d\udf4a\ud887\udcb2\udb5a\uddd6\ud929\udfe1\uda58\uddc5\udb98\udf40\uda25\udef2\uda79\ude0d",
        -3, 80481, 2136762320, 492949045799736390L, -63040L, false, false, (char) 43226, (char) 43276,
        Double.longBitsToDouble(0x3fd955c3bbf670caL), Double.longBitsToDouble(0x3fe0dcfa986940bbL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.io.FileNotFoundException\012",
        Z.run(T, 1, 3, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc22\ud994\udcad\ud953\udc03\ud9eb\udc7d\ud9f2\udeb4\udb3c\udf7c\udbce\udc67\uda9f\ude0b\ud90d\udc4e\ud95e\udcf8\uda8e\udc1c\ud9cc\udddb\ud8f6\udc69\udb53\udf5a\u057b\udb37\ude52\ud8b3\udd7d\udabe\uddea\u2498\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d", "\ua07e\ua64b\u2544\u92b3\u6b1a", "\u461a\ud974\ude96\ud9d8\udd1f\udaa4\ude0c\ud851\udeb1\ud8e2\udf8a\ud9f0\udd06\ud9d8\udd77\ud9b2\udeab\ud9fd\udef5",
        58, 49403, -365526268, 3070718360845130316L, 23510L, true, true, (char) 4222, (char) 40135,
        Double.longBitsToDouble(0x3feff014aa088b32L), Double.longBitsToDouble(0x3fc7953a58c9cbf0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 3, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\uda1e\udfd4\udb9e\udf9c\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud848\udfbe\udb43\udd4d",
        25, 82078, -2049025729, -2423167328381468459L, -58986L, true, true, (char) 18797, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d87777e6L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.joda.time.tz.ZoneInfoCompiler$DateTimeOfYear:MonthOfYear: 1\012DayOfMonth: 1\012DayOfWeek: 0\012AdvanceDayOfWeek: false\012MillisOfDay: 0\012ZoneChar: w\012\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 2, 9, 3, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\udbf1\ude01", "\u7769\u1f96\ub224\ua44e\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\uda42\udc9a\u398c\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, -95303L, false, false, (char) 5685, (char) 61486,
        Double.longBitsToDouble(0x3fd0753057211330L), Double.longBitsToDouble(0x3fdd54cdadca1f98L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 2, 10, "\ud858\ude76\udac5\udf43\ud882\udf6b\ud855\udeca", "\u820a\ud145\u72e6\ua601\ucfc3\u790a\u0550\u0c7f\ubc82\ua2fe", "\udb53\udf5a\ud831\uded8\ud842\udfe6\ud8dc\uddb1\ud8c0\udc1a\ud8d5\udd9c\udb1e\udd89\u39a0",
        9, 75053, -449812205, 1512513176944400703L, -1483L, false, false, (char) 22849, (char) 42664,
        Double.longBitsToDouble(0x3fbae8258b194228L), Double.longBitsToDouble(0x3fe899a2ef3bbbb2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\udb81\udf15\udaa5\udfac\ud994\udcad\u9806\ud957\udf3b", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\u2c9a\u76e7", "\udb1e\udd89\u39a0\ud80c\uddbb\ud8d5\udd15",
        -1, 45062, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 59649, (char) 31144,
        Double.longBitsToDouble(0x3fe899a2ec3bbbb2L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 11, "\ud851\udf1a\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud8e4\udd25\uda50\udcf2\uda69\udcf8\ud9f2\udeb4\udb3c\udf7c\udbce\udc67", "\u1f6d\uaa12\u3e9d\u55f7\u6c84\u77e9\u2c9a\u76e7\u90b5\ua7c2\u1417\u9e5d", "\ud82f\ude71\udac0\udd75",
        11, 15451, 1081966805, 5876856709130946483L, 78069L, true, true, (char) 880, (char) 61421,
        Double.longBitsToDouble(0x3fd0753057211330L), Double.longBitsToDouble(0x3fe8f4874c4a622dL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\uda1d\ude52\udb59\udc77\uda59\udc73\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d\0121=java.lang.String:\uda1d\ude52\udb59\udc77\uda59\udc73\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d\012",
        Z.run(T, 2, 7, 7, 11, "\uda1d\ude52\udb59\udc77\uda59\udc73\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\u2c9a\u76e7", "\udb1e\udd89\u39a0\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 59649, (char) 31144,
        Double.longBitsToDouble(0x3fe899a2ec3bbbb2L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\ud90e\udf35\udbae\uddb0\udb18\ude33\ud9eb\udc7d\ud9f2\udeb4\ud886\udf81\udbce\udc67", "\u045a\u2eb8\u7eca\uaa3d\u6758\u1428\u9ac1\u2b18\u4bcd\ua7d8\u1417\u4a99", "\udb3c\udc74\ud90a\udf21\ud9b0\ude0c\uda63\udfb3\uda17\udf2a\ud991\uded8\udb42\udf72\uda1a\udd69\udbe4\ude5a\u0479\ud951\udd20\ud96f\udd00\udaa4\ude0c\udbe3\uddba\udb6e\udfcb\ud988\udfd4",
        34, 8357, -2018939849, -7589602061170478822L, 98626L, true, true, (char) 9136, (char) 6706,
        Double.longBitsToDouble(0x3fd72fb1d76b00f0L), Double.longBitsToDouble(0x3fcb40928acb4a98L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.TreeMap:{} |this=org.joda.time.tz.ZoneInfoCompiler:@?\012",
        Z.run(T, 1, 0, 5, 3, "\udbb7\udc59\uda3a\udee5\uda1b\udd17\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03", "\ua83e\u7769\ubbdf\uaf03\ubcbf\uabf1\uadcd\ua397\u151e\u6b1e\u7447\u8254\u90b5\ua7c2\u1417", "\udb43\udd4d\ud82f\ude71\udac0\udd75\ud9b0\ude0c\uda95\udc2b\udbbb\udca1\ud991\uded8\uda95\ude10\ud8e7\udfeb",
        16, 31915, -1145909485, 5982245106052786439L, -25995L, false, false, (char) 55921, (char) 41500,
        Double.longBitsToDouble(0x3fef3bd139d017b8L), Double.longBitsToDouble(0x3fa50c6d18eb3960L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 12, "\uda1d\ude52\udba8\udcc5\uda1b\uddb7\ud855\udeef\ud8ec\udc8b\ud9e0\ude54\udb1e\udf6f\udbc9\ude10\ud92e\udff8", "\u7769\u1f96\u898d\u2aec\uabf1\u9c3d\u3dfd\ub4d3\u2a79\ua587\u4bea", "\u4e54",
        5, 10663, 1163659021, 2413687463360007957L, -46279L, false, true, (char) 24642, (char) 2028,
        Double.longBitsToDouble(0x3fedeed9d93c1578L), Double.longBitsToDouble(0x3fd424f5b2ba77aaL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Character:w\012",
        Z.run(T, 1, 10, 10, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\udb1b\udeb2\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d\ud82f\ude71\udac0\udd75\ud9b0\ude0c",
        36, 45460, 1369951877, 4584391411498232961L, 59726L, false, true, (char) 19044, (char) 48140,
        Double.longBitsToDouble(0x3fec844cc2435ed0L), Double.longBitsToDouble(0x3fe31c651079afa0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.util.TreeMap:{} |this=org.joda.time.tz.ZoneInfoCompiler:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda1d\ude52S\udbda\ude97\ud88e\udd4d\ud89b\udd42\uda66\udc20\ud994\udcad\udb5a\udf4c\udaf8\udf0b", "\000\u1f96\ub224\ubcf5\uabf1\ua77f\u8657\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\ud8e5\udc3e",
        -1, 39178, -2048988907, -2423167328381468459L, 98579L, true, true, (char) 878, (char) 22022,
        Double.longBitsToDouble(0x3fe9b1a2e9e0a846L), Double.longBitsToDouble(0x3fd0753d8f211330L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 13, "\uda4a\uddd7\uda9e\udefb\uda1b\uddb7\ud80f\udf59\ud88a\udc20\uda0a\udf00\uda8e\udd5f\udb15\udc87\ud8c2\udd4c", "\u7769\u1f96\ub224\ubae3\ua9f1\ua77f\u30d0\ua4c4\u29c1\ud79a\ubb0d", "\udb9c\udc9d\udb0e\udc90\uec42\ud846\udd04",
        36, 39551, -223705133, -2616866699130414540L, 43245L, false, false, (char) 44832, (char) 44930,
        Double.longBitsToDouble(0x3fc46f6ca705f9f0L), Double.longBitsToDouble(0x3f446740553ea000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 9, 12, "", "\u5512\u71b6\u3724\u0c0f", "\ud8c2\udd4c\uda06\uddb7\udb3c\udf7c",
        59, 87866, -2058089591, 6397244235956610835L, -47702L, true, false, (char) 58248, (char) 32023,
        Double.longBitsToDouble(0x3fe048ec64e9f6bcL), Double.longBitsToDouble(0x3fdbbcd348ad91acL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 11, "\uda1d\ude52\uda16\ude37\uda1b\udd8d\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\uda39\udcd6\ud9f8\uddb8", "\u7408\u1f96\ub224\ubcf5\ub377\u6bff\u913d\u0e11\ua791\u7363\ub2f6", "\udb9c\udcb4\u398c\ud80c\uddbb\uda81\ude80\ud82f\ude71\uda2c\udcaa\udad8\udd34\udba7\udc42",
        5, 64330, 1067386803, -5289927424937258281L, 9805L, false, false, (char) 48140, (char) 48424,
        Double.longBitsToDouble(0x3fec8c5d6e7e619cL), Double.longBitsToDouble(0x3fddea833cbaf642L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.TreeMap:{} |this=org.joda.time.tz.ZoneInfoCompiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\uda39\udcd6\ud9f8\uddb8", "\u7408\u1f96\ub224\ubcf5\ub377\u6bff\u913d\u6f85\u77e9\u7363\ub2f6", "\udb9c\udcb4\u398c\ud80c\uddbb\udb43\udd4d\ud82f\ude71\udac0\udd75\ud9b0\ude0c\uda95\udc2b",
        5, 64330, 1067386803, -5289927424937258281L, 9805L, false, false, (char) 48140, (char) 48424,
        Double.longBitsToDouble(0x3fec8c5d6e7e619cL), Double.longBitsToDouble(0x3fece5419d5d7b21L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.joda.time.tz.ZoneInfoCompiler$DateTimeOfYear:MonthOfYear: 1\012DayOfMonth: 1\012DayOfWeek: 0\012AdvanceDayOfWeek: false\012MillisOfDay: 0\012ZoneChar: w\012\0121=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\012",
        Z.run(T, 2, 2, 1, 11, "\uda1d\ude52\uda9e\udf26\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u842c\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\uc6a5\u3657\ubb52", "\ud981\uddea\udb32\udd9a\ud9d9\udd75\udb43\udd54\ud82f\ude71\ud8e0\udc06\ud9b0\ude0c\uda95\udc2b\udbbb\udca1\ud991\uded8\udb42\udf72\ud928\udeb0\ud871\udf5d\u4328\ud973\uddd5\ud9d8\udd1f\udaa4\ude0c\udb7a\udefb\ud8e7\udc07\ud8f8\udd7b\udb31\udeb5\udb13\udca1\udb61\udd65\u3365\ud904\udceb\ud8c3\udca8\uda10\uddf4\udbff\uddc0\udab8\udc5b\ud94c\udf4a\ud8e1\udc2b\ud830\udc12\uda97\udf05\uda20\udf3e\uda4d\udefa\ud855\ude5e\ud898\udfa6\ud856\ude42\ud813\udd84\ud9da\uded4\ud913\ude84\ud985\uddf2\ud81d\udd58\ud8a4\udff0\uda61\udcc3\ud885\udf4b\ub8c4\ud979\udc89\ud8a9\udf29\ud883\udc4e\udb5a\uddd6\ud929\udfe1\uda58\uddc5\udb98\udf40\uda25\udef2\uda79\ude0d",
        -3, 80481, 2136762320, 492949045799736390L, -63040L, false, false, (char) 43226, (char) 43276,
        Double.longBitsToDouble(0x3fd955c3bbf670caL), Double.longBitsToDouble(0x3fe0dcfa986940bbL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.TreeMap:{} |this=org.joda.time.tz.ZoneInfoCompiler:@?\0121=java.util.TreeMap:{} |this=org.joda.time.tz.ZoneInfoCompiler:@?\012",
        Z.run(T, 2, 0, 0, 3, "\uda1d\ude52\uda9e\udefb\ud9ff\udeb7\u00c9\000\uda66\udc20\uda1e\udfd4\udb9e\udf9c\ud9eb\udc7d", "\u7769\u695d\000\u484c\uabf1\ua77f\uaa3d", "\ud9ec\uddb5\ud8b3\udd7d\udabe\udd64\uda6a\uddc7/\000\000\000\000\000\000\uda95\udc04\udbbb\udca1\ud964\uddc5\ua036\ud998\udfac",
        21, 47962, -1141644840, 57426021187584L, 58018L, false, true, (char) 433, (char) 24526,
        Double.longBitsToDouble(0x3fee3b088537bf23L), Double.longBitsToDouble(0x3fded3e579793748L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.util.TreeMap:{} |a1=[Ljava.io.File;:[[]] |this=org.joda.time.tz.ZoneInfoCompiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 10, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud85f\ude29\ud89b\udd27\uda66\udc20\uda1e\udfd4\udb9e\udf9c\ud83f\udfc5\ud9f2\udeb4\ud86f\udf77\udbce\udc67\udac0\udc1b", "\uabf1\ubaba\u9c88\u6ff0", "\ud8b3\udd7d\udabe\udd64",
        8, 51767, -1628045500, -6958438080531658995L, 26054L, true, false, (char) 46085, (char) 24372,
        Double.longBitsToDouble(0x3fdb6407dd62f254L), Double.longBitsToDouble(0x3fe849ff22d7b696L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\ud999\udfe5\udb52\udf01\uda1b\udceb\ud855\udeef\ud89b\udd42\uda66\udc20\uda1e\udfd4\udb9e\udf9c\ud9eb\udc7d\0121=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 2, 7, 6, 3, "\ud999\udfe5\udb52\udf01\uda1b\udceb\ud855\udeef\ud89b\udd42\uda66\udc20\uda1e\udfd4\udb9e\udf9c\ud9eb\udc7d", "\u5428\u0deb\u2810\u417b\u2e51\u5433\u38ac\ub75d\ud5cf\ud7eb\ubb0d", "\uda97\udd81\udb6b\udde6\ud848\udfbe\udb43\udd4d",
        25, 82078, -2049025729, -2423167328381468459L, -62409L, false, false, (char) 58094, (char) 61486,
        Double.longBitsToDouble(0x3fd46a405b838502L), Double.longBitsToDouble(0x3fecc1e54c677085L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 6, "\uda1d\ude13\uda9e\udefb\udad1\udd51\ud97a\udd3f\uc9f5\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud805\ude57", "\u7758\u1f96\ub224\ubcf5\uabf1\ua77f\u9b20\u6f85\u77e9\ud79a\ubb0d", "\ud8bb\udf27\ud8b9\udc57\ud83e\udef5\udb43\udd4d",
        23, 80998, 1920118644, 4724434430062329947L, -58830L, true, true, (char) 6756, (char) 46368,
        Double.longBitsToDouble(0x3fd196e56a151978L), Double.longBitsToDouble(0x3fe6781e4b90dd98L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.util.TreeMap:{} |this=org.joda.time.tz.ZoneInfoCompiler:@?\0121=java.util.TreeMap:{} |this=org.joda.time.tz.ZoneInfoCompiler:@?\012",
        Z.run(T, 2, 0, 0, 12, "\uda1d\ude5d\uda9e\udefb\udae7\udff7\ud855\udecc\ud89b\udd42\uda66\udc20\ud8fc\udce2\ud953\udc03\udbf1\ude01", "\u11cd", "\ud80e\udcf0\udbf2\udf0e\udb9e\udf16\ud8f6\udc0c\udb53\udf5a\uda89\udeb8",
        47, 60630, -124803490, 3620646820676813078L, -22031L, true, false, (char) 63353, (char) 42886,
        Double.longBitsToDouble(0x3fc53334189e16dcL), Double.longBitsToDouble(0x3fe6aef2fa0a4077L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 3, "\000", "\000\u0300\u2e90\ub17b", "",
        -5, 23348, 0, -2063597568L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe0000004e9f6bcL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 4, 1, "\000\uda9e\udea8\uda1b\uddb7\ud855\udeef\udb81\udf15\udaa5\udfac\ud994\udcad\u9806\ud957\udf3b", "\u7769\u1f96\ub224\ubcf5\023\ua77e\uaa3d\u6f85\u77e9\u2c9a\u76e7", "\udb1e\udd89\u39a0\ud80c\uddbb\ud8d5\udd15",
        -1, 45062, 22847, -2423167495885193003L, 98579L, true, true, (char) 59649, (char) 31144,
        Double.longBitsToDouble(0x3fe899a2ec3bbbb2L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void\0121=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 2, 11, 5, 12, "\ud8dc\udf91\uda61\udd56\u2098\ud9e1\udccb\ud87e\udea6\udb22\udf2d\udb1e\udf6f\ud876\udd26\ud874\udc7f", "\ua9f9\u1f96\u898d\u2aec\uabf1\u9c3d\u3dfd\ub4d3\u2a79\u8d99\u1411", "\ud8c1\udef7\u3a14\ud86c\udfe7\ud970\udfae\ud93d\uddef\uda28\ude27\udb6e\udd83",
        36, 45460, 879493253, -8907891915645125945L, 13986L, true, true, (char) 11342, (char) 18925,
        Double.longBitsToDouble(0x3fa60d73530077a0L), Double.longBitsToDouble(0x3fda63a198b0afaeL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=java.lang.Character:w\012",
        Z.run(T, 2, 10, 10, 5, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud85f\ude29\ud89b\udd27\ud98b\udcd3\uda1e\udfd4\udb9e\udf9c\ud83f\udfc5\ud9f2\udeb4\ud86f\udf77\uda0b\udc09", "\ubcf5\uabf1\ubaba\u9c88\u6ff0\u77e9\ud79a", "\u2498\udb9c\udc76\udaa3\udfda\ud953\udcb0\udb43\udd4d\uda2f\udf71\ub7df\ud99b\udd0c\uda95\udc2b\udbbb\udca1\udbdc\udcd9",
        6, 36793, 1161269975, 6741256122685042825L, -36788L, false, true, (char) 52497, (char) 45032,
        Double.longBitsToDouble(0x3fe1104059e21ab2L), Double.longBitsToDouble(0x3fafe414f90223c0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.util.TreeMap:{} |a1=[Ljava.io.File;:[[]] |this=org.joda.time.tz.ZoneInfoCompiler:@?\0121=!java.io.FileNotFoundException\012",
        Z.run(T, 2, 0, 3, 10, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud85f\ude29\ud89b\udd27\uda66\udc20\uda1e\udfd4\udb9e\udf9c\ud83f\udfc5\ud9f2\udeb4\ud86f\udf77\udbce\udc67\udac0\udc1b", "\uabf1\ubaba\u9c88\u6ff0", "\ud8b3\udd7d\udabe\udd64",
        8, 51767, 1939448388, 2432985450608383274L, 26054L, true, true, (char) 10228, (char) 24372,
        Double.longBitsToDouble(0x3fdb6407dd62f254L), Double.longBitsToDouble(0x3fe849ff22d7b696L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\0121=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\012",
        Z.run(T, 2, 1, 1, 6, "\uda35\udc8f\uda59\udd18\ud882\udecf\uda0f\udd2a\ud8df\udd3f\uda40\uded5\udbc0\ude66\udb6a\udc66\udbbc\ude6c", "\u99cc\ubf32\ub224\ubcf5\uabf1\ua77f\u9a7a\u6f69\u6ad5\uaafb", "\u525e\ud82c\udf60\ud8b9\udc57\ud83e\udef5\udb43\udd4d\ud973\udf53\ud8e7\udf12\ud974\udf5a\udaa1\udeb2\ud8ca\udc92\ud8d8\udc3a",
        29, 49386, -475848567, 7950702610457534745L, 73348L, false, true, (char) 28733, (char) 25218,
        Double.longBitsToDouble(0x3fdbc97f95b6bc2eL), Double.longBitsToDouble(0x3fe37ad09ad6b216L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\012",
        Z.run(T, 1, 1, 10, 2, "\udb42\udc3e\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20", "\u7d4b\uc495\ua83e\u7769\u1f96\ub224\u8a3f\uac9a", "\udb53\udf5a\u057b",
        39, 97345, -852169495, -1589979870805037182L, 60036L, true, true, (char) 32126, (char) 49614,
        Double.longBitsToDouble(0x3fd0c201ac4f0bbcL), Double.longBitsToDouble(0x3fcabbcbf63101f4L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.util.TreeMap:{} |a1=[Ljava.io.File;:[[]] |this=org.joda.time.tz.ZoneInfoCompiler:@?\0121=java.util.TreeMap:{} |a1=[Ljava.io.File;:[[]] |this=org.joda.time.tz.ZoneInfoCompiler:@?\012",
        Z.run(T, 2, 0, 0, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\uda1e\udfd4\udb9e\udf9c\ud9eb\udc7d", "\u7769\u1f96\u977a\ubcf5\uabf1\ua77f\uafab\u6f85\u77e9\ud79a\ubb0d\u902f", "\u398c\ud848\udfbe\udb43\udd4d",
        56, 82078, -2049025729, -2423167328381468459L, -58986L, true, true, (char) 18797, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d87777e6L), Double.longBitsToDouble(0x3fe5ea982b908998L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 11, 11, 14, "\ud9ef\ude5b\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\uda1e\udfd4\udb9e\udf9c\ud9eb\udc7d\ud9f2\udeb4\ud86f\udf77\udbce\udc67\uda9f\ude0b\ud99e\udcd6\ud95e\udcf8\uda89\udd1c\ud9cc\udddb\ud8f6\udc69\udb53\udf5a\u057b\udb37\ude52\ud975\udc66\ufe36\ud832\udf54\ud86c\udfc4\ud9b0\udd6e\udbc0\udd5e\udb43\udde0\uda2f\udf71\ub7df\ud9b0\ude0c\uda95\udc2b\udbbb\udca1\ud883\uded0\udbb0\udff9", "\u4e22\u7931\u5d70\u7fdf\u6cf0\u743a\u7168\u714f\ucd06\uaa22", "\udb3d\udebe",
        12, 26030, 1796120185, 5413265346653084679L, 83848L, true, false, (char) 58322, (char) 14489,
        Double.longBitsToDouble(0x3fe9043d0034fd8aL), Double.longBitsToDouble(0x3fe747c41986e057L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.joda.time.tz.ZoneInfoCompiler$DateTimeOfYear:MonthOfYear: 1\012DayOfMonth: 1\012DayOfWeek: 0\012AdvanceDayOfWeek: false\012MillisOfDay: 0\012ZoneChar: w\012\0121=org.joda.time.tz.ZoneInfoCompiler$DateTimeOfYear:MonthOfYear: 1\012DayOfMonth: 1\012DayOfWeek: 0\012AdvanceDayOfWeek: false\012MillisOfDay: 0\012ZoneChar: w\012\012",
        Z.run(T, 2, 2, 2, 2, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda65\udfbf\ud994\udcad\ud953\udc03\udbf1\ude01", "\u7769\u1f96\u7e31\u140e\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\uda42\udc9a\u398c\ud80d\udcbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, -95303L, false, false, (char) 5685, (char) 61486,
        Double.longBitsToDouble(0x3fd0753057211330L), Double.longBitsToDouble(0x3fdd54cdadca1f98L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 6, "\000\uda90\udea8\udad1\udd51\ud97a\udd3f\uc9f5\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud805\ude57", "\u7758\u1f96\ub224\ubcf5\u9cf0\ua77f\u9b20\u6f85\u77dc\ud79a\ubb0d", "\u2c2f\000\ud83e\ude4f\udb43\udd4d",
        23, 80998, 1920118644, 4724434430062329947L, -58830L, true, true, (char) 6756, (char) 46368,
        Double.longBitsToDouble(0x3fd196e560000000L), Double.longBitsToDouble(0x3fe678000000dd98L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 7, "", "\u8df6", "\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud93f\ude54\ud9f2\udeb4\uda86\udfe2\udbce\udc56\uda9f\ude0b\ud90d\udc4e\ud95e\udcf8\uda54\udd1c\001",
        52, 55369, -1870488576, 2129336848378242569L, 14245L, true, false, (char) 0, (char) 32767,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Integer:21600000\012",
        Z.run(T, 1, 8, 4, 1, "6\uda9e\udea8\uda1b\uddb7\ud855\udeef\udb81\udf15\udaa5\udfac\ud994\udcad\u9806\ud957\udf3b\ud9f2\udf05\udb3c\udf7c\udbce\udc67\uda9f\ude0b\ud90d\udc4e\ud95e\udcf8\023\ud9cc\uddda\ud8f6\udc69\udb53\udf5a", "\u76e7\u90b5", "\u39a0\ud80c\uddbb\ud8d5\udd15\ud81f\udd27\udb80\udfd4\u593f",
        -3, 53805, 1368466153, 4584391409466238729L, -13629L, true, true, (char) 11920, (char) 48140,
        Double.longBitsToDouble(0x3fec844cc0dc42ccL), Double.longBitsToDouble(0x3fce0168e3316074L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:21600000\012",
        Z.run(T, 1, 8, 4, 1, "6", "\u2473\u0cda\u0de4\uca38", "\ud9f2\udf05\udb3c\udf7c\udbce\udc67\uda9f\ude0b\ud90d\udc4e\ud95e\udcf8\023\ud9cc\uddda\ud8f6\udc69\udb53\udf5a\u057b\ud8e8\uddb0\udbcc\udf09\udbf9\udeb5\ud8d5\udd9c\udb1e\udd89\u39a0\ud80c\uddbb\ud8d5\udd15",
        19, 34542, 22847, -2423167495885193003L, 98579L, true, true, (char) 59649, (char) 31144,
        Double.longBitsToDouble(0x3fe899a2ec00fa8fL), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:21600000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 1, "6\uda9e\udea8\uda07\uddb7\ud855\udeef\udb81\udf15\udaa5\udfac\ud994\udcad\u9806\ud823\udd94\udbbb\uddcf\udb45\udf28\udbe7\uddb2\uda91\udd7a\ud90d\udc4e\ud952\udef8\uda8c\ude39\ud9cc\udeb2\ud8f6\udc69\udb53\udf5a", "\u5fe8\u90b5", "\u39a0\ud80c\uddbb\ud8d5\udd15\ud81f\udd27\udb80\udfd4\u593f",
        45, 16034, -105298423, 9205277733172963081L, -13629L, true, true, (char) 11920, (char) 6740,
        Double.longBitsToDouble(0x3fec844cc0dc42ccL), Double.longBitsToDouble(0x3fce0168e3316074L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Integer:6\012",
        Z.run(T, 1, 5, 13, 1, "6", "\u2473\uc80b\u0de49", "\ud9f2\udf05\udb3c\udf7c\udbce\udc67\uda9f\ude0b\ud99c\udd54\ud95e\udcf8\023\ud971\udfad\ud8fb\udf4f\udb53\udf5a\ud886\udddb\ud8c7\udd0d\udbcc\udf09\udbf9\udeb5\ud8d5\udd9c\udb1e\udd89\u39a0\ud80c\uddbb\ud8d5\udd15",
        19, 34542, 22847, -2423167495885193003L, 98579L, false, false, (char) 40316, (char) 31144,
        Double.longBitsToDouble(0x3fe899a2ec00fa8fL), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Integer:6\012",
        Z.run(T, 1, 6, 1, 14, "6", "\u2473", "\ud994\udcad\u9806\udbd7\ude52\ud9f2\udf05\udb3c\udf7c",
        59, 87866, -2058089591, 6397244235673028378L, 17974L, true, true, (char) 58169, (char) 21527,
        Double.longBitsToDouble(0x3fb1b7f797c11658L), Double.longBitsToDouble(0x3fc4abba161f7060L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 6, 10, 1, "1", "\u2473\u0cda\u0e3d", "\udbd7\ude52\ud9f2\udf05\udb3c\udf7c\udbce\udc67\uda9f\ude0b\ud90d\udc4e\ud95e\udc57\uda87\udf24",
        59, 78146, 1194179369, -8033687206166084715L, -60328L, true, false, (char) 49567, (char) 63626,
        Double.longBitsToDouble(0x3fba66e497d08020L), Double.longBitsToDouble(0x3fcac283d2debf58L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Character:u\012",
        Z.run(T, 1, 10, 10, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\udb1b\udeb2\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\uae25\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9", "\udbd2\uddf4\u2498\udb60\udc78\udb3a\udd80\ud80c\uddbb",
        57, 40993, -1405974938, 7180806257419169454L, -88607L, true, false, (char) 71, (char) 58397,
        Double.longBitsToDouble(0x3fe74ed3a1075305L), Double.longBitsToDouble(0x3fec844cc2435ed0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 8, 4, 1, "0\uda9e\udea8\uda1b\uddb7\ud855\udeef\udb81\udf15\udaa5\udfac\ud994\udcad\u9806\udafb\udc24\ud9f2\udf05", "\u4295\ub249", "\ud9cc\uddda\ud8f6\udc69\udb53\udf5a",
        8, 87933, 583780605, 635216663706071738L, 30904L, true, true, (char) 42567, (char) 34228,
        Double.longBitsToDouble(0x3fc5d0e0ec117500L), Double.longBitsToDouble(0x3fcff4c9c9a95490L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=java.lang.Character:u\012",
        Z.run(T, 2, 10, 10, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\udb1b\udeb2\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\uae25\ubcf5\uabf1\u2b39\ud659\u6f85\u77e9", "\udb78\udde7\u2498\udb60\udc78\udb3a\udd80\ud80c\uddbb",
        57, 40993, -1405974938, 7180806257419169454L, -88607L, true, false, (char) 71, (char) 58397,
        Double.longBitsToDouble(0x3fe74ed3a1075305L), Double.longBitsToDouble(0x3fec844cc2435ed0L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:21600000\0121=java.lang.Integer:21600000\012",
        Z.run(T, 2, 8, 8, 1, "6\uda9e\udea8\uda07\uddb7\ud855\udeef\udb81\udf15\udaa5\udfac\ud994\udcad\u9806\ud823\udd94\udbbb\uddcf\udb45\udf28\udbe7\uddb2\uda91\udd7a\ud90d\udc4e\ud952\udef8\uda8c\ude39\ud9cc\udeb2\ud8f6\udc69\udb53\udf5a", "\u5fe8\u90b5", "\u39a0\ud80c\uddbb\ud8d5\udd15\ud81f\udd27\udb80\udfd4\u593f",
        45, 16034, -105298423, 9205277733172963081L, -13629L, true, true, (char) 11920, (char) 6740,
        Double.longBitsToDouble(0x3fec844cc0dc42ccL), Double.longBitsToDouble(0x3fce0168e3316074L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:6\0121=java.lang.Integer:6\012",
        Z.run(T, 2, 5, 5, 14, "6", "\u2473", "\ud994\udcad\u9806\udbd7\uddaa\ud9f2\udf05\uda09\udf17",
        7, 87866, -2058089591, 6397244235673028378L, 17974L, true, true, (char) 49500, (char) 21527,
        Double.longBitsToDouble(0x3fd819f3d3a64cb4L), Double.longBitsToDouble(0x3fc4ba89b61f7060L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 6, 0, "+\uda9e\udea8\uda1b\uddb7\ud855\udeef\udb81\udf15\udaa5\udfac\ud994\udcad\u9cba\ud957\udf3b\ud9f2\udf05\udb3c\udf7c\udbce\udc67\uda9f\ude0b\ud90d\udc4e\ud95e\udcf8\023\ud9cc\uddda\ud8f6\udc69\udb53\udf5a", "\u76e7\u90b5", "\ud8e4\udd4a\udb75\udd77\ud8d5\udd15\ud81f\udd27\udb80\udfd4\u593f",
        -3, 53805, 1368466153, 4584391409466238907L, -58502L, true, false, (char) 11904, (char) 48140,
        Double.longBitsToDouble(0x3fec844cc0dc42ccL), Double.longBitsToDouble(0x3fce0168e10b9148L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 4, 1, "-\uda9e\udea8\uda1b\uddb7\udba6\uddd9\udbc1\ude57\ud92b\udd46\ud994\udcad\udb4c\udff8\ud93a\udccf\ud864\udc4c\udb3c\udf97\udbce\udc67\uda9f\ude0b\ud90d\udc4e\ud9d8\udccc\023\uda46\udc11\ud8ec\udff6\udb36\udc07", "\u76e7\u90b5\ua7c2", "\ud80c\uddbb\ud8d5\udd15\ud81f\udd27\udb80\udfd4",
        27, 98352, 330000341, -5065985354165712914L, 78069L, true, true, (char) 880, (char) 11920,
        Double.longBitsToDouble(0x3fd075305720d330L), Double.longBitsToDouble(0x3fd5debbe9e0168eL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.joda.time.chrono.LenientChronology:LenientChronology[ISOChronology[UTC]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 8, 1, "-\uda9e\udea8\uda1b\uddb7\udba6\uddd9\udbc1\ude57\uda72\udc0b\udba5\udc1e\udbfb\udedc\ud95e\ude8c\ud942\udd27\udb3c\udef2\udaa6\udf1b\uda9f\uddf1\ud90d\udc4e\ud9d8\udccc\023\uda46\udc11\ud8ec\udff6\udb36\udc07", "\u76e7\u90b5\ua7c2", "\ud80c\uddbb\ud8d5\udd15\ud81f\udd27\udb80\udfd4",
        27, 98352, 330000341, 4893000643601442542L, 78069L, true, true, (char) 880, (char) 11920,
        Double.longBitsToDouble(0x3fd075305720d330L), Double.longBitsToDouble(0x3fd5debbe9e0168eL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Integer:21600000\0121=java.lang.Integer:21600000\012",
        Z.run(T, 2, 8, 8, 1, "6", "\u2473\u8d1c\u8d34\u2bdd", "\ud9f2\udf05\udb3c\udf7c\udbce\udc67\udac8\udd13\ud8d1\udfd7\ud811\udd6aA\ud971\udfad\ud8fb\udf4f\uda20\udd20\ud91a\udf13\udb08\udc49\ud900\udc08\ud882\ude89\ud8d5\udd73\udb1e\udd8b",
        48, 94695, 1717307149, -3268185785921044528L, -46240L, true, true, (char) 25428, (char) 57791,
        Double.longBitsToDouble(0x3fe04e64b8129011L), Double.longBitsToDouble(0x3fee49422802345dL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Integer:21600000\0121=java.lang.Integer:21600000\012",
        Z.run(T, 2, 8, 8, 4, "6\000\uda07\udcdf\ud855\udeef\udb81\udf15\udaa5\udfac\ud994\udcad\u9806\ud823\udd94\udbd2\udd3a\ud9f4\udd08\udbe7\uddb2\uda91\udd7a\ud90d\udc4e\ud952\udef8\uda8c\ude39\ud960\udfa8\ud8f6\udc69\udb53\udf5a", "\u5fe8", "\udae5\udc89\u39a0\ud80c\uddbb\ud8d3\ude08",
        -1, 34542, 22847, 2525853086915525186L, -81396L, true, true, (char) 59649, (char) 10408,
        Double.longBitsToDouble(0x3fe800000400fa8fL), Double.longBitsToDouble(0x3fb3b48140044800L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void\0121=null\012",
        Z.run(T, 2, 11, 7, 10, "-", "\uae57\ud4f5\u6a53\u4518", "\ud942\udd10\udb3c\udef2\udaa6\udf1b\uda9f\uddf1\ud90d\udc4e",
        55, 53336, -1362852352, 593572974868392406L, -39351L, true, true, (char) 9998, (char) 18595,
        Double.longBitsToDouble(0x3feb7cf7af0d9f3aL), Double.longBitsToDouble(0x3fe97b32e6662169L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 10, "-", "\u6d41\ua835\uc163\u904f\u9c70\u72ab", "\ud8ce\ude3e\uda9f\uddf1\ud90d\udc4e\ud909\udccf\ud9de\udd44\udb98\udd2d\ud937\udebb\ud9c1\udce8\udb60\udc05\ud976\ude48",
        57, 63965, 1728839303, 5281567092384333656L, -58L, true, true, (char) 2234, (char) 48254,
        Double.longBitsToDouble(0x3fea8dfbc425b226L), Double.longBitsToDouble(0x3fb7f599aadf51a8L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 7, "", "\u8df6", "\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud93f\ude54\ud9f2\udeb4\uda86\udfe2\udbce\udc56\ud899\ude08\ud90d\udc4e\ud95e\udcf8\ud95f\udec2\u762b",
        18, 21290, -1870477366, 2129336848378242569L, 6336L, true, true, (char) 85, (char) 32767,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=java.lang.Character:u\012",
        Z.run(T, 2, 10, 10, 7, "\ud860\udf11\u9131", "\uab9c\u7ca0\uc7d8", "\ud9f2\udeb4\uda86\udfe2\udbce\udc56\ud899\ude08\ud90d\udc4e\ud95e\udcf8\ud95f\udec2\u75f4",
        18, 21290, -1870477366, 6957195647064087537L, 6336L, true, true, (char) 85, (char) 32767,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=java.lang.Integer:3600000\012",
        Z.run(T, 2, 10, 8, 4, "1\uda90\udea8\udad1\udd51\ud97a\udd3f\uc9f5\uda43\ude31\uda16\udfd4\udb6a\udc66\ud805\ude57\ud9f2\udeb4\uda86\udfe2\udbce\udc56\uda9f\ude0b\ud90d\udc4e\ud95e\udcf8\uda54\udd1c\ud9cc\udddb\ud984\uddb1\udb53\udf5a\u056e\udb01\udd63\ud8b3\udd7d\udabe\udd64\ud918\udcdd\u2c2f\000\ud83e\ude4f\ud9eb\udf21", "\ud718\u5e30", "\udbb1\udc95\uad51",
        37, 37994, 41241, -577237297L, 75519L, false, false, (char) 6782, (char) 6529,
        Double.longBitsToDouble(0x3fda77834984d95aL), Double.longBitsToDouble(0x3f9e4b13f0d31fa0L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 10, 5, 14, "1", "\ub78d\uab9c\u7ca0\ua7d8", "\ud9f2\udeb4\uda86\udfe2\udbce\udc56\uda9f\ude0b\ud90d\udc4e\ud95e\udcf8\uda54\udd1c\ud9cc\udddb",
        52, 55369, -1870488576, 2129098327369459209L, 14245L, true, false, (char) 0, (char) 32767,
        Double.longBitsToDouble(0x3fe86cfb7451015cL), Double.longBitsToDouble(0x3fb78c1a7ba344f8L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Integer:3600000\0121=java.lang.Integer:3600000\012",
        Z.run(T, 2, 8, 8, 9, "1\uda90\udea8\udad1\udd51\ud97a\udd3f\uc9f5\uda43\ude31\uda16\udfd4\udb6a\udc66\ud805\ude57\ud9f2\udeb4\uda86\udfe2\udbce\udc56\ud884\udf89\ud928\udc94\ud95e\udcf8\ud871\udca1\u9b77\udbc6\udff6\udb3b\udd99\u056e\udb01\udd63\ud8b3\udd7d\udabe\udd64\ud918\udcdd\udb0f\udd4d\u00b4\ud83e\ude4f\ud944\udf48", "\ud718\u0aed", "\udbb1\udc95\uad51",
        37, 37994, -1733975783, 140127025761999L, 75519L, false, false, (char) 6782, (char) 6529,
        Double.longBitsToDouble(0x3fda77834984d95aL), Double.longBitsToDouble(0x3f9e4b13f0d31fa0L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 5, 5, 14, "1", "\u764b\uab9c\u7ca0\u4e5e", "\uda1c\udfc8\uda86\udfe2\udbce\udc56\uda9f\ude0b\ud90d\udc4e\ud95e\udcf8\uda54\udd1c\ud9cc\udddb",
        52, 55369, -1870488576, 2129098327369459209L, 14245L, true, false, (char) 0, (char) 32767,
        Double.longBitsToDouble(0x3fe86cfb7451015cL), Double.longBitsToDouble(0x3fb78c1a7ba344f8L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 10, 5, 14, "1", "\ub78d\uab9c\u7ca0\ua7d8", "\ud9f2\udeb4\uda86\udfe2\udbce\udc56\uda9f\ude0b\ud940\ude4e\ud95e\udcf8\udb18\ude87\ud9a1\udef8",
        -5, 71701, -1870488576, 2129098327369459209L, 14245L, true, false, (char) 90, (char) 32767,
        Double.longBitsToDouble(0x3fe86cfb7451015cL), Double.longBitsToDouble(0x3fb78c1a7ba344f8L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=java.lang.Character:u\012",
        Z.run(T, 2, 10, 10, 11, "1", "\ub78d\uab3f\u7ca0\ua7d8", "\ud9f2\udeb4\uda86\udfe2\udbce\udc56\uda9f\ude0b\ud940\ude4e\ud95e\udcf8\udb18\ude87\ud9a1\udef8",
        -5, 71701, -1870488576, 2129098327369459209L, 14245L, true, false, (char) 90, (char) 32767,
        Double.longBitsToDouble(0x3fe889afcc51015cL), Double.longBitsToDouble(0x3fb78c1a7ba344f8L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=!java.io.FileNotFoundException\012",
        Z.run(T, 1, 3, 1, 8, ",\uda9e\udea8\udb59\ude15\uda85\udea3\udb35\udea1", "\u26d1\ub170\uc50d\ua83e\u4ca8\u1f9c\u8344\u7d2a\023", "\ud879\udfe8\u057b",
        23, -395, 147887153, 4744051530125796664L, -22115L, false, true, (char) 63609, (char) 55475,
        Double.longBitsToDouble(0x3fd3f5cf7c000000L), Double.longBitsToDouble(0x3fcabbcbeba501f4L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 7, "]", "\ub78d\uab9c\u7ca0\uc7d8", "\ud9f2\udeb4\uda86\udfe2\udbce\udc56\ud9ab\udcb1\ud90d\udcb5\ud95e\udcf8\uda54\udd1c\001",
        52, 55369, -1870488576, 2129336848378242569L, 38369L, false, false, (char) 87, (char) 51010,
        Double.longBitsToDouble(0x3ec581e400000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 7, "", "\u8df6", "\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud93f\ude54\ud9f2\udeb4\uda86\udfe2\udbce\udc56\uda9f\ude0b\ud90d\udc4e\ud95e\udcf8\uda54\udd1c\001",
        52, 55369, -1870488576, 2129336849258061321L, -30371L, false, true, (char) 119, (char) 32767,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=java.lang.Character:w\012",
        Z.run(T, 2, 10, 10, 3, "", "\u8df6", "\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud93f\ude54\ud9f2\udeb4\uda86\udfe2\ud823\udfe0\ud9b9\udda5\ud90d\udc4e\ud95e\udcf8\uda54\udd1c\001",
        6, 55369, -1870488576, 2129336849258061321L, -30371L, false, true, (char) 119, (char) 32767,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 7, "", "\u8df6", "\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud962\udd8b\ud9f2\udeb4\uda86\udfe2\udbce\udc56\ud899\ude08\ud90d\udc4e\uda5f\udecc\uda3c\udd95\u762b",
        18, 21290, -1870477366, 2129336848378242569L, 6336L, true, true, (char) 103, (char) 32767,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x3fe7f308000000e9L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=java.lang.Character:w\012",
        Z.run(T, 2, 10, 10, 11, "]", "\ub78d\uab9c\u7ca0\uc7d8", "\udb7d\ude7a\ud9a5\ude17\uda31\ude66\ud9a6\ude2b\ud90d\udcb5\ud95e\udcf8\uda54\udd1c\udbfe\ude8c",
        1, 55369, -1870488576, 2129336848378242569L, 38369L, false, false, (char) 87, (char) 51010,
        Double.longBitsToDouble(0x3ec581e400000000L), Double.longBitsToDouble(0x3fe0000000b608e9L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=java.lang.Character:u\012",
        Z.run(T, 2, 10, 10, 7, "", "\u8df6", "\uda43\ude31\uda1e\udfd4\udb6a\udc0e\ud962\udd8b\ud9f2\udeb4\ud9a9\udf4c\udbce\udc56\ud899\ude08\ud8df\udc89\udaee\ude28\udb0e\udd8b\uda86\udfc8",
        33, 21290, 62651451, 2129336573500335625L, 6336L, true, true, (char) 103, (char) 47053,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x3fe7f308000000e9L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Character:s\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 7, "", "\u49d0", "\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud93f\ude54\ud9f2\udeb4\uda86\udfe2\uda27\udf63\uda9f\ude0b\ud90d\udc4e\udb5f\udcf0\ud8e6\udc50\001",
        52, 55369, -1871180286, 2129336849258061336L, 35201L, false, false, (char) 115, (char) 32767,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x3f3172c000000000L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Character:s\0121=java.lang.Character:s\012",
        Z.run(T, 2, 10, 10, 7, "", "\u49d0", "\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud93f\ude54\ud9f2\udeb4\uda86\udfe2\uda27\udf63\uda9f\ude0b\ud90d\udc4e\udb5f\udcf0\ud8e6\udc50\001",
        52, 55369, -1871180286, 2129336849258061336L, 35201L, false, false, (char) 115, (char) 32767,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x3f3172c000000000L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Character:w\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 6, "+\uda90\udea8\udac4\udc8b\ud97a\udd3f\uc9f5\udb8d\udded\uda1e\udf6c\udb6a\udc66\uda74\uddce", "\u7758\u1f96\ub224\ubcf5\u9cf0\ua77f\u9b20\u6f85\u77dc\ud79a\ubb0d\u549f\ub934\u2c2f\000\uc58b\u93eb\u55da\u785d\ud718\u25ca", "\udbb1\udc95\uad51",
        37, 80674, 41466, -577117925L, -61147L, false, true, (char) 23445, (char) 52176,
        Double.longBitsToDouble(0x3fe6742443e4adbdL), Double.longBitsToDouble(0x3fbdb3fcc3407570L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 2, 10, 5, 7, "", "\u8df6", "\uda43\ude31\uda1e\udfd4\udb6a\udc66\ud93f\ude54\ud9f2\udeb4\uda86\udfe2\udbce\udc56\ud899\ude08\ud90d\udc4e\ud95e\udcf8\ud95f\udec2\u762b",
        18, 21290, -1870477366, 2129336848378242569L, 6336L, true, true, (char) 117, (char) 32767,
        Double.longBitsToDouble(0x3ebb83c800000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\udac5\udf46\ud953\udcd2\ud9eb\udc7d", "\u8823\u1f96\ub224\ubcf5\uabf1\ua77f\uaa3d\u6f85\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 18797, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d87777e6L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=java.lang.Character:u\012",
        Z.run(T, 2, 10, 10, 10, "\u05e9", "\ub57e\u5d65\u7c33\u8f4a", "\ud9f2\udeb4\udb0b\ude85\ud94e\udc56\ud899\ude08\ud90d\udc4e\uff28\ud8b6\udf67\udacd\uded6",
        31, 68088, 1926721409, 5829042171089580037L, 14793L, true, true, (char) 117, (char) 32767,
        Double.longBitsToDouble(0x3ebb9bc800000000L), Double.longBitsToDouble(0x3f4ad236647c0000L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 9, 9, 14, "1", "\ub78d\u7518\u6a1d\u1e2a", "\uda09\ude1f\uda86\udfe2\udbce\udc56\uda9f\ude0b\ud940\ude4e\ud95e\udcf8\udb18\ude87\ud9a1\udef8",
        34, 72945, -729622903, 2129342831267685897L, -100000L, false, false, (char) 42619, (char) 62892,
        Double.longBitsToDouble(0x3fb785fc159344f8L), Double.longBitsToDouble(0x3fe357e7883a6509L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.String:\ud8c5\ude46\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\ud89b\udf07\ud994\udcad\udad4\udee4\ud890\udd6c\0121=java.lang.Character:s\012",
        Z.run(T, 2, 7, 10, 1, "\ud8c5\ude46\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\ud89b\udf07\ud994\udcad\udad4\udee4\ud890\udd6c", "\u6189\u0175\u0fb6\u5e9e\ub377\u6bff\u913d\u4eb2\u7849\u7363\ub2f6", "\ud8a4\udf71",
        46, 19551, -497285363, 2407724274928485990L, -75270L, true, true, (char) 83, (char) 29748,
        Double.longBitsToDouble(0x3fe849fcfad7b696L), Double.longBitsToDouble(0x3fc8f8a093b4d174L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 4, 11, "\uda1d\ude52\uda9e\udefb\uda1b\uddb7\ud855\udeef\ud89b\udd42\uda66\udc20\ud994\udcad\ud953\udc03\ud9eb\udc7d", "\u7769\u1f96\ub224\ubcf5\uabf1\ua77f\ud10e\u686c\u77e9\ud79a\ubb0d", "\udb9c\udc76\u398c\ud80c\uddbb\udb43\udd4d",
        8, 45062, -2049025729, -2423167328381468459L, 98579L, true, true, (char) 18797, (char) 21782,
        Double.longBitsToDouble(0x3fdd8345d87777e6L), Double.longBitsToDouble(0x3fd0753057211330L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=java.util.TreeMap:{} |a1=[Ljava.io.File;:[[]] |this=org.joda.time.tz.ZoneInfoCompiler:@?\012",
        Z.run(T, 2, 10, 0, 12, "\000\ud8de\udcae", "\uab9c\ua6b2\u5bb7", "\ud9f2\udeb4\ud84b\udf4b\udb43\ude1f\uda9f\ude0b\ud90d\udc4e\ud832\udda3\ud997\ude80\ud859\udc90",
        52, 5299, -1870509551, 2129288466458479033L, -5652L, true, false, (char) 122, (char) 0,
        Double.longBitsToDouble(0x3fe56930e8620e6cL), Double.longBitsToDouble(0x3fe43571d55b91a1L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 0, 8, ",\uda9e\udea8\udb59\ude15\uda85\udea3\udb35\udea1", "\000", "\udb3c\udf7c",
        24, 87872, 0, -5873256864044548077L, 71021L, true, true, (char) 57563, (char) 0,
        Double.longBitsToDouble(0x3e44e10758000000L), Double.longBitsToDouble(0x3fd91494b0013cd4L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 14, 0, 8, ",\uda9e\udea8\udb59\ude15\uda85\udea3\udb35\udea1", "\ucd32", "\udb44\udefb\ud871\udc3d\uda9f\ude11",
        -5, 64824, 19, -6341068275337658186L, 5485L, true, true, (char) 57563, (char) 0,
        Double.longBitsToDouble(0x3e44e10758000000L), Double.longBitsToDouble(0x3fd91494b0013cd4L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Character:u\0121=java.lang.Character:u\012",
        Z.run(T, 2, 10, 10, 12, "\000\ud8de\udcae", "\uab9c\ua6b2\u5bb7", "\ud9f2\udeb4\udb6e\udd81\udb52\uddab\uda9f\ude1f\ud90d\udc4e\ud832\udda3\ud997\ude80\ud859\udc90",
        52, 5299, -1870509551, 2129288466458479033L, -23020L, true, false, (char) 122, (char) 0,
        Double.longBitsToDouble(0x3fe56930e8620e6cL), Double.longBitsToDouble(0x3fe43571d55b91a1L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 6, 6, 12, "1", "\ub78d\uab9c\u7ca0\ua7d8", "\ud9f2\udeb4\uda86\udfe2\udbce\udc56\uda9f\ude0b\ud940\ude4e\ud95e\udcf8\udb18\ude87\ud9a1\udef8",
        -5, 71701, -1870488576, 2129098327369459209L, 14245L, true, false, (char) 90, (char) 32967,
        Double.longBitsToDouble(0x3fe86cfb7451015cL), Double.longBitsToDouble(0x3fb78c1a7ba344f8L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Character:s\0121=java.lang.Character:s\012",
        Z.run(T, 2, 10, 10, 4, "\ud8c5\ude46\udbd9\udd38\uda1b\uddb7\u37e2\udaeb\uddd8\udaa6\udfac\udbf6\udcea\udad4\udf9b\ud890\udd6c", "\u6189\u6c5b\u0fb6\u5e9e\ub377\u6bff\u913d\u83b4\u7849\u7363\ud767", "\ud8a4\udf71",
        46, 19551, -497285363, 2407724274928485990L, -75250L, true, true, (char) 83, (char) 55916,
        Double.longBitsToDouble(0x3fe849fcfad7b696L), Double.longBitsToDouble(0x3fe63e2824990844L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=void\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 11, 14, 4, ",\uda9e\udea8\udb59\ude15\uda85\udea3", "\000\ucb32", "\udaf7\ude16\ud870\udf83\uda9f\ude11",
        -5, 73568, 19, -6341068275337658186L, 5485L, true, true, (char) 57563, (char) 0,
        Double.longBitsToDouble(0x3e44e10758000000L), Double.longBitsToDouble(0x3fd9149a10013cd4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.tz.ZoneInfoCompiler|compile|java.io.File,[Ljava.io.File;|new:org.joda.time.tz.ZoneInfoCompiler:",
    "M|org.joda.time.tz.ZoneInfoCompiler|getLenientISOChronology||static",
    "M|org.joda.time.tz.ZoneInfoCompiler|getStartOfYear||static",
    "M|org.joda.time.tz.ZoneInfoCompiler|main|[Ljava.lang.String;|static",
    "M|org.joda.time.tz.ZoneInfoCompiler|parseDataFile|java.io.BufferedReader|new:org.joda.time.tz.ZoneInfoCompiler:",
    "M|org.joda.time.tz.ZoneInfoCompiler|parseDayOfWeek|java.lang.String|static",
    "M|org.joda.time.tz.ZoneInfoCompiler|parseMonth|java.lang.String|static",
    "M|org.joda.time.tz.ZoneInfoCompiler|parseOptional|java.lang.String|static",
    "M|org.joda.time.tz.ZoneInfoCompiler|parseTime|java.lang.String|static",
    "M|org.joda.time.tz.ZoneInfoCompiler|parseYear|java.lang.String,int|static",
    "M|org.joda.time.tz.ZoneInfoCompiler|parseZoneChar|char|static",
    "M|org.joda.time.tz.ZoneInfoCompiler|printUsage||static",
    "M|org.joda.time.tz.ZoneInfoCompiler|test|java.lang.String,org.joda.time.DateTimeZone|static",
    "M|org.joda.time.tz.ZoneInfoCompiler|verbose||static",
    "M|org.joda.time.tz.ZoneInfoCompiler|writeZoneInfoMap|java.io.DataOutputStream,java.util.Map|static",
    "C|org.joda.time.tz.ZoneInfoCompiler|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
