package org.joda.time.field;
import org.junit.Test;
import static org.junit.Assert.*;
public class FieldUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:2196402\012",
        Z.run(T, 1, 16, 14, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u3e2d\u901b\u1448\ub5a4\u9ffd\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9547\uc206\u7868\u5bf9\ub0c4", "\udb46\udcfb\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbf4\udfee\ud9ef\udd90\ud83a\udeb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16\ud948\udc67\uda5e\udee4\udaf2\udc4e\udb1b\udd52\ud9bb\ude48\udb26\udf05\ud956\udf59\udbe3\udfb3\ud989\udfd1\ud897\udce9\uda43\ude7a\udbac\ude42\ud83d\udd19\ud9dc\uddac\u1ab8\udbb9\uded0",
        29, 75738, 1659714002, 8723731304523547556L, 53127L, true, true, (char) 53468, (char) 64881,
        Double.longBitsToDouble(0x3fdaf019cf7cb8dcL), Double.longBitsToDouble(0x3fd7a8a749eaaf1eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:2196402\012",
        Z.run(T, 1, 16, 14, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u3e2d\u901b\u1448\ub5a4\u9ffd\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9547\uc206\u7868\u5bf9\ub0c4", "\udb46\udcf5\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud951\udd17\udbf4\udfee\ud9ef\udd90\ud83a\udeb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16\ud948\udc67\uda5e\udee4\udaf2\udc4e\udb1b\udd52\ud9bb\ude48\udb26\udf05\ud956\udf59\udbe3\udfb3\ud989\udfd1\ud897\udce9\uda54\udfc9\udbac\ude42\ud83d\udd19\ud9dc\uddac\u1ab8\udbb9\uded0",
        29, 75738, 1659714002, 8723731304523547556L, 53127L, true, true, (char) 53468, (char) 64881,
        Double.longBitsToDouble(0x3fdaf019cf7cb8dcL), Double.longBitsToDouble(0x3fba229d2f39b8d0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:1721330\012",
        Z.run(T, 1, 16, 14, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\ud838\uddda\ud92d\ude93\u3de3\ud81c\udec0\udb4c\udd44\ud80f\udeb7\ud929\udd4b", "\u57c9", "\ud85c\udfa7\ud887\udf80",
        26, 66205, 1661000880, 3044756966980482339L, -6676L, false, true, (char) 36314, (char) 11523,
        Double.longBitsToDouble(0x3fd9636f7504d4f8L), Double.longBitsToDouble(0x3feda3cf9e93cde9L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:53360\012",
        Z.run(T, 1, 6, 10, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u3e2d\u901b\u1448\ub5a4\u9ffd\u7f52\u5bf9\ua5a2\u3229\u3665\u6875\u9547\u1d7a\ua90e\ucb7e\ub14c", "\udb46\udcfb\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0",
        0, 53360, 958721881, -5645949299591731626L, 15119L, true, true, (char) 11808, (char) 31865,
        Double.longBitsToDouble(0x3fe17d2ce2e64fe9L), Double.longBitsToDouble(0x3fe94ea04b482cf5L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 6, 7, "\ud81b\udc81\udadc\uded9\udb18\udd67\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u517c\u901b\u2568\u75ad\u3047\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9f29\u5f5f\u7868\u5bf9\ub0c4", "\udb46\udcfb",
        44, 54510, 2045989506, -3609191226887049581L, 18464L, true, false, (char) 55237, (char) 10415,
        Double.longBitsToDouble(0x3fe28fcfffe763a2L), Double.longBitsToDouble(0x3feda2e0dcd5f58bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 8, 1, 3, "\ud805\udded\uda04\udd0c\u4187\udba4\udd1f\udb5a\ude93\ud92d\ude93\u3de3\ud81c\udec0\udb4c\udd44\ud80f\udeb7\ud929\udd4b\ud9a1\ude58\ud89f\udd7c\ud9ed\ude84\udb69\udf52\udb60\udd57\ud950\udea7\ud88e\udf9f\uda5d\ude52\uda7b\udf10\uda64\ude85", "\u3c8a\u319f\u6108\u2f2f\u0a46\u7292\u4b0b\ua856", "\u448c\uda2e\udc57\udbcf\ude6a\ud9d0\udc26\udaa4\ude3c\uda5c\ude06\uda93\udeec\ud949\udd33\udb1a\udee2\ud98d\udffb\udb1b\udd52\ud9bb\ude48\udb26\udf05",
        47, 81672, -1626481272, 144226010284716391L, -20685L, false, true, (char) 24500, (char) 49849,
        Double.longBitsToDouble(0x3fd7a6875d82fd30L), Double.longBitsToDouble(0x3fed23ca0d809a6aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:-13\012",
        Z.run(T, 1, 9, 14, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udbb7\udf78\udb5a\ude93\ud92d\ude93", "\u3e2d\u901b\u1448\ub5a4\u9ffd\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9547", "\ud9d0\udebc\udbbb\udec8\udad5\ude69\ud822\ude09\udb46\udcfb\ud8f3\udc9d\ucb60\udb46\ude6c\ud93e\udcc0\udbf4\udfee\ud9ef\udd90\ud83a\udeb7\udba6\ude68\uda88\udf76",
        13, 26169, 1545285607, -753495642977318910L, -954L, false, true, (char) 48388, (char) 33594,
        Double.longBitsToDouble(0x3fc74091e9e29300L), Double.longBitsToDouble(0x3fd8858d19973e1aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:-34\012",
        Z.run(T, 1, 9, 16, 7, "\ud822\udd3e\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\udeb6\ud92d\ude93", "\u3e2d\u901b\u1448\ub5a4\u9ffd\ua516\u43af\ua5a2\u2862\u55b7\u685c\u9547\uc206\ubb55\u1c0f\ub0c4", "\udb2d\udfe4\udb31\ude1a\ud93f\ude13\udb45\udeb1\ud93e\udcc0\udbf4\udfee\ud9ef\udd90\udbe5\udfc5\ud909\ude91\udb3c\udde8\ud9b3\ude5c\udb2f\udc1f\udab4\udcb5\ud843\udfbe\ud947\udfb4\udad6\udcec\udaf1\udffd\udb1b\udd52\ud9bb\ude48\udb58\udd3e\udb58\udcf9\ud823\uddd1\ud989\udfd1\ud902\ude00\ud9b2\udf4a\ud8ec\ude7a\ud83d\udd19\ud9dc\uddac\uda24\udd66\u6e65",
        34, 17379, 1659714420, -8535296119594236950L, 17192L, false, false, (char) 53496, (char) 64881,
        Double.longBitsToDouble(0x3fdaf019cf7cb8dcL), Double.longBitsToDouble(0x3fd7a8a749eaaf1eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 7, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\ua16c\u901b\u1448\ub5a4\u9ffd\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9547\uc206\ua4d2\u5c1d\ub0c4", "\udb1e\udd17\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbf4\udfee",
        40, 28881, -1314550009, -8505005745580826953L, -954L, true, true, (char) 65165, (char) 49747,
        Double.longBitsToDouble(0x3fc74091e9e29300L), Double.longBitsToDouble(0x3fd8858d19973e1aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 11, 16, 7, "\ud9d1\udf93\udaf4\udc44\udb4d\udd34\udba4\udced\udb5a\ude93\ud92d\ude93", "\u7ff3\u4217\u0fee\ub5a4\u9ffd\ub281\u4b22\u0313\u747c\u2959\u497a\uc3d9\uc24b\u6db4\u5bf9\ub0c4", "\uda6d\udf81\ud8e0\udd3e\udbdb\udcdf\udb36\uddf1\ud93e\udcc0\udbf4\udfee\ud876\ude65\ud83a\udeb7\ud86b\uddd5\udb69\uddcf\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16\ud952\udc67\uda5e\udf50\udaed\udce1\udb1b\udd52\udbd1\udde0\udb26\udf05\ud956\udf59\udbe3\udfb3\uda34\ude8e\ud894\udc28\uda43\ude7a\udbac\ude42\ud83d\udd19\ud9dc\uddac\u1ab8\udbb9\uded0",
        -5, 75738, 850999762, 8734766527205917604L, -75827L, false, true, (char) 54932, (char) 34110,
        Double.longBitsToDouble(0x3fc8e3d6cdd6b944L), Double.longBitsToDouble(0x3feedbdab5a6f8a7L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:40\012",
        Z.run(T, 1, 4, 13, 9, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u2115\u1056\u1c4d", "\uda18\udc69",
        40, -710, 811964621, -3256548751889297866L, -70013L, true, false, (char) 64050, (char) 6046,
        Double.longBitsToDouble(0x3f8dd39901037ac0L), Double.longBitsToDouble(0x3fd9636ce504d4f8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:-1624302449\012",
        Z.run(T, 1, 5, 9, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\ud9ad\udec4\ud819\udc07\ud9fc\udea2", "\u2d95\u2135\u0ca9\uadc1\u0b35\u57c9\u5bf9\u1fb5\u3d37\u8c99\u1175\u9547\uc206\u7868\u5c67\u6be0\u0545\u7e78\ud6cb\u0a80\u43cb\u14a7\ua856", "\ud83a\udeb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud9a9\udfae\ud948\udc67\udb4c\uddbc\udad7\udc45\udb1b\udd52\ud9bb\ude48\udb26\udf05",
        47, 81672, -1624384120, 144226010284716391L, 95066L, true, false, (char) 25860, (char) 63458,
        Double.longBitsToDouble(0x3fea2938137a4ff6L), Double.longBitsToDouble(0x3fdd268756cec5daL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 1, 12, 8, 5, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udaf7\udd4e\ud920\udea4", "\u4a46", "\ud9a1\ude58\udbfe\udcea\uda18\udc69\udbf0\udddb\uda85\udd7d\ud85c\udfa7\ud887\udf80\uda5d\ude52\uda7b\udf10\udb8e\udddb\ud9c6\udcd1\udab0\udf0b\udb61\udef9\udac3\udc62\ud88a\udc34\ud82f\udcf8\ud8f3\udd17\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbbe\uddee\ud9ef\udd90\ud83a\udeb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda29\udd54",
        4, 59531, -1343633873, -3167856862876589271L, -63886L, false, false, (char) 3641, (char) 9657,
        Double.longBitsToDouble(0x3fc973f7459c0800L), Double.longBitsToDouble(0x3fd76ce643f41b2aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Long:-4385864652513458178\012",
        Z.run(T, 1, 7, 4, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u3e2d\u901b\u1448\ub5a4\u5e82\u57c9\u5bf9\ua9c8\ubeb5\u907e\u6875\u9547\uc206\u7868\u911e\ub0b6", "\udb46\uddd1\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbf4\udfee",
        6, 28881, -1314550009, -4385864652513370441L, -87737L, false, true, (char) 45894, (char) 27595,
        Double.longBitsToDouble(0x3fe7327f4b29d409L), Double.longBitsToDouble(0x3fd989cf55829f24L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:1659638316\012",
        Z.run(T, 1, 4, 9, 7, "\ud805\udded\ud884\udef9\ubc7b\uda7a\ude31\udb47\ude5a\ud92d\ude93", "\u2b71\u9e62\u1448\ub4fe\u9ffd\u57c9\u5bf9\ub6d4\u3183\u3c44\u685b\u9547\u6bca\u8525\u98e2\ub0c4", "\udb46\udcfb\udb34\udc8f\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbf4\udfee\ud9ef\udd90\ud811\udfb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16\ud97a\udef4\uda4f\udfeb\udaf1\udffc\udb1b\udd52\ud9bb\ude48\udb26\udf05\ud956\udf59\udbe3\udfb3\ud917\udc56\ud887\udfa9\udb98\udee0\uda54\udf18\ud807\ude50\ud9dc\uddac\u1ab8\udbb9\uded0",
        29, 75738, 1659714024, 8723731304523547556L, 53127L, true, true, (char) 33507, (char) 59853,
        Double.longBitsToDouble(0x3fc6bc801ef97010L), Double.longBitsToDouble(0x3fece453a4c54b9bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 1, 14, 7, "\u891e\uda04\udd71\u40c2\udba4\udc9c\udb5a\ude93\uda6b\ude92", "\u3e2d\u901b\u1448\ub5a4\u9ffd\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9547\ud6ef\ubd61\u4ae5\u2c03", "\udb46\udcfb",
        44, 54510, 2045989506, -3609191223531606381L, 15119L, true, true, (char) 26575, (char) 45717,
        Double.longBitsToDouble(0x3fe17d2ce2e64fe9L), Double.longBitsToDouble(0x3fe94ea049989cf5L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 7, "\ud805\udded\uda04\udd0c\udadf\udebc\udbba\ude3f\udb5a\ude93\uda0f\udde4", "\u1a07\u8b48\u70c3\ub519\u9770\u57c9\u5bf9\ua5a2\u3229\u1d51\uc745\u6a92\uc206\u7868\u5bf9\ub4ea", "\udb46\uddc2\ud8f3\udc9d\uda90\ude6e\udaa4\udd3a\ud93e\udcb3\udbf4\udfee\ud9ef\udd90\ud83a\udeb7\udba6\ude68\uda0a\udf2f\ud9b3\ude5c\udb20\ude98\uda5f\udf4b\ud8ce\udd9e\udbdb\uddd0\udab5\uddb0",
        0, 95721, 1334993304, 328607469544693946L, 22248L, true, false, (char) 29543, (char) 6107,
        Double.longBitsToDouble(0x3fe7d06cab794491L), Double.longBitsToDouble(0x3fe5b2800943e00bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 17, 14, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb3d\udea4\ud8ba\ude59", "\u3206\u6573\u1448\ub5a4\u6f6f\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9547\uc206\u7868\u5bf9\ub0c4", "\udb46\udcfb\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbf4\udfee\ud9ef\udd90\ud83a\udeb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16\ud948\udc67\uda5e\udee4",
        0, 95721, 1334993304, 328607469544693946L, 22248L, true, false, (char) 29543, (char) 6107,
        Double.longBitsToDouble(0x3fdfa0d95a995a6eL), Double.longBitsToDouble(0x3fe16e1429208176L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:8723731304523494429\012",
        Z.run(T, 1, 10, 2, 10, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\ud957\udd69\udbc2\udeff", "\u3e2d\u901b\u1448\ub5a4\u0703\u8784\u62fe\ua5a2\u3229\u8c99\u6875\ubbe1\uc206\u9197\u5bf9\u78c9", "\udb46\udcfb\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbf4\udfee\ud9b5\udd93\ud83a\udeb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16\ud948\udc67\uda5e\udee4\udaf2\udc4e\udb1b\udd52\ud9bb\ude48\uda97\udd3d\ud94c\udcbe\udbe3\udfb3\ud989\udfd1\ud897\udce9\uda3c\udd7a\udbac\ude42\ud83d\udd19\ud9dc\uddac\ud86b\udd08\udba2\udef7",
        -5, 46317, 1659714002, 8723731304523547556L, 53127L, true, true, (char) 53468, (char) 48169,
        Double.longBitsToDouble(0x3fdaf019cf7cb8dcL), Double.longBitsToDouble(0x3fd7a8a749eaaf1eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 3, 15, 7, "\ud805\udded\uda04\udd0c\ud83b\udfeb\ud928\ude3b\ud936\ude1e\udbb0\udf75", "\u3e2d\u901b\u1448\ub5a4\u9ffd\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9547\uc206\u7868\u5bf9\ub0c4\ua634\u6108\u2f2f\u0a86", "\ud93e\udcc0\udbf4\udfee\ud9ef\udd90\ud83a\udeb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16",
        11, 45687, -737574170, -7136759374163058280L, -75238L, false, false, (char) 13913, (char) 44936,
        Double.longBitsToDouble(0x3fd6702002ed9cc8L), Double.longBitsToDouble(0x3fdfa0d95a995a6eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=new org.joda.time.field.FieldUtils:@?\012",
        Z.run(T, 2, 3, 15, 7, "\udbfc\udd69\uda04\udd5e\udb13\ude16\udacb\uddaa\ud838\uddda\ud92d\ude93\ud97d\udd79\ud81c\udec0\udb4c\udd44\udb00\udf20\ud929\udd52\ud9a1\ude58\udbfe\udcea", "\ua5a2\u3229", "\uda7b\udf10\udbcd\ude89\uda6c\udf54\ud800\udf91\udb61\udf47\ud8a2\udd52\udbc7\ude19\udb24\udfbc\ud8ed\udde5\ud9ee\udfdc\ud910\udf5f\u16ca",
        -5, 37818, -1212099140, -1545994282609041756L, -56232L, true, true, (char) 64998, (char) 4030,
        Double.longBitsToDouble(0x3fd8b4a0a0001eb8L), Double.longBitsToDouble(0x3fd9b1c78193391aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 11, 12, 12, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\ud838\uddda\ud92d\ude93\u3de3\ud81c\udec0\udb4c\udd44\ud80f\udeb7\ud929\udd4b", "\u57c9", "\ud85c\udfa7\ud887\udf80",
        54, 66205, 1661000880, -1751277375732812509L, -69202L, false, true, (char) 36314, (char) 11523,
        Double.longBitsToDouble(0x3fd9636f7504d4f8L), Double.longBitsToDouble(0x3feda3cf9e93cde9L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:1721330\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 14, 7, "\ud949\udc9e\udad2\ude49\udb13\ude16\udb86\udf1f\ud838\uddda\ud906\ude3f\u3df8\ud81c\udec0\udb14\udfc9\ud80f\udead\ud929\udd4b", "\u57c9", "\ud85c\udfa7\ud887\udf80",
        26, 66205, 1661000880, 3044756966980482339L, 17078L, true, true, (char) 52191, (char) 22047,
        Double.longBitsToDouble(0x3fecde8bca82fd62L), Double.longBitsToDouble(0x3feda3cf9e93cde9L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:-806\012",
        Z.run(T, 1, 6, 15, 7, "\ud805\uddab\uda04\udd0c\ud964\udd7f\ud9fa\udde0\ud9d1\udf5e\ud818\udd88\udbf3\udd7c\ud81c\udec0\udb4c\udd44\ud80f\udeb7\ud929\udd4b\ud9a1\ude58\udbfe\udcea\ud994\udc67\uda0d\udcca\uda85\ude26\ud85c\udfa7\ud887\udf80\uda5d\ude52\uda7b\udf10\uda64\ude85\ud947\udcf6\udab0\udf0b", "\u6151\u2f2f\u0a86", "\uda7c\udca1\ube2f\ud888\udce7\ud9da\udd8e\ud850\udf01\ud8b2\udd7d\udb57\udf17\ud9df\udd75\udb8b\udd2c\ud8a7\udcc6",
        57, -863, 429639027, 8249593453975537615L, 80456L, true, true, (char) 35656, (char) 24090,
        Double.longBitsToDouble(0x3fe36069c0ab0f2bL), Double.longBitsToDouble(0x3feed33bab18a6ceL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Long:8627149690006418998\012",
        Z.run(T, 1, 17, 0, 7, "\udb83\udf94\uda04\udd4a", "\uadc4\u2859\uc03c\u20be\u4829\u8fe0\u265e\u5d2c\u0b28\u05f3\u6648\u7222\u3471\uca61\u6875\u6b4e\u9db1\u783b\uc6d3\uc1d3\ub5b0\ud785\u23e6\u7927\u87a3\u3032\u2c4d\u2645\u757c\u3d62\u202a\uc1d4\u4509\u2143y\u7076\u9004\u555f\u4fe9\ua4c6\u07d1\u0a92\u5d93\u0c8a\u1f45\u8928\u4054\ud6d7\ucc23\ud447\u1657\u9a90\u4a79\ub7c3\u5100\u96b8\u4481\u4a8c\u52bd\ubdf5\u1b47\u539a\u4a3a\u6824\uc718\uab8b\u46db\u16a2\u4e9b\u5054\u719e\uc5c0\u101f\u75b1", "\ud927\udd7c\udbd1\udd4b\ud8cb\ude88\ud929\uddf7",
        -1, 48762, 761285284, -8627149690006418998L, -58405L, true, false, (char) 16406, (char) 34468,
        Double.longBitsToDouble(0x3feb657a0e72cfefL), Double.longBitsToDouble(0x3fc2e77af4a5e2e0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:91913\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 6, 17, 13, "\uda12\udd9e\udb13\udff8\ud9bc\udd3b\udaee\udc06\ud838\udd77\ud92d\ude93\u3de3\ud81c\udec0", "\u4216\ub5a4\ua1d0\uce54\u67f1\u890f\ub1c9\u8106", "\ud8f6\uddde\ud9c6\udcd1\ud921\udf64\udb61\udef9\udac3\udc62\ud822\ude09\ud992\udef6\ud8c0\ude9d\ud942\udc47\ud92a\udf22\ud93e\udc89\ud82d\uddea\ud8bd\ude43\ud9ee\udf2f\ud8ee\udf1c\ud9cf\udd89\ud89a\udfef\uda62\udf6f\udb82\udec9\ud8be\uddb6\udae5\udf52\udaa0\udd85\udadc\uddfe\ud8aa\ude92\ud989\udca1\udaf7\udede\uda33\ude97\udb03\ude88",
        21, 91892, -1065947557, 5524753480783783912L, -31548L, false, false, (char) 17518, (char) 13618,
        Double.longBitsToDouble(0x3fe39dec151c5c23L), Double.longBitsToDouble(0x3fe72f972a10ed44L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Long:-8826707830932972672\0121=java.lang.Integer:-5\012",
        Z.run(T, 2, 10, 9, 10, "\ud805\uddae\uda04\udd0c\udb13\ude16\udba4\udd1f\udbd5\udf99\ud98b\udd5b\udaa8\udefa\uda1d\udd26\udad2\udec5", "\u75ed", "\udb10\udcd9\uda24\udcf9\uda3a\udcf5\udba9\udc0b\u4572\uda7b\udf10\ud82d\udc0a\ud9e3\ude95\ud810\ude1b\udb61\udf06\udac3\udc62\ud822\ude09\udb2b\udc22\ud8f3\udc9d\udbae\udf9d\udb36\udd5c\uda8f\ude68\uda4e\udc8d\ud87a\udf90\ud835\udf9f\udb51\udef1\udbf0\udd1c",
        5, 79381, 1088554572, -8826707830932933660L, 39012L, true, false, (char) 40336, (char) 38279,
        Double.longBitsToDouble(0x3fe48938036bdc78L), Double.longBitsToDouble(0x3fe44f4b582d6f54L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:28839\0121=java.lang.Integer:28839\012",
        Z.run(T, 2, 6, 6, 6, "\udbf2\ude14\uda0b\uddb8\udb03\ude14\udba4\udd1f\ud838\uddda\ud92d\ude93\udbf9\ude4b\ud81c\udec0\udb4c\udd44\ud80f\udeb7\ud929\udd4b", "\u57c9", "\ud85c\udfa7\ud887\udf80",
        26, 28813, 506244528, -7340824849280633565L, 13254L, false, true, (char) 36314, (char) 11523,
        Double.longBitsToDouble(0x3fd9636f7030d4f8L), Double.longBitsToDouble(0x3fd011896d279bd2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:5211795\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 16, 2, 7, "\ud805\ude36\uda04\udd0c\ud830\ude64\uda1e\udde2\ud838\uddda\ud92d\ude93", "\u3e2d\u901b\u1448\ua991\u28ed\u32e4\u2093\ua5a2\u3229\u8c99\u8745\u7580\u292e\u4022\u5bf9\ub0c4", "\udb4a\ude64\ud8f3\udc9d\ud9ee\udfdc\u992a\ud87e\udebe\ud889\udf43\udbb1\udc5e",
        57, 91435, 851067849, -4586005898931382148L, -99711L, true, false, (char) 14222, (char) 29845,
        Double.longBitsToDouble(0x3fdee29a60b6a2c8L), Double.longBitsToDouble(0x3fca24696551c2fcL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:1721330\0121=java.lang.Integer:1721330\012",
        Z.run(T, 2, 16, 16, 7, "\ud805\udded\uda04\udd0c\uda9e\udc44\uda71\udf8b\ud838\uddda\ud92d\ude93\ud863\udc5d\ud81c\udec0\udb4c\udd44\ud80f\udeb7\ud929\udd4b", "\u57c9", "\ud85c\udfa7\ud887\udf80",
        26, 66205, 1661000880, -6451364322299869764L, -70932L, true, false, (char) 37468, (char) 29310,
        Double.longBitsToDouble(0x3fee6c2b2a826ad5L), Double.longBitsToDouble(0x3fe8a9273493cde9L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:-1298702730\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 5, 11, 9, "\ud805\udded\ud8c1\udc40\udafc\udf63\udba4\udd1f\ud838\uddda\ud92d\ude93\u3de3\ud81c\udec0\udb4c\udd44\ud80f\udeb7\ud835\uddb6", "\u57c9\u5bf9\ua54a\u3229\u0319\u6868\u1ee1\u4381\ucc0a\u545e\ub0c4\ua634\u6108\u997c\uacf9\u43cb\u4b0b\uc5cf\u9ab3", "\ud828\udf8d\ud931\ude22\ud89d\udcad\uda93\udcb0",
        34, 39729, -1298742458, 2504970408828289544L, 23256L, true, false, (char) 63304, (char) 43678,
        Double.longBitsToDouble(0x3fe8c59406fbd51fL), Double.longBitsToDouble(0x3fd908eb6a3cc22aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:19083\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 6, 8, 17, "\ud805\udded\ud88f\ude57\udb44\udf8b\udb91\udf64\udb5a\ude93\ud92d\ude93", "\uc796\u8a9f\u13d2\ub5a4\u9ffd\u07b5\u39ab\ua5a2\uc39a\u3665\u6875\u2072\u1d7a\ua90e\u8615\ub0b6", "\udb87\ude4d\ud8f3\udcb6\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0",
        49, 19034, 958721962, -5645949299591690154L, -58865L, true, true, (char) 11808, (char) 58023,
        Double.longBitsToDouble(0x3fca71139b3f1fe0L), Double.longBitsToDouble(0x3feaaadd18f3c02aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 13, 6, 7, "\ud81b\udc81\udadc\uded9\udb18\udd67\udba4\udd1f\ud81b\udf53\ud85a\udf0a", "\u0245\u901b\u2568\u75ad\u3047\u57c9\u5bf9\ua5a2\uc061\u286d\u9f59\u4a58\u5eeb\u7868\u5a50\ub15f", "\udb46\udcfb\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udaa0\udc25\ud8a1\ude09\udb9a\udda6\udac5\udd67\ud91f\udf61\ud9b3\ude5c\ud851\udc30",
        42, -876, 1336493629, -7014552083998765725L, -82853L, false, true, (char) 37683, (char) 52535,
        Double.longBitsToDouble(0x3fe0d31cb9ec41d4L), Double.longBitsToDouble(0x3fe7bfeef182475dL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 6, 7, "\ud81b\udc81\udadc\uded9\udb18\udd67\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u517c\u901b\u2568\u75ad\u3047\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9f29\u5f5f\u7868\u7a3a\u97d6", "\udaa0\udefd\ud8f3\udcd5\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udaa0\udc25\ud8a1\ude09\udb9a\udda6\udac5\udd67\ud91f\udf61\ud9b3\ude5c\ud851\udc30",
        42, -876, -835726123, 7393662137844827660L, 17392L, true, false, (char) 14282, (char) 19823,
        Double.longBitsToDouble(0x3fea5913776a2f11L), Double.longBitsToDouble(0x3fc4cee55a4c9948L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Long:432678030854149173\012",
        Z.run(T, 1, 1, 7, 3, "\ud805\udded\udbd7\udcd0\ud9c8\uddcc\ud9b6\udd27\udb5a\uddf4\ud92d\ude93\u3de3\ud81c\udec0\udb4c\udd44\ud80f\udeb7\ud929\udd4b\u81ca\uda20\udf5c\ud9ed\ude84\udb69\udf52\udb60\udd57\ud950\udea7\ud88e\udf9f\uda5d\ude52\ud82e\udce8\uda64\ude85", "\u3c8a\u1bd6\u60eb\u2f2f\u0a46\u7292\u26e5\ua823", "\u0f04\ud99d\udc8b\ud9c0\udc81\u05bb\udaa4\ude3c\uda5c\ude06\uda93\udeec\ud949\udd33\udb1a\udee2\ud98d\udffb\udb1b\udd52\ud91f\ude5a\ud855\udeff",
        3, 81672, -1626481272, 144226010284716391L, -20818L, true, false, (char) 24532, (char) 49849,
        Double.longBitsToDouble(0x3fd7a6875d82fd30L), Double.longBitsToDouble(0x3fed23ca0d809a6aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 8, 1, 3, "\ud805\udded\uda04\udd0c\u4187\udba4\udd1f\udb5a\ude93\ud92d\ude93\u3de3\ud81c\udec0\udb4c\udd44\ud80f\udeb7\ud929\udd4b\ud9a1\ude58\ud89f\udd7c\ud9ed\ude84\udb69\udf52\udb60\udd57\ud950\udea7\ud88e\udf9f\uda5d\ude52\uda7b\udf10\uda64\ude85", "\u3c8a\u07d8\u60b0\u2f2f\u0a46\u7292\u4b0b\ua856", "\ud83e\udd61\uda95\udc89\udbcf\ude6a\ud9d0\udc26\udaa4\ude3c\uda5c\ude06\uda93\udeec\ud949\udd33\udb1a\udee2\ud98d\udffb\udb1b\udd52\ud9bb\ude48\udb26\udf05",
        47, 81672, 136, -832278169L, 96608L, false, true, (char) 36018, (char) 58006,
        Double.longBitsToDouble(0x3fea2ec37b7a4f3fL), Double.longBitsToDouble(0x3fd7a6875d82fd30L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 2, 16, 7, "\ud9d1\udf93\udaf4\udc44\udb4d\udd34\udba4\udced\udb5a\ude93\ud92d\ude93", "\u7ff3\u4217\u0fee\ub5a4\u9ffd\ub281\u4b22\u0313\u747c\u2959\u497a\uc3d9\uc24b\u6db4\u5bf9\ub0c4", "\uda6d\udf81\ud8e0\udd3e\udbdb\udcdf\udb36\uddf1\ud93e\udcc0\uf693\uc100\ud83a\ude5e\ud86b\uddd5\udb69\uddcf\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16\ud952\udc67\uda5e\udf50\udaed\udce1\udb1b\udd52\udbd1\udde0\udb26\udf05\ud956\udf59\udbe3\udfb3\uda34\ude8e\ud894\udc28\uda43\ude7a\udbac\ude42\ud83d\udd19\u6d4c\u1ab8\udbb9\uded0",
        -5, 75738, 12138962, 0L, -75827L, false, true, (char) 54932, (char) 34110,
        Double.longBitsToDouble(0x3fc8e3d6cdd6b944L), Double.longBitsToDouble(0x3feedbdab5a6f8a7L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 11, 16, 7, "\ud909\udf03\udaf4\udc44\udb4d\udd34\ud92f\udc73\udb5a\ude93\ud92d\ude93", "\u7ff3", "\u00cd\udbfe\udcea\ud944\udf60\ud919\udc72\udb0b\udfa5\ud987\udf1c\ud8a5\udc3f\ud81b\udf91\ud845\udd9c",
        44, 51404, 29987, 0L, 32352L, true, false, (char) 34420, (char) 44585,
        Double.longBitsToDouble(0x3feda3cf9e93cde9L), Double.longBitsToDouble(0x3fd825af0eb30e9cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 14, 17, 9, "\ud805\udded\udbe0\udc8c\uda32\udd11\udba4\udd72\udb5a\ude93\ud92d\ude93", "\u6dfc\u102f\u1c32", "\uda13\udd88",
        40, -710, 811964621, -3256548751889297866L, -70013L, true, false, (char) 64050, (char) 6046,
        Double.longBitsToDouble(0x3f8dd39901037ac0L), Double.longBitsToDouble(0x3fd9636ce504d4f8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:-379258370\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 9, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93\ud894\uddb2\uda62\udfad\ud8a6\udcbd\udad7\udc0e", "\u9ffd\u57c9\u5bf9\uad2f\u3229\uab1e\ucdf3\ua8e1\u7434\u6069\u5bf9\uc4f5\u0bdb", "\udb62\udc48\ud9ee\udfdc\uda9f\udea7\uda1d\uddfe\udbb8\udeb5\ud906\udf99",
        37, 80508, -379338877, 5998874325877954398L, 33012L, true, true, (char) 48176, (char) 47257,
        Double.longBitsToDouble(0x3feed1c325889ac6L), Double.longBitsToDouble(0x3fc1f0e390727a3cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 0, 16, "\ud805\udded\uda04\udd0c\udb13\ude16\u00a3\udb5a\uddd7\ud92d\ude93", "\u2115\u1056\u1c4d", "\uda18\udc69",
        40, -710, 811964621, -3256548751889297866L, -70013L, true, false, (char) 64050, (char) 6046,
        Double.longBitsToDouble(0x3f8dd39800000000L), Double.longBitsToDouble(0x3fd963600104d4f8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:928860886\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 5, 7, "\ud84a\udf36\udbee\udec8\udb13\ude16\udba4\udd1f\u0fb7\ud939\udd8d", "\u6d86\ua662\u7abb\u7f9a\u9ffd\u7ce9\ucf26\uac51\u3229\uab05\u90c6\u825b", "\ud9fe\udd92\ud805\ude52\uda4a\udecf\ud822\ude09\udb13\udd83\udb4f\udf3e\ud9ee\udfdc\ud94c\udefd\ud8fc\udde1\ud9e5\uddcb\ud891\ude69\ud84d\udea9\udac8\udc99\ud87d\udcf9",
        31, 94152, 928955006, 6716633912614996941L, 98529L, true, true, (char) 7973, (char) 18613,
        Double.longBitsToDouble(0x3fdeb730335363b2L), Double.longBitsToDouble(0x3fb6f46345b684e8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:-1265663983\0121=java.lang.Integer:-1265663983\012",
        Z.run(T, 2, 5, 5, 15, "\uda22\udc76\ud8ce\udf1e\ud800\uddf9\ud9ad\udec4", "\u69a3\ucc75\ua884", "\ud8cb\udd1e\ud9c4\udc78\uda18\udc69\uda0d\udcca\udaa2\ude22\udb83\ude93\ud887\udf80\uda47\udf52\uda7b\udf10\uda64\ude85\ud9c6\udcd1\udab0\udf79\uda4d\udeaa\udad0\udf72\uda33\ude15\uda3f\udd50\udbce\uddbe\udad4\udd46\udabb\udc21\udbd4\udc8d\uda32\ude1e\ud921\ude02\udaf2\udd21\udb62\udddc\ud938\ude21\ud9b3\ude5c\ud851\udc30\uda29\udc9d",
        53, 47587, -1265711569, -3167975726096506071L, 77089L, false, false, (char) 51772, (char) 13913,
        Double.longBitsToDouble(0x3fc973e5b6d80800L), Double.longBitsToDouble(0x3fd878d0f2d58ca4L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:6778622483381670377\0121=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 2, 17, 12, 7, "\ud805\udded\uda04\udd0c\udaf9\udcaf\ud9ad\udec4\ud819\udc07\ud9fc\udea2", "\u2d95\u2135\u0ca9\u0bfb\u0acc\u57c9\u5bf9\u1fb5\u3cff\u8c99\u1175\u9547\uc206\u7868\u2f67\u6be0\u29d3\u7e78\ud6cb\u86a5\u40b4\u37f9\ud317", "\ud928\udf9b\ucb6f\ud91f\udf61\ud9b3\ude5c\ud851\udc26\uda29\udd54\ud9a9\udfae\ud948\udc67\ud8d4\udedf\udad7\udc45\udb40\udd5f\ud9bb\ude48\udb26\udf05",
        47, 81672, -1624384120, 144226010284716391L, 95066L, true, false, (char) 25860, (char) 63458,
        Double.longBitsToDouble(0x3fea2938137a4ff6L), Double.longBitsToDouble(0x3fdd268756cec5daL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Long:-5645940503498709418\012",
        Z.run(T, 1, 17, 12, 7, "\uda50\udc40\uda04\udd0c\uda33\uddc7\udbd1\udcd5\ud819\udc07\ud9fc\udea2", "\u2d95\u2135\u0ca9\uadc1\u0b35\ub6e4\u9f4b\u1fb5\u3d37\u8c99\u1175", "\u9e1a\uda56\udc0e\uda77\udfc0\u1a0c\ud853\udfbf\udaf4\uddb4\udaa2\udc09\ud9ee\udfdc\ud9de\udf40\ud93e\udcc0",
        1, 89256, 972851223, -5645940503498709418L, -79003L, false, false, (char) 57932, (char) 45948,
        Double.longBitsToDouble(0x3fe17d2ce6ddb48eL), Double.longBitsToDouble(0x3fe94ea049989cf5L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 1, 12, 8, 5, "\ud805\udded\uda04\udd0c\udb13\ude16\ud92f\udca5\udaf5\udcda\ud920\udea4", "\u4a46", "\ud9a1\ude58\udbfe\udcea\uda18\udc69\udbf0\udddb\uda85\udd7d\ud85c\udfa7\ud887\udf80\uda5d\ude52\uda7b\udf10\udb8e\udddb\ud9c6\udcd1\udab0\udf0b\udb61\udef9\000\000\000\ud8f3\udc3d\ud9ee\udfdc\udb36\uddb1\udb00\udfc1\udbbe\udd5b\ud9fc\udd86\ud83a\udeb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda4f\udfe8",
        -5, -1000, -1343684608, -3167856862876589271L, -61464L, false, true, (char) 0, (char) 29031,
        Double.longBitsToDouble(0x3fd76ce643f41b2aL), Double.longBitsToDouble(0x3fee2f9516427398L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Long:-4385864652513458178\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 4, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u3e2d\u901b\u1448\ub5a4\u5e6f\u57c9\u5bf9\ua9c8\ubeb5\u907e\u6875\u9547\uc206\u7868\u911e\ub0b6", "\udb46\uddd1\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbf4\udfee",
        6, 28881, -1314550009, -4385864652513370441L, -87737L, false, true, (char) 45894, (char) 27595,
        Double.longBitsToDouble(0x3fe7327f4b29d409L), Double.longBitsToDouble(0x3fd989cf55829f24L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Long:-32407172490669119\012",
        Z.run(T, 1, 2, 4, 7, "\ud805\udded\ub902\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u3e2d\u901b\u1448\ub5a4\u5e82\u57c9\u5bf9\ua9c8\ubeb5\u907e\u6875\u9547\uc206\u7868\u911e\ub0b6", "\uda7d\udced\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbf4\udfee",
        32, 28881, -1314550009, 369367228087L, -87737L, false, true, (char) 45894, (char) 27595,
        Double.longBitsToDouble(0x3fe7327f4b29d409L), Double.longBitsToDouble(0x3fd989cf55829f24L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 1, 14, 5, "\u897f\uda04\udd71\u40c2\udbb7\udc9c\udb5a\ude93\uda6b\ude92\udbec\udf99\ud81e\udec1\udb4c\udd44", "\u00eb\u6b95\u57c9\u5bf9\ua5a2\u3229\u8f44\u9cd3\u9547\ud6ef\uc741\u4ae5\u2c03\u746a\u6108\u2f2f\u0a86\u43cb\ucfb2\ua856\u9a5b\uc5ea\u4313\u8229\ud271\u0f9a\u2467\u2d11", "\uda5e\udee4\udaf2\udc4e\udb1b\udd52\udaf2\udf04\ud904\udeaa",
        2, 96336, 174763102, 6267175722847094508L, 78121L, true, false, (char) 41885, (char) 44889,
        Double.longBitsToDouble(0x3fd3aa1f5dd7de36L), Double.longBitsToDouble(0x3fb1730781b098a8L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Long:-6671003405086034442\012",
        Z.run(T, 1, 1, 16, 1, "\u88f2\uda04\udd71\u40c2\udba4\udc9c\udb5a\ude93\ud9d1\udf24", "\u3e2d\u901b\u1448\ub5a4", "\uda0d\udcca\uda85\ude26\ud85c\udfa7\ud887\udf80\uda5d\ude52\udb91\ude3b",
        2, 71896, 510502613, -3335501702543017221L, -76462L, false, true, (char) 46221, (char) 48382,
        Double.longBitsToDouble(0x3feda3cf9e93cde9L), Double.longBitsToDouble(0x3fc50b5e1d661ea4L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Long:-753470871536615051\0121=java.lang.Long:-753470871536616959\012",
        Z.run(T, 2, 10, 7, 4, "\ud805\uddb9\uda04\udd0c\udadf\udebc\uda9a\ude0f\ud846\udffb", "\u297f\u1a07\u8b48\u70c3\ub519\u9770\u57c9\u5bf9\ua5a2\u3229\u1d51\uc745\u6a92", "\udab0\udf0b\ud923\udffa\udb4f\udd20\ud935\udecc\udb46\uddc2\ud8f3\udc9d\uda90\ude6e\udaa4\udd3a\ud90b\ude41\u0b23\ud9ef\udd90\ud83a\udeb7\udba6\ude68\uda0a\udf2f",
        44, 26337, 2112493536, -753470871536616005L, -954L, true, true, (char) 65165, (char) 49747,
        Double.longBitsToDouble(0x3fc74091e9e29300L), Double.longBitsToDouble(0x3fd8858d19973e1aL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new org.joda.time.field.FieldUtils:@?\0121=new org.joda.time.field.FieldUtils:@?\012",
        Z.run(T, 2, 15, 15, 7, "\udbfc\udd69\uda04\udd5e\udb13\ude16\udacb\uddaa\ud838\uddda\ud92d\ude93\ud97d\udd79\ud81c\udec0\udb4c\udd44\udb00\udf20\ud929\udd52\ud9a1\ude58\udbfe\udcea", "\ua5a2\u3229", "\uda7b\udf10\udbcd\ude89\uda6c\udf54\ud800\udf91\udb61\udf47\ud8a2\udd52\udbc7\ude19\udb24\udfbc\ud8ed\udde5\ud9ee\udfdc\ud910\udf5f\u16ca",
        -5, 37818, -1212099140, -1545994282609041756L, -56232L, true, true, (char) 27622, (char) 3875,
        Double.longBitsToDouble(0x3fd8b4a0a0001eb8L), Double.longBitsToDouble(0x3fd9b1c7849d451aL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Long:7729971413045208780\0121=java.lang.Long:7729971413045208780\012",
        Z.run(T, 2, 1, 1, 12, "\udbfc\udd69\uda04\udd5e\udb13\ude16\udacb\uddaa\ud838\uddda\ud92d\ude93\ud982\udc1a\ud998\udeb8\ud95f\udd2a\ud8e0\udc39\ud929\udd52\ud9a1\ude58\udbfe\udcea", "\ua5a2\u3229", "\uda7b\udf10\udbcd\ude89\uda6c\udf54\ud800\udf91\udb61\udf47\ud8a2\udd52\udbc7\ude19\udb24\udfbc\ud8ed\udde5\ud9ee\udfdc\ud910\udf5f\u16ca",
        -5, 37818, -1212099140, -1545994282609041756L, -56232L, true, true, (char) 64998, (char) 4030,
        Double.longBitsToDouble(0x3fd8b4a0a0001eb8L), Double.longBitsToDouble(0x3feb8aaf68c9cd02L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 3, 11, "\udbf4\udca8\udb79\udc19\udb23\ude45\udacb\uddaa\ud838\uddda\ud92d\ude93\ud97d\udd79\ud81c\udec0\udb4c\udd44\udb00\udf20\ud92c\udeeb\ud9a1\ude58\udbfe\udcea", "\ua5a2\u3229", "\uda7b\udf10\udbcd\ude89\uda6c\udf54\ud800\udf91\udb61\udf47\ud8a2\udd52\ud965\udee9\udb39\udc0f\ud8ed\udde5\ud9ee\udfdc\ud910\udf5f\uda8a\uddfa",
        -5, 37818, -1212099140, -1545994282609041756L, -56232L, true, false, (char) 41851, (char) 4030,
        Double.longBitsToDouble(0x3fd8b4a0a0001eb8L), Double.longBitsToDouble(0x3fd9b1c78193391aL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 3, 11, 13, "\udbfc\udd69\uda04\udd5e\udb13\ude16\udacb\uddaa\udab3\udc97\ud85a\udf08\ud97d\udd79\ud81c\udec0\udb4c\udd44\udb00\udf20\ud929\udd52\ud9a1\ude58\udbfe\udcea", "\ud685\u3229", "\uda7b\udf10\udbcd\ude89\uda6c\udf54\ud800\udf91\udb61\udf47\ud8a2\udd52\udbc9\udd19\udb24\udfbc\ud8ed\udde5\ud9ee\udfdc\ud910\udf5f\u16ca",
        10, 62418, -1212099140, -1545994282609041756L, -56232L, true, true, (char) 64998, (char) 4030,
        Double.longBitsToDouble(0x3fd8b4a0a0001eb8L), Double.longBitsToDouble(0x3fd9b1c78193391aL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:-1212061323\0121=java.lang.Integer:-1212061323\012",
        Z.run(T, 2, 5, 5, 7, "\udbfc\udd69\uda04\udd5e\udb13\ude16\udacb\uddaa\ud838\uddda\ud92d\ude93\udb17\ude69\udb89\udd5f\udab1\udf6a\udb00\udf20\ud929\udd52\ud9a1\ude58\udbfe\udcea", "\ua5a2\u3229", "\uda7b\udf10\udbcd\ude89\uda6c\udf54\uda8c\udf96\udb61\udf47\ud8a2\udd52\udbc7\ude19\uda5b\uded8\ud8d4\udd8e\ud8ad\udedd\ud865\udc3b\u16ca",
        -5, 37818, -1212099140, -1545994282609041756L, -56232L, true, true, (char) 64998, (char) 4030,
        Double.longBitsToDouble(0x3fd8b4a0a0001eb8L), Double.longBitsToDouble(0x3fd9b1c78193391aL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 3, 7, "\udbfc\udd69\uda04\udd5e\udb13\ude16\udacb\uddaa\ud838\uddda\ud92d\ude93\ud97d\udd79\ud81c\udec0\udb4c\udd44\udb00\udf20\ud929\udd52\ud9a1\ude58\udb0b\udeee", "\u3eac\u3231", "\uda7b\udf10\udbcd\ude89\uda6c\udf54\ud800\udf91",
        5, 52316, -439907256, -6386770153828793611L, 33330L, false, false, (char) 8272, (char) 15908,
        Double.longBitsToDouble(0x3fe52754594e184dL), Double.longBitsToDouble(0x3fda451436b2e5aeL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 8, 15, 7, "\ud805\uddab\ub8b5\000\udb98\udd4b\ud9d1\udf5e\u081e\000\000\ud913\udda8\ud8df\udeab\ud929\udd4b\ud9a1\ude58\udb9c\udeba\ud993\udffb\uda0d\udcca\uda85\ude26\ud85c\udfa7\ud887\udf80\000\uda7b\udf10\uda64\uddd5\ud947\udcf6\udab0\udf0b", "\u6151\u2f2f\u0a86", "\uda7c\udca1\uf615\udabf\udde1\ud9da\udd8e\ud850\udf01\ud8b2\udd7d\udb57\udf17\ud9a5\udf75\udb8b\udd2c\ud8a7\udcc6",
        57, 13265, 0, 0L, 80456L, true, true, (char) 55, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f39dd58c5367000L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Long:1130275715755856505\0121=java.lang.Long:1130275715755856505\012",
        Z.run(T, 2, 1, 17, 13, "\ud95e\ude25", "\u39cf\uad41\uc9ee\u116e\u297f\u16fa\ucb5c\u4216\ub5a4\ua1d0\uce54\u2db5\u890f", "\ud862\udc90\uda67\udd9c\ud8f6\uddde\ud9c6\udcd1\ud921\udf64\udb61\udef9\udad9\ude62\ud822\ude09\ud992\udef6\ud8c0\ude9d\ud9f0\udc3e\ud92a\udf22\ud93e\udc89\udaa1\udde4\ud8bd\ude43\ud9ee\udea6\ud8ee\udf1c",
        -1, 50198, -52690017, -1130275715755856505L, -78443L, true, true, (char) 38183, (char) 27694,
        Double.longBitsToDouble(0x3fca0668749e6ca8L), Double.longBitsToDouble(0x3fdc890ae49e198eL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Long:-56648\0121=java.lang.Integer:3\012",
        Z.run(T, 2, 10, 9, 10, "\ud805\uddae\uda04\udd0c\177\ud906\udc02\udbb3\udcd8\ud98b\udd5b\udaa8\udefa\uda1d\udd26\udad2\udec5", "\u75ed", "\udb10\udcd9",
        -3, 99216, 69, 0L, 56648L, true, false, (char) 29611, (char) 36337,
        Double.longBitsToDouble(0x3feac07e9735e9ccL), Double.longBitsToDouble(0x3fd6053a3b2c6deeL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:-979\0121=java.lang.Integer:-979\012",
        Z.run(T, 2, 6, 6, 6, "\ud990\udee4\000\000\udba4\udd1f\ud838\uddda\ud92d\ude93\u91e1\000\ud913\udda8\ud80f\udeb7\ud929\udd4b", "\u57c9", "",
        21, -1000, 0, 0L, -100000L, true, true, (char) 17551, (char) 4050,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Integer:850976442\0121=java.lang.Integer:850976442\012",
        Z.run(T, 2, 4, 4, 14, "\ud805\ude36\ud88c\udc26\ud81a\udd57\uda1e\udde2\ud838\uddda\ud875\udc96", "\u0c59\ubd60\u0504\ua991\ub5aa\ua51b\u2093\u13ee\u9d8f\u4149\u8745\u7580\u292e\u4022\u5bf9\uc5af", "\ud9fa\ude6d\ue480\udb9e\udd2e\u992a\ud87e\udebe\udb6c\udef5\udb7f\ude58",
        27, 91435, 851067849, -8685407459208505220L, 89436L, false, false, (char) 14222, (char) 29845,
        Double.longBitsToDouble(0x3fdee29a60b6a2c8L), Double.longBitsToDouble(0x3fc71123a551879cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:-34\0121=java.lang.Integer:-34\012",
        Z.run(T, 2, 9, 9, 9, "\ud805\udded\ud8c1\udc40\udafc\udf63\udba4\udd1f\ud838\uddda\udb20\udecd\ud844\udf35\ud81c\udef8\udb4c\udd44\ud80f\udeb7\ud835\uddb6", "\ub485\u220f\ua54a\u3229\u0319\u6868\uba9f\u4f8a\ucc0a\u545e\ub0c4\ua634\u6108\u997c\uacf9\u43cb\u4b0b\uc5cf\u9ab3", "\ud828\udf8d\ud931\ude22\ud89d\udcad\ud969\udd5a",
        34, 39729, -1298742458, 2504970408828289544L, 23256L, true, false, (char) 63304, (char) 14171,
        Double.longBitsToDouble(0x3fe8c5940645d51fL), Double.longBitsToDouble(0x3fd908eb6a3cc22aL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 6, 7, "\ud81b\udc81\udadc\uded9\udb18\udd67\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\u517c\u901b\u2568\u1833\u3047\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9f29\u5f5f\u7868\u7a3a\u97d6", "\udaa0\udefd\ud8f3\udcd5\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udaa0\udc25\udb6f\udd47\udb9a\udda6\udac5\udd67\ud91f\udf61\ud9b3\ude5c\ud851\udc30",
        42, -876, -835726123, 7393662137844827660L, 17392L, true, false, (char) 14282, (char) 19823,
        Double.longBitsToDouble(0x3fea5913776a2f11L), Double.longBitsToDouble(0x3fc4cee55a4c9948L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Long:-75827\012",
        Z.run(T, 1, 7, 11, 8, "\ud9d1\udf93\udaf4\udc44\udb4d\udd34\udaf1\udf74\udb5a\ude0b\ud92d\ude93", "\u7ff3\u4217\u0fee\ub5a4\u9ffd\ub281\u4b22\u0313\u747c\u2959\u497a\uc3d9\uc24b\u6db4\u5bf9\ub0c4", "\uda6d\udf81\ud8e0\udd3e\udbdb\udcdf\udb36\uddf1\ud93e\udcc0\uf693\uc100\ud84d\udf5e\ud86b\uddd5\udb69\uddcf\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16\ud952\udc67\uda5e\udf50\udaed\udce1\udb1b\udd52\udbd1\udde0\udb26\udf05\ud956\udf59\udbe3\udfb3\uda34\ude8e\ud894\udc28\uda43\ude7a\udbac\ude42\ud83d\udd19\u6d4c\u1ab8\udbb9\uded0",
        49, 4897, 12138962, 0L, -75827L, false, true, (char) 54932, (char) 34110,
        Double.longBitsToDouble(0x3fc8e3d6d1dfbd44L), Double.longBitsToDouble(0x3feca92125a633f9L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Integer:-274\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 9, "\ud805\udded\uda04\udd0c\uda8a\udf18\udba4\udc82\udb5a\ude93\ud8f3\udeb5\ud894\uddb2\uda62\udfad\ud8a6\udcbd\udad7\udc0e", "\u0e2e\ud7aa\u5bb4\uad2f\u3229\u304b\ucdb2\ua8e1\u7434\u92c7\u5bf9\uc4f5\u0bdb", "\udb62\udc48\ud9d8\udf7a\uda9f\udea7\uda1d\uddfe\udbb8\udeb5\ud906\udf99",
        52, -326, -379338877, 5998874325877954398L, 33012L, true, true, (char) 48176, (char) 47257,
        Double.longBitsToDouble(0x3feed1c325889ac6L), Double.longBitsToDouble(0x3fc1f0e390727a3cL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Long:6716633912614898301\0121=java.lang.Long:6716633912614898301\012",
        Z.run(T, 2, 10, 10, 0, "\ud84a\udf36\udbee\udec8\udb13\ude16\udb7c\udd08\ud93c\udf3c\ud939\udd8d", "\u5608\u9b1d\u17c9\u4124\u9eb2\u620d\u4e09\uac51\u3c3b\u9a82\u90c6\u825b", "\uda11\udedc\ufca5\ud950\udedc\ud918\ude7a\u4e01\udb95\udfdb\ud9ee\udfdc\ud94c\udefd\ud8fc\udde1\ud9e5\uddcb\ud891\ude69\ud84d\udea9\udac8\udc99\ud87d\udcf9",
        31, 94152, 928955006, 6716633912614996941L, 98640L, true, true, (char) 7973, (char) 18613,
        Double.longBitsToDouble(0x3fdeb730335363b2L), Double.longBitsToDouble(0x3fd5bd18d56da076L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 2, 17, 12, 7, "\ud805\udded\uda04\udd0c\udaf9\udcaf\ud9ad\udec4\ud819\udc07\ud9fc\udea2", "\u2d95v\000\u6cbd\u0acc\u57c9\u5bf9\u1fb5\u3cff*\000\ua1c6\uc206\u7868\u2f67\u6be0\u29d3\u7e78\ud6cb\u86a5\u40b4\u4d29\000", "\ud928\udf9b",
        16, -914, 0, 0L, -28611L, false, true, (char) 65165, (char) 49747,
        Double.longBitsToDouble(0x3fc74091e9e29300L), Double.longBitsToDouble(0x3fd8858d19973e5aL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Long:-74969764166627135\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 2, 8, 9, "\ud9b1\udf96\ub902\udb13\ude16\udba4\udd1f\udb5a\ude93\ud914\udfde", "\u43dc\u248f\u1462\u267d\u59d7\u43cc\u5bf9\ua9c8\ubeb5\u440c\u9370\u483f\ub9e0\u7868\u911e\ub0b6", "\uda7d\udced\ud8f3\udc9d\ud9ee\udfdc\udb36\uddb1\ud93e\udcc0\udbf4\udfee",
        32, 28881, -1314550009, 854482876855L, -87737L, false, true, (char) 45931, (char) 27595,
        Double.longBitsToDouble(0x3fe58d474e918936L), Double.longBitsToDouble(0x3feb543ab2e8dcb3L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 12, 14, 10, "\ud805\uddae\uda04\udd0c\177\ud906\udc02\udbb3\udcd8\ud98b\udd5b\udaa8\udefa\uda1d\udd26\ud90c\udfeb", "\u75ed\u876b\u652f", "\udb9b\udf6c",
        -1, -1000, 0, -792633533708264424L, -26438L, false, true, (char) 2858, (char) 8450,
        Double.longBitsToDouble(0x3fd6053a3b2c6deeL), Double.longBitsToDouble(0x3fcabf2a1e0ee32cL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Integer:-52\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 9, "\ud805\udded\uda04\udd0c\uda8a\udf18\udba4\udc82\udb5a\ude93\ud8f3\udeb5\ud894\uddb2\uda62\udfad\ud8a6\udcbd\udad7\udc0e", "\u0e2e\ud7aa\u5bb4\uad2f\u3229\u304b\ucdb2\ua8e1\u7434\u92c7\u5bf9\uc4f5\u0bdb", "\udb62\udc48\ud9d8\udf7a\uda9f\udea7\uda1d\uddfe\udbb8\udeb5\ud906\udf99",
        52, -326, -379338877, 5998874325877954398L, 33012L, true, true, (char) 54846, (char) 51421,
        Double.longBitsToDouble(0x3feed1c325889ac6L), Double.longBitsToDouble(0x3fc1f0e390727a3cL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Integer:2196402\012",
        Z.run(T, 1, 16, 14, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\udba4\udd1f\udb5a\ude93\ud92d\ude93", "\uadda\u901b\u1448\ub5a4\u9ffd\u57c9\u5bf9\ua5a2\u3229\u8c99\u6875\u9547\uc206\u7868\u5bf9\ub0c4", "\udb46\udcfb\ud8f3\udc9d\ud9ee\udfdc\ud8e9\udd2c\ud93e\udc8c\udbf4\udfee\ud9ef\udd90\ud83a\udeb7\udba6\ude68\ud91f\udf61\ud9b3\ude5c\ud851\udc30\uda29\udd54\uda4c\udc15\ud947\udfd2\uda5e\udee4\udaf2\udc4e\udb1b\udd52\ud9bb\ude48\udb26\udf05\ud956\udf59\udbe3\udfb3\ud989\udfd1\ud897\udce9\uda43\ude7a\ub8e5\ud83d\udd19\ud9dc\uddac\u1ab8\udbb9\uded0",
        29, 75738, 1659714002, 7228741836910937083L, 53127L, true, true, (char) 53468, (char) 64881,
        Double.longBitsToDouble(0x3fdaf019cf7cb8dcL), Double.longBitsToDouble(0x3fd7a8a749eaaf1eL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Long:5621833269380976266\0121=java.lang.Long:5621833269380976266\012",
        Z.run(T, 2, 17, 17, 7, "\ud805\udded\uda04\udd0c\udaf9\udcaf\ud9ad\udec4\ud819\udc07\ud9fc\udea2", "\u2d95\u2135\u0ca9\u0bfb\u0acc\u57c9\u5b9f\u1fb5\u3cff\u8c99\u1175\u09ef\u4dd2\u9226\u2f67\u6be0\u29d3\u7e78\ud6cb\u86a5\u40b4\u37f9\ud317", "\ud815\ude24\ucb6f\ud91f\udf61\ud9b3\ude5c\ud851\udc26\uda29\udd54\ud9a9\udfae\ud948\udc67\ud8d4\udedf\udad7\udc45\udb40\udd5f\ud9bb\ude48\udb26\udf05\ud956\udf59\ud9e5\udc75\ud8fb\udc85\ud897\udce9\uda43\ude7a\udbac\ude42",
        2, 71053, -1776713231, 2810916634690488133L, -19662L, true, true, (char) 16770, (char) 24636,
        Double.longBitsToDouble(0x3fdf4c732ed35ce0L), Double.longBitsToDouble(0x3fe64c0c90ce1f64L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 12, 12, 7, "\ud805\udded\uda04\udd0c\udaf9\udcaf\ud9ad\udec4\ud819\udc07\ud9fc\udea2", "\u2d95v\000\u3aaa\u30da\u2bf7\uaae8\u1fb5\u3cff*\000\ua1c6\uc206\u7868\u2f67\u6be0\u29d3\u7e78\ud6cb\u86a5\u40b4\u4d29\000", "\ud928\udf9b",
        16, -914, 398196736, 64424509440L, -28611L, false, true, (char) 65165, (char) 49747,
        Double.longBitsToDouble(0x3fc74091e9e29300L), Double.longBitsToDouble(0x3fd8858d19973e5aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 17, 17, 7, "\ud805\udded\ud95f\udc59\ud900\udd67\ud840\udca1", "\u69a3\ud3c5\u2d95", "\udbd3\udcd7\ud8af\udc74\udb58\udf0e\uda75\udfd3\uda0a\ude76\uda46\ude25\ud887\udf80\uda47\udf52\udb78\uddae\ud8d5\udd40\ud878\udd69\udaa5\ude79\uda4d\udeaa\ud8f1\udc5a\uda26\udff6\udbad\udc7d\udae6\udc8c\ud86e\udd12\uda56\ude69\ud892\udfc6\uda38\udf4f\ud8a1\udd66\ud815\ude24\ucb6f\ud91f\udf61\ud9b3\ude5c\ud851\udc26\uda29\udd54",
        0, 59531, 1334756911, -3167975723749942997L, 52968L, false, false, (char) 32897, (char) 43773,
        Double.longBitsToDouble(0x3fe07c7e21fa0d95L), Double.longBitsToDouble(0x3fe66aca51f1e313L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 11, 11, 8, "\ud9d1\udf93\udaf4\udc44\udb4d\udd34\udaf1\udf74\udb5a\ude0b\ud92d\ude93", "\u7ff3\u4217\u0fee\ub5a4\u9ffd\ub281\u4b22\u0313\u747c\u2959\u497a\uc3d9\uc24b\u6db4\u5bf9\ub0c4", "\uda6d\udf81\ud8e0\udd3e\udbdb\udcdf\udb36\uddf1\ud93e\udcc0\uf693\uc100\ud84d\udf5e\ud86b\uddd5\udb69\uddcf\ud9b3\ude5c\ud851\udc30\uda29\udd54\ud8c8\udf16\ud952\udc67\uda5e\udf50\udaed\udce1\udb1b\udd52\udbd1\udde0\udb26\udf05\ud956\udf59\udbe3\udfb3\uda34\ude8e\ud894\udc28\uda43\ude7a\udbac\ude42\ud83d\udd19\u6d4c\u1ab8\uda0b\udc79",
        2, 4897, 12138962, 0L, -75827L, false, true, (char) 54911, (char) 34110,
        Double.longBitsToDouble(0x3fc8e3d6d1dfbd44L), Double.longBitsToDouble(0x3feca92125a633f9L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 8, 8, 7, "\udbfc\udd69\u109f\udb13\udd97\000\ud838\uddda\ud92d\ude93\000\000\000\udac6\udcc3\ud929\udd52\ud853\uded1\udb96\udc0a", "", "\ud887\udf80\uda5d\ude1c\000\000\000\uda57\ude2b\udb61\udf47\ud8a2\udd52H\000\ud8b4\udf39\ud8ad\udedd\000\udbeb\udc55",
        27, 34490, 54716, 0L, -100000L, false, false, (char) 31390, (char) 1814,
        Double.longBitsToDouble(0x3f371c836bfde000L), Double.longBitsToDouble(0x3fc4baa0000172a0L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Long:-28611\0121=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 2, 7, 12, 7, "\ud805\udded\uda04\udd0c\udaf9\udcaf\ud9ad\udec4\ud819\udc07\ud9fc\udea2", "\u2d95v\000\u6cbd\u0acc\u57c9\u5bf9\u1fb5\u3cff*\000\ua1c6\uc206\u7868\u2cca\uca4e\u29d3\u7e78\ud6cb\u186d\uae03\u4fad\u807a", "\ud928\udf9b",
        16, -914, 0, 0L, -28611L, false, true, (char) 65165, (char) 49747,
        Double.longBitsToDouble(0x3fc74091e9e29300L), Double.longBitsToDouble(0x3fd8858d19973e5aL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 5, 12, 7, "\ud805\udded\uda04\udd0c\udb13\ude16\ud9ad\udec4\ud819\udc07\ud9fc\udea2", "\000\u20bf", "\ud8af\udcdd\uda18\udc69\uda0d\udcca\uda0a\ude76\udb83\ude93\ud887\udf80\ud9e9\udf43",
        10, -824, 0, 673447936L, -34554L, false, true, (char) 22156, (char) 3506,
        Double.longBitsToDouble(0x3fe49e6f4ca85af0L), Double.longBitsToDouble(0x3feacc3d4f073924L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 13, 13, 9, "\ud805\udded\u8c3d\uda88\udc9a\udba4\udc82\udb5a\ude93\ud8f3\udeb5\ud894\uddb2\uda62\udfad\ud97b\udea9\ud9ed\uddca", "\u3999\u61be\u5bb4", "\ud83b\ude1d\uda76\udf8f\ud9c2\udcca\ud852\udfc4\ud936\ude92\udab0\udf0b\ud96d\udeb8\ud936\uddad\uda4c\ude33{\uda67\udf31\ud91c\udc9a\uda9f\udea7\uda1d\uddfe\udbb8\udeb5\ud906\udf99",
        52, -326, 1461698435, 5998865903447086942L, 33012L, true, true, (char) 10288, (char) 54015,
        Double.longBitsToDouble(0x3feed1c325889ac6L), Double.longBitsToDouble(0x3fc1f0e390727a3cL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Long:-28611\0121=java.lang.Long:-28611\012",
        Z.run(T, 2, 7, 7, 7, "\ud805\udded\uda04\udd0c\udaf9\udcaf\udbc1\udd0e\udbff\uddac\ud9fc\udea2", "\u2d95v\000\u6cbd\u0acc\u57c9\u5bf9\u1fb5\u3cff*\000\u61f1\uce44\u7868\u2f67\u6be0\u29d3\u7e78\ud69f\u86a5\u40b4\u4d29\000", "\ud928\udf9b",
        55, -856, 0, 0L, -28611L, false, true, (char) 65165, (char) 49747,
        Double.longBitsToDouble(0x3fc74091e9e29300L), Double.longBitsToDouble(0x3fd8858d19973e5aL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 14, 14, 10, "\ud81d\udf3e\uda04\udd0c\uf3bf\ud906\udc02\udbb3\udcd8\ud98b\udd5b\ud864\udf77\udb6a\udfef\ud90c\udfeb", "\ua65e\u876b\u652f", "\udb9b\udf6c",
        -1, -1000, 1190766848, -792423869394697704L, -26409L, false, true, (char) 20445, (char) 8261,
        Double.longBitsToDouble(0x3fbe2012ecb1b010L), Double.longBitsToDouble(0x3fc1be2a17a9acf4L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Long:-1120897571673037043\0121=java.lang.Long:-1120897571673037043\012",
        Z.run(T, 2, 17, 1, 15, "\ud90d\udf11\ud9ee\uddad\udb6e\udf2c", "\ua601", "\udbf0\udf17\uda3d\udc6a\ud9f3\udd4a\ud8ff\udecc\uda43\udffc\udb5f\udd4f\uda3e\ude58\uda0a\ude76",
        1, 95706, -1538298058, -1120897571673037043L, -30650L, true, false, (char) 45699, (char) 15468,
        Double.longBitsToDouble(0x3fe0efb7bd29aa70L), Double.longBitsToDouble(0x3fe3c2c90443e202L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Long:-56648\0121=java.lang.Long:-56648\012",
        Z.run(T, 2, 10, 10, 10, "\ud805\uddae\udb07\uddce\ud84d\udf8b\ud93b\udea2\udbb3\udcd8\ud98b\udd5b\udaa8\udefa\uda1d\udd26\udad2\udec5", "\ub727", "\udb10\udcc3",
        -3, 99216, 69, 0L, 56648L, true, false, (char) 29611, (char) 36337,
        Double.longBitsToDouble(0x3feac07e976f22ccL), Double.longBitsToDouble(0x3fd6053a3b2d11eeL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.field.FieldUtils|safeMultiply|int,int|static",
    "M|org.joda.time.field.FieldUtils|safeMultiply|long,int|static",
    "M|org.joda.time.field.FieldUtils|safeMultiply|long,long|static",
    "M|org.joda.time.field.FieldUtils|equals|java.lang.Object,java.lang.Object|static",
    "M|org.joda.time.field.FieldUtils|getWrappedValue|int,int,int|static",
    "M|org.joda.time.field.FieldUtils|getWrappedValue|int,int,int,int|static",
    "M|org.joda.time.field.FieldUtils|safeAdd|int,int|static",
    "M|org.joda.time.field.FieldUtils|safeAdd|long,long|static",
    "M|org.joda.time.field.FieldUtils|safeMultiplyToInt|long,long|static",
    "M|org.joda.time.field.FieldUtils|safeNegate|int|static",
    "M|org.joda.time.field.FieldUtils|safeSubtract|long,long|static",
    "M|org.joda.time.field.FieldUtils|safeToInt|long|static",
    "M|org.joda.time.field.FieldUtils|verifyValueBounds|java.lang.String,int,int,int|static",
    "M|org.joda.time.field.FieldUtils|verifyValueBounds|org.joda.time.DateTimeField,int,int,int|static",
    "M|org.joda.time.field.FieldUtils|verifyValueBounds|org.joda.time.DateTimeFieldType,int,int,int|static",
    "C|org.joda.time.field.FieldUtils|<init>|",
    "M|org.joda.time.field.FieldUtils|safeMultiply|int,int|static",
    "M|org.joda.time.field.FieldUtils|safeMultiply|long,int|static",
    "M|org.joda.time.field.FieldUtils|safeMultiply|long,long|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
