package org.joda.time.chrono;
import org.junit.Test;
import static org.junit.Assert.*;
public class BasicMonthOfYearDateTimeField_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 13, 9, "\uda7b\udc48", "\ub6a8\ud0ec\uacca\ud7ce\ub594", "\ud959\udd14\uda35\udf42\ud870\udf6b\ud99f\udc11\ud81b\udfc0",
        13, 45426, -1198599, 4718268732168903889L, -65822L, false, false, (char) 21921, (char) 62972,
        Double.longBitsToDouble(0x3fc0492c7e4e7600L), Double.longBitsToDouble(0x3fe29dbd57b4bddfL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 13, 9, "\ud952\udc74\udaf3\udcaa\ud8e7\udca8\ud875\ude8e\ud866\ude60\ud9e4\udf6c\udbda\udeff\ud83d\udfc6\udaf5\udc73\udb45\udd85\ud959\udd14\uda35\udf42\ud870\udf6b\ud99f\udc11\ud81b\udfc0\ud82e\udfe7\udbe3\udf4b\udbab\uddf7\ud85c\udc62\ud93d\udea6\ud904\udd5d\ud80b\udec9\ud9c1\ude37\ud967\udf48\ud886\udf7c\udbfd\udeb3\udad0\udf4f\udae1\udd2e\ud9b3\udf20\u46a1\ud83c\udef1\ud912\udd70\ud8f3\udc0a\ud9fa\ude32\ud921\ude63\udb32\ude6f\uda49\udd70\udbc8\udc7a\u1a2a\ud9bd\udfd6\uc571\uda5d\udebd\ud9b8\ude3c\uda81\udfdd\uda2b\ude84\ud90e\udec2\uda52\udcfc\udb29\udcee", "\u3bba\u289c\u16c1\u33ff\ucdc6\u4cdd\u4827\u3eb9\ua0ce\u5941\u3955\u7614\ub6d8\u8ec5\ua5ff\u84c3\ua538\u9a24\ucbc5\u5c2c\u6380\u1f2a\u6be4\u00ab\u5099\u7a15\u2113", "\ud804\udda1\udb40\udecb\ud903\udda1\ud937\ude81\ud990\udc54\ud9cb\udf12\ud84e\udeb1\uda5d\ude89\uda8f\udf03\ud9b2\udca9\ud878\udc39\ud928\udf40\ud84a\udfc7",
        11, 76996, -358401838, 8508082343017468571L, 20441L, false, false, (char) 62084, (char) 13958,
        Double.longBitsToDouble(0x3fdf6c362fa6442aL), Double.longBitsToDouble(0x3fe3a4ccddf0c8b9L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 13, 6, "\udb11\udcc7\udb1d\udde6\ud89f\udc28\udba4\udc46\uda03\udfcf\uda0d\udf63", "\u0fae\u12c0\u19ea\u06cd\u2cbb\u0800", "\udbe3\udf4b\uda84\udd04\u274c\ud81e\udef9\udb34\udcf5\udb9d\udc53\udb70\udc09\ud8a4\udfc3\ud886\udf7c\udbfd\udeb3\udad0\udf92\ud870\udfbb\uda29\udd67\ud8ad\udc87\ud94f\udcf5",
        34, 21804, 615105826, -3472234916371317988L, -4179L, true, false, (char) 44193, (char) 47270,
        Double.longBitsToDouble(0x3fd4ab4fe94b82d2L), Double.longBitsToDouble(0x3fe676edcad437c7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 13, 9, "\udab4\udc08", "\ube88\ua416", "\ud83d\udfc6\udaf5\udc73",
        55, 34637, -1725278894, -8806680634914244798L, 12121L, false, false, (char) 56906, (char) 10730,
        Double.longBitsToDouble(0x3fd827a619e5c4d0L), Double.longBitsToDouble(0x3fee7c6e97297ed3L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 12, 7, "\udb73\udee5\ud8e7\udcd6\uda96\udfc7\ud846\udc2c\u825e\udb8a\udd10\ud9eb\udd3a\ud85e\udf83\ud801\udd79\ud89c\udcce\udab7\udfd9\uda35\udf12\ud870\udf6b", "\u4027\u08cb\u7111\u15ee\u5a0c", "\ud9c1\ude37\ud967\udf48\ud9fe\udfb8\u6cb4\ud91b\udd14\ud9b1\udfe0\ud902\udc0c\ud807\udfe7\uda3a\udcbf\ud887\udc1c\ud9b4\uddd7\uda67\udc74\ud980\udcad\ud82b\udf25\ud891\udf49\udbcc\udd76\ud8f2\udc18\udb6c\udfd4\ud9e6\udc5b\udafa\ude4b\udad7\udffb\ud8cd\udd02\udbc5\udebe\udaff\udfe6\ud94c\udd1c\ud92d\ude73\udb57\udfa5\uda3b\uddb8\udabb\udd1c\udad9\udc15\udb6a\udc71\udaba\udf1b\udb6e\udeff\udbf7\udd74\ud863\udd41\ud8c1\udeaf\ud9f6\uded7",
        9, 73589, -1100546867, 8053181905055452800L, 70673L, false, true, (char) 48808, (char) 44926,
        Double.longBitsToDouble(0x3fdd92b0f277ecb2L), Double.longBitsToDouble(0x3feae9c14b77574eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 15, 9, "\uda7b\udc48", "\ub65b\ud0ec\uacca\ud7ce\ub594", "\ud96d\udd1e\uda35\udf42\ud870\udf6b\ud99f\udc11\ud81b\udfc0",
        13, 45426, -1198599, 4718268732168903889L, -65822L, false, false, (char) 21921, (char) 7164,
        Double.longBitsToDouble(0x3fd9c29c0fd68420L), Double.longBitsToDouble(0x3fe29dbd57b4bddfL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 13, 9, "\uda7b\udc48", "\ub6a8\ud0ec\uacca\ud7ce\ub594", "\ud959\udd14\uda35\udf42\ud870\udf6b\ud99f\udc11\ud81b\udfc0",
        13, 45426, -1198599, 4718268732168903889L, -65822L, false, false, (char) 21921, (char) 28246,
        Double.longBitsToDouble(0x3fed54886df9bde4L), Double.longBitsToDouble(0x3fe29e3f1fb4bddfL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|add|org.joda.time.ReadablePartial,int,[I,int|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|add|long,int|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|add|long,long|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|addWrapField|long,int|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|get|long|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|getDifferenceAsLong|long,long|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|getLeapAmount|long|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|getLeapDurationField||new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|getMaximumValue||new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|getMinimumValue||new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|getRangeDurationField||new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|isLeap|long|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|isLenient||new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|readResolve||new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|remainder|long|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|roundFloor|long|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|add|org.joda.time.ReadablePartial,int,[I,int|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|add|long,int|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
    "M|org.joda.time.chrono.BasicMonthOfYearDateTimeField|add|long,long|new:org.joda.time.chrono.BasicMonthOfYearDateTimeField:org.joda.time.chrono.BasicChronology,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
