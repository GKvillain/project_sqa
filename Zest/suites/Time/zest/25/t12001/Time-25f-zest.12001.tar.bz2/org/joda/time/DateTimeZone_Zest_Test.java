package org.joda.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateTimeZone_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Long:-1238408481425293421 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 60276, 1060855292, -1238408481453671421L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Long:-6027656031267483572 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 3, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud9bb\udf76\ubdb3\ud85a\udcd2\ud926\udc96\ud90b\ude82\ud8b6\ude1a\ud9e8\uded3\udba1\uddf7\ud883\udc63\ud89a\udc4c\udac6\udec4", "\u3c06\u472c\u9218\u6155\u1beb\u23f1", "\udb65\udf22\uf6d5\u4039\udacc\uddf7\udb63\udeb1\udb7a\udd2f\u56fa",
        20, 95190, -982075815, -6027656031295861572L, 90571L, false, true, (char) 24694, (char) 37785,
        Double.longBitsToDouble(0x3fe7225dde2ed12cL), Double.longBitsToDouble(0x3fb242648331d780L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Long:-1238408481425293421 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\udbef\udfec\ud9be\udf55",
        58, 60276, 1060855292, -1238408481453671421L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Long:-1289355452209922157 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\udace\udce1\udb92\udccc\ud9df\udd1c\ud90b\udf31\ud8ba\udc7c\ud9e2\ude08\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        22, 60276, 1060855292, -1289355452238300157L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fe42e2bb4014fcdL), Double.longBitsToDouble(0x3fec8e4e4795d39fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Long:1782222803272100093 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb1b\udf1f\udb89\udc71\udbb2\ude0d\ud95d\udd47\ud986\uddde\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\u5dd3\u1898\ua5ad", "\ud9e8\uddd7\ud981\udd55\udb0c\ude6b\udb65\udf22\uf6d5\udbcc\uddb5\udacc\udd08\ud91b\ude60\udb86\udf33\udb46\udd86\u6cef\ud9f6\ude29\udb86\udee5\udbfa\udfd8\uda2f\udf62\udb4d\uddb6",
        29, 28283, 747530301, 1782222803246900093L, -92300L, true, true, (char) 19210, (char) 17092,
        Double.longBitsToDouble(0x3fe6f674e02cc210L), Double.longBitsToDouble(0x3fba7eac1480aba8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 6, 6, "\ud88a\udc73\udb89\udc71\udb52\udf05\udbc5\uddbf\ud8f8\ude23\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud971\udc60\uda89\ude84\ud8d8\uddf2\udbfb\ude43\udae5\udfe5\uda7c\udf96\udb20\udd28\ud87b\ude6c\ud8af\udee8\uda3d\ude58", "\u5670\uaf01\u50ed\u5dad\u3f5a\ua43e\ucf64", "\udb86\udee5\udbfa\udfd8\uda2f\udf62\udb4d\uddb6\ud84e\ude39\ud9c4\udc89",
        28, 12509, 36962537, -531493363728728317L, -95172L, false, true, (char) 10419, (char) 36411,
        Double.longBitsToDouble(0x3feb1d0a223764dcL), Double.longBitsToDouble(0x3fe6b9b84d59f1adL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Long:4556338784665390988 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\ud8a3\udc4c\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\uda94\udce8", "\uca45\u4710\u8818", "\udb37\udc75\udb12\udf5f",
        38, 69748, -950752724, 4556338784640190988L, 57277L, true, true, (char) 26058, (char) 38092,
        Double.longBitsToDouble(0x3fe2cbc910c7c576L), Double.longBitsToDouble(0x3fc7958b20a694e8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 4, 9, 10, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud81e\ude6e\u9323\ud8b2\udced\uda4d\udd55\udb5d\udee5\udba3\uddbb\ud8d8\uddf2\udad1\udeed\udae5\udf3d\ud898\ude62\ud9b1\ude14\ud9d9\udc85", "\u833d\u139e\u50a3\u3dec\u72f7\u61b0\ub834", "\u6cef\udac6\ude31\ua957\udbfa\udfd8\uda2f\udf62\udb4d\uddb6\udbc9\ude15\udb14\udfd8\ud9e9\udf08",
        58, 83052, -865426259, 2683831544276188646L, -30520L, true, true, (char) 53014, (char) 60686,
        Double.longBitsToDouble(0x3fbbabb94565bdc0L), Double.longBitsToDouble(0x3fe18f58e4b26c96L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Long:3776791824214881143 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\000", "\ubbf1\u0b1a\u0606\u488e\ud355\u5541\u5b31", "\udb5d\udee5",
        21, 99178, 584635616, 3776791824189681143L, -97341L, false, true, (char) 13282, (char) 68,
        Double.longBitsToDouble(0x3e2449d9e0000000L), Double.longBitsToDouble(0x3fe166deedfcc754L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Long:1860068062202429842 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb4d\uddee\udb72\udd10\udad5\ude23\ud932\ude65\ubdb3\uda61\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb1c\udf18\uda57\ude01\uda4d\udd12\udb5d\udee5\udba2\udd10", "\u3962\u732a\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        43, 60276, 1060855292, 1860068062177229842L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:-28378000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 6, 5, "\ud88a\udc73\udb89\udc77\udb70\ude12\ud95d\udd47\ubdb3\udb85\uddd9\ud9df\udd1c\udace\ude32\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\uda47\udc62", "\u08a8\ud0a9\u0281", "\uda3d\ude58\udb4d\udefb\udb0c\ude6b",
        5, 39338, 1060855292, -1238408481453671421L, -66675L, true, false, (char) 50382, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f27164L), Double.longBitsToDouble(0x3fd75f33af2bad58L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Long:6181344979703016412 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 10, "\ud88a\udc73\udb89\udc71\udb70\ude12\udacd\udd3d\ud9c0\udffa\ud894\udc3d\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb64\udc43\udaf2\udce0\ud9b5\ude69\u5a74\ud9a8\udf39\ud8a7\udc29\udad1\udeed\udae5\udf3d\uda7c\udf96\udb20\udd28\ud89c\udd6c\ud917\udee7\uda3d\ude58\ud981\udd55\udb0c\ude59", "\u50ed\u5dad\ub390\u7ecc\u6954\u2b73\u1298\u48f8\u84bf\ub126\uc6f7\u845b\u72a2\ud685\u4e2a\u910d\u2f76\ud037\ucd5c\u9359\u2844\u30d5\u91f3\uaaf5\u0511\u4650\ub345\u37a5\ua7a4\u74e1\u53d0\uc911\u160c", "\ud8bb\udf4f",
        15, 51100, 1659185398, 6181344979677816412L, 83457L, false, true, (char) 48988, (char) 57297,
        Double.longBitsToDouble(0x3f46d1d11516b000L), Double.longBitsToDouble(0x3fb68ed4154929d8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Long:2939504806682095667 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 9, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 60276, 1060855292, 2939504806653295667L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Long:8328827927046385632 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\udb36\udf48\ud8bd\udc73\ud9b6\udd4e\ud9f7\udf30\u38f3\uda4d\udd55\udb5d\udee5\ud872\udd18", "\uca45\u4710\u2f6f", "\uda3d\ude58\ud981\udd55\udb0c\ude6b\uda22\udc9f\uf6d5\ud874\udc5a\ud8f9\udde7\ud91b\ude60\udb86\udf33\udb46\udd86\u6cef\ud889\uddfa\ud959\udd30\udb52\udfd0",
        35, 59705, -2063657067, 8328827927021185632L, -92184L, true, true, (char) 25181, (char) 45035,
        Double.longBitsToDouble(0x3fe6bbe678e69c7cL), Double.longBitsToDouble(0x3fd87eca5bd176aeL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Long:4472560056014343224 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud8d0\udc76", "\u5c60\ua183\u0606\u488e\ud355\u5541\u5b31\u1240\u1167\u7559", "\udad1\udeed\udae5\udf3d\uda7c\udf96\udb20\udd28",
        2, 1146, 105184762, 4472560055985543224L, -70404L, false, true, (char) 35143, (char) 27348,
        Double.longBitsToDouble(0x3fe2e940fdd3ca5eL), Double.longBitsToDouble(0x3fe5bdb89985e1c6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:5054014475361204428 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 11, "\ud88a\udc73\udb89\udc71\ud822\udd8b\ud95d\udce7\ud931\udd8c\uda70\udd80\udac6\udd20\ud91d\udd8b\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\ud8d7\udfa5", "\uca45\u4710\u8818\u6155\ucb9e\u3568\u833d\u139e\u5670\uaf01\u50ed\u5dad\ub390\u7ecc\ucf64\u92e4\u1298", "\uda2f\udf62\udb4d\uddb6\udbc1\uddd1\ud9a0\udf06\uda57\ude99",
        27, 27624, 2129273611, 5054014475332404428L, -79134L, false, true, (char) 35390, (char) 21028,
        Double.longBitsToDouble(0x3fea5f48da4277bdL), Double.longBitsToDouble(0x3fef6ba528c99c24L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Long:2411422053252819317 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 0, 6, "\udb11\udcf5\udbbb\udcbf\udb97\udc1d", "\u0606\u488e\ud355\u5541\u5b31\ud4b9\ubf62\u54ea\u0884\u2bc5\u062d", "\udb20\udd28\ud89c\udd6c\ud917\udee7\ud8ad\udccf\udbc2\udc38\uaf1c\udb65\udf22\uf6d5\udbcc\uddb5\udbe4\udc34\ud91b\ude8a\udb86\udf33\udb46\udd86\u6cef\ud9f6\ude29\ud9a6\udff5",
        34, 88460, -696334295, 2411422053224019317L, 55999L, true, true, (char) 47915, (char) 17511,
        Double.longBitsToDouble(0x3fe29288278562b1L), Double.longBitsToDouble(0x3feed42126f036c3L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Long:6489353650114318844 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ubbaf\ud8da\udd00\uda8e\udf01\ud969\udf2c\ud8cb\ude5d\udb58\udf11\ud9df\udca5\udb38\uddb4\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\udbfe\udc58\ud900\udc0f\udb9a\udf84", "\u4187\u1aa1\u2f8f", "\uda04\udd58",
        22, 328, 172594262, 6489353650085518844L, -37929L, false, false, (char) 18606, (char) 29130,
        Double.longBitsToDouble(0x3fd81ea20cb2f244L), Double.longBitsToDouble(0x3fc8e00ec73a3e50L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:8357313229289104635 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\uda4f\ude17\udb89\udc0f\udb70\ude12\ud95d\udd47\ud8a5\uddad\ud8a1\udc68\ud9df\udd1c\ud83d\udc4a\ud8b6\uddfa\uda8f\udcbb\ud8f7\udf2e\u9bc2\udb52\udf96\udba2\udd10\ud8d8\uddf2\udb37\udc3b\udae5\udf3d\uda7c\udf96\udb20\udd28\ud89c\udd6c\ud917\udee7\udb78\udc95\ud889\ude7a\uda0a\udca9\udaaa\udc06\udb14\ude8e", "\ub390\u7ecc\ucf64\ub6e4\u1298\u68f8\u35d1\ub126\uc6f7\u6c83\u6b46\u07fa\u55ff\u56e4\u05d5\ua18a", "\ud891\udf95\udb10\udeb6\udb91\udd99\udb90\udc6e\ud8a3\udffb\ud85c\ude94\udb83\udd33\udad6\udc79\udb4a\udc04\udb77\udee1\udafc\uded6\udaa6\uddc5\uda9b\udef6\uda56\udfb2\ud968\ude23\ud85a\udc4e\uda0b\udcfc\ud85f\udf1c\udaac\ude71\ud815\ude7f\ud8de\udd36\udaad\udff9\uda94\udc7f\uda2e\udc24\ud9a8\udda2\ufb43\uff65\uda69\udd71\uda6f\udc78\udbbb\udfda\ud885\udd27\uda92\ude3b\u46f5\ud875\udd66\udbce\udc78",
        41, 58507, -1919372710, 8357313229263904635L, -20507L, false, true, (char) 27623, (char) 55420,
        Double.longBitsToDouble(0x3fea4f228e1b2015L), Double.longBitsToDouble(0x3fd60f421812beb6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\udb46\udc2d\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 60276, 1060855292, -1238408481453671421L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:6977696760430697746 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\uda99\udff9\ud888\udcb7\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\udb0b\udcfb\ud9fb\udfaa\udae5\udf3d\uda7c\udf96\ud8ff\ude18", "\u3568\u833d\u139e\u5670\uaf01\u50ed\u5dad\ubda2\u126d\u241d\uac05\ud5d9\u48f8\u35a2\ub126\uc6f7\u2cc8", "\ud8a7\udcc7\udb17\udc4c\ud9a8\udd2f\udbe1\uddd4\ud941\uddac\udb28\udc63\u26ea",
        32, 54219, 1634323123, 6977696760459497746L, 99561L, true, true, (char) 56608, (char) 58670,
        Double.longBitsToDouble(0x3fdfc2ad68d68286L), Double.longBitsToDouble(0x3fe3fcf4ec0d5cc3L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Long:2607237381529365219 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 12, "\ud958\udd3d\uda1c\uddbb\ud869\ude2f\ud95d\udd47\ubd8f\ud8a1\udc68\ud9df\udd1c\ud880\udeca\ud856\ude60\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb06\udff9\ud8b9\ude1c", "\uca45\u273c\u8818\ubd2f\u3b62\ub7b7\u833d\u7bbd\u464e\u0adf\u50ed\u5dad\u48bc\u7eac\ub2c2\ucabb\u47ae\u48f8\u990c\ub126\uc6f7", "\ud999\udf32\ud877\udd1e\udac3\udd23\ud929\udd68\ud93a\udf3a",
        43, 82334, -1351552928, 2607237381504165219L, -52179L, false, false, (char) 8547, (char) 35526,
        Double.longBitsToDouble(0x3fe3554911739ce1L), Double.longBitsToDouble(0x3fedebfcb901f6d6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.joda.time.tz.ZoneInfoProvider:@?\012",
        Z.run(T, 1, 15, 6, 6, "\ud8bc\udc47\ud892\udf9f\udb70\ude12\ud95d\udd47\ud969\udd0e\ud8a1\udd0b\ud9df\udd1c\ud9a4\udc1e\ud94d\udfe2\udb8e\udcd6\ud8e8\udfe4\uda4d\udd79\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 70260, 1060855292, -1238385391709488125L, -66675L, true, false, (char) 58035, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 13, 3, 7, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud8ca\uddde\ud817\udd1d\ud8a1\udc68\ud9df\udd1c\ud8fb\udc02\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55", "\ucb28", "\uda7c\udf96\udb20\udd28\ud89c\udd6c\ud917\udee7\uda3d\ude58\ud981\udd55\udb0c\ude6b\ud9fe\udc89\uf71a\udbcc\uddb5\udacc\udd08\ud91b\ude60",
        25, 53627, -507072841, 8728735865166542425L, -4956L, true, false, (char) 60947, (char) 46566,
        Double.longBitsToDouble(0x3fea4f8f78aa7ce8L), Double.longBitsToDouble(0x3fbcd6fc02c262f0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 6, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\uda83\udee2\udbe9\udfa3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 32116, 1060855292, -1238408481453671421L, 87193L, true, true, (char) 27984, (char) 60947,
        Double.longBitsToDouble(0x3fe5adcec7d14a6dL), Double.longBitsToDouble(0x3fe547e0c3d6dfe7L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Long:8642818080886489293 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\uda79\ude22\uda4d\udd55\udb5d\udee5\udba2\udd10", "\u7e45\u4642\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 15659, 1052075030, 8642818080857689293L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Long:4502776834565283256 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73", "\u9ed6\u0b1a\u0606\u488e\ud355\u5541\u5b31\u1240\u1167\u7559", "\udad1\udeed\udae5\udf3d\uda7c\udf96\udb20\udd28",
        2, 1146, 105184762, 4502776834540083256L, -81044L, true, false, (char) 36476, (char) 18482,
        Double.longBitsToDouble(0x3fe5bdb89b06e1c6L), Double.longBitsToDouble(0x3fe2cbc910c7c576L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Long:4156334712891642902 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb41\uddc2\ud842\udc38\udb70\ude12\ud95d\udd47\udbe4\udeed\ud8a1\udc91\ud9f0\udf1c\ud90b\udf31\ud8b6\ude5b\ud9aa\uddd2\ud83d\ude24\u2554\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818\u6155\ucb9e\u3568\u833d\u139e\u5670\u57b2\u50ed\u5dad\ub390\u7ecc\ucf64\u92e4\u1298\u48f8\u35a2", "\ud997\udf1c\ud93b\uddff\ud8ff\udf3d\ud8e8\udc2e\udb84\udf3b\ud9f6\udea3\ud991\uddb4\udbd1\udcea\udadd\udc6c\ud884\udece\udbc1\ude6a\ud8e1\udee0",
        30, 42071, 1349670026, 4156334712862842902L, -62970L, true, false, (char) 46856, (char) 25271,
        Double.longBitsToDouble(0x3f6d04fdf0504000L), Double.longBitsToDouble(0x3fe9f699670e1887L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Long:8590809532548952024 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 4, 6, "\ud88a\udc73\ud853\udd35\ud9e0\udd18\udbb8\udd13\ubdb3\ud886\udc98\ud9df\udd1c\ud94d\udee9\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udae3\udde5", "\uca3c\u461f\u8818\ubf00\ucb9e\u3568\u833d\u139e\u4e0a\u1aaf\u34ab\u4d16\ub390\u7ecc", "\udb5b\udf0e\udb30\udcef\uc77d\uda2f\udf62\udb4d\uddb6\ud95e\udde1\udbb4\udfc0\ud949\udc1e\udbd5\udc3c\ud842\udc6f\ud858\udce0\uda56\ude1c\udb88\ude98\ud9a1\udf30",
        1, 26032, -1952110654, 8590809532523752024L, 83743L, true, true, (char) 27142, (char) 14150,
        Double.longBitsToDouble(0x3fd0cf0827e66258L), Double.longBitsToDouble(0x3fdd7aaf11f9f13cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:-1238408481425293421 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 4, 2, 13, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\udac5\uddef\ud8f6\udeb2\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\udbb5\udeb6\udb5d\udee5\udba2\udd10", "\u4a87\u4710\u7fcc", "\ud823\ude0b\ud981\udce3\udb0c\ude6b",
        52, 64555, 1060855292, -1238408481453671421L, -66675L, true, true, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fcecc2ed2f2b218L), Double.longBitsToDouble(0x3fe706b1d224657aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Long:2891165837250910813 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc9c\udb89\udc71\ud913\udd2b\uda82\udf66\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\uf2db\u2089\uda4d\udd55\udb5d\udee5\udba2\udc20", "\uca45\u4710\u8e84", "\uda37\udd81\ud981\udd55\udb0c\ude6b\udb65\udf22",
        -4, 51292, -288339444, 2891165837222110813L, -13655L, false, true, (char) 12155, (char) 9790,
        Double.longBitsToDouble(0x3fc7958b20a694e8L), Double.longBitsToDouble(0x3fecaeb3f10de577L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.039\012",
        Z.run(T, 1, 9, 4, 0, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud998\ude71\uda89\udfd9\udb5d\udf22\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        39, 60326, 1060855292, -1238408481453671421L, -66675L, true, false, (char) 38092, (char) 12923,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 10, 3, 6, "\uda0b\udf54\udb89\udcb5\u748a\uda24\udcaf\ud88e\udc17\ud8a1\udc68\ud9df\udceb\ud90b\udf31\ud90f\udc07\ud9e2\udd6e\ud83d\ude24\uda4d\udd55\udb5d\udee5\ud901\udfff", "\uca45\u4710\u8818", "\udaec\uddb0\ud879\udd47\udb0c\ude6b",
        58, 60276, 1060855292, -1238408481453671421L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d395d67e0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Long:-1238408481425293421 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud91c\udd27\ud853\udfc8\u2642\udab0\udcc7\ud964\udf20\ud9c5\ude7b\udb43\udc85\ud9b1\udf8d\ud8a2\ude49\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8677", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        31, 60276, 1060855292, -1238408481453671421L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8e4aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d17b619d0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Long:7478671797763848307 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c", "\u5b31\u1240\u1167\u7559\u3bf7\ucb28\u062d\u85ef\ucb70\u8818\u6155\ucb9e\u3568\u833d\u139e\u5670", "\udacc\udd08\ud91b\ude60\ud915\udd34\udb46\udd86\ud88b\udc86\ud9f3\udef2\udb86\udee5\udbfa\udfd8\uda2f\udf62\udb79\udcdd\udbce\udddc\udb8c\uddac\ud8d7\udd3a\udba7\udf97\ud890\udcac\ud88d\udfd5\ud849\uddee",
        37, 98889, -12650454, 7478671797735048307L, -41099L, true, true, (char) 63917, (char) 39840,
        Double.longBitsToDouble(0x3fe28c680287e21bL), Double.longBitsToDouble(0x3fee4af725c622a8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.018\0121=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 9, 0, 4, "\ud88a\udc73", "\u9ed6\u0b1a", "\ud90b\udf40\ud8b6\ude5b\ud9e2\uddce\ud8c2\udd48\udbd2\udf3b\udbb3\udd75",
        18, 99178, 433640690, 3776792580103925239L, -97341L, false, true, (char) 34018, (char) 51350,
        Double.longBitsToDouble(0x3fd3c3e1858c34eeL), Double.longBitsToDouble(0x3fb2ea9d8971b8e0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.joda.time.tz.DefaultNameProvider:@?\012",
        Z.run(T, 1, 14, 6, 6, "\ud88a\udc73\udabf\udf8d\ud81b\uddbb\ud8e2\udda6\ud8de\udef2\ud982\udf8a\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud86e\udedd\uda7d\udc3a\ud8a7\udd30\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 60276, 1060855292, -1238408481453671421L, -67937L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fdc7063af2bacfcL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Long:4310026259085781087 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 60276, 1060855292, 4310026259056981087L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 6, "\ud88a\udc73\udb89\udc71\udae8\udd4e\udb41\ude46\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31", "\u1240\u1167\u530c\u1f8d\uaab5\uadfe\uca45\u4710\ua4bf\u466c\u5e18\u0a0e\u28c2\u1406\u5670\uaf01\u5038\u5dad\u3bed\u8a32\ucf64", "\udb86\udee5",
        51, 91482, -696334295, -1383883704499496975L, -48821L, true, false, (char) 5702, (char) 42030,
        Double.longBitsToDouble(0x3fc5adc1fb1177b0L), Double.longBitsToDouble(0x3fc00444c8b16254L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Long:225939771448709073 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\udb2b\udc77\ud9e2\uddfd\ud83d\ude24\uda4d\udd55\ud96a\udf26\udba2\udd10", "\uca45\u66f5\u8818", "\uda3d\ude58\ud981\udd55\ud88e\ude6c\udb65\udf22\uf6d5\udb78\udc4b\udacc\udd08\ud91b\ude60",
        25, 53627, -507072841, 225939771423509073L, -4956L, true, false, (char) 18311, (char) 3863,
        Double.longBitsToDouble(0x3fed6c23e4ff70dcL), Double.longBitsToDouble(0x3f9966e31242c2a0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 12, 11, 3, "\uda1f\udec2\udb59\udea1\udb70\ude12\udbc5\udf7c\uda2d\udfa6\ud980\udfe3\udb78\udcaa\uda66\udc0e\ud8d4\uddba\ud9e2\uddce\udae2\udfd7\uda24\udc73\ud9ec\udde8\udba2\udd10", "\uca45\u4710\u18fa\u6391\ucb9e\u3568", "\udb65\udf22\uda3d\udc27\udbcc\uddb5\ud8e0\udcfe\uda92\uddab\udbe2\uddb5\ud9fc\udc91\u6c98\udb74\udee9\udb86\udee5\udbe2\udc2a\uda39\udd9b\udb4d\uddb6",
        47, 87789, 807566195, 2342969993288063285L, 57578L, false, false, (char) 25464, (char) 53599,
        Double.longBitsToDouble(0x3fe74ff371e5c639L), Double.longBitsToDouble(0x3fefb258ca85ae91L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Long:44473046345483648 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud85f\udcee\ufe69\ud984\udf04\ud9c4\udffb\u8f72\ud8a1\udc68\ud9df\udd1c\u00e2\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "", "\udb20\udd28\ud89c\udd6c",
        -5, -1000, 1161472, 44473046320283648L, -66208L, true, false, (char) 0, (char) 26058,
        Double.longBitsToDouble(0x3fe8370e30000000L), Double.longBitsToDouble(0x3e42f2b164000000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Long:-1597119348429485277 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 6, 2, "\ud88a\udc73\udb89\udc71", "\u0b1a\u0606\u3e83\ud355\u5541\u5b31\u3914\u4ba8\u7559\u3bf7\ucb28\u062d\u7b45\u06c8\u8818\u6155\ua37e\u3568\ub6e8\uaa15\u5670\uaf01\u50ed\u5dad\ub390\u8047\ucec6\u6cda\u1351\u48f8\u35a2\ub126\uc6f7\u09f7\ua416\u0c80\uc886\u4719\ub729\u8b45\u4554\u407f\u766b\uba11", "\ud90f\udf98\ud88b\udc47\ud876\udcd4\uda4c\ude88\ud9cc\udc06\ud8d9\udddc\u64d4",
        41, 65258, 1096826130, -1597119348401107277L, 60458L, false, false, (char) 14036, (char) 47255,
        Double.longBitsToDouble(0x3fec23964eebe4b7L), Double.longBitsToDouble(0x3fd5e3b851a8d5baL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:-1238408481425293421 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\udbe2\udcea\udb0b\udf2a\ud98b\udc2d\udadc\udf0a\uda9d\udd98\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\ud863\udfc0\ud9d5\udd99\udb8e\udeac", "\uca45\u330f\u8818", "\uda3d\ude58\ud985\udd55\ud9df\udf34",
        58, 60276, 557538812, -1238408481453671421L, -47040L, true, false, (char) 38100, (char) 2820,
        Double.longBitsToDouble(0x3fc8f181e306b164L), Double.longBitsToDouble(0x3fa4d2ff732e07e0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+16:00\012",
        Z.run(T, 1, 7, 6, 6, "\ud874\udc66\udb89\udc71\udb70\ude12\ud95d\udd47", "\u488e\ud355\u5541\u5b31\u1240\u1167\ud2da\uc5bf\uaac2\u062d", "\udb20\udd28\ud89c\udd6c",
        16, 42762, 1041349037, -7089061397755223740L, -58524L, false, false, (char) 27348, (char) 36476,
        Double.longBitsToDouble(0x3fd62f85ed6f6e26L), Double.longBitsToDouble(0x3fe83709a6597922L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 10, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\ud9d6\ude3f", "\uca45\u8465\u3400", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 60276, 1060861948, -1277622563658302461L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8ed0ed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Long:8294361264197940591 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 7, 7, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10\ud8d8\uddf2\udad1\udeed\udae5\udf3d", "\u6155\ucb9e\u3568\u833d\u139e\u5670\uaf01\u50ed\u5dad\ub390\u7ecc\ucf64\ud45f\u1298\u48f8\u35a2\ub126\uc6f7\ud454", "\ue793",
        1, 87496, -395510422, 8294361264169140591L, 7734L, true, true, (char) 20583, (char) 22317,
        Double.longBitsToDouble(0x3fbda0be65e29798L), Double.longBitsToDouble(0x3fd7fef9e04cac1aL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.util.TreeSet:[Africa/Abidjan, Africa/Accra, Africa/Addis_Ababa, Africa/Algiers, Africa/Asmara, Africa/Asmera, Africa/Bamako, Africa/Bangui, Africa/Banjul, Africa/Bissau, Africa/Blantyre, Africa/Brazzaville, Africa/Bujumbura, Africa/Cairo, Africa/Casablanca, Africa/Ceuta, Africa/Conakry, Africa/Dakar, Africa/Dar_...\012",
        Z.run(T, 1, 11, 15, 12, "\ud88a\udc73\udb6f\udc19\ud8e4\udf9a\udb82\ude75\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\uda4b\udcdc\uda38\udc11\udb5d\udee5\udaab\udca8\ud8d8\udd45\udacf\udc7a\udae5\udf3d\uda7c\udf96\udb20\udd28\ud964\udfe7\ud905\udeb5\ud8bf\ude59\udb85\udc38\udaf6\uddec\udb65\udf22\uf6d5", "\ub390\u1d2b\ucf64\u92e4\u1298\u48f8\u35a2\u0927\uc6f7\u14a2\u687c\u6a9d\u0b6d\u44ab\u8c66\u578e", "\uda99\udc96\ud98b\ude1b\ud8ac\udff0\ud80b\udec8\ud976\udf26\ud801\udcba\udb74\udde3\udbab\udcf5\udbfe\udea6\ube2e\ud952\ude02\uba81\ud992\udc9d\ud9c1\udc56\ud9dc\udedf\ud9f3\udc44\udaaa\udf7a\udbfe\udf5f\udba8\udf78\uda35\ude89\uda82\ude44\udab0\ude49\uda42\udd0c\udbd5\udc8a\ud8d5\ude28\uadab",
        -5, 96576, -1234681909, 6923522143203627199L, 43755L, false, false, (char) 39523, (char) 11127,
        Double.longBitsToDouble(0x3fea634ce55394a6L), Double.longBitsToDouble(0x3fae41c01b70da80L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Long:689849187012008393 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 3, 6, "\ud87d\udfe3\udb89\udc71\udb70\ude12\ud9bb\udf76\ubdb3\ud85a\udcd2\ud926\udc96\ud955\udd67", "\u8a7f\u2428\u25f0\ucb19\u8695\u92c2\u3c06\u472c\u9218\u6155\ubdfc\u1af2\u82a4\u139e\u5670\uaf01\uc21b\u5e9c\u5c55\u25ac\uab49", "\udb86\udee5\u01d9\uda93\udd54\udb4d\uddb6\udbd8\udd9e\udbc7\ude65",
        43, 96035, -785623324, 689849186986808393L, 17240L, true, true, (char) 56738, (char) 10950,
        Double.longBitsToDouble(0x3fd0b2b913629fceL), Double.longBitsToDouble(0x3fcf104a1595f3a8L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Long:1466333748994492072 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 3, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud9bb\udf76\udb6a\udf4b\udaa8\ude0f\ud937\udf76\ud90b\ude82\udad4\udf17\ubedb\udbd5\udeea\ud883\udc63\ud89a\udc4c\udac6\udec4", "\u3c06\u472c\u9218\u6155\u1beb\u23f1", "\udb65\udf22\uf6d5\u4039\udacc\uddf7\udadf\udc0e\udb7b\udffb\udbfc\udedb",
        40, 95389, -982075815, 1466333748969292072L, -43285L, false, false, (char) 50005, (char) 37549,
        Double.longBitsToDouble(0x3fe7225dde2ed12cL), Double.longBitsToDouble(0x3fb24264bb31d780L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.joda.time.tz.DateTimeZoneBuilder$PrecalculatedZone:Asia/Bangkok\012",
        Z.run(T, 1, 10, 6, 11, "\ud88a\udc73\udb89\udc71\udb4e\ude87\ud9bb\udf76\ubdb3\ud85a\udcd2\ud926\udc96\ud90b\ude82\udae7\ude63\ud9e8\uded3\udba1\uddf7\uda80\udf00\ud8cd\udf4b\udaf9\udc76", "\u3c06\u9ee0\ua3b9\ub951\u2533\u23f1", "\udb65\udfb5\uf6d5\u4039\udacc\uddf7\ud87a\udcbc\udb7a\udd2f\u56fa\u7a65\udbdf\udd0e\udb86\udee5\u01d9\ud990\udc92\udb4d\uddb6\udbd8\udd9e\ud844\udc24\ud933\ude28\uda55\uded7\ud871\ude31\ud967\udd8d\ud875\udf15\udac8\udefc\ud8f9\udf39\ud8fb\ude63\ud829\ude4f\udb20\udd3d\udbdf\udef0\ud95c\udfce\udbef\ude03\ud98e\ude8a\udbf5\udd25\ud857\udd40\ud82a\udeac\ud994\udf6f\ud9ba\uddae\ud96b\udc70\ud825\udfee\udab1\udefd\udad8\udcb9\udaad\udc43\ud8fd\udc86",
        52, 21301, -1929517914, 9069802831057579084L, 82824L, false, true, (char) 20949, (char) 38384,
        Double.longBitsToDouble(0x3fe4f8f7a3873f47L), Double.longBitsToDouble(0x3fadda0fb0cff930L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Long:5513105350229084119 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 3, 6, "\ud88e\udee1\udb89\udc71\udb70\ude12\ud9bb\udf76\ubdb3\ud85a\udcd2\ud926\udc96\ud90b\ude82", "\u8a7f\u2450\u25f0\ucb19\u2396\u92c2\u6367\u472c\u9218\u6155\u1beb\u23f1\u3131\u139e\u5670\uaf01\uc21b\u5e27\u5c55\u4cc8\u0c1a", "\udb86\udec3\u01d9\uda93\udd54\udb4d\uddb6\udbd8\udd9e\udbf1\udd3a\ud942\ude50\udabc\udf84\uba9d",
        35, 70513, -511854490, 5513105350203884119L, 54617L, true, false, (char) 2639, (char) 65467,
        Double.longBitsToDouble(0x3fe153f474c1fcb7L), Double.longBitsToDouble(0x3fdf983b69dee248L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Long:5121077745222087452 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 10, 3, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud9bb\udf76\ubdb3\ud85a\udcd2\ud928\udf96\ud90b\ude82", "\ua75d\u55cc", "\udb6c\udda7\ud9e9\udd63\udb9e\udcfe\uda22\ude2f\ud81f\ude77",
        2, 79322, -802487134, 5121077745196887452L, 44473L, false, true, (char) 18240, (char) 38092,
        Double.longBitsToDouble(0x3fe2cbc9132bc576L), Double.longBitsToDouble(0x3fcfc4b740a60978L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:-6027656031328237268 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 13, 3, 15, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud9bb\udf76\ubdb3\ud85a\udcd2\ud926\udc96\ud90b\ude82\ud8b6\ude1a\udb6e\udecd\udba1\uddf7\ud883\udc63\ud89a\udc4c\udac6\udec4", "\u3c06\u472c\u9218\u6155\u1beb\u23f1", "\udb65\udf22\uf6d5\u4039\udacc\uddf7\ub396\ua08e\u5622",
        20, 73094, -979595664, -6027656031299859268L, 90571L, false, true, (char) 24694, (char) 37785,
        Double.longBitsToDouble(0x3fe7225dde2ed12cL), Double.longBitsToDouble(0x3fb242648331d7d8L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Long:8721528082892897967 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b8\ude25\uda8b\udfc1\ud9ed\udfa3\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\udb91\udebd\ud9be\udf55\udb65\udf22\uf6d5\udbcc\uddb5\udacc\udd08\uda0b\udeee\udba6\udde3\udb5e\udf9c\udb38\ude3c\udae4\udd12\udb86\udee5",
        45, 88460, -696334295, 8721528082867697967L, -61125L, false, true, (char) 1918, (char) 5484,
        Double.longBitsToDouble(0x3fde9b9a4a3c55beL), Double.longBitsToDouble(0x3fe8de0f9834d8cdL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.007\012",
        Z.run(T, 1, 9, 6, 6, "\ud88a\udc73\udb89\udc71\uda5c\ude08\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\u3b36\u4710\u8818", "\ud968\ude75\udbef\udfc3\ud9be\udf55",
        7, 79061, -562582021, -1238487144196965373L, -14758L, true, false, (char) 46653, (char) 14613,
        Double.longBitsToDouble(0x3fd29a526f2b3d10L), Double.longBitsToDouble(0x3fee8cdd8f45854cL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Long:3217924947825281370 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud893\ude0e\udb89\udc71\ud8fe\udfb9\udbb6\udf5f\ud9da\udd45\udb92\udca4\ud9df\udd1c\ud90b\udf31\uda03\udfa2\ud9e2\ude08\ud83d\ude24\ud934\uddc6\udb7f\udf60\udba2\udd10", "\uca45\u5e4a\u14e1\ucfea\uc49c\u8210\u07d6\uc6f4\u8ac1\ucf30\u50ed\uc4d6\ub390\uad61\ucedc\u92e4\u1298\u654d\u9efc\u553a\ubaf2\u48ca\u3753\ub154\u6125\u649c\u47aa\ua628\u4dff\uccfd\u4f24\u9db6\u622f\u02ec\u737f\u737d\u9d94\u8132\ubdaa", "\ud969\udcbd",
        6, 91327, 950012458, 3217924947800081370L, -8951L, false, false, (char) 61805, (char) 50317,
        Double.longBitsToDouble(0x3f976c1b24892780L), Double.longBitsToDouble(0x3fd302bce23263c4L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+16:00\0121=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 7, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95a\udc47\udace\udce1\udb92\udccc\udb2d\udca3\ud8fb\udc61\ud8ba\udc7c\ud9e2\ude08\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        16, 60276, 1060855292, -1289355452238300157L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fe42e2bb4014fcdL), Double.longBitsToDouble(0x3fec8e4e4795d39fL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Long:3456003931259018796 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 6, 6, "\ud8c5\uddde\udb79\udce1\udac7\uddd8\udbce\udc9a", "\u488e\ud355\u4884", "\uda7e\ude4c\ud8d1\udfa1\udb49\uddaf\ud902\udf97\udaa7\ude29\udae5\udf3d\uda37\udc14\uda4f\udcfa\ud89c\udd6c\ud990\udc1a",
        2, 38075, -1650550728, 3456003931230218796L, -8878L, false, false, (char) 4924, (char) 18482,
        Double.longBitsToDouble(0x3fe5bdb89b357335L), Double.longBitsToDouble(0x3fe24b95da850176L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+05:30\012",
        Z.run(T, 1, 10, 13, 6, "\ud88a\udc73\udb89\udc71\uda79\udfb8\ud8d1\udd8c\udace\udd58\udb92\udccc\ud9df\udd1c\ud90b\udf31\ud8ba\udc7c\ud9e2\ude08\ud9cc\udf8b\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818\u6155\ucb9e", "\uda7c\udcd8\uda51\udc17\uf6d5\udbcc\uddb5\ue0fe\ud91b\ude60\udb86\udf33\u008f",
        19, 95190, -1148078503, 5732999560713225217L, -23320L, false, true, (char) 9147, (char) 3108,
        Double.longBitsToDouble(0x3fc07a12f60cfcf8L), Double.longBitsToDouble(0x3fc6f96f04ef2f44L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Long:7808791352340470867 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud8db\udfc2\udb89\udcdf\uda3a\uddd1\ud86a\uddba\ud986\ude08\udb13\udca0\udb4d\udd74\udb91\ude55\udb00\udc6b\udaf6\udcf4\ud83d\ude24\uda4d\udd55\udb5d\udee5\udaa8\udcad", "\u492b\u0e33\u3481\u4b6f", "\ud981\udd55\udb0c\ude6b\udb65\udf22\uf6d5",
        37, 82372, 673152003, 7808791352315270867L, -14758L, true, false, (char) 9790, (char) 11541,
        Double.longBitsToDouble(0x3fa4d29d795d67e0L), Double.longBitsToDouble(0x3fefdddba83d4090L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Long:1854280397310028029 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\uda53\udffb\udb56\uddc5\udbb2\ude0d\udb2f\udcf1\ud9c5\udf5a\udbd5\ude8a\ud831\udcd8\ud8ef\udced\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud823\udc9a\udba2\udd10", "\u5dd3\u1898\ua5ad", "\ud9e8\uddd7\ud981\udd55\udb0c\ude6b\udb65\udf22\uf6d5\udbcc\uddb5\udacc\udd08\ud91b\ude60\udb86\udf33\udb46\udd86\u6cef\ud9f6\ude29\udb86\udee5\udbfa\udfd8\uda2f\udf62\udb4d\uddb6",
        -1, 66947, 295304443, 1854280397284828029L, -92300L, false, true, (char) 19291, (char) 17092,
        Double.longBitsToDouble(0x3fe6f674e02cc210L), Double.longBitsToDouble(0x3fe34fd58290d652L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 6, 6, "\ud88a\udc73\udb89\udc71\uda31\udc4e\udbc5\uddbf\ud8f8\ude23\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud8db\udeeb\uda35\udcdb\ud931\udf83\ud971\udc6f\uda89\ude84\ud8d8\uddf2\udbfb\ude43\udae5\udfe5\uda7c\udf96\udb20\udd28\ud87b\ude6c\ud8af\udee8\uda3d\ude58", "\u5670\uaf01\u50ed\u5dad\u3f5a\ua43e\ucf64", "\udb86\udee5\udbfa\udfd8\uda2f\udf62\udb4d\uddb6\ud84e\ude39\ud9c4\udc89",
        28, 12509, 36962537, -531493363728728317L, -95172L, false, true, (char) 10419, (char) 36411,
        Double.longBitsToDouble(0x3feb1d0a223764dcL), Double.longBitsToDouble(0x3fe6b9b84d59f1adL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Long:4301603638726771435 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\ud8a3\udc4c", "\u0b1a\u0606\u488e\ud355\u4db4\u5b31\u1240\u1167\u7559\u11b2\u15b6\u062d\uca45\u4710\u8818\u9a0d\u2b9a\u06e5\ub2f0\u13d1\u5670\u0fef\u6055\u5dad\ub390\u7ecc\ucf64\u92e4\u1298\u48f8\u35a2\ub126\u9a9c\u0c40\u1d5e\u1e96\ub587\u8b20\u58b8\ub0eb\uaece\u7b60\uc3d4\u7590", "\udbf7\ude70\ud9c7\udc77\udb03\udcfb\uda83\ude20\ub1f5\ud8c0\udc10\uda07\udc8c\udaf3\udde4\udb66\ude3a\ud83e\udc38",
        1, 24092, 853233099, 4301603638697971435L, -88788L, false, true, (char) 54518, (char) 9195,
        Double.longBitsToDouble(0x3fe2286dbfe87606L), Double.longBitsToDouble(0x3fe65dd551c5b74bL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Long:3573544907871504404 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud876\udc73\ud8a3\udc4c\udb70\ude12\ud95d\udd47\u99ab\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8f0\ude58\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\uda94\udce8", "\ucfe6\u4710\u8818", "\udace\udf03\udbbe\udf88\uda0a\udfba\udb65\udf22\uf6d5\udbcc\uddb5\udacc\udd08\udb8d\udcb9\ud9f6\udd82\ud83a\udc74\u07a0\udbef\udee7",
        36, 66335, -1522889540, 3573544907842704404L, 98340L, true, false, (char) 60189, (char) 16277,
        Double.longBitsToDouble(0x3fdb4a76f59ef2d8L), Double.longBitsToDouble(0x3fd631dfcc1b645eL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Long:-6540760769708438599 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb19\ude5c\ud8a3\udcb2\udb70\ude12\ud95d\udd47\udb41\udcba\ud8a1\udd11\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\u9cba\ud8a3\udc34\udb5d\udee5\uda94\udce8", "\uca45\u4710\u8818", "\udb37\udc75\udb12\udf5f\udb0c\ude9e\udb65\udf22\uf6d5\udbcc\uddb5\udacc\udd08\ud91b\ude60\udb86\udf33\udb46\udd86\u6cef",
        15, 47185, -1403428665, -6540760769736816599L, 61225L, false, true, (char) 27153, (char) 10449,
        Double.longBitsToDouble(0x3fe46cbbaea98a8cL), Double.longBitsToDouble(0x3fd22aa2e8b3ba42L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Long:4545749975844663624 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 6, 6, "\ud88a\udc9c\ud8a3\udc4c\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\ud8ea\udf62\udb5d\udee5\uda94\udce8", "\uca94\u4710\u8818", "\udb3b\udc4e\udb12\udf87\udb0c\ude9e\udb65\udf22\ud89e\udceb\ud8a0\uddbf\udacc\udd08\ud91b\ude60",
        25, 53627, -507072841, 4545749975869863624L, -70492L, true, false, (char) 55413, (char) 60048,
        Double.longBitsToDouble(0x3fe4f6f548073c73L), Double.longBitsToDouble(0x3fc1311b06af1dc4L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-00:00:00.002\012",
        Z.run(T, 1, 9, 2, 0, "\ud88a\udc69\ud8a3\udc4c\ud86e\ude11\ud95d\udd47\ucfb3\ud8a7\udc6b\ud9ae\udfe6\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb36\udeb5\ud9e1\udec3\ud8ab\udc80\udad1\udeed\udae5\udf3d", "\ubfae\ucb9e\u077b\ub2f0\u13d1\u5670\uaf01\u5027\u5dad\ub3b9\u183f\u5c6f\ua12a\u1298\u48f8\u99db\ub10f\u0c8f\u82de", "\ud8ae\ude42\ud854\udc79\udad4\udc6f\ud8c9\ude56\ud88a\ude05\udaba\udc7f\udb73\udff5\udb18\uddea\uda26\udc3f\ud884\uddb2\ud866\ude11",
        -2, 74498, -91296844, 985144268656365990L, -79445L, false, true, (char) 2222, (char) 39554,
        Double.longBitsToDouble(0x3fd956cb568f78e8L), Double.longBitsToDouble(0x3fe7735b177a74a2L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Long:4575479083081715596 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 10, 6, "\ud88a\udc73\ud8a3\udc4c\udb70\ude12\ud95d\udd47\ud942\udf00\ud8a1\udc68\ud9df\udd1c\ud887\udf32\udbd2\udfec\ud86e\udef3\ud928\udd4a\uda4d\udd55\udb5d\udee5\uda94\udce8", "\uca45\u4710\u8818", "\udb37\udc75\udb12\udf5f",
        38, 69748, -950752724, 4575479083056515596L, 57277L, true, true, (char) 26058, (char) 38092,
        Double.longBitsToDouble(0x3fe2cbc910c7c576L), Double.longBitsToDouble(0x3fc7958b20a694e8L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Long:2891165837717072861 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\ud8a3\udc4c\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\ud9bf\udc0d\udb47\ude84\udba3\udc90", "\uca45\u4710", "\ud917\udee7\udb37\udc75\udb12\udf5f\udb0c\ude9e\udbcb\udf15",
        -4, 51292, -288339444, 2891165837691872861L, -83522L, false, false, (char) 64262, (char) 65010,
        Double.longBitsToDouble(0x3fe5e562c829a5e3L), Double.longBitsToDouble(0x3fd6ec582023f96aL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-00:00:00.004\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 8, 6, "\u009b\udb27\uddf8\ud9e7\udfab\ud95d\udd3e\ubdc3\ud8a1\udc68\ud9df\udd1c\u7995\ud8ef\ude6c\ud830\udf21\uda7d\uddf9\udb80\udce0\udb1f\udeef\udbed\udd31", "\u48b0\u0b0f\ud1af\u3be8", "\udb39\udd31\udb1e\udff6\ud8d0\udc02",
        -4, 49244, -1638741466, 1774816096104540631L, -91087L, false, false, (char) 18723, (char) 63947,
        Double.longBitsToDouble(0x3fad525a6f4338f0L), Double.longBitsToDouble(0x3fe1229532544cd1L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Long:3776791820901249911 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:3776791820901249911 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 1, 6, "\000", "\ubbf1\u0b1a\u0606\u488e\ud355\u5541\u5b31", "\ud968\udf72",
        31, 99178, 584635616, 3776791820876049911L, -34982L, false, false, (char) 38911, (char) 16098,
        Double.longBitsToDouble(0x3fe166deedfcc754L), Double.longBitsToDouble(0x3fe0e50b24bccfb7L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=org.joda.time.tz.ZoneInfoProvider:@?\0121=org.joda.time.tz.DefaultNameProvider:@?\012",
        Z.run(T, 2, 15, 14, 6, "\uac00\ufdff\udb70\ude12\ubbf1\ubdb3\ud8a1\udc68", "\u3e38\u0a2a\uc3d2\u6491\u753f\u3bf7\ucb28\u062d\uca45\u4710\u875e", "\u19f2\udb30\udf1d\udb0c\ude33",
        58, 60276, -1414636036, 8153875763290382273L, 688L, false, true, (char) 36852, (char) 4918,
        Double.longBitsToDouble(0x3f99d9bbdb2bcae0L), Double.longBitsToDouble(0x3fe3c46fd0c79b48L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 1, 10, 6, 6, "\000", "\ubbf1\u0b1a\u0606\u48a0\uaf16\u4f0d\u5b31\u00f3\u1cbe\u7559\u3bf7\ucb28\u062d\uca45\ud31b\u875e\u6155\ucb9e\ua64b\000\u765c\u24e8\uaf01\u808f", "\ud8fa\udf5b\uda8f\udd88\udab2\udc8c\ue33e\ud886\udf41\ud99a\udf64\ud987\udc81\udac8\udc6d\udbb8\ude0e\ud8ff\udc2c\ub5bb\u163e\uda8a\udde4\udbe1\ude4d\ud907\udc07\udaec\uddce\udbe0\udd33\udac5\uded1\ud8fd\udc73\ua1da\ud8f9\udeb7\ud9eb\udc75\ud91d\uddaf\ud88d\udfd6\udbb6\udc32\udac7\udc97\ud842\udf11\ud808\udc45\ud886\ude18\udaa9\udda7\udadd\udcfd\udae3\udd8c\udac7\ude8e\ud8c6\udf9e\ud85b\udef3\ud94a\udd71\uda0f\udf48\uda0d\udda8\udbe5\udc3b\udaa2\udfbd\udb84\udcce\uda22\udf9a\ud885\ude4c\uda27\udf86\udb68\udfef\uda69\udcf8\uda77\udea2\ud9b6\udce8\ud978\ude5e\ud874\udf09\udb6a\udc6d\udaa3\udefd\udb08\ude91\udb07\udcaf\ud889\udfca\ud8fd\udfa1\udbac\udf4a\ud829\udcf3\ud9b2\udcdc\ud988\udc05\udbaf\ude1d\ud803\udcdc\ud88a\ude33\ud990\udc58\uda86\udc26\udae8\udd1c\udbde\udeb6\uda27\udca9\uda6a\udff1\ud94f\udea1\u8e77\udb31\udf34\udb11\udf70\ud8d0\udcdc\udba1\udc42\ud95a\udcc0\udbdd\udf7e\ud86f\ude2a\ud827\udfe3\uda76\ude8e\udbe3\uded9\ud9ca\udfcc",
        22, 50888, -1626271972, -7791753671812678639L, -38250L, false, false, (char) 55004, (char) 42786,
        Double.longBitsToDouble(0x3feacb3704ecc95dL), Double.longBitsToDouble(0x3fe9cf7c9e387a0eL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 11, 5, "\uda20\udd0c\ud9b5\udcd0\uda7f\udf9a\ud932\ude65\ubdb3\ud81f\uddf8\ud9df\udcc9\ud90b\udf31\ud91a\udeac\uda10\udf57\udb26\udee3\uda4d\udd12\udb5d\udee5\udba2\udd10\ud8d8\uddf2\ud9db\ude46\udae0\udd96\uda1d\udfca\udb20\udd28\ud89c\udd6c\ud8ed\udce7\ud893\ude63\u82e1\udaff\udd60\udb65\udf95", "\u57d2\ub39f\u7ecc\ua821\u29fa\uc85b\u48f8\u35a2\ub126\u94ed\ucf66\u7d92\u2801\uc194\u2d35", "\udbd9\udee5\ud884\udf25\udafb\ude22\udb4b\udc7d\udaff\ude98\udbbc\udd88\ud9fe\udcf2\udb5b\ude23\udb5b\udcc6\uda8d\udee2\ud969\udd9f\ud993\udc3c\ud972\udec2\u1eed\ud86a\udd22\ud824\udd73\ud8c6\udd99\udb0b\udfb3\uda49\udd46\uda67\ude1e\uda25\udf1f\ud862\ude90\uda40\udee2\ud9b3\udf81\uda56\ude59",
        0, 23737, 1092755048, -7429233618926768415L, 56049L, false, false, (char) 34582, (char) 25368,
        Double.longBitsToDouble(0x3fd9fb01cfe14ab4L), Double.longBitsToDouble(0x3fe1d0fdf4fc4ac3L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Long:1860068517992656914 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb4d\uddee\udb72\udd10\udad5\ude23\ud932\ude65\ubdb3\uda61\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb1c\udf18\uda57\ude01\uda4d\udd12\udb5d\udee5\udba2\udd10", "\u3962\u732a\u8818", "\uda3d\ude58\ud981\udd55\uc6be",
        8, 32483, -1096270172, 1860068517963856914L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fe14d29d77a4253L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Long:3434046698171071378 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 4, 6, "\udaf4\udd89\ud8ba\udf23\udad5\ude23\ud932\ude65\ubdb3\uda61\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb1c\udf18\uda57\ude01\uda4d\udd12\udb5d\udee5\udba2\udd10", "\u3962\u732a\u8818\u6155\ucb9e\u3568\u833d\u139e\u56e3\uaf01\u50ed\u28a4\ub39f\u7ecc", "\ud9f6\ude29\ud983\udfe2\udbfa\udfd8\uda2f\udf62\udb4d\uddb6\udb47\ude94\ud898\udf6f\ud8bb\udcc3\ud8de\udeb3\ud9f2\ude69\ud91d\udf38\ud8e6\udf01\ud838\udfe9\udaf5\udc22",
        3, 96063, 1879775463, 3434046698142271378L, -48038L, false, false, (char) 41116, (char) 27560,
        Double.longBitsToDouble(0x3fc840b3e5505dd8L), Double.longBitsToDouble(0x3fe2f838a7addccdL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Long:1860068659202883986 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb4d\uddee\udb72\udd10\udad5\ude23\ud932\ude65\ud8f3\udfc5\uda61\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb1c\udf18\uda57\ude01\uda4d\udd12\udb5d\udee5\ud91d\ude3a", "\u3962\u732a\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        29, 60276, 1060855292, 1860068659177683986L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 2, 6, "\udb4d\uddee\udb72\udd10", "\u0b1a\u460e\u3d4a\u37eb\u92eb\u6d99\u1774\u5e62", "\ud8d8\uddf2",
        1, -889, 577052072, -3138996005031710166L, -98214L, true, false, (char) 7508, (char) 16213,
        Double.longBitsToDouble(0x3fe166deedfcc754L), Double.longBitsToDouble(0x3fe061f9dc1219d0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 6, 5, "\ud88a\udc73\udb89\udc77\udb70\ude12\ud95d\udd47\ubdb3\udb85\uddd9\ud9df\udd1c\udace\ude32\ud8b6\ude5b\ud9e2\uddce\uda09\udfca\ud8a0\udfbd\udb5d\udee5\uda47\udc62", "\u08a8\ud0a9\u0281", "\uda3d\ude58\udb4d\udefb\udb0c\ude6b",
        5, 39338, 1060855292, 2942358180353841132L, -66675L, true, false, (char) 50352, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f27164L), Double.longBitsToDouble(0x3fd75f33afc3ad58L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Long:558370948480 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 10, "\uab85\ufdff\udb70\ude12\udacd\udd3d\ud9c0\udffa\ud894\udc3d\000\ud8e0\ude4f\ud8b6\ude5b\000\udaf2\udce0\ud9b5\ude69\u5a74\ud9a8\udf39\ud8a7\udc29\udad1\udeed\udae5\udf3d\uda7c\udf96\udb20\udd28\ud89c\udd6c\u00ba\000\ud952\udfa8\udb0c\ude59", "\u50ed\u5dad\ub390\u7ecc\u6954\u2b73\ub306\000\u23f8\ub126\uc6f7\u845b\u72a2\u1e3a\u4e2a\u910d\u2f76\ud037\u1566\u9359\u2844\u30d5\u91f3\uaaf5\u0511\u4650\ub345\u37a5\ua7a4\u74e1\u53d0\uc911\u160c", "\ud8bb\udf4f",
        15, 51100, 1659185398, 558345748480L, -100000L, false, true, (char) 48988, (char) 57297,
        Double.longBitsToDouble(0x3f46d1d11516b000L), Double.longBitsToDouble(0x3fb68ed4154929d8L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Long:4274149439788300378 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:4274149439845900378 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\udb70\ude12\udacd\udd3d\ud9c0\udffa\ud894\udc3d\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb64\udc43\udaf2\udce0\ud9b5\ude69\ud894\udc85\ud82e\udd20\ud8a2\udd9c\ud9e8\udf3d\ud8c3\udfc8\u9aba\udb20\udd28\ud89c\udd6c\ud917\udee7\uda3d\ude58\ue84e\udb0c\ude59", "\u50ed\u5dad\ub390\u7ecc\u6954\u8da5\ua56d\u991b\u84bf\ub126\uc6f7\u845b\u72a2\ud685\ud74b\u9071\u2f76\u3f31\ucda3\u10fb\u2844\u30d5\u1d27\uaaf5\u0511\u4650\ub345\u37a5\ua7a4\u74e1\u53d0\uc911\u160c", "\ud887\udfad\ud8d8\udd11\udad6\udd4c\udb6c\udc1f\ud882\udd9a\ud9ca\ude5b\ud8dd\udd38\ud845\udc7b\udb7a\ude72",
        43, 93653, 1168957440, 4274149439817100378L, -528L, false, true, (char) 12487, (char) 28542,
        Double.longBitsToDouble(0x3fcefa4a885072fcL), Double.longBitsToDouble(0x3fef8909e5249b4aL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Long:6181190488594805852 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 10, "\ud88a\udc73\udb89\udc71\udb70\ude12\udacd\udd3d\ud9c0\udffa\ud894\udc3d\u009b\ud90b\ude4f\ud8b6\ude5b\ubc4a\udaf2\udce0\ud9b5\ude69\u5a74\ud9a8\udf39\ud8a7\udc29\udad1\udeed\udae5\udf3d\uda7c\udf96\udb20\udd28\ud89c\udd6c\ud917\udee7\uda3d\ude58\ud981\udd55\udb0c\ude59", "\u50ed\u5dad\ub390\u7ecc\u6954\u2b73\u1298\u48f8\u84bf\ub126\uc6f7\u845b\u72a2\ud685\u4e2a\u910d\u2f76\ud037\ucd5c\u9359\u2844\u30d5\u91f3\uaaf5\u04bb\u4650\ub345\u37a5\ua7a4\u74e1\u53d0\u58d2\u160c", "\ud8bb\udf4f",
        15, 51100, 1659185398, 6181190488566005852L, 83457L, false, true, (char) 48988, (char) 57297,
        Double.longBitsToDouble(0x3f46d1d11516b000L), Double.longBitsToDouble(0x3fb68ed4154929d8L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Long:2939504805410754867 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 12, 6, "\udb83\ude49\udb6a\uddfd\ud8ae\udd98\ud88a\udc8e\ud97b\udd8b\ud89d\udccd\uda9a\udcf2\ud9f7\ude5b\ud8cb\udd18\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u394c\u2c58", "\ud8f0\uded0\ud963\udc6b\uda12\ude6e",
        49, 60276, 1060855292, 2939504805381954867L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:Australia/Sydney\012",
        Z.run(T, 1, 10, 15, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\udb7c\udcfd\udba6\udc5b\udb71\udcff\udb4b\udf35\udb5d\udee5\udba2\udd10", "\u58de\uae7c\u8818\ucb59\u3353\u1d17\uadc2\u25cc\u5670\uaf01\u50ed\ua249", "\ud988\udcb4\udba0\udcf0\udbf8\udd28\ud860\udeba\ud82e\udfd1\uda2f\udf62\ud836\udeaa\uda27\udc9d",
        13, 63959, 1540454735, -2929149390198770001L, -21748L, false, false, (char) 8330, (char) 16144,
        Double.longBitsToDouble(0x3fb123e795df2e28L), Double.longBitsToDouble(0x3fdfa03954894b6aL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Long:2939504808003895731 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 9, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58\ud981\udd55\udb0c\ude6b",
        58, 60276, 1060855292, 2939504807978695731L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Long:639001527680 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 0, 6, "\udb11\udcf5\udbbb\udcbf\udb97\udc1d", "\u0606\u488e\ud355\u5541\u5b31\ud4b9\ubf62\u54ea\u0884\u2bc5\u062d", "\udb20\udd28\ud89c\udd6c\ud917\udee7\ud8ad\udccf\udbc2\udc38\uaf1c\udb65\udf22\uf6d5\udbcc\uddb5\udbe4\udc34\ud91b\ude8a\udb86\udf33\udb46\udd86\u6cef\ud9f6\ude29\ud9a6\udff5",
        56, 88460, -696334295, 638976327680L, 55999L, true, true, (char) 47915, (char) 17511,
        Double.longBitsToDouble(0x3fe29288278562b1L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Long:2411422052607814005 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 0, 6, "\ud8e4\udcdd\udb05\uddeb\udb97\udc1d", "\u0606\u488e\ud355\u8754\u5b31\ud4b9\ubf62\u54ea\u0884\u2bc5\u062d", "\uda85\uddfb\ud949\ude39\ud917\udee7\ud8ad\udccf\udbc2\udc38\uaf1c\udb65\udf22\uf6d5\udbcc\uddb5\udbe4\udc34\ud91b\ude8a\ud828\udf83\udbb3\udffe\uda51\udf16\ud9f6\uded3\ud9a6\udff5",
        34, 88460, -696334295, 2411422052579014005L, 86567L, false, false, (char) 47915, (char) 17511,
        Double.longBitsToDouble(0x3fd76a004dde20b6L), Double.longBitsToDouble(0x3feed42126f036c3L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Long:6652812726941069860 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 0, 6, "\udb11\udcf5\udbbb\udcbf\udb97\udc1d", "\u8eae\u488e\u6185\u34ac\u5b31\ud4b9\ubf62\u54ea\u0884\u2bc5\u3d7c", "\udb20\udd28\udb23\uddf3\udb7f\udc0d\ud8ad\udccf\udbc2\udc38\uaf1c\udb65\udf22\uf6d5\udbcc\uddb5\udbe4\udc34\ud91b\ude8a\udbfe\udc33\ud9f6\udd87\u6cef\ud9f6\ude29\ua217\udb3d\udfc0\uda60\udfd9\udb4d\uddb6\udb78\udd8d\uda93\udf37",
        5, 64204, 795884533, 6652812726915869860L, -54476L, false, true, (char) 54706, (char) 49797,
        Double.longBitsToDouble(0x3fb9f66e01911398L), Double.longBitsToDouble(0x3fe6adca0cf47304L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Long:2411422052113187829 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 0, 6, "\udb11\udcf5\udbbb\udcbf\udb97\udc1d", "\u0645\u488e\ud355\u5541\u5b31\ud4b9\ubf62\u54ea\u0884\u2bc5\u062d", "\udb20\udd28\ud89c\udd6c\ud917\udee7\ud8ad\udccf\udbc2\udc38\uaf1c\udb65\udf22\uf6d5\udbcc\uddb5\udbe4\udc34\ud91b\ude8a\udb86\udf33\udb46\udd86\u6cef\ud9f6\ude29\ud9a6\udff5",
        34, 88460, -696334295, 2411422052087987829L, 6186L, true, true, (char) 47915, (char) 17511,
        Double.longBitsToDouble(0x3fe29288278562b1L), Double.longBitsToDouble(0x3feed42126f036c3L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+05:30\012",
        Z.run(T, 1, 10, 9, 6, "\udb72\udeef\uda26\udca6\ud80f\udeb8\uda35\udea6\ud8cb\ude5d\ud945\udcc7\udb19\udec8\udbc5\uddd9\ud8b6\ude42\ud9e2\uddce\ud83d\ude24\udbfd\udfe6\ud900\udc0f\udb9a\udf84", "\u4187\u1aa1\u2f8f", "\ud942\udc8f",
        54, 19000, 172594262, 6489353650085518844L, -37929L, false, false, (char) 18615, (char) 29130,
        Double.longBitsToDouble(0x3fd81ea20cb2f244L), Double.longBitsToDouble(0x3fd54007633e84e4L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Long:5752708715493154767 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ubbaf\ud8da\udd00\uda8e\udf01\ud969\udf2c\ud8cb\ude5d\udb58\udf11\ud9df\udca5\udb38\uddb4\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\udbfe\udc58\ud900\udc0f\udb9a\udf84", "\u4187\u1aa1\u2f8f", "\uda0b\ude6c\uda19\udd42\uda39\udfbd\ud89d\udca3\uda78\udd11\udbcc\uddb5\ud826\udf55\udbaf\udfcf\ud89f\udf50\udb46\udd86\u696d\ud9e7\udca4\udbfb\ude5f\udbd6\ude26",
        22, 73686, 1917930428, 5752708715467954767L, -28189L, true, true, (char) 18266, (char) 6754,
        Double.longBitsToDouble(0x3fd6fcf4971c20c6L), Double.longBitsToDouble(0x3fe87b5d2ff54138L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-04:00\012",
        Z.run(T, 1, 7, 6, 6, "\ud988\udc36\ud8da\udcde\ud88a\ude67\udac6\udff0\udba1\udf93\ud969\udcba\ud96f\udc22\uda1d\udc07\udb81\udea0\uda01\udd69\ud827\udef6\udbfe\udc58\ud900\udc0f\udb9a\udf84", "\u79ea\ubbf0\u2f8f\u7065\ucbdc\u2867\u833d\ua328\u4887\u9b7f\u357d\u73e6\u1602\u9b74\u667c", "\udbfb\ude5f\udbd6\ude26\udb06\udcc2\uda33\uddb6\udb78\udc93\udaa6\uddd4\ud85c\udd85\uda52\udeed",
        -4, 11996, -205016332, -147803091772892785L, 56285L, true, true, (char) 9060, (char) 16406,
        Double.longBitsToDouble(0x3faa302bee060970L), Double.longBitsToDouble(0x3f7437426462f300L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:\ud92a\udc29\ud829\udccd\udb08\udf5f\ud880\udd8c\ud899\udf14\ud8a1\udc98\0121=org.joda.time.tz.FixedDateTimeZone:\ud92a\udc29\ud829\udccd\udb08\udf5f\ud880\udd8c\ud899\udf14\ud8a1\udc98\012",
        Z.run(T, 2, 5, 5, 10, "\ud92a\udc29\ud829\udccd\udb08\udf5f\ud880\udd8c\ud899\udf14\ud8a1\udc98", "\u5541\u5b31", "\udb27\udf04\udbcb\udfd7\udab7\udffc\ud867\ude7a\udbae\ude5c\ud8c0\udfd9\udbe4\udcf4",
        -2, 23066, 524615162, 3496194889608802392L, 54902L, false, false, (char) 37112, (char) 26132,
        Double.longBitsToDouble(0x3fe5bdb8c477e1c6L), Double.longBitsToDouble(0x3fe71609db28c576L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 1, 5, 6, 6, "\ud873\udc78\udb89\udc71\udb70\ude12", "\u0606\ub001\u565e\uac53\u5b31\u9563\u1197\u7559\u3bf7\ucb28\u062d", "\udb20\udd28\ud89c\udd6c",
        0, 42762, 1041349037, -7089061397755223740L, -58524L, false, false, (char) 27348, (char) 36476,
        Double.longBitsToDouble(0x3fdd3ca5ed6f6e26L), Double.longBitsToDouble(0x3fe8370e36597922L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-05:00\0121=org.joda.time.tz.FixedDateTimeZone:\uda51\ude98\udb89\udc1e\ud828\uddae\ud8a6\udd74\ud9a3\udc84\ud860\udfb3\ud9df\udd1c\ud90b\udf31\ud914\udfc9\ud869\udf5b\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\udb0b\udcfb\ud9fb\udfaa\udae5\udf3d\uda7c\udf96\ud8ff\ude18\012",
        Z.run(T, 2, 7, 5, 1, "\uda51\ude98\udb89\udc1e\ud828\uddae\ud8a6\udd74\ud9a3\udc84\ud860\udfb3\ud9df\udd1c\ud90b\udf31\ud914\udfc9\ud869\udf5b\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\udb0b\udcfb\ud9fb\udfaa\udae5\udf3d\uda7c\udf96\ud8ff\ude18", "\u3004", "\udbe3\udcc4\ud803\udce1\udbcc\uddb5\udacc\udd08\udb69\udc88\uda8e\udc3a\ud9f8\ude08\ud820\ude45\udbd8\udf7c\ud9c3\udd05\udbee\udd68\ud87d\udffa\udb4d\uddb6\udaae\udd5a",
        -5, 45684, -1295311181, 4679724317015167846L, 5343L, false, true, (char) 7528, (char) 33968,
        Double.longBitsToDouble(0x3febda8222b3b0e1L), Double.longBitsToDouble(0x3fe575c409b73b2eL)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.CachedDateTimeZone:Europe/London\012",
        Z.run(T, 2, 0, 10, 12, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\uda99\udff9\ud888\udcb7\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\udb0b\udcfb\ud9fb\udfaa\udae5\udf3d\uda7c\udf96\ud8ff\ude18", "\u3568\u833d\u139e\u5670\uaf01\u50ed\u5dad\ubda2\u126d\u241d\uac05\ud5d9\u48f8\u35a2\ub126\uc6f7\u2cc8", "\ud8a7\udcc7\udb17\udc4c\ud9a8\udd2f\udbe1\uddd4\ud941\uddac\udb28\udc63\u26ea",
        32, 54219, 1634323123, 6977696760459497746L, 99561L, true, true, (char) 56608, (char) 58670,
        Double.longBitsToDouble(0x3fdfc2ad68d68286L), Double.longBitsToDouble(0x3fe3fcf4ec0d5cc3L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 3, "\ud913\udc0a\udaa8\udeff\udb70\ude12\ud95d\udd47\uda99\udff9\ud888\udcb7\udaca\udd92\ud90b\udf01\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\udb0b\udcfb\ud9fb\udfaa\udae5\udf3d\uda7c\udf96\ud8ff\ude18", "\u356b\u833d\u139e\u5670\uaf01\u50ed\u7711\u9934\ub27f\uc9d9\u3628\ud5d9\u48f8\u35a2\uc8ed\u06f7\u2cc8", "\ud919\udc8f\udb17\udc4c\ud9a8\udd2f\udbe1\uddd4\ud927\udfde\udb5e\udcae\udbdf\udeaa",
        32, 54219, 1634323123, 6977696760459497746L, 99561L, true, true, (char) 3361, (char) 48845,
        Double.longBitsToDouble(0x3fd0765828d68286L), Double.longBitsToDouble(0x3fe3fcf4ec0d5cc3L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:-24962884 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\uda99\udff9\ud888\udcb7\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\udb0b\udcfb\ud9be\uddab\udae5\udf16\uda7c\udf96\000", "\u3568", "\udb65\udf22\uf6d5\udbcc\uddb5\udacc\udd08\udb69\udc88\uda8e\udc3a\ud9e9\udc08",
        7, 50830, 89, 3837116L, -40501L, false, false, (char) 12223, (char) 1347,
        Double.longBitsToDouble(0x3fbe6cb2db320788L), Double.longBitsToDouble(0x3fefaed3937f63b0L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:1277337898154049180 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\uda99\udff9\ud888\udcb7\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\ud911\udcfe\ud9e5\uddaa\udae5\udf3d\uda7c\udf96\ud888\udcb3", "\u8ef9\uaae7\u139e\u9ebc\u6e25\u50ed\u5dad\ubda2\u126d\u241d\uac05\ud5d9\u48f8\u35a2\ub126\uc6f7\u2cc8\u8f5c\u6a6d\u55d2\uc571\uaee3\u0e1c\uc663\u6f74\u7a74", "\uda60\uddad\uda98\udde8\udb4a\udc74\udb2f\udc29\udb37\udfbd\ud87d\uddf6\udbbd\ude20\ud8e8\uddc5",
        15, 13451, 1556326015, 1277337898179249180L, 85091L, false, true, (char) 45638, (char) 32398,
        Double.longBitsToDouble(0x3fde342d50b3e532L), Double.longBitsToDouble(0x3fe77c7b9a9a269eL)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Long:5783765296311121787 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:5783765296311121787 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 3, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\uda99\udff9\ud888\udcb7\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\udb0b\udcfb\ud9fb\udfaa\udae5\udf3d\uda7c\udf96\udb2f\udfef", "\u3568\u833d\u139e\u5670", "\udacc\udd08\udb69\udc88\uda8e\udc3a\ud9e9\udc08\uda84\udfb7\ud9cc\udd74\ud9fe\udc16\udab4\ude2d\uda1a\udff1\udb4d\uddb6\udaae\udd08\uda2a\ude03\ud96d\uddfe\ud8a7\udcc7\udb17\udc4c\ud9b4\udf2a\udbe1\uddd4",
        33, 93642, 1959464968, 5783765296339921787L, 95777L, false, true, (char) 14673, (char) 4833,
        Double.longBitsToDouble(0x3fd33d527d6a9cd8L), Double.longBitsToDouble(0x3fe4cbef79fc37f4L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:6959400886944505106 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 6, "\ud88a\udc73\udada\udd19\ud835\udfdd\udbec\udf42\uda99\udff9\ud888\udcb7\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\udb0b\udcfb\ud9fb\udfaa\udae5\udf3d\uda7c\udf96\ud8ff\ude18", "\u3568\u833d\u139e\u5670\uaf01\u50ed\u5dad\ubda2\u126d\u241d\uac05\ud5d9\u48f8\u35a2\ub126\uc6f7\u2cc8", "\ud8a7\udcc7\udb17\udc4c\ud9a8\udd2f\udbe1\uddd4\ud941\uddac\udb28\udc63\udb94\udf6f",
        29, 54219, 1634323123, 6959400886973305106L, 99561L, true, true, (char) 56608, (char) 38735,
        Double.longBitsToDouble(0x3fdfc697b8d68286L), Double.longBitsToDouble(0x3fe3fcf4ec0d5cc3L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:Europe/London\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 6, 6, "\ud8bc\udc47\ud892\udf9f\ud8f2\udeb3\ud94c\udc2c\ud969\udd0e\ud8a1\udd0b\ud9df\udd1c\ud9a4\udc1e\ud94d\udfe2\udb8e\udcd6\ud8e8\udfe4\uda4d\udd79\udb5d\udee5\udba2\udd10", "\uca45\u4710\u6f67", "\udba2\udf3b",
        53, 91272, -606232252, -4083408974148575952L, -66211L, true, false, (char) 46936, (char) 16074,
        Double.longBitsToDouble(0x3fe6d848828bf933L), Double.longBitsToDouble(0x3fc8f8aed2f2b164L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Long:6175387442147261061 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ud817\udcb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\uda79\ude22\ud9c5\udd51\udb5d\udee5\udba2\udd10", "\u7e45", "\ud89c\udd6c\ud917\udee7\uda3d\ude58\ud981\udd55\udb0c\ude6b\udb65\udf22\ud811\uddd7\uffc8\uda03\udc52\ud854\udd05\udb86\udfa8\udb46\udd86\u6cef\ud9f6\ude29\udb86\udee5\udbfa\udfd8\uda2f\udf62\udb4d\uddb6\ud942\uddb2",
        13, 17927, 1363598430, 6175387442118461061L, -36632L, false, true, (char) 37486, (char) 49100,
        Double.longBitsToDouble(0x3fb7ff812f66a7f0L), Double.longBitsToDouble(0x3fdc203db5cf06ecL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+05:30\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 6, 6, "\udb41\uddc2\ud842\udc38\udb96\uddf0\ud95d\udd28\udbe4\udeed\ud8a1\udc91\ud9f0\udf1c\ud90b\udf31\ud8b6\ude5b\ud9aa\uddd2\ud83d\ude24\udb6b\udd9b\ud8cf\udd90\ud89d\udfdc", "\u0b75\u867d\u8818\u6155\ucb9e\ud18d\u248d\u5f31\u48b5\u74f4\u50c1X\u4514\u7e72\ucf64\u92e4\u1298\u48f8\u35a2", "\ud997\udf1c\ud93b\uddff\ud8ff\udf3d\ud8e8\udc2e\udb84\udf3b\ud9f6\udea3\uda19\ude78\udafd\udc44\udadd\udc6c\udaba\udc29\ud853\udf45\ud97a\ude65",
        -2, 30499, 1349670026, 4156334712862842902L, -62970L, true, false, (char) 34824, (char) 4960,
        Double.longBitsToDouble(0x3f68028df0504000L), Double.longBitsToDouble(0x3fe9f69964161887L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 1, 7, 6, 12, "\ud90c\udc6d\u8ce9\udb9c\udfe5\udbb8\udd57\ubdb3\ud886\udc98\ud9df\udd1c\ud94d\udee9\ud8b6\ude5b\ud9e2\uddce\uda33\uddfc", "\u3cb0\ub244\u74e1\uca3c\u461f\u8818\ubf00\ucb9e\u3568\ub80c\u66a7\ud0be\u1aaf\u34ab\u7b00\u4698\u7ecc\ub38a\u208a\u1bee\u787c\u515a\ub126\uc6f7\uc4e9\ud190\u3d56", "\ud858\udce0",
        0, 39214, -1408492509, -8350260251784643800L, -9137L, true, true, (char) 10517, (char) 27142,
        Double.longBitsToDouble(0x3fc211d6dc33c208L), Double.longBitsToDouble(0x3fdf1821fbaf55e2L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Long:-2157087870055126485 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:-2157087870055126485 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 2, 13, "\udbae\ude17\udb1e\udcff\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\udac5\uddef\ud8f6\udeb2\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24", "\u3bf7\u2d88", "\uda7c\udf96\ud9b9\udebc\ud89c\udd6c\udb64\udd2d\ud8c8\udcec\udbad\uddb3\u0d45\ud981\udccf",
        0, 59452, -288339225, -2157087870083504485L, -85591L, false, true, (char) 12155, (char) 24172,
        Double.longBitsToDouble(0x3fc79590db8358e8L), Double.longBitsToDouble(0x3fe1232bd11a0d79L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 5, 4, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\udaaa\udcb0\udbca\udc2f\ud8fc\ude09\ud906\udd32\ud91a\udfe2\uda7a\uddc0\ud83d\ude24\udbb5\udeb6\udb5d\udee5\udba2\udd10", "\u4a87\u4710\u7fcc", "\ud823\ude0b\ud981\udce3\udb0c\ude6b",
        52, 64555, 1060855292, -1238408481453671421L, -66675L, true, true, (char) 57705, (char) 12155,
        Double.longBitsToDouble(0x3fcecc2ed2f2b218L), Double.longBitsToDouble(0x3fef06b1d24403cbL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 4, 4, 0, "\ud88e\udcb4\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\udac5\uddef", "\u7716\u8552\u39bb\u7559\u1d7b", "\ud81e\uddeb",
        12, 70482, -1200666589, 3884613863141932538L, 70040L, false, true, (char) 52223, (char) 57788,
        Double.longBitsToDouble(0x3fe5d976dc03eed0L), Double.longBitsToDouble(0x3fe2e940fdd3ca5eL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Long:4877843012953786898 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c", "\u5b31\u1240\u1167\u7559\u3bf7\ucb28\u062d\u85ef\ucb70\u8818\u6155\ucb9e\u3568\u833d\u139e\u5670", "\udacc\udd08\ud91b\ude60\ud915\udd34\udb46\udd86\u79ce\ud9f3\udef2\udb86\udee5\udbfa\udfd8\uda2f\udf62\udb79\udcdd\udbce\udddc\udb8c\uddac\ud8d7\udd3a\udba7\udf97\ud890\udcac\ud88d\udfd5\ud849\uddee",
        37, 98889, -12650454, 4877843012928586898L, -41099L, true, true, (char) 63917, (char) 39840,
        Double.longBitsToDouble(0x3fe28c680287e21bL), Double.longBitsToDouble(0x3fee4af725c622a8L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Long:1403020603900855966 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 0, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\udb3f\udfec", "\u5b31\u1240\u1167\u7559\u3bf7\ucb28\u062d\u85ef\ucb70\u8818\u6155\ucb9e\u3568\u833d\u139e\u5670\uaf01\u50ed\u5dad\ub390\u18d5\ucf64\u2aa8\u7fc0\u48f8\u35a2\u986e", "\udb8c\uddac\ud8d7\udd3a\udba7\udf97\ud890\udcac\ud88d\udfd5\ud849\uddee\ud81e\udf15\uda12\udedc\uda68\udc1e\udb22\ude7d\uda0a\udd9e\udbfc\udcc5\ud86e\udd0f\udbd6\udf35\uda66\udcd0\uc885\uc48e\uda34\udc1e\udb81\uddd3\udbc0\udfa3\ud88d\udf9b\ud997\udda0\udbd3\udc6a\udbf0\ude61\udaa9\uddb5\uda9e\udee6\ud9a1\udeb5\ud93a\udcd1\udb99\ude55\ud930\udd3f\uda3a\udc4c\ud9fd\udd77\uda2a\udf56\ud8e1\udde5\ud8eb\ude06\udb5d\uddfe\ud80c\udc7b\udb31\udd56\udb18\uddd1\ud81b\udc14\ud9af\udc27\ud863\udf1f\u288c\ud943\udd4c\udbd5\udf98\ud9c8\udf54\udbf3\udf99\ud9ee\ude36\uda34\udfa2\udbae\udc5d\udbdd\udc70\ud829\uddbc\udb3e\uded6\ud942\udd12\uda72\udc24\ud952\udc8a\uda18\udf23",
        26, 6511, -598003221, 1403020603872055966L, 29914L, true, true, (char) 59501, (char) 13518,
        Double.longBitsToDouble(0x3fd750c4875956c2L), Double.longBitsToDouble(0x3fea428f48afa5e6L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.util.TreeSet:[Africa/Abidjan, Africa/Accra, Africa/Addis_Ababa, Africa/Algiers, Africa/Asmara, Africa/Asmera, Africa/Bamako, Africa/Bangui, Africa/Banjul, Africa/Bissau, Africa/Blantyre, Africa/Brazzaville, Africa/Bujumbura, Africa/Cairo, Africa/Casablanca, Africa/Ceuta, Africa/Conakry, Africa/Dakar, Africa/Dar_...\0121=java.util.TreeSet:[Africa/Abidjan, Africa/Accra, Africa/Addis_Ababa, Africa/Algiers, Africa/Asmara, Africa/Asmera, Africa/Bamako, Africa/Bangui, Africa/Banjul, Africa/Bissau, Africa/Blantyre, Africa/Brazzaville, Africa/Bujumbura, Africa/Cairo, Africa/Casablanca, Africa/Ceuta, Africa/Conakry, Africa/Dakar, Africa/Dar_...\012",
        Z.run(T, 2, 11, 11, 4, "\ud88a\udc73", "\u9ed6\u0b1a", "\ud9e7\udeb5\ubc15\ud9c4\udd29\ud8c2\udd48\udbd2\udf3b\udb98\uddd2",
        18, 35682, 300828914, 7826413138379898867L, -2681L, false, true, (char) 33833, (char) 51350,
        Double.longBitsToDouble(0x3fd3c3e1858c34eeL), Double.longBitsToDouble(0x3fd00977625c6e38L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.014\0121=org.joda.time.tz.FixedDateTimeZone:+14:00\012",
        Z.run(T, 2, 9, 7, 10, "\ud88a\udc73\ud882\udd92", "\u0b1a\uae37\u2e74\ud364\u5541\u5b31\u7d23\u10fc\ubd29\u0925\ucb28\u4394\u46cf\ubb3e\u6425\u6155\ucb9e\ucf77\u0085\u409a\uac41\u359c\u906e\u8c1f\u9b1a\u5b51\u9119\u73af\u0b1a\u7321\uc958\u10f7\uc8b0\u1b2b\u4cf7\u38c4\u3b81\u8e75\ucfaa\u4a24\u5c18\u6d4e\u42c7\uc819", "\udb9c\udcec\uda2a\udc41\ud96e\udccc\uda88\udf5a",
        14, 29611, 1906751821, 8355337642134070926L, 80316L, true, true, (char) 15836, (char) 41510,
        Double.longBitsToDouble(0x3fe96808a8868affL), Double.longBitsToDouble(0x3fd999750c77602aL)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:\ud88a\udc73\0121=org.joda.time.tz.FixedDateTimeZone:+30:00\012",
        Z.run(T, 2, 5, 7, 4, "\ud88a\udc73", "\u9e84\u0b1a", "\udb21\ude4f\uda61\udebc\ud9e2\uddce\ud8c2\udd48\udbd2\udf3b",
        30, 30013, 18078178, 1862472582644227287L, -96998L, true, true, (char) 5782, (char) 34018,
        Double.longBitsToDouble(0x3fe767cd513c3e18L), Double.longBitsToDouble(0x3fe630d3bc4baa76L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.028\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 9, 0, 0, "\ud88a\udc73", "\ubae4\u0b1a", "\uacf1\000\000\000\000\udbb3\udc8a",
        28, -1000, 433640448, 3776791655092121079L, -97341L, false, false, (char) 19968, (char) 51350,
        Double.longBitsToDouble(0x3e3630d3b8000000L), Double.longBitsToDouble(0x3fb2ea9d8171b8e0L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-00:00:00.001\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 9, 0, 4, "\ud873\ude17", "\u9ed6\u0b1a", "\ud90b\udf40\ud8b6\ude5b\udb7c\udfdc\ud99b\udde3\udbd2\ude7f\ud917\ude67",
        -1, 86946, 2090988186, 3790128629651664375L, 28867L, false, true, (char) 34018, (char) 51350,
        Double.longBitsToDouble(0x3fd3c3e1818c34eeL), Double.longBitsToDouble(0x3fb2eaa14971b8e0L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.009\0121=org.joda.time.tz.FixedDateTimeZone:+00:00:00.009\012",
        Z.run(T, 2, 9, 9, 4, "\ud8ac\udcbf\ud882\udd92", "\u1ed1\u008f\u4d09\u507e", "\ud8c2\udd48\udbd2\uded8\udbb3\udd75\ud94b\udead\ud960\udeb6\uda0b\udef0\ud913\ude3b\ud950\udd03\udab5\ude31\ud922\udf0f\udbc5\udce7\udbad\udd68\udb46\ude94\udbd9\uddf9\u40d8\ud9bf\udec7\ud979\ude69\u5517\udafc\udc3b\uda0a\udff0\udbd1\udc6b",
        9, 5049, -143239492, -8122495923612015687L, 90966L, true, false, (char) 25712, (char) 30592,
        Double.longBitsToDouble(0x3febbb780d516c1fL), Double.longBitsToDouble(0x3fe83eec66402045L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Long:1224645096219783336 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 2, 6, "\udb55\uddea\ud990\udc2a\ud83e\ude38\ud9c4\udffb\u8f72\ud8a1\udc68\ud9df\udd1c\u00e2\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\ud440\u412f\u8818\u6155\000\000\u79ec\u38bb\u00ba\u04d5\u791f\u5dad\ub38d]\u5191\u92e4\ub306\000\u34db\u63be\u3a33\ubdc3\u0ac1\u67e8\u5905", "\ud8ec\udf6b\ud901\udd65\ud94b\udf94\uda88\udd6a\ud8a1\udc3f\udbbd\udd32\ud9ad\udfca\u1676\udb82\udd0d",
        23, 27101, 1520554686, 1224645096194583336L, 44135L, false, false, (char) 12722, (char) 5265,
        Double.longBitsToDouble(0x3fe9b65f38cb27e5L), Double.longBitsToDouble(0x3fef24d3d2922bc7L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+59:00\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 8, 6, "\ud88a\udc73", "\u3cba", "\ud9ea\udeda\ud812\ude22",
        59, 38516, -1366973672, -7102720945444070078L, -49262L, false, false, (char) 14608, (char) 22103,
        Double.longBitsToDouble(0x3febfc002c73d470L), Double.longBitsToDouble(0x3fe8e9b25dfa35e8L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Long:3456004725827968556 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 6, 6, "\ud9fb\uddce\udb79\udce1\udac7\uddd8\udbce\udc9a", "\u87ef\ud317\u4884", "\uda7e\ude4c\ud8d1\udfa1\udb49\uddaf\ud910\ude97\uda72\udeb5\ud925\udd9c\uda37\udc14\uda4f\udcfa\udbd4\udc29\ud990\udc58",
        2, 4651, -1010346474, 3456004725799168556L, -8878L, false, false, (char) 4924, (char) 18482,
        Double.longBitsToDouble(0x3fe5bdb89b357335L), Double.longBitsToDouble(0x3fe24b95da850176L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=org.joda.time.tz.DateTimeZoneBuilder$PrecalculatedZone:Asia/Bangkok\0121=org.joda.time.tz.DateTimeZoneBuilder$PrecalculatedZone:Asia/Bangkok\012",
        Z.run(T, 2, 10, 10, 15, "\ud88a\udc12\udb89\udc71\uda31\udc4e\udac9\ude11\ud938\ude23\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\udb5b\udc54\ud901\udfde\ud835\udf21\ueb67", "\u93d1\u47f3\u1cb5\u474e\u8818\u3cda\u1bb1", "\udacb\ude4a\ud952\udf52\udba2\ude3f\ud82f\ude40\uda09\udc71\ud99e\udfb9\udb12\udd29\uda29\udf48",
        10, 92892, -982121267, 8239723399717772123L, 90571L, false, false, (char) 1012, (char) 57875,
        Double.longBitsToDouble(0x3fbe514df3501018L), Double.longBitsToDouble(0x3fed1fc4fd72767eL)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\0121=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 2, 10, 10, 6, "\ud9a6\ude37\udb89\udc71\uda31\udc4e\udbc5\uddbf\ud8f1\udf23\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\u35f2\uda35\udcdb\ud931\udf83\ud971\udc6f\uda89\ude84\ud8d8\uddf2\udbfb\ude43\udae5\udfe5\ud952\udc82\ud81e\udd40\ud995\uddee\ud8cc\ude8c\udb0f\udc34", "\u5670\uaf01\u2998\ud752\u1b58\ud315\u9a8a", "\udb86\udee5\udbfa\udfd8\uda2f\udf62\udb4d\uddb6\ud84e\ude39\ud937\udf0b",
        28, 12509, 36962537, -531493363728728317L, -65476L, false, true, (char) 10419, (char) 36411,
        Double.longBitsToDouble(0x3feb1d0a223764dcL), Double.longBitsToDouble(0x3fe6b9b84d52f1adL)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-00:00:00.004\0121=org.joda.time.tz.FixedDateTimeZone:-04:00\012",
        Z.run(T, 2, 9, 7, 6, "\u009b\udb27\uddf8\ud9e7\udfab\ud95d\udd3e\ubdc3\ud8a1\udc68\ud9df\udd1c\u7995\ud8ef\ude6c\ud830\udf21\uda7d\uddf9\udb80\udce0\udb1f\udeef\udbed\udd31", "\u48b0\u0b0f\ud1af\u3be8", "\udb39\udd31\udb1e\udff6\ud8d0\udc02",
        -4, 49244, -1638741466, 1774816096104540631L, -91087L, false, false, (char) 18723, (char) 63947,
        Double.longBitsToDouble(0x3fad525a6f4338f0L), Double.longBitsToDouble(0x3fe1229532544cd1L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 4, 6, "\udaf4\udd89\ud8ba\udf23\036\ud932\ude65\ubdb3\uda61\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb1c\udf18\uda57\ude01\uda4d\udd12\udb5d\udee5\udba2\udd10", "\u3962\u732a\u8818\u6155\ucb9e\u3568\u833d\u139e\u92bd\uaa2c\ucaf0\u28a4\ub39f\u985c", "\ud9c5\udf21\ud983\udfe2\udbfa\udfd8\uda2f\udf62\udb4d\uddb6\udb47\ude94\ud898\udf6f\ud8bb\udcc3\ud8de\udeb3\ud9f2\ude69\ud91d\udf38\u0083\000\000",
        41, 96063, 1879775463, 3434046698142271378L, -76524L, true, false, (char) 52832, (char) 47305,
        Double.longBitsToDouble(0x3fe2f838a7addccdL), Double.longBitsToDouble(0x3feb1e63d8e1b224L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Long:3940978234668515795 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 15, 11, "\udb28\udc91\ufe4d\udaf5\ude8a\udacd\udd14\ud9c0\udffa\ud894\udc3d\000\ud8e0\ude4f\ud8b6\ude5b\000\udaf2\udce0\ud9b5\ude69\u5a74\ud9a8\udf39\ud8a7\udc29\udad1\udeed\ud930\udf98\u8e80\uda64\udd2a\ud89c\udd6c\u5c25\uda8f\udc9d\ud952\udfa8\ud89e\ude21", "\u50ed\u5dad\ucb72\u8a60\uaa6c\u2b73\ub306\000\u23f8\u45fb\u4199\u8473\u72a2\u1e3a\u4463\u9514\u09b1\ub106", "\uda63\udfb5\ud999\udede\udb23\udce8\ud914\udf67\ud901\udec2\udbad\udd56\ud851\uddfa\ud9e8\udf68\uda32\ude95\udb23\udfde\ud944\udff2\ud83f\udc4e",
        -1, 81234, -291010893, 3940978234643315795L, -23978L, false, false, (char) 11800, (char) 35066,
        Double.longBitsToDouble(0x3ea7b4a000000000L), Double.longBitsToDouble(0x3fddf4690bebb3b8L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Long:14396721791403799 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 0, 6, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\udb01\udd91\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud9bd\udedb\uda80\udf4d\udad1\udeed\ud9d5\udcf0\ud8b5\udd99\udb20\udd28\ud89c\udd6c\ud917\udee7\ud8ad\udccf\udbc2\udc38\uaf1c\udb65\udf22\ud8f1\udcaf\ud803\udd72\u1bae\ud91b\ude8a\udb86\udf33\udb46\udd86\u6cef\udb67\ude23\ud9a6\udff5\u00bf\uda2f\udf62\udb4d\uddb6\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud909\ude89\udbdc\udc22\ud801\udf85\000\ud841\ude5f\ud901\ude27\udb26\udd16\udbc5\udfe1\udac5\udc98", "\ud730\u3148\u92dc\uc7f3\uba0a\u8f36\u44bd\ud6be\ua0a0\u1e81\ucdde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\ud945\uded4\ud9af\udde0\ud9da\udee0\uda27\udea7\udab3\udcc3",
        16, 86835, -93485570, 14396721762603799L, 40454L, true, true, (char) 51917, (char) 12924,
        Double.longBitsToDouble(0x3fd9c78fb7a66e76L), Double.longBitsToDouble(0x3fec7f4645b533e5L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=org.joda.time.tz.DefaultNameProvider:@?\0121=org.joda.time.tz.DefaultNameProvider:@?\012",
        Z.run(T, 2, 14, 14, 2, "\udbae\ude17\udb98\udcfc\udb70\ude12\ud95d\udd47\u0825\udaf5\ude31\udac5\uddef\ud8cd\udca9\ud8b6\udeed\ud950\ude65\udbee\udee3", "\u3bf7\u2d87", "\uda7c\udf96\ud9b9\udebc\ud89c\udd6c\udabf\udd7b\ud8c8\udca9\udbad\uddb3\u0d45\udb57\udd1a",
        41, 90966, -288339225, -2157087867553198437L, 38049L, false, false, (char) 12480, (char) 13440,
        Double.longBitsToDouble(0x3fc79590db8358e8L), Double.longBitsToDouble(0x3fe1232bd11a0d79L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Long:-2157087870055126485 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:-2157087870055126485 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 2, 13, "\udbae\ude17\udb1e\udcff\udb70\ude12\ud830\udeca\ud83e\uded8\ud8a1\udc68\udba2\udc6b\udbda\udfbe\ud804\udecd\ud825\udff1\ud957\udd3b", "\u3bf7\u2d88", "\udafe\udf19\uda38\udc7b\ud878\udf6c\udb64\udd2d\ud8c8\udcec\ud801\udd1d\ud9b7\udea0\uda20\udfd3",
        53, 59452, 1085754087, -2157087870083504485L, -85591L, false, true, (char) 12155, (char) 30060,
        Double.longBitsToDouble(0x3fc788bf7b8358e8L), Double.longBitsToDouble(0x3fe1232bd11a0d79L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.039\0121=org.joda.time.tz.FixedDateTimeZone:+00:00:00.039\012",
        Z.run(T, 2, 9, 9, 10, "\udb1f\udcdb", "\u9ed6\u78b4\u71a5", "\ud8b6\uded0\udb7c\udfdc\ud99b\udde3\udbd2\ude7f\ud917\ude67\ud920\udd77\ud8f7\udfc8\ud8a1\udeb1\ud80d\ude1d\udbfe\ude77\ud99c\udf6b\udbf8\udf27\ud8e4\udee7\ud995\ude9a\udb46\ude94\ud8fc\udecb\ud978\udfbc\ud993\udf8a\ud87d\udf90\ud94f\udc79\ud908\ude55\udae3\udf91\ud979\udf46\ud8f9\udc56\ud870\udd06\ud8f4\ude18\ud99b\udf01\udb16\udfa5\udbd4\udda7\udb43\udfce\ud862\ude93\uda7b\udee3\ud800\udd2c\ud86f\udf36",
        39, 80103, 1024879968, 5631047702678922290L, 53800L, true, false, (char) 43093, (char) 60348,
        Double.longBitsToDouble(0x3fe10edebb91b90bL), Double.longBitsToDouble(0x3fd14dfce291b612L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+40:00\0121=org.joda.time.tz.FixedDateTimeZone:+40:00\012",
        Z.run(T, 2, 7, 7, 4, "\udae5\uddf4\ud880\ude3d\udab2\udc33\ud866\udcd4\uda0f\udc04\ud836\udca7\ud9ea\udeda\ud95f\udce2\ud9db\ude60", "\u7c1b\u7559\uc4f9\u2b14\u062d\u1288\ud5c4\u87dd\u333e", "\ud9c6\udf63\ud83e\udc11\udbc9\udc7c\u82a4\udb08\udcd0\ud9a0\udfa1\uda76\udd46",
        40, 13369, 639295771, 5004010403696314650L, -83495L, false, false, (char) 42026, (char) 14845,
        Double.longBitsToDouble(0x3fe881b51bdaea54L), Double.longBitsToDouble(0x3fe7fc496e592a06L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+05:30\0121=org.joda.time.tz.FixedDateTimeZone:+05:30\012",
        Z.run(T, 2, 10, 10, 6, "\ud9a6\ude37\udb89\udc71\uda31\udc4e\udbc5\uddbf\ud8f1\udf23\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\u35f2\uda35\udcdb\ud931\udf83\ud971\udc6f\uda89\ude84\ud8d8\uddf2\udbfb\ude43\udae5\udfe5\ud952\udc82\ud81e\udd40\ud995\uddee\u6a94\udb0f\udc34", "\u5682\uaf01\u2998\u279f\u1b58\ud315\u9a8a\u92e4\u1298\u48f8\u35a2\ub126\uc6f7\u93ce", "\ud828\ude2a\ud8c4\udd0a\udad2\udd2a\uda73\udf64\ud988\udd62",
        12, 89180, -2145988228, -6826315580993154205L, 14391L, false, true, (char) 44671, (char) 21666,
        Double.longBitsToDouble(0x3fe5dcbd0a4ac0d8L), Double.longBitsToDouble(0x3fd627f2b6901790L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.Long:1982299134281555588 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:1982299134281555588 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 2, 13, "\udbae\ude17\udb1e\udcff\udb70\ude12\ud830\udeca\ud83e\uded8\ud8a1\udc68\udba2\udc6b\udbda\udfbe\udb00\udfcc\ue669\ud957\udd3b", "\u3bf7\u2d88", "\udafe\udf19\uda38\udc7b\ud878\udf6c\udb64\udd2d",
        30, 75474, 2022244230, 1982299134252755588L, 4805L, true, true, (char) 32458, (char) 6741,
        Double.longBitsToDouble(0x3fe2cbc913f66176L), Double.longBitsToDouble(0x3fc788bf7b8358e8L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.Long:-4083451855073681012 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udba2\udd10", "\uca45\u4710\u8818", "\uda3d\ude58",
        22, 91272, -606232252, -4083451855102059012L, -66211L, true, false, (char) 18482, (char) 26058,
        Double.longBitsToDouble(0x3fe8370e36597922L), Double.longBitsToDouble(0x3fc8f8aed2f2b164L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.Long:2487307610484742733 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud975\ude37\ud8cc\udc9e\ud826\udf48\ud932\ude65\ubdb3\udafe\ude97\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud8b7\ude55\udb59\udf67\ud9c1\udec8\u6adc\ud968\udeb0", "\u360e\ub748\u9d46\u610c\ucb9e\u3568\u833d\u139e\ua071\u68a9\u50ed\u28a4\ub7c5\u40ca\ucf64\u92e4\u1298\u48f8\u35a2\ub126\uc6f7\u9e48\u3771\ub92f\uc591\u470b", "\ud98d\udd1b\ud87a\udeed\ud86d\udeb8\udaa1\udd90\udbbd\uddd2\uda2f\udefe\uda01\udcf9\udabe\udde6\udb43\udfb9\ud97b\udd2d\uda70\udd48\ud889\ude12\uda05\ude31\ud8a2\udffc",
        9, 94163, -2100784064, 2487307610459542733L, -62633L, false, false, (char) 53799, (char) 45177,
        Double.longBitsToDouble(0x3fdd6348f1a96418L), Double.longBitsToDouble(0x3fad204939e4cbf0L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 6, 5, "\ud88a\udc73\ud8ca\udcb7\ud859\udd5b\udae0\udcf8\ud81d\udc65\udb85\uddd9\ud9df\udd1c\udace\ude32\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud93a\ude33\ud084\ud848\ude92\ud8fc\udce7\ud8a6\ude12\ud8f4\udd44\u7675\udb06\udddf\udaad\ude1f\uda3d\ude58\udb4d\udefb\udb0c\ude6b\ud865\udf81\ud920\udf19", "\ub390\u7ecc\ubab6\u3e37\u015d\u0a28\u8aab\u0599\u847a\u4ba0\ud1ba\uc529\u65f9\u0994\u77cf\uabb9", "\udb0f\udf8c\udab4\udf59\ud929\udf9a\udb8f\udc37\uda68\udc89\udafc\udf15\udbf2\ude5a\udac4\udd14\uda43\ude1f\udae5\udd9e\ud8b4\uddc7\udb10\udf3e\udadc\udde5\uda3a\udcdb\ud99c\udfac\udb04\udc10\ud904\ude56\udb43\udedf\udad2\uddf5\udb00\ude92\ud819\ude27\ud9aa\udc2f\ud8d0\udc5f\ud826\udd04\uda68\ude62\udbd7\udf55\ud979\udf0b\udbd1\udf8c\uda18\udca8\ud921\ude8b\udbf5\udfca\uda0b\udea6\ud95b\udd03\udb81\udf79\ud924\udf79\udb4a\uddc9\ua6aa\ud8fd\udda0\ud819\udd06\udb0d\udf7e\ud8c6\udc9a\ud8a9\udff9\ud97d\udfec",
        36, 60384, -470358417, 382524539107116376L, -56064L, true, true, (char) 32232, (char) 10880,
        Double.longBitsToDouble(0x3feb53eca74e542eL), Double.longBitsToDouble(0x3fcecfd96e505fb0L)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.lang.Long:2793286396356405461 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\uda79\ude22\uda4d\udd55\udbad\udeed\udba2\udd10\ud8d8\uddf2\udad1\udeed\udad2\udf3d\uda7c\udec8\udb20\udd28\ud89c\udd6c\ud917\udee7\uda3d\ude58\ud981\udd55\udb0c\ude6b\udb65\udf22", "\u4369\ub0c3\u7f41\ucf64\u92e4\u1298\u48f8\u35a2\ub126\uc6f7\u6e78\ud032\u0206\u43dc\ub913\u25a5\u0346", "\udaed\uded3\ud90b\udfa4\ud806\udf25\udb73\udf0f",
        54, 35593, -1750075583, 2793286396331205461L, -13307L, true, false, (char) 54354, (char) 30895,
        Double.longBitsToDouble(0x3fb25869b5f4ecf0L), Double.longBitsToDouble(0x3fb83e84a54104a8L)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.Long:464227443377968367 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb41\uddc2\ud842\udc38\uda08\udf0c\ud95d\udd47\udbe4\udeed\ud8a1\udc91\ud9f0\udf1c\ud90b\udf31\ud8b6\ude5b\ud9aa\uddd2\ud83d\ude24\u2554\uda4c\udce4\udba2\udd10", "\uca45\u4710\u2d42\u6144\ucb9e\u3568\u833d\u139e\u5670\u57b2\u50ed\u5dad\ub390\u7ecc\ucf64\u92e4\u1298\u48f8\u35a2", "\ud997\udf1c\ud92f\udfff\ud8ff\udf3d\ud8e8\udc2e\udb84\udf3b\ud9f6\udea3\ud991\uddb4\udbd1\udcea\udadd\udc6c\ud884\udece\udbc1\ude6a\ud8e1\udee0",
        30, 42071, 1349670026, 464227443349168367L, -62970L, true, false, (char) 6510, (char) 15213,
        Double.longBitsToDouble(0x3f6d03edf0504000L), Double.longBitsToDouble(0x3fe9f699670e1887L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 7, "\ud88a\udc73\udb89\udc71\udb70\ude12\udb04\uddc8\u9fb3\ud8a1\udc68\ud9df\udd1c", "\u5b31\u1240\u1167\u7559\u3bf7\ucb28\u062d\u85ef\ucb70\u8818\u91f0\ucb9e\u3568\u833d\uc85c\u8a9c", "\udacc\udd08\ud91b\ude60\ud915\udd34\udb46\udd86\ud88b\udc86\ud9f3\udef2\udb86\udee5\udb6a\udde0\uda2f\udf62\udb79\udcdd\udbce\udddc\udb8c\uddac\ud8d7\udd3a\udab1\udf26\ud890\udcac\ud88d\udfd5\ud849\uddee",
        37, 98889, -12650454, 6457545451512854164L, -41099L, false, true, (char) 47249, (char) 39840,
        Double.longBitsToDouble(0x3fe28c680287e21bL), Double.longBitsToDouble(0x3fee4af725c622a8L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=java.lang.Long:321225444696380120 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\uda84\udd79\ud9df\udd1c\ud90b\udf31\udad9\uddac\ud8ab\udeb4\ud828\udcc3\uda4d\udd55\udb5d\udee5\ud8a0\uddee\ud8e1\udcae\udad1\udeed\udb85\udcae\ud85b\ude9c\ud871\udcd0\ud89c\udd01\ud917\udee7\uda3d\ude58\ud981\udd55\udb0c\ude6b\udb65\udf22", "\u07ac\ub390\u18d5\u5765\u2aa8\u7fc0\u48f8\u35a2\ub126\uad3c\u2fde\uc6a6\ub0d5\u0f16\u5e2a\u2a66\u32a7\ud333\u5581\u2f45\u5f62\u3c6d\u5096\u4913\u4722\u578c\u775c\u8a5b\u12fe\u26dc\u704b\u0ccf\ucd08\u37d0\uc339\u5930\u1b8d\u1ad4\u949e\ubd2c\u9749\u44f0\u335f\u7043\u42d1\u3092\u8010\ua428\u063c", "\ud926\ude0f",
        9, 56787, -760131769, 321225444667580120L, 59264L, false, true, (char) 22136, (char) 63772,
        Double.longBitsToDouble(0x3fb965a268948630L), Double.longBitsToDouble(0x3fd31206f39069e2L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=java.lang.Long:6148856712050199421 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 6, 6, "\udb19\ude5c\ud8a3\udcb2\udb70\ude12\ud95d\udd47\udb41\udcba\ud8a1\udd11\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\u9cba\ud8a3\udc34\udb5d\udee5\uda94\udce8", "\uca45\u4710\u8818", "\udb37\udc75\udb12\udf5f\udb0c\ude9e\udb65\udf22\uf6d5\udbcc\uddb5\udacc\udd08\ud91b\ude60\udb86\udf33\udb46\udd86\u6cef",
        15, 47185, -1403428665, 6148856712024999421L, 61225L, false, true, (char) 27153, (char) 10449,
        Double.longBitsToDouble(0x3fe46cbbaea98a8cL), Double.longBitsToDouble(0x3fd22aa2e8b3ba42L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-00:00:00.004\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 8, 6, "\u009b\udb27\uddf8\ud9e7\udfab\ud95d\udd3e\ubdc3\ud8a1\udc68\ud9df\udd1c\u7995\ud8ef\ude6c\ud830\udf21\uda7d\uddf9\ue65c\udb1f\udeef\udbed\udd31", "\u48b0\u5ed0\ud1af\u3be8", "\udb39\udd31\udb1e\udff6\ud8d0\udc02",
        -4, -748, -1638741504, 1774816096104540631L, -91087L, false, false, (char) 18723, (char) 63947,
        Double.longBitsToDouble(0x3fad525a6f4338f0L), Double.longBitsToDouble(0x3fe1229532544cd1L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 10, 10, 15, "\ud984\udc0f\udb62\udd71\uda31\udc4e\udac9\ude11\ud938\ude23\ud8a1\udc68\ud9df\udd1c", "\u3518\u222a\u9ee5\u46c1\u382c\u93d1\u47f3\u1cb5\ud44c\u8818\u3cda\u1bb1\u3568\u7403\u4977\ucb19", "\uda09\udc71\ud99e\udfb9\udb12\udd29\uda29\udf48\udb09\udddf",
        23, 74521, 1918460103, -5789699087746031991L, -82222L, true, true, (char) 65037, (char) 8278,
        Double.longBitsToDouble(0x3fe5ef872d7cba34L), Double.longBitsToDouble(0x3fd3554caf9568daL)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\0121=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 2, 10, 10, 15, "\ud88a\udc12\udb4b\ude72\000\udac9\ude11\ud938\ude23\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\uf064\000\000\000", "", "\ua8c8\uda1c\ude32\udb20\udd28\ud875\udde8\ud8af\udee8\uda3d\ude58\ud8d5\udd5f\udacb\ude4a\ud952\udf52\udba2\ude3f\ud82f\ude40",
        43, 37743, -948833153, 725983780096L, 32301L, true, false, (char) 19892, (char) 20015,
        Double.longBitsToDouble(0x3fecaeb3f0c6a511L), Double.longBitsToDouble(0x3fefbfdfe53534dfL)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=org.joda.time.tz.ZoneInfoProvider:@?\0121=org.joda.time.tz.ZoneInfoProvider:@?\012",
        Z.run(T, 2, 15, 15, 13, "\000", "\u5d74\u643d\u0606\u06c8\ud30f\u5541\u2369", "\ud9cc\udcdb",
        7, 85498, 584640224, -6023040967947260454L, -97341L, false, true, (char) 13282, (char) 68,
        Double.longBitsToDouble(0x3e2449d9e0000000L), Double.longBitsToDouble(0x3fe166deedfcc754L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=java.lang.Long:4690590722614597787 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 1, "\ud88a\udc9c\udb89\udc71\ud913\udd2b", "\u0606\u488e\ud355\u5541\u584a\u715a\u11ac\u7559\u3b07\ucb28\u062d\uca45", "\udb16\udc65\ud98d\udee4\uda37\udd81\ud981\udd55\udb0c\ude6b\udb65\udf22\uf6d5\udbcc\uddb5\udacc\udd08\ud91b\ude60\udb86\udf33\uda27\udec1\ud837\udc8c\ud9f6\ude29\udb86\udee5\ud921\udecb\udbbd\udc04\udb4d\uddb6\udac8\udc04",
        5, 89978, 1079803127, 4690590722585797787L, -30064L, true, false, (char) 59851, (char) 38269,
        Double.longBitsToDouble(0x3fdf097912567de6L), Double.longBitsToDouble(0x3fc243f9eeb618e0L)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=java.lang.Long:2240105927126505406 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 0, 0, "\000", "\u7c91\u2a7f\u7e43\ua8d3\u742c!\000\000", "\udba2\udd10\ud8d8\uddf2\000\udae5\udf3d\udb78\udde8\ud92f\udceb\udb40\udd5e\uda1d\udec2\ud875\uded2\ud962\udfa8\uda12\ude6e\udbee\udf8a\uf6d5\udbcc\udcb9\ud99e\ude73\ud824\udf19\000\udaa4\udfb2\uaeb7\000\udb8b\udc85\udbfa\udfd8\uda2f\udf62\ud9c2\udc07\udb2a\udcb5\udba5\ude8c\udb0e\udd61",
        10, 33617, -655488136, 2240105927097705406L, 89908L, true, true, (char) 51864, (char) 22660,
        Double.longBitsToDouble(0x3fef117cf0f40dc6L), Double.longBitsToDouble(0x3fef98081772eb40L)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=java.lang.Long:2411447254981280742 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 4, 6, "\ud8f1\udc04\udbbb\udc48\udb97\udc1d", "\u0645\u488e\ud355\u5541\u8b1f\ud4b9\ubf62\u9d2a\u0884\u9630\ub21c", "\udb20\udd28\ud89c\udd6c\ud917\udee7\ud8ad\udccf\udbc2\udc38\uaf1c\udb65\udf22\uf6d5\udbcc\uddb5\udbe4\udc34\ud91b\ude8a\udb86\udf33\udb46\udd86\u6cef\ud9f6\ude29\udad4\udd6c",
        41, 47609, 60354690, 2411447254956080742L, 6186L, true, true, (char) 49603, (char) 9075,
        Double.longBitsToDouble(0x3fe12d0187c80b11L), Double.longBitsToDouble(0x3feed42126f036c3L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=java.lang.Long:7730272152996490785 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ud817\udcb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\uda79\ude22\ud9c5\udd51\udb5d\udee5\udba2\udd10\udb21\udd04\udad1\udeed\udad2\udf3d\uda7c\udec8\udb21\udf95\ud885\uddf9\ud917\udee7\uda3d\ude58\ud981\udd55\udb0c\ude6b", "\u7e68\u4369\ub0c3\u7f41\ucf64\u92e4\u1298\u48f8\u35a2\ub126\uc6f7\u5a1c\u7f01\u0a61\u5cb2\u97bb\u2286\u6260\ud271\ub9cd\u579f\u7ffd\u9ad8\u40c4\u9e27\u8636\u9b47\ua84b\uc2cb\u0fdf\u155e\u495c\uc857", "\ud94f\uddfa\ud82f\ude76\uda0f\udcfc\udbb2\udc75\ud811\udd34\uda06\udc39\uda42\udd47\ud94f\udd20\ud8ec\udc33\ud960\udc35\ue0f6\ud82f\udf90\ud8d3\udf17\ud80c\udd96\uda07\udcd2",
        14, 25389, -1346060328, 7730272152967690785L, -50527L, true, true, (char) 27440, (char) 43602,
        Double.longBitsToDouble(0x3fe83c21373c885bL), Double.longBitsToDouble(0x3fe937ec76a10bacL)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-01:00\0121=org.joda.time.tz.FixedDateTimeZone:-01:00\012",
        Z.run(T, 2, 7, 7, 14, "\ud873\ude17", "\u9ed6\u0b1a", "\ud90b\udf40\ud8b6\ude5b\udb7c\udfdc\ud99b\udde3\ud995\udc98\ud917\ude67",
        -1, 86946, 2090988186, 3790128629651664375L, 28867L, false, true, (char) 41025, (char) 62164,
        Double.longBitsToDouble(0x3fd3cf21a18c34eeL), Double.longBitsToDouble(0x3fb2eaa14971b8e0L)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=java.lang.Long:8324691512192775235 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 15, 11, "\udb28\udc91\ufe4d\udaf5\ude8a\udacd\udd14\ud9c0\udffa\ud894\udc3d\000\ud8e0\ude4f\ud8b6\ude5b\000\udaf2\udce0\ud9b5\ude69\u5a74\ud9a8\udf39\ud8a7\udc29\udad1\udeed\ud930\udf98\u8e80\uda64\udd2a\ud89c\udd6c\u5c25\uda8f\udc9d\ud952\udfa8\ud89e\ude21", "\u50ed\u5dad\ucb72\u8a60\uaa6c\u2b73\ub306\000\u23f8\u45fb\u4199\u8473\u72a2\u1e3a\u4463\u9514\u09b1\ub106", "\uda63\udfb5\ud999\udede\udb23\udce8\ud914\udf67\ud901\udec2\udbad\udd56\ud851\uddfa\ud9e8\udf68\udb84\udebf\udb23\udfde\ud944\udff2\ud83f\udc4e",
        -1, 81234, -291010893, 8324691512167575235L, -23978L, false, false, (char) 11809, (char) 35066,
        Double.longBitsToDouble(0x3f3166da50000000L), Double.longBitsToDouble(0x3fddf4690bebb3b8L)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=java.lang.Long:1074164192516196809 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 11, "\ud88a\udc73\udb89\udc71\ud88d\ude60\ud942\udefe", "\u0ce3\u41d0\u94f0\u5b31\u1240", "\ud8d7\udfa5\ud9e9\udc6d\udad1\ude85\udae5\udf3d\ud929\uddbf\udb20\udd28\ud89c\udd6c\ud917\udee7\udad1\udda2\ud91c\ude8d\uda75\udc20\udb65\udf38\uf6d5\udbcc\uddb5\udacc\udd08\udab3\udf2d\ud986\udd75\udb54\udebb\u6cef\ud9f6\ude29\udb86\udea3\ud8aa\udf86\uc1e9\udb4d\uddb6\ub962\ud9a0\udf06\ud830\udf89",
        21, 27624, -696155381, 1074164192490996809L, -79134L, false, true, (char) 35390, (char) 21028,
        Double.longBitsToDouble(0x3fea5f48da4277bdL), Double.longBitsToDouble(0x3fef6ba528c99c24L)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=java.lang.Long:2607035676983843171 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 12, "\ud958\udd3d\uda1c\uddbb\ud869\ude2f\ud95d\udce7\ubd8f\ud8a1\udc68\ud9df\udd1c\ud880\udeca\ud856\ude60\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb06\udff9\ud8b9\ude1c", "\uca45\u273c\u8818\ubd2f\u3b62\ub7b7\u833d\u7bbd\u464e\u0adf\u50ed\u5dad\u48bc\u7eac\ub2c2\ucabb\u47ae\u48f8\u990c\ub126\uc6f7", "\ud999\udf32\ud877\udd1e\udac3\udd23\ud929\udd68\ud93a\udf3a",
        43, 82334, -982454176, 2607035676955043171L, -52179L, false, false, (char) 8547, (char) 35526,
        Double.longBitsToDouble(0x3fe3554911739ce1L), Double.longBitsToDouble(0x3fedebfcb901f6d6L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=java.lang.Long:8625170343731466829 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 15, 6, "\ud88a\udc73\udb89\udc71\udb64\udeda\uda4e\udd2a\ubd83\ud913\udf70\udb94\udf57\uda1d\udd05\ud8b6\ude5b\ud9e2\uddce\uda1b\ude13\uda4d\udd55\udb5d\udee5\ud8b6\udd1a", "\u1061\u4642\u8818", "\udb90\udc56\u8f2d\uda32\udd05",
        50, 95038, 493932566, 8625170343706266829L, -66675L, true, false, (char) 31468, (char) 48420,
        Double.longBitsToDouble(0x3fe10b638cbcaca8L), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=java.lang.Long:9050580350249459236 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:9050580350249459236 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 2, 10, "\udbae\ude17\udb1e\udcff\udb70\ude12\ud95d\udd47\ubdb3\uda46\ude37\udac5\uddef\ud8f6\udeb2\ud8b6\ude5b\udaa3\uddcb\ud83d\ude24\udbb1\udfc5\ud91f\udea6\udba0\udd88\ud8f3\udedf\uda7f\udf26\u33e3\uda7c\udf96\ud8a2\udcbb\ud89c\udd6c", "\u6c65\u1d9c", "\ud804\udc19\ud99c\udc6a\udadd\ude41\udb89\udd5f\udb46\udd86\uda61\uddcd\ud9f6\ude29",
        41, 25383, -689640260, 9050580350220659236L, 56476L, false, true, (char) 4148, (char) 37949,
        Double.longBitsToDouble(0x3fbafc4f3f339bf0L), Double.longBitsToDouble(0x3f9496bebf13c520L)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=java.lang.Long:5146391 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 0, 6, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud9a7\udedb\uda80\udf4d\udad1\udeed\ud9d5\udcf0\ud8b5\udd99\ud891\ude22\ud89c\udd6c\ud917\udee7\ud8ad\udccfS\uaf1c\ua144\000\u2986\u1bae\ud91b\ude8a\udb86\udf33\udb46\udd86\udac3\udec2\udb67\ude1d\ud9a6\udff5\u00bf\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud909\ude89\uea52\ud801\udf85\000\ud841\ude5f\ud8d3\udf27\udb26\udd16\udbc5\udfe1\udac5\udc98", "\ud730p\000\000\u7da0\u8f36\u009e\ud5d1\ua0a0\u1e81\ucdde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\ud945\uded4\ud9af\udde0\ud9da\udee0\ud960\udfa4\udab3\udcc3",
        16, 86835, 254, -23653609L, 40454L, true, true, (char) 9422, (char) 12817,
        Double.longBitsToDouble(0x3fd9c78fb7a66e76L), Double.longBitsToDouble(0x3fec7f4645b533e5L)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\0121=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 2, 9, 5, 0, "\udbb6\ude7e\ud9ae\udf5d\ud9e7\udfab\ud95d\udd3e\ud824\udcc3\ud8a1\udc68\ud9df\udd1c\u7995\ud8ef\ude6c\ud830\udf21\ud82d\uddf1\udb64\uded2\udaf3\udefd\ud8a4\ude3e\ud99e\udf18\udab7\udd61\ud965\udf25\uda33\udef4\ud9f6\udce2\udad8\ude8a\udbc3\udd14\ud808\uded5\udb47\udc31\udb1f\udc14\uda55\udff4\udaaa\udcca", "\u2f07\u48e6\u4c65\u40d4\u3baa\u944b\u365a", "\ud9b4\udc2e\ud995\udf94\ud962\udd89\ud99c\udd42\udbea\ude11\ud910\udf50\ud8a6\udef5",
        0, 74069, 2090751750, 4841003715228719264L, -17026L, true, true, (char) 30316, (char) 4334,
        Double.longBitsToDouble(0x3fd4f420cc2390f8L), Double.longBitsToDouble(0x3fd30295ead0afceL)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 6, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud9a7\udedb\uda80\udf4d\ud944\udf1f\ud9de\udd27\ud9b8\udddc\udad5\udc71\ud89c\udd58\ud917\udee7\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\000\uda74\udd8b\ud945\ude97\u1106\udb86\udf78\udb46\udd86\udac3\udec2\udb67\ude1d\ud965\udffa\u0098\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\ub4bb\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\ud730p\000\000\u2222\u3259\u009e\ud5d1\ua0a0\u1e81\u7cde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, 22050, 816241551, 7185796056498569470L, -39351L, true, true, (char) 24149, (char) 37045,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x3fd1778fb7a66e76L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 12, 6, "\udb11\udccd\udbbb\udcbf\udabe\udc10\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud9cc\ude18\ud849\udd05\u6943\ud9a7\udedb\uda80\udf4d\ud944\udf1f\ud9de\udd27\ud9b8\udddc\udb8d\udc0d\ud90a\udcc3\ud917\udec8\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\000\udaf2\udfaa\ud945\ude97\u1106\udb86\udf78\udb46\udd86\udac3\udec2\udb67\ude1d\ud965\udffa\u0098\u00bc\udb4d\udd8d\u0095\uef1d\ud929\udfde\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\ub4bb\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ud8ce\udf3e\udaef\udfaf", "\ud730\ucd2d\u9750\000\u2222\u3259\u009e\ud5d1\ua0a0\u1e81\u7cde\ud3b0\u98da", "\udb67\udd78\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\ud989\udfd7\ud9af\udde7\ud9da\udee0",
        54, 21848, 816241551, 7185796056498569470L, -39351L, true, true, (char) 24149, (char) 37045,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x3fd1778fb7a66e76L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 0, 0, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8ae\udff7\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud9a7\udedb\uda80\udf4d\ud944\udf1f\ud9de\udd27\ud9b8\udddc\udad5\udc71\ud89c\udd58\ud917\udee7\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\000\ud86e\udc07\uda57\ude8a\u1106\udb86\udf78\udb46\udd86\udac3\udec2\udb67\ude1d\ud965\udffa\u0098\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\ub4bb\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\ud730p\000\000\u2222\u3259\u009e\ud5d1\ua0a0\u1e81\u7cde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, 22050, 816241551, 7185796056498569470L, -39351L, true, true, (char) 24149, (char) 37045,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=java.lang.Long:7185796056527369470 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 0, 6, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud9a7\udedb\uda80\udf4d\ud944\udf1f\ud9de\udd27\uda1a\udc0c\000\ud89c\udd58\ud917\udee7\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\000\000\000\u1106\u66a2\u7dd3\udac3\udec2\udb67\ude1d\ud965\udffa\u0098\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\000\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\ud730p\000\000\u2222\u3259\u009e\ud5d1\ua0a0\u5568\u7cde\ub010\u98da", "\000\udad1\uddc8\ud874\udc63\ud9e1\ude2c\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, -782, 816241551, 7185796056498569470L, -95113L, false, false, (char) 0, (char) 36811,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x3fd1778fb7a66e76L)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 0, 0, "\udb9e\udf53\ud9ca\ude1d\udb97\udd0e\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8ae\udff7\ud9e2\uddce\ud851\udf79\u2d67\u68bb\ud9a7\udedb\uda80\udf4d\ud944\udf1f\ud9de\udd27\ud9b8\udddc\udad5\udc71\ud89c\udd58\ud917\udee7\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\ud80c\udec5\ud86e\udc07\uda57\ude8a\uda94\udf0d\udba6\udc8e\udb46\udd86\udac3\udec2\udb67\ude30\ud965\udffa\u0098\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\ub4bb\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\ud730p\000\000\u2222\u3259\u009e\ud5d1\ua0a0\u1e81\u7cde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, 22050, 816241551, 7185796056511392057L, -39351L, true, true, (char) 24149, (char) 37045,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 0, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8ae\udff7\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud9a7\udedb\uda80\udf4d\ud944\udf1f\ud9de\udd27\ud9b8\udddc\udad5\udc71\ud89c\udd58\ud917\udee7\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\000\ud86e\udc07\udb20\udd42\ud9d4\udde8\udb86\udf78\udb46\udd86\udac3\udec2\udb67\ude1d\ud965\udffa\u0098\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda18\udc42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\ub4bb\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\u7cd1^\000\u338e\u310a\u3259\u009e\ua6de\ua0a0\u1e81\u7cde\ub057\u98da", "\ud857\udd35\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, 22050, 816241551, 7185796056498569470L, -39351L, true, true, (char) 24149, (char) 37045,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x3fc92eb660000000L)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 0, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8ae\udff7\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud9a7\udedb\uda80\udf4d\ud944\udf1f\udbac\udc23\ud9b8\udddc\udad5\udc71\ud89c\udd58\ud917\udee7\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\000\ud86e\udc07\udb20\udd42\ud9d4\udde8\udb86\udf78\udb46\udd86\udac3\udec2\udb67\ude1d\ud965\udffa\u0098\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda18\udc42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\ub4bb\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\u7cd1^\000\u338e\u310a\u3259\u009e\ua6de\ua0a0\u2080\u7cde\ub057\u98da", "\ud857\udd35\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, 22050, 816241551, 7185796056498569470L, -39351L, true, true, (char) 24149, (char) 37045,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x3fc92eb660000000L)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=java.lang.Long:1782225002298955645 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb1b\udf1f\udb89\udc71\udbb2\ude0d\ud95d\udd47\ud986\uddde\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud939\udfe4\udaf3\udc72\uda4d\udd55\udb5d\udee5\udba2\udd10", "\u5dd3\u1898\ua5ad", "\ud9b9\udc01\ud981\udd55\udb0c\ude6b\udb65\udf22\uf6d5\ud9fa\udfac\udacc\udd08\ud91b\ude60\udb86\udf33\udb46\udd86\ud844\udfa3\uda43\ude27\ud8da\udd44\udbe7\ude57\uda2f\udf62\udb4d\uddb6",
        18, 28283, 747530301, 1782225002270155645L, -92300L, true, false, (char) 19345, (char) 17071,
        Double.longBitsToDouble(0x3fe6f674e02cc210L), Double.longBitsToDouble(0x3fba7eac1480aba8L)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=java.lang.Long:1339620830264400501 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb4d\uddee\udb72\udd10\udad5\ude23\ud9c5\udcaf\ubdb3\uda61\udc68\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udabc\udca6\uda57\ude76\uda4d\udd12\udb5d\udee5\udba2\udd10", "\u3962\u732a\u8818", "\uda1e\ude8b\ud981\udd55\udb7b\udd61",
        58, 60276, 1060855292, 1339620830239200501L, -81842L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fef9c23b4bcd19bL), Double.longBitsToDouble(0x3fa4d29d795d67e0L)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\udb2b\udc77\ud9e2\uddfd\ud83d\ude24\udaae\udf85\uda64\udd2c\udab0\udfea", "\u239a\u66f5\u8818\u74e5\u789e\u3568\u833d\u53a6\u5670\u6960\ubec7\u5dad\ub390\u7ecc\ucf64\u92e4\u4ebd\u5df8\u358e\ub126\u3e11\u7c64", "\ud8c4\udf0f\ud87e\udd66",
        59, 89537, -1854609025, 7590207515853835069L, 27832L, true, false, (char) 18537, (char) 60227,
        Double.longBitsToDouble(0x3fc86e23e8507c08L), Double.longBitsToDouble(0x3fd7efbb2ea86c2aL)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\0121=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 2, 7, 7, 6, "\udae5\uddf4\ud880\ude3d\udab2\udc33\ud9ba\udcde\uda0f\udc04\ud836\udca7\ud99a\uded2\ud95f\udce2\ud9db\ude60", "\u7c1b\u7559\uc4f9\u0280\u0624\u1288\ud5c4\u87dd\u333e", "\ud92a\ude07\ud83e\udc11\uda26\udc6a\u82a4\udb08\udcd0\ud9a0\udfa1\uda76\udd46\udbc2\udcbc\uda07\udc4e\udb76\udf59\udacf\udeff\ud86c\udead\ud96e\udd89\u94e4\udb91\udc65\ud9b8\udcb4\ue119",
        0, 88962, 705087231, -7087541729513778020L, -49076L, true, true, (char) 56412, (char) 29135,
        Double.longBitsToDouble(0x3fdbdb7534986302L), Double.longBitsToDouble(0x3f7cd13f99e6dc80L)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=java.lang.Long:1542324396687209539 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 15, 11, "\udb28\udc91\ufe4d\udaf5\ude8a\udacd\udd14\ud9c0\udffa\ud894\udc3d\000\ud8e0\ude4f\ud8b6\ude5b\000\udaf2\udce0\udbf5\ude69\u5b4a\ud9a8\udf39\ud8a7\udc29\udad1\udeed\ud930\udf98\u8e80\ud8c4\uddcd\ud88e\udce4\u5c25\uda8f\udc9d\ud952\udfa8\ud8b2\udc9c", "\u50ed\u5dad\ucb72\u8a60\uaa6c\u2b73\ub306\000\u23f8\u45fb\u4199\u8473\u72a2\u1e3a\u4463\u9514\u09b1\ub106", "\uda63\udfb5\u1c93\udbda\udc18\udb42\udd5e\ud918\udf01\udbad\udd56\ud851\uddfa\ud9e8\udf68\udb84\udebf\udb23\udfde\ud944\udff2\u04b0",
        33, 51799, 13097746, 1542324396662009539L, -23978L, false, false, (char) 11809, (char) 35066,
        Double.longBitsToDouble(0x3f3166da50000000L), Double.longBitsToDouble(0x3fddf4690bebb3b8L)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=java.lang.Long:1665583179641004043 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud908\ude92\ud9b2\udfd0\udb70\ude12\ud95d\udd47\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\ud8b8\ude25\uda8b\udfc1\udb68\udc5f\ud81c\ude52\ud978\udf1e\udb11\udfaf", "\u7070\u4710\ua294\u0f9c\u7b85\u3532\u3838\ucb5b\u5cfa\uaf01\u50ed\u5dad\u0884\u92c7\u6898\ub58f\u99ab\u48f8\u35a2\ub126\uc6f7\u9f08\ubf11\u0eda\u71e9\u05eb\u5887", "\udb76\udd75\udaa0\udccb\ud808\udf3c\uda5a\uddf7\ud8bd\udf16\u2f08",
        55, 75246, 1065044564, 1665583179612204043L, -42274L, false, true, (char) 11168, (char) 43369,
        Double.longBitsToDouble(0x3fe4a193397cfacdL), Double.longBitsToDouble(0x3fec504e12c1109bL)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=java.lang.Long:7492032112380255366 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 4, 0, "\udb83\ude49\udb47\udcfd\ud8ae\udd98\ud970\udd61\ud93b\udc2a\ud938\udedb\udaaf\udd8b\udb42\ude82\ud8cb\udd18\ud9e2\uddce\ud83d\ude24\uda4d\udd55\udb5d\udee5\udae4\udd11\ud8d8\uddf2", "\u7f8a\u98a6\u0f50\u546d\u36e9\u0a53\uabd5\u469f\uaf01\u50ed\u0d8b\u1d5f", "\u6cef\udbed\udc56\udbef\ude2e\uce81\uda2f\udf62\udb4d\uddb6\ud9ad\udc08\ud98c\udda6\uda63\udc0c\ud9f2\udc9f\udb5f\udd5f\ud958\udc5b\u4055",
        33, 17143, -2108616072, 7492032112355055366L, -28953L, false, false, (char) 36582, (char) 19644,
        Double.longBitsToDouble(0x3fd5101797bbded0L), Double.longBitsToDouble(0x3fd188adbfc6c74cL)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 0, "\udb9e\udf53\ud9ca\ude1d\udb97\udd0e\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\udb8a\uddb1\ud93a\ude3b\uda22\udc0b\ud851\udf79\u2d67\u68bb\ud9a7\udedb\uda80\udf4d\ud944\udf1f\ud9de\udd27\ud9b8\udddc\udad5\udc71\ud85f\ude1a\ud917\ude40\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\ud80c\udec5\ud86e\udc07\uda57\ude8a\uda94\udf0d\udba6\udc8e\udb46\udd86\udac3\udec2\ud8ec\udd32\ud9ff\ude9f\ud995\udc9d\u00bc\udb4d\udd8d\u0095\ud8e5\udc92\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud966\udf38\uda9b\ude8c\uda50\udca1\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\ud730p\000\000\u2222\u3259\u009e\ud5d1\ua0a0\u1045\u7cde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\udb1e\udc58\ud9e1\ude2c\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, 59554, 744865853, 7185796056511392057L, -39351L, true, true, (char) 24149, (char) 37045,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x3fc7000000000000L)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=java.lang.Long:5020633974305873989 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:5020633974363473989 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\ud8de\udd41\udacd\udd3d\ud9c0\udffa\ud894\udc3d\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb64\udc43\udaf2\udce0\ud9b5\ude69\ud894\udc85\uda7c\uddf8\ud8b1\udfff\ud9e8\udf3d\ud8c3\udfc8\udad9\udc32\udb36\udd44\ud89c\uddc2\ud917\udee7\uda3d\ude58\ue84e\udb0c\ude59", "\u7e13\u4c63\ub390\u7ecc\u6954\u8da5\ua56d\u991b\u84bf\ub126\uc6f7\u845b\u72a2\ud685\ud74b\u9071\u94cc\u5f2c\u97dd\u10fb\u2844\u30d5\u1d27\u94bc\u6e30\u4650\ub345\u37a5\ua7a4\u74e1\u53d0\uc911\u160c", "\ud887\udfad\ud8d8\udd11\udad6\udd4c\udb6c\udc1f\ud882\udd9a\ud9ca\ude5b\ud8dd\udd38\ud845\udc7b",
        31, 59383, -1232206347, 5020633974334673989L, -33783L, false, false, (char) 10665, (char) 12487,
        Double.longBitsToDouble(0x3fe04ff278f7d254L), Double.longBitsToDouble(0x3fe0a0e5fff1213cL)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=java.lang.Long:1224645094247014184 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 2, 6, "\ud81a\udefb\ud990\udc2a\ud83e\ude38\ud9c4\udffb\u8f72\ud81c\uddc5\udb0b\udf43\u00d8\uda70\udf5f\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud923\ude07\udba2\udd10", "\ud440\u412f\u8818\u4dc7z\u0723\u7aa6\u38bb\u00ba\u04d5\u791f\u44c9\ub38d]\u5191\u92e4\ub306\000\u34db\u63be\u3a33\ubdc3\ud2e9\u40a1\u90b6", "\ud8ec\udf6b\ud901\udd65\ud94b\udf94\uda88\udd6a\ud8a1\udc3f\udbbd\udd32\ud9ad\udfca\u1676\udb82\udd0d",
        23, 27101, 1520554686, 1224645094218214184L, 44135L, false, false, (char) 30731, (char) 5265,
        Double.longBitsToDouble(0x3fee75181ba527e5L), Double.longBitsToDouble(0x3fe0abbcc0ba2b2aL)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:6977712132118650130 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 6, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud95d\udd47\uda99\udff9\udb2a\udfb2\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udda0\ud84e\udfb5\udba2\udc8e\udb0b\udcfb\ud9fb\udfaa\udae5\udf3d\uda7c\udf96\ud8ff\ude18", "\u3568\u833d\u139e\u5670\uaf01\u50ed\u5dad\ubda2\u126d\ua09a\u8f1a\ud5d9\u48f8\u35a2\ub126\uc6f7\u2cc8", "\ud8a7\udcc7\udb17\udc4c\ud9a8\udd2f\udbe1\uddd4\ud941\uddac\uda74\udc6b\ud957\udef1",
        50, 53771, -1344366445, 6977712132147450130L, -71263L, false, false, (char) 17692, (char) 24784,
        Double.longBitsToDouble(0x3fd3283e22b99f1cL), Double.longBitsToDouble(0x3fd5eff44e0aea2aL)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=java.util.TreeSet:[Africa/Abidjan, Africa/Accra, Africa/Addis_Ababa, Africa/Algiers, Africa/Asmara, Africa/Asmera, Africa/Bamako, Africa/Bangui, Africa/Banjul, Africa/Bissau, Africa/Blantyre, Africa/Brazzaville, Africa/Bujumbura, Africa/Cairo, Africa/Casablanca, Africa/Ceuta, Africa/Conakry, Africa/Dakar, Africa/Dar_...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 8, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8b6\ude02\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud85b\ude36\uda80\udf4d\ud944\udf1f\ud9de\udd27\ud9b8\udddc\udad5\udc71\ud89c\udd58\ud917\udee7\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\000\uda74\udd8b\ud945\ude97\u1106\udb86\udf78\udb46\udd86\udac3\udec2\udb67\ude1d\ud965\udffa\u0098\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\ub4bb\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\ud730p\000\000\u2222\u3259\u009e\u8e7c\ua0a0\u1e81\u7cde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, 22050, 816241551, 7185796056498632458L, 19454L, true, true, (char) 24049, (char) 37045,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x3fd1778fb7a66e76L)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=java.lang.Long:755316491095235900 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\ud8b9\ude76", "\uaebe\ua183\u0606\u488e\ud355\u5541\u5b31\u5911\u7a4a\u7559\u3bf7\ucb28\u062d\uca45\u4710\u8818\u6155\ucb9e\u3568\u833d\u139e\u4cb0\u10e8\u50ed\u5dad\ub390\u3092\u4f41\u92e4\u0376\u577c\ud198\ucf04\u78f1\u7ed8\u0151\uaca9\ud55c\u2298\u53c8\u61d8\u6a97\u11a7\uca61\uaa54", "\ud9cb\udc23\ud8ea\uddb3\ud888\udf43\ub7f0\ua03b\uda22\udc4c\ud81e\udc5b\udbc3\udf13\ud8fe\udc78\ud91c\udc6f",
        49, 10196, 1931664626, 755316491070035900L, 1428L, true, false, (char) 25671, (char) 33377,
        Double.longBitsToDouble(0x3fe48d943c7fd825L), Double.longBitsToDouble(0x3fe82070ed225afbL)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=java.lang.Long:5020633976490512069 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:5020633976540912069 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\ud8de\udd41\udacd\udd3d\ud9c0\udffa\ud91c\udd01\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb64\udca7\udaf2\udce0\ud9b5\ude69\ud894\udc85\uda7c\uddf8\ud8b1\udfff\ud9e8\udf3d\ud8c3\udfc8\udad9\udc32\uda39\udd06\ud8d4\uded7\ud917\udee7\uda3d\ude58\ud93c\udc0f\udb16\ude92", "\u7e13\u4c63\u2d48\u7ecc\u60bd\u9511\ua4f5\u991b\u25ef\ub0fc\uc6f7\u845b\u788e\u5c27\u9f46\u100a\u8b6f\u4a32\u97dd\u10fb\u2844\u30d5\u1d27\u94bc\u929f\u46b5\ub345\u37a5\ua7a4\u74e1\u53d0\uc911\u160c", "\ud887\udfad\u37ac\udae2\udd03\ud936\udc32\ud885\udc6a\ud9ca\ude5b\ud8dd\udd38\udb25\uddca",
        52, 30671, -1232206347, 5020633976515712069L, 71023L, false, false, (char) 10665, (char) 12487,
        Double.longBitsToDouble(0x3fe04ff278f7d254L), Double.longBitsToDouble(0x3fe0a0e5fff1213cL)));
  }
  @Test(timeout = 4000)
  public void test177() throws Throwable {
    assertEquals("0=java.lang.Long:5020662561608196165 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:5020662561665796165 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\ud8de\udd41\udacd\udd3d\ud9c0\udffa\ud894\udc3d\ud935\uddfc\ud90b\udf31\ud8b6\ude5b\udb64\udc43\udaf2\udce0\ud9b5\ude69\ud894\udc85\uda7c\uddf8\ud8b1\udfff\ud9e8\udf3d\ud8c3\udfc8\udad9\udc32\udb36\udd44\ud89c\uddc2\udbd7\udd7d\udb9b\udde3\ue84e\udb0c\ude59", "\u6a85\u1b96\ub390\u7ecc\u6954\u8da5\u0faf\u988d\u84bf\ub126\uc6f7\u845b\uc76b\ud685\ud74b\u9071\u9d91\u8adb\u97dd\u10fb\u2844\u30d5\u1d27\u94bc\u6e30\u41e9\ub345\u37a5\ua7a4\u65c4\u06a3\uc8f3\u160c", "\ud887\udfad\ud9bc\udda2\uda28\ude15\ud973\ude4a\ud962\udf85\ud9c6\udf79\ud8dd\udd38\ud845\udc7b",
        31, 59383, -1232206347, 5020662561636996165L, -33783L, false, false, (char) 10688, (char) 12487,
        Double.longBitsToDouble(0x3fe04ff278f7d254L), Double.longBitsToDouble(0x3fe0a0e5ff598d15L)));
  }
  @Test(timeout = 4000)
  public void test178() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+54:00\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 1, 8, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8b6\ude02\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud85b\ude36\uda80\udf4d\ud944\udf1f\ud9de\udd27\ud9b8\udddc\udad5\udc71\ud89c\udd58\ud917\udee7\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\000\uda74\udd8b\ud945\ude97\u1106\udb86\udf78\udb46\udd86\udac3\udec2\udb67\ude1d\ud965\udffa\u0098\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\ub4bb\000\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\ud730p\000\000\u2222\u3259\u009e\u8e7c\ua0a0\u1e81\u7cde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, 22050, 816241551, 7185796056498632458L, 19454L, true, true, (char) 24049, (char) 37045,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x3fd1778fb7a66e76L)));
  }
  @Test(timeout = 4000)
  public void test179() throws Throwable {
    assertEquals("0=java.lang.Long:48659987865500288 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:48659987915900288 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\ud8de\udd41\udacd\udd3d\ud9c0\udffa\ud91c\udd01\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb64\udca7\udaba\udfbc\ud9b5\ude69\ud894\udc85\000\ud87d\uddff\ud9e8\udf3d\ud8c3\udfc8\udad9\udc32\uda39\udd06\ud8d4\uded7\ud917\udee7\uda3d\ude58\ud93c\udc0f\udb16\ude92", "\u7e13\u4c63\u2d48\u7ecc\u60bd\u9511\ua4f5\u991b\u25ef\ub0fc\uc6f7\u845b\u9ea0\u5555\u9f46\u100a\u8b6f\000\000\u6671\u2844\u30d5\u1d27\u94bc\u929f\u46b5\ub345\u37a5\ua7a4\u74e1\u53d0\uc911\u00ea", "\ud887\udfad\u37ac\udae2\udd03\udb15\udf22\ud885\udc0e\ud9ca\ude5b\ud8dd\udd38\udb25\uddca",
        52, 30671, -1232206347, 48659987890700288L, 71023L, false, false, (char) 10665, (char) 108,
        Double.longBitsToDouble(0x3fe0000000f7d254L), Double.longBitsToDouble(0x3fe0a0e5fff1213cL)));
  }
  @Test(timeout = 4000)
  public void test180() throws Throwable {
    assertEquals("0=java.lang.Long:4575479082272183331 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 10, 6, "\ud88a\udc73\ud8a3\udc4c\udb70\ude12\ud95d\udd47\ud942\udf00\ud8a1\udc68\ud9df\udd1c\ud887\udf32\udbd2\udfec\ud86e\udef3\ud928\udd4a\uda4d\udd55\udb5d\udee5\uda94\udce8", "\uca4e\u4710\u8818", "\udb37\udc75\udb12\udf5f",
        38, 69748, -950752724, 4575479082243383331L, 57277L, true, true, (char) 26058, (char) 38092,
        Double.longBitsToDouble(0x3fe2cbc910c7c576L), Double.longBitsToDouble(0x3fc7958b20a694e8L)));
  }
  @Test(timeout = 4000)
  public void test181() throws Throwable {
    assertEquals("0=java.lang.Long:5146391 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:5146391 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 1, 6, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\udac1\ude8b\uda80\udef7\udad1\udeed\ud9d5\udcf0\ud8b5\udd99\ud891\ude22\ud89c\udd6c\ud917\udee7\ud8ad\udccfS\uaf1c\ua144\000\u2986\u1bae\ud91b\ude8a\udb86\udf33\udb46\udd86\udac3\udec2\udb67\ude1d\ud9a6\udff5\u00bf\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud909\ude89\uea52\ud801\udf85\000\ud841\ude5f\ud8d3\udf27\udb26\udd16\ud8c7\udc01\udac5\udc98", "\ud730p\000\000\u7da0\u8f36\u009e\ud5d1\ua0a0\u1e81\ucdde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\ud874\udc63\ud9e1\ude2c\ud945\uded4\ud9af\udde0\ud9da\udee0\ud960\udfa4\udab3\udcc3",
        16, 86835, 254, -23653609L, 40454L, true, true, (char) 9422, (char) 12817,
        Double.longBitsToDouble(0x3fd9c78fb7a66e76L), Double.longBitsToDouble(0x3fec7f4645b533e5L)));
  }
  @Test(timeout = 4000)
  public void test182() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 6, 6, "\ud88a\udc73\udb89\udc71\ud9ad\udf11\ud95d\udc56\ubdb3\ud8a1\udc68\ud9df\udd1c\ud90b\udf31\udb2b\udc77\ud9e2\uddfd\ud83d\ude24\udaae\udf85\uda64\udd2c\udab0\udfea", "\u239a\u66f5\u8818\ubeac\000\u3568\u833d\u53a6\u5670\u6960\ubec7\u5dad\ub390\u7ecc\ucf64\u92e4\u4ebd\u5df8\u358e\ub126\u3e11\u7c64", "\ud8c4\udf0f\ud87e\udd66",
        59, 89537, -1854609025, 7590207515853835008L, 27832L, true, false, (char) 18537, (char) 60227,
        Double.longBitsToDouble(0x3fc86e23e8507c08L), Double.longBitsToDouble(0x3fd7efbb2ea86c2aL)));
  }
  @Test(timeout = 4000)
  public void test183() throws Throwable {
    assertEquals("0=java.util.TreeSet:[Africa/Abidjan, Africa/Accra, Africa/Addis_Ababa, Africa/Algiers, Africa/Asmara, Africa/Asmera, Africa/Bamako, Africa/Bangui, Africa/Banjul, Africa/Bissau, Africa/Blantyre, Africa/Brazzaville, Africa/Bujumbura, Africa/Cairo, Africa/Casablanca, Africa/Ceuta, Africa/Conakry, Africa/Dakar, Africa/Dar_...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 8, "\udb11\udccd\udbbb\udcbf\udb97\udc1d\ud939\uddcd\ubdb3\ud966\udf09\uda2e\ude08\ud90b\udf31\ud8b6\ude02\ud9e2\uddce\ud9cc\ude18\udae2\udd72\u68bb\ud85b\ude36\uda80\udf4d\ud944\udf1f\ud9de\udd27\ud9b8\udddc\udad5\udc71\ud89c\udd58\ud917\udee7\ud8d7\udde7\ud853\udec3\ud8cf\udc59\ua144\000\uda74\udd8b\ud945\ude97\u1106\udb86\udf78\udb46\udd86\udac3\udec2\udb67\ude1d\ud959\udd65\u0098\u00bc\udb4d\udd8d\u0095\ud929\udc94\ud929\udfd8\uda2b\ude42\ud8e0\ude1d\ud9de\udc93\ud8d2\udd0e\ud9ce\udcc4\ub4bb\u00ed\ud841\ude5f\udb1e\udf6d\udb26\ude04\ub6ad\udaf0\udc81", "\ud730p\000\000\u2222\u3259\u009e\u8e7c\ua0a0\u1e81\u7cde\ub010\u98da", "\udb67\udd78\udaf2\udc8c\ud96f\udf01\ud95c\udc35\udba1\udd80\ud9af\udde7\ud9da\udee0",
        54, 22050, 816241551, 7185796056498572042L, 19454L, true, true, (char) 36978, (char) 8200,
        Double.longBitsToDouble(0x3fca847f40454800L), Double.longBitsToDouble(0x3fd1778fb7a66e76L)));
  }
  @Test(timeout = 4000)
  public void test184() throws Throwable {
    assertEquals("0=java.lang.Long:-24962884 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:-24962884 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 3, 4, "\ud88a\udc73\udb89\udc71\udb70\ude12\ud958\ude47\uda99\udff9\ud888\udcb7\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\ud9e2\uddce\ud83d\ude24\uda4d\udd55\ud84e\udfeb\udba2\udc8e\udb0b\udcfb\udb63\udd86\ud84d\ude23\uda7c\udf96\000", "\u3568", "\udb65\udf22\uf6d5\udbcc\uddb5\udacc\udd08\udb69\udc88\uda8e\udc3a\ud9e9\udc08",
        7, 50830, 89, 3837116L, -40501L, false, false, (char) 12223, (char) 1347,
        Double.longBitsToDouble(0x3fbe6cb2db2a0788L), Double.longBitsToDouble(0x3fefaed3937f63b0L)));
  }
  @Test(timeout = 4000)
  public void test185() throws Throwable {
    assertEquals("0=java.lang.Long:1860068550915387410 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 6, 6, "\udb4d\uddee\udb72\udd10\ud94e\udef1\ud932\ude65\ub27a\uda61\udc68\ud9df\udd1c\ud83a\ude29\u2fba\ud99d\ude14\uda57\ude0b\uda4d\udd12\udb5d\udee5\udba2\udd10", "\u8bc0\u72c1\u9d17", "\ud8fe\udcb5\ud981\udd55\udb0c\ude6b",
        43, 60276, 1060855292, 1860068550886587410L, -66675L, true, false, (char) 38092, (char) 12155,
        Double.longBitsToDouble(0x3fc8f8aed2f2b164L), Double.longBitsToDouble(0x3fa4d29d729d67e0L)));
  }
  @Test(timeout = 4000)
  public void test186() throws Throwable {
    assertEquals("0=java.lang.Long:2786848561508290125 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:2786848561558690125 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 3, "\ud88a\udc73\udb89\udce8\ud8de\udd41\udacd\udd3d\udaf6\ude85\ud91c\udd01\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb64\udc26\udaf2\udce0\ud9b5\ude69\ud894\udc85\udbd6\udcc6\ud90a\udc77\udaf3\ude6f\ud8c3\udfc8\u901c\ud86b\udfa5\ud8d4\udf19\ud917\udee7\uda3d\ude58\ud93c\udc0f\udb16\ude92", "\u7e13\u4c63\u2d48\u7ecc\ud611\u9511\ua4f5\u991b\u25ef\ub0fc\uc6f7\u845b\u788e\u5c27\u9f46\u100a\u8b6f\u3d75\u8963\u10fb\u2844", "\udbba\udd1a\udbce\udfc0\udbad\uddbb\uda89\udff9\ud9e8\udfc2\ud98d\udde2\udb23\udfde\u9164\ud9ac\uddf9\udaaa\udeb1\udb88\udece\uda3c\udebe\ud887\udfad\u37ac\udae2\udd03\ud936\udc32\ud885\udc6a\ud9ca\ude5b\ud8dd\udd38\udb25\uddca",
        52, 35231, -1232206347, 2786848561533490125L, 42282L, false, false, (char) 9641, (char) 881,
        Double.longBitsToDouble(0x3fe04ff278f7d254L), Double.longBitsToDouble(0x3fe0a0e5fff1213cL)));
  }
  @Test(timeout = 4000)
  public void test187() throws Throwable {
    assertEquals("0=java.lang.Long:48688572994714240 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:48688573045114240 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\ud8de\udd41\udacd\udd3d\ud9c0\udffa\ud894\udc3d\ud935\uddfc\ud90b\udf31\ud8b6\ude5b\udb64\udc43\udaf2\udce0\uda92\udc97\ud893\udfa5\uda7c\uddf8\000\000\ud8c3\udfc8\udad9\udc32\udb36\udd44\ud89c\uddc2\udbd7\udd7d\udb9b\udde3\ud9a9\ude05\u9826", "\u6a85\u1b96\ub390\u7ecc\u6954\u8da5\u0faf\u988d\u84bf\ub126\uc829\u845b\000\000\ud70b\u9071\u9d91\u8adb\u97dd\u10fb\u2844\u30d5\u1d27\u94bc\u6e30\u41e9\ub345\u37a5\ua7a4\u65c4\u06a3\uc83e\u160c", "\ud887\udfad\ud9bc\udda2\uda28\ude15\ud973\ude4a\ud962\udf85\ud9c6\udf79\ud8dd\udd38\ud845\udc7b",
        31, 59383, -1232206347, 48688573019914240L, -33783L, false, false, (char) 10688, (char) 12487,
        Double.longBitsToDouble(0x3fe04ff278f7d254L), Double.longBitsToDouble(0x3fe0a0e5ff598d15L)));
  }
  @Test(timeout = 4000)
  public void test188() throws Throwable {
    assertEquals("0=java.lang.Long:5597123312970600254 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:5597123313028200254 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\ud8de\udd41\udacd\udd3d\ud9c0\udffa\ud894\udc3d\ud935\uddfc\ud90b\udf31\ud901\udc5d\udb64\udc43\udac8\udd2c\uda92\udc97\ud893\udfa5\uda7c\uddf8\000\000\ud8c3\udfc8\uda91\ude0d\udbc6\udf31\ud89c\uddc2\udbd7\udd7d\udb9b\udde3\ud9a9\ude05\u9826", "\u6a85\u1b96\ub390\u0ec4\ua854\u8da5\u0faf\u988d\u2111\ub093\uc829\u845b\000\000\ud70b\u9071\u9d91\u8adb\u97dd\ucb11\u2883\u30d5\u1d27\u47ff\u993a\u41e9\ub345\u37a5\ua7a4\u65c4\u06a3\uc83e\u7101", "\ud887\udfad\ud9bc\udda2\uda28\ude15\ud973\ude4a\ud962\udf85\ud9c6\udf79\ud8dd\udd38\ud845\udc7b",
        31, 59383, -1232191755, 5597123312999400254L, -33783L, false, false, (char) 10688, (char) 12487,
        Double.longBitsToDouble(0x3fe04ff278f7d254L), Double.longBitsToDouble(0x3fe0a0e5ff598d15L)));
  }
  @Test(timeout = 4000)
  public void test189() throws Throwable {
    assertEquals("0=java.lang.Long:1542324396687209539 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 15, 11, "\udb28\udc91\ufe4d\udaf5\ude8a\udacd\udd14\ud9c0\udffa\ud894\udc3d\000\ud8e0\ude4f\ud8b6\ude5b\000\udaf2\udce0\udbf5\ude69\u5b4a\ud9a8\udf39\ud8a7\udc29\udad1\udeed\ud931\udc4a\u8e80\ud8c4\uddcd\ud88e\udce4\u5c25\uda8f\udc9d\ud952\udfa8\ud8b2\udc9c", "\u50ed\u5dad\ucb72\u8a60\uaa6c\u2b73\ub306\000\u23f8\u45fb\u4199\u8473\u72a2\u1e3a\u4463\u9514\u09b1\ub106", "\uda63\udfb5\u1c93\udbda\udc18\udb42\udd5e\ud918\udf01\udbad\udd56\ud851\uddfa\ud9e8\udf68\udb84\udebf\udb23\udfde\ud944\udff2\u04b0",
        33, 51799, 13097746, 1542324396662009539L, -23978L, false, false, (char) 11809, (char) 35066,
        Double.longBitsToDouble(0x3f3166da50000000L), Double.longBitsToDouble(0x3fddf4690bebb3b8L)));
  }
  @Test(timeout = 4000)
  public void test190() throws Throwable {
    assertEquals("0=java.lang.Long:48659985684462208 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:48659985734862208 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\ud8de\udd41\udacd\udd3d\ud9c0\udffa\uc3ec\000\000\000\000\000\000\ud893\udfa5\uda7c\uddf8\ud8b1\udfff\ud9e8\udf3d\ud8c3\udfc8\udac5\udee8\udb36\udcd5\ud89c\uddc2\ud917\udee7\uda3d\ude58\ue84e\udb0c\ude59", "\u7e13\u4c63\ub390\u7ecc\ucef5\000\u0cea\u991b\u84bf\ub126\uc6f7\u845b\u72a2\ud685\ud74b\u9071\u94cc\u5e48\u97dd\u8289\u2844\u30d5\u1d27\u94bc\u6e30\u4650\ub345\u37a5\ua7a4\u74e1\u53d0\u00d3\u160c", "\ud887\udfad\ud8d8\udd11\udad6\udd4c\udb6c\udc1f\ud882\udd9a\ud9ca\ude5b\ud8dd\udd38_",
        31, 59383, -1232206347, 48659985709662208L, -33783L, false, false, (char) 10665, (char) 12487,
        Double.longBitsToDouble(0x3fe04ff278f7d254L), Double.longBitsToDouble(0x3fe0a0e5fff1213cL)));
  }
  @Test(timeout = 4000)
  public void test191() throws Throwable {
    assertEquals("0=java.lang.Long:5016974799612235461 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:5016974799662635461 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\ud8de\udd41\udacd\udd3d\ud9c0\udffa\ud894\udc3d\ud9df\udd1c\ud90b\udf31\ud8b6\ude5b\udb64\udc43\udaf2\udce0\ud9b5\ude69\ud894\udc85\uda7c\uddf8\ud8b1\udfff\ud9e8\udf3d\ud8c3\udfc8\udad9\udc32\udb36\udd44\ud89c\uddc2\ud917\udee7\uda3d\ude58\ue84e\udb0c\ude59", "\u7e13\u4c63\ub390\u7ecc\u6954\u8da5\ua56d\u991b\u84bf\ub126\uc6f7\u845b\u72a2\ud685\ud74b\u9071\u94cc\u5f2c\u97dd\u10fb\u2844\u30d5\u1d27\u94bc\u6e30\u4650\ub345\u37a5\ua7a4\u74e1\u53d0\uc911\u160c", "\ud887\udfad\ud8d8\udd11\udad6\udd4c\udb6c\udc1f\ud882\udd9a\ud9ca\ude5b\ud8dd\udd38\ud845\udc7b",
        31, 43727, -1230904115, 5016974799637435461L, -33783L, false, false, (char) 10665, (char) 12487,
        Double.longBitsToDouble(0x3fe04ff278f7d254L), Double.longBitsToDouble(0x3fe0a0e5fff1213cL)));
  }
  @Test(timeout = 4000)
  public void test192() throws Throwable {
    assertEquals("0=java.lang.Long:8263225706008247109 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:8263225706058647109 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 2, 5, "\ud88a\udc73\udb89\udc71\ud8de\udd41\udacd\udd3d\udbcb\udfaa\uda5e\udd12\u9600\000\000\000\000\000\ud893\udfa5\uda7c\uddf8\ud8b1\udfff\ud9e8\udf3d\ud8c3\udfc8\udac5\udee8\udb36\udcd5\ud89c\uddc2\ud917\udee7\uda3d\ude58\ue84e\udb0c\ude59", "\u7e13\u4c63\ub390\u7ecc\ucef5\000\u0cea\u991b\u84bf\ub126\uc6f7\u845b\u72a2\ud685\ud74b\u9071\u94cc\u5e48\u97dd\u8289\u2844\u30d5\u1d27\u94bc\u1866\u2f65\u11c2\u37ab\ua7a4\u74e1\u53d0\u00d3\u160c", "\ud887\udfad\ud8d8\udd11\udad6\udd4c\ud881\uddcd\ud882\udd9a\ud9ca\ude5b\ud8dd\udd38_",
        31, 59383, -1232206347, 8263225706033447109L, -33783L, false, false, (char) 10665, (char) 12487,
        Double.longBitsToDouble(0x3fe04ff278f7d254L), Double.longBitsToDouble(0x3fe0a0e5fff1213cL)));
  }
  @Test(timeout = 4000)
  public void test193() throws Throwable {
    assertEquals("0=java.lang.Long:638985471360 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 0, 6, "\udb11\udcf5\udbbb\udcbf\udb97\udc1d", "\u0606\u488e\ud355\u5541\u5b31\ud4b9\ubf62\u54ea\u0884\u2bc5\u062d", "\udb20\udd28\ud89c\udd6c\ud917\udee7\ud8ad\udccf\udbc2\udc38\uaf1c\udb65\udf22\uf6d5\udbcc\uddb5\udbe4\udc34\ud91b\ude8a\uda25\ude62\udaa4\udfb2\u6cef\ud9f6\ude29\ud979\uddf5",
        34, 88460, -696334295, 638960271360L, 55999L, true, true, (char) 47915, (char) 17511,
        Double.longBitsToDouble(0x3fe29288278562b1L), Double.longBitsToDouble(0x3feed42126f036c3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.DateTimeZone|getOffsetFromLocal|long|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|convertLocalToUTC|long,boolean|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|convertLocalToUTC|long,boolean,long|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|convertUTCToLocal|long|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|equals|java.lang.Object|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|fixedOffsetZone|java.lang.String,int|static",
    "M|org.joda.time.DateTimeZone|forID|java.lang.String|static",
    "M|org.joda.time.DateTimeZone|forOffsetHours|int|static",
    "M|org.joda.time.DateTimeZone|forOffsetHoursMinutes|int,int|static",
    "M|org.joda.time.DateTimeZone|forOffsetMillis|int|static",
    "M|org.joda.time.DateTimeZone|forTimeZone|java.util.TimeZone|static",
    "M|org.joda.time.DateTimeZone|getAvailableIDs||static",
    "M|org.joda.time.DateTimeZone|getConvertedId|java.lang.String|static",
    "M|org.joda.time.DateTimeZone|getDefault||static",
    "M|org.joda.time.DateTimeZone|getDefaultNameProvider||static",
    "M|org.joda.time.DateTimeZone|getDefaultProvider||static",
    "M|org.joda.time.DateTimeZone|getOffsetFromLocal|long|fac:org.joda.time.DateTimeZone:getDefault:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
