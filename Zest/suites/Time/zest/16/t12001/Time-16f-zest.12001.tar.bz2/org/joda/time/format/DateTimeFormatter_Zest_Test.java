package org.joda.time.format;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateTimeFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=null |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 5, 8, 12, "\ud975\udc6d\uda8a\udcfb\ud97b\udcb5\ud968\udf6b\uda41\udf63\udaa7\udcac\udadc\udde4\ud875\udcc1\uda2b\udd26", "\u9b9a", "\ud9a8\udf17\udab8\udce3\udadb\udfdd\ud9b4\udf1b\ud8a3\udfd5\udb18\udf33",
        23, 95766, -422841932, 2637668117666511274L, -80508L, false, true, (char) 12242, (char) 36992,
        Double.longBitsToDouble(0x3fd745c57cd6128eL), Double.longBitsToDouble(0x3fe3a8e96304b13bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=null |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 5, 8, 12, "\ud975\udc6d\uda8a\udcfb\ud97b\udcb5\ud968\udf6b\uda41\udf63\udaa7\udcac\udadc\udde4\ud875\udcc1\uda2b\udd26", "\u9b9a", "\ud9a8\udf17\udab8\udce3\udadb\udfdd\ud9b4\udf1b\ud8a3\udfd5\udb18\udf33",
        23, 95766, -422841932, 2637668117666511274L, -75747L, false, true, (char) 47252, (char) 31627,
        Double.longBitsToDouble(0x3fc1f7e858d90928L), Double.longBitsToDouble(0x3fd745c57cd6128eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 14, 8, 12, "\ud975\udc6d\uda8a\udcfb\ud97b\udcb5\ud968\udf6b\uda41\udf63\ud9dd\udca7\udadc\udde4\ud875\udcc1\uda2b\udd26", "\u6b9a", "\ud9a8\udf17\udab8\udcd0\udadb\udfdd\ud9b4\udf1b\udaee\udf9a\udb18\udf33",
        23, 95766, -422841932, 2637668117666511274L, 55325L, true, true, (char) 44125, (char) 57636,
        Double.longBitsToDouble(0x3fc1f7e854c10928L), Double.longBitsToDouble(0x3fd005557cd6128eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=null |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 5, 8, 12, "\ud975\udc6d\uda8a\udcfb\ud97b\udcb5\ud968\udf6b\uda45\udc53\udaa7\udcac\udadc\udde4\ud875\udcc1\uda2b\udd26", "\u9b9a", "\ud9a8\udf17\udab8\udce3\udadb\udfdd\ud9b4\udf1b\ud8a3\udfd5\udb18\udf33",
        23, 61774, -422865660, 2637668118723475882L, -80508L, false, true, (char) 12242, (char) 37035,
        Double.longBitsToDouble(0x3fd745c24cd6128eL), Double.longBitsToDouble(0x3fe3a8e96304b13bL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=null |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 9, 4, 12, "\ud975\udc6d\uda95\udc33\ud97b\udcb5\ud968\udf6b\uf422\udaec\uded5\ud8c7\ude1d\ud85a\udfe8\ud978\udfad", "\u9b9a\u46b6\uc0f0\u911c\u58c8\ua77c\u5ae3\ucf0a\uad40\u60db\ucf5a\u1a11\u41d1\ub4a5\ua910\u067a\u3a6c\u7f63\u4b63\u6720\u63a7\uc873\uc8fe\ub119\u5039\uc6f8\ubaa8", "\udb39\udc73\ud830\udee1\uc55f\udbbe\udc06\ud937\udf89\u6f24\ud9a3\udc54\ud91c\udfe3\udbb6\udef3\uda8c\udd8e\ud86d\ude74\ud960\udf26\ud9ce\udc5e\ud9f3\udc3e\ud98b\udcb4\udb03\udd8a\ud915\udfcf\ud897\udc52\uda9c\udf99\ud86c\udf09\udba9\udc0a\uda2d\udde2\udb22\uddef\uda91\udea7\udb77\udeac\ud882\udf6b\udb46\udd16",
        51, 32760, -778457392, -6298654288971868196L, 51933L, false, false, (char) 41498, (char) 12949,
        Double.longBitsToDouble(0x3fe663ab6f07bf88L), Double.longBitsToDouble(0x3fd8196ce86aca28L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 10, 11, 12, "\ud975\udc6d\uda8a\udcfb\ud97b\udcb5\ud968\udf6b\uda41\udf63\ud8a4\udcd5\uda7c\ude7d\ud835\udede\uda70\udd14", "\u9b9a", "\u6465\uda96\udcd0\udadb\udfdd\ud9b4\udf1b\ud8a3\udfd5\udb18\udf33",
        23, 95766, -422841932, 2637668117666511274L, -90329L, false, true, (char) 12242, (char) 36992,
        Double.longBitsToDouble(0x3fd745c57cd6128eL), Double.longBitsToDouble(0x3fe3a8e96304b13bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 0, 8, 12, "\ud975\udc6d\udb87\udd39\ud94b\uddfc\ud8ef\udd0e\uda41\udf63\ud999\udd65\udb83\udff5\uda15\udd49\udbd1\udde9", "\u9b9a\u46b6\uc0f0\u0e26\u3b6c\ua77c\u6956\ud179\u5795\ubd44\ucc2f\ud3d4\u5c90\u1ab6\ubb30\u46b9\u0370\uac5f\ubbb7\ubaf2\uc4dc\uc815\uc8fe", "\ud996\udf7d\ud993\udf55\uda77\ude55\ud84d\udf7f",
        38, 2364, -219415419, -4013078569960643995L, 90324L, true, false, (char) 13644, (char) 30890,
        Double.longBitsToDouble(0x3fecee13fd3e3830L), Double.longBitsToDouble(0x3fe8ebf08c1cfffdL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 12, 8, 12, "\ud975\udc6d\uda8a\udcfb\ud97b\udcb5\ud968\udf6b\uda41\udf63\udaa7\udcac\udadc\udde4\ud875\udcc1\uda2b\udd26", "\u16f1", "\ud9a8\udf17\udb44\udd30\u77df\ud9b4\udf1b\ud8a3\udfd5\udb18\udf33",
        23, 95766, -422841932, 2637668117666511274L, -80508L, false, true, (char) 12242, (char) 36992,
        Double.longBitsToDouble(0x3fd745c57cd6128eL), Double.longBitsToDouble(0x3fe3a8e96304b13bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 15, 8, 12, "\ud86b\udc82\ud6af\ud8b2\udfca\ud968\udf6b\uda41\udf63\udaa7\udcac\udadc\udde4\ud875\udcc1\uda2b\udd26", "\u9b9a", "\ud9a8\udeab\udab8\udce3\udadb\udfb9\udabf\udc1f\ud9ee\ude2e\uda83\udccc",
        -1, 95766, -422841932, 2637668117666511274L, 50564L, true, true, (char) 25644, (char) 7248,
        Double.longBitsToDouble(0x3fbcd715f3594bc0L), Double.longBitsToDouble(0x3fe3a8e96304b13bL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 12, 2, "\ud975\udc6d\uda8a\udcfb\ud97b\udcb5\ud968\udf6b\uda41\udf63\udaa7\udcac\udadc\udde4\ud875\udcc1\uda2b\udd26", "\u9b9a", "\ud9a8\udf17\udab8\udce3\udadb\udfdd\ud853\ude4a\udaa7\udc32\udb6c\ude7b",
        36, 5223, -422841911, 2637668117666511274L, -80508L, false, true, (char) 12242, (char) 36992,
        Double.longBitsToDouble(0x3fd745c57cd6128eL), Double.longBitsToDouble(0x3fe3a8e96304b13bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 0, 8, 12, "\u39da\uda6c\udc96O\ud968\udeb2\uda29\ude13\udaa7\udcac\udadc\udd55\ud875\udcc1\u9625", "\uba99", "\ud9a8\ude68\u00f7\000\000\ud89b\udc0d\u929a",
        -5, -1000, -422842112, 2637668119478450432L, 2257L, false, false, (char) 58739, (char) 47025,
        Double.longBitsToDouble(0x3fe3a8e96304b13bL), Double.longBitsToDouble(0x3fd009a3c152d808L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 0, 0, "\u00da\ud826\udc93\ud97b\udcb5\ud968\udf6b\uda41\udf63\udaa7\udcac\udadc\udde4\ud875\udcc1\uda2b\udd26", "\u9b9a", "\000\ud8c8\udee3\ud5cb\udb02\udfc1\ud8a3\udfd5\udb18\udf33",
        23, 95766, -422903808, 2637668117666511274L, -80508L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd745c57cd6128eL), Double.longBitsToDouble(0x3fe3a8e96304b13bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 15, 12, "\ud975\udc6d", "\u1da0\u2385\ub576\u284b\u9886\u3b0c\u173d\uc584", "\udb9c\uddc0\ud9a8\udf17\udab8\udce3\udadb\udfdd\ud9b4\udf1b\ud8a3\udfd5\udb18\udf33\ud8ac\ude56\ud95c\udc21\udb04\udc37\ud8ca\udf56\u335a\ud8e9\udd8a\udbff\udc08\udbbd\udc03\ud9b0\ude5c\ud8ee\udf0f",
        17, 86526, 1463674228, -2833698290668508472L, 7997L, true, false, (char) 10419, (char) 16079,
        Double.longBitsToDouble(0x3fe260b7efbef8bbL), Double.longBitsToDouble(0x3fbc16e41d2c7220L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 0, 12, "\ud966\ude93", "\u1da0\u2385\ub54b\uc18f\uacbd\u3ae7\uadc1\uc584", "",
        -5, -1000, 0, -1194956978L, 59078L, true, true, (char) 19780, (char) 51887,
        Double.longBitsToDouble(0x3f4cd96000000000L), Double.longBitsToDouble(0x3fe35ca716bd123eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 13, 0, "\ud975\udc6d\uda8a\udcfb", "\u1d1c\ua040", "\uda2b\udd26\ud8e1\udf14\udbb2\udc6d\u5be3\udbba\udcca\uda8a\udff7",
        -2, 55543, 590206411, -5132301141761055800L, 78969L, false, false, (char) 51887, (char) 2041,
        Double.longBitsToDouble(0x3fdaa239a4d729c4L), Double.longBitsToDouble(0x3feb6091f49b8446L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 10, 10, 3, "\udab8\udd0d", "\uc9f3\u7063", "\udaa9\udd1b\uda2b\udd90\ud87f\uded1\udbb2\udca8\u2be3\udbba\udcca\uda8a\udff7\udb54\udced",
        24, 62411, -1194956978, 4689303210510527669L, 14947L, false, true, (char) 14157, (char) 13679,
        Double.longBitsToDouble(0x3fdf58b567b9f102L), Double.longBitsToDouble(0x3fe377d5b08fbf42L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 11, 11, 12, "\ud975\udc6d\uda8a\udcfb", "\u020a\u2089", "\uda2b\udd26\ud87f\uded1\udbb1\udfee\u2be3\udbba\udcca\uda8a\udff7",
        -2, 78460, 590157742, -5132301140687313976L, 78969L, false, false, (char) 51887, (char) 51193,
        Double.longBitsToDouble(0x3fdaa249a4d729c4L), Double.longBitsToDouble(0x3fe5e891f1f5c776L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.format.DateTimeFormatter|parseInto|org.joda.time.ReadWritableInstant,java.lang.String,int|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getChronolgy||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getChronology||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getDefaultYear||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getLocale||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getParser||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getPivotYear||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getPrinter||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getZone||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|isOffsetParsed||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|isParser||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|isPrinter||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseDateTime|java.lang.String|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseLocalDate|java.lang.String|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseLocalDateTime|java.lang.String|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseLocalTime|java.lang.String|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseInto|org.joda.time.ReadWritableInstant,java.lang.String,int|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
