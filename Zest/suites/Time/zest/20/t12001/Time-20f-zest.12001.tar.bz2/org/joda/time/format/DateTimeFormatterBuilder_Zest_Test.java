package org.joda.time.format;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateTimeFormatterBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 10, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud861\udc00\ud90b\udd0e\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3f9471e32c0aaa20L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 10, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udb8f\udca4", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud861\udc00\ud90b\udd0e\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3f9471e32c0aaa20L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud807\udcac\ud90b\udc72\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3fe8a38f19605551L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 14, 10, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u1a40\ubb07\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u9364\u6325\u124f\u0336", "\ud8db\ude7e\udb7e\udfca\ud861\udc00\uda3f\udc08\ud9df\udcf5\ud91d\udfb1\uda0b\ude34\uda14\ude0c\uda1a\udd61\uda6c\udc3d\ud8ea\uddb5\udaf4\udf69\udb9d\ude1f\ud964\udd54\ud8a3\udc58\ud80e\udcc8\udba0\ude54\uda2e\udefd\ud85e\udd35\ud8c3\udd06",
        33, 5686, 1910728194, 6147840189903573344L, 21278L, false, false, (char) 15252, (char) 18429,
        Double.longBitsToDouble(0x3fd194f238b41ee2L), Double.longBitsToDouble(0x3fedde602c6fc05eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 0, 7, "\udb24\udf4f", "\u997f\u211f\ubb50\u459a\ub500\uc8f4\u04de\u83ea\u5dbd\ud662\ub754\u91de\u4a67\u367e\u7157\uc71e\u6dfb\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u2ebc\u039d\uab6a\ud179\u3d89\u7626\u571a\ub517", "\uda0b\ude34",
        28, 72701, 1405405783, -6203076508241060829L, -14778L, true, true, (char) 56901, (char) 16449,
        Double.longBitsToDouble(0x3feb62c4eb7df8aeL), Double.longBitsToDouble(0x3fd6bd94cf327a64L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 14, 10, 14, "\udaf4\udc24\uda45\udfe2\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udafe\udca6\uda00\udc8a\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f\u0336\uab6a\ud179\u3d89\u7626\u571a\ub517\u6122\ua612\u6f5d\u2e70\uac54\u6d9f\u98c0\u5d95\ud41e", "\ud80e\udcc8\udba0\ude54\uda2e\udefd\ud9bf\ude06\ud8c3\udd06\uda1f\ude34",
        1, 9194, 1431405588, -1725000289733187333L, -56111L, true, true, (char) 33092, (char) 52679,
        Double.longBitsToDouble(0x3fee20b7360b5b80L), Double.longBitsToDouble(0x3fd21be43a38952aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 14, 11, 4, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42", "\ud662\ub754\u91de\u4a67\u48b5\ube22\uc67c\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u3af0\u1b06\u3a2c\u8d4c\u0765\u6325\u124f\u0336\uab6a\ud179\ubd47\u760e\u571a\ub517\u6122\ua367\u8427\u7939\uac54\u6d9f\u98c0\u5d95\ud41e\u585b\u64a0\uc52b\u3623\u1abf\uad9e\u89f2\u5b98\uc2b6\u24fd\u9932\uc73e\u0b07\u2ece\u6fa5\u8511\u4e49\uc786\u20b3\u1dda\u417d\ud211\ua5b6\ua993\ub1f8\ubd8e", "\udb83\udc51\ud9c0\udc3e\uda60\udd13",
        20, 73649, 1222209204, -43142822564325448L, 81073L, false, true, (char) 34292, (char) 18020,
        Double.longBitsToDouble(0x3f9d63ba06912c20L), Double.longBitsToDouble(0x3feadaaef3372581L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 10, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6", "\u965d\uda2e\uddca\u7906",
        -4, 45253, -1973518953, -8194444566333306830L, 99384L, true, false, (char) 63179, (char) 22298,
        Double.longBitsToDouble(0x3fe89584aaf7b115L), Double.longBitsToDouble(0x3fe0f0ed7af69835L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 13, 6, 3, "\ud959\udd7b\ud9ed\udd35\udad6\udc2d\udaba\udfda", "\u6ddb\u3bd1\uc8f4\u04de\u0f1c\u5dbd\ud662\ub754", "\ud8b5\udc00\uda99\udc12\ud869\udec0\ud82e\udccd\udb09\udce4\udb8a\udc04\udb3c\udc5c\ud99e\udeb9\ud863\udcb0\ud860\ude91",
        7, 45253, -1973518953, -8194444569394194382L, 64436L, true, true, (char) 39054, (char) 44044,
        Double.longBitsToDouble(0x3fdd21daf52bb5faL), Double.longBitsToDouble(0x3fa611db75530040L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 14, 5, 14, "\udaf3\udf9a\ud8d3\udfe9\ud93f\udcec\udaba\udfda\udac4\udd98\udb72\udc33\udae0\udf38\udbbf\udccd\ud9ff\udf7f\ua394\uda5d\uddc7\ud88e\ude16\ud835\udcf8\uda05\udf95\udac4\ude7a\uda22\udc6c", "\uc71e\u0ef9\u3508\u5f30\ua5cf\ucb11\u3e88\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u1f4a", "\udb78\udeeb\ud8b9\udd17\udb01\udedf\ud861\udc59\ud90b\udd0e\ud81a\udf01\ud8f2\udda1\uda54\udd54\ud9f7\udcba\uda1a\udd61\ud90e\udc9d\ud807\udd9c",
        3, 93096, 1773056794, -8182822280765004596L, 20469L, true, true, (char) 1129, (char) 48425,
        Double.longBitsToDouble(0x3f9471e32c0aaa20L), Double.longBitsToDouble(0x3fe845ffc535c42aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 4, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud82a\udc84\udb50\udd1c\ud9e4\udc43\ud90a\ude58\ud845\udc00\ud8b5\udc00\uda99\udc12\ud869\udcc0\ud9a1\uded8\uda43\udd4e\ud8c4\udc91\ud8a4\udcf2\u965d\uda2e\uddca\u7906\ud993\uddc0\ud9e0\udd4c\uda93\udc50\uda56\udfc4\udb59\udd6c", "\u0336\uab6a\ubf5e\u09e9\u762c", "\ue101",
        13, 8664, 616661728, -2882229281083831721L, -14778L, true, true, (char) 56901, (char) 51767,
        Double.longBitsToDouble(0x3feb65803b7df8aeL), Double.longBitsToDouble(0x3fe88eca64a133c9L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 10, 14, "\ua1de\ud8d3\udf7c\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\uda99\udcc6\uda5d\ude77\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud861\udc00\ud90b\udd0e\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3f9471e32c0aaa20L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 7, 14, "\ud900\udfea\ubd02\ud9f3\udf29\ud844\udc8c\uda11\udf1c\ud8df\udfcd\udae0\udec5\ud9e9\udcb7\ud8be\udf46\uda0b\udebb\uda4c\udcea\udb29\udd3c\ud98f\udff8\udb41\udd3d\ud977\udd71\udaf0\udc75", "\ua79b\u9844\u0eff\u6fc5\uce0c\u900c", "\ud855\udca2\udb58\udd88\ud854\uddb4\udaec\udcf1\udb0f\udcf4\ud8ba\udc75\ua6ad\ud939\udcc1\ud996\udffb\ud9dd\ude3c",
        5, 11439, -2065526565, -7763252525598707616L, 45226L, true, true, (char) 62343, (char) 32693,
        Double.longBitsToDouble(0x3fe6429e2423a9eaL), Double.longBitsToDouble(0x3f97f3b86ae41240L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 5, 9, 0, "\ud98f\udd32\ud9bc\udcaa\udade\udfcc\udaba\udfda\udb5d\udd43\ud8b5\udf14\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\ud8d2\udc03\ud88e\ude60\udb50\udcdf\udaa0\ude6f\udac8\uded2\udaff\udc8c", "\uc71e\u0ef9\ubb26\ub786\u2009\u67c7\ub7ad\u597b\u2cba\ud5b0\u7880\ubaab\ua5ca\ud2a6\ua3cc", "\udb78\udeaf\ud876\udcc2\ud961\udfe9\udba0\udc77\ud90b\udce0\ud81a\udf01\ud91b\udc16\udb0e\udef6\uda13\udeb1\uda1a\udd61\udb13\udf46\ud88c\ude85",
        59, 28100, 1773041393, -8171215247271178325L, 42188L, true, true, (char) 40755, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf6c8a4c8L), Double.longBitsToDouble(0x3fe8a763dd19e3c8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 10, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\ud99a\ude28\udae0\udf8a\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\udb54\ude19\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ec2\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\uab64\u81f9\u48a1\u3cd9\u6325\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud861\udc00\ud90b\udd0e\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\udbd4\uddaa",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3f9471e32c0aaa20L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 2, 14, "\udaf3\udf55\000\uacd4\udaba\udfbc\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda11\udf9d\ud9ec\ude35\uda5d\uddc7\011\000\000\000\000", "\u8e4b", "\ud8c4\udc91\ud8a4\udcf2\u965d",
        32, 38606, 393545881, -5007926487515497065L, -100000L, false, false, (char) 50472, (char) 19065,
        Double.longBitsToDouble(0x3f6b164f9aff7f00L), Double.longBitsToDouble(0x3fe89584aaf7b115L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 14, "\udaf4\udc24\ud8e8\udea1\udade\udfcc\ud834\udd20\ud8d6\udc32\ud97b\udc05\ud809\udd06\ud836\udf6a\ud9a3\uddc0\ud8db\udde7\uda5d\ude14\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u1d45\u2b47\u0765\u6325\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud861\udc00\ud90b\udd0e\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, false, (char) 661, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3f9471e32c0aaa20L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 14, 14, 0, "\udaf4\udc24\ud8d3\udfe9\udaa0\udeee\ud924\udf0e\udac4\udd98\ud8f7\ude10\udae0\udf40\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude34\udb50\udcdf\udb36\udd24\ud905\udc37\udb72\udcae", "\uc71e\u1e13\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u187a\uc262\u8715\u8e32\u0765\u1a90\u124f\u0336\ud23b\u8cdb\u3d89\u7626\u571a\ub517\u6122\ua612\ud173\u7991\uac04\ud34a\u98c0\uc5e1\ud41e\u585b\u64a0\uc52b\u3623\u1abf\uad9e\u2451", "\udbb6\udf2f",
        49, 75576, 2079592507, 7980240335145728900L, -14981L, false, false, (char) 36464, (char) 49240,
        Double.longBitsToDouble(0x3fcb9a6c64e1d414L), Double.longBitsToDouble(0x3fb1ac5976a0e0d0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 4, 4, "\udb80\udd8f\udb61\udf0a\udb69\udf02\udafc\udcd6", "\u81d2\u3bd1\uc8f4\u04de\u83ea\u5dbd\ud662\ub754\u91de", "\uda99\udc12\ud869\udec0\ud9a1\uded8",
        26, 58403, -642540748, -6051374106219656211L, 94407L, true, true, (char) 14360, (char) 45683,
        Double.longBitsToDouble(0x3fa94723b6b3c120L), Double.longBitsToDouble(0x3fd28d085c4208b0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 14, 10, 4, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udce3\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\ud800\udc88\ud83d\udd96\udb94\udd79", "\uc71e\u1074\ub9d9\u5ea7\u8915\u67c7\u70ff\ua0e2\uab36\u5b61\u3a2c\u8d4c\u16cd", "\ud938\udff3",
        7, 1010, -1324023022, 2139204285046813214L, 2743L, true, true, (char) 30485, (char) 33766,
        Double.longBitsToDouble(0x3fede9260a57d800L), Double.longBitsToDouble(0x3fd74936784752aeL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 7, 10, 14, "\udaf4\udc24\ud859\udcac\ub311\udb7a\ude7e\udac4\udd41\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\ud945\udffd\ud95c\uddeb\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\u51a0\u0ef9\u66d6\u5fcb\uc4ed\u67c7\u70ff\ua0e2\u2c66\u51a4", "\ud82f\udfaf\udb45\udd07\uda41\udd69\ud938\udff3\ud996\udffb\udb78\udeeb\ud8b1\uddc9",
        4, 39558, 1718783243, -2382279377081757046L, -960L, true, true, (char) 41559, (char) 37516,
        Double.longBitsToDouble(0x3fa1d4f5417f3b80L), Double.longBitsToDouble(0x3fe8d4d63b0769aeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 10, 10, 1, "\udaf4\udc24\uaf16\udad8\ude93\udaba\udfda\udac4\udd98\ud8ec\udf09\udae7\udcd4\udbbf\udccd\uda12\udc4e\ud999\ude25\ud892\udefa\ud87f\ude88\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u9580\ua0e2\u041a\u94b3\u2949\u28e7\u0765\u6325\u124f", "\ud886\udec0\ud973\ude6b\udb7f\udcb6\ud861\udc00\ud90b\udd0e\ud81a\udf01\ud91b\udc16\udadd\ude7d\ud9f7\udd0a\uda30\udea4\udb13\udf46\ud8ea\uddb5",
        41, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 15448, (char) 51242,
        Double.longBitsToDouble(0x3fc1dd0be70958c8L), Double.longBitsToDouble(0x3fda1a0c32c06220L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 3, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud861\udc00\ud90b\udd0e\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 28093L, true, true, (char) 43270, (char) 3721,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3f9471e32c0aaa20L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 3, 3, "\udaf4\udc24\ud8d3\udfe9\ud862\udd4e\uda9b\udc4e\udac6\udd99\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\uda39\udd72\ud9a5\udf0f", "\u60a1\u0ef9\ub459\u5fcb", "\uda2e\uddca\udae5\ude98\udb86\ude3b\ud9e0\udd4c\ud941\udea8\ud937\udd61",
        26, 80122, 1512814658, 7118297849409803267L, 95822L, true, false, (char) 36813, (char) 64299,
        Double.longBitsToDouble(0x3fa611c6755300f0L), Double.longBitsToDouble(0x3fd25c8f04cc1ebcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 1, 12, 14, 14, "\uda3e\uddff\ud84f\udf86\ud93d\udc35\ud91d\ude2c\ud9d1\udc3c\uda99\udd9e\udadd\ude25\uda81\udd69\udaa7\udc81\ud8d1\udd2f\ud862\udf71\udb56\udf11\udadf\ude47\ud93c\udd46\udafb\ude98\ud9ab\udcf9", "\u0862\u1457\u0cf3\u5fcb\ua5cf\u8226\u78de\u1ff7\u2c66\u1b06\u3a2c\u361d\u2664\u4e6f\ua219", "\udbb7\udd06\udb4b\ude43\ud827\udc2c\ud8f1\udc74\ud813\udcec\ud8bd\udef8\udba9\udc26\uda0e\udf5c\ud9f7\udd0a\uda1a\udd61\ud924\udc1c\uda8f\udc6b",
        52, 92967, -1280396518, -5567374418844201544L, -88878L, true, true, (char) 11176, (char) 56522,
        Double.longBitsToDouble(0x3fe3c7b2ff1cce32L), Double.longBitsToDouble(0x3fe8a38f1911329fL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 13, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75\ud8b5\udc00\uda99\udc12", "\u66d6\u5fcb\ua5cf", "\u7906\udb86\uddfa",
        43, 20047, -1907917803, 4328742308133833579L, -16511L, true, false, (char) 22298, (char) 45991,
        Double.longBitsToDouble(0x3fe7bd88ae1e1dafL), Double.longBitsToDouble(0x3fe2d73bd02c238cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 10, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\u4cbf\udaef\udfc0", "\uc71e", "\ud8c4\udc91\ud8a4\udcf2\u965d",
        32, 38606, 393545881, -5007926487515497065L, -20178L, true, true, (char) 50605, (char) 19065,
        Double.longBitsToDouble(0x3f6b164f9aff7f00L), Double.longBitsToDouble(0x3fe8000002f7b115L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 14, "\ud967\udfa6\udbed\udf0b", "\u211f\ubb50\u459a\u3bd1\uc8f4\u04de\u83ea\u5dbd\ud662", "\ud81b\ude85\uda74\udd5f\uda99\udc7c\ud869\udec0\ud9a1\uded8\uda48\udf4c\ub7be\ud85f\ude96\u965d\uda2e\uddca\u7906",
        -4, 45253, -1973518953, -8194444567843256270L, -65357L, false, false, (char) 63179, (char) 22298,
        Double.longBitsToDouble(0x3fe89584aaf7b115L), Double.longBitsToDouble(0x3fe0f0ed7a5ae77aL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\ud988\uddf0\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud807\udcac\ud90b\udc72\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773050650, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3fe8a38f19605551L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 9, 9, 7, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc", "\u5304\u2f80\u7d4c\u12e8", "\uda8c\udfa6\udb50\udcdf\udb36\udd24\ud977\udd71\ud985\udcff\ud8e7\udf4b\udb27\ude5a\ud888\udf81\ud9a1\uded8\uda48\udf4c\udae4\udfa1\ud85d\udda2",
        44, 47267, -836240394, 1690266687204509029L, -66229L, false, false, (char) 51068, (char) 50605,
        Double.longBitsToDouble(0x3fe10822c40362c9L), Double.longBitsToDouble(0x3fecd7fbfaa87094L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 6, 6, 3, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\u922e\u92e5\u6751\u1fa3\ua5cf\u67c7\u70ff\ua0e2\u2c66\u6be9\u8d03\u8d4c\u0765\u636a\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud807\udcac\ud86b\udeb6\ud81a\udf13\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3fe8a38f19605551L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 5, 7, 9, "\ud992\udf53\ud8d3\udfec\udade\udfcc\udaba\udfda\udac4\udd98\uda9c\udec1\udae0\udf16\udbbf\udccd\uda12\udc4e\ud892\udccf\uda5d\uddc7\uda98\uddbb\ud8e8\udec5\udb36\udd24\ud977\udd71\udaf0\udc75\ud8b5\udc00\uda99\udc12\ud869\udec0\ud9a1\uded8\uda48\udf4c\ud8c4\udc91\ud8a4\udcf2\u965d", "\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f\uc677\uab86\ud179\u3d89\u7626\u090e\ub47b\u6122\ua612\u38d9\u5ce7\u98c8\u0fbc\u90cb\u5d95\ud41e\u585b\u64a0\uc52b\u3623\u1abf", "\uda1f\ude34\ud972\udda2\ud950\uddba\ud86b\udc1b",
        5, 16898, 1547842247, -31440918055716908L, 87913L, false, true, (char) 60740, (char) 36597,
        Double.longBitsToDouble(0x3fe1aadf8028ef6bL), Double.longBitsToDouble(0x3fd4785aa53cdceaL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 5, 5, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf", "\u4a67\u367e\u7157\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2", "\ud941\udea8\ud937\udd61\ud908\udfbc\udaca\udc9e\uda41\udd69\ud938\udff3\ud996\udffb\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud807\udcac\ud90b\udc72\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fc1dd0bf80958c8L), Double.longBitsToDouble(0x3fe8a38f19605551L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 7, 6, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\uda22\udc2f\ud881\udd18\ud968\ude2a\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud8bb\udfd2\ud918\uddbd", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\u046d\u00ea\u1b1c\u3a2c\u8d4c\u43da\u62ca\u124f", "\udb78\udeeb\ud973\ude6b\u916a\ud96d\ude01\ud950\udf45\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\ud89e\udecd\ud8ea\uddb5",
        -3, 92967, 1772105242, 9178057892243532197L, 41675L, true, true, (char) 1262, (char) 48180,
        Double.longBitsToDouble(0x3fe8a38f19605551L), Double.longBitsToDouble(0x3fe518ab42073f2fL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 1, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\uda16\ude81\udba1\udeeb\udae0\udf38\ud9fa\udd8b\udaaf\udeea\ud8ab\ude93\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\uda1a\udc19\udbaf\udec3", "\uc687\u0ef9\u66d6\u1a40\ubb07\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a3a\u8d4c\u9364\u6325\u124f\u0336\uab6a", "\udb7e\udfca\ud861\udc00",
        33, 81990, -923768080, 74219393420832745L, 67081L, false, false, (char) 17891, (char) 10192,
        Double.longBitsToDouble(0x3fe8d4d63b0769aeL), Double.longBitsToDouble(0x3fed5c74d51c8b25L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 3, 3, "\udaf4\udc24\ud8d3\udfe9\udbe8\udd12\ud960\udec4\udbde\ude00\udbb0\udee4\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud868\ude16\udb7e\udff0\ud886\udc11\ud991\udf7b\ud994\udca7\ud82c\udfed\uda99\udc12\udbd3\ude1a\ud9bb\ude23\uda48\udf4c\ud9a8\ude5e\ud8a9\ude2a\u965d\uda2e\uddca\u7906\udb2e\ude6f\ud9f9\udfa3\ud941\udea8\ud937\udd61\ud8f5\udfbc\udaca\udc9e\uda58\udcd4\ud8d6\udde8\ud979\udcc1\ud8fd\udded\udaeb\udd8f\udb7e\udfca\ud88c\udd00", "\u52ba\u6f5d\ud2ec\uac54\u3772\u0a75\u827e\ud407", "\udb48\udd04\uda9d\udecf\ue70f\udb87\ude12\udbe7\udd06\uda1f\ude93",
        1, 9194, 1431405588, 9156540834076752709L, 21286L, false, true, (char) 18429, (char) 8252,
        Double.longBitsToDouble(0x3fb683dc49766028L), Double.longBitsToDouble(0x3fe5915c53c91829L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 7, 7, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u1a40\ubb07\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u9364\u6325\uceb9\u01ce", "\ud8db\ude7e\udb7e\udfca\ud861\udc00\uda3f\udc08\ud9df\udcf5\ud91d\udfb1\uda0b\ude34\uda14\ude0c\uda1a\udd61\uda6c\udc3d\ud8ea\uddb5\udaf4\udf69\udb9d\ude1f\ud964\udd54\ud8a3\udc58\ud80e\udcc8\udba0\ude54\uda2e\udefd\ud85e\udd35\ud8c3\udd06",
        33, 5686, 1910728194, -6246065984620031648L, 21278L, false, false, (char) 15252, (char) 18429,
        Double.longBitsToDouble(0x3fd194f238b41ee2L), Double.longBitsToDouble(0x3fedde602c6fc05eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 12, 12, 14, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\ud8a9\udff3\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0e68\u66d6\u1a40\ubb07\u956a\u70ff\ua0e2\u2c66\u1b06\u0796\u8d4c\u9364\u6325\u124f\u0336", "\ud8db\ude7e\udb7e\udfca\ud861\udc00\uda3f\udc08\ud9df\udcf5\ud8d2\udceb\uda0b\udea7\uda14\ude0c\uda1a\udd61\uda6c\udc3d\ud8ea\uddb5\udaf4\udf69\udb9d\ude1f\ud964\udd54\ud8a3\udc58\ud80e\udcc8\udba0\ude54\uda2e\udefd\ud85e\udd35\ud8c3\udd06",
        33, 5686, 1910728194, 6147840189903573344L, 21278L, false, false, (char) 15252, (char) 18429,
        Double.longBitsToDouble(0x3fd194f238b41ee2L), Double.longBitsToDouble(0x3fedde602c6fc05eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 10, "\uda89\udd41", "\u997f\u211f\ubb50\u0b0f\u6a68\uc914\u04de\u83ea\u5dbd\ud662\ub754\u91de\u4a67\u8645\ucb32", "\uda4f\udc59\ud8c4\udc91\ud9ae\udc96",
        56, 52877, -517473290, 1690266687204509029L, -66229L, false, false, (char) 51068, (char) 64429,
        Double.longBitsToDouble(0x3fe447402c0362c9L), Double.longBitsToDouble(0x3fecd7f97312b095L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 7, "\udb24\udf4f\ud8d3\udf86", "\u922a\u5c5f\u459a\ub500\uc8f4\ucc93\uc37d\u5dbd\ud662", "\udaf0\udc75\udbb8\udfc9",
        5, 10259, -1513955653, -2324150992011747613L, -20997L, true, true, (char) 55229, (char) 23181,
        Double.longBitsToDouble(0x3fd651775b2f7500L), Double.longBitsToDouble(0x3f958a5e0651c8e0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 8, 8, 2, "\udb24\udf4f", "\u997f\u211f\ubb50\u4542\ub500\uc8f4\u04de\u83ea\u5dbd\ud662\ub754\u91de\u4a67\u367e\u7157\uc71e\u6dfb\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u04e0\u3a64\u8d4c\u0765\u6325\u2ebc\u039d\uab6a\ud179\u3d89\u7626\u571a\ub517", "\uda0b\ude34",
        28, 72701, 1405405783, -6203076508241060829L, -14778L, true, true, (char) 56901, (char) 16449,
        Double.longBitsToDouble(0x3feb62c4eb7df8aeL), Double.longBitsToDouble(0x3fd6bd94cf327a64L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 14, 7, 7, "\udaf4\udc24\uda45\udfe2\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udafe\udca6\uda00\udc8a\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\ub7b6\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f\u0336\ua7f4\u59b7\u3d89\u7626\u571a\ub517\u6122\ua612\u6f5d\u2e70\uac54\u2cb7\u98c0\u5d95\ud41e", "\ud80e\udcf2\udba0\ude54\uda2e\udefd\ud9bf\ude06\ud8c3\udd06\uda1f\ude34",
        1, 9194, -615644069, -1725000611855734533L, -56111L, true, false, (char) 33092, (char) 52679,
        Double.longBitsToDouble(0x3fee20b7360b5b80L), Double.longBitsToDouble(0x3fd21be43a38952aL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 4, 14, "\udaf4\udc24\uda45\udfe2\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udafe\udca6\ud994\udf94\ud998\udebd\ud892\udf42\uda5d\uddc7\ud80b\ude1f\ud9ef\udf24\udb8b\udc0e\udb4d\udce2\udb51\udf92", "\u4080\ud6f8\u66d6\u5fcb\ua5cf\u24d1\u70ff\ua0e2\u2c66\u1b06", "\ud908\udfbc\udaca\udc9e\uda41\udd69\ud938\udff3\ud996\udffb\udaaa\udf35\ud973\ude6b\udb7f\udcb6\ud9e8\uddf9",
        3, 62853, -923771051, 74219393428587232L, 88672L, false, false, (char) 19937, (char) 27829,
        Double.longBitsToDouble(0x3fedeeacd2af1909L), Double.longBitsToDouble(0x3fe0225f737df8aeL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 13, 13, 13, "\ud96f\udc86\ud9ed\udd35\udad6\udc2d\udaba\udfda", "\u6ddb\u3bd1\uc8f4\ua0ce\u605d\u3c23\u1786\u4717", "\ud8b5\udc00\ud806\ude1b\udb12\ude94",
        0, 6646, 1116390425, -3673816489004142663L, 16407L, false, true, (char) 23676, (char) 14360,
        Double.longBitsToDouble(0x3f958a5e0651c8e0L), Double.longBitsToDouble(0x3fd7885a1c51a1d2L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 11, 11, 3, "\ud959\udd7b\ud9ed\udd35\udad6\udc2d\udaba\udfda", "\u70b6\uabdf\u538a\u0533\u2c58\u7a73\u6e32\ub754", "\udbc0\udf60\uda99\udc12\ud869\udec0\uda65\ude97\ud860\udf76\udb8a\udc04\udb3c\udc5c\ud99e\udeb9\ud863\udcb0\ud860\ude91",
        7, 45253, -1964685673, -8194444569394194382L, 64436L, true, true, (char) 22604, (char) 44044,
        Double.longBitsToDouble(0x3fdd21daf177b5faL), Double.longBitsToDouble(0x3fa61198f5530040L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 10, 7, 13, "", "\u8130\ua23a\u5d9a\u6ef7\u4527\ua97d\u7462", "\udb29\udcae\ud9cd\uddf7\udb1d\udd4d\ud977\udd71\ubbb5\uda2a\ude74\uda1b\udc29\ud947\udddf\ud847\ude8c\ud9db\udcfb\udbc2\udc90",
        13, -1000, 0, 0L, -99179L, false, true, (char) 18644, (char) 51297,
        Double.longBitsToDouble(0x3fcceab0bbbe5960L), Double.longBitsToDouble(0x3f6b164f9aff7f00L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 7, 7, 6, "\udaf4\udc24\ud8d3\udfe9\udade\udfcc\uda22\udc2f\ud881\udd18\ud968\ude2a\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud8bb\udfd2\ud918\uddbd\uda19\ude51", "\u0ef9\u66d6", "\udacc\udc67\uda2e\uddca\udb70\udedc",
        14, 38219, -1973518953, -8194444566496688078L, 99384L, true, false, (char) 43773, (char) 4708,
        Double.longBitsToDouble(0x3fe89584aaf7b137L), Double.longBitsToDouble(0x3fea2f2d79272e6cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 7, 13, "", "\u8130\ua23a", "\udae0\udec5\ud9e9\udcb7\ud8be\udf46\uda0b\udebb\u7753\udb29\udcae\uda5f\ude00\udb1d\udd4d\ud977\udd71\udbbc\udfbb\uda2a\ude74\uda1b\udc29\ud947\udddf\ud847\ude8c\ud9db\udcfb\ud9ae\ude46",
        0, -1000, 0, 0L, -25707L, false, false, (char) 18599, (char) 58209,
        Double.longBitsToDouble(0x3feebf097b304a67L), Double.longBitsToDouble(0x3fcf633a7e6bfdfcL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 7, 7, 6, "", "\u8130\ua23a", "\uda29\udfb4",
        24, -1000, 12258304, 131198365990912L, -100000L, false, false, (char) 181, (char) 0,
        Double.longBitsToDouble(0x3fc0e53540020c18L), Double.longBitsToDouble(0x3fbee06bc0056250L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\012",
        Z.run(T, 2, 7, 7, 13, "", "\u65fa\ua249", "\udae0\udec5\ud9e9\udcb7\ud8be\udf46\ud84b\udc62\u7753\udb29\udcae\uda5f\ude00\uda3e\udffe\ud977\udd50\udbbc\udfbb\uda2a\ude74\uda1b\udc29\uda2a\udc70\ud847\ude8c\uda80\uddae\uda4f\udc73",
        1, 25415, 1518613156, 57588407563452416L, -54379L, false, false, (char) 18599, (char) 58209,
        Double.longBitsToDouble(0x3feebf097ebfa73bL), Double.longBitsToDouble(0x3fcf667b1d27fdfcL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 10, 14, "\udaf4\udc24\udb44\udedb\udade\udfcc\udb4b\udd83\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\ud892\udf42\uda5d\uddc7\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u67c7\u70ff\ua0e2\u2c66\u1b06\u3a2c\u8d4c\u3fee\u4435\u9b89", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud861\udc00\ud90b\udd0e\ud81a\udf01\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fd8ee85f1fb3bceL), Double.longBitsToDouble(0x3fedae5d09605551L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.joda.time.format.DateTimeFormatterBuilder:@? |this=org.joda.time.format.DateTimeFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 10, 14, "\ua1de\ud8d3\udf7c\udade\udfcc\udaba\udfda\udac4\udd98\udbb3\udf2e\udae0\udf38\udbbf\udccd\uda12\udc4e\uda99\udcc6\uda5d\ude77\ud88e\ude16\udb50\udcdf\udb36\udd24\ud977\udd71\udaf0\udc75", "\uc71e\u0ef9\u66d6\u5fcb\ua5cf\u8c30\u70bd\u4097\u2c66\u1b06\u3a2c\u8d4c\u0765\u6325\u124f", "\udb78\udeeb\ud973\ude6b\udb7f\udcb6\ud861\udc00\ud90b\udd0e\ud887\ude05\ud91b\udc16\uda0b\ude34\ud9f7\udd0a\uda1a\udd61\udb13\udf46\ud8ea\uddb5",
        -3, 92967, 1773056794, -8171215247271178325L, 42188L, true, true, (char) 696, (char) 56522,
        Double.longBitsToDouble(0x3fe47742f826f2a9L), Double.longBitsToDouble(0x3fcad93c794191a4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.format.DateTimeFormatterBuilder|append|org.joda.time.format.DateTimeFormatter|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|append|org.joda.time.format.DateTimeParser|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|append|org.joda.time.format.DateTimePrinter|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|append|org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|append|org.joda.time.format.DateTimePrinter,[Lorg.joda.time.format.DateTimeParser;|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|append0|java.lang.Object|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|append0|org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|appendCenturyOfEra|int,int|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|appendClockhourOfDay|int|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|appendClockhourOfHalfday|int|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|appendDayOfMonth|int|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|appendDayOfWeek|int|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|appendDayOfWeekShortText||new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|appendDayOfWeekText||new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|appendDayOfYear|int|new:org.joda.time.format.DateTimeFormatterBuilder:",
    "M|org.joda.time.format.DateTimeFormatterBuilder|appendDecimal|org.joda.time.DateTimeFieldType,int,int|new:org.joda.time.format.DateTimeFormatterBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
