package org.joda.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class Period_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 6, 16, 8, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, 2067049315, -9211372500067064158L, 18688L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 6, 0, 9, "\ud917\udc8d\ud84a\udd98", "\u6050", "\ud95c\udf43\u34d3\ud90a\ude63\ud877\udf60\udb06\udd67\u76d6\uda9b\udd4f\udbd5\uddff\ufd68",
        58, 53482, -399244930, 6760676303512416579L, -42040L, true, false, (char) 39034, (char) 26710,
        Double.longBitsToDouble(0x3fc4465086534654L), Double.longBitsToDouble(0x3f88ceefebe62a40L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\0121=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 0, 11, 13, "\ud9c1\udd37", "\u77c2\u6050\u0af1\ua1d2\u0fd7\ub23c\u5f05\u2818\u336e\u8179\u540c", "\ud852\udc06\udaaf\udde5\ud8c2\uddff\ud9c1\udcce\ud853\udd85",
        39, 14240, -929631177, 4261478251429637427L, -59444L, false, false, (char) 43096, (char) 734,
        Double.longBitsToDouble(0x3fd13e5b50a1032cL), Double.longBitsToDouble(0x3fcf549bfc8b5f40L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 2, 1, 14, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        -4, 52400, 2067049315, -9211372500067064158L, 18688L, true, true, (char) 55774, (char) 43613,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 6, 15, 8, "\ud9c1\udd37\ud9af\udd9a\udbf4\udfff\udb6e\ude06\ud877\udff5\ud9eb\udecd", "\u2f21\u4100\u3245\u10ee\ucac2\u540c\u9592", "\udaaf\udde5\ud8c2\uddff\ud9c1\udcce\ud853\udd85\ud80a\udd83\ud9c3\udcd5\ud0f3\ud8ae\udf60\ud842\udc2d\udaf4\udde5\udbcb\udfac\uae26\u4abd\udaaa\udc7b\udb8d\udd9f\ud8be\udef1\udaf5\ude9b",
        6, 1510, -762263113, 1373129552918948788L, -62124L, false, true, (char) 30095, (char) 63261,
        Double.longBitsToDouble(0x3f98df9ab81a3100L), Double.longBitsToDouble(0x3fe900a6145c63afL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 6, 6, 4, "\ud86d\uddc8\udb79\udd0b\udbf5\udc22", "\u0af1\ua1d2\u7ffe\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u406a\u98d6\u760f\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\uda87\ude8f\udbc6\udd41\ud978\udd16\udb23\ude15\ud972\udc37\ud95b\ude20\u4b6c\udb9e\udc42\udb0f\udfa2\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud8c0\udc93\uda7a\udd36\ud98f\ude6d\udbb9\udd72\uda31\uddce",
        23, 52253, 2067049315, -9211372500067064158L, 18688L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a5ffb43c8L), Double.longBitsToDouble(0x3fe5ea2f78969fd0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 5, 16, 8, "\ud96d\udd2d\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ua9b8\u6b33\u625a\u3f4a\u563b\u26e7\uc476\ua64f\uaa8a\uadfb\u5dfa\u895a\u0435\u5192\uca45\u80c4\u4740\u5c4f\u9712\u00e4\u06a0\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\udbbc\udefc\udbcd\udd32\ud87c\udd34\udbab\uddb4\udb0f\udfa2\ud84a\udc9b\udae8\udc34\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, 2067049315, -9211372500067064158L, 18688L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 16, 16, 8, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u26bf\u5593\u653a\uc18d\u4846\u2c89\u8c4e\u8179\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u267a\u26e7\uc476\uc8c8\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08",
        56, 61392, 1672456149, -5775571459120762987L, -48483L, false, false, (char) 65099, (char) 57342,
        Double.longBitsToDouble(0x3fccb41b3b9c58dcL), Double.longBitsToDouble(0x3fde4f7f1fcf6970L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 6, 15, 14, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u06bb\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\ua99b\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u5069\u359b\u0718\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udb0c\udf1d\udbb9\ude82\udb84\udc28\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, -1567145657, 4551514712340122805L, 18688L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c1a1b8L), Double.longBitsToDouble(0x3fba7b4b04b0b728L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 16, 8, "\ud9c1\udd37\ud8f8\udcbe\udbf4\udfd4", "\u0af1\u0847\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ub4b8\u6b33\u625a\u6fbc\u267a\u48fd\u138c\u7817\uaa6b\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7959\u4f48\u1e08\u1c01", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udd85\udb8f\udc06\udbd6\udd5a\udb37\ude07\udbdd\udcdc\udb21\udc4b\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, 2067049315, -9211372500067064158L, 79872L, true, false, (char) 46268, (char) 43512,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0.023S\012",
        Z.run(T, 2, 6, 14, 8, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u7bf3\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\uc3cd\u6e66\u81ee\ub585\uaa8a\uadfb\u5a0a\u0a31\u049a\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud8db\udce8\ud831\udef5\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, 2067049315, -9211372500067064158L, 18688L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT-0.005S\012",
        Z.run(T, 2, 6, 14, 1, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u36dc\u6a66\u6b33\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u61f1\u4f48\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udad0\udf88\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\udb2f\udf6a\uda7a\udd36\ud98f\ude6d\udb72\uddee\000",
        -5, -1000, 2067049315, 11999537329602560L, -100000L, false, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 1, 6, 16, 8, "\ud9ac\udc65\ud910\udcea\udbf5\udc22\udb6e\ude06\ud877\udff5\ud9eb\udecd", "\u52aa\u4100\u3245\u7e10\u8179", "\ufd68",
        58, 21178, -391183521, 6760676301901803843L, -87684L, true, true, (char) 59173, (char) 13098,
        Double.longBitsToDouble(0x3f88ceefebe62a40L), Double.longBitsToDouble(0x3fef71f77d13e5b5L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.joda.time.Period:P8D\0121=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 3, 8, 10, "\ud9c1\ude27\ud910\udcea\udbf5\udc22", "\u1e5b\ube59\u0fd7\u863a\u4100\u03d5\u72ce\u8179\u6a45\u3400\u6cdc\u6b33\u625a\u6fbc\ud62d\ub702\u072d\u4c2d\uab31\uadfb\u5f91\u0577\u0435\ubdba\u7ad2\u1f68\u9839\u6fb6\u7159\u4f48\u0654\u1bc9", "\ud869\udcb9\udbc6\udd41\ud978\udd16\udafe\udde1\ud85b\udcd0\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2",
        8, 30533, -1089948856, -3008886515620694333L, -62882L, false, true, (char) 63678, (char) 7496,
        Double.longBitsToDouble(0x3fde4f7f1fcf6970L), Double.longBitsToDouble(0x3fd288e0282aae4aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 4, 16, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ua9b8\u6b33\u625a\u30bb\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, 2067049315, -9211372500067064158L, 18688L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.joda.time.Period:P50D\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 3, 15, 8, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0a5d\u126a\u0fd7\u863a\u4100\u8c00\u7e0a\u092f\ud61e\u1c6a\ua9b8\u6b33\u625a\u88bc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\uc859\u4740\u5c4f\u7159\u337f\u06d0\u0205", "\ud903\udd0c\ud93f\udcc7\uda63\udecf\ud819\ude44\ud8c5\udcbe\udbd6\udd5a\ud89b\udef9\udbab\uddb4",
        50, 71973, -1334144819, -4681294690929194584L, 29828L, false, false, (char) 57342, (char) 19390,
        Double.longBitsToDouble(0x3fe738b309e4f7f1L), Double.longBitsToDouble(0x3fef3da5c5286431L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT23H\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 13, 16, 8, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\udbd9\ude18\uda01\udf9c\ud907\udc13\udafe\udde1\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, 2067049315, -9211372500067064158L, 18688L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3fe8faf518964aa4L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT23H\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 4, 8, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u5e7a\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f4c\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, 2067049315, -9211372500067064158L, 18688L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.joda.time.Period:P56D\0121=org.joda.time.Period:P56D\012",
        Z.run(T, 2, 3, 3, 8, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\ud32f\u85f8\uba5e\u8591\u4100\u3245\u7e10\u8179\u1a92\u7ed3\u3d46\u6b2c\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u43b9\ud3bc\u261a\u1679\u5c4f\u7159\u4f48", "\udbbd\udd6b\ud8af\udfc7\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08",
        56, 49688, 1672456149, -5775571459120762987L, -48483L, false, false, (char) 65099, (char) 57342,
        Double.longBitsToDouble(0x3fef2f226bf02c61L), Double.longBitsToDouble(0x3fdc0ec0dfcf2a40L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT0.056S\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 4, 0, "\ud9c1\udd37\ud910\udcea\udbf5\udc22\udb6e\ude06\ud877\udff5\ud9eb\udecd\ud958\ude6c\ud95c\udf43\ud8cd\udcc8", "\u443a\ucb2a\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u471a\ub16e\u5192\uca45", "\ud8be\udef1\udaf5\ude9b\udbf6\udfb7\udb67\udfec\ud80e\ude8e\udbbd\udd6b\ud8af\udfc7\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08",
        56, 49688, 1672456149, -5775571459120762987L, -20176L, false, true, (char) 65099, (char) 57266,
        Double.longBitsToDouble(0x3fef2d04d6e71661L), Double.longBitsToDouble(0x3fde4f7f1fcf6970L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 15, 1, 4, "\ud9c1\udd37\ud910\udcea\udbc3\udf2b", "\u0af1\u7dd2\u0fd7\u397d\u4100\u3245\u7e10\ua465\uc79a\u5c54\ua9b8\u6b33\u625a\u6fbc\uc035\u9be7\u5464\u5dcf", "\ud94c\udf4b\ud861\udc36",
        55, 66452, 1055854511, -1894555371111542509L, 98694L, true, false, (char) 60396, (char) 4339,
        Double.longBitsToDouble(0x3fe96d03700c8673L), Double.longBitsToDouble(0x3fc1b7ce4ebe4204L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:P-3D\012",
        Z.run(T, 2, 6, 3, 16, "\ud917\udc8d\ud84a\udd98", "\000", "\ud95c\udf43",
        -3, 95170, -1148574871, -1749214328728121463L, 17028L, false, true, (char) 47215, (char) 21026,
        Double.longBitsToDouble(0x3fd7ee85fe8fd068L), Double.longBitsToDouble(0x3f377494ea400000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 0, 9, "\ud917\udc8d\ud84a\udd98", "\u6050", "\ud95c\udf43\u34d3\ud90a\ude63\ud877\udf60\ud827\udcd3\ud801\udc6d\udaba\udefc\udbd5\uddff\ufd68",
        58, 53482, -399244930, 6760676303512416579L, -42040L, true, false, (char) 39034, (char) 26710,
        Double.longBitsToDouble(0x3fc4465086534654L), Double.longBitsToDouble(0x3f88ceefebe62a40L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT0.058S\0121=org.joda.time.Period:PT58H\012",
        Z.run(T, 2, 14, 13, 6, "\ud982\ude1d\ud84a\udd98", "\u6050", "\ud8c1\udd35\ud9a0\udfa7\ud9c0\udee6\ud877\udf60\udb06\udd67\u76d6\uda9b\udd4f\udbd5\uddff\ufd68",
        58, 53482, -389871234, 6760572949419405635L, -42040L, true, false, (char) 39034, (char) 26710,
        Double.longBitsToDouble(0x3fc4465086534654L), Double.longBitsToDouble(0x3f88ceefebe62a40L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\0121=void |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 1, 2, 9, "\ud917\udc8d\ud870\udf73", "\uc0b2", "\ud8cd\udf71\u34d3\ud90a\ude63\ud877\udf60\udb06\udd67\u76d6\udaaa\udf4f\udbd5\uddff\ufd68",
        58, 53482, -399244930, 8303547302348694498L, 23496L, true, false, (char) 56509, (char) 9805,
        Double.longBitsToDouble(0x3fd99547a225a32aL), Double.longBitsToDouble(0x3f88ceee595e4500L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT58H\012",
        Z.run(T, 1, 13, 0, 0, "\ud917\udc8d\ud84a\udd98", "\u6050", "\udab2\udc0d\udaeb\udc5a\ud91a\udde0\ud877\udf60\udb06\udd67\u76d6\uda9b\udd4f\udbd5\uddff\ufd68",
        58, 53482, -399244930, 6760676303512416579L, -42040L, true, false, (char) 39034, (char) 54357,
        Double.longBitsToDouble(0x3fe0a2629994d90eL), Double.longBitsToDouble(0x3f88ceefebe62a40L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.joda.time.Period:PT0S\0121=void |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 2, 2, 14, "\ud9c1\udd37\ud910\udcea\udb6c\udf5e", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ua9b8\u6b33\u625a\u5938\u4ef9", "\ud9c3\udca6",
        53, 78724, 847523123, -3344568538639146604L, -23475L, false, false, (char) 28121, (char) 19837,
        Double.longBitsToDouble(0x3fe13334deea0b23L), Double.longBitsToDouble(0x3fcf659799a59588L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.joda.time.Period:P-4D\0121=org.joda.time.Period:P-4D\012",
        Z.run(T, 2, 3, 3, 14, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udafe\udde1\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        -4, 52400, 2067049315, -9211372500067064158L, 18688L, true, true, (char) 55774, (char) 43613,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\0121=org.joda.time.Period:PT0S |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 15, 15, 8, "\ud9c1\udd37\ud9af\udd9a\udbf4\udfff\udb6e\ude06\ud877\udff5\udb35\udecc", "\u2f21\u4100\u3245\u10ee\ucac2\u540c\u9592", "\udaaf\udde5\ud8c2\uddff\ud9c1\udcce\ud853\udd85\ud80a\udd83\ud9c3\udcd5\ud0f3\ud8ae\udf60\ud842\udc2d\udaf4\udde5\udbcb\udfac\uae26\u4abd\udaad\ude9c\udada\udf9b\ud8b6\udc72\udaf5\ude9b",
        6, 1510, -762263113, 1373129552918948788L, -62124L, false, true, (char) 30095, (char) 63261,
        Double.longBitsToDouble(0x3fec06fcd5447166L), Double.longBitsToDouble(0x3fe900a6145c63afL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.joda.time.Period:P23D\012",
        Z.run(T, 1, 3, 16, 8, "\ud9c1\udd37\ud8f8\udcbe\udbf4\udfd4", "\u0af1\u7d3e\u0fd7\u863a\u4100\u3245\u7e10\u6dd1\u2f9f\u9592\u9ab8\u6b33\u625a\u6fbc\u0c19\ua6f1\u845a\u7817\u56dd\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7959\u4f48\u1e08\uc9ee", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\udbcc\udc5b\uda2c\udc4b\udbd6\uddeb\udb37\uddca\udbdd\udcdc\udb21\udc4b\udb0c\udf1d\uda20\udd3a\udb57\udf83\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\udad4\udf24\ud98f\ude83\ud8fd\udd74\uda31\uddce",
        23, 52253, 2067049315, -9211372500067064158L, 79875L, true, false, (char) 46268, (char) 43512,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3fd69ed2c12cc3b4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT0.007S\0121=org.joda.time.Period:PT0.007S\012",
        Z.run(T, 2, 14, 14, 8, "\ud9ce\udde6\ud910\udcea\udbf5\udc22\udb6e\ude06\ud877\udff5\ud9eb\udecd\ud958\ude6c\ud95c\udf43", "\u3245\u7e10\u9af2\u540c\u1d93\u4585", "\udbc1\udd54\udae8\udcc8\ud861\udf71\udbce\udea0\ud954\udd36\udbc4\udfb5\ud845\uddc4\ud9c0\udcd5\uda67\udc69\udbcc\udc11\u8b02\ua3fd\ud960\udfa7\ud85e\udf4f\ud8be\udef1\udaf5\ude9b\udbf6\udfb7\ud9be\udf57\ud850\udd9d\udbbd\uddb0\ud8af\udfc7\ud8be\udd8b\udb90\udc98\uda63\uded7",
        7, 61753, -779598824, 1495931472117982677L, -78933L, true, false, (char) 25538, (char) 2225,
        Double.longBitsToDouble(0x3fe61eb1f6dce2f7L), Double.longBitsToDouble(0x3fcfd0f5bd7a2280L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT0.023S\0121=org.joda.time.Period:PT0.023S\012",
        Z.run(T, 2, 14, 14, 8, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u3ffa\u106d\u0fd7\u863a\u4100\u3245\u7e10\u4846\u540c\u9592\ua9b8\u6b33\u081b\u179c\ua051\u43c9\u7940\u81e7\u8d5f\u1d81\u9e25\u133a\u049a\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud8db\udce8\ud831\udef5\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\ud9c0\udc7a\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, 2067049315, 5848664654105045429L, 43456L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT-0.005S\0121=org.joda.time.Period:PT-0.005S\012",
        Z.run(T, 2, 14, 14, 1, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u2058\u6adf\u6cae\u50fe\u3f60\u267a\u0523\uc476\ua64f\uaa8a\u5bc7\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u61f1\u4f48\u0654\u1bc9", "\ud8ec\udc03\udbc6\udd41\ud978\udd16\ud955\udcae\ud8e2\udda4\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udad0\udf88\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\udb2f\udf6a\uda7a\udd36\ud98f\ude6d\udb72\uddee\000",
        -5, -1000, 2067049315, 11999537329602560L, -93119L, true, true, (char) 16180, (char) 43593,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3feb4f6960964aa4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.joda.time.Period:PT23H\0121=org.joda.time.Period:PT23H\012",
        Z.run(T, 2, 13, 13, 8, "\ud9c1\udd86\ud910\udcea\udbf5\udc22", "\u0af1\ua1d2\u0fd7\u863a\u4100\u3245\u7e10\u8179\u540c\u9592\ua9b8\u7054\u625a\u6fbc\u267a\u26e7\uc476\ua64f\uaa8a\uadfb\u4112\u059f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\udbbb\udcd3\uda76\udd67\ud907\udc13\udafe\udde1\ud8d3\udc08\udbd6\udd5a\ud89b\udef9\udbab\uddb4\udb0f\udfa2\udb0c\udf1d\udb7d\udd79\udb83\udf73\u9732\udbe1\udd0c\u934d\ud812\uddf5\ud9de\uddc2\uda7a\udd36\ud98f\ude6d\ud8fd\udd74\uda31\uddce",
        23, 52253, 2069773411, -9211372500067064158L, -37794L, true, true, (char) 24484, (char) 25886,
        Double.longBitsToDouble(0x3fb5708a68c301b8L), Double.longBitsToDouble(0x3fe8faf518964aa4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.Period:PT0S\0121=void |this=org.joda.time.Period:PT0S\012",
        Z.run(T, 2, 6, 2, 4, "\ud9c1\udd37\ud910\udcea\udbf5\udc22", "\u3b9b\ua1d2\u0fd7\u863a\u4100\u3245\u7d81\u8179\u540c\u9592\ua9b8\u6b33\u625a\u6fbc\u740b\u26c3\uc476\u8679\uaa8a\uadfb\u652b\u4f5f\u0435\u5192\uca45\u80c4\u4740\u5c4f\u7159\u4f48\u0654\u1bc9", "\ud849\uddde\udbc6\uddf8\ud822\ude28\ud98c\ude29\ud8d3\udc08\udbd6\udd5a\ud89b\ude87\udbab\uddb4\udacf\udce2\udb0c\udf1d\ud905\udc1d\udb83\udf73\u9732\udbe1\udd0c\u934d\ud802\udf22\ud9de\uddc2",
        20, 42623, -1272493340, 7219692309227879720L, 97936L, false, true, (char) 59084, (char) 38640,
        Double.longBitsToDouble(0x3fb839333f9dd690L), Double.longBitsToDouble(0x3fbf24ae01a13cd0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.Period|normalizedStandard||new:org.joda.time.Period:",
    "M|org.joda.time.Period|normalizedStandard|org.joda.time.PeriodType|new:org.joda.time.Period:",
    "M|org.joda.time.Period|checkYearsAndMonths|java.lang.String|new:org.joda.time.Period:",
    "M|org.joda.time.Period|days|int|static",
    "M|org.joda.time.Period|fieldDifference|org.joda.time.ReadablePartial,org.joda.time.ReadablePartial|static",
    "M|org.joda.time.Period|getDays||new:org.joda.time.Period:",
    "M|org.joda.time.Period|getHours||new:org.joda.time.Period:",
    "M|org.joda.time.Period|getMillis||new:org.joda.time.Period:",
    "M|org.joda.time.Period|getMinutes||new:org.joda.time.Period:",
    "M|org.joda.time.Period|getMonths||new:org.joda.time.Period:",
    "M|org.joda.time.Period|getSeconds||new:org.joda.time.Period:",
    "M|org.joda.time.Period|getWeeks||new:org.joda.time.Period:",
    "M|org.joda.time.Period|getYears||new:org.joda.time.Period:",
    "M|org.joda.time.Period|hours|int|static",
    "M|org.joda.time.Period|millis|int|static",
    "M|org.joda.time.Period|minus|org.joda.time.ReadablePeriod|new:org.joda.time.Period:",
    "M|org.joda.time.Period|normalizedStandard||new:org.joda.time.Period:",
    "M|org.joda.time.Period|normalizedStandard|org.joda.time.PeriodType|new:org.joda.time.Period:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
