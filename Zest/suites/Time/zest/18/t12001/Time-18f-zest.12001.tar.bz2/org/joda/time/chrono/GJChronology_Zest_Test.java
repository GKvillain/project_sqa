package org.joda.time.chrono;
import org.junit.Test;
import static org.junit.Assert.*;
public class GJChronology_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 1, 8, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u3ab5\u7793\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 1, 8, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u3ab5\u7793\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8bf\udeb7\u52c9\ud9ec\uded4\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 8, "\ud8ba\udde7", "\u5d2f", "\ud932\udcf9",
        11, 67513, -1985988068, -4895531295637050467L, 70777L, true, false, (char) 52259, (char) 6214,
        Double.longBitsToDouble(0x3fe08dc71000d37dL), Double.longBitsToDouble(0x3fb1e518c03dd408L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 1, 7, 2, 13, "\ud8ba\udde7\udb69\udd32", "\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\u880d\u8982\uc7af", "\ud831\udc8e\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud9b8\udc82",
        42, 30293, -64166718, -1164364325286937108L, -54289L, true, true, (char) 50243, (char) 36731,
        Double.longBitsToDouble(0x3fe4f1197c7622c6L), Double.longBitsToDouble(0x3fb963b1e47c7208L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 1, 8, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\uc2d2\u152e\ubad2\u53b3\ub84c\u8982\u8862\u7399\u8db2\u8085", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\ud8a7\ude14",
        1, 18387, -2083396707, -275593955572754223L, 96664L, true, false, (char) 25793, (char) 60205,
        Double.longBitsToDouble(0x3fe14bf37a8f44f7L), Double.longBitsToDouble(0x3febcd4d04f44d4fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 1, 13, "\ud8ba\udde7", "\u1cbd\ud66a\u16f3\uba7c\u7df4\u69f3\ub4a6\u25f2\u1562\u8982\uc7af\u3ab5\u7793\u6475", "\uda8d\udcd2\udb64\udcaf\ud8d6\udc0b\uda67\udf57\udbbb\udd89\udba4\udd55\ud914\udcbc\ud99d\udc8c\ud87d\ude00\udb15\udc01\ud9cc\udc94\ud947\udd1a\udbc0\udebc\udba5\ude33\ud955\udc31\udb2d\udde0\ud8f2\udc93\ud955\udc32\ud9ec\ude3e\ud9f0\uddc2\ud9d4\udf7f\ud9a5\ude39\udbbd\uddde\ud93d\udc07\ue418\ud8ea\udecd\ud843\udcf8\ud82b\uddf3\ud8e3\udc20\uda04\ude2b\ud8d9\udf21\udb08\udcc5\ud8e0\udead\udbd8\udeed\udbb6\udff5\udb10\udfd3\uda1c\udda2\udbf4\udd64\ud9d5\udf9d\ud942\ude34\uda01\udcd7\uda52\udd96",
        41, 25468, 1556166820, 802704895347643183L, 14137L, true, false, (char) 32757, (char) 11251,
        Double.longBitsToDouble(0x3fe93b50f9cfd969L), Double.longBitsToDouble(0x3fe9e3da49a46ac5L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 6, "\ud8ba\udde7", "\u1bee\ub374\ub64d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\ud05c\u3ab5\u7793\u6475", "\udb35\udfae\udbe6\udead\ud8d6\udc0b\u08f2\udb10\udcc6\udaa3\uddb1\udbd9\ude4f\udbe7\udc91\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\uda1e\udd74\udb96\ude15\udbda\udf4e\ud9ec\ude39\ud9d5\udcd5",
        51, 19009, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e6663efcL), Double.longBitsToDouble(0x3fecbbe90fb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 13, "\uda1a\ude35", "\u1bee\ub374\u365d\ua0cf\ud739\u796f\u60c1\u53b3\ub84c\u8982\uc7af\u3ab5\u7793\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ub4b2\ud8f5\ude55\ud99d\udc8c\ud90b\udc66\ud84e\udd8a\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802626096460861L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 15, "\ud8ba\udde7", "\u1bee\ub374\u36f9\ua0cf\u3074\ucfef\ubad2\u53b3\ub8d2\u8982\uc7af\u3ab5\ud592\u6475", "\ud882\udc71\udb08\udf27\ud975\udd29\u08f2\udbbb\uddfd\ud950\udfad\udbd0\udc69\udb73\udd3d\udb0c\udd5e\ud900\udd9b\uda54\udc0b\ud949\udd1a\ud896\udc10\udb0c\uddf7\ud8f2\udf9b\ud8af\udfdd\uda5e\udd5a\udb20\udca1\ud9cc\udeeb\ud9d5\udcd5",
        19, 53209, -1449086321, -4212765605537839977L, -19248L, false, false, (char) 2861, (char) 18052,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 13, "\ud8ba\udd91", "\u509e\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u3ab5\u7793\u6475", "\uda4c\udc78\udbe6\udead\ud8d6\udc0b\ubfc8\udbb1\udd92\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\ud8f4\udf9a\ud90a\udf65\ud904\udd95\ud8f2\udd55\ud809\uddec\ud9c8\udcf1\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3feefec10eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 16, 15, "\ud8ba\udde7", "\u1bee\u190e\u0cdb\u3c5e\ua354\u2051\u51f0\u53b3\u24ae\ub719\ub7e4\u3ab5\ua3cf\u6b5c", "\ud884\udc2a\ud9dd\udfe3\ud90f\uddea\ud818\ude9f\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\udaba\udc1b\udac7\udf9c\udb90\ude22\udb99\udd54\uda47\udeee\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8b0\udc04\ud8f2\udd55\ud955\udc32\udacb\ude2e\uda73\udc50",
        26, 49292, -1449086384, 5570802627790701812L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3fd6bfcfc741900eL), Double.longBitsToDouble(0x3fecbbeb9eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u3ab5\u7793\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 1, 10, 9, 8, "\ud8ba\udde7", "\u1bee\u5b86\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u3ab5\u7793\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\udb8a\udf6a\ud8e7\udc6d\ud8f2\udce5\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 14, 13, "\ud8ba\udde7", "\u1bee\u8574\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\u614d\uad44\uc7af\u3ab5\u7793\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc05\u08f2\udbbb\uddfd\ud950\udfad\udb58\udc41\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\ud8ad\ude9f\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802627801711860L, 81392L, false, false, (char) 47120, (char) 48690,
        Double.longBitsToDouble(0x3feb5dfb66663efcL), Double.longBitsToDouble(0x3fb6c64731a47248L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 14, 3, "\ud8ba\udde7", "\uc037\u0eca\u85c3\ud0ab\u3074\ucfef\ubad2\u53b3\ub80d\u8982\uc7af\ua92a\u7793\u6475", "\uda34\udd16\udbe6\udead\ud9ab\uddf7\ud89f\udd81\ud8c7\udd0e\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66",
        28, 69141, 1245911226, -5817016300906355811L, -57201L, false, true, (char) 45656, (char) 38799,
        Double.longBitsToDouble(0x3fd04dba48187e44L), Double.longBitsToDouble(0x3fe14bf37a8f44f7L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 14, 6, "\ud8ba\udde7\udb69\udd32", "\ub374\u365d\ua0cf\u3074\u08d3\ubb69\u0f6c\u1bf8\ua884\u7323", "\ud831\udc8e\ud9ee\udf9b\ud8f2\uddac\uda3a\udf44\udbe6\udead\ud8d6\udc0b\u0801\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ue28a\ud90b\udc66\ud80d\udf94\ud817\udd61\uda27\udce5",
        -4, 30293, -64166718, -1164364325286937108L, -18031L, false, true, (char) 21182, (char) 25345,
        Double.longBitsToDouble(0x3fc21f2d11d80798L), Double.longBitsToDouble(0x3fd1283c74b39890L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 1, 8, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u3ab5\u7793\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8bf\udeb7\u52c9\ud9ec\uded4\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 26924, (char) 18159,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 15, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u9a3b\ucfef\ubad2\u53b3\000\000\000\uca12\u7793\u00bf", "\udbfc\udc26\007\000\000\udbbb\udd43\ud950\udfad\ud83a\udf3e\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda47\udc00\ud943\udc60\ud830\uddbd\ueb00\000\ud8af\udfdd\ud8bf\udeb7\u52c9\udac9\udd02\ud9d5\udcd5",
        51, 84681, 0, 5570802625655342324L, -19248L, false, false, (char) 31845, (char) 31297,
        Double.longBitsToDouble(0x3feb5fe7e1000000L), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 1, 11, 0, 8, "\udabf\udebc", "\u5d2f", "\ud845\udd19\uda58\udebc\udaee\udedc\ud895\udebe\ud836\udd04\ud8d3\udcf0\ud985\udc87\ud88c\udea0\ud8b6\udc6c",
        4, 83453, -746736111, 4639657593945984820L, -44875L, false, false, (char) 60221, (char) 8362,
        Double.longBitsToDouble(0x3fdee0538bea5622L), Double.longBitsToDouble(0x3fd912be9de5cf02L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 6, "\ud8ba\udde7", "\u1bee\ub374\ub64d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\ud05c\u3ab5\u7793\ubb8d", "\udb35\udfae\udbe6\udead\ud8d6\udc0b\u08f2\udb10\udcc6\udaa3\uddb1\udbd9\ude4f\udbe7\udc91\ud90b\udc66\ud84e\udfb4",
        30, 75226, -1354379649, -8948120721223260990L, -66213L, false, false, (char) 17048, (char) 25793,
        Double.longBitsToDouble(0x3f887e450a5f9bc0L), Double.longBitsToDouble(0x3fe47a27bf79a9a0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 14, "\ud8ba\udde7\udb69\udd32\uf018", "\u1d55\ua0cf\u3074\u85dd\ub09c\u543b\ub84c", "\ud8b6\udc37\udabd\ude2b\ud94e\udf0b\ud8f8\udf9f\udbad\udd12\udb35\udfae\udbe6\udead\ud8d6\udc0b\u08f2\ud93e\udcbd\udaa3\uddb1\udbd9\ude4f\udbe7\udc91\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud93b\udcea\ud830\uddbd\uda15\udc4b\ud907\udc88\uda1e\udd74\udb96\ude15\ud91b\udc0f\ud9ec\ude51\ud9d5\udcd5",
        51, 19009, -1449086321, -482035274132285451L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e6663efcL), Double.longBitsToDouble(0x3fecbbe90fb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 8, "\ud8ba\udde7", "\u11fb\u1c81\ub64d\ua0cf\u933f\ud029\ubad2\u53b3\ub84c\u3883\ua6ae\ua222\u075f\u6475", "\udb35\udfae\udadf\udd29\ud8d5\udf78\udbc1\udcd1\uda1e\uddb6\ud9b2\ude02\udbd9\uddb1\udbe7\udc91\ud90b\udc66\ud987\udc11",
        4, 75271, -1354379649, -8948120719964969790L, -45634L, true, true, (char) 7982, (char) 37906,
        Double.longBitsToDouble(0x3fe5cb6d777964c1L), Double.longBitsToDouble(0x3fe5c26a7bf1ad26L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 12, 10, 16, "\ud8ba\udde7", "\u1bee\ub374\ub64d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\ud05c\u3ab5\u7793\u1ba0\u597a\u082a\ua96d\u2d5e\u6b60\u5f9c\u1e2d\u95b3\u5a87\u0aa3\u16ff\u2858\uc585\u10be\u3ed1\u206f\u7839\u4daa\ud5de\u8f74\u1147\ucbf0\u51e6\u6de6", "\ud819\udc7e\uda32\udeae\udaab\udcac\udb6f\uddc9\ud946\udd58",
        49, 83347, 2099365478, -6007292179473381452L, 26863L, true, false, (char) 32715, (char) 9062,
        Double.longBitsToDouble(0x3fed14129b591845L), Double.longBitsToDouble(0x3fa5d1bf58a89590L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=org.joda.time.chrono.GJChronology:GJChronology[UTC]\012",
        Z.run(T, 2, 12, 12, 0, "\ud8ba\udde7", "\u1bee\ub374\u4959\000\u3074a\ubad2\u53b3\ub84c\u8982\ud05c\u3ab5\u778c\u6475", "\udb35\udfae\udbe6\udead\ud8d6\udc0b\u08f2\udb10\udcc6\udaa3\uddb1\udbd9\ude4f\udbe7\udc91\ud90b\udc66\u28f3\uda1c\udfae\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\uda1e\udd74\000\000\ud9ec\ude39\ud9d5\udcd5",
        51, 19009, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 2861, (char) 65,
        Double.longBitsToDouble(0x3feb5fe7e6663efcL), Double.longBitsToDouble(0x3fecbbe90fb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=6]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 9, "\udba7\uddc8\udb57\udf32\uf018", "\uc4fd\ua0cf\uc2d2\ud415\u394b\ub070\ub85e", "\ud8ce\ude37\udabd\ude2b\ud831\udc8e\ud9ee\udf9b\uda40\udd33\udb35\udfae\udbe6\udead\ud8d6\udc0b\udacb\udcd5\udb10\udcc6\udaa3\uddb1\udbd9\ude4f\udbe7\udc91\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\udbaf\udf6e\udb96\ude15\ud8f4\udda9\ud9ec\udec9\ud9d5\udcd5",
        6, 93425, 1872999055, 5570802627801711860L, -19248L, false, false, (char) 2861, (char) 60826,
        Double.longBitsToDouble(0x3feb3d9e66663efcL), Double.longBitsToDouble(0x3fecbbe90fb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533677-09-29T05:21:51.860Z,mdfw=6]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u2b98\u9e53\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud9a5\udc60\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        6, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 60833, (char) 18889,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ubb7c\ua9a6\u53b3\ub84c\u8982\uc7af\u3ab5\u7793\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=6132-09-06T14:19:08.160Z,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u644b\000\u8982\uc6c8\u3ab5\u7793\u48bf", "\uda0f\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud801\udfc8\ud9ec\udddb\ud9d5\udcd5",
        7, -1000, 0, 131361574748160L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 10, 7, 13, "\ud8ba\udde7", "\u1bee\u408f\u32c8\ua0cf\u3074\ucfef\ubad2\u0e16\u6195\uad44\ua0de\u3a3f\u7793\u6475", "\ud969\udd7c\uda02\udc2e\udbd6\ude8b\u08f2\udbbb\uddfd\ud950\udfad\udb58\udc41\ud99d\udc8c\ud92b\ude66\uda75\udc28\uda54\udc0b\ud949\udd1a\ud830\uddbd\ud8ad\ude9f\ud907\udc4e\ud8af\udfdd\ud848\ude60\ud92b\udc18\ud9ec\ude3e\ud9d5\udcd5",
        51, 84681, -1449086321, 5570802627801711860L, 26799L, false, true, (char) 33883, (char) 56683,
        Double.longBitsToDouble(0x3fb6cd70b1a47248L), Double.longBitsToDouble(0x3feb55d5561ea256L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-45447190-01-14T01:51:50.312Z,mdfw=5]\012",
        Z.run(T, 1, 9, 14, 3, "\ud80b\ude8f", "\uc037\u0eca\u85c3\ub6ac\u3c4b\u0a1f\u8549\u53b3\ub80d\u8982\uc7af\ucc86\u7795\u6475\uc392\u9951\u794b\u2808\uc0b4\u468f\u3b94\u28e8\u617a\u4178\u1caa\u2858\ud1f7\u10be\u3ed1", "\udbad\udf3c\ud82d\udcdf\ud937\udcb1\ud973\udf2f\ud857\udeb7\ud955\udea1\ud87d\udf13\udb83\uddfb\uda57\ude27\ud915\udebc\udbca\udf41\ud849\udc54\ud9cb\udea9\ud9b1\udee2\ud825\udd19\ud918\udf74\udafe\udd5e\udba5\uddc1\uda67\udda5\ud866\udd59\ud9af\udeb7\udbc5\udeda\udad3\udf4c\udbf0\ude8b\udb56\udccd\uda6c\ude7c\uda15\udcdc\ud8d3\udc3c\ud943\uddea\udbce\udc9d",
        5, 78747, -1184707787, -1434236959404489688L, -61715L, false, true, (char) 51085, (char) 26129,
        Double.longBitsToDouble(0x3f997e95217ccf60L), Double.longBitsToDouble(0x3fe33c22a0a17794L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1696544-10-19T02:44:39.552Z]\012",
        Z.run(T, 1, 9, 14, 3, "\ud8ba\udde7", "\uc037\u0eca\u85c3\ud0ab\u3074\ucfef\ubad2\u53b3\ub80d\u8982\u00e7\ua834\u7793\u6475", "\uda34\udd16",
        4, 26567, 889192448, 53475615600279552L, 22778L, true, true, (char) 5619, (char) 2653,
        Double.longBitsToDouble(0x3fc75d3759fd290cL), Double.longBitsToDouble(0x3feced7a280000d1L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 1, 7, 14, 3, "\ud8ba\udde7\udb69\udd32\uf018\ud901\udd77\udbe9\udfe2\udb08\ude8f\udaca\udd31\udbfb\uddf1\ud8c2\udfea\ud860\udc25\udbfe\udfb6\udaee\ude36\ud952\udc71", "\u7793\u6475\uc392\ub851", "\ud9ab\uddf7\ud89f\udd81\ud8c7\udd0e\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud83c\udd8c\uee06\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud84f\udeb5\udb04\udd3c\ud955\udc32\ud9ec\ude3e\ud9d5\udcbc\ud9d4\udf7f\ud9a5\ude39\ud890\ude60\udbf8\ude0c\udb34\udd63\udb29\udc68\udbd4\udc66",
        41, 39064, 1467467337, -1682512775616078233L, -22509L, true, false, (char) 44303, (char) 38059,
        Double.longBitsToDouble(0x3fe9116ee2ebfe3eL), Double.longBitsToDouble(0x3fda1f74ea06dbbaL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 8, 15, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-03-23T18:20:12.470Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ud549\u365d\ua0cf\ua3aa\ucfb2\ubad2\u53b3\ub84c\u893e\u369e", "\ud8c5\udd4b\ud9c9\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 37266, -1917266878, -8877339301930787530L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fefc60ae0d1fc9cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, 90330L, false, true, (char) 55029, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 2, 3, "\ud8ba\udde7\udb69\udd32", "\u01c8\u365d", "\ud8c2\udfea\ud860\udc25\u8838\udaee\ude75\udaca\udcad\ud999\udd78\u9f19\ud939\ude76\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8",
        44, 88839, 1226075055, -3668168764400544582L, 7280L, false, true, (char) 43, (char) 47831,
        Double.longBitsToDouble(0x3fe9645e08bab698L), Double.longBitsToDouble(0x3fd8879436758684L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.091Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud9c7\udc8e\udb69\udd32", "\ucb5b\u365d\ub209\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143909L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d4234720b0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=20395314-02-18T22:49:16.292Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\u55c3\uca43\u5529\ub84c\u8982\u369e", "\ud86d\uddc0\ud81b\udc1d\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 643551781963756292L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42e7695e4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:26.358Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8bd\udee7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u6f57\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898173642L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 58296, (char) 751,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=2]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u936a\u5264\u8f8f\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\ud9d5\udea3\ud93c\uddc9",
        2, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d4252bf0b0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=276893568-08-29T23:47:37.992Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\uda49\udf8b\ud9f9\udffd\u08f2\udbbb\uddfd\ud950\udfad\udad6\ude4c\ud883\ude3d",
        5, 27348, -1230186708, 8737854888152857992L, -44218L, true, true, (char) 48756, (char) 44743,
        Double.longBitsToDouble(0x3fc265e6032cd5f0L), Double.longBitsToDouble(0x3fe425e90cac397aL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=177390068-06-14T21:08:47.643Z,mdfw=5]\012",
        Z.run(T, 1, 9, 6, 0, "\ud8ba\udde7\udb69\udd32", "\u2051\u4db8\ua760\u3074\ucfef\ubad2\u42d0\ub8a5\u8982\u36b4", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\udaba\udfcf\udbeb\udda0",
        5, 98769, 628944171, 5597827708309727643L, 95976L, false, true, (char) 35683, (char) 21758,
        Double.longBitsToDouble(0x3f9335126485c560L), Double.longBitsToDouble(0x3fe66c049b0fa1cdL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\u697d\uae9d\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 2, 1, "\ud8ba\udd5c\udb69\udd32", "\ucb5b\u2a55\ua0cf\ub4e5\u4d0f\u7746\u06aa\u6c2a\u00c9\u3695", "\uda1a\uddf6\udb6c\ude08\ud9ef\udf3c\udb32\udcc4\ud8ac\udc62",
        16, 17017, -1088499882, -710046978636405894L, -42021L, false, false, (char) 55021, (char) 13906,
        Double.longBitsToDouble(0x3fd881b366758684L), Double.longBitsToDouble(0x3fc854d4234694b0L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u01e3\u3260\ub027\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42ed17a44L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-127268491-06-29T09:00:30.370Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 5, "\ud8ba\udde7\ud97b\uddfa", "\u5e59\uc0a7\ub35e\u2978\ucfef\ubad2\u53b3\ub64c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -4016267813314769630L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-35304989-12-08T10:40:28.664Z,mdfw=6]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\u9bcd\uc5c7\ua0cf\u3074\ucfef\ubad2\u53b3\ubc72\u35dc\ub3ab", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\uda6b\udc50\ud9fb\ude7c",
        6, 15242, -2066916624, -1114179980966371336L, 92436L, false, true, (char) 53074, (char) 28875,
        Double.longBitsToDouble(0x3fee18a4a4c2a6a1L), Double.longBitsToDouble(0x3fee8c61608dc06dL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281312883-09-15T22:00:05.174Z,mdfw=5]\012",
        Z.run(T, 1, 9, 6, 4, "\ud8ba\udde7\udb69\udd32", "\000\u365d\u00b5\000\u925e\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, 12113082, -8877439290736794826L, 95840L, false, true, (char) 35683, (char) 21758,
        Double.longBitsToDouble(0x3fefd7654ff81590L), Double.longBitsToDouble(0x3fc883679f8ece30L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd887943e5111ecL), Double.longBitsToDouble(0x3fa6d62b5aff9b50L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-178556073-08-20T17:56:53.217Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\uddb4\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u2f67\u8dc3\ub2fb\u2d58", "\ud8f6\uddee\udb25\udfd4\udac5\udd42\udb69\udf1b\udbdd\udd3e",
        5, 93906, -1917266758, -5634747572191386783L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 2, "\ud8ba\udde7\udb69\udd32", "\ucae6\u365d\u55cf\u1c74\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 39870, (char) 8910,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-260942054-06-19T23:18:57.008Z]\012",
        Z.run(T, 1, 9, 7, 2, "\ud917\udd0b\udb69\udd32", "\u5ba8\uab4d\ua0a3\u3074\uaea5\u0c87\u53b3\ub84c\u8982\u369e", "\ud994\udd40\ud9ee\udf9b\ud9e8\udda8\ud8ff\udc15",
        4, 35055, -854062094, -8234598025384862992L, 39272L, true, true, (char) 47831, (char) 55021,
        Double.longBitsToDouble(0x3fc756d31621e50cL), Double.longBitsToDouble(0x3fe9d61a14c2a6a1L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-107300041-07-17T02:58:48.246Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u36cc\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, 783865018, -3386124393627671754L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=244257478-06-06T13:26:15.737Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\u65dd\uac86\u53b3\ub84c\u8982\u369e", "\ud8b6\udebe\ud95d\udfe2\ud9e8\udddd\uda4c\udc2e\udbe6\udead",
        5, -58, -1228422983, 7707959355245175737L, 89051L, true, true, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d4234721b8L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-282675355-08-18T19:20:21.302Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\udb36\udd13\udb69\udd32", "\u6abe\u023d\uc258\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, 182464647, -8920434756631178698L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d428aa78b0L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 11, 1, "\ud8ba\udc4b\udb69\udca8", "\u1417\ua2f6\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1921264454, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\uda84\udd25\ud9e8\uddb6\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, true, (char) 55465, (char) 60451,
        Double.longBitsToDouble(0x3fd8879096758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=276893568-08-29T23:47:37.992Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u5266\u2c18", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\uda6b\udc50\ud9f9\udf54\u08f2\udbbb\uddfd\ud950\udfad\udab0\udd4c\ud883\ude3d",
        5, 27348, -1231533268, 8737854888152857992L, -18764L, true, true, (char) 53634, (char) 17714,
        Double.longBitsToDouble(0x3fd46d761560c83eL), Double.longBitsToDouble(0x3fd0639a577085c0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=5]\012",
        Z.run(T, 1, 11, 16, 1, "\udaa3\udf7c\ud955\udd50", "\ucb5b\u365d\u3f54\u3074\u93b1\ubb3c\u53b3\u10b7\u8982\u3d6f", "\ud8c5\udd4b\ud9cf\udd3c\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -58710L, true, false, (char) 39938, (char) 48628,
        Double.longBitsToDouble(0x3fb363b83a07fe88L), Double.longBitsToDouble(0x3fee1584b8d1fc2cL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 2, 3, "\ud9fa\udda4\ud823\ude70", "\uc1de\u6806\ua0be\u3074\u0462\u9ab7\u4252\ub84c\u8982\ub59d\u1742\uce59\u1cc2\u597a\u1494\u1a4a\u2d5e", "\udbbb\uddfd\ud8f9\udd89\udb3f\udf01",
        53, 19005, -1950281652, -5289395107961562950L, 93734L, false, false, (char) 21758, (char) 17011,
        Double.longBitsToDouble(0x3fb4adc7f49b2978L), Double.longBitsToDouble(0x3fe845b2a4cc8c56L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-03-03T01:36:05.942Z,mdfw=5]\012",
        Z.run(T, 1, 9, 14, 1, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\uc182\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303719034058L, -41950L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=277335928-03-15T19:24:51.706Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\ud9aa\udede", "\ucb5b\u365d\ua0cf\u3074n\u0a4b\u546c\ub84c\u8982\ucf55", "\udb70\udf82\ud897\uddc4\uda38\udd08\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 8751814406969091706L, -42021L, true, false, (char) 54830, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fe51fa50ec82ab7L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1969-12-28T21:26:04.544Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3i\u8919\u369e", "\000\ud833\udd59\ud9e8\udda8\uda4c\udc2e\udba6\udead",
        5, 93906, 186, -268435456L, -42021L, false, false, (char) 35777, (char) 0,
        Double.longBitsToDouble(0x3fd8879430018684L), Double.longBitsToDouble(0x3e1a200000000000L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=262851985-12-17T18:47:35.875Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\u2a1f\uba28\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 8294745336893255875L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 1, 8, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u11a4\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\u2bc6\ud70f\u80c8\ub0ea\u53b3\u174d\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3f99a6a11a35d8c0L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=157105823-02-07T22:40:25.073Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 5, "\ud8ba\udde7\udb69\udd32", "\u33d0\u7cb4\ua0cf\u3074\ucfef\ud51f\u53b3\u3e4d\u8982\u369e", "\ud8c5\udd4b\ud9ee\udfe7\uda78\uddb0\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 4957718751384025073L, -42021L, false, false, (char) 55021, (char) 3751,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc857742347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 46930,
        Double.longBitsToDouble(0x3e39d00000000000L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-283141398-05-21T16:12:00.694Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, 12113082, -8935141660962479306L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-158977580-12-13T13:55:10.550Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\uddbb\udb69\udd32", "\u38cd\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1921594609, -5016909998311489450L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309735-01-24T21:38:45.174Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1905525062, -8877339969618074826L, -42021L, true, true, (char) 28308, (char) 13359,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32\uf018\ud9f9\udf32\ud802\udd1b\ud93d\udd2d\ud872\udd53", "\ubad2\u53b3\u9556\ucbc7\u369e\u0747\u5c3b\u5a52\u597a\u2875\u8952\u2d5e\u3974\u5f9c\u7d48\u28ec", "\udaf4\udc7b\ud88e\udd2e",
        40, 97378, -1019019896, -6439853648491256638L, 7152L, true, true, (char) 8963, (char) 20148,
        Double.longBitsToDouble(0x3fd85fcb40dc4630L), Double.longBitsToDouble(0x3fe2649a42a1934eL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1969-12-28T23:55:42.976Z,mdfw=3]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7", "\u1bee\u00eb\u5bda\ua0cf\u3074a\000\000\ub7e3\u8982\u369e\u0747\u5c3b\u1cc2", "\uda4b\udfe7\u6007",
        3, -758, 0, -259457024L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=210971208-07-23T04:32:09.506Z,mdfw=5]\012",
        Z.run(T, 1, 9, 4, 4, "\ud8ba\udde7\ud945\udd05", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u0703\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 6657546134665929506L, -42021L, true, false, (char) 54837, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=280345804-08-07T14:39:58.262Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\uda8a\ude08\ud818\udc2c", "\ucb5b\ub25d\u8bd4\u1a19\ucffd\ud100\u1adb\u089c\u7ad3\u76ab", "\ud804\udce2\ud940\udf6f\ud9c5\udde3\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 8846796931943998262L, -42021L, false, false, (char) 37653, (char) 26962,
        Double.longBitsToDouble(0x3fc92e314b95db48L), Double.longBitsToDouble(0x3fc854d4250bc9dcL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-197032460-01-30T11:18:49.069Z,mdfw=6]\012",
        Z.run(T, 1, 9, 1, 4, "\ud8ba\udde7", "\u0a18\u5454\u36a6\ua0cf\u3074\ucfef\u6ea4\u087f\u62d8\u8982\u369e\u0747\u5c3b\u1cc2", "\ud8ec\udd6c\udbd3\ude7f\ud9f9\udffd\u08f2\udbbb\uddfd\uda35\udfc2\udad6\ude4c\ud883\ude3d\udaf4\udc7b\ud8ef\udf47\uda2b\uded8\ud993\udfdf\uda96\uddf3\ud829\ude7c\ud93c\udc40\udb3f\ude82\udbed\ude54\udbc0\udf32\udb0a\udd26\uda70\udd31",
        6, 37299, 913664421, -6217806047373670931L, 89482L, true, true, (char) 48970, (char) 20138,
        Double.longBitsToDouble(0x3fb8e65d0bb48c18L), Double.longBitsToDouble(0x3fcffadc4d73d6d8L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1833653-10-08T07:35:20.118Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\u958d\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 57802356804920118L, -42021L, false, false, (char) 35777, (char) 0,
        Double.longBitsToDouble(0x3fc10f2000eb0d08L), Double.longBitsToDouble(0x3fc840000347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\u943f\u3329\u2124\u8a32\u5b5a\u2d98\u0861\u8ecd", "\ud8fe\udca9\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 54959, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8b4\udd72\udafe\udff2", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\uc9aa\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 54849, (char) 53074,
        Double.longBitsToDouble(0x3fd8879432758684L), Double.longBitsToDouble(0x3feab326a7458c89L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=5138-06-17T01:50:50.880Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ud442\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\uda84\udda2\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 99986838650880L, 95976L, false, true, (char) 35683, (char) 21758,
        Double.longBitsToDouble(0x3fd9277f487fbe4aL), Double.longBitsToDouble(0x3fd614090206cf18L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-253523040-04-17T20:05:43.560Z]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ud412\u3074\ucfef\ubad2\u53b3\u24be\u0a84\u7ade", "\ud8c5\udd4b\ud9ee\udf9b\ud98e\udd5a\uda4c\udc2e\udbe6\udead\ud9f9\udffd\u08f2\udbbb\uddfd\ud950\udfad\udad6\ude4c\ud883\ude3d\udaf4\udc7b\ud8d0\udd72\uda2b\uded8\ud993\udfdf\uda96\uddf3\udab9\uddf2\ud907\udc88\udbf2\udfdf",
        4, 74168, -521237646, -8000476562058856440L, 65867L, false, false, (char) 28223, (char) 25337,
        Double.longBitsToDouble(0x3fcba9c2af4fc084L), Double.longBitsToDouble(0x3fde9b71d548b6c8L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-282120288-11-06T00:14:41.462Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\ua606", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 26330, 440123780, -8902918527090318538L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281310725-09-27T22:50:50.550Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\ud92b\ude33", "\u1b6b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\ub9db\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e1\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877371189735349450L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fdb6794322b3e60L), Double.longBitsToDouble(0x3fedf13378d1fcc8L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=222368327-12-25T14:42:33.910Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde4\udb69\udd32", "\ucb5b\u8beb\u9111\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, 1052300474, 7017204485198553910L, 23515L, true, true, (char) 55021, (char) 53104,
        Double.longBitsToDouble(0x3fd88794363f8684L), Double.longBitsToDouble(0x3fc854ce4347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u89c8\u90bf\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9ec\ude00\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436778684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879438400484L), Double.longBitsToDouble(0x3fc854c7e347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=org.joda.time.chrono.GJChronology:GJChronology[UTC]\012",
        Z.run(T, 2, 12, 12, 6, "\ud8ba\udde7", "\u1bee\ub374\ub64d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\ud05c\u3ab5\u7793\ubb8d", "\udb35\udfae\udbe6\udead\ud8d6\udc0b\u08f2\udb10\udcc6\udaa3\uddb1\udbd9\ude4f\udbe7\udc91\ud90b\udc66\ud84e\udfb4",
        30, 15954, -1354379649, -8948120721223260990L, -66213L, false, false, (char) 17048, (char) 25793,
        Double.longBitsToDouble(0x3f887e450a5f9bc0L), Double.longBitsToDouble(0x3fe47a27bf79a9a0L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=6]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533677-09-29T05:21:51.860Z,mdfw=6]\012",
        Z.run(T, 2, 11, 9, 15, "\udba7\uddc8\udb57\udf32\uf018", "\uc4fd\ua0cf\uc2d2\u6fc8\ud491\ub070\ub85e", "\ud8ce\ude37\udabd\ude2b\ud831\udc8e\ud9ee\udf9b\uda40\udd33\udb35\udfae\udbe6\udead\ud8d6\udc0b\udacb\udcd5\udb10\udcc6\udaa3\uddb1\udbd9\ude4f\udbe7\udc91\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud86b\udd8c\udba5\udc3e\ud8e4\udf01\ud9d9\udc7a\ud9d5\udcd5",
        6, 93425, 1872999055, 5570802627801711860L, -19248L, false, false, (char) 26174, (char) 60826,
        Double.longBitsToDouble(0x3feb3d9e66663efcL), Double.longBitsToDouble(0x3fecbbe90fb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176534939-07-20T03:11:53.076Z,mdfw=6]\012",
        Z.run(T, 1, 9, 1, 13, "\ud890\udd32", "\ua56b\ub374\u365d\ua0cf\uc074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u2b98\u9e53\u6475", "\uda31\udf0d\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud9a5\udc60\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        6, 84681, -1449086321, 5570842446443513076L, -19248L, false, false, (char) 60833, (char) 18889,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533677-09-29T05:22:51.764Z,mdfw=6]\012",
        Z.run(T, 1, 9, 14, 12, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u2b98\u9e53\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud9a5\udc60\uda54\udc0b\ud949\udd1a\ud830\uddbd\ud9df\ude2e\udb28\udc12\ud9dc\udf87\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        6, 84681, -1449086321, 5570802627801771764L, -19248L, false, false, (char) 60833, (char) 18889,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533050-08-03T07:13:31.892Z,mdfw=6]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ubdd9\u66aa\ucfef\ubad2\u53b3\ub84c\u2319\uc7bf\u2b98\u9e53\u647f", "\uda1c\uddb1\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud9a5\udc60\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud845\udf0b\uda59\udd8f",
        6, 84681, -1449086321, 5570782836592411892L, -19248L, false, false, (char) 60833, (char) 18889,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-133322133-09-22T14:07:21.350Z,mdfw=2]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u3660\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u2b98\u9e53\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud9a5\udc60\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\udb99\udfd1\ud8d7\ude1f\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5\u5537\ud9a5\ude39\udbbd\udd77\ud93d\udc07\ud819\udc7e\uda32\udeae\udaab\udcac\ud96d\udf4e\udbe2\udc88\uda04\ude86",
        2, 38348, -1671349966, -4207302295955558650L, 28232L, true, false, (char) 49342, (char) 3899,
        Double.longBitsToDouble(0x3fe318463d0645c1L), Double.longBitsToDouble(0x3fe7d62d2533daa4L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-262590670-08-15T16:56:10.736Z]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\ua673\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u2b98\u9e53\u6475", "\uda4c\udc2e",
        4, 53943, 1575922, -8286623316428629264L, 22778L, true, true, (char) 5619, (char) 45766,
        Double.longBitsToDouble(0x3fc756c019fd290cL), Double.longBitsToDouble(0x3feced7a2cc283d1L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533677-09-04T09:09:01.300Z,mdfw=6]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u3604\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\uc7af\u2b98\u9e53\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udb8b\udcc4\ud8e2\udcb1\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud9a5\udc60\uda46\udfa3\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        6, 84681, -1449086321, 5570802625655341300L, -19248L, false, false, (char) 60833, (char) 18889,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533677-09-29T05:21:51.860Z,mdfw=6]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\000\u2f89\u365d\ua0cf\u3074\ubd61\ubab3\u53b3\ub84c\u8982\uc7af\u2b98\u9e53\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud9a5\udc60\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        6, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 60833, (char) 18889,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533677-09-29T05:21:51.860Z,mdfw=6]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\uc9ee\u4ddb\uc993\ucfef\ua9cb\u642b\ub84c\u8982\uc7af\u2b98\u9e53\u6475", "\udb81\udf0d\udbe6\udefb\ud8d6\udc0b\uda3d\udcfc\udbff\udcd5\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud9a5\udc60\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\uda94\udd91\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        6, 84681, -1449086321, 5570802627801711860L, -19248L, false, false, (char) 60833, (char) 18889,
        Double.longBitsToDouble(0x3fdf9fcfc29012f6L), Double.longBitsToDouble(0x3fecbbe90fb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=98567040-08-05T19:17:18.078Z,mdfw=6]\012",
        Z.run(T, 1, 9, 14, 13, "\uda5c\udd02", "\u1bee\u0a92\u2f38\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u29c6\u2136\u4ea9\u9e53\u6475", "\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\udbec\udfc1\uda7c\udca7\ud99d\udc8c\ud90b\udc66\ud9a5\udc60\udaf8\udfbc\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud955\udc32\ud9ec\ude3e\ud9d5\udcd5",
        6, 84681, -1449086321, 3110413201643838078L, -92680L, false, false, (char) 7816, (char) 51185,
        Double.longBitsToDouble(0x3fe6efe4db0a2c58L), Double.longBitsToDouble(0x3fdb62d388e3f584L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=6132-09-06T14:19:08.160Z,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u644b\000\u8982\uc6c8\u3ab5\u7793\u48bf", "\uda0f\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud801\udfc8\ud9ec\udddb\ud9d5\udcd5",
        7, -1000, 0, 131361574748160L, -19248L, false, false, (char) 2861, (char) 8091,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\u8c58\000\ua419\u3074\ucf8e\u4f1f\u644b\000\u8982\uc6c8\u2081\u778c\u00bf", "\udbbe\udfdf\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\udbbd\udf9c\000\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\ueb9d\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud801\udfc8\000\ud9d5\udcb8",
        7, -1000, 0, 0L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=58314996-05-15T20:39:33.018Z,mdfw=6]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u644b\000\u8982\uc6c8\u62a3\u7793\u0ed0", "\uda0f\udc2e\udbe6\udead\ud8d6\udc0b",
        6, 15242, -2070029072, 1840181374211973018L, 86125L, true, false, (char) 61556, (char) 43232,
        Double.longBitsToDouble(0x3feced7a2cc283d1L), Double.longBitsToDouble(0x3fca3f8597b3bf5cL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=6120-04-18T23:05:24.224Z,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u644b\000\u8982\uc6c8\u3ab5\u7793\u48bf", "\uda0f\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud801\udfc8\ud9ec\udddb\ud9d5\udcd5",
        7, -1000, 0, 130970732724224L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=6116-03-19T15:41:45.344Z,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 9, "\ud8ba\udde7", "\u1bee\ub374\u5bda\ua0cf\u3074\ucfef\ubad2\u644b\000\u8982\uc6c8\u2081\u7793\u48bf", "\000\000\000\u0800\udbbb\uddfd\ud950\udfad\ua336\ud9df\udcef\ud90b\udc66\ud862\udcfe\uda1c\udfae\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\u00c8\ud9ec\udddb\ud9d5\udcd5",
        7, -1000, 0, 130841883705344L, -19248L, false, false, (char) 2861, (char) 65,
        Double.longBitsToDouble(0x3e2663efc0000000L), Double.longBitsToDouble(0x3fecbbe908b4aca1L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=19844283-01-28T16:22:59.840Z,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u3899\ucb5f\u365d\ua0cf\u3074\ucfef\ubad2\u644b\u360c\u8973\uc6c8\u3ab5\u8fb5\u48bf", "\ud902\udcc7\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\udaf8\udebb\ud820\udda0\ud8af\udfdd\ud8f2\udd55\ud801\udfc8\ud9ec\udddb\ud9d5\udcd5",
        7, -1000, 553648128, 626162921310179840L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=6134-04-26T02:52:35.712Z,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u365d\ua0cf\u3074\u5a79\ub78b\u644b\000\u8982\uc6c8\u3ab5\u7793\u48bf", "\uda0f\udc2e\ud8ce\udeb9\ud859\udf8e\udb3b\udf44\udbbb\ude08\ue3ae\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda4e\udd44\ud907\udc88\udabd\udd42\ud8f2\udd27\ud801\udfc8\ud9ec\udddb\ud9d5\udcd5",
        7, -1000, 0, 131413114355712L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe909b4aca1L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=10260-12-06T11:52:50.432Z,mdfw=7]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 13, "\ud8ba\udde7", "\u1bee\ub374\u0a4b\u7692\u5082\u1c45\ubb3d\u644b\000\u8982\uc6c8\u3ab5\u8892\u48bf", "\uda0f\udc2e\udbe6\udead\ud8d6\udc0b\u08f2\udbbb\uddfd\ud950\udfad\ud919\uddbb\ud81f\udf4d\ud871\ude7d\ud84e\udf0c\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc2b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud801\udfc8\ud9ec\udddb\udbc5\uded5",
        7, -1000, 0, 261636522770432L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3fbaff3f1426dae0L), Double.longBitsToDouble(0x3fdb6a882d6959a2L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-151314901-05-01T04:50:24.088Z,mdfw=7]\012",
        Z.run(T, 1, 9, 11, 16, "\ud8ba\udde7\udb69\udd32", "\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u644b\u0d01\u88f5\uc6c8", "\ud88c\udf1c\udbad\udc09\ud901\udfe5\ud9cc\udf93\udb91\udc32\ud8d8\udc5d\u08f2\udbbb\uddfd\udabf\udc64\ud990\udc33\uda08\udf41\ud90b\udc66\ud84e\udfb4\udb79\udeea\uda2e\ude40",
        7, 22405, -1212943995, -4775099224532975912L, -99988L, false, false, (char) 0, (char) 22912,
        Double.longBitsToDouble(0x3f2d413120000000L), Double.longBitsToDouble(0x3fc21f2d11d80798L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1986-06-20T22:37:22.816Z,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 13, "\000", "\u1bee\ub374\u365d\ua0cf\u3074\ucfef\ubad2\u644b\000\u8982\uc6c8\u3ab5\u7793\u48bf", "\uda0f\udc2e\ud81a\udc07\ud8d5\udf5c\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud8af\udfdd\ud8f2\udd55\ud801\udfc8\ud9ec\udddb\ud9d5\udcd5",
        7, -1000, 0, 519691042816L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=250174599-12-26T13:11:27.911Z,mdfw=5]\012",
        Z.run(T, 1, 9, 14, 3, "\ud80b\ude8f", "\uc037\u0eca\u85c3\ub6ac\u3c4b\u0a1f\u8549\u53b3\ub80d\u8982\uc7af\u51b1\u7945\u6484\uc392\u1134\u794b\u446a\uc075\u468f\uc42b\u3098\u617a\u4178\u73d9\u2858\ud1f7\u10be\u3ed1", "\ud98a\ude8a\ud82d\udcfc\ud937\udcb1\ud973\udf2f\uda3b\udc6a\uda0a\udd5a\udaf3\udf1d\udb83\uddfb\uda67\udf2f\ud915\udebc\udbca\udf41\ud849\udc54\ud9cb\udea9\ud9b1\udee2\ud825\udd19\ud918\udf74\udafe\udd5e\udba5\uddc1\uda67\udda5\udab3\udf06\ud9af\udf60\udbc5\udeda\udad3\udf4c\udb65\udea4\udb56\udccd\uda6c\ude7c\uda15\udcdc\ud887\udc36\ud943\uddea\udbce\udc9d",
        5, 39626, 1420277662, 7894685676172287911L, 92589L, true, true, (char) 58621, (char) 60795,
        Double.longBitsToDouble(0x3feb74a5d10bb6baL), Double.longBitsToDouble(0x3fe33c22a0a17794L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=31628031-01-08T06:38:38.350Z,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 3, "\ud80b\ude8f", "\uc037\u0eca\u85c3\ub6ac\u3c4b\u0a1f\u8549\u53b3\ub80d\u8982\uc7af\ucc86\u7795\u63c3\uc392\u9951\u794b\u2808\uc0b4\u468f\u3b94\u2051\u514a\ub5fb\ua659\u43c9\u9797\ua29f\ua4ca", "\udbad\udf3c\ud82d\udcdf\ud937\udcb1\ud973\udf2f\uda13\udd76\ud9b1\uddb4\ud9d3\udf71\udaba\udf36\uda6f\uddcd\ud915\udebc\udbca\udf41\ud849\udc54\ud9cb\udea9\ud9b1\udee2\ud825\udd19\ud918\udf74\udafe\udd5e\udba5\uddc1\uda67\udda5\ud866\udd59\ud9af\udeb7\udb4d\udebf\uda04\ude6b\udbf7\udecd\ud948\udd87\uda6c\ude7c",
        7, 71252, -1546484903, 998022089572718350L, 83093L, false, true, (char) 28736, (char) 26033,
        Double.longBitsToDouble(0x3fe39c2a05fa2e47L), Double.longBitsToDouble(0x3fd0b32836ce5554L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-45447182-06-23T02:44:42.664Z,mdfw=5]\012",
        Z.run(T, 1, 9, 14, 3, "\ud80b\ude8f", "\uc037\u0eca\u85c3\ub6ac\u3c4b\u0a1f\u8549\u53b3\ub80d\u8982\uc7af\ucc86\u7795\u6475\uc392\u9951\u794b\u2808\uc0b4\u468f\u3b94\u28e8\u617a\u4178\u1caa\u2858\ud1f7\u10be\u3ed1", "\udbad\udf3c\ud82d\udcdf\ud937\udcb1\ud973\udf2f\ud857\udeb7\ud955\udea1\ud87d\udf13\udb83\uddfb\uda57\ude27\ud915\udebc\udbca\udf41\ud849\udc54\ud9cb\udea9\ud9b1\udee2\ud825\udd19\ud918\udf74\udafe\udd5e\udba5\uddc1\uda67\udda5\ud866\udd59\ud9af\udeb7\udbc5\udeda\udad3\udf4c\udbf0\ude8b\udb56\udccd\uda6c\ude7c\uda15\udcdc\ud8d3\udc3c\ud943\uddea\udbce\udc9d",
        5, 78747, -1184707787, -1434236693116517336L, -61715L, false, true, (char) 51085, (char) 26129,
        Double.longBitsToDouble(0x3f997e95217ccf60L), Double.longBitsToDouble(0x3fe33c22a0a17794L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=36695900-06-24T23:35:42.043Z,mdfw=5]\012",
        Z.run(T, 1, 9, 14, 8, "\ud80b\ude8f", "\uc037\u0eca\u85c3\u5ddd\u3c4b\u0a1f\u8549\u53b3\ub80d\u8982\uc7af\ucc86\ubc44\u2930\ua48c\u9951\u794b\uae04\u7458\u468f\u3b94\u28e8\u617a\u0a43\u0102\u2858\ud1f7\u10be\u3ed1", "\udbad\udf3c\ud82d\udcdf\ud937\udcb1\ud973\udf2f\ud857\udeb7\ud955\udea1\ud87d\udf13\udb83\uddfb\uda57\ude27\ud897\ude06\udbc2\udcad\ud849\udc54\ud9ce\udc56\ud9b1\udee2\ud825\udd19\ud918\udf74\udafe\udd5e\udba5\uddc1\ud8b5\uded5\ud866\udd59\ud9af\udeb7\udbc5\udeda\udad3\udf4c\udbf0\ude8b\udb56\udccd\uda6c\ude7c\uda15\udcdc\ud8d3\udc3c\udb33\udeff\udbb9\udcf2",
        5, 78747, 599829557, 1157948602817742043L, -6259L, true, false, (char) 51085, (char) 26129,
        Double.longBitsToDouble(0x3f997e95217ccf60L), Double.longBitsToDouble(0x3fd6784540ea8be2L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191831661-09-24T00:37:15.245Z,mdfw=5]\012",
        Z.run(T, 1, 9, 14, 13, "\ud80b\ude8f", "\uc037\u0eca\u85c3\ub6ac\u3c4b\u0a1f\u8549\u53b3\ub80d\u8982\uc7af\ucc86\u7795\u6475\uc392\u9951\u794b\u2808\uc0b4\u468f\u3b94\u28e8\u617a\u4178\u0671\u2786\ud1f7\u10be\u3ed1", "\udbad\udf3c\ud82d\udcdf\ud937\udcb1\ud973\udf2f\ud857\udeb7\ud841\ude3b\ud811\udfb5\ud932\udc52\uda57\udedf\ud915\udebc\ud875\ude3f\ud849\udc54\ud9cb\udea9\ud9b1\udee2\ud825\udd19\uda17\uddf2\ud81a\uddb8\udba5\ude21\uda67\udda5\ud866\udd59\ud9af\udeb7\udbc5\udeda\udad3\udf4c\udbf0\ude8b\udb56\udccd\uda6c\ude7c\udbdc\ude50\ud9c8\uddd1\ud943\uddea\udbce\udc9d",
        5, 55875, -1184707787, 6053560374127035245L, -61715L, false, true, (char) 51085, (char) 26129,
        Double.longBitsToDouble(0x3f997e95217ccf60L), Double.longBitsToDouble(0x3fe33c22a0a17794L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-171034974-01-04T16:00:45.199Z,mdfw=3]\012",
        Z.run(T, 1, 9, 14, 3, "\ud80b\ude8f", "\uc037\u0eca\u85c3\ub6ac\u3c4b\u0a1f\u8549\u53b3\ua665\u4e9b\uc7af\ucc86\u7795\ucd0c\u78e4\u216f\u78d2\u2808\uc0b4\u468f\u3b94\u28e8\u617a\u4178\u1caa\u2858\ud1f7\u61a1\uacf3", "\udbad\udf3c\ud82d\udcdf\ud937\udcb1\ud973\udf2f\ud857\udeb7\udb18\udda2\ud87d\udf50\udb83\uddfb\uda57\ude27\ud915\udebc\udbca\udf41\ud849\udc54\ud9cb\udea9\ud9b1\udee2\ud825\udd19\ud918\udf74\udafe\udd5e\ub5c6\uda67\udda5\udbd4\udd70\ud9af\udeb7\udbc5\udeda\ud996\udeac\udbf0\ude8b\udb56\udccd\uda6c\ude7c\uda15\udcdc\ud8d3\udc3c\ud943\uddea\udbce\udc9d",
        3, 40347, -1181302929, -5397404631724754801L, 32429L, false, true, (char) 36602, (char) 21190,
        Double.longBitsToDouble(0x3fe74838ce747cb1L), Double.longBitsToDouble(0x3fec7817d625c4a7L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-05T20:30:30.400Z,mdfw=2]\012",
        Z.run(T, 1, 9, 14, 3, "\ud8ba\udde7", "\uc037\u0eca\u85c3\ud0ab\u3074\ucfef\ubad2\u28e7\u4c6b\u3aa4\u2e80\ua834\u7793\u47a9", "\uda34\udd16\udbe6\udead",
        2, 88448, 12450762, 419430400L, -42021L, true, false, (char) 2653, (char) 629,
        Double.longBitsToDouble(0x3fe3fa521b9daf45L), Double.longBitsToDouble(0x3eca393d0a340000L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1696544-10-19T02:44:39.552Z]\012",
        Z.run(T, 1, 9, 14, 3, "\ud8ba\udde7", "\uc037\u0eca\u85c3\ud0ab\u3074=\ubad2\u53b3\ub80d\u8982\u00e7\ua834\u7793\u6475", "\uda34\udd16",
        4, 26567, 889192448, 53475615600279552L, 22778L, true, true, (char) 5619, (char) 2653,
        Double.longBitsToDouble(0x3fc75d3759fd290cL), Double.longBitsToDouble(0x3feced7a280000d1L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1998798-04-17T06:05:26.912Z]\012",
        Z.run(T, 1, 9, 14, 3, "\ud81a\ude30", "\uc037\u0eca\u85c3\ud0ab\u3074\ucfef\ubad2\u53b3\ub80d\u8982\u00e7\ua834\u7793\u6475", "\uda34\udd19",
        4, -220, 885384581, 63013814546726912L, 22778L, true, true, (char) 5619, (char) 2653,
        Double.longBitsToDouble(0x3fc75d3759fd290cL), Double.longBitsToDouble(0x3feced7a280000d1L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-265435450-11-30T15:47:30.220Z,mdfw=5]\012",
        Z.run(T, 1, 9, 8, 0, "\ud8bb\udee7\udb69\udd32\uf018\ud9f9\udf32", "\ua0cf", "\uda2f\udfec\udbe8\udd93\uda0e\udf0b\uda33\udd79\ud8c3\udc8e\u53c2\ud939\ude50\ud8c5\udd4b\ud9ee\udf9b\udb98\udcae\uda4c\udc2e\udbe6\udead\ud9f9\udffd\u08f2\udbbb\uddfd\ud950\udfad",
        5, 29296, -1886708347, -8376395893085549780L, 96040L, false, true, (char) 35683, (char) 21758,
        Double.longBitsToDouble(0x3fb435d3f28687f0L), Double.longBitsToDouble(0x3fea2601f5588c59L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 11, 4, "\udabc\udc10\udb69\udd32\uf018\ud9fa\udeb6\ud9ee\uddcf\udb6a\udc76\ud955\udd84\ud837\ude65\ud8c2\udfea\ud860\udc25\u8838\udabe\ude5c\ud952\udc33\udae8\ude2a\ud8bd\udc14\ud939\udf10\ud8c5\udd4b\ud9d9\udd59", "\u2d5e", "\u91ff\udac2\udc24\udad6\udf06\ud883\ude3d\ud830\udf32\ud8cb\udc0e\ud89d\udf7a\udb8e\udd12\ud93b\udc1f\ud826\udc0c\ud9a6\udda7\udaf1\udfdd\ud942\udcf3",
        42, 77042, 1053217834, 518147004560619625L, 52430L, false, true, (char) 26804, (char) 22522,
        Double.longBitsToDouble(0x3fb8412cdcba9510L), Double.longBitsToDouble(0x3fd3249af7cb2220L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-31242352-06-20T01:18:28.150Z,mdfw=5]\012",
        Z.run(T, 1, 9, 8, 15, "\udb61\udca9\udb69\udd32", "\ucb5b\u365d\ua0cf\u8dd3\u945c\ua653\u8699\ubc53\u892f\u369e", "\ud8c4\ude4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1192206406, -985975554840091850L, 52187L, true, false, (char) 15165, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d43b47f0b0L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=5]\012",
        Z.run(T, 1, 9, 7, 15, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=225612578-03-30T19:36:11.000Z,mdfw=6]\012",
        Z.run(T, 1, 9, 8, 15, "\udbfe\udfc9\udb69\udd32", "\ucb5b\u365d\ua0cf\uc532\ud10c\u7a6b\u53b3\ub8d3\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead\ud9f9\udffd",
        6, 15242, -165520675, 7119583135068971000L, 92436L, false, true, (char) 53074, (char) 30411,
        Double.longBitsToDouble(0x3fe9d61a14c2a6a1L), Double.longBitsToDouble(0x3fca3f859962a998L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=275843364-06-02T10:20:28.879Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ud549\u365d\ua0cf\ua3aa\ucfb2\ubad2\u53b3\ub84c\u893e\u369e", "\udb9b\udd56\ud9c9\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 37266, -1917266878, 8704713643323628879L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3feab60ae0d1fc9cL)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=292149066-03-06T06:27:43.542Z,mdfw=5]\012",
        Z.run(T, 1, 9, 10, 11, "\ud8ba\udde7\ud81c\udf05", "\ud549\u365d\ua0cf\ua3aa\ucfb2\ubad2\u53b3\ub84c\u893e\u369e", "\ud8c5\udd4b\ud9c9\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 98930, -1917266878, 9219271890983263542L, -42021L, false, false, (char) 20461, (char) 57145,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fefc60ae0d1fc9cL)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=2128000-02-23T22:09:47.008Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\u55c3\uca43\u5529\ub84c\u8982\u369e", "\ud86d\uddc0\ud81b\udc1d\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 67091031295787008L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42e7695e4L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=20395810-02-03T04:09:42.916Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\udaa7\udd9d\ud8c5\udea2", "\ucb5b\u365d\ua0cf\u3074\u55c3\uca43\u5529\ub84c\u8982\u369e", "\ud86d\uddc6\ud81b\udc1d\ud9e8\udda8\uda4c\udc2e\udbe6\udec2",
        5, 93906, -1430727494, 643567432824582916L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42e7695e4L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=20395314-02-18T22:49:16.292Z,mdfw=5]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucdc2\uca43\u5529\ub84c\u8982\u369e", "\udb1b\ude97\ud81b\udc1d\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 643551781963756292L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42e7695e4L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=225822766-05-30T22:36:50.179Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 8, "\ud8af\udd8d\udb3f\udc3c", "\u2dbb\u36d8\ua0cf\ubeac\u55c3\u1f16\u72b7\u76da\u8982\u369e", "\ud86d\uddc0\ud81b\udc1d\ud9e8\udda8\uda4c\udc2e\udbe6\udead\ud9f9\udffd\u08f2\udbbb\uddfd\udae4\udf76\ud93f\udd45\udb21\udd2c",
        5, 45444, -1231533268, 7126216032926210179L, 38046L, true, true, (char) 63260, (char) 15158,
        Double.longBitsToDouble(0x3fef4ce4b85d987aL), Double.longBitsToDouble(0x3fdc3547ef124fd4L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=276893568-08-29T23:47:37.992Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua034\u3074\ucfef\ubad2\u76bd\ua7d5\u51a0\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\uda49\udf8b\ud9f9\udffd\u08f2\udbbb\uddfd\ud950\udfad\udad6\ude4c\ud883\ude3d",
        5, 27348, -1230186708, 8737854888152857992L, -44218L, true, true, (char) 48756, (char) 44743,
        Double.longBitsToDouble(0x3fc265e6032cd5f0L), Double.longBitsToDouble(0x3fe425e90cac397aL)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=276893568-08-29T23:47:37.992Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 3, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\uafa0\ud9e8\udda8\uda4c\udc2e\uda49\udf8b\ud9f9\udffd\u08f2\udbbb\uddfd\ud950\udfad\udad6\ude4c\ud883\ude3d",
        5, 27348, -1230186708, 8737854888152857992L, -44218L, true, true, (char) 48756, (char) 44743,
        Double.longBitsToDouble(0x3fc265e6032cd5f0L), Double.longBitsToDouble(0x3fe425e90cac397aL)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=276469779-10-22T23:02:46.920Z,mdfw=6]\012",
        Z.run(T, 1, 9, 5, 4, "\ud895\udf15\ud9dd\udfac", "\ucb2f\u1347\u86f8\uc6cb\u1d36\ubad2\u53b3\u7679\u9f7c\u7fe0", "\ud8d6\udd45\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\uda49\udf8b\ud9f9\udffd\u08f2\udbbb\uddfd\udbe3\udef6\udab8\ude00\ub0b3",
        6, 5176, -1942932751, 8724481403670166920L, -44218L, true, true, (char) 48756, (char) 64641,
        Double.longBitsToDouble(0x3fc26e2b032cd5f0L), Double.longBitsToDouble(0x3fe425e90df2397aL)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=276893568-08-29T23:47:37.992Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\uda49\udf8b\ud9f9\udffd\u08f2\udbbb\uddfd\ud950\udfad\udad6\ude4c\ud883\ude3d",
        5, 27348, -1230186708, 8737854888152857992L, -44218L, true, true, (char) 48756, (char) 44743,
        Double.longBitsToDouble(0x3fc26386032cd5f0L), Double.longBitsToDouble(0x3fe425e90cac397aL)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-126462303-01-21T00:24:24.866Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 5, "\ud8ba\uddb6\ud97b\uddfa", "\ubbae\uc0cb\ub35e\u2978\ucfef\ubad2\u53b3\ub64c\u8982\ub5a0", "\ud8b8\udc3e\ud9ee\udfc0\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1941252934, -3990826990942535134L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd887943e758684L), Double.longBitsToDouble(0x3f88560c344067c0L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-35304989-12-08T10:40:28.664Z,mdfw=6]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\u9bcd\uc5c7\uaa96\ucf82\u8092\ubad2\u7c74\ubc72\u35dc\ub3ab", "\ud8c5\udd4b\ud9ee\udf9b\ud9d3\udf45\udbf5\udd90\uda6b\udc61\ud9fb\ude7c",
        6, 15242, -2066916624, -1114179980966371336L, 92436L, false, true, (char) 53074, (char) 28875,
        Double.longBitsToDouble(0x3fee18a4a072a6a1L), Double.longBitsToDouble(0x3fec4400688dc06dL)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-35304989-12-31T20:59:30.168Z,mdfw=1]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\u9bcd\uc5c7\ua0cf\u8cf5\ucfdb\u06f9\ucbc4\u4ae7\u6f14\ub3ef", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\udbc7\udd05\udbf5\ude34\ud9fb\ude82",
        1, 58349, -2066916624, -1114179978942029832L, -38578L, false, false, (char) 53059, (char) 28875,
        Double.longBitsToDouble(0x3feee8a4a2c2a6a1L), Double.longBitsToDouble(0x3fecc1fc7ba81789L)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=8684-12-04T08:15:20.576Z]\012",
        Z.run(T, 1, 9, 2, 12, "\ud8ba\udde7", "\u1bee\ucb5b\u365d\ua0cf\u3074\u65dd\uac86\u53b3\ub84c\u8982\u369e\u0747\u2b44\u7ab5", "\uda4c\udc2e",
        4, 24287, -855638016, 211902596120576L, -91800L, true, true, (char) 35077, (char) 0,
        Double.longBitsToDouble(0x3e46200000000000L), Double.longBitsToDouble(0x3fe9d61a14c2a6a1L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-59998614-11-02T18:00:35.854Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\ud9aa\udede", "\ucac6\u365d\ua0cf\u3074n\u0a4b\ud1c2\ub84c\u8982\ucf55", "\udb70\udf82\ud897\uddc4\uda38\udd08\ud8ce\udc2f\udbe6\udead",
        5, 93906, -1917266758, -1893435522789564146L, -42021L, true, false, (char) 54830, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fe51fa50dbb7db7L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=262851985-12-17T18:47:35.875Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\ude07\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\u2a1f\uba28\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 8294745336893255875L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=262851985-12-17T18:47:35.875Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\ua0cf\u3074\ucfef\u2a1f\uba28\ub84c\u8982\u369e", "\ud94e\udea9\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 8294745336893255875L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-283141373-07-26T01:47:50.454Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud9e6\ude5f\udb69\udcc3", "\ucb5b\u365d\ua0cf\u3074\ub70b\u3210\u6c7c\ub84c\u8982\u369e", "\ud8c5\uddb3\ud9ee\udf9b\ud9e8\udda8\ud88c\udf4e\udbe6\udefc",
        5, 93906, -1397173062, -8935140866393529546L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fee1535082a676bL)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-277325827-01-23T23:50:55.601Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 9, 10, 1, "\ud8ba\udde7\udb69\udd32", "\u4c5c\u365d\ua0cf\u2e90\ud028\u67ce\u77d9\u7b18\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 60538, 12067575, -8751619976141344399L, 89524L, true, false, (char) 25955, (char) 58544,
        Double.longBitsToDouble(0x3fe597f18cdcbf0fL), Double.longBitsToDouble(0x3fdd73cfed2197b4L)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-157590144-04-30T14:03:03.638Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\uddbb\udb69\udd32", "\u38cd\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udccf\udbe6\udead",
        5, 64580, 624519223, -4973126766688616362L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f068L)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1969-12-28T23:55:42.976Z,mdfw=3]\012",
        Z.run(T, 1, 9, 2, 3, "\ud8ba\udde7", "\u1bee\u00eb\u5bda\ua0cf\u3074a\000\000\uad94\u8982\u369e\u0747\u5c3b\u1cc2", "\uda4b\udfe7\u6007",
        3, -758, 0, -259457024L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=2004-06-04T16:41:08.864Z,mdfw=3]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7", "\u1bee\u00eb\u5bda\ua0cf\u3074a\000\000\ub7e3\u8982\u369e\u0747\u5c3b\u1cc2", "\uda4b\udfe7\u6007",
        3, 66034, -1392000809, 1086367268864L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-197032460-01-30T11:18:49.069Z,mdfw=6]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 4, "\ud8ba\udde7", "\u0a18\u5454\u36a6\ua0cf\u3074\ucfef\u6ea4\u087f\u62d8\uc582\u369e\u0747\u5c3b\u1cc2", "\ud8ec\udd6c\udbd3\ude7f\ud9f9\udffd\u08f2\udbbb\uddfd\udbab\udcc6\udad6\ude4c\ud883\ude3d\udaf4\udcef\ud8ef\udf47\uda2b\uded8\ud993\udfdf\udb98\udfb3\ud829\udec4\ud93c\udc40\udb3f\ude82\udbed\ude54\udbc0\udf32\udaf4\udf28\uda70\udd31",
        6, 37299, 913664421, -6217806047373670931L, 89482L, true, true, (char) 48970, (char) 20138,
        Double.longBitsToDouble(0x3fbf849d0ad68328L), Double.longBitsToDouble(0x3fcffadc4d73d6d8L)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=31277210-03-28T01:52:09.948Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ucb5b\u365d\u47c5\u3074\u6213\u24d9\u6ffc\u4b4b\u8982\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 986951254931529948L, -42021L, false, false, (char) 3267, (char) 0,
        Double.longBitsToDouble(0x3fc10f2008eb0d08L), Double.longBitsToDouble(0x3fc840000347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281310725-09-27T22:50:08.822Z,mdfw=3]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\ud92b\ude33", "\u1b6b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\ub9db\u369e", "\ud8c5\udd4b\ud97d\ude42\000\000\000",
        3, 93906, -1917266758, -8877371189735391178L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fdb6794322b3e60L), Double.longBitsToDouble(0x3fedf13378d1fcc8L)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=158048147-05-04T05:45:56.480Z,mdfw=7]\012",
        Z.run(T, 1, 9, 14, 13, "\000", "\u1bee\u840b\u365d\ua0cf\u3074\ucfef\uc028\u487e\u8359\u8982\uc6c8\u3ab5\uc305\u48bf", "\uda0f\udc2e\ud81a\udc07\ud8d5\udf5c\u08f2\udbbb\uddfd\ud950\udfad\ud8ed\udcb7\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\uda54\udc0b\u1639\ud920\ude47\ud92b\udf8f\ud949\udf6c\udb0e\ude68\uda65\udc33\uda43\udc4b\ud9ec\udddb\udac2\udf6b",
        7, -1000, 0, 4987455632027156480L, -19248L, false, false, (char) 2861, (char) 18075,
        Double.longBitsToDouble(0x3feb5fe7e1663efcL), Double.longBitsToDouble(0x3fecbbe90eb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1980-12-26T06:39:58.464Z,mdfw=5]\012",
        Z.run(T, 1, 9, 8, 0, "\ud8bb\udee7\udb69\udd32\uf018\ud9f9\udf32", "\ua0cf", "\uda2f\udfec\udbe8\udd93\uda0e\udf0b\uda33\udd79\ud8c3\udc8e\u53c2\ud939\ude50\ud8c5\udd4b\ud9c1\udd9b\udb98\udcae\uda4c\udc2e\udbe6\udead\ud9f9\udffd\u08f2\udb8b\udcc4\ud950\udebd",
        5, 29296, -1886708347, 346660798464L, -100000L, false, true, (char) 35683, (char) 21758,
        Double.longBitsToDouble(0x3fb435d3c28687f0L), Double.longBitsToDouble(0x3e45623164000000L)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 10, 10, 2, "\udb30\udf8a\u808e\uef45\ud9fa\udeb6\ud9ee\uddcf\udb6a\udc76\ud955\udd84\ud837\ude65\ud8c2\udfea\u4f1f\u87ff\udabe\ude5c\ud952\udc33\udae8\ude2a\ud8bd\udc14\ud939\udf10\ud8c5\udd4b\ud9d9\udd59", "\u7d55", "\u91ff\u00f0\udad6\udf06\ud883\ude3d\ud830\udf32\ud8cb\udc0e\ud89d\udf7a\udb8e\udd12\ud93b\udc1f\ud826\udc0c\ud9a6\udda7\udaf1\udfdd\ud942\udcf3",
        42, 77042, 1053217834, 518147004560619625L, 52430L, false, true, (char) 26804, (char) 22522,
        Double.longBitsToDouble(0x3fb8412cdcba9510L), Double.longBitsToDouble(0x3fd3249af7cb2220L)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=!org.joda.time.IllegalFieldValueException\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\udb69\udd32", "\ud549\u57d8\u1b2c\ua3aa\ucfb2\ubad2\u53b3\ub84c\u893e\u369e", "\udb9b\udd56\ud9c9\udf9b\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 37266, -1917266878, -4971029578251003212L, -42021L, false, false, (char) 54861, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3feab60ae165579cL)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=20395314-02-18T22:49:16.292Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=5]\012",
        Z.run(T, 2, 9, 11, 4, "\ud8ba\udde7\udb69\udd32", "\ua43f\u365d\ua0cf\u3074\ucdc2\uca43\u5529\ub84c\u8982\u369e", "\udb1b\ude97\ud81b\udc1d\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 643551781963756292L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fb8e690c1faeb20L), Double.longBitsToDouble(0x3fc8fd5ecd5edc8cL)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-59998628-01-02T07:56:40.590Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\ud9aa\udede", "\ucac6\000\000\u6e38n\u0a4b\ud1c2\u654c\u8982\ucf55", "\udb70\udf82\ud897\uddc4\uda38\udd08\ud8ce\udc2f\udbe6\udead",
        5, 91090, 186, -1893435990940999410L, -42021L, true, false, (char) 54830, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fe51fa50dbb7db7L)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=2004-06-21T14:04:50.048Z,mdfw=3]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7", "\u1bee\u00eb\u5bda\ua0cf\u3074a\000\000\uc2da\u9e38\u369e\u0747\u5c3b\u1cc2", "\uda4b\udfe7\u6007",
        3, 66034, -1392000809, 1087826690048L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-59998628-02-01T01:30:26.607Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 11, "\ud8ba\udde7\ud9aa\udede", "\ucac6\000\uce38\u0a7f\u0292\u90e4\u369a\ub1fa\uad0c\u4dd7", "\udb70\udf82\ud897\uddc4\uda38\udd08\ud8ce\udc2f\udbe6\udead",
        5, 92394, -1471931884, -1893435988372173393L, -42021L, true, false, (char) 54830, (char) 53074,
        Double.longBitsToDouble(0x3fd8879436758684L), Double.longBitsToDouble(0x3fe519de581c7db7L)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 1, 8, 14, 13, "\ud8fb\ude07\udb69\udcc7", "\ub374\u365d\u9701\u9296\ucfef\ubad2\u53b3\ub84c\u6f3c\u608b", "\ud831\udc8e\ud9e2\udd9f\ud87e\udd72\uda4c\udc2e\udbe6\udead\ud8d6\udc0b\udbe5\udce3\udb1a\uddd8\ud906\udf37\u2860\ud99d\udc8c\ud90b\udc66\ud84e\udfb4\ud9b2\udd79\ud8b2\udc49",
        5, 30293, -64166718, -1164364325286937108L, -54289L, true, true, (char) 21059, (char) 25345,
        Double.longBitsToDouble(0x3fc21f2d11d80798L), Double.longBitsToDouble(0x3fb963b1d2ce6208L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1972-11-14T18:29:03.616Z,mdfw=2]\012",
        Z.run(T, 1, 9, 14, 3, "\ud8ba\udd20", "\uc037\u0eca\u85c3\ud0ab\u3074\ucfef\ubad2\u53b3\ub80d\u8982\u00e7\ua834\u7793\u6475", "\uda34\udd16\udbe6\udead",
        2, 88448, 514718666, 90613743616L, -42021L, true, false, (char) 2653, (char) 629,
        Double.longBitsToDouble(0x3fe3fa521b9daf45L), Double.longBitsToDouble(0x3eca2eaed3900000L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=179802856-09-19T20:15:21.888Z]\012",
        Z.run(T, 1, 9, 10, 8, "\ud8ba\udde7", "\uc0a1\u0eca\u85c3\u243a\u3074\ucfef\ubad2\u53b3\ub80e\u2881\u0321\u6d61\u7793\u6475", "\uda34\udd16",
        4, 26567, 889192448, 5673967951781721888L, 22778L, true, true, (char) 5619, (char) 49216,
        Double.longBitsToDouble(0x3fe5d74d63a5177aL), Double.longBitsToDouble(0x3fece9b2a80000d1L)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-281309714-02-28T23:50:56.054Z,mdfw=3]\012",
        Z.run(T, 1, 9, 2, 11, "\ud8ba\udd94\udb69\udd32", "\ucb5b\u3c99\u0c42\u3074\ucfef\ubad2\u53b3\ub84c\u8982\u369e", "\ud8c5\udd4b\ud9d5\udf01\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        3, 86999, -1917266758, -8877339303898143946L, -42021L, false, false, (char) 58296, (char) 28143,
        Double.longBitsToDouble(0x3fd518a686758684L), Double.longBitsToDouble(0x3fc854d42347f0b0L)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-138688774-09-17T12:41:23.514Z]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 9, 7, 3, "\ud917\udd0b\udb69\udd32", "\u5ba8\u110b\u21a5\u3074\ua0b8\u9c73\u96ef\ub6e4\u2b90\u48d1", "\ud994\udd40\ud9ee\udf9b\udadf\udd62\ud8f4\udc01\u80df\udbe2\udf54\ud984\udd75\uda6d\udc2f\ud947\udc37\udad6\ude4c\ud883\ude3d\udaf4\udc7b",
        4, 41426, 1624577596, -4376657128792716486L, -91020L, false, true, (char) 50454, (char) 63225,
        Double.longBitsToDouble(0x3fd46f92994c68e8L), Double.longBitsToDouble(0x3fe393b4ea34b888L)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 8, 8, 4, "\ud8ba\udde7\udb6c\ude14", "\uc348\u5b3e\u7c01\u3074\u1ae6\ub2bd\ua206\ud613\uba21\u369e\u0747", "\ud9ee\udf9b",
        29, 93367, -1872994232, 5284488048876719090L, 80752L, true, false, (char) 53377, (char) 33711,
        Double.longBitsToDouble(0x3fb32a9799645e08L), Double.longBitsToDouble(0x3fc756d316d9e50cL)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=79280840-01-01T08:46:18.623Z,mdfw=5]\012",
        Z.run(T, 1, 9, 2, 4, "\ud8ba\udde7\ud92b\ude33", "\u1b6b\u365d\ua0cf\u3074\ucfef\ubad2\u53b3\ub84c\ub9db\u369e", "\ud8c5\udd4b\ud9ee\udf9b\ud9e1\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -977742662, 2501799495237978623L, -42021L, false, false, (char) 55021, (char) 53074,
        Double.longBitsToDouble(0x3fdb6794322b3e60L), Double.longBitsToDouble(0x3fedf13378d1fcc8L)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 7, 7, 1, "\uda63\udf78\udb69\udd22", "\u4c5c\u3895\ube99\u797b\ud028", "\udbb1\udf18\ud959\udd1a\udb93\udda0",
        40, 9551, -140507381, 2998361788620790178L, -9881L, false, false, (char) 56954, (char) 45665,
        Double.longBitsToDouble(0x3ec706dbea300000L), Double.longBitsToDouble(0x3fdf8f0e1139c5c6L)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=20395314-02-18T22:49:16.292Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=5]\012",
        Z.run(T, 2, 9, 11, 4, "\ud8ba\udde7\uda6f\udd35", "\ua43f\u365d\ud5d3\u3074\ucdc2\uca43\u5529\ub84c\u8982\u369e", "\udb1b\ude97\ud848\udcdd\ud9e8\udda8\uda4c\udc2e\udbe6\udead",
        5, 93906, -1917266758, 643551781963756292L, 9991L, true, true, (char) 64219, (char) 6779,
        Double.longBitsToDouble(0x3fe266a467221520L), Double.longBitsToDouble(0x3fdf555a07389204L)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1972-10-29T13:43:01.205Z,mdfw=2]\012",
        Z.run(T, 1, 9, 14, 3, "\ud8ba\uddfc", "\uc037\u02f3\u85c3\u31e9\u5eda\ud031\ubad2\u537c\ub80d\u3333\u54cb\ua834\u7f51\u6475", "\uda2a\ude71\udbe6\udead",
        2, 88448, 514718666, 89214181205L, -42021L, true, false, (char) 2653, (char) 629,
        Double.longBitsToDouble(0x3fe3fa521e02ee45L), Double.longBitsToDouble(0x3fdd2e94356b5e5eL)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=6]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533677-09-29T05:21:51.860Z,mdfw=6]\012",
        Z.run(T, 2, 11, 9, 15, "\udba7\uddc8\udb57\udf32\uf018", "\uc4fd\ua0cf\uc2d2\u6fc8\ud491\u1334\u3a90", "\ud8ce\ude37\udabd\ude2b\ud831\udc8e\ud9ee\udf9b\uda40\udd33\udb35\udfae\udbe6\udead\ud8d6\udc0b\udacb\udcd5\udb10\udcc6\udaa3\uddb1\udbd9\ude4f\udbe7\udc91\ud90b\udc66\ud84e\udfb4\uda54\udc0b\ud949\udd1a\ud830\uddbd\uda15\udc4b\ud907\udc88\ud86b\udd8c\udba5\udc3e\ud8e4\udf01\ud9d9\udc7a\ud9d5\udcd5",
        6, 93425, 1872999055, 5570802627801711860L, -19248L, false, false, (char) 26174, (char) 60826,
        Double.longBitsToDouble(0x3feb3d9e66663efcL), Double.longBitsToDouble(0x3fecbbe90fb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533677-09-29T05:21:51.860Z,mdfw=6]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=176533677-09-29T05:21:51.860Z,mdfw=6]\012",
        Z.run(T, 2, 9, 9, 15, "\udba7\uddc8\udb57\udf32\uf018\ud87d\udcd3\ud874\ude5f\uaf93\udae0\udf0b", "\ud491\ub070\ub85e\u8982\ud05c\ub646\u7793\u6475", "\udb35\udfae\udbe6\udead\ud8d6\udc0b\udacb\udcd5\udb10\udcc6\udaa3\uddb1\udbd9\ude4f\udbe7\udc91\ud90b\udc66\ud84e\udfb4\uda54\udc0b\u6d44\uda5f\udff7\uda15\udc4b\ud907\udc88\ud86b\udd8c\udba5\udc3e\ud8e4\udf01\ud9d9\udc7a\ud9d5\udcd5",
        6, 93425, 1872999055, 5570802627801711860L, -19248L, false, false, (char) 26174, (char) 60826,
        Double.longBitsToDouble(0x3feb3d9e66663efcL), Double.longBitsToDouble(0x3fecbbe90fb4aca1L)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=175824867-09-11T10:07:01.876Z,mdfw=6]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=175824867-09-11T10:07:01.876Z,mdfw=6]\012",
        Z.run(T, 2, 9, 9, 15, "\udba7\uddc8", "\ua4a8\u88b2\uc7a8\u5286\uc2d2\u6fc8\ud491\ub070\ub85e\u8982\ud05c\ub646\u7793\u6475", "\udb35\udfae\udbe6\udead\ud8d6\udc0b\udacb\udcd5\udb10\udcc6\udaa3\uddb1\udb27\udcd6\ud9c9\udf08\ud90b\udc66\ud84e\udfb4\000\uda95\udc89\uda5f\udff7\ud952\udfa9\000\ud887\udec3\udba5\udc3e\ud8e4\udf01\ud9d9\udc7a\ud9d5\udcd5",
        6, 93425, 10728079, 5548434743066821876L, -19248L, false, false, (char) 26174, (char) 60826,
        Double.longBitsToDouble(0x3feb3d9e66663efcL), Double.longBitsToDouble(0x3fe8000007b4aca1L)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-43390792-02-13T10:57:43.155Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-43390792-02-13T10:57:43.155Z,mdfw=3]\012",
        Z.run(T, 2, 9, 9, 15, "\udba7\uddc8", "\ua4a8\u88b2\uc7a8\ub957\uc2d2\u6fc8\ud491\ub070\ub85e\u8982\ud05c\ub646\u7793\u6475", "\uda52\udf46\ud9b5\udc46\ud8d6\udc0b\udacb\udcd5\udb10\udcc6",
        3, 81070, 9428736, -1369343303845336845L, -100000L, true, true, (char) 18756, (char) 465,
        Double.longBitsToDouble(0x3e4893ac00000000L), Double.longBitsToDouble(0x3fcfdbfb1a7d981cL)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1969-12-27T22:07:58.464Z,mdfw=7]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1969-12-27T22:07:58.464Z,mdfw=7]\012",
        Z.run(T, 2, 9, 9, 15, "\udba7\uddc8", "\ua4a8\u88b2\uc7a8\u5286\u5968\u3747\ud491\u7fdf\ub925\u78b2\u76b5\ub68e\u7793\u6475\u597a\u082a\ua96d\u2d5e", "\udb10\udcc6\udaa3\uddb1\udb27\udcd6\ud9c9\udf08\ud90b\udc66\ud84e\udfb4\000",
        7, 92650, 13755293, -352321536L, -62366L, true, false, (char) 25793, (char) 18496,
        Double.longBitsToDouble(0x3fe94bf37a8f6e73L), Double.longBitsToDouble(0x3ec473d134000000L)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-43390792-02-13T10:57:43.155Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-43390792-02-13T10:57:43.155Z,mdfw=3]\012",
        Z.run(T, 2, 9, 9, 15, "\udba7\uddc8", "\ua4a8\u88b2\uc7a8\ub957\uc2d2\u6fc8\ud491\ub070\ub85e\u8982\ud05c\ub646\u7793\u6475", "\uda52\udf46\ud9b5\udc46\ud8d6\udc0b\udacb\udcd5\udb10\udcc6",
        3, 81070, 9428736, -1369343303845336845L, -100000L, true, true, (char) 18756, (char) 465,
        Double.longBitsToDouble(0x3e4893ac00000000L), Double.longBitsToDouble(0x3fcfdbfb1a7c6c1cL)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-43390792-02-13T10:57:43.155Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=-43390792-02-13T10:57:43.155Z,mdfw=3]\012",
        Z.run(T, 2, 9, 9, 15, "\udba7\uddc8", "\ua4a8\u88b2\uc7a8\ub957\uc2d2\u6fc8\ud491\ub070\ub85e\u8982\ud05c\ub646\u7793\u6475", "\uda52\udf46\ud9b5\udc46\ud8d6\udc0b\udacb\udcd5\udb10\udcc6",
        3, -786, 0, -1369343303845336845L, -100000L, true, true, (char) 18756, (char) 465,
        Double.longBitsToDouble(0x3e4893ac00000000L), Double.longBitsToDouble(0x3fcfdbfb1a7d981cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.chrono.GJChronology|getDateTimeMillis|int,int,int,int|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getDateTimeMillis|int,int,int,int,int,int,int|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|assemble|org.joda.time.chrono.AssembledChronology$Fields|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|convertByWeekyear|long,org.joda.time.Chronology,org.joda.time.Chronology|static",
    "M|org.joda.time.chrono.GJChronology|convertByYear|long,org.joda.time.Chronology,org.joda.time.Chronology|static",
    "M|org.joda.time.chrono.GJChronology|equals|java.lang.Object|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getGregorianCutover||new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getInstance||static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone|static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone,long,int|static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone,org.joda.time.ReadableInstant|static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone,org.joda.time.ReadableInstant,int|static",
    "M|org.joda.time.chrono.GJChronology|getInstanceUTC||static",
    "M|org.joda.time.chrono.GJChronology|getMinimumDaysInFirstWeek||new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getZone||new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|gregorianToJulianByWeekyear|long|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getDateTimeMillis|int,int,int,int|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getDateTimeMillis|int,int,int,int,int,int,int|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
