package org.joda.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateTimeZone_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.joda.time.tz.DefaultNameProvider:@?\012",
        Z.run(T, 1, 15, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9bb1\u5db3", "\udbad\udc59\ua448\ud9e5\udfed",
        14, 22115, 202979478, -2497435858638710451L, -98704L, false, true, (char) 47629, (char) 29355,
        Double.longBitsToDouble(0x3fd82efc1d8ecaa8L), Double.longBitsToDouble(0x3fe7915bf0a44673L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.joda.time.tz.DefaultNameProvider:@?\012",
        Z.run(T, 1, 15, 8, 5, "\ud84e\udc35\ud905\ude6c", "\u9bb1\ub15e", "\udbad\udc59\ua448\ud9e5\udfed",
        14, 22115, 202979478, -2497435858638710451L, -98704L, false, true, (char) 47629, (char) 29355,
        Double.longBitsToDouble(0x3fd82efc1d8ecaa8L), Double.longBitsToDouble(0x3fe7915bf0a44673L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Long:-3485481915980009771 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u299b\ub1df\u8a71\u5dc6\u8f92\u39a5\u03a3\u376b\u09b4\ubfc9\u9aef", "\uda7e\udc3e\u6a2c\uda85\udc31\uda6f\udd14\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud81e\ude44",
        1, 4830, 126149880, -3485481916008387771L, 99694L, false, false, (char) 29897, (char) 20409,
        Double.longBitsToDouble(0x3fe8b1c5e1d50db7L), Double.longBitsToDouble(0x3fdcb23acd285cacL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Long:7301682456815874759 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd36\udb2e\udda2", "\u66c9\u980b\ub3d8\ub1b6\u6293\u76d3\u486c\ub6ec", "\udbcd\udf87\ud836\udeb3\ud9fc\udf8f\ud9fb\ude2d",
        1, 16743, -272562355, 7301682456787074759L, 61956L, false, true, (char) 33981, (char) 50954,
        Double.longBitsToDouble(0x3fedfcf1c58f9a84L), Double.longBitsToDouble(0x3fd5228521bef28cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+46:00\012",
        Z.run(T, 1, 8, 13, 12, "\ud9f0\udd01\ud818\udd5b\ud8c3\udf8e\ud983\ude9d\ud855\udf45\ud895\ude27\udb99\ude64\ud930\udedc\udae5\udf72\ud807\udfcb\ud802\udedc\ud913\ude90\ud965\udc1a\ud816\udc67\uda03\ude49\ud8fa\udd7a", "\uab6c\u65f8\ua0c7\u174a\u2f5b\u36f1\ud253\uc21b\ub7af\u3db0\u4d89\ud026\u0f06\u1b06\u8041", "\ud8c3\udd1e\udb10\udd78\uda5f\udce7\udb8d\udfbf\ud937\udd9c",
        46, -913, -1500924344, -765772790399522523L, 77753L, false, true, (char) 19443, (char) 16565,
        Double.longBitsToDouble(0x3fc36e4fc4ee68b0L), Double.longBitsToDouble(0x3fded3efd7cd4510L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.joda.time.tz.DefaultNameProvider:@?\012",
        Z.run(T, 1, 15, 12, 11, "\ud9f0\udd26\ud905\ude70", "\ub478\u1141", "\udb8d\udefd\ua448\ud9e5\udfed",
        14, 22115, 1578711190, -2497435807099102899L, -98262L, false, false, (char) 35181, (char) 32889,
        Double.longBitsToDouble(0x3fe13a1f374d6b5eL), Double.longBitsToDouble(0x3fd82efc1d8ecaa8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:Australia/Sydney\012",
        Z.run(T, 1, 11, 8, 8, "\ud811\ude8f\uda24\udfc7", "\u9bb1\u8c57", "\udbc1\udd36\uda7b\ude2a\uda89\ude56\ud9f6\udf28\udb4a\udd90\uda74\udfae\udb92\udda5\udaf8\ude7e\ud95c\udd2e\ud93f\udd69\ud9fc\udfc3",
        6, 94502, 1801352743, -1170474876695295614L, 34908L, false, false, (char) 45923, (char) 9635,
        Double.longBitsToDouble(0x3fe55ea084054962L), Double.longBitsToDouble(0x3fef9c9f7cc32cf7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+50:00\012",
        Z.run(T, 1, 8, 1, 10, "\ud9f0\udd26\ud905\ude70", "\u0237\u62b1", "\udbed\ude9b\udaca\udf72\ud960\udcca\ud8ed\udfb8\uda1d\udc19\udb8a\udd53\ud840\udd47",
        50, 27827, -1742483341, 7799130649713940851L, -91087L, true, false, (char) 9239, (char) 16393,
        Double.longBitsToDouble(0x3fe7907bf0a44673L), Double.longBitsToDouble(0x3fe2d37dddbf6809L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.joda.time.tz.DateTimeZoneBuilder$PrecalculatedZone:Asia/Bangkok\012",
        Z.run(T, 1, 11, 11, 5, "\ud932\ude61\ud8e0\ude06\ud84f\udc20\udb09\udeb0", "\u66c9\u980b\u6dab\ub1ac\u7cbc\u76d3\uc738\u9413\uabb3\ud06d\u55cc", "\udaaa\udc0d\ud88e\ude48\uda4e\udcd4\ud806\udff8\udae5\udf7a\ud892\udd57\udb03\udffb\udb11\udc75\ud80d\udd71",
        10, 3569, -160465479, 7100557551473459958L, -20616L, true, false, (char) 454, (char) 56582,
        Double.longBitsToDouble(0x3fe2a1752e39676aL), Double.longBitsToDouble(0x3fcfc5f95a0369acL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 5, 8, 5, "\uda02\udc8f\udbe6\uddb8", "\u45b1\u1986", "\ud9c7\uded6\udb2f\udcd3\uc9f4",
        15, 64527, -1110251971, -2497267079308879539L, -33168L, false, true, (char) 17276, (char) 16102,
        Double.longBitsToDouble(0x3fe0ffa5c6c76554L), Double.longBitsToDouble(0x3fe7915bf0a44673L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:Australia/Sydney\0121=org.joda.time.tz.FixedDateTimeZone:+34:00\012",
        Z.run(T, 2, 11, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9bb1\u5db3", "\udbad\udc59\ua448",
        34, 84234, 541080115, 871790219187671890L, 16888L, true, false, (char) 22639, (char) 13588,
        Double.longBitsToDouble(0x3fda536fbc4e87ccL), Double.longBitsToDouble(0x3fb35ad797c281e8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 11, 6, 7, "\ud9f0\udd26\u04f6\uda34\uddaf\ud844\udc42\uda73\udc98\udafb\ude8e\uda4b\udc81\ud855\udd8d\udb70\udca9\udb2d\udc63\udaaa\udf49\udb2f\udf91\udbdd\udfe3\udb5a\udc97\uda44\udf92\udae1\udd90\udbcd\udf40\ud886\udefb\ud9fe\udeda\ud93e\udd8f\ud9c3\uded9\udbf3\uddef\udbe0\ude80\udae5\udfbd\udb90\ude26\ud84a\udff9\ud983\ude83\ud8f2\udc1f\ud920\ude9e\uda94\udef8\udbec\udc44\ud94e\uddc7\ud831\udf13\ud85a\udee7\ud8a5\ude8d", "\ub48f\ucd17\u209a\u697b\u5acd\ucff8", "\uda94\udfd4\uda6c\udece\udb40\udcac",
        36, 49690, 836974068, 7953214318656820837L, 80869L, true, false, (char) 12054, (char) 50454,
        Double.longBitsToDouble(0x3fe2da17eb8e0ffcL), Double.longBitsToDouble(0x3fc5a4a29820e3b4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Long:-7666375933250878320 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 3, 13, "\ud9f0\udd6e\ud905\ude70\ud8c3\udff0\udb2e\udda2\udbf7\udc1f\ud895\ude27\udb99\ude64\udb82\udd38\udbad\udc68\ua448\ud9e5\udfed", "\u5710\u0a3e", "\ud836\udeb3\udabc\uddce",
        22, 86566, -312576473, -7666375933250878320L, -57752L, false, false, (char) 48232, (char) 49015,
        Double.longBitsToDouble(0x3fc3a7b86126dc10L), Double.longBitsToDouble(0x3fb2a50d9f65ca90L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u89b8\u5db3", "\udbad\udc59",
        59, 72728, 1485088000, 2323921398643898518L, -99885L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f30c00000000000L), Double.longBitsToDouble(0x3fd820000d8ecaa8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.TreeSet:[Africa/Abidjan, Africa/Accra, Africa/Addis_Ababa, Africa/Algiers, Africa/Asmara, Africa/Asmera, Africa/Bamako, Africa/Bangui, Africa/Banjul, Africa/Bissau, Africa/Blantyre, Africa/Brazzaville, Africa/Bujumbura, Africa/Cairo, Africa/Casablanca, Africa/Ceuta, Africa/Conakry, Africa/Dakar, Africa/Dar_...\012",
        Z.run(T, 1, 12, 8, 8, "\ud9f0\udd26\ud905\ude70\ud8c3\udff0\ud89c\udd39\ud855\udf47", "\u980b\u3b75\ub1b6\u96b5\u76d3\u486c\ub6ec\u0a3e\ud06d\u63d2\u4db5\u8bb7\u20bf\ub526", "\udae5\udf7a\ud892\udd57\udb66\udf18\ud898\ude00\ud806\uddc4\udafc\uddc2\ud920\udd79\udbf2\udc87\ud893\udcfa\udbba\udc80\ud90e\ude09\ud88e\udcc8\udbf7\udc6c\uf2c1\ud873\udc5e\ud926\udc0a\udad7\udc46\ud80d\udcf2",
        57, 85550, 1562148956, -1709821580682022033L, 74329L, false, true, (char) 23391, (char) 12129,
        Double.longBitsToDouble(0x3fd362e0dd0a51a2L), Double.longBitsToDouble(0x3fc50b9b932e45e4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 8, 5, "\ud824\udf40\ud94f\udefa", "\u9bb1\u5db3", "\udbad\udc59\ua448\ud9e5\udfed",
        14, 20227, 202979478, -2497435858638710451L, 72831L, false, true, (char) 47629, (char) 29355,
        Double.longBitsToDouble(0x3fd82efc1d8ecaa8L), Double.longBitsToDouble(0x3fe7915bf0a44673L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.joda.time.tz.DefaultNameProvider:@?\0121=org.joda.time.tz.FixedDateTimeZone:+28:00\012",
        Z.run(T, 2, 15, 8, 5, "\ud9f0\ude84\uda1b\udf9a", "\u343d\u5db3\u66c9\u980b\ub3d8\ub1b6\u62b5\u85bb\ua196\ub6ec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ud3f2\u2b80\u1d68\ua40b", "\udb66\udf18\ud9fe\uddd3\udb77\udecf\ud93a\udd33",
        28, 19122, 816091892, 2677473195550005980L, 31566L, true, true, (char) 55791, (char) 27275,
        Double.longBitsToDouble(0x3fd45fba31f16aa0L), Double.longBitsToDouble(0x3fd4aeda24f4117eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 8, 9, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u6655\u93e0\u02cb\ub6ec\u7c34\u1419\u89ea\u4db5\u8bb7\ucc1a\u6636\u03ee\u57d6\ud614\ub1df\u8a71\u73fd\u8f92\u9074\u25db\u9c69\u2988\ubfc9\u39b5", "\udb07\udd08\udb3f\udc18\ud87e\udfc0\uda6f\udd3a\ud9ca\udcb2\ud84d\ude9e\uda3e\udca6\uda72\udcc4\ud81e\udee2\ud897\uddcb",
        15, -120, 1837700266, 956240121437428640L, 56886L, true, true, (char) 25529, (char) 23881,
        Double.longBitsToDouble(0x3fdd5673c3964758L), Double.longBitsToDouble(0x3fe4a172b2ef9180L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:4834203018373521764 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u661b\u2393\ub6ec\u1400\u3a0c\u9b92\u4db5\u8bb7\u064a\uad26\u03ee\ua40b\u299b\ub1df\u8a71\u8cc6\u8f92\u39a5\u03a3\u376b\u2883\ubfe7\u2285", "\uda7d\udfc7\u6a2c",
        16, 60700, -1254502238, 4834203018348321764L, 87153L, false, true, (char) 57254, (char) 18658,
        Double.longBitsToDouble(0x3fc540f08d173e84L), Double.longBitsToDouble(0x3fed006a2bf2f641L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Long:3342736370126843294 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\uaf95\ua493\u2265", "\ua448",
        34, 84234, -1780336077, 3342736370101643294L, -10113L, false, false, (char) 62263, (char) 1820,
        Double.longBitsToDouble(0x3fe67cef24f6ebeeL), Double.longBitsToDouble(0x3febbeb5b982efc1L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Long:2751647087810899520 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\u3a46\u980b", "\ud9d5\udc14\ud99a\udf21\uda1d\udc19\ud9fc\udd4c",
        10, 99557, 35534696, 2751647087782099520L, 49886L, true, false, (char) 29468, (char) 47427,
        Double.longBitsToDouble(0x3fe63b2aa6f22b1cL), Double.longBitsToDouble(0x3fc488ce716ad754L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Long:158647465426213123 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\uda11\uddc6\ud905\udefb\ud881\udd0f", "\u775b\u583f\u85a0\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud06d", "\ud9fc\udf8f\ud9fb\ude2d\ud955\udd7e\ud9d2\ude81\udb97\ude57\ud82b\ude7b\ud986\udd51\udb66\udf18",
        6, 60714, 1841725322, 158647465397413123L, 32263L, false, false, (char) 7070, (char) 64915,
        Double.longBitsToDouble(0x3fe663fb88585c71L), Double.longBitsToDouble(0x3fe7f8f82d348c93L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Long:4834203714158223716 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u0b4f\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud0c9\u89ea\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u8937\ub1df\u8a71\u5dc6\uc36b\u1b34\u51b8\u376b\u09b4\ud5e6\u2def", "\ud982\udd88\u6a77",
        16, 60700, 1561112419, 4834203714133023716L, 23921L, false, true, (char) 57254, (char) 18658,
        Double.longBitsToDouble(0x3fc540f08d173e84L), Double.longBitsToDouble(0x3fed006a2bf2f641L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Long:-3485275005930524971 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\uda25\uddcf\ud905\ude70", "\u9ad7\u775b\ucbc5\u5dff\ub3d8\ub1b6\u62b5\u76d3\ud149\ub6ec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u299b\ubb59\u54c3\ua4a2\u8f92\u39a5\u03a3\ua633\u09b4\ud1d0\u9cab", "\udadd\udcd8\ud911\udc03\uda85\udc31\uda6f\udd14\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud81e\ude44",
        1, 49582, -271803175, -3485275005958902971L, -96914L, false, false, (char) 29897, (char) 20409,
        Double.longBitsToDouble(0x3fe8b1c5e1d50db7L), Double.longBitsToDouble(0x3fdcb2dacd285cacL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Long:806412555388381782 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ua2a0\u89c8\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u299b\ub1df\u8a71\u5dc6\u8f92\u39a5\u03a3\u376b\u09b4\ubfc9\u9aef", "\uda7e\udc3e\u6a2c\uda85\udc31\uda6f\udd14\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud81e\ude44\ud897\uddcb\ud95f\udfd1\ud99d\udd69",
        12, 64637, -163505248, 806412555363181782L, -94351L, false, true, (char) 46869, (char) 52545,
        Double.longBitsToDouble(0x3fe4a172b02583deL), Double.longBitsToDouble(0x3fe596cb08108aa7L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Long:5972336830419516604 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 13, "\ud9f0\udd26\ud905\ude70", "\ua0f6\u775b\uc745\u980b\u8fb2\u6956\u62a7\u76d3\u486c\ub6ec\u0a3e\ud06d\ubef3\u4db5", "\ud8e3\udff0\ud84e\uddaa\ud991\uddc2\udae5\udf7a\udab8\ude8b\udb66\udf22\udabc\udf53\udbf4\udfab\ud853\ude02\ud97f\udcb1",
        6, 1622, -2107243345, 5972336830390716604L, -79828L, false, false, (char) 41475, (char) 16839,
        Double.longBitsToDouble(0x3feb1fef5aaa5a0cL), Double.longBitsToDouble(0x3fef221f82d250c5L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Long:2761917802877361453 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 11, "\ud9f0\udd26\ud905\ude70\ud881\udd0f\uda5d\udfac\ud855\ude6b\udaa6\udfb1\uda03\ude38\ud8e5\ude6b\udbad\udc4a\ua448\ud9e5\udfed\ud99a\udf21\uda1d\udc19\udb89\udc2c\udb3d\uddcd\udaf8\ude7e\udbcd\udf87\ud836\udeb3\ud9fc\udf8f\ud9fb\ude2d\ud955\udd7e", "\u299b\ub750\u8e84\u134f\u8f92\u39a5\u03a3\ud332\u09b4\ubfc9\u9aef\u3729\u1e35\u485c\u8d1c\uca31\u1abd\u2a1d\u522d\u739f\u95b1\ubaf7\u4412\u8859\u7596\u9355\ucaff\u0813\u7935", "\udbb6\udd68\udbd4\udfe4\ud8a0\udfef",
        31, 63804, -1560651001, 2761917802848561453L, -63875L, true, true, (char) 12084, (char) 33051,
        Double.longBitsToDouble(0x3fe4e411c6d0a1c5L), Double.longBitsToDouble(0x3fbaab78e78f92e0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Long:871790219212871890 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u72b6\u775b", "\udbad\udc59\ua448",
        34, 84234, 546257459, 871790219187671890L, 16888L, true, false, (char) 41071, (char) 35181,
        Double.longBitsToDouble(0x3fd7e36fb84e87ccL), Double.longBitsToDouble(0x3fbb9af3e3068198L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Long:2536530261052366283 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd18\udb22\udf5f\ud881\udd0f\uda5d\udfac\ud833\udc2c\udaa6\udfb1\udb7b\udee1\udb82\udd38\ud8dd\ude04\ud88b\udeeb\ud9ee\udfeb\ud99a\udf21\uda1d\udc19\ud9fc\udd4c\ud840\udd47\udaf8\ude7e\udbcd\udf87\ud836\udeb3\ud9fc\udf8f\ud9fb\ude2d\ud955\udd7e\ud9d2\ude81\udb97\ude57\udae5\udf7a\ud986\udd51", "\u1ac6\u39a5\uaca5\u384b\u17bc\ub371\ub7a2\u3729\u1e35\u485c", "\udaac\udcd2\u612f\ud973\udec0\uda39\udc8f\ud8f0\udeba\ud9fb\udf13\ud89c\udf6d\ud95f\udfd1\ud99d\udd69\ud8d2\uddd0\ud8bd\udc0d\udb84\ude0f\udb4f\udc9a\uda22\udd99",
        48, 25513, 230152982, 2536530261023566283L, 8236L, true, true, (char) 31841, (char) 24954,
        Double.longBitsToDouble(0x3fdd41e287400c76L), Double.longBitsToDouble(0x3fab3be8dfab5490L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Long:3962036206109685073 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\uda17\udcf2\ud859\udd01", "\u9ad7\u775b\uc745\uc305\u7fdd\u0932\ud726\u17a5\u486c", "\udaf8\udea9",
        54, 23763, -1904379328, 3962036206084485073L, -32595L, false, true, (char) 9243, (char) 35342,
        Double.longBitsToDouble(0x3fc488ce716a9754L), Double.longBitsToDouble(0x3fec53e1b9076dc6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Long:-3485481915980009771 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.FixedDateTimeZone:+24:00\012",
        Z.run(T, 2, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u2bc1\ud06d\u89ea\u4db5\u01e9\u6150\u81f7\u8b6b\ua40b\u299b\u9e24\u8a71\u5dc6\u8f92\u39a5\u03a3\u376b\u09b4\ubfc9\u9aef", "\uda7e\udc3e\udafc\udfdd\ud806\udd3a\ud9e8\uddf0\ud989\udc71\ud92a\udebe\ud921\udf66\ud8d2\udedb\ud89c\ude07",
        24, 19915, 126149880, -3485481916008387771L, 99694L, false, false, (char) 29897, (char) 20409,
        Double.longBitsToDouble(0x3fe8b1c5e1d50db7L), Double.longBitsToDouble(0x3fdcb23acd285cacL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Long:6378404392251928115 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 0, 5, "\ud9f0\udd26i", "\u9ad7", "\000",
        23, -131, 0, 6378404392223128115L, 16888L, false, false, (char) 41071, (char) 36717,
        Double.longBitsToDouble(0x3ecf709d0f980000L), Double.longBitsToDouble(0x3f3af3c000000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Long:4385826926895058492 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\uda72\udf0a\ud8b2\udd6e", "\u0d9d\u8c1f\u413e\u290e\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud06d\u8a81\u2a7b", "\ud955\udd7e\ud9d2\ude81\udb97\ude57\udac6\ude7a\ud895\udc24\uda3e\ude76\ud886\udd3b\ud914\ude74\ud853\ude02\ud8ac\udd28",
        57, 89994, -2107243353, 4385826926869858492L, -11220L, false, false, (char) 10941, (char) 47589,
        Double.longBitsToDouble(0x3feb1fef5aaa5a0cL), Double.longBitsToDouble(0x3fef2218b2d250c5L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.022\012",
        Z.run(T, 1, 10, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u97eb\ub3d8\ub1b6\u76fa\ub6ff\u26f8\ub6ec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ucc1a\u81f7\ua251\ua40b\u299b\ub1df\u8a71\u5dc6\u8f92\u39a5\u03a3\u376b\u09b4\ubfc9\u9aef", "\uda7e\udc3e\u6a2c\uda85\udc31\uda6f\udd14\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud9cd\udffb",
        22, 4292, 300236240, -3485481821519107259L, 99694L, false, false, (char) 29897, (char) 20409,
        Double.longBitsToDouble(0x3fe8b1c5e1d50db7L), Double.longBitsToDouble(0x3fdcb23acd285cacL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Long:8549617792514186538 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\ub8d0\ub6ec\u0a3e\ud06d\u89ea\u4db5\ub250\ucc1a\u81f7\u03ee\ua40b\u299b\ubddf\u3271\u5dc6\u8f92\u39a5\u03a3\u376b\u09b4\ubfc9\u9aef", "\uda7e\udc3e\u6a2c\uda84\udf96\uda6f\udd14\udaa2\udfca\uda97\udd65\uda7c\udd45\ud8ec\udd9b\ud916\udda4",
        29, 61414, 61277024, 8549617792488986538L, 99694L, false, false, (char) 17786, (char) 49735,
        Double.longBitsToDouble(0x3fe8b68f59d50db7L), Double.longBitsToDouble(0x3fdcb23acd285cacL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Long:4154610183810358161 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud06d\u28eb\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u299b\ub1df\u8a71\u5dc6\uc011\u39a5\u03a3\u376b\u09b4\ubfc9\u7de1", "\uda7e\udc3e\u6a2c\uda85\udc31\uda6f\udd14\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud81e\ude44\ud897\uddcb\ud95f\udfd1\ud99d\udd69\ud8d2\uddd0\ud8bd\udc0d",
        37, 22234, 1356227798, 4154610183785158161L, -56523L, true, true, (char) 19690, (char) 18374,
        Double.longBitsToDouble(0x3fe0d2021e7fb1c5L), Double.longBitsToDouble(0x3feba960d7dee697L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Long:-3485481916036765771 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 4, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\u21ea\u89ea\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u299b\ub1df\u8a71\u5dc6\u8f92\u39a5\u03a3\u376b\u09b4\ubfc9\u9aef", "\uda7e\udc3e\u6a2c\uda85\udc31\ud968\udf18\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud81e\ude44",
        1, 4830, 126149880, -3485481916008387771L, 99694L, false, false, (char) 29897, (char) 20409,
        Double.longBitsToDouble(0x3fe8b1c5e1d50db7L), Double.longBitsToDouble(0x3fdcb23acd285cacL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Long:3459069652663380555 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd36\ud905\ude70", "\u9ad7\u89b9\uc7a2\u1243\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud06d\u89ea\u6bee\u8bb7\ucc1a\u81f7\u03ee\ua40b\u299b\ub1df\u8a71\u99a0\u8f92\u39a5\u03a3\u376b\u96bc\u98c6\ud0dc", "\uda7e\udc3e\u6a2c\uda85\udc31\uda6f\udd96\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\udbde\udcc4\ud897\uddcb\ud95f\udfd1\ud973\ude95\ud8d2\uddd0\ud8bd\udc0d\ud91e\udd6a\ud921\udf5a\uda22\udd99\udb55\udf58\udba8\udd61\udbd4\udfe4\ud8a0\udfef\ud823\udc86\ud8ce\udcd7\udb6a\udfe7\u60b8\uda1f\udc54\udb01\ude73\ud9f4\udda3\ud831\ude7c",
        50, 92133, -1312913409, 3459069652638180555L, -88914L, true, true, (char) 47591, (char) 59693,
        Double.longBitsToDouble(0x3fa07adb08169b70L), Double.longBitsToDouble(0x3fd10063d0e85d78L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Long:988499531394194901 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ucc1a\u81f7", "\udae5\udf7a\ud986\udd51\udb66\udf18\udabc\udf53\udbf4\udfab\ud853\ude02\ud8ac\udd28\uda6b\udc4a\ud98e\udeec\ud833\udd40\ud987\udd96\udb23\uddd3\udab1\udeab\uda7e\udc3e\u6a2c\uda85\udc31\ud923\udd58\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud81e\ude44\ud897\uddcb\ud95f\udfd1\ud99d\udd69\ud8d2\uddd0\ud8bd\udc0d\udbe0\udf0c\udb4f\udc9a",
        -2, 42563, 951850513, 988499531365394901L, 38900L, false, true, (char) 26943, (char) 22243,
        Double.longBitsToDouble(0x3f8bdfd516438180L), Double.longBitsToDouble(0x3fc0d6e583658fe4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Long:2606619714778792081 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\u9cad\u6248\u76d3\u4894\ub6ec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u299b\ub1df\u8a71\u5dc6\u8f92\u39a5\u03a3\u376b\u09b4\ubfc9\u562e", "\uda7e\udc3e\u6a2c\uda85\udc31\uda6f\udd14",
        58, 5762, 1355144164, 2606619714753592081L, 8050L, false, false, (char) 7214, (char) 31462,
        Double.longBitsToDouble(0x3fed006a2bf2f641L), Double.longBitsToDouble(0x3fcac1660fcd4358L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 3, 5, "\uda95\udf23\ud904\udde5", "\u40b6\ud314\u5f98\u03e9\ub3d8\ub1b6\u62b5\uc635\u486c\u927b\u96d5\ub2c7\u3c9e\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u49bc\ub134\u8a71\u5dc6\u8f4b\ubfb5\u03a3\u376b\u09b4\u59dd\u9aef", "\uda7e\udc3e\u6a2c\uda85\udc31\uda7f\ude6f\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud81e\ude44\ud897\uddcb\ud95f\udfd1\ud99d\udd69\ud9cf\udfaa\ud837\udf87\u52cd\udb4f\udc9a",
        37, 42563, 951850513, 988499531365394901L, -20389L, false, false, (char) 13598, (char) 39455,
        Double.longBitsToDouble(0x3fe62efc2acfcc3cL), Double.longBitsToDouble(0x3fe5c48cf68e5d57L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Long:4834203014078554468 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 14, 15, "\udbf0\udd26\ud905\ude70", "\u9ad7\u775b\u1bdc\u4e56\ub3d8\ub1b6\u61e0\u0a5c\uad30\ubf99\u0a3e\u60ba\ua591\u037c\u8bb7\ucc1a\u81f7\u7905\u9b33\u299b\ub1df\u8a71\u5dc6\u8f92\u5286\u03bc\u376b\u09b4\ubfc9\u9aef", "\ud810\udfc4\uda03\uddfa",
        39, 18491, -1226653400, 4834203014053354468L, 87153L, false, false, (char) 36688, (char) 43380,
        Double.longBitsToDouble(0x3fd540d47a6d4800L), Double.longBitsToDouble(0x3fe5006903f2f6ebL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Long:8788468012402680027 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u299b\ub1df\u8a71\u5dc6\u8f92\u39a5\u03a3\u376b\u09b4\u556c\u9a6c", "\uda7e\udc3e\u6a2c\uda85\udc31\uda6f\udd14\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud81e\ude44",
        1, 4830, -51190536, 8788468012377480027L, 18276L, false, false, (char) 29897, (char) 4537,
        Double.longBitsToDouble(0x3fe8b1c5e1d50db7L), Double.longBitsToDouble(0x3fdcb23acd285cacL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:6488754004025015978 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\uae38\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ucc1a\uca8e\u03c7\ua40b\u299b\ub1df\u8a71\u00a4\000\u921a\u03a3\u376b\u09b4\ubfc9\u9aef", "\u5acc",
        -5, 71072, -34930688, 6488754003996215978L, -62414L, true, true, (char) 63338, (char) 57254,
        Double.longBitsToDouble(0x3fcf0c7d52a81e10L), Double.longBitsToDouble(0x3fea2e7d0ba00d45L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Long:-3485481915980009771 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\ub3d8\ub1b6\u62b5\u76d3\u6889\ub6ec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ucc1a\u81f7\u03ee\ua40b\u299b\ub1df\u8a71\u5dc6\u8f92\u39a5\u03a3\u47db\u51f2\ubfbb\u9aef", "\uda7e\udc3e\u6a2c\uda85\udc31\uda6f\udd14\uda0b\udcb1\ud84d\ude9e\uda3e\udca6\udae9\udcf3\ud81e\ude44",
        1, 4830, 126149880, -3485481916008387771L, 99694L, false, true, (char) 29931, (char) 20409,
        Double.longBitsToDouble(0x3fe8b1c5e1d50db7L), Double.longBitsToDouble(0x3fdcb23acd805cacL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Long:7343543518041769578 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 0, 5, "\000\000", "", "\udb7b\udee1",
        -2, 39247, -1944956131, 7343543518016569578L, -19978L, false, false, (char) 13989, (char) 50156,
        Double.longBitsToDouble(0x3ee0f24026000000L), Double.longBitsToDouble(0x3fe78470017e36fbL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-04:00\012",
        Z.run(T, 1, 8, 8, 0, "\udbd4\udd90\ud905\udeca\ud881\udd0f\uda5d\udfac\ud855\ude6b", "\u9817", "\ud9e5\udfed\ud99a\udf21\ud917\udec3\udb4e\uddd6",
        -4, 99557, 35534696, 2751647087782099520L, 92136L, true, false, (char) 29468, (char) 47595,
        Double.longBitsToDouble(0x3fe63b2c4e8c04b2L), Double.longBitsToDouble(0x3fc488d8316a9754L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Long:4691988388988810327 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd36\udb2e\udda2", "\u662e\u980b\ub3d8\ucc0c\u6282\u76d3\u486c\ub6ec", "\ud880\uddac\ud836\udeb3\ud9fc\udf8f\udbba\udf0e\uda37\udc41\udb47\udc7a\udb97\ude57\udae5\udf7a\ud892\udd57",
        16, 58276, -660799060, 4691988388960010327L, -17455L, false, true, (char) 32469, (char) 63563,
        Double.longBitsToDouble(0x3fe5558496907d53L), Double.longBitsToDouble(0x3fed4dda213ade5dL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Long:7301682457067532999 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd79\udb2e\udda2", "\u66c9\u980b\ub3d8\ub1b6\u6293\u76d3\u48b0\ub6ec", "\ud93e\udf7f\ud9f0\udd3c\ud836\udeb2\ud9fb\udd3d",
        1, 16743, -272562272, 7301682457038732999L, 61956L, false, true, (char) 2329, (char) 50954,
        Double.longBitsToDouble(0x3febfcf1c58f9a84L), Double.longBitsToDouble(0x3fd5228521bef28cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Long:-1689701269198458055 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=null\012",
        Z.run(T, 2, 2, 13, 12, "\udad1\udce4\ud98d\udf82\uda74\udff2\ud8ee\ude1a\ud8a4\udc8b\ud895\ude27\ud892\udf7f\udb03\udfe6\ud847\udddd\ud971\udfcd\udbdf\udc54\ud835\ude12\uda3f\udd2f\ud923\udfde\ud948\udfb2\udbcf\udc28\ud860\udda7\ud9cc\ude4e\ud9fd\udc1a\ud9fb\ude2d\ud955\udd7e\udb40\ude72", "\u2a22\u4d1c\u125c\u4449\ubd25", "\ud931\udfef\ud997\udcc7\uda8a\ude43\ud9af\udff6\udbe0\udf84\ud950\udc12\udb8f\ude8a\ud9cb\udd8d\ue16d",
        34, 91140, 1678533195, -1689701269226836055L, -42269L, false, false, (char) 64479, (char) 13995,
        Double.longBitsToDouble(0x3fdc9d71a9924a28L), Double.longBitsToDouble(0x3fdc2f9f44da5fbaL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 7, 1, "\ud8c9\udc78\udbb0\udf26\uad39\udb2e\udda2\ud855\udf45", "\u849d\u60dc\u69da", "\u3a16\ud9fc\udd4c\u5df2\udba6\udf7a\ud9c4\udf3d\udac4\udeb2\ud9a5\udea3",
        19, 33367, 1801352959, 846966233705849598L, -34036L, true, true, (char) 50954, (char) 50423,
        Double.longBitsToDouble(0x3fd8f92b66a45016L), Double.longBitsToDouble(0x3fe76a89b3bb3816L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Long:7301682457502831676 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:7301682457502831676 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 2, 6, "\uda17\udc67\udbb0\udf26\uda8a\ude47\udbcd\uddaa", "\uc67e\ud1af\ub3d8\ub1b6\u6293\u76d3\u486c\ub6ec", "\udbcd\udf87\ud972\udeb1\ud9fc\udf8f\ud9fb\ude2d",
        1, 16743, -272562355, 7301682457474031676L, 61956L, false, true, (char) 33981, (char) 50954,
        Double.longBitsToDouble(0x3fedfcf1c78f9a84L), Double.longBitsToDouble(0x3fdb0a4a61bef28cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.003\012",
        Z.run(T, 1, 10, 6, 6, "\ud9ab\udc71\udbb0\udf26\ud8a7\udd36\udb2e\udda2\ud855\udf45\ud8b4\ude97\udb99\ude64\udbe6\uddcb\udab5\udc15", "\ua509\u4142\ud5f6", "\udbcd\udf87\ud81a\udcb2\ud9fc\udf8f\ud818\udd1c\udaf2\uddd1",
        3, 35682, -685019518, -4261568973386850741L, 94745L, false, true, (char) 63627, (char) 39202,
        Double.longBitsToDouble(0x3fa1354fd35bf4f0L), Double.longBitsToDouble(0x3fe09ec83c97c868L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Long:4006212804688001507 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd36\udb2e\udda2", "\u66c9\u980b\ub3d8\ub1b6\u6293\u76d3\u486c\ub6ec", "\udbcd\udf87\ud836\udeb3\ud9fc\udf8f\ud9fb\ude2d",
        1, 16743, 180422477, 4006212804659201507L, 61956L, false, true, (char) 33981, (char) 50954,
        Double.longBitsToDouble(0x3fedfcf1c58f9a84L), Double.longBitsToDouble(0x3fd5228521bef28cL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Long:7340202747179779143 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd36\udb2e\udda2", "\u66c9\u980b\ub3d8\ub1b6\u0663\u02bb\u486c\ub6ec", "\udbcd\udf87\ud836\udeb3\udafb\udee4\udaa2\ude03",
        1, 16743, -272562355, 7340202747154579143L, 61956L, false, true, (char) 33981, (char) 50954,
        Double.longBitsToDouble(0x3fedfcf1c58f9a84L), Double.longBitsToDouble(0x3fd5228521bef28cL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Long:3121107805108843148 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:3121107805108843148 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 2, 13, "\uda1c\udcd2\udbb0\udf26\ud8e8\udd56\udb2e\udda2", "\u66c9\ucd70\u7e56\ub1b6\u5219\u76d3\u486c\u37ee", "\udbcd\udf87\ud836\udeb3\ud9fc\udf8f\ud9fb\ude2d",
        1, 93067, -2026162205, 3121107805080043148L, 61956L, false, true, (char) 62850, (char) 43551,
        Double.longBitsToDouble(0x3fe6040aff2dd8b6L), Double.longBitsToDouble(0x3fdaa1054129c1d0L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+28:00\012",
        Z.run(T, 1, 8, 2, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd36\udb2e\udda2", "\u66c9\u980b\ub3d8\ub1b6\u6293\u7625\u486c\ub6ec", "\udbcd\udf87\ud836\udeb3\u9d45\ud8aa\udfec",
        28, 16743, -272562355, 7301682456787074759L, -67533L, true, false, (char) 40439, (char) 22547,
        Double.longBitsToDouble(0x3fd5228521bef28cL), Double.longBitsToDouble(0x3fe3197878f06d50L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Long:1160615871141624362 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd36\udb2e\udda2\ud855\udf45\ud895\ude27\udb99\ude64\udb82\udd38\udbad\udc59\ua448\ud9e5\udfcb\ud99a\udf21\uda1d\udc19\ud9fc\udd4c\ud840\udd47\udaf8\ude7e\udbcd\udf87", "\ucc1a\u81f7\u1d68\uab27\u29b7\ud253\u8a71\ub819", "\ud9ec\udc3c\u21c4\ud931\udfef\uda5d\udc77",
        11, 91341, 995075543, 1160615871116424362L, -27372L, false, false, (char) 63461, (char) 65052,
        Double.longBitsToDouble(0x3fe6335e261592c7L), Double.longBitsToDouble(0x3fe2b6574b455728L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Long:3754816276407516495 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd36\udb2e\udda2", "\u66c9\u7924\u137c\ub1b6\u6293\u76d3\u486c\ub6ec", "\udbcd\udf87\ud836\udeb3\ud9fc\udf8f\ud9fb\ude2d",
        1, 16743, -272562355, 3754816276378716495L, 61956L, false, true, (char) 33981, (char) 50954,
        Double.longBitsToDouble(0x3fedfcf1c58f9a84L), Double.longBitsToDouble(0x3fd522852b89f6d8L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Long:681231366903367527 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.DefaultNameProvider:@?\012",
        Z.run(T, 2, 2, 15, 2, "\ud9e5\udee0\ud9ea\ude04\udaa6\udec0\udb2e\udda2\ud857\udc45\udbf4\ude2a\udb99\ude64\ud8e8\ude1a\ud88f\udcec\udac7\uded7\udb40\udfcf\uda26\ude47\udafc\udca9\ue034\uda11\udd17\uda14\udf6e\udbcd\udf1f\ud836\udeb3\ud817\udc1b\ud9c6\udce0\u93e7\uda18\udfa1\ud821\udfcc\udacf\udd01\uda72\udc47\ud978\udc39\ud9b3\udced\udb27\ude8d\ud887\udd1a\ud849\udcb8\udb8b\ude9a\ud8f4\udd35\uda99\udea7\ud9a3\udfee\ud99e\udd12\udb6b\udcd3\uca9a\ud8b3\udf4b\ud924\udfbd", "\u5d57\ub0fe\u76f7\u80c1\u7ef1\u18a4\ua429\u9668\u28f8\u7d43\ub4f1\u4915\ud68f\u199f\u7b3f", "\ud994\udffd\ud895\ude0a\ud9c5\uddba\udaf6\udf40\ud9d2\uddab",
        -3, 61983, 786043190, 681231366878167527L, 48886L, false, true, (char) 16896, (char) 761,
        Double.longBitsToDouble(0x3fe0c0e8594c9e35L), Double.longBitsToDouble(0x3fd1ebf7607358b2L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 11, 0, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd36\udb2e\udda2", "\u66c9\u980b\ub3d8\ub1b6\u6293\u76d3\u3f44\ub6ec", "\uda96\udd92\ud836\udeb3\ud9fc\udf8f\ud9fb\ude2d",
        1, 16743, -272562355, 7301682456787074759L, 61956L, false, true, (char) 33981, (char) 50954,
        Double.longBitsToDouble(0x3fedfcf1c58f9a84L), Double.longBitsToDouble(0x3fd5228521bef28cL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Long:3713678245917395757 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\udad1\udc48\udba2\udf9b\ud8a7\udd36\udb2e\udda2\ud855\udf45\ud895\ude27\udb99\ude64\udb82\udd38\udbad\udc59\ua448\ud9e5\udfcb\udbf1\udfee\uda1d\udc19\ud9fc\udd4c\ud840\udd47\udaf8\ude7e\udbcd\udf87\ud836\udea5\ud915\udf93\ud9fb\ude2d\ud955\udd7e\udb47\udc7a\udb97\ude57\udae5\udf7a\ud843\udd4f\ud8c6\udfaf", "\uc4fe\uc4a2\u7412\u7d59\uaa69\u5eea\u5fb8\uc3c6\u6703\u9e1e", "\ud965\udf1c\udaee\udfd0",
        55, 33720, 1252740092, 3713678245892195757L, -16989L, false, true, (char) 40271, (char) 10182,
        Double.longBitsToDouble(0x3fe45ee4f208ac4bL), Double.longBitsToDouble(0x3fd61be19d888e2aL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Long:5076658958640635940 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd36", "\u5db3\u60c5\u980b\u7835\u5d94\u6293\ucc2a\u7b25\uc9ae\ubd8b\u265b", "\ud9a3\udf03\ud885\udd4a\ud955\uddb5\udb47\udc7a",
        -5, 22426, 891054791, 5076658958615435940L, -67675L, true, false, (char) 40439, (char) 22547,
        Double.longBitsToDouble(0x3fd5228521bef28cL), Double.longBitsToDouble(0x3fd0f667b1903560L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Long:7301682456815874759 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:7301682456815874759 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 2, 2, "\uda17\udc67\udbb0\udf26\uda56\udeed\udb08\udca2", "\u66c9\u980b\ub3d8\u5cd3\uc6dc\u76d3\u486c\ub6ec\u0a3e\ud06d", "\ud9fc\udf8f\ud9fb\ude2d",
        1, 51343, -273614453, 7301682456787074759L, 61956L, false, true, (char) 33981, (char) 8103,
        Double.longBitsToDouble(0x3fc73509563e6b04L), Double.longBitsToDouble(0x3fd5228521bef28cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Long:-7312438698462495345 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 2, 6, "\uda17\udc67\u7a5f\udb20\udd7d\ud86e\udd76", "\u66c9", "\udbe9\uddfe\uda44\udf9e\ud99a\ude58\ud8ad\udc21\ud9fc\udd4c\ud94d\udd9e\udaf8\ude7e\udbcd\udf87\ud8c7\udd1c\ud9e6\udd60\ud9fb\ude2d\ud955\udd7e\ud975\udc60\udba5\udfbe\udae5\udf7a\ud892\udd57\udb66\udf18\ud9b3\udced",
        13, 88745, -1640497017, -7312438698462495345L, -32193L, true, false, (char) 46238, (char) 26902,
        Double.longBitsToDouble(0x3fdcc5880ff39e8aL), Double.longBitsToDouble(0x3fd67ef243416da0L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 1, 6, 13, 12, "\ud975\udec6\ud818\udd5b\ud8c3\udf8e\ud983\ude9d\ud855\udf45\ud895\ude27\udb99\ude64\ud930\udedc\udae5\udf72\ud807\udfcb\ud802\udedc\ud913\ude90\ud965\udc1a\ud816\udc67\uda03\udee6\ud8fa\udd7a", "\uab6c\u7ddf", "\udb40\udd6d\uda0b\udcc1\ud892\udd57\ud889\udede\udab6\udde6\udbb2\udf45\udba1\udf7b",
        0, 94718, -1006306787, 3142849055262541475L, 5009L, true, true, (char) 51979, (char) 36588,
        Double.longBitsToDouble(0x3fae0b906a75b3a0L), Double.longBitsToDouble(0x3fe73b4e46485070L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 1, 8, 13, 12, "\ud9f0\udd01\ud818\udd5b\udb0c\udea3\ud983\udeb5\ud855\udf45\ud895\ude27\udb99\ude64\ud930\udedc\udae5\udf72\ud807\udfcb\ud802\udedc\ud913\ude90\ud965\udc1a\ud816\udc67\uda03\ude49\ud8fa\udd7a", "\uab6c\u65f8\ua0c7\u174a\u2f5b\u36f1\ubb53\uc21b\ub7af\u3db0\u4d89\ud026\u0f06\u1b06\u8041", "\ud8c3\udd1e\udb10\udd78\uda5f\udce7\udb0b\udf7f\udbe0\udc1e",
        0, -913, -1500924344, -765772790399523291L, 77753L, false, true, (char) 19443, (char) 16565,
        Double.longBitsToDouble(0x3fc36e4fc4ee68b0L), Double.longBitsToDouble(0x3fded3efd7cd4510L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 9, 9, "\ud9f0\udd26\ud905\ude70\ud8c3\udff0\udb2e\udda2\ud9fe\udd7b\ud904\udeeb\udb99\ude64\udae3\udd09\udb8d\udefd\ua448\ud9f7\udeb6\uda33\udf9c\uda1d\udc68", "\u99cc\u2ce9\u771d\u8bb7", "\udbab\udfd6\udbaf\udde0\udbb7\udf7e\ud801\udd6e\uda2b\udf9d\uda1c\udc29\udbcb\udf97\uda45\udc64\udb7f\udf3c\ud98f\udc86\ud823\udf46\ud864\udedb\udb69\udfd6\ud876\udc2a",
        40, 92894, -1314768858, -5338428737744067106L, -22859L, false, false, (char) 5778, (char) 51675,
        Double.longBitsToDouble(0x3fed010c794af3fdL), Double.longBitsToDouble(0x3fe59eca420fcec0L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 1, 11, 8, 8, "\ud811\ude8f", "\u394b\u9bb1\u8cc8\u99b3\u2fa3\ucbd8\u9036", "\udb4a\udd90\uda74\udfae\udb92\udda5\udaf8\ude7e\ud95c\udd2e\ud93f\udd69",
        14, 13096, 1139173502, 7736751119472370509L, 25241L, false, false, (char) 31998, (char) 45923,
        Double.longBitsToDouble(0x3feea1cc6eabd410L), Double.longBitsToDouble(0x3fd4d49627e7273eL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+05:30\012",
        Z.run(T, 1, 11, 8, 10, "\ud811\ude8f\udaad\udc8b", "\u9ac0\u8c57\u99b3\u1b30\u2cb6\u1bc3\u13c3\ud507\u41cb\u6a1b\u4f6f\uc49a\u85c5\u1ecd\u15c7\u2883\ua13c\u1d68", "\ud981\udd6b\udba4\udeac\ud97d\udd7a\ud8ce\udec1\ud973\udc49",
        12, 20267, -114027450, -8684274857033416441L, -57217L, true, true, (char) 1698, (char) 15851,
        Double.longBitsToDouble(0x3fe1ccd96f08704aL), Double.longBitsToDouble(0x3fe22c5d141fa860L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+05:30\012",
        Z.run(T, 1, 11, 8, 8, "\ud8a8\udd1b\ud8cf\udd13", "\u5dfb\u60f8", "\udbc1\udd36",
        12, 34241, 1492966890, -774555146856554472L, -17197L, false, true, (char) 35927, (char) 62576,
        Double.longBitsToDouble(0x3fe78473e87e364dL), Double.longBitsToDouble(0x3fe13a1f334d6b5eL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:Europe/London\012",
        Z.run(T, 1, 11, 8, 8, "\ud811\ude8f\uda24\udfc7", "\u9bb1\u8c57", "\udbc1\udd36\uda7b\ude2a\ud91a\udf7e\ud9e6\udcc0\udb4a\udd90\uda74\udfae\udb92\udda5\udaf8\ude7e\ud95c\udd2e\ud93f\udd69\ud8c0\udec4",
        -3, 94502, 1801352743, -1170474876695295614L, 34908L, false, false, (char) 45923, (char) 9635,
        Double.longBitsToDouble(0x3fe55ea084054962L), Double.longBitsToDouble(0x3fef9c9f7cc32cf7L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:-04:00\0121=org.joda.time.tz.FixedDateTimeZone:-04:00\012",
        Z.run(T, 2, 8, 8, 12, "\ud811\ude8f\uda24\udfc7\ud936\ude61\udb47\ude70\ud8d7\udf85\udaa4\ude1a\ud8f1\udcbd\udad3\udd01\udbc1\udd36\uda7b\ude2a\uda89\ude56", "\ub75e\uab57\ud06d", "\ud9fc\udfc3\ud8ba\ude23\ud95d\udc7e\udb47\udc7a\udbbe\ude57\uda28\udfb0\ud9aa\udfd0\ud9ef\udc71",
        -4, 40246, -737088490, 5288024940601146373L, 26147L, false, false, (char) 46141, (char) 51501,
        Double.longBitsToDouble(0x3fc132cde8d89bb4L), Double.longBitsToDouble(0x3fec64f5ebf1bf0aL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=null\012",
        Z.run(T, 2, 7, 13, 10, "\ud9f0\udd26\ud905\ude70", "\u0237", "\udb3c\udd97\udbed\ude9b\udaca\udf6c\ud8ac\udcf1\ud810\udde5\udabf\udf28\udbaf\udf59\ud833\udf28\uda77\udf83\ud888\udd6a\ud80c\ude6e\u0e60\ud994\udf29\udb7f\udf49\udacd\udd72\uda52\udc23\u0a0b\udb03\udf9e\udb66\udf18\uda8b\udf39\ud8d1\udc86\ud80e\udc1b\ud859\udee5\ud9fc\ude6f\udabb\udff9\ud8a9\udc99\udb0d\udf79\uda62\udf9d\uda28\udd64\uda08\udc64\ud897\ude23\udbaf\udcda\ud8c4\udc3c\ud90d\uddec\ud8b7\uddb5",
        53, 692, -1634345503, 2765893716587120069L, 3191L, true, false, (char) 15838, (char) 53319,
        Double.longBitsToDouble(0x3fe2ec4cccc36982L), Double.longBitsToDouble(0x3fcff6a4a1a35d14L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 11, 5, "\ud932\ude61\ud8e0\ude06\ud8fc\udc41\udb20\udc23", "\u66c9\u980b\u691b\u694a\u7cbc\u76d3\uc710\u9413\uabb3\ud06d\u55cc", "\ud8b8\uddfa\uda90\udfa5\uda8f\udc72\ua67e\udae5\udf7a\udacb\udf94",
        27, -858, 1055424956, 1495660361612758809L, 14823L, false, false, (char) 49294, (char) 5042,
        Double.longBitsToDouble(0x3fdf650d34c73c22L), Double.longBitsToDouble(0x3fe4f109c6185fb2L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=org.joda.time.tz.DateTimeZoneBuilder$PrecalculatedZone:Asia/Bangkok\0121=org.joda.time.tz.DateTimeZoneBuilder$PrecalculatedZone:Asia/Bangkok\012",
        Z.run(T, 2, 11, 11, 6, "\ud932\ude61\ud9b8\ude12\ud84f\udc20\udb09\udeb0", "\u66c9\uadac\ub089\ub1ac\u7cbc\u12e5\uc738\u9413\uabb3\ud06d\u55cc", "\udaaa\udc0d\uda23\ude73\uda4e\udd6c\ud806\udff8\uda28\ude80\ud892\udd57\udb03\udffb\udb11\udc75\uac0f",
        10, 3569, -1835691985, 7100557413413749494L, -20616L, true, false, (char) 454, (char) 56582,
        Double.longBitsToDouble(0x3fe2a1752e39676aL), Double.longBitsToDouble(0x3fcfc5f95a0369acL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+05:30\0121=org.joda.time.tz.FixedDateTimeZone:+40:00\012",
        Z.run(T, 2, 11, 8, 5, "\ud9f0\udd26\u8a01", "\u9bb1\u5db3\u1e9a\u980b\ub3d8\ub1b6\u62b5\u04c2\u80f8\ud7cd", "\udbcd\udf87\ud836\udeb3\ud869\uddad\ud9fb\ude2d",
        40, 16743, 1346196557, 243338382380311595L, -7897L, true, true, (char) 62984, (char) 55467,
        Double.longBitsToDouble(0x3fe98ec28a875668L), Double.longBitsToDouble(0x3feb9645a57b2e57L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Long:5602728603628972199 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 9, 5, "\udaca\udccd\ud986\udd58\ud8c3\udf71\udb2e\udda2\ud94b\udc27", "\u11f2\u3cd8\ub1b6\u2a72\u5172\u64ea\u343f\u1980\ud09c\u89ea\u4db5\ub728\ua29d\uce1d", "\udad1\udda1\uda15\udf19\udbc8\udeac\ud8d4\udd5c\udb98\udcfe\ud998\udc50\u7933\uda96\udca1\ud806\uddae\ud8f0\udf39\ud976\udc2b\ud8f5\udd25\udaa0\udf86\uda9f\ude33\ud870\ude3b\ud8b5\uddeb\udad5\udfb3\ud85e\uddde",
        37, 74714, -1852617366, 5602728603603772199L, 76032L, false, false, (char) 42798, (char) 50448,
        Double.longBitsToDouble(0x3fe81fc0407e8b07L), Double.longBitsToDouble(0x3fe5c342dba19be5L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+55:00\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 6, 5, "\ud9f0\udd26\ud905\ude70\udbfe\udf2d\uda6e\udcdb\ud980\udc61\ud895\udea6", "\u6d3f\u6934", "\uda1d\udc19\udb23\ude3f\ud840\udcf8\udaf8\ude7e\udbcd\udf87\ud81b\udccb\ud869\uddad",
        55, 86561, 1801333485, 5781870186961601272L, 14271L, true, true, (char) 31233, (char) 10,
        Double.longBitsToDouble(0x3f9ba1952c5226a0L), Double.longBitsToDouble(0x3fe14a7cd3e2de25L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 5, "\ud9f0\udd26\ud905\ude70", "\u9bb1\u5db3", "\udb85\udf22\ua448",
        34, 84234, 541080115, 871790219187671890L, 16888L, true, false, (char) 22639, (char) 13588,
        Double.longBitsToDouble(0x3fda536fbc4e87ccL), Double.longBitsToDouble(0x3fb35ad797c281e8L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 5, "\ud9f0\udd26", "\u1ca4\u9bb1\u5db3\u86c3\u980b\ub3d8\ub1b6\000\u75e9", "\ud840\udd47",
        21, 60264, 640667763, 4189528804743183088L, -99961L, false, false, (char) 33527, (char) 18918,
        Double.longBitsToDouble(0x3fe668de5d3de9d5L), Double.longBitsToDouble(0x3feb598795802aa3L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+42:00\0121=org.joda.time.tz.FixedDateTimeZone:+42:00\012",
        Z.run(T, 2, 8, 8, 11, "\ud9f0\udd26\ud905\ude70\u4ff9\uda45\udfb7\ud935\udd2f\ud923\udf6f\u8ca4\ud860\udc3a\udb4b\udeb8", "\u76d3\u486c\u55b0\ub353\u164d\u9eba\u2793\u67fd}\u3c32\u7db9\u5819\ucca7\ubdc4\ua1aa\u43d7\u6aa2\u121f\u5f93\u08d9\u04a4\u52fd\u0f23\u9bd2\u5df8\u26e1\uc5b3\uc08b\u9740", "\ud9fe\udf32\udbfc\udde6\udbc4\udee6\ud87c\udfe1\udb1c\udf52\ud868\uddcd\u2b37\udb73\udedc\udb93\udd93\udb58\ude8f\uda72\ude83\ud8fe\uddd4\u65bd\udae3\uddc7\uda5e\udeb0\ud8b6\udf98\ud80f\udc9f\udbae\udca8\uda8d\udcb9\udb4a\udf19\udb60\udfec\ud81e\ude26\udbb4\ude3d",
        42, 59960, -484175159, -5375213398849722879L, 33443L, true, true, (char) 58093, (char) 9692,
        Double.longBitsToDouble(0x3fe67edccf0879c1L), Double.longBitsToDouble(0x3fdf368596df6708L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Long:871790219212871890 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 14, 4, "\ud9f0\udd26\ud905\ude70", "\u9bb1\u8db3", "\udbad\udcdc\ua448",
        34, 84234, -901760461, 871790219187671890L, 16888L, false, true, (char) 22639, (char) 13588,
        Double.longBitsToDouble(0x3fda536fbc4e87ccL), Double.longBitsToDouble(0x3fb35ad797c281e8L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.035\0121=org.joda.time.tz.FixedDateTimeZone:+35:00\012",
        Z.run(T, 2, 10, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u8107", "\udb82\udd34",
        35, -131, 1709801964, 6378405397245475379L, 16888L, true, false, (char) 22639, (char) 36457,
        Double.longBitsToDouble(0x3fda536fbc4e87ccL), Double.longBitsToDouble(0x3fb35ad797c281e8L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Long:6252812330671847299 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 3, 13, "\ud812\udfdf\ud85b\udf27\ud8c3\udf56\udaac\udf45\udbf6\udfb8\ud847\udd41\udb99\ude64\uda54\uddbb\uda7e\udcbf\ud9bd\udd6b\ud9e5\udfed", "\u5710\u0a3e", "\udbc1\udcf8\ud95e\udfc9\ud90f\udc67\ud9f8\udd6b\ud802\udeae\udbad\udf9b\uda2d\udd5e\u4cfe\ud8a8\udc6d\ua0ce\udb41\udd86\ud8ad\udeb3\ud812\udd0f\udbfa\udf62\udaa5\udca5\udb56\uddaf\ud9ba\udf50",
        10, 86689, 1500528997, 6252812330671847299L, 14057L, false, false, (char) 17268, (char) 34213,
        Double.longBitsToDouble(0x3fe8308a4eb18523L), Double.longBitsToDouble(0x3feaf5e6bd1d0706L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Long:4799587835300870286 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 14, 10, "\ud9f0\udd6e\ud905\ude70\ud8c3\udff0\udb2e\udda2\uda45\udfe7\udb49\udd36\udb92\udd9a\udb82\udd38\ud911\udd5a\ua4c5\ud9e5\udfed", "\u5710\u0a3e", "\udb80\udeb9\udabc\ude50",
        22, 86566, -312576473, 4799587835300870286L, -11231L, true, true, (char) 60504, (char) 48903,
        Double.longBitsToDouble(0x3fc3a7b86126dc10L), Double.longBitsToDouble(0x3fb2a50d9f65ca90L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Long:3134025392121405170 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 3, 13, "\ud9f0\udd6e\ud905\ude70\ud8c3\udff0\udb2e\udda2\udbf7\udc1f\ud895\ude27\udb99\ude64\udb82\udd38\udbad\udc68\ua448\ud9e5\udfed", "\u5710\u5ebf", "\ud836\udeb3\udba2\udea1\udb5c\udfa9\ud955\udd7e",
        7, 4757, -134593392, 3134025392121405170L, -57752L, false, false, (char) 48232, (char) 49015,
        Double.longBitsToDouble(0x3fc3a7b86126dc10L), Double.longBitsToDouble(0x3fb2a50d9f65ca90L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Long:-7666375933250878320 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:-7666375933222500320 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 3, 13, "\ud8eb\udf72\ud905\ude70\ud9ca\uded3\uda1d\ude61\udbea\udd97\ud895\ude27\udb99\ude64\udb82\udd38\udbad\udc68\ud8a0\udf42\ud9e5\udf7f", "\u5710\u52f3", "\ud836\udeb3\udac9\ude89",
        51, 86566, -312576473, -7666375933250878320L, -71576L, false, false, (char) 48232, (char) 49015,
        Double.longBitsToDouble(0x3fc3a7b86126dc10L), Double.longBitsToDouble(0x3fb2a50d9f647590L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 5, "\000\000", "", "\000",
        -5, -945, -1946157027, 7343542505889375488L, -19978L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 3, "\ud9f0\udd26\ud905\ude70\ud896\udcf0\ud87f\udd4a\ud81b\udd4d\ud895\ude27\000", "\ub1b6\u61c9\u75e9\u486c\ub6ec\u0a3e\ud06d\u89eas\000\000\u8f68\000\000", "\udb34\udf87\udac6\uddee\ud9ce\udd65\ud842\udfb2",
        27, 32827, 1914513105, 825632893427301758L, 4855L, false, true, (char) 50664, (char) 14409,
        Double.longBitsToDouble(0x3fe56abc5988deb4L), Double.longBitsToDouble(0x3fd2ca9f1025e056L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 5, "\ud9f0\udd26\ud905\ude70", "\u89b8\u5db3\000\u2000\u52b8\u1574\u61c9", "\ud9fc\udd4c\ud840\udd47",
        22, 82696, 115, 309237645312L, -100000L, false, false, (char) 51585, (char) 9243,
        Double.longBitsToDouble(0x3fdfbb00df43515cL), Double.longBitsToDouble(0x3fccd30478fa97ecL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Long:4864074613325048740 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 0, 4, "\ud9f0\udd26\ud905\ude70\ud896\udd01\ud87f\udd4a\udb25\udd52\udabc\udf5c\uda56\ude9d\udaea\udd7d", "\u889e\u3a1d\u1aac\u9a03", "\udbcd\udf87\ud845\uddb7",
        10, 61284, 517865472, 4864074613325048740L, 14375L, false, false, (char) 64698, (char) 27723,
        Double.longBitsToDouble(0x3fe50a0c491c56a0L), Double.longBitsToDouble(0x3fc5182d851dd340L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.049\0121=org.joda.time.tz.FixedDateTimeZone:+00:00:00.049\012",
        Z.run(T, 2, 10, 10, 5, "\ud9f0\ude84\uda1b\udf9a", "\u343d\u525c\u9a6b\u980b\ub3d8\ub03b\u0313\u85bb\u220a\ua538\u0a3e\ud06d\u89ea\u6857\u8bd2\ud3f2\u2b80", "\ud918\udd2b\u7f03\ud8fb\udf46\ud9fe\uddd3\udb77\udecf\ud93a\udd33\ud981\udfd2\ud8d7\udeb1\udac3\uddda\uda35\udddf\uda42\ude30\udbb7\udcb1\ud8eb\udde3\ud984\udfae\uda70\ude8e\udabe\udea1\udb96\udd4a\uda7b\udec8",
        49, 64666, 1253298298, 6331918610253109086L, 1576L, true, true, (char) 41483, (char) 43862,
        Double.longBitsToDouble(0x3fc110e86040dcacL), Double.longBitsToDouble(0x3fe76109fff1fc7cL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=org.joda.time.tz.DefaultNameProvider:@?\0121=java.lang.Long:4194859407535515936 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 15, 2, 14, "\ud9f0\ude84\uda1b\udf9a", "\u343d\u5db3\u66c9\u980b\ub3d8\ub1b6\ud37b\u7e77\ua20f\ub6ec\u0a3e\ud06d\u89ea\u4e13\u8bb7\ub2e9\uafa0\u12fa\u4dec", "\udb66\udf18",
        0, 72062, -1522729833, 4194859407506715936L, -17393L, false, false, (char) 48162, (char) 21992,
        Double.longBitsToDouble(0x3fd42bb6a34be98aL), Double.longBitsToDouble(0x3fe7587be145fba3L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Long:956358808588886304 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9e4\udc0d\ud905\ude70\u24a2\udad4\udc16\ud855\udf1c\udaa6\udfb1\udb7b\udee1\udb82\udd38\udbad\udc59\uda69\udf67\ud9e5\udfed", "\uc6e8\u1400\u3a0c\u3d5d\u4db5\u8bb7\u064a\u4959\u03ee\ua40b\u299b\ub1df\ud459\u98ea\u8f92\u39a5\u03a3\u376b\u2883\uc148\u2285\u9e45", "\u6a2c\uda85\udc31\uda6f\udd14\udb6b\udfe3\ud84d\uddfc\uda3e\udca6\udae9\udcf3\ud81e\ude44\ud897\uddcb",
        15, -120, -814094772, 956358808563686304L, -22150L, false, false, (char) 2067, (char) 44983,
        Double.longBitsToDouble(0x3fdd7b6461ac0c3cL), Double.longBitsToDouble(0x3fe779e270001fd7L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Long:3342526964704959518 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd26\ud905\ude70", "\uc231\u9f70\u2265", "\ua448",
        54, 86577, -718114013, 3342526964676159518L, -10113L, false, false, (char) 62263, (char) 1924,
        Double.longBitsToDouble(0x3fe67cef24f6ebeeL), Double.longBitsToDouble(0x3fe3beb5bc940239L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Long:3342736373722138527 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 11, "\ud99f\udf22\uda31\udffd", "\u60cb\u9149\u7287", "\ud810\udf48",
        59, 84234, -1780336077, 3342736373693338527L, -10113L, false, false, (char) 62263, (char) 1820,
        Double.longBitsToDouble(0x3fe67cef24d381eeL), Double.longBitsToDouble(0x3febbeb5be82efc1L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Long:1139635976761247588 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\uda09\udc71\ud905\ude70\udba5\udce1\ud88f\udfae\ud853\udc61\ud8e9\udc0e", "\u1184\ub1b6\u62b5\u76d3\ucc6d\u6800\u8398\u1c55\ua276\u42f2\u2e13\u2980\u6c5b\u2bdc\ua435\u3ce6\ud65d\u5c67\u4e8c\u30f1\u32a3\u749d\u5ca7\u8718", "\ud9eb\udc64\uda0c\udd6e\ud9a2\udca5\ud985\ude2e\ud926\udd1c\ud990\udc9a\u157d\ud96e\uddcf\uda36\uddc3\ud906\udf34",
        31, 85965, -1935057416, 1139635976736047588L, 70117L, false, false, (char) 36777, (char) 14063,
        Double.longBitsToDouble(0x3fe590f15f927210L), Double.longBitsToDouble(0x3fa388a2bf101ca0L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Long:4667939972813398289 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9b1\udc07\u3791\uda06\udd36\ud9a2\udd88\ud855\ude6b\udaa6\udfb1\udb8e\udde1\udb82\udd38\ud993\udeee\udafa\udeee\ud9d5\udc14\ud99a\udf21\uda1d\udc19\ud9fc\udd4c\udb89\ude93\udaf8\ude7e\udbcd\udf87\ud836\udeb3\ud9fc\udf8f\ud9fb\ude2d\ud955\udd7e", "\u299b\ub9df\u2798\u9c8a\ub412\u8012\uaf1a\u89cc\u24e5\u7dbf\uc6d4\u8c20\u5cf4\u5b63\uc929\ub392\u534a\u2827\u5425\u8088\u47ab\ubdb4\ud6a7\u093e\ubbdc\u62fa\u00eb\u6484\ua0e1", "\uc31d\uda34\udc36\ud905\ude70\ud81c\udc9a\udad0\udfe2\ud8e2\udca0\udb35\udf1e\u5c28\udb4e\udcef\ud87e\udc95\udb25\udc63",
        38, 20173, -1675655543, 4667939972784598289L, 94756L, true, false, (char) 12574, (char) 9780,
        Double.longBitsToDouble(0x3fc9d675f0a27f58L), Double.longBitsToDouble(0x3fe4e9bffd463e5fL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Long:4526292125743580348 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:4526292125743580348 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 3, 4, "\ud9f0\udd26\ud905\ude70\uda1f\udf3a\u1d87\ud862\ude00\udb75\udf55\udb7b\udfa0\udb34\ude8a\udbad\udc5f\ua448\ud9e5\udfed\ud99a\udf21\ud8a7\udc1e\ud9fc\udd4c\u1ba7\ud993\udee8\ud95d\udfbf\uda65\udd85", "\u81f7\u0fc2\u53c7\u704a\u1115\u822b\ud7af\u123a\u6d36\u883f", "\udb59\udf4e\ud919\udd16",
        52, 22233, 945009200, 4526292125718380348L, 15412L, false, false, (char) 45662, (char) 61878,
        Double.longBitsToDouble(0x3fee0416c2bbd951L), Double.longBitsToDouble(0x3fec4cf543517777L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Long:3648443978694723152 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud991\udd7d\uda47\udd74", "\u72b6\u775b", "\udbad\udc59\ud8d8\ude50",
        40, 74210, -791913408, 3648443978669523152L, 75021L, false, false, (char) 22383, (char) 35083,
        Double.longBitsToDouble(0x3fd7e36fb84e87ccL), Double.longBitsToDouble(0x3fbb9af3eede8198L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Long:6479727622190574671 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 1, "\ud81b\udf32\ud859\udd01\ud8f9\ude4e\ud8a7\udcef\ud84f\ude26\ud9c8\ude49\ud84a\udec4\uda85\udd06\ud8ab\udd36", "\u17a5\u486c\uaf7f\ud0a6\ud649\u5833", "\ud9ba\ude0d\udb5a\udf04\ud9d2\ude6b\udb97\ude57\ud926\udf78\ud986\udd51\udb66\udf18\udb9b\udc68\ud93a\udd26\ud8b9\ude3d",
        6, 64650, 1928193076, 6479727622165374671L, 81404L, false, true, (char) 3354, (char) 33025,
        Double.longBitsToDouble(0x3fbfb4c65027d068L), Double.longBitsToDouble(0x3fd4ef5a9ec7b09cL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Long:-473678311390184745 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:-473678311390184745 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 1, 5, "\ud8fe\uddc8\udb28\udc7c\ud81d\udc20\uda0f\udfca\ud855\ude6b\udaa6\udfb1\udb7b\udee1\u781e\udb27\udf38\ud939\ude5b", "\u7284\uc74a\ud0a6\ud098\uba20\u4de1\u8bb7\ucc22\ub4bc\u3f4d\ua40b\u299b\ub1df\u8a71\u230e\u272f\u652f\uc302\u8c9c\u6a01", "\udb9a\udd3a\udb0f\udec1\ud8b8\ude2b\udb43\udd06\uda66\uded9\ud867\udf22\ud814\ude1d\ud815\udff1\ud9b7\udd93\ud9ba\udd06\udbad\udff7\uda5c\udca6\ud805\udee0\ud96c\udc9e\udb77\udf73\ud9ec\udc20\ud8c8\udeaf\uda46\ude75\ud8a7\udf33\ud8b9\udc08\ud9f2\udd7e\udb10\udf38\udb51\udd3e\uda58\ude12\udbd6\udd06\udb1d\udc14\ud92e\udef5\ud8c5\ude0c\ud830\udcc6\uda07\ude4a\udbad\udf72\udb21\ude63\udb0b\uddcb\ud900\ude6e",
        30, 98785, -1736000370, -473678311390184745L, 61538L, false, false, (char) 57495, (char) 28510,
        Double.longBitsToDouble(0x3fe5b5f3d9688732L), Double.longBitsToDouble(0x3fe0e3a95ec8f7e9L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Long:881973008614913679 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\udb2b\udd07\uda05\udf28", "\u0d9d", "\ud9d4\udea2\udbad\udc59\ua448\ud9e5\udfed\ud99a\udf21\uda1d\udc19\ud9fc\udd4c\ud840\udd47\udaf8\ude7e\udbce\udc1e\udbc3\udebc\ud9fc\udf8f\udae9\ude24\ud955\udd7e",
        50, 35645, 1700023426, 881973008586113679L, -43070L, true, false, (char) 6336, (char) 1433,
        Double.longBitsToDouble(0x3fe882b35acc71a8L), Double.longBitsToDouble(0x3fbb251c7dbed828L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Long:4892678910827981991 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 9, 7, "\ud943\udce3\ud953\udefe", "\u0d82\uc37d\uc779\u1243\u8711\u8444", "\uda34\udd63\ud8f9\udc8b\ud945\udeef\udaf8\ude7e\udbcd\udf87",
        35, 75672, 922483440, 4892678910802781991L, 91756L, false, true, (char) 25690, (char) 26406,
        Double.longBitsToDouble(0x3fddb7b874694566L), Double.longBitsToDouble(0x3fd4a0c4be01b088L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Long:4834203013678452708 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 14, 15, "\udbf0\udd26\ud905\ude70", "\u9ad7\u775b\u1bdc\u4e56\ub3d8\ub1b6\u61e0\u0a5c\uad30\ubf99\u0a3e\u60ba\ua591\u037c\u8bb7\ucc1a\u81f7\u7905\u9b33\u299b\ub1df\u8a71\u5dc6\u8f92\u5286\u03bc\u376b\u09b4\ubfc9\u9aef", "\ud810\udfc4\uda03\uddfa",
        39, 18491, -1226653400, 4834203013649652708L, 87273L, false, false, (char) 36688, (char) 43380,
        Double.longBitsToDouble(0x3fd540d47a6d4800L), Double.longBitsToDouble(0x3fe5006903f2f6ebL)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 0, 5, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\uc745\u980b\000\ub199\u62b5\u76d3\u486c\u7eec\u0a3e\ud06d\u89ea\u4db5\u8bb7\ucc1a\uca8e\u03c7\ua40b\u299b\ua3bd\u8a71\u00a4\000\u0130\ua107\uaa67b\000\ub9bf", "\000",
        -5, 71072, -34930688, 6488754002872107178L, -62414L, true, true, (char) 63338, (char) 57016,
        Double.longBitsToDouble(0x3fcf0c7d52a81e10L), Double.longBitsToDouble(0x3fea2e7d0ba00d45L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Long:7343543516450850154 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 9, 5, "\000\000", "", "\ud805\udd7d",
        -2, 39247, -1944956131, 7343543516425650154L, -19978L, false, false, (char) 13989, (char) 58314,
        Double.longBitsToDouble(0x3fb90a2112015300L), Double.longBitsToDouble(0x3fe78470017e36fbL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 9, 7, "\ud8d0\udd27\u2491", "\u6d16\u4094", "\u9d37\ua448",
        25, -766, 536870912, 7099090732515328L, 16888L, false, false, (char) 41024, (char) 3552,
        Double.longBitsToDouble(0x3fe3c5a91b775229L), Double.longBitsToDouble(0x3fe05c16ab9ae9c3L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Long:5241759661613483820 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\uda17\udc67\udbb0\udf26\ud8a7\udd79\udb2e\udda2", "\u66c9\u980b\ub3d8\ub1b6\u6293\u76d3\u48b0\ub6ec\u0a3e", "\ud9f2\ude4a\ud836\udeb2\ud9fb\udd3d\ud955\udd7e\udb47\udc7a\u9a92",
        36, 86115, 554623157, 5241759661588283820L, -17455L, false, true, (char) 33317, (char) 21184,
        Double.longBitsToDouble(0x3fdcba564d0a27baL), Double.longBitsToDouble(0x3fe3831d9d5d24f5L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Long:8191008140441688201 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 15, "\uda17\udc67\udbb0\udf26\ud951\ude22\udb3f\ude4b", "\u3761\u6c07\ub3d8\u4a9a\u3693\u868d\u48b0\ub6ec", "\ud93e\udf7f\ud9f0\udd3c\ud836\udeb2\ud9fb\udd3d",
        1, 16743, -272562272, 8191008140412888201L, 61956L, false, true, (char) 10181, (char) 50954,
        Double.longBitsToDouble(0x3fd7f9e386f1b290L), Double.longBitsToDouble(0x3fdb612ce1bef28cL)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 13, 13, 12, "\udad1\udce4\ud98d\udf82\uda74\udff2\ud8ee\ude1a\ud8a4\udc8b\ud895\ude27\ud892\udf7f\udb03\udfe6\u25df\ud971\udfcd\udbdf\udc54\ud835\ude12\uda3f\udd2f\ud83e\udc59\ud93c\udd8a\udbcf\udc28\ud860\udda7\ud9cc\ude4e\ud9fd\udc1a\ud9fb\ude2d\ud955\udd7e\udb0e\ude7b", "\u2a22\u4d1c\u25cf\u4449\ubd25", "\udb8e\udcd0\ud8fe\udd0a\uda8a\ude43\ud9af\udff6\u4f85\ud950\udc12\udb8f\ude8a\ud9cb\udd8d\ue16d",
        34, 91140, 1678533195, -1689701269226836055L, 88803L, false, false, (char) 64479, (char) 13995,
        Double.longBitsToDouble(0x3fdc9d71a9924a28L), Double.longBitsToDouble(0x3fdc2f9f44da5fbaL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=null\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 13, 0, 5, "\ud958\uddf4\uda68\udd3c\ud8d0\udcf7\udaa7\udd4d", "\u81a7\u6690", "\ud9e5\udfcb\uda5a\udf21\udaca\udc15\ud8f2\udf38\ud934\uddc0\ud831\udc59\udbf7\udd02\udbc7\uddbd\ud9b8\udcfb\ud971\udd5e\ud8af\uddbe\ud888\udc11\ud870\udf7f\udae5\udf7a\ud892\udd57\udb66\udf18\ud9b3\udced\ud9fc\udce2\ud85f\uddc0\udb4f\uddc5\udbf2\udf9b\ud811\ude19",
        22, 55914, -1161747521, 6779885607769424286L, 68370L, true, false, (char) 29143, (char) 6024,
        Double.longBitsToDouble(0x3fef213ae80968e4L), Double.longBitsToDouble(0x3fc84ccb85a45210L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\0121=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 2, 11, 11, 6, "\uda17\udc67\uda91\udc74\udb9c\udc1f\uda08\udccc", "\u7631\u05d5\ub3d8\u8ec0\ud250\u828d\u9369\ub678", "\udb99\ude17\u8b7f\ud9fc\udf89\udbdc\udc27",
        1, 16743, 889506381, 7301682096009821895L, 61956L, false, true, (char) 29630, (char) 60128,
        Double.longBitsToDouble(0x3fedbe76558fb22eL), Double.longBitsToDouble(0x3fe29142944920d3L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Long:5787747587577416062 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\uda8a\udce2\ud87f\udd04\ud8a7\udd36", "\u9c29\u6031\ucfe5\u7835\u5d94\u9dc6\ucc2a\u7b25\uc9ae\u37f6\u2696\u280d\ud4de\uc291\u9182\u5c8d\u044e\ua40b\u299b\u79b9\ucda0\u6d40\uccfa\uc598\uc4a2\u18cd\u7d59\uc2fe\uca54\u38b1", "\udaab\udf9e\u740b\ufc32\udbae\udc4b\uda2f\udd75\ud806\udc57\ud825\udd8e\ud91b\udd23\udb88\udf54\ud91c\udceb\uda5c\udf90\ud8fb\udc36\uda69\ude31",
        41, 49506, 1345119002, 5787747587548616062L, 52713L, false, true, (char) 31306, (char) 65328,
        Double.longBitsToDouble(0x3feb732d7fd0d451L), Double.longBitsToDouble(0x3fb1a11a50d108f8L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Long:5076658957449055908 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 13, 6, "\udabe\udd4a\ud97d\udf68\ud927\uded3", "\u9c16\u424a\u980b\u558a\u2b97\u5bcc\u4f7c\u607b\u75e9\ubcf5\u8bb1", "\ud9a3\udf03\ud885\udd4a\u693a\uda9a\udec7",
        46, 68522, 895085566, 5076658957420255908L, -88362L, true, false, (char) 40439, (char) 22547,
        Double.longBitsToDouble(0x3fd522852102f28cL), Double.longBitsToDouble(0x3fd0f667b1903560L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 2, 6, "\uda17\udc67\udbc4\udc70\ud8a7\udd0c", "\000\000\u2000\ua622\u5cea\u6293\u62ea\000\ua341\ubd8b\u265b", "\ud9a3\udf03\ud885\udd4a\ud955\uddb5\udb47\udc7a",
        -5, 22426, 889192448, 467917855232L, -67675L, true, false, (char) 40439, (char) 22547,
        Double.longBitsToDouble(0x3fd5228521bef28cL), Double.longBitsToDouble(0x3fd0f667b1903560L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 2, 0, "\udb72\udcb4", "\000\000\003", "\udb85\udf59",
        30, 77744, 8693025, 0L, 96608L, true, false, (char) 36717, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 11, 11, 10, "\ud932\ude61\ud9b8\ude12\ud84a\udfe2\ud981\udf4b", "\u2093\uadac\ub089", "\ud90f\udf22",
        55, 43121, -276951087, -8321428024226734639L, 55522L, false, false, (char) 31199, (char) 26896,
        Double.longBitsToDouble(0x3fedc6bcc482efe5L), Double.longBitsToDouble(0x3fe63b2db82c2b7eL)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Long:5616595644278483111 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 9, 5, "\udaca\udccd\ud986\udd58\ud8c3\udf71\udb2e\udda2\ud94b\udc27", "\u11f2\u3cd8\ub1b6\u2a72\u5172\u64ea\u343f\u1980\ud09c\u89ea\u4db5\ub728\ua29d\uce1d", "\udad1\udda1\uda15\udf19\udbc8\udeac\ud8d4\udd5c\ud82c\udf88\udade\udfc8\u7933\uda96\udca1\ud806\uddae\ud8f0\udf39\ud976\udc2b\ud8f5\udd25\udaa0\udf86\uda9f\ude33\ud870\ude3b\ud8b5\uddeb\udad5\udfb3\ud85e\uddde",
        37, 74714, -1852617366, 5616595644253283111L, 76032L, false, false, (char) 46805, (char) 50448,
        Double.longBitsToDouble(0x3fe81fc0407e8b07L), Double.longBitsToDouble(0x3fe5c342dba19be5L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Long:4189528804743183088 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:4189528804743183088 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 1, 3, "\uda1c\uddc8", "\u1ca4\u9bb1\u5db3\u866e\u980b\u2c72\u857b\ud025\u25cd", "\ud840\udd47",
        21, 60264, 640667763, 4189528804743183088L, -88450L, true, true, (char) 13330, (char) 59426,
        Double.longBitsToDouble(0x3fdea3181f1b18d6L), Double.longBitsToDouble(0x3fe8c18fc5e2bfedL)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 3, "\uc69d\udb9e\udfa3\ud85a\udca2\ud87f\udd4a\ud81b\udd4d\ud895\ude27\000", "\ub1b6\u61c9\uc421\u8812\ucf53\u925b\ud06d\u89ea\u915d\u12a2\u7fb3\u4046\000\000", "\udb34\udf87\udac6\uddee\ud9ce\udd65\ud899\udf7f",
        33, 38604, 1914513132, 808181444871241153L, 4855L, false, true, (char) 50664, (char) 14409,
        Double.longBitsToDouble(0x3fe56abc5988b4abL), Double.longBitsToDouble(0x3fd2ca9f1025e056L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 3, "\ud9f0\udd26\ud905\ude70\ud896\udcf0\ud87f\udd4a\ud81b\udd4d\ud895\ude27\000", "\ub1b6\u8366\u76a1\u486c\ub6ec\u0a3e\ud06d\u89eas\000\000\u8f68\000\000", "\udb34\udf87\udac6\uddee\ud9ce\udd65\uda2e\uddb1",
        27, 32827, 650555857, 5525303323934183243L, 70391L, false, true, (char) 34537, (char) 14409,
        Double.longBitsToDouble(0x3fe56abc5988deb4L), Double.longBitsToDouble(0x3fd2ca9f1025e056L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 5, "\ud9f0\udd26\ud905\ude70", "\ub675\u5db3\000\u2000\u52b8\u1574\u61c9", "\ud87d\udf17\uda73\udcff",
        22, 82696, 2013266035, 903102773329920L, -100000L, false, false, (char) 51585, (char) 9218,
        Double.longBitsToDouble(0x3fdfbb00df43515cL), Double.longBitsToDouble(0x3fccd30478fa97ecL)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:2937575330587096002 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 5, 3, 4, "\ud9f0\udd26\ud905\ude70\uda1f\udf3a\u1d87\ud862\ude00\udb75\udf55\udb7b\udfa0\udb34\ude8a\udbad\udc5f\ua448\uda8e\udd95\ud983\udfa3\ud8a7\udc1e\ud9fc\udd4c\u1ba7\ud993\udee8\uda61\udfb6\udab4\udc2c", "\u2c78\u3b55\u53c7\u704a\u1115\u822b\ud7af\u123a", "\udbcb\udc5d\ud8e8\ude39\uda55\udc35\ud919\udce6",
        38, 47378, -1513632915, 2937575330561896002L, 15412L, false, false, (char) 57424, (char) 61839,
        Double.longBitsToDouble(0x3fee0416c4d18f56L), Double.longBitsToDouble(0x3fec4cf4c3517777L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Long:45564276798326352 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud991\udd7d\uda47\udd74", "\000\u775b", "\udbad\udc59\ud8d8\ude50",
        40, 74210, -791913408, 45564276773126352L, 75021L, false, false, (char) 22383, (char) 35083,
        Double.longBitsToDouble(0x3fd7e36fb84e87ccL), Double.longBitsToDouble(0x3fbb9af3eede8198L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 5, "\ud991\udd0b", "\u5555\u72b6\u775b\uaaed\u97d5\u7a7d\u507c\ua334\u10f4\u544e\u1a3d\uc0c9\u8eee\ua0c6\u4d9a\u2243\ucc1a\u5dd1\u808f\u9ea1\ud638\u2404\u7e31\u9999\u905f", "\udb45\udc4e\ud891\udf25\ud965\ude84\ud8ac\udece\ud81a\ude08\uda3b\udf6f\ud83c\udc85\ud9ca\udff8\udb3c\udf32\udb18\udc1d\ud9cd\ude45\ud84a\ude4e\u5cb7\uda08\udd0e\ud955\udf8f\ud2f5",
        15, 9625, 506584053, 5049269580985537089L, 14567L, false, false, (char) 14016, (char) 65275,
        Double.longBitsToDouble(0x3fe10ad221ed4e83L), Double.longBitsToDouble(0x3f91445d4e9bfc20L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 14, 15, "\udbf0\udd26\ud905\ude70", "\u9ad7\u775b\u1bdc\u0ece\ub3d8\ub1b6\u61e0\u0a5c\uad30\ubf99\u0a3e\u6a7d\ua591\u53fe\u8bb7\ucc1a\u81f7\u7905\u9b33\u800a\uaad4\u8a71\u5dc6\u8f92\u4886\u490b\u6e5b\u09b4\ubfc9\u9aef", "\ud810\udf4f\uda54\udd43",
        39, 18491, -1226653400, 4834203013649652708L, 87273L, true, false, (char) 51279, (char) 34955,
        Double.longBitsToDouble(0x3fd540d47a6d48c0L), Double.longBitsToDouble(0x3fd0dba205c14f88L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 14, 4, "\ud997\uddaf\uda7a\udd6e", "\u9ad7\u775b\u1bdc\u4e56\ub3d8\ub1b6\u61e0\u0a5c\uc7ed\u4b22\u0a3e\u60ba\ua591\u037c\u8bb7\u4ff5\u8195\u7905\u9b33\u299b\ub1df\u8a71\u5dc6\u8f92\u5286\u03bc\u376b\u09b4\ubfc9\u9aef", "\ud810\udfc4\uda03\uddfa",
        39, 18491, -1226653400, 4834203013649652708L, 12410L, true, true, (char) 25243, (char) 18742,
        Double.longBitsToDouble(0x3fe5006903f2f6ebL), Double.longBitsToDouble(0x3fe542aad509cac0L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 0, 15, "\udbf0\udd26\ud905\ude70", "\u9ad7\u775b\u1bdc\u4e56\ub3d8\u531d\ub8c8\u3c71\uad30\ubf99\u0a3e\u60ba\ua591\u037c\u8bb7\u00f0\000\u7905\u9b33\u299b\ub1df\u8a71\u5dc6\u8f92\u5286\u295d\u376b\u09b4\ubfc9\u9aef", "\ud810\udfc4\uda03\uddfa",
        39, 18491, -1226653400, 4834203013649652708L, 87273L, false, false, (char) 36688, (char) 43380,
        Double.longBitsToDouble(0x3fd540d47a6d4800L), Double.longBitsToDouble(0x3fe5006903f2f6ebL)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 7, 7, 15, "\uda17\udc67\udba0\udc26\ud951\ude22\udb3f\ude4b\uda84\udca6\udb28\udf20\ud841\udf38\udbad\udd33\u65d0\ud9a0\udc14\udb0a\udf65\udbd2\udef3\uda1d\udc5d\udab3\udd48", "\ua18b\u1dd4\u8a2c\u0b2a\u5734\u1d68\ua45e\u8cad\u96c6\u30c8\u3b99\u1917\uc530\uc4a2\uaf9b\u09c2\u0973", "\udb89\udd81\ud827\udde5\ud941\udc34",
        13, 5622, 1007965987, -1237521739870286699L, -97427L, false, false, (char) 8072, (char) 6740,
        Double.longBitsToDouble(0x3fe1a0779b45ca4fL), Double.longBitsToDouble(0x3fea9bcb7e160f04L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.Long:37336258078310400 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 2, 2, "\udb72\udcb4\ud81c\uddee\ud9e5\udf40", "", "\udba6\udc38",
        13, 34077, 1190565744, 37336258078310400L, -87282L, false, true, (char) 50250, (char) 9195,
        Double.longBitsToDouble(0x3fca2820ba5b946cL), Double.longBitsToDouble(0x3f4a5d0000000000L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.Long:5113440934226601249 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 2, 13, "\udb72\udcb4", "\000", "\ud98e\udda6",
        -2, 42983, -603940835, 5113440934226601249L, -100000L, false, false, (char) 19813, (char) 50156,
        Double.longBitsToDouble(0x3ee0f011c7570000L), Double.longBitsToDouble(0x3fce11cfa0000000L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.FixedDateTimeZone:+05:30\012",
        Z.run(T, 2, 5, 11, 10, "\ud932\ude61\ud9b8\ude12\ud848\ude00\ud8cd\udeb8", "\u2093\uadac", "\ud856\udde5\ud90f\udf22\udb95\udf30\uda43\udcaf",
        -2, 99557, -254511, 7378776299475046154L, 53638L, true, false, (char) 43856, (char) 37991,
        Double.longBitsToDouble(0x3fe63b2db82c2b7eL), Double.longBitsToDouble(0x3fc17905f1ee6848L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.Long:4901691532473389081 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:4901691532473389081 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 1, 3, "\uda1c\uddc8", "\u1ca4\u9bb1\u5db3\u866e\u980b\u817b\u863c\u431d\u25e3", "\ud840\udd47\udbd2\udd76\udb11\udf69\ud836\udeb3\ud869\uddb8\ud9fb\ude2d\udabf\udddb\udb3c\udf54\u008a\udb33\udfc0\uda19\udca6\ud8e3\udd89\uf605\ud8c9\uddee\udb86\udc6a\ud908\udf1a\udb98\ude7e\ud89a\ude1e\udbda\ude4d\udb04\udd65",
        52, 24402, -483942571, 4901691532473389081L, -14212L, false, true, (char) 57234, (char) 4557,
        Double.longBitsToDouble(0x3feee82271119111L), Double.longBitsToDouble(0x3fab623b75b4cc00L)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 15, "\udbf0\udd26\ud905\ude70", "\u9ad7\u775b\uc6a7\ud391\ub3d8\u531d\ub8c8\u3c71\uad30\ubf99\u0a3e\u60ba\u401d\u037c\u8bb7\u00f0\000\u7905\u354c\u7d56\ub1df\u8a71\u5dc6\u8f92\u5286\u295d\u376b\u09b4\ubfc9\u9aef", "\ud810\udfc4\uda03\uddfa",
        39, 55611, -1226653400, 4834203013649652708L, 87273L, false, false, (char) 36688, (char) 43380,
        Double.longBitsToDouble(0x3fd540d479d81400L), Double.longBitsToDouble(0x3fe5006903f2f6ebL)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.Long:37337009697587200 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 8, 2, "\udb72\udcb4\ud81c\uddee\ud9e5\udf40", "", "\udbd6\udc50",
        13, 34077, 1190565744, 37337009697587200L, -87282L, false, true, (char) 50250, (char) 9195,
        Double.longBitsToDouble(0x3fca2820b65b946cL), Double.longBitsToDouble(0x3fe062f8f0000000L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=org.joda.time.tz.DefaultNameProvider:@?\012",
        Z.run(T, 1, 15, 0, 0, "\ud9ec\udfb6", "\u1ca4\u9bb1\u5db3\u66c9\u980b\ub3d8\ub1b6\u62b5\u76d3", "\ud840\udd47",
        22, 82696, 640667763, -8179246932015973648L, 61319L, true, true, (char) 47427, (char) 9243,
        Double.longBitsToDouble(0x3fe7915bf0a44673L), Double.longBitsToDouble(0x3fd61abcf3f0b4c6L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+05:30\0121=org.joda.time.tz.FixedDateTimeZone:+05:30\012",
        Z.run(T, 2, 11, 11, 5, "\ud9ed\udd64\ud905\ude70", "\u6953\u3e2f", "\udbad\udc59\ua448\ud9e5\udfed\ud973\udc6e\ud831\udd24\udae2\udca9\ud840\udd47\ud8b0\udf79\udbcd\udf87\ud836\udeb3\ud3f4\uda82\udf8b\udbb9\udef0\ud8ad\udd02\udac7\udc70\udb27\ude96",
        54, 55400, -1133970504, 273668104853553988L, 84846L, true, false, (char) 10995, (char) 34924,
        Double.longBitsToDouble(0x3fdb33ccb63be714L), Double.longBitsToDouble(0x3fe586df5cb60f34L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=org.joda.time.tz.DefaultNameProvider:@?\0121=org.joda.time.tz.DefaultNameProvider:@?\012",
        Z.run(T, 2, 15, 15, 11, "\ud8ac\uddaf\udb81\udd40", "\u3523\u59d8\u5b56\u980b\ub3d8\ub1b6\u62b5\u85bb\u7279\u7c8d", "\udbcd\udf87\ud812\udd5f\ud9fc\udf8f\uda92\udcaa\ud975\udf06\udb47\udc7a\udb97\ude57\udae5\udf7a\ud88c\udce9\udb66\udf18\ud9fe\uddd3\udb77\udecf\ud93a\udd33\u1917",
        4, 10892, 393965743, 8963107585745633215L, 87740L, true, true, (char) 27275, (char) 25833,
        Double.longBitsToDouble(0x3fcf16aa052bb688L), Double.longBitsToDouble(0x3fe3d045fd1d6176L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=java.lang.Long:2686222033367367489 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\udab3\udea4\udb10\uddcd", "\u65bb\ua4c1\u2265\ub6ce\u7683\uca8f\ud1eb\u76d3", "\udac0\udc00\uda90\udfca\udbfe\udd5c\udadb\udf2c\ud940\udcf1\ud9bb\udd95\ud900\udeb6",
        32, 35687, -1727018622, 2686222033342167489L, 28705L, true, false, (char) 63213, (char) 55466,
        Double.longBitsToDouble(0x3fd5461276ae889aL), Double.longBitsToDouble(0x3fc0a9d00d3240dcL)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=java.lang.Long:956358807739814643 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud9f0\udd18\udb22\udf5f\ud881\udd0f\uda5d\udfac\ud833\udc2c\udaa6\udfb1\udb7b\udee1\udb82\udd38\ud8dd\ude04\ud88b\udeeb\ud9ee\udfeb\ud99a\udf21\uda1d\udc19\ud9fc\udd4c\ud840\udd47\udaf8\ude7e\udbcd\udf87\ud836\udeb3\ud9fc\udf8f\ud9fb\ude2d\ud955\udd7e\ud9d2\ude81\udb97\ude57\udae5\udf7a\ud986\udd51", "\u1ac6\u39a5\uaca5\u384b", "\udb3a\ude21\udb23\uddd3\udab1\udeab\uda7e\udc3e\u6a2c\uda88\ude52\udaac\udcd2\u612f\ud973\udec0\uda39\udc8f\ud8f0\udeba\ud9fb\udf13\ud89c\udf6d",
        49, 97107, -807958640, 956358807711014643L, 56886L, true, true, (char) 20409, (char) 5074,
        Double.longBitsToDouble(0x3fcaa1b6e72c8cccL), Double.longBitsToDouble(0x3fe4a292b6cc3be8L)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=java.lang.Long:2666296294127771579 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\uda72\udf0a\ud8b2\udd6e", "\u0d9d\u8c1f\u413e\u290e\ub3d8\ub1b6\u62b5\u76d3\u486c\ub6ec\u0a3e\ud06d\u8a81\u2a7b", "\ud955\udd7e\ud9d2\ude81\ud8fb\udf49\udac6\ude7a\ud895\udc24\uda3e\ude76\ud886\udd3b\ud914\ude74\ud853\ude02\ud8ac\udd28",
        57, 89994, -2107243353, 2666296294098971579L, -15051L, false, false, (char) 10941, (char) 47589,
        Double.longBitsToDouble(0x3feb1fef5aaa5a0cL), Double.longBitsToDouble(0x3fef2218b2d250c5L)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\0121=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 2, 11, 11, 0, "\ud932\ude61\ud9b8\ude12\ud84f\udc20\udb09\udeb0", "\u66c9\uadac\ub089\u9b28\ud0cf\u12e5\ud6d29\uab6f\ud06d\u7fa1", "\udaaa\udc0d",
        56, 78783, -270160661, 7329507797551201991L, 8333L, true, false, (char) 15919, (char) 53742,
        Double.longBitsToDouble(0x3fe7b31455c4ddcbL), Double.longBitsToDouble(0x3fea98c2f9f650d3L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 5, 5, 3, "\ud9f0\udd26", "\u1f4f\u9b1d\u5db3\u86c3\u980b\ub3d8\ub1b6\ua97d\u5611", "\ud840\udd47",
        21, 60264, 640667763, 4189528804743183088L, -99961L, false, false, (char) 33527, (char) 18918,
        Double.longBitsToDouble(0x3fe950de5d3de923L), Double.longBitsToDouble(0x3febde6045802aa3L)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 5, "\uda27\udea1", "\ucf25\u9bb1\u43d6\u86c3\u980b\ub3d8\ub1b6\000\u75e9", "\udaaa\uddd5",
        14, 60264, -971124621, 9176823830465203877L, -99961L, false, true, (char) 33527, (char) 18918,
        Double.longBitsToDouble(0x3fe668de59f4e9d5L), Double.longBitsToDouble(0x3feb59851d802aa3L)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 0, "\000\000\000\000\000\ud958\udd0c\uc53e\ud82c\ude56\udb5e\udc5b\udbd2\udd46\ud9e5\udf01\ud99a\ude37\uda1d\udc19\ud9d2\udc97\000\000\000", "", "\udafb\udc31",
        28, 34406, -73630218, 7713619454891010287L, -8758L, false, true, (char) 49987, (char) 49505,
        Double.longBitsToDouble(0x3fe49b711ab3f983L), Double.longBitsToDouble(0x3fe57dda1fd1ae65L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=java.util.TreeSet:[Africa/Abidjan, Africa/Accra, Africa/Addis_Ababa, Africa/Algiers, Africa/Asmara, Africa/Asmera, Africa/Bamako, Africa/Bangui, Africa/Banjul, Africa/Bissau, Africa/Blantyre, Africa/Brazzaville, Africa/Bujumbura, Africa/Cairo, Africa/Casablanca, Africa/Ceuta, Africa/Conakry, Africa/Dakar, Africa/Dar_...\0121=java.util.TreeSet:[Africa/Abidjan, Africa/Accra, Africa/Addis_Ababa, Africa/Algiers, Africa/Asmara, Africa/Asmera, Africa/Bamako, Africa/Bangui, Africa/Banjul, Africa/Bissau, Africa/Blantyre, Africa/Brazzaville, Africa/Bujumbura, Africa/Cairo, Africa/Casablanca, Africa/Ceuta, Africa/Conakry, Africa/Dakar, Africa/Dar_...\012",
        Z.run(T, 2, 12, 12, 8, "\uda17\udc67\uae45\ud951\ude22\uda0e\udd99", "\u26c9\u6c07\ub3d8\u4a9a\u3693\u1b53\u48b0\ub6ec", "\ud93e\udf7f\uda3a\udd41\ud836\udeb2\ud866\udd12",
        -5, -65, -283823033, 3579322607316804824L, -47100L, true, true, (char) 64048, (char) 51008,
        Double.longBitsToDouble(0x3fd7f9e386f1b290L), Double.longBitsToDouble(0x3fdb612ce1bef28cL)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 2, 12, "\ud9fa\udc78\ud9fb\ude82\ub496", "\u00b1\000\u2000\ua622\u5cea\u6293\u62ea\000\ua341\ubd8b\u265b\u280d\ud4de\uc291\u9182\u822e", "\udae5\udf7a\uda40\udf1fm\udbd2\udd2d\udae1\ude30\udad9\ude57\udb38\udec3\u21c4\u5623\ud96c\udec3\ud828\uddfa\uda98\udea1\udacf\udee9\udbf8\udd51\ud92b\udf2c\ud8f1\udce9\ud849\ude47\ud830\udced",
        -3, 11414, 1845606587, 3866333434426441763L, -47881L, false, true, (char) 32965, (char) 59393,
        Double.longBitsToDouble(0x3fe78fedfa42fc46L), Double.longBitsToDouble(0x3fe164f5b01aeabaL)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:\udb72\udcb4\0121=java.lang.Long:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 6, 4, 4, "\udb72\udcb4", "\000\u0800\003", "\udb85\udf59",
        30, 77744, 1166320929, 0L, 96640L, true, false, (char) 11884, (char) 48053,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 14, 15, "\udbf0\udd26\ud905\ude70", "\u9ad7\u775b\u1bdc\u0ece\ub3d8\u10c8\u2003\u0a5c\uad30\ubf99\u0a3e\u6a7d\ua591\u53fe\u8bb7\ucc1a\u81f7\u7905\u9b33\u800a\uaad4\u8a71\u5dc6\u8f92\u4886\u490b\u6e5b\ubb21\ubfc9\u9aef", "\ud810\udf4f\uda54\udd43",
        41, 18491, -1226653400, 4834203013649625060L, 87273L, true, false, (char) 51279, (char) 34955,
        Double.longBitsToDouble(0x3fd540d47a6d48c0L), Double.longBitsToDouble(0x3fd0dba205c14f88L)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 0, "\udb69\uddb2\000\000\000\000\ud958\udd0c\uc53e\ud82c\ude56\udb5e\udc5b\udbd2\udd46\ud9e5\udf01\ud99a\ude37\uda1d\udc19\ud9d2\udc97\000\000\000", "", "\udafb\udc31",
        28, 34406, -73630218, 7713619454891010287L, -8758L, false, true, (char) 49987, (char) 49505,
        Double.longBitsToDouble(0x3fe49b711ab3f983L), Double.longBitsToDouble(0x3fe57dda1fd1ae65L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 0, "\000\000\000\000\000\ud8bc\ude0c\uc53e\ud82c\ude56\udb5e\udc5b\udbd2\udd46\ud9e5\udf01\ud99a\ude37\uda1d\udc19\ud9d2\udc97\000\000\000", "", "\udafb\udc31",
        28, 34406, -73630218, 7713541700592266228L, -8758L, false, true, (char) 49987, (char) 49505,
        Double.longBitsToDouble(0x3fe49b711ab3f983L), Double.longBitsToDouble(0x3fe57dda1fd1ae65L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=java.lang.Long:7343542886681577066 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 0, 5, "\000\000", "", "\udb7b\udee1",
        47, 56283, 795641905, 7343542886656377066L, -19978L, false, false, (char) 13989, (char) 50156,
        Double.longBitsToDouble(0x3ee0f24026000000L), Double.longBitsToDouble(0x3fe78470017e36fbL)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=java.lang.Long:5573833455159090404 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 2, 2, 6, "\uda25\udcf4\udbf4\udecb\ud8a7\udd36", "\u5db3\ua9c5\ua8b3\ub3d8\ub1b6\u0663\u02bb\u486c\u5750\u0a3e\ud06d", "\udbdc\ude6f\ud89e\ude12\ud946\uddec\udab8\udddf\udb99\udfeb\ud979\uddaa\ud892\udd56\udb66\udf18\ud9be\ude5d\udb76\udde6\udac6\udd41\udb38\udf1b\ud9ae\ude76\ud932\udc45\uda5d\udc77\ud909\udea1",
        56, 7256, -872946032, 5573833455130290404L, 8580L, true, false, (char) 6299, (char) 18937,
        Double.longBitsToDouble(0x3fe5a8be02ca0deeL), Double.longBitsToDouble(0x3fdec830abb59112L)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 5, "\ud9f0\udd26", "\u1ca4\u9bb1\u00bd\u86c3\u980b\ub3d8\u9440\ud1bf", "\ud9fc\udd4c\ud840\udd47",
        21, 60264, 640667763, 4190329249208204016L, -99961L, false, false, (char) 33527, (char) 18918,
        Double.longBitsToDouble(0x3fe668de5d3de9d5L), Double.longBitsToDouble(0x3feb598795802aa3L)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:3345048621130643192 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 5, "\udaba\udc72", "\u1ca4\u9bb1\u5db3\u0520\u75f6\ub3d8\ub1b6\000\u0b1d\u3dc7\ub660\u1b21\u47b4", "\ud869\uddad",
        55, 86605, 39, 3345048621101843192L, -91285L, true, true, (char) 13405, (char) 64398,
        Double.longBitsToDouble(0x3fe03c5bc2869c8dL), Double.longBitsToDouble(0x3f9a864aa0ecbc00L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=java.lang.Long:9122053238655028824 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 0, 7, "\uda7e\udc1a\ud94b\ude34\ud896\udc7d\ud87f\udd4a\ud8af\udef1\ud9c9\udee8\udbb2\udf9b\udbc9\uddc5", "\u8876\u3727\u1383\u47ce", "\u2c11\ud84a\udc7c",
        10, 65628, 517865494, 9122053238655028824L, 14375L, false, false, (char) 64698, (char) 34295,
        Double.longBitsToDouble(0x3fe28325e5fa5f40L), Double.longBitsToDouble(0x3fc5183e251dd340L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=java.util.TreeSet:[Africa/Abidjan, Africa/Accra, Africa/Addis_Ababa, Africa/Algiers, Africa/Asmara, Africa/Asmera, Africa/Bamako, Africa/Bangui, Africa/Banjul, Africa/Bissau, Africa/Blantyre, Africa/Brazzaville, Africa/Bujumbura, Africa/Cairo, Africa/Casablanca, Africa/Ceuta, Africa/Conakry, Africa/Dakar, Africa/Dar_...\0121=java.lang.Long:8307250475975267892 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 12, 3, 4, "\ud866\udd58\ud905\ude70\uda1f\udf3a\ud80a\udda7\ud862\uddfd\udb75\udf55\udb7b\udfa0\udb34\ude8a\udbad\udc5f\ud808\udc48\ud9e5\udfed\ud99a\udf21\ud8a7\udc1e\ud9fc\udd4c\u1ba7\ud993\udee8\ud95d\udfbf\ud97f\udfad", "\u2492\u0fc2\u53c7\u704a", "\udb89\udd3a\udaca\udf03\ud84b\uddc0\ud88f\udef7",
        14, 17430, 87682816, 8307250475946467892L, -80080L, true, false, (char) 48652, (char) 45735,
        Double.longBitsToDouble(0x3f8b146885b04ec0L), Double.longBitsToDouble(0x3fa4142d9763d800L)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 8, 3, "\uc69d\udb9e\udfa3\ud85a\udca2\ud87f\udd4a\ud81b\udd4d\ud895\ude27\000", "\ub1b6\u61c9\uc421\u8812\ucf53\u925b\ud06d\u89ea\u915d\u12a2\u7fb3\u4046\000\000", "\udb34\udf87\udac6\uddee\ud9ce\udd65\ud899\udf7f",
        33, 38604, -987945236, 808180796331179457L, 4855L, false, true, (char) 50664, (char) 14409,
        Double.longBitsToDouble(0x3fe56abc5988b4abL), Double.longBitsToDouble(0x3fd2ca9f1025e056L)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 3, 15, "\udbf0\udd26\ud905\ude70", "\u7dc4\u775b\uc6a7\ud391\ub3d8\u531d\ub8c8\u3c71\uad30\ubf99\u0a3e\u60ba\u50ea\u86b3\u8bb7\u00f0\000\u7905\u354c\u7d56\ub1df\u8a71\u5dc6\u8f92\u5286\u295d\u376b\u09b4\u2bf0\u9af9", "\ud810\udfc4\uda03\uddfa",
        39, 55611, -1226653400, 4834203013649652708L, -43799L, true, false, (char) 36688, (char) 13173,
        Double.longBitsToDouble(0x3fa01c304ec82480L), Double.longBitsToDouble(0x3fe5006903f2f6ebL)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.039\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 3, "\udbf0\udd1a\ud905\ude70", "\u465e\u775b\uc6a7\ud391\uafd8\u5336\ub8c8\u4672\uad30\ubf99\u0a3e\u60ba\u50ea\u86b3\u8bb7\u00f0\000\u5364\u3d15\u7d56\ub1df\u8a71\u5dc6\u0b60\u5270\u295d\u376b\u09b4\u2bf0\u9af9", "\ud810\udfc4\uda03\uddfa",
        39, 38617, -1237393337, 4834203013649652708L, -43799L, true, false, (char) 17477, (char) 13173,
        Double.longBitsToDouble(0x3fa01c304ec82480L), Double.longBitsToDouble(0x3fe5006903f2f6ebL)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:+00:00:00.009\0121=org.joda.time.tz.FixedDateTimeZone:+00:00:00.009\012",
        Z.run(T, 2, 10, 10, 5, "\ud943\udcad\ud80d\udc40", "\u8a53\u5db3\000\u2000\ub3d8\u20af\u43ed\uc5f1\ucf4c\ub6ec\uc048", "\udb26\udcf3\ud910\ude54\ud951\ude7c",
        9, -1000, 0, 7157567269052176579L, -6066L, false, false, (char) 4650, (char) 9237,
        Double.longBitsToDouble(0x3fdcad26bf125ae0L), Double.longBitsToDouble(0x3fd902919bf622c6L)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:102473633138048 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 5, 3, 4, "\ud9f0\udd26\ud905\ude70\uda1f\udf3a\u1d87\ud862\ude00\udb75\udf55\udb7b\udfa0\udb34\ude8a\u9d3d\000\000\uda61\udd2f\ud8a7\udc1e\ud9d2\udc97\000\ud993\ude19\uda61\udfb6\udab4\udc2c", "\u2c78\u3b55\u53c7\u704a\u1115\ub509\ud7af\u123a", "\udbcb\udc5d\ud8e8\ude39\uda55\udc35\ud919\udce6",
        38, -598, -1513632915, 102473607938048L, -100000L, false, false, (char) 0, (char) 61839,
        Double.longBitsToDouble(0x3fee0416c4d18f56L), Double.longBitsToDouble(0x3f43d30000000000L)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 15, "\udbf0\udd26\ud905\ude70", "\u9ad7\u775b\uc6a7\ud391\ub3d8\u531d\ub8c8\u3c71\uad30\ubf99\u0a3e\u60ba\u401d\u037c\u8bb7\u00f0\000\u7905\u354c\u7d56\ub1df\u8a71\u5dc6\u8f92\u5286\ua120\000\u0952\ubfc9\u9aef", "\ud810\udfc4\uda03\uddfa",
        39, 55611, -1226653400, 4834203013649652708L, 87273L, false, false, (char) 36688, (char) 43380,
        Double.longBitsToDouble(0x3fd540d479d81400L), Double.longBitsToDouble(0x3fe5006903f2f6ebL)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=java.lang.Long:2532478187460275583 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 3, "\ud9f0\udd26\ud905\ude70", "\u9ad7\u775b\u3a46\u980b", "\udabf\udd88\ud99a\udf21\uda1d\udc19\ud9fc\udd4c\udb89\ude93\udaf8\ude7e\udbcd\udf87",
        3, 75672, 922483440, 2532478187431475583L, 81158L, true, true, (char) 20088, (char) 55245,
        Double.longBitsToDouble(0x3fe9a63401dadcfaL), Double.longBitsToDouble(0x3fefa2413069b2e7L)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=java.lang.Long:56956 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:56956 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 1, 1, 5, "\ud8fe\uddc8\udb28\udc7c\ud81c\udf8c\uda0f\udfca\ud855\ude6b\udaa6\udfb1\udb7b\udee1\u141e\udb27\udf38\ud939\ude5b", "\u7284\uc74a\ud0a6\ud098\uba20\u009f\000\ucb2a\ub4bc\u6ebb\ua40b\u299b\ub1df\u8a71\000\000\u0ad0\uc24a\u8c9c\u6a01", "\udb9a\udd3a\udb0f\udec1\ud8b8\ude2b\udb43\udd06\uda66\uded9\ud867\udf22\ud814\ude1d\ud815\udf29\ud9b7\udd93\ud9ba\udd06\udbad\udff7\uda5c\udca6\ud805\udee0\ud96c\udc9e",
        29, 47569, 61321, 56956L, -100000L, false, false, (char) 0, (char) 3404,
        Double.longBitsToDouble(0x3fd2bd702ecdfb38L), Double.longBitsToDouble(0x3fe3963dab21c4d4L)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:6881067020938381432 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 2, "\udaba\udc72", "\u1ca4\u9bb1\u5db3\u0520\u75f6\ub3d8\ub1b6\000\u851c\u3dc7\ub660\u1b21\u47b4", "\ud869\uddad",
        55, 86605, 39, 6881067020913181432L, -91285L, true, true, (char) 50524, (char) 12638,
        Double.longBitsToDouble(0x3fe03c5bc2869c8dL), Double.longBitsToDouble(0x3f9a864aa0ecbc00L)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=java.lang.Long:1923258105936653896 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:1923258105936653896 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 2, 6, "\uda17\udc67", "\u1ca4\u9bb1\u5db3\u60c5\u980b\u7835\u5d94\u0393\ucc2a\u7b25\uc9ae\ubd8b\u265b\u280d\ud4de\uc291\u9182\u822e\u1d68\ua40b\uc206", "\udbd2\udde4\udae1\ude30\udad9\ude57\udb38\udec3\u21c4",
        19, 354, -1451554593, 1923258105911453896L, 55806L, false, false, (char) 16338, (char) 40120,
        Double.longBitsToDouble(0x3fe8f01198c398d3L), Double.longBitsToDouble(0x3fdedd1113f040f2L)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=java.lang.Long:3201621011963489354 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=org.joda.time.tz.FixedDateTimeZone:+34:00\012",
        Z.run(T, 2, 2, 8, 6, "\ud991\uddb4\uda47\udd74\ud905\udf0d\ud9e9\udc55\ud99c\udd08\udaa6\udfb1\ud947\ude87\ud8b4\udd52\udbad\udc63\ud8d8\ude50\ud8b5\udead\udb33\udcf5\udb86\udd77\udb70\udf73\ud885\udf22", "\u4d9a\ua741\ubc1d\uc404\u2a7b\ub8ce\uca6d\u59e9", "\ud9bd\udf44",
        34, 81077, -1829162683, 3201621011934689354L, -6058L, true, false, (char) 19528, (char) 57023,
        Double.longBitsToDouble(0x3fe2e5b60bb8593cL), Double.longBitsToDouble(0x3fd4fd2320834b0cL)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:3314649323642292344 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 5, "\udaba\udc72", "\u1ca4\u9bb1\u5db3\u0520\u0086\ub3d8\u9b32\000\uaaa1\u3dc7\ub660\u1b21\u47b4", "\ud869\uddad",
        55, -835, 0, 3314649323617092344L, -99125L, false, true, (char) 7551, (char) 53900,
        Double.longBitsToDouble(0x3f9a864aa0ecbc00L), Double.longBitsToDouble(0x3fe2278282aa07c5L)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 3, 15, "\udbf0\udd26\ud905\ude70", "\u7dc4\u775b\uc6a7\ud369\ub3d8\u531d\ub8c8\u3c71\uad30\ubf99\u0a8f\u60ba\u50ea\u86b3\u8bb7\u00f0\000\u7905\u354c\u7d56\ub1df\ud2e6\u5dc6\u8f92\u5286\u295d\u376b\u09b4\u2bf0\u9af9", "\ud810\udfc4\uda03\uddfa",
        39, 55611, -1226653400, 4834203013649647076L, -43799L, true, false, (char) 61963, (char) 13173,
        Double.longBitsToDouble(0x3fa01c304ec82480L), Double.longBitsToDouble(0x3fe5006903f2f6ebL)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:2398427531658325497 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 7, 3, 15, "\udbf0\udd26\ud905\ude70", "\u7dc4\u775b\uc6a7\ud391\ub3d8\u531d\u27fe\u3c71\uad30\ubf99\u0a3e", "\udbce\udf7a\ud9fc\udf8f\u00f0\000\ud91c\udf88\ud90c\udd9c\ud831\udc21\udac6\udead\uda01\udd16\ud885\udec1\ud9f9\udffa\ud856\udea9\ud9e9\udece\uda98\udca2\udbec\uddcf\uda40\udf9b\ud987\udda0\ud894\udfee\udafb\udfa3\ud9be\udfdd\uda03\uddfa",
        39, 55611, -1226653400, 2398427531629525497L, -4108L, true, true, (char) 40064, (char) 7988,
        Double.longBitsToDouble(0x3fe5006904e44fbcL), Double.longBitsToDouble(0x3fe1d7b5a0b41052L)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=java.lang.Long:7343543516093196906 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 0, 15, "\uda18\udc0b\000", "", "\udba3\udff5",
        41, 10704, -1944956131, 7343543516067996906L, -19978L, false, false, (char) 41388, (char) 50156,
        Double.longBitsToDouble(0x3ee0f24026000000L), Double.longBitsToDouble(0x3f9ff13e266cff60L)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=org.joda.time.tz.FixedDateTimeZone:UTC\0121=org.joda.time.tz.FixedDateTimeZone:UTC\012",
        Z.run(T, 2, 8, 8, 12, "\ud811\ude8f\uda24\udfc7\ud936\ude61\udb47\ude70\ud8d7\udf85\udaa4\ude1a\ud8f1\udcbd\udad3\udd01\udbc1\udd36\uda7b\ude2a\uda89\ude56", "\ub75e\uab57\ud06d", "\ud9fc\udfc3\ud8ba\ude23\ud95c\udc7e\ud909\udd7b\ud902\udcc4\uda51\udfbb\ud9aa\udfd0\ud9ef\udc71",
        0, 40074, -737106922, 5288024940601146373L, 26147L, false, false, (char) 46141, (char) 51501,
        Double.longBitsToDouble(0x3fc132cde8d89bb4L), Double.longBitsToDouble(0x3fec64f5ebf1bf0aL)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=java.lang.Long:4834203855492042724 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 14, 15, "\udbf0\uddb1\ud905\ude70", "\u9ad7\u775b\u1bdc\u0ece\ub3d8\ub1b6\u61e0\u0a5c\uad30\ubf99\u0a3e\u6a7d\ua591\u53fe\u8bb7\ucc1a\u81f7\u7905\u9b33\u800a\uaad4\u8a71\u5dc6\u8f92\u4886\u490b\u6e5b\u09b4\ubfc9\u9aef", "\ud810\udf4f\uda54\udd43",
        0, 17601, 1897725658, 4834203855463242724L, 87273L, true, false, (char) 51279, (char) 34955,
        Double.longBitsToDouble(0x3fd540d3fa6d48c0L), Double.longBitsToDouble(0x3fd0dba205c14f88L)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:1243123237422104934 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 2, "\udaba\udc72", "\u1ca4\u9bb1\u5db3\u0520\u75f6\ub3d8\ub1b6\000\u851c\u3dc7\ub660\u1b21\u47b4", "\ud869\uddad",
        55, 86605, 39, 1243123237396904934L, -91285L, true, true, (char) 50524, (char) 12638,
        Double.longBitsToDouble(0x3fe03c5bc2869c8dL), Double.longBitsToDouble(0x3f9a864aa0ecbc00L)));
  }
  @Test(timeout = 4000)
  public void test177() throws Throwable {
    assertEquals("0=java.lang.Long:1923258105936653896 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:1923258105936653896 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 2, 6, "\uda17\udc67", "\u1ca4\u9bb1\u5db3\u18f0\u980b\u9705\u5ac2\u256b\ucb95\u7b25\uc9ae\ubd8b\u265b\u280d\ud4de\uc291\u9182\u822e\u1d68\ua40b\uc206", "\uda77\udd97\udae1\ude30\uda31\udf42\uda78\udcc3\u0196",
        19, 354, -1451554593, 1923258105911453896L, 17953L, true, false, (char) 16338, (char) 40120,
        Double.longBitsToDouble(0x3fe8f01198c398d3L), Double.longBitsToDouble(0x3fdedd1113f040f2L)));
  }
  @Test(timeout = 4000)
  public void test178() throws Throwable {
    assertEquals("0=java.lang.Long:4834203013678447076 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:4834203013678447076 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 2, 3, 15, "\udbf0\udd26\ud905\ude70", "\u920a\ucf66\uc6a7\ud369\uced5\u79fa\u9a4e\u3c71\uad30\ubf99\u0a8f\uc3b0\uc231\u86b3\u523d\u3b33\u215e\uc1bb\u5ca9\u7d56\ub1df\ud2e6\u5dc6\u8f92\u5286\u295d\ucbf8\uce2d\u6b30\u9a50", "\ud810\udfc4\uda03\uddfa",
        39, 55611, -1226653400, 4834203013649647076L, -46871L, false, false, (char) 55794, (char) 7116,
        Double.longBitsToDouble(0x3fa01c02cec82480L), Double.longBitsToDouble(0x3fe5006903f2f6ebL)));
  }
  @Test(timeout = 4000)
  public void test179() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 0, 1, "\udb25\udf9b\udb5c\udc2b\udb0e\udd10\uda8b\uddcc\ud8e2\udeb4\ud895\ude72\uda5d\ude64\udb82\udd38\udbad\udc59\ud908\ude96\ud97d\udc5b", "\ub6ec\u0a3e", "\ud836\udeb3",
        -5, 16940, 816242341, 242647264395264L, -29378L, true, false, (char) 55058, (char) 13405,
        Double.longBitsToDouble(0x3fd802aa31acd84aL), Double.longBitsToDouble(0x3fe85ce9b4133709L)));
  }
  @Test(timeout = 4000)
  public void test180() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:2874569794624948192 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 5, "\udb12\udebc\udbd3\udd67\ud8c3\udff0", "\u4e81\u7a82\u75f6\u4ae6\ub1b6\u5bdf\ucd9b\u3da0\ub660\u4eaf\u473d", "\udbd7\udd5a",
        55, 93701, 39, 2874569794599748192L, -11582L, true, true, (char) 51287, (char) 56948,
        Double.longBitsToDouble(0x3fa0c32550765a40L), Double.longBitsToDouble(0x3fcab366c03cca48L)));
  }
  @Test(timeout = 4000)
  public void test181() throws Throwable {
    assertEquals("0=java.lang.Long:4840962776752281188 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:4840962776802681188 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 4, 3, 15, "\udbf0\udd26\ud905\ude70", "\u7dc4\u775b\uc6a7\ud391\ub3d8\u531d\ub8c8\u3c71\uad30\ubf99\u0a3e\u60ba\u50ea\u86b3\u8bb7\u00f0\ua552\u7905\u354c\u7d56\ub1df\u8a71\u5dc6\u8f92\u5286\u295d\u376b\u09b4\u2bf0\ub150", "\ud810\udfc4\uda03\uddfa",
        19, 32334, -2099068632, 4840962776777481188L, -43799L, true, false, (char) 36603, (char) 13173,
        Double.longBitsToDouble(0x3fa01c304ec82480L), Double.longBitsToDouble(0x3fe7806903f2f5ecL)));
  }
  @Test(timeout = 4000)
  public void test182() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:4673458778612823560 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 2, "\udaba\udc72", "\u1ca4\u9bb1\u76e2\u0520\ub541\uafae\u53bb\u24f7\ubfcd\u3e2f\u623c\uc2f7\u47b4", "\ud869\uddad",
        55, 86605, 39, 4673458778584023560L, -32962L, true, true, (char) 58108, (char) 60151,
        Double.longBitsToDouble(0x3fd61e58050d391aL), Double.longBitsToDouble(0x3fcf8e29541e45ccL)));
  }
  @Test(timeout = 4000)
  public void test183() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:9085293165513017391 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 2, "\udaba\udc72", "\u1ca4\u9bb1\u5db3\u0520\u92ab\ub3d8\ub1b6\000\u851c\u3dc7\ub660\u1b21\u47b4", "\ud869\uddad",
        55, 86605, 39, 9085293165487817391L, -91285L, true, true, (char) 50524, (char) 12638,
        Double.longBitsToDouble(0x3fe03c5bc2869c8dL), Double.longBitsToDouble(0x3f9a864aa0ecbc00L)));
  }
  @Test(timeout = 4000)
  public void test184() throws Throwable {
    assertEquals("0=java.lang.Long:4873287178274660391 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 3, 8, 5, "\ud83d\udfe0\ud9ca\ude53", "\u9ad7\u4de4", "\udbad\udc59\udafa\udf19\ud9d5\udc14\uacaa\uf835\u276c\udb89\ude93\udaf8\ude7e\udbcd\udf87",
        3, 75672, -358082320, 4873287178245860391L, 15622L, false, true, (char) 34278, (char) 11140,
        Double.longBitsToDouble(0x3fd250bd41949354L), Double.longBitsToDouble(0x3fe78f8a6bc3faedL)));
  }
  @Test(timeout = 4000)
  public void test185() throws Throwable {
    assertEquals("0=java.lang.Long:124554051584 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 1, 2, 0, "\udb72\udcb4", "\000", "",
        23, 6476, -245891072, 124554051584L, -100000L, false, false, (char) 52817, (char) 62564,
        Double.longBitsToDouble(0x3d30000000000000L), Double.longBitsToDouble(0x3eb5c78470000000L)));
  }
  @Test(timeout = 4000)
  public void test186() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:64323627145725312 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 5, "\udb12\udebc\udbd3\udd67\ud8c3\udff0", "\u4e81\u7a82\u75f6\u4ae6\ub1b6\u5bdf\ucd9b\u3da0\ub660\u4eaf\u473d", "\udbd7\udd5a",
        55, 93701, 39, 64323627120525312L, -11582L, true, true, (char) 51287, (char) 56948,
        Double.longBitsToDouble(0x3fa0c32550765a40L), Double.longBitsToDouble(0x3fcab366c03cca48L)));
  }
  @Test(timeout = 4000)
  public void test187() throws Throwable {
    assertEquals("0=java.lang.Long:1499573329328434051 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:1499573329386034051 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 4, 3, 2, "\udbf0\udd26\ud905\ude70", "\u7dc4\u775b\uc6a7\ud391\ub3d8\u531d\ub8c8\u3c71\uad30\ubf99\u0a3e\u60ba\u50ea\u86b3\u8bb7\u00f0\ua552\u7905\u3596\u7d56\ub1df\u8a71\u5dc6\u8f92\u5286\u295d\u18f1\u09b4\u2bf0\u7800", "\ud810\udfc4\uda03\uddfa",
        19, 32334, -2099068632, 1499573329357234051L, -4108L, true, true, (char) 40064, (char) 7988,
        Double.longBitsToDouble(0x3fe7806ce3f2f5ecL), Double.longBitsToDouble(0x3fed02c888e3cd67L)));
  }
  @Test(timeout = 4000)
  public void test188() throws Throwable {
    assertEquals("0=java.lang.Long:4467570830361494716 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:4467570830361494716 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 3, 4, "\ud9f0\udd26\ud905\ude70\uda1f\udf3a\u1d87\ud862\ude00\udb75\udf55\udb7b\udfa0\udb34\ude8a\udbad\udc5f\ua448\ud9e5\udfed\ud99a\udf21\ud8a7\udc1e\ud9fc\udd4c\u1ba7\ud993\udee8\ud95d\udfbf\uda65\udd85", "\u8fe6\u0fc2\u53c7\u704a\u1115\u822b\ud7af\u123a\u6d36\u883f", "\udb59\udf4e\ud949\ude4f",
        59, 22233, 945009200, 4467570830336294716L, 15412L, false, false, (char) 45662, (char) 61878,
        Double.longBitsToDouble(0x3fee0416c2bbd951L), Double.longBitsToDouble(0x3fec4cf543517777L)));
  }
  @Test(timeout = 4000)
  public void test189() throws Throwable {
    assertEquals("0=java.lang.Long:4467570830361494716 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:4467570830361494716 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 3, 4, "\ud9f0\udd26\ud905\ude70\uda1f\udf3a\u1d87\ud862\ude00\udb75\udf55\udb7b\udfa0\udb34\ude8a\udbad\udc5f\ua448\ud9e5\udfed\ud99a\udf21\ud8a7\udc1e\ud9fc\udd4c\u1ba7\ud993\udee8\ud95d\udfbf\uda65\udd85", "\u8fe6\u0fc2\u53c7\u704a\u1115\u822b\ud7af\u123a\u6d36\u883f", "\udb59\udf4e\ud949\ude4f",
        59, 22233, 945009200, 4467570830336294716L, -64668L, false, false, (char) 52509, (char) 3085,
        Double.longBitsToDouble(0x3fec4cf543517777L), Double.longBitsToDouble(0x3fe13a2494c09384L)));
  }
  @Test(timeout = 4000)
  public void test190() throws Throwable {
    assertEquals("0=java.lang.Integer:-28800000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:2768587868827189313 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 10, "\udaba\udc72", "\u1ca4\u0ba7\u5db3\u0551\u75d3\u63b8\ub1b6\uabb1\u664a\u3dc7\ub660\ub3b8\u47b4", "\udbb7\udf25",
        22, 12480, -1358954457, 2768587868798389313L, -91291L, true, false, (char) 13197, (char) 40742,
        Double.longBitsToDouble(0x3fb0736f382c8d80L), Double.longBitsToDouble(0x3fc72b29941d9464L)));
  }
  @Test(timeout = 4000)
  public void test191() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:3381103806425073784 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 5, "\ud981\udead", "\u1ca4\u9bb1\u5db3\u0520\u75f6\ub3d8\ub1b6\u3b00\u0b1d\u3dc7\ub660\u1b21\u47b4", "\uda99\udfe6",
        4, 86605, 39, 3381103806399873784L, -91285L, true, true, (char) 13405, (char) 64398,
        Double.longBitsToDouble(0x3fe03c5bc2869c8dL), Double.longBitsToDouble(0x3f9a864aa0ecbc00L)));
  }
  @Test(timeout = 4000)
  public void test192() throws Throwable {
    assertEquals("0=java.lang.Long:3314649325756153208 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:3314649325806553208 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 4, 3, 5, "\udaba\udc72", "\u1ca4\u9bb1\u5db3\u055f\u0086\u4470\u3e70\u1fe3\uaaa1\u3dc7\ub660\u1b21\u47b4", "\ud869\uddad",
        55, -835, 0, 3314649325781353208L, 48506L, false, true, (char) 7551, (char) 6285,
        Double.longBitsToDouble(0x3feef489ed0765e0L), Double.longBitsToDouble(0x3fe2278282aa07c5L)));
  }
  @Test(timeout = 4000)
  public void test193() throws Throwable {
    assertEquals("0=java.lang.Long:-3465731019480988980 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:-3465731019480988980 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 3, 4, "\ud9f0\udd26\ud905\ude70\uda1f\udf3a\u1d87\ud862\ude00\udb75\udf55\udb7b\udfa0\udb34\ude8a\udbb0\ude97\ua448\ud9e5\udfed\ud99a\udf21\ud8a7\udc1e\ud9fc\udd4c\u1aff\ud993\udee8\ud95d\udfbf\uda65\udd85", "\u8fe6\u710f\u53c7\u704a\u1115\u822b\ud7af\u123a\u6d36\u883f", "\udb59\udf4e\ud949\ude4f",
        59, 22233, 945009200, -3465731019509366980L, -36056L, false, false, (char) 35625, (char) 4578,
        Double.longBitsToDouble(0x3fe22c127abbd951L), Double.longBitsToDouble(0x3febbcf543517777L)));
  }
  @Test(timeout = 4000)
  public void test194() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:2874569798691260384 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 0, 3, 5, "\udb12\udebc\udbd3\udd67\ud8c3\udff0", "\ub5e8\u55ff\ud6f3\u4ae6\ub1b6\u5bdf\ucd9b\u14ac\u8b03\ud6ba\u63f0", "\udbd7\udd5a",
        55, 93620, 39, 2874569798666060384L, 13930L, true, true, (char) 51287, (char) 56948,
        Double.longBitsToDouble(0x3fa0c32550765a40L), Double.longBitsToDouble(0x3fcab366c03cca48L)));
  }
  @Test(timeout = 4000)
  public void test195() throws Throwable {
    assertEquals("0=java.lang.Long:3961760298355356798 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:3961760298355356798 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 3, 4, "\ud9f0\udd26\ud905\ude70\uda1f\udf3a\uda6b\udf01\udb4d\udf41\udb75\udf55\udb55\udd0c\udb34\ude8a\udbad\udc5f", "\u76d3", "\u1ba7\ud993\udee8",
        37, 36589, -1904381971, 3961760298326556798L, 71619L, true, false, (char) 32699, (char) 26139,
        Double.longBitsToDouble(0x3fdd3868c1d52f1cL), Double.longBitsToDouble(0x3fe1c3cad426e093L)));
  }
  @Test(timeout = 4000)
  public void test196() throws Throwable {
    assertEquals("0=java.lang.Long:8991718131031868545 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\0121=java.lang.Long:8991718131031868545 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 2, 3, 3, 4, "\ud9f0\udd26\ud905\ude70\uda1f\udf3a\u1d87\ud862\ude00\udb75\udf55\udb7b\udfa0\udb34\ude8a\udbad\udc5f\ua448\ud9e5\udfed\ud99a\udf21\ud8a7\udc1e\ud9fc\udd4c\u1ba7\ud993\udee8\ud95d\udfbf\ud856\udc8d", "\u8fe6\u0fc2\u53c7\u704a\u1115\u822b\ud7af\u123a\u6d36\u883f", "\udb59\udf4e\ud8cd\ude71",
        -1, 59440, 945009200, 8991718131006668545L, -64668L, false, false, (char) 31773, (char) 3085,
        Double.longBitsToDouble(0x3fec4cf543517777L), Double.longBitsToDouble(0x3fe13a2494c09384L)));
  }
  @Test(timeout = 4000)
  public void test197() throws Throwable {
    assertEquals("0=java.lang.Integer:-25200000 |this=org.joda.time.tz.CachedDateTimeZone:America/Los_Angeles\012",
        Z.run(T, 1, 0, 2, 5, "\ud9f0\udd26\ud905\ude70\ud896\udcf0\udb76\udd85\udab6\udced\ud895\ude21\000\ud884\udca2\udb21\udec6\ua448\ud9e5\udf01\ud99a\ude37\uda1d\udc19\uda15\udd4d\ud8ad\udf42", "s\000", "\ud940\udcc0",
        26, 22426, 225033927, 9064184445811053986L, 34107L, false, true, (char) 14861, (char) 44345,
        Double.longBitsToDouble(0x3feb2d0317836356L), Double.longBitsToDouble(0x3fe0f471cbce1a4eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.DateTimeZone|getOffsetFromLocal|long|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|adjustOffset|long,boolean|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|convertLocalToUTC|long,boolean|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|convertLocalToUTC|long,boolean,long|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|convertUTCToLocal|long|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|equals|java.lang.Object|fac:org.joda.time.DateTimeZone:getDefault:",
    "M|org.joda.time.DateTimeZone|fixedOffsetZone|java.lang.String,int|static",
    "M|org.joda.time.DateTimeZone|forID|java.lang.String|static",
    "M|org.joda.time.DateTimeZone|forOffsetHours|int|static",
    "M|org.joda.time.DateTimeZone|forOffsetHoursMinutes|int,int|static",
    "M|org.joda.time.DateTimeZone|forOffsetMillis|int|static",
    "M|org.joda.time.DateTimeZone|forTimeZone|java.util.TimeZone|static",
    "M|org.joda.time.DateTimeZone|getAvailableIDs||static",
    "M|org.joda.time.DateTimeZone|getConvertedId|java.lang.String|static",
    "M|org.joda.time.DateTimeZone|getDefault||static",
    "M|org.joda.time.DateTimeZone|getDefaultNameProvider||static",
    "M|org.joda.time.DateTimeZone|getOffsetFromLocal|long|fac:org.joda.time.DateTimeZone:getDefault:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
