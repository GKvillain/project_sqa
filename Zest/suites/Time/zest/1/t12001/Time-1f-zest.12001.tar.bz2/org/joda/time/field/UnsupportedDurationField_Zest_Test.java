package org.joda.time.field;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnsupportedDurationField_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 24, 6, 22, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\uf61a\udb83\udebe\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u5ca8\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\u2a38\u09d4", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 8315, -1466408150, 4106613920387493528L, -88324L, false, true, (char) 35119, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fedf66246c2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 24, 6, 22, "\uda67\udc80\ud9be\udde3\uda05\udd7a\ud9f3\udff5\uda2e\ude0c\udbc9\udd3d\udbb1\udcc2\udab3\uddb1\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\ud987\udcf2\ud8fb\udd2b\uda12\udc9b\ud84c\udf48\udb3f\ude6e\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\uf61a\udb85\udebf\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u054b", "\uda6f\udcef\ud940\udfdf\udbc8\udce8\udaf3\udfd8\udbed\udcb6\uda61\uddca\ud8a9\udef0\ud970\udff1",
        41, 16634, -642882348, -3553007970419121121L, 40505L, false, false, (char) 24953, (char) 60543,
        Double.longBitsToDouble(0x3fe9558e5f9aa898L), Double.longBitsToDouble(0x3fe4c1c7ee9f525eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 2, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\ud961\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\ud9d8\ude1b\ud812\udc0d\ud826\udeef\ud84c\udf48\ud885\udf0e\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\ud9a2\udc45\udb42\udf58\ud846\ude5d\udba1\udf22\ud924\udde2\ud9a8\udf33\udb67\uddf5\ud0fb\ud9f0\udce6\udb20\uddc9\u4da3\ud82d\udfc6\ud9e4\udebc\ud926\udc1a\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ud79c\u4f5a", "\ud8ad\uddd1\udbed\udceb\uda61\uddca\ud8a9\udef0",
        48, 4230, 1307829702, -2761158660662940141L, -13574L, false, false, (char) 60543, (char) 5366,
        Double.longBitsToDouble(0x3fecd0de3e960ffdL), Double.longBitsToDouble(0x3fe4fa92f59c07adL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 6, 22, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\ud906\udd93\uda80\udd50\ud8d6\udcfe\udac2\udd13\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9f1\udfce\ud8cd\udd33\uf61a\udb83\udebe\uda2f\udc12\udba6\udeaf\ud924\udde2\ud873\udf6d\udb26\uddd5\udb2a\udc71\ud9f0\udd07\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u52da\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\uad2e\ua434", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 30411, -2057891815, 4106617004174012056L, -88324L, false, false, (char) 28719, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fedf66246c2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 24, 6, 18, "\udbc6\udd8b\ud8c2\udf5d\ud952\udf51\uda06\udce1\ud849\udf97\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda48\ude03\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\ud820\udd21\ud93c\udc8c\u00cf\ud938\udd14\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\udb2e\udc1b\ud8d5\ude29\uf61a\ud882\udf5f\ub2ab\udba1\udea9\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u19db\u9f33\ucd61\u5ca8\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\u2a38\u09d4", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        19, 30627, -828543695, 4106614117955989144L, -88324L, false, true, (char) 35119, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fcaf9891b0b22fcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]] |a2=[I:[[44001, 40849, 43963, 48746, 43224, 51101, 35891, 7289]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 8, 16, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48", "\uac11\u9fc1\uabeb\ube9a\ua908\uc7cd\u8c63\u1ca9\ub413\u8cf0\u2a99\u95f6\u8120\u6459\u8488\u5ef9\u0be4\u788b\ub684\u0ca1\u2abe\u9f33\ucd61\u5ca8\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\u2a38\u09d4\uab0d\u7f69\u4ba2\u0b47\u45d0\ua574\u8639\u2a0b\u343a\u3b92\u9b25", "\uda0c\ude3c\ud91d\udcb9\uda42\ude70\ud8b9\udccb\udb0a\udebe\udb12\udf33\ud9a9\udc7c\ud96a\udeb6\ud876\udf9a",
        11, 77009, 581584786, -4415611899653084684L, 50083L, false, false, (char) 31935, (char) 44590,
        Double.longBitsToDouble(0x3fe9cdacff6f8e73L), Double.longBitsToDouble(0x3f866119f0545e80L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 13, 8, 22, "\ud8ef\udc44\uda78\udf8f\ud93f\uddab\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud816\udebf\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud854\udc12\ud9d2\udfce\ud8cd\udd33\uf61a\ud84f\udc05\ud85a\uddfa\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb7a\udfe8", "\u2abe\u9f33\ucd61\u9112\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\u2a38\u09d4\uab0d\u7f69\u4ba2\u0b47\u05e8\ua574\u8639\u2a0b\u343a\u3b92\u9b25\u5038\u0fb8\u79c6\u8d02\u4cc1\u5f94\u6cb1", "\uda04\udf98",
        34, 3379, -1671864062, 2927681896765709125L, 78437L, false, true, (char) 17838, (char) 1781,
        Double.longBitsToDouble(0x3fc7437644834d0cL), Double.longBitsToDouble(0x3fea3a870eb53b6dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 22, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9d2\udfce\ud9ec\udc9c\udacc\udcc7\uda84\uded8\u0e47\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u5ca8\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\u2a38\u09d4", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 8315, -1466408150, 4106613921108913816L, -88324L, false, true, (char) 35119, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fedf66246d066bfL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null]] |a2=[I:[[10894, 40707, 52529, 23672, 36251, 18483, 25054, 21690]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 17, 5, 6, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\ud9ab\udef3\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\ud864\udd74\ud96a\udfa2\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\ud93a\udf49\ud859\udc34\ud9d2\udfa0\ud8cd\udd33\uf6b0\udb83\udebe\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\udab9\udc0c\u4d97\ud962\udca7\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u5ca8\u8dcb\u4863\u620e\u54ea\u675c\u1e97\u2a38\u09d4", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 8315, -1466408150, 4106613920387493528L, -88324L, false, true, (char) 35119, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fedf66246c2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 14, 9, 15, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\uf61a\udb83\udebe\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\udb28\udd3c\ud86b\udcec\udb2d\udfb3", "\u2abe\u9f33\ucd61\u5ca8\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\u2a38\ube92", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 8315, -1466408150, 4106613920387493528L, -88324L, false, true, (char) 35119, (char) 46539,
        Double.longBitsToDouble(0x3febdd3116401486L), Double.longBitsToDouble(0x3fedf66246c2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\012",
        Z.run(T, 1, 23, 0, 22, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud947\udc30\udbbe\udc00\uda2d\udedf\udbf9\ude94\uda80\udd50\ud8d6\udcfe\udb9c\udfc5\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\ud9db\udf9d\ud811\udf94\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud98b\udf2a\ud833\udcdb\uda4f\udf21\udb83\udf5c\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud8f9\udd2d\ud87f\udec7\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u5ca8\u20ec\u705b\u502c\u08dc\u937d\uc92b\u890b\u09d4", "\ud83c\udf2b",
        52, 76777, -873342169, -1956059336311276386L, 92152L, true, false, (char) 13641, (char) 2617,
        Double.longBitsToDouble(0x3fecf8ac821773b4L), Double.longBitsToDouble(0x3febdd311640f386L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 5, 18, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud80d\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9d2\udfce\ud989\udd51\ud8a9\udf4b\udb83\udebe\ud9c8\udd3e\u7321\ud924\ude78\ud885\ude03\ud896\uddcd\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud877\ude03\ud86c\uddea\udb2d\udfb3", "\u2abe\u9f33\ucd61\u5ca8\uadff\u705b\u71ac\u6713\u63e2\u1e97\u2a38\u09d4", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud8a1\udcc0",
        -2, 8315, -1466408150, 4106613920387493528L, -70401L, true, false, (char) 45469, (char) 41414,
        Double.longBitsToDouble(0x3fedf66245efc8bfL), Double.longBitsToDouble(0x3fe26bb8631ff865L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 9, 22, "\ud8ef\udc44\ud8c5\uddb7\ud92f\udec0\uda06\udcd2\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udb99\udf71\ud93c\udc83\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9d2\udfce\ud921\ude9d\ud804\ude2d\udb83\udebe\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u5ca8\u8dcb\u705b\u71ac\u6713\u63e2\u0b1c\u2a38\u7ad0", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc\ud81e\udc1d\ud857\udc4f\ud94b\ude03\udb20\udef5\udab2\udf72\udac4\udf5c\udb4a\udea2\ud801\udfef\uda58\udca6\ud8b9\udccb\udbfe\udc57",
        0, 15270, -1455552830, -5021176001796414274L, -76995L, true, true, (char) 22531, (char) 62854,
        Double.longBitsToDouble(0x3feb4dfe374cd95cL), Double.longBitsToDouble(0x3fdaad43348dd21aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 10, 1, 22, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\uf61a\udb83\udebe\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud9b1\udd29\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u5ca8\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\u2a38\u09d4", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 94744, -1466408150, 4106613920387493528L, -88324L, false, true, (char) 35119, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fedf66246c2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 24, 3, 22, "\ud90d\udf46", "\u7c2f\u0ad0\u2616\ua6db\u48f0\u641f\ubc2a\u02de\u8589\u1f93\uca0d\u51dd\u495f\u88f8\u0d7a\u5af8\u969e\u5deb\uac11\u9fc1\uabeb\ube9a\ua908\uc7cd\u8c63", "\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\udb46\udf32\udad9\ude49\ud8f8\udc6c\ud982\udf91\u7a81\ud92c\uddae\ud965\udf5d\udb29\uddb8\udb99\udcbb\ud973\udc10\ud896\udf02\udb75\udc0c\uda61\uddca\ud8a9\udef0\ud970\udff1\udb7a\ude17",
        39, 82652, -827249133, 6271654039189209889L, -13574L, false, false, (char) 60543, (char) 5366,
        Double.longBitsToDouble(0x3fecd544c69838fdL), Double.longBitsToDouble(0x3fe4fa92f59c07adL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 6, 15, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\ud8db\uddcc\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\uf61a\udb83\udebe\uda37\udedc\udb6c\uddcd\ud924\uddfb\ud885\ude03\udb26\uddd5\ud176\ud923\udda1\udac9\udfd2\uda9d\ude16\uda4b\udc3a\udafc\udc0e\udbbd\udf7b\ud86c\ude3f\udb2d\udfb3", "\u2abe\u7191\ucdab\u6662\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\u2a38\u09d4", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 8134, -1466408150, 4106613920387493528L, -88324L, false, true, (char) 35119, (char) 46539,
        Double.longBitsToDouble(0x3fe5fd311040f3ffL), Double.longBitsToDouble(0x3fedf496aec2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=new org.joda.time.Partial:[]\012",
        Z.run(T, 2, 16, 23, 22, "\ud8dc\udfa4\ud8c1\udda5\ud952\udf51\uda06\udce1\udb4a\udf07\udaf7\udd7b\udb64\udefb\udbe2\udd94\uda5b\uddb0\udb86\uddd7\uda02\udf5f\udbf0\uddaa\u3c40\udb48\udffc\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\uda4c\udc17\udb59\udcb7\ud88a\udd0b\udb26\uddfc\ud8cd\udd33\uf61a\ud899\udd95\ud834\ude00\udba1\udf22\udb01\uddb1\ud885\ude03\udb26\uddda\udbb9\ude39\ud9f0\udcf6\ud8f9\udd2d\u4d66\uda58\udca3\udbfa\udff0\ud8df\udc86\ud86c\ude7d\udb2d\udfb3", "\u6485\uc98a\ucd61\u33a7\u8dcb\u705b\u76ac\u6713\u63e2\u1e97\u7dc6\u5379", "\ud83c\udf2b\ud81e\udd40\ud8eb\udd2d\ud8e1\udd1a\uda24\udc31\ud81e\udc04",
        55, 9850, 956145562, 5935443695652118175L, 47991L, true, true, (char) 41414, (char) 31750,
        Double.longBitsToDouble(0x3fe61645fae46c82L), Double.longBitsToDouble(0x3fe67dabd61b8326L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 11, 10, 2, "\uda67\udc80\ud9be\udde3\uda05\udd7a\ud9f3\udff5\uda2e\ude0c\uda68\udc6c\udbb1\udcc2\udab3\uddb1\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\uded9\ud93c\udc8c\ud987\udcf2\ud8fb\udd2b\uda12\udc9b\ud84c\udf48\udb3f\ude6e\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\uf61a\udb85\udebf\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\uda1b\udee6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u054b", "\uda6f\udcef\ud940\udfdf\udbc8\udce8\udaf3\udfd8\udbed\udcb6\uda61\uddca\ud8a9\udef0\ud970\udff1",
        41, 16634, -642882348, 1583065929620218911L, 40506L, false, false, (char) 24953, (char) 60543,
        Double.longBitsToDouble(0x3fe9558e5f9aa898L), Double.longBitsToDouble(0x3fe4c1c7ee9f525eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 2, "\udb98\udc18", "\u7c2f\u96d0\ube0d\ua6db\u5ab8\u63e5\ubc2a\u02de\u9fe3\u0444\u8dbc\u51dd\ud299\u88f8\u22d3\u1d57", "\ud9d2\udfce\udb38\udf08\ud960\udf91\udb42\udf58\ud846\ude5d\ud869\udf26\ud924\udde2\ud9a8\udf33\udb67\uddf5\ud0fb\ud9f0\udce6\udb20\uddc9\u4da3\ud82d\udfc6\ud9e4\udebc\ud926\udc44\ud86c\uddf2\udb2d\udfb3\udbad\udc49\uda9c\udf99\udb9a\uddd6\uda30\ude96\ud2b0\uda72\ude7f\udb99\udc6a\u426a\u42db\udbed\udceb\uda61\uddca\ud8a9\udef0\ud970\udff1\udb0d\udfe0\uaa5e",
        17, 40867, 1460233247, -5164603229766296793L, -59850L, false, true, (char) 65170, (char) 28925,
        Double.longBitsToDouble(0x3fd9c07ade13b0acL), Double.longBitsToDouble(0x3fe2c1082f28cb4cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 2, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\udaef\udfd5\ud849\udf49\ud961\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\ud9d8\ude1b\ud812\udc0d\000\ud84c\udf48\ud885\udf0e\ud88c\udf8e\ud9d2\udfce\ud87e\udc2f\ud9a2\udc45\udb33\udd58\ud846\ude5d\udba1\udf22\ud924\udde2\ud9a8\udf33\udb67\uddf5\ud0fb\ud9f0\udce6\udb20\uddc9\u4da3\ud82d\udfc6\ud9e4\udebc\ud926\udc1a\ud86c\uddf2\udb2d\udfb3", "\u2abe", "\uda72\ude7f\udb99\udc6a\ud901\udd88\u68a9\000\000\ud8a9\udef0\ud970\udff1",
        15, 80702, -642882348, -3553007970419121121L, 40505L, false, false, (char) 58586, (char) 14571,
        Double.longBitsToDouble(0x3fe9558e5f9a1bc7L), Double.longBitsToDouble(0x3fe4b07fe89f525eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 19, 6, 18, "", "\000", "\ud961\udcd9\uda2d\udedf\udbe2\udd94\uf3ae\ud8d3\udf48\udb76\udd0d\ud88c\udf21",
        17, -1000, 0, 0L, -100000L, true, false, (char) 7310, (char) 65042,
        Double.longBitsToDouble(0x3ecb400000000000L), Double.longBitsToDouble(0x3fe6000000694e01L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=java.lang.Integer:0 |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 9, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\ua7d3\uc139\ud961\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\udac4\udd9c\u3c18\udab8\udda8\ud93c\udc8c\ud9d8\ude1b\ud812\udc0d\ud826\udeef\ud84c\udf48\ud885\udf0e\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\ud9a2\udc45\udb42\udf58\ud8e9\udd5c\udba1\udf22\ud924\udde2\ud9a8\udf33\ud8df\ude4e\ud0fb\ud9f0\udce6\udb20\uddc9\u4da3\ud82d\udfc6\ud9e4\udebc\uda9e\udc16a\ud887\udec3", "\u2abe\u9f33\ud79c\u5676", "\ud8ad\uddd1\udbed\udceb\uda61\uddca",
        11, 50103, 206, 0L, 70977L, false, false, (char) 37754, (char) 241,
        Double.longBitsToDouble(0x3fc3dc8003aece50L), Double.longBitsToDouble(0x3fe9558e5f9a1bc7L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 17, 3, 15, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\ud94d\udde6\uda2d\udedf\udbe2\udd94\ud8e7\udf04\ud8d6\udc6b\udb76\udd0d\ud88c\udf21\u3c40\udae4\udc4c\ud93c\udc8c\ud9d8\ude1b\ud812\udc0d\ud826\udeef\ud84c\udf48\ud885\udf0e\ud88c\udf24\ud9d2\udfce\ud8cd\udd33\ud9a2\udc45\udb42\udf58\ud846\ude5d\udba1\udf22\ud924\udde2\ud9a8\udf33\udb67\uddf5\ud0fb\ud9f0\udce6\udb20\uddc9\ud924\udc6a\ud82d\udfc6\ud9e4\udebc\ud926\udc1a\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ud79c\u4f5a", "\ud8ad\uddd1",
        37, 65665, 1121389283, 1242817393471566213L, 55260L, true, false, (char) 55248, (char) 64450,
        Double.longBitsToDouble(0x3fe93dc29e66cbf1L), Double.longBitsToDouble(0x3fc3dc9b43aece50L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 6, 2, "\udb51\uddc4\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb2d\udf79\uda18\udfbb\udbe2\udd94\ud931\udf3f\udb12\udda0\udb95\udd05\ud88c\udf21\u3c40\udb3d\udd4b\ud8e0\udeff\ud9ca\ude92\ud812\udc0d\ud826\udeef\ud84c\udf48\ud885\udf0e\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\ud9a2\udc45\udb42\udf58\ud846\ude5d\udba1\udf22\ud924\udde2\ud85d\ude91\udb3b\udfff\ud9de\udf3f\ud9f0\udce6\udb20\uddc9\u4da3\ud82d\udfc6\ud9e4\udebc\ud926\udc1a\ud86c\uddf2\udb2d\udfb3", "\u7769\u892e\u6eb8\ubaef", "\udb00\udf55\ud9d8\ude45\uda3d\udc53",
        11, 50103, -263806770, 5617085798184543444L, 8024L, false, false, (char) 43642, (char) 22519,
        Double.longBitsToDouble(0x3fc3dc9b5b31f810L), Double.longBitsToDouble(0x3fe95338379a1bc7L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 20, 6, 2, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\ud961\uddd3E\000\000\u09b6\000\ud9c8\udd84\u3c40\udab8\udda8\ud93c\udc8c\u9d03\ud811\udf30\uda06\udddf\ud84c\udf27\ud885\udf0e\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\000\udb42\udf58\udb5d\udd69\udad2\ude88\ud924\udde2\ud9a8\udf33\udb67\uddf5\010\ud9f0\udcb1\u0091\000\000\uda59\ude36\ud926\udc1a\ud866\udd6e\udb13\udec9", "\u2abe\u9f33\ud79c\u4f5a", "\u68a9\udbd6\udf0a\ud9d5\uddc4",
        11, -1000, -263806770, 5548687379486736596L, -34464L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fc3dc9b43aece50L), Double.longBitsToDouble(0x3fe9558e5f9a1bc7L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 0, 11, 2, "\ud8ef\udc44\ud8c1\udda5\ud832\ude08\uda06\udce1\ud849\udf49\ud961\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\u573d\ud88c\ude8d\u3c40\udafa\udeb6\ud93c\udc8c\ud9d8\ude1b\ud812\udc0d\uc9d6\000\ud85d\ude0e\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\ud9a2\udc45\udb42\udf58\ud846\ude5d\udba1\udf22\ud924\udde2\ud9a8\udf33\udb67\uddf5\ud0fb\ud9f0\udce6\udb20\uddc9\u4da3\ud82d\udfc6\ud9e4\udebc\ud926\udc1a\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ud79c\u4f5a", "\ud8ad\uddd1\udbed\udceb\uda61\uddca\ud8a9\udef0",
        48, 4230, 1307829702, -2761158660662940141L, -13574L, false, false, (char) 60543, (char) 5366,
        Double.longBitsToDouble(0x3fecd0de3e960ffdL), Double.longBitsToDouble(0x3fe4fa92f59c07adL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 1, 6, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\ud961\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\udafd\udc92\udb76\udd3a\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\ud9d8\ude1b\ud812\udc0d\ud826\udeef\ud84c\udf48\ud813\udebd\ud88c\udf39\ud9e0\udfce\ud8cd\udd33\ud9a2\udc45\udb42\udf58\ud846\ude5d\udba1\udf22\ud924\udde2\ud9a8\udf33\uda9d\uddf0\ud0fb\ud9f0\udce6\udb20\uddc9\u4da3\ud82d\udfc6\ud9e4\udebc\ud8be\udca9\ud86c\ude2f", "\u0d4e\u2abe\u9f33\ud79c\u4f5a\u8dcb\u966a\u6860\u6713\u63e2\u1e97q\u1626\uba29\u7f69\u4ba2\u0b47\u57c7\ua574", "\ud857\udc4f\ud821\udccd\ud8cc\udc8b",
        -1, 10079, 1439706524, 5041600320542306776L, -76558L, true, true, (char) 9485, (char) 64099,
        Double.longBitsToDouble(0x3fe7cd11cf3757a0L), Double.longBitsToDouble(0x3fe631d689b49e16L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 12, 10, 22, "\udab6\udfc2\udac3\udf5d\ud96a\ude7f\uda06\udce1\ud8f6\uded7\udb95\udf67\uda2d\udedf\udbe2\udd94\ud93a\udd4d\udb70\ude2a\udbcf\ude37\udaa4\udf63\udaab\udd90\udbde\udf5f\ud93c\udc8c\udb38\uddbd\ud812\udc0d\ud826\udeb8\ud84c\udf48\ud93a\udefb\ud972\udd88\ud932\udda3\ud8cd\udd33\ud9a2\udc45\uda8b\udebd\uf600\udba1\udf7b\ud92d\udf03\ud9a8\udeb5\ud839\udc6d\udac2\udd07\ud9f0\udce6\ud942\udd1b\u4da3\udbd6\udc3a\ud82d\udcb9\ud8a0\udc62\udbc7\udedd\udb2d\udfb3", "\ubb9b\u9f33\ud79c\u5001\u8dcb\u966a\u12ef\ua4fa\u075a\u7017\ud485\u8703\uba29\u7f69\u4ba2\u0b47\u098f\u51b4\u61ca\ub653\u7860\u6416\u86f9", "\ud92d\udd4c\uda12\udcd3\uda5f\udec6\ud94f\uddfa\ud937\udcc9\udb3f\udeeb\ud895\udec4\udb9f\udd0c\ud914\udeb0",
        36, 87097, 1908763198, -2326266171848836332L, 9047L, true, true, (char) 49817, (char) 39399,
        Double.longBitsToDouble(0x3fef9014bcf775ddL), Double.longBitsToDouble(0x3fe4d147aceda6efL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 15, 2, "\ud8ef\udc7b\ud99d\udfd3\udb41\udc0e\uda06\udce1\ud849\udf49\ud938\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udafd\ude30\ud88c\udf2f\udb83\udc39\udb06\udcba\ud93c\udc8c\u7fc0\uda91\uddb3\udb85\udd11\ud84c\udf48\ud885\udf0e\ud88c\udf8e\ud9d2\udfce\uda8d\uded4\ud9a2\udc45\udb42\udf58\ud838\udf6a\uda23\uddc2\ud924\ude13\ud9a8\udf33\udb67\uddf5\ud88b\udc25\ud9f0\udce6\udb09\uddac\ud9a3\udc28\ud89b\udc2a\ud9e4\udf68\ud9f2\udc20\ud86c\uddf2\udb2d\udfb3", "\u6edb\u599b\ud79c\u4f5a\u8dcb\u966a\u6860\u6713\u63e2\u11da\ua68a\u7dab\uba29\u7f69\u4ba2\u0b47\u61ad\u4ce4\u11a0\u6f37\u3380\u6416\uaa8d\u5036\u0fb8\u0377\u9bda\ud0c5\u193b\u674a\u4b48\u983f\u29c1", "\ud82a\udd57\ud85e\uddad\udaad\udf21\udad2\udfe4\ud921\udd8e\ud8fc\ude3d\ud97f\udc04\ud9c5\udd3b\ud968\udeda",
        50, 86658, -1404487313, 5904234965388766139L, -52746L, false, true, (char) 57349, (char) 63027,
        Double.longBitsToDouble(0x3fee47cfd8694b1bL), Double.longBitsToDouble(0x3fdaef0af99eec60L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 20, 6, 4, "\udbd8\udca8\ud8c1\udda5\ud93c\udead\uda06\udce1\udb2d\udc16\ud950\udd59\udbe9\udd9e\u6da8\uda80\udd50\uda7f\udc2d\ud885\udc94\ud959\udf27\udae0\udfc4\udb1a\udd29\ud93b\udffd\ud9d8\ude1b\ud812\udc0d\ud826\udeef\udaff\uddc1\udb71\udd5d\ud90e\udfce\uc52c\uda1b\udfdb\ud9eb\udc69\ud9e7\udcba", "\uceef\u033a\u9f8f\u7720\u8361", "\udb02\udc90\uda19\udd8f\udaa8\udf60\udbc0\udf93\udb2d\udfb3\udbad\udc49\udab7\udc99\udbbc\udc86\uda97\ude8a\u7d6f\uda67\udd7f\udb93\udeb6\ud901\udd88\ud9d1\udf5c\udbed\udc4c\uda61\uddca\ud8a9\udef0\ud970\udff1\ud9fd\udce1\uaa5e\udb94\ude91\ud83c\udf2b\ud80b\udd40\udaa7\udfbc\ud9cb\uddcc\udabb\udec6\ud8e5\udeb9",
        58, 16941, 691224660, 5935443472313818783L, 55485L, true, true, (char) 41657, (char) 4245,
        Double.longBitsToDouble(0x3fe848f3a46b7886L), Double.longBitsToDouble(0x3fe2d3e2f49171a1L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]] |a2=[I:[[42667, 18624, 25583, 48122, 686, 40883, 20756, 36236]]\0121=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null, null, null]] |a2=[I:[[42667, 18624, 25583, 48122, 686, 40883, 20756, 36236]]\012",
        Z.run(T, 2, 17, 17, 0, "\ud922\ude06\ud8c1\udda5\ud952\udf51\uda06\udce1", "\ua6db\u48f0\u641f\ubc2a\u02de\u9fe3\u5144\u8dbc\u51dd\u4be4", "\ud82b\ude48\udb2a\udcc1\ud99e\ude98\ud9d2\udfce",
        -5, 52813, 1308704448, 6056898845962658199L, -77633L, true, true, (char) 41215, (char) 28473,
        Double.longBitsToDouble(0x3fd914fa44ee0786L), Double.longBitsToDouble(0x3feb5d70962a5a80L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 10, 17, 2, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\u9cd7\ud961\uddd3\ud88a\udc43\udbea\ude76\uda80\udd50\ud8d6\udcfe\udaea\udf34\ud88e\udc14\u3c40\udafa\udeb6\ud93c\udc8c\ud9d8\ude1b\ud812\udc0d\ud826\udeef\ud84c\udf48\ud885\udf0e\ud88c\udf8e\ud9d2\udfce\ud845\udd35\ud9a2\udc45\udb42\udf58\ud846\ude5d\udba1\udf22\ud924\udde2\ud9a8\udf33\udb67\uddf5\ud0fb\ud9f0\udce6\udb20\uddc9\u4da3\ud82d\udfc6\ud9e4\udebc\ud926\udc1a\ud982\uddbc\udb2d\udf3a", "\u2262\u9f33\ud79c\u4f5a", "\ud8ad\uddd1\udbed\udceb\uda9e\ude09\udbc7\uddd7",
        3, 21886, -51124794, -2809396765509210605L, -75622L, false, false, (char) 16521, (char) 24953,
        Double.longBitsToDouble(0x3fcd76728eed2c44L), Double.longBitsToDouble(0x3fecd0de3e960ffdL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=new org.joda.time.Partial:[]\012",
        Z.run(T, 2, 7, 2, 16, "\udaf9\udd46\ud8e8\udc10\ud952\udebb\uda06\udce1\ud849\udf49\ud961\uddd3\uda2d\udedf\udb5e\ude29\udac9\udff1\udb93\udc93\udb8d\udf8c\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\udaa1\udeff\udbae\uddd3\ud82a\udc73\ud84c\udf48\ud885\udf0e\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\ud9a3\udffe\udb42\udf58\ud846\ude5d\udba1\udf22\ud86d\udf2f\ud9a8\udecf\udb6f\ude8c\ud0fb\ud9f0\udce6\udb20\uddc9\u4da3\ud82d\udfc6\ud9e4\udebc\ud926\udc1a\ud86c\uddf2\udb2d\udfb3", "\u2ad5\u9f33\ud79c\u4f5a", "\udbc0\udebc",
        30, 65758, -839370269, 1425225209753280718L, 56884L, true, false, (char) 13009, (char) 64450,
        Double.longBitsToDouble(0x3fe93dc29e66cbf1L), Double.longBitsToDouble(0x3fc3dc9b43aece50L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 12, 11, 22, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\ud906\udd93\uda80\udd50\ud8d6\udcfe\udac2\udd13\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9f1\udfce\ud8cd\udd33\uf61a\udb83\udebe\uda2f\udc12\udba6\udeaf\ud924\udde2\ud873\udf6d\udb26\uddd5\udb2a\udc71\ud9f0\udd07\ud8f9\udd2d\u4d66\udaa7\udeff\uda71\udf2e\ud925\udf93\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u52da\u5aa4\u705b\u71ac\u6713\u63e2\u1e97\uad2e\ua434", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 30411, -2057891815, 4106617004174012056L, -88324L, false, false, (char) 28719, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fedf66246c2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 4, 17, "\udb7c\udd61\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\ud906\udd93\uda80\udd50\ud8d6\udcfe\udac2\udd13\uda80\udf1b\u3c40\udafa\udeb3\u12f2\udbf5\udc72\ud812\udc0d\uda12\udc9b\udb91\udd2a\ud8a3\udfd2\ud88c\udf8e\ud9f1\udfe0\ud8cd\udd33\uf61a\udb83\udebe\uda2f\udc12\udba6\udeaf\ud888\udfd4\ud939\udcc8\udb26\uddd5\udb2a\udc71\ud9f0\udd07\ud8f9\udd2d\u4d66\ud88b\ude58\udb41\udfaf\ud925\udffa\udafb\udff8\udb32\uddb3", "\u2abe\u9f33\ucd61\u52da\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\uad2e\ua990", "\ud83c\udf2b\ud81e\udd40\ud957\uddc4\uda7d\ude7c\ud9b9\udccc",
        -2, 30309, -1688921343, 4106617536749956760L, -88324L, false, false, (char) 28719, (char) 46539,
        Double.longBitsToDouble(0x3febdd3115cae386L), Double.longBitsToDouble(0x3fedf660dec2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 12, 13, 14, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udadc\udcd2\uda2d\udedf", "\ubc2a\u4b53\u9fe3", "\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9f1\udfce\ud8cd\udd33\uf61a\udb83\udebe\uda2f\udc12\udba6\udeaf\ud924\udde2\ud873\udf6d\udb26\uddd5\udb2a\udc71\ud9f0\udd07\ud8f9\udd2d\u4d66\uda58\udca3",
        28, 86933, -2116081311, -1481568923729975847L, 78388L, false, true, (char) 44462, (char) 38912,
        Double.longBitsToDouble(0x3fc2807226e10498L), Double.longBitsToDouble(0x3fdf06ad93c2af0cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 12, 14, 22, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\ud90c\udd24\ud849\udf49\udb21\uddd3\uda2d\udedf\ud906\udd93\uda80\udd50\ud8d6\udcfe\udac2\udd13\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\ud84a\ude75\udb94\udeb2\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9f1\udfce\ud8cd\udd33\uf61a\udb83\udebe\uda2f\udc12\udba6\udeaf\ud924\udde2\ud873\udf6d\ud98d\udf89\udb2a\udc94\ud9f0\udd07\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u52da\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\uad2e\ua434", "\ud86c\ude47\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 30411, -2057891815, 4106617004174012056L, -88324L, false, false, (char) 28719, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fedf6624624c8bfL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 4, 10, "\ud8ef\udc44\ud803\udda6\ud967\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\ud906\udd93\udb59\udd5d\udb13\udcb1\udac2\udd13\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\ud8d2\uddda\ud811\udffd\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9f1\udfce\ud8cd\udd33\uf61a\udb83\udebe\uda2f\udc12\udba6\udeaf\ud924\udde2\ud873\udf6d\udb26\uddd5\udb2a\udc71\udbc9\udfe9\udb1e\udc34\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u52da\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\uad2e\ua434", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 30411, -2057891815, 4106617004174012056L, -88324L, false, false, (char) 28719, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fedf66246c2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=new org.joda.time.Partial:[]\012",
        Z.run(T, 2, 2, 18, 16, "\ud8ef\udc44\ud8bf\udea5", "\u96d0\u2616\ua6db\u48f0\u641f\u5576\u02de\u9fe3\u0444\u79e3\u297c\u495f\u88f8\u0d7a\u2de3\ub2f7\u5deb\uac11\u9fc1\uabeb\u8c87", "\ud924\udde2",
        57, 82204, 1124349315, 5738760429665088255L, 40141L, true, true, (char) 60105, (char) 55113,
        Double.longBitsToDouble(0x3fbd7416c07bb938L), Double.longBitsToDouble(0x3fdbe24516e8a474L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\012",
        Z.run(T, 1, 2, 0, 22, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\ud9e3\udfcb\udb2c\udd83\uda4c\udd8a\ud8bc\udd3f\udb2c\udeac\uda80\udd50\ud8d6\udcfe\udb9c\udfc5\ud88c\udf21\u3c40\uda09\udebc\ud91d\udd74\ud94f\udc98\ud8c3\udf56\uda3d\udfcf\ud84c\udf48\uda07\udf0f\ud932\udc41\udb46\udf23\ud833\udcdb\uda4f\udf21\ud90c\udfec\ud93e\ude25\udbba\udf83\ud911\udc98\uda82\udd97\udaeb\udedd\ud176\ud9f0\udce6\ud8f9\udd2d\ud8d3\uddd1\ud9e0\udeb8\udb09\udd9e\ud925\udffa\ud86c\uddf2\ud989\uddc0", "\u8f2f\u1616\u4dc9\u23b9\u4a6a\u4e00\ucce8\u744f\u937d\uc92b\u890b\u09d4", "\ud83c\udf2b",
        52, 76777, -873342169, -5954754425394216333L, 57318L, false, true, (char) 9906, (char) 28925,
        Double.longBitsToDouble(0x3fd9c07ad6e98d88L), Double.longBitsToDouble(0x3fecf8ac8029bfaaL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 4, 2, "\uda6f\udd80\ud9be\udde3\uda05\udd7a\ud9f3\udff5\uda2e\ude0c\uda46\udf7b\ud9c3\ude3f\udab3\uddb1\uda80\udd50\ud8d6\udcfe\udb76\udd0d\udbd9\udf1c\u3c40\udafa\uded9\ud93c\udc8c\ud987\udcf2\ud8fb\udd2b\uda12\udc9b\ud84c\udf48\udb3f\ude6e\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\uf61a\udb85\udebf\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\uda1b\udee6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u054b", "\uda6f\udcef\ud940\udfdf\udbc8\udce8\udaf3\udfd8\udbed\udcb6\uda61\uddca\ud8a9\udef0\ud970\udff1",
        41, 16634, -642882348, 1583065929620218911L, 40506L, false, false, (char) 2681, (char) 60434,
        Double.longBitsToDouble(0x3fe9558bb79aa898L), Double.longBitsToDouble(0x3fe4c1c7ee9f525eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[] |a0=[Lorg.joda.time.DateTimeFieldType;:[[]] |a1=[I:[[]]\0121=new org.joda.time.Partial:[]\012",
        Z.run(T, 2, 19, 7, 18, "\udaf5\udd2a\uda1e\udfaa\000\udb16\udd0b\000\ud961\udcd9\uda2d\udedf\udbe2\udd94\ud814\ude5a\ud8d4\udc16\udb76\udd75\ud956\udc0d\u00c0\000", "", "",
        20, 65029, -1292760400, -4406190284485489252L, -24674L, true, false, (char) 44239, (char) 16397,
        Double.longBitsToDouble(0x3fe8a0320def273fL), Double.longBitsToDouble(0x3fe6bd520114914cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 15, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\ud94d\udde6\uda2d\udedf\ud85d\udf8f\udb44\udc71\ud8d6\udcf2\ud8d3\ude14\ud88c\udf21\u3c40\udae4\udc4c\uda3e\udd8e\ud9ef\ude1b\ud812\udc0d\ud826\udeef\udb40\udde1\ud885\udf0e\ud885\udd24\ud9d2\udfce\ud8cd\udd33\udb44\udfbf\udb42\udf96\ud846\ude5d\ud863\uddc4\ud924\ude14\ud9a8\udf33\u8e14\ud128\ud9f0\udce6\udb20\uddc9\ud924\udc6a\udb77\udc4b\u11bf\ud9f7\udcb1\ud984\udcba\uda68\udd1c", "\u2abe\u9f33\ud79c\u4f5a", "\ud8ad\uddd1",
        37, 65665, 1121389283, 1242817393471566213L, 55260L, true, false, (char) 55248, (char) 64450,
        Double.longBitsToDouble(0x3f8872ce9bd55ec0L), Double.longBitsToDouble(0x3fe4f726f9ebb3daL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null]]\0121=new org.joda.time.Partial:!toString:java.lang.NullPointerException |a1=[Lorg.joda.time.DateTimeFieldType;:[[null]]\012",
        Z.run(T, 2, 17, 17, 5, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\ud94d\udde6\uda2d\udedf\udbe2\udd94\ud8e7\udf04\ud8d6\udc6b\udb76\udd0d\ud88c\udf21\u3c40\udae4\udc4c\ud93c\udc8c\ud9d8\ude1b\ud812\udc0d\ud826\udeef\ud84c\udf48\ud885\udf0e\ud88c\udf24\ud9d2\udfce\ud8cd\udd33\ud9a2\udc45\udb42\udf58\ud846\ude5d\udba1\udf22\ud924\udde2\ud9a8\udf33\uda49\udfa7\000\udb51\udca7\udb20\uddc9\ud924\udc6a\ud82d\udfc6\ud9e4\udebc\ud926\udc1a\u2961\000", "\u2abe\u9f33\ud79c\u4f5a", "\ud8ad\uddd1",
        37, 65665, 1121389283, 1242817393471566213L, 55260L, true, false, (char) 55248, (char) 64450,
        Double.longBitsToDouble(0x3fe93dc29e66cbf1L), Double.longBitsToDouble(0x3fc3dc9b43aece50L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.joda.time.field.UnsupportedDurationField:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 22, "\udab6\udfc2\udac3\udf5d\ud96a\ude7f\uda06\udce1\ud8f6\uded7\udb95\udf67\uda2d\udedf\udbe2\udd94\ud93a\udd4d\udb70\ude2a\udbcf\ude37\udaa4\udf63\udaab\udd7c\udbde\udf5f\ud93c\udc8c\udb38\uddbd\ud812\udc0d\ud826\udeb8\ud84c\udf48\ud93a\udefb\ud972\udd88\ud932\udda3\ud8cd\udd33\ud9a2\udc45\uda8b\udebd\uf600\udba1\udf7b\ud92d\udf03\ud9a8\udeb5\ud839\udc6d\udac2\udd07\ud9f0\udce6\ud942\udd1b\u4da3\udbb6\udf76\ud82d\udcb9\ud8a0\udc62\udbc7\udedd\udb2d\udfb3", "\ubb9b\u9f33", "\udb99\udc6a\ud901\udd88\ud9ab\udd31\ud952\ude7c\ud98b\udc5f\udbbe\udcf8\ud8c9\ude55\uda99\udc23\uaa5e\udb94\ude91\ud83c\udf2b\ud81e\udd40\u1e29\uda7f\udc55\udb59\udf5c",
        50, 97651, 466051882, 1115639952908938902L, -88324L, false, false, (char) 35525, (char) 45697,
        Double.longBitsToDouble(0x3fe0d378ed06e9afL), Double.longBitsToDouble(0x3fd7c9873cc42b82L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[]\0121=new org.joda.time.Partial:[]\012",
        Z.run(T, 2, 2, 18, 2, "\ud8ef\udc7b\ud99d\udfd3\udb41\udc0e\uda06\udce1\ud849\udf49\ud938\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udafd\ude30\ud88c\udf2f\udb83\udc39\udb06\udcba\ud93c\udc8c\uda26\uddc2\ud9b0\udd66\udb85\udc96\ud84c\udf48\ud885\udf0e\ud88c\udf8e\ud9d2\udfce\uda8d\uded4\ud9a2\udc45\udb42\udf58\ud838\udf6a\uda23\uddc2\ud924\ude13\ud9a8\udf33\udb67\uddf5\ud88b\udc25\ud9f0\udce6\udb09\uddac\ud9a3\udc28\ud89b\udc2a\ud9e4\udf68\ud9f2\udc20\ud86c\uddf2\udbdd\udc6b", "\u6edb\u599b\ud79c\u4f5a\u8dcb\u966a\u6860\u6713\u63e2\u11da\ua68a\u7dab", "\ud83c\udf2b\ud827\udf40\ud975\ude74\ud95b\udc1f\ud8a9\ude81\udb27\udd3e\ud856\udf95",
        57, 22706, 1381953174, 553131996732784796L, -49491L, true, false, (char) 21992, (char) 41337,
        Double.longBitsToDouble(0x3fe2b5aa111a127bL), Double.longBitsToDouble(0x3fe9d28c61cfc252L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[] |a0=[Lorg.joda.time.DateTimeFieldType;:[[]] |a1=[I:[[]]\0121=new org.joda.time.Partial:[] |a0=[Lorg.joda.time.DateTimeFieldType;:[[]] |a1=[I:[[]]\012",
        Z.run(T, 2, 19, 19, 18, "\udaf5\udd2a\uda1e\udfaa\000\udb16\udd0b\000\ud961\udcd9\uda2d\udedf\udbe2\udd94\ud814\ude5a\ud8d4\udc16\udb76\udd75\ud956\udc0d\u00c0\000", "", "",
        20, 65029, -1292760400, -4406190284485489252L, -24674L, true, false, (char) 44239, (char) 16397,
        Double.longBitsToDouble(0x3fe8a0320defc53fL), Double.longBitsToDouble(0x3fe6bd520114914cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 22, "\ud8ef\udc44\ud8c1\udda5\ud952\udf51\uda06\udce1\ud849\udf49\udb21\uddd3\uda2d\udedf\udbe2\udd94\uda80\udd50\ud8d6\udcfe\udb76\udd0d\ud88c\udf21\u3c40\udafa\udeb6\ud93c\udc8c\u00cf\ud812\udc0d\uda12\udc9b\ud84c\udf48\uda07\udf0f\ud88c\udf8e\ud9d2\udfce\ud8cd\udd33\uf61a\udb83\udebe\ud846\ude5d\udba1\udf22\ud924\udde2\ud885\ude03\udb26\uddd5\ud176\ud9f0\udce6\ud8f9\udd2d\u4d66\uda58\udca3\udafc\udc0e\ud925\udffa\ud86c\uddf2\udb2d\udfb3", "\u2abe\u9f33\ucd61\u5ca8\u8dcb\u705b\u71ac\u6713\u63e2\u1e97\u2a38\u09d4", "\ud83c\udf2b\ud81e\udd40\u4ee3\uda94\udc15\ud9b9\udccc",
        -2, 8315, -1466408150, 4106613920387493528L, -88324L, false, true, (char) 35119, (char) 46539,
        Double.longBitsToDouble(0x3febdd311640f386L), Double.longBitsToDouble(0x3fedf66246c2c8bfL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=new org.joda.time.Partial:[] |a0=[Lorg.joda.time.DateTimeFieldType;:[[]] |a1=[I:[[]]\0121=new org.joda.time.Partial:[] |a0=[Lorg.joda.time.DateTimeFieldType;:[[]] |a1=[I:[[]]\012",
        Z.run(T, 2, 20, 4, 18, "\ud8f4\udc73\udbf2\udf62\000\udb16\udd0b\000\ud961\udcd9\uda2d\udedf\udbe2\udd94\ud814\ude5a\ud8d4\udc16\udb76\udd75\ud956\udc0d\u00c0\000", "", "",
        20, 65029, -1292760400, -4406190284485489252L, -24674L, true, false, (char) 44239, (char) 16397,
        Double.longBitsToDouble(0x3fe8a0320def273fL), Double.longBitsToDouble(0x3fe6bd520521eb7bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.field.UnsupportedDurationField|compareTo|org.joda.time.DurationField|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "C|org.joda.time.Partial|<init>|org.joda.time.Chronology,[Lorg.joda.time.DateTimeFieldType;,[I",
    "C|org.joda.time.Partial|<init>|",
    "C|org.joda.time.Partial|<init>|[Lorg.joda.time.DateTimeFieldType;,[I,org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|[Lorg.joda.time.DateTimeFieldType;,[I",
    "C|org.joda.time.Partial|<init>|org.joda.time.DateTimeFieldType,int,org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|org.joda.time.DateTimeFieldType,int",
    "C|org.joda.time.Partial|<init>|org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|org.joda.time.Partial,[I",
    "C|org.joda.time.Partial|<init>|org.joda.time.ReadablePartial",
    "M|org.joda.time.field.UnsupportedDurationField|add|long,int|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|add|long,long|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|equals|java.lang.Object|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|getDifference|long,long|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|getDifferenceAsLong|long,long|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "M|org.joda.time.field.UnsupportedDurationField|getInstance|org.joda.time.DurationFieldType|static",
    "M|org.joda.time.field.UnsupportedDurationField|compareTo|org.joda.time.DurationField|new:org.joda.time.field.UnsupportedDurationField:org.joda.time.DurationFieldType",
    "C|org.joda.time.Partial|<init>|org.joda.time.Chronology,[Lorg.joda.time.DateTimeFieldType;,[I",
    "C|org.joda.time.Partial|<init>|",
    "C|org.joda.time.Partial|<init>|[Lorg.joda.time.DateTimeFieldType;,[I,org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|[Lorg.joda.time.DateTimeFieldType;,[I",
    "C|org.joda.time.Partial|<init>|org.joda.time.DateTimeFieldType,int,org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|org.joda.time.DateTimeFieldType,int",
    "C|org.joda.time.Partial|<init>|org.joda.time.Chronology",
    "C|org.joda.time.Partial|<init>|org.joda.time.Partial,[I",
    "C|org.joda.time.Partial|<init>|org.joda.time.ReadablePartial",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
