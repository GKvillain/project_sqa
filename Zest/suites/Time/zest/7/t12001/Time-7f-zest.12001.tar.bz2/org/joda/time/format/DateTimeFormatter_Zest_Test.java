package org.joda.time.format;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateTimeFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 13, 13, 6, "\u34fc\udb84\udda1\uda2a\udf68\udb08\ude5e\udb6e\udca9\uda84\udc46\ud981\udcd0\ud9c0\udf73\uab02\ud96e\udf5a", "\u3ec3\u07d2", "\ud857\udfdf",
        18, 53746, -440865293, -7532684147599089315L, -65733L, true, false, (char) 31112, (char) 36107,
        Double.longBitsToDouble(0x3feafc04ac393621L), Double.longBitsToDouble(0x3feb3d8b4a3fcb6cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 13, 13, 4, "\u34fc\udb84\udda1\uda2a\udf68\udb08\ude5e\udb6e\udca9\udbe6\udf41\ud981\udcd0\ud9c0\udf73\uab02\ud96e\udf5a", "\u3ec3\u07d2", "\ud857\udfdf",
        18, 53746, -440865293, -7532684147599089315L, -65733L, true, false, (char) 53850, (char) 23812,
        Double.longBitsToDouble(0x3feafc04ac393621L), Double.longBitsToDouble(0x3feb3d8b4a3fcb6cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 13, 13, 6, "\u34fc\udb84\udda1\udb93\uddac\udb15\udf85\udac4\udff9\ud80f\ude6d\ud981\udc6d\ud9c0\udf73\uab02\ud96e\udf5a", "\u21db\u07d2", "\ud857\udfdf",
        18, 30474, -440072843, -7532684149632933937L, 49665L, false, false, (char) 209, (char) 16729,
        Double.longBitsToDouble(0x3fd76a14db3d8e3cL), Double.longBitsToDouble(0x3fc9246a30129734L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 0, 13, 0, "\u34fc", "\u4045\ubfd9", "\ud9c0\udeac\uab02\ud96e\udf5a\udbc8\udf0d\udaa7\uddbc\ud8d8\udcaa\ud836\ude5b\ud81f\uddff\u4396\ud857\udfdf\uda9b\udce1\ud849\udde3\uda23\udc66\udb8e\udd83\uda42\udc80\u8a7d",
        53, 51539, 1966831482, -9181406082296072353L, 75374L, false, false, (char) 2968, (char) 35264,
        Double.longBitsToDouble(0x3feb4e6fa36888a3L), Double.longBitsToDouble(0x3fb3235d2b00ee60L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 9, 13, 6, "\u3599\udb84\udda1\uda2a\udf68\udb08\ude5e\udb6f\udda9\uda84\udc46\udb22\udccf\ud9c0\udf73\uab02", "\u7787\u3ec3\u07d2", "\ud857\udfdf",
        18, 53746, -440865293, -7532684147599089315L, 49665L, true, false, (char) 209, (char) 13740,
        Double.longBitsToDouble(0x3fdb3d9ee42f3d5aL), Double.longBitsToDouble(0x3fecf97a822cc353L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 10, 12, 6, "\u34fc\uda20\udcf9\ud91d\udea0\udb08\ude0d\udb6e\udca9", "\u3fe2\u0351\u2499\u416b\ud774\u3ec3\u07d2\u82d1\u4362\u8c2c\u7724\u97ff\u04f1\u4424\u3c0d\u96d1", "\uda71\ude62\udac0\udc4d\uda90\ude8f\ud96b\udf97\udb21\udc4d\ud98b\ude17\udba5\udd85\udbba\udcae\ud92f\udd58\ud952\udc6e\ud9db\udf8f\ud9df\ude71\ud919\udc83\udb2f\ude1d\ud904\udfd2\u928b\uda05\ude06\ud874\udea9\ud838\udd97\udb39\udcd7\ud9c1\udfcc\uda7f\udf65\ud906\udf63",
        32, 11568, -859839715, 3498639036641385272L, -33576L, true, true, (char) 2152, (char) 41593,
        Double.longBitsToDouble(0x3fddd41595fe793eL), Double.longBitsToDouble(0x3fe46201f09973c4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=null |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 8, 5, 13, "\u34fc\udb26\udd92\uda81\udc4e\udb08\ude5e\udb6e\udca9\ud93b\udf48\ud812\udf9e\ud93b\udd98\uda6f\ude1b\ud96e\udf5a", "\u8dca\u07d2", "\udab2\udd1f",
        17, 53250, -438989481, 2260059535077169378L, -92149L, false, true, (char) 42950, (char) 55993,
        Double.longBitsToDouble(0x3fcec67e123d6a80L), Double.longBitsToDouble(0x3feb3d8b4a3fcb6cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 8, 13, 6, "\u34fc\udb84\udda1\uda2a\udf68\udb08\ude5e\udb6e\udca9\uda84\udc46\ud981\udcd0\ud9c0\udf73\uab02\ud9bf\udea3", "\u3ec3\u07d2", "\ud857\udfdf",
        18, 53746, -440865293, -7532684147599089315L, -65733L, true, false, (char) 31112, (char) 6005,
        Double.longBitsToDouble(0x3feafc04ac393621L), Double.longBitsToDouble(0x3fd1aa9e247ee36cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 0, 15, "\ud8d9\udc21\udb84\udda1\uda2a\udf68\udb08\ude5e\udb6e\udca9\udac1\ude45\ud948\udfa8\ud9bb\udc21\udb14\udcc6\ud8e9\udf50", "\u3e63\u07d2\u3f7b\u45fa\u9bbe\u292f\u97ff\u06ce\u1bc7\uc4ea\ud6fb\u991f\uce5f\u3c65\u7863\u3787\u9714\u6916\u91a4\u2dc8\ud629", "\uda22\udf53\ua7ae\udb00\ude89\ud80f\udf10\uda9a\ude1d\ud884\ude99\udbe8\udc1a\ud9fa\udfbf",
        14, 26912, -21242444, 396525282725181532L, 14553L, false, false, (char) 40322, (char) 36613,
        Double.longBitsToDouble(0x3fc0ab7529dae954L), Double.longBitsToDouble(0x3fd4ce4c5c79dce8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 11, 13, 3, "\u34fc", "\u4045\ubfd9", "\uda90\udf62\uda53\ude89\ud96e\udef7\udbc8\udf0d\udb13\udc14\udb29\udd5a\ud836\udf3d\udb36\udd0b",
        45, 10230, -650922197, 5053203922961362419L, -92157L, true, false, (char) 49315, (char) 25165,
        Double.longBitsToDouble(0x3febd01077d0753bL), Double.longBitsToDouble(0x3fed4404ac14a9e7L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 15, 4, 6, "\udbda\ude7a\udb84\udda1\uda2a\udf68\udb08\ude5e\ud8ee\udca9", "\u3fe2\u828a\uc641\ucc37\u613b\u9b30\ua58e\u8571\u4362\u989a\u24bc\u94db\u22f4\u1bc7\u68f0\u45a0\ub9df\ua7b6\u4b7f", "\ud96b\udf97",
        30, 1327, -587378196, 1368654228783178225L, 36781L, true, true, (char) 6772, (char) 16727,
        Double.longBitsToDouble(0x3fc6c95c66b39350L), Double.longBitsToDouble(0x3fef7248ae413caeL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=java.lang.Integer:2000 |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 11, 3, 6, "\ua73d\udb84\udda1\uda2a\udf68\udb08\ude5e\udb6e\udca9\uda84\udc46\ud981\udcd0\ud9c0\udf73\ue368\ud8ef\udddb", "\u3ec3\u07d2", "\ud857\udfdf",
        18, 53746, -440865293, -7532684147599089315L, -65733L, true, false, (char) 10632, (char) 58830,
        Double.longBitsToDouble(0x3fedac910d32356cL), Double.longBitsToDouble(0x3fe116c7ba3fcb6cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 7, 15, 6, "\u34fc\ud963\udc18\uda1f\udeeb\udb08\ude5e\ud93d\ude70\ud8cd\udd28\ud94b\udef6\udac8\uddff\uda44\udc02\ud980\udc8d", "\u69e9", "\ud822\udc49\ud857\udfdf\uda9b\udce1\ud849\udde3\udbdc\ude2f\ud96f\udd4e\ud925\udcef\u8a7d\ud92f\udca0\udb16\udc5b\uda2e\ude0f",
        15, 84437, -229259036, -2217162115345291783L, -87797L, false, true, (char) 60213, (char) 20122,
        Double.longBitsToDouble(0x3fe1d879b3277e1cL), Double.longBitsToDouble(0x3fcff72ef4c4ffc8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.joda.time.format.DateTimeFormatter:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 0, 7, "\udbf9\udfb1", "\u4045\ubfd9", "\udbba\ude58\ud897\udd4d\u4435\ud9b5\udf3d\udaa7\udd28\ud8d8\udcaa\ud836\ude5b\ud81f\uddff\u4396\ud857\udfdf\uda9b\udce1\ud866\udd06\ud9fd\udd61\udb8e\udd83\uda42\udc80\u8a7d",
        53, 51539, 1966831573, -3230180649702672606L, -9532L, true, true, (char) 34105, (char) 35462,
        Double.longBitsToDouble(0x3feb4e6fa36888a3L), Double.longBitsToDouble(0x3fb3235d2b00ee60L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 10, 10, 6, "\u34fc\uda20\udcf9\ud91d\udea0\udb08\ude0d\udb6e\udca9", "\u3fe2\u0351\u2499\u9770\ud774\ud1e6\u07d2\u82d1\u4362\u68bc\u562f\u97ff\u4c58\u432f\u3c0d\u96d1", "\uda71\ude62\udac0\udc4d\uda90\ude8f\ud851\udf6a\ud9df\udf61\udbc9\udd91\udba5\udd85\udbba\udcae\ud92f\udd58\ud952\udc6e\ud9db\udf8f\ud9df\ude71\ud919\udc83\udb2f\ude1d\ud904\udfd2\u928b\uda05\ude06",
        44, 57025, 242226174, 5442427909184988507L, 90347L, false, true, (char) 45436, (char) 30343,
        Double.longBitsToDouble(0x3fe9c1846e1bd053L), Double.longBitsToDouble(0x3fd5cdbaa6898588L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\0121=java.lang.Boolean:false |this=org.joda.time.format.DateTimeFormatter:@?\012",
        Z.run(T, 2, 11, 11, 3, "\u34fc", "\u8090\u59e6", "\ud86c\udebb\ud926\udd96\ud90d\udcb7\udbc8\udf44\udb13\udc14\ud9a3\udf51\ud816\ude3d\ud9fb\udc6a",
        45, 14350, -650960984, 5053203922961362419L, 79675L, true, false, (char) 31112, (char) 36107,
        Double.longBitsToDouble(0x3fed4404ac14a9e7L), Double.longBitsToDouble(0x3fd34a6a695c710cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 13, 13, 6, "\u34fc\udb84\udda1\uda2a\udf68\udb08\ude5e\udb6e\udca9\uda84\udc46\ud981\udcd0\ud9c0\udf73\uab02\ud96e\udf5a", "\u8e00\u367a", "\ud857\udfdf",
        18, 53746, -440865293, -7532684147599089315L, -65733L, true, true, (char) 31181, (char) 36107,
        Double.longBitsToDouble(0x3fd5f80958726c42L), Double.longBitsToDouble(0x3feb3d8b4a3fcb6cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.format.DateTimeFormatter|parseInto|org.joda.time.ReadWritableInstant,java.lang.String,int|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getChronolgy||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getChronology||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getDefaultYear||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getLocale||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getParser||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getPivotYear||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getPrinter||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|getZone||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|isOffsetParsed||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|isParser||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|isPrinter||new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseDateTime|java.lang.String|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseLocalDate|java.lang.String|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseLocalDateTime|java.lang.String|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseLocalTime|java.lang.String|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
    "M|org.joda.time.format.DateTimeFormatter|parseInto|org.joda.time.ReadWritableInstant,java.lang.String,int|new:org.joda.time.format.DateTimeFormatter:org.joda.time.format.DateTimePrinter,org.joda.time.format.DateTimeParser",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
