package org.joda.time.chrono;
import org.junit.Test;
import static org.junit.Assert.*;
public class GJChronology_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 11, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        -2, 90186, 1135061698, -572623837580277197L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 11, 2, "\udb3f\udd14\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\udaaf\udf20\udb7a\udfa0\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u0fd9\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        45, 64375, 1311336000, 5050979148311860956L, 57336L, true, false, (char) 61289, (char) 15017,
        Double.longBitsToDouble(0x3fec15d95bf2a863L), Double.longBitsToDouble(0x3fc4c5945e40f49cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        14, 90186, 1135061698, -572623837572497869L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 5, "\udb2d\udfa9\ud8f2\uddc3", "\u754e\u7066\uc0dd\ub4f0", "\ud909\ude5d\udb5e\udd5d\ud9c9\udee3\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\ud922\udf47\ud926\uddf5",
        30, 88013, -2075629891, -4352189143523629438L, 70432L, false, false, (char) 56568, (char) 34271,
        Double.longBitsToDouble(0x3fe6c69788baf244L), Double.longBitsToDouble(0x3fe2e9ae7921efb3L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 4, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\udbbb\udfe7\ud99d\udc8e\udaca\udfeb\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        -2, 19570, 1135061698, -356451055466504203L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 11, 2, "\udb2d\udfa9\ud8f2\udd99\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud872\udec5\udbbc\udfa4\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        -2, 90186, 1135061698, -572623837580277197L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be30bL), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 19, 2, "\udb0d\udcc5", "\ub524\ub6c9\u6fda\uc0dd\ub4f0\u7bf3\u7972\u120f\ucb56\uce6d\u0cef\u53fd\000", "",
        -5, -1000, 332544, 1408470153972704957L, -100000L, true, true, (char) 46, (char) 64750,
        Double.longBitsToDouble(0x3fe6e230c6d72f08L), Double.longBitsToDouble(0x3e30000000000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 11, 2, "\udb2d\uded8\ud87a\udfe6", "\u754e\u7066\uc0dd\ub4f0\u7bf3\u0a9d\u120f", "\ud8f6\uddf7\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95",
        39, 51354, 327935013, -8914762501458367736L, -3873L, false, false, (char) 64750, (char) 56563,
        Double.longBitsToDouble(0x3fe6b978469853f1L), Double.longBitsToDouble(0x3fe37fcef06eff6dL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 0, 16, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\ud877\uddbe\000\ud87a\ude08\000\000\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\000\000\000\ud926\udd7b\uda34\udcd9%\ud8e2\udcb1\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\u6698\000\000\uda4d\udd12\ud8c9\ude58\uda52\udffb\uda37\udc40",
        9, 90186, 1135061698, -572623838972786125L, -30515L, true, true, (char) 51060, (char) 54987,
        Double.longBitsToDouble(0x3fe7df68026be332L), Double.longBitsToDouble(0x3ebd000000000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 12, 0, 12, "\u82e4\ud9f2\ude39\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\000\ud82b\udc55\000\ud83b\uddeb\udab8\udd43\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafa\udfe9\ud926\udd2d\uda34\udcd9\udb87\udd4b\uda03\udf72\uf308", "", "\uda32\udda1\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda30\udd23\000\000",
        30, 88688, -868811814, 4875052871852269991L, -100000L, true, false, (char) 64718, (char) 51036,
        Double.longBitsToDouble(0x3fde1d5ea5f7dbc6L), Double.longBitsToDouble(0x3fe35f19940b0c00L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 11, 2, "\udb2d\udfa9\ud99c\uddb8\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud8a4\udefe\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc2\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud94a\ude65\uda37\udc40",
        -2, 90186, 1135061698, -572623837580277197L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\ud8fe\udfb5\ud8dc\ude39\udb7a\udf80\udac7\uddce\ud94c\udf51\udb02\udc5e\udb7b\udf57\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\udaae\udfc2\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        57, 90186, 1135061698, -572623837580277197L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1d6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 18, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\uda72\udd27\uda44\ude61\ud820\ude4a\udb7a\udf80\ud9d7\ude56\uda16\udfa8\uda7b\uddb5\udb7b\udf11\ud8f2\udc91\udadc\ude1f\u220e\ud810\ude44\ud9ac\udda4\uda2f\udd45\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\uda4a\ude71\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        -2, 90186, 1135061698, -572623837580277197L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 11, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\ud8c6\udfb7\udac7\udf5a\ud820\ude38\udb7a\udf80\uda9e\udd79\udba8\udcbd\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud8c6\uded2\udb1c\udc4b", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\ud9cf\udd13\ud8c9\ude58\ud983\ude93\uda37\udc40",
        -2, 90186, 1135061698, -572623837580277197L, -30515L, false, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\udb78\udf16\uda9a\udeee\ud8f5\udfdd\udb96\udcc8\udb39\udd2a\udb7b\udf11\ud843\udf6e\uda17\udfa6\udaa7\udc40\ud8c1\udfb5\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udf3e\udbc1\udd2b\ud95e\udea7\ud853\udc1e\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda3b\udf52",
        -2, 90143, 1135061698, -572623837580277197L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\012",
        Z.run(T, 1, 12, 15, 16, "\000\ud8f2\uddc3\ud967\udeef\000\ud90f\udf87\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb36\ude2a\ud913\udf5d\000\000\ud83b\uddeb\ud810\ude44\udab5\udeea\u3452\ub2be\000\ud8a7\udf0e\uda34\udcd9\udb87\udd4b\ud8e3\udec1\000", "\uace2", "\ud97c\udef2\ud835\udea5\000\000\uda22\udff1\ud960\uded0\ud983\udda1\ud8f3\udc3e",
        -2, 90186, 1135061698, -572623837580277248L, -30515L, true, true, (char) 51060, (char) 54762,
        Double.longBitsToDouble(0x3e335f1990000000L), Double.longBitsToDouble(0x3ebd000000000000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=3]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 18, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ud915\ude49", "\u3ae3\u21da\u7e9a\u4254\u39fe\u8a02\u5d1c\u378d\u41ab\u48d9\u5920\u4d7e\u9679", "\udb1f\udf18\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\u6914\uf3cc\uda9c\udc9c\ud8fb\udc72\ud870\udd18\udb25\udf9b\ud92d\udfbe\ud80f\ude5c\ud8b4\ude4c\uda26\udc1b\ud9ba\udf98\uda98\udf54\ud93e\uded7\uda39\udc8e\uda53\udd5a",
        3, 95851, 821985989, -7374555447057303142L, -70681L, false, true, (char) 57871, (char) 60297,
        Double.longBitsToDouble(0x3fd75f2f138a5f26L), Double.longBitsToDouble(0x3fe4f758d71ac81eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 11, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\uacd3\udb4d\udf58\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udbf2\udd86\udb7b\udf6f\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udf77\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\ud991\uddca",
        11, 52706, -902171382, 2882557999958482940L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 11, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udacd\udf1e\udaaa\udc13\uda70\ude2e\ud91e\udf7c\udac7\uddce\udb83\udff4\udabe\udd15\udb7b\udf7f\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\ud94d\udea8\udb2e\uded4\ua449\udb73\udf1f\udab9\udf0c\uda0e\udd62", "\u5abd\u21da\u7e9a\u4254\u6794\u879d\u5d1c\ub8ee\u0383\u48d9\u5920\u4d7e\u4f7f\u89ce\ua332\u848d\u23df\u238d", "\udb0c\udccf",
        8, 62459, -1086102520, 8656793881207256031L, 45534L, true, false, (char) 19679, (char) 22236,
        Double.longBitsToDouble(0x3f7a79ddeee6c900L), Double.longBitsToDouble(0x3fe5c5ae55ea6aa9L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 9, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\ud97f\udf09\ud6ec\udab9\udc10\udba8\udc9f\udba7\udd6a\udb7b\udf31\udb17\udf52\udbd0\ude78\ud83b\uddeb\ud810\ude44\udadf\udf9f\uda11\udf59\uda62\udfd2\ud85b\udd45\ud894\udd53\uda34\udcd9\udb87\udd4b\uda03\udf72\uda65\udf32\ud9a1\udda9\ud930\ude21\uda47\udd06", "\u74b0\u39fe\u8a02\u2a31\u37c9\u737f\u4880\u5920\u4d7e\u9679\u52f1\ub83b\u84b2\u23df", "\ud82c\udce2\udb0c\udccf\udb2d\udcc6\udb7b\udcad\uda9a\uddfc",
        48, 32660, 632123179, 1098196440283381546L, -39772L, true, true, (char) 30527, (char) 33904,
        Double.longBitsToDouble(0x3fea18018f3b8589L), Double.longBitsToDouble(0x3fe7b029dcc61bfbL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 1, 19, 2, "\udb2d\udfa9\ud8f2\uddc3\uda02\udcc5\udb66\udce6\udabb\udce3\ud959\udca5\udb9b\udcfe\udac7\uddce\ud826\udcbe\udb39\udd2a\uda28\udee1\ud84e\udd6e\ud81d\udfa9\udb67\udc92\udbf7\uddf4\udab5\udedf\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda94\ude39\ud80f\ude10", "\u3ae3", "\ud97c\udfc9\ud842\udf86\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        -2, 90186, 1135079885, -572623837580277197L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e94ad93700L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 0, 0, 12, "\000\000\000\000\000\ud950\udfa7\udb49\uddc4\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud968\udd0f\uda5a\udcedG\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda2f\udd77\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\u00a6",
        49, 67418, 0, 0L, -100000L, false, false, (char) 0, (char) 47359,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8600e800193700L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a",
        26, 78726, 789092060, 6048711255196067480L, -79122L, false, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fc10a3dcbf3778cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 2, "\udbab\udf79\ud8f2\uddc3\uda4d\udfc2\ud9a7\udf06\ud846\udd4a\udaaf\udf20\udb7a\udfa0\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u6b31\u71d7\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        2, 11251, 1311336000, 5050979148311860956L, 57336L, true, false, (char) 22510, (char) 15682,
        Double.longBitsToDouble(0x3fc5fd048fcaa18cL), Double.longBitsToDouble(0x3fc4c5945e40f49cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 5, 15, "\udb3f\udd14\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\udaaf\udf20\udb7a\udfa0\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u0fd9\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        45, 64375, 1311336000, 5050979148311860956L, 57336L, true, false, (char) 61289, (char) 15017,
        Double.longBitsToDouble(0x3fec15d95bf2a863L), Double.longBitsToDouble(0x3fc4c5945e40f49cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 0, 17, 18, "\udb3f\udd14\udaec\ude3f\uda49\ude54\udb66\udce6\udadb\udd63\udaaf\udf20\udb7a\udfa0\udac7\uddd4\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u0fd9\u6e1c\u66a8\u8470\ud258\u9125", "\udb87\udd4b\uda03\udf72\udbf1\ude71",
        45, 64375, 1898554411, -1426189463745685796L, 57336L, true, false, (char) 11290, (char) 10047,
        Double.longBitsToDouble(0x3fec15d95c396563L), Double.longBitsToDouble(0x3fc4d50f7e40f49cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=1]\012",
        Z.run(T, 2, 0, 4, 14, "\udb3f\udd14\ud8fe\uddc3\uda4d\udfc2\udb66\udce6\ud970\udfd8\udb17\udc1e\udb2f\uddd4\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u0fd9\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        1, 64375, 1311336000, 5339209524463575189L, 14776L, true, false, (char) 61289, (char) 39767,
        Double.longBitsToDouble(0x3fe71a5563f2a863L), Double.longBitsToDouble(0x3fc4c5945998f49cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 4, 2, "\udb3f\udd14\ud863\uddb7\uda4d\udfc2\udb66\udce6\udadb\udd63\udaaf\udf20\udb7a\udfa0\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u0fd9\u6e1c\u66a8\u43d6\u198d\u9aec", "\udb7e\udcd9\uda03\udf72\udb1b\udf78",
        45, 64375, 1311336000, 5050979148311860956L, 57336L, false, false, (char) 61289, (char) 15017,
        Double.longBitsToDouble(0x3fec15d95bf2a863L), Double.longBitsToDouble(0x3fc4c5945e40f49cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb40\ude0d\udbc9\udf82", "\u8d81\u470d\uc0db\ub4f0\u396a\u7972\ua681\ucb56\uce6d\u8bb4", "\uda1a\udf8d\ud8bc\udec5\udafb\udc95",
        39, 51354, 327935013, -8914762501458367736L, -3873L, false, false, (char) 64756, (char) 56563,
        Double.longBitsToDouble(0x3fe6b978469853f1L), Double.longBitsToDouble(0x3fe5873ef06eff6dL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ua51f", "\u3ae3\u21da\u7e9a\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920\u1e9f\u9679\u52f1\ub83b\u413f", "\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48",
        15, 38803, -719381461, 8413687489259741696L, 60719L, false, true, (char) 30897, (char) 18352,
        Double.longBitsToDouble(0x3fea8937d20a297cL), Double.longBitsToDouble(0x3fef200e648d38a9L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9", "\ub524\u5cd9\u0d70\u2aca\ub93f\u056f\u7bac\ua681\u7602\u0102\u2cd2\u14e9\ubb91", "\udaf2\uddcb\ud8bf\ude71\uda34\udcd9\ud92b\udcfd\ud8c8\udd29\udb1b\udf78\u5ea1\ud834\udfb0\uda92\udc04\ud90b\udd05",
        49, 86976, 1168074392, 4986401513063987532L, -70542L, true, true, (char) 11592, (char) 65167,
        Double.longBitsToDouble(0x3fe0cb57e6b6c628L), Double.longBitsToDouble(0x3fb6e917847bb7b8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud801\udf00\uda4d\udfd2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\udbe6\uddb1\uda13\udfa6\ud833\uddff\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\udb4b\udc4a\uda4d\udcf9\ud8c9\ude58\ud983\ude93\uda37\udc40",
        14, 90186, 1135061698, 2849548926130454067L, 62122L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\uda80\udfe9\uda4d\udfc2\udab9\udc8f\udaf4\udee5\ud821\udf8c\udb7a\udf80\udac7\uddce\udba8\udc9f\ud9aa\udd83\ud99b\udcff\udaa9\udc7c\uda9c\udc86\udb0d\udd14", "\u33b8\ud258\u0bd6", "\ud9cc\uddc3\uda03\udf72\udb1b\udf78\ud98f\udcdc",
        14, 36360, -1810170740, 3389123686403495639L, 48816L, true, true, (char) 53976, (char) 31190,
        Double.longBitsToDouble(0x3fef5b0f48a62ca2L), Double.longBitsToDouble(0x3fec81e93bda6b34L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\udb36\udec2\udafb\udc95\ud90e\udd6f\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\uc390", "\ud93c\udf0e\udbc1\udd2b\ud921\udca8\ud825\udfcf\uda4d\udd12\ud8c9\ude58\ud983\ude93\udb83\udc46",
        14, 90186, -1394509630, 7532636227779363464L, -54937L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\uda1c\udd81\ud820\uddf4\udb7a\udf80\udac7\uddce\uda68\udc9f\udb39\udd2a\uda93\udee3\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\uda14\udef3\ud893\udcfa\udb87\udde3\uda03\udf72\udb1b\udf78", "\u81e7\u805e\uccfc\u88c4\u3883\ube61\u5dab\u378d\u73ab", "\uda73\udf8d\udae4\udccc\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\u2876\uda74\udc1f\ud817\udc2b\ud914\udc90\udac9\uddbc\uda9a\udeec\udbba\udd24\uda56\udf70",
        42, 45517, -353606625, -1006901147906637617L, -39095L, true, true, (char) 25606, (char) 50134,
        Double.longBitsToDouble(0x3fef5bbf2456d6a8L), Double.longBitsToDouble(0x3fe193a78c01955dL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\ud950\udf84\udb66\udd75\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\ud888\udc16\uda93\udee4\ud84e\udd6e\ud9d1\udfa3\ud949\udfa7", "\u7cac\u2c3e\u3d80", "\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3",
        35, 69327, 1270132422, 5571366274859569623L, 13328L, false, false, (char) 39124, (char) 11950,
        Double.longBitsToDouble(0x3fe3e6a13ba3143dL), Double.longBitsToDouble(0x3fec81e93bda6b34L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udbc9\uddb7\ud8e3\udc43\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4", "\u8bb4\u025d\u9e6a\u8470\ud258\u9aec", "\udb87\udd4b\uda03\udf72\udbdc\udfe0",
        45, 64375, 1311336000, 5050979145634331210L, 57336L, false, false, (char) 16348, (char) 54409,
        Double.longBitsToDouble(0x3fec15dce3f2a863L), Double.longBitsToDouble(0x3fc4c5945e40f49cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\uda85\ude5d\udabd\udcf3\udb88\udf20\udad1\ude48\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        14, 90186, 1135061698, 1310080767126019358L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 16, 2, "\udb2d\udfa9\udae9\udc1e\ud900\udcfa\udbae\udd6b\udb1f\udd2d\ud820\uddf4\udb7a\udf80\ud9e7\udf17\udba8\udc9f\udae4\ude99\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\udbdc\ude71\ud9ca\udffd\uda03\udfd1\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda5f\udf52\uda70\udf18", "\u3ae3", "\ud97c\udfc9\ud84c\ude10\ud95e\ude7f\ud825\udf78",
        36, 75626, 748878834, 4406491474875522448L, 52894L, true, true, (char) 4929, (char) 38555,
        Double.longBitsToDouble(0x3fea2b619f4d1df1L), Double.longBitsToDouble(0x3feaea20c1e1d5eaL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 18, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud871\udee2\udb7a\udf80\udac7\uddce", "\ua681\ucb56\uce6d\u4017\u5657\u9e6a\u8470\ud258\u9aec\u9316", "\uda03\udf72\udb1b\udf78\udb5f\udca3",
        0, 19503, 1176022726, 3389124592641595095L, 48816L, false, false, (char) 50132, (char) 17713,
        Double.longBitsToDouble(0x3fe59745d2fcd782L), Double.longBitsToDouble(0x3fe1da7deb53bcd2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=143448506-02-13T08:18:13.290Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920", "\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb6e\udfe4\udb84\udcf2\udb2e\udf32",
        2, 8909, 351555708, 4526735454865093290L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fd02005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 12, 8, "\ud810\udc3b\uda77\udedd\ud912\udcaf\ud884\udf90\ud81f\udd17\ud820\uddf4\ud958\uddf5\uda69\udc56\udba8\udc9f\ud890\ude55\uda41\udd2f\u5640\ud8be\uddec\ud8c8\udd37\ud832\udc5c\udab5\udeea\uda03\udf8d\udb33\udd90\udaed\udef4\ud9c5\ude16\uda34\udd3f\udb1c\udc76\ud863\udcfc\udb1b\udf78\udb5f\udca3\uda4d\udff6\ud8df\uddb1\ud8ba\uddca\uda32\udda1\ud97c\udfc9", "\u2133", "\ud983\ude93\ud935\udc20\ud937\uddb2\udae4\udccc\ud9d2\udf35\ud83a\udd2f\udad6\udf1d\ud9c0\udda6\ud8b8\ude50\ud829\udda8\udaad\udf69\udb14\udd0e\ud9b6\udd48\ud844\udf26\uda9a\ude64\udaa7\udf9b\ud8b0\udd90\ud9e9\udebc\ud9dc\udcac\u66da\ud91e\udf45\udbeb\udc67\ud85c\ude99\u8715\udae2\udfaf\ud9c2\udf56\ud94c\udc1d\uda01\ude35\udbaa\udd95\udb68\ude8b\udb88\udd67",
        -2, 33749, -478927369, 2157739220206920605L, 87962L, true, false, (char) 5738, (char) 28817,
        Double.longBitsToDouble(0x3fe96d9bf750e6f7L), Double.longBitsToDouble(0x3feb9af22951094dL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 7, 11, "\ud83f\udcff\udb5b\udfe8\uda4d\udfc2\udb66\udce6", "\u8de9\ub4f0\u7bf3\u7972\ua681\ucb56\uce6d\uc93b\u663d\u9e6a\u8470", "\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ud85b\ude31\ud94d\udebf\ud816\udd7b\ud884\udcdb\ud9f0\udee7\uda32\udda1\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud824\uddbc\uda36\udfb7\ud937\udde1\udae4\udccc",
        38, 27479, 1397030586, -3952510232973414253L, 64701L, true, true, (char) 22645, (char) 5534,
        Double.longBitsToDouble(0x3f8618e90ad93700L), Double.longBitsToDouble(0x3fe602046c4efb11L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 12, 19, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud897\ude50\ud927\udf73\udab0\udeac\uda03\udfcb\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud93f\udc31\udbc1\udd83\ud95e\udea7\udbbe\udcc4\uda4d\uddb1\ud8c9\ude58\ud983\ude93\uda37\udc40",
        14, 90186, 1131712706, 5949575818661461555L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=75382773-07-06T07:00:14.185Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udbec\udf8d\udb5b\udc56\ud896\udf8a\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3\u21da\u7e9a", "\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud946\udd93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud84f\ude2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb23\udcf6\ud9a6\udcb5\ud877\udf02\ud83f\udf2a\ud973\udfaa\udb1c\udf6a\ud993\udf56\ud8d1\udc7a\uda07\ude27\ud93a\udcae\ud85f\ude2d\ubca3\uda94\udc2c\ufc5d\udb78\ude31\udbf5\udf9e\udbb6\udc67\udaa1\udfd3\udae1\udc80\uda90\udf62\uc699\udbb5\udc19\ud8af\udc06\udbaf\udd51",
        1, 8662, 737274602, 2378788398111614185L, -42202L, false, true, (char) 31876, (char) 42287,
        Double.longBitsToDouble(0x3fb9c39ae51c5b98L), Double.longBitsToDouble(0x3fc8224e5366af08L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 10, 2, "\udb2d\udfa9\ud8f2\uddc3", "\u5cd9\u7022\uc0dd\ub4f0\u7bf3\uc1c7\ua681\ucb56\uce6d\u8bb4", "\uda03\udf8d\ud8bc\udec5\ufe5b",
        8, 51354, 327935013, -8914762501458367736L, -3873L, false, false, (char) 64750, (char) 56563,
        Double.longBitsToDouble(0x3fe6b978469853f1L), Double.longBitsToDouble(0x3fe5873ef06eff6dL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\uda0c\udffd\ud982\udc83\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        14, 90186, 1135061698, 3884532418633874117L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe4676f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93980L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 12, "\udb0d\udcc5\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\ud8cb\udc2d\uda03\udf72\udb1b\udf78", "\000", "\ud97c\udfc9",
        16, 8000, -273465234, -4959684606889331838L, 96774L, false, true, (char) 26382, (char) 30456,
        Double.longBitsToDouble(0x3fc4e874e0000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 10, "\udb2d\udfa9\ud8f2\uddc3", "\u5cd9\u7022\uc0dd", "\udb39\udd2a\uda10\udc6f\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23",
        20, 29889, 2123886376, 9164482713737403564L, -29502L, true, false, (char) 31304, (char) 28496,
        Double.longBitsToDouble(0x3fe4161ccf7f680eL), Double.longBitsToDouble(0x3fe204cf6ec64e29L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\udbc8\udcdf\ud84a\udce8\ud84b\ude58\ud820\uddf4\udb7a\udf80\ud9e8\udeea\udbaf\ude2a\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\udac2\udccd\udb1b\udf78", "\u3ae3\u21da\u7e9a\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920\u1e9f\u9679\u52f1\u6e8f", "\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\uda24\udf79\ud837\udd4d\ud8d8\udfc5\udacf\udd52\udab3\udd88\ud9c9\udc78\udb04\udfcb\uda5f\udee9\udb02\udf04\ud862\udc60\ud895\udf04\ud994\udfd0\udbda\udd62\uda45\ude1b\udb14\uddf2",
        44, 81828, 1776537547, 4503727801147298282L, -39500L, false, false, (char) 6054, (char) 5324,
        Double.longBitsToDouble(0x3fcc8fedf02b5298L), Double.longBitsToDouble(0x3fe8bfc1f7bdb0feL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\ud9bb\udc31\ud8ee\ude76\uda4d\udfc2\udb66\udce6\udac4\udf82\ud850\udc23\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud831\udd31\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud992\udc9b\ud983\ude93\uda37\udc40",
        14, 90186, 1135061698, 868528043632678259L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe9bf6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud83c\udc0c\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u2460", "\ud97c\udf87\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fdb09bc5acdfc98L), Double.longBitsToDouble(0x3fdab6da3bbc4054L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 11, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb6f\udedf\ud96f\udc78\udb7a\udf15\udac7\uddce\udba8\udc9f\udb39\udd2a\udb4c\udce1\ud84e\udd8e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udb0d\ude75\ud8fd\udc15\uda29\udd51\udafb\udc95\ud881\udcc8", "\u3020\u3372\u01d6\uc684\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\udba1\udf76\uda4d\udd12\ud8da\udfa2\ud983\ude93\uda37\udc40",
        14, 90186, 1125790942, 3913799116069666355L, -30515L, true, true, (char) 51060, (char) 23499,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e945993700L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b", "\u841b\u3372\u01d6\uc684\u3ae3\u21da\u7e9a\u4254\u9768\uba55\u5d1c\u378d\u73ab\u48d9\u5920\u1e9f\u9679\u52f1\ub83b\u413f\u23df\u238d\u7802\u297c\u0c6a\u1a82\u912d\u0396\ubbf0\u48d2\u0279\ub662\u5bc2\u2821\uc951\u54f1\u0fce\u6bf9\u0a6d\ua2c4\uce20\u4ae1\u876d\ud72e\u1b3a\u776b\u130a\u635b\u2e3c\u7335", "\udb5a\udf41",
        43, 45517, -497377866, 3869857254638775816L, -51678L, true, true, (char) 26315, (char) 13455,
        Double.longBitsToDouble(0x3fcd2ce1bafab8fcL), Double.longBitsToDouble(0x3fe5b99e146c6edbL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 8, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\uda01\uddcb\udba8\udc9f\udb39\udd2a\uda93\udee4\udb5a\ude5f\ud8f9\udd44", "\u9e6a\u8470\ud258\u50a8", "\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb\ud9f0\udee7\u87bb\ud8a1\ude1b\uda05\udcd8\u1e7c\uda8d\udddb\uf97a",
        9, 97698, 938606758, 8229847780874295965L, 6919L, true, false, (char) 12403, (char) 47544,
        Double.longBitsToDouble(0x3fea68ec135d4418L), Double.longBitsToDouble(0x3fde1d5ea54115c6L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udbf8\udd7d\uda9c\ude24\udb7a\udf0c\udac7\uddce\udba8\udc9f\ud9a4\udcff\udb59\udd11\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud88d\udc84\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\ude18\uda03\udf72\udb1b\udf78", "\u398f", "\ud97c\udfc9\ud8bd\udd29\ud996\udea3\ud8a4\udd97\uda4d\udde1\ud8c9\ude58\ud983\ude53\uda37\udc40\udb5f\uddd6\ud8f0\udd5e\udaa5\udebe\ud83a\udd2f\udb03\udfb4\uda52\udc66\ud9b6\udc67\ud940\udfe6\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\u965a\udac0\uddf8\ud9ff\udf90",
        32, 95620, 412896744, 842497189995793780L, -63712L, true, false, (char) 63185, (char) 63602,
        Double.longBitsToDouble(0x3fec74cb88e74bbeL), Double.longBitsToDouble(0x3fda63590845c520L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb34\udefd\ud8f2\uddc3\uda4d\udfc2\uda7f\udff7\udb1f\udd70\uda3a\udcc2\udb58\ude8c\ud93c\udd04\uda8d\udf8e\udb60\udd2a\uda93\udee4\ud84e\udd6e\ud822\udd2c\ud968\ude5a\ud9ba\ude3b\udab5\udeea\uda03\udf8d\ud8a2\udd39\udafb\udc46\udac6\udc65\ud93d\udfe5\uda33\uddb0\ud8ae\udded\udb44\udde1", "\u2d41\u48f4\u74b4\u15fb\u6981\u0818\u03f0\ubd75\u73ae\u48d9\u5920\u1e9f\u94fe\u8f12\ub7d5\u413f", "\uda15\uddc7\ud82c\udd60\udb0c\udccf\ud9b6\udd48\u3957\uda9a\udece\ud86f\udf91\udad2\udf54\uda05\ude0d\ud860\udfc2\ud900\uded7\udb93\ude8c\ud915\udc6c\ud854\udd07\u390b\ud9af\udec9\ud8f1\udc02\ud9b0\ude9f\uda61\udc25\uda2d\ude4c\ud872\udfb5\ud9cf\udc5f\udaf3\udce6\ud884\uddb4\udb39\udf8e",
        38, 19629, 1525589040, 8210196506077178156L, 35895L, false, false, (char) 2159, (char) 43096,
        Double.longBitsToDouble(0x3fac993eb5d34ad0L), Double.longBitsToDouble(0x3fce5285a6a22e38L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 18, 8, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udf80\udb66\udce6\udadb\udd63\udb54\udd33\uda1e\udf3c\udaca\udfeb\udba8\udc9f\uda5b\ude37\udb7b\udf11\ud8d2\udc25\ud81d\udfcf\ud83b\uddeb\ud810\ude44\ud947\udd53\ud87a\udc95\ud9f9\udcc8\udafb\udc95\ud926\udd7b\ud901\udf3f\udb87\udd4b\ud848\udcb3\udb1b\udf78", "\u3ae3", "\u7b5c\ud91b\udc39\udabe\udda3\ud94d\udd03\uda73\udd66\uda5e\udc21\udb11\udccd\ud872\ude91",
        -2, 19570, 1135061698, -356451055466504203L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e91c727700L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 1, 1, 12, "\udb2d\udfa9\udaaa\udf88\uda4d\udfc2\udb49\udcf3\udb3d\udf0b\udbc2\udd70\ud99d\udc8e\ud97f\udea5\udba8\udc9f\udaa7\uddc1\uda31\udecd\ud8a8\uddcd\ud82b\udea9\uda15\udc57\ud97b\udeba\udab5\udeed\uda03\udf8d\udb24\ude79\udaec\udff5\udb8a\udd6e\udaaa\udcb4\udb62\udca8\udae4\udd80\ud9ea\udd6c\uda54\ude12\ud9c3\udf3b", "\u7ebc\u04b4", "\ud825\udf78\ud850\ude8f\ud8c9\ude15\ud8be\udcde\udaf9\udf54\ud92f\uddca\ud9d2\uded3\udabd\udc67\udae0\udf12\ud81f\udf23\ud9c0\udda6\ud8b8\ude50\ud940\udf50\udbc4\udc8e\ud957\udf64\ud9b6\udce6\udaf9\uddc6\udb7e\udfbb\ud9ac\udcfd\udb4f\ude0e\udac1\udcad\udaaa\udd51\ud9bc\udcf5\uda43\udc63\ud804\udd33\uda01\udeb0\udac0\udf92\ud862\udd37\udb79\udec8\uda4d\udebf\ud963\ude37\ud95b\ude2b\uda93\udca3",
        38, 43269, -426750182, 6547255620225906794L, -9080L, false, false, (char) 45813, (char) 35486,
        Double.longBitsToDouble(0x3fd8ddb76a6cbd9cL), Double.longBitsToDouble(0x3fe00874d774109aL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 17, 2, 12, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\udbbb\udfe7\ud99d\udc8e\udaca\udfeb\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3\u21da\u7e9a", "\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud9e3\udd78\ud9d2\uded3\udaa5\udebe\ud954\udd5c\udb15\udcda\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\ud846\udec9\ud8ef\udec9\udbeb\uddcc\ud967\udce3\udbdf\udc28\ud902\udd19\u9fae\ud831\udc11\udb5d\udea5\udb92\udd81\ud95f\ude1b\udb02\udebb\ud99e\udf21\ud9d7\uddc1\udbdc\udff6\ud97b\udcf0\udb58\udeb5\udbf5\udd82\ud967\udc24\ud9da\uddae\udaba\udc0b\ud96c\udc95",
        8, 46743, 103414333, 1994362016508017209L, -57071L, false, false, (char) 871, (char) 6558,
        Double.longBitsToDouble(0x3fea6424bedfffa0L), Double.longBitsToDouble(0x3fd75e5765e10b42L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 3, 19, 2, "\udb2d\udfa9\udacc\udc2f\uda44\udcc3\udb66\udce6\udadb\udd63\udbbb\udfe7\ud99d\udc8e\udaca\udfeb\ud9ef\udc43\uda59\udc4b\ud843\udf15\ud97e\udd66\ud81d\udfa9\ud925\udde0\ud810\ude44", "\u8f3f\u8771", "\udb5b\udc3b\uda03\udf72\udb1b\udf78",
        45, 75119, 1311352791, 5050979148311860956L, 57336L, false, false, (char) 28380, (char) 47942,
        Double.longBitsToDouble(0x3fc057656fca1eb0L), Double.longBitsToDouble(0x3fc4c5945e40f49cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 18, 2, "\uda10\udc11\ud8f2\uddeb\uda4d\udfc2\ud8cb\ude23\ud897\udffa\ud9f0\uddef\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\udbb9\udde4\uda0a\udde0\ud83b\udde5\ud810\ude44\udab5\udeea\ud8ed\udd81\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\uda73\udd7e\uda1c\udf86\udb1b\udf78", "\u8b39", "\ud872\udec5\udbbc\udfa4\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        -2, 90186, 1135061698, 9132120742180242272L, -30515L, true, true, (char) 51060, (char) 36812,
        Double.longBitsToDouble(0x3fe7df6f1a6be30bL), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 2, "\udb2d\udfa9\ud8f2\udd99\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\ud810\udd37\udac0\udcec\ud8bc\udf29\udafb\udc95\ud926\udd7b\uda34\udc84\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud872\ude6b\ud848\udc89\ud95e\ude2f\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        2, 90186, 1135061698, -572623837580277197L, -30515L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7dd13c26be30bL), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 18, 8, 5, "\udb2d\uded8\ud87a\udfe6\udb22\uddd1\uda97\udc18\ud81f\udc45\ud820\ude9c\udb76\udc2a\udac7\ude37\uda4c\uddc0", "\u7602\u81e7\ubc7a\u5444\u9e6a\u8fab\u35d5\u4f67\u9316", "\uda03\udf72\udb1b\udf78\udb5f\udca3",
        20, 52000, 1176022726, 4669587247047202407L, 48881L, false, false, (char) 16300, (char) 11012,
        Double.longBitsToDouble(0x3fd288206556ef02L), Double.longBitsToDouble(0x3fdec71f65a25fceL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 16, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\ud877\uddbe", "\000", "\ud8d7\udeee",
        37, 90367, -1199142111, 0L, -24402L, false, true, (char) 54570, (char) 0,
        Double.longBitsToDouble(0x3fe844200682c399L), Double.longBitsToDouble(0x3febfb40764099edL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 12, "\u82e4\ud9f2\ude39\ud916\udfa6\udbbc\ude09\udb7c\ude69\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\000\ud82b\udc55\000\ud83b\uddeb\udab8\udd43\udab5\udeea\ud927\udd5f\ud8bc\udee1\udafa\udfe9\ud926\udd2d\uda34\udcd9\u68b8\uda03\udeef\udbdc\udef8", "\u9497", "\ud84d\udd1b",
        16, 75800, -273465178, 12261895406878720L, 96608L, false, true, (char) 55899, (char) 37146,
        Double.longBitsToDouble(0x3fda743a70000000L), Double.longBitsToDouble(0x3e12600000000000L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=org.joda.time.chrono.GJChronology:GJChronology[UTC]\012",
        Z.run(T, 2, 12, 12, 12, "\u82e4\ud9f2\ude39\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\000\ud82b\udc55\000\ud83b\uddeb\udab8\udd43\udab5\udeea\ud9f7\udc31\udb9c\udc56\udafb\udc00\ud926\udd2d\uda34\udcd9\udb87\udd4b\uda03\udf72\uf308", "", "\ud940\udd60\ud97c\udf71\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda30\udd23\000\000",
        30, 59576, -868843204, 4875052871852269991L, -100000L, true, false, (char) 64718, (char) 51257,
        Double.longBitsToDouble(0x3fde1d5ea5f7dbc6L), Double.longBitsToDouble(0x3fe47f1995c38636L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 19, 18, 2, "\ud962\udedf\udbe1\ude19\u6df4\udb07\udf47\ud91b\uddbb\u0229\udada\udc0b\ud88a\udf2f\udb24\udc45\udafd\udf68\udb08\udcc4\ud88b\udcff\udb88\udcaa\ud851\udea5\uda9a\ude17\udac5\udd0a", "\u8e6b\u496c\u8106", "\udbb5\udf98",
        39, 45825, -1239741262, 8726224594782560280L, 19505L, false, false, (char) 1919, (char) 13597,
        Double.longBitsToDouble(0x3fe09f8733f2a8e6L), Double.longBitsToDouble(0x3fc4c5944bc0f49cL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=3]\012",
        Z.run(T, 2, 4, 4, 18, "\udb2d\udfa9\ud8f2\uddc3\udb52\udf48\udb66\udce6\udac8\udcd0\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\ud810\ude44\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ud915\ude49", "\u3ae3\u21da\u8b0c\u2901\u03da\u8a02\u5d1c\u378d\u41ab\u4367\u5920\u4d7e\u9679", "\udb1f\udf18\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\ud80d\udfdc\uf3cc\uda9c\udc9c\ud8fb\udc72\ud870\udd18\udb25\udf9b\ud92d\udfbe\ud80f\ude5c\ud8b4\ude4c\uda26\udc1b\ud9ba\udf98\uda98\udf54\ud93e\uded7\uda39\udc8e\uda53\udd5a",
        3, 95851, 821985989, -7374555447057303142L, -70681L, false, true, (char) 57871, (char) 60297,
        Double.longBitsToDouble(0x3fd75f2f138a5f26L), Double.longBitsToDouble(0x3fe4f758d01ac81eL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=87087654-03-18T22:45:20.652Z,mdfw=3]\012",
        Z.run(T, 2, 4, 18, 18, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\udaee\udc64\ud813\uded2\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ud915\ude49", "\u3ae3\u21da\u7e9a\u4254\u39fe\u8a02\u5d1c\u378d\u41ab\u48d9\u5920\u4d7e\u9679", "\uda80\udee9\ud9c0\udd5a\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud855\udc77\udb8b\udecf\ud951\udef3\u6914\uf3cc\uda9c\udc9c\ud8fb\udc72\ud870\udd18\udb00\udcea\ud92d\udfbe\ud80f\ude5c\ud8b4\ude4c\uda26\udc1b\ud9ba\udf98\uda96\udf54\ud93e\uded7\uda39\udc8e\uda53\udd5a",
        3, 95851, -1380376379, 2748158756577920652L, -70681L, false, true, (char) 57871, (char) 60297,
        Double.longBitsToDouble(0x3fc3ab2e44d8bdd0L), Double.longBitsToDouble(0x3fe4f758d6ed791eL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 12, "\udb2d\udfa9\ud8f2\uddc3", "\u754e\u7066\uc0dd\u6cfd\u7bf3\u7972\u120f\ucb56\uce6d\u0fd9", "\uda9f\udd9b\ud8bc\udec5\udafb\udc95",
        39, 51354, 327935013, -8914762498320031018L, -3860L, false, false, (char) 64750, (char) 56563,
        Double.longBitsToDouble(0x3fe6b97846e54770L), Double.longBitsToDouble(0x3fe5873ef06eff6dL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 6, "\000\udbe7\udd32\udb05\ude00\u9f10\ud931\udf57\ud950\udfee", "\u86f8\u9cfb\u1291\ua144\u65e4\u61c6G\u9e6a", "\udafb\udc95\ud926\udd7b\uda2f\udd77\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb\ud9f0\udee7\uda32\udda1\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud808\udf89",
        36, 75626, 1788914, 23381325539723008L, -29863L, false, true, (char) 43114, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe038c80100005fL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18", "\ud1e7\u0875\u017d\u8561\u7bf3\u29b0\ubcfd\u81d8\uce6d\u6661", "\000\ud8bc\ude83",
        -5, 91446, 766677553, 1408470155626824637L, 4830L, false, true, (char) 46, (char) 64951,
        Double.longBitsToDouble(0x3fe6e230c6d72f08L), Double.longBitsToDouble(0x3fe4c29f8eaad2deL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192365828-11-03T14:32:04.180Z,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8", "\udafb\udc95\ud831\udc57\ud989\udce2\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a\ua2e7\ud9f0\udee7\uda32\udda1\ud97c\udfc9\ud8e0\udc9a\ud8c6\udee4\u00a1",
        2, 63026, -361652246, 6070417059969124180L, -34154L, false, false, (char) 58124, (char) 46290,
        Double.longBitsToDouble(0x3fe80230daea8ce3L), Double.longBitsToDouble(0x3fbd8d471b7fdd08L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192365828-11-03T14:32:04.180Z,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud8d4\udd14\ud8d5\ude03\ud9be\udeb4\udbb4\udf2f\udaeb\udcdf", "\u7bf3\u288d\ubcfd\u81d8\uce6d\u6661\u6e1c\u66a8", "\udafb\udc95\ud989\ude96\ud989\udce2\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a\ua2e7\ud9f0\udee7\uda32\udda1\ud97c\udfc9\ud848\udfef\u400a\u0f86",
        2, 18909, -361652246, 6070417059969124180L, -17191L, false, false, (char) 18484, (char) 59487,
        Double.longBitsToDouble(0x3fca1b2f02350b40L), Double.longBitsToDouble(0x3fdad04a9cf5f08eL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=225184782-07-07T19:08:03.471Z,mdfw=3]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udbf1\udd33\ud800\udc74\ud9f1\udffb\ud81d\udfa9\uda30\udfc4\uda5f\udd51\udaa7\udf28\uda0c\udc51\uda84\udcff\udafb\udc35\ud831\udc57\ud989\udce2", "\ua128\u53cc\uc623\u6bd1\u21da\u7e9a\u4254\u811a\u7251\ub12c\u4350\ua6f8\ua67e\u97ff\ub86e\u8c1a\u1898\ubd9a\ube8f\ud68f\ua693", "\ud880\udc86\ud940\ude79\ud8e2\ude16\ud823\udfbe",
        3, 56019, -1268797630, 7106083205742483471L, 11435L, true, true, (char) 31059, (char) 45840,
        Double.longBitsToDouble(0x3f9325b8ebe4d200L), Double.longBitsToDouble(0x3fe77f369c07973bL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 5, 0, "\uda38\ude31\uda6c\uddec\uda3b\ude7a\ud904\udeb7\udbb4\udf2f\ud997\udde3\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a",
        26, 78726, 772314844, 6048710533641561752L, -79122L, false, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fc10a3dcbf3778cL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=228869447-08-16T09:40:48.598Z,mdfw=3]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\ud8a6\udc88\ud81c\udd18\udb49\udec6\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u7e7b\u476f\u2436\u0f2a\ud258\u9aec", "\udb87\udd4b\udbda\ude41\ud830\udfd2\ud9e4\udc29\ud816\udda9",
        3, 45920, 283624282, 7222360005682848598L, -79122L, false, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fc10a3dcbf3778cL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191677999-04-28T17:49:49.080Z,mdfw=5]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\uf873", "\u6661\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a",
        5, 72175, 789092060, 6048711256873789080L, -79122L, true, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fe7c094f71c4204L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda38\udcdb\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a",
        26, 78726, 789092060, 67930950805225472L, -79122L, false, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fc10a3dcbf3778cL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191677999-04-09T07:47:47.480Z]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\udb7e\udf5a\ud938\ude54\udbb4\udf2f\uda8b\ude8e\ud84c\udf1d\u6452\udb99\udd9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8\u23db\u73c1\u2a7e", "\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud9cb\uddd3",
        4, 75183, 789092060, 6048711255196067480L, -79122L, false, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fc10a3dca7c8d4cL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=189693752-09-24T06:13:32.500Z,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u20f0\u6e2e\u66a8\u8470\ud258\u9aec\u8021\u305a\u8b4f\u0df6\ua128\u53cc\uc623\u6bd1\u21da\u7e9a\u4254\u811a\u7251\u18b4\u4350\ua6f8", "\uf428\ud974\ude85\udab5\udf64\uda15\udc48\u2b91\ud95f\ude6a\ud819\udc42\uda71\udfc3\ud807\udf88",
        2, 52926, 479638376, 5986094482448012500L, -22868L, false, false, (char) 27807, (char) 11381,
        Double.longBitsToDouble(0x3feb787c28a95991L), Double.longBitsToDouble(0x3fdd69ec665ed68eL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=19454472-07-11T17:59:13.727Z,mdfw=6]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 6, "\udb3f\udd14\ud8f2\uddc3\uda4d\udfc2\udac4\uddf5\udadb\udd63\uda18\udef1\ud80f\udf06\uda0e\udfd1\uda58\udced\udb39\udd2a\udb7b\udf11", "\u0fd9\u6e1c\u5ab5\u8470\u367e\u18e9", "\ud9e1\udd80\udb54\udc42\ud81a\udc31\udb5f\udca3\ud816\udd7b\ud4cd\udb08\udf55\ud88a\udc31\ud8e8\udf30\ud899\udcba\uda36\udff3\ud98e\udf0b\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda5d\uded4\uda8a\uddec\udae9\uddca\udb80\udf8d\udbd7\udde0\ud87f\ude0c",
        6, 64887, 127734964, 613861688570353727L, -38515L, false, true, (char) 14111, (char) 52793,
        Double.longBitsToDouble(0x3fe79381ee640f25L), Double.longBitsToDouble(0x3fe546b22fb476f0L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 9, 9, "\udb3f\udd14\ud8f2\uddc3", "\u754e\u523a\ua7ce\u7671\u7bf5\u7972\u120f\ucb56\u9c28\u707f", "\uda03\udf8d\ud8bc\udec5",
        -5, 47014, -721087646, 1408470156360611517L, 57314L, true, true, (char) 2259, (char) 15460,
        Double.longBitsToDouble(0x3fe16d4aeed72f08L), Double.longBitsToDouble(0x3fe4c29f8eeb2cdeL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 0, 12, "\udb3f\udd14\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\udaaf\udf20\udb7a\udfa0\000\000\ud874\udd79\ud913\udf5d", "\000", "\uda03\udf8d\ud8bc\udec5",
        58, 47014, -721087646, 158918508544L, 4830L, true, true, (char) 237, (char) 0,
        Double.longBitsToDouble(0x3fe6e230c6000008L), Double.longBitsToDouble(0x3fe4c29f8eeb2cdeL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=222386956-04-15T20:57:57.972Z,mdfw=7]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 15, "\udb3f\udd14\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\udaaf\udf20\udb7a\udfa0\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u8547\u808f\uc588\u8470\ud258\u7841", "\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\u62ec\udbbf\udda6\u8227\ud97c\udf65\ud8f9\udd11\ud917\uddc3\ud98e\udf0b\uda4d\udd12\ud8c9\ude58\udafb\ude87\uda55\uded9\ud87b\ude68\ud9f7\udc91\udba5\udc65\udb9a\uddff\ud973\udfd0\udbed\udc5b\ud82f\udf7a\ud952\ude6e\udb23\udca4\uda97\udd4d\uda93\udd81\ud927\udd1e\udb62\udd57\ud80b\udde1\udb48\udddb\ud807\ude96\u2f41\ud8f6\udc2c\ud83e\udedd\ud9e9\udd58\ud8ff\udfc8\ud8ca\udcb3\ud8ae\udd1e\udb9b\udf10\ud9d4\udc67",
        7, 14013, -955195620, 7017792337861077972L, -11011L, false, true, (char) 32028, (char) 60562,
        Double.longBitsToDouble(0x3fed61673af93462L), Double.longBitsToDouble(0x3fe5d1dc169d5893L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=160061127-06-09T03:57:40.956Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 18, 17, 7, "\uda12\uddfe\udb59\udfb6\ud906\udcbf", "\u4040\uc0fd\ub4f0\u7bf3", "\uda53\udcbc\ud829\udcd7\udbae\udd44\ud8da\udc4f\udab8\ude53\uda03\udf8d\ud898\ude42\udafb\udc95\ud926\udd7b\uda7d\udd56\udb87\udd4b\uda03\udf72\udb1b\udf78",
        5, 64347, 1311336000, 5050979148311860956L, 4808L, true, false, (char) 61801, (char) 3833,
        Double.longBitsToDouble(0x3fd33c5127e550c2L), Double.longBitsToDouble(0x3fc4c5945e40f49cL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 5, 15, "\udb3f\udd14\ud98e\udf31\ud8a6\udc87\udb66\udce6\udadb\udd63\udaaf\udf20\udb68\udca0\udac7\uddce\u4d9f\udb39\udd2a\udb7b\udf11", "\u0f7b\u6e37\u66a8\u846e\ud258\ua7ed\u9390\u3871\u8b4f\u841b\u3372\ube4e", "\ud9f0\udee7\uda32\udda1\ud97c\udfc9\udba4\udd3c\ud956\udd22\ud98e\udf0b\uda4d\udd12",
        56, 63834, 1025966246, 7935984176867902927L, -35155L, false, true, (char) 7474, (char) 50603,
        Double.longBitsToDouble(0x3fed7c71e94f6db6L), Double.longBitsToDouble(0x3fd56b167de34b86L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 10, "\udb3f\udd14\ud8fe\uddc3\uda4d\udfc2\udb66\udce6\ud970\udfd8\udb17\udc1e\udb2f\uddd4\udac7\uddce", "\u120f\ucb56\uce6d\u0fd9\u6e1c\u66a8\u8470\ud258\u9aec\u9316", "\uda03\udf72\udb1b\udf78\udbca\udc88",
        20, 52000, 1243131590, 3389135281296660183L, -82641L, true, false, (char) 42069, (char) 46407,
        Double.longBitsToDouble(0x3fe331e93cd46894L), Double.longBitsToDouble(0x3fe3ef2da9266593L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=169194784-06-15T03:26:15.189Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 1, 7, "\udb3f\udd14\ud8fe\uddc3\uda4d\udfc2\udb66\udce6\ud970\udfd8\udb17\udc1e\udb2f\uddd4\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u0fd9\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        1, 64375, 1311336000, 5339209524463575189L, 14776L, true, false, (char) 61289, (char) 39767,
        Double.longBitsToDouble(0x3fe71a5563f2a863L), Double.longBitsToDouble(0x3fc4c5945998f49cL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=169194784-06-15T03:26:15.189Z,mdfw=1]\012",
        Z.run(T, 2, 0, 18, 5, "\udb3f\udd14\ud8fe\uddc3\uda4d\udfc2\udb66\udce6\ud970\udfd8\udb17\udc1e\udba4\udd4e\udac7\ude48\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u0fd9\u7e5c\u2912\u725c\ud258\u343c", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        1, 64375, 1311336000, 5339209524463575189L, 14776L, true, false, (char) 61289, (char) 39767,
        Double.longBitsToDouble(0x3fe71a5566f2a863L), Double.longBitsToDouble(0x3fc4c5915998f49cL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=169194784-06-15T03:26:15.189Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=3]\012",
        Z.run(T, 2, 18, 4, 8, "\uda15\uddfa\uda3a\udc77\uda4d\udfc2\udb66\udce6\ud970\udfd8\udb17\udc1e\udb2f\uddd4\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\uda5f\udd51\udba8\udf4a", "\u9aec", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        3, 64390, 1311336000, 5339209524463575189L, 16862L, true, true, (char) 61260, (char) 39767,
        Double.longBitsToDouble(0x3fe71a5563f2a863L), Double.longBitsToDouble(0x3fc4c5945998f478L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=48270720-12-15T04:20:44.667Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=1]\012",
        Z.run(T, 2, 18, 4, 14, "\udb3f\udd14\ud8fe\uddc3\uda4d\udfc2\udb66\udce6\ud970\udfd8\udb17\udc1e\udb2f\uddd4\udac7\uddce\udba8\udc9f\udb39\udd2a\udb90\udc11", "\u0fd9\u6e1c\u66a8\u8470\ud258\u6249", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        1, 64375, -886479296, 1523214656943644667L, 14776L, true, false, (char) 61289, (char) 39767,
        Double.longBitsToDouble(0x3fe71a5563f2a863L), Double.longBitsToDouble(0x3fc4c5945998f49cL)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 9, "\udb33\ude34", "\u5eb6\u00eb\uacd7\u4834\u36e3\u7bf3\u7972\u120f\u9f30\u80cb\u4e36\ub73d\u24ea\u0ba3\u31bd\ub313\u9147\u8f71\uc8a4\u4255\u936e\u33bd\u9bd9", "\ud8b3\udf75\udae6\udf9f",
        47, 50683, 1472394638, -7834835297943433501L, 12499L, true, false, (char) 46782, (char) 4263,
        Double.longBitsToDouble(0x3fc07acb3da19bc4L), Double.longBitsToDouble(0x3fe7f7e35c970d64L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=268933907-05-29T23:19:51.545Z,mdfw=3]\012",
        Z.run(T, 1, 2, 6, 14, "\udb3f\udd14\ud8fe\uddb6\uda4d\udfc2\udb66\udce6\ud954\udfd8\udb17\udc1e\udb2f\uddd4\udac7\uddce\udba8\udd56\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\uda5f\udd51\udaa7\udf28\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udbca\udc88\ud816\udd7b\ud892\udedb\udb68\udf23\uda34\udf5a\udb8f\ude73\udb9a\ude4c\ud956\udd22\uda27\udeb6\uda20\udc35\ud8e0\uddb9\ud983\ude93", "\ube78\ud7a4\u06e2\u8341", "\ud9ea\ude5e\ud86a\udff9\ud821\udf0d\ud857\udfc5\ud882\udefb\uda45\uddeb\udba6\udd66\u3fff\ud86a\udd59\udb67\udf5b\uda79\udef1\ud93d\udc97\ud868\udddb\udb7d\udc43\udb23\udc84\u8fe7\udadc\ude5a\ud877\ude00",
        3, 93677, 664526195, 8486672239984791545L, 83824L, true, true, (char) 21612, (char) 9648,
        Double.longBitsToDouble(0x3fe688438f01ebffL), Double.longBitsToDouble(0x3fe1b8545d6dc506L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 0, 2, "\udafc\udef5\ud8f2\uddc3\uda4d\udfc2\ud82c\udd11\udbe9\udd92\ud820\udea3\udb7a\udf80\udaa3\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud842\udd4a\ud81d\udfa9\udb2b\udd9a\ud832\udc5c\ud827\udca2\uda03\udf8d\ud8b6\udec5\udafb\udc95\udbac\udda3\ud896\udda3\udb76\udef6\uda03\udf72\ua51f", "\u3ae3\ud218\ucf7c\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920\uc213\u5506\u6bee\ub83b\u413f", "\ud940\udf50",
        15, 65153, -483235077, 897397661667734359L, -87835L, true, false, (char) 12545, (char) 18209,
        Double.longBitsToDouble(0x3fd8e635d4f52c6eL), Double.longBitsToDouble(0x3fefb9ddcf5126faL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\ud9a7\udfa6\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\ud803\udca8\ud8cc\udfb2\udba8\udc9f\udb39\udd2a\uda93\udee4\ud8af\udf9e\uda81\udf1b\uca9f\udab2\udd5d\udb58\udf5c\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ua51f", "\uc084\u411d\ub944\u3cfc\u5aaf\u1c25\ucb16\u378d\u73ab\ucba2\u5920\u1e9f", "\ud83a\udd2f",
        3, 45498, 495120531, 4906917315119579997L, -9048L, true, false, (char) 38014, (char) 32856,
        Double.longBitsToDouble(0x3fa96a8fa0074c30L), Double.longBitsToDouble(0x3fc2740f30c6ebc0L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=266621112-09-22T19:15:41.696Z,mdfw=7]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\u1d2c\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ua51f", "\u3ae3\u21da\u7e9a\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920\u1e9f\u9679\u52f1\ub83b\u413f", "\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48",
        7, 38909, -719381461, 8413687489259741696L, 60719L, false, true, (char) 30897, (char) 18352,
        Double.longBitsToDouble(0x3fea8937d20a297cL), Double.longBitsToDouble(0x3fef200e648d38a9L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud8a7\udf5c\uda34\udcd9\udb87\udd4b\uda03\udf72\ua51f", "\u3ae3\u21da\u7e9a\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920\u1e9f\u9639\u52f1\ub83b\u413f", "\ud909\udc03",
        15, 65153, -483235077, 897397662588654603L, -62162L, false, false, (char) 14677, (char) 18209,
        Double.longBitsToDouble(0x3fd8e635d4f52c6eL), Double.longBitsToDouble(0x3fefb9ddcf5126faL)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 12, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\uda92\udfea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ua51f", "\u3ae3\u21da\u7e9a\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920\u1e9f\u9679\u52f1\ub83b\u413f", "\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48",
        15, 38803, -721420245, 8413687490870354432L, 1425L, false, true, (char) 38455, (char) 18167,
        Double.longBitsToDouble(0x3fea8937d20a297cL), Double.longBitsToDouble(0x3fef200e648d38a9L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=266621112-09-22T19:15:41.696Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ua51f", "\u3ae3\u21da\u0526\ua18d\u0b0c\u8a02\u5d1c\u378d\u73ab\u48d9\u5920\u1e9f\u9679\u52f1\ub83b\u413f", "\ud940\udf50\ud82c\udce2\udb0c\udccf\uda69\udd61",
        3, 5771, -719349622, 8413687489259741696L, 60719L, false, true, (char) 30854, (char) 18352,
        Double.longBitsToDouble(0x3fea8937d20a297cL), Double.longBitsToDouble(0x3fef200e648d38a9L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\ud9c2\ude95\ud8f2\uddc3", "\u5cd9\u7022\uc0dd\ub4f0\u7bf3\u7972\ua681\ucb56\uce6d\u8bb4", "\uda1a\udce2\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ua51f\uda6d\udd51\udbd9\udd68\ud892\udedb\ud9f0\udee7\uda32\udda1\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe",
        43, 94723, -920265502, 2126526488701951821L, 7008L, false, false, (char) 18209, (char) 49387,
        Double.longBitsToDouble(0x3fe3d4b1bbf73bb9L), Double.longBitsToDouble(0x3fea8937d20a297cL)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=107399052-12-25T11:59:55.095Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 18, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce", "\ua681\ucb56\uce6d\u8bb4\u025d\u9e6a\u8470\ud258\u9aec\u9316", "\uda03\udf72\ua51f\uda6d\udd51",
        5, 52000, 1176022726, 3389124592641595095L, 48816L, false, false, (char) 39124, (char) 54701,
        Double.longBitsToDouble(0x3fef954318a62ca2L), Double.longBitsToDouble(0x3fec81e93bda6b34L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=266621140-03-21T06:38:55.488Z]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ua51f", "\u3ae3\u21da\u7e9a\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920\u1e9f\u9679\u52f1\ub83b\u413f", "\ud940\udfa2\ud82c\udce2\udb0c\udccf\udbbb\udc16",
        4, 24995, 1164289098, 8413688356843135488L, 60719L, false, true, (char) 30897, (char) 18352,
        Double.longBitsToDouble(0x3fea8937d20a297cL), Double.longBitsToDouble(0x3fef200e648d38a9L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 10, "\uda13\udf7c", "\u64e4\u5cd9\u0d70\u2aca\ua140\ud085\u7b8a\ua681\u7602\u0102\u497e\u1484\ubb91\ucd3d\u2348\u3b49\u55f8\u057d\ua5ee\ua09b", "\ud834\udfa6\uda92\udc04\ud90b\udd05\ud916\udd20\udab8\udf8c\ud950\udeb2\udbf9\uddd5\ud95f\ude60\udb1a\udd31\ud81c\udf91\ud925\udccd\udbd0\udd92",
        36, 56569, -1537300810, 8572457144320366479L, -40457L, false, false, (char) 23371, (char) 8188,
        Double.longBitsToDouble(0x3fdd3cdbea6200f2L), Double.longBitsToDouble(0x3fef5aaccbbb881aL)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=21789250-01-31T15:49:04.106Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 0, "", "", "\udb1f\udd70",
        3, 29944, -1126256432, 687540151871344106L, 30521L, false, false, (char) 49628, (char) 34426,
        Double.longBitsToDouble(0x3fb3bfa19b112228L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=90300580-10-12T17:34:14.067Z,mdfw=7]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud801\udf00\uda4d\udfd2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud817\udd60\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\udbe6\uddb1\uda13\udfa6\ud833\uddff\uda03\udf72\udb1b\udf78", "\u3ae3", "\ud97c\udfc9\udbc1\udd2b\ud95e\udea7\udb4b\udc4a\uda4d\udcf9\ud8c9\ude58\ud9b8\uddbb\uda1a\udc5c",
        7, 90186, 1135061698, 2849548926130454067L, 62122L, true, true, (char) 51060, (char) 36811,
        Double.longBitsToDouble(0x3fe7df6f1a6be332L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=262769454-04-13T04:33:28.816Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud801\udf00\uda4d\udfd2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\udbe6\uddb1\uda13\udfa6\ud833\uddff\uda03\udf72\udb1b\udf78", "\ubeff", "\ud97c\udfc9\ud9e1\ude3b\udadf\udce2\udb4b\udc4a\uda4d\udcf9\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\uda52\udffb\uda00\udc13\udb3f\udf50\ud89a\udf07\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\uda02\udfc8\udbb7\udef2\uda2b\udd85\udbe2\udc87\uda00\udd95\uda75\udcf7\uda14\udc08\ud88e\udf17\ufb36\ud93c\ude0f",
        2, 57354, -2107900475, 8292140888589208816L, 10280L, false, false, (char) 31658, (char) 61979,
        Double.longBitsToDouble(0x3febeac42c548626L), Double.longBitsToDouble(0x3fbfb73ee9276d90L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\uda09\udc0a\udb1d\udee1\uda92\udd5e\ud83a\udf98\u5a0b\udb15\udd6d\udb36\udec2\udafb\udc95\udbd3\uddce\uda34\udd21\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u2435", "\ud93c\udf0e\udbc1\udd2b\ud921\udca8\ud94f\udd19",
        36, 34986, 748878834, 4436609297676519312L, 65694L, true, false, (char) 27409, (char) 12265,
        Double.longBitsToDouble(0x3fefcddbee3f8bebL), Double.longBitsToDouble(0x3feaea9cd1e1d5eaL)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9", "\ub524\u5cd9\u7022\uc0dd\ub4f0\u7bf3\u33d1\uaf2b\ucb56\uce6d\u8bb4\u025d\u8b21", "\udafb\udc95\ud90e\udd6f\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud9e7\udc86\ud9ee\udf15\uda32\udda1\ud93c\udf0e\udbc1\udd2b\ud921\udca8\ud825\udfcf",
        36, 75626, 748878834, 4436609295881357200L, -100000L, false, false, (char) 0, (char) 12265,
        Double.longBitsToDouble(0x3fefcddbed3f8bebL), Double.longBitsToDouble(0x3fe80220c1e1d5eaL)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 18, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udab3\udf6d\udb34\udcbd\ud820\ude7f\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81e\udc5f\ud8bb\udc04\ud832\udc5c\udab5\udeea\udacc\udfdd\udb36\udec3\ud807\udc9b\ud90e\udd6f\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u4fb7", "\udb16\udd96\udbc1\udd73\ud921\udca8\ud848\udfcf\uda4d\udd12",
        56, 63834, 1032978598, 7724877943779294170L, 76963L, true, false, (char) 35227, (char) 3049,
        Double.longBitsToDouble(0x3fd3f8beb6ba8830L), Double.longBitsToDouble(0x3fde1d5ea5f7dbc6L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=44955548-11-11T17:40:31.565Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\uda1c\udd81\ud820\uddf4\udb7a\udf80\udac7\uddce\uda68\udc9f\udb39\udd2a\uda93\udee3\ud84e\udd6e\ud82e\udfff\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\uda14\udef3\ud893\udcfa\udb87\udde3\uda03\udf72\udb1b\udf78", "\u81e7\u3110\ucd3f\u88c4\u3883\ube61\u5dab\u378d\u73ab", "\udbea\udd4d\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 813887635, 1418597930396431565L, -96838L, false, true, (char) 17574, (char) 33031,
        Double.longBitsToDouble(0x3fe84e658b6c4abeL), Double.longBitsToDouble(0x3fb3616220fe3c98L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 2, 2, "\ud8f2\udfcd\uda19\udfc7\uda4d\udf22\udb66\udce6\udbec\udd48\ud849\udcf4\udb7a\udf80\udac7\uddce\uda68\udc9f\udb39\udd2a\uda93\udee3\ud84e\udd6e\ud81d\udfa9\uda5b\udff3\uda1a\ude2f\udb43\udf97\uda03\udf8d\ud8bc\udec5\udafb\udcde\uda14\udef3\ud893\udcfa\udb87\udde3\uda03\udf72\udb1b\udf78", "\u81e7\u805e\u48fd\u88c4\u12d6\ube61\u5dab\u2518\u73ab", "\uda73\udf8d\udae4\udccc\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\ud9c0\udda6\udba8\udec8\ud915\uddb0\udabb\uddc0\ud817\udc2b\ud914\udc90\udac9\uddbc\uda9a\udeec\udbba\udd24\uda56\udf70",
        59, 10648, -353606625, 4601487397981735611L, -39095L, true, true, (char) 25606, (char) 50132,
        Double.longBitsToDouble(0x3fef5bbf215642bcL), Double.longBitsToDouble(0x3fe193a78c01955dL)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud90c\ude74\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\ud8de\udf36\ud81a\uddb3\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495988-12-28T23:59:03.517Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\u7a6a\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4906917293644743517L, 58459L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=101925948-08-23T22:29:39.110Z,mdfw=7]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=7]\012",
        Z.run(T, 2, 2, 4, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud8f1\udf68\ud99c\udf21", "\u5f44", "\udb2f\uded1\udb52\udd82\udb1e\udda9",
        7, 66607, -1469877374, 3216410101722579110L, 95546L, false, false, (char) 58701, (char) 63040,
        Double.longBitsToDouble(0x3fcc4a72224f2494L), Double.longBitsToDouble(0x3fea68ec135d4418L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=205365504-06-22T01:10:28.219Z,mdfw=3]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 2, "\udb2d\udfa9\ud8f2\uddc3\uda43\udcc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 57886, -842884226, 6480647199853828219L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495981-05-16T05:22:54.941Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, -1182601069, 4906917053126574941L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-15T14:01:26.848Z,mdfw=6]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\000\ud9f2\ude39\uda4d\udfc2\udb66\udce6\udb1f\udd70\u1648\ud846\udc02\udac7\uddca\udba8\udc9f\000\000\031\ud81d\udfa9\ud8bd\udd23", "\u0c71\u0716\u9aec", "%",
        6, 28927, 130, 1260086848L, 96608L, true, false, (char) 10001, (char) 41614,
        Double.longBitsToDouble(0x3fbbbfdb490f7d98L), Double.longBitsToDouble(0x3fe805d95bf2a863L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 14, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\ud86b\udc2c\udb8a\udeec\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 12041, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\000\000\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=53632579-05-06T23:32:03.132Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[UTC]\012",
        Z.run(T, 2, 18, 12, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\ud915\uddf0\ud8bc\udec5\udafb\udc86\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\udb3b\ude8f\uda4c\udefc\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 1692418564855923132L, 24284L, false, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fb3ea60d35e71b0L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 15, 18, "\ud9dd\udda3\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc6\uddd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udbd4\udeca\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=157187297-06-23T08:28:06.365Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udaa9\udcea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud93c\udca7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4960289834324886365L, 3685L, true, false, (char) 57467, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 12, 6, "\uda11\uddfc\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\uda39\udc9d\ud9c7\udf09\udb7a\uded6\ud98f\uddd2\ud966\udd1d\udb39\udd2a\uda97\udcc4\ud84e\ude4a\udbcb\udfa0\ud8bd\udd23\udbb0\udc5b\udab5\udfa5\uda03\udf8d\ud9bf\udfed\ud93f\udcc9\ud926\udd7b\ud8ac\udf65\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\uda15\ude32\ud970\udee8\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        29, 45498, 495120531, 2764892742351487926L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3febfa9e079edeb3L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud9cf\uddef\ud82d\ude0b\ud8bd\udd23\ud832\udc5c\udab5\udeea\ud931\udede\ud86b\udd87\udafb\udc95\ud926\udd7b\uda34\udcd9\udb7e\udc4b\ud81a\udddd\uda3e\udf54", "\u5f44", "\uda19\ude3a\uda47\udc6e\ud95e\ude55\udaa1\udc76\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 11514, 495120588, 4906917315119579997L, 3685L, true, false, (char) 57470, (char) 33093,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\udb00\ude36", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=219431588-10-23T09:32:30.653Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=219431588-10-23T09:32:30.653Z,mdfw=3]\012",
        Z.run(T, 2, 2, 2, 2, "\udb2d\udfa9\ud8ad\udcc0\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud8dd\udc93\ue239\ud8c3\udd11\udba8\udc9f\udb39\udd2a\ud84c\udd40\ud818\udfc3\uc3b2\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda04\udc33\ud8bc\udec5\udafb\udc95\ud926\udd7b\ud963\ude11\udb6f\udc48\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\uddb0\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\ud9dd\udc28\uda81\udfd8\ud83a\udd2f",
        3, 45498, 495120531, 6924529948181550653L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3feb0074c97ed09bL), Double.longBitsToDouble(0x3feca1519dc4deb3L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=156870686-03-15T04:00:23.901Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\ud955\ude13\udb99\udd84\ud903\udf4d\ud9c4\udd49\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud812\udfa9\ud8bd\udd23\ud824\uddef\udab5\udeea\uda22\udc7c\ud852\udfbe\udafb\udc95\udb04\udeef\ud92c\udc2d\udb50\udce6\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4950298547467223901L, -15704L, true, true, (char) 44071, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=3]\012",
        Z.run(T, 2, 2, 4, 11, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\uda7d\udf42\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\u29fb\udaf5\ude6f\ud8c9\uddf0\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=28232593-01-28T12:46:11.293Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\ud9e1\udcf0\ud95a\udd2f\udb57\udd9b\udac7\uddce\udbbb\udde9\udb57\ude12\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud83c\udea7\uda34\udd05\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 78418, 150440151, 890872417399571293L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud975\udec3\ud837\ude7e\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\udbef\udc54\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud917\udcdf\udae4\udccc\udaa5\udebe\udaa9\udf4f",
        2, 72827, -2026962486, 4906917315119579997L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=156780880-01-06T14:03:40.253Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\ud817\udee6\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udaeb\uddea\ud867\udcc5\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, -328863597, 4947464537993020253L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1969-12-23T19:51:55.136Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\ude8f\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\000\000", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, -706084864L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e0500deb3L)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=154486240-06-27T07:29:06.983Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\ud97c\udcf1\udb1f\udd70\ud820\uddf4\udb7a\udf80\ud8a0\ude1a\ud89d\udfd9\udb39\udd2a\uda93\udee4\udae0\udf6a\ud83c\udca9\ud8bd\udd23\ud832\udc5c\udab5\udeea\ud94e\udfb1\ud8bc\udf7c\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda00\ude4f\udb65\udf10", "\u5f44\ubd90", "\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93",
        1, 80304, -856359974, 4875052708510146983L, 22082L, true, false, (char) 64718, (char) 51060,
        Double.longBitsToDouble(0x3fde1d5eaffe27c6L), Double.longBitsToDouble(0x3fe35cee8c0b0c74L)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=110205079-10-20T10:50:02.311Z,mdfw=3]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 2, "\udb2d\udfa9\u75d8\uda42\udc0b\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udaad\udec7\udaf2\ude9e\ud8f7\udc0a\udae8\ude22\ud9ca\udce8\udab9\ude0b\ud82a\ude40\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\ud93c\udcdd\udb87\udd4b\ud81a\udddd\ud99e\ude45", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 3477674246237402311L, 58235L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=154486245-09-19T13:48:46.887Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\ud81a\udddd\u6dc4", "\u5f44\ubd90", "\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93",
        1, 80304, -868811814, 4875052873556926887L, 65349L, false, true, (char) 12220, (char) 32467,
        Double.longBitsToDouble(0x3fde1d54b5f7dbc6L), Double.longBitsToDouble(0x3fe35f19940b0c74L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=13862875-12-01T06:31:03.773Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udabf\udef9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\ud974\udfd5\udaae\udf44\ud8bc\udec5\udafb\udc95\u6dd7\uda34\udcd9\udb87\udd4b\ud81a\udddd\ud985\udfc8", "\u5f44", "\ud975\udc57\udbc1\udcd9\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 437407942689063773L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fd0f0e994d63a38L), Double.longBitsToDouble(0x3feb329e05c4deb3L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=110996188-12-07T18:03:40.004Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=5]\012",
        Z.run(T, 2, 2, 4, 2, "\udbc9\uddb7\ud8e3\udc43\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\ud9bb\uddc8\udba8\udc9f\udb39\udd2a\uda93\udee4", "\u8bb4\u025d\u9e6a\u8470\ud258\u9aec", "\u8cdb\uda0b\udd2c\udbdc\udfe0",
        5, 64375, 1311336000, 3502639239242620004L, 4868L, true, false, (char) 16348, (char) 54409,
        Double.longBitsToDouble(0x3fe415dce3f2cfa4L), Double.longBitsToDouble(0x3fc4c5944243949cL)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=175203236-05-10T21:50:30.903Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udbc9\uddb7\ud8e3\udc43\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\ud83b\udd2a\udb39\udd76\uda93\udee4", "\u8bb4\u025d\u6977\u645d\ud312\u9aec\u9316\u4ac0\u6b1c\u841b\u97ca\u01d6\uc684\u3ae3\u21da\ubf5d\u37f4\u39fe\u8a02", "\ud8f3\udd5c\ud81b\udc7f\uda6f\udf12\ud908\udd2b\ud831\udd09\udb04\udc3a\ud915\udf36\ud8bb\udf96\ud860\udc2d\udb69\udc2a\uda13\udc44\ud851\udc9b\uda1d\ude74\udb4b\udc3f\ud817\udd93\udafa\udc65\ud9b3\udcde\uda70\udf8f\udb27\ude95\uda70\udfbb\ud9f2\udc58\ud848\udcf3\uda9c\udfd5\uda01\udc20\ud90c\udf86",
        5, 33825, -684762791, 5528817952811430903L, 45927L, true, false, (char) 8556, (char) 36614,
        Double.longBitsToDouble(0x3fec03d58a63c76cL), Double.longBitsToDouble(0x3fa43d82736ff080L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\uda85\ude5d\ud905\udc96\uda35\udea9\ud921\uddfa\uda66\udf94\uda3d\udc97\uda77\ude29\uda3e\uddc7\uda34\udcd9\udb29\udd3c\ud9eb\ude1f\udb1b\udf78", "\uaccb", "\ud97c\udfc9\udbc1\udd2b\ud86f\ude4f\ud8ac\uddb5\uda4d\udd79\ud8c9\ude58\ud983\ude93\uda37\udc40",
        14, 90186, 1135061698, 1310080766767734046L, -30515L, true, true, (char) 51060, (char) 36680,
        Double.longBitsToDouble(0x3fdfbede35c16ad8L), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=143448506-02-13T08:18:13.290Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udf56\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udb33\udf64\ud85d\ude63\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\udb09\udfcb\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u41a2\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920", "\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb6e\udfe4\udb84\udcf2\udb2e\udf32",
        2, 8909, 351555708, 4526735454865093290L, 41196L, true, true, (char) 28569, (char) 35250,
        Double.longBitsToDouble(0x3fee36ded3161237L), Double.longBitsToDouble(0x3fd02005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\u1362\udb87\udd26\uda03\udf72\udb1b\udf70\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920", "\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\uda2a\udf02\000\000",
        2, 8909, 20604, 0L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fd02005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=143448506-02-13T08:18:13.290Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=143448506-02-13T08:18:13.290Z,mdfw=2]\012",
        Z.run(T, 2, 2, 2, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920", "\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb6e\udfe4\udb84\udcf2\udb2e\udf32",
        2, 8909, 351555708, 4526735454865093290L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fd02005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=143453698-02-20T17:05:01.098Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\ud9be\uddee\ud809\udf8b\ud972\ude3f\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u2d96\ubf1d\u482f\uc1e8\u3864\u73ab\u48d9\u5920", "\udaa5\udebe\uda4d\udf79\u4002\ud9c0\udce9\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb6e\udfe4\udb6c\udff2\ud807\ude13",
        2, 59501, -2013011670, 4526899299277501098L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fd02005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=113764120-10-21T12:20:44.597Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[UTC]\012",
        Z.run(T, 2, 18, 12, 3, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udce8\ud8f1\udf86\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udaa5\udcea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u4254\u39fe\u8a02\u90aa\u8973\u73ab\u48d9\u5920", "\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\uda17\uded9\ud8b8\ude50\ud940\udf50\ud92f\udda4\udb17\udf48\ud9b6\udd48\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb63\udd03\udbf3\udc4b\ud87b\udc5c",
        2, 8909, 351555708, 3589986732380444597L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fd02005dbd90b7cL)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=143448506-03-13T07:09:54.730Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\udb47\udea0\ud913\udfcc\udb0f\udddf\uda71\udc7a\uda92\udcd7\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u47ca\u39fe\u8a02\u5cdd\u378d\u73ab\u48d9\u5920", "\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud933\udd46\ud82c\udce2\udb0c\udccf\udbd3\udf16\udb84\udee1\uda9a\uddfc\udbdd\udef6\ud8ce\udcb8\udace\udff7\udb84\udc14\udb2e\udf32",
        2, 8909, 351555708, 4526735457280194730L, 41196L, true, true, (char) 28569, (char) 52658,
        Double.longBitsToDouble(0x3fe48f833519f429L), Double.longBitsToDouble(0x3fd02a6febd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=143448506-02-13T08:18:13.290Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=143448506-02-13T08:18:13.290Z,mdfw=2]\012",
        Z.run(T, 2, 2, 2, 12, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\uda02\udf99\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\ud8ec\udc0b\ud816\udd7b\ud892\udedb", "\u4254\u39fe\u8a02\u54d0\u58bc\u73ab\u48d9\u5920", "\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud940\udf50\uda22\uded0\udaff\ude60\uda0a\udd52\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb6e\udfe4\udb84\udcf2\udb2e\udf32",
        2, 40821, 351555668, 4526735454865093290L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fd02005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=8141895-12-10T03:21:52.213Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=8141895-12-10T03:21:52.213Z,mdfw=2]\012",
        Z.run(T, 2, 18, 18, 7, "\udb05\udd96\uda86\ude8d\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud9d8\udf93\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda9d\udd89\ud84e\ude07\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\ud9d0\udfbe\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ud94f\uddf1\udb5f\udca3\ud816\udd7b\ud8b4\udfdb", "\u4254\u39fe\ub1b3\u4248\u378d\u73ab\u37d6\u7119", "\ud881\udca5\ud83f\udd46\ud9f0\udf4e\udb47\udc3d\udb88\udfaf\ud940\udf50\ud82c\udce2\udaa4\ude1b\udbc3\ude17\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb6e\udfe4\udb84\udcf2\u8e0e",
        2, 8909, -1930145668, 256871252172112213L, -71010L, false, true, (char) 16160, (char) 44347,
        Double.longBitsToDouble(0x3fea55171402b069L), Double.longBitsToDouble(0x3fd91f06677dc86eL)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=141659109-04-09T04:32:28.074Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 18, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udbc7\ude72\uda93\udf3d\uda90\udf62\ud818\udd4b\ud8bd\udd23\uda69\ude52\udab5\udeea\ud868\udede\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u4254\u39fe\u8a02\u5d1c\ua08c\u73ab\u48d9\u5920", "\udaa5\udebe\ud83a\udd2f\ud832\ude6b\ud99d\udfe8\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb6e\udfe4\udb84\udcf2\udb2e\udf32",
        2, 8909, 1928614012, 4470267544345948074L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fd02005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=143798390-11-08T10:00:19.882Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\uded1\udb1b\udf78\udb5f\udca3\ud816\udd7b\udaaf\udfca", "\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920", "\udaa5\udebe\udb48\udd36\udb1a\udf1f\ud945\udda8\ud804\udfac\ud925\udd7b\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb6e\udfe4\udb84\udcf2\udb2e\udf32",
        2, 8909, 351555708, 4537776750631219882L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fd02005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=75382773-07-06T07:00:14.185Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=75382773-07-06T07:00:14.185Z,mdfw=1]\012",
        Z.run(T, 2, 2, 18, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udbec\udf8d\udb5b\udc56\ud896\udf8a\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3\u21da\u7e9a", "\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud946\udd93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\ud84f\ude2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb23\udcf6\ud9a6\udcb5\ud877\udf02\ud83f\udf2a\ud973\udfaa\udb1c\udf6a\ud993\udf56\ud8d1\udc7a\uda07\ude27\ud93a\udcae\ud85f\ude2d\ubca3\uda94\udc2c\ufc5d\udb78\ude31\udbf5\udf9e\udbb6\udc67\udaa1\udfd3\udae1\udc80\uda90\udf62\uc699\udbb5\udc19\ud8af\udc06\udbaf\udd51",
        1, 8662, 737274602, 2378788398111614185L, -42202L, false, true, (char) 31876, (char) 42287,
        Double.longBitsToDouble(0x3fb9c39ae51c5b98L), Double.longBitsToDouble(0x3fc8224e5366af08L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=29515000-09-09T07:29:20.647Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa6\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udbec\udf8d\udb5b\udc56\ud896\udf8a\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u3ae3\u21da\u7e9a", "\ud95e\udea7\ud825\udf78\ud959\ude78\ud8c9\ude58\ud946\udd93\uda37\udc40\ud937\udde1\udb7d\udc3b\udaa5\ude49\ud84f\ude2f\udb1a\udf1f\ud9c0\udda6\uda74\udd0f\ud940\udf50\ud82c\udce2\udb0c\udccf\udbe4\udd1e\udb23\udc96\ud9a6\udcb5\ud877\udf02\ud83f\udf2a\ud973\udfaa\udb1c\udf6a\uda22\udc9e\ud8d1\udc79\udac6\udc2c\ud93a\udcae\ud85f\ude2d\ubca3\uda94\udc2c\ufc5d\udb78\ude31\udbf5\udf9e\ud99d\udc66\udaa1\udfd3\udae1\udc80\uda90\udf62\uc699\udbb5\udc19\uda85\udccc\udbaf\udd51",
        1, 8662, 200403690, 931341292817360647L, -42202L, false, true, (char) 56462, (char) 13452,
        Double.longBitsToDouble(0x3fb9c39ae51c5b98L), Double.longBitsToDouble(0x3fc8224e5366af08L)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\012",
        Z.run(T, 2, 2, 18, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb4c\udfe6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud90b\udd74\ud8bd\udccb\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\ud9e1\udc68\udb67\udf9b\uda32\ude28\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u2460", "\ud97c\udf87\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\udbb9\udef1",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 62322, (char) 33031,
        Double.longBitsToDouble(0x3fdb09bc5acdfc98L), Double.longBitsToDouble(0x3fdab6da3bbc4054L)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=173824834-12-04T12:18:02.650Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\ud938\udf7f\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud83c\udc0c\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u2460", "\ud97c\udf87\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\udb31\ude7d\ud937\udd59\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 495120531, 5485319804953082650L, 3685L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3fdb09bc5acdfc98L), Double.longBitsToDouble(0x3fd92318cb664884L)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 18, 2, "\uda10\udc11\ud8f2\uddeb\uda4d\udfc2\ud8cb\ude23\ud897\udffa\ud9f0\uddef\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11\udbb9\udde4\uda0a\udde0\ud83b\udde5\ud810\ude44\udab5\udeea\ud8ed\udd81\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\uda73\udd7e\uda1c\udf86\udb1b\udf78", "\u8b39", "\ud872\udec5\udbbc\udfa4\ud930\udca7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40",
        -2, 90186, 1135061698, 9132120740787733344L, -30515L, true, false, (char) 51060, (char) 36812,
        Double.longBitsToDouble(0x3fe7df6f1a6be30bL), Double.longBitsToDouble(0x3f8618e90ad93700L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 18, 8, 5, "\udb7f\udc39\ud87a\udfe6\udb22\uddd1\uda97\udc18\ud81f\udc45\ud820\ude9c\udb76\udc2a\udac7\ude37\uda4c\uddc0", "\u7602\u81e7\ubc7a\u5444\u9e6a\u8fab\u35d5\u4f67\u9316", "\uda03\udf72\udb1b\udf78\udb5f\udca3",
        20, 52000, 1176022726, 4669587245939906151L, 48881L, false, false, (char) 61803, (char) 11012,
        Double.longBitsToDouble(0x3fd288206556ef02L), Double.longBitsToDouble(0x3fdec71f638f126aL)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 18, 8, 5, "\udb0d\udcc5\ud87a\udfe6\udb22\uddd1\uda97\udc18\ud81f\udc45\ud820\ude9c\udb76\udc2a\udac7\ude37\uda4c\uddc0", "\u7602\u81e7\u00a6\ubaf5\u9e6a\u6caa\u35d5\u25b7\u9316", "\uda03\udf72\ud80e\udf11\000",
        -5, 52000, 1176022726, 4669587245638877287L, 48992L, false, false, (char) 16300, (char) 63235,
        Double.longBitsToDouble(0x3fd288206556ef02L), Double.longBitsToDouble(0x3fdec71f65a25fceL)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 18, 16, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udadb\udd63\ud820\ude38\ud877\uddbe", "\000", "\ud8bd\udd2b",
        2, 90367, -1199142111, 0L, -24402L, false, true, (char) 54570, (char) 0,
        Double.longBitsToDouble(0x3fe844200682c399L), Double.longBitsToDouble(0x3febfb40764099edL)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=229674765-11-25T20:23:11.716Z,mdfw=6]\012",
        Z.run(T, 2, 0, 2, 6, "\ud937\udd54\u8919\udb05\ude00\ud8e6\udeae\ud967\udd82\ud950\udfee", "\u1856\ucc4e\u1291\ua144\u65e4\u6592)\u9e6a", "\udafb\udc95\ud926\udd7b\ud99c\udf6e\udb31\udd19\ud9eb\udf74\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb\ud9f0\udee7\uda32\udda1\ud994\udfc9\udbc1\udd2b\ud95e\udea7\ud808\udf89\uda4d\udd12\ud8c9\ude58\uda56\udff3\udb8e\udd35\ud8d6\udc21\ud8ae\udf17\udbff\ude75\udb90\udeed\u9578\ud978\ude3c\000\ud874\udd79\ud9e8\udc40\ud8f1\udddd\ud935\udc39",
        6, 37943, 7210389, 7247773395951791716L, -80994L, false, true, (char) 24948, (char) 95,
        Double.longBitsToDouble(0x3fde4bb310cfee1aL), Double.longBitsToDouble(0x3fda8308fde298ccL)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=116931050-03-19T11:35:02.218Z,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud9cd\udf9b\udbb4\ude9b\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u9052", "\udafb\udc95\ud831\udc57\ud989\udd1b\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a\ua2e7\ud8cd\udc15\uda32\udda1\ud97c\udfc9\ud8e0\udc9a\ud8c6\udee4\u00a1",
        2, 63026, 1740087274, 3689925371667302218L, -34154L, false, false, (char) 58124, (char) 46290,
        Double.longBitsToDouble(0x3fe80230df5a8ce3L), Double.longBitsToDouble(0x3fbd8d479b7fdd08L)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192365837-02-21T22:22:09.236Z,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\ud91a\udc49\uda3f\ude93\udbb4\udf2f\udaeb\udcdf\udaad\udf86\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u7fd7", "\udafb\udc95\ud831\udc57\ud989\udce2\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a\ua2e7\ud9f0\udee7\uda32\udda1\ud97c\udfc9\ud8e0\udc9a\ud8c6\udee4\u00a1",
        2, 79418, -412671273, 6070417321962129236L, -34154L, false, false, (char) 58124, (char) 46290,
        Double.longBitsToDouble(0x3fe80230daea8ce3L), Double.longBitsToDouble(0x3fbd8d4707f7dd08L)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 19, 2, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\u3d3f\udb15\udec6\udb4b\udc20\ud91d\uddd4\uda39\udf08\udb7f\udd2d\ud800\udc74", "\u1a5e\u8c66\u66e0\u8470\ud276\u9aec", "\uda14\udd58\ud907\udd57\ud900\udc54\ud91e\udea2\ud816\udd1a",
        45, 78663, 802133724, 6048711273705006744L, -82935L, false, false, (char) 53469, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fd8851ee795bbc6L)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192367189-09-22T14:11:56.884Z,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud8a1\uddf6\ud855\udec7\ud92e\udc1d\ud806\udf25\ud959\udc43\udb4b\udc1e\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud9d0\udc3b", "\u6f93\u6e1c\u66a8", "\udafb\udc95\ud831\udc57\ud989\udce2\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a\ud93d\udc71\ud9f0\udee7\ucaa2\uda69\udd20\ud9ef\udcdb\ud8c6\udf64\u00a1",
        2, 63026, 57778154, 6070460005347116884L, -34154L, false, false, (char) 58124, (char) 46290,
        Double.longBitsToDouble(0x3fe80230daea8ce3L), Double.longBitsToDouble(0x3fbd8d471b7fdd08L)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-16T21:49:30.324Z,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8", "\udafb\udc95\ud831\udc57\ud989\udce2\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a\ua2e7\ud9f0\udee7\uda32\udda1\ud97c\udfc9\ud8e0\udc9a\ud8c6\udee4\u00a1",
        2, 63026, 0, 1374570324L, -34154L, false, false, (char) 58124, (char) 46290,
        Double.longBitsToDouble(0x3fe80230daea8ce3L), Double.longBitsToDouble(0x3fbd8d471b7fdd08L)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192365839-06-17T00:09:33.268Z,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udbc3\udfb7\ud81c\udcff\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8", "\udafb\udc95\ud831\udc57\ud989\udce2\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a\ua2e7\ud9f0\udee7\uda32\udda1\ud97c\udfc9\ud8e0\udc9a\ud8c6\udee4\u00a1",
        2, 41378, -259714259, 6070417394976573268L, -34154L, false, false, (char) 58124, (char) 46290,
        Double.longBitsToDouble(0x3fe80230daea8ce3L), Double.longBitsToDouble(0x3fbd8d471b7fdd08L)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192365823-06-29T04:14:05.140Z,mdfw=2]\012",
        Z.run(T, 1, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\ud85c\ude97\000\000\udba8\udc7f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8", "\000\000\ud989\udce2\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a@\000\ud80c\udec5\ud97c\udfc9\ud8e0\udc9a\ud8c6\udee4\u00a1",
        2, 63026, -361652246, 6070416891106445140L, -34154L, false, false, (char) 23040, (char) 46290,
        Double.longBitsToDouble(0x3fe80230daea8ce3L), Double.longBitsToDouble(0x3fbd8d471b7fdd08L)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192365828-11-03T14:32:04.180Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192365828-11-03T14:32:04.180Z,mdfw=2]\012",
        Z.run(T, 2, 18, 2, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\udb4e\udde9\uda23\udd9c\udbb8\udee1\ud95f\udc2a\ud91d\uddd4\udba8\udc9f\ud985\udcb1\ud90e\ude18", "\uca61\u6e1c\u66a8", "\udafb\udc95\ud831\udc57\ud99c\ude2c\ud8cc\udcd4\udab1\udc09\ud88e\uddcc\ud9e2\udf56\ud816\udd1a\ua2e7\u0d91\ud8ec\udf1d\ud96e\udea0\ud8e0\udc9a\ud93f\uddd1\u00a1",
        2, 63026, -361652246, 6070417059969124180L, -34154L, false, false, (char) 58124, (char) 46357,
        Double.longBitsToDouble(0x3fe80230daea8ce3L), Double.longBitsToDouble(0x3fbd8d471b7fdd08L)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192365837-07-21T01:30:31.124Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 18, 19, 19, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\udafb\udc32\udb4a\udee5\udb7d\udcb1\ud800\udcb0", "\u6661\u6e1c\u66a8", "\udafb\udc95\ud831\udc57\ud989\udce2\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a\ua2e7\ud9f0\udee7\uda32\udda1\ud97c\udfc9\ud8e0\udc9a\ud8c6\udee4\u00a1",
        2, 28170, -2038522015, 6070417334847031124L, -34154L, true, true, (char) 41333, (char) 46290,
        Double.longBitsToDouble(0x3fe80230dd0e8ce3L), Double.longBitsToDouble(0x3fdb09f4e5a26d4cL)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=192074195-10-19T23:29:49.939Z,mdfw=3]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 13, 16, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud8ff\uddb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udbf1\udd33\ud800\udc74\ud9f1\udffb\ud81d\udfa9\uda30\udfc4\uda5f\udd51\udaa7\udf28\uda0c\udc51\uda84\udcff\udafb\udc35\ud831\udc57\ud989\udce2", "\u95e8\u53cc\uc623\u6bd1\u21da\u7e9a\u4254\u1124\u7251\ub12c\u4350\ua6f8\u12ee\u97ff\ub86e\u8c1a\u35ed\ubd9a\ube8f\ud68f\ua693", "\ud880\udc86\ud940\ude79\ud8e2\ude16\ud823\udfbe",
        3, 56019, -1268797630, 6061214010122989939L, 11435L, true, true, (char) 31059, (char) 45840,
        Double.longBitsToDouble(0x3f9325b8ebe8f200L), Double.longBitsToDouble(0x3fd20660cc1d64e6L)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191675038-05-15T09:49:03.000Z,mdfw=5]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\uda38\ude31\uda6c\uddec\uda3b\ude7a\ud904\udeb7\udbb4\udf2f\ud826\uddd9\udad3\udc24\ud91d\uddd4\udb90\udd50\ud85b\udd5b\ud800\udd0e", "\u86ac\ud5a7\u6680\u5d09\u49b6\ubf07", "\udb87\udd4b\ud8dd\udd03\ud82b\udcfe\ud882\uddbf\ua88a",
        5, 33862, -1375168782, 6048617818182543000L, -79122L, false, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fc10a3dc6ef778cL)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 5, 0, "\uda38\ude31\uda6c\uddec\uda3b\ude7a\ud8f9\udeb7\ucdd0\uc390\udb4b\udc20\ud8e2\udcd0\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8\u8470\ud258\u9aec", "\ud8cb\udc2d\000\udb01\udd2f\ud9e2\udf25\ud816\udd1a",
        26, 78726, 772314844, 201106286080L, -100000L, false, false, (char) 65078, (char) 118,
        Double.longBitsToDouble(0x3e4d5150f8000000L), Double.longBitsToDouble(0x3fc10a3dcbf3778cL)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=165184502-11-06T08:45:47.598Z,mdfw=3]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 16, "\ud89e\udd49\u8779\udad3\ude9e\ud904\udeb7\ud9db\uddc3\udb1c\udc30\udb5c\udd66\ud9f8\udd6a\uda91\udc1b\udb7f\udd2d\ud800\udc74", "\u7e7b\u476f\u2436\u0f2a\ud258\ua984", "\udb87\udd4b\udbda\ude41\ud830\udfd2\ud9e4\udc29\ud816\udda9",
        3, 45920, 283624282, 5212657260290747598L, -79122L, false, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fd97e871194dfc0L), Double.longBitsToDouble(0x3fee9a8f72fcdd15L)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=230487597-10-30T01:46:49.046Z,mdfw=3]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\ud8a6\udc88\ud81c\udd18\udb49\udec6\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\ud800\udc74", "\u7e7b\u476f\u2436\u0f2a\ud258\u9aec", "\udb87\udd4b\udbda\ude41\ud830\udfd2\ud9e4\udc29\ud816\udda9",
        3, 46824, 1336753102, 7273423894067209046L, -79122L, false, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fc10a3dcbf3778cL)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191677999-04-28T17:49:49.080Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 18, 19, 5, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\ud91f\udedb\udb7f\udcf7\uf873", "\u239f\u6e1c\u66a8\u8470\ud29e\u9ac8", "\udb87\udd4b\uda04\uddf6\uda02\udd3c\ud9e2\udf25\ud816\udd1a",
        5, 72175, 789092060, 6048711256873789080L, -79122L, true, false, (char) 65078, (char) 46746,
        Double.longBitsToDouble(0x3fa3f564754543e0L), Double.longBitsToDouble(0x3fe7c094f71c4204L)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191677999-04-28T17:49:49.080Z,mdfw=2]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb3f\udd14\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\uf873", "\u6661\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud816\udd1a",
        2, 72175, 789092060, 6048711256873789080L, -79122L, true, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fe7c094f71c4204L)));
  }
  @Test(timeout = 4000)
  public void test177() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191682075-10-19T07:41:57.272Z]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 9, 4, "\udb3f\udd14\ud81c\udd18\udb7e\udf5a\ud938\ude54\udbb4\udf2f\ud925\ude9b\ud84c\udf1d\u6452\udb99\udd9f\udb7f\udd2d\ud800\udc74", "\u6661\u6e1c\u66a8\u23db\u73c1\u2a7e", "\udb87\udd4b\udbda\ude41\udb01\udd2f\ud9e2\udf25\ud9cb\uddd3",
        4, 75183, 789092060, 6048839898056517272L, -79122L, false, false, (char) 65078, (char) 44639,
        Double.longBitsToDouble(0x3fa3f538f54543e0L), Double.longBitsToDouble(0x3fc10a3dca7c8d4cL)));
  }
  @Test(timeout = 4000)
  public void test178() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=102455920-02-15T11:17:41.739Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=102455920-02-15T11:17:41.739Z,mdfw=1]\012",
        Z.run(T, 2, 18, 2, 9, "\udb3f\udd14\ud8f2\uddc3", "\u754e\u523a\ua7ce\u7671\u7bf5\u7972\u120f\ucb56\u9c28\u707f", "\uda03\udf8d\ud8bc\udf06\ud9fb\udc95\ud926\udd7b\ud98b\ude05\udb69\udcd3\udb2f\udfd5\udb10\udf9d\udb5f\udca3\udae3\udd80\udbc6\udc93",
        1, 46957, 1408325311, 3233134386213461739L, 89567L, false, true, (char) 54268, (char) 17433,
        Double.longBitsToDouble(0x3feefd0121a2e032L), Double.longBitsToDouble(0x3fe324a27ad4b973L)));
  }
  @Test(timeout = 4000)
  public void test179() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1975-01-14T08:01:48.544Z,mdfw=7]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 18, 0, 12, "\ud946\udfbf\u7ce6\uda4d\udfc2\udb66\udce6\udbeb\udeeb\udab4\udcdf\udb7a\udfa0\000\u6400\ud874\udd79", "\u40a8\000", "\ud9d7\udc40\ud9d9\udd9f",
        7, 47014, -721087646, 158918508544L, 4830L, true, false, (char) 23827, (char) 8827,
        Double.longBitsToDouble(0x3feee230c600e807L), Double.longBitsToDouble(0x3fe4c29f8eb22cdeL)));
  }
  @Test(timeout = 4000)
  public void test180() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=147464092-05-13T10:12:39.083Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 17, 7, "\uda12\ude29\udb59\udfb6\uda84\uddbd", "\u4040\uc0fd\ub4f0\u7cb5", "\uda53\udcbc\ud829\udcd7\udbae\udd44\ud8da\udcde\udab8\ude53\uda03\udf8d\ud898\ude42\udafb\udc95\ud926\udd7b\uda7d\udd56\udb87\udd4b\uda03\udf72\udb1b\udf78",
        5, 64347, 1311336000, 4653455117335959083L, 4808L, true, false, (char) 61801, (char) 3833,
        Double.longBitsToDouble(0x3fd33c5127e550c2L), Double.longBitsToDouble(0x3fc4c5945e40f49cL)));
  }
  @Test(timeout = 4000)
  public void test181() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=169194784-06-15T03:26:15.189Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=169194784-06-15T03:26:15.189Z,mdfw=1]\012",
        Z.run(T, 2, 2, 18, 7, "\udb3f\udd14\ud8fe\uddc3\uda4d\udfc2\udb66\udce6\u6c11\ud9b6\udf57\udb2f\uddd4\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u0fd9\u6e1c\u66a8\u8470\u7750\u9aec", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        1, 64375, 1311336000, 5339209524463575189L, 14776L, true, false, (char) 61289, (char) 39767,
        Double.longBitsToDouble(0x3fe71a5563f2a863L), Double.longBitsToDouble(0x3fc4c5945998f49cL)));
  }
  @Test(timeout = 4000)
  public void test182() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=169194784-06-15T03:26:15.189Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=3]\012",
        Z.run(T, 2, 18, 4, 8, "\uda15\uddfa\uda3a\udc77\uda4d\udfc2\udb66\udce6\ud970\udfd8\udb6f\udee6\uda19\udda5\udac7\ude01\udba8\udc9f\udb39\udd2a\udb7b\udf11\uda79\udfa4\ud8a8\uded0\ud83b\uddeb\uda5f\udd51\uda1b\uddd2", "\u9aec", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        3, 64390, 1311336000, 5339209524463575189L, 16862L, true, false, (char) 50766, (char) 39767,
        Double.longBitsToDouble(0x3fe71a5563f2a863L), Double.longBitsToDouble(0x3fc4c5945998f478L)));
  }
  @Test(timeout = 4000)
  public void test183() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=48270714-01-06T18:37:29.318Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=48270714-01-06T18:37:29.318Z,mdfw=1]\012",
        Z.run(T, 2, 18, 2, 14, "\udb3f\udd14\udb92\udd44\uda4d\udfc2\udb6a\udfe6\ud970\udfd8\udb17\udc1e\udb4a\udc72\udbb3\udf25\ud941\ude4e\ud820\udc94\udac2\udc9f", "\u0fd9\u6e1c\u840a", "\udbb3\udf01\u7543\ud87f\udd32\udb87\udd4b\udab3\udea9\udb1c\udc41",
        1, 64375, 1467099456, 1523214437971049318L, 47368L, true, false, (char) 61289, (char) 23440,
        Double.longBitsToDouble(0x3fe2b068b3c1519dL), Double.longBitsToDouble(0x3fe3f834e666339dL)));
  }
  @Test(timeout = 4000)
  public void test184() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=268933907-05-29T23:19:51.545Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=268933907-05-29T23:19:51.545Z,mdfw=3]\012",
        Z.run(T, 2, 2, 2, 14, "\udb3f\udd14\ud8fe\uddb6\uda4d\udfc2\udb66\udce6\ud954\udfd8\udb17\udc1e\udb2f\uddd4\udac7\uddce\udba8\udd56\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud83b\uddeb\uda5f\udd51\udaa7\udf28\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\ud850\udca7\ud816\udd6e\ud892\udedb\udb68\udf23\uda34\udf5a\udb8f\ude73\udb9a\ude4c\ud956\udd22\uda27\udeb6\uda20\udc35\ud8e0\uddb9\ud983\ude93", "\ube78\ud7a4\u06e2\u8341", "\ud810\udff2\ud86a\udf76\ud821\udf0d\ud857\udfc5\ud882\udefb\uda45\uddeb\udba6\udd66\u3fff\ud86a\udd59\udb67\udf5b\uda79\udef1\ud93d\udc97\ud868\udddb\udb7d\udc43\udb23\udc84\u8fe7\udadc\ude5a\ud877\ude00",
        3, 93677, 664526195, 8486672239984791545L, 83824L, true, true, (char) 21612, (char) 9648,
        Double.longBitsToDouble(0x3fd470871e03d7feL), Double.longBitsToDouble(0x3fe1b8545d6dc506L)));
  }
  @Test(timeout = 4000)
  public void test185() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=283774933-12-23T20:36:23.720Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\uda34\udc3e\udb7a\udf24\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\uda0b\udc10", "\u3ae3\u21da\u23f0\u4254\u39fe\u8a02", "\ud8c9\ude58\ud983\ude93\uda7f\udc44\ud937\udde1\udae4\udccc\udaa5\udebe\ud83a\udd2f\udaad\uddf5\ud9c0\udd2c\ud8b8\ude50\ud940\udfa2\ud82c\udce2\ud855\udd1a\ud812\ude1b\ud989\udf8d\udb9a\udea9\udbd8\udc60\uda20\udfdd\udb65\udc5e\ud843\udcca\ud81c\ude0c\ud81f\udf52\ud805\uddff\u6e43\udb96\uddc2",
        1, 87859, 1972699698, 8955009803162183720L, -81144L, false, true, (char) 21125, (char) 51051,
        Double.longBitsToDouble(0x3fe0831e1e722ddeL), Double.longBitsToDouble(0x3fec8759c3ed882dL)));
  }
  @Test(timeout = 4000)
  public void test186() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=44955548-11-11T17:40:31.565Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=44955548-11-11T17:40:31.565Z,mdfw=3]\012",
        Z.run(T, 2, 18, 18, 2, "\ud895\udd87\ud8da\ude62\uda4d\udfc2\udb66\udce6\uda1c\udd81\ud820\uddf4\udb7a\udf80\udac7\uddce\uda68\udc9f\udb64\uded5\uda93\udee3\ud84e\udd6e\ud82e\udfff\ud8bd\udd23\ud832\udc5c\udab5\udeea\ud88b\udca8\ud8a8\udd13\udafb\udc95\uda14\udef3\ud893\udcfa\udb87\udde3\uda5d\udcdf\udb9a\udccc", "\u81e7\u3343\u7ef9\u8973\u3788\ube61\u5dab\u378d\u73ab", "\udbea\udd4d\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 45498, 813887635, 1418597930396431565L, -96838L, false, true, (char) 17574, (char) 33031,
        Double.longBitsToDouble(0x3fe84e658b6c4abeL), Double.longBitsToDouble(0x3fb3616220fe3c80L)));
  }
  @Test(timeout = 4000)
  public void test187() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=44172393-04-25T13:40:36.173Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb12\udf33\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\uda1c\udd81\ud820\uddf4\udb7a\udf80\udac7\uddce\uda68\udc9f\udb39\udd2a\uda8d\udde3\ud84e\udd6e\ud82e\udfff\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\uda14\udef3\ud893\udcd5\udb87\udde3\uda03\udf72\udb1b\udf78", "\uc355\u3110\ucd3f\u88c4\u3883\ube61\u5dab\u57f9\u9963", "\udbea\udd4d\udae4\udccc\udaa5\udebe\ud83a\udd2f",
        3, 36514, -1987959650, 1393883928366036173L, -96838L, false, true, (char) 17574, (char) 7752,
        Double.longBitsToDouble(0x3fe84e658b6c4abeL), Double.longBitsToDouble(0x3fb3616220fe3c98L)));
  }
  @Test(timeout = 4000)
  public void test188() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-15T14:01:26.848Z,mdfw=6]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-15T14:01:26.848Z,mdfw=6]\012",
        Z.run(T, 2, 2, 18, 5, "\000\ud838\udc37\uda4d\udfc2\udb66\udce6\udb1f\udd70\u1648\ud846\udc02\udac7\uddca\udba8\udc9f\000\000\031\ud81d\udfa9\ud8bd\udd23", "\u0c71\u0716\u9aec", "%",
        6, 28927, 130, 1260086848L, 96608L, true, false, (char) 10001, (char) 41614,
        Double.longBitsToDouble(0x3fbbbfdb490f7d98L), Double.longBitsToDouble(0x3fe805d95bf2a863L)));
  }
  @Test(timeout = 4000)
  public void test189() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 2, "\ud8f2\udc85\ud950\ude67\ud885\ude6d\udae3\udffa\udb1f\udd70\u1648", "\u7bf3", "\udb90\udc5f\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda11\udc53",
        59, 11500, 0, 812920625323423093L, -24799L, true, false, (char) 27445, (char) 12716,
        Double.longBitsToDouble(0x3fa0b05d50b00000L), Double.longBitsToDouble(0x3f910e3ac8d81940L)));
  }
  @Test(timeout = 4000)
  public void test190() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1980-11-12T15:34:58.816Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 13, "\udb2d\udfa4\ud981\udec9\uda64\udd4b\udb66\udce6\ud96d\udd56\ud9b9\udfd2\ud952\udc72\ud913\ude50\udba8\udc9f\udb39\udd2a\uda93\ude8f\udab0\udc9e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\uda34\udcd9\udb87\udd4b\000\ud9a7\udeb2", "\u5f44", "\udaef\udf8a\udbcb\udf8c\udb51\udf60\ud825\udf85\uda4d\udd12\ud9c3\udc75\ud9f6\udf7b\udbf9\udf92\ud8ce\ude01\ud8f4\udcd4\udaa5\udebe\ud83a\udd2f",
        3, 45498, -2050167661, 342891298816L, 3685L, true, false, (char) 53915, (char) 57409,
        Double.longBitsToDouble(0x3fd0ef9ae4d63a38L), Double.longBitsToDouble(0x3feb329e0500deb3L)));
  }
  @Test(timeout = 4000)
  public void test191() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=5272-08-26T09:40:04.736Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 2, 0, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda95\udde4\ud8c0\udcd1\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\udafb\udc95\ud926\udd7b\u1362\udb87\udd26\uda03\udf72\udb1b\udf70\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920", "\udaa5\udebe\ud83a\udd2f\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\uda2a\udf02\000\000",
        2, 79597, -396712752, 104221676404736L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fdeb005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test192() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=2]\012",
        Z.run(T, 2, 2, 18, 17, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud898\ude94\udb0b\ude31\ud926\udd7b\u1362\udb7a\udc60\udb92\udf57\udb00\udcab\ud8b5\udedd\ud976\udc7c\ud892\udedb", "\u4254\u39fe\u8a02\u5d1c\u378d\u73ab\u48d9\u5920", "\udad9\ude18\u03e8\udb1a\udf1f\ud9c0\udda6\ud8b8\ude50\ud940\udf50\ud82c\udce2\udb0c\udccf\ud9b6\udd48\udb84\udf26\ud9e1\udff8\udbdd\udef6\ud973\ude6c\uda36\uddd2\023\udbb4\uddaf",
        2, 8909, 20604, 0L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f06662c246eL), Double.longBitsToDouble(0x3fd02005d5d90b9cL)));
  }
  @Test(timeout = 4000)
  public void test193() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=8141895-12-27T00:48:50.005Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=8141895-12-27T00:48:50.005Z,mdfw=2]\012",
        Z.run(T, 2, 18, 18, 7, "\ud81c\udd60\uda86\udf1a\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud9d8\udf93\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda9d\udd89\ud84e\ude07\ud81d\udfa9\ud8bd\udd23\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\ud9d0\udfbe\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\ud94f\uddf1\udb5f\udca3\ud816\udd7b\ud8b4\udfdb", "\u4254\u39fe\ub1b3\u4248\u378d\u73ab\u37d6\u7119", "\ud881\udca5\ud9e8\ude79\ud9f0\udf4e\udb47\udc3d\udb88\udfaf\ud940\udf50\ud82c\udce2\udaa4\ude1b\udbc3\ude17\udb84\udf26\udbac\udd06\udbdd\udfa3\ud963\udf43\udb6e\udfe4\udb84\udcf2\u8e0e",
        2, 8909, -1930145668, 256871253631730005L, -71010L, false, true, (char) 16160, (char) 44347,
        Double.longBitsToDouble(0x3fea55171402b069L), Double.longBitsToDouble(0x3fd91f06677dc86eL)));
  }
  @Test(timeout = 4000)
  public void test194() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=19289580-09-13T10:37:39.626Z,mdfw=2]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,mdfw=2]\012",
        Z.run(T, 2, 18, 4, 2, "\udb29\udfa7\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb1f\udd70\ud820\uddf4\udb7a\udf80\udac7\uddce\udba8\udc9f\udbc7\ude72\uda93\udf3d\uda90\udf62\ud818\udd4b\udb85\ude10\uda69\ude52\uda56\udebc\ud9a7\udcfa\udb21\udc21\udb06\udfc4\ud926\udd7b\uda34\udcd9\udb87\udd4b\uda03\udf72\udb1b\udf78\udb5f\udca3\ud816\udd7b\ud892\udedb", "\u4254\u39fe\u8a02\u5d1c\u967a\u73ab\u48d9\u5920", "\uda37\udf43\udb90\ude0e\udab5\udccf\udaa2\udf35\uda78\udf54\ud824\udc5a\ud82c\udce2\uda1c\udd57\ud861\udf44\udb84\udf26\uda9a\uddfc\udbdd\udef6\ud963\udf43\udb6e\udfe4\udb84\udcf2\udb2e\udf32",
        2, 8909, -1475129220, 608658205084659626L, 41196L, true, true, (char) 28569, (char) 10931,
        Double.longBitsToDouble(0x3fd91f066608246eL), Double.longBitsToDouble(0x3fd02005dbd90b9cL)));
  }
  @Test(timeout = 4000)
  public void test195() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=155495989-09-03T13:12:59.997Z,mdfw=3]\012",
        Z.run(T, 2, 2, 18, 2, "\udb2d\udfa9\ud8f2\uddc3\uda4d\udfc2\udb4c\udfe6\udb1f\udd70\uda72\uddfd\udb7a\udf80\udac7\uddce\udba8\udc9f\udb39\udd2a\uda93\udee4\ud84e\udd6e\ud90b\udd74\ud8bd\udccb\ud832\udc5c\udab5\udeea\uda03\udf8d\ud8bc\udec5\ud9e1\udc68\udb67\udf9b\uda32\ude28\udb87\udd4b\uda03\udf72\udb1b\udf78", "\u2460", "\ud97c\udf87\udbc1\udd2b\ud95e\udea7\ud825\udf78\uda4d\udd12\ud8c9\ude58\ud983\ude93\uda37\udc40\ud937\udde1\udae4\udccc\udaa5\udebe\udbb9\udef1",
        3, 45498, 495120531, 4906917315119579997L, 3685L, true, false, (char) 62322, (char) 33031,
        Double.longBitsToDouble(0x3fdb09bc5acdfc98L), Double.longBitsToDouble(0x3fdab6da3bbc4054L)));
  }
  @Test(timeout = 4000)
  public void test196() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191675038-05-15T09:49:03.000Z,mdfw=5]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191675038-05-15T09:49:03.000Z,mdfw=5]\012",
        Z.run(T, 2, 2, 18, 0, "\uda38\ude31\uda6c\uddec\uda3b\ude7a\ud904\udeb7\udbb4\udf2f\ud850\udda6\uda90\udcdf\ud86f\udff0\udb90\udca8\ud85b\udd5b\ud800\udd0e", "\u86ac\ud5a7\u6680\u5d09\ud298\u8f37", "\udb87\udd4b\ud8dd\udd03\ud82b\udcfe\ud882\uddbf\ud9d2\udc5e",
        5, 33862, -1375168782, 6048617818182543000L, -79122L, false, false, (char) 2343, (char) 6879,
        Double.longBitsToDouble(0x3fe177538f541fe8L), Double.longBitsToDouble(0x3fc10a3dd638cb70L)));
  }
  @Test(timeout = 4000)
  public void test197() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=199280167-08-14T19:46:41.930Z,mdfw=7]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles]\012",
        Z.run(T, 2, 18, 0, 12, "\ud946\udfbf\u7ce6\uda4d\udfc2\udb58\udce6\udbab\udc3b\uda7b\udd51\ud9b8\udef3\udb01\udf31\udab4\ude9f\ud879\udc70", "\u40a8\000", "\ud9d7\udc40\ud9d9\udd9f",
        7, 47014, 1055200098, 6288612516906401930L, 4830L, false, false, (char) 41980, (char) 41290,
        Double.longBitsToDouble(0x3feee230c600e807L), Double.longBitsToDouble(0x3fe4c29f8903f8deL)));
  }
  @Test(timeout = 4000)
  public void test198() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=169194784-06-15T03:26:15.189Z,mdfw=1]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=169194784-06-15T03:26:15.189Z,mdfw=1]\012",
        Z.run(T, 2, 2, 18, 7, "\udb3f\udd14\ud8fe\uddc3\uda4d\udfc2\udb66\udce6\u6c11\ud9b6\udf57\udb2f\uddd4\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\u0fd9\u6e1c\u66a8\u8470\u7750\u9aec", "\udb87\udd4b\uda03\udf72\udb1b\udf78",
        1, 64375, 1311336000, 5339209524463575189L, 14776L, true, false, (char) 61289, (char) 39767,
        Double.longBitsToDouble(0x3fe639e9e3f2a863L), Double.longBitsToDouble(0x3fc4c5945998f49cL)));
  }
  @Test(timeout = 4000)
  public void test199() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 11, 2, "\ud863\udd2f\uda3f\udcfd\ud88d\udec9\udb66\udcb8\udadb\udd63\ud820\ude38\udb1c\udf71\u0d48\udbee\ude71\udb39\udd2a\udb7b\udf11\ud84e\udd6e\ud81d\udfa9\ud856\udc57\uda42\udf13\uda98\uddd9\uda03\udf8d\ud83e\udec0", "\u3871\u213d", "\udaaa\udf50\ud812\udc25\ud892\udedb\ud9f0\udee7\uda32\udda1\ud97c\udfc9\ud885\udd21\ud926\udc87\ud825\udf78\ud9ba\uddc8\uda6d\udecd\ud983\ude93\uda61\udcf5\ud9e3\udd78\uda52\udd63\udaa5\ude0e\udbe9\udc27",
        20, 77529, -1619921848, 4906917315119579997L, 90336L, true, false, (char) 57470, (char) 33031,
        Double.longBitsToDouble(0x3feef5eabdad479eL), Double.longBitsToDouble(0x3feb2267f16f40d9L)));
  }
  @Test(timeout = 4000)
  public void test200() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[UTC]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 18, 2, "\uda10\udc11", "\u9c5e\000\u11c5\uc0dd\ub4f0\u7bf3\u7972\u0755\u2e38\u021e\u03d3\u5444\u63c0", "",
        -5, -1000, 0, 7506558295286008529L, 4830L, true, true, (char) 20677, (char) 64911,
        Double.longBitsToDouble(0x3fe6e230c6d72f08L), Double.longBitsToDouble(0x3fd0000f1561cfbcL)));
  }
  @Test(timeout = 4000)
  public void test201() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=191681408-01-01T10:41:57.400Z,mdfw=5]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 0, "\udb23\udc27\ud81c\udd18\uda4d\udfc2\ud904\udeb7\udbb4\udf2f\udaeb\udcdf\udb4b\udc20\ud91d\uddd4\udba8\udc9f\udb7f\udd2d\uf873", "\u6661\u6e1c\u66a8\u8470\ud258\u9aec", "\udb87\udd4b\udb18\udd9f\udae9\uddd6\ud9e2\udec2\ud816\udd1a",
        5, 72175, 789092060, 6048818824329717400L, -79122L, true, false, (char) 65078, (char) 29536,
        Double.longBitsToDouble(0x3fe84f7657545407L), Double.longBitsToDouble(0x3fe7c094f71c4204L)));
  }
  @Test(timeout = 4000)
  public void test202() throws Throwable {
    assertEquals("0=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=222386956-04-15T20:57:57.972Z,mdfw=7]\0121=org.joda.time.chrono.GJChronology:GJChronology[America/Los_Angeles,cutover=222386956-04-15T20:57:57.972Z,mdfw=7]\012",
        Z.run(T, 2, 18, 2, 15, "\u06ed\ud8f2\uddc3\uda4d\udfc2\udb66\udce6\udb71\udc4d\ud954\udd85\udb7a\udf73\udac7\uddce\udba8\udc9f\udb39\udd2a\udb7b\udf11", "\uac18\u808f\u5c2a\u86c2\ud258\u7841", "\udb87\udd4b\uda03\udf72\udb1b\udf78\ud85b\ude82\uda74\ude2d\uda28\udf6e\ud82c\udc38\ud9db\udd48\uda2f\udf52\ud8f9\udd11\udbd3\udee1\ud874\uddc1\uda4d\udd06\ud8c9\ude58\udafb\ude87\uda55\uded9\ud800\ude6a\uda29\udd59\udbca\uded0\udbf8\ude17\udb3d\udc12\udbe3\udf94\uda3c\udca6\ud952\ude1b\udb23\udca4\uda97\udd4d\uda93\udd81\ud927\udd1e\udb62\udd57\udbfb\uddd9\ud9dd\ude65\ud801\udd73\ud8b7\ude35\ud84c\udf56\ud843\udc0d\ud9e9\udd58\ud8ff\udfc8\ud89f\udcbd\ud82d\udc15\udb9b\udf10\ud9d4\udc67",
        7, 77493, -955195620, 7017792337861077972L, -11011L, false, true, (char) 32028, (char) 60562,
        Double.longBitsToDouble(0x3fed61669af93462L), Double.longBitsToDouble(0x3fe5d1dc169d5893L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.chrono.GJChronology|getInstance||static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone|static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone,long,int|static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone,org.joda.time.ReadableInstant|static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone,org.joda.time.ReadableInstant,int|static",
    "M|org.joda.time.chrono.GJChronology|assemble|org.joda.time.chrono.AssembledChronology$Fields|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|convertByWeekyear|long,org.joda.time.Chronology,org.joda.time.Chronology|static",
    "M|org.joda.time.chrono.GJChronology|convertByYear|long,org.joda.time.Chronology,org.joda.time.Chronology|static",
    "M|org.joda.time.chrono.GJChronology|equals|java.lang.Object|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getDateTimeMillis|int,int,int,int|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getDateTimeMillis|int,int,int,int,int,int,int|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getGregorianCutover||new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getInstanceUTC||static",
    "M|org.joda.time.chrono.GJChronology|getMinimumDaysInFirstWeek||new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getZone||new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|gregorianToJulianByWeekyear|long|new:org.joda.time.chrono.GJChronology:org.joda.time.chrono.JulianChronology,org.joda.time.chrono.GregorianChronology,org.joda.time.Instant",
    "M|org.joda.time.chrono.GJChronology|getInstance||static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone|static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone,long,int|static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone,org.joda.time.ReadableInstant|static",
    "M|org.joda.time.chrono.GJChronology|getInstance|org.joda.time.DateTimeZone,org.joda.time.ReadableInstant,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
