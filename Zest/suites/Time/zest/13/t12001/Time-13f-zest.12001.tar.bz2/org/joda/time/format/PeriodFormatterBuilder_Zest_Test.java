package org.joda.time.format;
import org.junit.Test;
import static org.junit.Assert.*;
public class PeriodFormatterBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 9, 12, 1, "\ud9dd\ude9c", "\u4861\u5883", "\udae4\udd53\uda68\udf42\uda22\udc12\udb60\udd1f",
        23, 34371, -1323997063, -1101387494182661682L, 97123L, true, false, (char) 54019, (char) 442,
        Double.longBitsToDouble(0x3feadfc7e8386eefL), Double.longBitsToDouble(0x3fbb61eb0dcbd210L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 9, 13, 3, "\ud9dd\ude9c", "\u4861\u5883", "\udae4\udd53\uda38\ude09\uda22\udc12\ud96b\udc6d",
        6, 79367, -1323997063, -1101387494182661682L, 59688L, false, true, (char) 24261, (char) 634,
        Double.longBitsToDouble(0x3feadfc7e8386eefL), Double.longBitsToDouble(0x3fbb61eb0dc96b78L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 8, 12, 1, "\ud9d0\udf9c\ud985\udd66\u3ac2\udb45\udfa4\udb45\uddbb\udbcc\ude0d\ud8b5\ude2a\udbc4\udc5f\uda97\udc42\u1524\udbbb\udc73\udb62\udc1c\uda88\udd47\ud98c\udfd2\ud979\udd02\udacf\udf0b\ud86a\ude8b", "\u44ea", "\ud8ff\udf2c\ud9f8\udf0b\udac0\udc2a",
        15, 27852, 1221324095, -9050839520390497369L, -11220L, false, true, (char) 32416, (char) 38977,
        Double.longBitsToDouble(0x3fc9d9b089216ea0L), Double.longBitsToDouble(0x3f84d64df1723000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 10, 3, 9, "\ud9dd\udf57\uda8c\udc49", "\u5883\ubbca\uabba\uce17\u3284\u6117\u1653\u0ec2\ua0fb\ua2f0\u53cb\u9251\u15e2\u84cd\ua95f\u0573\u8a52\u9ad5", "\ud8cb\ude29",
        35, 5130, -1430328804, -4497342308414120536L, 79457L, false, false, (char) 16095, (char) 22634,
        Double.longBitsToDouble(0x3f74b791b8157f80L), Double.longBitsToDouble(0x3fe816017bdc57c9L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 10, 8, 2, "\ud8e1\ude4b\ud8e7\uddfe\u3b25\u3bbf\udb17\udf97\udbe5\udfe3\udab4\ude44\ud8c0\udf59\uda4b\udc53\udb59\udf41\udb88\udebb\ud842\udcbf\ud815\udd0c\ud98c\udff7\udb4d\uddfd\u7d18\ud933\udee2", "\u84dc\ube4b\u96f3\u3328\u85d2\u159d\u65c5\ua110\uce17\ubb00\ub684\ud63b\u02d6", "\udb38\udf20\udabf\udcd1\ud861\udeb8\udb87\udd96\uda42\udca8\udb08\udc0b\uda1a\udf5c\udaf7\udeb0\ud953\udf1f\udab6\udfbc\uda1e\uddb7\ud9d7\udfc9\ud81c\ude64\ud813\udd2e\ud9ea\udc17\uda02\udcfa\udb2c\udf0d\ud9b8\ude87\ud8dc\udca9\ud9ca\udce5\ud8b2\udf11\ud8f4\udfbd\ud9df\udd36\ud902\udf34\udb50\udf42\ud8cc\ude82\udba4\ude99\ud82c\udd31\ud94e\udc42\uda13\udedd\uda25\uded8\udbaf\ude86\ud888\uddb8\ud877\udf3c\ud94b\udef2\ud9eb\udc70\ud8b4\udc9d\udb3d\udd99\udb4c\udd7a\ud9df\udcc8\ud8d7\udcf8\ud870\udf45",
        55, 31975, 1595702873, 3895144509405928102L, 80111L, false, false, (char) 39233, (char) 7224,
        Double.longBitsToDouble(0x3fd1f9655c1ccc9cL), Double.longBitsToDouble(0x3fe5146c0b9fe9c4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 10, 1, "\ud9dd\ude9c", "\u4861\u5883", "\ud840\udc0c\uda68\udf42\uda22\udc12\udb60\udd1f",
        23, 34371, -1323997063, -1101387494182645810L, 97123L, true, false, (char) 54019, (char) 64953,
        Double.longBitsToDouble(0x3feadfc7e8386eefL), Double.longBitsToDouble(0x3fbb61eb0dcbd210L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 11, 2, "\udbcb\udc95", "\u47f1\u5167\ud051\ua794\ub31b\u3284\u2217\u3e1b\u43d8", "\ud979\udd02\udacf\udf0b\ud933\udf6f\udb70\udd5a\uda14\ude99\udbac\udc7d\ud8b2\ude38",
        27, 36592, 2051208301, -8667369103909970851L, -78317L, true, false, (char) 37780, (char) 13361,
        Double.longBitsToDouble(0x3fd6c01ce850acecL), Double.longBitsToDouble(0x3fee696dab3f1959L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 3, 12, 1, "\uda29\udc92", "\u4861\u5883", "\udae4\udd53\uda68\udf42\uda22\udc12\udb60\udd1f",
        23, 34371, 1720797662, 6891601322901983660L, 97123L, true, false, (char) 48387, (char) 2083,
        Double.longBitsToDouble(0x3feadfc7e8386eefL), Double.longBitsToDouble(0x3fbb61eb0dcbd210L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 4, 8, 1, "\ud9dd\ude9c", "\u4861\u5883", "\u442a",
        15, 85542, 0, -86694292826882048L, -40073L, false, true, (char) 52677, (char) 12890,
        Double.longBitsToDouble(0x3fa3fa6d80029870L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 13, 0, 14, "\ud9dd\ude9c", "\u4861\u5883", "\udb00\ude53\uda68\udf42\uda22\udc12\udb60\udd1f",
        23, 34371, -1323997063, -1101387491531861554L, 97123L, true, false, (char) 54019, (char) 442,
        Double.longBitsToDouble(0x3feadfc7e8386eefL), Double.longBitsToDouble(0x3fbb61eb0dcbd210L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 12, 7, "\ud9dd\ude9c", "\u4861\u1abf", "\udb0a\udd46\uda68\udf42\uda22\udc12\udb60\udd1f",
        23, 34371, -1323997063, -1101387493397233664L, 97123L, true, false, (char) 54019, (char) 442,
        Double.longBitsToDouble(0x3feadfc7e8386eefL), Double.longBitsToDouble(0x3fbb61eb0dcbd210L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 12, 4, "\ud9dd\ude9c", "\u887f\ud439\ud2ce\ua794\ub31b\u3284\u6117\u1653\u0ec2\ua0fb\ua2f0\u1b13", "\udb70\udd5a\ud91a\ude9c\udbac\udc7d\ud879\udd9b",
        19, 36592, 2051208301, 502391845373925961L, -14413L, false, false, (char) 40587, (char) 1849,
        Double.longBitsToDouble(0x3fb002f18b928298L), Double.longBitsToDouble(0x3fe5d8da78966a03L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 12, 1, "\ud9dd\ude9c", "\ub3ad\u5883", "\udae4\udd53\uda68\udf42\uda22\udc12\udb60\udd1f",
        23, 66995, -1323982811, -1101387494182661682L, 97123L, true, false, (char) 44575, (char) 58880,
        Double.longBitsToDouble(0x3feadfc500386eefL), Double.longBitsToDouble(0x3fbb61eb0dcbd210L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 7, 12, 1, "\ud8cf\uddd4", "\u4861\u5883", "\udae4\udd53\uda68\udf42\uda22\udc12\udb60\udd1f",
        23, 34371, -1323997063, -1101387494182661682L, -99485L, false, true, (char) 41935, (char) 32870,
        Double.longBitsToDouble(0x3fec45cb98386eefL), Double.longBitsToDouble(0x3fbb61eb0dcbd210L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 9, 12, 1, "\ud9dd\ude9c", "\u4861\u5883", "\udae4\udd53\uda68\udf42\uda22\udc12",
        30, 20103, 1719662483, 6569102223563232687L, -99126L, true, false, (char) 44290, (char) 54019,
        Double.longBitsToDouble(0x3fe51778bf5bf8fdL), Double.longBitsToDouble(0x3fe9c3777c6d87acL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 11, 11, 2, "\ud9dd\udf80\udaef\udcbc\ud9d5\udfe1\ud800\udec9\udb5b\udd34", "\u8215\u08c7\u68be\u566e\u2971\ubdb3\ub8bd", "\udbf9\udef6\udaea\udf86\udb1e\udd68\ud9a2\udd12\ud886\udee4\ud9ab\udd3c\udaa4\udd20\ud9e8\udfad\ud98c\uddef\ud9c6\udc2f\ud8c4\udeca\udb9f\udcf1\udacf\udce2\ud86e\udc01\ud99a\udfc1\ud9d9\udc5c\u3357\uda13\ude43\ud840\udd43\udad9\udd1c\uda59\udd13\ud8d7\udf4c\uda27\udddc\ud9d0\udf2d\udb65\udc20\udb22\udce7",
        57, 93419, -1654331302, -5075217551946290494L, 65932L, true, false, (char) 37113, (char) 50158,
        Double.longBitsToDouble(0x3fdc52c34232dc9eL), Double.longBitsToDouble(0x3fea88574f8c2420L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 2, 11, "\udba3\ude52", "\u4895\u20b4\u5d81", "\udbe0\udde5\ud9e8\udf84\ud977\udeb4\udb62\udc69\ud8d4\udd4d\uda14\udfd6\ud979\udd02\udacf\udf0b",
        6, 77307, -1786267609, -6900217422597674105L, -79464L, true, false, (char) 52219, (char) 55638,
        Double.longBitsToDouble(0x3fed86c042f951a5L), Double.longBitsToDouble(0x3fefeb532573e96bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 14, 12, "\ud9dd\ude9c\uda8c\udc49\u3a4a\ud97a\udf2b\uda41\udddc\udb3a\udf7e", "\u3284\u6117\u1653\u0ec2\ua0fb\ua2f0\u53cb\u9251", "\uda14\ude99",
        55, 31650, 1861158747, -8670466979095448467L, -83098L, true, true, (char) 9905, (char) 4426,
        Double.longBitsToDouble(0x3fea809339c43eb9L), Double.longBitsToDouble(0x3fd6a36bf860841aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=void |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 2, 4, 7, "\ud9dd\ude9c", "\u4861\u85ca\u3321\ua794\ub31b\u3284\u6117\ud2d0\u0ec2\ua0fb\ua2f0\u53cb\u8a85\u6456\u84cd\ua95f\u0573\u8a52\uc072\u9820\u9d54", "\uda7b\udd70\ud942\udfcb\ud9da\udcb5\ud98c\ude4b\udbca\udd75\udbb9\udea8\udadc\udf42\udb12\udfca\ud861\udf59\udb55\udd76\udabc\udc44\udbb8\ude23\ud36b\ud807\ude10\ud833\udce4\ud9b2\udd45",
        9, 76290, 949743573, 6752444303104727662L, -10931L, true, false, (char) 59885, (char) 50614,
        Double.longBitsToDouble(0x3fee5a5eadc8deb3L), Double.longBitsToDouble(0x3fe5a5984d2f2bd2L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 12, 1, "\ud9dd\ude9c", "\u218b\ua082", "\udae4\udd53",
        32, 63670, -518384910, -86667703046604141L, -40073L, false, true, (char) 52677, (char) 12890,
        Double.longBitsToDouble(0x3fa3fa6d97d29870L), Double.longBitsToDouble(0x3fdcdef17fc114e2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 14, 7, 4, "\udb3d\ude48\u37a2\udac6\udf73\ud9a4\uddb7\udb22\udd4f\uda79\udd87\udb37\udf04\uda6a\udf68\ud955\udfa0", "\u738a\ud3c3", "\ud949\udf82\udb3c\ude50\ud989\udf72\udb61\ude35\udbe3\ude74\ud94c\ude7d\udaea\udf52\uda73\udc80\u9535",
        42, 10088, -1803482665, -1177709996434635921L, -14196L, true, false, (char) 38545, (char) 34677,
        Double.longBitsToDouble(0x3fef28b13ba5adc4L), Double.longBitsToDouble(0x3fdf3203be74f114L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 12, 3, "\udbb1\udee5\udaba\udf91\ud979\udf01\udb50\uddc6", "\u91a4\uacc8\u9918\u93d5\u8b7c\u7907\u7e51\u95bc\ua8f2\ubfdb\u15e2\u84cd\u0a41\u0573\u8a8b", "\ud9e8\udfa1\ud8f4\udea8\ud971\udd37\udafc\ude09\ud8cd\udf4b\ud907\udc0d\ud99a\uded4\ud8b7\udd78\udbf3\udc28\udb20\udfd4\ud855\udf4d\udacc\udff5\ud894\ude75",
        58, 81187, -1195384652, -2724683882759521803L, -77602L, false, false, (char) 21006, (char) 2627,
        Double.longBitsToDouble(0x3fee3e397ed32881L), Double.longBitsToDouble(0x3fe6c5a0b4185be8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 14, "\ud8c4\udef0\ud9c3\udcb5\udb55\udc9c\ud95d\udc59\udb4e\udd2b\ud857\udef2\ud818\ude42\ud82c\ude3a\ud9d4\uded7\u1524\ud855\ude3b\udb62\udc64\uda88\udd47\uda33\udd2c\ud9d9\udfee\udad7\udfee\ud86b\udc55\udac1\udca1\ud84d\uddaa\udbbb\udff4", "\u45a7\uc0f2\u4a06", "\ud8d2\udd89\ub602\udaf2\udd88\uda07\udd8e\ud8cc\udcdc\udbca\uddac\ud8ae\ude86\ud985\ude93\udb36\ude34\ud898\ude75\ud933\udf83\udba1\udccb\u933c\uc5aa\u80c7\udab5\udc6b\ud9dc\ude1a\ud947\udcbf",
        -4, 36528, 523993738, -25292040886373060L, -35921L, true, true, (char) 59786, (char) 57316,
        Double.longBitsToDouble(0x3fe65c187f0329acL), Double.longBitsToDouble(0x3fb4d720114e3160L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 5, 12, 1, "\ud9d0\udf9c\ud985\udd66\ud843\udf20\ud8bc\uddc0\udb47\udeee\udbcc\ude0d\ud8b5\ude2a\udbc4\udc5f\uda97\udc42", "\uc031\uc489\u021f\uc4cb\u9251\u1ffb\u1f96\u4b37\u44ea\u8a52", "\ud9f8\udf0b\udbb8\udc26\uda7b\udc86\uda6e\uddfb\ud8d2\udd89\ub602\udaf2\udd88\ud810\udf33\ud83a\ude1c\uda16\udea7\ud8ae\ude86\ud985\ude93\udb36\ude34",
        8, 83954, -1275951163, -886922483664295890L, -59582L, false, true, (char) 22769, (char) 10946,
        Double.longBitsToDouble(0x3fcb0087c4038780L), Double.longBitsToDouble(0x3fe24e6b8ecc7e95L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 2, 8, 4, "\udba1\udefa\ud967\udf80\u3ac2\udb45\udfa4\ud836\udf2b\ud8a8\udd13\ud8b5\ude2a\udbc4\udc5f\uda97\udc42\ud911\ude8a\uda6b\udc5f\udb62\udc1c\uda88\udd47\ud98c\udfd2\uda6b\udc34\udaec\udefa\ud80a\udcef", "\u44ea", "\ud8ff\udf2c\ud9f8\udf0b\udba4\ude2f",
        31, 27852, 811265343, 7627650861236391L, -11220L, false, true, (char) 32416, (char) 46913,
        Double.longBitsToDouble(0x3fe71f5bf2485ba8L), Double.longBitsToDouble(0x3f9173a9f8aafae0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 6, 6, 2, "\ud8e1\ude4b\ud8e7\uddfe\u3b25\u3ba7\udb17\udf97\udbe5\udfe3\ud949\udc60\ud834\udd72\ud837\udc47\udb59\udf41\udb88\udebb\ud842\udcbf\ud922\udc73\u9928\ud883\udfd6\ud996\udf53\ud91f\udcef", "\ub8b5\u5683\u96f3\u3328\u85d2\u159d\ub39a\ua110\uce17\ubb00\ub6ac\ud63b\u02d6", "\ua441\udabf\udcd1\ud96a\udc7b\udb87\udd96\uda42\udca8\ud8f0\udc1f\uda1a\udf12\ud9d3\udfde\ud958\ude4d\udab6\udfbc\ud8d6\uddb3\ud9d7\udfc9\ud853\ude60\ud813\udd2e\ud9ea\udc17\uda02\udcfa\udb2c\udf0d\u30df\ud8dc\udca9\ud9ca\udce5\ud8b2\udf11\ud8f4\udfbd\uda52\ude5a\ud902\udf34\udb17\ude77\ud8a8\udca9\udba4\ude99\udb12\udf04\ud94e\udc42\uda13\udedd\ud91e\udf93\udbe4\udf5d\uda01\udf05\u8c75\ud94b\udf70\ud9eb\udc70\ud8b4\udc9d\udb3d\udd99\udb4c\udd7a\ud9be\udeb8\udac4\udcb0\ud870\udf04",
        55, 31975, 1595702873, 3895144509400816294L, 80111L, false, false, (char) 39233, (char) 684,
        Double.longBitsToDouble(0x3fd1f966bcb9f786L), Double.longBitsToDouble(0x3fc76681ee7fa790L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 8, 8, 2, "\ud8e1\udec1", "\u2e32\u1af4\u3a78\ub46c\ub824", "\udb88\udebb\ud842\udcbf\ud81b\udc1a",
        59, 43501, -1029738314, 3483529952360399363L, -18217L, true, true, (char) 11622, (char) 17371,
        Double.longBitsToDouble(0x3f9d87ac372f5e00L), Double.longBitsToDouble(0x3fe810f2431b4934L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 1, 14, "\ud8e1\ude4b\ud8e7\uddfe\u3b25\u3bbf\udb17\udf97\udbe5\udfe3\udab4\ude44\ud8c0\udf59\uda4b\udc53\udb59\udf41\udb88\udebb", "\ua315\u2a27\u4ff7\u1555\u90ad\uc5f6", "\udb0d\uded6\uda2e\udf03\udae5\udc50\udb66\udf81\ud988\udf52\u8b01",
        34, 67747, 468970919, 6765856841755372784L, -13411L, false, true, (char) 42152, (char) 31123,
        Double.longBitsToDouble(0x3fde5b7b8c72a2c2L), Double.longBitsToDouble(0x3fe2343c2a865cb6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 10, 10, 13, "\ud8e1\ude4b\ud8e7\uddfe\u3b25\u3bbf\udb17\udf97\udbe5\udfe3\udab4\ude44\ud8c0\udf59\uda27\udd53\udb59\udf41\udb88\udebb\ud842\udcbf\ud815\udd0c\ud98c\udff7\ud87c\udf8e\uda54\udd4f\ud933\udee2", "\u84dc\ube4b\u96f3\u3328\u85d2\u159d\u65c5\ua110\uce17\ubb00\ub684\ud63b\u02d6", "\udb38\udf20\udabf\udcd1\udb82\uddb5\udb8e\udf20\uda42\udca8\udb08\udc0b\uda1a\udf5c\udaf7\udeb0\ud953\udf1f\uda43\uddec\ud9fb\udf7d\ud9d7\udfc9\ud81c\ude64\ud813\udd2e\ud9ea\udc17\uda02\udcfa\udb2c\udf0d\ud9b8\uded9\ud8dc\udca9\ud9ca\udce5\ud8b2\udf11\ud8f4\udfbd\ud9df\udd36\ud902\udf34\udb50\udf42\uda9f\udc4b\udba3\ude54\ud82c\udd31\ud94e\udc42\uda13\udedd\uda25\uded8\udbaf\ude86\ud888\uddb8\ud877\udf3c\ud94b\udef2\ud9eb\udc70\ud8b4\udc9d\udb3d\udd99\ud807\udcf8\ud944\uddad\ud8d7\udcf8\ud870\udf45",
        55, 31975, 1595702873, 3895144509405928102L, 80111L, false, false, (char) 32102, (char) 49498,
        Double.longBitsToDouble(0x3fd1f9655c1ccc9cL), Double.longBitsToDouble(0x3fe5146c0895e9c4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 13, 13, 1, "\udb2d\udcb2\uda99\udca2\u1953\u3bbf\udb17\udf97\udbe5\udfe3\udab4\ude44\ud8c0\udf59\uda4b\udc53\udb59\udf41\udb88\udebb\ud842\udcbf\ud815\udd0c\ud98c\udff7\udb4d\uddfd\u7d18\ud933\udee2", "\u84dc\ube4b\u96f3\u3328\u85d2\u159d\u65c5\ua110\uce17\ubb00\ub684\ud63b\u02d6", "\udb38\udf20\udabf\udcd1\ud861\udeb8\udb87\udd96\uda42\udca8\udb08\udc0b\uda1a\udf5c\udaf7\udeb0\ud953\udf1f\uda44\udfb2\uda12\udc0d\ud9d7\udfc9\ud81c\ude64\ud813\udd2e\ud9cd\udc28\uda02\udcfa\udb2c\udf0d\ud9b8\ude87\ud8dc\udca9\ud9ca\udce5\ud8b2\udf11\ud818\udec4\ud9df\udd36\ud902\udf34\udb50\udf42\ud8cc\ude82\udba4\ude99\ud82c\udd31\ud94e\udc42\uda13\udedd\uda25\uded8\udbaf\ude86\ud888\uddb8\uda08\udfa3\ud94b\udef2\ud9eb\udc70\ud8b4\udc9d\udb3d\udd99\udb4c\udd7a\uda7a\uded6\ud8d7\udd34\ud870\udf45",
        55, 31975, 1595702873, 3897677782501825190L, 58333L, true, false, (char) 48521, (char) 7337,
        Double.longBitsToDouble(0x3fd1f9655c1ccc9cL), Double.longBitsToDouble(0x3fe5146c0b9fe9c4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 14, 2, 14, "\ud8e1\ude4b\ud8e7\uddfe\u3b25\u3bbf\udb17\udf97\udbe5\udfe3\udab4\ude44\ud8c0\udf59\uda4b\udc53\udb59\udf41\udb88\udebb\ud842\udcbf\ud815\udd0c\ud98c\udff7\udb4d\uddfd\u7d18\ud933\udee2", "\u84dc\ube4b\u96f3\u3328\u85d2\u159d\u65c5\ua110\uce17\ubb00\ub684\ud63b\u02d6", "\udb38\udf20\udabf\udcd1\ud861\udeb8\uda4d\udd99\uda42\udca8\udb08\udc0b\uda1a\udf5c\udaf7\udeb0\ud953\udf1f\udab6\udfbc\uda1e\uddb7\ud9d7\udfc9\ud81c\ude64\ud813\udd2e\ud9ea\udc17\udb8b\uddc7\udb42\ude91\ud9b8\ude87\ud8dc\udca9\ud9ca\udce5\ud8b2\udf11\ud8f4\udfbd\ud9df\udd36\ud902\udf34\udb50\udf42\ud8cc\ude82\udb26\udc7a\udac7\udd93\ud94e\udc42\uda13\udedd\uda25\uded8\udbaf\ude86\ud95a\udc41\ud877\udf3c\ud94b\udef2\ud9eb\udc70\ud8b4\udc9d\udb3d\udd99\udb4c\udd7a\ud9df\udcc8\ud8d7\udcf8\ud870\udf45",
        55, 31975, 1595702873, 3895144509405928102L, 80111L, false, false, (char) 39233, (char) 7224,
        Double.longBitsToDouble(0x3fd1f9655c1ccc9cL), Double.longBitsToDouble(0x3fe5146c0b9fe9c4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 4, 4, "\ud9f5\udfde\ud8f0\ude7c\ud846\udf06\ud97a\udebb\ud80d\uddb8\ud9cb\udf89\uac07\udae4\udd53\uda68\udf42\ud9f8\udf04\udbbe\ude48\udbc5\udd2e\ud97d\udc7a", "\ud1bd\ucb65\u84cd", "\ud8b2\ude38\ud9cb\udc1e\ud9b5\udd5a\uda80\udd4a\ud978\ude5a",
        -1, 8080, -631319395, -28410072142599347L, 89098L, false, true, (char) 60217, (char) 49822,
        Double.longBitsToDouble(0x3fee696dab3f1959L), Double.longBitsToDouble(0x3fd38ca00f242e5aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 7, 2, "\udbd2\udc59", "\u47f1\u5167\ud051\ua794\ub31b\uaedf\u21af\u3e1b\u43d8\u52ce\ua2f0\u9ecb\u4b3c", "\uda14\ude99",
        55, 8714, 1861158747, -8670466980447696275L, -78317L, true, false, (char) 37780, (char) 13361,
        Double.longBitsToDouble(0x3feb3306742856c5L), Double.longBitsToDouble(0x3fee696dab3f1959L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 5, 14, 8, "\ud80c\uddbb", "\uad6d\u41fc\u159f\u645e\uc0d6\u0e7d\ua875\u4ed4\u83a9\ubbf9\u36d3\u44c6", "\udb70\udd5a\ue46c\ud8c9\udc97\ud963\udcd6",
        1, 37572, -1023523289, -8667369104069959377L, 71595L, false, false, (char) 43643, (char) 37148,
        Double.longBitsToDouble(0x3fda409f1b21cd40L), Double.longBitsToDouble(0x3fd6c01ce850acecL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 11, 11, 9, "\uda29\udc92", "\u5494\u9dd9\u5890\ua794\u82ad\u3284\u6117\013\u0ec2\u05d4\u5877\u33d7\u3edf\u7a7f\uc5fc", "\ud8b2\ude38\uda57\udde4\ud9f1\udd5d\udab0\udd31\udb91\udc97",
        29, 21241, -1984981460, 6121995876233580465L, 15593L, false, true, (char) 28585, (char) 57847,
        Double.longBitsToDouble(0x3fd2de3922bdd35eL), Double.longBitsToDouble(0x3fe3b115d9b67587L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 7, 1, "\ud9dd\udf8a\ud93e\udcc2\000\ud97a\udf2b\uda41\udddc\000\udbce\udd75\ud9d7\udd01", "\u0d72\u55af\000", "\ud961\uddb4\ud90e\uddcd\udb70\udd5a",
        4, -1000, 0, 3005026850574276829L, -65869L, false, true, (char) 42695, (char) 3820,
        Double.longBitsToDouble(0x3fe3c9e89f5aaf43L), Double.longBitsToDouble(0x3fe4fefdd21b7c09L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 14, 7, 7, "\ud9dd\ude9c", "\u4133\ud439\ud2ce\ua794\ub31b\u3284\u6117\u1653\u0380", "\udaf5\udf01\ud9e5\ude12\ud933\udf6f\udb70\udd5a\uda66\udec6\udbbc\uddd4\ud879\udd9b\uda57\ude5e\ud8cb\ude72",
        22, 80201, 1258206870, -7877222818701173331L, -93846L, true, true, (char) 12294, (char) 39365,
        Double.longBitsToDouble(0x3fe5d8da78966a03L), Double.longBitsToDouble(0x3fdcdc7fd3778326L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 13, 0, "\udbeb\udcc5\ud8c4\udcc0\ud84a\ude47\uda91\udf93\uda41\udddc", "\ub31b\u3284\u6117\u1653", "\ud99a\udf7e\ud979\udd02\udacf\udf0b\ud933\udf6f\udb70\udd5a\ud821\ude5f",
        25, 49108, 1861158747, -8670466979095448467L, -7617L, false, true, (char) 46962, (char) 31173,
        Double.longBitsToDouble(0x3feb0cdbd501f81cL), Double.longBitsToDouble(0x3f9503630b382000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 9, 9, 4, "\ud9dd\ude9c", "\u6a0e\u3400", "\udae4\udd53\ud9c4\udfbb\uda0c\ude67\ud86f\udd77\ub5c7\udb82\udc70",
        34, 1241, -785428018, -263464332189564405L, 48724L, false, false, (char) 65531, (char) 48935,
        Double.longBitsToDouble(0x3fb35c2b0dcbd210L), Double.longBitsToDouble(0x3fdee59d3c392378L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=void |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud9e7\udec8", "\ub3ad\u5883", "\ud8ad\udf53\udbd0\udea3",
        9, 91222, -20178897, -9063785471664611291L, -55406L, false, false, (char) 12890, (char) 44290,
        Double.longBitsToDouble(0x3fc30d30fbd01c34L), Double.longBitsToDouble(0x3feadfc500386eefL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 13, 1, "\ud9dd\ude9c", "\uce2a\u5883", "\uda6f\uddd6\uda21\ude41\uda33\udcc2\ud8fd\udfad",
        39, 45963, -1324000657, -1101388181377429042L, -33949L, true, false, (char) 5436, (char) 28771,
        Double.longBitsToDouble(0x3fec3e5500386eefL), Double.longBitsToDouble(0x3fbb61e00dcbd210L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 14, 1, "\udb65\udc2b\ud835\udf66\udbfc\udf2a\uda91\udf93\ud844\ude3e\ucdfa\ud895\udc84\udbbe\udc8d\ud949\udc67", "\u0ec2\ud46e\u902c\u53cb\uccc6\u8a52\uc318\ubfb8\uae2b\u4e37\u9ad5\uc9a2\u9d54\ub363", "\uda8c\udfcf\ud8ea\ude6a\ud821\udd14\ud873\udc85\uda08\udd2b\ud9c9\udccc\ud937\udf2b\ud964\udf0a\uda19\udeaa\ud86c\udd0d\udb9a\udd8c\udbd1\uded2\ud9d9\udf77",
        13, 80556, 2039523402, -6898458925485001005L, -79044L, false, false, (char) 62900, (char) 15803,
        Double.longBitsToDouble(0x3fe9926873227a0dL), Double.longBitsToDouble(0x3fd7fb3f5258387eL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 5, 1, "\ud9dd\ude9c", "\u7445\u5812\u1463\ua794\u295f\u36b6\u3505\u1653\u5f08\u1a0e\u029d\u8e75", "\ud8bd\udee1\ud821\ude5f\ud97a\ude4c\udb9b\udf42",
        44, 20749, -596114425, -6629321126578247744L, -46163L, false, false, (char) 50261, (char) 10152,
        Double.longBitsToDouble(0x3fdf275c0a7b7e24L), Double.longBitsToDouble(0x3fdbc456da859040L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 3, 3, 1, "\uda7f\udf5b", "\ub306\u973d\u3846", "\u68ec\uda22\udc12\udb60\udd1f",
        23, 66995, -1323982811, 5239680783542057627L, 66566L, true, true, (char) 3076, (char) 40099,
        Double.longBitsToDouble(0x3fe48d317c61e73dL), Double.longBitsToDouble(0x3f8135553b4be5c0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 2, 2, 3, "\ud978\udeca", "\u4819\u5883", "\udb69\udcf3\ud9d0\udf55\uda22\udc6d\udb60\udd1f",
        38, 47453, -1314720108, -1101387494182661682L, -99320L, false, true, (char) 27599, (char) 32870,
        Double.longBitsToDouble(0x3fece5cb9b05935dL), Double.longBitsToDouble(0x3fd3ea62d735b93cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 7, 7, 1, "\ud9dd\ude9c", "\u208f\ua082", "\udb0a\udd46",
        12, 63670, -518384910, 57447485029251584L, -99126L, true, false, (char) 44290, (char) 54019,
        Double.longBitsToDouble(0x3e97e00000000000L), Double.longBitsToDouble(0x3fe79dca485300eeL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 14, 14, 3, "\ud810\ude82\ud8e7\uddfe\u3b25\ud969\udf62\udb28\udc0b\udbe5\udfe3\ud9b9\udcec\ud8c1\udc22\uda4b\udc53\udb59\udf41", "\ucf18\ua315\u2ac1\u61c2\uc4be\u90df", "\ua0f5\udb0d\uded6\uda2e\udf03\udae5\udc50\udb66\udf81\ud988\udf52\u8b01\udb31\ude3f\udaff\udd4d\udac7\udf4c",
        8, 44096, -135062787, 1789272830693013097L, -29790L, true, false, (char) 14005, (char) 42152,
        Double.longBitsToDouble(0x3fecffcf99ba5ea0L), Double.longBitsToDouble(0x3fe1ca8b0e468785L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=void |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 2, 5, 5, 14, "\ud9f5\udfde\ud8f0\ude7c\ud846\udf06\ud97a\udebb\uf6b8\ud9cb\udf89\u9456\udae4\udd53", "\u3e1b\u43d8\u52ce", "\ud853\uded7\ud92b\udcf3\udb70\udd5a",
        4, 46045, -126020958, 5824569781044669294L, -83990L, false, true, (char) 4573, (char) 57825,
        Double.longBitsToDouble(0x3fd31da5e69bff36L), Double.longBitsToDouble(0x3fca53bcb554d33cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\012",
        Z.run(T, 1, 9, 12, 1, "\ud9dd\ude9c", "\u4861\u5883", "\udae4\udd53\u13b0\uda22\udc12\uda5e\udf7f",
        56, 50866, 940927097, -1101387532837367346L, 97123L, true, false, (char) 54019, (char) 442,
        Double.longBitsToDouble(0x3feadfc7e8386eefL), Double.longBitsToDouble(0x3fbb61eb0dcbd210L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.joda.time.format.PeriodFormatterBuilder:@? |this=org.joda.time.format.PeriodFormatterBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 12, 1, "\ud9a5\ude92", "\ub3ad\u5883", "\udae4\udd53\u3194\u9a94\000",
        23, 66995, 40997, -785448960L, 97123L, true, false, (char) 44575, (char) 58880,
        Double.longBitsToDouble(0x3feadfc500386eefL), Double.longBitsToDouble(0x3fbb61eb0dcbd210L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.joda.time.format.PeriodFormatterBuilder|append|org.joda.time.format.PeriodFormatter|new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|append|org.joda.time.format.PeriodPrinter,org.joda.time.format.PeriodParser|new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|append0|org.joda.time.format.PeriodPrinter,org.joda.time.format.PeriodParser|new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendDays||new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendField|int|new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendField|int,int|new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendHours||new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendLiteral|java.lang.String|new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendMillis||new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendMillis3Digit||new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendMinutes||new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendMonths||new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendPrefix|org.joda.time.format.PeriodFormatterBuilder$PeriodFieldAffix|new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendPrefix|java.lang.String|new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendPrefix|java.lang.String,java.lang.String|new:org.joda.time.format.PeriodFormatterBuilder:",
    "M|org.joda.time.format.PeriodFormatterBuilder|appendSeconds||new:org.joda.time.format.PeriodFormatterBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
