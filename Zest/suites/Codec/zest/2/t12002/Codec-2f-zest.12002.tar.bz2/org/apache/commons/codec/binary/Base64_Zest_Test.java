package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base64_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -5185271355049743542L, -66510L, true, true, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 6, 9, 4, "\uda34\udd55\udb0c\udd19\udae6\udf33\ud965\udd84", "\u8274", "\ue5a5\uda54\udfd8\ud986\udead\ud9c6\ude0f\ud96d\udd21",
        44, 29906, 460971019, -2143595455063643324L, -51181L, true, true, (char) 62572, (char) 31244,
        Double.longBitsToDouble(0x3fb3b41569f0b550L), Double.longBitsToDouble(0x3fdf7fce9a1995d6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[B:[[100, 66, 101, 106, 55, 82, 85, 56, 55, 84, 89, 61]] |a0=[B:[[116, 23, -93, -19, 21, 60, -19, 54]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 12, 1, 12, "\ud8a4\udf47\ud8d3\ude1d\uda45\ude6c\ud81d\udd66", "\u832c\uae3c<\ub0e6\u9297\u6953", "\ud9a9\udd34",
        17, 72246, -499094710, 8517480367699979605L, 23552L, false, true, (char) 31337, (char) 35348,
        Double.longBitsToDouble(0x3fec5c6666db1f17L), Double.longBitsToDouble(0x3fa6f133ef927fa0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, -119, 27, 34, -115, 42, 20]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\udb3f\udc52\udab9\ude4b\uda52\uddbd\ud85a\ude44", "\u27ca", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -5185271355049743542L, -87942L, true, true, (char) 18273, (char) 23123,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 17, 3, 16, "\ud9e3\udd58\udb94\ude09\udb5e\ude20\uda2c\udd6b", "\u8274\ua55d\u652a\u06c1\u6763\uc681\u27a8\ud7f0\ube9b\u290c", "\ud84e\ude44",
        21, 46821, -584195424, -9187167735811124998L, 23813L, false, false, (char) 33797, (char) 23814,
        Double.longBitsToDouble(0x3fef01275f3e488cL), Double.longBitsToDouble(0x3fb49612c2c63f38L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 3, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, 3127247657169349579L, -66510L, true, true, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e0cb4e3aL), Double.longBitsToDouble(0x3fd3b861c7afbec6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[B:[[68, 121, 73, 122, 69, 105, 76, 51, 67, 65, 61, 61]] |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 13, 1, 0, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -5185271355049743542L, -66510L, false, false, (char) 4709, (char) 45514,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b555db1f17L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[86, 37, -41, -18, 34, -123, 8]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\ud886\udd55\udb07\udc1e\uda52\uddb5\u0138", "\u8274", "\ud8d2\udff2\ubded\uda50\udfbb\ud9c6\ude0f\ud96d\udd21\udbad\udd36\udb78\udc6e\ud952\udeef\ud89a\udd89\ud84e\ude44\uda99\udd2e\udab0\udebc\uda9e\udc92\uda31\uddc3\ud8b5\udffb\udbe4\udda3\ud802\udcd9\ud9dd\udddc\ud8d4\udc6f\udb4b\udc26\ud9fc\udc19\ud932\udde0\ud8a7\udd80\ud920\udcf1\ud834\udddf\ud93c\udfec\udb48\udfc3\udb27\udf75\ud9ce\ude71\ud8a9\udf2b\ud91a\udd58\ud88c\udef1\uda85\uddd7\udb3c\udf45\udb72\ude5b\uda09\udff2\udbad\udf9c\ud993\ude6f\ud9d9\udefd\udaaa\udc72\uc455\ud8f4\udee7\udae3\ude68\u73e0\ud859\ude51\ud802\uddf1\uda05\udf2f\udbd9\udc0e\ud96b\udeea\udbf5\udcfa\ud8fa\udd17\ud86a\udcbe\ud96a\ude78\ud8a9\udf15\ud9f6\udc90\ud948\udded\ud9ba\ude50\udbef\udfd8\ud9d3\udfb3\ud880\uddb7\udbdf\udd0e\udb8d\ude86\uda74\udce0\udbbe\ude42",
        17, 11485, -1482978368, 8772248973038715923L, 93630L, false, false, (char) 10107, (char) 5696,
        Double.longBitsToDouble(0x3fddb5e3842dc036L), Double.longBitsToDouble(0x3fe59fe300cfaff5L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, 51, 18, 34, -9, -72, 123]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\ud8e8\udeab", "\u8274\uae3c<", "\ud9c2\ude04\ud9c6\ude0f\ud96d\udd21\udbad\udd36\udb78\udc6e\ud952\udeef\ud89a\udd89\ud84e\ude44\ud801\udc41\uda29\udd33\uda9e\udc92",
        40, 21757, 380297294, 2240355012677887707L, -59177L, false, true, (char) 8291, (char) 58363,
        Double.longBitsToDouble(0x3fac69fddb17ead0L), Double.longBitsToDouble(0x3fe84fd4177431c7L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 7, 0, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\u834a\ud992\ude04",
        7, 47374, 989148858, -5154080735610508470L, -66510L, true, true, (char) 27588, (char) 23046,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.math.BigInteger:39 |a0=[B:[[15, 34, 14, 123, 74, 0, 120, -10]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\udb3f\udc52\uda3e\udfab\ud87a\udd30\udba8\udd26", "\u8274\uae3c\u6c34\ub0e6\u8929\uc6a8\u029f\u4462", "\ud952\udeef\ud89a\udd89",
        56, 16778, 408895821, -2509100241081557089L, -26350L, false, true, (char) 34290, (char) 63402,
        Double.longBitsToDouble(0x3fbad7bc97bba810L), Double.longBitsToDouble(0x3fd79aca8509046eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 17, 15, 1, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u8274", "\u5dd5",
        31, 86701, 723369861, -5166049495834201810L, 45197L, false, true, (char) 3461, (char) 63727,
        Double.longBitsToDouble(0x3fb368151500c2f8L), Double.longBitsToDouble(0x3fe4fee96e75e07cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 6, 16, "\udbaf\udc37\udaa3\ude1a\ud83c\udd9b\u4e82", "\u8274\uae3c<", "\ud8c3\ude77\udbc7\udcb2\ud990\udf61\u35ca\udb78\udc6e\uda70\udd3d\ud89a\udd89\ud84e\ude44\uda99\udd2e\udab0\udebc\uda9e\udc92",
        40, 21757, 380297294, 2240355013605025499L, 94220L, false, true, (char) 10535, (char) 58442,
        Double.longBitsToDouble(0x3fcca58a5e844f24L), Double.longBitsToDouble(0x3fe5acef3ce5c81eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.math.BigInteger:20 |a0=[B:[[15, 34, 70, 27, 93, 76, 8]]\0121=[B:[[15, 34, 70, 27, 93, 76, 8]] |a0=[B:[[15, 34, 70, 27, 93, 76, 8]]\012",
        Z.run(T, 2, 9, 11, 16, "\udb3f\udc52\uda76\udd4b\ud88d\udd7c\u0138", "!", "\uda9a\udcc1\ud964\uddbd\uda8d\udc60\ud99b\udf0f\ud96d\udd21\udbad\udd36\udb77\udfbf\ud952\udeef\ud89a\udd89\ud84e\ude44\uda99\udd2e\udab0\udebc\udbf9\udcdf\uda31\udd84\udb88\udfa5\udbe4\udda3\ud802\udcd9\ud837\udd36\ud8fc\udcd2\ud90d\udcdc\ud847\udd7d\uda59\uded9\udb13\ude53",
        44, 34392, -2023729644, -581044712432256796L, 4390L, true, false, (char) 62281, (char) 50687,
        Double.longBitsToDouble(0x3f9f26faae27a4e0L), Double.longBitsToDouble(0x3fda2fc3f5aadbeeL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.math.BigInteger:220 |a0=[B:[[15, 34, 51, 18, 34, -109, 8, 74]]\0121=[B:[[-36]] |a0=[B:[[15, 34, 51, 18, 34, -109, 8, 74]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 6, "\udb3f\udc52\ud963\udd42\uda52\uddc3\u0138\ud87a\udc32\ud8eb\udddb\udb8c\udc36", "\u7c61\u8929\uc6a8\u029f", "\udb07\udc16",
        38, 46290, 1992960836, -2930573618647711344L, -26343L, false, true, (char) 34290, (char) 8335,
        Double.longBitsToDouble(0x3fe3739e0de75a1cL), Double.longBitsToDouble(0x3fe5c87947a8259eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-100, -32, 51, 126, 34, -9, 8]]\012",
        Z.run(T, 1, 9, 1, 16, "\udbcc\udd10\ud963\uddae\uda52\udd27\u0138", "\u8274", "\ud825\udebc\ud907\udfad\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -4842722968521733996L, 21554L, true, true, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e34ed055L), Double.longBitsToDouble(0x3fe823cb702e1f17L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-5, -21, 72, -81, -119, -91, 127, -73]]\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 3, 16, "\ud82b\ude1b\ud978\udedf\ud8b9\uded5\udbaf\udfe7", "\u8274", "\ud8e7\udee6\ud842\ude56\ud9c2\ude31\ud8e6\ude1f",
        22, 74317, 485832378, -5185271355049743542L, -64718L, true, true, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b55061a9d6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 12, "\udb3f\udc52", "\u671c", "\ub307",
        -5, 88896, 42654, 0L, -100000L, false, false, (char) 0, (char) 14125,
        Double.longBitsToDouble(0x3fea55c05344e240L), Double.longBitsToDouble(0x3fe693b651000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.math.BigInteger:64445 |a0=[B:[[43, 55, 51, 18, 34, -9]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\ud85b\ude67\ud963\udd42\uda52\udd27", "\u6658\u2229\u7a59<\ub0e6\u8929\uc6a8", "\udbad\uddeb",
        5, 55320, -499094710, 8559701611223745234L, 23552L, true, true, (char) 32497, (char) 5539,
        Double.longBitsToDouble(0x3fe820b556db1f17L), Double.longBitsToDouble(0x3fdb8e83b1d6a73aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-50, -11, -41, -12, -88, -92, -16]] |this=org.apache.commons.codec.binary.Base64:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 5, 1, 10, "\udbfe\udc25\ud807\ude24\ubad8\udbd4\udc20", "\u8274", "\ud8bf\udeee\ud9ad\uddcc\uda78\udc84\ud9c6\ude73",
        31, 55054, 485832378, -5185271356059578358L, -66510L, true, true, (char) 26566, (char) 32716,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\udad2\udce0", "\u1267\ucff5 \ub0e6\u8929\uc6a8\u029f\u4462\u496f\u277e\u51e3\u209d\u0687\u716c\u7f15\u8a02\u6a45\u8df6", "\ud824\udf20\udae2\udd24\ud9c1\udcda\ud925\udc63\ud9e0\udd13\ud9c2\udfa3\ud876\ude06\udbcb\udc02\ud82f\udfbe\uda64\udf65\ud84d\ude19",
        19, 13060, -1011947720, 1340178897224812494L, 89359L, false, false, (char) 34198, (char) 1039,
        Double.longBitsToDouble(0x3fc564b5df065e64L), Double.longBitsToDouble(0x3fc35886e34e8b50L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 8, 1, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\udbf6\udfb2", "\u8274\uae3c<\ua981\u758b\u93ca", "\ud90f\udc0a\udb78\udc6e\ud952\udeef\ud89a\udd89\uda2a\udfbd\uda99\udc69\udab0\udebc\uda9e\udc92\ud937\udfc8\udb86\udf4d\ud964\udfdf\ud802\udcd9\uda97\udc39\ud9dd\udca2\uda93\uddf7",
        37, 48705, -240666580, 1652299670298756734L, 61287L, false, false, (char) 24544, (char) 31782,
        Double.longBitsToDouble(0x3fd768d20a91301cL), Double.longBitsToDouble(0x3fedb05610fcdbb0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, -53, 30, 34, 77, -68, 60]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\udb3f\udc52\udbfb\udd4e\uda52\udd7d\ud8ec\udc6c\ud899\ude32\ud94c\udc2a\udb8c\udc36\ud8a5\udd98\udbbd\udd83\ud8d2\udff2\udb42\uddd6\ud982\udc57\ud9c6\ude0f\udb3e\udf3c\udbc6\uddf1\udb78\udc6e\ud873\ude5e\ud8ed\udff3\udb87\udec0\ud80e\ude41\udab0\udebc\ud9c4\udf86\uda0d\ude11\ud814\udfab\udbe4\udda3\ud802\udcd9\ud8c3\udd4f\udb1b\udca5\udb64\udfa5\ud813\udcfa\ud943\udc29", "\u47ac", "\ud898\udf56\udaa3\uded0\udb71\udf5a\ud938\udc55\ud833\udd1c\ud9aa\ude12\ud8bc\udc61\udb5b\ude51\udbf6\udfa4\ud836\udc2b\ud896\udce0\udbc9\ude4a\udb0d\udf01\ud886\udd68\udbca\udcae\ud9e9\udca5\ud8f1\uddf2\ud8af\udd75\udb43\udc55\ud8ab\uddf3\udb1d\uded8\ud8bb\udc44\ud875\udcaf\uda5c\udfc7\ud944\udf4f\udada\udde4",
        39, 71970, -473988364, -5618786873754150613L, 69498L, true, true, (char) 31589, (char) 19343,
        Double.longBitsToDouble(0x3fd55a828ba1398cL), Double.longBitsToDouble(0x3fd8782040d9adbcL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[69, 61, 51, 55, 34, -9, 8]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\uda75\udd6d\ud963\udd67\uda52\udd27\u0138", "\u8274\u5d34<\u06f5\u80dd\u3771\u029f\u4462\u496f\uadf5\u64b4\u7ef6\u480e\u716e\ubaa7\uc95a", "\ucdf0\ud802\udcd9",
        49, 92354, -2147111394, 3965297166281762345L, 24734L, false, false, (char) 6864, (char) 33635,
        Double.longBitsToDouble(0x3fd301408402a84aL), Double.longBitsToDouble(0x3fc8e4f17d2d1a40L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null\012",
        Z.run(T, 2, 0, 8, 16, "\000", "\u671c\u52ca\ud16d\u8274\uae3c\ub6c0\u0a48\u8929\u466d\u1b19\u4462\u496f\u36ba\u1739", "\udbea\ude04\000\000\000\000\000\ud802\udcd9\ud8ac\udea3",
        13, 5889, -33323976, -6531532135257847017L, -2489L, false, false, (char) 13537, (char) 489,
        Double.longBitsToDouble(0x3fd16a4869472858L), Double.longBitsToDouble(0x3fe73c30169a29c3L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-80, -76, 51, -54, -45, 17, -105, -44]]\0121=[B:[[115, 76, 81, 122, 121, 116, 77, 82, 108, 57, 81, 61, 13, 10]] |a0=[B:[[-80, -76, 51, -54, -45, 17, -105, -44]]\012",
        Z.run(T, 2, 9, 13, 12, "\udbe0\udee4\ud963\uddfa\ud803\udf41\udac7\udc04\ud87a\udc32\ud8eb\udddb\udb8c\udc36\uda88\udea9\udbbd\udd83\ud8c2\uddf2\ud97b\udfa2\ud9c2\ude04\ud9c6\ude0f\ud96d\udd59\udbad\udd36\udb97\uded2\uda40\udf90\ud894\udfbe\ud84e\ude44\uda99\udd2e\udab0\udebc\uda50\udcd3\ud81e\udea3\ud9e0\udcc1\ud979\udce1\uda32\udf12\udb4c\udcd3\uda5b\udc0b\udb92\udc30\uda35\udf48\udb76\udf3f\u0d88", "\u45e3\u8ec5", "\uec84",
        -2, 86478, -830415143, 4521170014142413120L, -50496L, true, true, (char) 1666, (char) 39228,
        Double.longBitsToDouble(0x3fc4d5ec685f14f0L), Double.longBitsToDouble(0x3fbbbf78c535b188L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.math.BigInteger:16421641 |a0=[B:[[43, 112, -58, 77, 74, -120, -14, -9]]\0121=[B:[[-6, -109, 9]] |a0=[B:[[43, 112, -58, 77, 74, -120, -14, -9]]\012",
        Z.run(T, 2, 9, 8, 4, "\ud95b\udca0\ud9f6\ude7d\ud87a\udfb8\uda22\udc27", "\u923d", "\ud8d2\udff2\ud9f3\udc4f\udb8c\udfa6\ud9e3\uddfe\ud96d\udcff\udbad\udd36\uda0a\udd5d\ud952\udedf\ud89a\udd89\ud84a\ude0a\uda99\udd2e\ud817\udf0f\ud82b\udff4\ud925\uddbd\udb88\udfa5\ud818\ude80",
        41, 87515, 616785229, -3132259651025914730L, -15130L, true, true, (char) 40251, (char) 18899,
        Double.longBitsToDouble(0x3fe15bb365b0563aL), Double.longBitsToDouble(0x3fe2efec31d313ebL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, 28, 16, 34, -9, -68, -2]]\0121=void |a0=[B:[[15, 34, 28, 16, 34, -9, -68, -2]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 7, 2, "\udb3f\udc52\udb4c\udc40\uda52\udd27\udbec\udf2e", "\u7472\u7caf", "\udb0c\udc7b\ud9cd\ude22\udb48\udccd\udb8f\udc01",
        33, -326, -1207290067, -2143595455063643324L, -51169L, false, false, (char) 31948, (char) 32497,
        Double.longBitsToDouble(0x3fb3b4157820b550L), Double.longBitsToDouble(0x3fe6d8f93871cde1L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[B:[[89, 115, 89, 114, 89, 121, 76, 51, 104, 65, 69, 61, 13, 10]] |a0=[B:[[98, -58, 43, 99, 34, -9, -124, 1]]\0121=[B:[[89, 115, 89, 114, 89, 121, 76, 51, 104, 65, 69, 13, 10]] |a0=[B:[[98, -58, 43, 99, 34, -9, -124, 1]]\012",
        Z.run(T, 2, 13, 14, 2, "\ud992\udef6\ud95b\udc93\uda52\udd27\ud9b4\udd31\ud87a\udc32\ud8eb\udddb\udbfc\udf79\udb09\udf0e\udbc1\ude83\ud83b\udd85\ud84d\udefd\udbed\udc25\udbcd\udc09", "\uc50e", "\udb96\udf41\udb1d\udeb1\ud9a7\ude10\uda9f\udc24\uda7f\udea9\udb88\udf8b\udabe\udc10\udbee\udd37\ud97d\udcd9\uda0d\ude24\udb54\udefc\udb54\ude3f\udb58\uded7",
        54, 89095, 314106757, 4135469506061914879L, -97029L, true, true, (char) 44683, (char) 57596,
        Double.longBitsToDouble(0x3fe9ec38c07fa118L), Double.longBitsToDouble(0x3fbda2c4fceb60d8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.math.BigInteger:14555277 |a0=[B:[[15, 34, 51, 18, 104, 105, 78, -97]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\udb3f\udc52\ud963\udd42\udb98\ude99\ud87e\udecf", "\u8274\uae3c<\ub0e6\u8929\uc6a8\u029f", "\udb78\udc6e",
        38, 46290, 1992960836, -6893741289361882803L, -26350L, false, true, (char) 34290, (char) 44342,
        Double.longBitsToDouble(0x3fe3edc6ee24c7efL), Double.longBitsToDouble(0x3fe22ae5ac7bb5feL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u8274\uae3c<\ub0e6\ucaa4\uc697\u029f", "\udb78\udc6e",
        38, 46290, 1992960836, -6893741290733747891L, -73669L, true, false, (char) 53712, (char) 55815,
        Double.longBitsToDouble(0x3fd70a095aa66e96L), Double.longBitsToDouble(0x3fd399ef6cbea714L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34]]\0121=[B:[[68, 121, 73, 61]] |a0=[B:[[15, 34]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 16, 11, "\udb3f\udc52", "\u671c\u35d6\ud16d\u8274\uae3c<\ub0e6\u8929\uc6a8\u029f\u4462\u496f\u290c\u51e3\ud007", "\udab0\udebc\udad2\ude1d\ud8a6\udfde\udb88\udfa5\udbe4\udda3\ud802\udcd9\udb27\udda0\ud9fc\uddd0\uda09\udd7b\udba4\udc9c\ud835\udfe5\ud8a1\uddb2",
        55, 39704, -978173429, 8455380472751998460L, 33554L, false, true, (char) 5667, (char) 4511,
        Double.longBitsToDouble(0x3fb794491877b388L), Double.longBitsToDouble(0x3fe7ac13351448c2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 3, 1, 16, "\udb3f\udc52\uda31\udd49\udb26\udc52\uda07\uddc3", "\u8bf0\ua820", "\ud9ad\uddcc\ud9c2\ude04\ud944\uddcf\uda2e\udca0",
        35, 13971, 1079564189, -2093125483346908348L, -51145L, false, false, (char) 31948, (char) 32497,
        Double.longBitsToDouble(0x3fb3b4157820b550L), Double.longBitsToDouble(0x3fe6d8f8bc042dc1L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[51]] |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\0121=[B:[[68, 121, 73, 122, 69, 105, 76, 51, 67, 65, 61, 61, 13, 10]] |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\012",
        Z.run(T, 2, 10, 15, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u93f1", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -5185271353161782454L, -66510L, true, true, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e01a7ce0L), Double.longBitsToDouble(0x3f86decfe3becc40L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=null\012",
        Z.run(T, 2, 3, 13, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138\ud87a\udc32\ud8eb\udddb", "\u14fa", "\ud9c2\ude04\ud9c6\ude0f\ud96d\udd21\udbad\udd36\udb78\udc6e\ud964\udfef\uda4b\udf6f\ud84e\ude6c\uda99\udd2e\uee78\uda9e\udc8f\uda31\uddc3\ud834\udcfa",
        30, 58300, -1509398821, 7487935069874810586L, 7607L, true, false, (char) 5713, (char) 19723,
        Double.longBitsToDouble(0x3fbf50e29663a0b0L), Double.longBitsToDouble(0x3fdfe46b92b9ef86L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, 28, 6, -48, -62, 9]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 2, 16, "\udb3f\udc52\ud84c\udf36\000\udbf2\udf39", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -5185271355049743616L, -66510L, true, true, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e000d055L), Double.longBitsToDouble(0x3fe8200000db1f17L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-70, -18, 22, -45, 34, -9, 8]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 4, 1, 16, "\udaea\udd1e\uda46\udd03\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -7995517522528933062L, -66510L, true, true, (char) 6534, (char) 40699,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.math.BigInteger:56852 |a0=[B:[[15, 34, 51, 18, 34, -9, 104, 83]]\0121=[B:[[-34, 20]] |a0=[B:[[15, 34, 51, 18, 34, -9, 104, 83]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 0, "\udb3f\udc52\ud963\udd42\uda52\udd27\udb98\ude83", "\u8274\uae3c", "\ud96a\udcfd",
        6, 30272, -1202814712, -4848282030972782918L, -66510L, true, true, (char) 35478, (char) 27737,
        Double.longBitsToDouble(0x3fe3af03e14ed055L), Double.longBitsToDouble(0x3fd641e9da0ca2e2L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=[B:[[102, 116, 108, 50, 115, 83, 76, 51, 67, 65, 61, 61, 13, 10]] |a0=[B:[[126, -39, 118, -79, 34, -9, 8]]\0121=[B:[[118]] |a0=[B:[[126, -39, 118, -79, 34, -9, 8]]\012",
        Z.run(T, 2, 13, 10, 16, "\udaae\udd09\udaa6\udde1\uda52\udd27\u0138", "\u8a61", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 79902, 485832378, -5185271355049743542L, -66510L, true, true, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[B:[[-101, 12, -102, 19, -95, 115, -38]] |a0=[B:[[-101, 12, -102, 9, 19, -95, 115, -38]]\0121=[B:[[109, 119, 121, 97, 67, 82, 79, 104, 99, 57, 111, 61, 13, 10]] |a0=[B:[[-101, 12, -102, 9, 19, -95, 115, -38]]\012",
        Z.run(T, 2, 11, 15, 16, "\udacb\ude3c\ud9ca\udc39\udb43\udfd1\udaa3\udf0a\ud90b\ude12\udb2d\ude0b\udad7\udfcd\uda3d\udfab\ud956\udeae\ud8d2\udff2\udbdb\udda2\ud882\udc67\ud943\ude70\ud9ee\udcc9\ud9e9\udf3e\ud8af\ude50\ud952\udeef\ud89a\udd89\ud8c0\udfb4\uda7d\udd57\udac8\uded0\uda9e\udc92", "\u4c33\u9a60\uc63c\u4a37\uae9b\u337a\u6fac\uab97\ucfc0\uac69\ub7b5\uc6cd\u3291\u7afa\u2ac5\u2a77\u7854\u14a8\u8622\u5efc\u12c4", "\uda8f\ude69\ud879\udc6c\udb07\udd31\uf747\ud90d\udf5e\ud881\udc90\uda55\udddb\udbbc\ude23\uda2e\udc09",
        49, 71184, -1066623819, -397482883364825757L, -47561L, true, false, (char) 50653, (char) 43609,
        Double.longBitsToDouble(0x3fdf69288c9ea2c2L), Double.longBitsToDouble(0x3fe1642425ea4dbfL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.math.BigInteger:239 |a0=[B:[[15, 34, -118, 55, -77, 8, -34, 45]]\0121=[B:[[15, 34, -118, 55, -77, 8, -34, 45]] |a0=[B:[[15, 34, -118, 55, -77, 8, -34, 45]]\012",
        Z.run(T, 2, 9, 11, 16, "\udb3f\udc52\ud9ba\ude67\u28e3\u0138\ud80e\udf5d", "\uae3c<\ub0e6\u8929\uc6a8\u029f", "\udb78\udc6e\ud952\udeef\ud89a\udd89\ud84e\ude44\uda99\udd2e\udab0\udebc\uda9e\udc92\udaed\udde1\udb2c\udc63\u529c\ud802\udcd9\ud8d4\udd57\ud82b\udd9d\udbf7\udcae\udb59\udcb2\ud8bc\udedb\ud95f\udd4e",
        4, 39584, 435876132, -7831410710543471569L, 63477L, true, false, (char) 65316, (char) 35345,
        Double.longBitsToDouble(0x3fd360c9afc841d2L), Double.longBitsToDouble(0x3fed64a65cccdfb9L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[B:[[-44, -27, -48, -48]] |a0=[B:[[-44, -27, -48, -48]]\0121=[B:[[49, 79, 88, 81, 48, 65, 61, 61]] |a0=[B:[[-44, -27, -48, -48]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 0, 0, "\uda04\ude15\000\ud500", "\000", "\000",
        14, 33096, 15877741, 210006720905307L, -85990L, false, false, (char) 47178, (char) 57856,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=[B:[[15, 34, 51, 18, 34, -9, 8]] |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\0121=[B:[[15, 34, 51, 18, 34, -9, 8]] |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\012",
        Z.run(T, 2, 11, 11, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -5185271355049743542L, -66510L, true, true, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=[B:[[-41, -89, 19, 91, -114, -104]] |a0=[B:[[-41, -89, 19, 91, -114, -104]]\0121=[B:[[49, 54, 99, 84, 87, 52, 54, 89]] |a0=[B:[[-41, -89, 19, 91, -114, -104]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 0, 16, "\ud907\uddd7\ub943\uda8b\udcbe\u0fc8", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\u8314\ud9cf\udcff",
        34, 9782, 476234988, -5185271355049743542L, -66510L, true, true, (char) 24386, (char) 42172,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b553e97017L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 3, 0, 16, "\udb3f\udc52\uc148\ud8e4\udf37\udb3c\udc9a", "\u3719\u5b69<\ub0e6\u8929\u4d46\u6ad9\u4462\u1ae5\u290c", "\ud949\udf4d",
        50, 46821, 1429070496, -9151680623938265483L, -84346L, true, true, (char) 25541, (char) 17846,
        Double.longBitsToDouble(0x3fecfe13a8df3b59L), Double.longBitsToDouble(0x3fef63e20a0fe397L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 12, 15, "\udb50\udde6\ud963\udd42\uda52\udd27\u0138", "\uad74", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud837\ude68",
        6, 69558, 485832378, -5185271355049743542L, -75313L, true, false, (char) 14582, (char) 24026,
        Double.longBitsToDouble(0x3fd7f87e609da0d0L), Double.longBitsToDouble(0x3fa48b5558dd9310L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\0121=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 15, 0, 0, "", "\000\u092d\000\u0130\u8274\uae3c<\ub0e6", "\ud9c6\ude0f\ud96d\udd21\u712e\000\udb10\udeeeJ\000\uda99\udd2e\000\uda9d\udff2\ud937\udfa6\udb7e\udfa0\udbe4\udda3\ud802\udcd9",
        57, 61590, -976723019, 572201606704219012L, -56852L, true, true, (char) 47582, (char) 19283,
        Double.longBitsToDouble(0x3fedd7a7d47b0ff3L), Double.longBitsToDouble(0x3fe4021f2744ef5bL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=[B:[[68, 119, 119, 77, 88, 90, 66, 70, 79, 110, 65, 61, 13, 10]] |a0=[B:[[15, 12, 12, 93, -112, 69, 58, 112]]\0121=[B:[[68, 119, 119, 77, 88, 90, 66, 70, 79, 110, 65, 61]] |a0=[B:[[15, 12, 12, 93, -112, 69, 58, 112]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 14, 16, 1, "\udb3f\udd3c\ud83c\udc8d\udac0\udc75\u296a\udaa0\udd19\ud87d\udd93\udb8c\udc36\uda88\udea9\udb86\udc90\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9cc\udeb6\ud96d\udd21\ud88d\udf25\udb78\udc72\ud952\udeef\ud89a\udd89\ud84e\ude44\udbf9\udd25\u8655\udab2\udf82\ud80a\ude2f\ud9e6\udd17\udb73\udeb4", "\u5d9a\ud265\u0be2\u1afa", "\udb93\udedf\udaf0\udfab\uda2a\ude0e\ud835\udfe6\ud963\udeb0\ud82d\udd92",
        1, 85730, -1348305016, 2747496530061570895L, -93879L, true, false, (char) 55634, (char) 63685,
        Double.longBitsToDouble(0x3fd9b383edb6ecacL), Double.longBitsToDouble(0x3fc4729bdef5522cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 13, 12, 5, "\udb3f\udc52\udb46\ude53\ud8a7\udf15\ud959\udc3c", "\u8274\uae3c<\ub0e6\u8929\uc6a8\u029f\u4462\u496f\u290c\u51e3\u4882\ucace\u7151\uae2f\uc95a\u6a45\u8df6\u832b\u63dd\ua54e\u4137\u32a9\u29de\u22f5\ubfd4\uc62f\ub866\u396d\u7a6a\uab7f\u029a\ub3d5\uc54d\u5e43\u637d\u4b24\u779d\u1bef\u7a5e\u2802\u21a1\u2ec8\u2e87\u166c\u529b\u3ca9\u9878\u2e34\ua089\ub8af\u4375", "\uf84b\udb70\udc5a\udb04\udf63\u824e\ud8ba\ude7a",
        9, 22963, -56146874, 3650805173142145423L, 33727L, true, false, (char) 21943, (char) 942,
        Double.longBitsToDouble(0x3fecf7a78ab14fceL), Double.longBitsToDouble(0x3fe9f3f7f7595d1aL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[15, 34, 51, 18, 34, -9, 125, -36]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 4, 1, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\ud8ad\udd0c", "\u8274\ua62f\ud44f", "\ud9c2\ude04\ud9c6\ude0f\ud898\udf38\udbad\udd36\udb78\udc6e\ud952\udeef",
        50, 27836, -1605074222, 1756194178081874592L, 56043L, false, false, (char) 28078, (char) 49393,
        Double.longBitsToDouble(0x3fb3381fb9fb1528L), Double.longBitsToDouble(0x3fea1b30af24cad3L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udb3f\udc52\ud963\udd42\uda52\udd27", "\u0f65\u8274\u60df<\ub0e6\u8929\uc6a8\u029f\u09b8\u496f\u290c\u51e3\ud007\uc71e\u2336\u6ce2\uc95a\u6a45\u8df6\u832b\u63dd\u3036\u9757\uac2c\u9569\u9a52\uccb0\u775f\ua996\uc75c\u29b8\u319b\u251c\u37ac\u10e4\u7fc7\u0cad\u646c\u3e02\u5554\u2f24\ubf52\u4929\u1a4d\u3506\u46d1\u5bff\u6a8d\u2c96\u35ff\u9e39\u77c0\u5b1a\u727c\u7023\u9025\u9f0f\ub96c\u9f32\u3111\u5ef3\u7b93\u6753\u9959", "\udb05\udc60\udb5d\udf6f\u50ec\uda9e\udf76\ud95f\udf20\ud844\udff1\uda51\uddb2",
        -3, 18084, -189307482, -3005623726537254157L, -78830L, true, false, (char) 27274, (char) 3399,
        Double.longBitsToDouble(0x3fe8d8eb48d2f068L), Double.longBitsToDouble(0x3fdc871d6a588094L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=[B:[[81, 116, 77, 122, 69, 105, 76, 51, 73, 100, 65, 61, 13, 10]] |a0=[B:[[66, -45, 51, 18, 34, -9, 33, -48]]\0121=[B:[[81, 116, 77, 122, 69, 105, 76, 51, 73, 100, 65, 61, 13, 10]] |a0=[B:[[66, -45, 51, 18, 34, -9, 33, -48]]\012",
        Z.run(T, 2, 15, 15, 14, "\udb72\udc03\ud963\udd42\uda52\udd27\uda51\udf00\udade\udd72\ud99e\udc35\ud9a0\udff6\udbe3\udf38\ud828\udf06\uda71\udc07\udb74\udfdb\ud818\udfeb\ud853\udcf9\udaed\uddb8", "\u9854\u6692", "\udb63\uddc1\uda97\udeca\udb35\udd85\udac6\udf03\uda4b\udf17\ud8c2\udda3\ubbf2\ud90f\udfbb\ueb71\ud824\udf45\uda34\udfd8\ufe2d",
        11, 56020, -1223485505, 3491370995606530696L, -11810L, true, true, (char) 7002, (char) 4314,
        Double.longBitsToDouble(0x3f8e00addff7c340L), Double.longBitsToDouble(0x3fd5ed12a939b4f0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[61, -39, 95, -114, 1, -119, 41]]\0121=[B:[[61, 95]] |a0=[B:[[61, -39, 95, -114, 1, -119, 41]]\012",
        Z.run(T, 2, 9, 10, 0, "\udb6d\udd09\udb8f\udebe\ud831\udfb9Y", "\u8274", "\ud8d2\udff2\ud8a4\uddc2\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -5170916131237500086L, -66510L, false, true, (char) 22097, (char) 60535,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b552db1f17L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 4, "\ud84b\udf83", "\u6716\u35d6\ud16d\u8274\uae3c<\ub0e6\u8929\uc6a8\u64fd\ucb8d\ua047\u3f98\ubcc1\u01af", "\udab0\udebc\ud9d3\udf29\uda31\uddc3\udb88\udfa5\udbe4\udda3\ud802\udcd9\udb11\udf57\ud9e2\udf6b\uda1b\udd36\ud85f\udfe7\uda20\udcc4",
        52, 31315, -681221597, -4011976194097807275L, -43321L, true, true, (char) 59919, (char) 40928,
        Double.longBitsToDouble(0x3fe178b25e0c5f9eL), Double.longBitsToDouble(0x3feecac38a5e6ca9L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=[B:[[15, 34]] |a0=[B:[[15, 34]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 11, 1, 2, "\udb3f\udc52", "\u7c30\u3683\u0e9a\u8274\u40d6\uabfc\ub0e6\u88f4\uc6a8\u029f\uc332\u8665\u9858\ubbfc\u9c52", "\udab0\udebc\ud9f1\udf4f\ud9d3\udf7a\ud8b1\udc04\ud8c7\ude22\ud960\udfbe",
        17, 23739, 1939977482, 3086321712496836920L, -95882L, true, false, (char) 61889, (char) 38546,
        Double.longBitsToDouble(0x3fe59e568e6abec3L), Double.longBitsToDouble(0x3fdef77b4237e570L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\0121=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 2, 11, 8, 16, "", "\000\000\000\000\u826d\uae3c<", "\ud9c2\ude04\ud9c6\ude0f\ud96d\udd21\udbad\udd36\udb78\udc6e\ud952\udeef\ud89a\udd89D\000\000\uda9e\udc92",
        40, 21757, 380297294, 2240355013447739099L, 2356L, false, true, (char) 7525, (char) 39739,
        Double.longBitsToDouble(0x3fef31d2c6de06f8L), Double.longBitsToDouble(0x3fbad1e6aae68fc8L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=[B:[[68, 121, 73, 122, 69, 105, 76, 51, 67, 65]] |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\0121=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 14, 6, 2, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u0bf0", "\ud8d2\udff2\ud9ad\uddcc\uda64\udf4a\uda43\udfc4\ud96d\udd21\udbad\udd36\udb78\udc6e\ud952\udeef\ud89a\udd89",
        56, 16778, 408895821, -2509100241081558113L, 2114L, false, true, (char) 15602, (char) 40324,
        Double.longBitsToDouble(0x3fa3b981bac88120L), Double.longBitsToDouble(0x3fefed17d7f82b7aL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.math.BigInteger:33 |a0=[B:[[30, 73, -40, 99, 44, -76, -96, 127]]\0121=java.math.BigInteger:33 |a0=[B:[[30, 73, -40, 99, 44, -76, -96, 127]]\012",
        Z.run(T, 2, 9, 9, 16, "\ud94e\udc79\udb08\ude93\uda5c\udde4\ud8d0\udfaf", "\u8274", "\udafd\udc85\ud9ad\uddcc\ud9c2\ude04\ud979\udf09\ud92b\udc8a\udad4\udcea\ud272\udbe3\udf67\ud89a\udd89\ud84e\ude44\uda99\udd2e\udab0\udebc\uda02\udde4",
        27, 21757, 380297294, 8229985978701673017L, -64097L, false, false, (char) 20316, (char) 53211,
        Double.longBitsToDouble(0x3fc5b04181e66514L), Double.longBitsToDouble(0x3fd159d3e89bbb58L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=[B:[[68, 121, 74, 117, 114, 105, 76, 51, 67, 65, 61, 61, 13, 10]] |a0=[B:[[15, 34, 110, -82, 34, -9, 8]]\0121=[B:[[68, 121, 74, 117, 114, 105, 76, 51, 67, 65, 61, 61]] |a0=[B:[[15, 34, 110, -82, 34, -9, 8]]\012",
        Z.run(T, 2, 13, 12, 10, "\udb3f\udc52\udb9e\uddde\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud97c\udccc\ud9c2\ude04\ud9c6\ude0f",
        31, 79854, 485832378, -5185271355049743542L, -66510L, true, true, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=[B:[[48, 67, 122, 101, 54, 116, 65, 61]] |a0=[B:[[-48, 44, -34, -22, -48]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[-48, 44, -34, -22, -48]]\012",
        Z.run(T, 2, 0, 8, 16, "\000\ud95c\ude0e\ud51a\000", "\u8274", "\u009e\ud97a\udffd\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, 60666413056000L, -66510L, false, false, (char) 6239, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[51]] |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\012",
        Z.run(T, 2, 3, 10, 8, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, -5185271355047354806L, -44421L, true, false, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=[B:[[101, 108, 51]] |a0=[B:[[101, 108, 51, 18, 34, -9, 8]]\0121=java.math.BigInteger:31325 |a0=[B:[[101, 108, 51, 18, 34, -9, 8]]\012",
        Z.run(T, 2, 10, 9, 16, "\ud895\ude9c\ud963\udd42\uda52\udd27\u0138", "\u82ed\u6ce5\u3758\uabad\u1f8f\u5ec4\u6f48", "\udb71\udead\ud952\udeef\ud89a\udd89\ud9d7\udfca\uda99\udcbd\udab0\udebc\uda9e\udc92\uda31\uddc3\udb88\udfa5\udbe4\udda3\ud802\udcd9\ud985\udd70\udba4\udfec\udab5\udc41\u21be\ud944\udf77\ud9c2\udc2d",
        -2, 82482, 446960625, -7757507373277790497L, -19923L, true, true, (char) 11806, (char) 24617,
        Double.longBitsToDouble(0x3fedf8ee115dc9f1L), Double.longBitsToDouble(0x3f78c08778c12580L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[38, -21, 2, 28, 24, -9, 8, 102]]\0121=[B:[[]] |a0=[B:[[38, -21, 2, 28, 24, -9, 8, 102]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 10, "\ud956\udf1b\ud832\udd4c\uda48\udf27\u0138\udb96\udef2\ud851\uddba\udb0c\udd27\udb9d\udda4", "\u115b\u8891\u8f4d\u0704", "\ud952\udeef",
        22, 49348, -436436416, -5112762815300664728L, -9595L, true, false, (char) 32620, (char) 52412,
        Double.longBitsToDouble(0x3fe842b20240584dL), Double.longBitsToDouble(0x3fc09ce76ad36bfcL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=[B:[[47, 54, 72, 52, 76, 105, 76, 51, 67, 65, 61, 61]] |a0=[B:[[-1, -95, -8, 46, 34, -9, 8]]\0121=[B:[[47, 54, 72, 52, 76, 105, 76, 51, 67, 65, 61, 61, 13, 10]] |a0=[B:[[-1, -95, -8, 46, 34, -9, 8]]\012",
        Z.run(T, 2, 12, 15, 13, "\ud92f\udcd1\ud928\ude5e\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud925\udd08\ud994\udf2e\ud955\udc7a",
        28, 47374, 485832378, -5185271355049743542L, -66510L, true, true, (char) 64194, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e14ed055L), Double.longBitsToDouble(0x3fe820afbedb1f17L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=[B:[[72, 73, 122, 109, 71, 99, 81, 109, 67, 69, 111, 61]] |a0=[B:[[28, -116, -26, 25, -60, 38, 8, 74]]\0121=[B:[[72, 73, 122, 109, 71, 99, 81, 109, 67, 69, 111, 61]] |a0=[B:[[28, -116, -26, 25, -60, 38, 8, 74]]\012",
        Z.run(T, 2, 12, 13, 0, "\ud84c\udebc\uda16\udf49\udaf4\udc56\u0138\ud87a\udc32\ud8eb\udddb\udb8c\udc36\udb21\udfcf\udbbd\udd83\ud8d2\udff2", "\u029f\u4462\u58be\u290c\u51e3\ubf47\u6546\u9282\uae2f\uc95a\u6a45\u8df6\u5d9d\u5c75\ucccc\u351b\u0523\u9029\u5591\ud30c\ub5a9\u8898\ub406\ud77b\u21c1\ud06a\u6ada\u2ac1\ub017\u8e59\u57de\u4de6\u1481\ubfb4\u551b\u9bd0\u4cd6\u0b88\ubb52\u9dec\ucbaa\u8086\u1a8d", "\uda63\udc65\udb6f\udc35\udb6c\udd52\udad5\udf29\uda5c\udc12\udb6b\udce3\udbd0\udd8b\u5e5b\udb35\ude4e\ud895\ude0e\ud944\udc35\ud96d\udffc\udbc1\udded\uda78\uddf8\uda45\udd95\uda02\udc62\ud893\uddb7\ud92a\udcc2\uda9f\ude63\ud8b6\udeb9\udaa4\udfb6\udaed\udcd6",
        2, 29384, -2109803050, -137766935945570306L, -32243L, false, true, (char) 61968, (char) 38452,
        Double.longBitsToDouble(0x3fe8816fceab3234L), Double.longBitsToDouble(0x3fe5865ac719a3caL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, -17, 77, 15, -64, 7]]\0121=[B:[[68, 45, 57, 78, 68, 56, 65, 72]] |a0=[B:[[15, -17, 77, 15, -64, 7]]\012",
        Z.run(T, 2, 9, 14, 2, "\udb3f\udd1f\ud97d\udd3f\ud9f0\udf37", "\ucf2f\u7a34\u2426\u94e4\u1407\uaaeb\u63d2", "\udb63\udf5c\udbe0\udc24\ud80f\udf4d\ud8e1\udec8\ud859\ude57\ud902\udddb\ud894\udda3",
        37, 78009, -1454737296, -4203314838719863672L, 26078L, false, true, (char) 47815, (char) 45688,
        Double.longBitsToDouble(0x3fe979d42cd4941fL), Double.longBitsToDouble(0x3fe2e3bcc246a653L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-82]]\0121=[B:[[114, 103, 61, 61, 13, 10]] |a0=[B:[[-82]]\012",
        Z.run(T, 2, 9, 13, 3, "\ue6de", "\u671c\u35d6\ud16d\u308c\ub497<\u4643\u8929\u60b6\u61e2\u1b7b\u3552\ucff9\u5236\ud007", "\udab0\udebc\uda9e\udc34\uda31\uddc3\udb88\udfa5\udbe4\udda3\ud9f7\udcf5\udb50\uddb6\ud8c9\ude3f\uda0e\udcc6",
        34, 57935, 73548887, -7851360420322570567L, -12160L, true, true, (char) 42372, (char) 46547,
        Double.longBitsToDouble(0x3fe48d5fccb627efL), Double.longBitsToDouble(0x3fa75ed884570ee0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-61, 17, 37]]\0121=java.math.BigInteger:0 |a0=[B:[[-61, 17, 37]]\012",
        Z.run(T, 2, 9, 9, 16, "\udbf3\udf41\uae55", "\uaacb\ud16d\u8274\uae3c<", "\ud9c2\ude04\ud959\ude00\u0f30\udbc7\udec2\uda2c\udd68\ud8e6\udd1d\ud93f\uddf5\udaaf\udc79\ud8c3\udf90\ud9e4\udcda\uda9e\udc4d",
        40, 85669, 374908437, 5387958117904400950L, -9320L, false, false, (char) 32518, (char) 7249,
        Double.longBitsToDouble(0x3fcc35f0ff854e78L), Double.longBitsToDouble(0x3fcc40dd7f0e4348L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-28]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\u0214", "\u5def", "\udb8c\udc36",
        11, 31825, -771751936, -4903072202381703571L, 64187L, false, true, (char) 14193, (char) 21538,
        Double.longBitsToDouble(0x3fea55c05344e240L), Double.longBitsToDouble(0x3fe00000014da054L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[26, -100, -63, 34, -9, -76, 7]]\0121=java.lang.Boolean:false |a0=[B:[[26, -100, -63, 34, -9, -76, 7]]\012",
        Z.run(T, 2, 10, 4, 16, "\udb4a\udecc\u1df1\uda52\udd27\udbe4\ude37", "\ucc6e\ub390\ub4c7\u1215\u8929\u620d\u5d2b\u990a\u3710\u28b9\u51e3\ud007\u480e\u716e\uae2f\uc95a\ua8ef\uce2a\u832b\u64b9\u51d1\u240b\uc3f0\u34c9\u9afc\u3e56\u4681\u1bd4", "\ud960\udfa8\uda72\udd45\ud835\udc26\ud998\udfc7\ud918\udd28\ud906\udd93\udbb5\udc25\ud9a4\udcba\udb9e\udd5b\ud8e2\udf87\udbe4\udc2f\ud8b8\ude7c\ud960\udddd\ud9a2\ude57",
        25, 78419, 233112038, -6599197704485510375L, -24350L, true, false, (char) 45728, (char) 57165,
        Double.longBitsToDouble(0x3fece5970b481e2aL), Double.longBitsToDouble(0x3fdd7264e33f1e62L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[4, 37]]\0121=java.math.BigInteger:0 |a0=[B:[[4, 37]]\012",
        Z.run(T, 2, 10, 9, 8, "\uda34\udd55", "\uc503\u670e\u3815\u99c2\u6824\u868b\u3b0f\u86c7\u168a\u7991\u1aa0\ud2fc\ub15c", "\udba6\udd70\uda99\udd02\udab0\udebc\uda4d\udc1f\udbc2\ude18\udb8a\ude64\udbe4\udda3\ud997\udd0f\ud8a4\uded6\udadd\udd21\ud92d\udd59\ud9c6\udecf\ud95e\udc32\ud850\udd31\udace\udcfa\uda45\udc35\udb78\udf29\udbd8\udd17\uda93\ude54\ud8d9\udd34",
        7, 10641, -716367587, 1153536050383186900L, 40606L, false, false, (char) 457, (char) 2632,
        Double.longBitsToDouble(0x3f7d8750ed290880L), Double.longBitsToDouble(0x3fe132b2d7a66046L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=[B:[[53, 84]] |a0=[B:[[4, 37, -36, 37, -74, 3, 53, 84]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 10, 1, 9, "\uda34\udd55\udb0c\udd55\udae6\udf33\ud965\udd84", "\u8274\u3e66\u1f0c", "\ud986\udead\ud9c6\ude0f\ud9d1\udf4c\ud860\udeee\ud98a\udd03\udb39\ude8b\udb81\udd29\ud89f\udd8d\uda7d\udd89\udab0\udebc\udaaf\udc70\udbc2\ude2f\uda9a\udeab\udbe4\udda3\ud997\udd0f\udbf6\udd7e\udaa9\udf3f\ud87d\udcc9\udbeb\udd5c\udae0\ude09",
        27, 11817, 734512242, -109410486026523363L, 23739L, false, true, (char) 33758, (char) 25269,
        Double.longBitsToDouble(0x3fe02863eaee9391L), Double.longBitsToDouble(0x3fa791424d05eb10L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[4, 37, 31, -53, -95, -29, 63, -49]]\0121=[B:[[66, 67, 85, 102, 121, 54, 72, 106, 80, 56, 56, 61]] |a0=[B:[[4, 37, 31, -53, -95, -29, 63, -49]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 10, 0, 4, "\uda34\udd55\ud84f\udffb\ud8d1\udd13\ud96f\udeff", "\u80b9\ua9dd\u079c", "\ud986\udead\ud9c6\ude0f\ud96d\udd21\udbad\udd36\ud99c\udd58\ud9f5\udda9\ud89a\udd89\ud84e\ude44\uda99\udcbe\udab0\udebc\udaaf\udc70\udbc2\ude2f\ud95a\udc2b\ud9fb\uddac\ud981\udfa2\ud8a4\uded6",
        7, 22918, 520448960, 2142558947333566857L, 8929L, false, false, (char) 47838, (char) 46553,
        Double.longBitsToDouble(0x3fe27f44b5e5bb19L), Double.longBitsToDouble(0x3fe3c133894b3a50L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 6, 9, 0, "", "", "\ud87a\udc32",
        19, 66632, 1366410719, -1361531154531899746L, -59265L, true, true, (char) 44151, (char) 10621,
        Double.longBitsToDouble(0x3fe5d5e5b80ba4b0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 14, 15, 12, "\uda85\ude3f\ud862\udd84\uda45\ude80", "\u03e4", "\udbbd\udd83",
        1, 14225, 720520934, 1738471367818114874L, 82598L, false, true, (char) 3277, (char) 37217,
        Double.longBitsToDouble(0x3fd557634220a43cL), Double.longBitsToDouble(0x3fe500c2f9bc642dL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=[B:[[83, 53, 50, 106, 82, 120, 85, 56]] |a0=[B:[[75, -99, -93, 71, 21, 60]]\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 13, 3, 12, "\uda7b\udfcd\ud8d3\udd77\uda45\ude6c", "\u7f47\u82cd\uae3c", "\ud8fb\udfb0\udba2\udcf4\udbea\udfeb\uda7f\ude2a",
        22, 22162, 1686369246, -2143595455073473724L, -56997L, false, false, (char) 22108, (char) 62363,
        Double.longBitsToDouble(0x3fea5c0dec987c29L), Double.longBitsToDouble(0x3fcc27b747329230L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=[B:[[100, 71, 87, 106, 55, 81, 61, 61, 13, 10]] |a0=[B:[[116, 101, -93, -19]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 15, 17, 8, "\ud8a4\udf95\ud8d3\ude1d", "\u6ab5\u68bb\ucba7", "\u449e\ud915\udd69\udba2\udcf4\udbea\udfeb",
        -3, 21862, -1628096838, 7242900760051084106L, -95221L, true, true, (char) 64254, (char) 56809,
        Double.longBitsToDouble(0x3fd1a6d4f59eee8aL), Double.longBitsToDouble(0x3fc1719995ceb328L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 14, 1, 16, "", "", "",
        -5, 32893, -800803905, 5858837726825733793L, -80928L, false, true, (char) 24370, (char) 48455,
        Double.longBitsToDouble(0x3feef4f7ab000083L), Double.longBitsToDouble(0x3fea271205557634L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=[B:[[112, 61, 74, 54]] |a0=[B:[[-86, 112, -78, 61, 74, -114, -19, 54]]\0121=[B:[[113, 110, 67, 121, 80, 85, 113, 79, 55, 84, 89, 61, 13, 10]] |a0=[B:[[-86, 112, -78, 61, 74, -114, -19, 54]]\012",
        Z.run(T, 2, 10, 13, 10, "\udbda\udda0\ud9e2\ude6d\udb7a\udfbe\ud81d\udd66", "\u0518\uae3c<\ub0e6\u9297\u6953", "\ud8ec\udcb2\udadb\udfcd",
        11, 17250, 1142784229, 5917427910148336840L, -95185L, true, true, (char) 34290, (char) 37524,
        Double.longBitsToDouble(0x3fe7c93fd54ee0f4L), Double.longBitsToDouble(0x3fe96414da867731L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=[B:[[100, 66, 100, 52, 65, 57, 75, 73, 84, 80, 89, 61]] |a0=[B:[[116, 23, 120, 3, -46, -120, 76, -10]]\0121=[B:[[100, 66, 100, 52, 65, 57, 75, 73, 84, 80, 89, 61]] |a0=[B:[[116, 23, 120, 3, -46, -120, 76, -10]]\012",
        Z.run(T, 2, 12, 12, 12, "\ud8a4\udf47\udba8\udc33\ud902\uddb8\ud87c\udd26", "\u832c\u062b\ua781\ub0e6\u9297", "\uda7f\ude2a\ud9a9\udd34\udbdc\udd01\ud998\uddca\ud89a\udd56\uda39\udedb\udb73\udfae\udab0\ude7f\ud94a\udc87\ud844\udc2d\ud889\udc9b\ud804\ude3f\uda12\udfd0",
        59, 99525, -152310023, -1997859401987605389L, -63256L, false, false, (char) 61808, (char) 13873,
        Double.longBitsToDouble(0x3fe2481af2ea82efL), Double.longBitsToDouble(0x3fc67175f5a0b2ccL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=[B:[[100, 66, 99, 112, 99, 81, 112, 70, 55, 84, 89, 61]] |a0=[B:[[116, 23, 41, 113, 10, 69, -19, 54]]\0121=[B:[[116, 23, 41, 113, 69, -19, 54]] |a0=[B:[[116, 23, 41, 113, 10, 69, -19, 54]]\012",
        Z.run(T, 2, 12, 11, 4, "\ud8a4\udf47\ud859\udfa1\uda3a\udf75\ud81d\udd66\ud97f\udea2\uca2a\udb8c\udcee\udbfb\udf91\ud8db\udc1b\ud8d2\udff2\udb87\udd75\ud913\udde7\ud90f\udf20\uda7f\ude2a\ud9a9\udd34\udbdc\udd01\ud998\uddca\ud89a\udd89\ud8fc\ude3b\udb89\udd57\ud80a\udee6\udb84\udee9\ud844\udc50\ud955\udc21\udbef\udc04\ud802\udd60\ud9dd\udd1c\ud864\ude88\ud9ca\udf40\udabd\udf2f\udb98\udefe\ud8a8\ude54\udb15\udca5\uda70\udd1f\ud8af\uded7\uda34\udce5\ud95b\udc31\udbb0\udd35\udbc1\udeab", "\u5241\u8626\u7d6e\uabc1\u67bd\u46e9\u02da\u5550\u9ed3\u5a86\uc38f\u2dda\u3933\uc353\u7aeb\ua74e\u8824\u1ea2\u9a83\u0afe\u9897\u865e\u3a28\ube10", "\udaf9\udfdd\uda5a\udeeb",
        39, 39423, 1302147261, 3678885612609799514L, -27714L, true, true, (char) 53749, (char) 9199,
        Double.longBitsToDouble(0x3fbdad03d1ebb740L), Double.longBitsToDouble(0x3fe8cac5af74b590L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=[B:[[100, 66, 101, 106, 55, 81, 83, 113]] |a0=[B:[[116, 23, -93, -19, 4, -86]]\0121=[B:[[100, 66, 101, 106, 55, 81, 83, 113]] |a0=[B:[[116, 23, -93, -19, 4, -86]]\012",
        Z.run(T, 2, 12, 12, 4, "\ud8a4\udf47\ud8d3\ude1d\uda34\udfda", "\uad9b", "\udbbd\udd83",
        29, 77045, 734219629, 1738471370904833338L, 7191L, false, true, (char) 25481, (char) 41262,
        Double.longBitsToDouble(0x3fe3d9b98265fbd1L), Double.longBitsToDouble(0x3fd046d4fb721398L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-18, -90, 124, 114, 124, 42, 20]]\0121=java.math.BigInteger:0 |a0=[B:[[-18, -90, 124, 114, 124, 42, 20]]\012",
        Z.run(T, 2, 9, 9, 8, "\udb1e\uded6\ud8ac\udda2\ue2ac\ud85a\ude44", "\u27ca", "\ud8d2\udff2\udab7\uded0\ud9c2\uddcf\ud9c6\ude0f",
        31, 68726, 485832378, -5185271355049743542L, -87942L, true, true, (char) 18273, (char) 23123,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=[B:[[53, 65, 61, 61, 13, 10]] |a0=[B:[[-28]]\0121=[B:[[53, 65, 61, 61]] |a0=[B:[[-28]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 15, 0, 0, "\u0214", "", "",
        -2, 23631, 1364116959, -1361531846505159010L, -100000L, true, true, (char) 29, (char) 10621,
        Double.longBitsToDouble(0x3fe5d5e5bf2d1cf5L), Double.longBitsToDouble(0x3fea55c00344e240L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=[B:[[116]] |a0=[B:[[-77, 40, 100, -39, 46, -16, 76, -124]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[116]] |a0=[B:[[-77, 40, 100, -39, 46, -16, 76, -124]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 5, 5, 9, "\ud9e3\udd58\udb94\ude09\udb5e\ude20\ud87c\udfb4", "\u8274\ua55d\u652a\u06c1\u6763\uc681\u27a8\ud7f0\ube9b\ud442", "\ud84e\ude44",
        21, 46821, -584195424, -9187167735811124998L, 23813L, false, false, (char) 33797, (char) 23814,
        Double.longBitsToDouble(0x3fef01275f3e488cL), Double.longBitsToDouble(0x3fb49612c2c63f38L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 3, 3, 16, "\udafc\udc97\udaaa\udca2\u05be\uda2c\udd6b", "\u8274\u2cb5\u958a\u5e4f\u9d8b\uc681\u27a8\ud7f0\ube9b\u290c", "\ud848\udff6",
        21, 46821, -584195424, -9187167735811124998L, -13004L, false, true, (char) 61015, (char) 6014,
        Double.longBitsToDouble(0x3fe3ef8c4587377fL), Double.longBitsToDouble(0x3fef01275f3e488cL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=[B:[[100, 108, 71]] |a0=[B:[[-31, -94, 100, 108, -88, -29, 21, 71]]\012",
        Z.run(T, 1, 10, 11, 16, "\udb11\uded2\udb94\ude9c\udbd8\udc13\uda45\ude77", "\u8274\ua2b2\uc5aa\u5e64\ud3c1\u48d6\u27a8\ud7f0\ube9b\u290c", "\ud84e\ude44",
        21, 5845, -584195424, -9187167736296216582L, -76812L, true, false, (char) 60916, (char) 6014,
        Double.longBitsToDouble(0x3fe3ef8c45873704L), Double.longBitsToDouble(0x3fef01275f3e488cL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=[B:[[-77, 40, 61, -90, 55, 56, 36]] |a0=[B:[[-77, 40, 61, -90, 55, 56, 36, 13]]\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 3, 16, "\ud9e3\udd58\uda6d\uded6\uda67\ude68\ud954\ude3d", "\u8274\ua55d\u5d3c\u5cfa\u913b\u3b84\u0ca2\u6c2f\ube9b\u290c", "\ud84e\ude44",
        21, 22197, -584195424, -9187168319819065606L, -27780L, true, false, (char) 49530, (char) 59318,
        Double.longBitsToDouble(0x3fd99f1881bd61dcL), Double.longBitsToDouble(0x3fe99783769b2090L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=[B:[[-21, 80, 51, -111, 104, -73, 8]] |a0=[B:[[-21, 80, 51, -111, 104, -73, 8]]\0121=java.lang.Boolean:true |a0=[B:[[-21, 80, 51, -111, 104, -73, 8]]\012",
        Z.run(T, 2, 11, 4, 3, "\ud81b\udc80\ud963\uddc1\ud998\udde7\u0138", "\u1f46", "\udb20\udf7b\ud8ed\udc6e\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, 3815453974894350369L, -37120L, true, true, (char) 12525, (char) 54109,
        Double.longBitsToDouble(0x3fe15378e3d7f768L), Double.longBitsToDouble(0x3fee9a188db103f4L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 2, 1, 0, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\ua76c", "\u4d4a\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, -954, 485818368, -5185271355049743542L, -66510L, false, false, (char) 4709, (char) 45514,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe8200005db1f17L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[58, -104, 51, 6, 61, 88, -72, 123]]\0121=[B:[[]] |a0=[B:[[58, -104, 51, 6, 61, 88, -72, 123]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 9, "\ud86a\udfc8\ud963\udd36\ud86d\udd88\ud8e8\udeab", "\u4bf0\uae3c", "\uda98\udf8a\uda9b\udea2\ud836\udeb4\ud88e\udf74\uda5e\udd63\udae8\udf35\ud970\uddbd\ud89a\udd89\u6da4\ud955\udeff\udb96\udfb6",
        59, 16015, -799671883, 4155380232336396958L, 90778L, false, false, (char) 47619, (char) 8304,
        Double.longBitsToDouble(0x3fead3fd0c0bc6adL), Double.longBitsToDouble(0x3fdb17ead613f5b2L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 7, 0, "\ud875\ude6e\ud963\udd18\udac0\udc5f\udbf4\uddb0", "\u8313", "\ud8d2\udff2",
        45, 15750, 737773421, -2385413870022265076L, 95008L, false, true, (char) 3461, (char) 63899,
        Double.longBitsToDouble(0x3fd4da0545411248L), Double.longBitsToDouble(0x3fcb1ba5b9d781f0L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=[B:[[-38]] |a0=[B:[[124, 50, 107, 125, 14, -19, -64, -34]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[50, 107]] |a0=[B:[[124, 50, 107, 125, 14, -19, -64, -34]]\012",
        Z.run(T, 2, 5, 10, 1, "\udbac\ude62\ud99b\udcad\uda3e\udd1d\udbf0\ude0e\udb35\udfaf\ud9c5\udc2c", "\uaaca\u2b22", "\ud924\udc6e\ud9df\udfad\uda06\ude62\ud83c\ude7b\udb77\udf0a\ud89a\udd89\ud84e\ude44\uda99\udd2e\udb4c\ude4b\uda9e\udc92\uda28\udefc\udb88\udfa5\udb8c\ude18\uda2c\udeb4\udb79\udde9\uda31\udd66\ud954\udd19\uda4b\udf73\u91fe\ud940\udd13\uda3d\udc34",
        31, 3856, 1007016523, -7880738111054387010L, 22194L, false, true, (char) 30402, (char) 63350,
        Double.longBitsToDouble(0x3fc6b33fe6464208L), Double.longBitsToDouble(0x3fe9779ae360c1a5L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[]]\0121=void |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 7, 0, "", "\032", "\ud8eb\udddb\udb8c\udc36\uda7b\udde3\ud943\udf82\u009e\ud97a\udffd\u834a\u876d\000\udb91\udc08\ud9c2\ude33\ud851\udee8\000\000",
        8, -923, -584253440, -2270802845746487691L, -99996L, true, false, (char) 711, (char) 17433,
        Double.longBitsToDouble(0x3fde4d179fdfa5d6L), Double.longBitsToDouble(0x3fdc3bd7c1e27a1aL)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=[B:[[34, 51, 18, 34, -9, 8]] |a0=[B:[[32, 34, 51, 18, 34, -9, 8]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 7, 3, "\udb50\udd52\ud963\udd42\uda52\udd27\u0138", "\u8274\uae3c<", "\u834a\ud992\ude04\udae7\udce1\ud8b5\ude75\ud9b4\udfb1\udb92\udea9\ud89a\udd89\ud84e\ude44\ud905\udca1\ud8d1\udcec\ud8b1\udef2\uda28\udefc\udb92\udfa5\udbe4\ude35\ud802\udcd9\ub404",
        46, 97442, -1358035445, -2657511702828185452L, 71999L, false, true, (char) 30767, (char) 39891,
        Double.longBitsToDouble(0x3fc3596815a1e7a0L), Double.longBitsToDouble(0x3fee061883779fbcL)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, 14, 123, 74, 0, 1, 30]]\0121=java.math.BigInteger:0 |a0=[B:[[15, 34, 14, 123, 74, 0, 1, 30]]\012",
        Z.run(T, 2, 9, 9, 1, "\udb3f\udc52\uda3e\udfab\ud87a\udd30\udb31\ude4e\udbb1\ude3d\ud930\udc03\ud9a0\ude79\ud8ca\ude30\udb05\udc9c\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f\ud96d\udd21\udbad\udd36\udb78\udc6e\ud952\udeef\ud89a\udd89\ud84e\ude44\uda99\udd2e\udab0\udebc\uda9e\udc92\uda31\uddc3\udb88\udfa5\udbe4\udda3\ud802\udcd9\ud96a\uddc2\ud9a4\udffd\ud8ef\udf50\uda8b\ude0d\ud95c\ude0f\ue23b\uda3f\udc10\uda15\udd38\udb9e\udc3f\ud80c\udf87\ud951\udc32\udb9a\udfe3\ud8e2\udf28\ud86a\udeaa\udaa9\ude35\ud9ef\ude50", "\u95be\u7db3\uce92\u846d", "\udafb\udec5\ud99b\udfdc\udbbd\udf01\ud8a7\udf55",
        11, 44033, 1164357469, -7366644074249820311L, -42506L, false, true, (char) 26225, (char) 61072,
        Double.longBitsToDouble(0x3fe0cbe98973bf38L), Double.longBitsToDouble(0x3fe5acb59b601a3dL)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=[B:[[68, 121, 74, 84, 77, 70, 43, 97, 101, 80, 89, 61]] |a0=[B:[[15, 34, 83, 48, 95, -102, 120, -10]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[83, 48, 95, 120]] |a0=[B:[[15, 34, 83, 48, 95, -102, 120, -10]]\012",
        Z.run(T, 2, 16, 10, 6, "\udb3f\udc52\ud983\ude60\udb8f\uddca\udba8\udd26", "\u62f2\uc1bb\u40ee\u81a9\uad9e\u497d\u029f\u4462", "\ud952\udeef\udab7\udec1",
        56, 16778, 408895821, -2509100241081557089L, -26350L, false, true, (char) 34290, (char) 2930,
        Double.longBitsToDouble(0x3fbad7b1cfbba810L), Double.longBitsToDouble(0x3fd60aca83bc3d7aL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=[B:[[15, 34, 44, -108, -46, 44, 37, 114]] |a0=[B:[[15, 34, 44, -108, -46, 44, 37, 114]]\0121=[B:[[15, 34, 44, -108, -46, 44, 37, 114]] |a0=[B:[[15, 34, 44, -108, -46, 44, 37, 114]]\012",
        Z.run(T, 2, 11, 11, 16, "\udb3f\udc52\ud85c\udec4\ud802\ude5c\ud955\udda2", "\u00a2", "\uda9a\udcc1\ud964\uddbd\uda8d\udc60\ud99b\udf0f\ud96d\udd21\udbad\udd36\udb77\udfbf\ud952\udeef\ud89a\udd89\ud84e\ude44\uda99\udd2e\udab0\udebc\udad1\udc63\ud979\udf5f\udb88\udfa5\udbe4\udda3\udb5d\udef6\udaed\udf66\ud8fc\udcd2\ud90d\udcdc\ud847\udd7d\uda59\uded9\udb13\ude53",
        44, 14888, -739224044, -581044712432256796L, 4390L, true, false, (char) 62281, (char) 50687,
        Double.longBitsToDouble(0x3fe55d0c5d713d27L), Double.longBitsToDouble(0x3fda2fc3f5aadbeeL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.math.BigInteger:56610 |a0=[B:[[15, 34, 51, 18, 83, 8, 74, 2]]\0121=[B:[[-35, 34]] |a0=[B:[[15, 34, 51, 18, 83, 8, 74, 2]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 6, "\udb3f\udc52\ud963\udd42\u3c83\u0138\ud87a\udc32\ud8eb\udddb\udb8c\udc36", "\u3661\u8929\uc710\u029f", "\udb07\udc16",
        38, 46290, 1992960836, -2930573618647711344L, -26343L, false, true, (char) 34290, (char) 8335,
        Double.longBitsToDouble(0x3fe3739e08f8aea9L), Double.longBitsToDouble(0x3fe5cf473fa8259eL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=[B:[[68, 121, 73, 61]] |a0=[B:[[15, 34]]\0121=[B:[[68, 121, 73, 61]] |a0=[B:[[15, 34]]\012",
        Z.run(T, 2, 14, 14, 12, "\udb3f\udc52", "\u69c7", "\udaf4\ude32",
        10, 37817, 856098319, -872415232L, -100000L, false, false, (char) 0, (char) 14125,
        Double.longBitsToDouble(0x3fdcf650aabcdc22L), Double.longBitsToDouble(0x3fe693b05c000000L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=[B:[[-28]] |a0=[B:[[-28]]\0121=[B:[[53, 65, 61, 61]] |a0=[B:[[-28]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 0, 12, "\024", "\u671c", "",
        -5, -1000, -318767104, 183197535043584L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3a55c000000000L), Double.longBitsToDouble(0x3f4c480000000000L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=[B:[[56, 64]] |a0=[B:[[56, 64]]\0121=java.lang.Boolean:true |a0=[B:[[56, 64]]\012",
        Z.run(T, 2, 11, 4, 12, "\ud868\ude70", "\u6699", "\ub3eb\uda96\udd76\ud943\udfb5\ud952\ude5a\000\000\udaf3\udf86\000\000\000",
        38, 46290, 1992960836, 143838686757120L, 4208L, true, true, (char) 27910, (char) 26379,
        Double.longBitsToDouble(0x3fe838d34ee5c946L), Double.longBitsToDouble(0x3fe09dee5ad8104cL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=[B:[[66]] |a0=[B:[[15, 66]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 10, 1, 12, "\ud93f\udd72", "\u7dec", "\udae3\uddbd\udaa9\udfc6\udaa7\udceb\uda77\udcc5\uda6f\ude4f\ud9f1\udda7\udaf3\udf86",
        46, 50344, 475418519, 3966190340720823901L, -19510L, false, true, (char) 17327, (char) 60736,
        Double.longBitsToDouble(0x3fb71014e7e1e328L), Double.longBitsToDouble(0x3fe46b03b6979bbfL)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=[B:[[113]] |a0=[B:[[15, 113]]\0121=[B:[[113]] |a0=[B:[[15, 113]]\012",
        Z.run(T, 2, 10, 10, 8, "\udb3f\udca1", "\u671c", "\ud880\ude70",
        32, 88908, 42654, 0L, -100000L, false, false, (char) 0, (char) 56108,
        Double.longBitsToDouble(0x3fb2ae39b03a9ad0L), Double.longBitsToDouble(0x3fe693b651000000L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=[B:[[109, 47, 122, 88, 49, 80, 47, 116, 112, 76, 107, 61, 13, 10]] |a0=[B:[[-101, -4, -41, -44, -1, -19, -92, -71]]\0121=[B:[[109, 47, 122, 88, 49, 80, 47, 116, 112, 76, 107, 61]] |a0=[B:[[-101, -4, -41, -44, -1, -19, -92, -71]]\012",
        Z.run(T, 2, 15, 13, 12, "\ud9cb\udc2c\uda07\ude04\ud82f\udc1d\udbd4\udce9", "\u8274", "\ud8bf\udeee\ud842\udeca\ud871\udf00\ud9c6\ude73",
        31, 55054, 485832378, -5185271356089397238L, -78527L, false, false, (char) 25932, (char) 43593,
        Double.longBitsToDouble(0x3fe850b5507195f6L), Double.longBitsToDouble(0x3fe2d263d6de3172L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=[B:[[113, 85, 86, 88, 72]] |a0=[B:[[113, 85, 86, 127, 88, -121, -66, 72]]\0121=[B:[[113, 85, 86, 88, 72]] |a0=[B:[[113, 85, 86, 127, 88, -121, -66, 72]]\012",
        Z.run(T, 2, 10, 10, 12, "\ud8a1\udf85\ud986\uddaf\ud888\udeb7\udbee\udd78", "\uce50\u5556\ua067\u1148\u8aa4\ua6e3\u4c94\u7c58\u496f\u79f6\u521f\u7f1b\u914a\u0571\uba41\uc95a", "\udad6\uddb7\udba2\udeaa",
        49, 12610, -2134092581, 3965297166281758761L, 24730L, false, false, (char) 6864, (char) 2772,
        Double.longBitsToDouble(0x3fe4b0a042012da9L), Double.longBitsToDouble(0x3fc8e4e5814f8e40L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=[B:[[48, 65, 61, 61]] |a0=[B:[[-48]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[-48]]\012",
        Z.run(T, 2, 0, 10, 16, "\000", "\u671c\u52ca\ud16d\u8274\u5942\ub6d8\u0a48\u8929\u466d\u1b19\u4462\u496f\ua6ae\u180b", "\udbea\ude04\000\000\000\000\000\ud802\udcd9\ud8ac\udea3\udadb\ude9e\udbae\udd25\ud8af\udc6b\ud9e6\udcc9\ud99e\udd9c\ud80f\ude9a\ud865\ude6a\ud877\ude15",
        38, 92096, -1809054442, -8790308890265538841L, 84633L, true, true, (char) 31768, (char) 64028,
        Double.longBitsToDouble(0x3fddcf8c98dfded4L), Double.longBitsToDouble(0x3fe2bc63526eb2fbL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.math.BigInteger:16421641 |a0=[B:[[43, 112, -58, 77, 74, -120, 5, 65]]\0121=[B:[[-6, -109, 9]] |a0=[B:[[43, 112, -58, 77, 74, -120, 5, 65]]\012",
        Z.run(T, 2, 9, 8, 4, "\ud95b\udca0\ud9f6\ude7d\ud87a\udfb8\ud835\udc71", "\u923d\u4331\u45dc\ub0e6\u633c\u8288\u70d7\u4440\u496f\u0bcc\u51d3\ud007\u37d4\u716e\ubd1a\ud58d\ub9c7\ub382\ua792\u703b\u6a40\u60df\ud6eb", "\ud83f\udd83",
        25, 12405, 1986793658, 6213382172599289264L, -15565L, true, false, (char) 63659, (char) 51060,
        Double.longBitsToDouble(0x3fbce30efadfca38L), Double.longBitsToDouble(0x3fe82b95e9387e0fL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[]]\0121=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 2, 9, 8, 4, "", "\u6016\u7a99\u40b6\u9dd6\u923d\u4331\u45dc\ub0e6\u633c\u8288\u70d7\u4440\u712e\u0b12\u1729\u64bd", "\ud817\udf0f\ud82b\udff4\ud925\uddbd\udb88\udfa5N\uda9f\udebc\uda16\udcae\uda6f\udf77\ud89f\udfe1\uda90\ude06\udadc\udd33\udab8\udd76",
        25, 12405, 1986793658, 6213382174646109616L, -81056L, true, true, (char) 61699, (char) 47563,
        Double.longBitsToDouble(0x3fd51d81f67e9094L), Double.longBitsToDouble(0x3fdc0e0945a6e86eL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[43, 112, -58, 77, 74, -120, -14, -9]]\0121=java.lang.Boolean:true |a0=[B:[[43, 112, -58, 77, 74, -120, -14, -9]]\012",
        Z.run(T, 2, 4, 4, 4, "\ud95b\udca0\ud9f6\ude7d\ud87a\udfb8\uda22\udc27", "\u923d", "\ud8d2\udff2\ud9f3\udc4f\udb8c\udfa6\ud9e3\uddfe\ud96d\udcff\ud9a4\udfa0\uda0a\udd5d\ud952\udf48\udbf5\uded6\ud84a\ude0a\uda99\udd2e\ud817\udf0f\ud82b\udff4\ud925\uddbd\udb88\udfa5\ud818\ude80",
        41, 87515, 616785229, -3132259651025914730L, -15130L, true, true, (char) 40251, (char) 18899,
        Double.longBitsToDouble(0x3fe15bb365b0563aL), Double.longBitsToDouble(0x3fe2efec31d313ebL)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=void |a0=[B:[[15, 34, 28, 16, 34, -9, -68, -2]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[15, 34, 28, 16, 34, -9, -68, -2]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 2, 7, 2, "\udb3f\udc52\udb4c\udc40\uda52\udd27\udbec\udf2e", "\u7472\u7caf", "\udb0c\udc7b\ud9cd\ude22\udb48\udccd\udb8f\udc01",
        33, -326, -1207290067, -2117166497965790396L, -26350L, false, true, (char) 34306, (char) 40530,
        Double.longBitsToDouble(0x3fd3cf9a7d298cc2L), Double.longBitsToDouble(0x3fd6aaef4fa43d70L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=[B:[[89, 115, 89, 114, 89, 121, 76, 51, 104, 65, 69, 13, 10]] |a0=[B:[[98, -58, 43, 99, 34, -9, -124, 1]]\0121=[B:[[89, 115, 89, 114, 89, 121, 76, 51, 104, 65, 69, 13, 10]] |a0=[B:[[98, -58, 43, 99, 34, -9, -124, 1]]\012",
        Z.run(T, 2, 14, 14, 2, "\ud992\udef6\ud95b\udc93\uda52\udd27\ud9b4\udd31\ud87a\udc32\ud8eb\udddb\udbfc\udf79\udb09\udf0e\udbc1\ude83\ud83b\udd85\ud9ec\uddc7\udbed\udcf1\udbcd\udc09", "\uc50e", "\udb96\udf41\udb1d\udeb1\ud9a7\ude10\uda9f\udc24\uda7f\udea9\udb88\udf8b\udabe\udc10\udbee\udd37\ud97d\udcd9\uda0d\ude24\udb54\udefc\udb54\ude3f\ud92e\udd22",
        34, 89095, 314106731, 4135469506061914879L, -62981L, true, true, (char) 44683, (char) 57596,
        Double.longBitsToDouble(0x3fe9ec38c07fa118L), Double.longBitsToDouble(0x3fbda2c4fceb60d8L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=[B:[[87, 48, 56, 99, 66, 109, 57, 52, 99, 69, 73, 61, 13, 10]] |a0=[B:[[91, 79, 28, 6, 111, 120, 112, 66]]\0121=[B:[[87, 48, 56, 99, 66, 109, 57, 52, 99, 69, 73, 61]] |a0=[B:[[91, 79, 28, 6, 111, 120, 112, 66]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 15, 16, 16, "\udb8b\udd7f\ud84c\udf36\udb9f\udfa8\udba0\udd72", "\u8274\u019d\022\ub0e6\u8929\u0164", "\ud835\udefe\udadf\ude66\ud952\udeef\ud89a\udd3f\ud899\udd01\uda0d\udfe7\udb7f\udeae\udafb\udddb\udadb\udd8e\udb98\udd42\000\ud802\udcd9\udb9a\udfe7\ud964\udec2\udbf0\udcb2",
        15, 43777, -248557142, -2223647279776427459L, 28883L, false, true, (char) 13444, (char) 40315,
        Double.longBitsToDouble(0x3fc376e5d68620f0L), Double.longBitsToDouble(0x3fc942fff788ff6cL)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=[B:[[-101, 12, -102, 19, -95, 100]] |a0=[B:[[-101, 12, -102, 9, 19, -95, 9, 100]]\0121=[B:[[109, 119, 121, 97, 67, 82, 79, 104, 67, 87, 81, 61, 13, 10]] |a0=[B:[[-101, 12, -102, 9, 19, -95, 9, 100]]\012",
        Z.run(T, 2, 11, 15, 16, "\udacb\ude3c\ud9ca\udc39\udb43\udfd1\udb39\udc94\ud92a\udfa5\uda21\udfc4\udad7\udfc4\uda3d\udfab\ud956\udeae\ud8d2\udff2\udbdb\udda2\ud882\udc67\ud943\ude70\ud9ee\udcc9\ud9e9\udf3e\ud8af\ude50\ud952\udeef\ud89a\udd89\ud8c0\udfb4\uda7d\udd57\udac8\uded0\uda9e\udc92", "\u4c33\u9a60\uc63c\u4a37\uae9b\u337a\u6fac\uab97\ub4c0\uac69\ub7b5\uc6cd\u3291\u7afa\u2ac5\u2a77\u7854\u14a8\u8622\u5efc\u12c4", "\uda8f\ude69\ud879\udc6c\udb07\udd31\uf747\ud90d\udf5e\ud881\udc90\uda55\udddb\udbbc\ude23\uda2e\udc09",
        49, 71184, -1066623819, -397482883364825757L, -47561L, true, false, (char) 50653, (char) 43609,
        Double.longBitsToDouble(0x3fdf69288c9ea2c2L), Double.longBitsToDouble(0x3fe1642425ea4dbfL)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[61, -39, 95, -114, 1, -119, 41]]\0121=java.lang.Boolean:true |a0=[B:[[61, -39, 95, -114, 1, -119, 41]]\012",
        Z.run(T, 2, 4, 4, 0, "\udb6d\udd09\udb8f\udebe\ud831\udfb9Y", "\u8274", "\ud8d2\udff2\ud8a4\uddc2\uda26\uddf6\ud87e\udf0c",
        51, 47374, 485832378, -5170916131237500086L, -66510L, false, true, (char) 22097, (char) 60535,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b552db1f17L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=[B:[[68, 121, 74, 74, 72, 83, 76, 51, 67, 65]] |a0=[B:[[15, 34, 73, 29, 34, -9, 8]]\0121=[B:[[68, 121, 74, 74, 72, 83, 76, 51, 67, 65]] |a0=[B:[[15, 34, 73, 29, 34, -9, 8]]\012",
        Z.run(T, 2, 14, 14, 2, "\udb3f\udc52\ud979\udd4d\uda52\udd27\u0138", "\u0bf0", "\ud881\udc4b\ud8b7\udf9a\uda64\udf12\uda43\udfc4\ud866\ude3e\udbb0\udc69\ud9ee\udd54\ud8b4\ude2f\ud97a\ude35",
        51, 16577, 408895821, -2509100241081558113L, -63422L, false, true, (char) 15474, (char) 4984,
        Double.longBitsToDouble(0x3fa3b981bac88120L), Double.longBitsToDouble(0x3fefed17d14b2b7aL)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=[B:[[120, 67, 112, 65, 49, 77, 65, 72, 13, 10]] |a0=[B:[[-60, 42, 64, -44, -64, 7]]\0121=[B:[[120, 67, 112, 65, 49, 77, 65, 72, 13, 10]] |a0=[B:[[-60, 42, 64, -44, -64, 7]]\012",
        Z.run(T, 2, 14, 14, 2, "\ud8f4\udd5a\ud870\udc04\ud9f0\udf37", "\ube5e\u7a34\u2426\u94e4\u1407\uaaeb\u63d2\u62ce\uacb5\u2ca2\ua7de\u01b2\u7784\u5f4b\u327c\u158d", "\udb64\udf53\udbd3\udffc\ud8a9\uded0\udb52\udea4",
        39, 33091, -566804473, 8876181350132469382L, 7285L, true, true, (char) 3626, (char) 15752,
        Double.longBitsToDouble(0x3fcf99622d1989f0L), Double.longBitsToDouble(0x3f9b8781d7ad79c0L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[4, 37, 31, -53, -95, -29, 63, -49]]\0121=[B:[[]] |a0=[B:[[4, 37, 31, -53, -95, -29, 63, -49]]\012",
        Z.run(T, 2, 10, 10, 9, "\uda34\udd55\ud84f\udffb\ud8d1\udd13\ud96f\udeff", "\u80b9\ua9dd\u079c", "\ud986\udead\ud9c6\ude0f\ud96d\udd21\udbad\udd36\ud99c\udd58\ud9f5\udda9\ud89a\udd89\ud84e\ude44\uda99\udcbe\udab0\udebc\udaaf\udc70\udbc2\ude2f\ud95a\udc2b\ud9fb\uddac\ud981\udfa2\ud8a4\uded6",
        7, 4710, 531701092, 2142558947333566857L, 8929L, false, false, (char) 47838, (char) 46553,
        Double.longBitsToDouble(0x3fe27f44b5e5bb19L), Double.longBitsToDouble(0x3fe3c749c14b3a50L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=[B:[[116, 23, -13, 21, -65, -19, 54]] |a0=[B:[[116, 23, -13, 21, 10, -65, -19, 54]]\0121=[B:[[116, 23, -13, 21, -65, -19, 54]] |a0=[B:[[116, 23, -13, 21, 10, -65, -19, 54]]\012",
        Z.run(T, 2, 11, 11, 4, "\ud8a4\udf47\uda23\udc45\uda3a\udfef\ud81d\udd66\ud97f\udea2\uca2a\udb8c\udcee\udbfb\udf91\ud8db\udc1b", "\ud0ca\ud206\u91e8\u793d\u7019\ucdb0\uc890\u7775\u28f0\u788c\ub536\u2b6d", "\ud802\udd60\ud9dd\udd1c\ud864\ude88\ud9ca\udf40\udabd\udf2f\udb98\udefe\ud8a8\ude54\udb15\udca5\uda70\udd1f\ud8af\uded7\ud9db\udc75\ud95b\udc31\ud8dd\udcac\udbd2\udf40\ud957\udf82\ud917\udc2e\ud9ad\udfe7",
        31, 1098, -406748196, -2378517270948118429L, -45482L, true, true, (char) 64521, (char) 11693,
        Double.longBitsToDouble(0x3fe525e7c6cbd6d5L), Double.longBitsToDouble(0x3f81db91e1eefa00L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=[B:[[-77, 40, 74, -95, 15, 36]] |a0=[B:[[-77, 40, 74, 13, -95, 15, 36, 13]]\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 3, 16, "\ud9e3\udd58\udb7a\ude3d\udad1\udf3f\ud954\ude3d", "\u9ed4\ua55d\u5d3c\u5cfa\u913b\u3b84\u27a2\u6c2f\ube9b\u290c", "\ud84e\ude44",
        21, 22197, -584195424, -9187168319819065606L, -27780L, true, false, (char) 49530, (char) 59318,
        Double.longBitsToDouble(0x3fd99f1881bd61dcL), Double.longBitsToDouble(0x3fe99783769b2090L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=[B:[[34, 51, 18, 34, -9, 8]] |a0=[B:[[32, 34, 51, 18, 34, -9, 8]]\0121=[B:[[34, 51, 18, 34, -9, 8]] |a0=[B:[[32, 34, 51, 18, 34, -9, 8]]\012",
        Z.run(T, 2, 11, 11, 11, "\udb50\udd52\ud963\udd42\uda52\udd27\u0138", "\u0e6b\uae15<\u480a\u2043\u619d\u0afb\u7a97", "\udb92\udea9\ud89a\udd89\ud84e\ude44",
        42, 94114, -572466955, -791651843133972033L, -56916L, true, false, (char) 39990, (char) 5055,
        Double.longBitsToDouble(0x3fe05c473630af0eL), Double.longBitsToDouble(0x3fe21ef1e308b67bL)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[15, 34, 51, 18, 34, -9, 8]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 1, 16, "\udb3f\udc52\ud963\udd42\uda52\udd27\u0138", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        33, 47374, 485832378, -5185271355049743542L, -974L, false, false, (char) 64254, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fdb016aadb6ad56L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[15, 34, -40, 36, 92, 25, -60, 116]]\0121=java.lang.Boolean:true |a0=[B:[[15, 34, -40, 36, 92, 25, -60, 116]]\012",
        Z.run(T, 2, 4, 4, 1, "\udb3f\udc52\ud908\udf54\udb8c\ude49\udbf4\udfa4", "\u8274", "\ud8d2\udff2\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, 3127247657169349579L, 28238L, false, true, (char) 17460, (char) 31948,
        Double.longBitsToDouble(0x3fe3af03e0fc4e3aL), Double.longBitsToDouble(0x3fd3b861c7afbec6L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=void |a0=[B:[[15, 34, 28, 16, 34, -9, -68, -2]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[15, 34, 28, 16, 34, -9, -68, -2]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 7, 2, 11, "\udb3f\udc52\udb4c\udc40\uda52\udd27\udbec\udf2e", "\u7472\u7caf", "\udb0c\udc7b\ud9cd\ude22\udb48\udccd\udb8f\udc01",
        33, -326, -1207290067, -2143595455063754820L, 20814L, false, true, (char) 31948, (char) 32497,
        Double.longBitsToDouble(0x3fb3b4157820b550L), Double.longBitsToDouble(0x3fe6d8f93871cde1L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[15, 34, -40, 36, 44, -32, -60, 24]]\0121=java.lang.Boolean:false |a0=[B:[[15, 34, -40, 36, 44, -32, -60, 24]]\012",
        Z.run(T, 2, 4, 4, 1, "\udb3f\udc52\ud908\udf54\udb5c\udd10\udbf4\udf48", "\u8274", "\ud8a9\udd54\ud9ad\uddcc\ud9c2\ude04\ud9c6\ude0f",
        31, 47374, 485832378, 3127186991255388363L, 28238L, false, true, (char) 17460, (char) 40907,
        Double.longBitsToDouble(0x3fe3af03e0fc4e3aL), Double.longBitsToDouble(0x3fd3b861c7afbec6L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-50, -11, -39, -72, -96, -105, -92, -16]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.math.BigInteger:0 |a0=[B:[[-50, -11, -39, -72, -96, -105, -92, -16]]\012",
        Z.run(T, 2, 5, 9, 10, "\udbfe\udc25\ud809\udce8\ud8d0\uddc7\udbd4\udc20", "\u8274", "\ud8bf\udeee\ud9ad\uddcc\uda78\udc84\ud9c6\ude73",
        31, 55054, 472397498, -5185271356059578358L, -66510L, true, true, (char) 11170, (char) 24559,
        Double.longBitsToDouble(0x3fe3af03e04ed055L), Double.longBitsToDouble(0x3fe820b556db1f17L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-80, -76, 97, -96, -56, 30, -105, 27]]\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 3, 6, "\udbe0\udee4\ud991\udcd0\ud9f8\udd4e\udac7\udc4b\ud87a\udc32\ud8eb\udddb\udad4\udd37\uda88\udea9\udbbd\udd83\udb43\uddf2\ud97b\udf81\ud9c2\ude04\ud9c6\ude0f\ud96d\udd59\uda29\udf86\udb97\uded2\uda40\udefa\ud8af\uddbe\ud84e\ude44\uda99\udd2e\udab0\udebc\uda50\udcd3\udbee\udd69\uda2d\uddb9\ud81b\udc02\uda32\udf12\udb4c\udcd3\uda5b\udc0b\udb92\udc30\uda35\udf48\udb76\udf3f\u0d88", "\u45e3\u8ec5\u8f1f\u5b2e\ud786\u8393\u1e44\u4223\u3e7d\ud53a\u2eb5\u4782\ucc5f\u43ba\u9b62\u7700\u34ae\u9184\ud683\ub3c6\ud0ad\u4db3\u5bf6", "\ud94d\ude20\udbac\udfdf\udb4e\udccd\udbcb\udcec\ud9fe\udf64\udb4e\udeaa\ud9b7\udf7a\ud885\udf8b\ud89c\udc4d\ud9fb\udeb9\uda4f\uddf8\udbfb\uddbd\udaf1\udc05\udb8e\udc6c\ud8c0\ude64\uda5a\udc58\ud918\ude1f\udb4a\udfb2\uda42\udd39\ud9ad\udd2a\udae9\udf6d\ud93b\udeaf\ud88a\udcef\udaa1\udc25\udb05\udf5a\ud913\udc9e\uda32\udeda\uea28\udae3\udddc\udbaa\udcfc\u58d7\udb1a\udcaf\ud87a\udff2\ud961\udc93\ud916\ude9b\u8a14\udb44\udc42\udbd6\udefa\ud86c\udf4b\uda31\ude37\udb0a\ude39\udad2\udc9a\ud958\udc6e\ud957\udf5f\uda4f\udf06\ud88f\udd79\u8714\uda0b\ude48\uda5c\udf58\ud97d\udcd8\ud945\uddbb\ud9d6\udcbe\ud8ff\udd7f\uda74\udee7\ud835\udce9\ud8c9\udea8\ud965\ude25\udb33\udff7\u2e43\uda14\ude56\udb5c\udce1\ud850\udde5\uc7c0\ud93d\udcb7\ud96c\udc6f\u8aa3\udb9c\ude05\uda4c\ude29\u84da\ud90b\ude81\uda5a\udebb\ud9e2\udd94\ud85f\udedb\ud8d2\udc0a\ud807\udcfa",
        43, 45911, 562013528, 673047167373161535L, 47814L, true, false, (char) 40675, (char) 10306,
        Double.longBitsToDouble(0x3fd10721b9505e6eL), Double.longBitsToDouble(0x3fdefdcdf9b6f4f2L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.math.BigInteger:27 |a0=[B:[[71, 49, 28, -116, 34, -9, -68, -2]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 7, 2, "\udb77\udd61\udb4c\udcbc\uda52\udd27\udbec\udf2e", "\u7472\u7caf", "\udb0c\udc13\ud9cd\ude22\uda1a\udf56\udb85\ude37\uda33\udc19\uda30\udd6b\ud952\udeef\udb88\udf40\ud84e\ude44\udbfb\udc5f\udb89\udd9a\uda9e\udc92\udbd7\udcd5\udafb\udc78\uda2d\udcc5",
        38, 41507, -350236559, 1443964930036582201L, 72188L, true, true, (char) 48926, (char) 25776,
        Double.longBitsToDouble(0x3feae800c0c2d882L), Double.longBitsToDouble(0x3fed2f8f8464024eL)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=[B:[[34, 51, 18, -9, 8]] |a0=[B:[[32, 34, 51, 18, 32, -9, 8]]\0121=[B:[[34, 51, 18, -9, 8]] |a0=[B:[[32, 34, 51, 18, 32, -9, 8]]\012",
        Z.run(T, 2, 11, 11, 9, "\udb50\udd52\ud963\udd42\uda50\udc27\u0138", "\u8274\uae3c<", "\u98ba\ud992\ude04\udae7\udce1\ud8b5\ude75\ud9b4\udfb1\udb92\udea9\ud89a\udd89\ud84e\ude44\ud961\uddaf\ud8d1\udcec\ud8b1\udef2\uda28\udefc\udb92\udfa5\udbe4\ude35\ud802\udcd9\ub404",
        31, 46880, -147421404, -2632576557226686316L, -84927L, false, false, (char) 46042, (char) 65359,
        Double.longBitsToDouble(0x3fee061883779fbcL), Double.longBitsToDouble(0x3fe4bc5e3904b5c3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base64|encode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|avail||new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|containsBase64Byte|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decodeInteger|[B|static",
    "M|org.apache.commons.codec.binary.Base64|discardNonBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|discardWhitespace|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64Chunked|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
