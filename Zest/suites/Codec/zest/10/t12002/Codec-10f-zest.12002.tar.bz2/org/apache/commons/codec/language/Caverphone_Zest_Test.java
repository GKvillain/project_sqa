package org.apache.commons.codec.language;
import org.junit.Test;
import static org.junit.Assert.*;
public class Caverphone_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u180c\u44b3\u6da8\u8835\u9361\u434b\u3ad0\u16d0\u546d\u6653\u61fd\ua012\ubcfe\u6fd9", "\ud82d\udc3e\ud85a\udc0d\uda14\udf13\udb1d\ude52\udab0\udc8d\udaa8\udd7a\ud810\udeda\u2841\uda23\uddc2\u1064\ud883\udf63\udaa0\udcb5\uda9b\udd64\udbf8\udcda\ud88e\uddf1\ud94e\udeb2\ud938\udeeb\ud965\udd68\udb52\uddf7\uda7c\ude7f\uda1c\ude58\ud866\udd29\ud839\udfe9\udb5e\udd83\udb7f\udeca\ud870\uddbe\udbea\udc64\udba2\udc82\uda02\ude98\ud8a9\ude13\udb53\ude99\uda71\ude44\uda8d\uddcb",
        18, 78211, -950988041, 242613752844396105L, 75466L, false, false, (char) 22803, (char) 17490,
        Double.longBitsToDouble(0x3feb497e2fcad6e6L), Double.longBitsToDouble(0x3fd18640ebb4c976L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udab1\udf4e\uda07\udd53\udb47\udfad\ud8c5\uddd0\ud811\udecf\u759b\udaa0\udeaa\ud86d\udc85\uda7e\udc74\ud9b0\udc14", "\ub33b\u7752\u1c50\u90a5\u180c\u44b3\u6da8\u8835\u9361\u434b\u3ad0\u16d0\u546d\u66a1\ubdfc\ua012\ub467\ub60d", "\udb19\uddb2",
        33, 39437, -941172449, -6826422310981676882L, 1127L, false, false, (char) 47775, (char) 59275,
        Double.longBitsToDouble(0x3fc4a32898a59ac8L), Double.longBitsToDouble(0x3fe2cc37257cae57L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 3, 2, "\udab1\udf4e\uda07\udd53\ud85a\udf0c\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udca9\ud86d\udc85\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u180c\u44b3\u6da8\u8835\u9317\u434b\u3ad0\u16d0\u546d\u6653\u61fd\ua012\ub9fd\u6fd9", "\ud82d\udc3e\ud85a\udc0d\uda14\udf13\udb1d\ude52\udab0\udc8d\udaa8\udd7a\ud810\udeda\u2841\ud9c5\uddb3\u1037\ud883\udf63\udaa0\udcb5\uda9b\udd64\udbf8\udcda\ud88e\udd80\ud94e\udeb2\ud938\udeeb\ud96b\udd0c\udaa2\ude10\udbc2\udd9d\uda1c\ude58\ud866\udd29\ud839\udfe9\udb5e\udd83\udb7f\udeca\ud870\uddbe\udbea\udc64\udba2\udc82\uda02\ude98\ud8a9\ude13\udb53\ude99\uda71\ude44\uda8d\uddcb",
        18, 78211, -950988041, 242613752844396105L, 75466L, false, false, (char) 22803, (char) 17490,
        Double.longBitsToDouble(0x3feb497e2fcad6e6L), Double.longBitsToDouble(0x3fd18640ebb4c976L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27", "\ub33b", "\udbbb\udd68\ud9c8\ude46\ud878\ude94\u316c\uecce\ud8ce\ude68",
        -3, 55606, 1161698495, 5012323849990363953L, 48515L, true, false, (char) 2949, (char) 27823,
        Double.longBitsToDouble(0x3fbe7af83b729fc8L), Double.longBitsToDouble(0x3fbe546ae365a7c8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 4, 1, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u180c\u44b3\u6da8\u8835\u9361\u434b\u3ad0\u16d0\u546d\u6278\u8a8f\ua012\ubcfe\u6fd9", "\ud82d\udc3e\ud85a\udc0d\uda14\udf13\uda4a\udec9\u17c8\ud920\udf57\ud810\udeda\u2841\u8ec3\u1064\ud883\udf63\udaa0\udcb5\uda9b\udd64\udbf8\udcda\ud88e\uddf1\ud94e\udeb2\ud938\udeeb\ud965\udd68\udb52\uddf7\uda7c\ude7f\uda1c\ude58\ud866\udd29\ud807\udee9\udb5e\udd83\udb7f\udeca\ud870\uddbe\udbea\udc64\udba2\udc82\uda02\ude98\ud8a9\ude13\udb53\ude99\uda71\ude44\uda8d\uddcb",
        7, 78211, -950988041, 242613750527829577L, 75466L, false, false, (char) 22803, (char) 17490,
        Double.longBitsToDouble(0x3feb497e2fcad6e6L), Double.longBitsToDouble(0x3fd18640ebb4c976L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 1, 2, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\000\uda7e\udd9f\ud86d\udc85\ud331\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u180c\u3cb2\u6da8\u8835\u9361\u434b\u3ad0\u16d0\u546d\u6653\u61fd\ua012\ubcfe\u6fd9", "\ud82d\udc3e\ud85a\udc0d\uda14\udf13\udb1d\ude52\udab0\udc8d\udaa8\udd7a\ud810\udeda\u2841\uda23\uddc2\u1064\ue5be\000\ud812\udfa0\udbf8\udc49\ud88e\uddf1\ud94e\udeb2\ud938\udeeb\ud965\udd68\udb52\uddf7\uda7c\ude7f\uda1c\ude58\000\ud839\udf5f\udb5e\udd83\udb7f\udeca\ud870\uddbe\udbe9\udfd3\uda6b\udc66\ud9d1\udea8\ud8a9\ude13\udb53\ude99\uda71\ude44\uda8d\uddcb",
        18, 78211, -950988041, 26440970730602496L, 75466L, false, false, (char) 22803, (char) 17490,
        Double.longBitsToDouble(0x3feb497e2fcad6e6L), Double.longBitsToDouble(0x3fd18640ebb4c976L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 2, 2, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\udb0e\udc7c\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u180c\u44b3\u6da8\u8835\u9361\u434b\u3ad0\u16d0\u75e8\u6653\u61fd\ua012\ubcfe\u6fd9", "\udaf0\udfd7\ud85a\udc0d\uda14\udf13\udb1d\ude52\udab0\udc8d\udaa8\udd7a\ud810\udeda\u2841\uda23\uddc2\u1064\ud883\udf63\udaa0\udcb5\uda9b\udd64\udbf8\udcda\ud88e\uddf1\ud94e\udeb2\ud938\udeeb\ud965\udd68\udb52\uddf7",
        4, 85656, -495811865, -1991178679418342692L, -9595L, true, true, (char) 6211, (char) 33274,
        Double.longBitsToDouble(0x3fda9e93b4d495d4L), Double.longBitsToDouble(0x3feaca385bad318eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 2, 2, 0, "\000\000\udafa\udc08\000\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\uc237\000\000\u3c5e\u6da8\u51fc\000\u792f\u0086\u16d0\u546d\u6653\u61fd\u6c84\000\u5c1a", "",
        -5, 62345, -383052692, -1886402770L, 96608L, true, false, (char) 0, (char) 42038,
        Double.longBitsToDouble(0x3e36900000000000L), Double.longBitsToDouble(0x3fecfee17e911e12L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\uda67\udd09\ud84e\ude48", "\ub33b\u8128", "\ud9c8\ude46\ud878\ude94\u316c",
        14, 21099, 478042502, 8286098324490951871L, -43887L, true, true, (char) 36619, (char) 61968,
        Double.longBitsToDouble(0x3fedffbe2c794036L), Double.longBitsToDouble(0x3fbe7af83b729fc8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 0, 4, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u180c\u44b3\u6da8\u8835\u9361\u434b\u3ad0\u16d0\u546d\ud027\u5d35\u9d56\u3256\u4cb8", "\ud82d\udc3e\ud85a\udc0d\uda14\udf13\udb1d\ude52\udab0\udc8d\udaa8\udd7a",
        37, 4005, 1204988295, 5105855159153122750L, 15809L, true, false, (char) 59275, (char) 56808,
        Double.longBitsToDouble(0x3fef33359470ef62L), Double.longBitsToDouble(0x3fe93883b5e42fc7L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 2, "\udab1\udf4e\uda5b\udec4\udbde\uddf7\ud839\udfa3\u4460", "\u735c\u1510\u130e\ud256", "\ud959\udd47\uda66\udf32",
        29, 18606, -1636769708, -8430068937387716388L, 8154L, true, false, (char) 36797, (char) 17466,
        Double.longBitsToDouble(0x3fe98a29593531ebL), Double.longBitsToDouble(0x3fa1a5746bf03520L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 0, 2, 0, "\uda21\udd21\ud99a\udea8\udae9\udc83\udba9\udf72\u438b\udaba\udd13\udaaf\udcae\ud88f\udf0f\ud8fb\udf3a\ud800\udf07\ud871\ude3a\ud998\ude08\uda3d\udf8a\ud959\udd47\uda66\udf32\ud962\udd0b\uda14\udd89\ud866\ude51\uda3d\udd62", "\u54d2\u0389\u16d0\u83df\u6642\u61fd\ua012\ubcfe\ub5e3\u8a3d", "\ud85a\udc0d\uda14\udf13\udaaf\udf22\udaec\udea4\ua8db\ud823\udff9\udb2f\udeb6\ud865\udecf\u1064\uda31\udc59\udaa0\udcb5\uda9b\udd64\udbf8\udcda\ud88e\uddf1\ud94e\udeb2\uda19\ude53\ud944\udc42\udb52\uddf7\uda7c\ude7f\ud89e\udd98\ud85a\udd7d\ud839\udfe9\udadb\udeab\udb7f\ude68\ud883\udcbe\udbea\udc64\udba2\udc82\uda02\ude98\u3c8e\udbdd\ude50\udbf1\udd0f\udaad\ude58\ud99b\udcd1\ud981\udc1f\udb55\udf9f\udb22\udc1e\udba9\uddd0\ud8fa\uded1\ud8ab\udee7\ud93f\udc1e\uda5d\udc62\udb9f\udecc\ud84e\udff5\udb86\udc4d\udbe6\udcfc\ud9f3\uddaf\udace\udf07\ud83b\udceb\udaf7\uddd2",
        33, 33423, -71336818, 5851889006470102946L, 42000L, false, true, (char) 44677, (char) 23291,
        Double.longBitsToDouble(0x3fa654ac3bb95f60L), Double.longBitsToDouble(0x3fed2c778934c460L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u180c\u44b3\u6da8\u8835\u9361\uc1c4\u3ad0\u16d0\u546d\u6653\u61fd\ua012\ubcfe\u5cd9", "\ud82d\udc3e\ud85a\udc0d\uda14\udf13\udb1d\ude52\udab0\udc8d\udaa8\udd7a\005\ud96d\udf96\uda23\uddc2\u1064\ud883\udea5\udaa0\udcb5\uda9b\udd64\udbf8\udcda\ud88e\uddf1\ud94e\udeb2\ud938\udeeb\ud965\udd68\udb52\uddf7\uda7c\ude7f\uda1c\ude58\ud866\udc42\ud839\udfe9\udb5e\udd83\udb7f\udeca\ud870\uddbe\udbea\udc64\udba2\udc82\uda02\ude98\ud8a9\ude13\udb53\ude99\uda71\ude44\uda8d\uddcb",
        18, 78072, -950988041, 242613752844396105L, 75466L, false, false, (char) 22803, (char) 17490,
        Double.longBitsToDouble(0x3feb497e2fcad6e6L), Double.longBitsToDouble(0x3fd18640e000c976L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\0121=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 4, 4, 1, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\ud9c3\udebb\udaaf\udd6e\ud84e\ude39\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\u9616\u90a5\u180c\u44b3\u6da8\u8835\u9361\u434b\u460c\u16d0\u546d\u6653\u61fd\ua012\ubcfe\u6fd9", "\ud82d\udc3e\ud85a\udc0d\uda14\udf13\udb17\udf52\ud9a0\udee5\udadc\udfc6\ud900\ude52\u04f8\uda23\uddc2\u1064\ud883\udf63\udaa0\udcb5\uda9b\udd64\udbf8\udcda\ud88e\uddf1\ud8e9\ude61\ud979\udf0b\ud965\udd20\udb52\uddf7\uda7c\ude7f\uda1c\ude58\udabe\udc9e\udbf0\udce4\udb5e\udd83\udb7f\udeca\ud870\uddbe\udbea\udc64\udba2\udc82\uda02\ude98\ud8a9\ude13\udb23\udce2\ud92c\uddef\ud820\udf53",
        9, 78211, -950988041, 242613752844396105L, 48174L, true, false, (char) 22803, (char) 1619,
        Double.longBitsToDouble(0x3fb4d92d16bb1478L), Double.longBitsToDouble(0x3fe66c24998002e5L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 3, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\uda0f\udd76\udabf\udd3e\ud9b0\udc27", "\ub33b\u7752\u3517\u72a4\u180c\u44b3\u6da8\u8835\u9361\u434b\u3ad0\u16d0\u546d\u6653\u61fd\ua012\ubcfe\u6fd9", "\ud82d\udc3e",
        55, 39308, -796468961, -8102038202167948743L, 81413L, false, true, (char) 48082, (char) 53148,
        Double.longBitsToDouble(0x3fde42fc7ad18ce2L), Double.longBitsToDouble(0x3f49822628000000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 0, "", "\ub0c2", "\udaba\udd13\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27\ud871\udd72\ud998\ude08",
        8, 40796, -1997684169, 8396388157368195470L, 6415L, false, false, (char) 53093, (char) 14048,
        Double.longBitsToDouble(0x3fe430e3f4bf72feL), Double.longBitsToDouble(0x3fdfc453e6628b1eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 2, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\udbee\ude46\uda7e\udc67\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u180c\u44b3\u6da8\u8835\u9361\u434b\u3ad0\u16d0\u546d\u6653\u61fd\ua012\ubcfe\u6fd9", "\ud840\udf66\ud85a\udc0d\uda14\udf13\udb1d\ude52\udab0\udc8d\udaa8\udd7a\uda61\udf23\u27db\uda23\uddc2\u1064\ud883\udf63\udaa0\udcb5\uda9b\udd64\udbf8\udcda\ud88e\uddf1\ud94e\udeb2\ud938\udeeb\ud965\udd68\udb52\uddf7\uda7c\ude7f\uda1c\ude58\ud866\udd29\ud839\udfe9\ud88b\udd61\udbb4\udf5e\ud870\uddbe\udbea\udc64\udba2\udc82\uda02\ude98\ud819\udf4b\udb42\udfd6\uda7f\udcc5\udbd9\udfbf",
        18, 78211, 333386487, -5707471713837587183L, 75466L, false, false, (char) 22803, (char) 17490,
        Double.longBitsToDouble(0x3feb497e2fcad6e6L), Double.longBitsToDouble(0x3fd18640ebb4c976L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 1, 4, 0, "\udab1\udf4e\ud958\uddfb\ud82c\ude4b\ud9a2\uddc5\u4460\udaba\udd13\ud910\ude81\ud9c9\ude9e\ud85d\udea9\ud84c\udc6e", "\u5096\ua965", "\ud9c8\ude46\ud878\ude94\u316c",
        14, 5059, 478042502, -4756326196847451980L, 8427L, true, true, (char) 36619, (char) 61968,
        Double.longBitsToDouble(0x3fedffbe2c794036L), Double.longBitsToDouble(0x3fbe7af83b729d78L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 4, 1, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\ud8f7\udfde\udaba\udd9d\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\u3517\u014b\u180c\u44b3\u6da8\u8835\u9361\u874c\u3ad0\u16d0\u546d\u5324\u5408", "\udb1f\udf2c\ud96c\udf20\udba1\udd6b\ud82d\udc3e\udba3\udd85\uda14\udf13\udb1d\ude52\ud965\udf27\udaa8\udd7a\ud810\udeda\u2841\uda23\uddc2\u1064\ud883\udf63\udaa0\udcb5\uda9b\udd64\u68e4",
        31, 31781, -278743164, 1186360334068727591L, 35832L, true, false, (char) 52220, (char) 5946,
        Double.longBitsToDouble(0x3fd6570f0db71ff0L), Double.longBitsToDouble(0x3fe04a02ce666a79L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 0, 0, 0, "\000", "", "\udaba\udd13",
        -4, 8203, 1498611712, 7161807853666185473L, 15255L, true, false, (char) 52755, (char) 60557,
        Double.longBitsToDouble(0x3fb4679c06e45800L), Double.longBitsToDouble(0x3fbcd0bccc36eac8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 0, 1, 2, "\udab1\udf4e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85", "\ud256\ud530\ub33b\u7752", "\ud9cf\udf40\ud878\ude94\u316c",
        14, 21099, 478042502, 8286098324490951871L, -43887L, false, true, (char) 36619, (char) 61968,
        Double.longBitsToDouble(0x3fdbff7c5f2b15acL), Double.longBitsToDouble(0x3fbe7af83b729fc8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 4, 0, 0, "\ud985\udf4b\udb7f\udd71\ud85a\udf38\ud9a2\uddc5\u4460\udaba\udd13\udb7b\udfd3\ud868\udfbc\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\u30e6\u90a5\u1fd9\u44b3\u6da8\u3b77\ub97d\u434b\u3ad0\u16d0\u546d\u6653\u61fd\u5f93\ubcfe\u6fd9", "\ud82d\udc3e\ud902\udee1\udb43\udc02\udb1c\udf72\ud90c\udf09\udb8d\ude99\ud9bd\udfea\u4515\udb97\udc6b\ud90d\udf41\ud9d9\udd93\ud9cc\uddc1\uda9b\udd64\udbf8\udcda\ud87e\uddf1\ud94e\udeb2\ud938\udeeb\ud965\udd68\udb52\uddf7\uda7c\ude7f\uda1c\ude58\ud866\udd29\ud839\udfe9\ud9f2\udd83\ud801\udecb\ud870\uddbe\udab5\udeab\udba2\udc82\uda02\ude98\ud8a9\ude13\udb53\ude99\uda71\ude44\uda8d\uddcb",
        31, 56705, -950988218, 242613752844396105L, 75466L, false, false, (char) 17657, (char) 3149,
        Double.longBitsToDouble(0x3fd1080a4f9b9238L), Double.longBitsToDouble(0x3fd186411826c976L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 1, "\000", "", "\u759b\udaa0\udeaa\ud86d\udc85\uda7e\udc74\ud9b0\udc14\ud865\udd57\ud998\ude08\uda3d\udf8a\ud959\udd47\uc237\udb7d\udedd\u598e\ud840\ude40\udb8c\udd6b\u94ce",
        29, 98454, 1929257472, 4989457043837442556L, -100000L, true, false, (char) 850, (char) 21504,
        Double.longBitsToDouble(0x3cf0000000000000L), Double.longBitsToDouble(0x3e4ecd9c00000000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udab1\udf4e\uda07\udd53", "\u585f", "\ud86d\udc85",
        32, 78313, 1264595430, 3784878495276987499L, 15255L, true, false, (char) 52755, (char) 60557,
        Double.longBitsToDouble(0x3fbae79c06e45810L), Double.longBitsToDouble(0x3fbcd0bccc36eac8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 2, "", "", "\ud811\ude03",
        26, 25419, -255599253, 6436720501516917305L, 69712L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe45800018e7485L), Double.longBitsToDouble(0x3fb5030e828cf380L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 3, 1, 0, "", "", "\000",
        -5, 38544, 0, 6436720289396031564L, 69472L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e20000000000000L), Double.longBitsToDouble(0x3e1ef3ce00000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udab1\udf4e\uda07\udd53\ud85a\udf87\ud9a2\uddc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u7431\u98e4\u23b9\u8835\u9361\u434b\u3ad0\u16d0\u546d\u6653\u61fd\ua012\ubcfe\u6fd9", "\ud82d\udc3e\ud85a\udc0d\uda2c\udcdd\udb1d\ude52\udab0\udc8d\udaa8\udd7a\ud810\udeda\u2841\uda23\uddc2\u1064\ud883\udf63\udbbb\udec2\uda9b\udd64\udbf8\udcda\ud88e\uddf1\ud94e\udeb2\ud938\udeeb\ud965\udd68\uda97\udc9a\uda7c\ude7f\uda1c\ude58\ud866\udd29\ud839\udfe9\udb5e\udd83\udb7f\udeca\ud870\uddbe\udbea\udc64\udba2\udc82\uda02\ude98\ud8a9\ude13\udb53\ude99\uda71\ude44\uda8d\uddcb",
        38, 78211, -950988041, 242613752844396105L, 75466L, false, false, (char) 22803, (char) 63356,
        Double.longBitsToDouble(0x3feb497e2fcad6e6L), Double.longBitsToDouble(0x3fd18640ebb4c976L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 3, 0, "", "", "",
        -4, 43584, -1815231729, -1097790431018364111L, -87455L, false, false, (char) 10481, (char) 47658,
        Double.longBitsToDouble(0x3fe1b80e800088edL), Double.longBitsToDouble(0x3e05000000000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 2, 3, "\udb30\ude97\uda07\udd53\ud99a\udf38\ud97b\udfc5\u4460\udaba\udd13\udaaf\udcae\ud86d\udc85\uda7e\udc74\ud9b0\udc27\ud871\udd72\uda53\udf01", "\ubc84\u6877\u180c\u44b3\u6da8\u8835\u1d42\u4304\u3ad0\u16d0\u546d\u1bcc\u2a6f\uc85c\u252d\u0cca\u17bd\u02df+\u8665\ua8f6\u889d\u8a61\u32f6\u85ce\u0765\u6e93\ua46b\u86ea\u3a12\u0eb5\u853f\u12c7\ucb2d\u19be\u761e\u97a6\u45a0\u8093\u4d0f\u230b\u1e4b\u8e42\u5980\u09c4\u4167\u5b7c\u12b0\u47d1\u597f\u2bb5\u1bba\u3afa\ucafc\u3635\u7ce6\ubfff\ua303\u96d1\u8bbf\u57f4\u8c88\u3b97\ub1c8\u0d1f\ud3d4\u1f27\u51f2\u79f1\u5a15\u43ea\ube49\u4405\ua988\ud00d\ub809\u25ad\u28cf\u892f\u4737\ub4fa\ube94\ucbf6\u3593\u2694\u1a06\u6dc5\u0c07\uc79f\u2131\u20a0\u2f6c\u8902\u204e\u2453\uc61c", "\ud811\udf7d\ud89e\udef1\uda01\udc69\ud9fe\ude6f\uda32\udf78\udaa4\udc0d\ud8d2\udd26\udbbc\udead\udafc\udf7d\ud838\udd19\ud86a\udd2f\udb33\udf26\udb10\udd44\ud85f\udea0\ud8eb\udd8f\uda88\udd3a\ud86d\udf8e\udbdc\udcd0\udb3f\ude63\ud9cf\udd9e",
        26, 42587, 1389530617, 6633913113095373710L, 11364L, false, false, (char) 9251, (char) 29923,
        Double.longBitsToDouble(0x3fe3fe319bbbe2e9L), Double.longBitsToDouble(0x3feae86cd8994d85L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 1, 2, 0, "\ua21e\uda07\udd53\ud85a\udf38\ud9a2\uddc5\u4460\ud829\udeb4\uda7e\udd9f\ud86d\udc85\ud331\ud9b0\udc27", "\ub33b\u7752\u3517\u90a5\u180c\u3cb2\u6da8\u8835\u9361\u434b\u3ad0\u16d0\u546d\u6653\u61fd\ua012\ubcfe\u6fd9", "\ud863\udc39\ud85a\udc0d\uda2f\udc13\udb1d\ude52\udab0\udc8d\udaa8\udd7a\ud810\udeda\u2841\uda23\uddc2\u1064\ue5be\000\ud812\udfa0\udbf8\udc49\ud88e\uddf1\ud9cf\uddb0\ud938\udeeb\ud965\udd68\udb52\uddf7\uda7c\ude7f\uda1c\ude58\000\ud839\udf5f\udb5e\udd83\udb7f\udeca\ud870\uddbe\udbe9\udfd3\uda6b\udc66\ud9d1\udea8\ud8a9\ude13\udb53\ude99\uda71\ude44\uda8d\uddcb",
        18, 78211, -950988041, 26440970730602496L, 57795L, true, true, (char) 52246, (char) 21269,
        Double.longBitsToDouble(0x3fe5a132fec98d89L), Double.longBitsToDouble(0x3feb497e2fcad6e6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.language.Caverphone|caverphone|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|encode|java.lang.Object|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|encode|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|isCaverphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "C|org.apache.commons.codec.language.Caverphone|<init>|",
    "M|org.apache.commons.codec.language.Caverphone|caverphone|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
