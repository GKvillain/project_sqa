package org.apache.commons.codec.language;
import org.junit.Test;
import static org.junit.Assert.*;
public class Caverphone_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef", "\u521b\u7f76\u14f2\u06d5\u15c4\u0327\uaafb\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda56\udd98\ud928\ude5c\ud93f\ude9d\ud91b\ude6f\udafd\udff5\udb62\udc40\u6223\udb11\udf87\ud8d0\udcaa\ud846\udd82\uda1c\uddce\ud941\ude4a\ud971\uddaa",
        19, 14129, 689709482, 87135886109869697L, -50701L, false, true, (char) 15055, (char) 30445,
        Double.longBitsToDouble(0x3fe8085b6bfa7476L), Double.longBitsToDouble(0x3fbd7ff9ffa4e190L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30", "\ua065\u07df\u521b\u7f76\u14f2\u06d5\ua758\u8501\uab90\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf\ua0bd\uaf58\u6493\u080e\u1e50", "\ud93f\ude9d\ud925\udc68\udafd\udff5\udb62\udc40\u6223\udb11\udf87\ud8d0\udcaa",
        48, 45139, 944534265, 7515110658347131246L, -91382L, false, true, (char) 34741, (char) 8101,
        Double.longBitsToDouble(0x3fe4d2222214b333L), Double.longBitsToDouble(0x3fe8fc978b21565cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud989\udf61\ud97c\udc3d\udb11\udd16\udb00\udd62\ud8e2\udcef", "\u521b\u9033\uc501\u06d5\u15c4\u0327\uaafb\u923b\u052b\u419a\u1dea\ub1f7\u39a9\ua2a8\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda58\udc98\ud928\ude5c\ud93f\ude9d\ud91b\ude6f\udafd\udff5\udb54\udf7a\uda6b\udc55\udb11\udf87\ud8d0\udcaa\ud846\udd82\uda1c\uddce\ud941\ude4a\ud971\uddaa",
        59, 52266, 535026544, -3821009455958713333L, -39453L, true, true, (char) 11363, (char) 30704,
        Double.longBitsToDouble(0x3fc416c5fd713e44L), Double.longBitsToDouble(0x3fe8085b6bfa7476L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 1, 0, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef", "\u521b\u7f76\u14f2\u06d5\u15c4\u0327\u317b\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf", "\ud809\udd08\ud93d\udda4\ud93e\udcb3\udb7c\udf6b\ud8e6\uddd7\ud934\udfc3\udbeb\udfd7\ud82a\udfdb\u0332\udaaf\udce9\ud930\udf34\ud8d0\udcaa\ud846\udd82\uda1c\uddce\ud941\ude4a\ud971\uddaa",
        19, 14129, 689709482, 87135886109869697L, -75596L, true, true, (char) 8720, (char) 43389,
        Double.longBitsToDouble(0x3fc26d7a054b5900L), Double.longBitsToDouble(0x3fc416c5fd713e44L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 4, 4, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udc71", "\u521b\u7f76", "\ubdf2\udafd\udcd1\ud8e8\udd0e\udb78\udd98\udb6f\uddc8\uda20\udf01\ud96c\udd66\ud9f9\udf7a\uda29\udd46\ud9b1\udec9",
        3, 39533, -2026299421, -8069486276550162122L, 44869L, false, true, (char) 63264, (char) 49867,
        Double.longBitsToDouble(0x3fe175f2a855c074L), Double.longBitsToDouble(0x3fc13f35f4dcfc5cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 2, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef", "\u521b\u7f76\u65d5\u06d5\u15c4\u0327\uaafb\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf\ua0bd\uaf58\u6493\u080e\u1e50\uccd6", "\ud91b\ude6f\udafd\udff5",
        39, 95479, -994428154, 72832314562766428L, -75168L, true, false, (char) 29328, (char) 47803,
        Double.longBitsToDouble(0x3fe40809ace072c4L), Double.longBitsToDouble(0x3fe4929b5354a609L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\udbbd\udcdc", "\u521b\u7f76", "\ubdf2\udafd\udcd1\ud8e8\udd0e\udb78\udd98\udb6f\uddc8",
        40, 82498, 1557469698, 3011758953171543261L, -58965L, true, true, (char) 62284, (char) 6457,
        Double.longBitsToDouble(0x3fbed195af29fe18L), Double.longBitsToDouble(0x3fd0228daa4c13f6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud989\ude9c\udb1c\udf4f\udb7c\udc5e\udb86\udd01\ud8e2\udcef", "\u8356\u7f76\u14f2\u06d5\u4db1\u0327\uaafb\u923b\u052b\u419a\ua6ed\u04c5\u8459\ua2a8\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda56\udd98\uece5\u11a4\uda79\udcb6\udadc\udca1\ud822\udd92\ud80f\udfca\uda02\ude78\udb57\udf7f\ud805\ude9b\uda1c\uddce\ud941\ude4a\ud990\uddaa",
        47, 14129, 689709482, 87135886109900673L, -31984L, false, false, (char) 23517, (char) 30460,
        Double.longBitsToDouble(0x3fc416d55d713e44L), Double.longBitsToDouble(0x3feddade63fa7426L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 1, 1, 0, "\ud989\ude9c", "\u38a5\uc018\ua065\u07df\u521b", "\udbc5\udfe2\ubdf2\ud9c8\ude9f\ud881\udf09\ud81e\udc70\udabc\udf47\uda3b\udc94\uc6d9\ud9f9\udf7a\uda29\udd46\ud9b1\udec9\udaa7\ude1d\ud962\udea7\udb8a\udcc4\u6dd4\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda56\udd98\ud928\ude5c\ud93f\ude9d\ud937\udcdd\udafd\udff5\ud9ec\uddb0\u62d4\uda58\ude72\ud8dd\uddb7",
        48, 45139, 944534265, 5303561766331506944L, -91309L, false, false, (char) 62026, (char) 59044,
        Double.longBitsToDouble(0x3fefe01a2214b333L), Double.longBitsToDouble(0x3fe8fc978d21565cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef", "\u521b\u7f76\u14f2\u06d5\u15c4\u0327\uaafb\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda56\udd98\ud928\ude5c\ud93f\ude9d\ud91b\ude6f\udafd\udff5\udb62\udc40\u6223\udb11\udf87\ud8d0\udcaa\ud846\udd82\uda1c\uddce\ud941\ude4a\ud971\uddaa",
        19, 85392, -940105302, 87185398492857985L, -50701L, false, true, (char) 15055, (char) 30445,
        Double.longBitsToDouble(0x3fe8085b6bfa7476L), Double.longBitsToDouble(0x3fbd7ff9ffa4e190L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 1, 2, "\ud989\ude9c\uda98\udded\ud9a9\ude06\udb00\udd58\ud8e2\udcef\udbea\udc42\uda8a\udf51\udac2\udccf\ud8b8\uddda\ue766\udbc5\udfe2\ubdf2\udafd\udcd1\ud8e8\udd0e\udb78\udd98\udbba\udc8d\ud8aa\udd53\udb6c\udc15\uda0a\ude7a\uda29\udd46\ud9b1\udec9\udb96\ude15\ud93e\udc5a\ud8e2\udfb4\ud9e7\udd79\ud9b4\udc02\ud864\udf48\uda74\udce7\uda3f\udc71\ud928\ude5c\ud93f\ude9d\ud91b\ude6f\udafd\udff5\udb62\udc40\ud9bd\ude35\udb11\udf87", "\u10cb\u12e1\u7f70\u2c4d\u91ea\u3a63\uc30e", "\ud970\udf75\udaaa\udfa6\udb93\udc35\ud8d7\udfc2\udba0\udf48\ud965\udd2f\uda1b\ude5c\ud88a\udd1f\u09ec\ud834\udcb3\ud90d\ude2d\ud96b\ude96",
        25, 61462, -1918409744, -6722105323989811390L, -87593L, false, true, (char) 17418, (char) 41530,
        Double.longBitsToDouble(0x3fd26f73f6302940L), Double.longBitsToDouble(0x3feee398200ed0c7L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 4, 2, 3, "\uda3e\udd86\ud920\udfb2\udb7c\udc30\udb56\udfe9\ud86e\ude0d", "\u521b\u7f76\u14f2\u06d5\u15c4\u0327\uaafb\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf\uc86f\u7379\u646a\u3f29\u1e50\uccd6\u0d15\u84a8\u6edd\u88d9\u2750\u874f\uccc5\ub987\u04cc\ucd63\u79ce\ua623\u7e37\u91ea\u3a63\uc30e\ud686\u4fbf\uacf6\u44f7\ube85\u5566\u5718\uc233\u12ee\uc4e6\ubd08\u46dd\u3e2b\u9645\ud1e6\u4c12\u2694\uc7c2\u99ee\u5261\u4fb1\uc537\u2542\ud629\u8070\ua87e\u152b\u8fcd\ub53d", "\uda54\uddec\udbe8\udc4a\udab4\udda3\uda07\udc12\ud9ff\udc4f\ud9b3\udded\ud879\udf5c\ud94f\udf2b\ubd86\ud91b\ude07\uda8d\udfaf\udbb8\ude8d\ud841\uddf6\ud994\udfb0\udbdc\udfc9\ud8cb\uddd8\udadf\udd88\ud9c1\ude40\ud853\ude8a\udb06\udd63\udaa0\udef4\ud9a2\udcd7\uda94\udd27\ud876\ude2a\ud9d9\udf43",
        50, 49865, -1566283795, -97323635814249370L, -63656L, false, false, (char) 44590, (char) 13381,
        Double.longBitsToDouble(0x3fedcee87ebd5021L), Double.longBitsToDouble(0x3fc98abb1490ac48L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 3, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef", "\u7801\u7f76\u14f2\u06d5\u15c4\u0327\uaafb\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda56\udd98\ud928\ude5c\ud93f\ude9d\ud91b\ude6f\udafd\udff5\udb62\udc40\u6223\udb11\udf87\ud8d0\udcaa\ud846\udd82\uda1c\uddce\ud941\ude4a\ud971\uddaa",
        19, 14129, 689709482, 87135886109869697L, -50701L, false, true, (char) 15055, (char) 30445,
        Double.longBitsToDouble(0x3fe8085b6bfa7476L), Double.longBitsToDouble(0x3fbd7ff9ffa4e190L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 4, 2, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\ud9d0\udeff\ud8e2\udcef", "\u521b\u7f76\u14f2\u06d5\u15c4\u0327\u20c3\ua628\u8756\u4148\ua6ed\u7808\u8459\ua2a8\u2795\u02bf", "\udb59\udc54\udbf6\udc9c\ud920\udc4d\uda56\udd98\ud928\ude5c\ud93f\ude9d\ud91b\ude6f\udafd\udff5\udb62\udc40\u6223\udb11\udf87\ud8d0\udcaa\ud846\udd82\ud806\udcf8\ud8a8\ude3c\ud971\uddaa",
        19, 14129, 689709482, 87135886109869697L, -88996L, false, false, (char) 47877, (char) 43389,
        Double.longBitsToDouble(0x3fc26d7a06c35900L), Double.longBitsToDouble(0x3fc416c5fd713e44L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 0, 1, 2, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud91f\udeee\udbea\udc42\udb6e\udda3\ud88e\udfe4\ud8b8\uddda", "\u3578\u4946\u1706\u9203\u052b", "\ud9f9\udf7a\uda29\udd46\ud9b1\udec9\ud91f\udd78\ud911\udef7\udb8a\udef6\ud9e7\udd79\ud86f\udd5b\udbce\udd3c",
        30, 84826, -793645786, -4731609219991313874L, -35323L, false, true, (char) 22788, (char) 43133,
        Double.longBitsToDouble(0x3fe4cdd64954384cL), Double.longBitsToDouble(0x3fd00499a4136d10L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 2, "\ud989\ude9c", "\000\000\ua065\u07df\u008b", "\udbc5\udeeb",
        43, -1000, 1101243648, 10981085444606691L, -100000L, false, false, (char) 18341, (char) 36520,
        Double.longBitsToDouble(0x3f431c9ed75abc00L), Double.longBitsToDouble(0x3fef188084138739L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 0, 2, 1, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe", "\u07df\u521b", "\udbc5\udfe2\ubdf2\udafd\udcd1\ud8e8\udd0e\udb78\udd98\udb6f\uddc8\uda20\udf01\udb6c\udc15\u35c5\uda29\udcc7\ud9b1\udec9\uda6a\udc1e\ud93e\udca7\udb8a\udcc4\ud9e7\udd79\ud86f\udd5b\udaea\udd05\u0c00\uda39\udf45\udac1\ude40\ud89f\uddd8\ud829\udcb5\uda45\udff9\udb62\udc40\u6223\udb11\udf87\ud8d0\udcaa",
        48, 88939, 1751409632, 5303561766331506944L, -91382L, false, true, (char) 34741, (char) 7386,
        Double.longBitsToDouble(0x3fe9b5f4ea69cbb6L), Double.longBitsToDouble(0x3fe8fc041b21565cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "", "\u8004\u38a5\uc018\ua065\u07df\u521b\u7f76\u14f2\u06d5\u15c4\ub87b\uaacb\u923b\u052b", "\ud9f9\udf7a\uda29\udd46\ud9b1\udec9\udaa7\ude1d\ud93e\udca7\udb8a\udcc4\ud9e7\udd79\ud86f\udd5b\udbf6\udc3c",
        30, 26698, -793645786, -4731609220159086034L, -84777L, true, true, (char) 1740, (char) 34133,
        Double.longBitsToDouble(0x3fe2e0081563adaeL), Double.longBitsToDouble(0x3fe7ce1a0954384cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 4, "\ud989\ude9c", "\000", "\uda8a\udf51",
        35, 75085, -1585744648, -6209411691100984784L, 96608L, true, true, (char) 28426, (char) 44525,
        Double.longBitsToDouble(0x3fdd2e257405c51eL), Double.longBitsToDouble(0x3e4374a400000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef", "\u521b\u7f76\u14f2\u06d5\u15c4\u0327\uaafb\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda56\udd98\ud928\ude5c\ud93f\ude9d\ud88d\udda4\udb26\udee9\u0587\ud9fa\ude0b\ud967\udcf6\ud8d0\udcaa\ud846\udd82\uda1c\uddce\ud868\ude3d\ud971\udd87",
        19, 14129, 689709482, 87135886109869697L, 37985L, false, true, (char) 17501, (char) 13350,
        Double.longBitsToDouble(0x3fb987e8aa15d778L), Double.longBitsToDouble(0x3f87bf84284cb200L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud989\udf8e\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef", "\u521b\u7f76\u14d7\u06d5\u15c4\u0327\uaafb\u923b\u052b\u419a\uaeba\u44e7\u4e9f\ua21f\u2795\u02bf", "\ud8f9\uded9\udaec\uddc4\ud994\ude2c\udb3e\ude24\ud912\udf9b\uda42\udf5f\ud9b9\udf01\uda24\udcaa\udb62\udc40\u6223\udb11\udf87\ud8d0\udcaa\ud846\udd82\udb2b\uddb5\ud941\udd6c\ud971\uddaa\uda6f\udcab\ud9cd\udecd\udb08\ude6a\ud8ca\uddb2\ud9ab\udd44\ud901\udc11\ud970\udf75\udaaa\udfa6\udb93\udc35\ud8ae\udfed\ud850\udf51\udb36\udf7b\uda7e\udccf\ud964\udc08\u09de\ud9fe\udff8\ud90d\ude93\ud8f0\ude98\ud882\uddcf\uda0b\ude9c\ud8d6\udcdc\ud948\udfd2\udb44\udf5c\ud8d7\udd84\ud994\uddf0\udba4\udd20\udb85\udf50\udb5c\udd96\ud814\udcbf\udab8\udcbb\udb4c\udcc3\ud867\udf7e\uda3a\udf7c\udada\udfa8\u3ca2\ud857\udcd3\ud8db\ude4b\udb17\udcfa\ud85e\udee3\udbfb\ude61\udba8\udc8f\udaf3\ude8a\uda90\uded5\ud84e\uddf8\ud8f7\udc68\ud92e\ude30\udaeb\udd89\ud83e\udf28\udabc\ude41\ud806\udf74\udb23\udc73\ud869\udf89\uda71\udfa2\ud957\ude7f\uda55\udf60\ud87a\udd4c\udbea\udecc",
        24, 19592, -1015100718, -4906640021313223541L, -67200L, true, true, (char) 44047, (char) 49189,
        Double.longBitsToDouble(0x3fd775e4d355c9b4L), Double.longBitsToDouble(0x3fe0ca24fb034440L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 2, 4, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe", "\ucb0c\u521b", "\udbc5\udfe2\ubdf2\udafd\udcd1\ud977\ude4a\udb78\ude22\udb6f\uddc8\ud89f\udc20\udab2\ude73\ud8bb\udd74\ud97d\udc51\ud9b1\udec9\udaa7\ude1d\ud93e\udca7\udb86\udeb6\ud9e7\ude38\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\ud937\udc08\ud928\ude5c\ud93f\ude9d\ud91b\ude6f\udafd\udff5\udb62\udc40\u6223\udb11\udf87\ud8d0\udcaa",
        1, 45272, 944534265, 5303561766331506944L, 76554L, true, false, (char) 4682, (char) 22904,
        Double.longBitsToDouble(0x3fe260fbbc7df203L), Double.longBitsToDouble(0x3fedab7f3321565cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30", "\u8bba\u07df\u521b\u7f76\u14f2\u06d5\ua758\uc0db\uce32\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf\ua0bd\uaf58\u84de\u2a66\u1e50", "\ud93f\ude9d\udbce\udc3c\udabf\udf6f\uda91\udd82\udbfd\ude66\ud92b\ude97\ud8d0\udcaa",
        48, 78955, 944534265, 7515110658347131246L, -91382L, false, true, (char) 31983, (char) 8101,
        Double.longBitsToDouble(0x3fe4d2222214b333L), Double.longBitsToDouble(0x3fe8fc978b21565cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 4, 0, 0, "\000", "\u27eb\uc018\ua065", "\000",
        -5, 72432, 2040151865, -4031250187992170496L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe682e6acdd29cbL), Double.longBitsToDouble(0x3fc1b31c9ed75abcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 4, 1, 0, "\ud989\ude9c\uda98\udded\ud9fa\udee2\udb00\udd4c\ud8e2\udcef", "\u521b\u66bd\u14f2\u06d5\u15c4\u58c8\uc6c7\u2288\u6f08\u419a\ua6ed\u7808\u8459\u1cc2\u103e\u02bf", "\ud809\udd08\ud93d\udda4\ud93e\udcb3\udb7c\udf6b\ud8e6\uddd7\ud934\udfc3\udbeb\udfd7\ud82a\udfdb\u0324\udaaf\udce9\ud930\udf34\ud8d0\udcaa\ud846\udd82\uda1c\uddce\ud941\ude4a\ud989\udcaa",
        14, 14129, 689709482, 87135886109869697L, -75596L, true, true, (char) 8720, (char) 43389,
        Double.longBitsToDouble(0x3fcf4d7a054b5900L), Double.longBitsToDouble(0x3fc416c5fd713e44L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\0121=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udc71", "\u521b\u0997", "\ubdf2\udafd\udcd1\ud8e8\udd0e\udb78\udd98\udb6f\uddc8\uda20\udf01\ud96c\udd66\ud9f9\udf7a\uda29\udd46\ud9b1\udec9\udaa7\ude1d\ud93e\udca7\udb8a\udcc4\ud9e7\ude62\ud983\uddc5\udaee\ude8c\ud928\udccd",
        -2, 11214, -1101663718, -4578926971526844331L, 97943L, true, true, (char) 1773, (char) 26298,
        Double.longBitsToDouble(0x3fe79e01697cc65aL), Double.longBitsToDouble(0x3fd72004831d8cf8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud989\ude9c\uda98\udded\udb80\udf83\udb00\udcfe\udb81\udce6", "\u3c29\u7f76\u65d5\u7b93\ua175\u0327\uc6fa\u923b\uc736\u419a\u3204\ucbd9", "\udaa7\udda1\ud93e\udca7\udab4\uded8\ud81d\udca9\udb8a\udd81\udac7\udf1d",
        59, 54956, -793645691, -4731609220159086034L, -42294L, true, true, (char) 34171, (char) 56618,
        Double.longBitsToDouble(0x3fe2e00817c3335eL), Double.longBitsToDouble(0x3fefce1a0f1b96e0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud896\udd03\u1884\uc24b\000\000", "\u5190\u0095\uc8dc\u06d5\u15c4\u0327\uaafb\u91fe\u052b\u419a\000\000\000\000", "",
        36, 21275, 1180076342, 216033245410789L, 26246L, false, false, (char) 25134, (char) 61555,
        Double.longBitsToDouble(0x3fc13f35e0dcfc5cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 2, 3, 0, "", "\u8004", "\u00d6",
        -5, -1000, -1346456064, -9188622007664395017L, -93993L, false, true, (char) 17632, (char) 35593,
        Double.longBitsToDouble(0x3fc82625874b895cL), Double.longBitsToDouble(0x3fe017147ad05cd5L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 3, 0, "\ud989\ude9c\udb1c\udf4f\udb7c\udc5e\udb86\udd01\ud8e2\udcef", "\u8356\u7f76\u14f2\u06d5\u4db1\u0327\uaafb\u923b\u99db\ub3d9\ua6ed\u04c5\u8459\ua2a8\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda56\udd98\uece5\u11a4\uda79\udcb6\udadc\udca1\ud822\udd92\ud80f\udfca\uda02\ude78\ud903\udd96\u50bb\uda1c\uddce\ud941\ude4a\ud990\uddaa",
        47, 14129, 689709482, 87135886109900673L, -31984L, false, false, (char) 23517, (char) 30460,
        Double.longBitsToDouble(0x3fc416d55d713e44L), Double.longBitsToDouble(0x3feddade63fa7426L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 3, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\uc398\udb75\ude9a", "\u7801\u7f76\u14f2\u06d5\u15c4\u0327\uaafb\ucb0c\u052b\u419a\ua6ed\u7808\u8459\ua001\ud7d6\ube08\ua0bd\u0b8b\ucacd\u080e\u1e50\uccd6\u0d15\u84a8\u6edd\u88d9\u2750", "\ud8d5\udd8b\ud846\udd82\uda32\udfce\ud941\ude4a\ud971\uddaa\uda6f\udcab\ud9cd\udecd\udbd0\ude6a\ud8e3\udd8a\ud9ab\udd44\ud901\udc11\ud970\udf75\udaaa\udfa6\udb93\udc35\uda0c\udd7b\ud858\udf1d\ud975\udd56\ud984\udd50\ud960\udd08\u09de\ud9fe\udff8\ud90d\ude93\uda1a\udfed\udb96\udc53\udb0e\udf65\ud81f\udc47\ud8b7\udc89\ud9db\udca8",
        41, 16869, 2108595016, -2547664490820529261L, 85130L, false, false, (char) 57131, (char) 62836,
        Double.longBitsToDouble(0x3fc7390cf4aef6c0L), Double.longBitsToDouble(0x3fd938a51cf7e4d2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 3, 0, "", "\u8004\u38a5\uc018\ua065\u07df\u7801\u7f76\u14f2\u06d5\u15c4\u0327\uaafb\u923b\u052b", "\ud9f9\udf7a\uda29\udd46\ud9b1\udec9\udaa7\ude1d\ud93e\udca7\udb8a\udcc4\ud9e7\udd79\ud86f\udd5b\udbf6\udc3c",
        30, 26698, -793645786, -4731609220159086034L, -84777L, true, true, (char) 1740, (char) 34133,
        Double.longBitsToDouble(0x3fe2e0081563adaeL), Double.longBitsToDouble(0x3fe7ce1a0954384cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 1, 3, 2, "", "", "\ud8e2\udcef",
        31, 60235, 799485831, -5782984122016500488L, -100000L, false, false, (char) 0, (char) 44525,
        Double.longBitsToDouble(0x3f4c4ae80b8a3c00L), Double.longBitsToDouble(0x3fe682e6acdd29cbL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef", "\u521b\u7f76\u14f2\u06d5\u15c4\u0327\u7acd\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda56\udd98\ud928\ude5c\ud93f\ude9d\udb3e\udd7f\udafd\udff5\udb62\udc40\u6223\udb2b\udc87\ud86c\udc17\ud81a\udd5b\uda1c\uddce\ud941\ude4a\ud971\uddaa",
        19, 14129, 689709482, 877856266587372056L, 35308L, true, true, (char) 39934, (char) 17567,
        Double.longBitsToDouble(0x3fc26d7a06c35900L), Double.longBitsToDouble(0x3fc416c5fd713e44L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud989\ude9c\udb1c\udf4f\udb7c\udc5e\udb86\udd01\ud8e2\udcef", "\u8356\u7f76\u14f2\u06d5\uc2ba\u03a3\u9b2b\u923b\u052b\u419a\ua6ed\u04c5\u8459\ubac2\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\udbe2\uddef\uda56\ude90\uece5\udbd3\udcc8\uda79\udcb6\udadc\udca1\ud822\udd92\ud971\udc23\uda23\ude52\udb57\udf7f\ud805\ude9b\uda1c\uddce\ud995\udfb4\ud978\udcaf",
        47, 14129, 1562124714, -6627696536568147874L, -31984L, false, false, (char) 23517, (char) 30460,
        Double.longBitsToDouble(0x3fc416d55d713e44L), Double.longBitsToDouble(0x3feddade63fa7426L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 4, 0, "\ud989\ude9c\u5dba\uda94\udf21\ub9fb\ud8e2\udcef", "\u0425\u7f76\u14f2\u06d5\uc2ba\u03a3\u9b2b\u923b\u052b\u2787\ua6ed\u04c5\u8459\ubac2\u2795\u73a0", "\ud86f\udd5b\udbf6\udc3c\udbe2\uddef\uda56\ude90\uece5\udbd3\udcc8\uda79\udcb6\udadc\udca1\ud822\udd92\ud971\udc23\uda23\ude52\udb57\udf7f\u320f\uda1c\uddce\ud995\udfb4\ud978\udcaf",
        47, 14129, 1562124714, -6627696536568147874L, -31984L, false, false, (char) 23517, (char) 30460,
        Double.longBitsToDouble(0x3fc416d55d713e44L), Double.longBitsToDouble(0x3feddade63fa7426L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud989\ude9c\udb1c\udf4f\udb7c\udc5e\udb92\udea7\udaa2\udf7a\udbf3\ude42\ud819\udf39\ud89b\udd1f\ud8b8\uddda\ue766", "\u03a3\u9b2b\u923b\u052b\ua4f9\ua6ed", "\ud895\udd0b\udaa7\ude1d\ud93e\udca7",
        41, 1397, 1180076342, 4594732076281509349L, 26246L, true, true, (char) 57007, (char) 28296,
        Double.longBitsToDouble(0x3fecee1807dedd56L), Double.longBitsToDouble(0x3fe70243cba03a7fL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 0, 3, "\ud84f\ude9f\udb1c\udf4f\ud992\udec9\ud99d\udcfc\udb7d\uddd6", "\u8356\u7f76\u76d9\ud3d1\uc303\u03a3\u9b2b\u923b\u5a34\u4197\ua6ed\u04c5\u8459", "\ud950\udce1",
        44, 78083, -1134261962, 4594531892150810085L, 26246L, true, true, (char) 57007, (char) 58909,
        Double.longBitsToDouble(0x3fecde3987dedd56L), Double.longBitsToDouble(0x3fe3a243cba03a7fL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 2, 0, "\ud989\uded9\udb1c\udf4f\udb7c\udc5e\udb86\udd01\ud8e2\udcef", "\u5ed6\u0157\u5242\u167d\u7dd9\u03a3\u9b2b\u923b\u052b\u419a\ua6ed\u04c5\u8459\ubac2\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\udbe2\uddef\ud986\udc76\uda8d\udd4e\ud8c7\udf88\uda40\udf65\udadc\udca1\ud822\udd92\ud971\udc23\uda23\ude52\udb57\udf7f\ud805\ude9b\uda1c\uddce\ud995\udfb4\ud978\udcaf",
        47, 14129, 1562124714, -6627696536568147874L, -31984L, false, false, (char) 23517, (char) 30460,
        Double.longBitsToDouble(0x3fc416d55d713e44L), Double.longBitsToDouble(0x3feddade63fa7426L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud989\ude9c\u8111\udb7c\udc5e\udb86\udd01\ud8e2\udcef", "\u8356\u35fc\u14f2\u06d5\uc2ba\u03a3\u9b2b\u923b\u052b\u419a\ua6ed\u7ff9\u370d\uc6bf\u3e81\u025b", "\udb6b\udd0f\uda0d\udfb8\udbe2\uddef\uda56\ude90\uece5\udbd3\udcc4\uda79\udcb6\udadc\udca1\ud822\udd92\ud971\udc23\uda23\ude52\udb57\udf7f\ud805\ude9b\uda1c\uddce\ud995\udfb4\ud978\udcaf\udaf4\udea7\ud9cd\udecd\udac3\udf26\ud954\udfb1\ud9bd\udf21\ud901\udc11\ud970\udf75\ud884\udc12\ud865\udc23\ud8dc\udf7a\ud93b\udf28",
        46, 18736, 1540106076, 8369600962489877498L, -66284L, false, false, (char) 46850, (char) 52510,
        Double.longBitsToDouble(0x3fc85ccf5169c238L), Double.longBitsToDouble(0x3fe633336dd4ad73L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud989\ude9c\udb1c\udf4f\udb7c\udc5e\udb86\udd01\ud8e2\udcef", "\u8356\u7f76\u1a64\u50fd\u5bc9\u03a3\u9b2b\u923b\u052b\u419a\ua6ed\u04c5\u31c5\u3857\u2716\u02bf", "\ud86f\udd5b\udbf6\udc3c\udbe2\uddef\uda56\ude90\uece5\udbd3\udcc8\uda79\udcb6\udadc\udca1\ud822\udd92\ud971\udc23\uda23\ude52\udb57\udf7f\ueb4d\uda1c\uddce\ud995\udfb4\ud978\udcaf",
        47, 14129, 1562124714, -6627696536568147874L, -31984L, false, false, (char) 23517, (char) 30460,
        Double.longBitsToDouble(0x3fc416c3fd713e44L), Double.longBitsToDouble(0x3feddade63fa7426L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud989\ude9c\udb1c\udf4f\udb7c\udc5e\udb86\udd01\ud8e2\udcef", "\u8356\u7f76\u14f2\u7909\uc2ba\u03a3\u9b2b\u923b\u052b\u419a\ua6ed\u04c5\u8459\ubac2\u2795\u02bf", "\ud86f\udd5b\udbf6\udc3c\udbe2\uddef\uda56\ude90\uece5\udbd3\udcc8\uda79\udcb6\udadc\udca1\ud822\udd92\ud971\udc23\uda23\ude52\udb57\udf7f\ud805\ude9b\uda1c\uddce\ud995\udfb4\ud978\udcaf",
        47, 14129, 1562124714, -6627696536568147874L, -31984L, false, false, (char) 23517, (char) 30460,
        Double.longBitsToDouble(0x3fc416d55d713e44L), Double.longBitsToDouble(0x3feddade63fa7426L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 0, 0, "\ud989\ude9c\udb1c\udf4f\udb7c\udc5e\udb52\udc87\ud8e2\udcef", "\u8332\u54c7\ua94b\u06d5\ud089\u03a3\u9b2b\u451f\u4f54\u8f87\u380e\ua08c\u8609\ua17b\ud45a\u5e7d", "\ud86f\udd5b\udabb\udf5f\ud92e\ude9b\uda39\udc05\uece5\udbd3\udcee\ud9c1\udcba\udafa\ude71\udaec\ude57\udb80\ude03\uda0c\udc0a\ud8c8\udd83\ud9af\udd5f\ud931\udc77\ud83a\udcfc\udb4d\ude97",
        47, 98969, 1562124714, -6627696536568147874L, 65884L, false, true, (char) 25157, (char) 46366,
        Double.longBitsToDouble(0x3fe940c45612b1f3L), Double.longBitsToDouble(0x3fc94dd882375788L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud989\ude9c\udb1c\udf4f\udb7c\udc5e\udb86\udd01\ud8e2\udcef", "\u8356\u7f76\u14f2\u06d5\uc2ba\u03a3", "\udb6f\uddc8\uda20\udf01\udb6c\udc15",
        -4, 86776, 1276864655, -2977133834529644619L, -62131L, false, true, (char) 2769, (char) 30120,
        Double.longBitsToDouble(0x3fdfabcdaa4c13f6L), Double.longBitsToDouble(0x3fd65fbb128efad0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 4, 0, "\ud989\ude9c\u5dba\uda94\udf21\ub9fb\ud8e2\udcef", "\u0425\u8d63\u5663\u3571\uc2ba\u03a3\u5880\u3263\u765a\u97b1\u6163\u0563\u8459\u03a3\u65f0\u73a0", "\ud86f\udd5b\udbf6\ude3c\udbe2\uddef\uda56\ude90\uece5\udbd3\udcc8\uda79\udcb6\udadc\udca1\ud822\udd92\ud971\udc23\uda23\ude52\ud9b7\udd7e\u320f\uda1c\uddce\ud995\udfb4\ud978\udcaf",
        47, 14129, 1567316274, 1619134352462987435L, 58955L, false, true, (char) 51057, (char) 14214,
        Double.longBitsToDouble(0x3fedf7c5e3faaa9bL), Double.longBitsToDouble(0x3feebeba72326b60L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 0, 0, "\ud4b1\u7aef\uda94\udf21\udbbd\udca1\uda9c\udd53", "\u0425\u3cdf\u0b1a\u06d5\uc2ba\u03a3\u16da\u285c\u028b\u2787\ua6ed\u04c5\u8459\ubac2\u2795\u73a0", "\ud912\ude8e\udbf2\udd40\udbe2\uddef\uda56\ude90\uece5\uda9d\udf00\udb1f\ude9a\ud91b\udc66\ud822\udd92\ud971\udc23\uda23\ude52\udb57\udf7f\u320f\uda1c\uddce\ud995\udfb4\udbce\udc7a",
        -3, 20559, 1562124714, -6627696536568147874L, -31984L, false, false, (char) 23517, (char) 30460,
        Double.longBitsToDouble(0x3fc416d55d713e44L), Double.longBitsToDouble(0x3fef3aae62fa7426L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 3, 3, "\ud989\ude9c\udac3\uddae\uda94\udf21\ub9fb\ud8e2\udcef\udbea\udc42\udb8d\udcec\udbfa\ude8e", "\u8b99\uc2ba\u03a3\u9b2b\u923b\u052b\u2787\ua6ed", "\ud895\udd0b\udbb6\ude5c\ufc47",
        55, 78083, 1180076342, 4594732076281509349L, 26246L, true, true, (char) 57007, (char) 28296,
        Double.longBitsToDouble(0x3fecee1807dedd56L), Double.longBitsToDouble(0x3fe70243cba03a7fL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 0, 0, "\ud4b1\u7aef\uda94\udf21\udbbd\udca1\uda9c\udd53", "\u0425\u3cdf\ua73f\u39b4\uc2ba\u03a3\u16da\u4a81\u028b\u2787\ua6ed\u04c5\u8459\ubac2\u4c43\u5c9a", "\ud912\ude8e\udb72\udfb8\udbd7\udfef\uda56\ude90\uece5\ud848\udfcf\udbb7\udfba\u878a\ud822\udd92\ud971\udc23\uda23\ude52\udb57\udf7f\udb09\udd4c\ud9ec\ude4c\udbe9\udd1a\ud9de\udf4f",
        21, 20559, 1562124714, -6627696540601249954L, -31984L, false, false, (char) 23517, (char) 30460,
        Double.longBitsToDouble(0x3fdb14faae0868faL), Double.longBitsToDouble(0x3fe1b090e2170e04L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 0, 0, "\ud4b1\u7aef\uda94\udf21\udbbd\udca1\uda9c\udd53", "\u0425\u3cdf\ua73f\u39b4\uc2ba\u03a3\u16da\u4a81\ub36e\u2787\ua6ed\u04c5\u8459\u1036\u4c43\u5c9a", "\ud912\ude8e\udb72\udfb8\udbd7\udfef\uda56\ude90\uece5\ud848\udfcf\udbb7\udfba\u878a\ud822\udd92\ud971\udc23\uda23\ude52\udb57\udf7f\udb09\udd4c\ud9ec\ude4c\udbe9\udd1a\ud9de\udf4f",
        21, 20559, 1562124714, -6627696540601249954L, -31984L, false, false, (char) 23517, (char) 41986,
        Double.longBitsToDouble(0x3fdb14f95e0868faL), Double.longBitsToDouble(0x3fe1b438aa170e04L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 0, 0, "\ud4b1\u7aef\uda94\udf21\udbc2\udd60\udaac\udd3e\u63bc\ud9b4\udcb6\ud8a7\udf24\ud977\ude19", "\uc2ba\u03a3\u16da", "\ud990\udfb5",
        -2, 106, 701181121, 5484091936490964877L, -26355L, true, false, (char) 63685, (char) 59288,
        Double.longBitsToDouble(0x3fef2f0f29fabcdaL), Double.longBitsToDouble(0x3fd2609fb115f762L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 0, 0, "\ud4b1\u7aef\uda94\udf21\udbbd\udca1\uda9c\udd53", "\u0425\u3cdf\ua73f\u39b4\uc2ba\u03a3\u16da\u4a81\ub36e\u2787\ua6ed\u0fbc\u8459\u1036\u4c43\u5c9a", "\ud912\ude8e\udb72\udfb8\udbd7\udfef\uda56\ude90\uece5\ud848\udfcf\udbb7\udfba\u878a\ud822\udd92\ud971\udc23\uda23\ude52\ud962\udf84\udb42\udd3a\ud9ec\ude5d\udbe9\udd1a\ud9de\udf4f",
        21, 20559, 1562124714, -6627696539594608037L, -49497L, false, false, (char) 54337, (char) 46366,
        Double.longBitsToDouble(0x3fea98c4541b5fe7L), Double.longBitsToDouble(0x3fdb14f95e0868faL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 0, 0, "\u3ebf\u7aef\uda94\udf21\udbc2\udd60\udaac\udd3e\000\ud9b4\udcb6\ud8a7\udf24\ud977\ude19", "\u5a6e\u03a3\u16da", "\000",
        -2, 106, 701181121, 5484091936490964877L, -26355L, true, false, (char) 22, (char) 59288,
        Double.longBitsToDouble(0x3fef2f0f28fabcdaL), Double.longBitsToDouble(0x3fd2609fb115f762L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 0, 1, "\ud4b1\u7aef", "\u7ed0\u83df\uaa42\u0425\u3cdf\ua73f\u39b4\uc2ba\u03a3\u16da\u4a81\ub36e\u2787\ua6ed\u0fbc", "\uda82\udc94\udb29\udd45\u1fad\000\ud912\ude8e\udb72\udfb8",
        25, 26946, -72225498, 3998335045910834037L, -25149L, false, true, (char) 15193, (char) 18036,
        Double.longBitsToDouble(0x3fecbfc44dea9413L), Double.longBitsToDouble(0x3fefce1e41868b78L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud989\ude9c\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef", "\u521b\u7f76\u1410\u28c1\u15c4\u0327\uaafb\u923b\u052b\u419a\ua6ed\u7808\u8459\ua2a8\u2795\u02f3", "\ud86f\udd5b\udbf6\udc3c\ud920\udc4d\uda56\udd98\ud928\ude5c\ud93f\ude9d\ud91b\ude6f\udafd\udff5\udb62\udc40\u6223\udb11\udf87\ud8d0\udcaa\ud846\udd82\uda1c\uddce\ud93a\udc86\ud8d2\udeca",
        19, 14129, 689709482, 87135886109869697L, -50701L, false, true, (char) 15055, (char) 30445,
        Double.longBitsToDouble(0x3fe809036bfa7476L), Double.longBitsToDouble(0x3fbd7ff9ffa4e190L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 3, 2, "", "", "\udbe5\udeb1",
        46, 44739, 799524896, -5783160043876944648L, -100000L, false, false, (char) 0, (char) 44525,
        Double.longBitsToDouble(0x3f4c4ae80b8a3c00L), Double.longBitsToDouble(0x3fe682e6acdd29cbL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 2, 1, 3, "\ud912\udd08\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef\ud8b6\udc48\uda8a\udf51\ud88e\udfe4\ud8b8\uddda\ud895\udd74\udbc5\udfe2\ubdf2\udafd\udcd1\ud8e8\udd0e\udb78\udd98\udb6f\uddc8\uda20\udf01\udb6c\udc15\ud9f9\udf7a\uda29\udd46\ud9b1\udec9\udaa7\ude1d\ud93e\udca7\udbf8\udfba\ud9e7\udd79\udbec\udeb9\ud9a0\udd4d\ud920\udc4d\uda56\udd98\ud928\ude5c\udad2\udc65\udb11\udfeb\ud9c0\udef0\udb62\udc40\u6223\uda3c\udd9b\ud8d0\udcaa\ud846\udd82\uda1c\uddce\ud941\ude4a\ud971\uddaa\uda6f\udcab\ud9cd\udecd\ud8a3\udc16\ud8ca\uddb2\ud9ab\udd44\ud9b4\uddca\ud96b\udca8\uda02\udf15\u0228\udbaa\udf13\ud86a\udc1e\u083d\u5e04\udb65\uddd9\uda6b\udc3b\udaea\udf9e\ud930\uddab\ud80a\ude74\udb20\udc2b\udb61\udd34\uda16\udd5d\uda53\udf0b\u34cd\ud962\udd32\uda7d\udee8\u19ee\u5eeb\ud8a7\udcde\uda60\udffe\uda0b\udee9\ud971\udc74\udb22\udd1e\ud8d8\udced\ud80f\ude7b\ud829\ude4f\ud935\udd7f\ud930\udd8a\ud847\udcbe\udba7\ude94\ud8d3\udfd4\ud998\udd17\ud9c6\udc12\ud840\udcf0\ud97e\udca8\udac0\udeb1\ud83d\ude95\ud83d\ude17\udbd4\ude6a\ud86b\udef9\udbee\udeb4\udaaf\uddef\udb87\udf9a\ud9c9\udc63\udac9\udc77\uda28\udd03\udb7f\udf93", "\u78b6\u44c8\u553e\u8bf0\u3305\u9b82\u55c7\ubc4d\u8bd1\u637e\uaa2f\ua4cc\ud7b6\uc18a\ub000\u3787\uc26c\u590b\uc2ff\uc8a0\u40f2\u4e0a\uba9b\u64e0\ud72e\u7bb2\u9634\u8e13\u52be\u7a95\ucd63\ucdc4\u74ec\ua7f8\u0a01\u928d\uc673", "\ud9d3\ude5a\udb37\udce2\ud906\udc79\ud8fe\uded2\ud867\udc0d\ud9b9\ude32\udb90\udf65\ud955\ude59\ud967\udc49\ud954\udfb7\uda6c\udd4e\udbe3\ude5f\ud965\udf6e",
        20, -523, -573076360, 6755841643320676362L, -79295L, false, false, (char) 24361, (char) 25459,
        Double.longBitsToDouble(0x3fe0fd73cbf0bf5bL), Double.longBitsToDouble(0x3fe67b8be0d11022L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 1, 1, 0, "\ud989\ude9c", "\ud4e8\uc003\ua065\u07df\u521b", "\ud9ef\udf97\ubde2\ud9c8\ude9f\ud8df\udf18\ud8a9\udce3\udabc\udf41\uda3b\udc94\uc6d9\ud9f9\udf7a\uda29\udd46\ud906\udea1\u2a3f\ud925\udf11\udb8a\udcc4\ud9f4\udcd8\ud86f\udd5b\ud98e\udd88\ud920\udc4d\udb47\udc07\ud858\udef5\ud93f\ude9d\ud937\udcdd\udafd\udff5\ud9ec\uddb0\u62d4\udb98\udc93\ud8dd\uddb7",
        48, 90301, 944534265, 5303561766331507065L, -60634L, false, false, (char) 26865, (char) 62101,
        Double.longBitsToDouble(0x3f8ac51496063bc0L), Double.longBitsToDouble(0x3fecc316d6dda42fL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 2, 1, 3, "\ud912\udd08\uda98\udded\udb7c\udc30\udb00\udcfe\ud8e2\udcef\ud9d3\ude96\uda8a\ude70\ud88e\udfe4\ud8b8\uddda\ud895\udd74\udbc5\udfe2\ubdf2\udafd\udcd1\ud8e8\udd0e\udb78\udd98\udb6f\uddc8\uda20\udf01\udb6c\udc15\ud9f9\udf7a\uda29\udd46\ud9b1\udec9\udaa7\ude1d\ud93e\udca7\udbf8\udfba\ud9e7\udd79\udbec\udeb9\ud9a0\udd4d\ud920\udc4d\uda56\udd98\ud928\ude5c\ud9a3\udc0f\udb12\udc0d\ud9c0\udef0\ud9a2\uddb7\ud80f\ude00\uda3c\udd9b\uda5b\ude30\uda67\udfbf\uda1c\uddaf\ud941\ude4a\ud971\uddaa\uda6f\udcab\ud9cd\udecd\ud8a3\udc16\ud8ca\uddb2\ud9ab\udd44\ud9b4\uddca\ud96b\udca8\uda02\udf15\u0228\udbaa\udf13\ud86a\udc1e\u083d\ud832\ude52\ud85a\udc61\u4809\udaea\udf9e\ud9d2\udc3d\ud844\udf9f\udb20\udc6e\udb61\udd34\uda16\udd5d\uda53\udf0b\u34cd\ud962\udd32\uda7d\udee8\u19ee\u5eeb\ud8a7\udcde\uda60\udffe\uda0b\udee9\u6978\udb22\udd1e\ud8d8\udced\ud80f\ude7b\ud829\ude4f\ud935\udd7f\ud930\udd8a\ud847\udcbe\udba7\ude94\ud8d3\udfd4\ud998\udd17\ud9c6\udc12\ud840\udcf0\ud97e\udca8\udac0\udeb1\ud83d\ude95\ud83d\ude17\udbd4\ude6a\ud86b\udef9\udbee\udeb4\udaaf\uddef\udb87\udf9a\ud9c9\udc63\udac9\udc77\uda28\udd03\udb7f\udf93", "\u78b6\u44c8\u553e\uc6e5\u486b\u8983\u312c\ubc4d\u8bd1\u637e\uaa2f\ua4cc\ud7b6\uc18a\ub000\u3787\uc26c\u590b\uc2ff\uc8a0", "\udace\udca2\ud8dd\uddb1\udbe6\udd04\udb03\udd2d\ud8e7\uddbf\uda93\udf33\udae3\udd3a\ud902\udfdc\udbd2\udc64\ue231\ud9f5\udc25\udab9\udf68\ud8ba\ude08\ud8f5\udeac\udb15\udc05\ud820\udc2f\ud99a\udde7\ud9d3\ude5a\udb37\udce2\ud906\udc79\ud8fe\uded2\ud867\udc0d\ud9b9\ude32\udb90\udf65\ud955\ude59\ud967\udc49\ud954\udfb7\uda6c\udd4e\udbb8\udf5f\ud965\udf6e\ud8c1\udefa\ud94a\udf82\uda9c\ude74\ud9b3\udfb4\ud814\udfa1\ud9ae\uded2\udbfc\ude94",
        26, 49583, -1418440012, -7421171647350453647L, -62927L, true, true, (char) 11380, (char) 53365,
        Double.longBitsToDouble(0x3fc7093c37421ed8L), Double.longBitsToDouble(0x3fef2cdaf51cda17L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 2, 1, 3, "\ud912\udd08\uda98\udded\udb7c\udc30\udb00\udd64\ud8e2\udcef\ud9d3\ude96\uda8a\ude70\udb33\uddd3\ud8b8\uddda\ud895\udd74\udbc5\udfe2\ubdf2\udafd\udcd1\ud8e8\udd0e\udb78\udd98\udb6f\uddc8\uda20\udf01\udb6c\udc15\ud9f9\udf7a\uda29\udd46\ud9b1\udec9\udaa7\ude1d\ud93e\udca7\udbf8\udfba\ud9e7\udd79\udbec\udeb9\ud9a0\udd4d\ud821\udcff\uda56\uddd5\ud928\ude5c\ud9a3\udc0f\udb12\udc0d\ud9c0\udef0\ud9a2\uddb7\ud80f\ude00\uda3c\udd9b\uda5b\ude30\uda67\udfbf\uda1c\uddaf\ud941\ude4a\ud971\uddaa\uda6f\udcab\ud9cd\udecd\ud8a3\udc16\ud8ca\uddb2\ud9ab\udd44\ud9b4\uddca\ud96b\udca8\uda02\udf15\u0228\udbaa\udf13\ud86a\udc1e\u083d\ud832\ude52\ud85a\udc61\u4809\udaea\udf9e\ud9d2\udc3d\ud844\udf9f\udb57\udde9\ud8ce\udf57\uda16\udd5d\uda53\udf0b\u34cd\ud962\udd32\uda7d\udee8\uda19\ude37\ud94f\ude7d\ud8d3\udf74\uda60\udffe\uda0b\udee9\u6978\udb22\udd1e\ud8d8\udced\ud80f\ude7b\ud829\ude4f\ud935\udd7f\ud930\udd8a\ud847\udcbe\udba7\ude94\ud8d3\udfd4\ud998\udd17\ud9c6\udc12\ud840\udcf0\ud97e\udca8\udac0\udeb1\ud83d\ude95\ud83d\ude17\udbd4\ude6a\ud86b\udef9\udbee\udeb4\udaaf\uddef\udb87\udf9a\ud9c9\udc63\udac9\udc77\uda28\udd03\udb7f\udf93", "\u78b6\u834d\u553e\uc6e5\u486b\u8983\u312c\ubc4d\u8bd1\u637e\uaa2f\ua4cc\ud7b6\uc18a\ub000\u3787\uc26c\u590b\uc2ff\uc8a0", "\udace\udca2\ud8dd\uddb1\udbe6\udd04\udb03\udd2d\ud8e7\uddbf\uda93\udf33\ud9c0\udcf3\ud8c1\ude6a\uda8c\udd10\ud89b\uded2\ud9f5\udc25\udab9\udf68\ud8ba\ude08\ud8f5\udeac\udb15\udc05\ud820\udc2f\ud99a\udde7\uda17\udcdd\udb39\udd16\ud906\udc79\ud8fe\uded2\ud867\udc0d\ud9b9\ude32\udb90\udf65\ud955\ude59\ud967\udc49\ud954\udfb7\uda6c\udd4e\udbb8\udf5f\ud965\udf6e\udb3d\udef8\ud94a\udf82\ud954\ude70\ud9b3\udfb4\udbdf\udeac\ud9ae\uded2\udbfc\ude94",
        26, 49583, -1418440012, -7421350867745781135L, -62927L, true, true, (char) 11380, (char) 53365,
        Double.longBitsToDouble(0x3fc7093c37421ed8L), Double.longBitsToDouble(0x3fef2cdaf51cda17L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 3, 4, "\ud989\ude9c\udb1c\udf4f\ud929\udf74\udb86\udd01\ud8e2\udcef\ub948\udaa7\udf40\uda5e\udf61\ud8b8\udd7d\ue766", "\u03a3\ua22b\u923b\u052b\ud088\u47da", "\udada\udc8f",
        27, 6469, -191702648, -8261398510693915265L, 44869L, true, true, (char) 59571, (char) 8471,
        Double.longBitsToDouble(0x3fd477d68ebba65aL), Double.longBitsToDouble(0x3fe81d46b7dedd56L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.language.Caverphone|caverphone|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|encode|java.lang.Object|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|encode|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|isCaverphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "C|org.apache.commons.codec.language.Caverphone|<init>|",
    "M|org.apache.commons.codec.language.Caverphone|caverphone|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
