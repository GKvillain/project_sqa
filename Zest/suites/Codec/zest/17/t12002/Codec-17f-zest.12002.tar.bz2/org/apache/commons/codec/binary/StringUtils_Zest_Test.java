package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9 |a0=[B:[[-17, -39]]\012",
        Z.run(T, 1, 0, 8, 15, "\ud81f\ude09", "\u7f0a", "\uda5d\udd3f\ud915\ude01\udb0f\udfe3\ud828\udf50\udb83\udd0d\ud91b\ude9d",
        31, 76681, 267767060, -56271171761955832L, -86273L, true, false, (char) 62090, (char) 13255,
        Double.longBitsToDouble(0x3fee1410b02ffee8L), Double.longBitsToDouble(0x3fe8896ddb437499L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\u00baL |a0=[B:[[-70, 76]]\012",
        Z.run(T, 1, 0, 8, 15, "\udbea\ude7c", "\u7f0a", "\ud84b\udd1b\ud944\udcd4\ud97e\udd1c\ud93a\uddbf\ud81c\ude42\udb85\udd42",
        59, 34631, -1342845484, 4340571791884842004L, -86273L, true, false, (char) 35427, (char) 3137,
        Double.longBitsToDouble(0x3fee1410b02ffee8L), Double.longBitsToDouble(0x3fe8896ddd005299L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9 |a0=[B:[[-17, -39]]\012",
        Z.run(T, 1, 0, 8, 15, "\ud81f\ude09", "\u7f0a", "\udbba\udda2\udb80\udd3d\udb0f\udfe3\ud828\udf50\udb83\udd0d\ud91b\ude9d\uda50\uddbf\ud9ee\ude63\udb15\ude04\ud8af\udd9f\ud96a\udde9\uda16\uded2",
        14, 62559, 567621157, -9073044668229865534L, 9329L, true, true, (char) 11459, (char) 29784,
        Double.longBitsToDouble(0x3f83c61b05a12940L), Double.longBitsToDouble(0x3fb53945614dbe60L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9 |a0=[B:[[-17, -39]]\012",
        Z.run(T, 1, 0, 8, 15, "\ud81f\ude09", "\u7f0a\u81ba\u936f", "\udb0f\udfe3\ud828\udf50",
        23, 95943, 146350396, 967255331752115652L, -86273L, true, false, (char) 62090, (char) 13255,
        Double.longBitsToDouble(0x3fee1410b02ffee8L), Double.longBitsToDouble(0x3fe8896ddb437499L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9\u00f9\u00a8\u00b4\u0091 |a0=[B:[[-17, -39, -7, -88, -76, -111]]\012",
        Z.run(T, 1, 0, 8, 15, "\ud81f\ude09\ud929\uddd8\udae4\udec1", "\u936f\u6745\u14b4\ub897\u0a38", "\uda50\uddbf\ud9ee\ude63\udb15\ude04\ud8af\udd9f",
        56, 41321, -331888031, -4871207771748092379L, 9329L, true, true, (char) 23581, (char) 32871,
        Double.longBitsToDouble(0x3fd09bf27e43b942L), Double.longBitsToDouble(0x3feaa70fd27b7987L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9 |a0=[B:[[-17, -39]]\012",
        Z.run(T, 1, 0, 8, 15, "\ud81f\ude09", "\u7e94\u1e76\u936f\u6745\u14b4\ub897\u0a38\u58cd\u0319\u9b92\ub181\u6ffe\u0cbe\u4967\u5aec\ubaee\uae37\u463e\u1cb6\u4e76\u0e63\u0543\u4f46\ud099\ubd4a\ud46f", "\ud888\udd40\uda43\udd8d\udb66\ude40\ud985\ude29",
        33, 18289, 1573640751, -2651902035754207399L, -48888L, true, false, (char) 47705, (char) 22835,
        Double.longBitsToDouble(0x3fc818d4057a9348L), Double.longBitsToDouble(0x3f9dff68237e8ea0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 8, 15, "", "\u5ffb", "",
        45, 41598, 0, -1684670208L, -68000L, false, true, (char) 27218, (char) 52607,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e330ee498000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9\u00d9\u0097]'\u0082\u0086 |a0=[B:[[-17, -39, -39, -105, 93, 39, -126, -122]]\012",
        Z.run(T, 1, 0, 8, 15, "\ud81f\ude09\ud809\udfc7\udb8d\ude57\udab2\udfb6\ud90c\udeda\udb5c\udfb6\ud969\udeab", "\u0a38\u58cd\u0319\u5ba9\ub181\u6ffe\u0cbe\u4967\u5aec\ubaee\uae37\u463e\u1cb6\u4e76\u0e63\u0543\u0570\ubc31\u4055\u4aa5\u379e\u5424\u165f\ub80a\u5318\ube33\u9e9e\u9ba9\u91e0\ua4f0\u7add\u0604\uaab7", "\uda19\ude7c\ud94e\udfcf\ud98e\uddbc\ud95a\udff2",
        48, 94750, -32154399, -231253465297847402L, 78932L, false, true, (char) 39317, (char) 46261,
        Double.longBitsToDouble(0x3fdb77a9a35a85ecL), Double.longBitsToDouble(0x3fe1d630049e2f60L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[B:[[-16, -105, -72, -119, -15, -102, -105, -104, -13, -119, -117, -127]]\012",
        Z.run(T, 1, 11, 8, 15, "\ud81f\ude09\ud929\uddd8\udae4\udec1", "\u936f\u1d1f\u14b4\ub897\u0a38\u58cd\u0319\u9b92\ub181\u6ffe\uadd1\u4967\u5aec\ubaee\uae37\u463e\u1cb6\u4e76\u0e63\u0543", "\ud8a7\udddb\u62c5",
        24, 40921, -1432004906, 9183350208049250158L, 26982L, false, false, (char) 763, (char) 51916,
        Double.longBitsToDouble(0x3fd9d7b2df0b687cL), Double.longBitsToDouble(0x3fe6aecd390a5957L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=4 cap=4]\012",
        Z.run(T, 1, 3, 2, 15, "\ud81f\ude09", "\u7f0a", "\uda5d\udd3f\ud915\ude01\udb0f\udfe3\ud828\udf50\udb83\udd0d\ud91b\ude9d",
        31, 76681, 267767060, -56271171761955832L, -86273L, true, false, (char) 62090, (char) 13255,
        Double.longBitsToDouble(0x3fee1410b02ffee8L), Double.longBitsToDouble(0x3fe88fdec3437499L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\031 |a0=[B:[[25]]\012",
        Z.run(T, 1, 0, 8, 15, "I", "\u7f0a", "\uda5d\udd3f\ud915\ude01\udb0f\udfe3\ud828\udf50\ucf5a\ud91b\ude9d",
        31, 76681, 267767060, -56271171761955832L, 82747L, false, true, (char) 45528, (char) 65303,
        Double.longBitsToDouble(0x3f912dbb68600000L), Double.longBitsToDouble(0x3fe20c34d39e046cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 8, 15, "\ud81f\ude09\ud929\uddd8", "\u2a2d\ub0b3\u0a81\u2bf0\u7431\u1ef6\u22b2\u6029\u9b92\ub181", "\ud891\udf27\uda16\uded2\uda1e\udd36\ud848\ude5b\ud85b\udd31\ud96c\ude57\ud9eb\udfb1\udbd2\udee0\ud82c\uddf0\ud8f9\udc91\udb16\udd82\u4ae1\ud802\udc9a",
        25, 84836, -1358983178, 3201943334929527065L, 49739L, true, true, (char) 61005, (char) 6178,
        Double.longBitsToDouble(0x3fde1d913678ba42L), Double.longBitsToDouble(0x3fe23deb76b8eb8cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[B:[[48, -37, -111, -36, 41, -39, -40, -35, -28, -38, -63, -34, -62, -38, 126, -35, 12, -39, -38, -34, 92, -37, -74, -33, 93, -38, 63, -35, 21, -39, 1, -34]]\012",
        Z.run(T, 1, 10, 8, 15, "\udb30\udc91\ud929\uddd8\udae4\udec1\udac2\udd7e\ud90c\udeda\udb5c\udfb6\uda5d\udd3f\ud915\ude01", "\u58cd", "\ud9ee\ude63\udb15\ude04\ud8af\udd9f\ud96a\udde9\uda16\uded2\udbdd\ude16\ud901\udf5d\uda7a\udca7\ud96c\ude86\ud9eb\udfb1\udbd2\udee0\ud82c\uddf0\ud897\udd01\uda3e\udc17\ud9f9\ude48\uda1c\ude9b",
        47, 42068, 1747684314, 7011279077410639334L, 46460L, true, false, (char) 58280, (char) 62860,
        Double.longBitsToDouble(0x3f8e738b44fc7900L), Double.longBitsToDouble(0x3fc6c58e720972c8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 8, 15, "\uda99\udcbd", "\u7f0a", "\udb23\udc02\uda9b\udcb3\udb0f\udfe3\ud828\udf50\udb83\udd0d\ud91b\ude9d",
        52, 76681, 267767060, -56271171761955832L, 1180L, false, false, (char) 63325, (char) 14223,
        Double.longBitsToDouble(0x3fef9e14902ffee8L), Double.longBitsToDouble(0x3fe88f6feb437499L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -40, 46, -33, 9]]\012",
        Z.run(T, 1, 8, 8, 15, "\ud82e\udf09", "\u7f0a", "\uda5d\uddc9\ud955\ude39\udafb\udee9\ud828\udf50\udb83\udd0d\ud986\udd8f",
        11, 96937, -2095029871, -56268307018769400L, -86273L, true, false, (char) 26762, (char) 13255,
        Double.longBitsToDouble(0x3fee1410b0836ae8L), Double.longBitsToDouble(0x3fe8896ddb437499L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 14, 8, 5, "\ud81f\ude09", "\u7f0a", "\udb31\udf3d\ud915\ude01\udb7b\udcb8\ud978\ude64\ud90f\udeae\udbbf\udea3",
        45, 27283, 267767042, -56271171761955832L, 82747L, false, true, (char) 43401, (char) 46871,
        Double.longBitsToDouble(0x3fe88f8ddb437499L), Double.longBitsToDouble(0x3fe273dd6a9e1b56L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\ufffd\ufffd |a0=[B:[[-17, -39]]\012",
        Z.run(T, 1, 15, 1, 6, "\ud81f\ude09", "\u842d", "\ud808\ude4f\ud97a\udc13\uda39\udc0a\ud864\ude69\ud8c3\ude95\ud93a\udfc3\udbdb\ude25\udad6\uded9\ud967\udec5\ud961\udf18\ud8ce\udcb7\ud87d\udf03\uda1e\udd36\ud848\ude5b\udb6b\udf13",
        52, 43072, 235142447, -1687031467254846443L, -23013L, false, false, (char) 54005, (char) 38733,
        Double.longBitsToDouble(0x3fe9197fdc2164f1L), Double.longBitsToDouble(0x3fe6c54f27dafb63L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\013\u00d9 |a0=[B:[[11, -39]]\0121=[B:[[-2, -1, -40, 59, -34, 9]]\012",
        Z.run(T, 2, 0, 8, 15, "\ud83b\ude09", "\u7f0a", "\uda5d\udd3f\ud915\ude01\udb0f\udfe3\ud828\udf50\udb83\udd0d\ud91b\ude9d",
        31, 76681, 267767060, -56271171761955832L, -86273L, true, false, (char) 62090, (char) 13255,
        Double.longBitsToDouble(0x3fee1410b02ffee8L), Double.longBitsToDouble(0x3fe8896ddb437499L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:\031 |a0=[B:[[25]]\012",
        Z.run(T, 1, 0, 8, 15, "\u7349", "\u7f0a", "\uda5d\udd3f",
        10, 14815, -1684670149, -783857569570849409L, -75015L, false, false, (char) 5547, (char) 39744,
        Double.longBitsToDouble(0x3fcd20010987724cL), Double.longBitsToDouble(0x3fe2bf61be25bc65L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[B:[[-40, 31, -34, 9]]\012",
        Z.run(T, 1, 9, 0, 15, "\ud81f\ude09", "\u9e25", "\uda5d\udd3f\ud805\udc79\ud9be\udf42\ud847\udcf7\udb93\udf06\ud9a1\udcfe",
        15, 43089, 826825211, -56039617190126584L, -86273L, true, true, (char) 21656, (char) 56165,
        Double.longBitsToDouble(0x3fd2744c4173b59eL), Double.longBitsToDouble(0x3fe8896ddf437499L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 1, 5, 13, 10, "\ud992\udec2\ud929\uddf6\udae4\udec1\udac2\udd7e\ud908\udf4b\udb5c\udfb6\uda5d\udd3f\ud915\ude01\udb8b\udfe1\ud828\udf50\uda09\udcaf\ud964\ude09", "\u97a7\u0d0b\u81c2\ub912\u85dd\u0326\u6cda\u1cb6\u4e76\ub694\u0543", "\udbd4\udfc3\ud9d5\udfa0",
        27, 8655, 1595284998, 8103891640273927110L, 52088L, false, false, (char) 42935, (char) 9429,
        Double.longBitsToDouble(0x3fd6d7d624a5768eL), Double.longBitsToDouble(0x3fe7c3b0e5176de9L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 14, 15, "\ud81f\ude09", "\u7f0a", "\uda5d\udd3f\ud915\ude01\udb0f\udfe3\ud828\udf50\udbc8\udf4f",
        28, 42348, 225206681, 7563176635008554281L, -37769L, true, false, (char) 60046, (char) 62090,
        Double.longBitsToDouble(0x3fdf221d5f85042cL), Double.longBitsToDouble(0x3fa7ff743112dbb0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[B:[[63]]\012",
        Z.run(T, 1, 7, 10, 15, "\ud81f\ude09", "\u7f0a", "\uda5d\udd3f\ud90d\ude01\udbcb\udf41\udb55\udfe7\uda10\udfa3\ud919\udd90",
        52, 76681, 267767060, -56271171761955832L, -86273L, true, false, (char) 62090, (char) 13255,
        Double.longBitsToDouble(0x3fe80650b08079e8L), Double.longBitsToDouble(0x3fe8896ddb437499L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 8, 15, "\u76da", "\u1b46", "\uda7c\udd3f\u0347\udafc\udd6c\ufbdb\udb0d\udd1c\ud91b\udefd\ud88b\udc07\ud9ee\uddf5\udaf9\udd7c\ud9ac\udddd",
        36, 17759, 1555852641, -1479434302384108341L, 43571L, true, false, (char) 55499, (char) 57308,
        Double.longBitsToDouble(0x3fe58e99209df3fbL), Double.longBitsToDouble(0x3fd6cfd1af94a2bcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\004\u00a6 |a0=[B:[[4, -90]]\012",
        Z.run(T, 1, 0, 8, 8, "\ud834\uded6", "\u1f0a\u1e76\u936f\uace6", "\ud8f8\udd44\udb27\udd03\udb70\ude53\uda50\udd86\ud9ee\ude63\udb15\ude04\udb6b\udebd\udb2f\udc06\uda16\udcd2\uda1e\udd36\ud848\ude5b\ud98c\udc23\ud96c\ude86\ud9eb\udfb1\udbd2\udee0\ud82c\uddf0\uda14\udc3f\uda28\udd38\ud94a\udd57\ud834\udecf\ud867\udc5d\ud836\udc0d\uda1f\ude3e\udb22\udc6a\ud9c6\udd34\udb50\udfa2\ud94f\ude24\udb15\udf78\ud812\udf5b\uda2c\udec7\ud85e\ude33\ud8d9\udecb\ud812\udc63\ud982\uddf8\uda32\udda6\udb06\udc3d\ud817\uddd1\udb0a\ude80",
        5, 94949, -438125537, -2956410788989118769L, -25053L, true, true, (char) 38282, (char) 1692,
        Double.longBitsToDouble(0x3fe066765ac96de8L), Double.longBitsToDouble(0x3fe5e09dbdeeadf7L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 6, 5, 11, "\ud81f\ude09", "\u7f0a\u1e76\u936f\u6745", "\ud828\udf50\u9bc3\ud955\ude0d\udbf5\udf20\ud06f\udb15\ude04\ud802\udd0f\ud96a\ude57",
        26, 97969, 953242172, 8737000867172352248L, -64463L, true, true, (char) 57308, (char) 61895,
        Double.longBitsToDouble(0x3fe8d50fc05629f1L), Double.longBitsToDouble(0x3fee9c3494244428L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\u00d0 |a0=[B:[[-48]]\012",
        Z.run(T, 1, 0, 0, 15, "\000", "", "",
        -5, -1000, -1694498577, -2017612634756417221L, -1055L, false, true, (char) 185, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcd3b800987724cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 1, 3, 15, "\ud81f\ude09", "\u6f0c\u1e76\u936f\ub06a\u22be\ub85b\u0a38\u9a48\u0319", "\udb15\ude04",
        2, 58456, -594342679, -1425639555236233641L, 50797L, false, true, (char) 1975, (char) 55499,
        Double.longBitsToDouble(0x3fb0dd26714ab848L), Double.longBitsToDouble(0x3fcf40e22f2c6ad8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 8, 8, 15, "\ud81f\ude09", "\u7f0a\u1e76\u936f\u6745\u14b4\ub897\u0a38\u58cd\u0318\u9d0d\u5ee9\u6ffe\u0cbe\u4967\u5aec\ubaee\uae37\u463e\u1cb6\u4e76\u0e63\u0543\ua59b\u512a\u2a48\u5507\u38ce\u04e2\ubfb1\uadc6\u2868\ud1fc\uc729\uc2fb\u8980\u98f2\u2955\ud21f\ua720\u61ee\u4c0b\u38ed\uc3ad\u4284\u4cdd\ua365\u9b10\u1c3e\u1f57\u69b8\u0b12\uc7a4\ucaa1\uc279\u07ed\u35e8\u48ad\ua493\uc8ad", "\uda62\udf7f\ud879\udc0d\u24e2\uf3b7\uda82\udcd7\ud8bf\udfb7\uda6d\udc12\udb20\udf81\ud944\ude23\u11da\udb6e\uddb7\udad9\udd09\ud9c5\ude5e\ud84a\udfcf\ud917\ude25\udb00\uddfa\uda09\udc03",
        22, 73211, 1527090656, 814989896891664754L, 19488L, false, true, (char) 39976, (char) 24446,
        Double.longBitsToDouble(0x3feab96279955c0aL), Double.longBitsToDouble(0x3fb3a87b2de9a498L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9 |a0=[B:[[-17, -39]]\0121=java.lang.String:\u00ef\u00d9 |a0=[B:[[-17, -39]]\012",
        Z.run(T, 2, 0, 0, 15, "\ud81f\ude09", "\u8ccb", "\ud933\udf09\ud83b\udd8e\udb0f\udfe3\ud828\udf50\udb83\udd0d\ud91b\ude9d",
        31, 76681, 267767218, -39945623107855417L, -31935L, true, false, (char) 3270, (char) 51324,
        Double.longBitsToDouble(0x3fc27042c305eea4L), Double.longBitsToDouble(0x3fc0010e351113a0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ud81f\ude09: null\012",
        Z.run(T, 1, 12, 15, 3, "\ud81f\ude09", "\u7f0a", "\uda5d\udd3f\ud915\ude01\udb0f\udfe3\ud828\udf50\udb83\udd0d\u4278",
        19, 19170, -237288524, 8593459449581575322L, -86273L, true, true, (char) 62090, (char) 7414,
        Double.longBitsToDouble(0x3fee1416b8a6fee8L), Double.longBitsToDouble(0x3fe8896ddb437499L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -40, -93, -36, 59, -38, 88, -34, -13, -38, -28, -34, -127, -38, -62, -35, 126, -39, 12, -34, -38, -37, 92, -33, -74, -38, 93, -35, 63, -39, 21, -34, 1, -37, 15, -33, 114, -40, 40, -33, 80, -37, -77, -34, 13, -39, 38, -33, -99, -40, -60, -35, -86, -39, 3, -36, -88, -39, -37, -35, -94]]\0121=[B:[[-93, -40, 59, -36, 88, -38, -13, -34, -28, -38, -127, -34, -62, -38, 126, -35, 12, -39, -38, -34, 92, -37, -74, -33, 93, -38, 63, -35, 21, -39, 1, -34, 15, -37, 114, -33, 40, -40, 80, -33, -77, -37, 13, -34, 38, -39, -99, -33, -60, -40, -86, -35, 3, -39, -88, -36, -37, -39, -94, -35]]\012",
        Z.run(T, 2, 8, 10, 1, "\ud8a3\udc3b\uda58\udef3\udae4\ude81\udac2\udd7e\ud90c\udeda\udb5c\udfb6\uda5d\udd3f\ud915\ude01\udb0f\udf72\ud828\udf50\udbb3\ude0d\ud926\udf9d\ud8c4\uddaa\ud903\udca8\ud9db\udda2", "\u5aec\u45e5\ubab4\uca75\u1bde\u4e76\u836c\u3600\u7004\uc365\u4289\u5c76\u4243\u782e\u983b\u44b6", "\udbbc\udd17\udbbf\udc03\ud822\udf56\uda0d\ude1c\ud9f0\ude56\udade\udf69\ud949\uddd4\ud970\udfce\ud912\udf3f\udb8b\udf0f\ud947\ude15\ud944\ude3c\udaae\ude28\uda73\udc2e\uda67\udded\uda7f\uddac\udab1\udf0c\ufb1f\ud8dc\uddb3\udbc7\ude2b\udab5\udd8f\udb9d\uddcf\ud873\udd46\udb2c\udf78\udbb5\udff4\udb1d\udfdb\ud84f\ude4f\udadd\ude9f\udbda\udfe0\ud86a\ude8f\ud98f\udf68\udb05\uddaa\ud835\udfa5\ud948\udf21\ud902\udc90\udabd\udfe3\ud847\udc71\ud935\udf0f\udba8\udd9a",
        41, 24757, -1816562807, -2099226372552765396L, -77897L, false, false, (char) 43192, (char) 47520,
        Double.longBitsToDouble(0x3fbd6268942318e0L), Double.longBitsToDouble(0x3fd027ca090a5facL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 1, 8, 15, "\uda5c\udea6", "\u81b5\u1e76\uc7f2\u6745\u14b4\u046b\u0a38", "\uda50\uddbf\ud9ee\ude63",
        10, 27347, -1844929528, -4007302020603590111L, 82747L, true, true, (char) 45528, (char) 46871,
        Double.longBitsToDouble(0x3fe2a96ddb437499L), Double.longBitsToDouble(0x3fd0664d2146aa24L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[-16, -80, -110, -101]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 5, "\ud881\udc9b", "\u7f0a", "\uda5d\udd3f\ud915\ude01\udb0f\udfe3\udbf5\uddf6\udb7d\udf35\ud933\udda1\uda50\uddbf\uda5d\udc9b\udb15\ude04\udb7e\udc07\udb35\udde8\uda16\uded2\uda1e\udd36\ud848\ude5b\ud9ef\udfbe\ud829\udfd7\ud9a0\udf5f\udbd2\udee0\udb72\udef2\ud89f\udf64",
        30, 4726, -1621731618, 187380927369190038L, 43276L, true, false, (char) 54981, (char) 25294,
        Double.longBitsToDouble(0x3faf3d297987c810L), Double.longBitsToDouble(0x3fe59d2dacaac2e6L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9rCZ\033A\u00e9 |a0=[B:[[-17, -39, 114, 67, 90, 27, 65, -23]]\012",
        Z.run(T, 1, 0, 8, 12, "\ud81f\ude09\udba2\udc73\ud88a\ude4b\udb71\udf19\ud90c\udeda\udb5c\udfb6\uda5d\udd3f\u8afd\udb0f\udfe3\udb19\udd55\udb83\udd0d\ud91b\ude9d\uda50\uddbf\ud9ee\ude63\ud9b5\udc44\udbdd\udf1d\udbfa\udd3e\ud849\udfe4\uda1e\udd36\ud848\ude5b\ud98c\udc23\ud96c\ude86\ud8bf\ude1a\udac8\udef6\ud82c\uddf0\ud814\udc5f\uda68\udc48\uda96\udcc1\udb7a\udfb8\ud806\uddfc\ud936\udfe0\udbb8\ude41\udaf3\ude91\ud816\udef2\udb42\ude92", "\u2b7f\u91f4\u9428\u6e34\u5cc6\u3b07\u1f1c\u606c\u5050\u9ed9\u0ba8\uc8d0\u82df", "\udb76\ude5c\udbba\udc28\ud8dd\udc38\uda07\udf84\uda86\udf84\udb27\ude9f\uda5a\udd1b\ud8fc\udce9\udb82\udf7b\udb2c\udcd3\ud928\udd1a\udb0b\udef1\ud905\udcf9\ud97f\udf8c\udb15\udc2e\ud99b\udd8e\udaad\udc3c\udb26\udfb2\ud8db\udd2c\ud8c7\udf96\ud83d\udca8\uda57\uddd8\ud9ca\udf2a\ud96e\udc15\udb02\udf97\udbca\udf47\uda89\udd8d\udaa0\ude0d\ud9e0\udd8d\ud8fb\ude86\uda95\udc64\udb26\udcf5\u65f4",
        5, 76624, 2001630860, 2484549916500326104L, -52340L, true, true, (char) 34198, (char) 9130,
        Double.longBitsToDouble(0x3fd8b42fa42659e8L), Double.longBitsToDouble(0x3fdb8b4dc71f29fcL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9 |a0=[B:[[-17, -39]]\012",
        Z.run(T, 1, 0, 15, 15, "\ud81f\ude09", "\u8488\ua984\ua0f3\ubaff", "\ud823\udca9\udb83\udd0d\udbb4\ude23\uda39\ude74\ud839\udc66\uda48\udf16\udad8\ude73\ud96a\udde9\ud9c6\ude96\uda20\udd36\ud848\ude5b\ud98c\udcfa\ud96c\ude86\ud9eb\udfb1\udbd2\udee0\ud82c\uddf0\ud871\udded\ud910\uddcf\ud94d\udfee",
        -3, 78088, 1130234024, 7996806127882167322L, -51244L, true, true, (char) 9668, (char) 12577,
        Double.longBitsToDouble(0x3fdbc8ad28b06a7aL), Double.longBitsToDouble(0x3fd28b17504febccL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ud81f\ude09: null\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 12, 14, 15, "\ud81f\ude09", "\u5b2a", "\ud97b\udf34\ud856\ude38\ud898\udc62\ud828\udf50\udb83\udd0d\ud91b\ude9d",
        31, 76681, -2011664309, -8808546152514530230L, -2362L, true, false, (char) 62090, (char) 44230,
        Double.longBitsToDouble(0x3fec9166d480b7a9L), Double.longBitsToDouble(0x3fe88841c3437499L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[B:[[-16, -105, -72, -119, -15, -102, -89, -104, -15, -118, -72, -125, -15, -82, -119, -102, -15, -109, -117, -102, -16, -65, -91, -115, -28, -112, -94, -15, -119, -121, -102, -16, -110, -125, -100, -16, -109, -92, -126, -13, -90, -111, -104, -15, -106, -71, -108, -16, -112, -90, -104, -14, -88, -73, -...\012",
        Z.run(T, 1, 11, 8, 12, "\ud81f\ude09\ud92a\uddd8\ud8eb\ude03\ud978\ude5a\ud90c\udeda\ud8be\udd4d\u4422\ud8e4\uddda\ud808\udcdc\ud80e\udd02\udb59\udc58\ud91b\ude54\ud802\udd98\uda63\udde7\ud9c5\udc2e", "\u5aec\u48e8\u1a0c\u17f7\ud152\u53a9\u0e63\u0543\u8474\u209e\u7d5f\u05e4\u5904\u74b6", "\udbc0\udfa2",
        42, 34485, 166830274, -1806041780774340562L, 77321L, true, false, (char) 53465, (char) 17064,
        Double.longBitsToDouble(0x3fe5e5c3d2a872c6L), Double.longBitsToDouble(0x3fd74705235bb8e0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \uda49\udd7f: null\0121=java.lang.IllegalStateException:java.lang.IllegalStateException: \uda49\udd7f: null\012",
        Z.run(T, 2, 12, 12, 15, "\uda49\udd7f", "\u7f0a\uabba\u936f", "\udb0f\udfe3\ud828\udf50",
        4, 95943, 146350396, 967255331752115652L, -86273L, true, false, (char) 62090, (char) 13255,
        Double.longBitsToDouble(0x3fee1410b02ffee8L), Double.longBitsToDouble(0x3fe8896ddb437499L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 8, 15, "\ud81f\ude09", "\uaef2\u823d\u936f\u6745", "\udbae\udd52\udbab\udf18\uda11\udd7b\ud96b\udca4\ud811\udcf1\udaa5\udd90\ud966\udf26\u959c\uda4c\udc5d\uda1e\udd36\ud848\ude5b\ud98c\udc23\ud96c\ude86\ud9eb\udfb1\udbd2\udee0\ud82c\uddf0\ud863\udc88\ud897\udd3b\udb04\udda8",
        57, 57682, 1355284, -2390751817529621568L, -1614L, true, false, (char) 16892, (char) 15183,
        Double.longBitsToDouble(0x3fd7f750ab93675aL), Double.longBitsToDouble(0x3fb0a3d31cc1ddc0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[B:[[63]]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 6, 14, "\ud81f\ude09", "\u2b92\u81ba\u936f", "\ud859\udff3\uda16\udd27",
        1, 95946, 146350396, 967255331752115652L, -77569L, true, false, (char) 62090, (char) 13255,
        Double.longBitsToDouble(0x3fee1410b02ffee8L), Double.longBitsToDouble(0x3fd042dbb686e8a0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[B:[[-2, -1, 0, 0, -39, 41, -35, 124, -40, -71, -36, 23]]\0121=[B:[[-2, -1, 0, 0, -39, 41, -35, 124, -40, -71, -36, 23]]\012",
        Z.run(T, 2, 8, 8, 5, "\000\ud929\udd7c\ud8b9\udc17", "\u6f67\u3b1c\000\000\ua193", "\uda50\uddbf\ud966\udd9f",
        59, 95367, 26244938, -2564492787521435039L, -62329L, false, true, (char) 12839, (char) 52135,
        Double.longBitsToDouble(0x3fe6f95019c7b6faL), Double.longBitsToDouble(0x3fb99abcad2870c0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 15, "\udaff\udcef\udb28\uddfe\ud801\udd79", "\u938e\u1d1f\u9ac3\ub897\u972d\u63df\u3bfb\ub849", "\ud8e1\uddc6\ud988\uddcd\udbce\udf46\udaa1\udd9b\ud848\ude5b\udbfa\udc5b\udbd0\udd59\ud9eb\udfa9\udbd2\udee0\ud82c\uddf0\u5280",
        -2, 74831, 1675917848, 1469783327401499046L, 43360L, false, true, (char) 59749, (char) 52000,
        Double.longBitsToDouble(0x3fe6240755b5dcc5L), Double.longBitsToDouble(0x3feb214b469fef22L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=4 cap=4]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 15, "\ud81f\ude09", "\u7f0a", "\uda5d\udd3f\ud915\ude01\udb0f\udfe3\ud828\udf50\udb83\udd0d\ud91b\ude9d",
        31, 76681, 267767060, -56271171761955832L, -86273L, true, false, (char) 62090, (char) 13255,
        Double.longBitsToDouble(0x3fee1410b02ffee8L), Double.longBitsToDouble(0x3fe88fdec3437499L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=[B:[[-40, 15, -35, -54, -39, 41, -34, 58, -38, -28, -34, -63, -38, -62, -35, 126, -39, 12, -34, -38, -37, 92, -33, -74, -37, 122, -33, -115, -37, -117, -36, -104, 12, 11, -40, 40, -33, 80, -37, -125, -35, 13, -39, 27, -34, -99, -38, 80, -35, -65, -39, -18, -34, 99, -37, 21, -34, 4, -40, -81, -35, -97, ...\0121=[B:[[-2, -1, -40, 15, -35, -54, -39, 41, -34, 58, -38, -28, -34, -63, -38, -62, -35, 126, -39, 12, -34, -38, -37, 92, -33, -74, -37, 122, -33, -115, -37, -117, -36, -104, 12, 11, -40, 40, -33, 80, -37, -125, -35, 13, -39, 27, -34, -99, -38, 80, -35, -65, -39, -18, -34, 99, -37, 21, -34, 4, -40, -81, -3...\012",
        Z.run(T, 2, 9, 8, 15, "\ud80f\uddca\ud929\ude3a\udae4\udec1\udac2\udd7e\ud90c\udeda\udb5c\udfb6\udb7a\udf8d\udb8b\udc98\u0c0b\ud828\udf50\udb83\udd0d\ud91b\ude9d\uda50\uddbf\ud9ee\ude63\udb15\ude04\ud8af\udd9f\ud96a\udde9\uda16\uded2\udbdd\ude16\ud901\udf5d\uda7a\udca7\ud96c\ude86\udba8\udea4\udb01\udc19\uda7f\ude94\udaa4\udfb4\uda38\udd8d\ud9f9\ude48\uda1c\ude9b\ud90e\udd48", "\u77bf\ud07e", "\ud9fc\udd66\ud99d\udd5b\ud8c3\udf9a\ud883\udf3a\uda65\udfb1\ud9bf\ude2c\u259c\udba8\udd4d\uda33\udc9c",
        11, 50202, 1918255499, -5969194833006831260L, 91899L, false, true, (char) 2600, (char) 46599,
        Double.longBitsToDouble(0x3fe7f91fbbf35f3bL), Double.longBitsToDouble(0x3fd27561df514f8eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=16 cap=16]\0121=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=16 cap=16]\012",
        Z.run(T, 2, 3, 3, 14, "\ud959\udd88\ud929\uddd8\udae4\udec1\uda54\udfc8", "\ub826\u5c42\u8fd4\u94d7\u2c73\u803f\u3b2b\u7737\uaa85\u56b2\ub4f7\u3eb6\ubaee\uae93\u9784", "\ud9a7\ude74\udb1b\udc70",
        58, 32900, -594325447, -8456758062332900456L, -23013L, false, false, (char) 38536, (char) 36334,
        Double.longBitsToDouble(0x3fe91978682164f1L), Double.longBitsToDouble(0x3fe6c68657dafb63L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 1, 4, "\ud81f\ude09\ud929\uddd8", "\ub1c5\u93fe\u49ee\u5c74\u2f89\u8f0d\u6d5d\u803f\u3b2b", "\ud961\udf18",
        27, 95432, -331888031, -4871207772050082267L, -43304L, true, false, (char) 5511, (char) 58218,
        Double.longBitsToDouble(0x3feb9ed1f839210eL), Double.longBitsToDouble(0x3feacee49c97461dL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String:\013\u00e0\u00f9\u00a8\u00b4\u0091\u0092N |a0=[B:[[11, -32, -7, -88, -76, -111, -110, 78]]\0121=java.lang.String:\013\ufffd\ufffd\ufffd\ufffd\ufffd\ufffdN |a0=[B:[[11, -32, -7, -88, -76, -111, -110, 78]]\012",
        Z.run(T, 2, 0, 15, 15, "\ud83b\ude10\ud929\uddd8\udae4\udec1\udac2\udd7e\ud90c\udeda\udb5c\udfb6\udbc6\udeb3", "\u0a38\u58cd\u0319\u9b92\u375d\u21b6\u0cbe\u4967\ud6ec\ubaee\uae37\u85a9\u1cb6\u4e76\u0e63\u0543\u0164\u2c3c\u8661\u3663\u1d9b\u55a8\ubbc0\u9f22\ua289\u5815\u3a91\uc98b\ub9c2\u51eb\u7a63\ud0a3\ub89c\uaf4a\ua9e5\u45f1\u4ab1\u5fd1\u8295\uaccd\u087b\u42ab\uc006\u3968\u240a\u1bdd\u7710\ub380\u37fa\uc978\u25ab\u2715\ud24c\u53df\ub534\u6003\u40ae\u86c1\u903c\u4ad3\u693b\u5456\u7514\u1527\uc5e6\u6188\u3990\u0871", "\ud9b6\udf93\udbde\ude57\u76af\udaa2\udc55\udb43\ude34\ud943\udeed\ud905\udd17\uda8e\ude74\ud84f\ude85\ud982\udeb6\udaf6\udd1d\uda2a\udf62\ud86e\udfc7\udae3\udc6f\ud941\ude68\ud8a2\udf79\udbe1\udf7d\ud81e\udf94\uda42\udc5e\ud8d3\udf8e\udadf\udc7a\ud97b\udc7d\ud9b1\udfa0\uda41\udcab\uda53\ude35\ud9e9\udea0\ud9d1\udd05\udb15\uddb6\ud8b6\uddea\ud895\udc87\ud93f\udebe\ud97c\udc60\udb8e\udca8\ud8be\uddca\uda0c\ude7e\ud8a8\uddee\udac4\udfb9\udad7\uddf9\udadb\udce9\ud9f1\uddd4\udbba\udf72\ud854\udd7e\udb38\udf39\ud815\udf37\udbe9\ude88\ud8d9\uddd5\ud995\udf27",
        25, 92494, 1202229354, 5159267321035368269L, 9657L, true, false, (char) 24412, (char) 24483,
        Double.longBitsToDouble(0x3fd02b1608b7413cL), Double.longBitsToDouble(0x3fb8ea9466304308L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=[B:[[-14, -115, -103, -108]]\0121=[B:[[-14, -115, -103, -108]]\012",
        Z.run(T, 2, 11, 11, 14, "\ud9f5\ude54", "\u898d\ua3ab\u0d55\u21b1\u423d\uba09", "\ud91b\ude4d\uda62\udd0a\ud9ee\ude63\ud8dd\udf89\ud9d2\udfef\udbc5\ude6d",
        40, 97969, 127794775, -7764090244037188571L, 74809L, true, false, (char) 27632, (char) 49335,
        Double.longBitsToDouble(0x3fd0c36439751d88L), Double.longBitsToDouble(0x3feb3d441938aaf7L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 9, 9, 15, "\ud81f\ude05", "\u3b99", "\udb88\udeb9\ud901\udce7\ud971\udd13\udb22\ude6d\udaa7\uddeb",
        28, 99782, 1568630567, -7542545849576909527L, 99814L, true, false, (char) 60046, (char) 43810,
        Double.longBitsToDouble(0x3fe9ba6e33eae82fL), Double.longBitsToDouble(0x3fdf42eb26225b76L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 10, 15, "\ud82a\udfb0\uda9f\udc81\u68f5\ud9ee\ude32\udbe6\udd3e\ud94c\udf55\uda5d\udd3f\ud90d\ude01\udbcb\udf41\udb55\udfe7\uda10\udfa3\ud919\udd90\ud876\udf53\ud9ee\ude63", "\u4967\u5aec\u357b\uae37\u463e\uba0b\u1f7c\u0eb4\u0543\u52f7\u39b9\u1b9d\u43fd\ub2c3\u31a2\ub1fb\u10d1\u1b85\ua9ee\ub7b4\u44f3\uc23d\u5d15\u9678\u45d4\u3cb9\u5b90\u9408\u3257\u7e5b\u3732\ua64f\u25f7\u0420\u3cf7\u1d82\u1c77\u7e5e\ud1cf\u9dc4\u4a05\u7cdc\u439b\u2aed", "\udbe9\udd56\udbcd\udc95\ud9fd\udc19\uda73\udff1\u1e0d\ud4cd\udb05\udd28\ud862\udc71\uda35\udf96\udbb7\udd44\udbbb\udff6\udbfc\udcdf\ud88a\ude0a\ud999\udc3f\ud893\udee6\uda04\udc10",
        54, 88819, 1588608, 22276238874651185L, -13775L, false, false, (char) 19714, (char) 8120,
        Double.longBitsToDouble(0x3fec32d3417ccc6fL), Double.longBitsToDouble(0x3fd02c43724c4138L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 15, "\u76da", "\u1b46", "\uda7c\udd3f\u0347\udafc\udd6c\ufbdb\udb0d\udd1c\ud91b\udefd\ud88b\udc07\ud9ee\uddf5\udaf9\udd7c\ud9ac\udddd",
        36, 17759, 1555852641, -1479434302384108341L, -21965L, false, true, (char) 55499, (char) 57308,
        Double.longBitsToDouble(0x3fe58e99209df3fbL), Double.longBitsToDouble(0x3fd6cfd1af94a2bcL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 15, "\uc40f", "\000", "\uda7c\udd3f\u0347\udafc\udd6c\ufbdb\u00ab\000\ud88b\udc07\000\000\000",
        -5, 17759, 1555852641, -1479434302384108544L, -34464L, true, false, (char) 55499, (char) 57308,
        Double.longBitsToDouble(0x3f4a648000000000L), Double.longBitsToDouble(0x3e4f280000000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String:\021\ufffd\ufffdi\ufffde\ufffd& |a0=[B:[[17, -111, -88, 105, -38, 101, -25, 38]]\0121=java.lang.String:\021\ufffd\ufffdi\ufffde\ufffd& |a0=[B:[[17, -111, -88, 105, -38, 101, -25, 38]]\012",
        Z.run(T, 2, 15, 15, 12, "\ud941\udfc1\udbd8\udf99\ud90a\ude95\udb17\udf56\ud830\udefb\ud9b4\udc0f\ud940\udf45\udbfb\udc74", "\u3bd4\u0379\u2960\u8912\ud775\u7208", "\udb85\udf87\ud895\udf16\udbc1\udec9",
        -1, 2173, 767277127, 8401934668586576707L, -24381L, false, true, (char) 55162, (char) 50013,
        Double.longBitsToDouble(0x3fef2f58e6582a65L), Double.longBitsToDouble(0x3fddb4b14eaec39eL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 14, "\ud959\udd88\ud929\uddd8\udae4\udec1\udb6e\udc5f", "\ub826", "\ud94e\udd3b\ud8ab\udc4a",
        36, 30892, 724063249, 1104000883651789279L, -88088L, true, false, (char) 60138, (char) 2396,
        Double.longBitsToDouble(0x3fe790b3417810bcL), Double.longBitsToDouble(0x3fda17963ba41c06L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 1, 4, "\ud81f\ude09\udb5d\uddd2", "\ub1c5\u1d98\ucf66\u5c74\u1742\u8f0d\u6d5d\u803f\u3b2b", "\000",
        -5, -1000, 0, -4871207772050082267L, -43304L, true, false, (char) 146, (char) 14615,
        Double.longBitsToDouble(0x3f4b47e0e4000000L), Double.longBitsToDouble(0x3feacee49800001dL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=[B:[[63]]\012",
        Z.run(T, 1, 7, 8, 15, "\uda75\udf74", "\u7f0a", "\uda5d\udd3f\ud915\ude01\udb0f\udfe3\ud828\udf50\udb83\udd0d\ud91b\ude9d",
        31, 76681, 267767060, -56271171761955832L, -86273L, true, false, (char) 62090, (char) 13255,
        Double.longBitsToDouble(0x3fee1410b02ffee8L), Double.longBitsToDouble(0x3fe8896ddb437499L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=[B:[[-16, -77, -78, -115, -16, -97, -118, -109, -15, -65, -77, -82, -13, -128, -91, -66, -15, -99, -99, -82, -14, -76, -81, -110, -14, -89, -108, -65, -15, -107, -104, -127, -13, -109, -65, -93, -12, -115, -105, -74, -13, -81, -100, -75, -15, -100, -74, -95, -14, -92, -122, -65, -14, -89, -110, -101, -...\0121=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 2, 11, 7, 5, "\ud88f\udc8d\ud83c\ude93\ud9bf\udcee\udac2\udd7e\ud935\udf6e\uda92\udfd2\uda5d\udd3f\ud915\ude01\udb0f\udfe3\udbf5\uddf6\udb7d\udf35\ud933\udda1\uda50\uddbf\uda5d\udc9b\udb15\ude04\udba6\udc84\udb35\udde8\uda16\uded2\uda1e\udd36\ud848\ude5b\ud9ef\udfbe\ud829\udfd7\udbd8\uddda\udab8\ude48\udb72\udef2\ud89f\udf64\ud9a1\udc02\ud937\udfa1\udab0\udd2b\ud8bd\ude1d\ud8da\udd7f\udbd3\udce4\udb27\udc6d", "\u96d8\u37cf\u4494\u0649\u1471\u7968\uc93d\ua022\u27b5\ub231\uc3a1\u7b4a\u7e07\u32a8\u4fd9\u91b3\u347a\u2949\u1a4c\u3b9a\u6806\u3e57\u4fdf\u2192", "\ud93d\udea3\ud87f\uddb6\ud9a7\udceb\udacd\udf17\ud9c9\udfb2\ud837\udeb3\ud9a9\udc06\u6092\uda66\udf5b\udb45\ude0b\uda34\udee1\ud8fb\udfb8\ud926\uddcf\ud98a\udebe\ud9ed\udc2d\ud965\ude11\uda2a\udf79\ud97f\udf23\ud991\udc21\udafa\ude36\uda33\udf79\udb86\udff8\ud84c\uddb0\udb28\udf69\ud98e\udfa4\ud4d4\ud887\udd70\udbc5\udca1\udb95\udffa\ud86b\udf00\udb84\udc2a\uf908\ud9bb\ude5b\ud947\udfed\ud9cd\uddf1\ud88a\ude42\udaea\udd8c\ud855\udfc7\udabe\udf36\udbeb\udf0f\ud9f2\udf15\uda55\uddfe\udaaa\udfff\uda2e\udd5b\ud94d\udf43\uda6e\udcfb\udb91\udc49\ud9c9\uddca\ud9a1\udc2f\ud8dc\ude06\udb71\udd14\ud9f7\udf3c\udafc\udd6b\uda33\uddd6\ud892\ude0e\ub45f\uda83\udfeb\ud883\udfff\ud81e\udea8\uda00\ude89\udb75\udde0\ud9b1\udcae\u418d\ud9e8\udcff\udafc\udd75\ud952\udc2a\uda6c\uddca\uda14\udc0e\udbd1\udff3\udbec\udc3b\ud8af\udd38\ud8c0\udf06\u4111\uda3d\ude34\uda58\udc85",
        25, 77017, -1761704892, -6703469861932574065L, -22279L, true, true, (char) 5434, (char) 23944,
        Double.longBitsToDouble(0x3fee19641ce8ff41L), Double.longBitsToDouble(0x3fe7503b25273ef0L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63]]\0121=[B:[[63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 2, 5, 5, 12, "\ud845\ude1d\ud927\udece\ud9bf\udcee\udac2\udd7e\uda3f\udcb4\ud9ea\udd6d\uda5d\udd3f", "\u878d\u484a\u447d\u9cff\uc59b\u6ffe\ua44b\u1b99\u4c9e\u1679\uae37\u3dee\u7700\u0a26\u0e63\ua67a\uc650\u77f6\u085d", "\ud8da\udd7f\udbd3\udce4\udb27\udc6d\u32aa\udbe7\udf2f\ud975\udd14\ud96e\udf94\udb2e\ude45\udb84\ude58\ud95e\uddfd\udba1\uddc3\uda0f\udef8\ud82a\udd99\ud841\udc5b\ud930\ude61\udb4a\udfe6\udb10\udc3d\u1b4e",
        11, 26640, 1929549647, -2073391209135361131L, -21930L, true, false, (char) 18046, (char) 40257,
        Double.longBitsToDouble(0x3fe617556e5c350cL), Double.longBitsToDouble(0x3fd656aa970e14ecL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String:\u00ef\u00d9\u00f9\u00a8\u00c4\u00f9t\003 |a0=[B:[[-17, -39, -7, -88, -60, -7, 116, 3]]\012",
        Z.run(T, 1, 0, 8, 15, "\ud81f\ude09\ud929\uddd8\ud9f4\ude29\ud8a4\udf33\uda70\ude19\ud99e\ude41\ud907\udf46\udbe7\udc02\udb0f\udfe3\ud828\udf50\ud8c8\udd0f\ud91b\udeb8\uda50\uddbf\udae0\udfc6\ud8fe\udf90\ud8af\udd9f\ud96a\udde9\uda16\uded2\uda1e\udd36\ud848\ude5b\ue17f\ud96c\uddbd\ud9eb\udfb1\udbdb\udc50\ud82c\uddf0\uda26\udee8\ud8a5\udeb5\u3ac9\ud92c\udc3a\ud8da\udf6c\ud9b2\udf65\ud836\udf1a\udb6a\udfc9\udaf5\ude16\ud828\ude79\ud95e\udcd7\uda4f\udd52\udb7a\udd31\ud89e\udf9c\ud83c\udecb\udaf6\uddb4\udbdb\udfd6\udb85\udc39\udbf4\udc9b\ud933\udc10\udb37\udc75\udbbf\udf63\ud948\udfd9\u02de\udbed\udda0", "\u51a3\u7ff2\ud6fd\u7acb\ub0a7\u0cbd\ua77a\u734e\u0c25\uc54d\u9e99\u17a1\u2d24\u2cb7\ub870\u0697\uc16a\u472b\uae3c\u84b1\ua8ee\u42fb\u2974\u5ba0\u8cff\uc81d\u5503\u80bd\u5c46\ubb43", "\ud919\udfea\ud8ca\udd75\udbf4\udd27\ud929\udf76\uda87\udc60\uda5a\udfaa\ud984\uddc5\u045f\udaac\udd67\udbe9\udef6\uda49\udc44\udbbd\uddda\udbfe\udc23\ud9ff\udd87\udad5\udd9f\ud8a3\udc48\udaaf\ude0b\ud950\udd59\ud83d\udf90\ud991\uddbc\udb44\ude12\ud806\uddac\ud9dd\udd3e\udb43\ude4b\ud849\udd89\udb0c\udf45\ud926\udc5c\ud853\udc51\udada\udf62\udbe1\udcf1\ud8fe\ude30\u52c0\udb00\uddaa\ud92e\udc1e\ud8ec\udc5b\uda94\udeef\ud98f\udd6c\ud8fc\ude11\ud883\ude40\ud958\udf9c\uda0b\udc69\ud943\udffe\ud820\uddbc\ud807\udf0e\udb7a\udf8a\ud9d8\udfaf\ud9c8\udc75\ud81b\ude4c\ud94c\udcc0\ud9b3\udda0\uda42\ude54\uda1a\udcf8\ud943\uddc1\ud862\udd2d\udb56\udccb\udbeb\udfbc\uda5f\udefa\u89cd\uda1c\udd32\udb42\udd26\ud970\udd29\uda8b\udd95\ud8f8\udff5\uda6b\udec8\ud833\udc12\ud980\udc1c\ud928\udcfc\ud905\udfc0\udb79\udfb3\udbe8\udcb8\ud922\udf74\ud83d\udf3a\ud86e\udd09\udaec\udf36\ud9cd\udd10\uda1e\ude62\ud994\udedf\udb8b\udc49\uda92\udf8f\ud814\uded5\udb31\udd4e\udb07\udcc8\udbf1\udd54\ud818\udd02\ud802\udf21\ud8de\ude37\ud933\udf83\udaf2\udd8a\uda24\udfec\uda6d\udc4c\ud805\udf1c\ud9ee\udcc3\ud888\uddfe\ud8c9\ude7d\ud973\udeb8\uda12\udfc5\ud8f9\udef1\udb37\udc95\uda2e\ude25\ud95f\udf7f\ud9e1\udd6e\udabf\ude40\ud815\udfd5\ud61e\ud8dd\udcc0\udbfb\udfe7\ud8c6\udc40\ud907\udf53\udbad\udd42",
        25, 13844, 727202527, -3241560577786231585L, -15814L, false, false, (char) 56771, (char) 37420,
        Double.longBitsToDouble(0x3fd0783126458938L), Double.longBitsToDouble(0x3fd26ed44b4478aaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.StringUtils|newStringIso8859_1|[B|static",
    "M|org.apache.commons.codec.binary.StringUtils|equals|java.lang.CharSequence,java.lang.CharSequence|static",
    "M|org.apache.commons.codec.binary.StringUtils|getByteBuffer|java.lang.String,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|getByteBufferUtf8|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytes|java.lang.String,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesIso8859_1|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUnchecked|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUsAscii|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Be|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Le|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf8|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|newIllegalStateException|java.lang.String,java.io.UnsupportedEncodingException|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|newStringUsAscii|[B|static",
    "M|org.apache.commons.codec.binary.StringUtils|newStringIso8859_1|[B|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
