package org.apache.commons.codec.language.bm;
import org.junit.Test;
import static org.junit.Assert.*;
public class Lang_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 3, "\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\udac3\udc65\uda59\udd24\ud984\udcfb\ud953\udeaf\uda60\udee5\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\ud944\uddad", "\u6930\u5c65\uac54\u45cc\u2f87\uc3ec\ua25c\u1d1b", "\udbf7\udc31\ud990\udf0e",
        26, 44120, -1764011878, -1387648722913107045L, 73378L, true, false, (char) 15600, (char) 57353,
        Double.longBitsToDouble(0x3fd479c1e5ede7a6L), Double.longBitsToDouble(0x3fede326c8e71b90L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 3, "\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\000\000\000\000\udac2\udfc6\uda59\udd24\ud984\udcfb\ud953\udeaf\uda60\udee5\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\ud944\uddad", "\u6930\u5c65\uac54\u45cc\u3728\uc3ec\ua25c\u1d1b", "\udbf7\udc31\ud990\ude1e",
        26, 44120, -1764011878, -1387648722913107045L, 73378L, true, false, (char) 15600, (char) 57353,
        Double.longBitsToDouble(0x3fd479c1e5ede7a6L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 3, "\ud97b\udc6d\ud8f3\udc33", "\u89e4\ub460\u419c\u6fdb\u07a2\u4372\u6de6", "\ud953\udeaf\uda60\udee5\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\ud944\uddad\ud9d9\udcd7\udb72\udc80\udb46\udd1b\udb53\ude98\ud9db\udd8c\ud93c\ude3e\ud808\udcc4\ud9c6\udec4\ud90e\udc57\uda12\udc90\uda35\udcda\udb77\udfca\udbf7\udc31\ud990\udf0e\ud828\udd62\udbf8\udd7b\ud85b\uddda\udb5a\uddff\u0464\ud9b2\udc4c\udb7e\udc71\u8cb0\uda52\udeb7\ud87a\ude0f\ud91c\udc8f\ud9d4\udce7\udb64\udd5b\ud917\udc10\ud9ae\udd81\udadb\udd8a\udb9a\ude63\uda6e\udd23\uda07\udc83\udb15\udf85\uda5f\udc5f\ud826\ude02\udbdb\udfb1\ud8a7\udd3f\udb1d\udef3\ud94f\udfb6\udb6a\udc94\udbf7\udead\udbb8\ude5e",
        13, 16385, 281374400, -2940924428591956892L, 25643L, false, false, (char) 48080, (char) 39724,
        Double.longBitsToDouble(0x3feb6d67f8dfc66cL), Double.longBitsToDouble(0x3fddf702fcb0f60aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 4, "\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd", "\u6fdb\u07a2\u6783\uc8b3\u9738\u1936\uba78\u43df\u1fc3\u28b1\u3802\uc9af\u2923\uc8cb\u5e33\u9464\u5bd1\uac54\u45cc\u2f87\uc3ec\ud738\u8a67\u5625\u85e5\u4439\u2a1c\u6807\u778f\u23e6", "\ud9b2\udc4c\ud94a\udc77",
        55, 58073, 675630650, -877312115803285002L, 33351L, true, true, (char) 28690, (char) 13494,
        Double.longBitsToDouble(0x3fd4fd0cce8a1e2eL), Double.longBitsToDouble(0x3fe37bcdf2b78cc0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 3, "\u00ba\ud8e9\udc14\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\u2589\000\000\ud977\udddb\ud953\udeaf\u009d\u3900\udbb4\ude15\u6f37\ud822\udcdf\ud944\uddad", "\u6930\u5c65\uac54\ua3cb\u2f87\uc3ec\u34d7\u1d1b", "\udbf7\udc31\ud97f\udf1e",
        26, 44120, -1764011878, 53503157845451520L, 73378L, true, false, (char) 15600, (char) 57353,
        Double.longBitsToDouble(0x3fd479c1e5ede7a6L), Double.longBitsToDouble(0x3fede32000001b90L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 2, 3, "\ud97b\udc6d\udad4\udcb0\ud90d\udf44\ud9ec\udd84\ud926\uddbd\ud847\udc9a\ud8a0\udfa3\uda6b\udcdd\udbda\uddf4\ud94f\udcb9\udac3\udc65\uda59\udd24\ud80c\uddca\udbcd\ude4c\uda60\udee5\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\ud944\uddad", "\u6930\u5c65\uac54\ube16\u2f87\uc3ec\ua25c\u1d1b", "\u4a66\ud9a2\ude3b\ud828\udd62",
        5, 53234, -323087145, -5927472018194541602L, -15541L, true, false, (char) 36188, (char) 64919,
        Double.longBitsToDouble(0x3fe7b79e9fbc64d9L), Double.longBitsToDouble(0x3fcce3721814541cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 3, "\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud817\udf19\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\udaf1\udce0\ud9ed\ude3e\udbaa\uddd9\udac3\udc65\u8149\ud984\udcfb\ud953\udeaf\uda60\udee5\udaab\udc92\uda88\udea8\u6f37\ud822\udcdf\ud944\uddad", "\u6930\u5c65\uac54\u45cc\u2f87\uc3ec\ua25c\u1d1b", "\ud8dc\udf96\ud990\udf0e",
        26, 44120, -1764011878, -1387648722913107045L, -49514L, false, true, (char) 50533, (char) 44745,
        Double.longBitsToDouble(0x3fede326c8e71b90L), Double.longBitsToDouble(0x3fe1d1dba5c0046aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 3, "\ud97b\udc6d", "\u2f68\u89e4\ub460\u4131\u6fdb", "\000",
        9, 78464, 743269395, 675072376832L, -60228L, true, false, (char) 2003, (char) 17726,
        Double.longBitsToDouble(0x3fdcbee33deefa6eL), Double.longBitsToDouble(0x3fde09ca070a1880L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 3, "\ud97b\udc6d\ud917\ude33\udbdd\udea4\ud9ec\udd84\ud9a9\uddf9\ud847\udcf9\ud9c4\ude75\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\ud941\udc64\ud880\ude18\uda8d\udceb\uda0b\uddc1\udbff\udd93\ud963\udf81\udbb4\ude7e\ud88f\udf30\ud822\udcdf\ud944\uddad", "\u345e\u877f", "\ud80d\ude1f\ud9c6\udec4\ud90e\udc57\ud95f\udd95\uda35\udcda\udb77\udfca\udbf7\udc31\ud990\udf0e\udafb\udeeb\udadb\udece\ud81c\udf31\ud9c0\udfb4\udbe5\udec1\ud9bf\udea8\ud94a\udc77\ud8ad\udc93\ud950\udf2d\ud87a\ude0f\ud93d\udcdf\ud9d4\udc27\udb64\udd5b\uda6d\udefc\udab1\udc2d\ud895\udf16\ud976\udc7a\u9ecc\ud872\udd73\uda9c\udeeb\udad9\udf15\ud9ae\uddec\udb42\ude47\ud8dd\udc95\udba4\ude91\udbea\udddd\ud95b\udc69\ud811\udf94\uda72\udd02\udb5b\ude5a\u1d01\ua749\ud8ba\udd6a\u480e\udb03\udf32\udab5\udf25\ud847\udf90\uf3e9\ud8ac\udf7c",
        38, 11771, -1884606184, 7338028127432163415L, -14150L, true, true, (char) 53103, (char) 27300,
        Double.longBitsToDouble(0x3fefdce4dc014f44L), Double.longBitsToDouble(0x3fe391310f607d81L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud953\udeaf\uda60\udee5\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\ud944\uddad\012",
        Z.run(T, 1, 13, 13, 3, "\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud953\udeaf\uda60\udee5\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\ud944\uddad", "\u3030\u5c65\uac54\u45cc\u2f87\u3f8b\ua1f0\u89d9", "\udbf7\udc31\ud990\udf0e",
        26, 44120, -1764011878, -1387648722913107045L, 73378L, true, false, (char) 15600, (char) 57353,
        Double.longBitsToDouble(0x3fe9f918f2b2dedfL), Double.longBitsToDouble(0x3fcd1b1c239c6e40L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 3, "\000", "", "",
        -5, -1000, -1027997696, -6564933667049888375L, 74190L, false, true, (char) 16311, (char) 27370,
        Double.longBitsToDouble(0x3fde5c0f0d125ae6L), Double.longBitsToDouble(0x3feae22aa069b9acL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\ud848\udc01\ud8fd\udfec\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8f5\udc98\uda6c\udc28\ud9ed\ude3e\udbaa\uddd9\udac3\udc65\uda59\udd24\ud984\udcfb\ud953\udeaf\uda6c\udc0e\udaab\udc92\udb39\udde3\ub237\ud822\udcdf\ud944\uddad\012",
        Z.run(T, 1, 13, 12, 8, "\ud848\udc01\ud8fd\udfec\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8f5\udc98\uda6c\udc28\ud9ed\ude3e\udbaa\uddd9\udac3\udc65\uda59\udd24\ud984\udcfb\ud953\udeaf\uda6c\udc0e\udaab\udc92\udb39\udde3\ub237\ud822\udcdf\ud944\uddad", "\u6930\u5c65\uac54\u45cc\u2f87\uc3ec\ua25c\u97fb", "\ud978\udd12\ud98b\udc84",
        13, 44030, 1296266013, 6909399648740975364L, 25423L, true, false, (char) 15600, (char) 57353,
        Double.longBitsToDouble(0x3fd479c1e5ede7a6L), Double.longBitsToDouble(0x3fe9157ec812dcb1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\ud97b\udc6d\ud917\ude33\udb45\udc42\ud9ec\udd84\udade\udf37\uda48\udfe9\ud8a0\udfa3\uda6b\udcdd\ud95a\udf5b\udbc2\uddf4\udac3\udc65\ud82f\udc8f\udb52\udf63\ud926\udcd8\udaa1\udf05\ud8a5\ude6a\ud8b9\udfc5\ud8a4\ude15\udbb1\uddd1\ud944\uddad\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 10, 3, "\ud97b\udc6d\ud917\ude33\udb45\udc42\ud9ec\udd84\udade\udf37\uda48\udfe9\ud8a0\udfa3\uda6b\udcdd\ud95a\udf5b\udbc2\uddf4\udac3\udc65\ud82f\udc8f\udb52\udf63\ud926\udcd8\udaa1\udf05\ud8a5\ude6a\ud8b9\udfc5\ud8a4\ude15\udbb1\uddd1\ud944\uddad", "\u393f\u5c77\uac54\u45cc\u0e70\uac83\ubf3b\u1d1b", "\ud8db\udda1\ud990\udf0e\ud828\udd62\ud9d2\udf29\udaee\ude67\ud9c0\udfb4\udbe5\udec1\ud9b2\udc4c",
        38, 59525, -535341927, -7197033739848570553L, -35749L, true, false, (char) 16794, (char) 22994,
        Double.longBitsToDouble(0x3fee04c87eb1a31bL), Double.longBitsToDouble(0x3fe57fd005797933L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\ud9cf\udf32\udb07\ude97\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\udb7b\ude65\ud9ed\ude5d\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud8e8\uddda\uda60\udea3\udaab\udc92\udbb4\ude9e\udbd0\udeb0\ud821\udd22\ud944\uddad\0121=java.lang.String:\ud9cf\udf32\udb07\ude97\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\udb7b\ude65\ud9ed\ude5d\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud8e8\uddda\uda60\udea3\udaab\udc92\udbb4\ude9e\udbd0\udeb0\ud821\udd22\ud944\uddad\012",
        Z.run(T, 2, 13, 13, 3, "\ud9cf\udf32\udb07\ude97\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\udb7b\ude65\ud9ed\ude5d\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud8e8\uddda\uda60\udea3\udaab\udc92\udbb4\ude9e\udbd0\udeb0\ud821\udd22\ud944\uddad", "\u3030\u30da\u31f5\u8ee3\u39ef\u3f8b\ua1f0\u89d9", "\uda5e\udc69\udae2\udc6b",
        26, 54608, 1169084314, -1099169318139782350L, 73378L, true, false, (char) 51622, (char) 46165,
        Double.longBitsToDouble(0x3fd4a1e82565bdbeL), Double.longBitsToDouble(0x3fcd1b1c239c6e40L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\udbc8\udc9e\ud8d3\udc3d\u11d0\ud9ec\udd84\ud9eb\uddfd\ud915\udc13\ud8a0\udfa3\udb7b\ude65\ud81b\udc33\udbaa\ude15\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud8e8\uddda\uda60\udea3\udaab\udc92\udbb4\ude9e\udbd0\udeb0\ud821\udd22\ud97e\udd8b\0121=java.lang.String:\udbc8\udc9e\ud8d3\udc3d\u11d0\ud9ec\udd84\ud9eb\uddfd\ud915\udc13\ud8a0\udfa3\udb7b\ude65\ud81b\udc33\udbaa\ude15\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud8e8\uddda\uda60\udea3\udaab\udc92\udbb4\ude9e\udbd0\udeb0\ud821\udd22\ud97e\udd8b\012",
        Z.run(T, 2, 13, 13, 3, "\udbc8\udc9e\ud8d3\udc3d\u11d0\ud9ec\udd84\ud9eb\uddfd\ud915\udc13\ud8a0\udfa3\udb7b\ude65\ud81b\udc33\udbaa\ude15\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud8e8\uddda\uda60\udea3\udaab\udc92\udbb4\ude9e\udbd0\udeb0\ud821\udd22\ud97e\udd8b", "\u2fdb\u767b\u8169\u8e5c\u39ef\u3f8b\u93b2\u66b4\u0163\u8690\ua9ec\uc170\u2688\u17d2", "\udb7f\uddcd\ud9b2\udc57\udb23\udee3",
        41, 16793, 511900592, 2134069921959976835L, 33351L, false, true, (char) 5512, (char) 18935,
        Double.longBitsToDouble(0x3fe71e7aea04e0e2L), Double.longBitsToDouble(0x3fd06c154a2397deL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 12, 3, "\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\ud9ff\udf5d\uda59\udd24\ud984\udcfb\ud953\udeaf\uda60\udee5\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\ud944\uddad", "\u6930\u5c65\uac54\u45cc\u2f87\uc3ec\ua25c\u1d1b", "\udbf7\udc31\ud990\udf0e",
        26, 44120, -1764011878, -1387648722913107045L, 73378L, true, false, (char) 15600, (char) 34844,
        Double.longBitsToDouble(0x3fd479c1e5ede7a6L), Double.longBitsToDouble(0x3fede326c8e71b90L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud953\udeaf\uda60\udee5\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\u3030\012",
        Z.run(T, 1, 13, 13, 3, "\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\ud953\udeaf\uda60\udee5\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf,", "\u3030", "\ud93c\ude3e",
        17, 58202, -1280756629, 7671085562334085120L, 53600L, false, true, (char) 204, (char) 48639,
        Double.longBitsToDouble(0x3fc358fc6000036cL), Double.longBitsToDouble(0x3fecdf65f3deadbdL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\udb8f\udd72\uda73\udfd4\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\u3030\0121=java.lang.String:\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\udb8f\udd72\uda73\udfd4\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf\u3030\012",
        Z.run(T, 2, 13, 13, 3, "\ud97b\udc6d\ud917\ude33\ud8a5\udf13\ud9ec\udd84\ud9eb\uddfd\ud847\udcf9\ud8a0\udfa3\uda6b\udcdd\ud9ed\ude3e\udbaa\uddd9\ud8b5\ude9f\ud8d1\udeda\ud995\udc03\udb8f\udd72\uda73\udfd4\udaab\udc92\udbb4\ude9e\u6f37\ud822\udcdf,", "\u3030", "\ud93c\ude3e",
        17, 58202, -1280756629, 7671085562334085120L, 53600L, false, true, (char) 204, (char) 48639,
        Double.longBitsToDouble(0x3fc358fc6000036cL), Double.longBitsToDouble(0x3fecdf65f1deadbdL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|applyFinalRules|org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder,java.util.Map|new:org.apache.commons.codec.language.bm.PhoneticEngine:org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
    "M|org.apache.commons.codec.language.bm.Lang|guessLanguage|java.lang.String|new:org.apache.commons.codec.language.bm.Lang:java.util.List,org.apache.commons.codec.language.bm.Languages",
    "M|org.apache.commons.codec.language.bm.Lang|guessLanguages|java.lang.String|new:org.apache.commons.codec.language.bm.Lang:java.util.List,org.apache.commons.codec.language.bm.Languages",
    "M|org.apache.commons.codec.language.bm.Lang|instance|org.apache.commons.codec.language.bm.NameType|static",
    "M|org.apache.commons.codec.language.bm.Lang|loadFromResource|java.lang.String,org.apache.commons.codec.language.bm.Languages|static",
    "C|org.apache.commons.codec.language.bm.Lang|<init>|java.util.List,org.apache.commons.codec.language.bm.Languages",
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|encode|java.lang.String|new:org.apache.commons.codec.language.bm.PhoneticEngine:org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|encode|java.lang.String,org.apache.commons.codec.language.bm.Languages$LanguageSet|new:org.apache.commons.codec.language.bm.PhoneticEngine:org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|getLang||new:org.apache.commons.codec.language.bm.PhoneticEngine:org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|getMaxPhonemes||new:org.apache.commons.codec.language.bm.PhoneticEngine:org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|getNameType||new:org.apache.commons.codec.language.bm.PhoneticEngine:org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|getRuleType||new:org.apache.commons.codec.language.bm.PhoneticEngine:org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|isConcat||new:org.apache.commons.codec.language.bm.PhoneticEngine:org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|join|java.lang.Iterable,java.lang.String|static",
    "C|org.apache.commons.codec.language.bm.PhoneticEngine|<init>|org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean,int",
    "C|org.apache.commons.codec.language.bm.PhoneticEngine|<init>|org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
    "M|org.apache.commons.codec.language.bm.PhoneticEngine|applyFinalRules|org.apache.commons.codec.language.bm.PhoneticEngine$PhonemeBuilder,java.util.Map|new:org.apache.commons.codec.language.bm.PhoneticEngine:org.apache.commons.codec.language.bm.NameType,org.apache.commons.codec.language.bm.RuleType,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
