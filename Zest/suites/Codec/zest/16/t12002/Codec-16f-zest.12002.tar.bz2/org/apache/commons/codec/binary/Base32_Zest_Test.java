package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base32_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u3288\ubf18", "\ud907\udced\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8",
        6, 29708, 88299318, 1891435433808018425L, -76930L, true, true, (char) 64089, (char) 60049,
        Double.longBitsToDouble(0x3fed550594ee6653L), Double.longBitsToDouble(0x3fe213233a7d4129L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, -59, -75, -85, -67]]\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, -59, -75, -85, -67]]\012",
        Z.run(T, 2, 4, 5, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u3288\ubf18", "\ud907\udced\udb88\udc8a\udbfa\udcc1\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8",
        6, 29708, 88299318, 1891435431769840633L, -59978L, false, false, (char) 3753, (char) 35750,
        Double.longBitsToDouble(0x3fded639d2af3b8cL), Double.longBitsToDouble(0x3fdb758c61919062L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 4, "\ud946\udedf\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4\udbce\udf6f\udb31\ude73\ud80b\udc66\udb92\udf40\ud8a0\ude10\udbc2\ude93\ud907\udced\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8\udb49\udd30\ud856\udd52", "\u4e99\ub37f\u876d\u059e", "\udb3e\udc7e\ud88c\udeeb\udaea\uddb1\udaf2\uded8\ud81b\ude19\ud8a7\udd27\ud95a\udc37\udae8\udd96\ud8b1\udccf",
        16, 1979, 758504926, -9030626998801954481L, 13821L, true, false, (char) 38234, (char) 34218,
        Double.longBitsToDouble(0x3fa0542e4e52b9d0L), Double.longBitsToDouble(0x3fd8ba64b90c85aaL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 0, "\ud8bc\ude5b\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\udb49\udd62\udb6e\udf51\udb6c\udce4", "\u3288\ubf18", "\udb8c\udc0f\ud9b8\udc85\udbea\udcb9\udaf2\udfdc\udb53\ude5d",
        35, 73381, 1248261828, 384027852602849921L, 66606L, false, false, (char) 1536, (char) 47193,
        Double.longBitsToDouble(0x3fed5c4d13ad8eacL), Double.longBitsToDouble(0x3fc139410eaa82c8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 6, "\ud888\udede\ud853\ude05\udb8b\udef0\udbdb\udded\ud99a\udd2a", "\u6d46\ubeb9", "\udb92\udf40",
        9, 99688, -1985811481, 4030648270612578333L, -60833L, false, true, (char) 36688, (char) 43298,
        Double.longBitsToDouble(0x3fe9b7c39a810543L), Double.longBitsToDouble(0x3fefc8d1fd327bb6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, -59, -75, -85, -67]]\012",
        Z.run(T, 2, 2, 5, 7, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4\udbce\udf6f\udb31\ude73", "\u987f\u5270\ucf9d\ub78a", "\udb53\ude5d\ud9c1\udfb8\udb49\udd30\ud9a4\udcd9\ud9d2\ude40\ud866\udddb\ud986\udeac\ud8c5\udfe5\uda33\ude1b",
        48, 30926, -1901280341, -3888739889059848055L, 50141L, false, true, (char) 9001, (char) 16694,
        Double.longBitsToDouble(0x3fdd10b28a77f030L), Double.longBitsToDouble(0x3fe4060b0abcf363L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 5, 0, "\ud8bc\udde6\ud853\udd83\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u3288\ubf18", "\ud907\udced\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8",
        6, 29708, 54, 1891435433808018425L, -76930L, true, true, (char) 64089, (char) 60049,
        Double.longBitsToDouble(0x3fc5541653b80000L), Double.longBitsToDouble(0x3fe213233a7d4129L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud968\udcb3\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u3288\ubf18\u987f\u5270\ucf9d\ub78a\u1472\ubf05\u8a2f\u450b\u58fc\uadb1\u7f21\u399d", "\uda10\udc1b\udab7\udcae\uda21\ude42\ud915\udcfd\uda95\udf49\ud88c\udeeb\udaea\uddb1\udaf2\uded8\ud81b\ude19\ud82f\ude2a\udb9f\udd49\ud8a0\udf8b\uda8a\udd45\ud823\ude85\ud925\udd4f\ud8d2\ude61\ud901\udf60\ud893\ude6a\ud95c\udfc0\ud8c7\udcf6\u1a9f\ud971\ude72\ud8c4\udeff\uda1c\ude21\ud890\udc0f\uda1a\udd09",
        11, 11430, 711694910, 3404345742123852697L, 25922L, true, false, (char) 21318, (char) 55076,
        Double.longBitsToDouble(0x3fddae93d536eba6L), Double.longBitsToDouble(0x3fc569e0580f94c8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 0, "\ud8bc\udde6\ud8d7\udffd\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u3288\ubf18", "\ud907\udced\udb88\udc8a\uda6d\udd52\udab6\uded8\uda83\udc3c\ud9c1\udfb8",
        4, 29708, 88280877, 1891345029041404921L, -72435L, true, false, (char) 1117, (char) 54081,
        Double.longBitsToDouble(0x3fe213233a7d4129L), Double.longBitsToDouble(0x3fc9bcf7c27522c0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ufd5d\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u2185\000", "\ud907\udced\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9f5\udf12",
        -5, 29708, 0, 1891434879757237241L, -76930L, true, true, (char) 63917, (char) 60049,
        Double.longBitsToDouble(0x3fed550594ee6653L), Double.longBitsToDouble(0x3fb09919d3e80000L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, 99, -60, -74, -36]]\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, 99, -60, -74, -36]]\012",
        Z.run(T, 2, 5, 5, 6, "\ud8bc\udde6\ud853\ude05\udb93\udef4\ud8e6\udc0c\udb50\ude65\udb9d\udca1\uda47\ude70\udb6c\udce4", "\u88c1\u25f9", "\ud907\udced\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8",
        6, 23940, 1026770462, 1877637864254520313L, 37558L, false, false, (char) 3753, (char) 55194,
        Double.longBitsToDouble(0x3fdf7737c35a6b7eL), Double.longBitsToDouble(0x3fe68e63f6f18927L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 3, 5, 8, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u8438\u37f2\u8629\u0c84\ucf9d\uca3a\u1472\ubf05\u8a2f", "\ud856\udcc9",
        -2, 78985, 2075573073, 1959577888668720760L, -76930L, true, true, (char) 64089, (char) 18322,
        Double.longBitsToDouble(0x3fe5aec00253bf56L), Double.longBitsToDouble(0x3fe23231a27d2c29L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 0, "", "\u3460\u75bc\ua5fb\000\000\000", "\ud9be\udf64\udb92\udf40",
        19, 99814, 10617063, 174571520L, -99875L, false, true, (char) 20394, (char) 49091,
        Double.longBitsToDouble(0x3fefc8d1fd327bb6L), Double.longBitsToDouble(0x3eca2b7c6f3c0000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, -59, -75, -85, -67]]\012",
        Z.run(T, 2, 7, 5, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb4d\uddaa", "\u3288", "\ud967\udfa5\u9afe\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8",
        6, 29708, 88299318, 1891435433808018425L, -76930L, true, true, (char) 64089, (char) 60049,
        Double.longBitsToDouble(0x3fed550594ee6653L), Double.longBitsToDouble(0x3fe213233a7d4129L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 4, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5", "\u9671\ubfc8", "\udb31\ude73\ud80b\udc1e",
        20, 15274, 593778814, -8528995365982523329L, -44765L, true, true, (char) 52797, (char) 18725,
        Double.longBitsToDouble(0x3fe7d4902f36f873L), Double.longBitsToDouble(0x3fe4082a19f91a3fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 5, 0, "\ud938\udeeb\ud873\ude07\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud901\udeae\udb6e\udf51\udb6c\udce4", "\u4bf3\ubf18", "\udb5e\udd8c\udb88\udd45\udbea\udcb9",
        46, 53185, 198471430, 2081652025542828484L, -4462L, false, false, (char) 57005, (char) 3991,
        Double.longBitsToDouble(0x3f90464c505bcb20L), Double.longBitsToDouble(0x3fc139410eaa82c8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 5, 0, "\ud8bc\udde6\ud853\ude05\ud961\udf0a\udbcf\udff0\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u3288\ubf18", "\ud907\udced\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud96f\udf53",
        7, 29708, 88299318, 1891435433808018425L, -76930L, true, true, (char) 63577, (char) 60049,
        Double.longBitsToDouble(0x3fed550594ee6653L), Double.longBitsToDouble(0x3fe213233a7d4129L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 8, "\uda96\udf00", "\u75bc\u90bc\u4337\uc8e6\u9495\uc373\ubb5c\u3288\ubf18\u987f\u5270", "\udbea\udcb9\udb0a\ude8d\udb72\udce6\ud9fa\udef8\udb49\udd30",
        0, 40491, -1906132351, -8159386735345842111L, -48177L, false, false, (char) 2551, (char) 64089,
        Double.longBitsToDouble(0x3fc139410eaa82c8L), Double.longBitsToDouble(0x3fcdccca6d09919cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 8, 0, "\ud8bc\udde6\u2541\ud8d9\udc5e\uda7e\udf17\udb89\udffc\ud810\udd2e\ud9e1\udd85\ud809\ude31", "\u8753\u622a\u031f", "\ud9d2\ude4f\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8\udb49\udd30\ud856\udd52\ud975\udf85\u1c0d\ud986\udf43\ud8d4\ude9c\uda45\ude1b\udb10\udc2d\uda21\ude42\ud915\udcfd\udb3e\udc7e\ud807\udf27\u11fa",
        54, 24602, 397429373, 3588058270721197430L, -84758L, false, true, (char) 29086, (char) 26197,
        Double.longBitsToDouble(0x3fa9aaa56605b390L), Double.longBitsToDouble(0x3fccf5dd767f32b8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 5, 0, "\ud8bc\ude84\ud853\ude05\ud8f5\udee5\udbdb\udded\udbad\udf74\ud8e1\uddae\uda32\udf53\udb6c\udce4", "\u3288\ubf18", "\ud9f1\uded3\ud8e2\udf87\uda3b\udf1b\ud874\udea2\udb53\ude5d\ud823\udce8\udb49\udd66\ud856\udd52\ud975\udf85\u1c0d\ud986\udf43",
        41, 38584, 1511047903, 5075216058389676971L, 22743L, false, true, (char) 54081, (char) 3753,
        Double.longBitsToDouble(0x3fe3ea094b7da771L), Double.longBitsToDouble(0x3feeb2048d23b402L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud8bc\udde6\u2b82\ud8f5\udee5\uda46\uddc2\000\ud8d9\ude2b\udb6e\udf51\udb6c\udce4", "\u3268\u6cc6", "\ud907\udced?\udb6e\udc96\udb0a\ude8d\udb53\ude5d\000",
        -5, 29708, 4413238, 1873497447061699577L, -76930L, true, true, (char) 27392, (char) 60049,
        Double.longBitsToDouble(0x3fed550594ee6653L), Double.longBitsToDouble(0x3fe213233a7d4129L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 5, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8dd\udf8d\udb6e\udebb\udb6c\udce4", "\u3288\ubf18", "\ud907\udced\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8",
        6, -804, 0, 1891434879757237241L, -99880L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fed6c756089ca08L), Double.longBitsToDouble(0x3fed550594ee6653L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udab9\ude3c\udb6c\udce4\udbce\udf6f\udb31\ude73\ud80b\udc66\udb92\udf40\ud8a0\ude10\udbc2\ude93\ud907\udced", "\ubf05\u2246\u450b\u2dba\u08d2\ubd72\u399d\u3899\ub37f\u876d\u059e\u556f\u955a\uad07\u73da\uccaa\ubbed\u2f7d\u73a8\ub92d\u17f1\u4c04\uce45\u7f01\u12b9\u89d9\u450a\u832b\u3220\u855a\u4be8\u391c\u776c\u3f3b\u8a6b\u10a2\uc0dd\u3c91\ub7c9\ua32b", "\udb4b\udefa\uda01\udd23\uda27\ude1c\udb36\udd08\udafc\udc64\ud8f3\udeb1\ud9da\udf25\uda8b\udcce\ud9cb\udeaf\udb02\udd31",
        43, 10184, -1686203901, 9207431446733377068L, -58337L, true, false, (char) 59701, (char) 57003,
        Double.longBitsToDouble(0x3fd70b727fa0cbe4L), Double.longBitsToDouble(0x3fe818bab5eddca8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\ud9c8\uddb3\uda1c\ude8f\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u3288\ubf18", "\ud97d\udda0",
        13, 42549, -1482631229, -779290956658451450L, 91506L, true, true, (char) 60591, (char) 19529,
        Double.longBitsToDouble(0x3fe6f8da5a1e5a10L), Double.longBitsToDouble(0x3fed5a32631351acL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 5, 0, "\u2265\ud853\ude05\ud9be\udfc9\udbdb\udded\ud99a\udd2a\ud8e1\uddae\ud9e3\udee6\uda67\ude7d", "\u3288\u6fb0\u987f", "\udb88\udc8a\udbea\udcb9\udae5\udd46\udb53\ude5d\ud9c1\udfb8\udb49\udd30\ud856\udd52\ud975\udf85\ud926\uddeb\ud831\udf7a\ud8c5\udfe5\uda10\udc1b\udb0f\udfd5\uda43\udd6d\ud915\udcfd\udb3e\udc7e\ud88c\udeeb\udaea\uddb1",
        54, 67341, 2085112445, 8307033325596092253L, 20841L, true, true, (char) 36116, (char) 36612,
        Double.longBitsToDouble(0x3fc7a3a0c419d5b0L), Double.longBitsToDouble(0x3fea8c468de896b4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 0, "\000", "\u75bc", "\udb6e\udf51",
        27, 71180, -641871691, -6261373999969375034L, -77346L, true, true, (char) 18145, (char) 63499,
        Double.longBitsToDouble(0x3fee18533f01a7a0L), Double.longBitsToDouble(0x3fe837a97b7d0bd4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 4, 5, 4, "\ud8bc\udde6\u0082\ud8f5\ude5b\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u3288\ubf18", "\000",
        -5, -1000, 0, -779404210313335034L, -100000L, false, true, (char) 61672, (char) 19529,
        Double.longBitsToDouble(0x3fe6f8de7a1e5a10L), Double.longBitsToDouble(0x3fed5a3263ad8eacL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 5, 2, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\ud833\udfb9\ud982\udfac\ud8e1\uddae\udb6e\udf51\ud9f8\uddcd\udbce\udfa6\udb31\ude73\ud80b\udc66\udb92\udf40\ud8a0\ude10\udbc2\ude93\ud907\udced\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8\udb49\udd30", "\u399d\u4e99", "\udb10\udc2d\uda21\ude42\ud915\udcfd\udb3e\udc7e\ud88c\udeeb\udaea\uddb1",
        54, 24602, -1546237315, -6900768229387771553L, 9018L, false, true, (char) 49034, (char) 61736,
        Double.longBitsToDouble(0x3fd3be360b51fa50L), Double.longBitsToDouble(0x3fcfa1ef9fdfbb04L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 9, 7, 4, "\ud8d3\udeea\ud853\uddc5\ud8f5\udee5\udad4\udf0a\uda7a\udf5a\ud8e1\uddae\udb52\udee4\u7a6e", "\u3288\ubf18", "\ud8f4\ude38\udb88\udc8a\udbea\udcb9\udb0a\ude8d",
        0, 58606, -294401371, 3774545734881199837L, 93790L, true, true, (char) 11206, (char) 35750,
        Double.longBitsToDouble(0x3fdcaf19517f8c70L), Double.longBitsToDouble(0x3fecac4c79c263caL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\ud8c6\ude35\udb5d\udcc8", "\u3288\ubf18", "\ud907\udced\udb88\udc8a\udbfa\udcc1\udb0a\ude8d\udb53\ude5d\udbad\udeb1",
        6, 52444, 910382902, 1891435430679321593L, -42259L, true, false, (char) 20136, (char) 65288,
        Double.longBitsToDouble(0x3fed6f3a0089ca08L), Double.longBitsToDouble(0x3feedd0594605253L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 6, 0, "\ud8a2\udcd0\ud853\ude05\ud884\udd8c\udbdb\udd38\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u3288\u6cc6", "\u00e7\udb88\udc4b\udbfa\udcc1\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8",
        43, -1000, 0, 0L, -59978L, false, false, (char) 3753, (char) 35750,
        Double.longBitsToDouble(0x3fded639d000018cL), Double.longBitsToDouble(0x3fdb758c61919062L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 4, 3, 4, "\ud834\udd22", "", "",
        -5, -1000, 0, -641871872L, -77346L, true, true, (char) 18145, (char) 63499,
        Double.longBitsToDouble(0x3f05de0069e80000L), Double.longBitsToDouble(0x3fe837a8037d0bd4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, -59, -75, -85, -67]]\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, -59, -75, -85, -67]]\012",
        Z.run(T, 2, 6, 6, 3, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud839\udfb9\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\uce5b\uc2d3", "\ud907\udced\udb88\udc8a\udbfa\udcc1\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8",
        6, 29708, 88299318, 1891435431769840633L, -62029L, true, false, (char) 16984, (char) 22594,
        Double.longBitsToDouble(0x3fcbeb6a09f504a4L), Double.longBitsToDouble(0x3fded639daaf3b8cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, -59, -75, -85, -67]]\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, -59, -75, -85, -67]]\012",
        Z.run(T, 2, 4, 5, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udbc0\udd1a\uda1c\udc70\ud833\udd8e\udb1e\udf23\ud80a\udff2\udb92\udf40\ud8a0\ude10\udbc2\ude93\ud907\udced\udb88\udc8a\udbfa\udcc1\udb0a\ude8d\udb53\ude5d\ud862\ude49\uda65\udfc9\ud908\udd95\uda29\udddc\udbeb\udd2f\uda6b\udc1a\ub13d\uda10\udc1b\udb10\udc2d\uda62\udeaa\ud929\ude95\u1e74\udb14\udded\udaea\udd7e\uf2dd\ud81b\ude19\udb52\udc5b\ud848\udc23\ud90f\ude92\udae6\udd56\udb2f\udc55\udba4\udc73\udaf5\ude7f\udbe8\ude97\ud9ac\udc91", "\u3db4\ud298\u7866\u1906\u4573\ud7e2", "\ud981\udc1f\ud800\udc1f\ud8e6\uddac\ud8d9\ude93\ud9cb\udc51\ud866\ude6c\udbe1\udee7\ud867\udcd8\udbc4\udf40\ud89f\udd6c\uda87\udc5a\udacb\udc3c\ud80e\uddae\ud963\uddb8\u77f7\udbb0\ude7c\ud936\udd96\udae1\udf21\ud940\udd6f\udb46\udeeb\u14c1",
        40, 23198, -1766719167, 1902513617989967209L, 25813L, false, false, (char) 61964, (char) 10501,
        Double.longBitsToDouble(0x3fed5e3922672da3L), Double.longBitsToDouble(0x3fd4208b7d244674L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, 17, -63, -85, -67]]\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-116, -74, 35, -43, 17, -63, -85, -67]]\012",
        Z.run(T, 2, 5, 5, 8, "\ud8bc\udde6\ud853\ude05\ud941\uddf1\udbdb\udded\ud966\ude2a\udb70\udf62\ud84c\udf84\ud9bb\udc6f", "\u3288\ubf18\u9816\u5270\ucf9d\ub78a\u3f83\u5f5d\u2a33", "\udb0f\udc4f\udb09\udff9\u1c0d\uda6b\udc1a\ub13d\uda10\udc1b\udb10\udc2d\uda6c\udd4f\ud88d\uddca\ud95e\udf49\ud894\udc2a\udaea\uddb1\udaf2\uded8\udb8d\udd52\udb12\ude03\ud848\udc23\ud90f\ude92\ud80c\ude6d\ud90f\ude86\udbeb\udc80\uda15\udda1\ud9ba\ude24\ud905\udd44\uda59\udfdd\uc695\uacc5\ud934\udee5\ud935\udda3\uda3b\udead\ud963\udf88\ud99a\udf41\ud8dc\udef9\uda56\ude32\udbb3\udc6d\udab8\ude9c\ud803\udd17\ud915\udf5c\uda4e\udc0c\ud99e\udc13\udbbd\ude8d\u3376\udb69\udf41\ud835\uddef\uda5b\ude15\ud83c\udf8b\ud97a\ude1b\udb99\udfd1\udac2\udc9b\udb62\udf51\ueb2a\udabd\udded\udaf3\udc10\udb72\udd7a\udba5\udf67\udb42\udf04\ud956\udef4\ud85a\ude13\ud997\udc75\udaa3\udccc\ud875\udc25\udad2\ude51\ud86d\udde2",
        45, 67133, 752681282, 8802460988721807907L, -68895L, false, false, (char) 57329, (char) 41585,
        Double.longBitsToDouble(0x3fe33796db86eacaL), Double.longBitsToDouble(0x3fe50ee742ca6a3cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 8, 1, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\udb18\udf6c\udab8\udc63\udb6e\udf7b\udb6c\udce4\udbce\udf6f\udb31\ude73\ud80b\udc66\udb92\udf40\ud8a0\ude10\udbc2\ude93", "\u4e89\ubf05\u8a2f\u23c6\u13c0\u42fe", "\udb18\udd27\ub13d\uda90\udd99\udb0a\udd32\uda6c\udd4f\uda63\udd47",
        9, 92001, 1716741034, 7234871096945257026L, 59213L, true, true, (char) 54909, (char) 4346,
        Double.longBitsToDouble(0x3fd31df75b398852L), Double.longBitsToDouble(0x3fc81ba8c894e7a4L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 2, 9, "\ud8bc\udde6", "\ua9b5\u2979\u4394\uc8e6\u9495\uc373\u00b5\u1103\ubf18\u987f\u587e", "\udbea\udcb9\udb0a\ude8d\ud80f\ude5b\ud9c1\udfb8\udb49\udd30",
        10, -756, 2093023232, 421675466752L, -100000L, false, false, (char) 49919, (char) 64089,
        Double.longBitsToDouble(0x3fc1394100000000L), Double.longBitsToDouble(0x3fcdccca6909919cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 5, 7, "\uda60\udf6d\udbef\udd6c\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud8e1\uddae\udb6e\udf51\udb6c\udce4\udbce\udf6f\ud95f\udc49", "\u987f\u5270\u171f\ub78a", "\udb53\ude5d\ud9c1\udfb8\udb49\udd30\ud9a4\udcd9\ud9d2\ude40\ud866\udddb\ud810\ude11\udb8a\udee7\udbb4\uded9",
        6, 17358, 102890115, 4938974834159927968L, 50141L, false, true, (char) 9001, (char) 16694,
        Double.longBitsToDouble(0x3fdd10b28ad5f030L), Double.longBitsToDouble(0x3fe4060b0abcf363L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 8, 2, "\ud9a2\udeb9\uda54\udca6\ud94d\ude70\udbdb\uddc2\ud92d\udd34\ud917\udd41\ud8a6\udf2d\udb6c\udc8f\udbce\udf6f\udaa9\ude6f", "\u987f\u5270\u8881\u8f50", "\udb53\udf48\udacc\udc26\udb4e\udd56",
        10, 15036, 2093070977, 8914518542776366386L, -50113L, false, false, (char) 2551, (char) 64089,
        Double.longBitsToDouble(0x3fc139410eaa82c8L), Double.longBitsToDouble(0x3fcdccca6909919cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-48]]\012",
        Z.run(T, 2, 2, 5, 1, "\000", "\u75bc\u29d6\u5051\000f\000\000", "",
        19, 99814, -1985811481, 4030648269968244736L, -60833L, false, true, (char) 0, (char) 65190,
        Double.longBitsToDouble(0x3fdf4f0735020a22L), Double.longBitsToDouble(0x3feb13e60d327bb6L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[]]\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[]]\012",
        Z.run(T, 2, 5, 6, 4, "", "\u3460\u22f6\u1d5e", "\udb6c\udce4",
        30, 83309, 8581, 95813632L, 31303L, true, true, (char) 63499, (char) 2858,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3eca831000000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 8, 0, "\ud8bc\ude14\u2541\ud8d9\udc5e\uda7e\udf17\udb89\udffc\ud810\udd2e\ud9e1\udd85\ud809\ude31\udb1f\ude86\udaf7\ude65\udb49\udd18\udb4b\udf12\udb02\udea2\udbc2\uded7\ud907\udced\ud9d2\ude4f\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8\udb49\udd30\ud856\udd52\ud975\udf85\u1c0d\ud986\udf43\ud8d4\ude9c\uda45\ude1b\udb10\udc2d\uda21\ude42\ud915\udcfd\udb3e\udc7e\ud807\udf27\ud98f\udd7f\u473a\uda62\udda2\ud8e7\uddfd\ud8aa\udfa2\ud832\udc06", "\u3540\u8ff9\u6e9a\u0c52\u1647\ub414", "\uda1c\udeec\ud937\udfbb\udbad\udefd",
        13, 59296, -444155968, -5126363447812567430L, 39786L, true, true, (char) 3207, (char) 30991,
        Double.longBitsToDouble(0x3f8bff6f26ea5580L), Double.longBitsToDouble(0x3fb59b4a07a340d8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 0, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\ud9c8\uddb3\uda1c\ude8f\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\u87fb\uc6c7\u45af\u2676\ua066\u4c1d\u148f\ubf05\u8a2f\u3a2f\u2dba\u08d2\u6016\u7745", "\ud8a2\udf48\udb0f\udfba\uda21\ude42\ud89d\uddd4\ud9f0\udf35\udb06\ude76\udb5d\ude89\udb8c\udce5\u8c6f\udbfe\udc59\ud8f6\udca6\uda3e\udf13\u9a18\udb90\udd21\ud4e8\udab7\udf8d\udb9d\udf51\uda90\udf77\ud87b\udff7\ud9c4\udc59",
        32, 94780, 338898196, -7283932577924606056L, 76307L, true, true, (char) 61235, (char) 16770,
        Double.longBitsToDouble(0x3fc665fa87afa224L), Double.longBitsToDouble(0x3fc8130b8545d144L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 6, 6, 3, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\ud839\udfb9\ud8e1\uddae\udb6e\udf51\udb6c\udce4", "\uca87\uc2ee", "\ud944\uded2\ud9bb\udf50\udb72\udf50\ud94a\ude0c\udb53\ude96\ud939\udef4\ud8a7\ude64\ud856\udd52",
        -2, 23129, 37395449, 3281495263294725752L, -62029L, true, false, (char) 16984, (char) 4947,
        Double.longBitsToDouble(0x3fcbf62049f504a4L), Double.longBitsToDouble(0x3fded639daaf3b8cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 8, 1, "\ud8bc\udde6\ud853\ude05\ud8f5\udee5\udbdb\udded\udb18\udf6c\udab8\udc63\udb6e\udf7b\udb6c\udce4\udbce\udf6f\udb31\ude73\ud80b\udc66\udb92\udf40\ud8a0\ude10\udbc2\ude93", "\u5b24\ua973\u8a2f\u23c6\u13c0\u42fe", "\udb18\udd27\ub13d\uda90\udd99\udb0a\udd32\uda6c\udd4f\udade\udd45",
        32, 92001, 1716741034, 7234871096945257026L, 59213L, true, true, (char) 54909, (char) 4346,
        Double.longBitsToDouble(0x3fd31df75b398852L), Double.longBitsToDouble(0x3fc81ba8c894e7a4L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 0, "\ud9ad\ude9f\udb06\ude3f\u7485\udbdb\udd7d\ud840\udc61\ud899\udeed\udb6e\udf48\udb6c\udce4", "\u6b03\ubf18", "\ud8d3\udd55\udb88\udc8a\udbea\udcb9\udb0a\ude8d\udb53\ude5d\ud9c1\udfb8\udb49\udd30\ud856\udd52\ud975\udf85\udb6b\uddfe\ud986\udefc\ud8c5\udfe5\ud931\uddcc\ud990\udd6a\ud93d\udfe7",
        13, 42812, -152421419, 7373346795984219374L, 5164L, true, true, (char) 19339, (char) 12426,
        Double.longBitsToDouble(0x3fe3935bc3ec6712L), Double.longBitsToDouble(0x3f61c9c070821500L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[8, 63, 67, -41, -59, -75, -85, -67]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 2, "\ud938\ude6f\ud873\ude07\ud8f5\udee5\udbdb\udded\ud99a\udd2a\ud901\udeae\udb6e\udf51\udb6c\udce4\udbce\udf6f\udb31\ude73\ud96d\udd6b\udb92\udf40\u0c62\uda8b\udd2a\udb5e\udd8c\ud9e8\uded6\udbbc\uded2\udb0a\ude14\udb53\ude5d\ud9c1\udfb8\udb49\udd30\ud856\udd52\ud975\udf85\u1c0d\ud986\udf43\ud8c5\udfe5", "\u181a\u706e\u5a8b\u6794\u17c7\u6509\u3168\u126e\u2494\u5ceb\u5f00\u8208\ube6a\u0137\ub971\ub3ef\u3e02\u0cfa\u83c7\u98da\u8054\u4862\u4b21\uc8c6\uc830\u6c9f\u934a\uc158\ub407", "\ud951\udf20\udaa3\udedf\udb76\uddca\udb88\ude45\ud943\udf26\ud8ee\ude0c\udb39\udd62\ud9c8\udd71\ud8ab\ude4f\ud94c\udf8b\ud885\udd59\udb61\udf6c\ud946\udd8e\udbd4\udd6d\uda1f\ude1b\ub86b\uda5d\udcaa\udb2b\udf11\ud8ca\uddb1\udb22\udea5\udb75\udefc\ud95c\ude2b\udb32\ude20\ud933\udcb6\ud8cb\udd4e\udb75\udc20\udb14\udf0a\ub0b2\uda50\udde6\udbed\udec7\ud8fb\ude58\ud8e4\udc5f\udb54\udec7\uda1c\uddea\udbe5\udecc\ud9ae\udd12\ud932\udc38\udbb5\ude26\ud987\udcfd\udac4\udde4\ud9fa\udd9f\ud804\udd26\ud90c\udc5c\ud881\udecf\ud856\uddfd\udbc0\udd50\ud879\udc68\ud97e\ude1f\ud8e5\udff4\ud855\udc89\ud929\udd5c\ud9a4\udff0\ubd8b\udb22\udcd2\ud8a6\udd60\ud96a\udec6\ud8ee\ude47\ud950\udddf\ud955\udf56\uda0a\udd1a\ud851\udccf\udad4\udf3c\ud9fc\udc28\ud9e7\udeab\udbd3\udf0e\u3c51\u205e\uda38\udd05\ud929\udde6\udb75\udd64\ud980\udd24\ud9bf\udc31\udb2a\udfe7",
        0, 7437, 210168491, 7369538613068970631L, -26328L, false, false, (char) 61418, (char) 60673,
        Double.longBitsToDouble(0x3fec8cced20a4d10L), Double.longBitsToDouble(0x3fea001b1ac7e143L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 2, 8, 1, "\ud8f8\ude37\ud853\ude05\uece5\udbdb\udded\udb18\udf6c\udab8\udc63\udb6e\udf7b\udb6c\udce4\udbce\udf6f\udb31\ude73\ud80b\udc66\udb92\udf40\ud8a0\ude10\udbc2\ude93", "\u4e89\ubf05\u4230\ud196\u45d3\u01e2", "\udb18\udd27\ud938\udea3\uda90\udd99\udab9\udd0a\uda6c\udd4f\udb46\ude58\udb42\udfb6\ud88c\udeeb\udaea\uddb1\udaf2\uded8\ud81b\ude19\udb52\udc5b\ud848\udc23\ud90f\ude92\ud80c\ude6d\ud932\ude0c\ud8d5\uddaa\ud82a\udf90\udabe\udc29\udadb\udf2d\ud95a\udd09\udbb3\ude9d\ud948\udd8c\udb2b\udc3d\uda5b\udfbd\ud981\uded7\udb17\udcf3\udab6\udeaf\uda53\ude2f\ud9d2\uddea\ud915\udda4\udafb\udf0c\udaee\udec9\udad2\udd0a\udaf1\udd87\ud92f\udd9a\ud87a\udf2d\uda2f\uddb2\uda83\udc47\udbc6\udd3f\uda88\udf09\ud987\uddb1\ud9e1\udf1c\udbc3\uddfb\ud906\udc7d\ud917\udcfe\ud89b\udf0c\ud966\udc37\uda02\uded6\ud890\udfd5\ud801\udd12\ud9a9\ude0e\ud834\udfa6\udbf4\udeaf\ud916\udff3\ud818\udf83\udbd3\udda6\ud9f1\udca5\udb27\udc74\udb9b\udf64\udbb3\ude96\ud809\udfef\udba6\udc5c\ud857\uddc3\uda81\udf7d\ud87f\ude45\ud88b\udea8\udb62\udff2\ud8a9\udea3\udadd\udeb5\ud8f4\udeb2\ud818\uddd9\ud914\ude21\udb46\udf44\udb9f\udef8\ud8f4\ude8d\udb37\ude73\uda3c\udef0\ud8f5\udd1a\ud9c9\udc11\uda91\udee2\udb03\udc37\ud91c\udd68\ud892\udf53\udb0e\udcee\ud91e\udfa0\udac1\ude7b\ud98b\udc95\u80b8\ud936\ude1c\ud818\ude4e\ud8d4\udc1d\ud80b\udfe6\ud93a\ude42\uda39\udecc\udb37\udc2d\udb01\uddd0\udacf\udf43\ud9cb\udd63\ud8c0\ude36\ud852\udd8b\udb87\udc6d\udbad\udf2b\ud80f\udc64\ud86e\udfac\udb61\udcdd\udbc0\udfc9\uda34\udfa7\ud901\ude2e\ud8cd\udf73\ud809\udd9b\udbab\udf7b\ud8ea\udf5c\udbcc\udf76\ud899\udc76\udb39\ude26\ud88f\udfc8\ud9de\udef1\ud8e5\udfdf\udb9d\udd42",
        5, 3454, -34086442, 742968447333552828L, -50196L, true, false, (char) 35807, (char) 29289,
        Double.longBitsToDouble(0x3fdaf916fe8c2cf4L), Double.longBitsToDouble(0x3fd2665f68c3bb46L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base32|decode|[B,int,int,org.apache.commons.codec.binary.BaseNCodec$Context|new:org.apache.commons.codec.binary.Base32:",
    "M|org.apache.commons.codec.binary.Base32|encode|[B,int,int,org.apache.commons.codec.binary.BaseNCodec$Context|new:org.apache.commons.codec.binary.Base32:",
    "M|org.apache.commons.codec.binary.Base32|isInAlphabet|byte|new:org.apache.commons.codec.binary.Base32:",
    "C|org.apache.commons.codec.binary.Base32|<init>|int",
    "C|org.apache.commons.codec.binary.Base32|<init>|int,[B",
    "C|org.apache.commons.codec.binary.Base32|<init>|int,[B,boolean",
    "C|org.apache.commons.codec.binary.Base32|<init>|int,[B,boolean,byte",
    "C|org.apache.commons.codec.binary.Base32|<init>|",
    "C|org.apache.commons.codec.binary.Base32|<init>|byte",
    "C|org.apache.commons.codec.binary.Base32|<init>|boolean",
    "C|org.apache.commons.codec.binary.Base32|<init>|boolean,byte",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
