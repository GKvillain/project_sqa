package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base32_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uac1d\u60ba\u7ad9\u6bb0\ua4ec\u9307\u8b2e\u14d7\u15f4\u5ee8\u46ad\uc3ae\ubd29\u7650", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d\ud9f8\udd94\udb2b\udfa4\uda50\ude5f\uda96\udc6d\uda32\udfac\ud802\udc20",
        26, 2948, -1151051784, -6465048713083834141L, -33595L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f6212d68L), Double.longBitsToDouble(0x3feb32257fed5431L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud8fa\udd25\uda7d\udf80\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53\ud8d9\udc70\ud9dd\udceb\u4449\uda5a\udc51\ud827\ude5f\uda62\udeae\udb24\udc36\ud917\udcd7\ud952\udca6\udb7b\udcb3\udb35\udefe", "\uc3ae\ubd29\u7650\u5ed7\u6f75", "\uda90\udd7f\uda28\udf39\udb23\udd8d\ud9f8\udd94\udb2b\udfa4\uda98\udd53\uda96\udc6d",
        53, 42245, -1045040784, 8451146794307704824L, -14211L, false, false, (char) 44979, (char) 11023,
        Double.longBitsToDouble(0x3fd6058c7d69d50cL), Double.longBitsToDouble(0x3fd8d901ec4213c8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uac1d\u60ba\u7ad9\u6bb0\ub38d=\u8b2e\u14d7\u15f4\u5ee8\u46ad\uc3ae\ubd29\u1eb3", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d\ud9f8\udd94\udb2b\udfa4\uda50\ude5f\uda96\udc6d\uda32\udfac\u5820",
        26, 2948, -1151051784, -6465048713083834141L, -33595L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f6212d68L), Double.longBitsToDouble(0x3feb32257fed5431L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\000\ud815\udf8c\ub887", "\u21e5\u38a5\u3ea5\000\000\000\000\000\u92ca\u8b2e\u14d7\u15f4\u5ee8\u46ad\uc3ae\ubd29\u7650\u5ed7", "\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d\ud9f8\udd94\udacd\udf95\uda50\ude5f\uda96\udc6d\uda32\udfac\ud802\udc20\ud8e5\uddc4",
        28, 44216, -1505261453, -2230776177694808994L, -50792L, false, true, (char) 16943, (char) 64189,
        Double.longBitsToDouble(0x3fe1096b476644afL), Double.longBitsToDouble(0x3fef6aa18850a930L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud8fa\udd25\ud815\udf8c\ub887\uda16\udca7\udb9d\udcc7\udaf5\udd53\ud8d9\udc70\ud9dd\udceb", "\u54da\u6bb0\ua4ec", "\ud8b9\udd92",
        9, 68555, 295233745, 7874203285156090209L, 14048L, false, true, (char) 50322, (char) 62874,
        Double.longBitsToDouble(0x3fd4b44cdb2202e2L), Double.longBitsToDouble(0x3fdffc9d1122da4aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud8f1\udcb3\ud8bb\udc99\ub80a\ud954\udc05\udbd2\udd2d\ud806\udf8b\ud971\udc7c\ud9dd\udceb\udaf3\udee2\udbf5\udfba\ud827\ude5f\uda62\udeae\ud871\udf01\ud91e\udd2f\ud952\udca6\udb7b\udcb3\udb35\udefe\ud8db\udd2b\ud9d2\udedb\uda56\udc9b\ud930\udf8e\ud839\udc4b\ud943\udfc5\udb53\udff8\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d", "\u513e\u23ca\u2711\ub68f", "\udbbe\udfec\ud973\udde2\udbc5\udf0f\udb27\udfd5\ud94e\udf62\ud949\udd03",
        37, 80731, -197200186, 4949304401021970278L, 62767L, false, true, (char) 42141, (char) 18830,
        Double.longBitsToDouble(0x3fe42563d0d4e85bL), Double.longBitsToDouble(0x3fbb337f995c9e18L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\ud172\u60ba\u7ad9\u6bb0\ua4ec\u9307\u8b2e\u14d7\u15f4\u5ee8\u46ad\uc3ae\ubd29\u7650\u5ed7\u6f75\u07d5\u111b\u3721\ua559\u8120\u096f\u7145", "\uda32\udfac\ud802\udc20\ud8e5\uddc4\ud976\udc25\udbbe\udfec\ud98e\udf29",
        37, 59694, -347669349, -4483544774144684704L, -24378L, true, true, (char) 37599, (char) 2985,
        Double.longBitsToDouble(0x3fe56ca1e3d189c5L), Double.longBitsToDouble(0x3fe80b8e020746e2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 7, 8, 9, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uac1d\u60ba\u7ad9\u6bb0\ua4ec\u9307\u8b2e\u14d7\u15f4\uaa2a\u46c7\uc3ae\ubd29\u7650", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d\ud966\ude2b\ud858\udf61\uda50\ude5f\uda96\udc6d\uda32\udfac\ud802\udc20",
        26, 2948, -1151051784, -6465048713083834141L, -33595L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f6212d68L), Double.longBitsToDouble(0x3feb32257fed5431L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 3, 8, 1, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\ud82f\udd90", "\u7c1f\u60ba\u7ad9\u6bb0\ua4ec\u30e6\u46ca\u1c5d\u160b\ubc3d\u468a\uc3ae\ubd29\u7650", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f\ud9e2\udf7b\udb23\udd8d\ud9f8\udd94\udb2b\udfa4\uda50\ude5f\uda8f\udc2b",
        46, 42245, -1045040784, 8451146796221210726L, -14211L, false, false, (char) 33065, (char) 37539,
        Double.longBitsToDouble(0x3fc860ac87e22d0cL), Double.longBitsToDouble(0x3fe4fbc296bc2c68L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 9, 2, 1, "\ud8ff\udde5\ud815\udf8c\ub887\ud954\udc05\ud837\udddf\udaed\udc30", "\uac1d\u60ba\u7ad9\u6bb0\ua4ec\u9307\u8b2e\u14d7\u15f4\u5ee8\u46ad\uc3ae\ubd29\u7650", "\ud90f\udcdf\udbf0\udd82\uda90\udd4d\uda28\udf39\udb23\udd8d\ud9f8\udd94\udb2b\udfa4\uda50\ude5f\uda96\udc6d\uda32\udfac\ud802\udc20",
        26, 2948, -1151051784, -6465048713083834141L, -33595L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f6212d68L), Double.longBitsToDouble(0x3feb32257fed5431L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 0, "\ud8fa\udd25\uda79\udec2\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53\udace\udc1f\ud9dd\udcd1\u44df\uda5a\udc51\ud827\ude5f\uda62\udeae\ud84d\udd2b\uda54\udd77\u2155\udbba\ude11\udb35\udefe\ud8db\udd2b\ud9d2\udedb\ud976\udc4c\ud934\udc2d\ud91f\udd1e\udb57\udd47\ud8ea\uddf2\udaad\udc64\uda55\uddd4\uda90\udd7f\ud8f4\udf3f\ud90a\udfe2\ud8ff\udc50\udb39\udc06\ud960\udca7\uda66\udde8\uda32\udfac", "\u343d\u5ea7\u7cc6\u66e8\u9938\u640b\u6900", "\ud54c\ud8b8\ude2d\ud879\udc5c\udb17\udf4d\udb67\uddcd\udb25\ude6e\udb5d\ude42\ud9b5\udf2f\uda9f\udf23\ud847\udefe",
        31, 64425, -799942623, -3651007263297761183L, 52324L, true, true, (char) 28057, (char) 44796,
        Double.longBitsToDouble(0x3fcf94ab14915118L), Double.longBitsToDouble(0x3fec145a59027cdcL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\uda68\udd33\ud824\ude13\ud83e\udf3d\u0139\udb41\udd3f\udaf5\udd53", "\u9422\u2dd0\u52cd\u6bb0\u49ec\u9b42\ucc24\u14d7\u15f4\u5ee8\u3cad\u089f\ubd29\u787d", "\ud952\udf38\ud8fd\uddf2",
        11, 27466, -801415804, 1526122818214131112L, 40801L, true, false, (char) 35101, (char) 30027,
        Double.longBitsToDouble(0x3fdc9cca7ff0ea90L), Double.longBitsToDouble(0x3fbceed9071d3238L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 9, "\ud8fa\udcdf", "\u7b14\uaf77\ud198\u8b07\u9bf6\uac1d\u60ba\u7ad9\u6bb0\ua4ec\u85f7\u8b2e\u14d7", "\udb5e\udc61\uda56\udc9b\u8621\ud839\udc54\ud943\udfc5\udb53\udff8\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\udb4e\udd85\ud9f8\udd94\udb2b\udfa4\uda50\ude5f\uda96\udc6d\uda32\udfac",
        50, 5216, 1967685948, -4943729769787717517L, -50792L, false, true, (char) 16946, (char) 64189,
        Double.longBitsToDouble(0x3fe1096b476644afL), Double.longBitsToDouble(0x3fef6aa189b0baffL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud8fa\udd25", "\u9b05\ub064\ud198\ua436\u9bf5\uac1d\u60ba\u7ad9\u6bb0\ua4ec\u9307\u8b2e\u14d7", "\ud9d2\udedb\uda41\udc03\ud930\udf8e\udbba\udeca",
        -1, 15433, -771430507, 8910651734479453647L, 30959L, true, true, (char) 41936, (char) 21942,
        Double.longBitsToDouble(0x3fe1a9a5d9700c9cL), Double.longBitsToDouble(0x3f9631b564b3db60L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 0, "\ud94d\ude1a", "\ud76a\u8ff7\000\u0897\u3ea5\000\u605c\uad08\ua7b3\000\000\000\ucda0", "\000",
        -5, -1000, -684909056, 2499688806593069056L, 96981L, true, false, (char) 11520, (char) 24210,
        Double.longBitsToDouble(0x3fb5561a00000000L), Double.longBitsToDouble(0x3fd0000003ff93a2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 3, 8, 0, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\u3bb4\uabb9\u5e0a\u6b60\u9586\u93ad\u8b2e\ucadf\u9cf3\u5ee8\u46ad\uc3ae\ubd29\u979e", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f",
        -5, 75811, 355328085, 104145258112208273L, -59442L, true, false, (char) 61452, (char) 17137,
        Double.longBitsToDouble(0x3fefc3aa4073bb64L), Double.longBitsToDouble(0x3fcc74c8f17b8428L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 8, 1, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\u4e97\ub22d\u7ad9\u6bb0\ua4ec\u9307\u8b2e\u14d7\u15f4\u5ee8\u46ad\uc3ae\ubd29\u7650", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\ud9d7\udd83\ud9f8\uddb8\udb2b\udfa4\uda50\ude5f\uda96\udc6d\uda32\udfac\ud802\udc20",
        26, 2948, -1151051784, -6465048712144310045L, -33595L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fb3a4078c7bb330L), Double.longBitsToDouble(0x3fea241640ed5431L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 2, 7, 5, "\ud8e7\udc34\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uac1d\u60ba\u7ad9\u6bb0\ua4ec\u9307\u8b2e\u14d7\u15f4\u5ee8\u46ad\uc3ae\ubd29\u7650", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d\ud9f8\udd94\udb2b\udfa4\uda50\ude5f\uda96\udc6d\uda32\udfac\ud802\udc80\ud8e5\uddc4\ud976\udc25\udbbe\udfec\ud98e\udf29\udbc5\udf0f\uda62\udd12\ud92f\udd17\ud949\udd03\udae2\udf2e\ud848\udd0b\ud54c\ud8b8\ude2d\ud879\udc5c\udbf9\udd9f\uda96\ude29\udafb\udf57\udb93\udf94\ubef0\ud817\ude58\uda46\ude37\ud806\udf58\uda83\udfd6\ud815\udf0e\ud8cf\udecd\ud846\udeb8\ud972\udc50",
        26, 53462, -321318578, 2000541992556535691L, -2018L, false, true, (char) 32274, (char) 47866,
        Double.longBitsToDouble(0x3fea34b89ed6fa12L), Double.longBitsToDouble(0x3fd5b8fe948f4f12L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-14, -11, -27, 92, 108, -19, 15, -46]]\012",
        Z.run(T, 1, 4, 8, 1, "\ud922\udc25\ud815\udf8c\udb9c\udd1d\uda3f\ude02\udbd2\udc46\udaf5\udd53", "\uac1d\u60ba\u7ad9\u6bb0\ua4ec\u9307\u8b2e\u14d7\u15f4\u5ee8\u46ad\uc3ae\ube5d\ud49d", "\ud90f\udcdf\ud8a5\ude03\udb81\udc16\uda5a\udec3\udb23\udd8d\ud9f8\udd94\udb2b\udfa4\ud8b1\udcc5\uda96\udc6d\uda32\udfac\ud802\udc20\ud9cf\udcb8\ud8f4\udd6b\ud878\udfa4\ud98e\udf29\ud94e\udc32\ud922\udf92\ud94e\udf72\ud949\udd03\udae2\udf2e",
        24, 74759, 1152349729, 6066673493354106861L, 38335L, true, true, (char) 1856, (char) 2764,
        Double.longBitsToDouble(0x3fec0c9c9335e7b5L), Double.longBitsToDouble(0x3febd844ac434c46L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\u5b94\ud815\udece\ub887\ud954\udc05\u8ff7\u00df", "\uac1d\u60ba\u7ad9\000\uc95e\u5e0c\000\ucda0\u15f4\u5ee8\u46ad+\ubcc8\u5850", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f\ud988\udcaf\000\ud9f8\udd3f\udb2b\udfa4\uda50\ude5f\uda96\udc6d\uda32\udfac\ud8be\udc3e",
        -5, -1000, 0, 20134750849073152L, -100000L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f6212d68L), Double.longBitsToDouble(0x3feb32257fed5431L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 0, 6, "\uda07\udc8c\ud93b\udeca\udad5\uddd4", "\ud198\ua436", "\uda49\udf58",
        -4, 84883, -1195325090, 8073404083583388864L, 69358L, true, false, (char) 9723, (char) 56258,
        Double.longBitsToDouble(0x3fd616d46d6649e2L), Double.longBitsToDouble(0x3fdbad72dbea4560L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-54, -11, -27, 92, 87, -38, 21, 106]]\012",
        Z.run(T, 1, 5, 5, 1, "\ud8fa\udd25\ud815\udf8c\ub887\ud90a\udf45\udb9a\udcfb\udb24\udd42", "\uac1d\u8280\u30cf\u783c\ub69e\u0cb0\uab59\ua817\u15f4\u5ee8\ub572\uc3ae", "\ud943\udf69\ud830\udc26\ud90f\udcdf",
        44, 66063, 1580871084, 6514694733815472220L, 18161L, true, true, (char) 21942, (char) 56559,
        Double.longBitsToDouble(0x3fd70fe9c279836aL), Double.longBitsToDouble(0x3fefc3aa4073bb64L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud8fa\udd25\ud815\udf8c", "\ub064\ud198\ua436\u9bf5\uac1d\u60ba", "\ud84d\udd2b",
        19, 55640, -712968395, 8911034259131138617L, 82827L, true, true, (char) 17316, (char) 34023,
        Double.longBitsToDouble(0x3feac9158795c6b8L), Double.longBitsToDouble(0x3feb729e8dcf7ba8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 8, 1, "\ud979\udcc3\udbdd\udde7\ud828\udd4e\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uac1d\ua51e\u7ad9\u6bb0\u21ab\ud7b9\u07b0\uc3e8\u344a\u5ee8\u2221\uc466\ud1e7\u55fc", "\uc3f0\ud968\udcea\uda90\udd7f\uda28\udf39\ud9de\uddcb\ud9f8\udda6\udaf4\udca4\ud8cb\udd5f\uda96\udc6d\uda32\udfac\ud802\udc20",
        26, 2948, 711219192, -8542896991161898449L, 65221L, true, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f6212d68L), Double.longBitsToDouble(0x3feb32257fed5431L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 3, 0, 0, "", "", "\000\udacf\udc67\u0091",
        42, 87552, 1426782, 0L, -1184L, false, false, (char) 14690, (char) 16257,
        Double.longBitsToDouble(0x3fe48a69a9d22c29L), Double.longBitsToDouble(0x3fe1588cc1000046L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-54, -11, -27, 92, 87, 36, -43, -94]]\012",
        Z.run(T, 1, 6, 4, 6, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uc281\u60ba\u0258\u6bb0\ua4ec\u9307\u8b2e\u14d7\u15f4\u35e8\ud790\u1ba9\u07c3\u43ac", "\ud90f\udcdf\uda55\uddd4\uda9f\udfd6\uda28\udf39\udb23\udd8d\ud9f8\udd94\udb2b\udfa4\ud9f5\udeb9\uda96\udc6d\udbc1\udf53\ud802\udc20",
        26, 2948, -1151051784, 5928857463248306006L, 23198L, true, true, (char) 26177, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f60b44abL), Double.longBitsToDouble(0x3fe8675f3a326ef2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 8, 2, 5, "\udb47\udc0d\ud815\udf81\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uac1d\u60ba\u508a\u69a3\ua4ec\u90a7\u1e84\u1579\ua3fa\u4fd2\u5701\uc3ae\ubd29\u7650", "\ud90f\udcdf\udad0\udf92\uda8f\udff1\uda28\udf39\udb23\udd8d\ud82c\udf57\uda3c\udc23\uda50\ude97\udbf9\uddb8\ud948\udfde\udbd9\uddbd",
        47, 30652, 18073229, -6465158773255118109L, -33595L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f6212d68L), Double.longBitsToDouble(0x3feb32257fed5431L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 6, 9, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d", "\u9bf5\uac1d\u60ba\u7ad9\u6bb0\ua4ec\u2fbf\u8b2e\u681b\u15f4\ub6d7\u46ad\uc3ae\ubd29\u7650\u5ed7\u6f75\ub115\u8cfe\u3721\ub533\u8120\u50f0\u2c98\uad51\u1fd8\uad30\u64df\u96ae\u155e\u5470\u861c\u50ef", "\ud949\udd03\udae2\udf2e\ud848\udd0b\ud98c\udd77\ud8b8\ude4f\ud879\udc5c\ud8e6\ude96\ud87b\udf5d\ud93b\udf42\ud91e\udd2d\udad9\udf8e\udb0b\udf64\ue6c7\ud9e4\ude95\ud8df\udc75",
        43, 1173, 1928698725, -7994757937091379479L, 54192L, false, true, (char) 9872, (char) 65115,
        Double.longBitsToDouble(0x3fc7ef6a4e02f8b8L), Double.longBitsToDouble(0x3fea228789da4b7dL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 8, 9, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\ucc51\u5f3f\u68d8\u33e7\ub3ce=\u8b2e\u14d7\u15f4\uc771\u46ad\u7a32\u874c\u1ccf", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd57\ud9f8\udd94\udb2b\udfa4\uda50\ude5f\uda96\udc6d\uda32\udfac\udb29\udec8",
        56, 2948, -154245896, -6465048713083834141L, -33595L, true, false, (char) 46360, (char) 16943,
        Double.longBitsToDouble(0x3fd9f901e6948c1cL), Double.longBitsToDouble(0x3feb3767b719dbffL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 1, "\000\ud815\udf8c\ub887", "\u21e5\u38a5\u7d2a\uba66\u4500\000\000\000\u92ca\u262f\u14d7\u15f4\u5ee8\u46ad\uc3ae\ubd29\u7650\u5ed7", "\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d\ud9f8\udd94\udacd\udf95\uda50\ude5f\ud9ac\udd39\uda32\udfac\ud802\udc20\ud8e5\uddc4",
        28, 44216, -1505261453, -2230776177694808994L, -50792L, false, true, (char) 16943, (char) 29539,
        Double.longBitsToDouble(0x3fe1096b476644afL), Double.longBitsToDouble(0x3fef6aa18850a930L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 5, "\ud91e\udd56\ud804\ude3c\ub887\ud9a0\udccf\udb9d\udcc7\udaf5\udd53\ud8d9\udc70\ud9dd\udceb\u44df\uda5a\udc51\ud854\udc5f\uda62\udeae\ud84d\udd2b\ud917\udcd7\ud952\udca6\ud8b9\udd92\ud8dd\udee2\ud9a4\udcb8\ud9ce\uddda\uda56\udc9b\ud925\udfbc\ud839\udc4b\ud943\udfc5\ud993\udff4\uda54\udd6f", "\ua559\u44f7\u2191\u3701\ucd59\u1d82\uaf26\u3874\uc2cc\ub6b3\ua84a\u5046\u54b3\u8246\u635b\ua1bf\u65cd\u0e43\u0c33\u9342\ud2e2\u1519\u3f43\u2368", "\udbae\udd5f\ud833\udfc1\uda32\udc53\uda88\ude41\ud871\udf3f\udb05\udd06\ud8a9\udcf6\ud813\udf70\udb55\uddc4\ud8bb\udcab\ud8a4\udfaf\udb44\ude4d\ud88c\udea5\ud9d5\udf81\udb16\udcb6\ud994\udcd4\uf420\uf8ec\ud98a\udc9b\uda48\ude15\udb05\udc10\udaa9\udf92",
        30, 56160, 1224313051, -8670510691925265559L, 26515L, true, true, (char) 21240, (char) 8720,
        Double.longBitsToDouble(0x3fd519372aecd84aL), Double.longBitsToDouble(0x3fef01e8d3e6f66fL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-48]]\012",
        Z.run(T, 1, 6, 4, 1, "\000", "", "\udaf5\udd53\000\ud977\ude3b\udb0a\uddfb\uda59\udff3\ud854\udc5f\000\ud84d\udd2b\ud917\udcd7",
        15, 8933, -1703389986, -88628561118172975L, -13631L, true, false, (char) 34023, (char) 30217,
        Double.longBitsToDouble(0x3fecae35c68bd204L), Double.longBitsToDouble(0x3fd807ba8b596dbaL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 0, 3, "\ud8fa\udd25\ud815\udf8c\ud8e9\udea4\uda16\udd4a\udb9d\udcc7\udaf5\udd53\ud8d9\udc70\ud9dd\udceb\u44df\uda5a\udc51\ud854\udc5f\uda62\udeae\ud814\udc2a\ud847\uddbe\uda4c\ude42\udadf\ude35\ud8dd\udefe\ud9a4\udcb8\ud9ce\uddda\ud977\udd4f\ud931\udc11\ud839\udc4b\u74d3\udb55\udea5\ud90f\udcdf\udb6f\ude01\uda90\udcfb\uda28\udf39\ud903\udeac\u6413\udb1d\udd60", "\ud5f1\u8dbb\u2216\ub6b3\ua134\u09a0", "\ud94e\udf73\uda36\udc88\udbc6\ude0a\udbf3\udd0c\u3771\ud9b8\udded",
        52, 17197, -423256701, -3063102670678356706L, 10200L, false, false, (char) 5333, (char) 34058,
        Double.longBitsToDouble(0x3fe58278efd25721L), Double.longBitsToDouble(0x3fea960f3b055ed4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[]]\012",
        Z.run(T, 1, 6, 8, 1, "", "", "\udb9d\udcc7\udaf5\udd53\ud8d9\udc70\ud9dd\udceb\u44df\uda5a\udc51",
        37, 84704, -1195325090, 8073404083583388864L, -40399L, true, false, (char) 48807, (char) 17316,
        Double.longBitsToDouble(0x3fdbad72d6b24560L), Double.longBitsToDouble(0x3fecae35c68bd204L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 1, "\ud8fa\udd25\ud815\udf8c\ub887\uda16\udca7\udb9d\udcc7\ud8d7\udec4\ud8db\udda7\ud9dd\udceb", "\u54da\u6bb0\ua4ec", "\ud8b9\udd92",
        9, 68555, 295233745, 7874203285156090209L, 14663L, false, true, (char) 50371, (char) 62874,
        Double.longBitsToDouble(0x3fd4b44cdb2202e2L), Double.longBitsToDouble(0x3fdffc9d1122da4aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 5, 0, 0, "", "", "\udb9d\udcc7\u00df",
        -5, -1000, 0, 0L, -99808L, true, true, (char) 14620, (char) 47939,
        Double.longBitsToDouble(0x3fca3fd8a8ac4660L), Double.longBitsToDouble(0x3fd616d46d6649e2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 8, 1, "\udb9e\udf57\ud815\udf3f\ub887\uda16\udca7\udb9d\udcc7\udaf5\udd53\udb5d\udc72\udba6\udde2", "\u54da\u6bb0\ua4ec", "\ud8b9\udd92",
        9, 68555, 295233745, 7874203285156090209L, 16043L, false, false, (char) 13367, (char) 4814,
        Double.longBitsToDouble(0x3f92d9aa8f0448a0L), Double.longBitsToDouble(0x3fe911fd6b429f33L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 9, "\ud8fa\udd81\ud815\udf8c\ub887\udbe6\udc6e\udbe3\udc36\udaf5\udd53\ud9d8\udf48\udbbc\udd83\udb70\udc06", "\u43ef\ua4ec", "\udb7b\udcb3\udb35\udefe\udba1\udcee\ud9d2\udef5",
        4, 57785, -684908877, 2499521208391324505L, 31345L, true, true, (char) 2503, (char) 53070,
        Double.longBitsToDouble(0x3fb78363aea8fc08L), Double.longBitsToDouble(0x3fec761a39ffc991L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 0, "\ud8fa\udd25\udb90\ude28\ub542\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uac1d\u60ba\u7ad9\u4b46\ua4ec\u9307\u8b2e\u14d7\u15f4\u0582\u76b0\ub2b5\u03ef\uafe1", "\ud90f\udcdf\uda55\uddd4\uda68\udc6b\udb31\udd60\ud9bf\udc7a\ud958\udf89\ud858\udf61\uda50\ude5f\uda96\udc6d\ud952\udf5d\ud802\udc20",
        26, 2948, -1151051784, -6465048713083834141L, 22539L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc8586212d68L), Double.longBitsToDouble(0x3feb32257fed5431L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 9, 8, 8, "\ud8fa\udd25\ueb8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uac1d\u60ba\u7ad9\u6bb0\ua4ec\u9307\u8b2e\u14d7\u4fa8\u3115\u46c7\ua850\u4ce9\u9add", "\ud90f\udcf7\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d\ud966\ude2b\ud858\udf61\uda50\ude5f\uda96\udc6d\uda32\udfac\ud802\udc20\udab1\udf6a\ud976\udc25\udbbe\udfec\ud98e\udf29\udbc5\udf0f\udb27\udfd5\ud94e\udf62\ud949\udd03\ud83e\udcfc\udb0d\udcd0\uda70\uded8\ud8c0\udde1\ud879\udc5c\udac4\udd65\udb0d\ude50\ud9e5\ude29\uda5a\udf68\udbc4\udccb\ud980\ude46\uda63\udde0\uda91\udcc6",
        17, 63367, 1052794890, -1679066659285379962L, -79861L, true, false, (char) 61399, (char) 52135,
        Double.longBitsToDouble(0x3fe26b06e0d80cb3L), Double.longBitsToDouble(0x3fc7d1289fdbeb8cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-54, -11, -27, 92, -88, -37, -48, 126]]\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-54, -11, -27, 92, -88, -37, -48, 126]]\012",
        Z.run(T, 2, 4, 4, 5, "\ud8fa\udd25\ud815\udf8c\ud8d8\udc0b\000\udbae\udd36\udaf5\udd53", "\uac1d", "\ud926\udef2\ud94a\udd69\ud917\udc9a\u0cc0\000\udb35\udefe\udba1\udcee",
        59, 2819, 619794785, -2941661226873082438L, -100000L, false, false, (char) 0, (char) 57428,
        Double.longBitsToDouble(0x3feea8f96d91b471L), Double.longBitsToDouble(0x3fdffc9d1122da4aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 8, 9, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53", "\uac1d\u60ba\u47e1\ube0a\ua4ec\u810c\u3eca\u14e2\u15f4\uaa2a\u46c7\uc3ae\ubd29\u7650", "\ud90f\udcdf\ud800\udf6a\uda90\udd7f\ud8ca\udc6f\udb23\udd8d\ud94b\udf34",
        10, 62529, 1093870965, 3817620520415569973L, -62404L, false, false, (char) 50536, (char) 44979,
        Double.longBitsToDouble(0x3fee475a356058c7L), Double.longBitsToDouble(0x3fed1b14629f901eL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud8a6\udde5\ud813\udfa9\ub887\ud954\udc05\udaeb\uddd9\udaf5\udd53", "\ubcf0\u4341\ucf0b\u6bb0\u9c55\u5547\u0ff2\u14d8\u15f4\uaa2a\u46c7\uc3ae\ubd29\u7650", "\ud90f\udcdf\udbad\udf57\uda90\udd7f\uda28\udf39\udb23\udd8d\ud966\ude2b\uda2c\udcaa\uda9d\udde6\uda61\udf27\uda7f\udc3f\ud93c\udf82",
        26, 2948, -1151051784, 4797891004783507317L, -33595L, true, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f4d62d68L), Double.longBitsToDouble(0x3fe474ff896bf421L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-54, -11, -27, 92, 87, 36, -43, -94]]\012",
        Z.run(T, 2, 3, 6, 9, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbd2\udd2d\udaf5\udd53\ud8d9\udc70\ud9fd\udefb\uad20\uda5a\udc51\ud827\ude5f\udb5e\udfd4\ud82b\udd02\ud917\udcd7\udbcc\udcde\udb7b\udcb3\udb35\udefe\udba1\udcee\ud9d2\udef5\uda56\udc9b\ud930\udf8e\ud839\udc4b\ud943\udfc5\udb53\udff8\udba9\udcac\udb4d\udc90\ud864\udf78\uda6f\udf97\udb23\udd8d\udb95\ude58\ud858\udf61\uda50\ude5f\uda96\udc6d", "\u879c\u343d", "\ud9e6\udc1f\ud85d\udda3\udb6a\udcce\uda4a\udd5f\ud851\udde8\ud84c\udd63\ud54c\ud8b8\ude2d\ud879\udc5c\ud8ef\udeba\uda5f\ude98\ud8a0\ude3f\uda08\udec6\ud8a1\udc00\ud91a\udf05\ud823\ude79\ud8df\udfc8\udae8\udc90",
        -2, 58143, -2110139655, -7829104020321777812L, 98609L, false, true, (char) 15538, (char) 11734,
        Double.longBitsToDouble(0x3fc1fb45be57f604L), Double.longBitsToDouble(0x3fe330b62f90ba7dL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 7, 8, 9, "\ud8fa\udd25\ud815\udf8c\uda68\udc83\ud954\udc05\ud943\udee5\udb89\udd50\ud9d9\ude4b\ud9da\udee8\udbe3\ude19\uda5a\udc51\ud827\ude5f\uda62\udeae\ud84d\udd2b\ud917\udcd7\ud952\udca6\udba7\udfee\udb06\udd01\udae1\udd15\ud835\udf88\ud84d\ude21\udb2a\udf8b\ud839\udc4b\ud943\udfc5\udb54\udc4a\ud9d9\udea4\uda55\udde1\udb42\udda9\uda4c\uddce\udb7a\udd60\udae4\udc97\ud858\udf61\uda50\ude5f\uda96\udc6d", "\u879c\u343d", "\ud83a\udd20\ud889\udc14\udaad\udc49\udbcd\ude33\udae2\udf2e\ud9db\ude06\ud955\udfae\ud8b8\ude4f\udbb4\ude70\udbb2\udd1b\ud922\ude5f\ud83b\udc91\udb29\uddb5\uda3f\ude24\udbd8\udf40\uc2a5\udb59\udf49\uda46\udfb5\ud863\udee7\ud947\udd68\uda3d\udf83\ud931\udeab\ud936\ude0c\uda5f\udc91\udb79\udcfd\ud9fd\udc09\ud9d4\udccb\udba7\udcfc\uda2b\udea8\udb62\udd58\udb74\ude0b\uda64\udd34\ud9db\udd4c\ud846\udeaf\uda48\udef9\ud854\ude13\ua757\ud8eb\udc65\ud839\udf57\ubc55\uda67\udff0",
        19, 59000, -737325951, 5286586253504448954L, -57611L, true, true, (char) 15154, (char) 60413,
        Double.longBitsToDouble(0x3fe92dfd50ebc3e0L), Double.longBitsToDouble(0x3fe34507cf091db4L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 6, 7, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udb1a\udd31\udaf5\udd53\ud8d9\udc70\ud9dd\udceb\ud82d\udcec\uda5a\udc51\ud827\ude5f\uda62\udeae\ud84d\udd2b\ud917\udcd7\ud952\udca6\udb7b\udcb3\udb35\udefe\udba1\udcee\ud9d2\udef5\uda56\udc9b\ud930\udf8e\ud839\udc4b\ud943\udfc5\udb53\udff8\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d\ud966\ude2b\ud858\udf61\uda20\udf07\uda96\udc6d\uda32\udfac\ud802\udc20\ud8e5\uddc4\ud976\udc25\uda5d\udc3a\ud98e\udf29", "\u643e\u6900\u622c", "\ud8b8\ude2d",
        29, 7397, 1142368767, 5501969905339682757L, 83880L, true, true, (char) 45029, (char) 44427,
        Double.longBitsToDouble(0x3fe8dc3fdc0ea23cL), Double.longBitsToDouble(0x3fdf0cbd2bf620a4L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 8, 7, "\ud8fa\udd25\ud815\udf8c\ub887\uda70\uddb3\udbd2\udcc2\udaf5\udd53", "\u23d1\u1b7a\u3003\u6bb0\ua4ec\u9307\u8b2e\u14d7\u15f4\uaa2a\ua7b5\u8917\u68a3\u7650", "\ud90f\udcdf\uda55\uddd4\udb2b\udf8d\uda28\udf39\udb23\udd8d\ud966\ude2b\ud858\udf61\uda50\ude5f\ud806\udec6\uda24\udc2e\ud802\udc20",
        13, 99150, -1151051784, -6465048713083834141L, -33595L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe71940f1212dc6L), Double.longBitsToDouble(0x3fe9d7bf47ed5431L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 8, 1, "\ud898\ude5b\ud9c4\udd36\uda99\udcc7\ud954\udc05\ud81c\uddf2\ud8b1\udc22", "\u7bfa\u60ba", "\udaa3\udd8b",
        32, 43482, -1294282804, 5563470052372091537L, 82827L, true, true, (char) 48723, (char) 47430,
        Double.longBitsToDouble(0x3feac9132f95c6b8L), Double.longBitsToDouble(0x3fe45e9025cf7ba8L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\uda68\udd33", "\000\000\000\000\u1946\u9422\uccb5\u522e\u6bb0", "",
        36, 90605, 1295346290, 3182235763477114834L, 75775L, false, false, (char) 55325, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3cf6800000000000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 0, "\u0094", "", "",
        -5, 55864, 16037, 840287488L, -100000L, false, false, (char) 0, (char) 16371,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 3, 8, 0, "\ud8fa\udd25\udb5b\uddb0\udb8e\udde8\ud988\udc3b\udbd2\udd2d\ud844\udf1b", "\u3bb4\uabb9\u5e0a\u6b60\u9586\u933d\u8b2e\ucadf\u02b0\u5f1a\u467d\uc3ae\ubd29\u979e\u3ded\ud5b3\ub115\u111b\u3721\u130b\u6335\u14af\uaed1\u0722\uba5a\u5214\u31ba\u753e\ucb0c\u5897\u996f\u76ca\u0641\u0806\u56e6\u0cb7\u9b93\u2bba\uc0ef\uaa7f\u9532\uc2e1\u9ad2\u941c\u9934\u8bdd\u5c3a\u9884\u8403\u5ae4\u9411\u247e\u8875\u40ed\ubc3b\u67d6\u3766\u8fab\ucc4c\u0372\u1dc4\u9eb4\u3270\u712d\uabc9\u2354\u5145\u4da5\u8883\uba27\u1ba9\ud6c4\u9499\ua781\u8ece\ubb71\u0695\u6c7c\u2910\ua480", "\ud882\ude04\uda5e\uddfe\udb5d\udec4\ud8d7\udcfc\ud978\udd8b\udafe\udd7e\ud86e\udff1\ud840\ude5b\uda91\udfd3\ud9ff\udd3f\udabb\uddf4\udb08\udc9e\uda0e\udede\udabc\udd19\udb37\udee4\ud8e7\ude4b\ud80b\udf78\u0f47\ud870\udc6e\ud83d\udef4\udb8a\udca8\uda49\udfa1\ud88a\uddbd\udba2\ude63\ud83c\uded1\ud900\udf2f\ud9fa\udd95\ud807\udcfc\ud93b\udc58\uda31\udccd\udb00\udcaf\uda15\udce4\ud881\udc93\udb6d\udebc\uda06\udcdf\ud908\ude8f\ud86a\udfd2\ub05d\udbad\udcbe\uda00\udc50\uda23\udea8\ud85c\udee8\ud874\udcc5\uda63\udde7\ud920\udd2e\udbd2\ude9c\uda09\ude9d\ud84e\udcae\ud97f\udfa7\ud8ea\udcc7\ud966\ude4f",
        22, 9060, -818855215, 9005705870224110974L, 92795L, true, true, (char) 12448, (char) 2391,
        Double.longBitsToDouble(0x3f9d04511ffd99a0L), Double.longBitsToDouble(0x3fdfd2a2a462ea24L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-54, -11, -27, 92, 87, 36, -43]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 9, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05", "\ua3be\u0c2b", "\uda3d\udd8c\udb45\udd3d\ud84d\udd2b",
        32, 27521, -622358690, 5563469953284936337L, 82827L, true, true, (char) 17316, (char) 34023,
        Double.longBitsToDouble(0x3feac9158795c6b8L), Double.longBitsToDouble(0x3fe45e9025cf7b91L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 9, "\ud8fa\udd25\ud9ff\udfdb\uda4c\udd5f\ud954\udc05\udbd2\udd2d", "\u9bf5\uac1d\u60ba\u7ad9\u6bb0\ua4ec\ubab6\u8b2e\u681b\u15f4\ub6d7\u46ad\uc3ae\ubd29\u7650\u5ed7\u6f75\u0915\u8cfe\u3721\ub533\u8120\u50f0\u2c98\uad51\ua80e\uad30\u64df\u96ae\u155e\u5470\u861c\u50ef", "\ud949\udd03\udae2\udf2e\ud848\udd0b\ud98c\udd77\ud8b8\ude4f\ud879\udc5c\ud8e6\ude96\ud87b\udf5d\ud800\udcf3\ud91e\udcfd\udad9\udf8e\udb34\udc77\ue6c7\ud9e4\ude95",
        40, 11163, -565496827, 8283697945850472964L, 49712L, false, true, (char) 35317, (char) 9872,
        Double.longBitsToDouble(0x3fd63b8f8d82194eL), Double.longBitsToDouble(0x3fec0798d74450f1L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-54, -11, -27, 92, 87, 36, -43, -106]]\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[-54, -11, -27, 92, 87, 36, -43, -106]]\012",
        Z.run(T, 2, 6, 6, 9, "\ud8fa\udd25\ud815\udf8c\ub887\ud954\udc05\udbc6\udc42", "\u8cc4\uac1d\u60ba", "\udb32\udc7d",
        41, 55640, -836586699, 5563469953284936337L, 82827L, true, true, (char) 17316, (char) 34023,
        Double.longBitsToDouble(0x3feac9158795c6b8L), Double.longBitsToDouble(0x3fe45e9025cf7b91L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[]]\0121=new org.apache.commons.codec.binary.Base32:@? |a1=[B:[[]]\012",
        Z.run(T, 2, 5, 6, 1, "", "", "\udb7e\udcb4\udbac\udf5d\ud8f8\udef4\ud9dd\udceb\ud968\udd0a\udaf4\udc3e",
        44, 47845, -1195325058, 8073404083583388864L, -63461L, true, false, (char) 48807, (char) 17316,
        Double.longBitsToDouble(0x3fe81c372acfb2d3L), Double.longBitsToDouble(0x3fe9f8416a600804L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "", "\u61e2\u5684\u6e00\u00df", "",
        -5, -1000, 0, -1195325184L, -99808L, true, true, (char) 14620, (char) 47939,
        Double.longBitsToDouble(0x3fca3fd8a8ac4660L), Double.longBitsToDouble(0x3fd616d46d6649e2L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\0121=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 2, 6, 6, 0, "", "", "\udb9d\udcc7\u00df",
        -5, -1000, 0, 0L, -99808L, true, true, (char) 14620, (char) 47939,
        Double.longBitsToDouble(0x3fca3fd8a8ac4660L), Double.longBitsToDouble(0x3fd616d46d6649e2L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base32:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud8fa\udd7e\ud815\udf8c\ub887\udb30\udcd4\ud929\udfaa\udaf9\udea9", "\uac1d\u60ba\u7ad9\u6bb0\u5539\u9307\u8b2e\u14d7\u15f4\u5ee8\u46ad\ud428\ubd29\u7650", "\ud90f\udcdf\uda55\uddd4\uda90\udd7f\uda28\udf39\udb23\udd8d\ud9f8\udd94\udb2b\udfa4\uda50\ude5f\uda96\udc6d\uda32\udfac\ud802\udc20",
        26, 2948, 656832760, -6475852492863524637L, -33595L, false, true, (char) 26151, (char) 16943,
        Double.longBitsToDouble(0x3fe4fc80f6212d68L), Double.longBitsToDouble(0x3feb32257fed5431L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base32|decode|[B,int,int,org.apache.commons.codec.binary.BaseNCodec$Context|new:org.apache.commons.codec.binary.Base32:",
    "M|org.apache.commons.codec.binary.Base32|encode|[B,int,int,org.apache.commons.codec.binary.BaseNCodec$Context|new:org.apache.commons.codec.binary.Base32:",
    "M|org.apache.commons.codec.binary.Base32|isInAlphabet|byte|new:org.apache.commons.codec.binary.Base32:",
    "C|org.apache.commons.codec.binary.Base32|<init>|int",
    "C|org.apache.commons.codec.binary.Base32|<init>|int,[B",
    "C|org.apache.commons.codec.binary.Base32|<init>|int,[B,boolean",
    "C|org.apache.commons.codec.binary.Base32|<init>|int,[B,boolean,byte",
    "C|org.apache.commons.codec.binary.Base32|<init>|",
    "C|org.apache.commons.codec.binary.Base32|<init>|byte",
    "C|org.apache.commons.codec.binary.Base32|<init>|boolean",
    "C|org.apache.commons.codec.binary.Base32|<init>|boolean,byte",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
