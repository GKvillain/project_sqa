package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base64InputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb23\udeed\udabb\udf2a", "\uba2c\u6c11\ud2ff\u6ce1\u410d\uba69", "\udb5f\udeb6",
        35, 16428, -1259699841, -660286123796283451L, 50300L, false, false, (char) 57563, (char) 29604,
        Double.longBitsToDouble(0x3fd42b66905cf11cL), Double.longBitsToDouble(0x3fe0c0bbe226a09dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb7b\ude78\udabb\udf2a", "\uba2c\ub42c\uc758\u6d62\u410d\uba69", "\udb5f\udeb6",
        35, 16428, -1259699841, -660286123796283451L, 50300L, false, false, (char) 57563, (char) 29604,
        Double.longBitsToDouble(0x3fd42b66905cf11cL), Double.longBitsToDouble(0x3fe0c0bbe226a09dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 6, "\uda8b\udf7c\udbb8\udd3c\ud9f1\udd7e\ud983\udfda\uda82\uddd0\ud9b8\ude78\uda67\udf81\ud8d7\udf67\ud95e\udc6b\udb79\uddde\udb78\udcf5\ud920\uddd6\uda8d\udeee\udabb\udf12", "\uba2c\u6c11\u4a27\u1c54\u40d5\uba69", "\udb5f\udeb6\uda88\udc1b\ud907\udd53\udaca\udfd4",
        20, 82077, 802955365, -1758010122264955306L, 50732L, false, true, (char) 32956, (char) 57747,
        Double.longBitsToDouble(0x3fe13504eda8144eL), Double.longBitsToDouble(0x3fe8bb2e248df8b0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 4, "\uc2d1\udb40\udc6c\ud8fd\udc0a\ud963\ude7a\uda87\udfc7\ud8b9\udd72\ud9b0\udeba\udb65\udc20\uda14\ude10\udb3a\udc55\udb7f\udc6e\uc38f\udb23\udeed\udabb\udf2a", "\uba2c\u66bb\ud2ff\u6ce1\u410d\u0a7e", "\uda14\udfbc\uda88\udc1b\ud817\udd5b\ud8c5\udfbf\udaf8\udcba\uda6d\udcc3\udb61\udc2a\udbb8\udefd\uda9b\udce1\ud80f\udf10\udb3f\udedd\udb18\udc5c",
        24, 72152, 1123156518, 3931372282083620230L, 60144L, true, true, (char) 42469, (char) 35410,
        Double.longBitsToDouble(0x3fec8280bc6a95b3L), Double.longBitsToDouble(0x3fd55ff3ba99b990L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "\udaa1\udebf\udbb8\udd3c\ud847\udf8d\uda6d\ude82\uda17\udeed\uda58\udfdb\udb37\udf1e\ud85d\udd17\ud8d2\udece\udb1b\ude83\udbe8\udd26\ud9bd\udc64\ud8ae\udff2\udaba\udcf2", "\u424a\u542a\u22e1", "\ud9ec\udf2b\udb0b\udfb6\udb3d\udd1c\udb5f\udeb6\uda87\udfdf",
        43, 72159, -153734843, -3674726441167302811L, 79565L, false, true, (char) 2277, (char) 5268,
        Double.longBitsToDouble(0x3fe13504ed21952aL), Double.longBitsToDouble(0x3fde8a75ff32f184L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\udace\uddc2\ud8e5\udf39\udb79\udde4\ud9d5\udeb6\ud9d7\udcf3\udb23\udeed\udabb\udf2a\udae5\udc4f\uda94\udd5b\uda04\ude90\ud9e4\udd46\uda44\udd44\ud8b8\ude32\u933d\ud9d5\udf2b\uda12\udd99\ud9ba\uddb7\udb5f\udeb6\uda88\udc1b\ud907\udd53\ud8c7\udd12\udaf8\udcba\uda6d\udcc3\ub337\udbb2\uddab\udb3c\udd8d\ud80f\ude41\udb3f\udedd\udb18\udc5c", "\u586e\u0865\u82f0\u954e\u37cd\u3fdb\ub0f4\u4249\u49fa\uc8f6\u486e\u6a45\u6353\u26f9\u7e65\ud4bb\u0ae5\u076c\u4d99\u0a84", "\ud857\udf39\ud959\ude3b",
        34, 42067, 1391011781, 4084841679357295019L, -7144L, false, true, (char) 60929, (char) 14570,
        Double.longBitsToDouble(0x3fd4be4c9026c7b6L), Double.longBitsToDouble(0x3fdd1fa361011b72L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 4, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\ud926\ude30\udbce\udeec\uda90\udef0\udb79\uddde\ud9d2\udc95\ud9d7\udcd5\udb23\udeed\udabb\udf2a\ud9d5\udc47\uda94\udd5b\uda04\ude90\ud9e4\udd46\uda44\udd44\ud8a4\udcce\u933d\ud977\udfb1\uda63\udd85\ud9ba\ude41\udb5f\udeb6\uda88\udc1b\ud8cd\udc23\ud8c7\udd63\udaf8\udcba\ud94d\udd92", "\uce29\u76aa\u9bfc\u6024\u1fc3\u510b\u00bd\u1cb1\u9332\ub6cf\u7060\u036d\u8430\u5ff4", "\udba5\udca0\ud8fe\udea6\ud92e\udc69\uda7e\udce1\udb49\udc2a\ud86e\udc4f\ud985\udf57\ud95a\udf7f\ud87b\udc4b\ud811\udc1f\uda54\ude6c\ud917\ude5d\ud899\udd4e\ud9e6\ude2a\ud931\udd75\uda80\udf07\udb0d\udeff",
        18, 69067, 1169532341, -2554792325359360857L, 17949L, true, false, (char) 33595, (char) 1467,
        Double.longBitsToDouble(0x3fd5d17d1a9ef6daL), Double.longBitsToDouble(0x3feffee972307d93L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 3, "\uda8b\udf7c\udbbe\udebe\ud9d5\udc59\uda55\udf74\ud92e\udf1c\ud9fb\udfb9\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb23\udeed\udabb\udf2a\udae5\udc4f\uda94\udd5b\uda04\ude90\ud9e4\udd46\uda44\udd44\ud8b8\ude32\u933d\ud9ec\udf2b\uda12\udd99\ud9ba\uddb7\udb5f\udeb6\uda88\udc1b\ud907\udd53\ud8c7\udd12\udaf8\udcba\uda6d\udcc3\ub337\udbb2\uddab\udb3c\udd8d\ud80f\ude41\udb3f\udedd\udacb\uddc3\ud908\udd90\udbf3\udc78\udbf3\udcbe\udbe8\udf4d", "\ucf23\u3053\u274e\uace8\u2222", "\udadb\uddf1\ud89b\udcc3\ud8d3\udf57\ud9d3\udea7\uda22\udf36\ud967\udd9d\udbcc\udc96\ud8b7\udf1a\udb1d\udeb4\ud998\udffd\udadb\udcc7\udbf6\udeb7\ue4e2\ud9c5\udcb7\udbd2\ude42\u2683\uda8d\udca3\ud914\udcdc\ud981\udf00\uda64\ude0e",
        16, 68832, 159019418, -7727287983133056666L, -23119L, false, true, (char) 28909, (char) 37584,
        Double.longBitsToDouble(0x3fc3b82a8915d0b0L), Double.longBitsToDouble(0x3fd68e07b6733d52L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud947\udd9d\ud989\uddad\ud990\udfeb\uda3e\udc7f\ud8d7\udfa5\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb23\udeed\udadd\ude13", "\uba2c\u6c11\ud2ff\u51e1\ua115\u3f69", "\ud89d\udff6",
        58, 16442, -1259699841, -3943871533314687109L, -94278L, false, true, (char) 20271, (char) 29604,
        Double.longBitsToDouble(0x3fd42b66905cf11cL), Double.longBitsToDouble(0x3fe0c0bbe326a09dL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 5, 4, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb23\udeed\udabd\udcca", "\uba2c\u6c11\ud2ff\u6ce1\u410d\uba69", "\udb5f\udeb6",
        35, 82060, 553313142, -2421474456074404168L, 50300L, false, false, (char) 57563, (char) 22692,
        Double.longBitsToDouble(0x3fdbbac3305cf11cL), Double.longBitsToDouble(0x3fe793cbe5e6d094L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 3, 6, "\u5d03\udbb7\udfd8\ud892\udf1a\udb33\udd10\ud9aa\ude78\uda15\udf78\uda3e\udc96\ud809\ude60\udaf9\udc22\udad3\udc65\udaae\udec3\ud9d7\udcff\udb23\udeed\udabb\udf2a", "\uba2c\u6c11\ud2ff\u6ce1\u410d\u7517", "\uda04\ude69",
        57, 16428, -1485078145, -660286123796283451L, -2018L, false, false, (char) 57747, (char) 41667,
        Double.longBitsToDouble(0x3fd1c5d516f2dbf8L), Double.longBitsToDouble(0x3fcdc19f01e69700L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "\ud825\udf20\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udbfd\udf81\ud9c6\udee6\ud9d7\udcf3\ud91d\udd69\udabb\udef9", "\uba2c\u6e11\ud2ff\u6ce1\u410d\uba69", "\udad4\udfa0\uda88\udc1b\ud907\udd53\ud8c7\udd12\udaf8\udcba\uda6d\udcc3",
        25, 33372, -1361365418, -4580105846688992460L, -97906L, false, false, (char) 41667, (char) 54552,
        Double.longBitsToDouble(0x3f9dae4fb44bbbe0L), Double.longBitsToDouble(0x3fbba62581c9a668L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 4, 3, "\uda8b\udf7c", "\uae87", "\uda55\udf52\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb23\udeed",
        51, 49418, -211664358, -7190524079461248080L, 51252L, false, false, (char) 42443, (char) 53764,
        Double.longBitsToDouble(0x3fd36384f45a98e8L), Double.longBitsToDouble(0x3feaf2681f5ad0e9L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 4, 2, 4, "\udab0\udfaf\ud8e2\udecf\ud827\udcb7\ud979\udd46\udaae\udc2d\uda1c\udf19\uda3e\udc96\uda41\udfdc\ud95e\udcc2\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb1b\udd89\uda14\udf5d", "\uba2c\u6c11\ud2ff\u6ce1\u410d", "\ud9ba\uddb7\udb5f\udeb6\ud96f\udcce\udae0\udc90\ud8c7\udd12\udaf8\udcba\uda6d\udcc3\uda46\udc1b\udbb2\uddc1\udb3c\udd8d\ud910\udca0\udb1e\udce8\udb18\udc5c\ud908\udd90\udbf3\udc78\ud83a\udd62\ud9b5\udcf8\udae3\udcf1\ud810\udcf8\udaa1\udea5\ud807\udece\ud920\udf1f\udbaf\udf6e\uda2b\udf56\uda36\udd11\udae0\udf55",
        37, 21860, 925343324, 5197430598478186387L, 50337L, false, true, (char) 55175, (char) 53695,
        Double.longBitsToDouble(0x3fd16e59752e9ae8L), Double.longBitsToDouble(0x3fd94fc50ddf9af6L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 4, 4, "\uda8b\udf7c\uc539\000\ud979\udd46\uda91\udeb9\u00d0\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\ud999\udeee\ud9d5\udeb6\ud999\uddf3\udb23\udeed\udabb\udf2a", "\ub9ba\u6c11\ud2ff\u6ce1\u410d\u9a69", "",
        -5, -1000, -329949696, 545460846592L, -91808L, false, true, (char) 7665, (char) 57563,
        Double.longBitsToDouble(0x3fe9a6038142b669L), Double.longBitsToDouble(0x3fa73c47218177c0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "\ud8b5\udd99", "\uae87", "\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\u8dbe\000\uda29\udfb4",
        51, 49418, -211664358, -7190524079461248080L, 51252L, false, false, (char) 42376, (char) 53764,
        Double.longBitsToDouble(0x3fd36384f45a98e8L), Double.longBitsToDouble(0x3fe2f2681e7cd9aaL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\udb83\udd9e\udb24\udc3d\udaf3\udf1d\udac4\udeef\ud9d7\udcea\udb23\udeed\udabb\udf2a", "\u21f5\u6c11\ud2ff\u6ce1\u410d\uba69", "\udb5f\udeb6",
        35, 44, -1366345504, 8551525909698932654L, 7320L, false, false, (char) 8517, (char) 29632,
        Double.longBitsToDouble(0x3fd42b66905cf11cL), Double.longBitsToDouble(0x3fe0c0bbe226a09dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 3, "\ud8c0\udc96\udbb8\udd2e\ud8c8\udece", "\u2012\u571b\u1dbf\u4e1b\ud213\u6943\u43b7\u920f\u5948\u825d", "\ud9e4\udd46\uda44\udd44\ud8b8\ude32\u933d\ud9ec\udf2b\uda12\udd99\ud9ba\uddb7\udb5f\udeb6\uda88\udc1b\ud907\udd53\ud8c7\udd12\udaf8\udcba\uda6d\udcc3\ub337\ud8d3\udc32\udb3d\udc7a\ud80f\ude41\udb3f\udedd",
        52, 2526, -1600271848, 4751581444781179299L, -11591L, false, false, (char) 32108, (char) 30315,
        Double.longBitsToDouble(0x3fe53ee3fca0d813L), Double.longBitsToDouble(0x3fefac974603e83aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 3, "\uda12\udc77\udbb8\udd3c\ud847\ude21\ud979\udd46\uda87\udfc7\uda1c\udf29\udbf1\udc6e\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud90f\uddd9\udb29\udc27\udabb\udea7", "\uba2c\ubc5d\ud398\u6ce1\u410d\uba69", "\udb5f\udeb6",
        35, 16428, -1259699841, -660286123796283451L, 50300L, false, false, (char) 57563, (char) 29604,
        Double.longBitsToDouble(0x3fd42b66905cf11cL), Double.longBitsToDouble(0x3fe0c0bbe226a09dL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 4, "\ud8b5\ude71", "\uae87", "\uda3e\udc96\ud8d7\udf67\ud95e\udc6b",
        14, -938, -733415545, -311426571544596293L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd890000c90377aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 4, 4, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\ud893\udda5\uda37\ude4d\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb23\udeed\udabb\udf2a", "\u869e\u6c11\ud2ff\u6ce1\u410d\uba69\u8105\ub7d3\u7573\u84ee\uc72c\u7881\u9e68\ub353\u411e\u7631\uce29\u76aa\u9bfc\u6024\u6c03\u510b\u62d4\u2174\u744a\ub50c\u71e9\ucc21", "\ud840\uddc0\ud965\ude21\ud9f3\udd5c\uda78\udeba\udb36\udf40\ud829\udda0",
        26, 79770, -666574786, 2114285322381805485L, 97538L, true, false, (char) 16292, (char) 23899,
        Double.longBitsToDouble(0x3fc5b8512246eed4L), Double.longBitsToDouble(0x3fdd9d96d82c169cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 2, "\ud917\udf6c\ud9e8\udcb2\ud848\udcad\u5ddc\udace\udd35\udb18\ude01\ud938\udcb2", "\uc3da\u3a12\u43b7\u920f\u5948\u825d\u1326\u156b\ub318\ud2aa", "\udaaa\udf82",
        -2, 34349, 1021968791, -1829938402389788418L, -31248L, true, true, (char) 18932, (char) 51548,
        Double.longBitsToDouble(0x3fd53ec35979f656L), Double.longBitsToDouble(0x3fe882cb5190338eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 4, 5, 0, "\uda8b\udea6\udbb8\udd3c\ud847\udd8d", "\ubc4c\u126d\u1df6\u09c6\ub1bf\u6943\u43b7\u920f\u5948\u825d", "\ud9e4\udd46\uda44\udd44\ud8b8\ude32\u933d\ud9ec\udf2b\uda12\udd99\ud9ba\uddb7\udb5f\udeb6\uda88\udc1b\ud8d3\uddf9\uda29\ude4d\udaf8\udc76\uda6d\udcc3\udbc4\ude71\udba1\udf5e\udb3c\udd8d\ud80f\ude41\udb3f\udedd",
        52, 2526, -1600271848, 651616932528251190L, -15044L, false, true, (char) 47303, (char) 58475,
        Double.longBitsToDouble(0x3fd09a8fcdab54f2L), Double.longBitsToDouble(0x3fe5b923ceb10833L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 2, 3, 3, "\ud95b\udc0d\ud87a\ude01\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\udbee\udd5e\uda45\udf93\udabb\udead", "\u9fd1\u1b26\ud327", "\ud9fe\ude8e\uda12\udd99\ud9ba\uddb7\ud822\udf29\uda87\udfc0",
        43, 72159, -492424891, -3664259697195868059L, -48374L, false, false, (char) 29613, (char) 14251,
        Double.longBitsToDouble(0x3fa73c47218177c0L), Double.longBitsToDouble(0x3fe13504ef71ff75L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 3, "\udad2\udfd0", "\uae87\u326a", "\ud8d7\udf67\ud8f2\udf96\udb45\udcdb\ud830\udc89\udaf0\udf7f\udb34\ude26\udabb\udf2a\udae5\udc4f\ud869\udfa6\uda04\ude90\ud9e4\udd46\uda44\udd44\ud8b8\ude32\udbaf\udf82\ud9ec\udf2b\uda12\udd99\ud9ba\uddb7\udb5f\udeb6\uda88\udc1b\ud907\udd53\udb77\udedb\udb6f\udfe5\udbe6\udd5f\u3cd7\udb99\ude76\udb3c\udd76\ud80f\ude41\udb2f\udddd\udafb\ude94\ud84f\udf93\uda1d\udfdb\ud979\udf0a\uda24\udc1e",
        45, 73086, -349191452, -2814600231583325585L, -71041L, false, true, (char) 62988, (char) 16844,
        Double.longBitsToDouble(0x3f86dea120519e40L), Double.longBitsToDouble(0x3fdfe2813f7a0078L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 0, "\udb12\udd60\ud8b6\udf94\ud847\udd8d\ud979\udd46\uda87\udfc7\udab0\udf20\ud92b\udcab\ud979\uddf9\udb54\udcba\udb79\uddde\ud9d5\uddfa\uda89\ude6c\udb23\udeed\udabb\udf2a", "\uba2c\u6c11\ud2ff\u6ce1\u410d\uba69", "\udbd4\udd5c\uda88\udc1b\ud907\udd53\ud8c7\udd12\udaf8\udcba",
        27, 4365, -409318628, -5847019949281758720L, -2018L, false, false, (char) 57747, (char) 58436,
        Double.longBitsToDouble(0x3fd9c62e21a861ccL), Double.longBitsToDouble(0x3fd1ed1e9d5f4beeL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 2, "", "\u604a", "\000\000",
        20, 33015, -294834456, 1186854348262012807L, -63323L, false, false, (char) 25571, (char) 5077,
        Double.longBitsToDouble(0x3fed84e1b55d5ed1L), Double.longBitsToDouble(0x3fd2cba815091342L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-37, 35, -120, 12, 23, 93, -37, 62]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 3, 4, 5, "\ud90b\udd53\udbb8\udd3c\ud847\udd8d\ud80b\udf6e\ud862\udfa3\ud931\udea3\ud8c4\udc22", "\uc721\u696d\u43b7", "\ud81f\udc4c\uda94\udd4c\uda04\ude90\udbca\udf3a\uda39\udf2f\ud8b8\ude32\u933d\ud9ec\udf2b\uda12\udd99\ud9ba\uddb7\udb5f\udeb6\uda88\udc1b\ud907\udd53\ud8c7\udd12\udaf8\udcba\uda6d\udcc3\ub337\udbb2\uddab\udb3c\udd8d\ud80f\ude41\udb3f\udedd\udb18\udc5c\ud908\udd90\udbee\ude55",
        59, 45669, -1060633758, 8955587141539875027L, 3015L, true, false, (char) 64884, (char) 4903,
        Double.longBitsToDouble(0x3fd45e671e237326L), Double.longBitsToDouble(0x3fbf868d557a87e8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 3, "\u4f62\ud986\udf9b\udb68\udff8\udabe\udc7b\ud8ab\udef8", "\u1dbf\u30c6\ub403\u113f\u4412\u5765\u06e2\u90d7\uc6f0\uba2c\u76da\u4013\ua9b4\ua97a\uba69\u8105\uca31\u44a1\u0ab9\u98ba\u7881\uc637\ub331\u883f\u50a0\u512d\u2976\u1261\u9cd4\u6bf2\ubd12\u6df9\u38a1\u40be\u4ed3\ud277\u1c63\u9f09\u3976\ub4fe\u0c77", "\uda38\udd35\udafc\udece\udba0\udd0b\ud8b0\ude26\ub4bc\udb58\uddeb\u94ca\udb04\udc52\ud80e\udd82\uda5b\ude8f\ud914\udcdf\udb0f\uddee\uda7e\udebe",
        59, 1005, 968415080, -2960305223745085887L, -1659L, true, true, (char) 63774, (char) 28442,
        Double.longBitsToDouble(0x3fdd4be4df9cda34L), Double.longBitsToDouble(0x3fe176754f38af38L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 1, "\uc2d1\udba4\udfa8\udb48\udcec\ud979\udd66\uda87\udfc7\uda1c\udf29\uda3e\udc96\udab3\udd95\ud95e\udca4\udb88\udc60\ud9d5\udeb6\ud9d7\udcf3\uda26\udeaf\udabb\udf2a\ud8fd\udec0\udad6\ude5f\uda04\ude90\ud9e4\udd46\uda44\udd44\ud8b8\ude32\u933d\ud9d2\udf2b\uda12\udd99\ud9ba\uddb7\uafde\udb33\udda9\udac9\uddf9\ud8c7\udd12\ud85f\ude9c\uda6d\udc4b\ud85c\udd8e\ud838\udc89\uda19\udf34\ud80f\ude41\udb3f\udedd\udb18\udc5c\ud908\udd90\udbf3\udc78\ud813\udc0f\ud904\udd1f\udaba\udc08\ud96e\udd66\udaf1\udf59\udbb7\udeca\u0942\ud8f2\udf4d\udb91\udc45\ud9c7\udd5e\udbf2\udce4\udae3\udf88\uebd0\uda53\ude39\udac7\udf79", "\u161b\ua5d5\ud125\u0226\u9f13\ucd23\uc323\u1320\u84f5n", "\udafe\udec7\ud81f\udd5a\udad4\udead\ud1d1\uaa25\ud9ae\udffb\uda30\udcf7\udbfa\uddf1\udb1e\udc7d\ud9e2\udfc6\ud87b\uddcd\udb12\udfa0\udbe3\udf6a",
        45, 13446, -1109313888, 1983891280188352785L, -95374L, true, false, (char) 56633, (char) 33421,
        Double.longBitsToDouble(0x3fe16c366f6ef48eL), Double.longBitsToDouble(0x3fe5322647758d84L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 3, 4, 1, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b", "\u43b7\u920f\u5948\u5c6a\u79ac\u9e86\u6c11\ud2ff\u6ce1", "\uda12\udd99",
        24, 60037, -643157410, -1417122622328897153L, 50300L, false, false, (char) 57563, (char) 29604,
        Double.longBitsToDouble(0x3fd42b66905cf11cL), Double.longBitsToDouble(0x3fe0c0bbe226a09dL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 1, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9a1\ude81\udb23\udeed\udabb\udf2a\udbca\udca1\uda94\udd5b\uda45\udeb0", "\u6d9e\u410d\uba69\u8105\u099b\u9afa\u84ee\uc72c\u7881\u9e68\ub353\u41a1\u7631\uce29\u76aa\u9bfc", "\udbf3\udc78\ud93b\ude43\ud998\udf44\udbe8\ude72\udb00\udc47\ud826\udc5c\ud811\udeaf\ud9d2\udcf3\ud9e1\udfe2\ud8ad\udc35\ud8ad\udc63\udaae\udcef\uda97\udcb4\udba1\udcf8\ud904\udd0d\uda64\udd4e",
        17, 18434, 1389478905, 551364996050838172L, -33341L, false, true, (char) 24393, (char) 49136,
        Double.longBitsToDouble(0x3fdb834bfb565d4eL), Double.longBitsToDouble(0x3fc61a2493237cc4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\uda8b\udf7c", "\uae87", "\uda0d\udf5d",
        30, 33015, -294834456, 1186854348262012807L, -63323L, false, false, (char) 25571, (char) 5077,
        Double.longBitsToDouble(0x3fed84e1b55d5ed1L), Double.longBitsToDouble(0x3fd2cba815091342L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 3, 3, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\udab1\udd42\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb23\udeed\udabb\udf2a\udae5\udc4f\uda94\udd5b", "\ud2ff", "\ud862\udc76\uda23\udf2c\ud9ba\uddb7\udb5f\udeb6\uda88\udc1b\ud907\udd53\ud9f4\ude89\udb0e\ude0f\uda6d\udcc3\ub337\udbb2\uddab\udb3c\udd8d\uda30\udc2f\udb3f\udedd\udb18\udc5c\ud908\udd90",
        2, 99478, -673689513, -6888902274876924921L, -33855L, true, false, (char) 14940, (char) 26872,
        Double.longBitsToDouble(0x3fedf0f2044b383fL), Double.longBitsToDouble(0x3fd59cd50f3e9ff4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 2, "\ud8ad\udc2e\udbb8\udd69\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud91b\udcd5\udb23\udeed\udabb\udf2a\udae5\udc4f\uda94\udd5b\uda04\ude90\ud9e4\udd46\ud8ee\udcf5\u8ff4\udb25\udfd9\ud9ec\udf2b\uda12\udd99\ud9ba\uddb7\udb5f\udeb6\uda88\udc1b\ud907\udd7a\ud8c7\udd12\udaf8\udcba\ud8cc\udf52\ub337\udbb2\uddab\udb3c\udd8d\ud80f\ude41\udb3f\udedd\udb18\udc5c\ud908\udd90\udbf3\udc78\udba1\ude54\ud8bd\udef5\uda07\udd2e\ud8d1\uddc9\udaec\udf11\ud889\udf36\ud8e8\udf5d\udb7a\udf42\ub7d1", "\ua7ee\u39f5\u069c\ua09c\u12b5\ub43c\u9584\u9201\u41fa", "\ud81b\udc2f\ud9ab\udd42\ud9cb\uddbc\ud96a\udc76\udbfd\uddb1\udbdf\udcc8\ud9f8\udd89\udac0\udc12\udad8\udd6c\uda82\udc59\uda8a\udc70\uda11\ude7e\udac3\udda7\udb63\udf99\uda68\udebc\ud945\udd70\udb48\udc05\ud810\udcfc\uc591\udb5c\udfd2\ud936\udeb6\udbc3\udef9\udac1\udf32\udab8\udf14\udbe1\udc05\uda62\udf01\uda25\udcd0\ud9e7\ude69\ud961\udc0b\ud9f7\uddd2\udb15\ude38\ud8fa\udd7c\udad8\udd97\ud82d\uddc9\udae9\ude53\udae9\udca0\uda32\udc14\udaa5\ude09\uda34\uddc9\ud881\udcb6\uda1b\udd79\ud816\udcdc\ud9d4\udd51\ud994\udcf3\udacc\udee7\udb3a\udf6b\ud9a9\udf41\ud865\uded0\udb92\uddfd\uda42\udc34\ud894\ude42\ud93a\udf8d\ud9d1\ude22\ud90c\ude56",
        3, 53105, -699635339, -2751444139846084940L, -22321L, true, false, (char) 26478, (char) 52199,
        Double.longBitsToDouble(0x3fc5cefea0899540L), Double.longBitsToDouble(0x3fd433cad7539a5aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 6, "\ud8b5\udf71", "\000", "",
        -5, 14568, -511126985, -1266304346476502594L, 95447L, true, false, (char) 34761, (char) 25571,
        Double.longBitsToDouble(0x3fbcbcd89d84e1b0L), Double.longBitsToDouble(0x3fd5d5ed1925d214L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 6, "\udbb1\uddf3\udbb8\udd3c\ud9f1\udd7e\ud98d\udeda\u9f91\ud9b8\ude42\ud93a\ude0a\uda78\udecc\ud9bd\udd65\udb79\uddde\udb8e\udd33\ud910\ude4e\u141c\udaae\udd1b", "\uba2c\u6c11\u9569\u6d87\u4104\u2495", "\udb5f\udeb6\ud85a\udc18\ud907\udd53\udad4\udf94",
        42, 82077, 802955365, -1758010122264258069L, 50732L, false, true, (char) 32956, (char) 25153,
        Double.longBitsToDouble(0x3fe13504ed349e4eL), Double.longBitsToDouble(0x3fef832e248df8b0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 0, "\uda8b\udf7c\udbb8\udd3c\ud9f1\udd7e\ud983\udfda\ud8cd\uddd4\ud9c7\udec9\uda67\udf81\ud8d7\udf67\udb5e\udc6b\udb79\uddde\udb78\udcf5\ud920\uddd6\uda8d\udeee\udabb\udf12\udae5\udc4f\uda94\udd5b\uda04\ude90\ud9e4\udd46\uda81\udc02\ud9d3\udf40\u9305\ud9ec\udf2b\u8cfe\ud9bc\udfd8\uda73\udc21\ud854\udc2f\ud99e\udd8b\udbf0\udc0e\uda4c\ude9e\uda5d\ude1f", "\ubff1\uca73\u1bd8\u3df2\u6c03\u4fbf\u9a9b\u3645\u166d\ua420\u6e13\u2173\ua104\u5d79\u86e3\u2018\u2dcd\u248b\ub317\u3fd6\ud0fc\u0869\ua1e6\u069e\u1c46\u6c60\ucf5f\u937c\u60ff\ub486\u3b2f\u459c", "\uda53\udc53\ud9df\udd12\udb18\uddcf\uda37\udf06",
        7, 51670, 993755987, -5489796040047361584L, -94126L, true, false, (char) 18293, (char) 16221,
        Double.longBitsToDouble(0x3fe0912c355e2187L), Double.longBitsToDouble(0x3fe4e95c6fd14d5fL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 6, "\ud8b0\udf0d\udbb8\udd3c\ud9f1\udd7e\ud983\udfda\uda82\uddd0\ud9b8\ude78\uda67\udf81\ud8d7\udf67\ud95e\udc6b\udb79\uddde\udb78\udcf5\ud920\uddd6\uda8d\udeee\udabb\udf12", "\uba2c\u6c11\u4a27\u1c54\u40d5\uba69", "\udb5f\udeb6\uda88\udc1b\ud907\udd53\udaca\udfd4",
        1, 59141, 440893425, -1758045083298744746L, 50732L, false, true, (char) 32956, (char) 57747,
        Double.longBitsToDouble(0x3fe13504edc8144eL), Double.longBitsToDouble(0x3fe8bb2b3c8df8b0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 0, "", "", "\uda82\uddd0",
        -5, 22160, 1047847865, -2195273684670927128L, -17054L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe000000072f362L), Double.longBitsToDouble(0x3fed84e1b55d5ed1L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 5, 3, "\udaae\udcbe\udbb8\udd3c\ud9f1\udd7e\ud983\udfda\uda82\uddd0\ud9b8\ude78\uda67\udf81\ud8d7\udf67\ud95e\udc6b\udb79\uddde\udb78\udcf5\ud920\uddd6\uda8d\udeee\udabb\udf12", "\uba2c\u6c11\u4a27\u1c54\u40d5\uba69", "\udb5f\udeb6\uda88\udc1b\ud90c\udd42\udaca\udfd4",
        20, 82077, 802955365, -1758010121241545130L, 50732L, false, false, (char) 19918, (char) 57684,
        Double.longBitsToDouble(0x3fe5a864eda8144eL), Double.longBitsToDouble(0x3fe8bb2e248df8b0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 2, 2, 6, "\uda8b\udf7c\udbb8\udd3c\ud9f1\udd7e\ud983\udfda\uda82\uddd0\ud9b8\ude78\uda67\udf81\ud8d7\udf67\ud95e\udc6b\udb79\uddde\udb78\udcf5\ud920\uddd6\uda8d\udeee\udabb\udf12", "\uba2c\u6c11\u4a27\u1c54\u40d5\uba69", "\udb5f\udeb6\uda88\udc1b\ud907\udd53\udaca\udfd4",
        20, 82077, 802955365, -1758010122264955306L, 50732L, false, true, (char) 32956, (char) 57747,
        Double.longBitsToDouble(0x3fe13504eda8144eL), Double.longBitsToDouble(0x3fe8bb2e248df8b0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "", "\000", "\000",
        56, -1000, -520093696, -1266304346253950786L, -100000L, false, false, (char) 82, (char) 0,
        Double.longBitsToDouble(0x3fbcbcd8800001b0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-58, -62, 58, -71, -24, -22, 124, -38]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 6, "\ud9f6\uddf2\ud96a\udde9\uda18\ude1a\ud9ac\ude0a\uda82\uddd0\ud9b8\ude78\uda67\udf81\ud8d7\udf67\ud95e\udc6b\udb79\uddde\udace\udc1f\ud920\udd41\uda8d\udeee\udabb\udf12", "\uba2c\u0bef\uc7f7\u1c54\u2085\uba69", "\udb5f\udeb6\ud91d\udc59\ud907\udd05\udaca\udfd4",
        20, 52157, -2131569680, 6175581594923504173L, 50732L, false, true, (char) 32956, (char) 57747,
        Double.longBitsToDouble(0x3feff504eda81404L), Double.longBitsToDouble(0x3fe8eb2e248df8b0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 4, "\uc2d1\udb40\udc6c\ud8fd\udc0a\ud963\ude7a\uefc1\ud8b9\udd72\ud9b0\udeba\udb65\udc20\uda14\ude10\udb3a\udc55\udb7f\udc6e\uc38f\udb23\udeed\udabb\udf2a", "\uba2c\u66bb\ud2ff\u6ce1\u410d\u5315", "\uda14\udfbc\uda88\udc1b\ud817\udd5b\ud8c5\udfbf\udaf8\udcba\uda6d\udcc3\udbb0\udda6\uda3b\udd93\udab6\udf1c\ud80f\udf10\udb3f\udedd\udb18\udc5c",
        2, 64839, 1123156518, 6978901855465653613L, 60144L, true, true, (char) 52943, (char) 61276,
        Double.longBitsToDouble(0x3fec81fdac6a95b3L), Double.longBitsToDouble(0x3fd55ff3ba99b990L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 4, "\ud8df\udfe6\udb40\udc6c\ud8fd\udc0a\uda6d\udf7e\uda87\udf7f\ud8b9\udd72\ud9b0\udf37\udb4c\udc20\uda14\ude10\ud99b\udd85\u3473\ueb26\udbe3\udc0d\udb3a\udcd9", "\uba97\u66bb\uaa68\u6cd9\u410d\u0a7e", "\ud89c\udf80\ud937\uded4\ud817\udd5b\udb7d\udd89\udaf3\udd08\uda6d\udcc3\ud952\udd92\udbb8\udefd\ud9e3\uddf1\uda1a\udcd4\udb3f\udeb5\udb18\udc5c",
        24, 72152, 1123180070, 3931372282083620230L, 60144L, true, true, (char) 42469, (char) 35410,
        Double.longBitsToDouble(0x3fe5816b046a95b3L), Double.longBitsToDouble(0x3fd55ff3ba99b990L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 4, "\uc2d1", "\u57bb", "\ud9b0\udeba\udb65\udc20\uda14\ude10\udb3a\udc55\udbbf\udc6e\uc38f\udb23\udeed",
        51, 49418, -211664358, -7190524081575177296L, 51252L, false, false, (char) 26396, (char) 61641,
        Double.longBitsToDouble(0x3fdce1ed5e5a98e8L), Double.longBitsToDouble(0x3fe2f26b1e7cd9aaL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 1, 4, "\uc2d1\udb40\udc6c\udaf5\udee7\ud884\uddc5\uda87\udfc7\ud8b9\udd72\ud9b0\udeba\udb65\udc20\uda14\ude10\udb3a\udc55\udb7f\udc6e\uc38f\udb23\udeed\udabb\udf2a", "\uba2c\u66bb\ud2ff\u6ce1\u410d\u0a7e", "\uda14\udfbc\uda88\udc1b\ud817\udd5b\ud8c5\udfbf\udaf8\udcba\uda6d\udcc3",
        6, 65534, -983428868, -4580104957630762188L, 30522L, true, true, (char) 6856, (char) 17716,
        Double.longBitsToDouble(0x3fd9026b3a335044L), Double.longBitsToDouble(0x3fe42a5b01b4389eL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-55]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 1, 4, "\uc1f9", "\u57bb", "\ud9b0\udeba\udb65\udc20\uda14\ude10\udb3a\udc55\udb7f\udc6e\uc38f\udb23\udeed",
        51, -918, -211681280, -7190524081575177296L, 10892L, false, false, (char) 67, (char) 115,
        Double.longBitsToDouble(0x3fd000000e5a00e8L), Double.longBitsToDouble(0x3fe2f26b1e7cd9aaL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 4, 3, "\uda8b\udf7c\udbb8\udd3c\ud9b7\udd85\ud979\udd46\uda87\udfc7\uda1c\udf29\ud9b4\udf78\udbce\udeec\udaf2\udd20\ud827\udc15\udbe9\udebf\ud9b4\udd8e\udb23\udeed\udabb\udf2a\ud9d5\udc47\ud822\udfdd\uda04\udede\ud9e4\udd46\uda44\udd44\udacb\ude80\u933d\ud977\udfb1\uda63\udd85\ud9ba\ude41\udb5f\udeb6\uda88\udc1b\ud8cd\udc23\ud8c7\udd63\udaf8\udcba\ud94d\udd6c", "\uce29\u76aa\u9bfc\u6024\u1fc3\u510b\u00bd\u1cb1\u9332\ub6cf\u7060\u036d\u43c2\u5ff4\u500a\u0450\u0ebf\u65f0\u2101\u3919\u1bcb\u2a7f", "\ud87b\udc4b\ud811\udc1f\uda54\ude6c\ud917\ude5d\ud899\udd4e\ud9e6\ude2a\ud931\udd75\uda80\udf07\udb0d\udeff\ud95d\udd23\ud9ac\udd7b\udaa2\uddd0\ud836\udfd3\uda8a\udff6\udbba\ude22\udac0\uddc3\udaf5\udfcd\ud990\udc43\ud889\udd93\ud81a\udca3\udacc\udf41\ud9e8\udf65\ud8ab\ude8e\ud9cd\uded1\uda4e\udf38\ud992\udce7\ud8ad\udf01\ud815\udedf\udaf3\ude05\udbdb\udef7\ud864\udf52\ud972\ude13\uda53\udfaf\ud88c\udfa4\udbf7\udde0\udb84\ude62\udb56\udc2b\uda59\udc8d\udb92\udc61\udb8a\udf5b\udaac\udc73\ud82d\udf66\ud919\udea9\ud84d\uddc5\ud928\udd43\uda33\udd18\udace\udd31\udaee\ude02\udb8e\ude6b\ud9d5\udfed\ud964\udc3a\udb95\udf11\udb40\udeba\udb7d\udede\u0e66\ud855\udff7\udbee\udd63\udb35\udfd2\ud87d\ude94\ud99d\udfee\udb52\udfd0\ud93e\udd9b\ud9ec\ude94\uda73\udd80\udbfb\ude75\udbe6\ude7e\udbbf\ude51\ud8ca\udf22\ud9b7\udfb1\udb66\ude9b\uf766\udaa4\udc51\ud99e\ude18\udba1\udc3b\ud832\ude2c\ud94b\udc35\uda60\udf1c\ud99f\udf05\ud834\uddb5\udae9\udec8\udaa2\udf9f\udbdc\ude1b\ud950\udc2b\udaee\udcb0\uda74\ude2c\u3823\udb4c\udcb9\udacb\ude67\ud917\udcf8\udbd0\uded0",
        8, 28111, 1535499564, 4827245188684610386L, 94582L, false, true, (char) 47579, (char) 54080,
        Double.longBitsToDouble(0x3fc936cc1f900b34L), Double.longBitsToDouble(0x3fc32ea148b5bafcL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 3, 6, "\u5c6d\udbb7\udfd8\ud892\udf1a\udb33\udd10\ud9aa\ude78\uda15\udf78\uda3e\udc96\ud809\ude60\udaf9\udc22\udad3\udc65\udaae\udec3\ud9d7\udcff\udb23\udeed\udabb\udf2a", "\uba2c\u6c11\ud2ff\u6ce1\u410d\u7517", "\uda04\ude69",
        57, 16428, -1485078145, -660286123796283451L, -2018L, false, false, (char) 57747, (char) 10732,
        Double.longBitsToDouble(0x3fd1c5d516f2dbf8L), Double.longBitsToDouble(0x3fcdc19f01e69700L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-45]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-45]]\012",
        Z.run(T, 2, 3, 3, 6, "\u5d03", "\u4962", "\uda3e\udc96\ud809\ude60\udaf9\udc22\udad3\udc65",
        -5, 45467, -72509649, -1911935567767428526L, 22766L, false, true, (char) 21898, (char) 21175,
        Double.longBitsToDouble(0x3fe4244d0a890c43L), Double.longBitsToDouble(0x3fe247db4436384fL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-24, -87, 123, -91, 124, 9, -98, -104]]\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 3, 2, 3, "\ud818\uddd9\udaab\uddd5\ud8ac\udc39\ud9ce\udfc8\ud900\ude2b\udba4\udf95\ud9d0\udfbd\ud92c\udcb1\ud95e\udc6b\udbfd\udf81\ud86b\udca6\ud9d3\uddf8\ud91d\udd69\udabb\udef9", "\u70bf\u2b07\ua0e8\u947b\u61e3\u65a3\ud2d2\ud38e\ud300\u9c90\uc72c\ub9a5\u4d44\u2a43\u5891\u827b\uce29\u76aa\u9bd9\u8379\u2c41\u966d\ud025\u9b81\ua966\u8a90\u6a09\u937c\uab6b\uc97b", "\ud9f2\udf08\udb4d\ude1e\ud8c6\udcd5\ud997\ude50\udaa7\udc4f",
        18, 79299, 1105739219, -6456351838700647180L, 55884L, true, false, (char) 16214, (char) 42846,
        Double.longBitsToDouble(0x3fd89d238d505d56L), Double.longBitsToDouble(0x3fd5e36fe6635aa2L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-51, -24, -90, -87, -32, -68, -84, -98]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 1, 2, "\ud8fd\udc18\ud9d6\udcd9\udb10\uddec\u5ddc\udace\udd35\udb18\ude01\ud938\udcb2", "\ubd03\u3a12\ua6b6\ub970\u8c0b\u825d\u1326\u156b\uc7d9\u48e1\uac69\u3199\u5198\u40c2\ucb06\u19c9\u5c01\u57b7\ud0d1", "\ud8d2\ude5c\ud977\udcea\ud83f\udd0a\udbfe\ude00\udb25\ude19\ud817\udcd1\uda61\udda1\ud816\udd57\uda01\udc7f\uda4e\udd6f\ud910\uded1\ud804\ude2b\ud8b6\ude07\uda41\ude2d\uda75\udcd2\ud989\udd75\udbbd\udd94\ua90b\udbf4\uddd1\ud824\udd7d\udbcf\udf53\ud935\udd21",
        18, 6912, 150290555, 7281534192588653891L, 39296L, false, false, (char) 9807, (char) 21556,
        Double.longBitsToDouble(0x3fec3768bf2922c9L), Double.longBitsToDouble(0x3fe5be4498430b37L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-37, 35, -73, 35, -97, 14, -37, 62]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-37, 35, -73, 35, -97, 14, -37, 62]]\012",
        Z.run(T, 2, 3, 3, 6, "\ud90b\udd53\udbe7\udd53\udbcf\udc3e\ud80b\udf6e\ud862\udfa3\ud931\udea3\ud8c4\udc22", "\u9a82\u7bc5\ud724", "\ud81f\udc4c\uda94\udd4c\uda04\ude90\udbca\udf3a\udb66\ude4b\ud816\ude5c\u933d\ud9ec\udf2b\uda12\udd99\ud9ba\uddb7\ud8b2\udf58\udab6\udcea\ud8f2\udf53\ud8c7\udd12\udaf8\udcba\uda6d\udcc3\ub337\udbb2\uddab\ud88b\uddc3\ud80f\ude41\udb3f\udedd\udb18\udc5c\ud908\udd90\udbee\ude55",
        59, 45669, -1060633758, 8955587141539875027L, -79845L, true, true, (char) 41650, (char) 56235,
        Double.longBitsToDouble(0x3feea31ee58daebfL), Double.longBitsToDouble(0x3fe89221299902f8L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-24, -87, 123, -91, 124, 9, -98, -104]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-24, -87, 123, -91, 124, 9, -98, -104]]\012",
        Z.run(T, 2, 3, 3, 3, "\ud818\uddd9\udaab\uddd5\ud8ac\udc39\ud9ce\udfc8\ud964\udebe\udba2\udefc\ud9d0\udfbd\ud92c\udcb1\ud95e\udc6b\udbfd\udf81\ud86b\udca6\ud9d3\uddf8\ud91d\udd69\udabb\udef9", "\uc534\u2b07\ua0e8\u947b\u61e3\u65a3\ud2d2\ud38e\ud300\u9c90\uc72c\ub9a5\u4d44\u2a43\u5891\u827b\uce29\u31ab\u1bbe\ubf11\u2c41\u756e\ud025\u9b81\ua966\u8a90\u6a09\u937c\uab6b\uc97b", "\ud9f2\udf08\udb4d\ude1e\ud8c6\udcd5",
        21, 25606, 1294470733, 6597015217382112723L, -21396L, true, false, (char) 43185, (char) 64007,
        Double.longBitsToDouble(0x3fc27bd85b863030L), Double.longBitsToDouble(0x3fdd44991d505d56L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-51, -24, -90, -87, -32, -68, -84, -98]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-51, -24, -90, -87, -32, -68, -84, -98]]\012",
        Z.run(T, 2, 3, 3, 1, "\ud8fd\udc18\ud9d6\udcd9\udb10\uddec\u5ddc\udace\udd35\udb18\ude01\ud938\udcb2", "\ubd03\u3a12\ua6b6\ub970\u8c0b\u825d\u1326\u156b\uc7d9\u48e1\uac69\u3199\u5198\u40c2\ucb06\u19c9\u011d\u57b7\ud0d1", "\ud8d2\ude5c\ud977\udcea\ud83f\udd0a\udbfe\ude00\udb25\ude19\ud817\udcd1\uda61\udda1\ud816\udd57\uda01\udc7f\uda4e\udd6f\ud910\uded1\ud804\ude2b\ud8b6\ude07\uda41\ude2d\uda75\udcd2\ud989\udd75\udbbd\udd94\ua90b\udbf4\uddd1\ud824\udd7d\udbcf\udf53\ud935\udd21",
        18, 6912, 150290555, 7281534192588653891L, 39296L, false, false, (char) 9807, (char) 21556,
        Double.longBitsToDouble(0x3fec3768bf2922c9L), Double.longBitsToDouble(0x3fe5be449c141f81L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\uda3e\udc96\ud8d7\udf67\ud95e\udc6b\udb79\uddde\ud9d5\udeb6\ud9d7\udcf3\udb23\udeed\udabb\udf2a", "\uba2c\u6c11\ud2ff\u6ce1\u410d\uba69", "\udb5f\udeb6",
        35, 16428, -1259699841, -660286123796283451L, 50300L, false, false, (char) 57563, (char) 29604,
        Double.longBitsToDouble(0x3fe4d52b482e788eL), Double.longBitsToDouble(0x3fe0c0bbe226a09dL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 4, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud979\udd46\uda87\udfc7\uda1c\udf29\ud926\ude30\udbce\udeec\uda90\udef0\udb79\uddde\ud9d2\udc95\ud9d7\udcd5\udb23\udeed\udabb\udf2a\ud9d5\udc47\uda94\udd5b\uda04\ude90\ud9e4\udd46\uda44\udd44\ud8a4\udcce\u933d\ud977\udfb1\uda63\udd85\ud9ba\ude41\udb5f\udeb6\uda88\udc1b\ud8cd\udc23\ud8c7\udd63\udaf8\udcba\ud94d\udd92\ud95b\udd03\ud9f2\udc3e\udb3c\udd8d\ud80f\ude41\udb3f\udedd\udb18\udc5c\ud82f\udd8d\udbf3\udc78\ud947\uddd5", "\ub6cf\u7060\u036d\u8430\u5ff4\u2308\ud3e0\u5533\ucc5d\u2101\u3919\u1bcb\u2a56", "\ud87b\udc4b\ud811\udc1f\uda54\ude6c\ud917\ude5d\ud899\udd4e\ud9e6\ude2a\ud931\udd75\uda80\udf07\udb0d\udeff\ud95d\udd23\ua97b\udaa2\uddd0\ud836\udfd3\uda8a\udff6\udbc3\ude22\udac0\uddc3\udaf5\udfcd\udbfd\udcd8\ud935\udfb6\ud81a\udca3\udacc\udf41\ud9e8\udf65\udbaf\udd0f\udbca\udf80\udae0\udcda\ud855\uddb4\ud875\udde8\udb6a\udfa5\ud9c7\udd0f\udabe\ude1a\ud987\ude3a\udafc\udc7d\udadc\udde8\ud8e0\udd91\uda59\ude33\ud9c4\udec3\ud815\udf7d\u9dad\udbb9\ude97\ud8c1\udc22\ud908\udcf8\ud886\udd8e\udaef\udd0f\ud9a0\uddc9\ud817\udf64\ud82a\udd38\udb4c\uddd0\udb15\uddd1\uda09\udf5d\ud8b0\udfb3\udac2\udd96\udbaa\udec0\udb2c\udfbb\ud9e0\ude49\ud85c\uddac\u7c22\udad8\udc1f\u991e\ud9dd\udcc8\ud911\udf16\udbce\udec6\uda2b\udff5\uda9c\udf02\udb74\udcf2\u300b\udbe6\udeb7\ud97c\udc90\ud81c\udfbc\udb92\udeff\udbdf\udfe8\udaab\uded3\ud9ce\udde3\ud9cc\udc3a\udb03\udd56\uda60\udefd\ud8c6\uddbd\ud8f9\uddf0\udb5e\udfff\uda6e\udf2a\ud95c\udca9\udbfd\udc4c\ud89a\udffd\ud95d\udd37\ud8a0\udf92\u51aa\ud825\udec3\ud885\udf3b\udbad\udc87\udbe0\udc5e\ufc6b",
        51, 81651, 1736774107, -6456200984103128764L, 19152L, false, true, (char) 64343, (char) 55241,
        Double.longBitsToDouble(0x3fe2656f8ca8ff60L), Double.longBitsToDouble(0x3fd5c24d56cdce50L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 0, "\uda8b\udf7c\udbb8\udd3c\ud9f1\udd7e\ud983\udfda\ud8cd\uddd4\ud9c7\udec9\uda37\ude48\000\udb5e\udc34\udb79\uddde\udb22\udcea\ud920\uddd6\uda8d\udeee\udabb\udf12\udae5\udc4f\uda94\udd5b\u2072\ud9e4\udd46\uda81\udc02\ud9d3\udf40\u9305\ud9ec\udf2b\u8cfe\ud9bc\udfd8\uda73\udc21\ud8a4\udf78\udadf\udf4e\u1379\000\uda3d\udcfe", "\ubff1\uca73\u1bd8\u3df2\u6c03\000\u37b4\u3645\u166d\ua420\u6e13\u2173\ua104\u5d79\u86e3\u2018\u2dcd\u248b\ub317\u3fd6\ud0fc\u0869\ua1e6\u069e\u1c46\u6c60\ucf5f\u937c\u60ff\ub486\u3b2f\u459c", "\uda53\udc53\ud9df\udd12\udb18\uddcf\uda37\udf06",
        7, 51670, 993755987, -5489796040047361584L, 67892L, true, true, (char) 4704, (char) 30863,
        Double.longBitsToDouble(0x3fcd71e03c8985d0L), Double.longBitsToDouble(0x3fe3d7602a9c4ffeL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[91, 76, -120, 12, 23, 93, -66, -17]] |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 1, 2, 3, "\uda8b\udf7c\udbb8\udd3c\ud847\udd8d\ud8ee\ude1f\uda87\udff9\uda1c\udf29\uda3e\udc96\udb83\udd9e\uda15\udd16\udaee\udd09\udac4\udeef\ud930\udf8e\udb23\udeed\udabb\udf2a", "\u2279\u6c11\ud2ff\u6ce1\u410d\uba69", "\udb5f\udeb6",
        3, 0, -1366345504, 8551525909698932654L, 7320L, false, false, (char) 10155, (char) 54779,
        Double.longBitsToDouble(0x3fd42b68305cf11cL), Double.longBitsToDouble(0x3fe0c0bbe226a09dL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[95, 78, -120, 12, 23, 93, -66, -17]] |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=java.lang.Integer:0 |a0=[B:[[95, 78, -120, 12, 23, 93, -66, -17]] |this=org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 1, 1, 4, "\uda8f\udd7e\udbb8\udd3c\ud847\udd8d\ud8ee\ude1f\uda87\udff9\uda1c\udf29\uda3e\udc96\udb83\udd9e\uda15\udd16\udaee\udd09\udac4\udeef\ud930\udf8e\udb23\udeed\udb0f\udd74", "\u2279\u2234\u93b9", "\ud9ec\udf2b\uda12\udd99\ud9ba\uddb7\udb5f\udf04",
        3, 0, -1366345504, 8551525909698932654L, 7320L, false, false, (char) 10155, (char) 54779,
        Double.longBitsToDouble(0x3fd42b68305cf11cL), Double.longBitsToDouble(0x3fe0c0bbe226a09dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base64InputStream|read||new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|read|[B,int,int|new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|markSupported||new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "C|org.apache.commons.codec.binary.Base64InputStream|<init>|java.io.InputStream,boolean,int,[B",
    "C|org.apache.commons.codec.binary.Base64InputStream|<init>|java.io.InputStream,boolean",
    "C|org.apache.commons.codec.binary.Base64InputStream|<init>|java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|read||new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|read|[B,int,int|new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
