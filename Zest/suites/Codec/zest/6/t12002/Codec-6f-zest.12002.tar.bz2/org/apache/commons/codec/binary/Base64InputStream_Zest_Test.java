package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base64InputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\ud85b\udf62\udb59\udecd\ud8ab\udc0d\udb0f\udd67",
        40, 73076, -627046357, 5705811112284949653L, 38658L, true, true, (char) 54670, (char) 63325,
        Double.longBitsToDouble(0x3fd039ec924d81ceL), Double.longBitsToDouble(0x3feee9a3c2ac7520L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 5, 0, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda54\udc3c\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\ud8b1\udee0\uda0a\udf18\uda68\udf13\udb84\udd7a\udb4b\udc9f\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u4c66\u2928\u18ae\u3140\u6072\ub5be", "\udbc8\ude17\ud85b\uddf7\uda5e\udda4\udb14\ude2d\udb8c\udfac\ud8ea\udd03\ud9b1\udfc4\uda60\udcb0\ud84f\udeaa\udb5f\ude5b\ud8b2\udcc0\udb03\udf95\uda4f\udde4\u7ac4\ud9c4\udcd8\uda21\udd32",
        12, 14775, 887202912, 5989871399774100066L, -4981L, false, false, (char) 11235, (char) 58752,
        Double.longBitsToDouble(0x3fd86d11bf8398deL), Double.longBitsToDouble(0x3f8d9730bc12c200L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\uda1a\udceb", "\u8485\u59d1\uc21e", "\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02",
        51, 99208, -221147100, -8945931623472841246L, -32465L, false, false, (char) 9897, (char) 5867,
        Double.longBitsToDouble(0x3fdd5fb0f3c0b342L), Double.longBitsToDouble(0x3fe8f58db250cf71L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\uda1a\udceb", "\u8485\u59d1\uc21e", "\ud82d\udec3\ud8a9\udf18\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\ud89c\udcfe",
        51, 99208, -221147100, -8945931623908655646L, 40843L, false, true, (char) 6357, (char) 43457,
        Double.longBitsToDouble(0x3feb38a7b9b43e55L), Double.longBitsToDouble(0x3f516d9732cede00L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\udbe0\uddfc\udb10\udcd6\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\ud85b\udf62\udb59\udecd\ud8ab\udc0d\udbf2\udc19",
        9, 48744, -627030984, 5705811112284949653L, 38658L, true, true, (char) 54670, (char) 63325,
        Double.longBitsToDouble(0x3fd039ec924d81ceL), Double.longBitsToDouble(0x3feee9a3c2ac7520L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f\u189c\u9f2d\u3140\u6072\ud6bf\ua0d7\u7139\u5371\ud3de\u62d3", "\ud8e2\udcf9\ud9b1\udfc4\uda60\udcb0\ud84f\udeaa\udb5f\ude5b\ud981\udd14\ud819\udd4b\uda6f\udc3d\u7ac4\ud8ee\ude6d\udb60\udc8d\ud817\udce3\ud864\udce6\ud9de\udc5d\uda66\ude7c\udbe0\udfa0",
        26, 53099, -116199492, -6179758075744764004L, -91633L, true, true, (char) 49205, (char) 24100,
        Double.longBitsToDouble(0x3feee675b82d7e75L), Double.longBitsToDouble(0x3fb6db3ac5705518L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 3, 6, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\000\udb1d\udd4d\ud8ea\udcd6\u00bd\ud8a9\ude5b\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\u61a0\ud9f4\udc79\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\uda0a\uddde\000\000\000\ud950\udfa7\ud8ce\ude08e\000\000\000\udae5\udfd2\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\ud85b\udf62\udb59\udecd\ud8ab\udc0d\udb0f\udd67",
        40, 73076, 10487851, -684195840L, 38658L, false, true, (char) 53646, (char) 143,
        Double.longBitsToDouble(0x3fd0300c904c01ceL), Double.longBitsToDouble(0x3feee80002ac7520L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 6, 5, "\uda1a\udc90\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\u2a42\uda21\udd81\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda3e\ude68\ud81b\udd9f\ud98e\udf7a\ud8d8\udfe2\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\uc58c\ud98c\ude22\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\ud9ea\udf09\ud8fa\ude55\uda0b\ude04\ud8f7\ude20",
        40, 72569, -627046357, 5705811112284949653L, 38658L, true, true, (char) 54670, (char) 53085,
        Double.longBitsToDouble(0x3f6c61dfb82f9900L), Double.longBitsToDouble(0x3fe8fceddaac7520L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\uda1a\udceb\ud80d\udf14\u1a0d", "\uc21e\u154e\uc02b\u621a\u4127\u9359\u24ac\u53b8\u4979\u27d7", "\udb7d\udf85\ud9f6\udc31\ud85e\udeca\u1b45\uda3e\ude68\udb0f\udc38\udb08\udf18\ua869\udb4b\uddc5\ud90e\udc91\ud8c9\udf1d",
        38, 13382, 351787600, -2632031381059286689L, -33543L, true, true, (char) 21045, (char) 61769,
        Double.longBitsToDouble(0x3fee17e8c8801f03L), Double.longBitsToDouble(0x3fe4b99ea5049e77L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\udbf5\udec6\ud811\udf16\udb95\udda1\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca", "\u53b8\u4979\u1470\uce53\uc936\u5334\uc890\u8084\u4f71\ub8e6\u73b2\u5bc0\u4b26\ubce1\u008f\u7c10\u0517\u2591\u032a\u5d48\ua071\u498c\u84f9\u8520\u86b7\uc99b\u2b41\u91d1\u6422\u5f1d\uac03\u187f\u17ed\u9f2d\u3140\u6072\ud6bf\ua0d7\ub33e\u637c\ubba6\u5aac", "\ud8e2\udcf9\ud9b1\udfc4\uda60\udcb0\ud84f\udeaa\udb5f\ude5b\ud981\udd14\ud819\udd4b\uda6f\udc3d\u7ac4\ud9d7\udfe2\ud9b6\udf04\ud9e0\udf58\ud8f3\udf58\ud985\uddad\ud8fe\udf02\ud896\udcdc",
        57, 68456, -359230974, -5697116145425467016L, 43427L, false, false, (char) 40273, (char) 49584,
        Double.longBitsToDouble(0x3fed7a312664ac19L), Double.longBitsToDouble(0x3fe5b8a7ac0615fbL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 5, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud8a3\udd67\ud96a\ude2a\udb5e\udd2c\ud839\uddd5\ud9fd\udff2\udbea\ude59\ud956\udc16\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\udabc\udc79\uda05\ude82\udb66\udf45\udafe\udd51\udadc\udd5f\ua7f5\ud8f0\uded7\udbf4\uddfe\udb37\udded\udbb7\udcd0\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\ud9d1\udc5e\ud938\udfe5\ud92e\ude6d\ud8c7\udce0\u55d1\ud9ac\ude3d\ud8ce\ude98", "\u818f", "\ud85b\udf62\u3ead\uda01\udc18\udbe8\udd5d",
        40, 73076, 1303119915, 5705811112284949653L, 38658L, true, true, (char) 54670, (char) 63325,
        Double.longBitsToDouble(0x3fe3481e4f2f38adL), Double.longBitsToDouble(0x3feee9a3c2ac7520L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\uda1a\udceb", "\u8485\u59d1\uc21e", "\ud809\ude92\ud8a9\udeca\uda29\udf48Q\000\000\uda3b\ude93\uda52\udc45\udb24\udd02",
        51, 99208, -221147100, -8945931622284542494L, 36400L, false, false, (char) 9897, (char) 5867,
        Double.longBitsToDouble(0x3fdd5fb0f3c0b342L), Double.longBitsToDouble(0x3fe8f58db250cf71L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 5, "\uda1a\udceb\ud811\udf16\u1a0d\000\000\udb0e\udf27\ud909\udf74\ud8c1\udd60\ud809\ude92\ud8a9\udeca\ud8cd\udf3a\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udad9\udeeb\u00b8\000\000\000\ud846\udea3\udadc\udd5f\ua7f5\uda34\udfb9\000\000\000\000\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc3f\ud92e\ude6d\udae5\udfde\ud7c2\udbaf\udcb6\ud8ce\ude98", "\u187f", "\ud85b\udf62\udb59\udecd\ud8ab\udc0d\udb0f\udd67",
        40, 73076, -627046357, 5705811112284949653L, 96608L, true, true, (char) 53646, (char) 0,
        Double.longBitsToDouble(0x3e20000000000000L), Double.longBitsToDouble(0x3feee9a3c2ac7520L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 3, 6, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\uda40\ude38\ud884\udea4\ud909\udf5c\ud821\udc4a\ud809\ude8c\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda3e\uddc1\udafe\udd51\udadc\udd5f\ud890\uddeb\udaa8\udf67\udac8\udc1a\ud9d6\udf39\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\udb83\udc3b\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\ud85b\udf62\ud82f\udc58\ud8de\udf07\udb0f\uddf7",
        40, 73076, -627046357, 5705811112284949653L, -35661L, true, false, (char) 49100, (char) 47629,
        Double.longBitsToDouble(0x3fddd3478afff188L), Double.longBitsToDouble(0x3fb63dfeac473cc8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 5, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27", "\uc936\u6c7d\u90dc\u8084\u3d13\u016b\u73b2\u3cfc\u5cfb\ubce1\u008f\u9fa4\u1dec\ud21d\ua77f\ub8f3\u14e4\u19ae\u45fe\u2e9c\u865a\u82c7\u2b41\u900b\u6edf\u5e39\ube4e\u187f\u189c\u81b7\u4863\u6072\ud6bf\ua0d7\u7139\u1fe3\u05eb\u62d3\u5249\u416e\u553f\ubd9d\ua186\u5198\u0e86\ua797", "\u7ac4\udab0\ude2d\ud877\uddb9",
        44, 92606, 802190472, 2916353014692660216L, -27943L, false, true, (char) 36012, (char) 43798,
        Double.longBitsToDouble(0x3feba57d13653002L), Double.longBitsToDouble(0x3fe9ac1d1fd6fea9L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 2, 5, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud87f\udf51\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\ud90b\udf64\udb59\udecd\ud8ab\udc0d\udb0f\udd67",
        40, 73076, -627046357, 5705811112284949653L, 38658L, true, true, (char) 54670, (char) 63325,
        Double.longBitsToDouble(0x3fd039ec924d81ceL), Double.longBitsToDouble(0x3feee9a3c2ac2275L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 5, 2, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\ud967\udd4b\udacb\udc4f\ud8fa\udf55", "\u9359\u24ac\u53b8\ud5eb\u2a5e\u3093\uc936\ub78a\u044c\u8084\u4f71\ub8e6\ub885\u1f7c\u5d27\ubce1", "\udbab\ude2d\ud9a1\udc41\ud930\udf8c",
        -5, 10343, 1729148773, 4262942478872253858L, -59796L, true, true, (char) 47217, (char) 24871,
        Double.longBitsToDouble(0x3fcc33d8ec1f0c74L), Double.longBitsToDouble(0x3fecd701409af8fbL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\uc3d1\ud811\udf16\u1a0d\u5d8d\ub5b6\ud912\udf77\ud90a\ude08\ud8ea\udcd6\ud809\ude92\udbd9\udfe0\uda29\udf04\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\ud9fa\udc27\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\ud878\udd34\ud9a1\udc9f\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udac5\udfc9\ud871\udcac\ud8ce\ude98", "\u187f\u189c\u9f2d\u3140\u6072\ud6bf", "\udbc8\ude17\ud85b\uddf7\uda5e\udda4\udb14\ude2d\udb8c\udfac\ud8e2\udcf9\ud9b1\udfc4\uda4b\udc87\udb02\udee9\udb5f\ude5b\ud981\udd14\ud819\udd4b\uda6f\udc3d\udb01\udc75\udbdc\udf6a\ud8e4\uddb4\ud907\udf2a\udbc1\udfb5\udb75\ude8d\ud914\udfc0\uda63\udc10\ud90a\ude04\ud983\udcd4\udab6\udc79\udb42\udd14\udb5e\udea8\ud9f4\udfaa\ud9c0\udc07\ud9b5\udf02",
        1, 26641, -1830501918, -1866460892856180243L, 38205L, false, true, (char) 8280, (char) 45428,
        Double.longBitsToDouble(0x3fccfefa5fac1aecL), Double.longBitsToDouble(0x3fe853c39093681bL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 5, 5, "\ud885\udd77\ud9bf\udd71\udbfc\udef1", "\u1cbb\u154e\u52e3\u2494\u4127\u9359\u6244\u5a17\u827a\u2b39", "\ud999\udcc5\uda14\uddcf",
        42, 2180, 1288420836, 1050154152077408283L, -11043L, false, true, (char) 58552, (char) 47613,
        Double.longBitsToDouble(0x3fe202eb8b5fa4fdL), Double.longBitsToDouble(0x3feb2f4a3b996710L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 4, 5, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud8c9\udcb6\uda71\udda8\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud965\udd08\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\ud85b\udf62\ud9cd\udfa7\ud91e\udcfc\udb0f\udd5d",
        40, 73076, -627046357, 5705811112284949653L, 56452L, true, false, (char) 23094, (char) 58810,
        Double.longBitsToDouble(0x3fe3f4f041416216L), Double.longBitsToDouble(0x3fdd517fd24d81ceL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[28, -69, -31, -26, -35]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "\uda4c\udeeb\ud811\udf16\u1a0d", "\ua23d\u154e\u7eb0\u4159\u4127\u9359\u4755\u53b8", "\ud954\udcf2\ud9d3\udedd\udb55\udd1a\ud9f6\udc1e\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\udbb6\udcb3\udbb7\udd42\udae5\udea2",
        53, 63215, -1001919649, 7435346989806060441L, -27525L, false, true, (char) 54491, (char) 55607,
        Double.longBitsToDouble(0x3fb4ecad7af55638L), Double.longBitsToDouble(0x3fec871449d5b993L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\000", "\u8485", "\ud909\udf54",
        52, 88397, -1037317521, 6913977198170644049L, -83041L, true, true, (char) 24234, (char) 0,
        Double.longBitsToDouble(0x3e4ee1d400000000L), Double.longBitsToDouble(0x3fa20407296f2d10L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 2, 5, 3, "\udb89\ude1c\ud811\udf16\ud8ca\udc2e\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\udabc\ude70\ud9e9\ude71\uda3b\ude93", "\u6cd0\uc943\u8084\u4650\ua93f\u2042\u2a62\u2185\u3ffd\u3b5a\u7c10", "\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c",
        39, 17716, 1748162498, 5824368447978934355L, 22498L, true, false, (char) 20543, (char) 60563,
        Double.longBitsToDouble(0x3fb6c1a839199b08L), Double.longBitsToDouble(0x3fcdff4b7872b4a0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 5, 4, 0, "\udae3\uddcf", "\u8485", "\000\ud8c1\udd60\ud809\ude92",
        54, 264, 1109171793, 162468707777L, -79187L, false, false, (char) 3218, (char) 32040,
        Double.longBitsToDouble(0x3fa2040700000d10L), Double.longBitsToDouble(0x3fde28300d469996L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-22, -69, -31, -26, -35, 7, 13, -33]]\012",
        Z.run(T, 1, 3, 5, 5, "\uda1a\udceb\ud811\udf16\u1a0d\udb37\udd3d\ud90f\udea0\ud9a6\udfb6\udb78\udc1f\ud960\udea7\udb36\udc9e\ud899\udfdf\udad3\udc32\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda54\udf64\ud8fc\ude09\ud8b1\udee0\uda0a\udf18\uda68\udf13\uda7e\udc4e\udb4a\udff2\udbb7\udd42\ud9a1\udc41\ud94e\udc23\ud995\udf45\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\uda08\udf8a\ud98f\ude1f\ud8ce\ude98", "\u4c66\ub20e\u2120\ucec3\u6072\ub5be", "\udbc8\ude17\ud85b\uddd7\uda5e\udda4\udb14\ude2d\udb8c\udfac\ud8ea\udd03\udbff\udef8\udba0\udcaa\ud84f\udeaa\udb5f\ude5b\ud8b2\udcc0\udb03\udf95\uda4f\udde4\ud90c\udebb\udb3d\udcce\uda21\udd32",
        12, 14775, 887202912, 5989871399774100066L, -4981L, false, false, (char) 11235, (char) 58752,
        Double.longBitsToDouble(0x3fd86d11bf8398deL), Double.longBitsToDouble(0x3f8d9730bc12c200L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 0, 0, "\uda1a\udceb", "\u8485\000\uc21e", "\ud809\ude92\ud8a9\udeca\uda54\udc3c\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02",
        51, 99208, -221147100, -8945931623572963328L, -100000L, false, true, (char) 6357, (char) 43457,
        Double.longBitsToDouble(0x3f14f70000000000L), Double.longBitsToDouble(0x3fb9400000033880L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 3, 5, "\uda1a\udceb\udbbf\udf6c\ud98a\ude68\ud9db\udfbc\ud920\udc3d\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda54\udc3c\ud94a\udd81\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\uda3c\udf26\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\ud8b1\udee0\uda0a\udf18\uda68\udf13\udb84\udd7a\udb4b\udc9f\udbb7\udd42\ud9a1\udc41\ud930\udf8c\uda98\udfd5\ud8ce\ude51\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\udb27\udfc7\udb47\udfe3", "\u4c66\u2928\u18ae\u3140\u6072\u9ed7", "\udbc8\ude17\ud85b\uddf7\uda5e\udda4\udb14\ude2d\udb8c\udfac\ud8ea\udd03\udb88\udc05\uda4b\udf10\ud84f\udeaa\udb5f\ude5b\ua9fd\udaea\udfd2\uda4f\udde4\u7ac4\ud9c4\udcd8\uda21\udd32",
        12, 14775, 887164244, 5989871399774100066L, -4981L, false, false, (char) 15843, (char) 32516,
        Double.longBitsToDouble(0x3fe92a45c7c1dc6eL), Double.longBitsToDouble(0x3f8d9730bc12c200L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 3, 5, "\uda1a\udceb\ubd06\u1a0d\u5d8d\ud90f\udea0\udb2d\ude47\ud909\udf74\ud8ea\udcd6\ud96e\udcca\ud9e7\ude1e\udbea\udfd1\ud974\ude36\ud97b\udfc4\ud9fc\udf27\uda3a\udcd1\u18d5\udbcb\udda6\ud9cd\udc18\ud9f6\udc1b\udaf2\udd0a\u0cb3\u6b38\udbd5\udc55\uda1d\udc31\uda0a\ude95\uda68\udf13\udb84\udd7a\udb4b\udc9f\udb8a\udf4f\ud9a1\udc41\ud870\ude41\ud8ed\udfb6\ud8ce\ude08\udb95\udd77\uda98\ude23\udbaa\ude9f\ud904\uddb8\udb14\udde9\uda7b\udc0d\ud84d\udca4\ud966\udc67", "\u1df1\u2928\u18ae\u3140\u6072\ub5be\ucd67\u7139\u5371\ud3de\u62d3\u1440\u33ab\u712f\ubd8b", "\udb5f\ude5b\udbd0\udc0e\ud8a3\udd69\uda4f\udde4",
        24, 28068, 1588647838, -2218322101850950969L, -80467L, false, false, (char) 27881, (char) 10653,
        Double.longBitsToDouble(0x3fc0a5e993569454L), Double.longBitsToDouble(0x3fd03c1da10163d2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-22, -69, -31, -26, -35, -96, -72, -33]]\012",
        Z.run(T, 1, 3, 0, 5, "\uda1a\udceb\ud811\udf16\u1a0d\udbd0\udce8\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda54\udc3c\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda92\udfd2\udb7c\udc9c\ud8b1\udea1\uda0a\udf18\uda68\udf13\udb84\udd7a\udb4b\udc9f\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u4c66\ub890\u18ae\u3140\u6072\ub5be", "\udbc8\ude17\ud85b\uddf7\uda5e\udda4\udaa8\udd76\uda0f\udce6\udbfe\udf97\ud8a2\udee5\ud9dd\udc1b\ud84f\udf0a\udb5f\ude5b\u4c24\udbec\ude28\ud921\udc6e\udb5e\udf7e\ud9c4\udcd8\uda21\udd32",
        12, 14775, 887202912, 5989871399774100066L, -4981L, false, false, (char) 11235, (char) 58752,
        Double.longBitsToDouble(0x3fd86d11bf8398deL), Double.longBitsToDouble(0x3f8d9730bc12c200L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 5, "\ud8bf\udd8a\ud977\udecf\u1a0d\ud99b\uddab\ud9ad\udeb7\ud95f\udcc1\ud90a\udc1a\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\udbe0\uddfc\udb10\udcd6\udbd1\uddf1\ua809\udab3\udfe7\ud9bb\ude62\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud962\udec7\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f\u189c", "\udb59\udecd\ud8f8\uddf4\uda0b\udce2\udbeb\udd49\udbb4\ude73\udad7\udf70\ud811\udfeb\udb14\ude2d\udb8c\udfac\ud8e2\udcf9\ud9b1\udfc4",
        5, 95273, 479134893, -7004827163863604989L, -84675L, false, false, (char) 30865, (char) 7310,
        Double.longBitsToDouble(0x3fce63600f46d3d0L), Double.longBitsToDouble(0x3fe82b9047faf19eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 3, 5, "\uda1a\udceb\uda3d\udf0c\u1c6d\udb87\uddaf\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud979\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\udbe0\uddfc\udb10\udcd6\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\uda96\uddb7\udadc\ude07\ud88b\uddf1\udbff\ude1f\ud99d\udd02\ud83e\ude2f", "\u187f\u189c\u9f2d\u3140\u6072\ud6bf\u7e2c\uafcc\u87ef\u37ec\u62d3\u1440\ub37d\u5eb6\ubd9d\ua186\u5198\u0e86\ua797\u528f\ub756", "\udbce\udef6\ud86d\udca4\uda35\ude13\ud907\udd00",
        38, 46724, 1523906358, 4845429176385028365L, 21129L, true, true, (char) 19788, (char) 23884,
        Double.longBitsToDouble(0x3fe6d1aa575c9fe8L), Double.longBitsToDouble(0x3fe987442eba0460L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 5, 2, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74", "\u4127\u9359\u24ac\u53b8\u4979\u1470\uce53\uc936\u6cd0\uc943\u8084\u4f71\u68e4\u136d\ub792\u5d27\ubce1\u008f\u7c10\u0517", "\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\uda51\udcfc\ud8ce\ude98\uda62\ude8e\ud838\ude03\uda74\udce5\uda45\ude91\udbe9\udfb6\ud85b\udf62\udb59\udecd\ud8ab\udc0d\udbf2\udc19\ud90d\ude48\ud8f5\udf53\ud86a\ude04\uda5e\udda4\udb14\ude2d\udb8c\udfac\ud8e2\udc48\ud9b1\udfc4\uda60\udcb0\ud84f\udeaa\udb5f\ude5b\ud96c\udc14\ud819\udd4b",
        13, 90566, 1729342124, 8479539548686549088L, -34860L, true, true, (char) 19518, (char) 24681,
        Double.longBitsToDouble(0x3fd2b20c13d2524cL), Double.longBitsToDouble(0x3fe5f1e84288c9edL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 0, 2, "\uda1a\udceb\ud811\udf16\u1a0d\ud9bf\udc2c\ud91d\udc46\uda53\udcb0\ud909\udf74\udbe1\uded1\ud809\ude1d\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\udb23\udf8a\ud9fd\udc44\udb6c\udc72", "\ua42e\ua484\ubea5\u7650\ubb37\ua457\u5cfc", "\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud8a8\udec8\ud995\udee2\ud8c9\udd14\udadd\udd7b\udad0\udd00\ud91e\udecc\ud92e\ude6d",
        1, 8522, 1356091455, -7005612746680619516L, -65357L, true, false, (char) 17028, (char) 45898,
        Double.longBitsToDouble(0x3f9cad28f0bd9aa0L), Double.longBitsToDouble(0x3fd98657c870c0f2L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 6, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\udb1d\udd6d\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\udbe0\uddfc\udb10\udcd6\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\udabf\udd3e\uc9e0\000\000\000\u26a5\ub765\000\ud926\udc3f\ud92e\ude6d\ud8c7\udce0\udbfb\udfc4\ud99d\udcc3\ud8ce\ude98", "\u187f", "\ud85b\udf62\udb59\udecd\ud8ab\udc0d\udbf2\udc19",
        9, -848, -627031040, 5705811112284949653L, 38658L, true, true, (char) 54670, (char) 63325,
        Double.longBitsToDouble(0x3fd039ec924d81ceL), Double.longBitsToDouble(0x3feee9a3c2ac7520L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u995c\u8485\u59d1\000\000\000", "\uda29\udf48",
        23, 52902, -754974720, -5766952459213733888L, -75168L, false, true, (char) 38961, (char) 40295,
        Double.longBitsToDouble(0x3fe7141ece287891L), Double.longBitsToDouble(0x3fe9852e2e6268f9L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 0, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\udbe8\udcd5\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud895\udedc\ud9fc\udefa\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\uda0c\udf31\ud857\udf5d\u1b45\udbe0\uddfc\udb10\udcd6\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udff4\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud934\ude2d\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\udb25\udeb9", "\u187f", "\ud85b\udf62\uda15\uddeb\ud8ab\udc0d\udbf2\udc19",
        9, 48744, -627030984, -1288842058812488386L, 38658L, true, true, (char) 15759, (char) 5438,
        Double.longBitsToDouble(0x3fd039ec924d81ceL), Double.longBitsToDouble(0x3feee9a3c562cb20L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 5, "\uda1a\udc90\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\u2a42\uda21\udd81\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda3e\ude68\ud81b\udd9f\ud98e\udf7a\ud8d8\udfe2\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\uc58c\ud98c\ude22\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\ud9ea\udf09\ud8fa\ude55\ud92b\udf02\ud86b\udeb5",
        28, 72569, -627046357, 5705811112284949653L, 38658L, true, true, (char) 54670, (char) 53085,
        Double.longBitsToDouble(0x3f6c61dfb82f9900L), Double.longBitsToDouble(0x3fe8fceddaac7520L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 0, 5, "", "\u00b1", "",
        -5, 67664, -747044864, -2650517103577413009L, -100000L, false, false, (char) 42177, (char) 32558,
        Double.longBitsToDouble(0x3f45fef8186abc00L), Double.longBitsToDouble(0x3f455e200001c000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 2, 2, 1, "\uda1a\udceb\ud811\udf16\u1a0d\000\000\udb0e\udf27\ud909\udf74\ud8c1\udd60\ud809\ude92\ud8a9\udeca\ud8cd\udf3a\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udad9\udeeb\u00b8\000\000\000\ud846\udea3\udadc\udd5f\ud898\udcea\uda42\udd56\000\000\uda3d\udd0a\u3a4f\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc3f\ud92e\ude6d\udae5\udfde\ud7c2\udbe1\udce7\ud8ce\ude98", "\u187f", "\ud85b\udf62\udb59\udecd\ud8ab\udc0d\udb0f\udd67",
        40, 84492, -15284675, 5705810051428027541L, 96608L, true, true, (char) 53646, (char) 0,
        Double.longBitsToDouble(0x3e20000000000000L), Double.longBitsToDouble(0x3feee9a3c2ac7520L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 6, 2, "\uda1a\udceb\ud96b\udec3\u1a0d\ud8ad\ude78\udbc4\uddd3\ud884\udea4\ud909\udf5c\ud821\udc4a\ud809\ude8c\ud8a9\udeca\udacb\uddda\uda4c\udc98", "\u1470\u0519\ucfca\u6ccf\uc943\u8084\u1b98\ub83f\u73b2\u1f9b\u3d5d\u72bd\u3d68\ud7d1\u0517", "\ud93a\ude98\ud8ce\ude08\udb95\udd77\udb60\ude07\udaf1\udc30\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud84a\udd2f\udb5e\udec2\ud911\ude3a\ud8d0\udc3d\uda74\udce5\uda95\ude99\udbe9\udfb6\ud85b\udf62\ud82f\udc58\ud8de\udf07\udb0f\uddf7",
        40, 73076, -627046263, 5705811112284949653L, -35661L, false, true, (char) 17409, (char) 47629,
        Double.longBitsToDouble(0x3fddd3478afff188L), Double.longBitsToDouble(0x3feac7bfd2266213L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-43, -84, -25, -35, 39, 124, 16, 62]]\012",
        Z.run(T, 1, 3, 6, 5, "\u6305\udadc\udd17\u1a0d\ud857\udfac\uda40\ude6e\ud96e\udcd1\ud926\udcc4\udb49\udd9e\uc58c\udbaa\udcbb\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\udbd1\ude3b\ud857\udf5d\u1b45\uda3e\uddc1\udafe\udd51\udadc\udd5f\ud890\uddeb\udaa8\udf67\udac8\udc1a\ud9d6\udf39\udbb7\udd42\ud9a1\udc41\ud930\udf8c\udb87\ude0c\udb92\udd85\udb95\udd77\udb60\ude07\udb83\udc3b\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u5704", "\ud96c\ude10\uda30\udf76\ud8ce\udd2b\udb0f\uddf7",
        40, 73076, 1071581227, 5712333535520001173L, -35661L, true, false, (char) 49100, (char) 47629,
        Double.longBitsToDouble(0x3fddd3478afff188L), Double.longBitsToDouble(0x3fb63dfeac473cc8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\uda40\ude38\ud884\udea4\ud909\udf5c\ud821\udc4a\ud809\ude8c\ud8a9\udeca\uda29\udf48\ud9c3\ude1e\ud8f7\udcdc\udb6c\udc71\ud8f2\ude55\udb5b\udf1f\udb24\udd02\udaf2\udc8b\ud9f6\udc31\uda9f\udd01\u1ada\uda3e\uddc1\udafe\udd51\udadc\udd5f\ud890\uddeb\udaa8\udf67\udac8\udc1a\ud9d6\udf39\udbb7\udd42\ud9a1\udc41\uda62\udf85\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\udb83\udc3b\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\ud85b\udfe9\ud82f\udc58\ud8de\udf07\udb0f\uddf7",
        40, 73076, -627046357, 4115948084846400573L, -92367L, true, true, (char) 54670, (char) 63325,
        Double.longBitsToDouble(0x3fd039ec924d81ceL), Double.longBitsToDouble(0x3fcba68f15ffe310L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 0, "", "", "\ud90f\udea0",
        51, 14410, -747044864, 810720952320L, -59471L, false, false, (char) 0, (char) 7726,
        Double.longBitsToDouble(0x3fe38b8fb8000000L), Double.longBitsToDouble(0x3f455e2000000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 0, "\uda4c\udeeb\ud811\udf16\u1a0d", "\ub450\u11b4\u2d29\u5b03\u4127\u9359\u4755\u53b8", "\ud954\udcf2\ud9d3\udedd\udb55\udd1a\ud9f6\udc1e\ud83d\udc5d\u1b45\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\udbb6\udcb3\udbb7\udd42\udae5\udea2",
        53, 63215, -1001919649, 7435346989806060441L, -27525L, false, true, (char) 54491, (char) 55607,
        Double.longBitsToDouble(0x3fb4ecad7af55638L), Double.longBitsToDouble(0x3fec871449d5b993L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[28, -69, -31, -26, -35]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[28, -69, -31, -26, -35]]\012",
        Z.run(T, 2, 3, 3, 0, "\uda4c\udeeb\ud811\udf16\u1a0d", "\u6ad4\u83f0\u4ba3\ubbb7\u4127\u9359\u4755\ubf88", "\ud954\udcf2\ud9d3\udedd\udb55\udd1a\ud9f6\udc1e\ud857\udf5d\udb3f\ude20\uda3e\uddda\udafe\udd51\udadc\udd5f\ud96b\udc73\ud83e\udd54\ud9bb\ude1f\udbb6\udcb3\udbb7\udd42\udb26\udf34",
        53, 63215, -1001919649, 7435346989465248858L, -27525L, false, true, (char) 54491, (char) 55607,
        Double.longBitsToDouble(0x3fb4ecad72f55638L), Double.longBitsToDouble(0x3fec871449d5b993L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[-106]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "\ue4c6", "\ua66a\ud4f6\u88b2\u15f2", "\ud8a9\udeca\uda29\udf48\uda1f\udfc6\ud97b\udfaf\udaa4\udf1b\udac0\udcfd\ud954\udcf2\ud9d3\udedd\udb55\udd1a\uda87\udda6\udbe4\ude02\ud911\ude0f\ud943\udcc4\udafb\udc00\udadc\udd5f\ud8a8\udf92\ud83e\udcb2\ud9bb\ude1f\udbb6\udcb3\udb9c\udf42",
        48, 89048, 1045818215, -4303212123943622479L, -73537L, false, false, (char) 45417, (char) 13272,
        Double.longBitsToDouble(0x3fd05dc320a7656aL), Double.longBitsToDouble(0x3feaf5563f90e289L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 0, "\uda4c\udeeb\ud811\udf16\uda64\udd1b", "\u062f\u99e6\u8465\u65db\u9323\u64d5", "\udaa4\udf1b\udae4\udde2\ud954\udcf2\ud9d3\udedd\ud85f\udc1e\ud966\udeac\ud9c1\udebc\u1b45\uda2b\ude3a\udbcb\ude69\udadc\udd5f\ua7f5\ud83e\udd5e\udbbb\udec6\udbb6\udcb3\udbb7\udd42\udae5\udea2\ud942\udef8",
        -5, -649, 1731176625, 7865822180517511911L, -4500L, false, true, (char) 28471, (char) 63496,
        Double.longBitsToDouble(0x3feaf5563f90e289L), Double.longBitsToDouble(0x3fdd5b99393a0950L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[28, -69, -31, -26, -35]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 1, 0, "\uda4c\udeeb\ud811\udf16\u1a0d", "\ua23d\u154e\u9833\u1278\u4127\u9359\u4755\u53b8", "\ud954\udcf2\ud9d3\udedd\ud84d\udd35\udbbd\ude14\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\udbb6\udcb3\udbb7\udd42\udae5\udea2\ud8b4\uddb0\uda70\udd4d\ubfda\udad5\udec5\udb60\ude07",
        2, 41419, -48663284, -2579762409602941691L, -9341L, true, false, (char) 26016, (char) 7211,
        Double.longBitsToDouble(0x3f9721eb879a26a0L), Double.longBitsToDouble(0x3fe82cbefe7abe73L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[28, -69, -31, -26, -35]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[28, -69, -31, -26, -35]]\012",
        Z.run(T, 2, 3, 3, 5, "\uda4c\udeeb\ud811\udf16\u1a0d", "\ua23d\u154e\u7eb0\u4159\u4127\u9359\u4755\u53b8", "\ud954\udcf2\ud9d3\udedd\udb55\udd1a\ud9f6\udc1e\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\udbb6\udcb3\udbb7\udd42\udb67\udfcc",
        -2, 8543, -1001919649, 7435346989806060441L, 38011L, false, true, (char) 54491, (char) 55607,
        Double.longBitsToDouble(0x3fb4ecad7af55638L), Double.longBitsToDouble(0x3fec871449d5b993L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[28, -69, -31, -26, 123, -18, 123, -33]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "\uda4c\udeeb\ud811\udf16\ud9ab\udf1e\u51ab\ud90f\udea0\ud9b9\udcb3\ud909\udf74\ud8ea\udcd6", "\u9359", "\udaa4\udf1b\udac0\udcfd\ud954\udcf2",
        53, 89031, 135137189, -949819564188128618L, 3L, false, true, (char) 32603, (char) 9897,
        Double.longBitsToDouble(0x3fe356c401d5fb0fL), Double.longBitsToDouble(0x3fde07496305636cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 3, 3, 0, "\ud82f\udc43\uca41\u1af8", "\u83c2\u17e6\u4275\u4159\uc127\u7e9b\u7f94\ud622\u3058", "\ud8fb\udc7d\udac3\ude2f\ud849\udff0\ud857\udf5d\ud82a\udd75\udbef\udc66\udb97\udfcb\udaed\udec6\ud914\udd5b\ud845\uddc2\uda74\udd79\udbb6\udcbf\ud81a\udfd4\udace\udced\uda03\udd8c",
        4, -649, 1360955554, 3686481460287966300L, -4500L, false, true, (char) 55607, (char) 33025,
        Double.longBitsToDouble(0x3fe9a17638c7cc44L), Double.longBitsToDouble(0x3fdcfb9339f24efcL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 3, 5, 5, "", "", "\000",
        -5, 30232, 0, 0L, -100000L, false, false, (char) 42177, (char) 32558,
        Double.longBitsToDouble(0x3fe59d7fb8000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 2, 3, 3, 2, "\uda1a\udceb\ubd06\u1a0d\u5d8d\ud90f\udea0\udb2d\ude47\ud8b5\ude0a\udad7\udf04\ud96e\udcca\ud9e7\ude1e\udbea\udfd1\ud974\ude36\ud97b\udfc4\ud9fc\udf27\uda3a\udcd1\u18d5\ud99d\uddd0", "\ua244\u40df\u684e\u812f\ube99\u06d9\ub740\u5e92\u1119\u2b23\u2591\ua7be\u49ee", "\uda98\ude23\udbaa\ude9f\ud904\uddb8\udb14\udde9\uda7b\udc0d",
        57, 62268, -216608616, -4260956078853298826L, 18829L, false, false, (char) 22956, (char) 55205,
        Double.longBitsToDouble(0x3fcf5b5412553cbcL), Double.longBitsToDouble(0x3fe2e6b9c7398afbL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[8, -89, -42, -35, 93, -37, -64, -3]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[8, -89, -42, -35, 93, -37, -64, -3]]\012",
        Z.run(T, 2, 3, 3, 5, "\uda38\uddd7\ubd06\u1a0d\u5d8d\ud90b\udff0\udb2d\ude47\ud909\udf74", "\u2e55\u7d8b\ucad2\u53d5\u4979\u426c\u17ef\u7936\u4d19\u0419\u1291\u09f5\u3cfc\u2824\u0f6b\ud765\ub740\u5e92\u1119\u2b23", "\ud8ed\udfb6\ud8ce\ude08\udb95\udd77\ud93e\udf76\udbaa\ude9f\ud904\uddb8\udb14\udde9\uda7b\udc0d\ud84d\udca4\ud966\udc67\ud8af\udf43\udb89\udf89\udb29\udf1e\udabe\udf9d\ud9f4\udd79\ud85b\udf62\udb59\udecd\ud8dd\udc66\uda33\udf46\ud868\uddce",
        46, 30102, 302484818, -2938411695816874404L, -64179L, true, true, (char) 9261, (char) 46119,
        Double.longBitsToDouble(0x3fc9e391fe95ec14L), Double.longBitsToDouble(0x3fe66ed0cb2bdc78L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\uda40\ude38\ud884\udea4\ud909\udf5c\ud821\udc4a\ud809\ude8c\udaa3\udec7\uda29\udf48\ud9c3\ude1e\ud8f7\udcdc\uda18\udc67\ud8f2\ude55\u00e7\000\udad9\udeeb\ud9f6\udc31\uda9f\udd01\u1ada\ubd3b\udadc\udeae\udadc\udd5f\ud890\uddeb\udaa8\udf67\udac8\udc1a\ud9d6\udf39\udbb7\udd42\ud9a1\udc41\uda62\udf85\ud995\udf13\ud8ce\ude08\udb95\udd12\udb60\ude07\udb83\udc3b\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f", "\u2ce2\ud82b\udd35\ud8de\udf07\ud6ac",
        27, -756, -627048448, 220976067379200L, -92367L, false, false, (char) 54445, (char) 63325,
        Double.longBitsToDouble(0x3fd039ec924d81ceL), Double.longBitsToDouble(0x3fcba68f15ffe310L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[8, -89, -42, -35, 63, 93, 62, -73]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[8, -89, -42, -35, 63, 93, 62, -73]]\012",
        Z.run(T, 2, 3, 3, 5, "\uda38\uddd7\ubd06\u1a0d\ud96f\udd8d\ud86e\udee7\udb2d\ude47\ud909\udf74", "\u46b1\u86d3\ucad2\u53d5\u4979\u426c\u17ef\u7936\u4d19\u0419", "\udb77\ude6e\udac6\udc9d\u44ef\uda08\udf22\uda68\udf13\udb84\udd7a\udb4b\udc9f\udb8a\udf4f\uda94\udce9\ud9ab\ude0b\ud8ed\udfb6\ud8ce\ude08\udb95\udd77\ud93e\udf76\udbaa\ude9f\ud904\uddb8\udb14\udde9",
        7, 76852, 884520268, -930327549809128698L, -8370L, true, true, (char) 12992, (char) 17028,
        Double.longBitsToDouble(0x3fcdff4b7f4ecc3cL), Double.longBitsToDouble(0x3fca1ed633d152e0L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 4, 5, 5, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\ud8ea\udcd6\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud97b\udfaf\ud9fc\udf27\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda3e\ude68\udafe\udd51\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\ud8ce\ude98", "\u187f\u189c\u9f2d\u3140\u6072\ud6bf\ua0d7\u7139\u5371\ud3de\u62d3\u1440\ub37d\u5eb6\ubd9d\ua186", "\ud981\udd14\ud819\udd4b\uda6f\udc3d",
        24, 72092, 1004695387, 2414897032032979273L, -64704L, true, false, (char) 20752, (char) 47511,
        Double.longBitsToDouble(0x3fea304aca81bd36L), Double.longBitsToDouble(0x3fe66466cb9727c6L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 0, "\uda1a\udceb\ud811\udf16\u1a0d\u5d8d\ud90f\udea0\udb2d\udeb4\ud909\udf74\udbe8\udcd5\ud809\ude92\ud8a9\udeca\uda29\udf48\ud974\ude36\ud895\udedc\ud9fc\udefa\uda3b\ude93\uda52\udc45\udb24\udd02\udaf2\udc8b\uda0c\udf31\ud857\udf5d\u1b45\udbe0\uddfc\udb10\udcd6\udadc\udd5f\ua7f5\ud83e\udd5e\ud9bb\ude1f\ud8c9\udf1d\udbb7\udd42\ud9a1\udc41\ud930\udff4\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud934\ude2d\ud92e\ude6d\ud8c7\udce0\udbff\udde5\ud99d\udd02\udb25\udeb9", "\u774f\u68dd\ub5c9\u2bd4\u36ab\ud6bf\u7e2c\uafcc\u87ef\u52ec\u0fc7\u5861\ub37d\u5eb6\ubd9d\ua186\u5198\u31fd\ua78b\u6e3a\ub756\u4532\uc9bd\uc0af\u9be9\u2654\u2bf3\u64a0\u4fac\u7cde\u96c8\ub7f3\uc99f\u4afc\u84e1\u36eb\uc6bf\u593b\u91fb\uaa74\uc702\u3374\u9241\u8ccf\u21f8\u4ed0\u5257\uc7f4\u5225\uc93f\u32c5\u5369\u669d\u7892\u790a\u5b3b\u87fe\u0747\u9da3\uaa26\ubee4\u9c8d\u71d0\u4939\uc7ad\ud511\u96ac", "\ud9f3\uddf2\udb6e\udc7f\udb45\udd52\udb3f\ude7e\ud89b\udcac\udb49\udf1c\ud9f9\udea4\udbb9\udfb7\ud9cc\udd5e\udb65\udfcd\uda98\udee8\ud8a7\udd50\ud909\udc57\ud99e\udd01\ud9e4\udc0d\ud8b3\udc05\ud9cc\udcfa\udad5\udfc4\udbcf\udf10\ud985\udcab\uda50\udd12\udada\udd59\ud9c6\udc2a\ud9dc\udccb\ud86e\udf96",
        52, 78594, -1991123609, -5239693890398877990L, -15454L, true, false, (char) 17, (char) 17327,
        Double.longBitsToDouble(0x3fd8186340675838L), Double.longBitsToDouble(0x3fc2a3fd729a4d08L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[28, -69, -31, -26, 123, -18, 123, -33]]\0121=new org.apache.commons.codec.binary.Base64InputStream:@? |a3=[B:[[28, -69, -31, -26, 123, -18, 123, -33]]\012",
        Z.run(T, 2, 3, 3, 0, "\uda4c\udeeb\ud811\udf16\ud9ab\udf1e\u51ab\ud90f\udea0\ud9b9\udcb3\ud909\udf74\ud8ea\udcd6", "\u9359", "\udaa4\udf1b\udac0\udcfd\ud954\udcf2",
        53, 89031, 135137189, -949819564188128618L, 3L, false, true, (char) 32603, (char) 9897,
        Double.longBitsToDouble(0x3fe356c401d5fb0fL), Double.longBitsToDouble(0x3fde07496305636cL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.Base64InputStream:@?\012",
        Z.run(T, 1, 2, 2, 0, "\ud85c\udce8\ud8b6\udd7a\u60f1\udad0\ude4c\ud92f\udf7f\uda96\udcc6\ud8ec\udc27\ud8ea\udcd6\uda2b\udce7\ud8fa\udf6c\uda95\ude1f\ud98c\udcc8\ud87f\udf51\ud9fc\udf27\udbbd\udeb4\uec3f\udb0a\udd93\udaf2\udc8b\ud9f6\udc31\ud857\udf5d\u1b45\uda3e\ude68\uda64\udfb7\udbc0\udd1a\udb11\ude89\ud864\udf0e\ud9cd\udf1f\udbca\ude3e\udbb7\udd0a\ud9a1\udc41\ud930\udf8c\ud995\udf13\ud8ce\ude08\udb95\udd77\udb60\ude07\ud926\udc8c\ud92e\ude6d\ud9bc\udc88\udbd2\ude00\ud99d\udd02", "\uac03\u187f\u189c\u9f2d\u87a3\u6072\ud571\uc42c\u42e0\u6271", "\ud9f4\udd05\ud863\udd35\uda1c\udc3e\ud8eb\udda5\uda60\udd49\ud84f\udeaa\udb5f\ude5b\uda90\udf45\ud99c\udff2\udac0\udda6\uebf8\udaa2\udf22\ud914\ude4f\udbc4\udd20\ud8e9\udced\uda9b\udf49\uda17\udca0\udae0\uddd4\ud98d\udda4\uda18\udfc3\ud898\udeb3\uda45\udf07\ud909\udfb3\udb41\ude94\uda9a\udc6c\udab5\ude96\udb80\udd36\udaf9\udfea\udac8\udd43\ud88c\udd2f\udb3c\ude50\uda3a\udf55\udb67\udc21\ud995\uddbd\u7371\ud8f1\udc4e\ud934\udf6f\ud8ee\udceb\u754a\udb7f\udf0b\udb64\udf0c\ud855\udf5a\ud920\udcb3\udb07\udf22\udbea\udfce\uca87\uce73\udaa9\udf90\ud9df\ude2b\ud87d\udd99\uda88\udfb3\ud902\udf1b\udab3\udd66\ud9dc\udd71\udaab\udf23\udaf1\udd1f\uc666\ud8e1\udd5a\udb79\udc6f\ud8f4\udcca\uda8f\ude96\ud9d5\udc50\ud859\ude03\udb4d\ude20\ud9e5\udc0a\ud9e4\uded2\ud806\udeab\ud9ab\udcde\ud838\udf59\udb1a\ude40\ud8f0\udd38\uda73\udcb0\uda51\udef1\udb94\udd52\uda61\udd40\ud889\udf89\ud8b2\udd09\ud858\ude16\ud94b\udd3d\ud902\udc6b\udba4\udd42\ud80c\udea0\udbd7\udfd2\uda2c\udc44\ud879\udff0\ud994\udcc6\ud938\udde5\udbca\udd8d\ud8c6\udfd3\ud97d\ude4e\udaf6\udd78\ud8d9\udf0c\uda0e\ude81\ud89a\udcae\uda13\udc66\udb11\ude84\uda24\udfbf\ud9e5\ude70\udaac\udc5a",
        16, 22369, -618960744, 4873025176930550617L, -12776L, false, true, (char) 18004, (char) 5351,
        Double.longBitsToDouble(0x3fef11f8ea148a0cL), Double.longBitsToDouble(0x3fe6e96cc6b0caa2L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base64InputStream|read||new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|read|[B,int,int|new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|markSupported||new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "C|org.apache.commons.codec.binary.Base64InputStream|<init>|java.io.InputStream,boolean,int,[B",
    "C|org.apache.commons.codec.binary.Base64InputStream|<init>|java.io.InputStream,boolean",
    "C|org.apache.commons.codec.binary.Base64InputStream|<init>|java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|read||new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|read|[B,int,int|new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
