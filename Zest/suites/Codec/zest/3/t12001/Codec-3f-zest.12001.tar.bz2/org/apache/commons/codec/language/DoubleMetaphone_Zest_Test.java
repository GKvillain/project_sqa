package org.apache.commons.codec.language;
import org.junit.Test;
import static org.junit.Assert.*;
public class DoubleMetaphone_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d",
        44, 15857, -1957680656, -4758436297087576427L, -86441L, false, false, (char) 18092, (char) 31124,
        Double.longBitsToDouble(0x3fb236fc20382a18L), Double.longBitsToDouble(0x3fdee8e561b3acbeL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\ud951\udea2\udac1\udf20\ud93f\udfa7\ud8f0\udeea\ud876\udd5f |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\ud8f0\udeea\ud876\udd5f", "\u1263", "\udb78\udc9c",
        44, 15857, 446522096, -385667807414193196L, -86441L, false, false, (char) 18092, (char) 31124,
        Double.longBitsToDouble(0x3fb236fc20382a18L), Double.longBitsToDouble(0x3fdee8e561b3acbeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a3=[Ljava.lang.String;:[[\u1263]]\012",
        Z.run(T, 1, 14, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d",
        44, 64001, -1957680733, -4758436297087525227L, -86441L, false, false, (char) 18092, (char) 21652,
        Double.longBitsToDouble(0x3fc8eb2f1b2c2d0cL), Double.longBitsToDouble(0x3fd77450a8cb81f8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 14, 6, "\ud951\udea2\000\ud93f\udf4e\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d",
        -4, -879, -1957680656, -4758436297087576427L, -86441L, false, false, (char) 18092, (char) 31124,
        Double.longBitsToDouble(0x3fb236fc00002a18L), Double.longBitsToDouble(0x3fdee00001b3acbeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 6, "\ud839\ude8a\udac1\udf32\ud945\udca7\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb5e\udd5d",
        38, 15857, 2003333360, 3694532017652004245L, -87915L, false, false, (char) 18092, (char) 31124,
        Double.longBitsToDouble(0x3fb236fc20382a18L), Double.longBitsToDouble(0x3fe38242b21a225cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 12, 14, 6, "\ud96e\ude91\uda21\udc82\udb65\udcbb\uda34\udd4f\udb49\udfae", "\u9982\u8c70\ua45b\u8014\u4b59\u5a75\u97a3\u8d56\u7016\u4f83\u9897\u0217\u31c6\u8bd4\u7070\ucf83\u8d81\u1059\u7d4e\ub80c\ucad6", "\u3d9c\uda44\ude95\ud1ed\udb5d\udf27\udb8c\udc32\ud954\udf57\ud964\ude44\udad5\udd1a\udaa4\ude1a",
        19, 63818, 1084453504, 3921198406085813980L, -86603L, true, true, (char) 58728, (char) 10475,
        Double.longBitsToDouble(0x3fee694263cd54b9L), Double.longBitsToDouble(0x3fe1537e0fe10ee3L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 6, "\ud824\udd1d\udaed\udc15\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263\u7248\ua45b", "\udb2e\udda1\uda48\udf0f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\uda15\udd57\udb1e\udd70\udbda\udcf3\ud98a\udc97\ud8d9\udd54\udbdd\udf79",
        28, 77496, -82285658, 8381434476117919412L, -14473L, true, false, (char) 34001, (char) 62380,
        Double.longBitsToDouble(0x3fead799d3667a75L), Double.longBitsToDouble(0x3fd91008d420a2aaL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 6, "\ud8d2\ude2c\udaca\ude6d\ud98c\uddf1\uda21\udcf7\ud8dc\ude18", "\u1263", "\udb7f\udf5d\ud87e\udcac\ud988\udc04",
        -4, 59214, 700782229, -7952809028507677943L, -34792L, true, false, (char) 43076, (char) 40760,
        Double.longBitsToDouble(0x3fd938a7e6b7f5daL), Double.longBitsToDouble(0x3fb8f62b6c9f6570L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 6, "\000\000\ud93f\udf4e\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d",
        44, 15857, -1957680656, -4758436297087576427L, -86441L, false, false, (char) 18092, (char) 3712,
        Double.longBitsToDouble(0x3fb236c020382a18L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 6, "\ud951\udea2\udac1\udf20Y\uda0e\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d",
        28, -1000, 0, -4827858799840389483L, -77544L, false, false, (char) 6400, (char) 95,
        Double.longBitsToDouble(0x3fac585a51795a70L), Double.longBitsToDouble(0x3fa2eb8568dfb5a0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 9, 2, 13, "\uda4d\udcae\ua470\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u765d", "\udb7f\udf5d",
        44, 15857, -1957680656, -4758436297087576427L, -86441L, false, false, (char) 18092, (char) 31124,
        Double.longBitsToDouble(0x3fc053be101c150cL), Double.longBitsToDouble(0x3fdee8e56a99acbeL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 6, 14, 6, "\ud8f6\udc47\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18\udb59\ude80", "\u7248\ua45b\u8014\u4b59\u5a75\u97a3\u4e61\u6ce4", "\uda15\udd57\udb1e\udd70\udbda\udcf3\ud839\udcce\ua57b\ud8bf\ude49\ud811\udfe8\uda9d\udf17\uda55\udcca",
        23, 74884, -1534240592, -89259467986814491L, -79081L, false, false, (char) 40958, (char) 38778,
        Double.longBitsToDouble(0x3f98d4b182ced2e0L), Double.longBitsToDouble(0x3fba1ecdfa183690L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d",
        44, -879, 0, -4827858799840389483L, 96608L, false, false, (char) 18092, (char) 31124,
        Double.longBitsToDouble(0x3e401c010c000000L), Double.longBitsToDouble(0x3fdee8e561b3acbeL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\uda0f\ude39",
        54, 15972, -1957680656, -4758436297087576427L, -86646L, false, false, (char) 18092, (char) 31124,
        Double.longBitsToDouble(0x3fc29d9a002ebaa4L), Double.longBitsToDouble(0x3fdee946b1b3acbeL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\ud9e9\udea6\ud9e6\ude97", "\u1263\u7248\ua45b\u8014\u4b59\u5a75\u97a3\u8d21\u7016", "\ud849\udd71\udba9\udc55\udbda\udcf3\ud98a\udc97\ud8d9\udd54",
        51, 72753, 480287632, 425052983783092316L, -83372L, true, false, (char) 27862, (char) 61855,
        Double.longBitsToDouble(0x3fe638c94f870f26L), Double.longBitsToDouble(0x3fde899094bd0f04L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 7, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d",
        44, 15857, -1957680656, -4758436297087576427L, -86441L, true, true, (char) 65526, (char) 31124,
        Double.longBitsToDouble(0x3fc5fb7e101c150cL), Double.longBitsToDouble(0x3fdee8e56fb3acbeL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Character:\000 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 7, 1, 8, "\uda8a\udeb8\ud83d\udcf5\udbea\udd42\uda34\udd9e\ud983\udd12\udbe9\udcb4\u5f99\udb7f\udcf1\ud830\udd56\udb94\ude77\udb7f\udf5d", "\u59b9\u9381\ucd37\u3b94", "\ud9cf\ude1c\udb31\ude69\udb15\udf26\u9404\udaad\udf30\udaa0\udd90\udbcf\ude61\ud993\uded8\ud9e5\udeaf",
        -3, 74390, 27655804, 5280642678048407264L, -4519L, false, false, (char) 11920, (char) 52137,
        Double.longBitsToDouble(0x3fe498f2ea8b487dL), Double.longBitsToDouble(0x3fec288ac4dd80f6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\udac4\udc03\ud8dc\udded", "\u9d5a", "\udb7f\udf5d\udbf7\udc0d",
        12, 1344, -1107886234, 2965936385055388243L, 7160L, false, false, (char) 31124, (char) 61497,
        Double.longBitsToDouble(0x3fe8382fff734b56L), Double.longBitsToDouble(0x3feca44a031cb658L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 5, "\uda64\udcf0\ud88a\udc77\udb90\udff0\udb39\ude39\ud8dc\ude69", "\ud413", "\udab5\udcb3",
        -1, 98645, -1957680788, -4758436297087576427L, -74314L, false, false, (char) 13280, (char) 39076,
        Double.longBitsToDouble(0x3fdc27c541c296d0L), Double.longBitsToDouble(0x3fee44083ddfe6adL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 6, "\ud8b9\udf5a\udb6f\udcf8\udb52\ude59\udb50\udc60\ud8dc\ude18\ud8cd\udcc6\udbfa\udd03", "\ua45b\ubd79", "\u1b1f\ud8a2\ude8d",
        0, 8247, 155700160, -8610611303423211948L, 20231L, false, true, (char) 43064, (char) 40760,
        Double.longBitsToDouble(0x3fe542785d5ae90eL), Double.longBitsToDouble(0x3fe855c8392c098eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 10, 14, 6, "\ud951\ude66\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d",
        -1, 2272, -1957680656, -4758436297087576427L, -86441L, false, false, (char) 18151, (char) 31124,
        Double.longBitsToDouble(0x3fb236fc20382a18L), Double.longBitsToDouble(0x3fdee8e561b3acbeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\udb75\ude14\ud921\uddef\ud940\udc27\uda34\udd6b\ud8dc\ude18\ud8cd\udcc6 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 13, "\udb75\ude14\ud921\uddef\ud940\udc27\uda34\udd6b\ud8dc\ude18\ud8cd\udcc6", "\uc23d\ua45b\u7804\u4b59\u5a75\u97a3\u8d21\u7016\u3edf\u39d3\uacf0\u5c06", "\ud8d9\udd54\udbdd\udf79\udb75\uddfa\ud8fc\ude3e\udba6\udcb0\ud86a\udd41\udbb2\udf8a\ud801\ude6d\u60c8\ud8e6\udff7\ud9b3\udd0e\udadb\uddfd\ud895\udef6\uda97\udd3a\ud96c\udd78\uda1d\udf46\uda01\uddf9\uda3c\udea1\udadd\udc06\udb8f\udf73\ud9bd\udc07\u39f6\uda63\udd1a\ud843\udecd\uda8d\udc49\ud83c\udfd9\udb02\udf70\ud935\udd42\ud909\udf4f\uda41\udc1d\ud8cc\uddee\udb53\udffd\ud9b0\udf86\ud91f\udf30\udb50\udea6\udbbd\ude0c\uda01\udc80\ud977\udca0\udb57\udfc3\ud8c6\udf33",
        -3, 81626, 698444321, 2819026575051692073L, -76465L, false, false, (char) 40066, (char) 29247,
        Double.longBitsToDouble(0x3fb503fe491595e8L), Double.longBitsToDouble(0x3fdf19063b84c87eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\ud951\udea2 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 6, "\ud951\udea2", "\uad05\u89ad", "\ud903\uded3",
        32, 90700, 248970878, 1194896127547304569L, -10758L, true, false, (char) 7192, (char) 23722,
        Double.longBitsToDouble(0x3fe5204a3896a616L), Double.longBitsToDouble(0x3fe8a074059edbf0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 14, 6, "\ud803\udf1b\udac1\udf20\udb51\udfb0\ud9c4\udd73\ud8dc\ude18", "\u1263", "\ud903\udfbf\ud87e\udcac\udb2e\uddf9",
        -1, 61043, 700782229, -7952809028507677943L, 78794L, false, true, (char) 33848, (char) 330,
        Double.longBitsToDouble(0x3fdee8e5661f16beL), Double.longBitsToDouble(0x3fee888be3be84b7L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\u994e |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 6, "\u994e\000\000\000\000", "\u1263", "\udb7f\udf5d",
        44, 15857, -1957680896, -4758436297788358507L, -48032L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fb236fc20382a18L), Double.longBitsToDouble(0x3f41cac367580000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 13, 6, "\ud951\udea2\udac1\udf20\ud940\udc0b\uda34\udd6b\ud8fc\udc2d", "\u1263", "\udb7f\udf5d",
        44, 15857, -1957680656, -4758436297087576427L, -86441L, false, false, (char) 23575, (char) 31001,
        Double.longBitsToDouble(0x3fb236fc20382a18L), Double.longBitsToDouble(0x3fdee8e561b3acbeL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 3, 7, 0, "\udaf5\udd18\ud978\udceb\udb25\udf1b\ud9a9\udcc6", "\u2e6c\u4a73", "\udb7f\udf5d\ud87e\udcac",
        42, 79072, -1182296431, 2821553495243883859L, 43206L, false, true, (char) 59539, (char) 33853,
        Double.longBitsToDouble(0x3f7c150cf7472b00L), Double.longBitsToDouble(0x3fed677fda2a0680L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:\ud86a\uded2\udadb\udfa1\ud93f\udfa7\uda34\udd6b\ud8dc\ude18 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 10, 10, "\ud86a\uded2\udadb\udfa1\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u313a\u7af2\u850a\u8014\u4b59\u5a75\u97a3\u8d21\u7016\u1784\u42c6\u3d03\ua3d6\u6b19\u442a\ubbf0\ua5a0\u3002\u5d17\u2f73", "\udbe8\udda6\udb72\udeac\ud896\udf57\uda65\uddd6\ud9f5\udc0a\ud835\ude59\ud86c\uddb5\uda91\udec5\udb73\uddd5\uda3b\udc99\udaa4\udc16\udb41\udde2\uda26\udf8b\udb87\udcd3\udb96\udce2\udb72\udd14\ud95b\ude9d\udbf9\udf0f\udaac\udefb\udbf0\ude96\udb14\udf95\udbc9\udd60\udbb8\udd6b\ud88c\ude87\ud96a\udc9e\uda87\uddd8\udbca\udffd\ud81c\udefd\ud8d5\udd11\uda5b\udcc3\udbdf\udfd3\udabc\udee3\udb64\uddfe\udab0\ude7a\udb07\udd9d\ud9d5\udc5b\udbbc\udeb5\ud8a0\uddfb\ud97b\udf88\uda4b\udf06\u472d\udb03\udd20\udb2a\udc3a\udb03\udc6e\ud831\ude34\udafa\udf0c\ud9a8\uded7\u5755\uda9a\ude1e\ud8b4\udd41\udbb6\udd12\uce81\ud9a1\udd5e\udbc8\udd69\ud927\uddde\ud828\udfe6\ud9e2\ude51\ud9c8\udc41\ud8ad\udc71\ud811\udd5e\ud849\udf65\ud8e2\uddfb\udb3a\udc7c\ud8d9\ude2f\udaaf\udc2d\udaee\udd38\udb66\udd66",
        30, 95981, 943877673, 3884209608559783629L, -41631L, false, false, (char) 21868, (char) 14834,
        Double.longBitsToDouble(0x3fd04b599a6b61c6L), Double.longBitsToDouble(0x3fe53c6960c79669L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 4, 13, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\ud958\udcca",
        24, 15857, -1957680656, -4758436298948051819L, -86441L, false, false, (char) 18092, (char) 31124,
        Double.longBitsToDouble(0x3fb236fc20382a18L), Double.longBitsToDouble(0x3fdee8e56a31e904L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a3=[Ljava.lang.String;:[[\u1244]]\0121=java.lang.Boolean:false |a3=[Ljava.lang.String;:[[\u1244]]\012",
        Z.run(T, 2, 14, 14, 6, "\ud951\udea2\udac1\udf20\udba0\udc1b\ub1a2\ud8df\ude2f", "\u1244", "\udb58\udf8a\ud98d\udf48\u029b\uda48\udf0f",
        27, 43229, -1851657645, 668726309790210506L, 58484L, false, false, (char) 37961, (char) 2932,
        Double.longBitsToDouble(0x3fe5b08ba3789c2aL), Double.longBitsToDouble(0x3fe18ac829920845L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Character:\000 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 1, 6, "\ud951\udea2\udb6c\udc4c\udab7\udd89\uda24\udcc1\ud8dc\ude18\ud8cd\udcc6\ud90b\udec7", "\ua45b\u2f52", "\uda48\udf0f\udadf\udf81",
        -1, 75355, 155699977, -6478785800145166186L, -77544L, true, false, (char) 43076, (char) 40760,
        Double.longBitsToDouble(0x3fecf44d8c9913cdL), Double.longBitsToDouble(0x3fcc16b63692a7bcL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 5, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb4d\udc83\ud87e\udcac\ud985\udde6\ud86d\udd50\udb19\udd19",
        19, 75500, 153078537, -6478785800145166186L, -54564L, true, false, (char) 43076, (char) 40760,
        Double.longBitsToDouble(0x3fe7c623996183dbL), Double.longBitsToDouble(0x3fee7a9dede7bf97L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u5d0f\uad05\u89ad\000\000\000\000\000\000", "\uda48\udf0f",
        -1, 43229, -1851657645, 223239515144192L, -72588L, false, false, (char) 330, (char) 43076,
        Double.longBitsToDouble(0x3fcb3acbf02d002cL), Double.longBitsToDouble(0x3fd6d1191d25ba64L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 4, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d\ud87e\udcac\udb2e\udda1\uda48\udf0f\ud905\udc3f\ud874\udd0b",
        15, 57977, -1508459868, 1045011679050492692L, -69932L, false, false, (char) 59821, (char) 32796,
        Double.longBitsToDouble(0x3fee231afed60851L), Double.longBitsToDouble(0x3fe17f35a1bb3a52L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 5, 11, 15, "\ud951\udea2\udac8\udc55\ud93f\udfce\uda41\udf8e\ud89d\udfbd\udb3b\udcfe\udb52\udda8\udaf4\udd29\udb79\udf26\ud916\udd58\ud86b\udfe9\u14e6\udb29\udd55\ud9db\udcd3\udadf\udf81\uda6a\udf31\uda8b\udca0\ud811\udd7e\ud987\udc95\uf5ca\ud985\udef5\udb54\ude33\ud8a6\udef9\udbf2\udfd3\udbf1\uddc2\ud9bb\udee7\udb44\udc4b\udbed\ude09\udb4f\ude2f", "\u9d62\ub6d2\u72fd\u3156\u55d0\ua107\ucaba\u6d9a\uc5dc\ub141\ua7c7\u8db5\u9a87\u54c6", "\ud877\udd3c\uda0c\udca4",
        16, 88918, 1880189621, -4283604800991562756L, 36739L, true, true, (char) 8586, (char) 16730,
        Double.longBitsToDouble(0x3fe3a92826e8fdc2L), Double.longBitsToDouble(0x3fe523ca121a5bbeL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 14, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\udb7f\udf5d",
        44, 64001, 1934633379, 2613837653036359297L, -86441L, false, false, (char) 18092, (char) 21652,
        Double.longBitsToDouble(0x3fdc7597874d36fcL), Double.longBitsToDouble(0x3fd34e4cc4d6a140L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 14, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u1263", "\ud875\udcc3",
        59, -398, 2001742335, -2260343866009617264L, -75574L, false, true, (char) 58470, (char) 16380,
        Double.longBitsToDouble(0x3fe94c90aa0eb758L), Double.longBitsToDouble(0x3fd13abbea658278L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 6, "\000\000\000", "", "",
        2, -753, 704643072, 9772800L, -100000L, false, false, (char) 40075, (char) 62231,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc2c00000503a00L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 7, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u6d36", "\udb56\udc5d",
        44, 41865, 950807354, -2778253715599663561L, -86441L, false, false, (char) 18092, (char) 21652,
        Double.longBitsToDouble(0x3fc8eb2f1b2c2d0cL), Double.longBitsToDouble(0x3fd77450a8cb81f8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 14, 6, "\uda26\udcdc\u00ee\ud93f\udf4e\udafd\ude4f\udba1\udf5d", "\ud565\uc2d3\u4a73\u64e4\ub9cb\u78b3", "\ud874\udd0b\udb7c\udd7e\u2b95\ud979\udf49\udb60\udeaa\udae7\uddf5\ud98a\udcd0\000\udbdd\udf79\ud9ce\udde7\udb73\udd03\ud974\udea8\ud960\udd15\udb45\udecb\udb0b\udde7\ud8e4\udc31\udb19\udee1",
        2, 38363, -1184076507, -2173662174147020779L, 3941L, false, true, (char) 58134, (char) 64300,
        Double.longBitsToDouble(0x3fe3a81a3d23b725L), Double.longBitsToDouble(0x3fd563cfa192e49cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 3, 14, 6, "\udb83\udda4\000\ud93f\udf4e\uda34\udd6b\ud8dc\ude18\ud8cd\udcc6\ud90b\udec7", "\u8e88\uc9db", "\udaff\udcdb",
        9, 66562, -1851719680, 668726573982464676L, -81153L, false, false, (char) 23093, (char) 6638,
        Double.longBitsToDouble(0x3fe18eb2fbd9fb04L), Double.longBitsToDouble(0x3fdf864cd86d8e78L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 7, 14, 3, "\ud951\ude83\ud92f\udc02\ud93f\udf4e\ud86b\udf24\ud8dc\ude54\ud927\udeb4\ud937\ude41", "\u4a73\u8014\ua429", "\ud92a\udd10",
        7, 91664, 195887610, -5598212879367221680L, -12008L, true, true, (char) 15807, (char) 51270,
        Double.longBitsToDouble(0x3fe2a336a5a1a9e1L), Double.longBitsToDouble(0x3fbcbabfd16a8a90L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 2, "\udbdc\udec9\ud906\udcd8\udbd6\udcda\uda34\udd3b\ud8dc\ude18\ud8de\udd8c\ud96b\udfbe\ud903\uded3\udb79\udf26\uda74\udf25\udb7f\udf5d\ud87d\udffa", "\u8d21", "\ud8b1\udfed\ud97c\ude29\udb1e\udd2e\udbda\udcf3\ud990\udc9aU\ud860\ude2a\ud9d6\udf6b\ud890\udc3a\udab9\udfd4\ud953\udfaa\udb62\udcb1\ud96c\udc47\udb71\udcbb\ud872\udf82\uda26\uddea\udad8\udc20\udb67\udda7\u63f7\ud81a\udd19\ud819\ude80\uda0e\udc72\uda09\udd9f\uda9f\udccf\ud9c2\uddf9\ud9be\ude9e\udbd6\udeea\ud844\udf2f",
        0, 3241, -2033586617, -5533446920431318105L, -26190L, false, true, (char) 528, (char) 12275,
        Double.longBitsToDouble(0x3f7a6b3a9a947f00L), Double.longBitsToDouble(0x3fd6cb264cc28f3cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 4, 15, "\uda10\udf8d\000\ud87c\udeee\uda34\udd6b", "\u6750\u1263", "\uda95\udc59",
        43, 17706, -1889953816, -4814775543477758315L, -25218L, true, true, (char) 33848, (char) 1347,
        Double.longBitsToDouble(0x3fe7700000d9d65fL), Double.longBitsToDouble(0x3fd91d3f399cb48cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 6, "\ud839\ude8a\udac1\udf32\ud97f\udf8c\ud86f\ude0f\ud8dc\ude04", "\u1263", "\ud89a\udfdb",
        6, 23655, 2003333360, -2853058699178984046L, -87915L, false, false, (char) 18133, (char) 54316,
        Double.longBitsToDouble(0x3fb236fc20382a18L), Double.longBitsToDouble(0x3fe3808a71f55819L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 6, 10, "\ud839\ude30\udac1\udf32\ud945\udc55\uda2c\udfe7\udaa6\ude68\ud8ec\udd76\ud860\uddf2\ud903\ude5b\udb79\udf26", "\u0733\u5a75\u6e39\u1b09\uc960\u1b0a\u1047\u1d56\u6f5a\u9056\u3685\ub1c3\u1729\u10cf\u09fe\u656e\u0d1f\u6727\u620a\ub4b6\u9278\uaaf3\u03ae\ua4a9\ucc49\u3393\u833e", "\ud9b0\ude8f\ud80d\udef1",
        47, 9356, -838009507, 4953363832610936609L, -86829L, false, false, (char) 60356, (char) 50083,
        Double.longBitsToDouble(0x3fd91c50339aefa8L), Double.longBitsToDouble(0x3fe39ff4c9390dccL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 12, 14, 0, "", "", "\udb49\udfae",
        31, 920, -469249367, 5405669234149956012L, -34286L, false, false, (char) 10736, (char) 41807,
        Double.longBitsToDouble(0x3fe4adefb25329c5L), Double.longBitsToDouble(0x3f83234200000000L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 7, "\ud96e\ude91\uda21\udc82\udb65\udcbb\uda34\udd4f\udb49\udfae\udae3\udc15\u90cc", "\ua45b", "\udb2e\udda1\uda48\udf0f\udadf\udfb6\ud874\udd0b\udb90\udfd1\ud9c0\ude5c\ud99e\ude6c\udb1e\udd70\ud8fb\udc9e\ud8da\udc4d\ud89f\udf88\u4813",
        20, 74206, 1624207923, -858304111472069137L, -43409L, true, false, (char) 46127, (char) 38534,
        Double.longBitsToDouble(0x3fa7769dc87bc730L), Double.longBitsToDouble(0x3fe823d3dc6eda66L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 11, 6, "\udbd7\udd4a\000", "\u7bc2", "\ud833\udda5\u19d1\ud945\udc2a\udb7f\udf5d\ud993\ude56\ud869\udfa0\uda54\udf3a\udaf0\ude8b\uda75\udd3b",
        4, 84912, -557894402, -6652452670479007646L, -35296L, true, false, (char) 51199, (char) 20113,
        Double.longBitsToDouble(0x3fd270c10c53dbaeL), Double.longBitsToDouble(0x3fb5015d09271968L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 0, 6, "\000\000\ud93f\udf4e\uda34\udd6b\ud8dc\ude18", "\u1263\u8748", "\ud87e\udcac\udb06\udf4f\udbb9\udc8e\ud8d4\udd28\ud874\udd0b\udbb8\udfd1\ud996\ude1e\uda15\udd80\udb1e\udd70\ud95e\ude4f\uda38\udc99\u37ad",
        -5, 60208, -302988083, -4418338220456927831L, -78998L, true, false, (char) 35095, (char) 36874,
        Double.longBitsToDouble(0x3fcddb46ab53df4cL), Double.longBitsToDouble(0x3fb442b922861a10L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.String:\ube00\000\ud93f\udf4e\uda34\udd6b\ud9d6\udc35 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 6, "\ube00\000\ud93f\udf4e\uda34\udd6b\ud9d6\udc35", "\u4202", "\udb7f\udf5d\ud87e\udcac\udb2e\udda1\uda48\udf0f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\uda15\udd57\udb1e\udd70\udb23\uddd1\ud98a\udc97\ud801\udc07\000\ud9b8\udc02\ud8c2\udfe8\udaac\udf55\ud95b\udc54\uda56\ude6e\ud9c7\udef8\udad9\uddbf\udbd4\udf9e\u1d1a\udbfc\udd39\ud93e\udfff\ud836\udf08\udad5\udf48\udaf2\udc06\ud868\udfc1",
        13, 93975, -669204722, -5497122984938905425L, -51008L, false, false, (char) 10244, (char) 48947,
        Double.longBitsToDouble(0x3fe37e8263956446L), Double.longBitsToDouble(0x3fe89f91526ed2fcL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 6, "\000", "\000", "",
        -5, -1000, 1476395008, 65150L, -72743L, false, true, (char) 11958, (char) 54411,
        Double.longBitsToDouble(0x3fb4ca7140000000L), Double.longBitsToDouble(0x3eb1c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 6, 14, 6, "\ud8f6\udc47\udac1\udf20\ud93f\udfa7\uda26\udc4a\ud8dc\ude18\udb59\ude80", "\u7248\ua45b\u8014\u4b59\u5a75\u8aa4\u4e61\u6ce4", "\uda15\udd57\udaa5\udf8b\udaad\udc22\ud949\ude0c\udbdb\udf4d\ud8bf\ude49\ud811\udfe8\uda9d\udf17\uda28\udcb5",
        9, 44423, -1534226947, -89259467986814491L, -79081L, false, false, (char) 40958, (char) 38778,
        Double.longBitsToDouble(0x3f98d4b1e2ced2e0L), Double.longBitsToDouble(0x3fba3366ba183690L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\ud951\udea2\udac1\udf20\ud93f\udfa7\ud9e9\udea6\ud9e6\ude97\uda90\udf48\ud90b\ude64\ud903\uded3\udb79\udf26\ud89a\udfe8\udba5\udfc5\ud87e\udc29\udb2e\udda1\uda48\udf0f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\ud849\udd71\udba9\udc55\udbe2\udf7d\ud98a\udc97\ud8d9\udd54\udbdd\udf79\ud844\udca1", "\u8c0b\u25b8\ua540", "\uda74\ude05\uda24\udfab",
        18, 44280, -441476514, -917058082902195270L, -83715L, false, true, (char) 4415, (char) 54746,
        Double.longBitsToDouble(0x3feddaee7b9292ceL), Double.longBitsToDouble(0x3fc56a35f62d181cL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\000", "", "\uda90\udf48",
        9, 84147, 1476682231, 3081616271802302078L, -72743L, false, true, (char) 11958, (char) 54411,
        Double.longBitsToDouble(0x3fe2994e2b0991a1L), Double.longBitsToDouble(0x3fe5204a3b81a7c8L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Character:\ud83d |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 7, 1, 1, "\uda8a\udeb8\ud83d\udcf5", "\u6958\ub137\u73bb\u7ab1\u5089", "\udb78\uddd5\ud905\uddc7\udb4d\udca9",
        2, 81425, 1256016941, -5335083138911735818L, 49297L, false, false, (char) 42049, (char) 7945,
        Double.longBitsToDouble(0x3fcb3ac93b9e11b0L), Double.longBitsToDouble(0x3fe21fb9751e8227L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Character:\000 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 7, 1, 8, "\uda8a\udeb8\ud83d\udcf5\udbea\udd42\uda34\udd9e\ud983\udd12\ud9c1\udcc0\u5f99\udb7f\udcf1\ud830\udd56\udb94\ude77\udb7f\udf5d", "\uc65b\ud0e2\u0745\u12a8", "\ud9cf\ude1c\udb31\ude69\udb15\udf26\u9404\udaad\udf30\udaa0\udd90\udbcf\ude61",
        26, 21054, 1620362057, -6336939102341562756L, -4519L, false, false, (char) 11920, (char) 52137,
        Double.longBitsToDouble(0x3fe498f2ea8b487dL), Double.longBitsToDouble(0x3fec288ac4dd80f6L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Character:\000 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 7, 1, 1, "\ud851\udfbc\ud83d\udcf5\ud967\uddc3\udab9\udcbb\ud863\udf21\ud849\ude23\uda9c\udf3b\ud909\udd25\ud830\udd56", "\u8155", "\ud93e\ude16\ud92c\udf45\ud809\udff2\ud813\udd4f",
        -2, 95815, 1384307085, -6606617316863836175L, 5143L, true, false, (char) 47648, (char) 39451,
        Double.longBitsToDouble(0x3fedb4a7ab766005L), Double.longBitsToDouble(0x3fe3e540748a01a5L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 7, 7, 8, "\uda8a\udeb8\ud83d\udcf5\udbea\udd42\uda34\udd9e\ud983\udd12\ud945\ude2a\udac0\uddc6\udb08\udedc\udb51\udda5\udb34\udd98\udb7f\udf2d\ud94f\ude95\ud8a1\udf31\udba7\udcf8\uda56\udd42\ud900\udc51\ud8c0\udc0c\udaca\udcd1\udbc3\udea9\uda15\udf49\ud8ba\udcbb\ud87e\uddb3\ud8dc\udff9\udaad\udef9\udaa0\udd90\udbcf\ude61\ud993\uded8\ud9e5\udeaf\ud816\udcfa\ud8cd\ude47\udb09\ude09\udb55\uddc5\ud9b3\udda2\ud87b\udffa", "\u19e8\u2eed\ub07d\u571a\uad60\u47c8\u54db\u7acc\u1883\u2494\u83b0\uc86c\u40c9\ud0a2\u7fdf\u4c0f\u2bea\ub065\uc311\u4a24\u26f7\u1b38\ua745\u9e89\u6754\u5e95", "\udb1d\udc9c\udade\ude61\udbd7\udd8e\udbe0\udd15",
        48, 72371, 1184285253, -8618722994046092290L, -36179L, false, false, (char) 6898, (char) 61142,
        Double.longBitsToDouble(0x3fce5c7c3de5c858L), Double.longBitsToDouble(0x3fc8f0036706c334L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 5, 5, 8, "\uda8a\udeb8\ud83d\udcf5\udbea\udd42\uda34\udd9e\ud983\udd12\udadc\udf2c\ud909\udee4\udb7f\udcb0\ud830\udd56\udb94\ude77\udb7f\udf5d", "\uc380\u9381\ucd37\u3b94", "\ud9cf\ude1c\udb31\ude69\udb15\udf26\u9404\udaad\udf30\udaa0\udd90\udbcf\ude61\ud993\uded8\ud9e5\udeaf",
        -3, 74390, 27655804, 5280642678048407264L, -29130L, false, false, (char) 59631, (char) 13064,
        Double.longBitsToDouble(0x3fec288ac4dd80f6L), Double.longBitsToDouble(0x3fddd9bc6588a552L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 4, 4, 10, "\uda8a\udeb8\ud83d\udcf5\udbea\udd42\uda34\udd9e\ud983\udd12\udbe9\udcb4", "\u7363\u80c6\u8014\u8155\ub2a9\u59b9\u9381\ucd37\u3b94", "\ud9cf\ude1c\udb31\ude69\udb15\udf26\u9404\udaad\udf30\udaa0\udd90\udbcf\ude61\ud993\uded8\ud9e5\udeaf",
        -3, 74390, 27655804, 5265063697794449120L, -4519L, false, false, (char) 11920, (char) 52137,
        Double.longBitsToDouble(0x3fe498f2ea8b487dL), Double.longBitsToDouble(0x3fec288ac4dd80f6L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 12, 14, "\uda8a\udeb8\ud83d\udcf5\udbc0\udd42\uda34\udd9e\ud983\udd12\udbe9\udcb4\udaa1\udf7d\ud836\ude48\ud821\udde4\udb94\ude77\udb7f\udf5d", "\ub740\u9381\u8097", "\udb6f\udd3f\udae3\ude27\udb31\ude69\ud994\udd45\u9404\udaad\udf30\udaa0\udd90\udbcf\ude61\ud993\uded8\ud9e5\udeaf\ud816\udcfa\ud8cd\ude47\udb71\ude94\uda4c\udcdb\uda34\udd62\ud8ed\udc32\udb82\udd6b\ud9a7\udc0b\ud8c7\udffe\udb7b\ude9c\uda7f\udee7\ud85e\udfdc\udb37\udfff\udacd\udc88\udbb8\uddf8\uda2f\udd2a\u72b2\uda3b\udfb1\ud83b\ude71\udb3b\udd50\udb80\udf18",
        11, 59096, 2127499515, -8073988968268595437L, 62303L, true, true, (char) 62362, (char) 13254,
        Double.longBitsToDouble(0x3fd6a5570a451a2eL), Double.longBitsToDouble(0x3f89f53704b64100L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "\ud951\udea2\ud9ac\uded6\ud93f\udffb\udac4\udc03\ud8dc\udded\ud8cd\udcc6\ud932\udfcb\udb20\udd51\udb3e\udc79\ud8aa\udc24", "\uc7f7\u9206\ucef3\uc5a8\u1385\u7af7\ud156\u31f6\u9056\u5364\u6c51\u97bf", "\udb7f\udeef\ud985\ude06\ud857\udd5d\uce7d\udb6a\ude7c\ud9c5\uddfb\ud85c\udd73\uda58\udd7d\uda1b\uddca",
        8, 56530, 504599502, 8036074740334441106L, -61557L, true, false, (char) 52005, (char) 5203,
        Double.longBitsToDouble(0x3feb99234e0cbb38L), Double.longBitsToDouble(0x3fca4a0d42e3aebcL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 13, 3, "\uda64\udcf0\ud88a\udc77\udb90\udff0\udb39\ude39\ud8dc\ude69\ud8cd\udcc6\udb3b\udef0\ud8fe\udc84\udb79\udf26\ud903\uddca\udab5\udcb3\ud80f\ude34\udb1f\udefa\ud901\udfb4\udadf\udf81\ud874\udd0b\udaa8\udd30\u2b95\udb36\udff6\udb1e\udd0b\ud9c9\udf06\udb6d\udf92\uda96\udf99\ud976\udd43\u5ce3\ud925\ude32\udadc\udfd8\uda73\ude33\ud9c2\udd65\udbc4\ude49\udb52\udd27\uda2a\udd1f\ud94d\udc31\ud886\udf45\ud90e\udfeb", "\u69d3\u94c8\u3075", "\udb62\udd0d\udba2\udd61\ud9a7\udece\uda8a\udd80",
        11, 51614, -1753276449, -1096263393092743230L, 60944L, false, false, (char) 49837, (char) 26780,
        Double.longBitsToDouble(0x3feb7d6ed2f21f3dL), Double.longBitsToDouble(0x3fd2b791dce90cbeL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 4, 9, 6, "\ud8b9\udf5a\udb6f\udcf8\udb52\ude59\udb50\udc60\ud8dc\ude18\ud8cd\udcc6\udbfa\udd03", "\ua45b\ubd79", "\u1b1f\ud8a2\ude8d",
        0, 8247, 151047104, -8610611303423211948L, -11588L, false, true, (char) 43064, (char) 40760,
        Double.longBitsToDouble(0x3fe542785d5ae90eL), Double.longBitsToDouble(0x3fe855c83c2c098eL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 5, 12, 6, "\ud8b9\udf92\uda75\udedb\udb52\ude70\udb50\udc60\ud836\udf12\ud8cd\udcc6\udbfa\udd03", "\ua45b\ubd79", "\u935a\ud8a2\ude8d",
        0, 8247, 155648448, -8610611303423211948L, 20231L, false, true, (char) 14435, (char) 40760,
        Double.longBitsToDouble(0x3fe542785d5ae90eL), Double.longBitsToDouble(0x3fe055c8392c841aL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 13, 5, "\ud94a\udf62\udac1\udf20\udbfc\ude1d\uda34\udd3f", "\u05a6\u676a\u7248\ua45b\u8014\u4b59\u5a75\u97a3\uc40b\u2e9c\u1784\u7524\u0be1\ub09e\u2257\u3685\u0551\u3cb2\u01ca\u17ba\u3c6f\ube81\u39c4\u3c31\u793c\ub278\u731a\u0980\u6bdd\u0e7d\u8cb0", "\ud907\udd4e\udbb1\udf35\udbb8\udcaf",
        23, 6584, 1731440354, 612460157097480899L, 54522L, true, false, (char) 54312, (char) 55262,
        Double.longBitsToDouble(0x3fecdde258f1a4c0L), Double.longBitsToDouble(0x3fec818548a583dfL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\udaf5\udd18\ud978\udceb\udb25\udf71\uda25\uddff", "\u4d26", "\uda13\udea0\ud977\ude59\ud919\udc77\ud8c9\udc50\ud9c3\udee1\udbc7\udfc2\ud901\udd8c\ud867\ude87\ud9f4\uddaf\udb52\ude3b\udafb\udc70",
        21, 45072, -1906902009, -1186951466686856276L, -1794L, true, false, (char) 57959, (char) 20940,
        Double.longBitsToDouble(0x3fca83c9803b2348L), Double.longBitsToDouble(0x3fde8d3b44d63514L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 5, 14, 3, "\ud951\udea2", "\u19a3\u33df", "\ud9f9\ude2e\udbaa\udc56",
        0, 35355, -1048760585, 3789411330622827168L, -8245L, false, false, (char) 23722, (char) 50114,
        Double.longBitsToDouble(0x3fc2d4c2d0503a00L), Double.longBitsToDouble(0x3fdf709fd84e0a86L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 9, "\ud951\udea2\udac1\udf20\ud93f\udfa7\uda34\udd6b\ud8dc\ude18", "\u6d36", "\udb56\udc5d",
        44, 41865, 950807354, -2778253715599663561L, -86441L, false, false, (char) 18092, (char) 21652,
        Double.longBitsToDouble(0x3fc8eb2f1b2c2d0cL), Double.longBitsToDouble(0x3fd77450a8cb81f8L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 3, 6, "\u5da0\udac1\udf20\ud931\udc83", "\u7d67\ub130\u7acc\u71b5\ua45b", "\ud804\ude41\udbf9\ude90\udbd8\uddb8\ud8a6\udcad\udbb8\udfd1\uda07\ude33",
        27, 9834, 1501054484, 811677930031652555L, 36091L, false, true, (char) 16642, (char) 14292,
        Double.longBitsToDouble(0x3fe616e689735cd3L), Double.longBitsToDouble(0x3febd8673410d996L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 15, "\ud95c\udc26\uda21\udc82\udb65\udcbb\uda34\udd4f\udb49\udfae\ud960\udd54\uda0f\udcb5\ua159\udb0b\udff2\ud893\udc31\udb7f\udf5d\ud87e\udcac\udb2e\udda1\uda48\udf0f\udadf\udfb6\udb36\udead\uda24\ude94\ud9cf\udf14\ud99e\ude6c\udb1e\udd70\u4baa\ud8ef\udc4d\ud89f\udf88\u4813\ud862\udf76\ud969\udccd\uda07\udfe7\ud906\udc41\ud868\udf7c\uda38\udfbf\u3d9c\uda44\ude95\ud9ef\udeab\udb72\udc0e\udab8\udd59\uda7b\udc8a\udad2\udccc\udba7\udc93\ud987\udfd8\ud86b\udde2\uda25\udf6d\u35f1\uda49\udc48\uda86\udd96\udb69\udf34\udaaf\udfc2\ud87c\uddc5\ud840\ude3d\ud899\udf5c\udb96\udd68\ud9b1\udcf4\uda96\udc42\udab9\ude18\udb16\udcd7\udb38\udff7\udb72\udffa\ud8fe\ude08\uda02\udd56\ud9d1\uddc2\ud800\udeae\ud80f\udc8f\uda2d\ude82\udba4\uddcb\ud854\uddb2", "\u732e\u7cef\u2e0a\ub195\u0203\u399d\u485b\u66a09\u7671\u91c5\u689d\u1907\u495c\u56c0\u35fb\u075b\u0145\u4df0\u90c5\u222c\u80bb\u986e", "\ud83a\udee4\udac2\udc7f\udbe0\udf94\ud9a3\udd81\udb6e\udc37\uda68\udefe\ud8ad\uded8\udb72\udf10",
        59, -343, -651604183, 4129599186751673402L, 23410L, false, false, (char) 5479, (char) 14946,
        Double.longBitsToDouble(0x3fd40057e43b3160L), Double.longBitsToDouble(0x3fc1050b7cd23494L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.String:L |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 11, 6, "\udae3\udfb1l", "\u7bc2", "\ud828\udfa5\u19d1\ud801\udf4a\udb7f\udfd8\ud993\ude56\ud869\udfa0\uda54\udf3a\udaf0\ude8b\uda75\udd3b",
        4, 84912, -557894402, -6652452670479007646L, -35296L, true, false, (char) 51199, (char) 20113,
        Double.longBitsToDouble(0x3fd270c10f5fdbaeL), Double.longBitsToDouble(0x3fb50153c9271968L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 6, "\ud82c\ude03\000\ud93f\udf4e\uda84\udc93\ud9d6\udc35", "\u4202", "\ud895\udf69\ud877\uddac\udace\udfb3\ud9bf\ude43\udbe3\ude3f\uda99\ude6d\udb9a\udeb2\u08d0\ud911\udcdb\ud87c\udf0e\ud913\uded9\udab5\udcc6\u15a2\000\ud97e\udf4d\ud820\udc40\udbd3\ude91\ud95b\udc54\uda56\ude6e\ud9cf\udf0b\ud9e9\uddc7\udbd4\udf9e",
        6, 47965, -848113926, -5282045774671570910L, -14972L, true, true, (char) 60385, (char) 37989,
        Double.longBitsToDouble(0x3fe47628a19292fdL), Double.longBitsToDouble(0x3fe62680803a373aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:\ube00\000\ud950\ude2e\udad5\udcbe\ud9ba\udcd1\ud8f8\udd2f |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 6, "\ube00\000\ud950\ude2e\udad5\udcbe\ud9ba\udcd1\ud8f8\udd2f", "\u72d1\u2eb1\u8014\u4b59\u5a75\u97a3\u8d21\u7016", "\uda15\udd57\udb1e\udd70\udb23\uddd1\ud98a\udc97\ud90f\ude53",
        0, 10176, 165960531, -854160320839935704L, -83835L, false, false, (char) 31879, (char) 22844,
        Double.longBitsToDouble(0x3fe3af1a66fa72deL), Double.longBitsToDouble(0x3fead66b912eb6b2L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\ud951\udea2\udac1\udf20Y\000\ud9e6\ude97\uda90\udf48\ud90b\ude64\ud903\uded3\udb79\udf26\ud89a\udfe8\000\000\ud910\udc07\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\ud849\udccd\u0081\udbe2\udedf\ud98a\udc97\ud8d9\udd54\udbdd\udf79\ud844\udca1", "\u8c0b\u25b8\ua540", "\uda74\ude05\uda24\udfab",
        18, 44280, -441476514, -917058082902195270L, -83715L, false, true, (char) 4415, (char) 54746,
        Double.longBitsToDouble(0x3f3773d800000000L), Double.longBitsToDouble(0x3fc56a35f62d181cL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\u00ab", "", "\uda90\udf48\uda2c\udd6d\ud903\uded3\ud80b\udc29\ud893\udc31\ud8c3\ude3f\ud87e\udcac",
        24, 1344, -1107930266, 3009969167163060819L, -52220L, true, true, (char) 64822, (char) 2001,
        Double.longBitsToDouble(0x3fc21d9f2d6edd64L), Double.longBitsToDouble(0x3fc2a63a771cfe78L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "o", "", "\uda90\udf48",
        9, 84147, 1476682231, 3081616271802302078L, 58329L, true, false, (char) 12054, (char) 54411,
        Double.longBitsToDouble(0x3fe2994e2b0991a1L), Double.longBitsToDouble(0x3fe5204a3b81a7c8L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\000", "\u9754", "\ud9a5\udd11",
        14, 50264, 6663084, 0L, -100000L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fde38420000012cL), Double.longBitsToDouble(0x3fecb77b5a140e80L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.String:L |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:L |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\udae3\udfb1l", "\u7bc2", "\ud828\udfa5\u19d1\ud801\udf4a\udb7f\udfd8\ud993\ude56\ud869\udfa0\uda54\udf3a\udaf0\ude8b\uda75\udd3b",
        4, 84912, -557894402, -6682289018204492166L, -35296L, true, false, (char) 51199, (char) 5009,
        Double.longBitsToDouble(0x3fe8a1f004f9d8e5L), Double.longBitsToDouble(0x3fb52c4cab871968L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\u9900\000\000\000\ud9e6\ude75\uda90\udf48\ud90b\ude64\000\udb79\udf26\ud89a\udfe8\000\000\ud910\udc07\uda3e\udd1ff\uda16\ude6a\000\udb10\udc87\ud849\udccd\u0081\udbe2\udedf\udbf2\udc4b\ud850\udd48\udbdd\udf79\ud844\udca1", "\000", "\ud80c\udd74\ud99a\udc6e\uda74\ude05\uda24\udfab\uda72\udd75\ud8c0\udece\u30d1\udbfc\udfc7",
        51, 88792, -1104396387, 3780881726680456391L, -100000L, false, true, (char) 15962, (char) 23442,
        Double.longBitsToDouble(0x3fe28316b71dad17L), Double.longBitsToDouble(0x3feb6ae984ed9f0cL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\ud951\udea2\udac1\udf20YV\ud9e6\ude97\uda90\udf48\ud90b\ude64\ud903\uded3\udb79\udf26\ud89a\udfe8\000\000\ud910\udc07\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\ud9a7\udf22\ud91b\udf62\u0081\udbe2\udedf\ud98a\udc97\ud8d9\udd54\udbdd\udf79\ud844\udca1", "\u8c0b\ua0b8\ua540", "\uda74\ude05\uda24\udfab",
        18, 44280, -441476514, -917058082902195270L, -83715L, false, true, (char) 4415, (char) 54746,
        Double.longBitsToDouble(0x3f3773d800000000L), Double.longBitsToDouble(0x3fc56a35f62d6350L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\udb45\ude4d\uda7d\udeadY\000\ud9e6\ude97\uda90\udf48\ud90b\ude64\ud903\uded3\udb79\udf26\ud9f0\udebc\ud862\udf89c\ud910\udc07\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\ud849\udccd\u0081\udbe2\udedf\ud98a\udc97\ud8d9\udd54\udbdd\udf79\ud844\udca1", "\u8c0b\u25b8\ua540", "\uda74\ude0a\uda24\udfab",
        18, 44280, -441476514, -917058082902195270L, -56390L, false, true, (char) 4415, (char) 54746,
        Double.longBitsToDouble(0x3f3773d800000000L), Double.longBitsToDouble(0x3fc56a35f62d181cL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "o\000\udb38\udedcA\ud9e6\ude97\uda90\udf48\ud90b\ude64", "\ua45b\u8014", "\ud8e2\udd78\udadf\udf81",
        -1, 75355, 155699977, -6356625659369489535L, 61120L, false, false, (char) 25465, (char) 29550,
        Double.longBitsToDouble(0x3fcdd5b47f6cfd18L), Double.longBitsToDouble(0x3fe80e841079715cL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 6, "\uda1f\udda4j\000\000\ud8bc\udfbc\uda97\udf23\ud8b3\uded9\u5d7d\udb79\udf10\ud893\udc31", "\uba98\u9e78\u8d21\u7016\u1784\uab2f\u36c7\u3735\u60f9\u9472\u01b9\u1c98", "\ud95a\udf07",
        41, 50796, -1865995907, -6129370684670970847L, 33503L, true, true, (char) 20277, (char) 8676,
        Double.longBitsToDouble(0x3fe3cb0b0452f306L), Double.longBitsToDouble(0x3fe5ad593c4be84fL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "k", "", "\uda90\udf48",
        9, 84147, 1476682231, -9096117120607524531L, 58329L, true, false, (char) 12054, (char) 11147,
        Double.longBitsToDouble(0x3fe2994e2b0991a1L), Double.longBitsToDouble(0x3fe5204a3b81a7c8L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\000\000", "\u7bc2", "\ud828\udfa5\u19d1\ud801\udf4a\udb7f\udfd8\ud993\ude56\ud869\udfa0\uda54\udf3a\udaf0\ude8b\uda75\udd3b",
        4, 84912, -557894402, -6682289018204492166L, -35296L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe8a1f004f9d8e5L), Double.longBitsToDouble(0x3fb52c4cab871968L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:SF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 15, "\ud92f\udca0\ud8b3\ude62\000\000\ud9e6\udeaa\uda90\udf48\ud90b\ude64\000\udb79\udf26\ud89a\udfe8\u00e7\000\ud910\udc07\uda3e\udd1ff\uda16\ude6a\000\udb10\udc87\ud849\udccd\u0081\udb9e\udd7c\udbf2\udc4b\ud850\udd48\udbdd\udf79\ud844\udca1", "\000", "\ud9c3\udcb6\udaac\udf04\ud937\udc5e\uda24\udfab\uda72\udd75\ud8c0\udece\u30d1\udba2\uddd9",
        51, 88798, -1104396387, 3780881726680456391L, -100000L, true, true, (char) 3613, (char) 23442,
        Double.longBitsToDouble(0x3fe0cb16b222ad17L), Double.longBitsToDouble(0x3feb6aeeeced9f0cL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\u99ae\ud852\udc08w\000\ud9e6\ude75\uda90\udf48\ud90b\ude64\ud8e5\uded2\udb79\udf26\ud89a\udfe8\000\000\uda84\udc90\u0a0b\ub7a6\uda16\ude6a\000\udb10\udc87\ud849\udccd\u0081\udbe2\udedf\ud967\udcd8\ud850\udd48\udbdd\udf79\ud844\udca1", "\u2b42", "\ud80c\uddf4\ud99a\udc6e\uda74\ude05\uda24\udfab\uda72\udd75\ud8c0\udece\u30d1\udbfc\udfc7",
        51, 88792, -1104396387, 3780881726680456391L, -100000L, false, true, (char) 15962, (char) 23442,
        Double.longBitsToDouble(0x3fe28316b71dad17L), Double.longBitsToDouble(0x3feb6ae984ae9f0cL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.String:MF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 9, "\u3413\u79f0m\udbce\udfc6\uda43\udf49\ud859\udc1d\ud90b\ude64\000\udb79\udf26\ud89a\udfe8\000\uf200\ud910\udc07\uda3e\udd1ff\uda16\ude6a\udbad\udc06\udb10\udc87\udbe3\udd98\uc602\udbe2\udedf\udbea\ude4b\ud850\udd48\udbdd\udf79\ud8d5\ude4f", "\u99e3\u0488\uc7b9\u1756\u71a8\u04e2\ua7e8\u7527", "\udbfc\udfe7\u00ba\u071c\udbb3\ude8b\ud9c1\ude39\udb0d\udf71\uda6e\udf37\udb66\udd49\ud932\udc18",
        16, 79387, -1390947760, 6715024397499633517L, -92600L, true, false, (char) 28490, (char) 31625,
        Double.longBitsToDouble(0x3fbe92b497faa9e8L), Double.longBitsToDouble(0x3fd713e702ed4c62L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\u9900\000\000\000\ud9e6\ude75\uda90\udf48\ud90b\ude64\000\udb79\udf26\ud89a\udfe8\000\000\ud910\udc07\ud87c\ude95h\uda16\ude6a\udad6\udc0a\udb10\udc87\ud849\udccd\u0081\udbe2\udedf\udbf2\udc4b\ud850\udd48\udbdd\udf79\ud844\udca1", "\000", "\ud95a\udd70\u7cdf\uda74\ude05\ud9b9\uded6\uda72\udd75\ud8c0\udece\u30d1\udbfc\udfc7",
        51, 88792, -1104396387, 3780881726680456391L, -100000L, false, true, (char) 15962, (char) 23442,
        Double.longBitsToDouble(0x3fe28316b71dad17L), Double.longBitsToDouble(0x3feb6ae984ed9f0cL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\udb30\udfb5\000\000\000\ud9e6\ude9c\uda90\udf48\ud90b\ude64\000\udb79\udf26\ud89a\udfe8\000\000\ud910\udc07\uda3e\udd1ff\uda16\ude6a\000\udb10\udc87\ud8c0\udec7E\udbe2\udedf\udbf2\udc4b\ud850\udd48\ud831\udee3\ud844\udca1", "\000", "\ud80c\udd74\ud99a\udc6e\udaca\udf03\uda24\udfab\u30e3\ud8d0\udfa5\u30d1\udbfc\udfc7",
        51, 88792, -1104396387, 3780881726673232327L, -100000L, false, true, (char) 15962, (char) 23442,
        Double.longBitsToDouble(0x3fe6b9c6b71dad17L), Double.longBitsToDouble(0x3feb6ae984ed9f0cL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.String:NF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 6, "\u9900\000\000\000\ud9e6\ude75\uda6a\udc81\ud90b\ude64\000\udb79\udf26\udb22\udf0d\u00f1\000\udb90\udd57\uda3e\ude1af\uda79\ude98\udb74\udd3f\udb42\ude07\udb87\ude2b\u0081\udbe2\udedf\udbf2\udc4b\ud850\udd48\ud9d5\udf95\ud8d4\ude5f", "\u90ca", "\ud80c\udd74\ud99a\udc6e\uda76\udc66\udba5\ude40\uda88\udcff\ud8c0\udece\u30d1\udbfc\udfc7",
        51, 31792, -1104396387, 3780881726680456391L, -100000L, false, true, (char) 15962, (char) 23442,
        Double.longBitsToDouble(0x3fea8316b71dad17L), Double.longBitsToDouble(0x3feb6ae984ed9f0cL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\ud951\udea2\udac1\udf20YV\ud9e6\ude97\uda90\udf48o\ud8d0\udde8\udb79\udf26\ud89a\udfe8\000\000\ud910\udc07\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\ud9a7\udf22\ud91b\udf62\u0081\udbe2\udedf\ud98a\udc97\ud8d9\udd54\uda52\uddf3\uda87\udfc3", "\u8baf\ua0b8\ua540", "\uda74\ude05\uda24\udfab",
        18, 44048, -441476514, -917058082902195270L, -83715L, false, true, (char) 4415, (char) 54746,
        Double.longBitsToDouble(0x3f3773d800000000L), Double.longBitsToDouble(0x3fc56a35f62d6350L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.String:FK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\ud951\udea2\udac1\udf20YV\ud9e6\ude97\uda90\udf48\udad6\udeee\udb2a\ude57\ud9bd\udc71\ud87b\udeae\000\000\ud910\udc07\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\uda1d\udf1d\udbc1\udd15q\udbe2\udedf\ud98a\udc97\ud8c1\udc06\udbdd\udf79\ud844\udca1", "\u8c0b\ua0b8\u3b41", "\ud901\udd6b",
        3, 61983, -2021469720, -1896127189795605368L, -69774L, true, true, (char) 8723, (char) 4415,
        Double.longBitsToDouble(0x3fea6d9468005dcfL), Double.longBitsToDouble(0x3fe8000004ab51afL)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.String:PF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\uda2e\udcd0\ud9e3\udd0bbV\ud9e6\ude97\uda90\udf48\ud90b\ude64\u63d7\udb79\udf26\ud89a\udfe8\ud921\udc01\000\ud910\udc07\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u41d8\ud91b\udf39\u0081\udbe2\udedf\ud98a\udc97\ud8d9\udd54\udbdd\udf79\ud844\udca1", "\u53f0\ua0b8\ua540", "\uda74\ude05\uda24\udfab",
        18, 44280, -441476514, -917058082902195270L, -83715L, false, true, (char) 4415, (char) 54746,
        Double.longBitsToDouble(0x3f3773d800000000L), Double.longBitsToDouble(0x3fc56a35f62d6350L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.String:KR |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 15, "\udb45\ude4d\uda7d\udeadY\000\ud9e6\ude97\uda90\udf48\ud90b\ude64\ud903\uded3\uef27\ud9f0\udebc\ud862\udf89c\ud910\udc07\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\uda57\ude74r\udb70\udfc6\uda27\udfcb\ud8d9\udd54\udbdd\udf79\ud844\udca1", "\u8c0b\u25b8\ua540", "\udac8\udf74\uda24\udf8a",
        39, 44280, -441476514, -917058082902195270L, -56390L, false, true, (char) 4415, (char) 54746,
        Double.longBitsToDouble(0x3f3773d800000000L), Double.longBitsToDouble(0x3fc56a35f62d181cL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.String:N |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "n\uda6e\udd48\udb38\udedcA\udb39\udce0\ud8f5\ude99\ud82f\udc36", "\u22dd\u669e", "\udbb6\ude65\ud8f7\udfd7\udae3\ude88\ud821\udebb\ud8ac\udd86\ud9a8\ude35",
        49, 83728, -614102368, -358162544689774611L, -25081L, true, true, (char) 19654, (char) 61908,
        Double.longBitsToDouble(0x3fed2279c456e88bL), Double.longBitsToDouble(0x3fd761ca4da8d9beL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 6, "\uda1f\udda4j\000\000", "\u574a\u895e\u62bf\u7cef\u8074\u4af5\uba98\u9e78\u8d21\u7016\u1784\uab2f\u36c7\u3735\u60f9\u9472\u01b9\u1c98\u3f72\u71ce\u4dc4\u7d42\u8c4d\uadac\u0d05\ub59a\u4418\u0e83", "\udbf6\ude37\udb09\udd23",
        13, 88473, -1423485870, -1706914059282260917L, 44261L, true, true, (char) 1287, (char) 6154,
        Double.longBitsToDouble(0x3fe1ce571c0eec6dL), Double.longBitsToDouble(0x3fe51360326efe55L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.String:T |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 10, 3, "\uda1f\udda4\ud97e\udc76\uda71\udc58T\ud8bc\udfbc\uda97\udf23\ud8b3\uded9\u5d7d\ud821\udfe4\ud803\udf62", "\uba98\u9e78\u8d21\u7016\u1784\uab2f\u36c7\u3735\u60f9\u9472\u7b12\u1c98", "\ud95a\udf07\ud926\udcb5",
        21, 79093, -1427105322, 5439913083175793782L, -58506L, true, false, (char) 8676, (char) 47065,
        Double.longBitsToDouble(0x3fb4bcc1b5f62140L), Double.longBitsToDouble(0x3fb2b7a80abe2610L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.String:JS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 6, "\uda1f\udda4j\ud875\udc3as\ud8bc\udfbc\uda97\udf23\ud8b3\uded9\u5d7d\udb79\udf10\ud893\udc31", "\uba98\u9e78\u8d21\u4c53\u1784\uab2f\u36c7\u3735\u60f9\u9472\u01b9\u4a4c", "\ud95a\udf07",
        41, 50796, -1865995907, -6129370684670970847L, 33503L, true, true, (char) 5173, (char) 23822,
        Double.longBitsToDouble(0x3fe3c8a66452f306L), Double.longBitsToDouble(0x3fe5ad593c4be84fL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\u00df", "", "\uda90\udf48",
        9, 84147, 1476682231, -9096117120607524531L, 58329L, true, false, (char) 12054, (char) 11147,
        Double.longBitsToDouble(0x3fe2994e2b099ba1L), Double.longBitsToDouble(0x3fdd006087034f90L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "z\u00ab\000\000\ud9e6\ude97\uda7b\udd4c\ud90b\ude64\ud903\uded3\udb79\udf26\uda24\ude3b\udb7a\ude2c\ud87e\udcac\ud810\udc72\ud8e2\udd78\ud8e3\udca2\ud864\udd84\udb67\udcf9\u2c30\ud849\udd71\uda63\udf13", "\u72a5", "\ud85b\udc5a\u2779\udbc4\udfca\ud895\udc4b\udb0b\udfe3\udbf6\udfd2",
        49, 73355, 1545440557, -2552949437325185424L, 72348L, false, true, (char) 28244, (char) 13066,
        Double.longBitsToDouble(0x3fe521a793ca79a7L), Double.longBitsToDouble(0x3fc4f695f07270b4L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 8, 7, "u\000\000\000\ud9e6\ude97\uda90\udf48\ud90b\ude64", "\ud40e\ub6e2", "\ud8e2\udd78\ud8e3\udca2",
        -1, 75355, 155699977, -6356625659792852095L, 44373L, true, true, (char) 60480, (char) 23472,
        Double.longBitsToDouble(0x3fd2eeaa12d1c9b4L), Double.longBitsToDouble(0x3fd4db4a1962f142L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.String:SFT |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 15, "\ud920\udc3d\udbde\udc04\ud9b6\ude0b\ud914\udce7\ud87d\udd7d\uda90\udf48\ud90b\ude64\000\udb79\udf26\ud89a\udfe8\u00e7\000\ud910\udc07\uda3e\udd1ff\uda81\udf3f\ud9a0\ude85\ud96a\udc94\ud849\udccdD\udb9e\udd7c\udbf2\udc4b\ud850\udd48\udbdd\udf79\ud844\udca1", "\000", "\ud9c3\udcb6\udaac\udf04\ud937\udc5e\uda24\udfab\uda72\udd75\ud8c0\udece\u30d1\udba2\uddd9",
        51, 88798, -1104396387, -614631509633162811L, -100000L, true, true, (char) 3613, (char) 23442,
        Double.longBitsToDouble(0x3fe0cb16b222ad17L), Double.longBitsToDouble(0x3feb6aeeebed9f0cL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.String:PSF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 15, "\ud92f\udca0\ud8b3\ude62\000\000\ud9e6\udeaa\uda90\udf48\ud889\ude24P\udb79\udf26\ud89a\udfe8\u00e7\000\ud910\udc07\uda3e\udd1ff\uda16\ude6a\000\udb10\udc87\ud849\udccd\u0081\udb9e\udd7c\udbf2\udc4b\ud850\udd48\udbdd\udf79\ud844\udca1", "\000", "\ud9c3\udcb6\udaac\udf04\ud937\udc5e\udb68\udc6b\u80ed\ud8c0\udece\u30d1\udba2\uddd9",
        51, 88798, -1104396387, 3780881726680456391L, 89912L, true, true, (char) 3613, (char) 23442,
        Double.longBitsToDouble(0x3fe0cb16b222ad17L), Double.longBitsToDouble(0x3feb6aeeeced9f0cL)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\u99ae\ud852\udc08w\000", "\u66ed\ua04b\u7248\u231d\u6273\u009b\u7c64\u9940\ub7a6\uc8ac\u8857\u8ef6\u2172\u0081\ub242\u6f2e\uc8e2\u5097\u2475\u9bad\000\u2b42\u836e\ua540\u17d6\u71a8\u065d\u9cbb", "\u30d1\udbfc\udfc7\u00ba",
        12, 37613, 880305126, 39930718983094272L, 36587L, false, false, (char) 15412, (char) 27805,
        Double.longBitsToDouble(0x3fc5d3e18cf1cdc0L), Double.longBitsToDouble(0x3fe024393954d1bcL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.String:KS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\u99ae\ud852\udc08w\000\ud9e6\ude75\uda90\udf48\ud90b\ude64\ud8e5\uded2\udb3c\udd67\ud8ad\udf64X\u4d1f\ud8c9\udf9a\udb47\udf17\ub7a6\udae4\ude39\ud847\ude7d\udb10\udc87\ud849\udccd\u0081\udbe2\udedf\ud967\udcd8\ud850\udd48\udbdd\udf79\ud844\udca1", "\uafab", "\ud80c\uddf4\uda2d\ude57\uda74\ude12\uda24\udfab\uda72\udd75\ud8c0\udece\u30d1\udbfc\udfc7",
        51, 88792, -1104396387, 3780881726680456391L, -100000L, false, true, (char) 15962, (char) 23442,
        Double.longBitsToDouble(0x3fe28316b71dad17L), Double.longBitsToDouble(0x3feb6ae984ae9f0cL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.String:FF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\ud8b8\udd58\ud940\ude3ef\000\ud9e6\ude9c\uda90\udf48\ud90b\ude64\000\udb79\udf26\ud89a\udfe8\000\000\ud910\udc07\uda3e\udd1ff\uda16\ude6a\ud909\udf03\ud81a\udd90\udae4\udf3f\ud92f\udf22\udb9d\udc35\udbf2\udc4b\ud850\udd48\ud852\udde3\ud844\udca1", "\000", "\ud80c\udd74\ud99a\udc6e\udaca\udf03\uda24\udfab\u30e3\ud8d0\udfa5\u30d1\udbfc\udfc7",
        51, 88792, -1104396387, 7239646240493773294L, -100000L, false, true, (char) 15962, (char) 23442,
        Double.longBitsToDouble(0x3fe6b9c6b71dad17L), Double.longBitsToDouble(0x3feb6ae984ed9f0cL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 0, "\ud951\udea2\udac1\udf20Y\000\ud9e6\ude75\uda74\udf48\udad6\udeee\udb2a\ude57\uda28\udd46\udb13\udea8\000\000\ud910\udc07\uda3e\udd1f\udab7\udc81\ud874\udd0b\udbb8\udfd1\uda1d\udf1d\ub96c\000\000\ud998\udc4b\ud86c\udffc\udbdd\udf79\ud844\udca1", "\u8c0b\ua0b8\ub3dc", "\ud901\udd6b",
        3, 55752, -2021523456, 403726925824L, -69774L, true, false, (char) 230, (char) 0,
        Double.longBitsToDouble(0x3d8773c000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.String:R |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 3, "\udb45\ude4d\uda7d\udeadY\000\ud9e6\ude97\uda90\udf48\ud818\udccb\udb17\udd48\udbd4\ude1a\ud838\udfdf\ufad6\ud889\udcd8\ud928\udcf0\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\uda57\ude74r", "\ua67e\u5097\u2475\u4586\u33a7\u628d\u25b0\ua540\u1756\u72c6\u5029\u9c5f\u9f28\u131a\ub32d\u88aa", "\udba7\ude78\uda49\ude6a\u89dd\udab5\udffd\000\ud947\udd8f\ud9fe\udccb\u36f3",
        44, 43347, -137976935, -6228882885245474726L, 27067L, true, true, (char) 62585, (char) 26887,
        Double.longBitsToDouble(0x3fe9f93ff9a8ec89L), Double.longBitsToDouble(0x3fca918c73a5bcc8L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 0, "\000j\000\000", "o\u890f\u62bf\u7cef\u8074\u2ba7\uba98\u9e78\u8d21\u7016\u1a54\uab2f\u36c7\u3735\u60f9\u9472\u01b9\u1c98\u3f72\u71ce\u4dc4\u7d42\u8c4d\uadac\u0d05\ub59a\u4418\u0e83", "\udbf6\ude37\udb09\udd23",
        13, 88473, -1423485870, -1706914059282260917L, 96608L, false, true, (char) 24405, (char) 34627,
        Double.longBitsToDouble(0x3fe2d2f56c3b33cfL), Double.longBitsToDouble(0x3fe1ce571c0eec6dL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.String:ST |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 10, 3, "S\000\uda71\udc58T\ud8bc\udfbc\uda97\udf23\ud8b3\uded9\u5d7d\ud821\udfe4\ud803\udf62", "\uba98\u9e78\u8d21\u7016\u1784\uab2f\u36c7\u3735\u60f9\u9472\u7b12\u1c98", "\ud95a\udf07\ud926\udcb5",
        21, 79093, -1427105322, 5439913083175793782L, -58506L, true, false, (char) 8676, (char) 47065,
        Double.longBitsToDouble(0x3fb4bcc180000000L), Double.longBitsToDouble(0x3e257c4c20000000L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.String:JS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 15, 7, "\u0ab6j\ud875\udc3as", "\u69e9\u225f\u7232\ua45b\u8014", "\ud99e\udd96\udadf\udfa9",
        44, 75355, 155699248, -2871378923610950927L, -15151L, true, false, (char) 44386, (char) 54859,
        Double.longBitsToDouble(0x3fcd258394ec5404L), Double.longBitsToDouble(0x3fe12ec0749ce7a1L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.String:JJ |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 6, "\uda1f\udda4j\udb00\udfffJ\ud88e\udfa5\udaee\udd18\ud8b3\uded9", "\ua45b\u8014\u4b59\uba98\u9e78\u8d21\u4c53", "\ud9b2\udf53\ud9bf\ude33\udaf7\udeda\udb34\udd43\ud923\udd0d",
        34, 71702, 352424147, -2878295618720034267L, -45085L, false, true, (char) 7954, (char) 49140,
        Double.longBitsToDouble(0x3fec79a58a0334e4L), Double.longBitsToDouble(0x3fa8454c1e014e50L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.String:SS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 6, "\udaa6\udda8S\ud875\udc3as\ud8bc\udfbc\uda97\udf23\ud8b3\uded9\u5d7d\ud809\udf18\udbb6\uddac", "\uba98\u9e78\u8d21\u4c53\u1784\uab2f\u90e3\u3735\u60f9\u9472\u01b9\u4a4c", "\udaaa\udf0f",
        59, 50796, -1865995907, -6129370684670970847L, 33503L, true, true, (char) 5173, (char) 23822,
        Double.longBitsToDouble(0x3fe3c8a66476f306L), Double.longBitsToDouble(0x3fe5ad593c4be84fL)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 7, "u\000\000\uda7b\udd68\ud9e6\ude97\uda90\udf48\ud90b\ude64", "\u0ad5\u92be", "\ud8e2\udd78\ud8e3\udca2\ud874\udd0b\udbb8\udfd1\u2b95\udab7\uddd8\uda30\uddf3\ud9d0\uddbf\ud875\uddcc",
        46, 44476, -358512654, -1956104653456799631L, 60945L, false, false, (char) 60605, (char) 29400,
        Double.longBitsToDouble(0x3fde18baa65043e8L), Double.longBitsToDouble(0x3fe6408f54b26cc6L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 8, 7, "i\000\000\udafc\udf3d\ud9dc\ude92\uda90\udf48\ud90b\ude64", "\ud40e\u352c\uc72d", "\ud8e3\udca2\ud874\udd0b\udbb8\udfd1\ud9ca\udf94",
        56, 37129, -1998950302, -7636473246974720595L, 61796L, false, true, (char) 9795, (char) 45550,
        Double.longBitsToDouble(0x3fc62f143174c0ecL), Double.longBitsToDouble(0x3fcbc7ba514971d4L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.String:KSFT |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 15, "\uda8e\uddd4\udbde\udc04\ud9b6\ude0b\ud914\udce7\ud87d\udd7d\uda90\udf48\ud8fb\udee3G\udb79\udf26\ud89a\udfe8\u00e7\000\ud910\udc07\uda3e\udd1ff\uda81\udf3f\ud9a0\ude85\ud96a\udc94\ud849\udccdD\udb9e\udd7c\udbf2\udc4b\ud9e0\udc5c\udbdd\udf8a\ud844\udca1", "\000", "\ud9c3\udcb6\udaac\udf04\ud937\udc5e\uda24\udfab\uda72\udd75\ud8c0\udece\u30d1\udba2\uddd9",
        51, 88798, -1104396387, -2632244141063173467L, -100000L, true, true, (char) 3613, (char) 23442,
        Double.longBitsToDouble(0x3fe0cb16b222ad17L), Double.longBitsToDouble(0x3feb6aeeebed9f0cL)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.String:KS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 8, "\u99ae\ud852\udc08w\000\ud9e6\ude75\uda90\udf48\ud90b\ude64\ud99e\udd78\udb3c\udd67\ud8ad\udf64X", "\u0ada", "\ud847\ude7d",
        4, 35592, 129, -2598421952269250744L, -41102L, true, false, (char) 38904, (char) 0,
        Double.longBitsToDouble(0x3eccf50f85640000L), Double.longBitsToDouble(0x3fce8ac6830dbe80L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 0, "\000jo\000\ud8bc\udff3\udb33\udd31o", "\u7cef\u8a52\u19f1\uba98\u9e78\u8d21\u7016\u1e14\ud1f4\u378d\u3735\u60f9\ub4bd\u01b9\u1c98\u3f72\u71ce\u4dc4\u7d42\u8c4d\uadac\u0d05\ub59a\u4418\u0e83\u6b5a\ub5da\u265e\ubbbc\u3e79\u0eae\u6fc2\u22a1\u52a5\u4d90\u1f5e\u3647\u9691\u0d7b\u23c2\uad48\u4706\u9250", "\udb26\udcd2\ud851\udca1\uda61\udd05\ud98b\udc9c\ud82b\ude1c",
        40, 71150, -1771683804, 6666071918526905397L, -50590L, false, false, (char) 28936, (char) 13742,
        Double.longBitsToDouble(0x3fed78515ddc63f2L), Double.longBitsToDouble(0x3fdd508bd92dd0acL)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 12, 11, "\ud9a9\udfa0\ud8d5\udfc5\000\000", "\u7670\u7283\u2974\uc9fa\u7fde\u2ba7\uba98\u9378\ucdda\u2903\u65d1\u7119\u36c7\uba74\u4e71\u8704\u01b9\u1c98\u3f72\ub594\u137f\u7d42\uc1b2\u3c7e", "\ud98a\udd40\udac3\udea8\ud978\udf86\ud9de\ude8d",
        12, 47579, 1628089754, 5063568223524836434L, 81314L, false, false, (char) 47847, (char) 34627,
        Double.longBitsToDouble(0x3fc44575ab16c120L), Double.longBitsToDouble(0x3fe1ce571c0eec6dL)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.String:JS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:JS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 7, "\u0ab6j\ud875\udc3as", "\u3235\u340a\u7232\u4249\u69db\u1b24", "\udadf\udf4d",
        44, 14171, 155699248, -2871378923610950927L, -15151L, true, false, (char) 44449, (char) 48939,
        Double.longBitsToDouble(0x3fb4c7bb9a4a1e60L), Double.longBitsToDouble(0x3fe12c6aab8be7a1L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 13, "i\000\000\udafc\udf3d\ud9dc\ude92\uda90\udf48\ud90b\ude64", "\ud40e\u352c\uc72d", "\ud8e3\udca2\ud874\udd0b\udbb8\udfd1\ud9ca\udf94",
        56, 37129, -1998950302, -7636473246974720595L, 61796L, false, true, (char) 9795, (char) 45550,
        Double.longBitsToDouble(0x3fe34b350c5d303bL), Double.longBitsToDouble(0x3fcbc7ba514971d4L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.String:KKT |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 15, "\uda8e\uddd4\udbde\udc04\ud9b6\ude0b\uda85\udce1\u50ff\ud8a5\udd88\ud8fb\udeedG\udb79\udf26\ud89a\udfe8\ud9e9\udc7b\uda60\udd16\ud910\udc07\ud8fb\udc5cC\uda81\udf3f\ud9a0\ude85\ud96a\udc94\ud849\udccdD\udb9e\udd7c\udbf2\udc4b\ud9e0\udc5c\udbdd\udf8a\uda31\udc57", "\000", "\ud9c3\udcb6\udaac\udf04\ud937\udc5e\uda24\udfab\uda72\udd75\ud8c0\udece\u30d1\udba2\uddd9",
        12, 88798, -1104396387, 9185201281157008001L, 82711L, true, true, (char) 3613, (char) 23442,
        Double.longBitsToDouble(0x3fe0cb16b222ad17L), Double.longBitsToDouble(0x3feb6aeeebed9f0cL)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 0, 0, "\000\000w\000\uda54\udc69\udb6a\ude75o\000\000\uf8ad\000", "", "\udab2\udf39\ud847\ude7d",
        -5, 88976, 129, -2598421952269250744L, -41102L, true, false, (char) 38904, (char) 0,
        Double.longBitsToDouble(0x3ecce10f85640000L), Double.longBitsToDouble(0x3e186df400000000L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.String:JS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:JS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 7, "\u0ab6j\ud875\udc3as\ud851\udc71\uda3b\ude04\udb29\udc33\u6f45\udb79\udf10\ud9e2\udddf", "\uc36f\u4d16\u8ced\u4c53\u0083\uab2f\u68da\ud788\u4ca7\u94de\u8289\u4a4c\u40cc\u18ae\u4362\u7d42\u6340\u3473\u35f4\u9d77\ub892\u0922\uced0\u8413\ub883\ub9b5\u86dc\uaf3e\u2e03\u39f2\u4929", "\uda15\udf27",
        42, 60340, 1701923070, -648386620109260948L, 79870L, false, true, (char) 22672, (char) 51694,
        Double.longBitsToDouble(0x3fdf302005313fbcL), Double.longBitsToDouble(0x3fef2ea5eeca0916L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 14, 6, "\ud951\udea2\udac1\udf20\ud88d\ude2e\uda7c\udd5b\udb10\ude89", "\u60b7", "\udb7f\udf5d\ud87e\udcac\ua11f\ud9ae\udc80\ud87c\udcc5\ud874\udd0b\udbb8\udfd1\u2b95\uda15\udd57\ud948\udd25\udbdc\uded4\ud98a\udc97\ud8d9\udd54\udbc9\udeee\uda92\udf89\udbe9\udd25\udbdd\ude54\udae4\udf26",
        9, 93587, 757522297, 3111018117775131664L, 67660L, true, true, (char) 11475, (char) 15880,
        Double.longBitsToDouble(0x3fbe992528e22500L), Double.longBitsToDouble(0x3fe0af9f14a9ff48L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 6, 6, 8, "\uda8a\udeb8\ud83d\udcf5\udbea\udd42\uda34\udd9e\ud983\udd12\udbe9\udcb4\u5f99\udb7f\udcf1\ud830\udd56\udb94\ude77\udb7f\udf5d", "\u59b9\u9381\ucd37\ub774", "\ud9cf\ude1c\udb31\ude69\udb15\udf26\u9404\udaad\udf30\udaa0\udd90\udbcf\ude61\ud993\uded8\ud9e5\udeaf",
        -3, 74390, 27655804, 5280642678048407264L, -4519L, false, false, (char) 11920, (char) 52137,
        Double.longBitsToDouble(0x3fe498f2ea8b487dL), Double.longBitsToDouble(0x3fec288ac4dd80f6L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "c", "", "\ud8d3\udf70",
        9, 84147, 1812226551, 3081616272559528062L, 43495L, true, true, (char) 11958, (char) 54411,
        Double.longBitsToDouble(0x3fe2994e2b0965b6L), Double.longBitsToDouble(0x3fe52777e381a7c8L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 2, 6, "A\000\udb38\udedcA\ud9e6\ude97\udb22\udf50\udbf0\udc65", "\uc245\u60cc\u94f6\uba98\u9e78", "\udbb8\udfd1\u2b95\ud8eb\udfc1\ud819\uddeb\udac3\udea4\udb12\udc77\ud97d\udd8c",
        11, 59689, 390473966, -3277820241263106208L, 59718L, true, true, (char) 4328, (char) 34429,
        Double.longBitsToDouble(0x3fec163f9f0a72feL), Double.longBitsToDouble(0x3fd5674c48ac8f28L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\u99ae\ud852\udc08w\uda04\udca2\udabe\uddac\uda90\udf48\ud8d9\ude6b\udb35\udf14\udb79\udeb9\ud89a\udfe8\uda53\udf88z\uda84\udc90\u0a0b\ub7a6\uda16\ude6a\000\udb10\udc87\ud849\udccd\u55ec\ud87f\udd47\ud967\udcd8\ud850\udd48\udbdd\udf86\ud984\udca1", "\u684c\u4cb0\u8431\u17d6\u71a8", "\uda72\udd75\ud8c0\udece\u30d1\udb48\udd4c",
        51, 88792, -1104396387, 3780881726680456391L, -100000L, false, true, (char) 15962, (char) 23442,
        Double.longBitsToDouble(0x3fe28316b71dad17L), Double.longBitsToDouble(0x3feb6ae984ae9f0cL)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.String:FL |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 14, 6, "\u99ae\ud844\udf42\ufb04\000\ud9e6\ude75\uda90\udf48\ud90b\ude64\udbea\udfdf\ud982\uddb4\ud8a4\udeb7\000\000\uda84\udc90\u0a0b\ub79f\udb49\udc6f\000\udb10\udc87\ud849\udccd\u0081\udb9e\udd5d\ud8aa\ude36\ud850\ude00\udbdd\udf79\ud844\udca1", "\u2b42", "\ud80c\uddf4\ud99a\udc6e\uda74\ude05\uda62\udf79\ud872\udf3a",
        42, 92962, -1892902803, 800716750848L, -34464L, false, false, (char) 15104, (char) 21082,
        Double.longBitsToDouble(0x3fd8b46d26a0c5acL), Double.longBitsToDouble(0x3fd795b51cf35f0eL)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 6, "\uda2d\udef3\u009e\000\udaf4\udcaa\ud9e6\ude9c\uda90\udf48\ud90b\ude64\000\udb79\udf26\ud89a\udfe8\000\000\ud910\udc07\uda3e\udd1ff\uda16\ude6a\000\udb10\udc87\ud8cc\uddc7E\udbe2\udedf\udbf2\udc4b\ud850\udd48\ud831\udee3\uda20\udd70", "\000", "\ud80c\udd74\ud99a\udc6e\udaca\udf03\uda24\udfab\u30e3\ud8d0\udfa5\u30d1\udbfc\udfc7",
        54, 23126, 1939250077, 3780881726673232327L, -100000L, false, true, (char) 27482, (char) 36772,
        Double.longBitsToDouble(0x3fe73ad2ef1dad17L), Double.longBitsToDouble(0x3fe36ae984c5ae49L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.String:RR |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 6, 15, "\udb45\ude4d\uda7d\udeadY\000\ud9e6\ude97\uda90\udf48\ud90b\ude64\ud903\uded3\uef27\ud9f0\udebc\udb7d\udf6cR\ud910\udc07\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\uda57\ude74r\udb70\udfc6", "\u5097\u2475\u4586\u33a7\u8c0b\u25b8\ua540\u1756\u72c6\ucad3\u9c9a\u9f28\u131a\ud32d\u7572\u63af\u498e\u9455\u2216\uc8fc\uc27b\000\u1bd0\u3fab\u7b23\ua5d9\u4ff1\u4d9b\u6e8d\uc871\ubf45", "\ud81e\udc01\uda79\udeb1\ud8cd\udd40\ud817\udeab\udaee\udc79\udb15\udefa\ud958\ude9f\udb78\uded7\uda07\udd83\udacd\ude5e\udb35\udcb5\udb59\udcea\udbfc\uddff\ud87c\udfd3",
        49, 31058, -2096284014, -7626221863575624891L, -27376L, false, true, (char) 39195, (char) 8099,
        Double.longBitsToDouble(0x3fea065da5fd3d09L), Double.longBitsToDouble(0x3fecf715b07165e8L)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.lang.String:N |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:N |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 2, "\ud9a7\udefc\u00d1\udb98\udd4b\000\ud9e6\ude97\uda90\udf48\ud90b\ude64", "\ud40e\ub6e2", "\udbcd\ude6a\ud8e3\udca2",
        -1, 75355, 155699977, -6356625659792852095L, 44373L, true, true, (char) 60480, (char) 23472,
        Double.longBitsToDouble(0x3fd2eeaa12d1c9b4L), Double.longBitsToDouble(0x3fd4db4a1962f142L)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.String:PP |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 15, "\ud92f\udca0\ud8b3\ude62\000\000\ud9e6\udeaa\uda90\udf48\ud889\ude24P\udb79\udf26\ud89a\udfe8\udbd7\ude07\udadd\udd3c\ud9ad\udea8\uda6d\udf1fp\uda16\ude6a\000\udb10\udc87\ud849\udccd\ud8a2\udfb8\udb9e\udda3\udbf2\udc4b\ud850\udd48\udbdd\udf79\ud844\udca1", "\000", "\ud9c3\udcb6\uda2e\udf05\ud937\udc5e\udb68\udc6b\u80ed\ud8c0\udece\u30d1\udba2\uddd9",
        51, 88798, -1104396387, 3780881726680456391L, 89912L, true, true, (char) 3613, (char) 23442,
        Double.longBitsToDouble(0x3fe0cb16b0d3831dL), Double.longBitsToDouble(0x3feb6aeeeced9f0fL)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 0, "Hj\000\000\ud8bc\udff3\udb33\udd31\ud56f", "\u7cef\u8074\uaea1\uba98\u9e78\u8d21\u7016\u1a1a\u5628\u5a40\u36de\u60f9\ucaf6\u3e10\uaad4\u8098\u5071\u4dc4\u7d42\u8c4d\uadac\u0d05\u549a\u4418\u0e83\u6b5a\ub5da\u265e\u9f97\u3e79\u5977\u6fc2\u96a1\u52a5\ub7d5\u1f5e\u1f7b\u062e\u0d7b\u23c2\uad48\u4706\u3b1e", "\udaa6\udee3",
        8, 94032, 476998805, 7759737969347968111L, -35195L, true, true, (char) 47299, (char) 27337,
        Double.longBitsToDouble(0x3fe3da27c913bc18L), Double.longBitsToDouble(0x3fe24b55e128b5b8L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 0, "\000j\udb48\udfe4\000", "o\u382c\u0a25\u7d27\u8074\ud6d2\u1e2f\u9e78\u8d21\u7016\u1a54\uab2f\u36c7\u3735\u60f9\uadde\u7bd9\u1c98\u9b31\ua03c\u9961\uafe7\u929b\uadac\u7590\u3c99\ub161\u4d87", "\ud9e0\ude4a\udb09\udd23\ud815\uddab\ud95e\uddf4\udbe0\udf27\uda6a\udd4f\uda0a\udf04",
        51, 59480, 735099666, 4146140171334667097L, 75413L, false, true, (char) 286, (char) 15132,
        Double.longBitsToDouble(0x3fc479c3f14842d4L), Double.longBitsToDouble(0x3fc362005410a8dcL)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=java.lang.String:SS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 0, 0, "Sj\ud875\udc3as", "\000\u21f3", "\uda99\ude8a",
        -4, 88313, -1917820845, -4758436124316586462L, -85712L, true, false, (char) 2840, (char) 56750,
        Double.longBitsToDouble(0x3fc1f8931b6dcc08L), Double.longBitsToDouble(0x3fd37b82b6861612L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=java.lang.String:AS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:AS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 6, "u\udbda\udf5d\u00df\uda7b\udd68\ud9e6\ude97\uda90\udf48\ud90b\ude64", "\u0ad5\u92be", "\ud8e2\udd78\ud8e3\udca2\ud874\udd0b\ud80b\udf5a\u2b95\udab7\uddd8\uda30\uddf3\uf614\ud875\uddf8",
        46, 44476, -358512654, -1956104653456799631L, 53777L, false, false, (char) 60605, (char) 43760,
        Double.longBitsToDouble(0x3fde18baa65043e8L), Double.longBitsToDouble(0x3fe6408f54b26cc6L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=java.lang.String:R |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 8, "\u99ae\ud852\udc08w\000\ud9e6\ude75\uda90\udf48\ud90b\ude64\ud99e\udd78\udb3c\udd67\ue4car", "\u0ada", "\u04d9",
        17, 35667, -99090303, 2882405502286443483L, -41102L, true, false, (char) 38904, (char) 0,
        Double.longBitsToDouble(0x3eccf50f85640000L), Double.longBitsToDouble(0x3fce8ac6830dbe80L)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 0, 0, "x\000w\000\uda54\udc69\udb6a\ude75o\000\000\uf8ad\000", "", "\udab2\udf39\ud847\ude7d",
        -5, 88976, 129, 8411154002907631432L, -41102L, true, false, (char) 38904, (char) 0,
        Double.longBitsToDouble(0x3ecce10f85640000L), Double.longBitsToDouble(0x3e186df400000000L)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 6, "u\udbda\udf5d\000\uda7b\udd68\ud9e6\ude97\uda90\udf48o", "", "\uda09\uddfc",
        44, 44723, 102, -855638016L, -32577L, false, true, (char) 12504, (char) 9804,
        Double.longBitsToDouble(0x3fd0000005e95298L), Double.longBitsToDouble(0x3fef928df52eeaa1L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\ud951\udea2\udac1\udf20Y\000\ud9e6\ude97\uda90\udf48\ud90b\ude64\ud903\uded3\udb79\udf26\ud89a\udfe8\uda90\udfe8Y\ud910\udc07\uda3e\udd1f\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\ud849\udccd\u0081\udbe2\udedf\ud98a\udc97\ud8d9\udd54\udbdd\udf79\ud844\udca1", "\u8c0b\u25b8\ua540", "\uda74\ude05\uda24\udfab",
        18, 44280, -441476514, -917058082902195270L, -83715L, false, true, (char) 4415, (char) 54746,
        Double.longBitsToDouble(0x3f3773d800000000L), Double.longBitsToDouble(0x3fc56a35f62d181cL)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 6, "\ud885\udf47\udac1\udf20YV\udaa0\udd79\uda90\udf48\ud90b\ude64\uda52\udff9\udb74\ude8b\ud89a\udfe8\uda54\udc69\uda3e\udc42\ud9cf\udddd\uda3e\udd1f\udadf\udf81\ud967\uddb8\udb1a\ude1f\ud9a7\udf74\ud91b\udf62\u0081\udb29\uddfd\ud924\udc93\ud8d9\udda1\ud8a0\udd54\ud844\udcb1", "\u8c0b\ua0b8\u474f", "\uda74\ude05",
        59, 83962, -2021469720, -1896127189795605368L, -69774L, true, true, (char) 8723, (char) 4415,
        Double.longBitsToDouble(0x3fea6d9468005dcfL), Double.longBitsToDouble(0x3fe8000004ab51afL)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=java.lang.String:R |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\u99ae\ud852\udc08wR\ud9e6\ude75\uda90\udf48\ud90b\ude64\ud8e5\uded2\udb79\udf26\ud89a\udfe8\000\000\udbcc\udc94\u0a0b\ub7a6\uda16\ude6a\000\udb10\udc87\ud849\udccd\u0081\udbe2\udedf\ud967\udcd8\ud850\udd48\udbdd\udf79\ud844\udca1", "\u2b42", "\ud80c\uddf4\ud99a\udc6e\uda74\ude05\uda24\udfab\uda72\udd75\ud8c0\udece\u30d1\udbfc\udfc7",
        51, 88792, -1104396387, 3780881726680456391L, -100000L, false, true, (char) 15962, (char) 23442,
        Double.longBitsToDouble(0x3fe28316b71dad17L), Double.longBitsToDouble(0x3feb6ae984ae9f0cL)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=java.lang.String:AJ |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 12, 0, "Yj\000\000\ud8bc\udff3\udb33\udd31o\uda0d\udd88\udb6c\udc50\udb7c\udf22\udb4c\udcb2\ud876\udcfa\ud810\udc72\ud8e2\udd78\udadf\udf81\ud874\udd0b\ufa53\udb04\udfbf\ud83d\udf14\uda81\udd34\ud8c3\ude80\ud83e\udeea\udb70\ude9e\ud96c\ude2e\ud9e7\uddc3\udb9e\ude25\ud871\udf6c\ud926\udd57\udb0a\udf00\ub2f1\udabf\udcd2\udbc4\udc93\u5def\udbf8\udc28\udb65\ude18\ud9de\ude8d\udbf6\ude37\udb09\udd23\ud816\udccd\ud998\ude99\udbd3\udf51\uda6a\udd4f\uda0a\udf04\udab1\udc8a\uda55\udd89\u65a7\udaaa\udcd2\ud936\uded9\uda86\udd67\udaf6\udd19\udac7\udd11\u5c93\uda5d\udcca\uda42\ude81\ud83e\udfa0\udb4d\udc8d\udb36\ude05\u3f39\ud8e0\udcf0\udba0\udca5\ud9a4\udc42\ud8f6\udd52\u5a81\ud955\udc96\udbd0\udcfa\ud886\udff6\ud88d\udf0b\uda94\ude23", "\u8f06\u1b4b\u8c2c", "\udbd5\udd92",
        33, 49724, 718899801, -8458172649273311410L, -57468L, true, true, (char) 38650, (char) 18498,
        Double.longBitsToDouble(0x3fb61571e041bc88L), Double.longBitsToDouble(0x3fe4d4f9bd3afd6aL)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 2, "\udab5\udf02\ud978\udcaag\udafc\udf3d\ud9dc\ude92\udb6c\udc98\ud926\udf1c", "\ud40e\u352c\u8c83", "\ud8e3\udca2\ud874\udd0b\udbb8\udfd1\ud9ca\udf94",
        56, 37129, -1998950302, -7636473246974720595L, 61796L, false, true, (char) 9795, (char) 45463,
        Double.longBitsToDouble(0x3fe34b350a5d303bL), Double.longBitsToDouble(0x3fdc9c2d48a4b8eaL)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 0, 0, "\000\000wE\uda54\udc69\udae5\udcf9\u00b2\udb79\udda4\000\uf8ad\000", "\u0ada", "\ud847\ude7d",
        -5, 88976, 129, -2598421952269250744L, -41102L, true, false, (char) 39161, (char) 124,
        Double.longBitsToDouble(0x3ecce6c495640000L), Double.longBitsToDouble(0x3fe449db1c33427fL)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 0, 0, "\ud954\ude23wwE\uda54\udc69\udae5\udcf9\u00b2\udb5f\udc91\u008c\uf8ad\000", "\u0ada", "\ud847\ude7d",
        36, 88976, 129, -2598421952269250744L, -93291L, false, false, (char) 7647, (char) 3850,
        Double.longBitsToDouble(0x3fe449db1c33427fL), Double.longBitsToDouble(0x3fedd4d80122d2ceL)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 12, 14, 6, "\ud96e\ude91\uda21\udc82\udb65\udcbb\ud845\udfb8\udb49\udfd5\udae3\udc15\u90cc\ua103\udb0b\udff2\ud893\udc31\udbda\udd4b\ud8d6\udcef\udb2e\udda1\uda48\udf0f\ud90e\udd15\ud93a\udf5c\uda19\udfc9\ud9c0\ude5c\ud99e\ude6c\udb1e\udd70\ud8fb\udc9e\ud8da\udc4d\ud89f\udf88\u4813\uda98\udf0b\udaac\udeff\ud999\udf28\ud906\udc41\udb5c\ude15\uda38\udf6c\u3d9c\uda44\ude95\ud1ed\udb5d\udf27\udb8c\udc32\ud954\udf57\ud964\ude44\udad5\udd1a\udaa4\ude1a\ud854\udfa3\udad0\udf8d\ud87d\ude4f\udbe4\udc61\udb20\udf97\ud939\udcad\udb0e\uded6\ud847\udffb\udb1c\uddbb\uda7b\udf86\u157b\udbef\udf94\ud8ab\udccb\u3263\uda6d\udf0a\ud81c\udc51\ud96a\udcda\ud913\udd0c\udb67\udcb4\uda19\udf62\ud94d\udf79\uda76\udd39\udaa6\udebe\udaf4\udd8b\ud9db\ude37\ud8a4\udc56\ud8f6\udea2\uda12\udd06\ud908\udc11\udb7b\uded4\uda2e\uded0\ud808\ude8d\u0a0b\udb0f\udda0\u090f\udacb\udd10\udba8\udc6e\uc018\ud89c\udd4d\ud89a\udf23\udb9f\udf4d\ud889\udf38", "\u9a70\u112d\u55d3\u02a1\ub36d\ud00c\uc0db\u2a04\ud196\u3b12\u1dcd\u9bf9\u6736\u07ac", "\u62aa\ud84d\ude45\ud899\udd4c\ud97a\udf11\ud808\udebd\udac3\udd03\ud97a\udd4f\udbdb\udf4a\udbe3\ude84\uda06\udd6e\udb06\udfd9\uda62\udd83\ud8bd\udec2\udb6a\udec8\uda40\udd58\ud815\udf19\udbbd\udd1c\udbae\ude6f\ud8e4\udd9f\udb48\ude73\ud895\udd73\udbb0\udcd3\ud9f8\udc82\uda9e\udeb5\ud907\udca0\udb62\uddf3\ud899\udd22\uda98\udff4\udabc\udf8c\ud9a1\udf4a\u1f05\udbd4\udf1f\ud909\udcd1\udb96\udcbf\udaf8\udfa4\udbcf\udcd9\ud853\ude06",
        48, 90059, 873693924, -1757283085652059286L, -62399L, true, false, (char) 1869, (char) 63325,
        Double.longBitsToDouble(0x3fe561b3accbdb1fL), Double.longBitsToDouble(0x3fdbd94c6ad9b152L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 5, 5, 7, "\ube00\000\ud950\ude2e\udad5\udcbe\ud9ba\udcd1\ud8f8\udd2f", "\u72d1\u2eb1\u8014\u4b59\u5a75\u97a3\u8d21\u7016", "\ud9c8\udc2f\uda5a\ude74\uda01\udd82\ud8d1\ude6c\ud90f\ude53",
        0, 10176, 165960531, -854077857467852504L, -83835L, false, false, (char) 31879, (char) 22844,
        Double.longBitsToDouble(0x3fe3af1a66fa72deL), Double.longBitsToDouble(0x3fead66b912eb6b2L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 13, 6, "\u9900\000\000\000\ud9e6\ude75\uda90\udf48\ud90b\ude64\000\udb79\udf26\ud8e6\udeeeh\000\ud910\udc07\ud87c\ude95h\uda16\ude6a\udad6\udcef\udb10\udc87\ud849\udccd\u0081\udbe2\udedf\udbf2\udc4b\ud850\udd48\udbdd\udf79\ud844\udca1", "\000", "\ud95a\udd70\u7cdf\uda74\ude05\ud9a8\udcad\uda84\udc75",
        50, 94486, -1672350584, 8310105272512513738L, -100000L, false, false, (char) 15104, (char) 15962,
        Double.longBitsToDouble(0x3fee71c838f0fdf0L), Double.longBitsToDouble(0x3fe8ed6ef76d5d30L)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=java.lang.String:TST |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 15, "\uda8e\uddd4\uda6c\udc4c\ud9fd\udfc5\uda95\ude7d\ud870\udd86\uda90\udf25\ud8fb\udee3D\udb79\udf26\ud916\udfe6\u00e7\000\ud910\udc07\uda3e\udd1f\u00c5\uda81\udf3f\ud9a0\ude85\ud96a\udc94\ud849\udccdD\udb9e\udd7c\udbf2\udc4b\udb5a\udc3f\ud9ae\udff3\ud844\udca1", "\000", "\ud9c3\udcb6\uda75\udd89\ud91b\udf57\ud95f\udf6a\uda72\udd75\ud8c0\udece\u30d1\udba2\uddd9",
        51, 88798, -1104396387, -2632244141113505115L, 86787L, false, false, (char) 33598, (char) 23442,
        Double.longBitsToDouble(0x3fe0cb16b222ad17L), Double.longBitsToDouble(0x3feb6aeee802730cL)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=java.lang.String:FLF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 14, 6, "\u99ae\ud844\udf42\ufb04\000\ud9e6\ude75\uda90\udf48\ud90b\ude64\udbea\udfdf\ud982\uddb4\ud8a4\udf71\000\ufb00\uda84\udc90\u0a0b\ub79f\udb49\udc6f\000\udb10\udc87\ud849\udccd\u0081\udb9e\udd5d\ud999\udd30\ud850\udf9e\udbdd\udf79\ud844\udca1", "\u0543", "\ud80c\uddf4\ud99a\udc6e\uda74\ude05\uda62\udf79\ud856\udc03",
        42, 77306, -1985342809, 6732345909444608L, -34464L, false, true, (char) 22759, (char) 46353,
        Double.longBitsToDouble(0x3fd8b20d26a0c5acL), Double.longBitsToDouble(0x3fdc0e351cf35eeaL)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 6, "\uda2d\udef3\u009e\000\udaf4\udcaa\ud9e6\ude9c\uda90\udf48\ud90b\ude64i\udb79\udf26\ud89a\udfe8\000\000\ud910\udc07\uda3e\udd1ff\uda16\ude6a\000\udb10\udc87\ud8cc\uddc7E\udbe2\udedf\udbf2\udc4b\ud850\udd48\ud831\udee3\uda20\udd70", "\000", "\ud80c\udd74\ud99a\udc6e\udaca\udf03\ud882\udc0c\u3083\ud8d0\udfa5\u30d1\udbfc\udfc7",
        9, 78138, -86136968, 3780881726673232327L, -100000L, false, true, (char) 27482, (char) 36772,
        Double.longBitsToDouble(0x3fe73ad2ef1dad17L), Double.longBitsToDouble(0x3fbcda8c262d7488L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=java.lang.String:SS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:SS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 0, "Sj\ud875\udc3as", "\000\u21f3", "\uda00\ude02\ud87e\udc45\ud810\udc72\ud99e\udd96\ud861\udce9\ud9cf\udc02\udbb8\udfd1\u28bc\ud960\udc0a\udbb7\udfc3\udb33\udf8e\ud83e\udf56\udaa3\udc05\udae2\ude4f\ud9e9\ude4a\ud801\udc63\ud9a3\udc52\udb96\udf69\udb69\udd15\ud9be\ude17",
        26, 16166, 1661122089, 2912113113274874171L, 87980L, false, true, (char) 64076, (char) 15941,
        Double.longBitsToDouble(0x3fd519d478938988L), Double.longBitsToDouble(0x3fe3c55ea4a19da8L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 6, "\ud951\udea2\udac1\udf20Yh\ud9e6\ude97\uda90\udf48\ud90b\ude64\ud903\uded3\udb79\udf26\ud89a\udfe8\uda90\udfe8Y\ud910\udc07\ud87a\udd1d\udadf\udf81\ud874\udd0b\udbb8\udfd1\u2b95\ud849\udccd\u0081\udbe2\udedf\ud98a\udc97\ud8d9\udd54\udbdd\udf79\ud844\udca1", "\u8c0b\u25b8\ua540", "\uda74\ude05\udb35\udd33",
        18, 44280, -441476514, -917058082902195270L, -83715L, false, true, (char) 19519, (char) 47500,
        Double.longBitsToDouble(0x3f3773d800000000L), Double.longBitsToDouble(0x3fc56a35f62d181cL)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 3, "\000\000wE\uda54\udc69\udae5\udcf9\u00b2\udb79\udda4\000\uf8ad\000", "\u0ada", "\ud847\ude7d",
        -5, 88976, 129, 5904374144206245745L, -41102L, true, false, (char) 39161, (char) 124,
        Double.longBitsToDouble(0x3ecce6c495640000L), Double.longBitsToDouble(0x3fec49db18338760L)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=java.lang.String:SS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:SS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 0, "Sj\ud875\udc3as\ud810\udd41\u2a1a\uda3d\udcfe\u21c5\udb72\uddf5\udbe3\udc20\uda00\ude02\ud80b\udecd\ud810\udce1\ud99e\udd96\ud861\udce9\ud9cf\udc02\udbb8\udfd1", "\u51c4\u4ca7\u94de\ud697", "\ud9e4\udc6c\ud85d\uded9\ud86a\udf6f\udb69\udd15\ud9be\ude17\ud8e5\udcc4\uda76\ude86\udada\udffe\udabe\uddd4\udafc\ude8a\udac3\udf84\udbf7\udd3b\ud824\udd30\uda9f\udea3\uda5c\udf29\uda20\udf42\ud861\udfa8\ud941\udcac\udb4c\udd8d\uda60\udca9\udb2e\udfc6\ud983\udff1\udb48\udd90\ud9c6\ude40\ud9e4\udec6\ud8e5\udec9",
        6, 12833, -1086918169, -8450377769616567549L, -36248L, true, true, (char) 26307, (char) 47570,
        Double.longBitsToDouble(0x3fe90287636505e1L), Double.longBitsToDouble(0x3fe1895dace6c1c4L)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=java.lang.String:SJS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:SJS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 0, "\u00c7j\ud875\udc3as", "\000\u21f3\u9df9\u4702\u8c84\u4af2\uba98\u78d7\u86d3\u4c53\u1784\ub3a8\u3921", "\ud9cc\ude56\udaa2\udf91\udadd\udd4f\uda4c\udc0f\ud801\udc68\ud9a3\udc52\udb96\udf69\udb69\udd15\ud9be\ude17\ud8e5\udcc4\ud8b5\udfd8\ud8e2\udecb\udb99\udcb5\udafc\ude8a\udaa2\udeca\udab8\udd66\udbdc\udd65\udb59\ude51\ud8ff\ude9e\ud97a\udde0\ud8bd\udd26\ud941\udcac",
        11, 99926, -1898243241, 6122743746108307351L, 26801L, true, false, (char) 29140, (char) 41230,
        Double.longBitsToDouble(0x3fda10da1a91b538L), Double.longBitsToDouble(0x3fdabbe486ed0302L)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=java.lang.String:SJ |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:SJ |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 0, "Sj\000\000", "\000", "\udb43\ude8a\uda00\ude02\ud87e\udc45\ud810\udc72\ud99e\udd96\u7ce9\ud9cf\udc02",
        15, 57248, -11808747, 4030858520337896207L, -71048L, true, false, (char) 38481, (char) 42792,
        Double.longBitsToDouble(0x3ec2c57c12c80000L), Double.longBitsToDouble(0x3fed0861d336cf6eL)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=java.lang.String:F |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 7, 0, "\ud9d0\udcc1\ud9db\ude52vV\ud9e6\ude97\uda90\udf48\ud8f4\udc64\u63b6\udb79\udf26\ud89a\udfe8\ud921\udc01\000\ud835\udd39\uf56a\udaed\ude89\ud874\udd0b\udbb8\udfd1\u41d8\ud91b\udf39\u0081\ud949\udcb2\ud995\udce1\ud8d9\udd54\udb8b\ude90\ud844\udca1", "\u53f0\ua0b8\ua540\u6855", "\uda24\udfab\uda72\udd75\ud8c0\udece\u30d1",
        51, 75034, 1852864018, -4743346363105254426L, -43501L, false, false, (char) 63546, (char) 15962,
        Double.longBitsToDouble(0x3fd8b58d4c7ecf2eL), Double.longBitsToDouble(0x3fcab2325afbe248L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.language.DoubleMetaphone|handleG|java.lang.String,org.apache.commons.codec.language.DoubleMetaphone$DoubleMetaphoneResult,int,boolean|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|charAt|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|cleanInput|java.lang.String|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionC0|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionCH0|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionCH1|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionL0|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionM0|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,[Ljava.lang.String;|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|doubleMetaphone|java.lang.String|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|handleG|java.lang.String,org.apache.commons.codec.language.DoubleMetaphone$DoubleMetaphoneResult,int,boolean|new:org.apache.commons.codec.language.DoubleMetaphone:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
