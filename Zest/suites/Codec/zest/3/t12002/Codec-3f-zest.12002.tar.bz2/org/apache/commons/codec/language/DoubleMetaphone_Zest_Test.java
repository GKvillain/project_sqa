package org.apache.commons.codec.language;
import org.junit.Test;
import static org.junit.Assert.*;
public class DoubleMetaphone_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 9, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda45\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 9, 10, "\ud905\udf98\uda45\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\udb29\ude47\udb64\udc82\ud92b\uded5\ud813\udcec\udb89\udf06\ud843\ude67", "\u6fe4\u55ec", "\udb6e\udcda",
        26, 39814, 1390130434, -5283549551806568871L, -69994L, false, true, (char) 47079, (char) 43796,
        Double.longBitsToDouble(0x3fe7763fb797f797L), Double.longBitsToDouble(0x3fd59b8d6e5f2290L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\ude8d\ud8ef\udf56 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 9, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\ude8d\ud8ef\udf56", "\uc6e4\u536b\ud416\u210b\u10ea\u3085\u0775\u3736\u78c5\u9d55\u1d17\uc435\u97f8\u643e\u0a3d\ub7f6\uae3f\u538c\u3a46\ua7d6\uc801\u0b3d\ud706\u7888\ud1c0\ua431\ud651\u880e\u4cbc\u6298\u2c0e\u2570\u3d14", "\uda75\uddf9\udab2\udcfc\udb2c\udf07\ud9dc\udc0a\ud8e7\ude50\udbbe\udfad\ud949\udfa4\ud959\udc86\udbf9\udefa\ud94c\uddce\ud947\ude9b\udb6a\udf44\ud8a9\uddc1\ud8af\udc7f\udaba\ude89\ud9c6\udf93\udbfe\uddef\udb96\udc67\ud8b3\udea1\ud800\ude4e\uda92\uddd3\udb4c\udcc4",
        36, 5359, -339781536, -8874277678603824820L, 99276L, true, true, (char) 48381, (char) 20037,
        Double.longBitsToDouble(0x3fe457d5995507beL), Double.longBitsToDouble(0x3fe22f85f570ea51L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\ud897\uddba\uda2d\udca0\ud903\udf1b\ud8a0\udd81 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 9, 10, "\ud897\uddba\uda2d\udca0\ud903\udf1b\ud8a0\udd81", "\u74cf\u35b8\u94d2\u48f7\ucd67\ud425\u6fe4\u55ec\u4522\u210b\u10ea\u3085\u0775\u3736\u78c5\u9d55\u1d17\uc435\u97f8\u643e\u0a3d\ub7f6\u0340\u721f\u70b1\ubde4\u34a4\u0b3d\u4f07\u7888\ud1c0\u0edd\ua77d\u01c4\ucd9e\u58b5\u9719\u86ce\uc4f9\u1d2c\u49ce\u9f7c\ua6a9", "\udbf0\udff9\udb8b\ude15\ud9d9\udd15\udbdf\ude53\uda11\udd2e\ud87c\udf92",
        44, 18870, -1214085556, -2983019068927785948L, 11544L, false, true, (char) 31044, (char) 10965,
        Double.longBitsToDouble(0x3fec2dee5d3fc2ebL), Double.longBitsToDouble(0x3febb22cd5b12719L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 9, 10, "\uda16\ude6a\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda23\udefd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ud9a1\udf01", "\u992f", "\udb67\udc4c\udb6e\udcda\ud926\ude94\ud9cc\udf62\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8\ud85b\udc13",
        41, 30254, -1193873513, -7978120862206871761L, 80409L, true, false, (char) 48992, (char) 14040,
        Double.longBitsToDouble(0x3fd6b0b9334f7990L), Double.longBitsToDouble(0x3fefa40f2c0f8f67L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\ud961\udf3a\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 9, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\ud961\udf3a\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\000\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d",
        -3, 55754, -253212196, -3571980131856098137L, -30263L, false, false, (char) 46894, (char) 26118,
        Double.longBitsToDouble(0x3fc72c9f205f1a38L), Double.longBitsToDouble(0x3fbe45ba16800000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\udaa5\udd7b\udbba\udd3a\ud92b\uded5\ud813\udcec\udb89\udf06\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 9, 13, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\udaa5\udd7b\udbba\udd3a\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u34c8\u6749\uc3e4\uc703\u10ba", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 4, 12, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06", "\ud425\u6fe4\u55ec\u4522\u210b\u10ea\u3085\u0775\u3736\u78c5\u9d55\u1d17\u0c99\u97d5\u643e\u498d\u4ad6\uc2bb\u9381", "\ud96b\udd56\uda34\udd70\ud9be\udda3",
        28, 77171, -2115655257, 3270163034260840880L, -94579L, false, true, (char) 59544, (char) 7113,
        Double.longBitsToDouble(0x3fca93bfec62d874L), Double.longBitsToDouble(0x3fb9d5ec530d3878L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 12, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\udbb3\uddc1\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u0254", "\uc9e4\udb1e\udf5a\uda53\udf7d",
        -3, 55754, -253206422, -3571980131856098137L, -30263L, true, true, (char) 18551, (char) 59198,
        Double.longBitsToDouble(0x3fc72c9f321b8a38L), Double.longBitsToDouble(0x3fbe6dd4d6846040L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\udafe\udc8a\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 13, 10, "\ud905\udf98\udafe\udc8a\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55f7\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, -46381L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e8a482L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 9, 10, "\uda7e\udf34\uda2d\udca0\ud8c2\udefb\ud8a0\udd81\uda27\uddfd\udabd\udf89\udbce\udee5\ud86d\ude4d\udb89\udf06\udaa1\udc81\uda5b\udde6\ud978\uddac\ud92f\udfd2\uda92\udcdc\ud898\ude18\udb67\udc4c\udbbc\udea6\ud926\udeb2\ud9f6\udc23\uc9e4\udbc1\uddaa\uda7c\udf7d\uf1e4\udb0b\udc7e\ud932\ude10\ud98f\uddd3\udba7\udd73\ud9ff\ude73\udbe6\ude3c", "\u47b7\u34a4\u13a9\u4f07", "\uda0c\ude38\ud9c0\udcb5\ud851\ude94\udbd0\udc19\udb02\udd5e\udac0\udf32\udb7f\udffa\udba5\udda1\ud8fc\udf8b\udb91\udd89\udb26\udfb8\udb5e\udcb4\ud8c5\uded4\udb79\udf6c\uda54\udf2c\udba7\ude9e\uda29\udd4c\ud95d\udd88\ud944\ude8c\udb97\udc23\ud826\udf99\ud911\udd22",
        25, 4509, -2014798217, -9008412308603064924L, -63497L, true, true, (char) 53974, (char) 54995,
        Double.longBitsToDouble(0x3fc3ad23b9a247f4L), Double.longBitsToDouble(0x3fe70120f68dc4fcL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, -8296L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fe71be643f481e5L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 8, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\udac5\ude4a\u805d\uda52\ude0b\ud42d\udb89\udf06\ud85e\udf60", "\u66a8", "\udb67\udc4c\ud8f2\udfbb\udbdc\udf2e\uda2e\udcd6\uca84\udb55\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud973\udd2c\ud8a4\udfbf",
        -1, 30254, -1193873513, -7978120862206871761L, 38933L, true, false, (char) 48992, (char) 14198,
        Double.longBitsToDouble(0x3fd6b0b9334f7990L), Double.longBitsToDouble(0x3fefa40f2af220deL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 9, 8, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d\udbfa\udced\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 50853, (char) 48803,
        Double.longBitsToDouble(0x3fe6871f396b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 13, 10, "\ud905\udf98\uda7f\ude6a\ud87d\udf73\ud887\udfbe\uda27\uddfd\udbba\udd81", "\u94d2\u48f7", "\u0142\udb6b\udce5\ud898\ude18\udb67\udc4c\udb6e\udcda",
        34, 39814, 1390130434, -5283549551806568871L, 82375L, true, false, (char) 18916, (char) 59182,
        Double.longBitsToDouble(0x3fd59b8d6e5f2290L), Double.longBitsToDouble(0x3fe1c40830b964f9L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 9, 10, "\ud84d\udc7f\uda2d\udca0\ud903\udf1b\udbdf\udc75\ud825\udcf2\udbba\udd81\ud92b\uded5\ud813\udcec\udb93\udc6c\u8a08", "\u6fe4\u55ec\u4522\u93aa\u18c9", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 56741, (char) 48864,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud844\udcc6\ud849\udd97\udb1a\udf01\ud9ae\udc01 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 9, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud844\udcc6\ud849\udd97\udb1a\udf01\ud9ae\udc01", "\u6fe4\u55ec\u4522\u210b\u10ea\u3085\u0775\u4d6f", "\uf1e4\udb0b\udc7e\ud90c\udcf8\ud85b\udc13\uda5c\udd59\ud864\udd6f\ud998\udf65\uda73\uded2\ud955\udcb3\ud943\udc2b\ud96b\udd56\uda34\udd70\ud9be\udda3\uda88\udf7e\udbc9\udd74\uda0c\ude38\udba7\ude28\ud969\ude46\uda35\ude1a\udbd2\udd17\ud933\udce1\udb54\udd6b\udb93\uddd0\ud943\ude9a\uda06\udc69\udb27\udd10\udb75\udcd5\udbd8\udc47",
        49, -444, -1822050807, 550953240939772801L, -1761L, true, true, (char) 29563, (char) 11205,
        Double.longBitsToDouble(0x3fd9b22746a80d74L), Double.longBitsToDouble(0x3feae8999247bdd9L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\ud86d\udc0a\u1b6d |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 9, 6, "\ud86d\udc0a\u1b6d", "\u5229\u0818\u735a\u4112\uaf43\ub93b\ud3c5\uaf30\u9eed\ucd55\u4522\u210b\u94e9\u3085\u7c89\u7554\u78c5\u29c7\u25ec", "\ud85d\udd80\uda5c\udd65\ud864\udd6f\ud94a\udf7b",
        20, 19541, 1694046435, -4139159106321121261L, -78192L, true, false, (char) 29308, (char) 29948,
        Double.longBitsToDouble(0x3fd59febfdfdd588L), Double.longBitsToDouble(0x3fe9a5f7f0190ecaL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\ud845\udc9a\u61ce\uda49\ude07\ud92b\uddbe\ud802\udded", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uc9e4\ua69f\udbaf\udf8c\ud81f\udde7\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -1818811666, -2810221927698046492L, 70440L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\u90dd\ud87c\udd07", "\u25af\u9ef9\u60a8\u2d86\u8e23\ud4d0", "\udbd4\ude6a\uda0f\udf88\uda38\udf42\ud913\udccc\ud9f5\udfcb\ud965\udec6\ud80f\uddac\udb0b\udc7e\ud90c\udcf8\ud9a6\udd6f\udb65\udd3d\udbe4\udda2\ud92d\udd12\uda73\uded2\ud975\udfb3",
        22, 40767, 290324503, -2485604213748749750L, 53177L, false, true, (char) 44450, (char) 31562,
        Double.longBitsToDouble(0x3fe502817a7aaaafL), Double.longBitsToDouble(0x3fda281d5f1059e2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udfef\ud994\udc75\uda69\udf4e\ud8d5\uddeb\uda46\udca1\udbba\udd81\ud92b\ude8b\ud813\udcec\udb89\udf06\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 7, 10, "\ud905\udfef\ud994\udc75\uda69\udf4e\ud8d5\uddeb\uda46\udca1\udbba\udd81\ud92b\ude8b\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u5329\u48af\u0f60\u9b71", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 65695, -141065746, -5199705289790871719L, 70440L, true, true, (char) 9748, (char) 49757,
        Double.longBitsToDouble(0x3fe68554a16b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "", "\u2afa", "\udb8f\udfe7\ud92b\uded5\ud813\udcec\u00dd\u4308\ud8ac\ude99\ud978\uddac\u0142\udb6b\udce5\ud898\ude18\udb67\udc4c\u00e0\000\ud9cc\udf3c\uc9e4\udb1e\udf5a\uda4a\udd24\uf1e4\udb0b\udc7e\ud90c\udcf8\uc6ff\uda25\udcb2\ud864\udd6f\ud998\udf65\uda73\uded2\ud975\udfb3\000\000\000\000\udabc\uded8\udbc9\udd74\uda0c\ude38\ud9f5\udd50\uda98\udc2b\uda80\udd0b\udb95\udf31\udae6\udf71\udb1b\udffe\ud99f\udcd9\ud9bc\udfc6\uda5b\ude6e\uda30\udf38\ud86e\udf7c\uda38\ude98\uda84\udefe\ud95b\udce8\ud9de\ude51\uda56\udc1e\ud818\udf09\ud928\udc92\udb6b\udd1d",
        39, 51695, 1648196803, 729348120487325933L, 78545L, true, false, (char) 3918, (char) 2611,
        Double.longBitsToDouble(0x3fe683cbd2212cf3L), Double.longBitsToDouble(0x3fd52722279204aaL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\u83d3\u8b09\ud8ac\ude99\ud978\uddac\u0141 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 5, 7, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\u83d3\u8b09\ud8ac\ude99\ud978\uddac\u0142", "\u210b\u10ea\u3085\u0775\u3736\u78c5\u9d55\u1d17\uaf81\u81fd\u643e", "\ud998\udf65\uda73\uded2\ud975\udfb3\ud943\udc2b\ud96b\udd56\uda34\udd70\ud9be\udda3\uda88\udf7e\udb03\udeb1\udbad\ude2d\ud90e\udf3b\udab5\udc10\udb80\udffa\ud934\udc1b\ub754\ud811\udcfb\udbfa\udeab\ud8de\udff1\udb7b\ude7f\ud84e\udc00\udad0\udd1c\uca70\ud989\udff9\ud8bc\udd94\ud9c3\udeab\udbd4\udd82\ud9e5\udd86\ud8be\ude9f\ud836\udff8\ud9f4\ude3a\udb84\udc03\udb49\uddd9\ud872\uddc2\ud8d0\udfe2\udac7\udfd3\udbe1\udcc1\udb8a\udcfb\ud900\ude06\u7990\uda2f\udc04\uda5e\uddea\ud94d\ude91\ud9a9\udca2\ud81d\ude3f\udb8f\udd0c",
        -4, 17441, 3498338, 678030744698580937L, -11125L, false, true, (char) 22822, (char) 63320,
        Double.longBitsToDouble(0x3fe6b8e96f5aab9eL), Double.longBitsToDouble(0x3fdc4a4acce73c54L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\ud905\udf98\uda2d\udca0\ud903\udf1b\u9f26\ud887\udec3\udbba\udd81\ud92b\uded5\ud813\udcec\udb86\udce5\ud984\udf01", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d\uf1e4\u8aca\000",
        -5, -1000, 0, 0L, -8296L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 9, 10, "\ud905\udf98", "&\u0f00\u107a\000\u35a7\u94d2", "",
        31, -1000, 0, 1729382257219267383L, 96575L, false, false, (char) 3548, (char) 21384,
        Double.longBitsToDouble(0x3fe2cdb568000065L), Double.longBitsToDouble(0x3e1b800000000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 9, 10, "\000", "\u4689", "\000",
        -5, -1000, 863007744, 279569716472751L, 17226L, false, false, (char) 0, (char) 63561,
        Double.longBitsToDouble(0x3fa0d568626a1d50L), Double.longBitsToDouble(0x3fd0258daf5aa5b6L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\udb08\udde7\ud84e\udfa4\ud8f0\udc0b |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 5, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\udb08\udde7\ud84e\udfa4\ud8f0\udc0b", "\u6f7a\u55ec\u4522\u210b\u0db7", "\u17d1",
        7, 17529, -548187183, -7695654738311231012L, -25415L, false, true, (char) 59182, (char) 48687,
        Double.longBitsToDouble(0x3fe97c8a46388106L), Double.longBitsToDouble(0x3fdc864f98146418L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a3=[Ljava.lang.String;:[[\u893d\026\u8472\u16fd\u06d3]]\0121=java.lang.Boolean:false |a3=[Ljava.lang.String;:[[\u893d\026\u8472\u16fd\u06d3]]\012",
        Z.run(T, 2, 14, 14, 2, "\ud905\udf98\uda2d\udca0\ud903\udf1b\uda30\udc25\udb75\udd84\udab2\udc9c\uda25\udfae\uda12\udd2e\udb89\udf06\udac1\udf1e", "\u893d\026\u8472\u16fd\u06d3", "\uc9e4\ud9f9\udd50\ud83b\udc51\uf1e4\udb0b\udc7e\ud90c\udcf8",
        7, 85031, -141065746, -5127647850372004519L, 70440L, false, true, (char) 50946, (char) 48880,
        Double.longBitsToDouble(0x3fe6846041860b93L), Double.longBitsToDouble(0x3fe03096d3f44fd2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 9, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u10ea", "\ud96d\udd81\udb2a\udeb0\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\ud811\udc4a\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708\ud8ac\ude99\ud951\udfac\u041d\udb6b\udce5\ud898\ude18\udb67\udc4c\udb6e\udcda\udb2f\udef8\ud9cc\udf62\u943d |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 7, 11, "\ud811\udc4a\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708\ud8ac\ude99\ud951\udfac\u041d\udb6b\udce5\ud898\ude18\udb67\udc4c\udb6e\udcda\udb2f\udef8\ud9cc\udf62\u943d", "\u1d17\uc435", "\uda5c\udd59\ud864\udd6f\ud998\udf65",
        0, 24679, 1694066232, -4139159106321121257L, 52880L, true, true, (char) 26223, (char) 40,
        Double.longBitsToDouble(0x3f9c0d8a30c651a0L), Double.longBitsToDouble(0x3f856c580a50eb80L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 13, 14, "\ud9a8\udf41\uda2d\udca0", "\u736a\u07b6\u74cf\u3f83\u94d2\u48f7\ucd67\ud425\u6fe4\u55ec\u4522\u210b\u4d99\u2f13\u016d\u126c\u296c\u9d55", "\udbd4\uddfe\ud85b\udc13\uda5c\udd59\ud864\udd6f\ud8d8\udd2c\udb2d\udfe9\uda80\udef3\udb5b\udd67\ud96b\udd56\uda34\udd70\ud9be\udda3",
        1, 77171, -2115646341, 4591125099899456644L, -71333L, true, true, (char) 35800, (char) 62308,
        Double.longBitsToDouble(0x3fc83fb655510360L), Double.longBitsToDouble(0x3fd9b7ef97582d7eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\ud905\udf98", "\u526d\u3c29\ub1f6\u2c02\ubf9e\u94d2", "\udb5e\udcc0",
        3, 44338, 402786478, 1327131660233598432L, 13114L, false, true, (char) 25224, (char) 56582,
        Double.longBitsToDouble(0x3fee889b2acadf53L), Double.longBitsToDouble(0x3fddc9533dffe1d0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a3=[Ljava.lang.String;:[[\u7f69\u24db\u4452\u35fc\u94d2\u48f7\ucd67\ud425\uacf5\u55ec\u4522\u210b\u10ea\u3085\u0775\u3736\u9cc5\u9d55]]\012",
        Z.run(T, 1, 14, 9, 2, "\ud819\udd1d\uda2d\udca0", "\u7f69\u24db\u4452\u35fc\u94d2\u48f7\ucd67\ud425\uacf5\u55ec\u4522\u210b\u10ea\u3085\u0775\u3736\u9cc5\u9d55", "\ud913\udd9a\ud85b\udc13\uda5c\udd59\ud864\udd6f\ud998\udf65\uda73\uded2\ud975\udfb3\ud943\udc2b\ud96b\udd56\udacc\udd5c\udbd3\udc8b\ud996\uded6\udbc9\udd74\ud9f9\udecc\ud925\udfc7\ue66b\uda17\ude73",
        19, 58376, -568247370, 6026158479217476465L, 11791L, false, true, (char) 48645, (char) 59685,
        Double.longBitsToDouble(0x3f94b8689de3d300L), Double.longBitsToDouble(0x3fddb3d61053b206L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\ud888\udf6b\ud92a\udd84\ud903\udf01\ud8a0\udd81\uda27\uddfd\ud81b\uddb1\ud92b\uded5\ud813\udcec\udb89\udf06\udb5e\udd94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 8, 10, "\ud888\udf6b\ud92a\udd84\ud903\udf01\ud8a0\udd81\uda27\uddfd\ud81b\uddb1\ud92b\uded5\ud813\udcec\udb89\udf06\udb5e\udd94", "\ud50d\u55ec\u4522\u210b", "\ud9c5\uded4\uc9e4\udb63\udcf2\uda53\udf4f\uf1e4\udb0b\udc7e\ud90c\udcf8\ud85b\udc13\uda54\udd22\ud864\udd6f\ud998\udf65\uda73\uded2\ud975\udfb3\ud943\udc2b\ud924\ude33\uda18\udfa4\ud9b7\ude1f\udb07\udd9d\ud965\udc6a\uda0c\uddf7\ud965\udf27\udb55\udc73\udb32\udc84\udb44\uddba\uda74\udfbb\ud88d\udf03\ud836\udd95\ud9ab\udec8\udb5f\udeef\ud8fd\udd8d\u3635\ud827\udf77\udba7\udcc8\udbea\udf0f\uda09\udf74\ud867\ude27\uda2b\ude0e\ud9ae\udc52\udbc6\udd8c\ud91a\udd57\ud804\udfa8\u0292\ud9bf\udd44\udb31\udc2f\ud9f6\ude5b\udbd1\ude18\ud9ea\ude44\ud929\udec0\uda78\udf81\udab8\udc8d\ud8be\udc88\ud8ec\udfb4\udb27\uded0\ud873\udc79",
        32, 33391, -398510409, 2437342487525052868L, -59503L, false, true, (char) 65202, (char) 22370,
        Double.longBitsToDouble(0x3fe1f9ee4bc96cfaL), Double.longBitsToDouble(0x3fe986e2945c2718L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 6, 5, 11, "\ud896\ude9b\udafc\udcdc\ud847\udeb8\ud8d5\udf4c\ud994\udd09\ud810\udc76\ud9d4\udda9\ud910\udd2a\uda45\udc3a\ud87a\ude64", "\u566f\u0440\u0c65\u9af2\ub4b2", "\udadd\ude39\ud8f8\ude27\ue742\ud91a\udcdc\udb2b\ude33\ud90c\udcf8",
        13, 64672, -408423802, -6402427727138200743L, 70260L, true, false, (char) 50853, (char) 17082,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 10, "\ud919\ude3e\uda2d\udca0\udbfd\ude38\ud8a0\udda7\udb29\ude47\ud9ad\udfc8\ud92b\uded5\ud813\udcec\udb89\udf06\udba1\udeb6", "\u6fe4\u55ec", "\ua8f9",
        3, 39814, 1390130434, -5283549551806568871L, -69994L, false, true, (char) 47079, (char) 43796,
        Double.longBitsToDouble(0x3fe7763b5797f797L), Double.longBitsToDouble(0x3fd59b8d6e5f2290L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 2, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\udb29\ude47\udb64\udc82\ud92b\uded5\ud813\udcec\udb89\udf06\ud843\ude67", "\u6fe4\u55ec", "\udb6e\udcda",
        26, 39814, 1390130434, -5283549551806568871L, -69994L, false, true, (char) 46984, (char) 43796,
        Double.longBitsToDouble(0x3fe7763fb197f797L), Double.longBitsToDouble(0x3fd59c792e5f2290L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 10, "", "", "",
        -5, 23031, -1936843357, 124317828382720L, -49317L, false, true, (char) 15183, (char) 6146,
        Double.longBitsToDouble(0x3fde0126a04355a0L), Double.longBitsToDouble(0x3fe1350ea80058daL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 5, 15, 6, "\ud975\udc9d\uda1a\uddc6", "\u7f1d\u16c7\u5a25\u18d3\u9451\u9be0\ub5e8\ud425\uce79\u156e\u5b32\u210b\u303e\u314c\u0775\u8635\u78c5\u9d55", "\uda0d\uddeb\ud85b\udc13\udb05\udc2d\ud9ad\udc17\udae9\udd2e\ud82c\uddba\ud811\udeb1\udbe5\udcf5\udad4\udf7d",
        3, 68581, 280476227, -2003816995574724395L, -65983L, false, true, (char) 53838, (char) 1635,
        Double.longBitsToDouble(0x3fbf51d4a29d2fb8L), Double.longBitsToDouble(0x3fe4a869f35eaacbL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud96f\udee9\udb00\uddc9\udb64\udc82\ud9b3\udc67\ud820\udc23\udb89\udf06\ud843\ude67 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 7, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud96f\udee9\udb00\uddc9\udb64\udc82\ud9b3\udc67\ud820\udc23\udb89\udf06\ud843\ude67", "\u26d6\ub576", "\udbb5\udc59\uda11\udc66\udbd8\udce8\ud94d\udd75\udb1e\udf5a\uda53\udf7d\ud831\udd58\udbbb\uddeb\ud84c\udeb9",
        12, 85031, -141074706, -5127647695753181863L, 61818L, true, false, (char) 15655, (char) 34007,
        Double.longBitsToDouble(0x3fbe03b7275e1af8L), Double.longBitsToDouble(0x3fe416a88fff8465L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 10, "", "\u2afa\u4689\ua60f\u5574\u74cf", "\000",
        -5, 57344, 933021179, 45539478512599040L, -41152L, true, false, (char) 59387, (char) 3548,
        Double.longBitsToDouble(0x3fc5aa5b60000000L), Double.longBitsToDouble(0x3fee889b2acadf53L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\000",
        -5, -1000, 0, 7536211026281090816L, -39840L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 13, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd", "\u35b8\u9459\u14fa\u94c9\u7fc5\uc6e4\u536b\ud416\u210b", "\ud895\udf67\udb0e\udd98\udb1e\udf39\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8\ud85b\udc13\uda5c\udd59\ud864\udd6f\ud98d\ude65\ud892\udded",
        48, 87586, -972698439, 1650569360269924473L, -44341L, true, true, (char) 30169, (char) 11331,
        Double.longBitsToDouble(0x3fa21b038cc2fa00L), Double.longBitsToDouble(0x3fd8a1c847894dfeL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\ud86b\udebf\ud91e\udeb3\ud92b\uded5\ud813\udcec\udb89\ude8d\ud8ef\udf56 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 14, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\ud86b\udebf\ud91e\udeb3\ud92b\uded5\ud813\udcec\udb89\ude8d\ud8ef\udf56", "\uc6ae\u3e53\ud416\u30f2\u10ea\u570e\u07d1\u3736\u0b89\u1ae9\u3c05\u0825\u62af\u276c\u1501\u8ab6\ube09", "\ud93d\ude1d\ud91e\udd4e\uda34\udd70\ud85c\ude1c\ud904\udf44\ud982\ude3b\udbfa\udc2c\ud8b6\uddb2",
        24, 33289, 478437580, -8210005452194769939L, -17434L, true, false, (char) 1720, (char) 63100,
        Double.longBitsToDouble(0x3fed1bab903b67d0L), Double.longBitsToDouble(0x3fbbd2194da4dfa8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 7, 7, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\ud961\udf3a\udbba\udd81\ud86a\udcd4\ud813\udcec\udb89\udf06\ub708", "\000\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d",
        -3, 55754, -253212196, -3571980131856098137L, -30263L, false, false, (char) 46894, (char) 26118,
        Double.longBitsToDouble(0x3fc72c9f205f1a38L), Double.longBitsToDouble(0x3fbe45ba16800000L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:\ud93b\udf41\udaf7\udd5b\ud903\udf1b\ud8a0\udd81\ud961\udf3a\udbba\udd81\ud92b\uded5\ud8ba\udf9b\udaad\ude79\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 7, 10, "\ud93b\udf41\udaf7\udd5b\ud903\udf1b\ud8a0\udd81\ud961\udf3a\udbba\udd81\ud92b\uded5\ud8ba\udf9b\udaad\ude79\ub708", "\000\u55ec\u4522\u28c9\u10ea", "\uc9e4\udb1e\udf5a\uda53\udf7d",
        -3, 55754, -253212196, -379191705411517809L, -30263L, false, false, (char) 46894, (char) 26118,
        Double.longBitsToDouble(0x3fc72c9f205f1a38L), Double.longBitsToDouble(0x3fbe45ba16800000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\ud961\udf3a\udbba\udd81\ud92b\uded5\ud813\udcec\udb6a\udc06\ud929\udf05\ud8ac\ude99\uda61\udce2\udbbe\udca0\udb6b\udce5\ud898\ude18\udb67\udc4c\udb6e\udcda\udb0c\ude66\ud9cc\udf62\uc9e4\udb1e\udf5a\u9895\uda94\udf32\u2929\ud935\udea3\ud85b\udc13\uda5c\udd59\ud864\udd6f\uda8c\udfa6\000\ud923\udde9\ud861\uddb8\udb62\udf40\ud9bf\udf6e\uda6b\udc37\udba9\udd6f |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 8, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\ud961\udf3a\udbba\udd81\ud92b\uded5\ud813\udcec\udb6a\udc06\ud929\udf05\ud8ac\ude99\uda61\udce2\udbbe\udca0\udb6b\udce5\ud898\ude18\udb67\udc4c\udb6e\udcda\udb0c\ude66\ud9cc\udf62\uc9e4\udb1e\udf5a\u9895\uda94\udf32\u2929\ud935\udea3\ud85b\udc13\uda5c\udd59\ud864\udd6f\uda8c\udfa6\000\ud923\udde9\ud861\uddb8\udb62\udf40\ud9bf\udf6e\uda6b\udc37\udba9\udd6f", "\u4da2\ubbd7\ud551\u93bf\uca27\u7bd0\ub8e0", "\ud9ec\udc4d\uda15\udc5a\udb9a\udc7a\udaac\udeee",
        6, 89306, 865570808, -1027870582413354110L, -50212L, false, true, (char) 23611, (char) 21888,
        Double.longBitsToDouble(0x3fdaa31c7e80113aL), Double.longBitsToDouble(0x3fed8f3ffc4bc8fdL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 11, 9, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\ud961\udf3a\udbba\udd81\ud92b\uded5\ud813\udcec", "\ucd67\u3c71", "\udaf0\udd06",
        44, 99760, -1593835520, 6402506950673413378L, 86671L, true, true, (char) 27165, (char) 57103,
        Double.longBitsToDouble(0x3fe7ff8744a7ce6dL), Double.longBitsToDouble(0x3fdeec7f6f2fef2eL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 5, 5, 12, "\ud905\udf98\uda2d\udca0\udb17\udce0\ud8a0\udd81\uda27\uddfd\udbba\udd81", "\u1888\uc9fb\ucd67\u0da1\u6fe4", "\ud8dd\udc39\udadb\udcd8\udb68\udf07\ud8dc\udfea\uc9e4\udb1e\udf5a\uda74\udd8d\uf1bb\ud88d\udcde\ud90c\udcd5\ud85b\udc13",
        -1, 20163, -1655205974, 912599592431171375L, 80409L, true, false, (char) 2276, (char) 22482,
        Double.longBitsToDouble(0x3fd6b0ba634f7990L), Double.longBitsToDouble(0x3fefa40f29b02d61L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 4, 4, 12, "\ud905\udf98\uda2d\udca0\ud903\udf1b\udbfc\udc59\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06", "\ud425\u6fe4\u55ec\u4522\u210b\u10ea\u3085\u0775\u3736\u78c5\u9d55\u600d\u97bb\u97d5\u643e\u498d\u4ad6\uc2bb\u9381", "\ud96b\udd56\uda34\udd70\ud9be\udda3",
        28, 77171, -2115655257, 3270163034260840880L, -94579L, false, true, (char) 59544, (char) 7113,
        Double.longBitsToDouble(0x3fca93bfec62d874L), Double.longBitsToDouble(0x3fb9d5ec530d3878L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\uc593\udb32\udceb\ud985\udc21\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 4, 12, "\ud905\udf98\uda2d\udca0\uc593\udb32\udceb\ud985\udc21\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06", "\u8f25\u6fe4\u5d08\u992c\u057b\u10ea\u3085\u5eaa\u3803\u78c5\u4cbd\ud586\u0c99\u97d5\u643e\u4958\u4ad6\u6d0a\u1024", "\ud96b\udd56\uda34\udd70\ud9be\udda3",
        0, 77171, -2115655257, -5212648340940915491L, -54645L, false, true, (char) 25299, (char) 43317,
        Double.longBitsToDouble(0x3fb9d5ec530d3878L), Double.longBitsToDouble(0x3feba574d6e3609aL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 13, 10, "\ud905\udf98\ud829\udd7f\udb8d\ude5a\ud8a0\udd81\uda27\uddfd\udbba\udd81\udbb3\uddc1\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u0254", "\uc9e4\udb1e\udf5a\uda53\udf7d",
        -3, 85194, -253206422, -3571980131856098137L, -30263L, true, true, (char) 18551, (char) 59198,
        Double.longBitsToDouble(0x3fc72c9f321b8a38L), Double.longBitsToDouble(0x3fbe6dd4d6846040L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 12, 10, "\ud902\udffe\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\uda89\udec9\ud8aa\udd32\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u0254", "\uc9e4\udb1e\udf5a\uda53\udf7d\uda55\udc45\udb8f\ude47\ud838\ude51\udaa0\udef6\uda5c\udd59\ud864\udd6f\ud998\udf65\uda73\uded2\ud975\udfb3\ud943\udc2b\udb37\uded3",
        30, 73452, 1572776656, -5419160100315836425L, -42220L, false, false, (char) 21633, (char) 40348,
        Double.longBitsToDouble(0x3fe249e26461062fL), Double.longBitsToDouble(0x3fe765bf31a68a87L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 12, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\udbb3\uddc1\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u0254", "\uca9a\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud911\udf86\ud85b\udc13\uda5c\udd59\ud864\udd6f\ud998\udf65\uda73\uded2\ud975\udfb3\ud943\udc2b\udb37\udefc\uda4c\udc3d\ud9be\udda3\ud91a\udfa7\u3f24\uda68\ude13\uda1e\udec3\udb2c\udc97\uc5c2\udb11\udd50\ud98b\udeae\udb5a\udcf8\ud835\ude1c\ud94f\udec9\udb86\ude9b\uda31\udc80\udabc\udcd5\ud882\ude0c\ud9d9\udcc6\ud90e\uddd0\udb26\udefe\ud8a3\ude5d\udb6c\udcfa\udb24\udd1a\ud890\udce2\ud895\ude6b\ud914\udf7b\ud975\udf8f\udbb4\udfd9\udbf6\udef5\uda59\udd16\udaf6\udf9d\ud804\udedd\ud8b1\udc08\u782c\ud95d\udc97\ud892\udd39\ud9ff\udd63\uda80\uddda\udac8\udc0b\udbc5\uddd9\ud88a\udc5c\uaff6\udb8a\uddef\ud81b\udceb\uda70\udedc",
        28, 14203, -1061068751, -3403586113694717979L, -94841L, true, true, (char) 25979, (char) 38790,
        Double.longBitsToDouble(0x3fe5df9b35418c61L), Double.longBitsToDouble(0x3fdce2a0ebcf242aL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 12, 10, "\ud905\udf98\uda2d\udca0\udb89\udf1e\ud8a0\udd81\ud8b2\udfa9\udadd\udd53\ud987\udc35\uda48\udf99\udb64\udf32\ud8b9\udf0d", "\u6fe4\u2736\ubc1c\u2149\u0254", "\uca44\udb1e\udf5a\uda53\udf7d\uf1e4\udb8a\udd31\ud9fb\udc3c\ud8b8\udf10\udb1d\ude39\ud864\udd6f\ud998\udf65\uda73\uded2\ud975\udfb3\ud975\udc24\udb37\udefc\uda4c\udc3d\uda60\udff3\ud8ca\udcf9\uda53\udee7\ud91c\ude9b\uda71\udf0b\ud84d\udea0\uda60\ude3b\ud8a8\udd26\ud99c\udc02\uda94\udcfb\udbce\ude70\ud849\uddf3\udbc8\udcf5\udad9\udeb6\uda4d\udfad\ud872\udf9e\ud8cd\udd48\uda57\udf2c\ud8f1\udc11\uda6b\udd9a\ud807\udf27\ud91a\udfd4\ud8ef\udde0\udad3\uddac\ud873\udef6\ud955\ude4e\uda7f\udfec\udb03\udcde\ud804\uddd8\ud8bc\udf9f\udb12\udd69\udb20\udd89\uda7b\udcde\uda8d\udc44\ud9e8\uded4\ud8f2\udfb1\udad1\udf29\uda7a\udee8\uda27\uded1\ud8bd\udc5e\ud8ed\udce6\udb71\udfc8\ud8d3\uddcf\udbc9\udc2a",
        0, 60567, -311880494, 337748808244688769L, -3736L, false, false, (char) 3161, (char) 2975,
        Double.longBitsToDouble(0x3fba5da672265410L), Double.longBitsToDouble(0x3fcfd9dcd87b5734L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 6, 6, 10, "\udbf6\udf70\ud820\udc8c\udaac\udcb8\ud8a0\udd81\uda27\uddfd\udabd\udf89\udbce\udee5\ud87a\udd4d\udb89\udf06\udaa1\udc81\ud9a9\udc6d\ud936\udd05\udb71\udf20\u4b3c\ud898\ude11\udb67\udc4c\udbbc\ude0f\ud926\udeb2", "\ub02e\u6956\u1d17", "\ud98f\uddd3\uda9a\udcac\udacc\udef8\udbeb\udc20\udb37\udca3\ud95b\udde1\ud95b\uddfd\ud919\ude43",
        28, 73361, 194226896, -4843382347767895641L, 56046L, true, true, (char) 10585, (char) 4909,
        Double.longBitsToDouble(0x3fc995dfdd81c9f4L), Double.longBitsToDouble(0x3fe14706b1fa1a91L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 10, "\uda7e\udf34\uda2d\udca0\ud8c2\udefb\ud8a0\udd81\uda27\uddfd\udabd\udf89\udbce\udee5\ud86d\ude4d\udb89\udf06\udaa1\udc81\uda5b\udde6\ud978\uddac\ud92f\udfd2\uda92\udcdc\ud898\ude18\udb67\udc4c\udbbc\udea6\ud926\udeb2\ud9f6\udc23\uc9e4\udbc1\uddaa\uda7c\udf7d\udba2\uddf6\udaea\udede\ud932\ude10\ud98f\uddd3\udba7\udd73\ud9ff\ude73\udbe6\ude3c", "\u47b7\u34a4\u13a9\u4f07", "\uda0c\ude38\ud9c0\udcb5\ud851\ude94\udbd0\udc19\udb02\udd5e\udac0\udf32\udb7f\udffa\udba5\udda1\ud8fc\udf8b\udb91\udd89\udb26\udfb8\udb5e\udcb4\ud8c5\uded4\udb79\udf6c\uda54\udf2c\udba7\ude9e\uda29\udd4c\ud95d\udd88\ud944\ude8c\udb97\udc23\ud826\udf99\ud911\udd22",
        25, 4509, -2014798217, -9008412308603064924L, -63497L, true, true, (char) 53974, (char) 54995,
        Double.longBitsToDouble(0x3fc3ad23b9a247f4L), Double.longBitsToDouble(0x3fe70120f68dc4fcL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 9, 10, "\uda7e\udf34\uda2d\udca0\ud8c2\udefb\ud8a0\udd81\uda27\uddfd\udabd\udf89\uda12\udc68\ud86d\ude4d\ud93e\ude0d\udaa1\udd49\uda5b\udde6\ud978\uddac\udbff\ude3a\ud8f1\udcfa\ud898\ude18\udb67\udc4c\ud887\udc2b\ud8d6\ude01\ud9f1\udcb1\uc9e4\udb49\udd0e\uda4a\uddc6\uf179\udb0b\udc7e\udb9f\udeef\ud99c\udfff\ud809\udf2b\ud9ff\udee0\udbe6\ude3c", "\u47b7\u34a4\u13a9\u4f07", "\uda0c\ude38\ud9c0\udcb5\ud850\udf94\udbd0\udc19\udb02\udd5e\udae7\ude32\udb7f\udffa\udba5\udda1\ud8fc\udf8b\udb91\udd89\ud854\udf69\ud816\uded1\ud977\udcdc\udb79\udf6c\uda54\udf2c\udba7\ude9e\uda29\udd4c\ud95d\udd88\ud944\ude8c\udb97\udc23\ud826\udf99\ud911\udd22",
        30, 50077, -2014798217, -9008412308603064924L, -63497L, true, true, (char) 53974, (char) 54995,
        Double.longBitsToDouble(0x3fc3ad23b9a247f4L), Double.longBitsToDouble(0x3fe70120f6b7c4fcL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 10, "\uda7e\udf34\uda2d\udca0\ud8c2\udefb\ud8dc\ude86\uda27\uddfd\udabd\udf89\udbce\udee5\uda94\udd8f\udac3\udfcd\udaa1\udd10\uda5b\udde6\ud8dd\udea3\ud92f\udfd2\uda92\udcdc\ud898\ude18\udb67\udc4c\udbbc\udea6\ud951\uddc1\ud9f6\udc23\uc9e4\udbc1\uddaa\uda7c\udf7d\uf1e4\udb0b\udc7e\ud932\ude10\ud98f\uddd3\udba7\udd73\ud9ff\ude73\udbe6\ude3c", "\u47b7\u34a4\u13a9\u4f07", "\uda0c\ude38\ud9c0\udcb5\udbfd\udc8b\udac3\udcee\udb02\udd5e\udac0\udf32\udb7f\udffa\udba5\udda1\ud8fc\udf8b\udb50\udddd\udb26\udfb8\udb5e\udcb4\ud8c5\uded4\ud9ef\udc67",
        0, 25645, -1678585038, 5179290530820176674L, 91396L, true, false, (char) 44409, (char) 21856,
        Double.longBitsToDouble(0x3fd739dbb904276cL), Double.longBitsToDouble(0x3fcb42b33b6f8cc0L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Character:\000 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Character:\000 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 13, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\udbe3\uddfb\udbba\udd81\ud92b\uded5\udb76\udddd\ud858\uddd9\udb1d\udd2a", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uca06\udb1e\udf5a\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 20767, -1385519670, -7361433110928947788L, -8296L, true, false, (char) 50853, (char) 48992,
        Double.longBitsToDouble(0x3fe68460466b0b93L), Double.longBitsToDouble(0x3fe71be653f481e5L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 12, "\ud84d\udc7f\uda2d\udca0\ud903\udf1b\udbdf\udc75\ud825\udcf2\udbba\udd81\ud92b\uded5\ud813\udcec\udb93\udc6c\udb62\ude65", "\u6fe4\u55ec\u4522\u93aa\u18c9\u30e7", "\udb1e\udf5a\uda53\udf7d\uf1e4",
        29, 94804, -831666433, -4037797406214487570L, 70440L, true, false, (char) 56741, (char) 48864,
        Double.longBitsToDouble(0x3fe68460416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 5, 5, 10, "\ud84d\udc7f\uda7a\ude67\ud903\udfb5\udbde\udfc4\ud825\udcf2\udbba\udd81\ud880\udd9e\ud98a\udf36\udb93\udc6c\u8a08", "\u6fe4\u55ec\u4522\u93aa\u18c9", "\u8f5f\udae0\udfec\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8",
        28, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 56741, (char) 20666,
        Double.longBitsToDouble(0x3fe680fb416b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=null |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 2, "\ud84d\udc7f\ud979\udeee\ud927\ude0d\ud8bb\udcb6\udaba\udf13\ud998\ude72\ud92b\ude7c\u9c37", "\u8654\u4407", "\ud898\ude18\ud80a\udd65\udbf0\udccd\ud926\udef6\ud9cc\udf62\ud91d\udc5a\udbb7\ude03\uda53\udfc1\ud938\udcdf\ud850\udc7b\ud83d\uddc9\ud8ec\udd0f\ud9f8\udc98\ud86c\udf80\ud84b\udf82\ud829\uddc4\ud9d3\udfba\u0a02\u63ae\ud9ba\udc70\ud8ff\udf22\udba8\uddee\udaee\udd35",
        47, 90610, 516735030, 1721368880610063744L, 18627L, false, true, (char) 58799, (char) 34010,
        Double.longBitsToDouble(0x3fd8e0b4ac7f0352L), Double.longBitsToDouble(0x3fec47dca9df08c6L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Character:\ud92b |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 7, 10, "\ud905\udfef\ud994\udc75\uda69\udf4e\ud8d5\uddeb\uda46\udca1\udbba\udd81\ud92b\ude8b\ud813\udcec\ud93d\udf85\ub708", "\u6fe4\u5329\u48af\u0f60\u9b71", "\ud8b2\udc93\udb55\udd0d\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8\ud96e\udfbc\udb11\udf56\ud864\udd6f\ud93a\udf07\ud9cc\ude29\ud975\udfb3\ud985\udc2c\udb74\udf57\ud9a6\udfba\ud912\udd02\uda88\udf7e\udbc9\udd74\uda0c\ude38\ud817\udde1\udbc2\udc18\ud9b4\udc89\udb80\udc14\ud94a\udcc1\udbaa\udcd1\udb5c\udf66\u16f0\ud994\uded3\udb67\udd66\ud882\udeba\ud870\udc9c",
        12, -814, 1984118201, 4327168130823931539L, 7589L, false, true, (char) 15698, (char) 9926,
        Double.longBitsToDouble(0x3fe62d364a3c25c1L), Double.longBitsToDouble(0x3fec771d1a5b9953L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "", "\u2afa", "\udb8f\udfe7\ud92b\uded5\ud813\udcec\u00dd\udbbe\udc1e\ud87d\uddcd\ud978\uddac\u0142\udb6b\udce5\ud898\ude18\udb67\udc4c\u23e0\000\ud920\ude47\ud948\ude47\udad3\ude32\uda4a\uddb2\uf1e4\udb0b\udc7e\ud90c\udcf8\uc6ff\uda25\udcb2\ud864\udd6f\ud998\udf65\uda73\uded2\ud975\udfb3\000\000\000\000\udabc\uded8\udbc9\udd74\udb97\uddfc\ud9f2\ude77\ud8d5\ude99\uda80\udc7f\udb95\udf31\udae6\udf71\udb1b\udffe\ud99f\udcd9\ud9bc\udfc6\uda5b\ude6e\uda30\udf38\ud86e\udf7c\uda38\ude98\uda84\udefe\ud95b\udce8\ud969\uddb7\uda56\udc1e\ud818\udf09\ud928\udc92\udb6b\udd1d",
        39, 51695, 1648196803, 729348120487325933L, 77521L, true, false, (char) 3918, (char) 2611,
        Double.longBitsToDouble(0x3fdd0797a44259e6L), Double.longBitsToDouble(0x3fd52722279204aaL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\u83d3\u8b09\ud8ac\ude99\ud978\uddac\u0141 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 5, 7, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\u83d3\u8b09\ud8ac\ude99\ud978\uddac\u0142", "\u210b\u10ea\u3085\u0775\u3736\u78c5\u9d55\u1d17\uaf81\u81fd\ud651", "\ud854\udf63",
        0, 24679, 1694066232, -4139159105684832233L, 58601L, true, true, (char) 54207, (char) 32976,
        Double.longBitsToDouble(0x3fe98bdc0f87caf3L), Double.longBitsToDouble(0x3fe6a25c73645992L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 5, 5, 7, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\u83d3\u8b09\ud8ac\ude99\ud978\uddac\u0142", "\u2182\u10ea\u3085\u0775\u3736\u78c5\u9d55\u1d17\uaf81\u81fd\u643e", "\ud998\udf65\uda73\uded2\ud975\udfb3\ud943\udc2b",
        1, 48551, -1138614289, -9001459263653684885L, 34156L, true, true, (char) 10875, (char) 54881,
        Double.longBitsToDouble(0x3feb22cc90d860d1L), Double.longBitsToDouble(0x3fd86dc143631778L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 3, 9, "\ud905\udf98\ud951\ude8b", "\u471c\u07b6\ud7cf\u35b8\u34c1\u0c72\ucd67\ud425\u2b4f\u6eba\u4522\ub6eb\u5c2c\u8035\u9b74\u3736\u2a8d\u0826", "\000\000\000\ud99a\uddec\ud8c1\udf38\u00b5\000\udb70\udc43\ud956\ude63\uda34\udd70\ud9be\udda3\ud833\ude34\udb9b\udc06\uda0c\ude38\ud988\ude18\ud9d7\udfad\uda74\uddb1",
        22, 10536, -37569279, 4635202022468405039L, -89579L, true, false, (char) 13031, (char) 49980,
        Double.longBitsToDouble(0x3fdd5a76c6070424L), Double.longBitsToDouble(0x3fd9797b85ace506L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 2, "'", "\u54fb,\u5ecc\u803c\uc404\u94d2", "\000",
        -5, -1000, 0, 0L, -100000L, false, true, (char) 219, (char) 0,
        Double.longBitsToDouble(0x3e30000000000000L), Double.longBitsToDouble(0x3fddc9533a1be1d0L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 14, "\ud8be\udf1c\uda2d\udca0\ud903\udf1b\ud8a0\udd81\ud91d\udc7e\u07db\ud92b\uded5\ud8b6\udcfd\udb89\udf06\ub708\ud8ac\ude99\ud978\uddac\u0142\udb6b\udce5\ud898\ude18\udb67\udc4c\ud9bb\udee8\ud875\udf70\udb69\udee9\ud9e7\udec4\udb41\udc00\uda53\udf7d\uda79\udf38\ud97b\udc64\udbd4\uddfe\ud85b\udc13\uda5c\udd59\ud864\udd6f\ud8d8\udd2c\udb2d\udfe9\uda80\udef3\udb5b\udd67\ud96b\udd56\uda34\udd70\ud9be\udda3\uda88\udf7e\udbc9\udd74\udb8d\udd48\ud8c1\udf7a\uda6f\ude19\ud98c\udc25\uda57\udca5\ud93d\udf52\udbbc\udc70\u7a3b\uda82\udca0\ud8bc\udc34\ud8f3\udc93\uda5b\udccf\ud8a8\udef2\uda6b\udddb\ud800\udce7\ud96b\udeeb\ud9b8\udcff\ud984\udfb9\udb13\udff6\udb99\udf6f\ud911\uddbb\udaf7\udfca\udaf8\udfa2\udab7\udc89\ud99b\uddbc\ud954\udf37\udb9c\udd68\ud9c4\udcaa\udb69\udf1a\ud965\ude9f\udb6a\udc13\udb2a\udfbc\ue6a2\udbb0\udcb3\ud99c\udf56\uda9e\udc13\ub1e5\uda9b\udd5b\udb16\ude10\uda89\udc11", "\ub296\u67a3\u1cf1\u9883\ucc9c\u1084\u7921\u0965\u5b74\u4045\ucd7a\u5558\u9ba0\u225a\u67b2\u8c3f\u881f\u769b\u0336\u700b\ub000\u0598\u9b55\ua5c7\u1fb4\u38a9\u575b\ub9ff", "\udade\ude8a\udbb6\udc1c\ud6e4\uda95\udf6e\udba7\uddb2\ud969\udf46\udb81\udf63\udab9\udcd0\ud885\udfbb\udb9f\ude4c\ufb58\udb34\udf03\udb7e\uddc6\udb95\udf28\ud8c2\ude1d\udb63\ude92\udb60\udf5e\ud855\udfb4\ud85b\udeb7\udbb7\udc1d\udbe2\udc63\ud8d2\udfc4\udbf8\udd9c\udb70\udf86\ud885\udd12\ud837\udeb5\udbb9\udd09\ud979\udef0\udb39\udfda\ud804\udd39\udbe3\udd69\uda5c\udc53\udb53\udc56\u0c73",
        59, 98117, -1513854685, -6134513417415528317L, -79316L, false, true, (char) 210, (char) 9391,
        Double.longBitsToDouble(0x3fef6295763dd3bdL), Double.longBitsToDouble(0x3fc0698c578b2b64L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 6, 6, 14, "\ud9a8\udf41\uda2d\udca0", "\u736a\u07b6\u74cf\u3f83\u2275\u4962\ucd67\ud425\u6fe4\u55ec\u555c\u210b\u4d99\u6ee3\ucf54\u126c\u296c\u9d55", "\udbd4\uddfe\ud85b\udc13\uda5c\udd59\ud864\udd6f\ud8d8\udd2c\udb2e\udc3e\udb46\uddb6\udb5b\udd67\ud96b\udd56\uda34\udd70\ud9fa\udfa1",
        1, 77171, 1606955131, 4591124992525274244L, -25916L, true, false, (char) 11892, (char) 50731,
        Double.longBitsToDouble(0x3fd9b7ef97582d7eL), Double.longBitsToDouble(0x3fd7c3c9c5eec736L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:\udb4a\udf90\uda2d\udc7c\ud903\udf1b\udbc7\udf9e\ud98c\udf0c\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\uda20\uddde\ud97f\uddef\udb5e\udcc0G\udb62\udfe5\ud898\ude2b\udb67\udc4c\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\udb4a\udf90\uda2d\udc7c\ud903\udf1b\udbc7\udf9e\ud98c\udf0c\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\uda20\uddde\ud97f\uddef\udb5e\udcc0G\udb62\udfe5\ud898\ude2b\udb67\udc4c\uda22\udcd4\ud926\ude94", "\u78c5\u9d55\u1d17", "\udad3\ude65\ub62c\ud8fa\udd72\udac4\udfa5",
        44, 69169, 1440222481, -3312453579530353493L, -23179L, true, true, (char) 42942, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3fe8e777b5e17262L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 2, "\udb4f\udc06\ud909\udc7c\ud91d\ude8a\ud8bb\udcb6\uebc8\ud8d4\ude96\ud8c4\udd0f\u9d18\udb93\udc6c\u7b08\uda80\udfb9\ud8dd\ude5a\u0142\uda27\udc84\ud898\ude18\ud80a\udd65\udbf0\udccd\ud926\udef6\ud9cc\udf62\ud91d\udc5a\udae5\udcdb\uda53\udfc1\ud938\udcdf\ud850\udc7b\ud83d\uddc9\ud8ec\udd0f\ud9f8\udc98\uda56\udd15\ud84b\udf82\ud829\uddc4\ud9d3\udfba\u0a02\u63ae\ud9ba\udc70\ud8ff\udf22\udba8\uddee\udaee\udd35\uda80\udcaa\udbcd\uddc0\uda92\ude06\ud974\udd48", "\u5bcc", "\ud942\ude98\udaa6\ude32\ud95f\uddfc\ud973\udc0c\uda69\udcec\udb56\udd1a\udb65\ude36\uda41\udfce\ud88c\udfda\ud831\udc1a\ud99a\udc27\uda56\udc16\udb30\udc67\ud819\udcdc\ud9a6\ude71\udb60\udddb\ud858\udd1f\uda82\udfd8\ud8fa\udef1\uf87c\ud987\udfd9\udb85\udd2d\ud8a6\udf6b\ud8f2\udca5\ud8fa\udc67\udbaf\udf08\uda5d\ude99\udaf6\ude17\udada\uddf9\uda13\udc29\udb04\udf33\ud838\ude10\ud8d1\udf5c\ud9bb\udf37",
        47, 21317, 1474907839, 4010087634142314319L, -92847L, false, true, (char) 23595, (char) 17369,
        Double.longBitsToDouble(0x3fdc66949d6fe4f6L), Double.longBitsToDouble(0x3fe3ac65ab017e06L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 5, 5, 7, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udbf3\udf3a\u8b09\ud8ac\ude99\ud978\uddac\u0142", "\u20eb\u10ea\u3085\u0775\u3736\u78c5", "\uda2b\udc45\ud906\udefd\ud85b\udc13\ud8c2\udfb4\ud867\udd9f\ud998\udf65\uda73\uded2\ud975\udfb3\ud943\udc2b\ud94c\ude56\ud8b2\udcb0\ud848\udfef\ud95f\udd21\uda43\udeb1\u2ff6\ud8f4\udcf1\udab5\udc10\udb80\udffa",
        0, 39916, 1007950040, -8377608427177936463L, -62871L, false, false, (char) 32935, (char) 6027,
        Double.longBitsToDouble(0x3feb791df649a95fL), Double.longBitsToDouble(0x3fe66c4845be6db6L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:\udb4a\udf90\uda2d\udc7c\ud903\udf1b\udbc7\udf9e\ud98c\udf0c\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\uda20\uddde\ud97f\uddef\udb5e\udcc0J\udb62\udfe5\ud898\ude2b\udb67\udc4c\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\udb4a\udf90\uda2d\udc7c\ud903\udf1b\udbc7\udf9e\ud98c\udf0c\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\uda20\uddde\ud97f\uddef\udb5e\udcc0J\udb62\udfe5\ud898\ude2b\udb67\udc4c\uda22\udcd4\ud926\ude94", "\u78c5\u9d55\u1d17", "\udad3\ude65\ub62c\ud8fa\udd72\udac4\udfa5",
        44, 69169, 1440222481, -3312453579530353493L, -23179L, true, true, (char) 42942, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3fe8e777b5e17262L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\udb4a\udf90\uda2d\udc7c\ud903\udf1b\udbc7\udf9e\ud98c\udf0c\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb6c\udd97\uda20\uddde\ud97f\uddef\udb5e\udcc0G\udb62\udfe5\ud898\ude2b\udb67\udc4c\uda8d\udda9\ud926\ude94", "\u78c5\u9d55", "\ud90c\udcf8\udad3\ude65\ub62c\ud8fa\udd72\udac4\udfa5\udaa8\udc1b\uda18\udff2\ud824\ude20\ud9c8\ude4f\udbb3\udcbb\ud8f2\udf0e\u82c0\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\udbca\ude6f",
        33, 9281, -675606927, 5033458475234651595L, 36763L, true, false, (char) 58556, (char) 62576,
        Double.longBitsToDouble(0x3fe658da6404362aL), Double.longBitsToDouble(0x3fe14b852f1515beL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.String:\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\ua8ea\000\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\000\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\ua8ea\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud90c\udcf8\udacd\udde1\000\uc700\000\udaa7\udf81\uda18\udff2\ud824\ude20\005\u44ab\ud8a4\udeb2\u82c0\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\udbca\ude6f",
        33, 55857, -1593502047, 873006545392911853L, 29774L, false, false, (char) 43644, (char) 25858,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd439f87fd67030L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.String:N |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 8, 15, 11, "\udb16\udc40\uda2d\udc7c\ud903\udf1b\ud922\udf2c\u731d\ud9d7\udf96\ud98a\udd9b\udbaa\udd80\udb89\udf06\uda20\uddde\ud985\uddf2\udb5e\udcc0N", "\u210b\ua534\u3085\u485f\u3736\u78c5\u9d55\u1a8d\uc463\u1e30\026", "\udac4\udfa5\udaa8\udc1b\uda18\udff2\ud824\ude20\ud9c8\ude4f\udb3b\udd3f\ud8f2\udf24\u82c0\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\udbca\ude6f\udab5\uddd9\ud967\udfec\udba9\udd07\udaf1\udec2\ud8fd\udebf\ud9b6\udf87\ud9ba\udca8\uda71\udda6\udb9a\udda3\uda74\ude88\uda83\udcd7\udb06\uddda\udba5\udf20\ud942\udf34",
        44, 22037, -576010586, -4748354163376881510L, 54609L, true, false, (char) 40243, (char) 37419,
        Double.longBitsToDouble(0x3fd5169f97634894L), Double.longBitsToDouble(0x3fe955b1eb905541L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String:\udb4a\udf90\uda2d\udc7c\ud903\udef8\udbc7\udf9e\ud98c\udf0c\u349a\ud97b\uddfc\udbd1\udf80\udb89\ude29C\ud97f\uddbe\udb5e\udcc0J\udb38\udfe5\ud898\ude2b\uf337 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KJ |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 0, "\udb4a\udf90\uda2d\udc7c\ud903\udef8\udbc7\udf9e\ud98c\udf0c\u349a\ud97b\uddfc\udbd1\udf80\udb89\ude29C\ud97f\uddbe\udb5e\udcc0J\udb38\udfe5\ud898\ude2b\uf337\000\000", "", "\ud872\udddf",
        -4, 94804, -2119899688, -3476927329204582481L, -62982L, true, true, (char) 60219, (char) 8925,
        Double.longBitsToDouble(0x3fc57a40e16c047cL), Double.longBitsToDouble(0x3fef5d3090037300L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 9, 15, 11, "\uda6d\udf01\udaf1\udc2c\ud903\udf1b\udbc7\udf9e\ud98c\udf0c\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\ud891\ude37\ud97f\ude6d\udb5e\udcc0y\udb62\udfe5\ud898\ude2b\udb67\udc4c\uda22\udcd4\ud926\ude94", "\uc7d4\u66d1\u7fd4", "\udad3\ude65\ub62c\uda32\udd6e\udac4\udfa5",
        44, 23577, 493371558, 7239253848003396779L, -23179L, true, true, (char) 63678, (char) 12703,
        Double.longBitsToDouble(0x3fc9f8785bae3bccL), Double.longBitsToDouble(0x3fe8e777b5e17262L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.String:B\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "b\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud90c\udcf8\udacd\udde1\000\uc700\000\udaa7\udf81\uda18\udff2\ud824\ude20\005\u44ab\ud8a4\udeb2\u82c0\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\uda3c\udec8",
        43, 43773, -1593502047, 873006545392911853L, 29774L, false, false, (char) 43644, (char) 25858,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd439f87fd67030L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:\u8210E\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udb9c\udd7b\udbe8\udd02\ud89f\udda4\ud97f\uddfa\uda29\udfb4\udb94\udf71\udac9\udd12\000\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\000\000\u8210e\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udb9c\udd7b\udbe8\udd02\ud89f\udda4\ud97f\uddfa\uda29\udfb4\udb94\udf71\udac9\udd12\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\udb52\ude51\ud90c\udcf8\udacd\udde1\000\uc700\000\udaa7\udf81\uda18\udff2\udb39\udc13\005\u44ab\ud8a4\udeb2\u82c0\ud8e2\udc39\ud8ab\udffa\ud88f\uddfc\ud921\udc6a\udbca\ude6f",
        33, 55857, -1593502047, 873006545392906477L, 29774L, false, false, (char) 64636, (char) 23623,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd439f87fd67030L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String:\u48f3 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\000\000\u48f3", "\u2b58\u2c02\ubf9e\u94d2\u5a57\uc5cd\uca12", "\ud8a7\udcda\ud999\ude3a\ud9cf\udc8a\ud926\ude94\000\udbc7\udd0c\udb9a\udfad\uda4a\udd7d\uf1e4\udbd4\udf75\ud8c7\udc5c\ud83a\udc03\udab0\ude67\udacc\udf13\udbea\ude34\udaa7\udf81\uda18\udff2\ud824\ude20\udb81\udde5\u4474\ud8a4\udeb2\ud930\udf82\ud98d\udc5a",
        4, 77289, 642753743, -1258297223920034020L, -28671L, false, false, (char) 21002, (char) 53913,
        Double.longBitsToDouble(0x3fdda610c9ea00d6L), Double.longBitsToDouble(0x3fe0848b61b368e0L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KP |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 4, 15, 11, "\ud9d9\udd59\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\udb71\udefa\ud99d\udcc9\uda62\ude77G\ua8eap\uda53\udf4f\udb17\udf14\ud91a\udfdb", "\u5bf0\u8a2a\u3f25\uc435\u97f8\u5e9b\u2b4d", "\udb54\udf80",
        12, 62481, 5, 75499720146944L, -46493L, false, false, (char) 29885, (char) 26769,
        Double.longBitsToDouble(0x3feb8fca991ceef6L), Double.longBitsToDouble(0x3fea54e91ea13ad0L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:K\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\ua8ea\000\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KKK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "k\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\ua8ea\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud8a8\udc65\udac5\udffc\ud87e\udd47\uc717\000\udaa7\udf81\uda18\udff2",
        56, -995, 17579, -6485183462575778837L, -76655L, true, true, (char) 52754, (char) 45123,
        Double.longBitsToDouble(0x3fe509d682d4a105L), Double.longBitsToDouble(0x3fded0c1d3bbc178L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String:\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udbea\udd78T\ud97f\uddef\uda29\udfb4G\udae6\udc07\ud913\udc6b\udb3a\ude07\u7633\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:TK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\000\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udbea\udd78T\ud97f\uddef\uda29\udfb4G\udae6\udc07\ud913\udc6b\udb3a\ude07\u7633\ud926\ude94", "\u604b", "\udbf4\udee1\ud856\ude77\ud8b1\udce7\uda61\udcaf\uc7b1\000\udaa8\udc09\uda18\udff2\ud824\ude20\005\u44ab\ud8a4\udeb2\u82c0\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\udbd1\udd6f",
        33, 55857, -1593502047, 873006545392911853L, 29774L, false, false, (char) 15780, (char) 25951,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd432387fd67030L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 11, 15, 11, "\udb16\udc40\uda2d\udc7c\udb85\ude7c\ud9a6\uddff\u7373\ud9d7\udf96\ud98a\udd9b\udbaa\udd80\ud84e\udd89\ud89d\udfa8\ud9cc\udd79\udb84\udef3w", "\u30be\u12c8\u80ea\u485f\u10f2\ub1bb\u5d4a\u1a8d\uc463\u1e30\ucce7", "\udac4\udfa5\udaa8\udc1b\uda18\udff2\ud824\ude20\ud9c8\ude4f\udb3b\udd3f\ud8f2\udf24\u82c0\ud8ba\udc04\udbf6\udf1f\ud88f\uddfc\ud921\udc6a\udbca\ude6f\u3667\udb1d\uddae\udba9\udd07\udbf7\uddfe\ud8fd\ude3f\ud9b6\udf87\ud9ba\udca8\uda8a\udf74\uda96\uddbc\ud87d\udce2\ud932\udf3c\udad1\udd71\uda6a\udf61\ud94c\udc0d",
        44, 99821, 2051156379, -4748354163376881511L, 54609L, true, false, (char) 40243, (char) 37419,
        Double.longBitsToDouble(0x3fd5169f9d1f4894L), Double.longBitsToDouble(0x3fe6e5b01636b587L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.String:N |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:N |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 14, "\udb16\udc40\uda2d\udc7c\uda58\udc0e\ud865\uded5\ud9e0\udecf\ud9d7\udf96\ud888\udd9a\udbaa\udd80\ud858\ude6e\udb4f\udd02\ud985\uddf2\udb5e\udcc0N", "\uc4ba\u0b37\u3085\u485f\u3736\u9080\u9d55\u56c5\uc463\u14fe\026", "\udac4\udfa5\udaa8\udc1b\uda18\udff2\ud824\ude20\ud9c8\ude4f\udb3b\udd3f\ud8f2\udf24\u82c0\u4b00\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\udbca\ude6f\udab5\uddd9",
        14, 98045, 1041726234, 2465945900964716145L, -74531L, true, false, (char) 33964, (char) 5468,
        Double.longBitsToDouble(0x3fb36494d21bc438L), Double.longBitsToDouble(0x3fd6de845d4c7d00L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\uda6d\udf01\udaf1\udc2c\ud903\udf1b\udbc7\udf9e\ud98c\udf0c\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\ud891\ude37\ud97f\ude6d\udb5e\udcc0y\udb62\udfe5\ud898\ude2b\udb67\udc4c\uda22\udcd4\ud926\ude94", "\uc7d4\u66d1\u7fd4", "\ud8f7\udd96\ub6ae\uda32\udd6e\udbff\udde2",
        44, 23577, 493371558, 1278739740173737703L, -23179L, true, true, (char) 63678, (char) 12703,
        Double.longBitsToDouble(0x3fc9f8785bae3bccL), Double.longBitsToDouble(0x3fe8e777b5e17262L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.String:PK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 3, "b\000\udb26\udff2\ud93a\udc02\ud98a\ude0e\ud9da\udc3a\ud98a\udd9b\udbd1\udf80\udb28\udcd6\uda35\udea2\ud98a\udf41\uda67\udff7G\ua8ea\u00d6\000\uda1f\uddd4\ud926\ude94", "\ud2fe", "\ud9b2\uded6\ud911\udf50\udacd\udde1\000\uc700\000\udaa7\udf81\uda18\udff2\ud824\ude20\ud8bf\udd63\uda26\udcbf\ud9a7\ude73\uda72\udf3d\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\uda1a\ude87\uda3c\udec8",
        20, 34037, -1582219253, 873006545392911853L, 29774L, false, false, (char) 14584, (char) 55324,
        Double.longBitsToDouble(0x3fba48725a7f0260L), Double.longBitsToDouble(0x3fd439f87fd67030L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.String:\ud846\udf05Z\udb41\udef2\ud94c\udc2b\ud95b\udecd\ud9d8\udc3c\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud983\udeef\uda29\udfb4\udb44\udc28\ud90b\ude5c\udaea\udff5\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:S |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 2, "\ud846\udf05Z\udb41\udef2\ud94c\udc2b\ud95b\udecd\ud9d8\udc3c\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud983\udeef\uda29\udfb4\udb44\udc28\ud90b\ude5c\udaea\udff5\000\uda22\udcd4\ud926\ude94", "\u604b\u7755\u1d17\uc435", "\000\uc700\000",
        20, 69169, 1440222481, 21474854059L, -23179L, true, true, (char) 42942, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3f8fe9add10c0a40L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.String:L\000\ud981\udce0\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\udb91\udff7\ud9a0\udddbG\u14ea\000\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:LK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "L\000\ud981\udce0\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\udb91\udff7\ud9a0\udddbG\u14ea\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud90c\udcf8\uda94\uddb7\000\uc700\000",
        7, 69169, 1440222481, 21482129067L, -23179L, true, true, (char) 42942, (char) 29885,
        Double.longBitsToDouble(0x3fc9f87857de914cL), Double.longBitsToDouble(0x3fe3904f68562c73L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.String:B\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\uda41\ude6e\ud9e9\udc51\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4\udb9e\ude16\ud821\udcd5\udac5\udffd\u00c7\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "b\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\uda41\ude6e\ud9e9\udc51\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4\udb9e\ude16\ud821\udcd5\udac5\udffd\u00c7\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud90c\udcf8\udacd\udde1\000\uc700\000\udaa7\udf81\u8b98\udbb4\uded0\ud821\ude5d\u44ab\ud8a4\udeb2\u82c0\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\uda3c\udec8",
        43, 43773, 1074468513, 873005841018275309L, 29774L, false, false, (char) 43644, (char) 25858,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd439f87fd67030L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.String:B\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9e0\udcad\ud89a\udd96\udb97\udf4f\ud86d\udc96U\udba3\udf20\uda29\udfb4G\ua8ea\000\ud8da\udca3\u1780\udaa8\ude95 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "b\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9e0\udcad\ud89a\udd96\udb97\udf4f\ud86d\udc96U\udba3\udf20\uda29\udfb4G\ua8ea\000\ud8da\udca3\u1780\udaa8\ude95", "\u604b", "\udb0b\udc7e\ud90c\udcf8\udacd\udde1\000\uc700\ud88e\udc06\ud9be\udc8d\udadd\udc14\ud824\ude20\005\u44ab\ud8a4\udeb2\uda1c\ude97\ud9a7\udfd8\ud8ac\udc5b\ud88f\ude6c\ud921\udc6a\uda3c\udec8",
        24, 43773, -1593502047, 873006545392911853L, 29774L, false, false, (char) 43644, (char) 25858,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd439f87fd70830L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.String:B\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000X\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PKKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "b\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000X\uda22\udcd4\ud926\ude94", "\u604b\u4e78\u1d17\uc435\u97f8", "\uc700\000",
        20, 69169, 1440222481, 21474854059L, -23179L, true, false, (char) 58045, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3f8fe9adcb54ca40L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.String:\udafa\udc81\udb92\udc08\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9dc\ude80\ud9b1\udfff\udbd1\udf80\udb28\udcd6R\ud97f\uddef\uda29\udfb4G\ua8ea\000\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:RK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\udafa\udc81\udb92\udc08\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9dc\ude80\ud9b1\udfff\udbd1\udf80\udb28\udcd6R\ud97f\uddef\uda29\udfb4G\ua8ea\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\udb5e\udda5\uda09\udc72\udacd\udde1\000\uc700\000\udaa7\udf81\uda3e\uddf2\ud824\ude20",
        0, 16579, -1509949440, 8353847364512960771L, -10281L, true, true, (char) 6121, (char) 64218,
        Double.longBitsToDouble(0x3fe96b569ea13ae8L), Double.longBitsToDouble(0x3fe6a5082ded0c1dL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.String:X\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\udad9\udc03\udb46\udf54\udbba\udc51\udbed\uddb0\ua8ea\000\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:S |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "X\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\udad9\udc03\udb46\udf54\udbba\udc51\udbed\uddb0\ua8ea\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud90c\udcf8\udacd\udde1\000\uc700\000\udaa7\udf81\uda18\udff2\ud824\ude20\005\u44ab\ud8a4\udeb2\u82c0\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\uda3c\udec8",
        43, 43773, -1593502047, 873006545392911853L, 29774L, false, false, (char) 43644, (char) 25858,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd439f87fd67030L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.String:I\000\u8210E\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udb9c\udd7b\udb63\ude60\udb1c\udf30\ud97f\ude51\uda29\udfb4\udb94\udf71\udac9\udd12 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "i\000\u8210e\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udb9c\udd7b\udb63\ude60\udb1c\udf30\ud97f\ude51\uda29\udfb4\udb94\udf71\udac9\udd12\000", "\u3085", "\uda46\udfa3",
        29, 7195, -1795047264, 2299168819025074098L, -7654L, true, true, (char) 42299, (char) 21772,
        Double.longBitsToDouble(0x3fc5600000000000L), Double.longBitsToDouble(0x3fef5a58010373eeL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.String:\ua271\udaa5\udd67\uda8f\udc3fM\udaf4\udd19\udbb9\ude18\ud98a\udd9b\udb9c\udd7b\udbe8\udd02\ud89f\udda4\ud97f\uddfa\ud80c\udec5\udb51\udfd7\udac9\udd12\000\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:M |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\ua271\udaa5\udd67\uda8f\udc3fM\udaf4\udd19\udbb9\ude18\ud98a\udd9b\udb9c\udd7b\udbe8\udd02\ud89f\udda4\ud97f\uddfa\ud80c\udec5\udb51\udfd7\udac9\udd12\000\000\uda22\udcd4\ud926\ude94", "\u889d\u7755\u596f\uc1d0\u97f8\u5e9b\u0c23\uc700\000\u6a13\u2183\u188a\005\u3f01\ub577\u7552\ub129\ud586\u9e8a\u9ba5\u4f3f\u36ae\ua395", "\ud91d\udf15\ud88c\udf84\uda00\udd4e",
        52, 77480, 340690465, 1575437754430574476L, 59723L, true, true, (char) 27238, (char) 44944,
        Double.longBitsToDouble(0x3fd3a0d54acac510L), Double.longBitsToDouble(0x3fe6052aaea7f4fbL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.String:\u8210E\ud95b\udecd\ud9d8\udc7d\ud98a\udd9b\udb9c\udd7b\udbe8\udd02\ud89f\uddee\ud97f\uddfa\uda29\udfb4\udb94\udf71\udac9\udd12\000H\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\000\000\u8210e\ud95b\udecd\ud9d8\udc7d\ud98a\udd9b\udb9c\udd7b\udbe8\udd02\ud89f\uddee\ud97f\uddfa\uda29\udfb4\udb94\udf71\udac9\udd12\000h\uda22\udcd4\ud926\ude94", "\u5f02", "\udb52\ude51\u37f6\udacd\udde1\000\uf90f\000\udaa7\udf81\uda18\udff2\udb39\udc13\005\u44ab\ud8a4\udeb2\u82c0\ud8e2\udc39\ud8ab\udffa\ud88f\uddfc\ud921\udc6a\ud8cd\udc6b",
        33, 55857, -1593502047, 873006546874530330L, -72592L, true, true, (char) 17767, (char) 53096,
        Double.longBitsToDouble(0x3fd439f87fd67030L), Double.longBitsToDouble(0x3fd2130967a0d8d0L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.String:O\000\ud8f8\udfb3\ucba5 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "o\000\ud8f8\udfb3\ucba5", "\u2b9b\u3b00\u2b69\u5912\u3fbf\uca12\u8db9\u7d46\000\000\u386b\u3085\000\u5604\u4db3\u88b2\u596f\uc1d0\u97f8\u5e9b\000\u0c01\000\u7e13", "\005\u44ab\ud8a4\udeb2\udbee\udcbf\ud8e2\udc39\ud8ab\udffa\ud88f\uddfc\ud921\udc6a",
        52, 81268, 986725857, -6844039177770792236L, -21765L, false, false, (char) 49186, (char) 27066,
        Double.longBitsToDouble(0x3fee69c0e3330b07L), Double.longBitsToDouble(0x3fcf28435b6879a0L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 13, "\u00cd\u61f8\ud811\uded2e\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbaf\udd7b\udbe8\udd02\ud89f\udda4\ud97f\uddfa\uda29\udfb4\udb5b\udf7c\udae1\uddcf\uda81\ude3b\u98ac\uda22\udcd4\uda51\udda8", "\u604b", "\udb52\ude51\ud90c\udcf8\uda95\udfe1\000\uc700\000\udaa7\udf81\uda18\udff2\udacb\udeda",
        0, 16579, -1509949440, 8353847364865282307L, 18828L, true, false, (char) 11461, (char) 52754,
        Double.longBitsToDouble(0x3fde17262d4275a0L), Double.longBitsToDouble(0x3fe6a50828ed0c1dL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KP |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 4, 15, 11, "\ud9e9\udc82W\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\udb71\udefa\ud99d\udcc9\uda62\ude77G\ua8eap\uda53\udf4f\udb17\udf14\ud91a\udfdb", "\u5bf0\u8a2a\u3f25\uc435\u97f8\u5e9b\u2b4d", "\udb54\udf80",
        12, 62481, 5, 75499720146944L, -46493L, false, false, (char) 29885, (char) 26769,
        Double.longBitsToDouble(0x3feb8fca991ceef6L), Double.longBitsToDouble(0x3fea54e91ea13ad0L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.String:KP |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KP |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\ud9d9\udd59\000\udb26\udff2&\ud95b\udecd\udad1\ude3b\ud98a\udd9b\udbd1\udf80\uda45\ude24\ud9ea\udd03\ud907\udec8\u79d3G\ua8eap\uda53\udf4f\udb17\udf14", "\u2be8\u5bf0\u8a2a", "\ud90c\udcf8\udacd\udde1\udb1b\udcb1\uda3e\udcaa\u3e88\uda97\ude67\uda2d\ude6a\u1e7d\005\udbbc\udf40\ud8bb\udf39",
        59, 45707, -751515106, -4340729481161104177L, -96308L, false, true, (char) 20849, (char) 5916,
        Double.longBitsToDouble(0x3fed8f27578f4cfdL), Double.longBitsToDouble(0x3fc8026faef5b710L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:FK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 4, 15, 11, "\ud981\uddce\ud860\udf1b\uda93\udd6bf\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\udb71\udefa\ud99d\udcc9\uda62\ude77G\ua8ea\u5e70\uda53\udf4f\ud9fa\udcc6\ud91a\udfdb", "\u5bf0\u8a2a\u3f25\uc435\u97f8\u5e9b\u2b4d", "\udb56\ude80",
        12, 62481, 5, 75499720146944L, -46493L, false, false, (char) 29885, (char) 26769,
        Double.longBitsToDouble(0x3feb8fca991ceef6L), Double.longBitsToDouble(0x3fea54e91ea13ad0L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.String:KKK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KKK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "k\000\udb26\udff2&\ud95b\udecd\ud9ee\udeb2\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\ua8ea\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud8a8\udc65\udac5\udffc\ud887\udf8a\uc717\000\udaa7\udf81\uda18\udff2",
        56, -995, 17579, 6989586621791369524L, -76655L, true, true, (char) 52754, (char) 45123,
        Double.longBitsToDouble(0x3fe509d682c6a105L), Double.longBitsToDouble(0x3fded0ce83bbc178L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.String:K\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\udb28\uddd0\ud8e8\udd34\u00d1\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KKKN |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "k\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\udb28\uddd0\ud8e8\udd34\u00d1\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud8a8\udc65\udac5\udffc\ud87e\udd47\uc717\000\udaa7\udf81\uda18\udff2",
        56, -995, 17579, -6485183462575778837L, -76655L, true, true, (char) 52754, (char) 45123,
        Double.longBitsToDouble(0x3fe509d682d4a105L), Double.longBitsToDouble(0x3fded0c1d3bbc178L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.String:H\u1884\udb26\udff2&\ud817\uddeb\ud9d8\udc3e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\ua8ea |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 3, "H\u1884\udb26\udff2&\ud817\uddeb\ud9d8\udc3e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\ua8ea", "", "\u5ea9\udbc7\udd0c\uda46\udfa3\u7b49\uf15b\udb0b\udc7e\ud8a8\udc65\ud976\udfca\udb63\udede",
        2, 77568, 501327360, 6140708211333270801L, -82421L, false, false, (char) 31211, (char) 29722,
        Double.longBitsToDouble(0x3fe0f6ee5989d334L), Double.longBitsToDouble(0x3fc9f8784dc7e54cL)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.String:KKKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 14, "k\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\ua8ea\ud82c\udfd6s\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud8a8\udc65\udac5\udffc\ud87e\udd47\uc717\udad1\udde7\uda90\udd40\uda18\udff2",
        53, 9930, 17579, -6451509819463511061L, -76655L, false, true, (char) 23016, (char) 45123,
        Double.longBitsToDouble(0x3fed09d68228cc70L), Double.longBitsToDouble(0x3fded0c1d3bbc178L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.String:TK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:TK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "\000\u29ec\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udbea\udd78T\ud97f\uddef\uda29\udfb4G\udae6\udc07\ud913\udc6b\udb3a\ude07\u7633\ud926\ude94", "\u604b", "\udbf4\udee1\udb38\udc5e\u257d\uda61\udc5f\uc7b1\000\udaa8\udc09\uda18\udff2\ud824\ude20\005\udbeb\udc53\udb57\ude6f\u8201\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\udbd1\udd6f",
        33, 55857, -1593502047, 873006545392911853L, 29774L, false, false, (char) 15780, (char) 25951,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd432387fd67030L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\udb16\udc40\udbaf\uddbd\udb85\ude7c\ud9a6\uddff\u7373\ud9d7\udf96\ud98a\udd9b\udbb3\udfa3\ud84e\udd89\ud89d\udfa8\ud9cc\udd79\udb84\udef3w", "\u30be\u12c8\u80ea\u6a10\u10f2\uc7ef\u5d4a\u1a8d\uc463\u1e30\ucce7", "\udac4\udfa5\udaa8\udc1b\uda18\udff2\udb69\udc02\udba7\udd45\udb3b\udd3f\ud8f2\udf24\uda83\udd11\udbb9\udd45\ud918\ude1e\ud842\udcd4\ud96f\ude16\udbe6\udcd6\u3667\udacc\ude65\ud98c\ude5d\udbf7\uddfe\ud8fd\ude3f\ud9b6\udf87\udbf4\udd86\uda8a\udf04\uda96\uddbc\ud87d\udce2\ud8be\udcab\uda04\udc00\ud9c5\udc94\ud8fb\ude98",
        35, 99821, 2051156379, -4748354163376881511L, 54609L, true, false, (char) 40243, (char) 37419,
        Double.longBitsToDouble(0x3fd5169f9d1f4894L), Double.longBitsToDouble(0x3fe6e5b01636b587L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.String:\ud846\udf05D\udb41\udef2\ud94c\udc2b\ud95b\udecd\ud9d8\udc3c\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud983\udeef\ud9f7\udfbb\udb44\udc28\udb06\udc5a\udaea\udff5\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:T |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 2, "\ud846\udf05d\udb41\udef2\ud94c\udc2b\ud95b\udecd\ud9d8\udc3c\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud983\udeef\ud9f7\udfbb\udb44\udc28\udb06\udc5a\udaea\udff5\000\uda22\udcd4\ud926\ude94", "\u613a\u7755\ub962\uc435", "\ud8a8\udcd3\uc70c\000",
        20, 69169, 1440222481, 21474854059L, -23179L, true, true, (char) 20733, (char) 18745,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3f8fe9add10c0a40L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.String:L\000\ud989\udee0\ud9d7\udf50\ud80d\udcb3\ud89f\ude9d\ud98a\udd9b\ud99d\udd43\udbeb\udcccA\udb91\udff7\ud9a0\udddbG\u14ea\000\000\uda2b\udf62\ud96d\udf12 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:LK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "L\000\ud989\udee0\ud9d7\udf50\ud80d\udcb3\ud89f\ude9d\ud98a\udd9b\ud99d\udd43\udbeb\udcccA\udb91\udff7\ud9a0\udddbG\u14ea\000\000\uda2b\udf62\ud96d\udf12", "\u604b", "\udb0b\udc7e\uda7e\udcb0\uda94\uddb7\000\ud9a6\udc24\ua208",
        24, 62038, 1440222481, 21482129067L, -23179L, true, true, (char) 42942, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784a4e37b4L), Double.longBitsToDouble(0x3fca0fa7a158b1ccL)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.String:L\000\ud981\udce0\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\udb91\udff7\ud9a0\udddbV\u14ea\000\000\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:LF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "L\000\ud981\udce0\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\udb91\udff7\ud9a0\udddbv\u14ea\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud90c\udcf8\uda94\uddb7\000\uc700\000",
        7, 69169, 1440222481, 21482129067L, -23179L, true, true, (char) 42942, (char) 29885,
        Double.longBitsToDouble(0x3fc9f87857dc1690L), Double.longBitsToDouble(0x3fe3904f68562c73L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.String:PK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "b\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\udb1f\udcab\ud89a\udd96\udb97\udf4f\ud86d\udc96U\udba3\udf20\udbe6\uddc1G\ua8ea\uda32\udc44\ud8da\udca3\uda7c\udc0d\udaa8\udf12", "\u604b\u7755", "\uda41\uddda\udacd\udde1\uda8b\udc64\uc7c2",
        50, 7192, -557441526, 6185708454858981381L, 25982L, true, false, (char) 58235, (char) 43167,
        Double.longBitsToDouble(0x3fd1cd81699f8784L), Double.longBitsToDouble(0x3feb8fca983df4d6L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 11, "b\000\udb26\udff2\ud94c\udc05\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000X\uda22\udcd4\ud926\ude94", "\u604b\u4e78\u1d17\uc435\u97f8", "\uc700\000",
        20, 69169, 1440222481, 21474854059L, -23179L, true, false, (char) 58045, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3f8fe9adcb54ca40L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.String:PKKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PKKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "b\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000X\uda22\udcd4\ud926\udec3", "\u604b\u4e78\ub405\u1b7a\u97d3", "\uc700\000",
        20, 69169, 1440222481, 21474854059L, -23000L, true, false, (char) 58045, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3f8fe9adcb54ca40L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.String:B\000\udb26\udff2\ud8df\udd15\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000X |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PKKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 8, "b\000\udb26\udff2\ud8df\udd15\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000X", "\u75df\u56ae\u604b\u4e78\u1d17\uc435\u97f8\u5e9b\000", "\udaa7\udf81",
        14, 62481, 5, 262124639092736L, 17903L, true, false, (char) 2646, (char) 3387,
        Double.longBitsToDouble(0x3fd22f8cb2e7a120L), Double.longBitsToDouble(0x3fddd74be260a648L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.String:R |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:R |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "R", "\ub891", "\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000X\uda22\udcd4\ud926\ude94\udaf6\udead\udbc7\uddb6\uda46\udfa3\ud83a\udf7b\uf1e4\udb0b\udc7e\ud90c\udcf8\udacd\udde1\uac12\uc700\000\ud84d\udc35",
        49, 62557, 5, 75499720146944L, -10281L, true, false, (char) 11461, (char) 34021,
        Double.longBitsToDouble(0x3fe96a994e39d18eL), Double.longBitsToDouble(0x3fe5bbef67f036cbL)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.String:B\000\ud991\udcc7\udace\uddbb\ud95b\udf97\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8eaQX\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PKKK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 6, "b\000\ud991\udcc7\udace\uddbb\ud95b\udf97\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8eaQX\uda22\udcd4\ud926\ude94", "\u604b\u4e78\u1d17\uc435\u97f8", "\uc700\000",
        54, 69169, 1440222481, 2481060102895467560L, 85145L, true, false, (char) 58045, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3f8fe9adcb54ca40L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:S |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "X\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\ud853\ude21\ud9ec\udd04\udbb9\udfe0\udbed\uddb0\ua8ea\000\000\ud8a2\udf15\ud95a\uddd6", "\u5213", "\ud9d9\uddd6\ud813\udcf7\udaf5\udee0\000\uc700\000\udaa7\udf81\uda18\udff2\udbe4\udc7f\ud960\udcea\u44ab\ud8a4\udeb2\u82c0\ud9a7\udefc\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\uda3c\udec8",
        3, 60137, -1593502047, 873006545392911853L, 29774L, false, false, (char) 43644, (char) 25858,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd439f874667030L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\ud98d\udc63\u6b24\u8210e\ud95b\udecd\ud9d8\udc7d\udb46\udc5a\udb9c\udd7b\udbe8\udd02\ud89f\uddee\ud97f\uddfa\uda29\udfb4\udb6a\udf80\udac9\udd1c\000h\udb73\udcbb\ud9f8\udc17", "\u5f02\u7755", "\u37f6\udacd\udde1\000\uf90f\000\uda91\udea4\uda18\udff2\udb39\udc13",
        0, 16579, -1509949440, 8353847365917826246L, -10281L, true, false, (char) 22213, (char) 30698,
        Double.longBitsToDouble(0x3fde2dc55d4275a0L), Double.longBitsToDouble(0x3fe6a5082a1a0c1dL)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\udb16\uddf9O\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\udb71\udefa\ud99d\udcc9\uda62\ude77G\udba9\udc99\u0083\uda53\udf4f\udb17\udf14\ud91a\udfdb", "\u5bf0\u8a2a\u3f25\uc435\u97f8\u5e9b\u2b4d", "\udb54\udf80",
        12, 62481, 5, 75499720146944L, -46493L, false, false, (char) 29885, (char) 26769,
        Double.longBitsToDouble(0x3feb8fca991ceef6L), Double.longBitsToDouble(0x3fea54e91ea13ad0L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.String:FP |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:FP |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\ud9e9\udc82F\udac2\udf32&\ud95b\udecd\ud9d8\udc1e\ud955\udc41\ud936\udf94\ud92d\ude99\udad2\udc85\ud991\udcd8\uda04\ude68\udb29\udccb\ua8eap\uda53\udf4f\udb17\udf14\ud957\uddba", "\u1e15\uc62b\uc40a\uc396\u241f\ucb38\u6200", "\udb54\udf80",
        39, 62481, 5, 75499720146944L, -46493L, false, false, (char) 29885, (char) 26769,
        Double.longBitsToDouble(0x3feb8fca991ceef6L), Double.longBitsToDouble(0x3fea54e91ea13ad0L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 4, 4, 9, "\ud981\uddce\ud860\udf1b\uda93\udd6bf\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\udb71\udefa\ud99d\udcc9\uda62\ude77G\ua8ea\u5e70\uda53\udf4f\ud9fa\udcc6\ud91a\udfdb", "\u5bf0\u8a2a\u3f25\uc435\u97f8\uc531\uab77", "\udb56\ude80\uda1a\ude39\ud824\ude20",
        0, 16579, -1509949440, 8353847364512960771L, -10281L, true, false, (char) 11461, (char) 57362,
        Double.longBitsToDouble(0x3fea54e91ea187d0L), Double.longBitsToDouble(0x3fd477edb9ae7c04L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.String:W\000\udb71\ude17\ud8fc\ude63\ud986\uddfc\udab2\udfcb\udb23\ude17\udbd1\udf80\ud8bb\udeffC\ud97f\uddef\udac1\udfc0G\udb52\uddd0\u96d5\ud8ba\udcb7\ud9f5\udf94\ud8ab\ude96\u00dd\udbde\udc77\udb3c\ude6a |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "W\000\udb71\ude17\ud8fc\ude63\ud986\uddfc\udab2\udfcb\udb23\ude17\udbd1\udf80\ud8bb\udeffC\ud97f\uddef\udac1\udfc0G\udb52\uddd0\u96d5\ud8ba\udcb7\ud9f5\udf94\ud8ab\ude96\u00fd\udbde\udc77\udb3c\ude6a", "\u07dc\u900a\u0971\u2939\uc717\u15ee\u7e8b\u1dd7\u22cf\ub0c4\u55c8\ub554\u3f19\u61a1\u0f1a\u6660\u1ef9\u9f25\u36ae\ua395\uae0e\u2f2d\u7104\u0bc1\ud5f4\u530f", "\ud9c1\ude09\uda0a\udc97",
        -2, 33207, 772627785, 1089876597539913849L, 81184L, true, true, (char) 26179, (char) 45865,
        Double.longBitsToDouble(0x3fc579c1aa04a578L), Double.longBitsToDouble(0x3fe737cde830b2f4L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.String:\udbf3\udee3\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\udb28\uddd0\udaae\udef8SS\uda22\udcd4\ud926\ude94 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 11, "\udbf3\udee3\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\udb28\uddd0\udaae\udef8\u00df\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud8a8\udc65\udac5\udffc\ud87e\udd47\uc717\000\udaa7\udf81\uda18\udff2",
        56, -995, 17579, -6485183462016625685L, -76655L, false, true, (char) 52754, (char) 45123,
        Double.longBitsToDouble(0x3fe509d682d4a105L), Double.longBitsToDouble(0x3fded0c1d3bbc178L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 3, "H\u1884\udb26\udff2&\ud817\uddeb\ud9d8\udc3e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\uda29\udfb4G\ua8ea", "", "\u5ea9\udbc7\udd0c\uda46\udfa3\u7b49\uf15b\udb0b\udc7e\ud8a8\udc65\ud976\udfca\udb63\udede",
        38, 98506, -840849920, 6188849189789109521L, -82421L, false, false, (char) 31211, (char) 29722,
        Double.longBitsToDouble(0x3fe0f6ee597ad334L), Double.longBitsToDouble(0x3fc9f878416be54cL)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.String:KKSS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 14, "k\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\udb84\ude18z\ua8ea\ud82c\udfd6s\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\ud8a8\udc65\udac5\udffc\ud87e\udd47\uc717\udad1\udde7\uda90\udd40\uda18\udff2",
        53, 9930, 17579, -6451509819463511061L, -76655L, false, true, (char) 23016, (char) 45123,
        Double.longBitsToDouble(0x3fed09d68228cc70L), Double.longBitsToDouble(0x3fded0c1d3bbc178L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 15, 14, "S\ud809\udca4\ud803\udc20", "\u010f\u0d7d\u0cbf\u0dc7\u3ff9\ucb37\u2c17\u3432\ubf29\u6d54s\uce6a\u3085\uc5af\ub26b\u6088\u92ac\u1c8e\u1cce\u981a", "\uc717\ud808\udc03\ud83f\udeb3\ud8ce\udddc\udbac\udc4c\ud842\udcc7\ud980\udd63\ud84b\ude34\ud8f9\udc0f\udbc8\udc27\u29ca\ud88f\udd7b\ud92a\udf0f\ud81c\ude1a\udab8\uddc9\ud90c\udeff\ud862\udc97\udb54\udf48\uda94\ude52\ud8e8\uddf6\ud93a\udfa0\ud855\udded\u0665\udb4d\udd31\ud80f\uddd7",
        13, 95221, 1502918575, 7863936209542926756L, -82286L, true, true, (char) 56546, (char) 10091,
        Double.longBitsToDouble(0x3fef5981e45cd1afL), Double.longBitsToDouble(0x3fe252de169d25a3L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.String:KKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 14, "k\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\uda34\udc0a\udb14\udda7\ud899\uddc5\udba3\udffa\ud848\udf44\uda60\udf97G\ua8ea\ud82c\udfd6s", "\000\u5604\u604b\u1a89\u1c8e\uc435\u9d4e\u1fcc\ud370", "\uda90\udd40",
        14, 8473, 10930, 75203375243776L, -10281L, true, false, (char) 1510, (char) 23016,
        Double.longBitsToDouble(0x3fde1726274275a0L), Double.longBitsToDouble(0x3fe1466385ed0c1dL)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "g\u29ec\udb26\udff2\u6e26\ud96f\udc17\ud9d8\udc1e\ud98a\udd9b\u157b\uda3c\udf14\u0081\ud97f\uddef\uda29\udfb4G\udae6\udc07\ud909\uddc6\udbd7\udd10\u7633\ud926\ude94", "\u604b", "\ud93f\udfbb\ud88c\udf04\u257d\u05ef\ud921\udcc6\000\udaa8\udc09\uda18\udff2\ud8a3\udc3f\ud8f1\ude02\udbeb\udc53\udb57\ude6f\udb86\udc5b\ud9a7\udf7d\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a\udbd1\udd6f",
        33, 55857, -1593502047, 3684728258479066884L, 32370L, false, false, (char) 15780, (char) 25951,
        Double.longBitsToDouble(0x3fb28c474c60aee8L), Double.longBitsToDouble(0x3fd432387fd67030L)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.lang.String:T |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:T |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 2, "\ud846\udf05d\ud99a\udeff\ud94c\udc2b\ud95b\udecd\ud8a4\udd35\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud983\udeef\ud9f7\udfbb\udb44\udc28\udb06\udc5a\udaea\udff5\000\uda22\udcd4\ud926\ude94", "\u613a\ua3b2\u54a3\u408a", "\ud8a8\udcd3\uc70c\000",
        -2, 77708, 126676819, -2658373902999466303L, 4951L, true, true, (char) 20733, (char) 18745,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3fd0ff4d6e886052L)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.String:LK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:LK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "L\000\ud989\udee0\ud9d7\udf50\ud80d\udcb3\ud89f\ude9d\ud98a\udd9b\ud99d\udd43\udbeb\udccc\ud816\udf2b\ud846\udee7\ud9a0\udddbG\u14ea\000\000\ud8bc\udd86\ud82b\udec3", "\u604b\u7565", "\uda7e\udcb0\uda94\uddb7\000\ud9a6\udc24\ud87c\udd71\ud861\udc4c\uda12\udc17\ud824\ude20\ud926\udef7\uda1f\udeb1\ud8a4\udeb2\u82c0\uda62\ude75\ud8ab\udf7a\ud88f\uddfc\ud616\ud9c0\uddf4",
        43, 14342, 1592109997, -8156647696620971546L, 58821L, false, false, (char) 33687, (char) 38581,
        Double.longBitsToDouble(0x3fd580086d4453ceL), Double.longBitsToDouble(0x3fdcaa5d0b168540L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=java.lang.String:PS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "b\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\udb1f\udcab\uda80\udd0a\udb97\udee1\uda5a\uddc1s\udba3\udf20\udbd8\udfbb\udad9\udd55\ua824\uda32\udc44\ud8da\udca3\uda7c\udc0d\udaa8\udf12", "\u604b\u7755", "\uda41\uddda\udacd\udde1\udb47\udfde\uc7c2",
        50, 7192, -557441526, 6185708454858981381L, 25982L, true, false, (char) 58235, (char) 43167,
        Double.longBitsToDouble(0x3fd1cd81699f8784L), Double.longBitsToDouble(0x3feb8fca983df4d6L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 0, "b\000\udb26\udff2\ud94c\udc05\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\000X\uda22\udcd4\ud926\ude94", "\u604b\u4e78\u1d17\uc435\u97f8", "\uc700\000",
        20, 69169, 1440222481, 21474854059L, -23179L, true, false, (char) 58045, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3f8fe9adcb54ca40L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=java.lang.String:PF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PF |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "b\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\udaff\udd1eV\ua8ea\000\ud982\udc58\uda22\udcd4\uda8e\udfd6", "\u3554\u4e26\ub405\u1b7a\u97d3", "\ud848\udc6a\u00b0",
        20, 69169, 1440222481, 21474854059L, -23000L, true, false, (char) 58045, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e79cL), Double.longBitsToDouble(0x3f8fe9adcb54ca40L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=java.lang.String:SS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:SS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "X\000\udb26\udff2\ud94c\udc2b\ud95b\udecd\ud974\ude11\ud9ab\udc73\ud932\udde6\uda4f\udf5b\ud853\ude21\ud9ec\udd04\udbb9\udfe0\udbed\uddb0\ua8ea\000Z\ud8a2\udf15\ud95a\uddd6", "\u5213", "\udabf\udea9\ud82d\udf90\udbd2\udfb2\udb1d\udc72\uda26\udef2b\udaa7\udf81\uda18\udff2\udbe4\udc7f\ud960\udcea\u44ab\ud8a4\udeb2\u82c0\ud9a7\udefc\ud9af\udc3c\ud88f\uddfc\ud921\udc6a\uda3c\udec8",
        49, 74461, -1581798874, 873006545392911853L, 29785L, false, false, (char) 44502, (char) 25866,
        Double.longBitsToDouble(0x3fb28c474c6206e8L), Double.longBitsToDouble(0x3fd439f874667030L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 3, "H\u1884\udb47\udd09&\ud817\uddeb\ud9d8\udc3e\ud98a\udd9b\udbd1\udf80\udb89\udf06W\ud97f\uddef\uda29\udfb4G\ua8ea", "", "\u5ea9\udbc7\udd0c\uda46\udfa3\u7b49\uf15b\udb0b\udc7e\ud8a8\udc65\ud976\udfca\udb63\udede",
        38, 98506, -840849920, 6188849188588168721L, -82421L, false, false, (char) 31211, (char) 29722,
        Double.longBitsToDouble(0x3fe0f6ee597ad334L), Double.longBitsToDouble(0x3fc9f878416be54cL)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=java.lang.String:KKR |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KKR |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "g\u29ec\udb26\udff2\u6e26\ud96f\udc17\ud9d8\udc1e\ud97b\ude9b\u157b\uda3c\udf14\u0081\ud97f\uddef\uda29\udfb4G\udae6\udc07r\udbd7\udca3\u7633\ud926\ude94", "\000", "\ud93f\udfbb",
        40, 3, 1294401536, -3098257401514557440L, 9071L, true, true, (char) 9592, (char) 55750,
        Double.longBitsToDouble(0x3fd45ab27c9d9fdeL), Double.longBitsToDouble(0x3fd849b1b43dbb40L)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=java.lang.String:KR |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KR |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "g\u29ec\udb26\udff2\u6e26\ud96f\udc17\ud963\udca4\ud97b\uddfc\ud886\udfba\uda24\udd52\u0081\u0931\000\udafc\udf3d\udae6\udc07r\000\000\000", "\000", "\ud93f\udfbb",
        40, 3, 1294401536, -3098257401514557440L, -100000L, false, false, (char) 27780, (char) 42942,
        Double.longBitsToDouble(0x3fd2ad58a8ac1e86L), Double.longBitsToDouble(0x3fe6b9c9ade2d192L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708 |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 9, 10, "\ud905\udf98\uda2d\udca0\ud903\udf1b\ud8a0\udd81\uda27\uddfd\udbba\udd81\ud92b\uded5\ud813\udcec\udb89\udf06\ub708", "\u6fe4\u55ec\u4522\u210b\u10ea", "\uc9e4\udb1e\udf5a\uda6f\udce1\uf1e4\udb0b\udc7e\ud90c\udcf8",
        47, 85031, -141065746, -5127647695753181863L, 70440L, true, false, (char) 50853, (char) 24417,
        Double.longBitsToDouble(0x3fe68463316b0b93L), Double.longBitsToDouble(0x3fda7bcc87e903caL)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "\ud905\udff7\uda2d\udca0\ud903\udf1b\udb59\udc1d\u33ce\uda0a\udfca\ud93e\udf7d\ud813\udcec\udb89\ude8d\udba7\udd4e\udad0\udd47\ud971\ude30\udad8\udcce\uda05\udf4d\ud8bc\udd0c\udb67\udc4c\udb6e\udcda\ud926\ude94\ud895\udf67\udb0e\udd98\udb1e\udf39\uda53\udf7d\uf1e4\udb0b\udc7e\ud90c\udcf8\ud85b\udc13\ud934\ude32\ud864\udc90\ud98d\ude65\ud84d\udfac\udbf3\udc88\ud93d\ude1d\u6374\ud93d\ude0c\ud9aa\udda3\uda88\udf7e\udbc9\udd74\uda1e\udf38\ud878\udc70\ud858\udf34\udad6\udf6b\uda19\udfb6\udab5\udd0a\uda8b\ude66\ud97b\udf0d\uda01\udef0\ud9ca\udda5\udb7e\udcd2\udb04\uddae\uda7f\ude65\udab3\udcfb\uda5c\udedd\udb86\udf6e\udba2\udf1c\ud927\udf51\udb8f\udddf\ud8b6\udf85\udb92\udeff\udb98\udf3e\udbc0\ude65\ud9b4\ude1d\ud8fa\ude53\ud9a1\udfd7\ud9bf\udf3f\ud8f4\udf34\ud91f\udc0e\uda0d\udff8\uda6a\udc0b\udaf1\udda9\ud980\udf10\uda6f\udfeb\ud80f\udc9a\udb94\udf2a\ud871\udee6", "\u8516\u85ba\u5c5f\u4e34\u47d1\ua38e\u76c3\u7f8e\u6644\u57a1\u584a\u56aa\u31c7\u3b8e\u0bfb\u9b88", "\ud8af\udf2a\udb1d\udda7\udb0c\udef6\ud826\udcf0\uda26\udf80\uda60\udcf2",
        59, 65826, 1417596799, 4206845119919316091L, -69072L, false, true, (char) 169, (char) 18866,
        Double.longBitsToDouble(0x3fe92bf28d3cbdd3L), Double.longBitsToDouble(0x3fecc5a8b06ab6adL)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\udb4a\udf90\uda2d\udc7c\udbd9\udc86\udbc7\udfbb\ud98c\udf0c\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06\udab2\udd0f\ud97e\udfc2\udb5e\udcc0J\udb62\udfe5\ud898\ude2b\udb67\udc4c\uda22\udcd4\ud926\ude94", "\u78c5\u9d55\u1d17", "\uda3c\ude94\ub62c\ud8fa\udd72\udac4\udfa5",
        44, 46121, -481356186, -5762411776819903317L, -23179L, true, true, (char) 42942, (char) 29885,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3fe8e777b6e17262L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=java.lang.String:\udb4a\udf90\uda2d\udc7c\ud903\udef8\udbc7\udf9e\ud98c\udf0c\u349a\ud97b\uddfc\udbd1\udf80\udb89\ude29C\ud97f\uddbe\udb5e\udcc0J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KJ |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 0, "\udb4a\udf90\uda2d\udc7c\ud903\udef8\udbc7\udf9e\ud98c\udf0c\u349a\ud97b\uddfc\udbd1\udf80\udb89\ude29C\ud97f\uddbe\udb5e\udcc0J", "\u1338\000\000\000\000\000\ub684\ua4b4\u3a35\u97f8\026", "\ud93a\udc3c\udaa8\udc1b\uda18\udff2\ud824\ude20\ud9c8\ude4f\udbb3\udcbb\ud8f2\udf0e\u12b2\ud9ec\udcb8\ud9ca\udf30\uda98\udfdb\udba8\ude4e\ud98a\ude40\udb4b\udff1\uda23\udf9a\ud95d\udd79\uda7a\udf5e\udacd\udf59\udaa0\udfd4\udb36\udc8c\ud88c\udc6f\uda30\udcb9\ud9a6\udcd9\ud9d0\udc88\udb1c\udfb6\udb13\udfef\ud87b\udd94",
        22, 9905, -1919037243, 4155623416915049504L, 50089L, false, false, (char) 38609, (char) 59093,
        Double.longBitsToDouble(0x3fdecc588a0b71dcL), Double.longBitsToDouble(0x3fd1e3b65732de5cL)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 5, 13, "\uda62\udedd", "\u526d\u3c29\u2b70\u2c02\ud225\u263e\u9aab", "\u00c2\udbb0\udfed\u77a1\ud867\udf75\uda22\udcd4\ud926\ude94\ud9cc\udd4c\udba0\ude7a\ud9b7\udec3\ud913\udcbc\udad0\uddb7\udaf2\udefd\uda8a\ude18",
        0, 79921, -1913466705, 1799877694697782020L, -39870L, false, true, (char) 12324, (char) 24768,
        Double.longBitsToDouble(0x3fef5f73590373eeL), Double.longBitsToDouble(0x3fe8f6ed016f9030L)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "i\000\u8210\udb09\udf51\ud8f4\udec5\udaba\ude33\ud98a\udd9b\udb9c\udd7b\udb63\ude60\udb1c\udf30\uda72\udfea\uda67\udf40\udb94\udf71\udac9\udd12\uda54\udc09", "\ubd04", "\uda46\udfa3",
        29, 73987, 1760356804, -883192589130082558L, -7654L, true, true, (char) 42299, (char) 21772,
        Double.longBitsToDouble(0x3fc5600000000000L), Double.longBitsToDouble(0x3fef5a58010373eeL)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 8, 15, 11, "\000\000\u8210\udbf2\udf9e\udbdd\udd2d\ud9d7\udf92\ud98a\udd9b\udb9c\udd7b\udbe8\udd02\ud89f\uddee\ud97f\uddfa\ud953\udf65\ud98b\udfd2\ud969\udd2aYh\ud912\udf6c\ud8e5\udf06", "\u04d0", "\udb52\ude51\u37f6\udacd\udde1\000\uf90f\000\udaa7\udf81\uda18\udff2\udb39\udc13\005\u44ab\ud8a4\udeb2\ud92a\udcbf\ud8e2\udc39\ud8ab\udffa\ud89e\ude75\ud806\udcf0\ud899\udefa",
        33, 55857, -1185147231, 872857441910546970L, -72592L, true, true, (char) 34151, (char) 32911,
        Double.longBitsToDouble(0x3fd439f87fd67030L), Double.longBitsToDouble(0x3fd2130967a0d8d0L)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=java.lang.String:KKN |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KKN |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "k\000\udb26\udff2&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\udb59\udf25\uda38\udf97\udb3d\ude4c\ud902\uddd5\ud8e8\udd34\u00d1\ud87e\udf62\ud926\uded3", "\u604b\u8a5e\u24ea", "\ud8f6\ude07\ud87e\udd47\uc717\000",
        50, 69169, 1440222481, 21474854059L, 52726L, true, true, (char) 2826, (char) 47704,
        Double.longBitsToDouble(0x3fc9f8784dc7e54cL), Double.longBitsToDouble(0x3fe8e777b5e17262L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 15, 7, 14, "C", "\u0ce3", "\ud999\udffc\udbd1\udf80\udb89\udf06\ud812\udf8c\ud968\udfe3\uda29\udfb4G\ua8ea\ud8f8\ude58\u9a20\uda22\udcd4\ud926\ude94\000",
        45, 78016, -1441202087, -2354446613273670966L, 48003L, false, true, (char) 38220, (char) 39248,
        Double.longBitsToDouble(0x3fe9c04962bb7039L), Double.longBitsToDouble(0x3fd193413435fc9eL)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=java.lang.String:L |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:L |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "L\000\ud989\udee0\ud9d7\udf50\ud80d\udcb3\ud89f\ude9d\ud98a\udd9b\ud92b\udfea\udb0d\udc2aA\udb91\udff7\ud9a0\udddb\udabe\udd08\u4234\000\000\uda2b\udf62\ud96d\udf2f", "\u604b", "\udb0b\udc7e\uda7e\udcb0\uda94\uddb7\000\ud9a6\udc24\ua208\ud860\udf7e\uda12\udc17\ud824\ude20\uda1c\udf64\ud87e\ude92\ud8a4\udeb2\u82c0\ud9b0\udcfc",
        4, 51161, -1281252145, -3071689811112544048L, -43923L, false, true, (char) 63659, (char) 15003,
        Double.longBitsToDouble(0x3fd82ae959b2468cL), Double.longBitsToDouble(0x3fd80748d7426bbcL)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=java.lang.String:PKKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PKKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "b\000\udb26\udff2\ud8df\udd15\ud95e\udfac\uda0c\ude5f\ud99a\udcba\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\ua8ea\u0680X", "\u75df\u921b\u604b\u4e78\u1d17\uc435\u97f8\u5e9b\uca81", "\u41ac",
        14, 62481, 5, 1023572927990190892L, 17903L, true, false, (char) 2751, (char) 3387,
        Double.longBitsToDouble(0x3fd22f8cb2e7a120L), Double.longBitsToDouble(0x3fddd74be260a648L)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 15, 0, "j", "\ub891", "\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4\ud89a\uddf3\ud9a1\udeb2\udad3\udf5e\uda62\uddc5\uda22\udcd4\ud926\ude94\udaf6\udead\ud890\udc9a\ud9c9\udced\ud830\udf77\u9641\uda60\udc87\uda05\uddf5\udacd\uddba\ud84b\uddb8\uc700\udbe2\udf91\ud801\udc7c",
        17, 85437, 48645, -7948214892635356991L, 51159L, true, false, (char) 11613, (char) 34021,
        Double.longBitsToDouble(0x3fe10d414e39d154L), Double.longBitsToDouble(0x3fe5bbef67f036cbL)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 5, 5, 13, "\uda62\udedd", "\u2f0f\u00a3\u2b7a\u2c02\ud225\u263e\u9aab", "\u00c2\udbb0\udfed\u77a1\ud867\udf75\uda22\udcd4\ud926\ude94\ud9cc\udd4c\udba0\ude7a\ud9b7\udec3\ud913\udcbc\udad0\uddb7\udaf2\udefd\uda8a\ude18",
        0, 79921, -1913466705, 1799877694697782020L, -39870L, false, true, (char) 12324, (char) 24768,
        Double.longBitsToDouble(0x3fef5f73590373eeL), Double.longBitsToDouble(0x3fe8f6ed016f9030L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 6, "\000\000\ud947\ude86\udbfe\udff6\udbdd\udd2d\ud9d7\udf92\ud98a\udd9b\uda9c\udeda\udbd9\ude82\ud89f\uddee\ud97f\uddfa\ud953\udf65\ud98b\udfd2\ud969\udd2aYh\ud912\udf6c\ud8e5\udf06", "\u04d0", "\udb52\ude51\u37f6\udacd\udde1\000\uf90f\000\udaa7\udf81\uda18\udff2\udb39\udc13\005\u44ab\ud8a4\udeb2\ud92a\udcbf\ud8e2\udc39\ud8ab\udffa\udb92\udd0e\ud806\udd5a\ud899\udefa",
        33, 55857, -1185147231, 872857441910546970L, -72592L, true, true, (char) 34151, (char) 32911,
        Double.longBitsToDouble(0x3fd439f87fd67030L), Double.longBitsToDouble(0x3fd2130967a0d8d0L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:J |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 0, "j", "\ub891", "\ud98a\udd9b\udbd1\udf80\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4\ud89a\uddf3\ud9a1\udeb2\udad3\udf5e\uda62\uddc5\uda22\udcd4\ud926\ude94\udaf6\udead\ud890\udc9a\ud9c9\udced\ud830\udf77\u9641\uda60\udc87\uda05\uddf5\udacd\uddba\ud84b\uddb8\uc700\udbe2\udf91\ud801\udc7c",
        17, 85437, 48645, -7948214892635356991L, 10985L, false, false, (char) 11613, (char) 34021,
        Double.longBitsToDouble(0x3fe10d414e39d154L), Double.longBitsToDouble(0x3fe5bbef64f036cbL)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=java.lang.String:M |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:M |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\ua271\udaa5\udd67\uda8f\udc3fM\udaf4\udd19\udbb9\ude18\ud98a\udd9b\udb5e\uddb7\udbe8\udd02\ud89f\udda4\ud97f\uddfa\ud841\udcc5\udb51\udfd7\udac9\udd12\ud822\ude8d\000\uda22\udcd4\ud926\ude94", "\ucd44\u8838\u288f\u316e\uc33a\u9478\u7fe4\uc700\u3bc1\u8a49\uad2e\u8b09\u6b44\u3f01\ub577\u7552\ub129\ud586\u9e8a\u13c8\u4f3f\ub2dd\u9799", "\ud91d\udf15\ud88c\udf84\uda00\udd4e",
        52, 77480, 340690465, 1575437754430574476L, 59723L, true, true, (char) 27238, (char) 21541,
        Double.longBitsToDouble(0x3fe4ceb92eb797aeL), Double.longBitsToDouble(0x3fd5490e5d4fe9f6L)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=java.lang.String:KKKN |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KKKN |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "k\udb8b\udc85\udb27\udc81&\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\ud8bb\udcf5\udb95\udc45C\udbda\udf1d\uda69\udcadG\udb28\uddd0\ud8e8\udd34\u00d1\uda22\udcd4\ud926\ude94", "\u604b", "\udb0b\udc7e\udb12\ude7c\uda10\udef4\udb1f\udcac\u1bb1\000\udaa7\udf81\uda18\udff2",
        39, -995, 17579, 504403158469974390L, 44866L, true, true, (char) 26806, (char) 11461,
        Double.longBitsToDouble(0x3fe8e777b5e17262L), Double.longBitsToDouble(0x3fe509d682d4a105L)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=java.lang.String:PKSK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PKSK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "b\000\udb26\udff2\uf263\uda64\udc5b\ud9d8\udc1e\ud98a\udd9b\udb5b\udc4a\udb28\udcd6\u00f7\ud97f\uddef\uda29\udfb4G\udb6b\udd2bsX", "\u75df\u56ae\u604b\u4e78\u1d17\uc435\u97f8\u5e9b\000", "\udaa7\udf81",
        14, 62481, 5, 262126182596608L, -39352L, false, false, (char) 29885, (char) 48672,
        Double.longBitsToDouble(0x3feb8fca980ff4d6L), Double.longBitsToDouble(0x3fe96a994aad2a8eL)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "\uda26\ude81Q\udb26\udff2&\ud95b\udecd\udae8\udda6\uda60\ude1e\ud9e2\udd67\udaeb\udd9b\udb89\uddfd\ud99d\udc3f\uda62\ude77G\udba9\udc99\u0083\uda53\udf4f\udb17\udf14\ud91a\udfdb", "\u5bf0\u8a2a\u3f25\ucdb1\u97f8\u5e9b\u2b4d", "\udb54\udf80",
        12, 62481, 5, 20977216787578880L, -46268L, false, false, (char) 29885, (char) 26769,
        Double.longBitsToDouble(0x3feb8fca991ceef6L), Double.longBitsToDouble(0x3fea54e91ea13ad0L)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 0, "b\000\udb26\udff2\ud836\udf0d", "\u5da1\ubf9e\u4860\u00f7\u3fb4\uca12\u6ee9\ua8ea\000X\u573f\u3085\u75df\u56ae\u604b\u4e78\u1d17\u9885\u1e61\u8bb7\u7fd3\u609d\ub5fa\u7e13", "\005\u44ab\ud8a4\udeb2\udb79\udf2d\uda23\ude68\ud8ab\udf7a\ud88f\uddfc\ud921\udc6a",
        1, 17783, -1378240723, -909061002095751944L, 4827L, false, true, (char) 27564, (char) 44906,
        Double.longBitsToDouble(0x3fceff991df936fcL), Double.longBitsToDouble(0x3fe10321898aadc2L)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=java.lang.String:KRS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KRS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "g\u29ec\udb26\udff2\u6e26\ud96f\udc17\ud963\udca4\ud97b\uddfc\ud886\udfba\uda24\ude0a\ufbd3\uda09\ude38\udbfa\ude1a\udafc\udf3d\udae6\udc07r\000\u0e21\u00df", "\000", "\ud93f\udfbb",
        40, 3, 1294401536, -3098257401514557440L, -100000L, false, false, (char) 27780, (char) 42942,
        Double.longBitsToDouble(0x3fd2ad58aa76a810L), Double.longBitsToDouble(0x3fe6b9c9ade2d192L)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.String:NK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 12, 15, 11, "kN\ud80c\udec5\ua14f\uda08\udc98\ud9d8\udc1e\ud98a\udd9b\udb07\ude0f\ud9ec\udf58\ud9f6\udc5d\ud905\udde3\uda56\udc38G\ua8ea\000\000\uda22\udcd4\ud926\ude94", "\u604b", "\ud86b\udcb7\ud8a7\udfb2\udac5\udffc\ud87e\udd47\uc717\000\udaa7\udf81\udade\udeb5",
        6, 98691, 17579, -6485183462575778837L, 85292L, true, true, (char) 26769, (char) 11461,
        Double.longBitsToDouble(0x3fe8e4fd9de17262L), Double.longBitsToDouble(0x3fe509d682d4a105L)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "i\000\u8210e\ud95b\udecd\ud9d8\udc1e\ud98a\udd9b\udb9c\udd7b\udb63\ude60\udb1c\udf30\ud97f\ude51\uda29\udfb4\udb94\udf71\udac9\udd12\000", "\u3085", "\uda46\udfa3",
        29, 7195, -1795047264, 2249846230678348149L, -7654L, true, true, (char) 42299, (char) 21772,
        Double.longBitsToDouble(0x3fc5600000000000L), Double.longBitsToDouble(0x3fef5a58010373eeL)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 8, "g", "\u6e26", "\ud97b\uddfc\000\000\000\000\000",
        50, 76002, 114, 0L, -100000L, false, true, (char) 219, (char) 0,
        Double.longBitsToDouble(0x3fd00000009f3fc8L), Double.longBitsToDouble(0x3d900d4000000000L)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=java.lang.String:KJ |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KJ |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 0, "\udb4a\udf90\uda2d\udc7c\ud903\udef8\udbe2\udd9e\ud8cf\ude95\ud926\udc30\ud97b\uddfc\udbd1\udf80\udb89\ude29C\ud97f\uddbe\udb5e\udcc0J", "\u1338\000\uc6d4\u58ac\u9db3\000\ub684\ua4b4", "\udad3\ude65\ub62c\udadd\udc76\ud93a\udc3c",
        44, 69169, 1440222481, -3312453579530353493L, 33228L, true, false, (char) 10854, (char) 34979,
        Double.longBitsToDouble(0x3fe025c4940d649bL), Double.longBitsToDouble(0x3fe40da45186ee86L)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "k\000\udb26\udff2&\ud8fd\uddcd\ud9d8\udc1e\ud98a\udd9b\udbd1\udf80\udb89\udf06C", "\u7cb0\u2d50\u3fb8]\ud1ba\u2278\u54bd\u5604\u604b\u8a5e\u24ea\u22c4\u7fc0\u7415\ud370\uc717\000\u257b", "\005\u44ab\ud89e\ude2e\ud95d\udef9\udb44\udf7a\uda21\udd1a\ud86f\udcd6\ud921\udc6a",
        52, 81268, -320324127, -3368483385295436503L, -33869L, true, true, (char) 24064, (char) 24194,
        Double.longBitsToDouble(0x3fbf7d34a98552f0L), Double.longBitsToDouble(0x3fed919376036cacL)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=java.lang.String:PSKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:PSKS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "b\000\udb26\udff2\uda6a\ude5a\uda64\udc5b\ud9d8\udc1e\ud98a\udd9b\udb5b\udc4a\udb28\udcd6\u00e7\ud97f\uddef\uda29\udfb4G\udb6b\udd2bsX", "\u75df\u56ae\u604b\u8a07\u1d17\uc435\ub011\u5e9b\u8f68", "\udba3\ude4f\uda18\udf99",
        56, -995, -948816849, 152454683787611335L, -48258L, true, true, (char) 48672, (char) 11461,
        Double.longBitsToDouble(0x3f8fe9ad8a538a40L), Double.longBitsToDouble(0x3fe5685e65791e68L)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=java.lang.String:KRSS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KRSS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "g\u29ec\udb26\udff2\u6e26\ud96f\udc17\ud963\udca4\ud97b\uddfc\udbed\uddb7\uda24\ude0a\ufbd3\uda6e\ude89\udbe9\udf91\udafc\udf3d\udae6\udc07rS\u0e21\u00df", "\000", "\ud93f\udfbb",
        40, 3, 1294401536, -3098257401514557440L, -100000L, false, false, (char) 27780, (char) 42942,
        Double.longBitsToDouble(0x3fd2ad58aa76a810L), Double.longBitsToDouble(0x3fe6b9c9ade2d192L)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=java.lang.String:KR |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KR |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 8, "C\u29ec\udb26\udff2\u6e26\ud96f\udc17\ud96f\udea4\ud97b\uddfc\ud886\udfba\uda24\ude0a\ufbd3\uda09\ude38\ud92b\udc73\ud89b\udc1b\ud8e6\udc2br", "", "\udbc7\udd0c",
        -5, -1000, -1612437248, 9076600765848115849L, 96608L, true, true, (char) 54528, (char) 36999,
        Double.longBitsToDouble(0x3fdf1f7a0a220000L), Double.longBitsToDouble(0x3fed03cec1542873L)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=java.lang.String:NK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:NK |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "kN\ud86b\ude8d\ud972\ude06\uda08\udc98\ud9d8\udc1e\ud98a\udd9b\udb07\ude0f\ud9ec\udf58\ud9f6\udc5d\ud905\udde3\uda56\udc38G\ud823\udfe6\ud97c\ude38\ud930\udd1d\udb49\uddfb\ud942\udf85", "\u604b", "\ud951\udfcb\ud8af\udd23\ud8c2\udf72\ud87e\udd78\uc717\000\udaa7\udf81\uda7f\udc64",
        25, 98691, 17579, -6485183462575778837L, 85292L, true, true, (char) 26769, (char) 11461,
        Double.longBitsToDouble(0x3fe8e4fd9de17262L), Double.longBitsToDouble(0x3fe509d682d4a105L)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=java.lang.String:KRSS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.String:KRSS |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 15, 15, 11, "g\u29ec\udbf6\udd5a\ud841\ude4c\ud988\udc17\ud963\udca4\ud869\udcb4\ud803\uddf5\uda24\ude0a\uda82\udfd5\u8dbd\udbe9\udfac\udafc\udf3d\udae6\udc07rS\u0e21\u00df\000\udbc3\udeff\000\udb5b\udd10\ud819\udf1d\ud93f\udfbb\ud88c\udf04\u257d\udbd9\udc8b\ud921\udcc6\ud8e9\udcf3\udb83\udc30\u55f1\ud8a3\udc3f\ud8f1\ude02\ub154\000\ud8d8\ude0c\ud9a7\udf7d\ud9b1\udf9d\udb07\ude1d", "\u4b11\u253b\ua824\u7c7e", "\uda1c\udf78\udbec\udc2c",
        31, 64420, 1321122105, -3970513815525852009L, -20181L, false, true, (char) 39147, (char) 54382,
        Double.longBitsToDouble(0x3fec64f642657c3aL), Double.longBitsToDouble(0x3fa426c09bb3b340L)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=java.lang.String:H\u1884\udb26\udff2T\ud817\uddeb\ud9d8\udc3e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\ud9bc\udcbeG\ua8ea |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 5, 3, "H\u1884\udb26\udff2T\ud817\uddeb\ud9d8\udc3e\ud98a\udd9b\udbd1\udf80\udb89\udf06C\ud97f\uddef\ud9bc\udcbeG\ua8ea", "", "\ud961\udead\ud9c0\udda4\uda46\udfa3\u7b49\uf15b\udb0b\udc7e\uda70\udfea\ud976\udf15\udb63\udede",
        2, 77568, 501327360, 6140708211333270801L, -82421L, false, false, (char) 31211, (char) 29722,
        Double.longBitsToDouble(0x3fe0f6ee5989d334L), Double.longBitsToDouble(0x3fc9f8784dc7e54cL)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 4, "b\u0094\udb26\udff2\ud94c\udc05\ud95b\udecd\ud8ff\udc11\ud98a\udd64\udbd1\udf80\udb28\udcd6\u00f7\ud97f\ude07\uda29\udfb4N\ua8ea\000\ud89c\udc65\uda22\udcd4\ud8e8\udf13", "\u604b\u4e78\u6417\uc435\u97f8", "\uc700\000",
        20, 69169, 1440222481, 21474854059L, -23179L, true, false, (char) 58045, (char) 29885,
        Double.longBitsToDouble(0x3fc9f874cdc7e54cL), Double.longBitsToDouble(0x3f8fe9adcb54ca40L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.language.DoubleMetaphone|handleG|java.lang.String,org.apache.commons.codec.language.DoubleMetaphone$DoubleMetaphoneResult,int,boolean|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|charAt|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|cleanInput|java.lang.String|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionC0|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionCH0|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionCH1|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionL0|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|conditionM0|java.lang.String,int|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|contains|java.lang.String,int,int,[Ljava.lang.String;|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|doubleMetaphone|java.lang.String|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|handleG|java.lang.String,org.apache.commons.codec.language.DoubleMetaphone$DoubleMetaphoneResult,int,boolean|new:org.apache.commons.codec.language.DoubleMetaphone:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
