package org.apache.commons.codec.language;
import org.junit.Test;
import static org.junit.Assert.*;
public class Caverphone_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 12, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -5, 63725, 616474880, 1087772870896289348L, 52639L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 12, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\uda2e\ude19\udafa\udeaf\ud9ed\udf78\udb9f\udee4", "\u15bd", "\ud8b4\udcfd\udb16\udf49\ud8df\ude9e\ud932\udf58\udbe7\udcef\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud9e6\udd06\ud82b\udde9\uda96\udeeb\ud8ce\udf7c",
        46, 76071, 1764842353, -4866913115796072756L, 56018L, false, false, (char) 11476, (char) 13033,
        Double.longBitsToDouble(0x3fde2f5b34d1f86eL), Double.longBitsToDouble(0x3fea2ee3729443fdL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 12, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\ucd23", "\udb9f\udee4",
        36, 96604, 1536377140, -2102150045403017746L, -42533L, false, true, (char) 51655, (char) 63957,
        Double.longBitsToDouble(0x3fd0076fa754497cL), Double.longBitsToDouble(0x3fe22078c415ae14L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 3, 13, "\udbe5\udfb4\udbd7\ude92\ud9f5\udc6d", "\uc141\uae1e\u6e9e\ud37a\u47cc\uc8a0\u888d\u1bb6\u15bd\u6718\ubd48", "\ud8df\ude9e\ud932\udf58\udbe7\udcef\ud940\udf2a\udaeb\udc8d\ud875\uddad\ud90d\udd0d\ud82b\udde9\uda96\udf1a\ud8ce\udf7c\ud873\ude7b\ud8c1\uddab\u8b0e\ud806\ude3a\ud9f8\udf65\ud82c\ude8e\ud9d4\uddfe\uda99\udc85\ud887\udeae",
        6, 81195, 223697838, 8247083585500221892L, 30692L, true, true, (char) 44247, (char) 40970,
        Double.longBitsToDouble(0x3fd30d4cc43c0c36L), Double.longBitsToDouble(0x3fdefcfe4eec85e4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 10, 5, 14, "\ud8eb\udd72\udb02\udfc5\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        13, 63727, -820455680, -2116538263977818556L, 52639L, false, true, (char) 30668, (char) 1062,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 12, 13, "\ud872\udfee\udb07\udf4d\uda15\udf6c", "\uc141\u712e\ub0dd", "\uda01\udc14\ud868\udd5c\udb7d\ude03\uda1d\uded2\ud8d9\udfde",
        28, 23479, -1858387013, -822936690494702627L, -65628L, true, false, (char) 38167, (char) 16753,
        Double.longBitsToDouble(0x3fb367ac9f0d3088L), Double.longBitsToDouble(0x3fc922c999c61630L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 17, 13, "\ud84c\udd43\udb07\udf37\uda0a\udc9f", "\uc141\uae1e\u2d52", "\u0680\ud8f4\udf7f\ud9e8\ude3d\udbb4\udcab\ud88d\udc45\uaec5\udaba\udff8\ud8ff\udc4d\uda61\ude2c\ud932\udf58\udabd\udc7e\ud940\udf2a\udaeb\udc8d\ud89f\udcc1",
        30, 70939, -687632554, -8457792223271912608L, -91113L, false, false, (char) 20698, (char) 4372,
        Double.longBitsToDouble(0x3fe302f276020450L), Double.longBitsToDouble(0x3fea7f44256939eaL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udad5\ude87\ud8f4\udedf\u674c |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 12, 11, 13, "\udad5\ude87\ud8f4\udedf\u674c", "\uc141\uae1e\u6e9e\u5504", "\ud868\udd5c\ud86c\udcea\udb2e\udec0\udbaf\ude3c\udb84\udffe\udbb0\ude0b\udb16\udf49",
        13, 94900, 1996127725, -5006360919612552425L, 6987L, true, false, (char) 51603, (char) 30668,
        Double.longBitsToDouble(0x3fe6d5308ae7d9cbL), Double.longBitsToDouble(0x3fed349f12a36931L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 12, 13, "\ud84c\udda3\udb07\udf37", "\u39b8\u51d7\ub3de\u6e9e\ud37a\u47cc\uc8a0\u9b8d\u09ee\u442b\u6718\u7687", "\ud8df\ude9e\ud932\udf58\udbe7\udcef\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud9e6\udd06\ud82b\udde9\uda96\udeeb\udac8\udeb9\ud832\udff7\uda89\udd2b",
        48, 58587, -1285024052, 7079859817777183994L, -94280L, true, false, (char) 51299, (char) 34412,
        Double.longBitsToDouble(0x3fe560a917c4277cL), Double.longBitsToDouble(0x3fe9db8f4825a214L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 6, 0, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\000\ud977\ude3b\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -5, 63725, 616474880, 1087772870896289348L, 52639L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "\ud84c\udd43\uda2a\udf0f\ud93c\ude70", "\uc141\uae1e\u6e9e\u1838\uad73\uc8a0\u9b8d", "\udb79\udff3",
        47, 71576, 799334523, 8483919292086637579L, -65628L, true, false, (char) 43041, (char) 51603,
        Double.longBitsToDouble(0x3fc93ae06b6a9844L), Double.longBitsToDouble(0x3fccfb320dc61630L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 4, 12, 0, "\ud84c\udd43\udb07\udf37\ud9f4\udf75", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        53, 63725, 616474880, 153562260701184L, -100000L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3ec20dc614000000L), Double.longBitsToDouble(0x3fe003498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 12, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\u6e9e\ud37a\u47cc\uc8a0\u9b8d\u1bb6\u15bd\u6718\u7708\u873d\ub0f2\u3339", "\ud940\udf2a\udaeb\udc8d\ud83a\udd70\udb68\udcd4\ud8bd\udcb7\uda96\udeeb\ud8ce\udf7c\ud870\udc96\uda89\uddaf\udbfe\udda3\ud806\ude3a\udaa4\udfbb\u6faa\uda43\ude91\ud891\udef0\ud884\udc39\ud8c5\udfbe\ud9c2\udc20\ud80d\udfca\uda47\udccd\u3cc7\udbb3\udd41\ud813\uddcd\udb4d\udc9d\uda99\udce1\udbec\udd05\ud85e\udc92\ud97b\udc05\ud8b8\ude7e\ud816\udfa8\udb2c\udf98\udba2\udef5\udbc1\udf02\udaf7\udfb4\ud915\udc9c\ud967\ude1c",
        -1, 17803, -606665602, -7255208276973030695L, -69938L, false, true, (char) 48173, (char) 16314,
        Double.longBitsToDouble(0x3fea7b00641d9afeL), Double.longBitsToDouble(0x3fdd88fb5a29fffeL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90\udbd5\udc34\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\ud8e0\ude4b\udb24\uddaf\ud9ed\udf78\udb9f\uded3\ud868\udd5c\uda83\udfe6", "\u7708\u873d\u9edf\u4275\u1ee6\u82f0\ub48c\u3d8e\u652c\u1f80\u5db8\u5cc2\u9e32\u7d4c\u2bc6\ub81d\u7a64\u6db6\u7558\ud05b\ua9c2\u1b35", "\udaf2\udf54",
        40, 91250, 1896790482, -5770622424285343925L, -72464L, true, true, (char) 7775, (char) 40965,
        Double.longBitsToDouble(0x3fc04eb8037874a0L), Double.longBitsToDouble(0x3fd785e0c5f04f62L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 12, 6, 13, "\ud84c\udd43\udb07\udf37\ud97d\udd12", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -5, 63725, 616474880, 1087772870896289348L, 52639L, false, true, (char) 30668, (char) 33067,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 12, 7, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -2, 1922, 616475039, 1087772870896289348L, 52639L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498f60f90bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 12, 5, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -5, 63725, 616474880, 1087772870896289348L, 52639L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 6, 12, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "7\uada6\000", "\udb9f\udee4",
        36, 96604, 1526726708, 738734374912L, -42533L, false, true, (char) 51655, (char) 0,
        Double.longBitsToDouble(0x3fd007600154497cL), Double.longBitsToDouble(0x3fb103c600000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 8, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda35\ude00\uda44\udf00\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -5, 63725, 616474880, 1087772870896289348L, 52639L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3fc419de29c61630L), Double.longBitsToDouble(0x3fe51d9056ccf90bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 7, 12, 0, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\u4f69\ubfe5\ud460", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -5, 63725, 616474880, 1087772870896289348L, 52639L, false, true, (char) 41434, (char) 33003,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498f17f77eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 0, 16, 13, "\ud9c7\udca6\udb07\udf37\ud9f5\udc6d", "\u2541\u6e56\u6e42", "\uda70\ude6b\ud830\udfe1\uda4a\udf5f\uda1d\ude99\udbbb\udc13\udb84\udfb8\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        31, 59327, 616474880, 1087772870896289348L, 55447L, false, false, (char) 48759, (char) 57597,
        Double.longBitsToDouble(0x3fe51b498eccf90bL), Double.longBitsToDouble(0x3fefd801f1733cdcL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 2, 6, 17, "\ud84c\udd43\udb07\udf37\udacc\udc69", "\u9ccb\uae1e\u6e9e", "\udbbb\udeae\ud9fd\udef7\ud97b\udc6b\ud949\udffa\ud9d2\udd33\udb84\udffe\udb70\ude1b\udb16\udf80\ud8df\ude9e\ud98a\udd56\ud960\udc48\ud9b2\udcfe\ufd40\ud933\udfe5\udae3\udf94\ud82b\ude03\uda96\udeeb\ud8ce\udf7c\ud870\udc96\uda89\uddaf\udbfe\udda3\udbda\udd24\ud98a\udfa9\ud8f6\udfe6\ud9b0\udc52\ud98b\udc08",
        49, 12115, 2005823301, -4153523064835960866L, -12060L, true, true, (char) 43701, (char) 56361,
        Double.longBitsToDouble(0x3fbfacb658b506f0L), Double.longBitsToDouble(0x3fe0b09f918623d1L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 6, 13, "\ud97a\ude48\ud920\ude23\ud977\udd09\ud965\udd60\ud8dd\udcea\udab3\udffa\udb32\udc14\uda2e\ude85\udafa\udeaf\ud8c0\ude01\uda60\ude52\udb22\udf26\uda83\udfe6\ud991\udc94\ud95e\udec9\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e\ud932\udf58\udbe7\udcef\ud939\udc2e\uda04\udcdd\udb9d\udfed\ud93f\udc31\ud838\udec2\uda96\udeeb\ud9b7\udc44\udafc\udd62\uda89\udd50\udbfe\udda3\udb73\udf10\ud84c\udd04\uda04\uddc1\ud870\uddea\ud9aa\udd2a", "\u3e85\u8ab2\u7970\u3cf9\u0324\u0ac2\u54b7\u6129\u16d5\u5576\u46c2\u6d07", "\udabd\udda0\udb0d\udf21\udb04\udf4d\udab6\uddd5\u8a36\ud94a\uddf1\udaf2\udf07\udbed\uddb3\ud868\udf2e",
        7, 78535, 623348193, 259644894166756356L, -92262L, true, true, (char) 29064, (char) 58757,
        Double.longBitsToDouble(0x3f90e8c3046b0ce0L), Double.longBitsToDouble(0x3fd77335b34d2036L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 2, 14, 5, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -5, 63725, 616474880, 1087772870896289348L, 83735L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud9c4\udc9e\udb07\udf37\ud9f5\udc6d |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 0, 12, 17, "\ud9c4\udc9e\udb07\udf37\ud9f5\udc6d", "\u4ffb\uae1e\u6e9e\ud37a\uae89\u6c34\u9b8d\u1bb6\u15bd\u6718\u7708\u873d", "\ud932\udf58\udbe7\udcef\ud940\udf2a\udaeb\udc8d\u7782\ud9e6\udda8\ud82b\udde9\uda96\udeeb\ud8ce\udf7c\ud870\udc96\uda89\uddaf\udbfe\udda3\ud806\ude3a\udbde\udc37\udb74\udf15\udbdb\udf81\udb5a\udf34\ud9c1\uddaa\udbdd\udca7\ud898\udc2c\ud83b\udd0e\uda1a\udd4a\ud9c6\ude90",
        0, 25178, 897854476, 7730387376594947384L, 65054L, false, true, (char) 24598, (char) 54123,
        Double.longBitsToDouble(0x3fec19590f387acdL), Double.longBitsToDouble(0x3fe8ba8c9168ba8eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud84c\udd43\udb07\udf37\ud82f\udc6a |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 13, 3, 6, "\ud84c\udd43\udb07\udf37\ud82f\udc6a", "\uc141\uae1e\u6e9e\ud37a\u47cc\uc8a0\u9b8d\u1bb6\u34d9\u6718\u7708\u98cd\ub0f2\u3339\ub233\u382f\uc962\u65bc\u2fda\u1f80\u4e6f\ub42d\u2141\u7d4c\u2bc6\u31c3\u26a3\u3de8", "\udbde\udd70\ud99b\ude35\udaa2\udf2f\udbe0\udc91\uda29\udc24\ud95a\udec1\udaa2\ude18\uda7c\udf21\ud852\udf00\ud8e3\uddf5\ud8ee\udec6\ud992\udd71\ud88d\ude13\uda4f\udc5a\ud811\udd77\udbac\ude93",
        22, 75820, -627253076, 745498401546904287L, 53386L, true, false, (char) 3837, (char) 26602,
        Double.longBitsToDouble(0x3fd16b5009e4a5a4L), Double.longBitsToDouble(0x3fd74f8d7851d9aaL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 9, "\uda15\udf36\ud8a1\uded7\ud927\udff9\udb00\udc69\ud85b\udc92\udab3\udffa\udb18\udd14\uda2e\ude19\udafa\udeaf\ud9ed\udf78\udbb8\udee4\ud913\ude93\uda7a\ude8f", "\u7708\u873d\ub0f2", "\udbf4\ude52\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud9e6\udd06\ud82b\udde9",
        46, 43833, -644839974, -8823425887358955888L, -43285L, true, false, (char) 51040, (char) 35422,
        Double.longBitsToDouble(0x3fcfd30cd169125cL), Double.longBitsToDouble(0x3fdba30c2f59c16eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 6, 8, 4, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\ub224\000\000", "",
        -5, -1000, 0, -489445120L, -100000L, false, false, (char) 0, (char) 7936,
        Double.longBitsToDouble(0x3fed5125f6440f18L), Double.longBitsToDouble(0x3e94800000000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 7, 7, 9, "\u63ea\udbc0\ude25\udbdd\udf70", "\uc141", "\ud8d3\udd3b\ud9ed\udfe5\udb9f\udee4\ud868\udd5c",
        -1, 65140, -489444948, -2364796700530565272L, -38642L, true, false, (char) 63957, (char) 8186,
        Double.longBitsToDouble(0x3fed5125f6440f18L), Double.longBitsToDouble(0x3f95ae1487ea7c40L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 13, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae02\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\udace\udfe0\udb16\udf84\ud8df\ude9e",
        -5, 63725, 616474880, 1087772870896289348L, 9321L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3fccfb3219c61630L), Double.longBitsToDouble(0x3fe7bff446ccf90bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 5, 8, 3, "\ud8fc\udd3e\udb07\udf8d", "\u39fa\uc141\uae1e\u6e9e\ud37a\u47cc\u9df4\u848e\u1bb6\u15bd\u6718\u7167", "\ud8df\ude9e\ud954\ude24\udbf9\ude8c\ud940\udf2a\udaeb\udc8d\udb68\ude27\ud9e6\udd06\ud82b\uddfa\uda96\udeeb\ud9e6\udce7\ud9bc\ude54\udbb9\udcd3",
        -2, 58587, -201713972, 5246507265103394926L, 71311L, true, false, (char) 36268, (char) 48399,
        Double.longBitsToDouble(0x3fb880610f034948L), Double.longBitsToDouble(0x3fe12afe2999613fL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 6, 8, "\ud84c\udd43", "\u2c3b\u452d", "\uda2e\ude19\udafa\udeaf\ud9ed\udf78\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\uda74\udcad\udb16\udfc4\ud8df\ude9e",
        -5, 2957, -2036684776, 1087772673327793732L, 52639L, false, true, (char) 55915, (char) 13026,
        Double.longBitsToDouble(0x3fe1f3db8c718590L), Double.longBitsToDouble(0x3fd1035c0d986416L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud84c\udd43\udb07\udf37\ud9f5\udc6d |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 15, 10, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe",
        11, 19523, 1975316398, 8928478669479509485L, -64246L, false, false, (char) 45609, (char) 43041,
        Double.longBitsToDouble(0x3fb5870fbde18308L), Double.longBitsToDouble(0x3fea3d308ce7d990L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "\uca16\u3a3e\u397a\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda47\udc62\uda1d\ude99\udb79\udff3\u00ee\ud8ac\udd95\udb16\udf49\ud84d\udee5",
        -5, 63725, 12495104, -1374386688L, -100000L, false, false, (char) 41160, (char) 0,
        Double.longBitsToDouble(0x3e3b8c2c60000000L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud84c\udd43\udb07\udf37\ud9f5\udc6d |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 15, 12, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\u491e\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -5, 93165, 616475115, 1116764793497486916L, 52639L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\u4ec8\012",
        Z.run(T, 1, 2, 8, 5, "\u4ec8\ud8ed\udcbb\uda10\udd3a", "\uc141\ub7e5\u6e9e", "\udb36\udd3e\udb03\udfc6\uda79\udce6\ud95d\udc06\udb79\udff3\udb84\udffe\ud87e\udc3b\ufdad\udae9\ude50",
        -5, 63725, 618486528, 1087772870896289348L, -47914L, true, true, (char) 49830, (char) 46195,
        Double.longBitsToDouble(0x3fccfb3203d94630L), Double.longBitsToDouble(0x3fe6c2ab84c00b14L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 2, 12, 7, "\ud83f\udfbd\udb07\udf37\ud9f5\udc6d\ud965\udd60\ud8b1\udceb\ud93a\ude84", "\ud37c\u47cc\uc8a0\u9b8d", "\udb79\udff3\udb84\udffe\ud887\uddf4\ud9c3\ude80\udb11\udd57\ud843\udfce\u1cbb\ud940\udf2a\udaeb\udc8d",
        12, 87109, 473846847, -2953326347254914871L, -79751L, true, true, (char) 50132, (char) 4056,
        Double.longBitsToDouble(0x3fef70743dff1190L), Double.longBitsToDouble(0x3fc2b85bff133994L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 16, 0, 0, "", "\ubd1d", "\000",
        -5, -1000, 846004224, 575525617664L, 27876L, false, true, (char) 147, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e402c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 3, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e\ud932\udf58\udbe7\udcef\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud806\ude16\udb11\udc67\uda96\udeeb\ud8ce\udf7c\ud870\udc96\uda89\uddaf\udbfe\udda3",
        32, 60868, 946775960, 4123381525502069271L, 61957L, true, true, (char) 13095, (char) 61390,
        Double.longBitsToDouble(0x3fe9065686f0d788L), Double.longBitsToDouble(0x3fd50dc17a9088eeL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 8, 9, "\ud84c\udd43\udb07\udf37\u577e", "\ucef6\uae1e\u6e9e\ubbf3\u5734", "\ud967\udc58\uda1d\udf3f\udb79\udff3\uda0c\udfc1\ud8b4\udcfd\udb16\udf49\ud8df\ude9e\ud932\udf58\ud864\uddaa\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud9e6\udd06\ud82b\udde9\ud949\udf74\udb64\udcd7\udbdc\uddcc\ud889\udc4f",
        7, 76986, -237853871, 5558671761794861186L, -91059L, false, true, (char) 26326, (char) 61410,
        Double.longBitsToDouble(0x3fecd28b933699c5L), Double.longBitsToDouble(0x3fe0af30710d7acdL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud84c\udd43\udb07\udf37\ud9f5\udc6d |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud84c\udd43\udb07\udf37\ud9f5\udc6d |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 15, 12, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d", "\uc141\u17e2\u35fd\ud37a\u23a6\u688a\u7ef5\ub35a\u7d71\u39e3\u7708\u873d", "\ud932\udf58\udbe7\udcef\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud9e6\udd06\ud82b\udde9\uda96\udeeb\ud819\udee7\uda13\udf79\uda89\uddaf\udbfe\udda3\ud806\ude3a\udbde\udf78\ud8f1\udd8f\ud898\udcb9\ud887\udc55\ud916\ude99\udb9a\udcda\udb74\udf21\ud802\udecb\ud943\udc98\udb61\udcfc",
        24, 3659, -238510873, -8025176065956609736L, 88730L, false, true, (char) 64859, (char) 54510,
        Double.longBitsToDouble(0x3fd3bbaa042d3700L), Double.longBitsToDouble(0x3fcce0995f964140L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 12, 2, "\000\000\ud9f4\udf75", "\uc141\uae1e\u1461", "",
        55, 41716, 1241513984, 41448513170571264L, -100000L, false, false, (char) 0, (char) 21515,
        Double.longBitsToDouble(0x3fcdaf7d0401d800L), Double.longBitsToDouble(0x3fe8000006440f18L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 6, 14, 13, "\udbb1\udd35", "", "",
        59, 37984, -647697312, 3633595346036399238L, -42533L, false, false, (char) 21515, (char) 63957,
        Double.longBitsToDouble(0x3fd0076fa754497cL), Double.longBitsToDouble(0x3e40540000000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\uda2e\ude19\udafa\udeaf\ud9ed\udf78\udb9f\udee4", "\u15bd", "\ud8b4\udcfd\udb16\udf49\ud8df\ude9e\ud91b\udfed\u94af\ud934\udd62\udaeb\udc8d\ud83a\udd70\ud9e6\udd06\ud82b\udde9\uda96\udeeb\ud8ce\udf7c",
        46, 76071, 1764842353, -4866913115796072756L, 56018L, false, false, (char) 11476, (char) 13033,
        Double.longBitsToDouble(0x3fde2f5b34d1f86eL), Double.longBitsToDouble(0x3fea2ee3729443fdL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 12, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\uda2e\ude19\udafa\udeaf\ud9ed\udf78\udb9f\udee4\ud868\udd5c\ud884\udf16\uda1d\ude99\udb79\udff3\udb84\udffe\udb22\udea8\udb16\udf49\ud8df\ude9e\ud932\udf58\udbe7\udcef\ud940\udf2a\udaeb\udc8d\ud8dc\udfc0", "\u2cf7\u9e32\u7d4c\u2bc6\ub81d\uc041\u8a18\u1f7c\u2a90\u58b6\u61d6\u70af\u7136\u4040\u87da\u3f66\u189b\u60ab\u1ad3\u37fd\u6248\u4fcf\u655d\u05d6\u0855\u285f\ubaa2\u1466\u4296\u9342\u124f\u9d09\ub6ae\u4d3d", "\udae5\udcd6\uda9f\udd74\ud967\udcc8\uda34\udf1d\ud968\ude8c\ud940\udca3\ud9f5\udea8\uda70\udd88\ud9c9\udd1c\ud9a1\ude15\ud838\udf00\ud9b8\udf03\ud96c\udc16",
        29, 45672, -1538386443, -3301593171970090725L, -58736L, true, false, (char) 51945, (char) 11127,
        Double.longBitsToDouble(0x3fdacd55cfedd6c4L), Double.longBitsToDouble(0x3fe4d0d3782d334eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\ud2ad\012",
        Z.run(T, 1, 2, 4, 13, "\ud904\udd3f\udb07\udf37\ud9f5\udc6d\ud9fd\udd54\ud8dd\udcea\uda97\ude83\ud8b8\udfe8\ud9f2\ude38\ud2ad\ud9ed\udf78\udb9f\udee4", "\u15bd", "\ud8b4\udcfd\udb16\udf49\ud9fb\udc8e\ud929\udf3c\udbe7\udcef\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud9e6\udd06\ud82b\udde9\uda96\udeeb\ud8a0\udc26",
        9, 67125, 1764842353, -4866913115527637300L, -10941L, false, false, (char) 46704, (char) 23620,
        Double.longBitsToDouble(0x3fde2f5b34d1f86eL), Double.longBitsToDouble(0x3fea2ee3729443fdL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 12, 1, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d\ud965\udd60\ud8dd\udcea\uda9b\udf1c\ud96a\udded\udab1\udef3\udaf8\ude97\ud9ed\udf78\udb9f\udee4", "\u8da8", "\ud8b4\udcfd",
        8, 58398, 2078823435, 8573303298130356480L, -65628L, true, false, (char) 43041, (char) 51603,
        Double.longBitsToDouble(0x3fe69657f2daa65fL), Double.longBitsToDouble(0x3fccfb320dc61630L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud84c\udd43\udb07\udf37\ud9f5\udc6d\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\udb37\udced\udb29\udd19\ud9f1\ude78\udb9f\udf39 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 14, 2, 17, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\udb37\udced\udb29\udd19\ud9f1\ude78\udb9f\udf39", "\u5c25", "\ud8b4\udcfd\udb16\udf49\ud8df\ude9e\ud932\udf58\udbe7\udcef\ud940\udf2a\udaeb\udc8d\ud847\ude86\ud9e6\udd06\ud82b\udde9\uda96\udeeb\ud8ce\udf7c\ud870\udc96",
        1, 68353, -1133166513, -1492636736788651188L, -78400L, false, true, (char) 13033, (char) 50191,
        Double.longBitsToDouble(0x3fedb6b63cf53defL), Double.longBitsToDouble(0x3fe1d5bd171b845bL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 3, 13, "\ud84c\udd43\udb07\udf37\ud9f5\udc6d\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\uda28\udd95\udbb3\udf63\ud9ed\udf78\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8e3\udc91\udb16\udf49\ud890\udc17\ud85e\udc04\uda5f\ude52\ud918\udd40\udaeb\udc8d\ud83a\udd70\ud9b0\ude4c\udae8\udf9f\udb92\udf97\uda4b\ude4e\ud883\udc75\ud9b5\udf6b\ud9da\udd68\ud8b2\ude70\udb71\udc1b\ud99a\ude41\udbdc\udf0a\ud831\udc56\udbdd\udd66\ud8e4\udc36\uda53\udf63\ud835\udf26\ud993\ude2c\ud809\ude5b\udba0\udf3e\ud90e\udc99\ud9d0\udc93\ud830\udd68\ud942\udd33\uda4b\udc73\ud875\udc51\udb70\udf4c\ud9af\udef9\udb10\uddf8\ud88b\udc9d\udb36\udd03\ud81e\udd82", "\u7775\u356a\u21d7\u1ef4\uc189\u7025\u1367\ub84a\ua536\u926e\u7a26\ubda4\u5b28\u1cd2\u3f3e\u11d4\u07c3\u80c8\u17da\ud2b3\u7664\u636a\u6944\u720d\ubb1d\u20b1\u9d7e\u574b\u62ae\ud089\uabbb", "\uda65\udd7f\udad5\udebe\ud9ee\udd5f\uda28\ude6f\u55c2\u82f0\ud95b\udca3\udabb\udf7c\uda5e\udd34\ud848\uddd3\ud8a7\udd5e\ud8cb\udde3\udbeb\ude12\uda34\udfb3\udb36\udeef\ud807\ude1a\ud862\udea7\ud8d1\udd67\ud86b\ude45\udad2\udc3a\udbf9\udec4\udb70\udf30\ud9b7\udfa9\ud9be\udf23\udae1\udeff\ud844\udd21\udb60\udc37\ud8cd\udf17\udba6\udf49",
        33, 69342, 536374958, 5691383589388310085L, -63284L, true, false, (char) 38838, (char) 2520,
        Double.longBitsToDouble(0x3f7593866e4ad080L), Double.longBitsToDouble(0x3fbac6789f2473b0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 2, 1, 10, "\ud84c\udd43", "\u96fb\u61e5", "\uda28\udd95\udbb3\udf63\ud9ed\udf78\ua54a\ud936\udc11\ud907\udfbe",
        20, 11100, -550597192, 1978522141691335652L, -78485L, true, true, (char) 8186, (char) 21057,
        Double.longBitsToDouble(0x3fdba86fe6937486L), Double.longBitsToDouble(0x3fb163f571e093c0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 10, 5, 14, "\ud8eb\udd72\udb02\udfc5\ud9f5\udc6d", "\uc141\uae1e\u6e9e\ud37a\u47cc\uc8a0\u9b8d", "\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e\uda7d\udcbe\udbe7\udcf1\ud8b3\udc1e\udb6c\uddee",
        25, 87109, 473846847, -2953326345157762871L, -60196L, false, true, (char) 55851, (char) 25758,
        Double.longBitsToDouble(0x3feedf30914c9018L), Double.longBitsToDouble(0x3fe44600ea324ff6L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 14, 14, "\ud8eb\udd72\udb02\udfc5\ud9f5\udc6d", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb85\udc0e\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        13, 63727, -820455680, -2116538263977818556L, 52639L, false, true, (char) 30668, (char) 1062,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 3, 2, 16, "\ud8b7\uddb4\uda64\udef8\ud9f5\udc28", "\u9d41\ucba2\u13c8\ud37a\u47cc\uc8a0\u9b8d\u0c95\u15bd\u6718\u7708\u873d\ub0f2\u3339\uc227\u28c1\u2d0a\uc0d9\u6f1c\u1f80\u2afe\u3a92\u483c\u8399\u2bc6\ub81d\u7a64\uad2c\u519c", "\uda64\udd0f\ud841\udebf\udaf3\ude0b\ud88e\udc79\uda30\udea2\ud8a4\udf0d\ud9e3\udfc7\uda41\udc05\udb47\udfaf\udaac\ude2b\ud8a0\udcaa\ud8a9\udc1f\ud97d\udfcf\ud98e\udfdd\udb87\udd83\ud9b2\udf6f\uda67\uddd2\uda5f\udca4\ud9e8\uddd2\udac6\udc87\udb93\udcc5\udaaa\udc10\ud901\udfbc\udaa8\udc30\ud95d\udf7e",
        30, 40553, -1120491652, -6728611548279595093L, -37031L, true, false, (char) 58636, (char) 55115,
        Double.longBitsToDouble(0x3f992aa09258fb60L), Double.longBitsToDouble(0x3fe07dac52157d4dL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 5, 5, 14, "\ud8eb\udd72\ud850\udeab\u9c99", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        13, 63727, -820455680, -2116538263977818556L, -78433L, true, false, (char) 56415, (char) 1062,
        Double.longBitsToDouble(0x3fe82ecc8371858cL), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 17, "\ud872\udfee\udb07\udf4d\udace\udd69\ud939\udfbe\udb4c\ude4c\udab4\udc38", "\u18bc\u47cc\u38ed\u9913\u2cdb\u15f6\u8b52\u874a\u8019", "\uda7b\udecb\udbfd\udfb1\udbce\udd1a\udaba\udc59",
        20, 70035, -674718638, 4671761311452073861L, 41932L, false, true, (char) 29529, (char) 53499,
        Double.longBitsToDouble(0x3f97aa313a3f6740L), Double.longBitsToDouble(0x3fe2c16397a9ad2fL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud80c\udc10\uda62\uddb5\uda29\ude92\ud86c\udd73\udb7d\udfe8\uda95\udcab\ud8e6\udc40\ud8da\udefc |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 15, 12, 13, "\ud80c\udc10\uda62\uddb5\uda29\ude92\ud86c\udd73\udb7d\udfe8\uda95\udcab\ud8e6\udc40\ud8da\udefc", "\u38ed\u2a34\u54d1\u15f6\u872c", "\ud8e5\udcd2\udbe0\udc7e\u7a69\udb0c\udf82",
        11, 1462, 1259767364, -7296959702936213991L, -19194L, false, false, (char) 50956, (char) 36472,
        Double.longBitsToDouble(0x3fc8ed417ed47368L), Double.longBitsToDouble(0x3fc21856538b8de0L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 17, 3, 14, "\ud872\udfee\udb07\udf4d", "\u39fa\uc141\u712e\ub0dd\u5c2e\u47cc\u38ed\u3bd8\u35d8\u15f6\u2254\u1b01", "\ud84c\udc6b\udb05\uddfb\udbfd\udfb1\udbc5\udd8c\uda83\uddf9\ud83a\udd70\udad5\udd02\ud970\ude3a\ub590\uda5d\udff6",
        24, 40201, 1955972721, -4267548117474321638L, -30658L, true, false, (char) 61287, (char) 11811,
        Double.longBitsToDouble(0x3fe14fe675baeaf1L), Double.longBitsToDouble(0x3fc15cdc1e94b81cL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.String:\u0680\uaec5\012",
        Z.run(T, 1, 2, 11, 8, "\udbc5\udc9f\udafd\udc76\uda0a\udc9f\ud95b\udd5d\ud8dd\udcea\udab3\udffa\udb18\udd14\udbcf\udc09\ud9e8\uddeb\uda76\udf2d\u0680\ud8de\udf75\ud9f7\ude64\udaef\udee6\ud9e4\udd13\uaec5\ud897\udefd\uda3f\udf0e\ud904\ude20\udb4c\ude45\udabd\udc7e\ud940\udf2a\ud950\udd27\uda66\ude84\ud89e\udc77\udbac\udea3\uda8f\udceb", "\u3618\ua5db\u7385\u019a\u7180\u5f7d\ud22c\u3ff3\u083c\uad4c\ua6ef", "\uda0a\udedc\udb49\udefe\ud95f\uddda\ucfd2\uda93\udfb8\udb76\udc38\ud856\udd0f",
        58, 6799, 985668510, -6116757566281269349L, -11083L, true, true, (char) 9563, (char) 44775,
        Double.longBitsToDouble(0x3fae38ea793e7f10L), Double.longBitsToDouble(0x3fd9f890eb976c36L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:\u9ba6\012",
        Z.run(T, 1, 2, 17, 17, "\udbb7\uddd6\ud9c4\udc78\ud93a\udd3b\udafb\udec5\ud879\udc16\udaf7\ude7d\uda8a\ude55\uda2e\ude19\uda8a\uddf7\ud9ed\udf29\udb87\udee4\ud8b5\udf9d\ud811\ude4b\ud878\ude53\udbac\udc6f\udb84\udffe\udbb0\ude0b\udb16\udf49\udb49\udd30\u9ba6\udbe7\udcef\udb43\uddeb\ud867\udfc8\udb67\ude82\ud9fc\udf06\ud806\uddcd\ud86c\ude07\ud8ce\udf7c\ud91c\udddf\udbbd\udc87\udb2c\ude1f\ud9ad\udd05\udb01\udd28\ud9a3\udd70\ud84b\udfbc\ud89e\udc94\ud83c\udf68\uda6f\udc8b\ud9dd\ude27\udabe\udd45\uda1b\udca5\udaac\udd93\uda73\ude77\udb56\udc79\ud971\ude16\uda6d\ude4d\udb75\udff2\ud98b\udc7c", "\u02d9\u5c23\ua5f2\u1426\u67dc\ud3e2\u137d\u1aff\u8f3c\u59a7\ua33d", "\uda49\udeae\ud901\udca4\ud8d0\udcd2\udab3\udd14\ud83c\udfa9",
        52, 56126, -793757788, 123653243344717725L, -37817L, true, true, (char) 33973, (char) 4662,
        Double.longBitsToDouble(0x3fd16c9a6f948ff8L), Double.longBitsToDouble(0x3fcf948345e66be8L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 5, 17, "\uda13\udde5\ud8f7\udd56\ud85a\ude7e\udb4f\uddfe\uda79\udec3\ud84a\ude4f\udb18\udd14\udac3\udfa3\udaa9\ude27\ud9ed\udf29\udb9f\udee4\udbe2\ude06\ud8db\udf9d\udb63\udef9", "\u6c53\ub0f2\u044a\u730d\uca69\u9b7f\ua70d\u4d89", "\udaef\udd7c\udaa4\udfc7\udb7f\udd0c\udbbd\udc87\u864c\ud83f\udff0\uda58\udd66\ud915\udca7\uda09\udc8d\ud8a1\ude80\udb60\udfee\ud9b5\udd28\udbee\ude42\u1128\ud82c\udea9\ud942\udfc7\uda84\udf65\ud874\udd70",
        11, 33264, -1881910968, -5211448247588765629L, -97711L, false, true, (char) 51819, (char) 43669,
        Double.longBitsToDouble(0x3fe5fe3d9fecbcf6L), Double.longBitsToDouble(0x3fc3d570e563b3e4L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "", "\u0afb\u2109\u1118", "\uda2e\ude19\uda75\udda9\ud887\udc67\u28a9\udbaf\udcb6\udbf9\udfc0\udb3f\udd7b\ua9ac\000\ud8b4\udcfd\udb16\udf49\ud8df\ude95",
        -5, 63725, 608959744, 153562260701184L, 52639L, false, true, (char) 30668, (char) 33003,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe563e29c2a6bd2L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "\000\ud9eb\uddb4\ud93c\ude70", "\uc141\uae1e\u84d7\u1781\uad73\uc8a0\u9b8d", "\udb79\udff3",
        26, 71576, 799334523, 8483919292086637579L, -65628L, true, false, (char) 43041, (char) 51603,
        Double.longBitsToDouble(0x3fc93ae06b6a9844L), Double.longBitsToDouble(0x3fccfb320dc61630L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "\000\000\ud93c\udd78", "\uc141\uae1e\u6e9e\u1838\uad73\uc8a0\u9b8d", "\udb79\udff3",
        47, 71576, 799334523, 8483919292086637579L, -65628L, false, false, (char) 21567, (char) 51603,
        Double.longBitsToDouble(0x3fc93ae06b6a9844L), Double.longBitsToDouble(0x3fccfb320dc61630L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90\udbd5\udc34\ud965\udd60\ud8dd\udcea\udab3\udffa\u7578\u780f\uc6b7\ud9ed\udf78\u9f98\ud833\udcb8\uda47\udc62", "\000\000\000\u42ab\u4d1e\000\ub48c\u3d8e\ua514\u1f80\u5db8\u4d5a\u9d69\u7d4c\u2bc6\ua7e3\u5aa3\000\u7545\ud05b\ua9c2\u1b35", "\udaf2\udf54",
        55, 91250, 1896743122, -5770622424285343925L, -72464L, true, true, (char) 7775, (char) 40772,
        Double.longBitsToDouble(0x3fc04eb8037874a0L), Double.longBitsToDouble(0x3e37c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90\udbd5\udc34\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\ud8e0\ude4b\udb24\uddaf\ud9ed\udf78\udb9f\uded3\ud868\udd5c\uda83\udfe6", "\u7708\u873d\u9edf\u4275\ub8e6\u82f0\ub48c\u3d8e\u652c\u1f80\u5db8\u5cc2\u9e32\u7d4ca\u4289\u7a6a\u6db6\u7558\ud05b\ua9c2\u1b35", "\udaf2\udf54",
        40, 91250, 1896790482, -5770622424285343925L, -72464L, true, true, (char) 7775, (char) 40965,
        Double.longBitsToDouble(0x3fc04eb8037874a0L), Double.longBitsToDouble(0x3fd785e0c5f04f62L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90K\ud965\udd60\ud8dd\udcea\udb42\udd42\000\000\udb24\uddaf\ud9ed\udf78\u7793\ud833\udcb8\uda83\udfe6", "\u7708\u873d{\000\ua2da\u82f0\ub48c\u3d8e\u652c\u1f80\u5db8\u5cc2\u9e32\u02db\u0ce8\000\u7a64\u6db6\u089b\ub8b1\ua9c2\u1b35", "",
        29, 32815, 202193250, 8146653086210498939L, -92799L, false, true, (char) 43440, (char) 7775,
        Double.longBitsToDouble(0x3fc83de88209d700L), Double.longBitsToDouble(0x3fcbc3a515e17830L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud84c\udd43\ud92c\udd24\udbb0\udcdc\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\ud801\uddba\ud9c2\ude4c\uda0c\udc0e\udb9f\uded3\ud868\udd5c\uda83\udfe6 |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud84c\udd43\ud92c\udd24\udbb0\udcdc\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\ud801\uddba\ud9c2\ude4c\uda0c\udc0e\udb9f\uded3\ud868\udd5c\uda83\udfe6 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 12, 12, 13, "\ud84c\udd43\ud92c\udd24\udbb0\udcdc\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\ud801\uddba\ud9c2\ude4c\uda0c\udc0e\udb9f\uded3\ud868\udd5c\uda83\udfe6", "\u7708\u873d\u9edf\u4275\u1ee6\u82f0\ub48c\u3d8e\u652c\uaffc\uaed5\u8193\u7114\u7d4c\u2bc6\ub81d\u7a64\u6db6\u7558\ud05b\ua9c2\u1b35", "\udaf2\udf54",
        40, 91250, 1896790482, -5770621857349660853L, -72464L, true, true, (char) 7775, (char) 40965,
        Double.longBitsToDouble(0x3fc04eb8037874a0L), Double.longBitsToDouble(0x3fd785e0c5f04f62L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 0, 0, "\ud84c\udd43\000\000\000\000\000\udb18\udd14", "\u47cc\uc88f\000", "",
        -5, -1000, 0, 1847848566014345386L, 63309L, false, true, (char) 45159, (char) 38235,
        Double.longBitsToDouble(0x3f95ae1487ea7c40L), Double.longBitsToDouble(0x3fd561c3e193ae06L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\000\000\000\ud8bb\ude1d\ud8dd\udcea\uda89\udec3\udb18\udd14\ud8e0\ude4b\udb24\uddaf\ud926\udf78\udb9f\uded3\ud868\udd5c\uda83\udfe6", "\000\u873d\u9edf\u4275\u1ee6\u82f0\ub48c\u3d8e\u1ed0\u1f80\u5db8\u5cc2\u9e32\u7d4c\u2bc6\000\u79c1\u6db6\000\ub8b1\ua9c2\u1b35", "\udaf2\udf54",
        40, 91250, 1895872978, -5770622422859280565L, -72608L, true, true, (char) 143, (char) 0,
        Double.longBitsToDouble(0x3fc04eb8037874a0L), Double.longBitsToDouble(0x3fd785e0c5f04f62L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\udbb1\udd35\000\000\ud965\udd60\ud8dd\udcea\udb9b\udfee\ud9e7\udd7c\000\000\ud9ed\udf78\udb9f\uded3\ud868\udd5c\ud97b\udc5c", "\u7708\u873d\u9edf\u4275\u1ee6\u00ed\000\u3d8e\u652c\u1f80\u5db8\uad56\u9e32\u7d4c\u2bc6\ub81d\u7a64\u6db6\023\000\u2796\u1b35", "\udaf2\udf54",
        40, 91250, 1896790482, -5770622422859280565L, -72464L, true, true, (char) 7775, (char) 61445,
        Double.longBitsToDouble(0x3e1bc00000000000L), Double.longBitsToDouble(0x3fd785e005f04f62L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 12, 12, 13, "\ud84c\udd43\udb07\udf37\ud97d\udd12", "\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda83\udfe6\udb78\udd27\ud952\udedb\udb70\udd47\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        -5, 63725, 616474880, 1087772870896289348L, 52639L, false, true, (char) 30668, (char) 33067,
        Double.longBitsToDouble(0x3fccfb320dc61630L), Double.longBitsToDouble(0x3fe51b4989ccf90bL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\0121=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 6, 6, 13, "\ud84c\udd43\udb07\udf37\udb3e\uddf2", "\uc141\uae1e\u6e9e\ud37a\u47cc\uc8a0", "\uda1d\ude99",
        42, 53862, 450633576, 3433115636824076206L, 63309L, false, true, (char) 45159, (char) 38235,
        Double.longBitsToDouble(0x3f95ae1487ea7c40L), Double.longBitsToDouble(0x3fd561c3e193ae06L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 10, 10, 13, "\ud9ab\udd7b\ud93a\udd32\ud9f5\udc09", "\uc141\ud008\ucaeb", "\udb9f\udebf",
        36, 96604, 1536377140, -2102150045403017746L, -78408L, true, true, (char) 8186, (char) 45166,
        Double.longBitsToDouble(0x3fe22078c415ae14L), Double.longBitsToDouble(0x3fafa9f15561c3e0L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 7, 6, 0, "\000\000\000", "\u4f69", "\udafa\uddf8\ud889\udc00\000\ud868\udcb8\uda83\udfe6\udaa2\udd3c\000\000\ud8b4\udcfd\000\000\000\000\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud9e6\udd06",
        26, 49708, -1509887529, 240629837725696L, 31072L, true, true, (char) 19575, (char) 27903,
        Double.longBitsToDouble(0x3fbe0b1b3b530a30L), Double.longBitsToDouble(0x3fea2883f4235da5L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 8, 10, "\ud9c7\udca6\udb07\udf37\uda58\udebf", "\ua882\u6e56\u6e42", "\uda70\ude6b\ud830\udfe1\uda4a\udf5f\uda0d\udf4d\udbbb\udc13\udb84\udfb8\ud8b4\udcfd\udb16\udf49\ud8df\ude9e",
        31, 59327, 616474880, 1087772870896289348L, 55447L, false, false, (char) 48759, (char) 59510,
        Double.longBitsToDouble(0x3fe51fd266ccf90bL), Double.longBitsToDouble(0x3fe553b57a9f387dL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:\u6b23\012",
        Z.run(T, 1, 2, 6, 17, "\ud84c\udd43\u6b23\udae1\udc66", "\u9ccb\uae1e\u6e9e\u8dea\u7b9f\u5a08\u2903\u1f85\u9f79\uc189\u7708\u65c2\ub129\u3339\u9285\u8216\u5c32\u4237\u822a\u05d0\u5dd2\u5cc2\u9e32\u7d4c\u2bc6\ub81d\u9c9f\u8564\u9e7e\ub023\u0e67\u2b51\u0659\uccf7\ua475\uc416\u878d\u489b\u9cc9\u8b89\u5abc\u7fbe\u32ba\u7889\u076b\u81bd\u7b8b\u97e3\ua38b\uc5ba\u0339\ub10a\ua4e2\u1104\u3dc8\u2e64\u9c98\u2099\u0804\uc997\u479f\u0104\u644e\uaafab\uc6e3\u08bb\u0404\u3ccc\u6d5d\u1314\u2730\u2bd5\u13ee\u3532\u87db\u3f32\u0de8\u5185\u284e\u9560\ub1da\u99ff\u0df2\u8534\ucf96\ub8b4\u64ac\u253d\u8e2f\u638c\u7377\u4b2f\u584a\ucf9e\u7646\u7430\u61d6\u49d2\u64a9\ua5ae\uac67\u0c10\u91af\u542d\uc889\u6884\uaa51\u912a\u9d77\u486d\ua15c\ud416\u8c9f\u2a34\u68d3\u1c1b\u1be1\ud707\u8add", "\ud96b\uded2\ud8f4\udebb\udbf2\uddab\uda2e\udc02\ud9a2\udfc7\udb7f\udceb\udb85\ude45\ud841\udf05\ud831\udf5c\uf920\ud96d\udcff\ud903\udfba\ud823\udefc\ud98b\udc97",
        4, 73580, -897778600, 1173400520575140643L, 21279L, false, true, (char) 45032, (char) 56845,
        Double.longBitsToDouble(0x3fe887ff0ee892d0L), Double.longBitsToDouble(0x3fe5a7d5f2339605L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 2, 6, 17, "\000", "\uaa12", "\000\uda2e\uddb9",
        20, 57047, -1380140152, -788529152L, 98316L, false, true, (char) 65174, (char) 3726,
        Double.longBitsToDouble(0x3fed717d250b75bcL), Double.longBitsToDouble(0x3fe24608f800de16L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud817\ude7a\udb07\udf37\ud9f5\udc6d |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud817\ude7a\udb07\udf37\ud9f5\udc6d |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 12, 12, 17, "\ud817\ude7a\udb07\udf37\ud9f5\udc6d", "\u4ffb\uae1e\u6e9e\ud37a\uae89\u6c34\u9b8d\u1bb6\u15bd\u6718\u7708\u873d", "\ud932\udf58\udb92\udf85\udac2\udc8b\udb01\udcf1\u7782\ud9e6\udda8\ud82b\udde9\uda96\udeeb\ud8ce\udf7c\ud870\udc96\uda89\uddaf\udbfe\udda3\ud806\ude3a\udbde\udc37\udb74\udf15\udbdb\udf81\udb5a\udf34\ud9c1\uddaa\udbdd\udca7\ud898\udc2c\uda70\udf4a\uda1a\udd21\ud9c6\ude90",
        0, 25178, 897854476, 7730387376594947384L, -12978L, false, true, (char) 24598, (char) 54123,
        Double.longBitsToDouble(0x3fec19590f387acdL), Double.longBitsToDouble(0x3fe8ba8c9168ba8eL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\uca16\u1f79\u1912\u4ffb\uae1e\u6e9e\ud37a", "\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb84\udffe\ud8b4\udcfd\udb16\udf49\ud8df\ude9e\ud932\udf58\udbe7\udcef\ud940\udf2a\u8baa\000\ud88b\udce4\ud82b\udde9\uda96\udeeb\ud8ce\udf7c\ud870\udc96\uda89\uddaf\udbfe\udda3\uda98\udea3\000\udb65\udcb2\udbd0\udd81\udb5a\udf34\ud9c1\uddaa\udbdd\udca7\ud898\udc2c\ud83b\udd0e\uda1a\udd4a\ud9c6\ude90\ud93e\udc5e",
        53, 88448, 1799871069, -7630490611459555097L, -43148L, true, true, (char) 54123, (char) 11041,
        Double.longBitsToDouble(0x3fe9c3d668005192L), Double.longBitsToDouble(0x3fd000000fa9823cL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 4, 4, 14, "\ud9c4\udc9e\udb07\udf37\ud9f5\udc6d\ud81a\udffa", "\uadc8\u6e9e\ud37a\uae89", "\uda83\udfe6\uda1d\ude99\udae7\udfea\udb84\udffe\ud8b9\udf67\udb16\udf49\udaba\udd4d\u2593\udb5b\udccf\ud801\ude9f\udaeb\udc8d\u7782\uda05\udda8\ud82b\udde9\uda96\udeeb\ud8ce\udf7c\ud870\udc96\uda89\udda0\udbfe\udda3\ud806\ude3a",
        -3, 69195, 118763098, 4423284184439192009L, 64300L, true, false, (char) 26690, (char) 58619,
        Double.longBitsToDouble(0x3fe453bc39d21360L), Double.longBitsToDouble(0x3f891e70974d6100L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 3, 6, "\ud84c\udd43\udb07\udf37\ud82f\udc6a", "\uc141\uae1e\u6e9e\ud37a\u75b9\uc8a9\u9b8d\u1bb6\u34d9\u6718\u7708\u98cd\ub0f2\u3339\ub233\u382f\uc962\u65bc\u2fda\u1f80\u4e6f\ub42d\u2141\u7d4c\u2bc6\u31c3\u26a3\u3de8", "\udbde\udd3d\udb93\ude05\ud9d0\udf2b\udbe0\udce5",
        38, 51735, 63029728, -6473554560991619718L, -8098L, true, false, (char) 9169, (char) 35695,
        Double.longBitsToDouble(0x3fd32e6528ec90e8L), Double.longBitsToDouble(0x3fdd4e00be89ddecL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 7, 7, 9, "\u63ea\udadd\udffc\ud932\udf4c", "\u17fd", "\ud8d3\udd3b\ud9ed\udfe5\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99",
        42, 53862, 450633576, 3433115636824076206L, 63309L, false, true, (char) 45159, (char) 39250,
        Double.longBitsToDouble(0x3f95ae1487ea7c40L), Double.longBitsToDouble(0x3fd950c594bae432L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 7, 11, 9, "\udb60\ude42\udbc0\ude25\udbdd\udf70\ud8ee\udd00\uda83\udc8d\ud86f\ude5a\udb18\udd1d\uda2f\ude60\uee18\ud9f3\udc89\udb9f\udee4\ud868\udd5c\uda83\udfe6\uda1d\ude99\udb79\udff3\udb18\udee5\uda7a\udce6\udb16\udf49\ud8df\ude9e\ud932\udf58\udbe7\udcef\ud8ee\udc10\udaf9\udc42\ud876\udd6a\ud9e6\udd12\udac2\udc35\ud8f6\udda9\uda61\udfbe\ud9d6\udcc2\ud90a\ude84\ud922\udd7e\ud8c1\udf5c", "\uc76b\u8000\u7c16\ua262\u8dab\u5a4a\u3245\ubf47\uc49f\u9fb1\u03aa\ub31f\u9691\u5d09\u6db6\ub1d5\u394d\u4782\u611d\u820b\ucc85\u8941\u2d75\u51a7\ud207\u4e8f\u607e\ud023\ubd9f\u546b\u4b78\u66e8\u647b\ucf74\u3968\u11a1\ucf7e\u2115\u782e\u5b87\u4373\ua3dd\ubd83\u7244\u47f9\u1001\uc092\u3656\u2186\ubac0\uab44\u266d", "\udbfe\udd05\uda76\ude5a\udb6d\udc27\uda0a\ude3a\ud9f1\udc9b\ud814\udc4c\ud929\udf17",
        37, 63103, 1621034558, 5817668573721203609L, -10868L, true, false, (char) 27469, (char) 2969,
        Double.longBitsToDouble(0x3fda74bc9363adeeL), Double.longBitsToDouble(0x3fed73e0e5fa739eL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 13, 13, "\udaf5\udfc2\uda87\udedb\uda6a\udf56\ud8e9\ude0b\ud8ee\udc76\udab3\udffa\udb18\udcf8\uda2e\ude19\udafa\udeaf\ud9ed\udf78\udb9f\udee4\ud893\ude93\ud952\uddb3\uda1d\ude99\ud928\udfaa\udb73\udfff\udace\udfe0\udb16\udfc7P\ud932\udf58\udbe7\udcef\uda02\udfcc\udbec\udd3d\ud83a\udd70\ud9a6\udcfa\ud945\udd80\uda96\udf6b\ud8ce\udf7c\ud8bc\udc9c\uda89\uddaf\udb85\ude5a\ud806\ude8e\uda54\udc92\udb82\uddaa\udb1f\udd89\ud924\uddb4", "\u426b\u35f7\u24a9\u0b3e\ua1fb\u5f66\u9fce\u8ff9\ud118\u9efa\u1dfa\u5fe9\u712d\ucd1c", "\udaee\udc6d\ud937\uded7\udbf4\udd31\udbd6\udcaf\ud846\udfc1\ud8a6\udf16\udbb9\ude0c\udacc\udc10\ud8fb\udc83\udbcb\udd6a\ud988\udece\udbd3\udd0c\ud821\udf21\udb0b\ude52\u52d5\udac5\udd22\ud8ad\udef8\udb68\udda3\udbb8\ude2c\uda4b\ude21\ud97c\udee7\ud83b\ude19\udb31\udc90\ud8d8\udf3d\ud83f\udcc4\ud861\udead\uda0e\udde8\udb1e\udfb7\uda01\udd3f\ud913\udd4c\ud85d\udd50\udbc6\ude1e\ud98a\udd20\uda06\udd96\udb67\udc66\ud885\ude3e",
        3, 32450, 1843266329, 6454617192500326326L, -79977L, false, true, (char) 57653, (char) 2073,
        Double.longBitsToDouble(0x3fc20562a734f8fcL), Double.longBitsToDouble(0x3fe89091769f27dbL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 13, 11, "\000", "\u3a3e", "\ud9e7\udd60\000",
        34, 56710, -212502620, 5770470824656630660L, -38642L, true, false, (char) 31720, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f95ae009ef01fe0L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 2, 0, 0, "", "\ub991\u3a3e\u397a\uc141\uae1e\u6e9e", "\udb9f\udee4\ud868\udd5c\uda47\udc62\uda1d\ude99\udb79\udff3\u00ee\ud8ac\udd95\udb16\udf49\ud84d\udee5",
        -5, 98642, 12495104, -1374386688L, -100000L, false, false, (char) 41160, (char) 0,
        Double.longBitsToDouble(0x3e3b8c2c60000000L), Double.longBitsToDouble(0x3fe51b498eccf90bL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.String:\u4ec8\012",
        Z.run(T, 1, 2, 8, 5, "\u4ec8", "\u3a3e\u39fa\uc141\ub7e5", "\ud9ed\udf78\udb36\udd3e\ud881\ude86\uda34\udfe6\uda2d\udf56",
        47, 53862, -1701818264, 162651090086274657L, 63309L, false, true, (char) 45190, (char) 4956,
        Double.longBitsToDouble(0x3f95ae5a6ecfcd80L), Double.longBitsToDouble(0x3fd27c1b419243bcL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 17, "\000\000\ud82a\udf15\udb4f\uddfe\ubebf\ud84a\ude4f\udb18\udd14\udac3\udfa3\u9be7\000\u7700\000\000\u7217", "", "\udb49\udd30\udb8b\ude22\uda25\udcaa\udb44\uddbf\ud907\udee9\ud8a0\uddcb\ud82e\udeff\ud837\udf8c\udaef\udd7c\ua0c9\000\000\u00a6\udae2\uddb1",
        7, 70028, 554404507, -8290628525949744176L, -75304L, true, true, (char) 44647, (char) 43263,
        Double.longBitsToDouble(0x3fe009486c9917a3L), Double.longBitsToDouble(0x3fc58a446501aaf8L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 13, 8, "g\ud9eb\uddb4\ud93c\ude70", "\uc141\u4acd\ua36c\u9f6a\u2bf8\uceea\u9b8d", "\udb79\udff3",
        26, 71576, 799334523, 8483919292086637579L, -65628L, true, false, (char) 43041, (char) 51603,
        Double.longBitsToDouble(0x3fc93ae06b6a9844L), Double.longBitsToDouble(0x3fd4655903827a9aL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "\014\ud9eb\uddb4\ud93c\ude70", "\uc141\uae1e\u84d7\u1781\uad73\uc8a0\u9b8d", "\ud87c\udf7c",
        26, 71576, 799334523, 8483919292086637579L, -65628L, true, false, (char) 43041, (char) 51603,
        Double.longBitsToDouble(0x3fc93ae06b6a9844L), Double.longBitsToDouble(0x3fccfb320dc61630L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "S\000\ud93c\udd78\ud9d1\uddaf\ud90a\udff8\ud989\udce6\udb05\udf86\uda2e\ude19\uda8f\uddb1\ud887\udc67\udb9f\udee4\ud863\ude1b\uda99\ude8c", "\u7708\u873d\u995c\u83b3\u10dc\u82f0\uc804\u3d8e\u465c\000\u5db8\u5cc2\u9e32\u2442\u2bc6", "\uda69\udecc\ud9be\udd0f\udab7\udc80\uda81\udeb1\udb66\udfd4\udaa3\udee5\ud909\ude08\u6ce9\ud82a\udc60\ud8ee\udef5\uda36\udc54\ud815\udc0f\ud875\udea0",
        32, 40079, -437884584, -5428190717371490869L, 85236L, true, false, (char) 44175, (char) 41583,
        Double.longBitsToDouble(0x3feffc49c8bdd39cL), Double.longBitsToDouble(0x3fea49f60113dec5L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "A\000\ud93c\udd78", "\uc141\uae1e\u6e9e\u1838\uad73\uc8a0\u9b8d", "\udb79\udff3",
        47, 71576, 799334523, 8483919292086637579L, -65628L, false, false, (char) 21567, (char) 51603,
        Double.longBitsToDouble(0x3fc93ae06a92ffb8L), Double.longBitsToDouble(0x3fccfb320dc61630L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 1, 6, 16, "\001\000\ud93c\udd78", "\u5154\u6ac8\u6e9e\u1838\uad73\ub0f9\u9b8d", "\ud8b8\ude7f",
        54, 97445, 799334523, -8887257877979091993L, -68833L, false, false, (char) 54083, (char) 45313,
        Double.longBitsToDouble(0x3fe2912e9adaa611L), Double.longBitsToDouble(0x3fccfb320dc61630L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 0, 7, "\000\002\ud93c\udd78", "\uc141\uae1e\u6e9e\u1838\uad73\uc8a0\uba6c", "\udb79\udff3",
        47, 71576, 799334523, 8483919292086637579L, -65628L, false, false, (char) 21567, (char) 51603,
        Double.longBitsToDouble(0x3fc93ae06b6a9844L), Double.longBitsToDouble(0x3fccfb320dc61630L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 17, 0, "\022\000", "\u1909\uc141\uae1e", "\ud8ee\udd12\udb9f\udee4\ud868\udd5c\udbf9\udfc0\udb74\udd7b",
        42, 53862, 450633576, 3433115636824076197L, 63309L, false, true, (char) 45044, (char) 38235,
        Double.longBitsToDouble(0x3e94df4000000000L), Double.longBitsToDouble(0x3f98a73e6a642b80L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.String:\u78d7\u7733\u554b\0121=java.lang.String:\u78d7\u7733\u554b\012",
        Z.run(T, 2, 2, 2, 1, "\ud818\udc88\ud948\udfc2\udbf0\udc6d\ud965\udd60\ud8dd\udc67\udab3\udffa\udb78\udcc4\u78d7\udbb8\udda4\udb90\udfc1\u7733\ud81d\udfa5\u554b", "\000\u6cbf\u44de\ud2ed\u7b94\u00a4\u7ba8\ua86f\ua514\u109e\ua229\u2cc3\u0540\u751f\uca85\ud040\u8288\u64e5\u7545\ud05b\ua9c2\ua8fc\u5b6c\u1c62\u3b20\u7d6e\u37a8\u75eb\u8740\u5b39\u088a\u6a1f\u6330\u74e0\u93f8\u5b11\u00de\000\u7082\ua1f1\uccc6\u9d50\ub484\u0ce2\u1c2b\u58eb\u51e9\u3509\u86af\ub68e", "\ud8cc\udc08\uda2e\ude0e\ud8f3\uddd7\ud9b6\udfab\udb5f\udcb7\ud958\udf74\udb5e\udc8f\ud827\udc15\ud99d\udd01\uda25\udf4b\udb23\udf9b\ud961\udf3b\ud803\udde1\uda7d\ude69\ud956\udc51\udaf3\udf71\ud93d\udfa6\ud8c5\ude12\udbfc\udf63\udafb\ude2a\ub468",
        51, 62436, -1067923961, 4923355438839913351L, 11003L, false, false, (char) 2897, (char) 17769,
        Double.longBitsToDouble(0x3fb7658b2401cce8L), Double.longBitsToDouble(0x3fb63cb3ba8c82f8L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90\udbd5\udc34\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\ud8e0\ude4b\udb24\uddaf\ud9ed\udf78\udb9f\uded3\ud868\udd5c\uda83\udfe6", "\u7708\u873d\u9edf\u4275\ub8e6\u82f0\ub48c\u3d8e\u652c\u1f80\u7f19\u366c\u5c8c\u7d4ca\u4289\u7a6a\u0ee6y\ud05b\ua9c2\u062c", "\udaf2\udf54",
        40, 91250, 1896790482, -5770622424285343925L, -72464L, true, true, (char) 63064, (char) 11607,
        Double.longBitsToDouble(0x3fc6accb037874a0L), Double.longBitsToDouble(0x3fd785e0c5f04f62L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udaf1\udf18\uda17\ude36\ud9ea\ude7e\ud8dd\udcea\udab3\udffa\uda8c\ude2f\uda83\udc2a\ud8cd\udcbe\ud9ed\udfc3\ud95f\ude1c\ud868\udcd1\uda83\udfe6", "\u1968\u871d\030\u1eb6\ub8e6\u82f0\ub48c\u3d8e\u2bbb\ub579\u5db8\uac2a\u3b11\u7d4ca\u9290\u7a6a\u6db6\u454a\u6a6e\ub517\u207f", "\uda00\udf6a\udb01\uded3\udb3a\ude17\uda84\udc7b\udbac\udf47\ud8b0\ude51\uda7d\udce3\ud93e\udd8d",
        4, 27336, 1975562433, 2101176076696565982L, 54360L, false, false, (char) 60837, (char) 53955,
        Double.longBitsToDouble(0x3feec1f27e0c79edL), Double.longBitsToDouble(0x3fec767d5c0eebd9L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90\udbd5\udc34\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\ud8e0\ude4b\udb24\uddaf\ud9ed\udf78\udb9f\uded3\ud868\udd5c\uda83\udfe6", "\u7708\u873d\u9edf\u4275\ub8e6\u82f0\ub48c\uae71\u652c\u1f80\u5db8\u5cc2\u1f62\u1001h\u4289\u0dad\u7b8e\u7558\ud05b\ua9c2\u1b35", "\udaf2\udf54\udb01\uded3\udb3a\ude17",
        -3, 24267, -1416523957, 6606749725870549904L, -95440L, true, false, (char) 22082, (char) 22022,
        Double.longBitsToDouble(0x3fd785e0c5f04f62L), Double.longBitsToDouble(0x3fece4fb3e829475L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90K\uda31\ude97\ud8dd\udcea\udb42\udd42\uda23\udf30\000\udb24\uddaf\ud9ed\udf78\u7793\ud833\udcb8\uda83\udfe6", "\u7708\u9fa8g\000\ua2da\u82f0\u398a\u3d8e\u652c\ub063\u5e03\u5cc2\u9e32\u02db\u0ce8\000\u7a64\u7357\u0955\ub8b1\ua9c2\u1b35", "",
        6, 13630, 1903692064, 8146652708253376891L, -92799L, false, true, (char) 43440, (char) 7775,
        Double.longBitsToDouble(0x3fc83de88209d700L), Double.longBitsToDouble(0x3fcbc3a515e17830L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90\020\ud965\udd60\ud8dd\udcea\udb42\udd42\000\000\udb24\uddaf\ud9ed\udf78\u7793\ud833\udcb8\uda83\udfe6", "\u7708\u873d{\000\ua2da\u82f0\ub48c\u3d8e\u652c\u1f80\u5db8\u5cc2\u9e32\u02db\u0ce8\000\u7a64\u6db6\u089b\ub8b1\ua9c2\u1b35", "\udb0b\ude22",
        40, 91250, 1896790482, -5770622424285343925L, -72464L, true, true, (char) 7775, (char) 40965,
        Double.longBitsToDouble(0x3fc04eb8037874a0L), Double.longBitsToDouble(0x3fd785e0cb1f6f60L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 3, "\ud84c\udd37\udbe1\ude90\ud841\ude61\ud8f9\udf53\uda2b\ude9d\uda13\udcaf\031\000", "\uc9f1\ub6b8\u955c\u4d58\u6718\u6d41\u2270\u0722\u6658", "\ud940\udf2a\ud9af\udd4e\ud84a\udc92\ud9e6\udd06\uf600\uda96\udc30\udb71\udecc\udbee\udc47\uece7\000\ud806\ude3a\ud958\udff5\udacf\udc19\ud9ea\udcd4\ud848\udddf\ud8be\udfc5\000\000\udaf2\udf54\udb01\uded3\udb3a\ude17\uda84\udc7b\udb37\udcc2\ud8b0\ude51\ud8ca\udd46\ud92b\udd97\ud9de\udc02\uda0c\udcd3\ud9cf\udfb1\udba8\ude39\udb65\ude68\udb03\udfd3\uda53\uddd7\ud97e\ude57\udbaf\udcdb\udab5\udc61",
        12, 99425, 940054153, -804650155589879182L, -78724L, true, false, (char) 20549, (char) 63217,
        Double.longBitsToDouble(0x3fe7ed9df5d20ebaL), Double.longBitsToDouble(0x3fe460d67d1a4b61L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\ud9c7\udd02T\ud965\udd60\ud8dd\udcea\udb42\udd42\000\000\udb2c\ude29\ud9ed\udf78\u7793\ud833\udcb8\ud910\udc0c", "\u7708\u873d{\000\ua2da\u82f0\ub48c\u3d8e\u65bd\u1f80\u5db8\u5cc2\u9e32\u02db\u0ce8\000\u40c8\u01d4\ub8a6\u1f3d\ua9c2\u1b35", "\uda1a\udfe0\ud9f3\ude7c\udb69\uddd0",
        -3, 23387, -1414055514, -8883090380234665403L, -95440L, true, false, (char) 22082, (char) 22022,
        Double.longBitsToDouble(0x3fd785e0c3b8b292L), Double.longBitsToDouble(0x3fd24df5ea82bfccL)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\000K\000\000\000\000\000\uc6b7\ud9e6\udf78\u7793\ud833\udcb8\uda83\udfe6", "\u7708\u873d{\000\ua2da\u82f0\u0b8c\u3d8eD\u1f6b\u5db8\u5cc2\u9e32\u02db\u0ce8\000\u79c1\u6db6\u189a\ub8b1\ua9c2\u1b35", "",
        29, 11111, 201326592, 8146653086210498939L, -92799L, false, true, (char) 34667, (char) 7775,
        Double.longBitsToDouble(0x3fc83de88209d700L), Double.longBitsToDouble(0x3f1d280000000000L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 0, 0, "\uda64\ude77\003\000\udaa0\udcbc\uea9b\ud87c\udd65\udb18\udcfa", "\u70d6\uc88f\000", "\u7303\000\000\udb7e\uddfd\u00aa\ud91d\udf4d\udbe7\udcef\ud940\udf2a\ud8bd\udcb7\ud83a\uddf5\ud9e6\udd06\ud844\udde9\uda96\udeeb\udb12\ude1e\uda7b\udefc",
        21, 93872, -1417311782, 6254189950724213950L, -15089L, false, false, (char) 3671, (char) 41309,
        Double.longBitsToDouble(0x3febfd2a9cc7188bL), Double.longBitsToDouble(0x3fdfc9f48bcdd972L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 10, 0, "\ud80e\udd44\ud8f2\udf98\005\000\000\000\udb18\udd14", "\u3b58\uc88f", "",
        24, 70579, 1635232656, 600301095291L, -100000L, false, true, (char) 8186, (char) 45159,
        Double.longBitsToDouble(0x3fe22078c415ae14L), Double.longBitsToDouble(0x3feedaad56b3f251L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 0, 0, "\ud84c\udd43\000\000\000\000\000\udb18\udd14\ud807\ude3e\udb0c\ude8c\ud9ed\udf78", "\000\000\000\000\000\u9edf\u6baa\ua2da\u82f0\ub48c\u3d8e\u652c\u3f34\u5db8\uc7b4\u9c19+\u99ee\u110c\u1ac9\u2be0", "\udbdf\udee0\udb3f\udd35\ud8be\udf7d\ud812\udefc",
        46, 62463, -1337800896, -2182413113406371712L, 60527L, true, false, (char) 8639, (char) 38709,
        Double.longBitsToDouble(0x3fea9d4b064c6a01L), Double.longBitsToDouble(0x3fec892abdbe4181L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\udbb1\udd35\000\000\ud965\udd60\ud8dd\udcea\udb9b\udfee\udad2\udd71\004\000\uda8c\udfa7\udb9f\ude99\ud868\udd5c\ud97b\udc5c", "\u7708\ub347\u9edf\u4275\u1ee6\u08ae\u6542\u3d8e\ua589\u3b44\u43de\uad56\ubc8d\u51e0\u2bc6\ub81d\u7a64\u6db6\023\u8471\u2841\u1b35", "\udb08\udea1",
        40, 39110, 1575177653, -5770622169456210101L, -72464L, true, true, (char) 15661, (char) 1590,
        Double.longBitsToDouble(0x3e36f00000000000L), Double.longBitsToDouble(0x3fd786cd07d64f62L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\udbb1\udd35\000\ud985\udc62\ud965\udd60\ud902\udc12\udb9b\udfee\ud9e7\udd7c\000\000\ud9ed\udf78\udb9f\uded3\ud868\udd5c\ud8b1\udf78", "\u7708\u873d\u9edf\u4275\u1ee6\u8d82c\u3d8e\u652c\u25ea\u5db8\u4bfe\u9e32\u7d4c\u2bc6\u3a59\u7a64\u6db6\u5226\000\u2796\u1b35", "\udaf2\udf54",
        40, 91250, 1896790482, 4888834945173262123L, -72464L, true, true, (char) 7775, (char) 61445,
        Double.longBitsToDouble(0x3e1bc00000000000L), Double.longBitsToDouble(0x3fd785e004460b62L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 17, "\uda2f\ude53\015\000\udbe4\udc7f\ud8dd\udc9c\udb9b\udfee\ud9e7\udd7c\000\000\ud817\udf2d\udad0\udd2e\ud9da\ude72\ud97b\udca0", "\u2755\u337c\u67b8\u71b9\u0a0c\u17a2\u8199\uac45\u0c51\u1f8d\u5db8\uad56\u9e32\u86d2\u2bc6\u8bab\u8ffd\u17b0\u6e56\uaf19\u2880\u1bfe", "\uda98\udd2b",
        35, 90578, 644897869, -5829375191761711285L, 59002L, true, true, (char) 7775, (char) 61445,
        Double.longBitsToDouble(0x3e1bc00000000000L), Double.longBitsToDouble(0x3fd785e005f04f62L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 7, 6, 5, "\u0096\000\000", "\u1378", "\udafa\uddf8\ud889\udc00\000\ud868\udcb8\uda83\udfe6\udb6c\udc21g\000\ud8b4\udcfd\u5e63\udb4e\udee6\ud825\udcdb\u5eac\ud940\udf2a\udaeb\udc8d\udb52\ude5b\ud9e6\uddb8",
        26, 37497, -1509887529, 240629837725780L, 31072L, true, true, (char) 19575, (char) 27903,
        Double.longBitsToDouble(0x3fd4e2c6ced4c28cL), Double.longBitsToDouble(0x3fea2883f5d85da5L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 7, 6, 0, "\ud9af\udfad\uda30\udd25\ud981\udd4a\013\ud982\udff0\uda0d\udce2\ud8f5\udea2\udbce\ude33\udb8e\udcb7\ud8af\udef0\u2f91\ud868\udcb8\uda83\udfe6\ud950\udf94\udaeb\udcf9\u00ed\udbbb\udc0a\ud884\udca2\ud80d\udc94", "\u3e6a\u9a02\uaced\uc8a6\ubfce\u734b\uc315\u02db\000\u7710\u85ea\u053f\ua9e0", "\udb5c\udc57\ud88c\udc77",
        57, 51505, 1343588389, 2430996424684642633L, -60994L, false, true, (char) 40250, (char) 22102,
        Double.longBitsToDouble(0x3fe60b8859686c2dL), Double.longBitsToDouble(0x3fd87794f9582cf4L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 17, 0, "\udaf5\udfc2\uda87\udedb\uda6a\udf56\ud8e9\ude0b\ud8ee\udc76\udab3\udffa\udb18\udcf8\uda2e\ude19\udafa\udeaf\u0086\udb77\udf3b\ud893\ude93\ud952\uddb3\uda1d\ude99\ud928\udfaa\udb73\udfff\udace\udfe0\udb16\udfc7P\ud932\udf58\udbc7\udf02\uda02\udfcc\udbec\udd3d\ud83a\udd70\ud9a6\udcfa\ud945\udd80\ud8ad\uddd6\ud8ce\udf7c\ud8bc\udc9c\uda89\uddaf\udb85\ude5a\ud806\ude8e\uda54\udc92\udb82\uddaa\udb1f\udd89\ud924\uddb4", "\u426b\017\u23b8\u0b3e\ua1fb\u5f66\u9fce\u8ff9\ud118\u9efa\u1dfa\u5fe9\u712d\ucd1c", "\udaee\udc6d\ud937\uded7\udbf4\udd31\udbd6\udcaf\ud846\udfc1\ud8a6\udf16\udbb9\ude0c\udacc\udc10\u00ee\000\ud9d9\udc6b\udbd3\udd0c\ud821\udf21\udb0b\ude52\u52d5\udac5\udd22\ud8ad\udef8\udb68\udda3\udbb8\ude2c\uda4b\ude21\ud97c\udee7\ud83b\ude19\udb31\udc90\ud8d8\udf3d\ud83f\udcc4\ud861\udead\uda0e\udde8\udb1e\udfb7\uda01\udd3f\ud913\udd4c\ud85d\udd50\udbc6\ude1e\u4344\000\udb67\udc66\ud885\ude3e",
        3, 32450, 1843266329, 6454617192500326326L, -79977L, false, false, (char) 57543, (char) 2073,
        Double.longBitsToDouble(0x3fc20562a734f8fcL), Double.longBitsToDouble(0x3fe89091769f27dbL)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 17, "\000", "\u9a0e", "\udb18\udd14\udac3\udfa3\u9be7\000\u7700\000\000\u7217\000\000\udbb0\ude0b\000\udb49\udd30\udb8b\ude22",
        -3, 63858, -1189573865, -5902496591974736363L, -100000L, false, false, (char) 166, (char) 0,
        Double.longBitsToDouble(0x3fe524a80044eaf6L), Double.longBitsToDouble(0x3fe4de15ad48210bL)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:g\ud9eb\uddb4\ud93c\ude70 |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:g\ud9eb\uddb4\ud93c\ude70 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 13, 13, 8, "g\ud9eb\uddb4\ud93c\ude70", "\uc141\u4acd\ua36c", "\udba1\udd2e\ud96f\udcd1\u3165\uda0b\udde0\udaa1\udc4a\udb61\ude3f\ud8b4\udcfd\udb16\udf49\ud8df\ude95\ud932\udf58\ud882\udcfd\uda47\udf65\ud9e8\udeb0\ud83a\udd70\ud9e6\udd06",
        27, 83126, -1508794167, 6165668520736440646L, -14604L, false, true, (char) 22789, (char) 41913,
        Double.longBitsToDouble(0x3fe04d8302c91667L), Double.longBitsToDouble(0x3fea655d4d074b5aL)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 13, 8, "\006\ud9eb\uddb4\ud93c\ude70", "\uc141\u4acd\ua36c\u9f6a\u2bf8\uceea\u9b8d", "\udb79\udff3\udb61\udefe\ud8b4\udcfd\ud848\udd1d\ud9b4\ude98\ud9b3\ude09\ud95f\udd16\uda47\udf38\udaeb\udc8d\ud8b7\udc34\ud9c4\udf00\ud846\udd25\uda96\udeeb\ud8ce\udf7c\udb8d\udfe4\udb6b\udce2\uda63\uddef\ud83d\udf02\ud9b5\ude2e\u5b9d\udb48\udcd6\udbb6\ude5f\ud8a2\uddc5\uda85\udff1\udadd\udd86\u486b",
        5, 3198, -217051627, 4134237893659248101L, 34829L, false, false, (char) 5419, (char) 57650,
        Double.longBitsToDouble(0x3fe6652dc125a87aL), Double.longBitsToDouble(0x3fb4eb3755da90b0L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.String:B |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "B\000\ud93c\udd78\ud9d1\uddaf\ud90a\udff8\ud989\udce6\ud949\ude07\udb4e\udeae\uda8f\udd4e\ud887\udc67\udb9f\udee4\ud863\ude1b\uda99\ude8c", "\u7708\u873d\u995c\u83b3\u10dc\u82f0\u4ed5\u808d\u62dc\u93fc\u5db8\u5cc2\u9e32\u4075\u2bd4", "\uda69\udecc\ud9be\udd0f\udab7\udd79\uda81\udeb1\udb66\udfd4\udaa3\udee5\ud909\ude08\u6ce9\ud82a\udc60\ud8ee\udef5\uda36\udc54\ud815\udc0f\ud875\udea0",
        32, 40079, -437884584, -5428190717371490869L, 81301L, false, false, (char) 44798, (char) 41583,
        Double.longBitsToDouble(0x3feffc49c8bdd39cL), Double.longBitsToDouble(0x3fea49f60113dec5L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "S\000", "\u1909\u3a70\u6490", "\ud887\udc67\udb9f\udee4\ud863\ude1b\uda99\ude8c\udb74\udd7b",
        42, 53862, 450633576, 8808443265244086520L, 63309L, false, true, (char) 45044, (char) 38235,
        Double.longBitsToDouble(0x3e9487e000000000L), Double.longBitsToDouble(0x3fd561c3e193ae06L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.String:A |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 7, 14, "A\u7100\udb6b\udda4", "\uc141\uae1e", "\ud887\udc67\udb9f\udee4\ud868\udd5c\udbf9\udfc0\ud8f1\udf6b",
        52, 96953, -1216072829, 3407760013924298661L, -67763L, false, false, (char) 64433, (char) 38328,
        Double.longBitsToDouble(0x3e9487e000000000L), Double.longBitsToDouble(0x3fd561c3e469ae06L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 1, 6, 16, "\010\000\ud93c\udd78", "\u5154\u6ac8\u6e9e\u1838\u035c\u47ab\u9b8d", "\ud977\udcde",
        12, 97555, 799334523, -8887257877979091993L, -68833L, false, false, (char) 54083, (char) 45313,
        Double.longBitsToDouble(0x3fe3c8a69adaa611L), Double.longBitsToDouble(0x3fccfb2e6dc61630L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 1, 6, 16, "\025\000", "\u2689\u5154\u152f", "\ud887\udc67\ud929\udee9\ud868\udcfd\udbf9\udfc0\udb45\udf4e",
        -4, 92125, 450659445, 3433115632779533836L, -936L, false, true, (char) 44808, (char) 26322,
        Double.longBitsToDouble(0x3f9c6b0f08d11fa0L), Double.longBitsToDouble(0x3fd85947ca5c4ba6L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 17, 0, "\022\000\ud8fc\ude22\ud9d1\uddaf\ud90a\udff8", "\u6e9e\u17ed\u09ae\ube75\uc9d4\u77dc\u901f\u6718\u7708\u873d\ub0f2\u3330", "\uda47\udf23\udaeb\udc8d\ud88f\udc45\000\udbf8\uddbe\ud913\ude0f\ud93a\uddbe\udbb1\udf53\ud8d0\udcf8\ud804\uddc5\uda72\udc9c\uda0f\udcba\uda58\udc23\ud808\udcfb\udb32\uddad\udb81\ude37\u71e8\uda63\udf14\ud807\udd38\udacb\udf7b\ud86d\ude8f\udb97\udf57\u0918\udb46\udd17\uda1c\udd85\ud957\udd0e\ud8f6\udc57\ud9e7\udd07\ud875\udd66",
        44, 32869, -411101247, 7585955543113548795L, -40065L, false, false, (char) 17798, (char) 36017,
        Double.longBitsToDouble(0x3f82b0b4073d38c0L), Double.longBitsToDouble(0x3fc866a80d5fc55cL)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 17, 0, "\ud891\udf6b\021", "\u1909\uc141\uae1e", "\ud8ee\udd12\udb9f\udee4\ud868\udd5c\udbf9\udfc0\ud8ff\udf30",
        2, 2897, 450633576, 3433115636824076197L, 63309L, false, true, (char) 45044, (char) 38235,
        Double.longBitsToDouble(0x3e949bf360000000L), Double.longBitsToDouble(0x3fdd6ba0a8eaa6b8L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 17, 0, "\ud943\udef3C", "\u1909\uc141\uae1e", "\ud8ee\udd12\udb9f\udee4\ud8af\uddda\udbf9\udfcb\udb57\ude7b",
        0, 26031, 450633576, 3433115634122944421L, 88141L, false, true, (char) 28372, (char) 59650,
        Double.longBitsToDouble(0x3feeb6111efa0000L), Double.longBitsToDouble(0x3f98a73e6a642b80L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 0, 13, "\ud84c\udd43\udbe1\ude90\udbd5\udc34\ud965\udd60\ud8dd\udcea\udab3\udffa\ud85b\udff6\ud8e0\udee1\udb0c\udf0f\ud9ea\udf36\udb9f\uded3\ud868\udd5c\uda83\udfe6", "\u7708\u873d\u9edf\u4275\ub8e6\u82f0\uaad0\uc78f\u6560\u1f80\u7f19\u366c\u79e1\u291cY\u4289\u7a6a\u0ee6y\ud05b\ua9c2\u062c", "\udaf2\udf54",
        40, 91250, 1896790482, -5770622424285343925L, -72464L, true, true, (char) 63064, (char) 11607,
        Double.longBitsToDouble(0x3fc6accb022d5bc4L), Double.longBitsToDouble(0x3fd785e0c3f04f62L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udaf1\udf18\uda17\ude36\ud9ea\ude7e\ud8dd\udcea\ud88f\udec9\udbcd\udca2\ud8d0\udf27\ud8cd\udcbe\ud9ed\udfc3\ud95f\ude1c\ud868\udcd1\uda83\udfe6", "\u1968\u9a60a\u1eb6\ub8e6\u82f0\ub48c\u3d8e\u2bbb\ub579\u5db8\uac2a\u3b11\u7d4ca\u9290\u7a6a\u6db6\u0a7a\u6a6e\ub517\u207f", "\uda00\udf6a\udb01\uded3\udb3a\ude17\uda84\udc7b\udbac\udf47\ud8b0\ude51\uda7d\udce3\ud93e\udd8d",
        4, 27336, 1975562433, 2101176076696565982L, 54360L, false, false, (char) 60837, (char) 53955,
        Double.longBitsToDouble(0x3feec1f27cf379edL), Double.longBitsToDouble(0x3fef26a2840eebd9L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90\udbd5\udc34\ud965\udd60\ud8dd\udcea\udab3\udffa\udb18\udd14\ud8e0\ude4b\udb24\uddaf\ud9ed\udf78\udb9f\uded3\ud868\udd5c\uda83\udfe6", "\u7708\u873d\u9edf\u4275\u8385\u82f0\ub48c\uae71\u652c\u1f80\u5db8\u5cc2\u1f62\u1001h", "\ud95c\uddcd",
        40, 43169, -1025015252, -4607992759791107086L, -70422L, true, true, (char) 45178, (char) 50654,
        Double.longBitsToDouble(0x3fd7b710ee975fd4L), Double.longBitsToDouble(0x3feefd5c8b905bafL)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90K\uda31\ude97\ud8dd\udcea\udb42\udd42\uda23\udf30\000\udb24\uddaf", "\uc53e\u852e\u15bd\u6718\u7883\u9fa8g", "\udbe7\udcef",
        0, 58858, -1374386620, 7557607613395784842L, 55447L, false, false, (char) 58598, (char) 0,
        Double.longBitsToDouble(0x3fe5180006ccf90bL), Double.longBitsToDouble(0x3fc9b65ac0e7f5c8L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 1, "\ud84c\udd43\udbe1\ude90K\uda31\ude97\ud8dd\udcea\udb42\udd42\uda23\udf30\000\udb24\uddaf\ud9ed\udf78\u7793\ud833\udcb8\uda83\udfe6\udbd1\ude93\udb79\udff3\udb84\udffe\udb92\udd0dg\000", "\u398a\u3d8e\u652c\ub063\u5e03\u5cc2\u9e32\u02db\u0ce8\000\u7a64\u7357\u0955\ub8b1\ua9c2\u1b35\000\000\ua70e\uc4d6\uc79b\u1779\u8a90\u5b39\u088a\u745c\u0e28\u8dfa\u9450\u5b11\u4055\u75b7\u3e3e\u4773\u2a7b\u0791", "\udb0f\udd25\ud932\udffe\udbbd\ude5b\udb9a\udef5\ud87c\udcf9\udad6\udc08\u755f\u8988\ud95a\udfa9\ud8db\udf41\u4636\ud9a4\udd8c\udaf6\udc10\udb58\udf9d",
        23, 47145, 1987445728, 5147372474553102455L, -26559L, false, false, (char) 15862, (char) 33011,
        Double.longBitsToDouble(0x3fec7dfbc62008acL), Double.longBitsToDouble(0x3fe5dc359d0a2348L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 14, 17, "\ud84c\udd43\udbe1\ude90K\uda31\ude97\ud8dd\udcea\udb42\udd42\uda23\udf30k\udb24\uddaf\ud9ed\udf78\u7793\ud833\udcb8\ud908\udd89", "\u7464\u9c17\u0cfa\u00f8\ua2da\u402a\ubaff\u39a0\u4a7e\u5a2f\u288a\ucaed\u96be\u05ef\u0cfc\000\u7a64\u7357\u0955\ub8b1\ua9c2\u1b35\uae2a", "\udb10\udf2d",
        9, 15970, -1347193029, -6083924070529265446L, -85442L, false, true, (char) 42054, (char) 24683,
        Double.longBitsToDouble(0x3fb116c76e488540L), Double.longBitsToDouble(0x3feacc481689552fL)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90Ky\000\000\000\000\udb24\uddaf\ud9ed\udf78\u7793\ud884\udc01\uda47\udc62", "\u7708\u9fa8g\000\ua2da\u82f0\u398a\000\u64e8\ub063\u5e03\u5cc2\u9e32\u02db\u0ce8\000\u7a64\u7357\u0955\ub8b1\ua9c2\u1b35", "",
        6, 13630, 1903692064, 8146652708253376891L, -92799L, false, true, (char) 43440, (char) 7775,
        Double.longBitsToDouble(0x3fc83de88209d700L), Double.longBitsToDouble(0x3fcbc3a515e17830L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\uddfc\ud912\udc28\016\ud91a\ude9b\ud8dd\udcea\udb08\ude84\ud9b5\udd70\uc6e4\uda63\udc6f\ud8a5\udc17\udacc\uddea\ud833\udda6\udbc5\udfe7", "\u76ad\uc298{\000\ua455\u0732\u5ca6\u3d8e\ud73f\u1fd0\u5db8\u5cc2\u0189\u02db\u802b\012\u11ae\ubf26\u089b\ub8b1\ua9c2\u488e", "\udb0b\ude22",
        40, 91250, 1896790482, -5770622424285343925L, -72464L, true, true, (char) 44871, (char) 35879,
        Double.longBitsToDouble(0x3fc05798137874a0L), Double.longBitsToDouble(0x3fd785e1bb1f6f60L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90\020\ud965\udd60\ud8dd\udcea\udb42\udd42\011\000", "\u7793\u9ee8\u1bb6\u15bd\u6718\u7708\u873d{\000", "\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud9e6\udd06\ud82b\udde9\uda96\udeeb\ud9a3\udf3e\ue211\uece7\000\ud806\ude3a\ud958\udff5\u2c7f\udbca\ude02\ud8ed\ude8f\ud8be\udf3b\000\ud8e5\udc04\udb0b\ude22\udb01\uded3\udb3a\ude17\uda84\udc7b\ud91e\udf85\uda7b\udc4a\ud80e\udd04\ud92b\udd97\ud9de\udc02\uda0c\udcd3\ud9cf\udfb1\udba8\ude39\ud808\udf95\ud810\udf99\ud8c6\udff7\ud992\udf10\ud819\udd62\uda78\udd9e",
        3, 99010, 824944349, -380705475985340243L, -99708L, false, false, (char) 19174, (char) 8685,
        Double.longBitsToDouble(0x3f9ab33ee8fcdea0L), Double.longBitsToDouble(0x3fdc2848a78b9112L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\udbe1\ude90\020\ud939\udd59\ud8dd\udcea\ud83e\udf1f\udb67\udfa3\007\udb24\uddaf\ud9ed\udf78\u7793\ud833\udcb8\uda83\udfe6", "\u7708\u873d{\000\ua2da\u82f0\ub48c\u3d8e\u652c\u1f80\u5db8\u5cc2\u9e32\u02db\u0ce8\000\u7a64\u6db6\u089b\ub8b1\ua9c2\u1b35", "\udb0b\ude22",
        40, 91250, 1896790482, -5770622424285343925L, -72464L, true, true, (char) 7775, (char) 40965,
        Double.longBitsToDouble(0x3fc04eb8037874a0L), Double.longBitsToDouble(0x3fd785e0cb1f6f60L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud84c\udd43\ud9c7\udd02T\ud965\udd60\ud80d\udc29\udb2f\uddfc\000\000\udb2c\ude29\ud9ed\udf78\u7793\ud833\udcb8\ud910\udc0c", "\u7708\u873d\u741d\u5e77T\u8251\ub48c\u3d8e\u65bd\u1f80\u5db8\u5cc2\u9e32\u02db\u0ce8\000\u40c8\u01d4\ub8a6\u1f3d\ua9c2\u1b35", "\uda1a\udfe0\ud9f3\ude7c\udb69\uddd0",
        -3, 23387, -1414055514, -8883090380234665403L, -95440L, true, false, (char) 22082, (char) 22022,
        Double.longBitsToDouble(0x3fd785e0c3b8b292L), Double.longBitsToDouble(0x3fd24df5ea82bfccL)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\ud8c4\udd9f\ud9a6\udf78T", "\u9290\000\000", "\u7793\ud833\udcb8\udad5\udffc\uda1f\udfa9\udb79\udff3\udb84\udffe\udaba\ude52\uda10\udc22\000\ud91d\udf4d\udbe7\udcef",
        3, 58874, -1199847211, 6044398639432750143L, -41401L, false, false, (char) 45888, (char) 21501,
        Double.longBitsToDouble(0x3fe0879476398c0fL), Double.longBitsToDouble(0x3fe16072df00c2e7L)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 0, "\ud80e\udd44\udbfc\udf9d\ud9ee\udd21\026\000\000\udaa9\udf10", "\u3b58\uc88f\000\000\ud25e\u1d78\ubf14\u008c\uab3c\u2394\u81aa\uc0ef\ub48c\u3d8e\u652c\u819c\ubfb4\u5d81", "\udac1\udcac\udb4e\ude2d\uda90\udc89\ud887\udfc8\udb46\udcc7\ud9cc\udedd\ud99b\udf95\udbab\ude01\ud894\udd59\udae3\udf0b\ud8f4\udc06\uda11\ude6a\ud84b\udc94\udb32\udf82\ub42f",
        54, 40039, -690935879, -5463376837581159669L, 85262L, false, true, (char) 30546, (char) 4333,
        Double.longBitsToDouble(0x3f8b20a74bce3680L), Double.longBitsToDouble(0x3fee2eee9aef1c4bL)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\udbb1\udd35\uce67\u00df\ud965\udd60\ud8dd\udcea\udb9b\udfee\ud959\udd42\024\000\uda8c\udfa7\udb9f\ude99\ud868\udd5c\ud97b\udc5c", "\u7708\ub347\u9edf\u4275\u1ee6\u08ae\u6542\u3d8e\ua589\u3b44\u43de\uad56\ubc8d\u51e0\u2bc6\ub12a\u7a64\u6db6\023\u8471\u2841\u1b35", "\udb08\udea1",
        40, 99886, 1575177515, -5770622169456210101L, 31984L, true, true, (char) 15661, (char) 1590,
        Double.longBitsToDouble(0x3e36f00000000000L), Double.longBitsToDouble(0x3fd786cd07d64f62L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 1, 1, 5, "\uda2f\ude53\015\uae00\udbe4\udc7f\ud875\udf99\udb89\udda7\ud9e7\udd7c\udb2b\udec0\ud9c8\ude2a\ud817\udf2d\udbf5\ude72\ud974\udf99\uda95\udde6", "\u675a", "\ud909\udc9e\u228f\ud921\udf8a\ud8c2\udf99\ud9a7\ude02\ud9ca\udf25\ud94a\udf05\ud817\udce7\uf54c\ud840\ude34\uda5a\uddf1\ud907\ude39\ud8cd\udd0b\udad9\udfc3\uda8b\udf3a\u6e10\ud9ed\udc0e\ud97e\udceb\ud98a\ude27",
        23, 63042, 246291140, 5607568830783564638L, -81527L, false, true, (char) 61456, (char) 48834,
        Double.longBitsToDouble(0x3fd77ce6e3a0191eL), Double.longBitsToDouble(0x3fdad3c4490da018L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:B |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 1, 17, "B\000\udaec\udd71\ud9d1\uddaf\udbc3\udef5\ud989\udce6\ud949\ude07\udbac\udddc\ud8dc\udf78\ud895\udc64\udb9f\udee4\ud863\ude1b\uda99\ude8c", "\u3393\u873d\u995c\u83b3\u10dc\u82f0\u4ed5\u808d\u62dc\u93fc\u5db8\u5cc2\u9e32\u2f75\u6c59\u9f0b", "\ud921\ude8e\ud85a\udf40\udb13\uddab\uda9c\udd7e\udaa3\udee5\ud909\ude08\u6ce9\ud82a\udc60\ud8ee\udef5\uda36\udc54\ud815\udc0f\ud875\udf1f\udbb4\uddf1\udbe5\udec5\ud8c7\udfce\uda11\udc74\uda28\udd21\ud80f\udc4c\uda18\udffb",
        25, 53791, -1992698388, -3198422153837909827L, -24499L, false, false, (char) 33518, (char) 55303,
        Double.longBitsToDouble(0x3feef4ac5277ca5fL), Double.longBitsToDouble(0x3fe9ea8354266d52L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 1, 2, "\030\udb22\udd42\uda45\uddab\ua0ca", "\uae1e\u6e9e", "\udb4a\udc93\ud868\udd5c\udbf9\udfc0\ud8f1\udf6b\udb69\udd75\ud8cc\udc52\ud9ec\ude43\ud9c7\ude30\udbbf\udc26\udabe\uddc4\ud997\udd6c\ud92b\udd1d\ud8af\udf52\ud8a5\ude45\ud8ad\udcf3\uda08\udee8",
        32, 34485, 381252918, 7558763588600224105L, 7159L, true, false, (char) 6779, (char) 40897,
        Double.longBitsToDouble(0x3fc00f0b7c7aead4L), Double.longBitsToDouble(0x3fe3ac71e7ae52e9L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:S |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 17, 0, "\022\000\ud8fc\ude22S\ud90a\udf08", "\u6e9e\u17ed\u09ae", "\udbf9\udfc0\udb74\udd7b\udb79\udff3",
        47, 71576, 799334523, 8483919292084775184L, -88668L, false, false, (char) 48889, (char) 13142,
        Double.longBitsToDouble(0x3fea990ae4dce52dL), Double.longBitsToDouble(0x3fecc5111912d379L)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 17, 15, "\ud891\udf6b\021", "\u1909\uc141\uae1e", "\ud8ee\udd12\udb9f\udee4\ud868\udd5c\udbf9\udfc0\ud8ff\udf30",
        2, 2897, 450633576, -5776464126171877489L, 63309L, false, true, (char) 45044, (char) 38235,
        Double.longBitsToDouble(0x3e949bf360000000L), Double.longBitsToDouble(0x3fdd6ba0a8eaa6b8L)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 17, 0, "\ud943\udef3C", "\u1909\uc141\uae1e", "\ud8ee\udd12\udb9f\udee4\ud8af\uddda\udbf9\udfcb\udb57\ude7b",
        0, 26031, 450633576, 3433115634122944421L, 88141L, false, true, (char) 28372, (char) 59650,
        Double.longBitsToDouble(0x3feeb6111efa0000L), Double.longBitsToDouble(0x3f98a73e6a642b80L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 17, 0, "\ud943\udef3C\udaeb\udf71\ud9d1\uddaf\ud90a\udff8\udab3\udffa\udb18\udd14\uda2e\ude19\udaa5\udc20\ud8ee\udd12\udb9f\udee4", "\u1d1f\uc9d6\u0a51\u873d\u9048\u9424\ub8a1\u0bf1\u2565\uc431\ud0ca\u77d6\u85c8\u43a2\u458a\u1161\uc03e\u4c6f\ub576\u0e12\u8587\u2fa8\u528a\u3029", "\udba7\ude34",
        30, 26371, 688660255, 2346501606982949540L, 66914L, true, false, (char) 30346, (char) 16445,
        Double.longBitsToDouble(0x3fe55b35e8ed1848L), Double.longBitsToDouble(0x3fc22708c8679aacL)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 17, 0, "\u23fbC", "\u1909\u8179\uae1e", "\ud8ee\udd12\udb9f\udee4\ud8af\uddda\udbf9\udfcb\udb57\ude7b",
        0, 26031, 450633576, 3433115633746418341L, 88141L, false, true, (char) 28372, (char) 59650,
        Double.longBitsToDouble(0x3feeb6111efa0000L), Double.longBitsToDouble(0x3f98a73e6a642b80L)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 0, 1, "\ud84c\udd43\udbe1\ude90K\uda31\ude97\ud8dd\udcea\udb42\udd42\uda23\udf30\000\udb24\uddaf\ud9ed\udf78\u7793\ud833\udcb8\uda83\udfe6\udbd1\ude93\udb79\udff3\udb84\udffe\udb92\udd0dg\000", "\u398a\u3d8e\u652c\000\u0979\u5cc2\u9e32\u02db\u0ce8\000\u7a64\u7357\u0955\ub8b1\u00b1\u1b35\000\000\u02f6\uc4d6\uc79b\u1779\u8a90\u5b39\u088a\u745c\u0e28\u8dfa\u9450\u60b2\000\u483fG\u4746\u2a7b\u0791", "\000\000\000\udb9a\udef5\ud87c\udcf9\udad6\udc08\u755f\u8988\ud95a\udfa9\ud8db\udf41\u4636\ud9a4\udd8c\udaf6\udc10\udb58\udf9d",
        23, 47145, 7734240, 1092538335232L, -26559L, false, false, (char) 15862, (char) 33011,
        Double.longBitsToDouble(0x3fec7dfbc62008acL), Double.longBitsToDouble(0x3ec674288d200000L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 1, "\ud84c\udd43\udbe1\ude90K\uda31\ude97\ud8dd\udcea\udb42\udd42\uda23\udf30\ud9ad\udcb6\ud811\udfcb\ud86c\udd02\u7793\ud833\udcb8\uda83\udfe6\udbd1\ude93\udb79\udff3\udb84\udffe\ud81d\uddf2\027\000", "\u0f8d\u3d8e\u652c\ub063\u5e03\u5cc2\u9e32\u02db\u0ce8\000\u7a64\ubacc\u0955\ub8b1\ua9c2\u1b35\000\000\ua70e\uc4d6\u04d5\u1755\ua20b\u5b39\u088a\u745c\u0e28\u8dfa\u9450\u5b11\u4055\u75b7\u3e3e\u4773\u9738\u5423", "\udbe4\udcaf\ud932\udffe\udbbd\ude5b\udb9a\udef5\ud87c\udcf9\udad6\udc08\u755f\u8988\ud95a\udfa9\ud8db\udf41\u4636\ud9a4\udd8c\udb74\udecf\udafc\ude63",
        23, 47145, 1987445728, 5147372474553102455L, -26559L, false, false, (char) 15862, (char) 33011,
        Double.longBitsToDouble(0x3fec7dfbc62008acL), Double.longBitsToDouble(0x3fe5dc359d0a2348L)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud83d\ude61\udbe1\ude90Ky |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 12, 13, "\ud83d\ude61\udbe1\ude90Ky", "\u07da\000\ua27b", "\ud884\udc01\udb0c\udf25\uda1d\ude99\udb79\udff3\udb84\udffe\udb92\udd0dg",
        -5, 18920, 1996127725, 2647129219166896128L, 30027L, false, false, (char) 51603, (char) 30668,
        Double.longBitsToDouble(0x3fe6d5308cb8db48L), Double.longBitsToDouble(0x3fe802b802a30000L)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 0, "\ud80e\udd44\udbfc\udf9d\ud9ee\udd21\026\000\000\udaa9\udf10", "\u3b58\uc75f\u3ce8\u9b00\ud25e\uc1a0\026\u008c\uab3c\u2394\u81aa\uc0ef\ub48c\u3d8e\u652c\u819c\ubfb4\u5d81", "\udac1\udcac\udb4e\ude2d\uda90\udc89\udaec\udd5b\ud9c8\udf39\ud9cc\udedd\ud99b\udf95\udbab\ude01\ud894\udd59\udae3\udf0b\ud8f4\udc06\uda11\ude6a\ud84b\udc94\udb32\udf82\ub42f",
        54, 40039, -690935879, -5463376837581159669L, 85262L, false, true, (char) 30546, (char) 4333,
        Double.longBitsToDouble(0x3f8b20a74bce3680L), Double.longBitsToDouble(0x3fee2eee9aef1c4bL)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\udbb1\udd35\ud9e8\udea1\023\ud965\udd60\ud8dd\udcea\udb9b\udfee\ud959\udd42\024\000\uda8c\udfa7\udb9f\ude99\ud868\udd5c\ud97b\udc5c", "\u7708\ud346\u9edf\ua21d\u1ee6\uc537\u34b2\u25bf\u9cb4\u3826\u43de\uad56\ubc8d\u51e0\u2bc6\ud374\u7a64\u55cf\023\u8471\u2841\u0fee", "\udb08\udea1",
        40, 99886, 1575177515, -5770622169456210101L, 31984L, true, true, (char) 12078, (char) 1590,
        Double.longBitsToDouble(0x3e36f00000000000L), Double.longBitsToDouble(0x3fd786cd0dd64f62L)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=java.lang.String:T |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:T |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 1, 17, 5, "\uda2f\ude53\015\uae00\udbe4\udc7f\ud875\udf99\udb89\udda7\ud9e7\udd7c\udb00\udfc0\ud9c8\ude2a\ud817\udf2d\udbf5\ude72\ud974\udf99D", "\u3634", "\ud909\udc9e\u228f",
        45, 26026, 8563, 2634016445740221474L, -21781L, false, true, (char) 24890, (char) 6215,
        Double.longBitsToDouble(0x3f44b66000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 0, 1, "\ud84c\udd43\udbe1\ude90K\ud997\ude0b\ud8dd\udc3d\uda94\uddab\uda23\udf40\000\udb24\uddaf\ud9ed\udf78\ud855\uddcf\ud82b\udc14\uda83\udfe6\uda59\ude97\udb79\udff3\ud818\udf7c\udae8\ude67g\ud998\udc4b", "\u398a\u3d8e\u652c\000\ubcfe\u5c7e\u9e32\u02db\u0ce8\000\u7a64\u7357\u0955\ub8b1\u00b1\u4922\000\ud757\u02f6\uc4d6\uc79b\u1779\u8a90\u5b39\u088a\u745c\u0e28\u7ad6\u62f7\u879f\000\u483fG\u4746\u2a7b\u0791\u05d7", "",
        -5, -1000, 1179795153, 3802733380047028037L, 20562L, false, true, (char) 43412, (char) 1918,
        Double.longBitsToDouble(0x3fe6a87c9f13ea38L), Double.longBitsToDouble(0x3fcf312225679394L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 0, "", "K\ub2a6\u39fa\ub224\u5098\u35e3", "\u7793\ud833\udcb8\uda83\udfe6\udbd1\ude93\udb79\udff3\udb84\udffeh\000\000\ud91e\udc32\udb5e\udf6c\ud82d\udc0e\000\000\ud920\ude43\ud82b\ude34\uda96\udeeb\ud8ce\udf7c\000\u00e7\000",
        58, -1000, 205, 1014998764993610284L, -100000L, false, false, (char) 29578, (char) 23518,
        Double.longBitsToDouble(0x3fe104fab9562408L), Double.longBitsToDouble(0x3e4d2c63c8000000L)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 8, 13, "\ud83d\ude55\udbe1\ude90Ky", "\u07da\000\u89a5", "\ud884\udc01\udb0c\udf25\uda1d\ude99\udb79\udff3\udb84\udffe\udb92\udd0dg",
        -5, 18920, 1996127725, 2647129219166896128L, 30027L, true, false, (char) 51603, (char) 30668,
        Double.longBitsToDouble(0x3fe6d5308cb8db48L), Double.longBitsToDouble(0x3fe802b802a30000L)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 1, 17, 5, "\uda2f\ude53\015\u8900\udbe4\udc7f\ud875\udf99\udb89\udda7\ud824\udcdb\udb01\udc5a\ud9c8\ude2a\ud817\udf2d\udbf5\ude72\ud94f\udfa0\001", "\u3634", "\ud909\udc9e\u228f",
        45, 80218, 11796, 2634016445740221474L, -21781L, false, true, (char) 24890, (char) 6215,
        Double.longBitsToDouble(0x3f44b673e8940800L), Double.longBitsToDouble(0x3fe3e11f0800957dL)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 3, 17, "\ud84c\udd43\udbe1\ude90K\udbc0\udf12\ud8dd\udcea\udb42\udd42\ud960\uddd0\uda7f\udc22\uda79\udf7f\ud939\udf6b\u0d61\ud833\udcb8\udac5\udf25\ud906\ude0f", "h4\000\u6fc0\u93a2\ucff9\ucdf4\000\ub063\u5e03\u80f7\u9e32", "\000",
        58, -1000, 205, 1014998764993610284L, -54459L, false, true, (char) 0, (char) 43068,
        Double.longBitsToDouble(0x3fd92561d3704e5aL), Double.longBitsToDouble(0x3fd3b60a3316d640L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 3, 17, "\ud84c\udd43\udbe1\ude90K\udbe3\udf85\ud8bf\udef5\udb42\udd42\ud960\uddd0\uda7f\udc22\uda79\udf7f\ud939\udf6b\u0d61\ud833\udcb8\udb61\udfbf\ud929\udda2\udb79\udf86\udb84\udffeh4\000\ud947\udc32\udb5e\udf6c\udafe\udc51\udb6c\udf46\000\ud920\ude43\ud82b\ude34\ud808\udd24\ud8ce\udf7c\000\u00e7\000\u5aa3\uda74\ude79\udbad\udd29\ud9ea\udd89\ud8ed\ude92\ud823\udd2dh\000\udbec\udd70\udb34\udc5e", "\u9d90", "\udbcb\udf69\ud868\udf8b\udba7\udeeb\ud8e3\udebf\ud896\udfca",
        17, 77225, 1897476962, -5261112927321247767L, 20641L, true, true, (char) 44304, (char) 59997,
        Double.longBitsToDouble(0x3fe49eb5551add9bL), Double.longBitsToDouble(0x3fb023b6e23f4c08L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 16, 14, "\ud84c\udd43", "\u8788\u8fe5\uc128\uae1e\u6e9e\ud37a\u47cc\uc8a0\u9b8d\u4083\u7b20\u6718\u7e22\u6f7b\ub0f2\u3339\u1ee6\u82f0\ub48c", "\ud9e6\udd06\ud961\udf44\uda15\udd3f\udac1\ude35\udbfe\ude13\uda70\udedc\udbfe\udda3\ud806\ude3a\ud8df\udf99\udba5\udcac\ud86e\udc34\udb21\ude4b\ud85d\udfda\ud806\ude67\ud96b\uddfd",
        52, 57112, 242557847, -2706257459744809220L, 30307L, false, false, (char) 24567, (char) 59030,
        Double.longBitsToDouble(0x3fe6bc5262a8c0b8L), Double.longBitsToDouble(0x3fef391554816e8bL)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=java.lang.String:P |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 3, 7, "P\000\udb0d\udc21", "\uc141\uae1e\u6e9e\ud3c7\uad73\u7741\u9b8d", "\udb79\udff3",
        47, 71576, 799334523, 8483919292086637579L, -65628L, false, false, (char) 21567, (char) 51535,
        Double.longBitsToDouble(0x3fc93ae06b6a9844L), Double.longBitsToDouble(0x3fccfb320dc61630L)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 13, 8, "W\ud9eb\uddb4\ud93c\ude70", "\uc141\u4acd\ua36c\u9f6a\u2bf8\uceea\u4c70", "\udb79\udff3\udb61\udefe\ud92f\udcfb\udb16\udf41\ud8df\ude95",
        -5, 63725, 608959744, 1087772870896289348L, 52639L, false, true, (char) 42700, (char) 56474,
        Double.longBitsToDouble(0x3fdff46f92680f20L), Double.longBitsToDouble(0x3fe82c7d0146b70cL)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 1, 1, 16, "\014\ud9eb\uddb4\ud93c\ude70\ud9d1\uddaf\ud90a\udff8\udab3\udffa\udb18\udd14\udbc7\udc65\uda75\udcf2\uda69\ude38\udab3\ude1c\ud877\udfc6\ud814\udf1c\ud9b7\ude44\ud861\udcf2\udb61\udefe\ud8b4\udcfd\udb16\udf49\ud8df\ude95\ud932\udf58\udbe7\udcef\uda47\udf23\udaeb\udc8d\ud824\udc70\ud9e6\udd06\udbcb\ude5a\uda74\ude71\ud8ce\udf7c\ud870\udc96\uda89\uddaf\ud8ff\udde4\ud82f\ude31\udb53\ude8b", "\u446a\ua0d7\u6adc\u6a98\u8218\u8b17", "\ud8c6\ude0b\udb2f\udc6f\ud9b3\uddac\ud9bf\udcf7\ud984\udc5c\u7253\uda21\udec0\ud872\udfa4\ud98a\ude84\udb9b\uddf1\uda4e\udf35\udb3a\udc60\udb62\udd33",
        55, 17803, -1843231294, -282990936575670155L, 70318L, false, false, (char) 64384, (char) 42031,
        Double.longBitsToDouble(0x3fdc472b1e69980aL), Double.longBitsToDouble(0x3fe569c6423dae62L)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=java.lang.String:T |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 17, 0, "D\000", "\u1909\uc141\uae1e", "\ud8ee\udd12\udb9f\udee4\ud868\udd5c\udbf9\udfc0\udb74\udd7b",
        42, 53862, 450633576, 3433115634601684901L, 63309L, false, true, (char) 45044, (char) 25948,
        Double.longBitsToDouble(0x3fe255e50927bd36L), Double.longBitsToDouble(0x3feb7d4ff89efd3fL)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 2, 2, 1, "\ud818\udc88\ud948\udfc2\udbf0\udc6d\ud965\udd60\ud8dd\udc67\udab3\udffa\udb78\udcc4\u78d7\ud87a\udc05\udb21\udd37\u7733\ud81d\udfa5\u554b", "\000\u6cbf\u44de\ud2ed\u7b94\u00a4\u7ba8\ua86f\ua514\u109e\ua229\u2cc3\u0540\u751f\uca85\ud040\u8288\u64e5\u7545\ud05b\u2c6d\uc606\u5b6c\u2562\u665e\u67ad\u37a8\u8025\u9ce2\u5b76\u088a\u6a1f\u6330\u74e0\u6f47\u8e82\u2027\u9966\u7742\u7fa7\uccc6\u9d50\ub484\u25c6\u1bfb\u58eb\u51e9\u3509\u86af\u9336", "\ud8cc\udc08\uda2e\ude0e\ud8f3\uddd7\ud9b6\udfab\udb5f\udcb7\ud958\udf74\udb5e\udc8f\ud827\udc15\uda3a\udd08\uda25\udf4b\udb23\udf9b\ud961\udf3b\ud803\udde1\uda7d\ude69\ud956\udc51\udaf3\udf71\ud93d\udfa6\ud8c5\ude12\udbfc\udf63\udb0d\udfd8\ub468",
        51, 3868, -1067956302, 4923355438839913351L, 11003L, false, false, (char) 2897, (char) 17769,
        Double.longBitsToDouble(0x3fc7b2c59200e674L), Double.longBitsToDouble(0x3fb63cb3ba8bfe78L)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 12, 13, "\u652a\ud8b5\udd99T\ud965\udd29\ud958\udce8\000\000\000\udb08\udc63\u1c86\000\000\ud910\udc0c", "\u2625\000\000\000\ua2da\u00ed\000\u3ce4\u65bd\u1f80\u543f\000\u9e32\u02db\u0ce8\000\ub341\000\ub896\u3ed1\ua9c2\000", "",
        -5, -1000, 202241307, 0L, -100000L, false, false, (char) 0, (char) 7775,
        Double.longBitsToDouble(0x3fc83de88209d700L), Double.longBitsToDouble(0x3fcbc3a515e17830L)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 8, 13, "\ud84c\udd43\udbe1\ude90\ud8d2\udd98\ud946\ude0f\ud8dd\udcea\udb42\udd42\011\000", "\u7793\u9ee8\u1bb6\u15bd\u0718\u1e4f\u4053{\000", "\ud940\udf2a\udaeb\udc8d\ud83a\udd70\ud9e6\udd06\ud82b\udde9\uda96\udeeb\ud9a3\udf3e\ue211\uec57\000\ud806\ude3a\ud958\udff5\u2c7f\ud9e3\udc23\ud9b4\udc9e\ud8b7\udf89\000\ud8e5\udc04\udb0b\ude22\udb01\uded3\udb3a\ude3d\uda84\udc7b\ud946\udcf0\uda7b\udc4a\ud80e\udd04\ud92b\udd97\ud9de\udc02\uda0c\udcd3\ud9cf\udfb1\udba8\ude39\ud808\udf95\ud810\udf99\ud8c6\udff7\ud992\udf10\ud819\udd62\uda78\udd9e",
        3, 99010, 824944349, -380705475985340243L, -45331L, false, false, (char) 22246, (char) 8608,
        Double.longBitsToDouble(0x3f9ab33ee8fcdea0L), Double.longBitsToDouble(0x3fdc25e8a78ab512L)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 10, 2, "X\ud878\udfae\uda45\udde3\ua0ca", "\uae1e\u6e9e", "\udb54\udc8e\ud868\udd5c\udbf9\udfc0\ud8f1\udf6b\udb69\udd75\ud8cc\udc52\ud9ec\ude43\ud9c7\ude30\udbbf\udc26\udabe\uddc4\ud997\udd6c\ud92b\udd1d\ud8af\udf52\ud8a5\ude45\ud8ad\udcf3\uda08\udee8",
        32, 34485, 381252918, 7558763588600224105L, 7159L, true, false, (char) 6779, (char) 40897,
        Double.longBitsToDouble(0x3fc00f0b7c7aead4L), Double.longBitsToDouble(0x3fe3ac71e7ae52e9L)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 7, "\ud867\udd22\u06e5\u78f2\udb79\udf15", "\u07da\027\u48f0\ua22d\u62da\ube50", "\udb79\udff3\udb84\udffe\udb92\udd0dg\000\ud8c4\udf18",
        18, 29800, -285212672, -5903081036746824683L, -78838L, true, false, (char) 33003, (char) 17610,
        Double.longBitsToDouble(0x3fef6ac8048c0194L), Double.longBitsToDouble(0x3fed33dee7f6d8dcL)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud83d\ude61\ud857\udcd3gy |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 12, 13, "\ud83d\ude61\ud857\udcd3gy", "\u07da\000\ua27b", "\ud884\udc01\udb0c\udf25\uda1d\ude99\udb79\udff3\udb84\udffe\udb92\udd0dg",
        -5, 18920, 1996127725, -929573309706368964L, 30027L, false, false, (char) 51603, (char) 30668,
        Double.longBitsToDouble(0x3fe6d5308cb8db48L), Double.longBitsToDouble(0x3fe802b802a30000L)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=java.lang.String:S |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:S |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 8, 2, "X\ud878\udfae\uda45\udde3\udad8\udf0c", "\uae1e\u6e9e", "\000",
        7, 80124, -197636067, 4221563907444687717L, 83143L, true, true, (char) 50364, (char) 22784,
        Double.longBitsToDouble(0x3fcc076b59a63400L), Double.longBitsToDouble(0x3fe2207ba89d0014L)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 7, "\ud867\udd22\u06e5\uc63c\ud999\udc38", "\u07da\027\u48f0\ua22d\u5913\ube50\u083b\u1bf6\u6718\u7708\u9fa8g\000", "\ud8b6\udc2a\ud9ff\udeff\ud81b\ude3f\ud87d\udf27\uda4b\udd10\uda96\udeeb\ud8ce\udf7c\uda82\uddbf\udad5\udcbf\udb44\udc04",
        29, 95726, 987881462, 2312454017390364686L, -34239L, true, false, (char) 7976, (char) 39898,
        Double.longBitsToDouble(0x3fed6a5a7edca448L), Double.longBitsToDouble(0x3fe7da2369a398b6L)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 17, 5, "\ud83d\ude61\ud857\udcd3g", "\u27fd", "\udb24\uddaf",
        33, 29611, 1310720, 3848607358101176628L, -5262L, false, true, (char) 38046, (char) 0,
        Double.longBitsToDouble(0x3e47b5efa0000000L), Double.longBitsToDouble(0x3fe003b7d03cf319L)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:J |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 4, "\udbd5\udc3d\ud875\udc92gy", "\u07da\000\ua27b", "\ud884\udc01\udb0c\udf25\uda1d\ude99\udb79\udff3\udb84\udffe\udb92\udd0dg",
        -5, 18920, 1996127725, -929573309706368964L, 30027L, false, false, (char) 51603, (char) 30668,
        Double.longBitsToDouble(0x3fe6d5308cb8db48L), Double.longBitsToDouble(0x3fe802b802a30000L)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 10, 15, "\ud839\udded\ud857\udcd3gy\ud89e\ude2e\uda32\udeb3\ue7d9\000\udb24\uddaf\uda96\ude4c\u7793\ud884\udc01\udb0c\udf25\uda1d\ude99\udb79\udff3\udb91\udedd\udb92\udd0dg\000\ud91d\udf4d\udbe7\udcef\ud95b\udd3d\ud9f5\udfe5\ud841\ude4a\ud920\ude43\ud82b\ude34\uda96\udeeb\ud8ce\udf7c\ud824\udcb0\uda3c\uddd8\ucf00\ud9f4\udcf0\udb62\udf95\ue34a\ud903\udf6c\udb95\udfae\udb25\ude78\udac1\udfe5\ud88f\ude84\ud992\udddd\ud82e\udd5a\udba3\udfa0\ud92d\udd49\udabb\udfba\udad3\ude0e\udbb9\ude21\udb1f\udf4f\ud8a5\udef1\uab02\udb19\udeaa\udb01\udf5b\udb2c\udc26\uda60\udcf2\uda26\udc63\udb0a\udc9d\ud9a1\udea2\ud87e\ude25", "\u9240\u3169\u3281\ub30f\u87f0\u747d\u89c3\u133e\u4245\uad7e\u4eeb\ud4e2\u364c\uc692", "\udb85\ude22\uda79\ude9f\ud8bb\udf3b\ud8e0\udd87\uda81\udd79\ud9bb\udf6c\udb3f\udcce\udb90\udce9\udb25\udf70\ud961\udf89\uda87\udee0\ud857\udc09\udba0\udded\u1666\ud88b\uddeb\udb9d\udff2\udb43\udd22\ue1b7\udb39\udc69\uda07\udc54\uda6b\udee5\ud817\uddca",
        0, 46436, 1088309665, -6073599925358904935L, 24357L, false, false, (char) 10101, (char) 29196,
        Double.longBitsToDouble(0x3fe9cec47692e21dL), Double.longBitsToDouble(0x3fe26bb9ba26d57cL)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 4, "\udbd5\udc3d\udbe6\udd8c\udb01\udc07\012", "\u07da\000\u200c", "\ud8a9\ude8e\udaf0\udef7\uda1d\udea3\udb79\udff3\udb84\udffe\ud8c9\udee7B\000\ud91d\udf4d\ud8fd\udcfb",
        3, 80028, -1367301346, 7557607613395784842L, -75625L, false, false, (char) 49152, (char) 63809,
        Double.longBitsToDouble(0x3fd94a67a1c2dfaaL), Double.longBitsToDouble(0x3fefc2553515f91cL)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 17, "\ud839\udded\ud857\udcd3gy\ud89e\ude2e\uda32\udeb3\ue7d9\000\udb24\uddaf\uda96\ude4c\u7793\ud884\udc01\udb0c\udf25\udb61\ude9b\ud875\udff1\udb91\udedd\udb92\udd0dg", "\u82f0", "\ud841\ude4a\ud920\ude43\ud82b\ude34\uda96\udeeb\ud8ce\udf7c\ud824\udcb0\uda3c\uddd8\ucf00\ud9f4\udcf0\udb62\udf95\ue34a\ud903\udf6c\udb95\udfae\udb25\ude78\udb67\udc98",
        12, 62917, 339290153, 2564454226824933754L, -61929L, true, true, (char) 61729, (char) 23615,
        Double.longBitsToDouble(0x3f9ee2d9141529a0L), Double.longBitsToDouble(0x3fcbdbd8f0839998L)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 17, 17, 6, "g\u85dc\udab4\ude5c", "\uc141\u4acd\ua36c\u9f6a\u57b2\u4418\u8484", "\uda8c\udf1a",
        26, 16961, 799334523, -782236941228157764L, -65628L, false, false, (char) 30598, (char) 51603,
        Double.longBitsToDouble(0x3fc93ae07f6a9844L), Double.longBitsToDouble(0x3febac95cc6fa279L)));
  }
  @Test(timeout = 4000)
  public void test177() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:P |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 17, 0, "\udaf5\udfc2\uda87\udedb\uda6a\udf56\ud8e9\ude0b\ud8ee\udc76\udab3\udffa\udb18\udcf8\uda2e\ude19\udafa\udeaf\u0086\udb77\udf3b\ud893\ude93\ud952\uddb3\uda1d\ude99\ud928\udfaa\udb73\udfff\udace\udfe0\udb16\udfc7P\ud92a\udf95\ud923\udf63\uda02\udfcc\udbec\udd3d\ud83a\udd70\ud9a6\udcfa\ud945\udd80\ud8ad\uddd6\ud8ce\udf7c\ud8bc\udc9c\uda89\uddaf\udb85\ude5a\ud806\ude8e\uda54\udc92\udb82\uddaa\udb1f\udd89\ud924\uddb4", "\u426b\017\u23b8\u0b3e\ua1fb\u5f66\u9fce\u8ff9\ud118\u9efa\u1dfa\u5fe9\u712d\ucd1c", "\udaee\udc6d\ud937\uded7\udbf4\udd31\udbd6\udcaf\ud846\udfc1\ud8a6\udf16\udbb9\ude0c\udacc\udc10\u00ee\000\ud9d9\udc6b\uda58\ude47\ud821\udf21\udb0b\ude52\u52d5\udac5\udd22\ud9ab\uddf9\udb68\udda3\udbb8\ude2c\uda4b\ude21\ud97c\udee7\ud83b\ude19\udb31\udc90\ud8d8\udf3d\ud83f\udcc4\ud861\udead\uda0e\udde8\udb1e\udfb7\uda01\udd3f\ud913\udd4c\ud85d\udd50\udbc6\ude1e\u4344\000\udb67\udc66\ud885\ude3e",
        3, 32450, 1843266329, 6454617192500326326L, -79977L, false, false, (char) 57543, (char) 2073,
        Double.longBitsToDouble(0x3fc20562a734f8fcL), Double.longBitsToDouble(0x3fe89091769f27dbL)));
  }
  @Test(timeout = 4000)
  public void test178() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 17, 0, "\udb77\udf4d\013", "\u5bff\u46e3\u8ee3", "\ud86c\ude81\udb9f\udf39\ud894\udd64",
        1, 58345, -1003166303, 5271129323767734120L, -23921L, true, true, (char) 24021, (char) 44994,
        Double.longBitsToDouble(0x3fe8d50aa5fd1b2eL), Double.longBitsToDouble(0x3fbb585d4d144990L)));
  }
  @Test(timeout = 4000)
  public void test179() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 17, 8, 12, "\ud854\ude5c\udbda\udf45\020\ud8c8\udf40\ud8dd\udcea\ud83e\udf1f\ud8a6\udf64\022\ud84b\udca2\ud9ed\udf78\u7793\udb40\udff6\uda83\udfe6", "\u7708\u29a5\ub29d\000\ua2da\u14e4\ub4ca\u3d8e\u652c\u3e3b\u4f30\u478d\u7b3f\ud56d\u0ce8\000\u7a64\u6db6\u4120\ubc40\u4aa0\u1c34", "\udb0b\ude22",
        40, 91250, 1896790482, -5770622424285343925L, -6838L, false, true, (char) 17959, (char) 61624,
        Double.longBitsToDouble(0x3fe1a9c51bc0f05bL), Double.longBitsToDouble(0x3fe062a3b58d221eL)));
  }
  @Test(timeout = 4000)
  public void test180() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 5, 17, "\ud84c\udd43\udbe1\ude90K\udbca\udcc8\ud970\ude4a\udb42\udd42\ud960\uddd0\uda7f\udc22\uda79\udf7f\ud939\udf6b\u0d61\ud833\udcb8\udac5\udf25\ud906\ude0f", "hu\000\u6fc0\u93a2\ucff9\ucdf4\u810f\ubeee\u5e03\u80f7\u9e32", "\uda27\udd59",
        48, -1000, 205, 1014998764993610284L, -54459L, false, true, (char) 0, (char) 43068,
        Double.longBitsToDouble(0x3fedee40ee4fa711L), Double.longBitsToDouble(0x3fe6b66fc98bfc52L)));
  }
  @Test(timeout = 4000)
  public void test181() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 7, 5, "W\ud8ee\udd76\ud93c\ude15", "\uc129\u3ff7\ua345\u9f6a\u2bf8\uceea\u4c70", "\udb79\udff3\udb63\udcfe\ud92f\udcfb\udb16\udf41\ud8df\ude95",
        34, 63490, 608959744, 1087772873382306781L, 2885L, false, true, (char) 42700, (char) 56474,
        Double.longBitsToDouble(0x3fdff46f92680f20L), Double.longBitsToDouble(0x3fe82c7d0146b70cL)));
  }
  @Test(timeout = 4000)
  public void test182() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:JK |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 8, 15, "\ud839\udded\ud857\udcd3gy\ud89e\ude2e\uda32\udeb3\ue7d9\000\udb24\uddaf\uda96\ude4c\u7793\ud884\udc01\udb0c\udf25\uda1d\ude99\udb79\udff3\udb91\udedd\udb92\udd0dg\000\ud91d\udf4d\udad3\udd46\udbad\uddcc\ud9f5\udfe5\ud841\ude4a\ud920\ude43\ud82b\ude34\uda96\udeeb\ud8ce\udf7c\ud824\udcb0\uda3c\uddd8\ucf00\ud9f4\udcf0\udb62\udf95\ue34a\ud903\udf6c\udb95\udfae\udb25\ude78\udac1\udfe5\ud88f\ude84\ud992\udddd\uda48\ude68\udb2a\udcee\ud92d\udd49\udabb\udfba\udad3\ude0e\udbb9\ude21\udb1f\udf4f\ud8a5\udef1\uab02\udb19\udeaa\udb01\udf5b\udb2c\udc26\uda60\udcf2\uda26\udc63\udb0a\udc9d\ud9a1\udea2\ud87e\ude25", "\u9240\u3169\u3281\ub30f\u87f0\u90a2\u1697\u133e\ub689\u3011\u4eeb\ud4e2\u364c\uc692", "\udb85\ude22\ud975\udf02\ud9e7\udc9d\ud98d\udf13\uda81\udd79\ud9bb\udf6c\udb3f\udcce\udb90\udce9\udb25\udf70\udab3\udfb2\ud8c3\udfb2\ud857\udc09\udba0\udded\u1666\ud88b\uddeb\udb9d\udff2\udb43\udd22\ue1b7\udb39\udc69\uda07\udc54\uda6b\udee5\ud914\udf09",
        13, 1130, 1088309665, -6073599925694449255L, 24357L, false, false, (char) 10101, (char) 29196,
        Double.longBitsToDouble(0x3fe9cec47692e21dL), Double.longBitsToDouble(0x3fe26bb9ba26d57cL)));
  }
  @Test(timeout = 4000)
  public void test183() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:KK |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 1, 15, "\ud839\udded\ud857\udcd3g\ud8ba\udf59\ud89e\ude2e\uda32\udeb3\ue7d9\ud935\udc7a\udb24\uddaf\ud8c6\ude85\ud8b1\udd7c\ud887\udca9\udb0c\udf25\uda1d\ude99\udb79\udff3\udb91\udedd\udb92\udd0dg\000\ud91d\udf4d\udbe7\udcef\ud95b\udd3d\ud9f5\udfe5\ud841\ude4a\ud920\ude43\ud82b\ude34\uda96\udeeb\ud8ce\udf7c\ud824\udcb0\ud9dd\udd09\u7ddd\uda00\udddb\ud812\udc5b\ue34a\ud903\udf6c\udb95\udfae\udb25\ude78\udac1\udfe5\ud88f\ude84\ud992\udddd\ud82e\udd5a\udba3\udfa0\ud92d\udd49\udabb\udfba\u11a7\udaa8\ude01\udb1f\udf4f\ud8a5\udef1\uab02\udb19\udeaa\udb01\udf5b\udb2c\udc26\uda60\udcf2\uda26\udc63\udb0a\udc9d\ud9a1\udea2\ud87e\ude25", "\u9240\u06ab\ua76f\ub30f\u87f0\u747d\u012f\u133e\u4245\uad7e\u4eeb\ud4e2\u364c\uc692", "\udb85\ude22\uda79\ude9f\ud8bb\udf3b\ud8e0\udd87\uda81\udd79\ud9bb\udf6c\udb3f\udcce\udb90\udce9\udb25\udf70\ud961\udf89",
        21, 33277, 193990976, -4336832361491290085L, 84248L, true, true, (char) 17880, (char) 14882,
        Double.longBitsToDouble(0x3fea937a17373cb1L), Double.longBitsToDouble(0x3fed037c7d041f49L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.language.Caverphone|caverphone|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Metaphone|metaphone|java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.SoundexUtils|clean|java.lang.String|static",
    "M|org.apache.commons.codec.language.Caverphone|encode|java.lang.Object|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|encode|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|isCaverphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "C|org.apache.commons.codec.language.Caverphone|<init>|",
    "M|org.apache.commons.codec.language.Metaphone|encode|java.lang.Object|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|encode|java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|getMaxCodeLen||new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isLastChar|int,int|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isMetaphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isNextChar|java.lang.StringBuffer,int,char|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isPreviousChar|java.lang.StringBuffer,int,char|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isVowel|java.lang.StringBuffer,int|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|regionMatch|java.lang.StringBuffer,int,java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Caverphone|caverphone|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Metaphone|metaphone|java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.SoundexUtils|clean|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
