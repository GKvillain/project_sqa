package org.apache.commons.codec.language;
import org.junit.Test;
import static org.junit.Assert.*;
public class Caverphone_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 14, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41\u1717\u80bf", "\udaab\ude75\udaf8\udd44",
        44, 91075, -1210245875, 8290801601524403683L, -91594L, false, true, (char) 65394, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4c8baa2b8L), Double.longBitsToDouble(0x3feb0840ce0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 14, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41\u1717\ud0dd", "\udaab\ude75\udaf8\udd44",
        44, 91075, -1210245875, 8290801601524403683L, -91594L, false, true, (char) 65394, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4c8baa2b8L), Double.longBitsToDouble(0x3feb0840ce0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 14, 13, "\ud8af\ude63\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41\u1717\u80bf\u0dc5\u249d\uccf6\ua757\u1913\u4c68\uc78d\u107f\u5db6\ubbb5\u1fa3\u94a5\u32db\u0a6d\u453e\uaac4\u3526\u33c7\u4ed2\ud22a\u8dbf\uc0eb\u9483\u256a\u25d7\u3854\u0ff5\u8669\u5db2\u8e31\u2586\u81ec\u9945\u44ef\ua35b\u2124\u7673\u2088\uc8d7\ub3f8\u7a12\ucf29\u91ea\u39ef\u3d06\u8864\u8f2e\u6d81\uc5d8\u76ff\ud2df\u1bbd\u240f\u7134\u31ea\u77dc\u8773\u2f97\u9f45\u6df4\ubd63\u61e5\u4e57\u9e45", "\udb5a\udd01\uef8b\ud8b4\udcd9\ud923\udc86\udaa3\udf30\ud85c\ude7a\uda80\udcee\udbf1\ude84\ud98b\udd9f\udbb6\udf03\udbfe\udf66",
        2, 76316, -1946002484, -2791126806179580008L, 47059L, false, true, (char) 4531, (char) 28523,
        Double.longBitsToDouble(0x3fde5cb2760e8156L), Double.longBitsToDouble(0x3feb0118dc2fff79L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 14, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ucfa8\u99fa\ua858\u9c41\u1717\u80bf\u0dc5\u249d\uccf6\ua757\u1913\u4c68\uc78d\u107f\u5db6\ubbb5\u1fa3\u94a5\u32db\u0a6d\u453e\uaac4\u3526\u33c7\u4ed2\u5f35\ua121\u6472\u59cd\u5dfc\u5c83\u6de5", "\udbe2\udfad\ud884\udf38",
        12, 60010, 1812422094, -7136837276312714045L, 90259L, false, true, (char) 60051, (char) 50413,
        Double.longBitsToDouble(0x3febfcea8391e9d1L), Double.longBitsToDouble(0x3fe961a52912c122L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u99fa\ua858\u2766\u62c2\u80bf\u2ceb\u4238\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u5db6\ubbb5\u1fa3\u371e\ub326\u64ff\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514275242508412839L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 5, 14, 11, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41\u1717\u80bf", "\udaab\ude75\udaf8\udd44",
        44, 91075, -1210245875, 8290801599846088675L, -91594L, false, false, (char) 65394, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4c8baa2b8L), Double.longBitsToDouble(0x3feb0840ce0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 14, 17, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\u0eb6\u9c41\u1717\u80bf", "\udaab\ude75\udaf8\udd44",
        44, 91075, 539735203, 5802456797199131156L, 33459L, false, true, (char) 43857, (char) 5404,
        Double.longBitsToDouble(0x3feb7840ce0bb8a7L), Double.longBitsToDouble(0x3faf134105cf51a0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 0, 13, "\ud807\udf82\udb09\udc9e", "\u4de0\u7646\ua4e2\u823b\u4ab1\ub4fe\u736d\u4f2d\u0338\uccf6\ua757", "\udb14\udeba",
        49, 87588, -389047629, 2397226273975544149L, -99696L, true, true, (char) 14722, (char) 42153,
        Double.longBitsToDouble(0x3fdfba8ae6c39620L), Double.longBitsToDouble(0x3fe685c53b7aa63bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 2, 10, "\udb75\udf26\udb24\udcdf\ud84a\ude42\uda81\udfaa\udae2\ude8c\ud8cf\udd6c\udbaa\udfe4\u3725\uda34\ude57\uda69\udd46\ud857\udc74\uda91\udf59\ud994\ude76\udaa7\udd3e\udaf8\udd44\ud994\ude5f\ud814\udfa7\ud91f\ude12\udb47\udee8\udb34\udf5b\u061c", "\u32db\u0a6d\u453e\uaac4\u8508\uab7b\u4ed2\ua8be\u6e29", "\udbd9\udf89\ue0f5\uda48\udf53\u2ac8\udb48\udccc\uda8e\udd3b\udbbb\udc73\ud91c\udfed\udbc5\udddb\udb0e\udf0b\uf270\udb72\ude4f\ud97f\udc4b\udbe9\udc4b\udbbe\udfa2\udb89\udd3b\uda01\udd38",
        51, 3123, 1956854768, 2023333827584461368L, -55713L, true, true, (char) 19127, (char) 34118,
        Double.longBitsToDouble(0x3fe3edd0af288bc8L), Double.longBitsToDouble(0x3fe40656c4154a65L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 6, 11, 11, "\udb75\udebd\ud8de\udc37", "\ud02e\uaf74\u40e3\ud4ad\u9c8f\u0ba6", "\udb64\udccd\udaab\ude75\udaf8\udd44\udb66\udc12\udb6f\udcf7\uabbf\uda09\udcd1\ud8a9\ude10\ud977\ude3f\udba3\uded4\u5eab\ud8a7\udc84\ud8e9\uddab",
        51, 51536, -1464972124, 583570390860168033L, 89398L, true, false, (char) 63403, (char) 7765,
        Double.longBitsToDouble(0x3fbbfab01a23e0e8L), Double.longBitsToDouble(0x3fe30205a0eb8702L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 1, 17, 2, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9cdd\u1717\u80bf\u0dc5\u249d\u5483\ua757\ua1aa\u7287\uc78d\u107f\u5db6\u7254\u8ad0\u94d2\u32db", "\ud95d\ude88\uda87\udf7e\ud886\udea8\uda24\udcd2\uda19\udd39\udac9\udc0e\ud952\ude9f\udbcd\udc19\ud88b\udf25",
        55, 17980, -1374579782, 4470638651975313368L, -68450L, true, false, (char) 23668, (char) 60597,
        Double.longBitsToDouble(0x3fc5eaa5ae182d04L), Double.longBitsToDouble(0x3fcf5802bd8b8780L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 14, 1, "\ud806\udfe5\udb24\udcdf\ud84a\ude42", "\uab20\u99fa\ua390\u9c41\u1717\u80bf", "\ud9e1\udd08\udb5d\udeb6\ub9de\uda21\udf52\udac6\udccc\udb47\udee8\udb96\udc02\uda32\udf59\udba3\udf53\ud90d\udca6\ud8bd\udc80\udace\ude0d\uda92\udd33\u7fda\udaa1\udf84\ud886\udea8\udb4d\udf07\ud837\udfe4\ud80f\udc8c\ud861\udc3e\ud9af\udfc3\u2b74\udb99\udd67",
        53, -926, 214784176, 3295305361446908914L, 41345L, false, true, (char) 24445, (char) 55202,
        Double.longBitsToDouble(0x3fe32e217ffe9204L), Double.longBitsToDouble(0x3fdd412741814d14L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 16, 7, 7, "\u0407\uda72\udef8\udae3\udce3\udb16\udf5c\ud8c0\udc1e", "\ua8b8\u3cd5\u4eec\u80bf\u5db3\u5fb3\ubee9", "\udbd8\ude03\udac2\udf69\udb8d\udd99\ud9ea\uddf5\ud927\ude59\uda4f\ude18\ud8da\udc9b\ud8d1\udfe4\udb74\udc36",
        19, 3740, -1464949497, 583570393940917079L, -93929L, false, true, (char) 59239, (char) 53049,
        Double.longBitsToDouble(0x3fc79d912ae46ba4L), Double.longBitsToDouble(0x3fb13f8e692412d0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 10, 12, 6, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41", "\udaf9\udc8b\udb62\udfb8\udaab\ude75\udaf8\udd44\uda8f\udcf9\ud80a\udd7d\ud9e3\udc53\udb47\udf2e\ud9d9\udc59\ud80c\ude16\udb87\udd4c\u5eab\ud8a7\udc84\ud8e9\uddab\uda71\udc18\ud93a\udd5f\uda87\udf7e\ud886\udea8\uda95\udf2c\uda47\udc35\ud8f4\udf84\uda78\udc5d\uda65\udd8f\ud91c\udc6c\ud940\udf95\udb14\udf26\ud98b\ude32\ud996\udd44\ud8bf\udf33\ud9a0\ude5a",
        -4, 83361, -1294215563, 8994022360006389066L, -44006L, true, false, (char) 50316, (char) 31733,
        Double.longBitsToDouble(0x3fec0474737d6754L), Double.longBitsToDouble(0x3fe821a496a727d6L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 11, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41\u1717\u80bf", "\ud8a1\udf12\udb80\udf0a\uda8f\udcf9\ud80a\udd7d\udac6\udccc",
        23, 11475, -1892091552, 5649927040142125397L, -28224L, false, false, (char) 60124, (char) 890,
        Double.longBitsToDouble(0x3fe05dc53a27ff5aL), Double.longBitsToDouble(0x3fd0b505cf6fbe9aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 2, 8, "\uda15\udc17\ud920\udd75\ud858\ude62", "\u6b13\u4818\u2a6c\u3984", "\uda96\udda7\udb95\uddd3\udaab\ude75\udade\udcd7\ud946\udd78\udbbb\udf71\ud875\udc61\ua55f\udbf5\udc8e\uda32\udeba\ud95d\uddf1\udad8\udcda\ud809\udd32\ud8e9\uddab\ud861\uddf1\ud93a\udd9b",
        17, 49017, 366443260, 2125908480600498372L, -2424L, false, true, (char) 9518, (char) 45500,
        Double.longBitsToDouble(0x3fe17ddbe9dd0d42L), Double.longBitsToDouble(0x3fe746f5bc715280L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 6, 14, 13, "\udb75\ude82", "\u57e5\u4db5\ud220\u99fa\ua858\u64a2", "\ud90b\udc94\udb62\udfb8\udaab\ude75\udaf8\udd44\udb4b\udcf7\udbd0\udd80\ud927\uddfc\ucde2\udbc0\ude40\uda32\udeba\udba3\udf53\u5eab\ud8a7\udc84\ud8e9\uddab\uda71\udc18\ud93a\udd5f\uda87\udf7e\udb90\udcd8\uda95\udf2c\ud9b1\uddab\ud845\uddaa\ud933\udc4b\udaea\udd98\udb15\udcad\udae9\udec0\udbe8\udecc\uda33\udc9d\ud81f\uddbe\ud840\udcd3\ud990\ude27",
        59, 33715, 2090157189, -7552060605913980376L, -50995L, false, true, (char) 14571, (char) 6893,
        Double.longBitsToDouble(0x3fe0e2706fa2694eL), Double.longBitsToDouble(0x3fd0e5928d5fde04L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 15, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\ub42b\u1717\u80bf", "\udbf3\udf7b\udbb1\udf36",
        44, 90882, 1390222605, -7801028155632820589L, -91594L, false, true, (char) 65507, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4c8baa2b8L), Double.longBitsToDouble(0x3feb0840ce0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 4, 14, 11, "\ud983\udd3e\udb22\udfcc\ud84a\ude42\uda81\udfaa\ud8b1\uddee\ud907\ude50\udbde\udc69\u3725\uda34\ude57\uda69\udd46\ud857\udc74\ud90b\udc94\udb62\udfb8\udaab\ude75\udaf8\udd44\uda8f\udcf9\ud80a\udd7d\udac6\udccc\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\u5eab\ud8a7\udc84\udb06\udf86\ud883\udf22\ud921\uddc8\uda87\udf7e\ud886\udea8\uda95\udf2c\ud86a\udee7\udaa0\udf4e\uda48\udcdd\ud986\ude69\udaef\ude65\udbb3\udc6a", "\ubf08\u0258\u8845\uca74\u7c36\u1d9e\u2f86\u4c6d\u5d2c\u4ead\u9b9b\ubb8c\u505b\u7936\u9598\u5ea2\u0b4c\ucff5\u7e3e\u1ad9\u010c\ub103\u6a02\ub4f0", "\ud8d6\uddc1\ud8fd\udf2d\udbf2\udcd0\ud9e5\uded9\ud994\udf8a\ud98e\udf2e\udb66\ude3a\ud818\udea5\ud9d2\ude05\ud8fa\udecc\ud979\ude0f\ud8df\ude63\ud828\udf0b\ud9f5\udd7c\uda7d\ude47\ud81d\udc9e\udb81\udf6f",
        58, 14025, -956339140, 4886201119447648868L, -27539L, true, true, (char) 320, (char) 12404,
        Double.longBitsToDouble(0x3feb1c068d17eef2L), Double.longBitsToDouble(0x3fd2700d86648f02L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 14, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\u3ebb\u99fa", "\uda69\udd46\ud857\udc74",
        0, 87158, -975627805, -4729671163952600417L, -27027L, true, false, (char) 33009, (char) 56733,
        Double.longBitsToDouble(0x3fe22f4021554e68L), Double.longBitsToDouble(0x3fcacb5164da8678L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 5, 13, "\uda25\udc98\ud8d8\ude5e\ud857\udc8b\uda81\udfaa\ud8b1\uddee\ud907\ude50\ud9de\ude49", "\u1717\u80bf\u0dc5\u249d\u33c7\ua757\u1913\u4c68\u21bc", "\ud9af\udc57\ud95e\udc37\u5eab\ud8a7\udc84\ud8e9\uddab\ub696\u04ec\uda87\udf7e\ud886\udea8\uda95\udf2c\udbad\udea1\ud960\udf07\ud8fe\udfd2\uedb6",
        9, 14149, -1276234820, 3735419095871781287L, 67004L, true, false, (char) 28334, (char) 34820,
        Double.longBitsToDouble(0x3fe319adf2083cc1L), Double.longBitsToDouble(0x3fc785980d05f0e0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:\012",
        Z.run(T, 2, 6, 2, 4, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41\ud46c\u40a1", "\uda72\uddcd\udaf8\udd44\udbe3\udd03\ud80a\udd7d",
        40, 39673, 1243221475, -4073018367404797192L, 74447L, false, false, (char) 65394, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4c8baa2b8L), Double.longBitsToDouble(0x3feb0840ce0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 14, 11, "\udb75\ude82\udb24\udcdf\ud84a\ude42\uda81\udfaa\ud8b1\uddee\ud907\ude50\udbde\udc69\ud979\udd5a\uda07\udeb3\uda61\ude6b\ud9fc\udc67\ud90b\udc94", "\ua757\u1913", "\ud810\udd4e\udbb8\udc4b\ud879\udd27\ud8c6\udd37",
        8, 22908, -1001666221, -8627602451120855136L, 57915L, true, false, (char) 30355, (char) 7640,
        Double.longBitsToDouble(0x3fe44c8840051b8fL), Double.longBitsToDouble(0x3fd60be1e61d6976L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb75\ude82\udb24\udcdf\ud84a\ude42 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 13, 4, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41\uc54f\u78b4", "\udaab\ude75\udaf8\udd44",
        44, 91075, 14490893, 8290801601524403683L, -91594L, false, true, (char) 65394, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4c8baa2b8L), Double.longBitsToDouble(0x3feb0840ce0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb75\ude82 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 15, 8, 9, "\udb75\ude82", "\u719b\u11d7\ud2e5\u3834\u11f0\ua85e", "\udbfc\udc23\udb5b\udcd5\udaab\ude75",
        19, 26063, -1735080820, -5208534312834639839L, 98320L, true, false, (char) 5566, (char) 47141,
        Double.longBitsToDouble(0x3fc027ce8cceac80L), Double.longBitsToDouble(0x3fe8f2ca24a41da6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\u432d\u3725\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\u432d\udbde\udd87\udaa0\ude53\ud854\ude11\udb80\udccc\uda34\ude74\ud925\ude15\u3725\uda34\ude57 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 2, 13, 7, "\u432d\udbde\udd87\udaa0\ude53\ud854\ude11\udb80\udccc\uda34\ude74\ud925\ude15\u3725\uda34\ude57", "\u1ccb", "\udaf2\udd44\ud88c\ude16\ud80a\udd7d\udac6\udd71",
        4, 91163, -1892094368, 5649926764192966997L, 24714L, true, false, (char) 43754, (char) 47431,
        Double.longBitsToDouble(0x3fe3b48a4a18d2beL), Double.longBitsToDouble(0x3fd1f71c9d0cf04aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb75\ude82\udb24\udcdf\ud84a\ude42 |this=org.apache.commons.codec.language.Metaphone:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 14, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u09e3\u6d27\u80bf", "\udaab\ude75\udb26\ude3b",
        44, 89803, -1210245693, 8290801598940712419L, -91594L, true, true, (char) 23245, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4caa9476cL), Double.longBitsToDouble(0x3fe90b094e0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 13, "\udb75\ude82\udb75\udc28\uda63\ude71\uda81\udfaa\ud877\udd30\ud9e7\ude9f\ud96e\udd9e", "\u1717\u80bf", "\udaab\ude75\udaf8\udd44",
        47, 52097, 110641279, 8290802065380871651L, -75210L, false, true, (char) 65394, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4d0baa2b8L), Double.longBitsToDouble(0x3fe30a5abea31daeL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 0, 14, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41\u1717\u80bf", "\udaab\ude75\udaf8\udd44",
        54, 54147, -1210234018, 8290801601524403683L, -91594L, true, true, (char) 65394, (char) 28644,
        Double.longBitsToDouble(0x3fe530ed322ea88eL), Double.longBitsToDouble(0x3feb0840ce0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 5, 14, 13, "\u3d2f", "", "\ud907\ude50\udb80\udc5a\u3725\uda01\udd1f\uda69\udd46\ud857\udc74",
        32, 87158, -975627805, 234344693262848L, -27027L, true, false, (char) 33009, (char) 17274,
        Double.longBitsToDouble(0x3fe5ac7801554e68L), Double.longBitsToDouble(0x3fcacb5164c0f9d0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 17, 10, 13, "\000\000\000", "", "\u3725",
        21, 10352, 0, 0L, -100000L, true, false, (char) 41171, (char) 18957,
        Double.longBitsToDouble(0x3fa0dbeede3730e0L), Double.longBitsToDouble(0x3fd604a0056b1e70L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 17, 8, 12, "\udb75\ude82", "\u57e5\u4db5\ud220\u99fa\ua858\u9c41", "\ud90b\udc94\udb62\udfb8\udaab\ude75\udaf8\udd44\uda8f\udcf9\ud80a\udd7d\udac6\udccc\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\u5eab\ud8a7\udc84\ud8e9\uddab\uda71\udc18\ud93a\udd5f\uda87\udf7e\ud886\udea8\uda95\udf2c\udb9b\ude60\ud857\udc4f\udb27\udc64\ud82a\uddfc\ud8a6\udfec\ud9a7\ude1f\udabe\ude2d\ud8f5\udee9\ud891\udf6d\ud894\udd9c\udb4f\ude87",
        59, 31759, 1730964142, 1698478933033756784L, 12342L, true, false, (char) 45729, (char) 5082,
        Double.longBitsToDouble(0x3fe1b29f139533acL), Double.longBitsToDouble(0x3fd179c4b8ecddacL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 14, 0, "\000", "\000", "U",
        -5, 14160, 0, -458944975L, 89981L, true, true, (char) 10492, (char) 28421,
        Double.longBitsToDouble(0x3f8a5a6a086df740L), Double.longBitsToDouble(0x3fde3730e2c09434L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb75\ude82\udb24\udcdf\ud84a\ude42 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 12, 14, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\u098b\u6f72\u4fac\u9c41\u1717\u80bf", "\udaab\ude75\udaf8\udd44",
        44, 91075, -1210245875, 8290801601524403683L, 47787L, false, true, (char) 31585, (char) 33956,
        Double.longBitsToDouble(0x3fe93d6e7fa088aeL), Double.longBitsToDouble(0x3fdadbf88483d33eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 1, 16, 1, "\ud912\udcc1\udab2\ude8d", "\u704d\ua1e4\u99fa\ua80a\u9530\u1717\ud0dd\u0dc5", "\ud852\ude98\uda87\udfd3",
        15, 59653, 1930352673, 6541666447582038504L, -93450L, false, false, (char) 1956, (char) 8563,
        Double.longBitsToDouble(0x3fe81acd28251165L), Double.longBitsToDouble(0x3fe1754575610819L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 3, 14, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ucfa8\u99fa\ua858\u9c41\u1717\u1d51\u0de2\u249d\uccf6\ua757\u1913\u4c68\uc78d\u107f\u5db6\ubbb5\u1fa3\u94a5\u32db\u0a6d\u453e\uaac4\u3526\u33c7\u4ed2\u5f35\ua121\u6472\u59cd\u5dfc\u5c83\u6de5", "\u2a89\ud884\udf38",
        12, 60010, 1812422094, -7136837276312714045L, -28115L, true, true, (char) 60051, (char) 50413,
        Double.longBitsToDouble(0x3febfcea8391e9d1L), Double.longBitsToDouble(0x3fe961a52912c122L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 7, 8, 13, "\udb75\ude82\ud8ad\uded1\ud98a\udca5", "\u4da2\u9a2a\ua858\u08eb\u98b3\ucef7\u30f1\u249d\ucd9a\ua757\u6301\u70ae\uc78d\u107f\ub2fe\u119c\u8b8f\u8b5f\u7eaa\u8e27\ud47b\ua081\u34a4\u33c7\u4ed2\u46aa\u0d58\u6472\u59cd\u6d0f\u3e36\ud5cb", "\udbe2\udfad\ud9f3\udefe",
        20, 60010, 1812422094, -7136837276312714045L, 90259L, false, true, (char) 45203, (char) 24129,
        Double.longBitsToDouble(0x3fe8d39a832a9a4eL), Double.longBitsToDouble(0x3fe961a52912c122L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 5, 4, 15, "\uda96\udc15\ud9c3\ude62\ud849\udc29", "\u82df\u9a53\u2afe\ucfa5\u1717\u80bf\u0dc5\u249d\uccf6\ua757\u1913\u4c68\u6683\uc161\u056e\ubbb5\u80ed\uae8e\ub0e7\u0ab8\u453e\uaac4\ub6c7\u709a\u4ed2\u5f35\ua121\u6472\u59cd\u5dfc\u5c83\u235c", "\udbe2\udfad\ud884\udf38",
        12, 60010, 1812422094, -7137078069359196989L, -99715L, true, true, (char) 1232, (char) 28002,
        Double.longBitsToDouble(0x3fe961a52912c122L), Double.longBitsToDouble(0x3fe133364ca23e2dL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb75\udf49\udb24\udcdf\ud9e9\udf0f\ud878\udfc2\udab8\udda6\ud906\udfd8\udbde\udc69\u3725\uda34\ude57\uda69\udd46\ud857\udc74\udb80\udd0e\udb4f\udd40\ud8b8\ude3b\ud847\udfb1\ud998\udcad\ud960\udd66\udb69\udde7\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\u5eab\ud8a7\udc84\ud8e9\uddab\ud956\udf8a\udb1d\udfa9\uda8a\udd94\u26fd\udada\ude44\ud9e5\udedb\ud86f\ude3c\uda14\udf35\ud996\uddda |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 15, 7, 16, "\udb75\udf49\udb24\udcdf\ud9e9\udf0f\ud878\udfc2\udab8\udda6\ud906\udfd8\udbde\udc69\u3725\uda34\ude57\uda69\udd46\ud857\udc74\udb80\udd0e\udb4f\udd40\ud8b8\ude3b\ud847\udfb1\ud998\udcad\ud960\udd66\udb69\udde7\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\u5eab\ud8a7\udc84\ud8e9\uddab\ud956\udf8a\udb1d\udfa9\uda8a\udd94\u26fd\udada\ude44\ud9e5\udedb\ud86f\ude3c\uda14\udf35\ud996\uddda", "\u6de5\u7fac\u8556\u4d47\ud5fc\u8f16\u0d66\u6086\uc6eb\u28c0\u0159\u153b\u9de1\u3d9a\u6e94\u19c9\u182c\u30aa", "\udba4\udd65\uda4f\udf66\ud9b8\ude23\uda39\udc35\udaf5\udd5c\udbc8\uddea\ud8f4\uddd7\udac1\udda1\u0c87\ud9b2\udc8d\udacd\udc7f\uda9e\udc3e\ud876\udd25\ud8de\ude12\udb8d\udd25\ud88f\udde0\ud951\udfbc\udba2\udcc0\udbff\udc7f\uda56\udc22\udb31\udf86\udb28\udc21\ud959\udfcc\ud9a6\ude91\u810b\uda3d\uddb3\udbbd\udfdf\ud930\udc46\ud9d3\udfee\ud8c3\udffb\ud86e\udd6e\ud82d\udd43\ud9a7\udc0b\ud91f\ude1c\udb4e\uded4\uda42\udd9a",
        31, 49158, -462926574, 8060087816006116109L, 95671L, false, true, (char) 18229, (char) 20688,
        Double.longBitsToDouble(0x3fd5ceafc1c7d15aL), Double.longBitsToDouble(0x3fcbf173689dd0ecL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 9, 14, 13, "\000\000\ud84a\ude42", "\000", "",
        49, -1000, 1255671808, -1971153868734351074L, 43661L, true, true, (char) 0, (char) 3328,
        Double.longBitsToDouble(0x3fd604a1a16b1e70L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\udb10\udc87\u0099", "\u81cf\000\ua858\u2766\u62c2\u80bf\u2ceb\u4238\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u5db6\ubbb5\u1fa3\u371e\ub326\u64ff\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514014202986096551L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb3f\udf77\udb24\udcdf\ud843\udd90 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 13, 15, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u9e93\u331e\uc294\u030d\u80bf\u2ceb\u4238\uc0fd\u4a8d\u9f24\u9678\ub96b\u107f\u5db6\ubbb5\u1fa3\u371e\ub326\u64ff\u2e1f\uaac4\u56a3\ucf28", "\udb92\udd3a\ud9eb\udd43",
        41, 26000, -707346135, 4483107283316631463L, 82271L, false, true, (char) 42446, (char) 35722,
        Double.longBitsToDouble(0x3fbb1054f0a3b9f8L), Double.longBitsToDouble(0x3fe7529790cf0f4eL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 3, 13, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u99fa\ua858\u2766\u62c2\u80bf\u2ceb\u4238\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u5db6\ubbb5\u1fa3\u371e\ub326\u64ff\u4606\uaac4\u56a3\ub8b7", "\udb8e\uddd1",
        38, 87449, -117074829, -2922060825321149078L, -68480L, true, true, (char) 65433, (char) 8655,
        Double.longBitsToDouble(0x3fc1e17bd1b10628L), Double.longBitsToDouble(0x3fe0a3b9feea52f2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:M |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\ud87f\udf77M\ud843\udd90", "\u81cf\000", "\udaca\udd3c\ud857\udc74",
        49, 65422, 1095719830, -6852387361728789055L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3ec6400000000000L), Double.longBitsToDouble(0x3fef7bb25fa08844L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 11, "", "\ud63b\ua4bf\000\ud2b2\u99fa\ua858\u2766", "\uda21\uddf3\udb82\ude68\ud90b\udf6f\ud926\udc8e\u5c1b\ud80a\udd8e\ud9e6\udcc2\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\udb71\udf8a\ud85c\uddbf\uda73\udfc3\u5bf3\ud900\uddbf\ud98d\udf20\ud8ba\udd0e\uda95\udf2c\ud8bc\udd71\u10ed",
        -5, 80824, -117074829, -2922060825321149078L, -68480L, false, true, (char) 65433, (char) 8655,
        Double.longBitsToDouble(0x3fc1e17bd1b10628L), Double.longBitsToDouble(0x3fe0a3b9fe0052f2L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 3, 7, 11, "\ud9a4\udef5\udba4\uddc8\ud843\udd90", "\ud2b2\u99fa\ua858\u2766\u62c2\u80bf\u2ceb\u4238\uc0fd\u8d73\u8d7e\u4c79\u4193\u107f\u5db6\ubbb5\u1fa3\uc163\ub326\u64ff\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514275242508412839L, 82271L, false, true, (char) 1743, (char) 24685,
        Double.longBitsToDouble(0x3fbb106290a3b9f8L), Double.longBitsToDouble(0x3fb360fc843d4b70L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb3f\udf77\udb66\udcbc\ud9f5\ude99 |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb3f\udf77\udb66\udcbc\ud9f5\ude99 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 13, 15, 13, "\udb3f\udf77\udb66\udcbc\ud9f5\ude99", "\ud3cc\u99fa\ua858\u2766\u62c2\u7f19\u2d08\u3738\uc0fd\u8d73\u8d7e\u4c79\uca03\u08ba\u5db6\ubbb5\u1fa3\u371e\ub326\u846d\u2cd1\uaac4\u56a3\uc528", "\ud860\uddda\ud8e7\udd81",
        -5, 45611, -1636646615, -6605912084932703381L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\000", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u00ef\uaac4\u56a3\000", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 0, "", "\ud63b\u5557\ud280\ud2b2\u99fa\ua858\u2766", "\uda21\uddf3\udb82\ude68\ud90b\udf6f\ud90a\ude65\u5c1b\ucee4\000\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\udb71\udf8a\ud85c\uddbf\udaa1\udfc3\uda71\udce0\ud93a\udd5f\ud98d\udf20\ud8ba\udd0e\uda95\udf2c\ud8bc\udd71\udb8e\uddd1",
        38, 87449, -117074829, -2922060825321149078L, -68480L, false, false, (char) 50019, (char) 8655,
        Double.longBitsToDouble(0x3fc1e17bd1b10628L), Double.longBitsToDouble(0x3fe0a3b9feea52f2L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ucc08", "\ud838\ude14\udaca\udd3c\ud857\udc74\uda21\uddf3\udb82\ude68",
        17, 66585, 1808205516, 3257737384606820109L, 34627L, false, true, (char) 8685, (char) 27069,
        Double.longBitsToDouble(0x3fcad7f6432c3dd0L), Double.longBitsToDouble(0x3fef7bb25fa08844L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 1, 3, "\udb3f\udf7e\udb24\udcdf\ud843\udd90\ud9b1\udce5\uda91\uddba\uda89\ude81\udbde\udc96\u3725\ud838\ude14\uda31\uddaf\ud857\udd0d\uda21\uddf3\udb82\ude68\ud90b\udf6f\u884d\udaac\udfd3\ud80a\udd8e\ud9e6\udcc2\udb47\udee8\udbc0\ude40\uda32\udeba", "\ub326\u3436\u77be\uaad0\u838b\uc528\u4ed2\u56c9\u0ec9", "\udad3\udc09\ud8a9\udec5\ud860\udd1b\udbf0\udfd6",
        34, 28807, -797916316, 855210444515333263L, 71540L, false, false, (char) 10214, (char) 24429,
        Double.longBitsToDouble(0x3fe64936fadec259L), Double.longBitsToDouble(0x3fda1dd77cede9beL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 0, 7, 13, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u99fa\u2f29\ube65\u62c2\u80bf\u2ceb\ub799\uc121\ubf5f\u8d51\u12e0\ucf73\u97a7\u79d0\ubbb5\u1fa3\u050b\u2294\u648c\u0eac\uaac4\u56a3\uc528", "\ud8fb\udf79\ud8e7\udd6f",
        5, 98775, 42414589, 4514275239363970260L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fe0102dce14fa46L), Double.longBitsToDouble(0x3fcd4a5e599053bcL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 10, 13, "\udb3f\udf77\u5058\udb1c\ude9d", "", "",
        -5, 82096, 261017682, 5393069395906753073L, -57910L, true, false, (char) 9896, (char) 15019,
        Double.longBitsToDouble(0x3fe86801a8211cffL), Double.longBitsToDouble(0x3f3cc38000000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\udb3f\udf77\udb24\udcdf\ud843\udd90\udb64\udf3c\uda79\udf15\ud9f5\ude05\udbaf\udcb0\ud83a\udffa\ud94a\udfdb\ud924\udd0d\ud857\udc74\uda21\uddf3\udb82\ude68\udb99\udf71\udaca\ude20\ud966\udfd1\udba3\uddb5\ud9e6\udd13\udb11\udda5\udbc0\uddb7\uda32\udeba\udba3\udf53\udb71\udf8a\ud85c\uddbf\udaa1\udfc3\uda95\udd11\ud8ad\uddac\ud98a\udf99\ud8ba\udd0e\uda95\udf2c\ud8bc\udd71\udb8e\uddd1\ud8e7\udd81\udbd5\udde8\udad3\udc09", "\ub003\u0172\u975c\ub305\u076f\uaa3c\u29c1\ucc27\u681a\u24c7\uc6c3\u4feb\u5847\u2525\u12e0\ud1f9\u627e\u9ded", "\ud9fd\ude07",
        55, 23917, -1811143577, -145432408337263663L, -84780L, false, false, (char) 19710, (char) 20759,
        Double.longBitsToDouble(0x3fdf9d4be4cd6e80L), Double.longBitsToDouble(0x3fe103a2b3d9e499L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 5, 17, "\udb3f\udf77", "\u5557\ud280\ud2b2\u99fa\ua858\u2766", "\uda21\uddf3\udb82\ude68\ud90b\udf6f\ud926\udc8e\u5c1b\ud80a\udd8e\ud9e6\udcc2\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\udb71\udf8a\ud85c\uddbf\udaa1\udfc3\uda71\udce0\ud93a\udd5f\ud98d\udf20\ud8ba\udd0e\uda95\udf2c\ud98a\udd56\uda1a\ude92",
        7, 13616, -117112448, -2922060825321149078L, -68480L, true, true, (char) 65433, (char) 8655,
        Double.longBitsToDouble(0x3fc1e17bd1b10628L), Double.longBitsToDouble(0x3fe0a3b9feea52f2L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u99fa\ua858\u2766\u62c2\u80bf\u2ceb\u4238\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u5db6\ubbb5\u1fa3U\ub250\u9ca5\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514275242508412839L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 2, "\udb3f\udf77\u5058\000", "\ud2b2\u99fa\ua858\u2766\u62c2\u80bf\u2ceb\u4238\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f", "\udba3\udf53\udb71\udf8a\ud85c\uddbf\udaa1\udfc3\uda71\udce0\ud93a\udd5f\ud98d\udf20\ud8ba\udd0e",
        -2, 13155, 254546157, -8562569389392061983L, -18377L, false, true, (char) 9804, (char) 54061,
        Double.longBitsToDouble(0x3feffa2b23643c36L), Double.longBitsToDouble(0x3fd5ed07091e17bcL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 7, 7, 14, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u99fa\ua858\u2766\u62c2\u5d90\u2ceb\u278e\u18c3\u8d73\u8d7e\u4c79\ub96b\u107f\u5db6\ubbb5\u1fa3\u371e\ub326\u64ff\u4606\uaac4\u6490\uc528", "\udb8e\uddd1\ud8e7\udd81",
        24, 87152, 909498586, 5659743404365281734L, 58167L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:\u3725\u5c1b\012",
        Z.run(T, 2, 17, 2, 17, "\udb3f\udf77\udb24\udcdf\ud843\udd90\udb64\udf3c\uda79\udf15\ud907\udee2\udbde\udc69\u3725\ud838\ude14\ud97f\udeda\ud857\udd01\uda21\uddf3\udb82\ude68\ud90b\udf6f\ud926\udc8e\u5c1b\udb08\udd8d\ud9e6\udcc2\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\udbbd\ude9b\ud85c\udd75\udaa1\udfc3\uda71\udce0\ud99f\udd52\ud96d\udd10\udb97\udfdd\uda95\udf1b\ud8bc\udd71", "\ud20e\u9c2d\u1119\u37aa\ub003\u7d5e\u975c\ub305\u076f\uaa3c\u29c1\u5863\u89b8\u5b88\u5aa4", "\ud877\udcf9\ud921\udcc8\ud8f5\udd57\ud80d\udca4",
        5, 87885, 1279165917, -6802953941532428081L, 60962L, true, false, (char) 1545, (char) 4152,
        Double.longBitsToDouble(0x3fdef20e924857acL), Double.longBitsToDouble(0x3feaa79c8da2b561L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 0, 2, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u99fa\ua858\u2766\u38fb\u80bf\uca40\000\000\u8d4a\u00c1\u4b95\015\000\000\000\000\000\u00d6\000\u4517\uaac4\u56a3\u5315", "",
        -5, 68344, -1129899551, 1570596525703168L, -100000L, false, false, (char) 0, (char) 49919,
        Double.longBitsToDouble(0x3fd5ed07000017bcL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:\012",
        Z.run(T, 2, 11, 2, 13, "\udb3f\udf77", "\u5557\ud280\ud2b2\u99fa\ua858\u2766", "\uda21\uddf3\udb31\udf1f\udbf9\udd1d\udb8f\uddd1\ud8f9\udd2d\ud86d\uddbf\ud9e5\udd32\udb47\udee8\udbc0\ude40\ud8b7\udc9a\udba3\udf7e\udb71\udf8a\ud85c\uddbf\udaa1\udfc3\uda71\udce0\ud93a\udd5f\ud9eb\udf2f\ud8ba\udcb2\uda95\udf2c\ud8bc\udd71\udb8e\uddd1",
        38, 87449, -117074829, -2922060825321149078L, -68480L, true, true, (char) 65433, (char) 8655,
        Double.longBitsToDouble(0x3fc1e17bd1b10628L), Double.longBitsToDouble(0x3fae3820eea52f20L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 11, 7, 13, "", "\ud63b\u5557\ud280\ud2b2\u5185\ua858\u2766", "\000",
        11, 70830, -1595445719, 758501092L, 86401L, true, true, (char) 17274, (char) 8685,
        Double.longBitsToDouble(0x3feaaa7340d6bfb2L), Double.longBitsToDouble(0x3fc961ee8fbdd92cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 0, 16, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u99fa\ua858\u2239\u29c7\u80bf\u2ceb\u4238\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u5db6\ubbb5\u1fa3\u371e\000\u64ff\ubc3f\u0fa1\000\000", "\udb8e\uddd1",
        38, 87449, -117074829, -2922060825321149078L, -68480L, true, false, (char) 65433, (char) 8655,
        Double.longBitsToDouble(0x3fc1e17bd1b10628L), Double.longBitsToDouble(0x3fe0a3b9feea52f2L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\ud843\udcf7", "\ud2b2\u99fa\ua858\000\u6270\u80bf\u2ceb\u4238\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u5db6\ubbb5\u1fa3\u371e\ub326\u64ff\u62b5\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514275242508412839L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 13, "\udb1d\udc77\udb24\udcdf\ud843\udd90", "\u353c\u99fa\ua858\u2766\u62c2\u80bf\u7d83\u57be\u84de\u57d7\u8cfc\u4c79\ub96b\u107f\u40da\ubc0d\u1fa3\u371e\ub326\u64ff\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, 90161449, 8349272960108717991L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529450980f4eL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:\000 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000", "", "\ud907\udee2\udbde\udc69\u3725\ud838\ude14\udaca\udd3c\ud857\udc74\uda21\uddf3\udb82\ude68\ud90b\udf6f\ud926\udc8e\u5c1b\ud80a\udd8e\ud9e6\udcc2\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\udb71\udf8a\ud85c\uddbf\udaa1\udfc3\uda71\udce0\ud93a\udd5f\ud98d\udf20\ud8ba\udd0e",
        -2, 13155, 254546157, -8562569389392061983L, -18377L, false, true, (char) 9804, (char) 54061,
        Double.longBitsToDouble(0x3feffa2b23643c36L), Double.longBitsToDouble(0x3fd5ed07091e17bcL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 5, 14, 11, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ud220\u99fa\ua858\u9c41\u1717\u80bf", "\udaab\ude75\udaf8\udd44\uda8f\udcf9\ud80a\udd7d\udac6\udccc\udb47\udee8",
        17, 33487, 1315476149, 6524494668761407702L, 98335L, false, true, (char) 7192, (char) 10235,
        Double.longBitsToDouble(0x3fabcc6f3fd1f4a0L), Double.longBitsToDouble(0x3fe684272847e580L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.String:\u72af\012",
        Z.run(T, 1, 2, 17, 6, "\udb75\udebd\uda7c\udc27\uda44\udc7f\ud81c\uddca\udba0\udcf7\ud866\udd78\ud916\udf4d\u72af\ud959\udf51\ud82f\udf97\ud9d6\udc9b", "\uccf6\ua757\u5b13\u90c4\u7ad0\u5d80\ua122\u6c26\u1f24\u94a5", "\ud95d\udd8e\ud9c5\udf4f\ud855\udfaa\ud886\udea8\uda95\udf2c\u86c1\uda17\uddb6\ud982\udcb3\udbee\udcc4\ud8e5\uddb4",
        59, 17148, -9704768, -1179803860521612452L, 98747L, false, false, (char) 17490, (char) 17223,
        Double.longBitsToDouble(0x3fe55da74c557297L), Double.longBitsToDouble(0x3fe23d300302b734L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udbae\uddfd\ud8b6\udfe6\udb54\udd20\uda81\udf1b |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 14, 11, 5, "\udbae\uddfd\ud8b6\udfe6\udb54\udd20\uda81\udf1b", "\u12df\u103c\u5cdc\u0ba6\u1d92\u048c\u6617\ub11b\ua757\u790a\u1887", "\ud896\udcc6\udba9\udce2\udbb9\udf13\ud9cc\udc93\ud8a6\udfc4\ud8e9\uddab",
        1, 47128, -1135192887, 626366838016346043L, 89398L, false, false, (char) 63403, (char) 44090,
        Double.longBitsToDouble(0x3fefb3ea13447c1dL), Double.longBitsToDouble(0x3fe30205a2eb8702L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb1a\udfe2\udb1e\udc84\ud84a\ude42 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 9, 12, 1, "\udb1a\udfe2\udb1e\udc84\ud84a\ude42", "\uab20\u99fa\ua390\u9c41\u1717\u8ad5", "\ud9e1\udd08",
        0, 17799, 1600578773, -5219358549543561183L, 98145L, true, false, (char) 63420, (char) 46926,
        Double.longBitsToDouble(0x3fd30d9a308589a4L), Double.longBitsToDouble(0x3fda088449544b90L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud806\udfe5\udb24\udcdf\ud84a\ude42\uda81\udfaa\ud8b1\uddee\ud8fd\udf50 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 5, 12, 15, "\ud806\udfe5\udb24\udcdf\ud84a\ude42\uda81\udfaa\ud8b1\uddee\ud8fd\udf50", "\ud056\u1774\u80bf\u2345\u725c", "\ub9de",
        -1, 36125, 1930352673, -6415002454148449793L, 11312L, false, false, (char) 13796, (char) 55921,
        Double.longBitsToDouble(0x3fe1754573610819L), Double.longBitsToDouble(0x3fde63df6cbe439eL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String:\u3725\u5eab\012",
        Z.run(T, 1, 2, 12, 6, "\uda90\uddb3\udb5b\udfb9\ud84a\ude42\udae9\udd07\ud904\ude2d\ud9ec\udca0\ud939\udf1d\u3725\uda34\ude57\uda69\udd46\ud857\udc74\udaf9\udc8b\udb62\udfb8\udaab\ude75\udaf8\udd44\udb8a\udcbd\ud80a\udd7d\ud9e2\udfd8\udb47\udf2e\ud9d1\udc59\ud80c\ude16\udb87\udd4c\u5eab\ud8a7\udc84\ud8e9\uddab\uda92\udced\ud91f\udc83\uda87\udc02\ud886\udea8\uda95\udf2c\uda47\udc35\ud8f4\udf84\uda78\udc5d\uda65\udd8f", "\uc8f0\uab17\u11c3\u4a82\u0656\u5dfd\u2d3d\u4b07\u1b9e", "\uda3f\udd5e\udbda\udff1\ud909\udd40\uda0b\udce5\udb74\ude61\uda69\udeda\u898b\udabe\udf7d",
        17, 64833, 896957956, 3100200404494777108L, 95207L, true, false, (char) 40660, (char) 55000,
        Double.longBitsToDouble(0x3feab11eefa719d4L), Double.longBitsToDouble(0x3fceeff2bc2d0500L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb75\ude82\udb24\udcdf\udb14\ude47 |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb75\ude82\udb24\udcdf\udb14\ude47 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 12, 12, 6, "\udb75\ude82\udb24\udcdf\udb14\ude47", "\ud220\u99fa\ua858\u9c41", "\udaf9\udc8b\udb62\udfb8\udaab\ude75\udaf8\udd44\uda8f\udcf9\ud80a\udd7d\ud9e3\udc53\udb47\udf2e\ud9d9\udc59\ud80c\ude16\udb87\udd4c\u5eab\ud8a7\udc84\ud8e9\uddab\uda71\udc18\ud93a\udd5f\uda87\udf7e\ud886\udea8\uda95\udf2c\uda47\udc35\ud8f4\udf84\uda78\udc5d\uda65\udd8f\ud91c\udc6c\ud940\udf95\udb14\udf26\ud98b\ude32\ud996\udd44\ud8bf\udf33\ud9a0\ude5a",
        -4, 83361, -1294215563, 8994022360006389066L, -44006L, true, false, (char) 50316, (char) 31733,
        Double.longBitsToDouble(0x3fec0474737d6754L), Double.longBitsToDouble(0x3fe82782e6a727d6L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 3, 2, 8, "", "\000", "",
        22, 50386, 762971270, 721083536982131755L, -5685L, true, true, (char) 57279, (char) 37372,
        Double.longBitsToDouble(0x3fe8fa7ed2d3a01cL), Double.longBitsToDouble(0x3fe4e635409c61e9L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 2, 15, 13, "\udb83\udc17\udb24\udcdf\ud84a\ude42\uda81\udfaa\ud893\udd2e\ud907\ude50", "\ub42b\u1717\u80bf\u0dc5\u2cf7", "\uda8f\udcf9\ud80a\udcbc",
        0, 64593, 1554996883, -8139390395325312331L, -91594L, false, true, (char) 65507, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4c8baa2b8L), Double.longBitsToDouble(0x3feb0840ce0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 6, 13, "\ud880\udf12\udb24\udcdf\ud842\ude21\udb4c\uddd0\ud8c9\udd1f", "\ua858\ub42b\u5e2c\u773d\u8b85\u4efe\u9665\u66ed\u3213\uac54\u5183\u2de9\ud4aa\u65ae\u1fa3\u94a5\ub6ed\u678f\u7467\uaac4\u3526\u33c7\u4ed2\u8151\ud399\u9e7c\ucbe2\ua2df\u67e0\002\u2250\ub2ad\uba23", "\ud99a\udd5f\uda63\udc0e\ud89b\udfa7\ud967\udf13\ud8e9\udefb\ud9e9\udeab\udb14\udfb9",
        48, 36961, -808703730, 2213451104487419003L, -6993L, false, true, (char) 42262, (char) 27541,
        Double.longBitsToDouble(0x3fea094b5d12a126L), Double.longBitsToDouble(0x3fc5899d92ddfbbcL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 15, 13, "\000\000\000", "\ud220\u99fa\ua858\ub42b\u1717\u80bf", "\u7991",
        7, 4359, 758500882, 62237909696118784L, -94993L, false, false, (char) 63420, (char) 31585,
        Double.longBitsToDouble(0x3ebd180620000000L), Double.longBitsToDouble(0x3fed044220000000L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 4, 3, "\udb75\ude82\udb24\udcdfK", "\ud220", "\u045f\ud925\udc64\000\ud907\ude63\udb67\udc74",
        16, 78557, -1607335777, 1390222605L, -58675L, true, true, (char) 8640, (char) 63420,
        Double.longBitsToDouble(0x3e2303e000000000L), Double.longBitsToDouble(0x3fe80625e7a08844L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:\012",
        Z.run(T, 2, 0, 2, 4, "\000", "\u00f5\000\000\u99fa\ua858\u9c41", "\u1451\ubd33\udaef\ude77\udaf8\udd44\udbe3\udd03\uced3\udac6\udcbf\udb47\udee8\udbc0\ude40\000\000\ud98d\udfdc",
        40, 33040, -2008794329, 2136649746149690532L, -73130L, false, true, (char) 52650, (char) 11500,
        Double.longBitsToDouble(0x3fe62440678ba771L), Double.longBitsToDouble(0x3fe3899d2aa6d710L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Caverphone:@?\0121=new org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 6, 6, 4, "\udb75\ude82\udb24\udcdf\ud85e\udd72", "\u7570\u7539", "\ud896\udf1c\ud94f\udd79\udb59\udc5a",
        18, 87403, -1726679005, -7393354745164730157L, -24257L, true, true, (char) 55206, (char) 55921,
        Double.longBitsToDouble(0x3fe50f39916f1f94L), Double.longBitsToDouble(0x3fe5a8a8f32774e2L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 2, 2, 17, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\u2daf\u99ee\ua858\u414d\u4ff6\u40a1", "\uda72\uddcd\udaf8\udd44\udbe3\udcd4\u967d",
        40, 44689, 1482934151, -4052493886928317704L, -12303L, false, false, (char) 22386, (char) 41564,
        Double.longBitsToDouble(0x3fc483b4c8baa2b8L), Double.longBitsToDouble(0x3feb0840ce0bb8a7L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 8, 8, 4, "\ud845\udceb\ud8f0\ude68\ud84a\ude42", "\u515e\u9a09\ua858\u9c41\ud46c\u40a1", "\ud89c\udd82\udacb\ude52\udbe3\udd03\ud80a\udd7d",
        40, 24458, 1243221475, -4073018367404797192L, 74447L, false, false, (char) 65394, (char) 39396,
        Double.longBitsToDouble(0x3fc74e35e33e89b8L), Double.longBitsToDouble(0x3fa78ac960b71cf0L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 4, 4, 12, "\udb75\ude82", "\u4501\u386b\u95ae\u4400", "\ud9a5\udd1c\udbca\udc82\u1426",
        56, 49280, -1101212381, -6854079925990338861L, 86401L, true, true, (char) 25051, (char) 54579,
        Double.longBitsToDouble(0x3fcee44c50b69db4L), Double.longBitsToDouble(0x3fb01e02013e5058L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\u8b8d", "\ud907\ude50\udbde\udc69\u3725\uda34\ude57\ud896\udf1c\ud94f\udd79",
        32, 54723, -432999597, -4729671163941131617L, -100000L, false, false, (char) 33009, (char) 1402,
        Double.longBitsToDouble(0x3fe7c63bcea1e732L), Double.longBitsToDouble(0x3fd6f1f94881443cL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 7, "\u432d\udbde\udd87\udaa0\ude53\ud854\ude11\udb80\udccc\uda34\ude74\ud925\ude15\u3725\uda34\ude57", "\u1ccb", "\udaf2\udd44\ud88c\ude16\ud80a\udd7d\udac6\udd71",
        4, 91163, -1892107168, 5649926764192966997L, 24714L, true, false, (char) 43754, (char) 47431,
        Double.longBitsToDouble(0x3fe3b48a4a18d2beL), Double.longBitsToDouble(0x3fd1f71c9d0cf04aL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String:\u432d\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\u432d |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 2, 13, 7, "\u432d", "\u97b8\ub5cc\u90f0\uaf61\u6562\u7879\ub0d2\u1e1f\u0ac5\u16a0\u57eb\u8f57\ua0c3\u4c68\uc832\ud335\u3e01\ub0b5\u1f63\u40f8\ud64d\u3f78\u3933\ua92b\u3f4d\u3fe3\u8f11\ubcd2\u08f5\uab84\u7aee\uba3b\u348b\u8301\u5c70\u8746\u716b\uc320\u4ebf\u8914\u6c41\u2c32\u7a69\ub69c\u790b\u5548\u7d33\u92e8\u0265\u8636\u1dcb\ua620\u4bca\u6ed4\u0385\u0269\u4e1a\ubec8\uce59\u1082\uae76\ub190\u8225\u1885\uc954\ucb48\u3875\u2b92\ube00\u7a09\u9f3b\u83cf", "\udb3a\uded5\udb9e\ude35\ud8f6\udfe9\ud943\udc16",
        22, 48354, -1293144380, 3274059010421642039L, -96472L, true, false, (char) 39485, (char) 44129,
        Double.longBitsToDouble(0x3fc74e82a00ae1f8L), Double.longBitsToDouble(0x3febfe90971759a6L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 13, 4, "\000\udba1\udff0\udaa0\ude53\ud8b6\ude02\udb80\udccc\uda34\ude74\ud925\ude15\u3725\uda34\ude57", "\u1ccb", "#\udb9b\udf6c\ud80a\udd7d\udac6\udd71",
        4, 91163, 60928, 5649765732984138069L, -48496L, false, false, (char) 59177, (char) 63142,
        Double.longBitsToDouble(0x3fad9558249e6fe0L), Double.longBitsToDouble(0x3fe3b48a4a18d2beL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud9b0\udedb\udbdc\udd22\udaa5\udce6 |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\ud9b0\udedb\udbdc\udd22\udaa5\udce6 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 13, 13, 13, "\ud9b0\udedb\udbdc\udd22\udaa5\udce6", "\u90f0\uaf61\ua858\u9c41\ud40f\u84ba\u1ccb", "\udaf2\udd44\udbe5\udea6\udb65\ude6e\udac6\udd75",
        28, 91080, -1892094368, 5649926762011928917L, 90250L, false, false, (char) 1489, (char) 47431,
        Double.longBitsToDouble(0x3fbcd25249c16820L), Double.longBitsToDouble(0x3fee3e8d06ae2013L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 2, 2, 0, "\udb75\ude82\udb75\udc28\uda63\ude71\uda81\udfaa\ud877\udd30\ud9e7\ude9f\ud96e\udd9e", "\u1717\u80bf", "\udaab\ude75\udbaa\udebd",
        40, 15306, 373178379, -3518362273345565213L, -75210L, false, true, (char) 21, (char) 28644,
        Double.longBitsToDouble(0x3fc483b4d0baa2b8L), Double.longBitsToDouble(0x3fe30a5abea31daeL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.String:\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 14, 3, "", "\u6f73\u57e5\u4fab\u293e\u714c\ua7df\u9c41\u1717\u80bf\u0dc5\u13c8\u00e3", "\ud8f1\udc74\ud9d8\udce2\udb47\udf54\udbc0\ude40\ud946\udd63\udb7f\udc9e\ud8bc\udd5d",
        53, 50744, -2008794329, 2136649747626085540L, 49089L, true, false, (char) 58367, (char) 20217,
        Double.longBitsToDouble(0x3fe0cd6a4ee355f2L), Double.longBitsToDouble(0x3fed0da8161d04a8L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.String:B |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 7, 9, 15, "\ud855\udc84\udb71\udedaB\uda6d\udeb5\ud81b\udea3\ud9ef\ude0c\ud8da\ude4b", "\u20d8\ub7ef\u3e50\u257b\u552e", "\ud80a\udd7d",
        40, 15993, 1243221475, -8142233935164173643L, 86971L, true, false, (char) 23430, (char) 50685,
        Double.longBitsToDouble(0x3fec76fdb5bb7c21L), Double.longBitsToDouble(0x3fbf72d95a36b888L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.String:L |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 17, 10, 13, "l\000\000", "\u87b4\u64c3\u739a\u9c41\u2c58\000\000\000\000\ua1c6", "\udac6\udccc",
        23, 24539, -1892091552, -8956935400797636180L, -11549L, false, false, (char) 47930, (char) 65179,
        Double.longBitsToDouble(0x3fe0dda988712ce9L), Double.longBitsToDouble(0x3feb39f705c66604L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 17, 10, 13, "\000\udad0\ude03\004", "\u6198\u0734\u8e3e\u9c39\u2c58\u285f\u5294\ud5ab\000\u6fb3\u04e0\u7e28\uc78d\u7f54\u8fd7\u39e1\ud2a1\u2bf2", "\uda4a\udff7\ud966\udea5\ud82a\udc64\uf798",
        7, 81903, -626350266, 5952889233656151176L, 1563L, true, false, (char) 55232, (char) 26515,
        Double.longBitsToDouble(0x3fe7c7719fbd954aL), Double.longBitsToDouble(0x3fe610588710fd43L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 17, 10, 13, "w\000\000", "\u26b6", "\uda34\ude57",
        37, 38360, -1455357877, 0L, 19393L, true, false, (char) 18957, (char) 36862,
        Double.longBitsToDouble(0x3fde3730e2c09400L), Double.longBitsToDouble(0x3fbb23ce11b28f08L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 10, 0, "\ud99d\udc49\ud9c4\udd0c\ud833\udd91\udbad\uddc7\ud8c2\udd2f\ud945\udc4fg\ud8df\udeae\udadd\uddcd\ud81f\uddad\ud87c\udcf7\ud90b\udc94\udb62\udfb8\uda27\udf93", "\u4cf5\uaa97\ud117\u0f5f\u32bb\u5e8d\u8bfc\u6bd7\uc8c5\u852e", "\uda1a\udc54",
        27, 36929, 858129651, 5385593910865054768L, 83805L, true, false, (char) 49953, (char) 24738,
        Double.longBitsToDouble(0x3fbbbf4886954fc8L), Double.longBitsToDouble(0x3fe875a4e37ccce3L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 5, 5, 7, "\udb75\ude82\udb24\udc96\ud84a\ude42", "\u0d16\u99fa\ua858\u9c41\u1717\u1d51\u0de2\u695a\uccf6\ua7f3\u1913\u4c68\uc78d\u107f\u5db6\ubbb5\u1fa3\u94a5\u32db\u2bff\u453e\u9de7\uce35\u33c7\u4ed2\u460e\ua121\u6472\u59cd\u5dfc\u5c83\u6de5", "\ud899\udf7a\ud884\udf38",
        49, 10, 1812422094, -7136837276307202877L, -28115L, true, true, (char) 60051, (char) 50413,
        Double.longBitsToDouble(0x3febfcea8391e9d1L), Double.longBitsToDouble(0x3fe961a52912c122L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\ud976\udff6\ud8c3\udd70C", "\u8054\u00bc\ua858\u2766\u23eb\ua3b5\u3a4b\u4238\uc0fd\u8d73\u12d6\u4c79\u8ca6\u107f\u5db6\ubbb5\u1fa3\u371e\u2827\u64ff\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -1284325079, 4514014757036877735L, 82783L, false, true, (char) 8655, (char) 32669,
        Double.longBitsToDouble(0x3feb9ca6ed577727L), Double.longBitsToDouble(0x3fc7eb09e2607ec4L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\000", "\u81cf\000\ua858\u2766\u221a\u80bf\u2ceb\u4238\uc0fd)\000\000\000\000\000\ubbb5\u1fa3\u1428\u9250\u64ff\u4606\000\u55ff\uc528", "\udb8e\uddd1\u0082",
        29, 84171, -680345303, 4514014202986096551L, 82271L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4851dcfc000000L), Double.longBitsToDouble(0x3fe7529790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:E |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "E\udb10\udc87\u0099", "\u81cf\000\ua858\uc4bb\u2938\u32cc\u31ed\u4238\uc0fd\u8d73\u8d7e\u4c79\u2972\u107f\u5db6\ubbb5\u1fa3\u371e\u1326\u1f1d\u19ca\ub766\u56fd\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514014202986096551L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\ua1d8\udb10\udc87\u0099", "\u81cft", "\udaca\udd3c\ud89b\udd16",
        49, 65422, 1989696406, -6852387183839967807L, 34627L, false, true, (char) 8685, (char) 47293,
        Double.longBitsToDouble(0x3fedfb52d0a92c12L), Double.longBitsToDouble(0x3fcdeedae69c9834L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 16, 8, "\ud832\udfa0\udb10\udc87C", "\u81cf\000\ua858\u2766\u62c2\ubac5\u62eb\u4238\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u5db6\ubbb5\u3293\u371e\ub326\u64ff\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514014202986096551L, 82271L, false, true, (char) 8655, (char) 11373,
        Double.longBitsToDouble(0x3fbb107bf0a3b9f8L), Double.longBitsToDouble(0x3fe3020796dd224eL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 2, "\000\udb10\udc87\u0099", "\u81cf\000\ua858\000\000\000\u2ceb\u4238\uc0fd\000\u8cbd\u4c79\ub96b\u107f\u00e3\ubbb5\u1fa3\u1bc9\ub326\u64ff\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514014202986096551L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fcd4a5e42603d38L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 11, "", "\ud63b\ucecd\012\ub34e\uce72\ua858\u2766", "\uda21\uddf3\udb82\ude68\ud90b\udf6f\ud926\udc8e\u5c1b\ud80a\udd8e",
        13, 39673, 1363258339, -3520831463019842278L, -84657L, false, false, (char) 27210, (char) 27946,
        Double.longBitsToDouble(0x3feb0b38b60bb8a7L), Double.longBitsToDouble(0x3fcdb63dc0000000L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 5, 5, 11, "\ud850\udd48", "\ua4bf", "\uda30\udf2a\u3725\ud838\ude14\udaca\udd3c\ud857\udc74\uda73\udcf1",
        44, 93196, -1595345034, 7766323147157393124L, 86401L, true, true, (char) 17274, (char) 8685,
        Double.longBitsToDouble(0x3fdca0868a796696L), Double.longBitsToDouble(0x3fc961e44fbdd92cL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb3f\udf77\udb66\udcbc\ud8a7\udf0a |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb3f\udf77\udb66\udcbc\ud8a7\udf0a |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 15, 15, 13, "\udb3f\udf77\udb66\udcbc\ud8a7\udf0a", "\ud3cc\u99fa\ua858\ua118\u6270\u7f19\u2d08\u3738\uc0fd\u460c\u2f2b\u4bba\uca03\u08ba\u5db6\ubbb5\u1fa3\u371e\ub326\u846d\u2cd1\u0949\u5675\uc528", "\udb45\udf93\ud8e7\udd81",
        -5, 72267, -1636646615, -6605912084932703381L, 82271L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7552790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\000\000\000 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 13, 1, "\000\000\000", "\000\u99a5\ua858\u5307\000\u2480\uca45\u6119\uc0fd\u39de\u70da\ua728\u2c2a\u017f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u02b5\uaac4\u56a3\000", "\udba1\udff5\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 4726, (char) 24668,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\000", "\000\u99a5\ua858\u2239\000\uabcc\u8a58\u6119\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u4ff0\ubbb5\u1fa3\u36c9\ub326\u00cb\u00ef\u63de\ubdccY", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 3, "A\000\000", "\u9966\u73c1\uc41a\u2239\ud200\u80bf\u0b9d\u6965\uc0fd\u8dc7\u8d7e\u4c79\u6d7d\u107f\u50b6\u1028\u1fa3\u36c9\u1886\u3e4f\010\uaac4\u56a3\000", "\udb8e\uddd1\udaa0\udddd",
        33, 94155, -680345303, -6582594241966512541L, 31072L, false, true, (char) 8732, (char) 21801,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979500004eL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\ud92a\udf3e\010", "\000\u182a\u0765\u672b\000\ua6ab\uca6d\u6119\uc0fd\u8d73\u70a1\u4c79\ub96b\ub53b\u8bc9\u51f3\u1fa9\u36c9\ub326\u00cb\u00ef\uaac4\u56a3\000", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000e84eL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\ud83c\udc7d\002\000", "\ubb90\u99a5\ua858", "\ud88e\udf74",
        56, 18032, 1095719830, -6852387183839967807L, 31299L, false, true, (char) 8685, (char) 26984,
        Double.longBitsToDouble(0x3fcad7f6432f54b8L), Double.longBitsToDouble(0x3fcde0001e800000L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\000", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u2c53\u571c\u49a0\u107f\u50b6\ubbb5\u6544\u36c9\u0270\u982b\uae16\u5e81\u19fb\006", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 21353,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\u67ad\udb31\udc65\027", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u00ef\uaac4\u56a3\000", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 61863, (char) 40936,
        Double.longBitsToDouble(0x3fddf92cac28ee7eL), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\ud903\udc61\udbbf\ude9by", "\000\u018e\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u00ef\uaac4\u56a3\000", "\udb8e\uddd1\ud8e7\udd81",
        44, 2340, -242593088, 28917694158667943L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\000", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u00ef\uaac4\u5554\016", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 9, "\ud91e\udc0e\ud910\udd88G", "\000\u357f\u2b8f\u7b74\uc897\uc2ef\uca40\u18e2\uc0fd\u8d73\u24ef\u4c79\u3d7b\ub544\u50cb\ubbb5\u671b\u5226\u3b37\u84a4\u00ef\uaac4\u56a3\u5639", "\udb8e\udd8d\ud8e7\udd81\ud924\udf57",
        27, 90697, 10874218, 6344728167294435360L, -42095L, true, false, (char) 41584, (char) 32309,
        Double.longBitsToDouble(0x3fec7185db036486L), Double.longBitsToDouble(0x3fe0d45129927f17L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\000", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u50b6\ubbb5\u1fa3\u36c9\ub326\024\u00ef\uaac4\u56a3\000", "\udbb2\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\udb1e\udc0e\000\000", "\000\u99a5\ua858\u2239\u1631\u80bf\uca40\u6119\uc0fd\u8d73\u8d7e\u0f4a\u160f\u107f\u50b6\ubbb5\u1fa3\u36c9\u1701\uc47f\ud42a\ubf15\uc511\022", "\udabf\uddd5\ud8e7\udd81",
        59, 62603, -680387031, 46704412156821671L, -83309L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\udb3f\udf77\udb24\udc2f\ud843\udd90\udb64\udf3c\uda79\udf15\ud907\udee2\udbde\udc69\u3725\ud86c\udd6e\ud812\udcc2\ud857\udc74\ud8ae\udf9a\udbd6\udd1d\udbb1\udf09\udb82\udfe2\udb38\udd3d\ud80a\udd8e\ud9e6\udcc2\udb47\udee8\ud947\udd63\uda32\udeba\udba3\udf53U\ud85c\udce9", "\uaac4\u56a3\uc528\u1428\u4979\u5ae8\u46f8", "\ud986\udfda\ud860\udd29\ud99d\udcd7",
        34, 20103, -797916316, 6043357212492376273L, 71540L, false, false, (char) 10214, (char) 19464,
        Double.longBitsToDouble(0x3fe0c66fd104b7e5L), Double.longBitsToDouble(0x3fe52b53ee82bf82L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\u0b4b\u99fa\ua858\u2766\u62c2\u80bf\u2ceb\u4238\uc0fd\u8d73\u9bb6\ub133\ub96b\u107f\u5db6\ubbb5\u1fa3\u3984\u923e\030\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514275242508412839L, 16735L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529790920f4eL)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 0, "\udb3f\udf77\ud800\udc4d\ud939\udd8b", "\ud2b2\u99fa\ua858\u2766\u38fb\u80b4\u2ceb\u5155\uc0fd\u8d73\u087e\u4c79\015\000\u8597\u2161\u1eeeU\ub250\u9ca5\u4606\uaac4\u56a3\u8328", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 4514275242508412839L, 82271L, false, true, (char) 20830, (char) 24685,
        Double.longBitsToDouble(0x3e4851dcfc000000L), Double.longBitsToDouble(0x3fe7529790980f4eL)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.String:\u36b2\u5c1b\0121=java.lang.String:\u36b2\u5c1b\012",
        Z.run(T, 2, 2, 2, 17, "\udb3f\udf77\udb24\udcdf\ud843\udd90\ue045\ud8b6\uddc6\ud8e3\ude05\ud9ff\ude87\u36b2\ud838\ude14\ud97f\udeda\ud857\udd01\uda21\uddf3\udb82\ude68\ud90b\udf6f\ud926\udc8e\u5c1b\udb08\udd8d\ud9e6\udcc2\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\udbbd\ude9b\ud85c\udd75\udaa1\udfc3\uda71\udce0\ud99f\udd52\ud96d\udd10\udb97\udfdd\uda95\udf1b\ud8bc\udd71", "\ud20e\u9c2d\u1119\u37aa\ub003\u7d5e\u975c\ub305\u076f\uaa3c\u29c1\u5863\u89b8\u5b88\u5aa4", "\ud877\udcf9\ud921\udcc8\ud8f5\udd57\ud80d\udca4",
        5, 91653, 1279165901, -6802953941532428081L, 60962L, true, false, (char) 1545, (char) 4152,
        Double.longBitsToDouble(0x3fdef20e924857acL), Double.longBitsToDouble(0x3feaa79c8da2b561L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 0, 2, "\ud838\udfd3\ud898\udc16\udad9\udd23", "\ud2b2\u99fa\ua858\ud4fc\u9e51\u80bf\uca40\000\000\u8d4a\u00c1\u4f95\021\u3494\u4531\000", "\ubeed",
        -5, 88488, 497477536, 4721737093050941988L, 96608L, true, true, (char) 20762, (char) 5,
        Double.longBitsToDouble(0x3fdcc00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 0, 2, "\ud87c\udf55\uda2f\ude87\ud843\udd90", "\u3638\u73f7\ua858\u2766\u38fb\ucf40\u4712M\000\ucc02\uad92\u03ba\023\000\000\ua2d3\u511e\u388d\u00d6\000\u4517\uaac4\u56a3\u51f3", "\000\ud8ca\udf0e\udbd5\udde8\ud927\udc73\udaa7\ude94\000\ud806\ude0e\udabf\udfb7\000\u7d98\uda0f\ude3d\udbec\udc2b\ud853\ude34\ud882\ude20",
        17, 54834, -1899186120, -3460527418679800398L, -67049L, false, true, (char) 16065, (char) 42327,
        Double.longBitsToDouble(0x3fe3ddeaa6a3baecL), Double.longBitsToDouble(0x3fd75f468e58a18cL)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 0, 2, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u99fa\ua858\u2766\u38fb\u80bf\uca40\000\000\u8d4a\u00c1\u1ed8d6\000\000\u271c\uc21d\u00d6\000\u4517\uaac4\u56a3\u5315", "",
        -5, 68344, 287614238, 1570596525703168L, -100000L, false, false, (char) 0, (char) 51092,
        Double.longBitsToDouble(0x3fd35087c00017b2L), Double.longBitsToDouble(0x3e20800000000000L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 0, 2, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\011\u99fa\ua858\u2766\u38fb\u80bf\uca40\000\000\u8d4a\u00c1\uc8ea\uc23c\000\000\000\000\u83df\u00d6\000\u4517\uaac4\u56a3\u5315", "\u00fd",
        44, 87449, -1585277837, 5779880718796587008L, -100000L, false, false, (char) 49919, (char) 8655,
        Double.longBitsToDouble(0x3f07bc0000000000L), Double.longBitsToDouble(0x3e310032f8000000L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 0, 2, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\u1e96\u99fa\uab03\u3406\uaa3b\u80bf\uca40\000\000\u8d4a\u00c1\u3a0e\u7952\u7d81\000\000\000\000\u00d6\000\u4517\u83c4\u56a3\u5315", "",
        -5, 68344, -1129899551, 1570596525703168L, -100000L, false, false, (char) 27854, (char) 49919,
        Double.longBitsToDouble(0x3fdb95ea200017bcL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 10, 10, 7, "\udb1a\udfe2\udb1e\udc84", "\u4e1e\uab20\u99fa\ua390\u9c41\u1717\u8ad5\u881b\u01d2", "\ud80e\ude33\ud8fa\ude74",
        59, 39673, -1493609150, -8126470652662607179L, -36195L, false, true, (char) 34068, (char) 13796,
        Double.longBitsToDouble(0x3fdaa25c89613652L), Double.longBitsToDouble(0x3fc86e23e4f54cb8L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 3, 3, 1, "\udb1a\udfe2\udb1e\udc84\ud84a\ude42", "\ub268\u99fa\ua390\u1bc7\u1717\u8ad5\u676b\u9c7a\uc766\u04dd\u7264\u25e7\ub733\ua150\uc93d\ubc54\u38d2\u6b29\u3192\u670c\uca59\u1a68\u6350\u6df5\u951f\uc20f\uabe3\u1725\u7266\u62f3\uc150\u468c", "\udbfe\udd4a\ud96a\ude53\ud975\udce3\udb9c\udd7b\udb1a\udd42\udbba\udeba\ud935\ude08\udb3e\udfa2\udaf1\udf98\udb06\udf87\ud893\udce8\udad4\udd3a",
        4, 61820, -171348916, 1487189257784201447L, 99900L, true, false, (char) 14468, (char) 50571,
        Double.longBitsToDouble(0x3fc383a76f1dd3a8L), Double.longBitsToDouble(0x3fefcf118810fe60L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 6, 13, "\ud880\udf12\udb24\udcdf\ud842\ude21\udada\udc36\ud8b5\udf49", "\ua858\ub42b\u5e2c\u773d\u8b85\uc56e\u9665\ua4f1\027\u7ca3\u5183\u6dd1\ud4aa\u65ae\u1fa3\u94a5\ub6ed\u678f\u7467\uaac4\u3526\u33c7\u4ed2\u8151\ud399\u9e7c\ucbe2\ua23b\u67e0\002\u2250\ub2ad\uba23", "\ud99a\udd5f\uda63\udc0e\ud89b\udfa7\ud967\udf13\ud8e9\udefb\ud9e9\udeab\udb14\udfb9",
        48, 36961, -808703730, 2213451104487419003L, -6993L, false, true, (char) 39150, (char) 31027,
        Double.longBitsToDouble(0x3fb6ed90e8950930L), Double.longBitsToDouble(0x3fc5899d92ddfbbcL)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 6, 13, "\ud880\udf12\udb24\udcdf\ud842\ude21\ud8d0\uddad\udb0a\udc1f", "\ua858\ub42b\u5e2c\u773d\ua1a2\u32c5\u9665\u66ed\u7f71\u5560\u71e0\u2de9\ud4aa\u65ae\u1fa3\u94a5\ub6ed\u678f\u7467\uaac4\u3526\u33c7\u4ed2\u8151\ud399\u9e7c\u7b6b\uc404\u9402\026\u2250\ub2ad\uba23", "\ud99a\udd6a\uda63\udc0e\ud89b\udfa7\ud967\udf13\ud8e9\udefb\ud9e9\udeab\udb14\udfb9",
        48, 36961, -808703730, -8939215341172872069L, -6993L, false, true, (char) 42262, (char) 27541,
        Double.longBitsToDouble(0x3fea094b5fb97026L), Double.longBitsToDouble(0x3fdacc31296efddeL)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 8, 15, 13, "\udba5\ude11G\000", "\ud220\u99fa\ua858\ub42b\u1717\u80bf", "\u7991",
        7, 4359, 758500882, 62237909696118784L, -94993L, false, false, (char) 63420, (char) 31585,
        Double.longBitsToDouble(0x3ebd180620000000L), Double.longBitsToDouble(0x3fed044220004000L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.String:\u432d\0121=java.lang.String:\u432d\012",
        Z.run(T, 2, 2, 2, 7, "\u432d", "\u3a9f\u2295\u90f0\uc134\u6562\u7879\ub0d2\u1e1f\u0ac5\u16a0\u57eb\u8f57\ua0c3\u4c68\uc832\ud335\u3e01\ub0b5\u1f63\u40f8\ud64d\u3f78\u3933\ua92b\u3f4d\ud0ce\u8f11\ubcd2\u08f5\uab84\u7aee\uba3b\u348b\u1bb2\ua56a\ud158\ua2b7\uc320\u4ebf\u3f14\u6c41\u2c32\u7a69\ub69c\ubf49\u552b\u7d33\u92e8\u0265\u8636\u2c9b\ua6a1\u4bca\u6ed4\u02e5\u0269\u4e1a\ubec8\uce59\u0d32\u1235\u8348\u3877\u8d10\u428e\ucb48\u3875\u2b92\ube00\u7a09\u9f3b\u83cf", "\udb3a\uded5\ud928\udfc5\ud8f7\udc98\ud943\udc16",
        22, 48354, -1293144380, 3274059010421642039L, -85461L, false, false, (char) 6351, (char) 10847,
        Double.longBitsToDouble(0x3febfe97971759a6L), Double.longBitsToDouble(0x3fd06291786525faL)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 2, 2, 3, "", "\u6f73\u76b5\u26bf\u6bc8\u74c3\u89f2\u9cb8\u1717\u7fdb\u0dda\u13c8\u00e3", "\ud8f1\udc74\ud9d8\udce2\ud881\udf91\udbc0\udd6f\ud946\udd63\ud91e\ude0e\ud8c5\udfa3",
        20, 48851, -2008794329, 8637211618143314154L, 19917L, true, false, (char) 58367, (char) 20217,
        Double.longBitsToDouble(0x3fe0cd6a4ee355f2L), Double.longBitsToDouble(0x3fed0da8161d04a8L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 17, 2, 13, "\000\ud89f\ude0e\007", "\u6198\u0734\u8e3e\u9c39\u2c58\u285f\u5294\ud5ab\u6c83\u6fb3\u04e0\u7e28\uc78d\u68ae\u8fd7\u6ff8\ud2a1\u2bf2", "\uda4a\udff7\ud966\udea5\ud8ea\udee3\uda0f\udea4",
        7, 81903, -626513054, 5952889233656151176L, 1563L, true, true, (char) 55232, (char) 26515,
        Double.longBitsToDouble(0x3fe7c7719fbd954aL), Double.longBitsToDouble(0x3fe610588710fd43L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 7, 17, 0, "w\000\000", "\u3745\u0246", "\u2c58\ud9a8\udfcc",
        16, -1000, -863240192, 5692550960779515735L, 4817L, true, false, (char) 33009, (char) 17248,
        Double.longBitsToDouble(0x3fbb23ce11b28f08L), Double.longBitsToDouble(0x3fcd83727b7a8c6cL)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 10, 0, "\ud99d\udc95\ud9c4\udd0c\ud833\udd91\udbad\uddc7\ud8c2\udd2f\ud945\udc4fg", "\u14f6\u75af\u3f34\u8c58", "\ud97a\udc22\ud90c\udcde\udabe\udfd6",
        46, 91754, -1617233568, -1044140521254554789L, -7184L, true, true, (char) 16696, (char) 19022,
        Double.longBitsToDouble(0x3fd477d44466679aL), Double.longBitsToDouble(0x3feacc2bb4f38baeL)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 10, 0, "\ud99d\udc49\ud9c4\udd0c\ud833\udd91\udbad\uddc7\ud8c2\udd2f\ud945\udc4fh\ud8df\udeae\udadd\uddcd\ud81f\uddad\ud87c\udcf7\ud90b\udc94\udb62\udfb8\uda27\udf93", "\u4cf5\uaa97\ud117\u0f5f\u32bb\u5e8d\u8bfc\u6bd7\u8324\u8500", "\uda1a\udc54",
        27, 36929, 858129651, 5385593910865054768L, 83805L, true, false, (char) 49953, (char) 24738,
        Double.longBitsToDouble(0x3fbbbf4886954fc8L), Double.longBitsToDouble(0x3fe875a4e37ccce3L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 10, 0, "\ud99d\udc49\ud9c4\udd0c\ud833\udd91\udbad\uddc7\ud8c2\udd2f\ud945\udc4fg\000\udadd\uddcds\000\000\000\000", "\u4cf5", "\udbd6\udf16\ud8e2\udd71\ud969\udedf\udab2\udcf4\uda86\udf79\u6a49\000\000\ud9f5\udde6\uda1a\udc54\ud93c\udefa\000\uda89\udff6\uda2f\udd88\000\000\000\ud95b\udf6f\000\ud20d\000\000\udb7e\udc0a\udb12\udec8\u57a6\udab1\udd00\udbc8\udc3a\ud9b7\ude5f\u1285\udaa8\udc0d\ud9af\udc01\ud83a\udeca\uda39\udd3e",
        32, 43879, -188245110, -4149576102322212889L, -37792L, false, true, (char) 26693, (char) 12289,
        Double.longBitsToDouble(0x3fec932899d9f357L), Double.longBitsToDouble(0x3feab4fcb959c7d8L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 9, "\ud976\udff6\ud8c3\udd70C\udb64\ude45\udb97\udfc1\ud858\udf8a\u00bc\ud8f0\udc64\uda9b\ude4f\udae4\ude3e\ud9ec\udc9f\ud8ec\udf9c\udb82\ude68\ud90b\udf6f\ud926\udc8e\ub972\ud80a\udd8e\udb14\udd88\udb47\udee8\udbc0\ude40\uda32\udeba\udba3\udf53\udb71\udf8a\ud90d\ude8a\udaa1\udfc3\udba6\udd64\ud8ab\udc8e", "\u26d0\u4984\u5ae8\u7fab\ud20e\u9c2d\u957d\u22cd", "\ud993\udee6",
        19, 47198, -1797426241, 8586046114775401815L, 57207L, false, true, (char) 58514, (char) 57799,
        Double.longBitsToDouble(0x3fc4d5c6ed763dd4L), Double.longBitsToDouble(0x3fee2fd20dab78f3L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 11, 7, 7, "\ud976\udff6\ud8c3\udd70C\udb64\ude45\udb97\udfc1\ud910\ude60", "\u2766\u23eb\ua3b5\u3a4b\u4238\uc0fd\u3338\u4adb\u4c79\u0164\u1501\u2c5e\u4ce5\uaf8e\u9623\ub7d0\u64ff\u0525\ud7e2\u56a3", "\ud8bc\udd71",
        42, 9458, -2035869215, -7426794730120101591L, 4615L, false, true, (char) 3939, (char) 65433,
        Double.longBitsToDouble(0x3fd5ed07077e17bcL), Double.longBitsToDouble(0x3feb9b0eea50ab27L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=java.lang.String:T |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:T |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 1, 7, 7, "\ud916\udf89\ud8c3\udd70\uda4a\ude07\udb5d\udefc\udb43\ude57\udb1b\uddeat\u3725\uda01\udd59\udae4\ude14\ud9ec\udc9f\ud8ec\udf9c\udb82\ude68\ud90b\udf6f\udb26\udffb\ub972\udafa\ude06\ud990\ude93\udb6e\udc1c\u6758\uda16\udf45\udb8b\ude75\udb71\udf8a\ud9d0\udf90\ud97a\uded0\udbb2\udf57\u24fe\ud98d\udf20\ud8ba\udd0e\uda8b\udf2a\ud8bc\udd71\udb8e\uddd1\ud8e7\udd81\udbd5\udde8", "\u0176\u98d4\u7d5e", "\uf255",
        34, 88875, -1328432606, 2283651287763785880L, -31336L, true, false, (char) 65410, (char) 46356,
        Double.longBitsToDouble(0x3fc1700322f980b4L), Double.longBitsToDouble(0x3fb904887333d4f0L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 1, "\ud976\udff6\ud8c8\udff3K", "\u8054\u00bc\ua858\u2766\u23eb\ua3b5\u3a4b\u4238\ua6fe\uc4aa\u12d6\u4c79\u8ca6\u107f\u5db6\ubbb5\u1fa3\u371e\u2827\u64ff\u4606\uaac4\u56a3\uc528", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -1284325079, 4514014757036877735L, -48289L, true, true, (char) 25828, (char) 11435,
        Double.longBitsToDouble(0x3feb9b0a8d577727L), Double.longBitsToDouble(0x3f9a584f99c5c200L)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=java.lang.String:E |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:E\012",
        Z.run(T, 2, 17, 2, 12, "E\udb10\udc87\u0099\udb64\ude45\uda79\udf15\ud86c\udcd4\000", "\u2938\u32cc", "\uda44\udf3f\ud899\udff0",
        49, 95478, -329947021, 8290802275848949219L, -54174L, true, false, (char) 25207, (char) 59299,
        Double.longBitsToDouble(0x3fb7ac7b936188f8L), Double.longBitsToDouble(0x3fde1892b62d794eL)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:EP |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "E\ud912\udc4aP", "\u81cf\000\ua858\uc4bb\u2938\u32cc\u1ba2\u4238\uc0fd\u8d73\u8d7e\u4c79\u2972\u107f\u5db6\ubbb5\u1fa3\u371e\u6558\u1f1d\u0d33\ub766\u56fd\u0e29", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -677396183, 4514014202986096551L, 82271L, false, true, (char) 9385, (char) 18240,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fd2652f261ddbe8L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:T |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\ud8f9\udc68\udb10\udd32\u0099\ud932\udcac\uda79\udf0c\ud86c\udcd4t", "\u4f7f\u92fb", "\ud894\ude93\ud926\udc8e\u5c1b\udb80\ude2f\ud9e6\udcfb\udb47\udee8\udaea\udc96\udb36\udf3d\udba3\udf53\ud87d\udf86\udba7\udd8b",
        50, 20735, -1216900697, -3880273139259857987L, -89554L, true, true, (char) 37892, (char) 4398,
        Double.longBitsToDouble(0x3feff1ff0415c081L), Double.longBitsToDouble(0x3fbec5a154711fe8L)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 11, 7, 13, "\ua1d8\ud91c\udcedp", "\u81cf\ucc44", "\udaca\udd3c\ud89b\udd16\udbc5\udf64",
        47, 96435, -1595445719, 7766323146483278308L, 86401L, true, true, (char) 17274, (char) 8685,
        Double.longBitsToDouble(0x3fe2aa7343bf6a5aL), Double.longBitsToDouble(0x3fc5258253bddb5cL)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\udbd6\uddd5\ud96d\udc04\021", "\u81cf\u00c9\u6c59", "\ud89b\udd16\uda21\uddf3\udb82\ude68\uda0d\udea3\ud926\udc8e",
        22, 50276, 486532934, -3859065768318380682L, 95519L, true, true, (char) 49468, (char) 46960,
        Double.longBitsToDouble(0x3fd7261d3e04ce84L), Double.longBitsToDouble(0x3fd0ec3a510f0b32L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:M |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 17, 11, "\ud876\uddb7M\ud843\udd90\uda0c\udff3\012\ud86d\udcf8\udb0d\udcd2\u3725\ud9a6\udfab", "\u2ceb\u0bb4\uc0fd\u8d73\u8d7e\u4c79", "\udb80\udcac\udb5c\udf8e\ud898\udd26",
        44, 822, 1984626891, 19297454782218240L, 48219L, true, true, (char) 30386, (char) 49883,
        Double.longBitsToDouble(0x3e4a7b7aa8000000L), Double.longBitsToDouble(0x3fefe019636e2833L)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 12, 11, "", "\ud63b\ucecd\012\ub34e\uce72\ua858\u2766", "\uda21\uddf3\udb82\ude68\ud90b\udf6f\ud9a4\udf54\uda7f\udedf\ud80a\udd8e",
        13, 39673, 1363258339, -3520831463019842278L, -87317L, true, false, (char) 55740, (char) 48940,
        Double.longBitsToDouble(0x3fee1ac4065a332bL), Double.longBitsToDouble(0x3fe2743a93fdd102L)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\000\udb3a\udd3c\013 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 13, 1, "\000\udb3a\udd3c\013", "0\u99a5\ua858\u5307\000\u2480\uca45\u6119\uc0fd\u39de\u70da\ua728\u2c2a\u017f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u02b5\uaac4\u56a3\000", "\udba1\udff5\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 4726, (char) 24668,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 9, "\u00f1\000\uea3d", "\000\u99a5\ua858\u5307\000\u2480\uca45\u87da\uc290\u39de\u70da\ua728\u2c2a\u017f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u02b5\uaac4\u56a3\000", "\uda2a\udfcc\ud8f5\udc55",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 4726, (char) 24668,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\000\000\000 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 13, 1, "\000\000\000", "\u431b\u99a5\u98f0\ua6d6\025\u2480\uca45\u6119\uc0fd\u39de\u70da\ua728\u2c2a\u017f\u50b6\ubbb5\u1fa3\ub128\u4f31\u52d0\u6a74\uaa53\u56a3\u617b", "\udba2\udc2d\ud8e7\udd81\udbd5\udde8\udad3\udc09\uda39\udec2",
        38, 20143, 963510304, 906408757157931957L, 52719L, false, false, (char) 5459, (char) 25267,
        Double.longBitsToDouble(0x3eb39b5cc5000000L), Double.longBitsToDouble(0x3fe4e3b292131060L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 1, "\031\ud9cd\udf05\ud8a7\udd2e\ud89b\udc9b\uda79\udf15\ud97a\udf0c\udbcc\uddd1", "\000\u2480", "\ud90b\udf6f",
        9, 7280, 758469012, 5228933212337043664L, -36160L, true, false, (char) 26984, (char) 57480,
        Double.longBitsToDouble(0x3fc961ee8ad40000L), Double.longBitsToDouble(0x3fed01535ca41da6L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\000", "\000\u99a5\ua858\u47d3\017\uabcc\u8a58\u6119\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u4ff0\ubbb5\u1fa3\u36c9\ub326\u00cb\u00ef\u63de\ubdccY", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "H\000\000", "\000\u99a5\ua858\u2239\000\uabcc\u8a58\u6119\uc0fd\u8d73\u8d7e\u0f6f\ua543\u1152\u4ff0\ucbb4\u1fa3\u36c9\ub326\u00cb\u00ef\u63de\ubdccY", "\udb8e\udd3d\ud8e7\udd13",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 28424,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:T |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "d\000", "\ud280\000\u76a5", "\000",
        5, 69921, -1909587968, 4706080833833233961L, 18500L, true, true, (char) 62751, (char) 29483,
        Double.longBitsToDouble(0x3fd604a1a56b1e70L), Double.longBitsToDouble(0x3fe8027340d6bfb2L)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\004\000\ud8b1\udc51", "\u03b3\u99a5\ua858", "\udab0\udd94",
        51, 18032, 1095719830, -6852387183839967807L, 31101L, false, true, (char) 8685, (char) 26984,
        Double.longBitsToDouble(0x3fcad7f6432c3dd0L), Double.longBitsToDouble(0x3fcde0000a800000L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 5, 13, "\000\000\ud8b8\udc09\udb4b\udf45\uda79\udf15\014\uda4f\udfca\uda6a\ude84\ud8f9\udd60\000\udab0\udd94\udbe0\ude32\udb54\udd4a\udb2b\udcc8\ud926\udc8e\ud942\udd91\ud80a\udce2\ud9e6\udcc2\ud91d\udd33\udbbd\udd12\uda32\udeba\udba3\udf53", "\u00cb\u7034\u63fb\ubdccY\u2b70\u4984\u5ae8\ua972\u8d23\u093f\u1119\u8e2e\u159a\u008a\ua75c\ub305\u286f\uaa3c\u29c1\ub032\u6f47\u0b0c\ucd1a\u0ba6", "\ud9c6\udd77\udb0e\udd18\ud906\ude9f\ud99e\ude76\udb9b\udeba\ud985\udc8d\ud94f\udfdb\ud821\udf64\ud8b7\udf69",
        19, 7286, 1639911862, -1657330740611820796L, 83496L, true, true, (char) 16094, (char) 58494,
        Double.longBitsToDouble(0x3fe9b4300f3f5344L), Double.longBitsToDouble(0x3fea893c92dc90d6L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=java.lang.String:A111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 0, 7, 3, "A\000\000", "\u9966\u73c1\uc41a\u2239\ud200\u80bf\u0b9d\u6965\uc0fd\u8dc7\u8d7e\u4c79\u6d7d\u107f\u00e3\u7684\u1fa3\u36c9\u1886\u3e4f\010\uaac4\u56a3\000", "\udb8e\uddd1\udaa0\udddd",
        33, 94155, 41, -6582855281488828928L, -100000L, false, true, (char) 8732, (char) 21801,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979500004eL)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 3, "A\000\025", "\u9966\u73c1\uc41a\u2239\ud200\u80bf\u0b9d\u6965\uc0fd\u8dc7\u8d7e\u4c79\u6d7d\u107f\u50b6\u1028\u1fa3\u36c9\u1886\u3e4f\010\uaac4\u56a3\000", "\udb8e\uddd1\udaa0\udddd",
        33, 94155, -680345303, -6582594241966512541L, 31072L, false, true, (char) 8732, (char) 21801,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979500004eL)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 3, "A\ud945\udd22\005", "\u9966\u73c1\uc41a\u2239\ud200\u80bf\u0b9d\u6965\uc0fd\u8dc7\u8d7e\u4c79\u6d7d\u107f\u50b6\u1028\u1fa3\u36c9\u1886\u3e4f\010\uaac4\uc06a\000", "\udb8e\uddd1\udaa0\udddd",
        33, 94155, -680345303, -7447285371021366391L, 31072L, false, true, (char) 8732, (char) 21801,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979500004eL)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 13, "\000\000\000", "\000\u99a5\ua858\u2239\000\u080b\000\u6119\uc0fd\u8d73\u2c53\u571c\u49a0\u105d\u50b6\ubbb5\u6544\u36c9\u0270\u100e\u13aa\u5e81\u19fb\006", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, 49449, 0L, -100000L, false, false, (char) 53454, (char) 21647,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe7529790000000L)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\ud952\udfe8\007", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\u9459\u8d73\u2c53\u571c\u0f41\u1113\u50b6\ubbb5\u6544\u36c9\u0270\u982b\uae16\u5e81\u19fb\006", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 21353,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=java.lang.String:A111111111 |this=org.apache.commons.codec.language.Caverphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 0, 7, 13, "\u68a7\udb31\udc65H", "\u7e08\u9a8c\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u50b6\u239d\u1fa3\u36c9\ub326\u00cb\u00ef\uaac4\u56a3\uacbd", "\ud9a1\ude1b\udbbe\uddb9\ud806\ude0a\udac5\udd09\ud8a9\udec5\udb0f\udd73\ud963\uddd7 \ud95a\udf8c\ud87f\udf6a\ud8fc\udc47\ud97c\udc34\uc8e6\ud970\udef7\uda83\udeee\udadf\udc2f\udb02\udd5e",
        50, 55359, -920926565, 6241089748543079880L, 55212L, false, true, (char) 801, (char) 33633,
        Double.longBitsToDouble(0x3fd1b5a94e16b9d8L), Double.longBitsToDouble(0x3fe443d29b5e79d6L)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\003\000\000", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u0aca\u4c79\ub96b\u107f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u00ef\uaac4\u5554\016", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062badbb9f8L), Double.longBitsToDouble(0x3fca6cbb60000138L)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\000\udb4b\udf45\uda79\udf15\000\udbde\udc14\u3725\ud800\ude38\000\ud913\udc33\ud93c\udd7e\ud852\udf36\udb22\udf47\ud926\udc8e\u5c1b\ud80a\udd8e\ud9e6\udcc2\udafd\udc23\udbbd\udd40\uda32\udeba\udba3\udef6\udb71\udf35\uda7f\udea9\u00cb\u00ef\ud93a\udd5f\udab0\ude74\016\uda56\udfcb\ud8bc\udd71\udb8e\uddd1\ud8e7\udd81\udbd5\udde8", "\u8e2e\ua102 ", "\uf211\udb30\udc8b\ud828\udf32\ud970\udef7\uda83\udeee\ud8b0\ude57",
        59, 37297, 1550839084, -8399650565186269596L, -2704L, true, true, (char) 45163, (char) 38372,
        Double.longBitsToDouble(0x3fee411d13d47d82L), Double.longBitsToDouble(0x3fd61bad512be744L)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:S |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "X\000\000", "\000\u99a5\ua858\ud071\000\u80bf\uca40\u6119\uc0fd\u8d73\ucbbd\u4c79\u2e29\u3afa\ucdde\ubc49\u1fa3\ua1f5\u8b6b\u654f\ubc99\u9b48\u5554\016", "\udb8e\uddd1\ud8e7\udd81",
        35, 84171, -680345303, -7231112586943547365L, 31072L, false, true, (char) 4183, (char) 29508,
        Double.longBitsToDouble(0x3fdbb0133dca690eL), Double.longBitsToDouble(0x3fe752915000004eL)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 9, "\ud94a\udc03\ud910\udd88G\udb4b\udf45\uda79\udf15\000\ud9d0\ude4e\udac9\udfc9\u7b74\uda16\ude6a\ud867\udea4\udb1e\ude31", "\u8d73", "\udb28\udf99",
        59, 8168, -1892091552, -902010651853918866L, 90368L, false, false, (char) 10799, (char) 59523,
        Double.longBitsToDouble(0x3fe542a698a98833L), Double.longBitsToDouble(0x3fc041e5978624acL)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 17, "\ud91e\udc0e\ud910\udd88G\udb4e\udece\uda66\uddcb\ud867\ude63\ud9d0\ude4e\udac9\udfc9\u7b74\uda16\ude6a\udb54\ude7b", "\ube0b\001\u24ef\u4c79\ub036\ub544\u50cb", "\ud8fe\udd9f\ud885\udfde\u2939\u00ef\ud93a\udd5f\ud98d\udf20\ud88b\udd84\udb1c\udd3e\ud9f1\ude39\uda87\udeaa\ud8e7\uddf1\uda23\udccc\udabc\udd92\ud8a9\udec5\udb0f\udd73\ud963\uddd7",
        27, 69904, 234877540, 2032900136840958360L, -42095L, true, false, (char) 41584, (char) 32309,
        Double.longBitsToDouble(0x3fec7185db036486L), Double.longBitsToDouble(0x3fe0d45129f1eefaL)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 9, "", "G\uc95f\ud280", "\udac9\udfc9",
        9, -1000, 1255669760, 209050348544L, 18500L, true, true, (char) 25708, (char) 59206,
        Double.longBitsToDouble(0x3fd604a1a42f1e70L), Double.longBitsToDouble(0x3fca09cf6d016380L)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\030\000\000", "\000\u99a5\ua858\ub8bd\000\u80bf\uca40\u6119\uc258\u491b\u409a\u7d52\ub969\u107f\u50b6\ubbb5\u1fa3\u36c9\ub326\024\u00ef\uaac4\u56a3\000", "\udbb2\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 52942, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062bf33b9f8L), Double.longBitsToDouble(0x3fe752950800004eL)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\ud9de\udccb\000h", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u8d7e\u4c79\u2b7e\u7837\u6e86\u3d58\u5101\u37bd\u9085\ub80f\u00ef\u4fc2\u56a3\000", "\udbb2\uddd1\ud8e7\udd81",
        59, 84171, -1457340119, -8036027269836373849L, -4040L, false, false, (char) 39115, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\000\000\000\udb4b\udf45\uda79\udf15\000\udbde\udc14\u3725\ud800\ude38\000\ud857\udc74\udb1e\ude31\udb54\udd4a\ud9ad\udf00\ud926\udd2a\u5c1b\ud80a\udd8e\ud9e6\udcc2\udb47\udee8\udbbd\udd40\uda32\udeba\udba3\udf53\udb71\udf35\ud85c\uddbf\024\u00ef\ud93a\udd5f\ud98d\udf20", "\u4984", "\udbe1\udfb2\udad3\udc09\ud8a9\udec5\udb0f\udd73\ud963\uddd7 \ud95a\udf8c\ud9d6\udc96\uf211\udb10\udc6b\u9373\ud970\udef7\uda83\udeee\ud9dd\ude2d\ud8f3\udf5e",
        22, 22099, 1107755907, 7159345922216038468L, -40261L, false, true, (char) 54774, (char) 12577,
        Double.longBitsToDouble(0x3fb0d1b031123e60L), Double.longBitsToDouble(0x3fcd8d3fdf1da62cL)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\udb46\ude35\000\000", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u8d7e\u4c79\ub96b\u107f\u50b6\ubbb5\u1fa3\u36c9\ub326\024\u00ef\uaac4\005\u41bb", "\ud960\udfe5",
        57, 87449, -117074829, -2922060826361336470L, -49980L, false, true, (char) 24685, (char) 38390,
        Double.longBitsToDouble(0x3fe0a3b9feea52f2L), Double.longBitsToDouble(0x3eb3aa0878b00000L)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 11, "\udb1e\udc0e\000\000\udb4b\udf45\uda79\udf15\000\udbde\udc14\u3725\ud800\ude38\uda1c\ude95\ud857\udc74\udb1e\ude31\udb54\udd4a\ud90b\udf6f\ud926\udc8e\ua11b\ud8ad\udf1a\u9f5c\udb9c\udd21\udadb\udf4c\ud877\udf0e\udb99\udd48\udb71\udf35\ud938\udfed\ud9a4\udc0d\ud81a\udf46\ud84f\udcbe\uda15\udc34\022\uda56\udfcb\ud8bc\udd71\udabf\uddd5\ud8e7\udd81\udbd5\udde8\ub54a\ud880\udfc5\udb0f\udd73\ud963\uddd7 \ud93f\ude29\ud9d6\udc96\udba2\udee7\udb10\udcd9\udb0a\udd8f\uda46\udd59\uce68\ud8cb\udd4a\ud89a\udf00\ud93a\udf1d", "\u93ea\uaaed\uad6b\ua725\u080e\uc1ff\uc6ee\u279d\u246e\u7e17\u9507\ub8e1", "\udaf3\udfc8\uda98\uddbf\udb02\udedd\udbdd\udce8\ud92f\udf26\ud8b8\udee7\ud83e\udd23\udb6f\udc66\uda86\udd77\ud98e\udfd4\ud888\udde6\uda5e\udce8\uda39\udde6\ud97f\udf1c\ud853\udf53\ud990\ude41\uda1b\udcb4\ud884\udffc\ud9e8\udf2c",
        22, 1510, 378394472, 5253551307789600912L, 73601L, true, false, (char) 14820, (char) 44951,
        Double.longBitsToDouble(0x3fe82cab9b7a17eaL), Double.longBitsToDouble(0x3fc7e991c6bf7184L)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 0, 2, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\ud2b2\u40cb\u63d2\u2766\u38fb\u80bf\uca40\000\000\u8d4a\u00c1\u1ed8d6", "",
        12, 48693, 214, -2008794368L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd1e892b8e62248L), Double.longBitsToDouble(0x3e74000000000000L)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 2, 11, 0, 2, "\udb3f\udf77\ud946\udd8a\ud843\udd60", "\ud2b2\u99fa\ua858\u2766\u38fb\u80bf\uca40d\000\u8d4a\u00c1\u1ed8d6\000\000\u271c\uc21d\u00d6\000\u4517\uaac4\u56a3\u5315", "",
        46, 6874, 26262727, 1460095607111680L, -100000L, false, false, (char) 0, (char) 51092,
        Double.longBitsToDouble(0x3fd35087c00017b2L), Double.longBitsToDouble(0x3e2ff00000000000L)));
  }
  @Test(timeout = 4000)
  public void test177() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 2, "\udb3f\udf77\udb24\udcdf\ud843\udd90", "\011\u99fa\ua858\u2766\u6254\ud725\uca40\000\000\u8d4a\u00c1\uc8ea\uc23c\ud059\u78a6\000\000\u83df\u00d6\000\u4517\uaac4\u56a3\u5315", "\u00fd",
        44, 87449, -1585277837, 5779880718796587008L, -100000L, false, false, (char) 61435, (char) 55972,
        Double.longBitsToDouble(0x3f07bc0000000000L), Double.longBitsToDouble(0x3e310032f8000000L)));
  }
  @Test(timeout = 4000)
  public void test178() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 17, "\udb3f\udf77\ud81d\uddb6\udb8c\udd2e\uda4e\uddd6\ud894\ude20\ud993\ude21\udbde\udc69\udb8c\udf44\udae8\udd46\ud989\udd44\ud883\udf7a\ud836\udd86\ud8eb\udd94\ud8a8\udfb1\ud9fc\ude0f\udb93\udd05\uda54\ude3f\u2cc3\ud934\udc0d\ua0d6\020\000", "\u5400\u4517", "\ud914\udefc\000\000\ud8f2\udfb8\ue177\ud818\udca8",
        53, -1000, -1141184407, 677380096000L, 80992L, true, false, (char) 51835, (char) 21,
        Double.longBitsToDouble(0x3e2d2548b0000000L), Double.longBitsToDouble(0x3fea021e39506660L)));
  }
  @Test(timeout = 4000)
  public void test179() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 6, "\udb3f\udf77", "\u5557\ub04a\u1e96\u99fa\uab03\u3406", "\udb1e\ude31\000",
        -5, 50240, 193, -7285423544004907525L, -100000L, false, false, (char) 214, (char) 0,
        Double.longBitsToDouble(0x3fe8000000a08844L), Double.longBitsToDouble(0x3fc483b4cbeca8bcL)));
  }
  @Test(timeout = 4000)
  public void test180() throws Throwable {
    assertEquals("0=java.lang.String:P |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 17, 16, 13, "p\ud929\udc54\012", "\u6198\u0734\u8e3e\u9c39\u2c58\u285f\u5294\ud5ab\ud51a\u9117\u04e0\u7e28\uc78d\u68ae\u8fd7\ud2f8\ud2a1\u76b2", "\uda4a\udff7\ud966\udea5\ud8ea\udee3\ud95d\udd2b",
        40, 70286, 693050983, 6876765788844413072L, -1924L, true, false, (char) 19323, (char) 9828,
        Double.longBitsToDouble(0x3f800a4b1db04e00L), Double.longBitsToDouble(0x3fe25f719fbd954aL)));
  }
  @Test(timeout = 4000)
  public void test181() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 9, "\ud976\udff6\ud8c3\udd70\ud867\udcf6\udb64\ude45\udbb8\uddd1\ud8c5\udf4a\026\ud8f0\udc64\uda9b\ude4f\udae4\ude3e\ud9ec\udc9f\ud8ec\udf9c\ud941\udcdf\ud90b\udede\ud926\udc8e\uba30\ud80a\udd8e\udb14\udd88\udbd8\udd11\udbc0\udded\uda32\udeba\udba3\udf53\ud8ca\udea3\ud90d\ude5e\udb35\udded\udba6\udd64\ud8ab\udc8e", "\u8adb\u4984\u5ae8\u7fab", "\udb29\udd65\ud825\udc3f",
        54, 86165, 1010230106, -3427024481965682338L, -84499L, false, true, (char) 26606, (char) 14409,
        Double.longBitsToDouble(0x3fe0deb37e177287L), Double.longBitsToDouble(0x3fd0a55724d7644eL)));
  }
  @Test(timeout = 4000)
  public void test182() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:P |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "p\ud912\udc4a\uda19\uddbc", "\u81cd\u0fc0\ua858\u1c44\u6566\u32cc", "\ud90b\udf6f\uda0f\udde4\udbe0\udfe2\ud80a\udcc5",
        40, 13273, 323516542, 7932149588745032373L, 22666L, false, true, (char) 34526, (char) 33774,
        Double.longBitsToDouble(0x3fea49efebfbf7b1L), Double.longBitsToDouble(0x3fd616716c17714eL)));
  }
  @Test(timeout = 4000)
  public void test183() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:E |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "E\ud912\udc4a\ud9ef\udec6", "\020J\u32a0\u53fb\u2938\u13f7\u6a54\u08b5\u5dad\u2b1a\u8d7e\ua21e\u2972\u6032\u7ab6\ubbb5\u1fa3\uba7d\u6525\u1f1d\u0d33\ub766\u56fd\u0e29", "\ud897\udfec\uda27\udeaf",
        59, 84171, -677396183, 4514014202986096551L, 82271L, false, true, (char) 9385, (char) 18240,
        Double.longBitsToDouble(0x3fbb10628ea789f8L), Double.longBitsToDouble(0x3fd2652f261ddbe8L)));
  }
  @Test(timeout = 4000)
  public void test184() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:KP |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 0, "c\ud912\udc4aP\udac3\ude35\udbc3\udf8b\udaa5\udee6\uda34\udd52\u3725\ud935\ude52\udba9\uddcf\ud8a9\udc72\uda02\ude48\udba9\udc14\ud90b\udf43\ud926\udc8e\u5c1b", "\u107f\u5d55\ubbb5\u1fa3", "\ud984\udc85\u5f9b\udb45\ude05\ud98d\udf7a\ud8c2\ude0e\uda95\udf2c\udae8\udd67\udb8e\uddd1\ud8e7\udd81\udbd5\udde8\udad3\udc09\udb6d\udec7\ud824\udfb1\ud99d\udcd7\udb8d\udf36\ud98c\udf8b\u1d6f\ud870\udd36\udb10\udc6b\u9373\ud970\udef7\udb1f\udc15\udb53\udfc7\ud857\udc03\ud8e3\ude09",
        46, 77329, 2124955211, -5974981582831214119L, 78313L, true, false, (char) 60845, (char) 45307,
        Double.longBitsToDouble(0x3fe125ec5ad7d63bL), Double.longBitsToDouble(0x3fdb01c92cdc5d0eL)));
  }
  @Test(timeout = 4000)
  public void test185() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 17, 8, "\000\udb3a\udd3c\013", "0\u99a5\ua858\uc832\036\uba50\u6a08\u3e5c\u5021\u39de\u8464\ua728\u1504\u017f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u4f75\u83e8\u56c2\ud0e5", "\uda07\uddc6\udbc3\udf79",
        19, 84311, -680345303, 46704412156821671L, 31072L, false, true, (char) 32373, (char) 24701,
        Double.longBitsToDouble(0x3fbb1062ababb9f8L), Double.longBitsToDouble(0x3fda87ee3dd1c4eeL)));
  }
  @Test(timeout = 4000)
  public void test186() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\000\udb3a\udd3c\013 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 13, 1, "\000\udb3a\udd3c\013", "x\u99a5\ua858\u5307\000\u2480\uca45\u6119\u9065\ub941\u9c73\ua728\u2c2a\u017f\u50b6\ubbb5\u1fa3\ud590\u54f6\u00cb\u02b5\ub844\ua6ab\000", "\udb97\ude3a\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 4726, (char) 24668,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test187() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 1, 1, "\031\ud9cd\udf05\ud8a7\udd2e\ud8e1\ude7d\ud9b1\uddc9\uda12\udc0f\uf57b", "\u47e4\u389e", "\ud922\udfa2",
        27, 95026, 762663316, -5435590708430407659L, -62272L, true, false, (char) 26984, (char) 57480,
        Double.longBitsToDouble(0x3fdcb0f7456a00deL), Double.longBitsToDouble(0x3fed01535ca41da6L)));
  }
  @Test(timeout = 4000)
  public void test188() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\udb9c\udeda\u4809\ud8a7\udd2e\udb72\udd86\uda79\udf15\uda4a\udc09 |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 13, 11, "\udb9c\udeda\u4809\ud8a7\udd2e\udb72\udd86\uda79\udf15\uda4a\udc09", "\u0930\003\u5993\u85d4\u1ab2", "\udb04\udc46\ud8f5\udfd1\ud912\udcf8\ud94e\udce2",
        -3, 41448, 1315476149, -4633611379537600298L, 97301L, false, true, (char) 18770, (char) 15622,
        Double.longBitsToDouble(0x3fe9824768b39142L), Double.longBitsToDouble(0x3feeb083821243d4L)));
  }
  @Test(timeout = 4000)
  public void test189() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 2, "\000\000\000", "\000\u99a5\ua858\u47d3\017\uabcc\u8a58\u6119\uc0fd\u8d73\u62a1\u4c79\ub96b\u107f\u4ff0\ubbb5\u1fa3\u36c9\ub326\u00cb\u00ef\u63de\ubdccY", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test190() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "w\000\000\ud9a5\udd70\uda79\udf15\000\udbde\udc14\u3725\udb2b\udd2a\ud970\ude26\ud9f1\udd24\udbe0\ude32\udb54\udd4a\ud90b\udf6f\ud926\udc8e\u5c1b\ud80a\udd8e\ud9e6\udcc2\udb47\udee8\udbbd\udc7a\udbc5\ude22\ud913\udffe\udb71\udf35\ud85c\uddbf\u00cb\u00ef\ud87f\udf81\udaa6\udf26Y\uda56\udfcb\ud8bc\udd71\udb8e\uddd1\ud8e7\udd81\udbd5\udde8", "\u8e2e", "\ud95a\udf8c",
        19, 47198, 1099584655, 8592679438271028756L, 31072L, false, true, (char) 51232, (char) 37331,
        Double.longBitsToDouble(0x3fe0d95cc9211b05L), Double.longBitsToDouble(0x3fe6c75270ad6280L)));
  }
  @Test(timeout = 4000)
  public void test191() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "G\000", "\ud280\000\u76a5", "\000",
        36, 69921, -1909587968, 4706080833833233961L, 25001L, false, false, (char) 17274, (char) 8685,
        Double.longBitsToDouble(0x3fe802734766bfb2L), Double.longBitsToDouble(0x3feab32f4243a721L)));
  }
  @Test(timeout = 4000)
  public void test192() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 2, "\000\000\ud894\udc09\udb4b\udf45\uda79\udf15\014\000\uda6a\ude84\ud8f9\udd60\000\udab0\udca0\udbe0\ude32\udb54\udd4a\udb2b\udcc8\ud926\udc8e\ud942\udd91\ud80a\udce2\ud9e6\udcc2\ud91d\udd33\udbbd\udd12\uda32\udeba\u00b5", "\u00cb\u7034\u63fb\ubdccY\000\000\u5ae8\ua972\u8d23\u093f\u1119\u8e2e\u159a", "\ud9d6\udc96",
        11, 20647, 2000639084, 5965472990170638058L, 4178L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e44b8596c000000L)));
  }
  @Test(timeout = 4000)
  public void test193() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:A |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 17, "A\uda93\udca9\udbef\udfed\udb4b\udf45\uda79\udf15\udb88\udf18\ud905\ude27\u4e0f\ud800\ude38\ud200\ud857\udc74\ud9d4\udf6d\udb16\udf4b\ud90b\udf6f\ud926\udce2\u5c1b\ud80a\udd8e\ud9d3\udcd4\udb47\udee8\udbd0\udf33\ud925\udf53\udba3\udf53\udb71\udf35\ud9e1\udeda\udb3b\uddc6\010\ud93a\udd5f\ud970\udf31\000\uda56\udfcb\ud95f\uddf4\udb8e\uddd9\udb7e\udfcb\udb52\ude1c\udadc\udf09\ud8a9\udec5\udb0b\udf52\uda23\udd5d\uda7f\udd46\ud95a\udf8c\ud9d6\udc96\udb66\uddb3\udb10\udc6f\u9373\ud970\udef7\uda83\udeee\uda69\udd79\udbcf\uddea\uda00\udc85\ud9a3\udfdf\ud811\ude58\ud9dd\udd9e\uda04\udfcc\udaa7\udd9f\uda01\udd82\udbd6\udda4\udb32\udcfc\udb57\udd76\ud90e\udf6c\ud972\udde3\ud8e1\ude0d\udabd\udf2b\udbbd\ude3c\udbc7\uddc6\uda73\udc68\ud92f\udd83\uda08\uddb6\udbf8\udc7c", "\u8ac4\u800f\uc019\u38af\u5fa1\ua49c\uba7d\ua1a9\u996c\ucff0\u8e06", "\ucfb0\ud920\udc3c\ud8cb\ude4d\uda48\udd41\ud9d8\udf36\ud976\ude55\udb39\ude5d\uda36\udfe9\uda86\udf27",
        43, 21736, 1207365248, -6595809298920907375L, 92543L, true, false, (char) 21407, (char) 32343,
        Double.longBitsToDouble(0x3fa7d6b987882a20L), Double.longBitsToDouble(0x3fcb3328c596319cL)));
  }
  @Test(timeout = 4000)
  public void test194() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "\023\000\000", "\000\u99a5\ua858\u2239\000\u80bf\uca40\u6119\uc0fd\u8d73\u0aca\u4c79\ub96b\u107f\u50b6\ubbb5\u1fa3\u36c9\ub326\u00cb\u00ef\uaac4\u5554\016", "\udb8e\uddd1\ud8e7\udd81",
        59, 84171, -680345303, -8744322060463180728L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062badbb9f8L), Double.longBitsToDouble(0x3fca6cbb60000138L)));
  }
  @Test(timeout = 4000)
  public void test195() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:K |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 13, "K\000\ud83f\udd9e", "\000\u99a5\u64f6\ud071\000\u80bf", "\udbed\udd67",
        52, 88359, 758501092, -1513236906746729840L, 98156L, true, false, (char) 26984, (char) 56407,
        Double.longBitsToDouble(0x3fcca2215035fd68L), Double.longBitsToDouble(0x3fa218d9c661da60L)));
  }
  @Test(timeout = 4000)
  public void test196() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 17, "\ud91e\udc0e\udb60\udf7a\uda57\udf44\ud85d\udfa7\udb17\ude2c\ud840\udc22\ud9d0\ude4e\udac9\udfc9\u7b74\uda16\ude6a\udb54\ude7b", "\ube0b\001\u24ef\u4c79\ub036\ub544\u50cb", "\ud8fe\udd9f\ud885\udfde\u2939\u00ef\ud93a\udd5f\ud98d\udf20\ud98d\udda6\udb35\udd48\ud819\udf47\udaa0\uddac\ud8e7\uddf1\uda23\udccc\udabc\udd92\ud92f\udec8\udb0f\udd73\ud963\uddd7",
        27, 69904, 234877540, 2032900136840958360L, -42095L, true, false, (char) 41584, (char) 32309,
        Double.longBitsToDouble(0x3fec7185db036486L), Double.longBitsToDouble(0x3fe0d45129f1eefaL)));
  }
  @Test(timeout = 4000)
  public void test197() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 11, 7, 6, "K\000\ud83f\udd9e", "\u34cb\u9f7f\u30e2\ud071\u97ff\u65dd", "\u7037\ud847\udf68\uda07\udedd\ud80a\udd8e\ud881\uddd0",
        38, 39757, -1892091404, -6743979126229199921L, -96718L, true, true, (char) 2519, (char) 27148,
        Double.longBitsToDouble(0x3fe358692d29833aL), Double.longBitsToDouble(0x3fe0a716ce200380L)));
  }
  @Test(timeout = 4000)
  public void test198() throws Throwable {
    assertEquals("0=java.lang.String:1111111111 |this=org.apache.commons.codec.language.Caverphone:@?\012",
        Z.run(T, 1, 4, 0, 13, "\udb75\ude82\udb24\udcdf\ud84a\ude42", "\ucc55\u8b46\ua858\u9c41\u1717\u80bf", "\udaab\ude75\udaf8\udd44",
        44, 91075, -1210245875, 8290801601524403683L, -26058L, false, true, (char) 21874, (char) 52318,
        Double.longBitsToDouble(0x3fc483b328baa2b8L), Double.longBitsToDouble(0x3fe71898ce2d2c09L)));
  }
  @Test(timeout = 4000)
  public void test199() throws Throwable {
    assertEquals("0=java.lang.String:\u432d |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:\u432d |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 17, 13, 7, "\u432d", "\u97b8\ub5cc\u90f0\uaf61\u6562\u842b\ub0d2\u1e1f\u33b2\ub7f0\u57eb\u8f57\u8e36\u4c68\uc832\ud335\uaa5b\ub0b5\u1f63\u40f8\ud64d\u3f78\u3933\ua92b\u3f4d\u3fe3\u4e8f\ubdb8\u08f5\uab84\u7aee\uba3b\u348b\u8301\u5c70\u8746\u716b\uc320\u4ebf\u8914\u2242\u2c32\u7a69\ub69c\u05e2\u5548\u7d33\u92e8\u0265\u8636\u1dcb\ua620\ud1b6\u4978\ua490\u0294\u4e1a\ubec8\uce59\u1082\uae76\ub190\u8225\u1885\u6357\ubf45\u0654\u2b92\ube00\u7a09\u9f3b\u83cf", "\udb3a\uded5\udb9e\ude35\ud8f6\udfe9\ud943\udc16\ud83b\udd21\ud8d5\udffe\ud87e\udc73\ueb2e\udbcc\udf1d\uda47\udc7f\ud976\udd98\uda62\udd92\udb2b\udea1\ud937\udf83\ud8b5\udc7f\ud9b7\udc9d\ud9ef\udcb5\udab2\udcd1\uda6b\udc25\ud944\udd81\ud8f0\udda5\ud99e\ude3b\udac9\udffc\udb26\ude0b\udab9\udf46\ud98d\ude0a\uda18\udfe7\ud81f\udee4\ud83d\uddd4\udabd\udeab\ud90f\uddfa\udab5\udd4c\ud979\udc52\ud830\udca8\udb42\udea2\ud855\uddc5\ud863\udd01\ud87e\udc88\udac8\ude06\udb1e\udde1\uda14\udf34\ud872\udd46\ud8d9\udd3a\udb30\uded2\udb9d\udc4d\ud980\udf5f\ud8e4\udd79\udbfc\udfae\udbd7\ude21\udb4c\udfdf\uda29\udcfa\uda06\udf26\uda45\udecb\udb28\udc55\udb7c\udc5a\ud9be\udfdd\ud8f0\udf28\ud872\udce8\ud834\udf9a\udae5\udd08\ud840\ude86\udb68\ude5e\udbf7\udd2c\udaee\udc38\ud8d1\ude8f\ud825\udcbd\udb71\udc6e",
        21, 94668, -957018984, 2733587485405612799L, 93047L, false, false, (char) 5840, (char) 31049,
        Double.longBitsToDouble(0x3fd6137e514a9bc0L), Double.longBitsToDouble(0x3fe511943b8394f5L)));
  }
  @Test(timeout = 4000)
  public void test200() throws Throwable {
    assertEquals("0=java.lang.String:\u5f67\0121=java.lang.String:\u5f67\012",
        Z.run(T, 2, 2, 2, 10, "\udb75\ude82\ud9c6\udff0\ud805\udc02\uda53\ude5d\ud877\udd30\uda0c\udd51\ud96e\udd9e\ud82f\ude29\udbc7\uddd5\ud948\udf23\ud857\udcd7\ud90b\udc94\ud8dc\udf02\udaab\ude75\ud931\udf41\udbc7\udd6e\u5f67\ud98d\udec5\ud950\udd46\udbc0\ude40\uda32\udeba\udba3\udf53\udb65\udd31\ud8b7\udc84\udb3b\uddb4\uda71\udc18\ud904\udc5f\uda87\udf7e\uda94\udc9e\udb12\udc20\udaea\udd2a\ud869\udfe9\uda6c\udff5\ud9a5\udd0e\uda81\ude19\ud90d\udce8\uda9e\udd0b\ud94e\ude22\ud870\udd80\ud810\udce6\ud952\udc7b\udb77\ude8a\udab0\udd5a", "\u54df\uc32e\ub470\ube6b\u54e0", "\udbba\udd5b",
        46, 41527, 1468400862, -7697898157801253472L, -76047L, false, false, (char) 48670, (char) 53845,
        Double.longBitsToDouble(0x3fe1ffa4a5d81328L), Double.longBitsToDouble(0x3fee61bce4964d1fL)));
  }
  @Test(timeout = 4000)
  public void test201() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:B |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 7, 3, "\udaf9\udc19\ud9a7\udd4bb", "\u9966\u73c1\uc41a\u2239\ud200\u80bf\u0b9d\u5f9e\u40e9\u563b\u3ffa\u4c51\u6d7d\u107f\u50b6\u7ffe\u1fa3\u36c9\u1886\u3e4f\010\uaac4\u56a3\u9aaa", "\udaf3\udf32\udaa0\udddd\udb52\ude96\udadc\udf09\ud8a9\udec5\udb36\udc07\ud860\udebe\ud950\udcea\uf95e\ud83b\udfff\ud90f\ude0f\ud831\ude36\u9373\ud970\udef7\uda83\udeee\udbe8\ude78\uda34\udd21",
        26, 92872, -765728770, 7535465898096975329L, -54401L, true, true, (char) 51553, (char) 16809,
        Double.longBitsToDouble(0x3fe93f9186bafbebL), Double.longBitsToDouble(0x3fda7ac7eb6eb958L)));
  }
  @Test(timeout = 4000)
  public void test202() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 0, "\000\000\000", "\000\u99a5\ua858\u2239\000\u80bf\uca40\000\000\000\000\000\000\000\000\u9a54\000\000\000\000\u00ef\uaac4\000\000", "\udbb2\uddd1\000",
        -5, 46168, -680345303, 46704412156821671L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test203() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 9, "\u00f1", "\uc95f", "\u60ea\u3725\ud914\ude42\000\uda6d\udc98\udb1e\ude36\uda6d\uddf5\ud8c4\udcca\udb5f\udc3d\udb90\udeff\ua43e\uda52\udfb9\udb7f\udf4e\udbbd\udd40\uda32\udeba\udba3\udf53\ud851\udd84\ud85c\uddbf\u00cb\u02b5\ud93a\udd5f\ud98d\udf20\udbdd\udd29\ud815\udf69\udb47\ude40\uda2b\udc8b\ud8f5\udc55\uda87\udde1\udad3\udc09\ud8a9\udec5\udb0f\udd73\ud963\uddd7 \ud95a\udf8c\ud9a2\udd3c\uc7b7\udb30\udd6b\ud8b6\udcdb\ud970\udef7",
        37, 23240, 1182299249, 8067074826573650182L, 25243L, false, true, (char) 64434, (char) 59955,
        Double.longBitsToDouble(0x3fecdeb40cb84326L), Double.longBitsToDouble(0x3f9715e879044b40L)));
  }
  @Test(timeout = 4000)
  public void test204() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:false |a0=java.lang.StringBuffer:He\000\udb4b\udf45\uda79\udf15\000\udbde\udc14\u3725\ud800\ude38\000\udab0\udd94\udbe0\ude32\udb54\udd4a |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 15, 11, "He\000\udb4b\udf45\uda79\udf15\000\udbde\udc14\u3725\ud800\ude38\000\udab0\udd94\udbe0\ude32\udb54\udd4a", "\u8d7e\u0f6f\ua543\u1152", "\udba3\udf53\udb71\udf35\ud85c\uddbf\u00cb\u00ef\ud861\udc81\udaa6\udf26Y",
        -5, 13155, 254546009, -8562569861838464543L, -18377L, false, true, (char) 332, (char) 22573,
        Double.longBitsToDouble(0x3e3b21e1b0000000L), Double.longBitsToDouble(0x3fd5e637065417bcL)));
  }
  @Test(timeout = 4000)
  public void test205() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 11, 0, "\000\000\000", "\000\u99a5\ua858\u2239\000\u80bf\uca40\000\000\u29c7\u4784\u00b7\000\000\000\u9a54\000\000\u3a5f\000\u00ef\uaac4\000\000", "\udbb2\uddd1\000",
        -5, 46168, -680345303, -7487254814477810028L, 31072L, false, true, (char) 8655, (char) 24685,
        Double.longBitsToDouble(0x3fbb1062b0a3b9f8L), Double.longBitsToDouble(0x3fe752979000004eL)));
  }
  @Test(timeout = 4000)
  public void test206() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.Metaphone:@?\0121=java.lang.String:H |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 2, 11, 1, 11, "He\000\udb4b\udf45\uda79\udf15\000\udbad\ude14\u3725\ud800\ude38\000\udab0\udd2b\ud8ff\udd41\udbf8\ude9d", "\u73ee\u741c\ua543\u1152", "\udba3\udf53\udb71\udf35\ud85c\uddbf\u00cb\u00ef\ud861\udc81\udaa6\udf26Y",
        -5, 13155, 254546009, -8562569861838464543L, -18377L, false, true, (char) 332, (char) 22573,
        Double.longBitsToDouble(0x3e3b21e1b0000000L), Double.longBitsToDouble(0x3fd5e637065417bcL)));
  }
  @Test(timeout = 4000)
  public void test207() throws Throwable {
    assertEquals("0=java.lang.String:W |this=org.apache.commons.codec.language.Metaphone:@?\012",
        Z.run(T, 1, 7, 10, 1, "wE\000\000\ud9e8\udf34\u26b6\ud8b6\ude76\udb70\udd80\ub150\u2c58\ud9a8\udfcc\ud906\udf2e\000", "\u5476\u7e28\uc78d\u107f\u8597\ubbb5\u2578\u766d\u161c\u7b97\uca2c\u0eda\u02d0", "\udb14\udf8d\u8718\u6f3a\ud827\udc6d\udb53\udfe5\udb79\udec0\uda0d\udf28\ud80d\udfe4\udaf9\ude05\ud890\udf9e\udb24\udf89\udb72\uddcd",
        32, 31468, 586051539, 8534332503238677653L, -26426L, false, false, (char) 2842, (char) 65491,
        Double.longBitsToDouble(0x3fcc7ec42f1a32b8L), Double.longBitsToDouble(0x3fed1b26f8822ed3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.language.Caverphone|caverphone|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Metaphone|metaphone|java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.SoundexUtils|clean|java.lang.String|static",
    "M|org.apache.commons.codec.language.Caverphone|encode|java.lang.Object|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|encode|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Caverphone|isCaverphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "C|org.apache.commons.codec.language.Caverphone|<init>|",
    "M|org.apache.commons.codec.language.Metaphone|encode|java.lang.Object|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|encode|java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|getMaxCodeLen||new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isLastChar|int,int|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isMetaphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isNextChar|java.lang.StringBuffer,int,char|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isPreviousChar|java.lang.StringBuffer,int,char|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|isVowel|java.lang.StringBuffer,int|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Metaphone|regionMatch|java.lang.StringBuffer,int,java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.Caverphone|caverphone|java.lang.String|new:org.apache.commons.codec.language.Caverphone:",
    "M|org.apache.commons.codec.language.Metaphone|metaphone|java.lang.String|new:org.apache.commons.codec.language.Metaphone:",
    "M|org.apache.commons.codec.language.SoundexUtils|clean|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
