package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base64_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[B:[[5, -63, 30, 39, -26, -74, -38, -80]] |a0=[B:[[5, -63, 30, 39, -26, -74, -38, -80]]\012",
        Z.run(T, 1, 9, 7, 10, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        10, 26138, 1634116835, -7284668773450976360L, -9556L, false, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fecf62c0b0f1c6fL), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 13, 3, 18, "\udb7c\udde3\ud937\ude07\udbbd\udf02\uda91\udd79\udb02\uddd8\uda2d\udc49\udbd7\ude46\ud900\udd95", "\u9358\uc82a", "\ud967\udc42\udac8\udc93\ud9bb\udc2f\udaf1\udf3c\ud872\ude8a",
        57, 24869, 1415515276, 3963192053207331768L, -9556L, false, true, (char) 56266, (char) 14122,
        Double.longBitsToDouble(0x3feca828bde91c13L), Double.longBitsToDouble(0x3fe1e59b08bbda63L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[B:[[5, 50, 30, 39, -26, -74, -38, -80]] |a0=[B:[[5, 50, 30, 39, -26, -74, -38, -80]]\012",
        Z.run(T, 1, 9, 7, 10, "\uda35\udc62\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\ud87f\udce8\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\ud870\udc64\ud91d\udd67\ud96b\udf6d\udaf1\udeb5\udaae\ude88\ud88f\uddc2\ud8f4\udee8\ud9a6\udea0\udb3e\ude63\udb57\udea5\uc154\ud829\udf0b",
        8, 53711, -981340236, -4803162104218555068L, -96091L, true, true, (char) 49603, (char) 48640,
        Double.longBitsToDouble(0x3fe46303cc8c309eL), Double.longBitsToDouble(0x3fe2f54d1f1ad02eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-43, 58, 41, 56, -18, 42, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 1, 9, "\ud805\udc6a\uda59\udc68\udb1e\udc5a\udb33\udff4\ud888\udd4b\uda2d\udc49\udbd7\udef9\ud8f0\udc6e\udbce\udc45\ud86e\udcdb\ud973\uddc8", "\uacc0\u87fa", "\udb04\udf8b\ud992\udd1d\ud8a9\udce1",
        3, 63698, -2080055078, -8088111113396259144L, 67364L, true, false, (char) 17643, (char) 29983,
        Double.longBitsToDouble(0x3fe878e7a63cb36fL), Double.longBitsToDouble(0x3fc777cc74c61b28L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[5, -63, -118, -122, -26, -74, -38, -80]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 9, 10, "\uda35\udcf1\udbba\udcb6\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        10, 26138, 1634116835, -7284669155703065704L, -9556L, false, true, (char) 233, (char) 12212,
        Double.longBitsToDouble(0x3fecf62c0b0f1c6fL), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[B:[[-78, 87, 26, 28, -40, 22, -38, -80]] |a0=[B:[[-78, 87, 26, 28, -40, 22, -38, -80]]\012",
        Z.run(T, 1, 9, 7, 10, "\udae2\ude87\ud94a\ude4c\udb08\udc46\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbb7\ude68\ud900\udd6e", "\u6cfc\u356a\u9b20\u70c0\u87fa\u429d\u1e64\ua080", "\ud818\udee1\ud9a6\udea0\udb3e\ude63\ud877\udcad\ud9c8\uddc2\udb36\udd1a\ud83b\udfbe\ud854\udd4d\udb1c\ude99",
        18, 57887, -1100767684, -4461958121729768887L, 24173L, true, false, (char) 16712, (char) 61791,
        Double.longBitsToDouble(0x3fd9f30f86ef04ceL), Double.longBitsToDouble(0x3fdf361021cb0c2cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 4, 2, "\ud947\udceb", "\u40cd\u7fb9\u60de\u2720\u2544\uc163\u9aa2\u69ea\uc82a\u9b77\u70c0", "\ud96b\udf6d\udabd\udf5b\udaae\ude1d\ud88f\uddc2\ud8f4\udee8\ud9a6\udea0\udb3e\ude63\udb57\udea5\udbb1\udf57\ud849\udedd\ud876\udc84\ud8a7\udff2\ud835\udfcb\u195f\udb83\ude8b\ud86c\ude5e\uda0b\udcc2\uda5e\ude24",
        -5, 99671, 812124663, -5943657265921349386L, 53377L, false, false, (char) 47798, (char) 4927,
        Double.longBitsToDouble(0x3fa3cc30c8d0e270L), Double.longBitsToDouble(0x3feacc9142fe1cd8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[5, -63, 30, 39, -26, -74, -38, -80]]\012",
        Z.run(T, 1, 8, 7, 10, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\uda09\udeb4", "\u69ea\uc82a", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        10, 26138, 1634116835, -7284668773450976360L, -9556L, false, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fecf62c0b0f1c6fL), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[B:[[5, -63, 30, 39, -26, -74, -38, -80]] |a0=[B:[[5, -63, 30, 39, -26, -74, -38, -80]]\012",
        Z.run(T, 1, 9, 7, 10, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda8f\udcba\ud82c\udf4a\ud900\udd6e", "\u69ea\u67b1", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88\ud8a7\ude51\ud8f4\udee8\ud9a6\udea0\udb3e\ude63\udb8f\udd20\ud9c8\udd42\udb36\udd1a\ud83b\udfbe\ud89e\udef2\uda16\udfd2\ud808\udd4b\ud8d8\udc47\ud86c\ude5e\uda2b\udf12\udb6d\udef4\udaa0\udfd2\uda94\udf99\ud893\udc69\u1c4e\ud9bd\ude60\udb3e\udcd5\uda61\ude11\uda81\udc93\ud946\uddf7\ud8bc\udf26\uda07\udce8\ud94f\udecc\udb67\udea6\udbf6\udc5a\ud8c8\uddaf\ud9bd\udd91\udbbb\udf17\ud8bd\udd8f\ud81f\udd99\ud9c7\udd5b\ud8c5\udf48\ud80d\udc8e\ud870\udcd7\ud9a5\udd17\ud9e4\udcd6\ud86d\udd6c\uda47\udf57\ud8a6\udd01\uda94\ude8f\ud831\ude3f\udac8\udc3b",
        28, 45716, 1357895293, -2096324578862307259L, 68312L, false, true, (char) 26409, (char) 11028,
        Double.longBitsToDouble(0x3fd828042222aee8L), Double.longBitsToDouble(0x3fb3698122f0d3b0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 14, 17, 10, "\uda35\udc6f", "\u40cd\u7fb9", "\ud8fc\ude6e",
        49, 24341, 1957364500, -9113766439737977552L, -95632L, true, false, (char) 49936, (char) 58918,
        Double.longBitsToDouble(0x3fe7035d8fffb656L), Double.longBitsToDouble(0x3fd7261c89c7a9deL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 2, 13, 10, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\udbb8\udf11\udbd1\udcca\ud900\udd6e\udbcd\udfcd\ud86e\udcdb\ud947\uddd1\ud882\udf3c", "\u87fa\ud049\u7a19\u1801\ubf45", "\uda33\udfc7\ud810\udfec\udb57\ude9c\ud94a\udc7b\ud924\udfa9\ud83c\udc3b",
        1, 75764, 485362152, -5517143676181832132L, 80276L, true, false, (char) 52082, (char) 9532,
        Double.longBitsToDouble(0x3fd27a7129337f7cL), Double.longBitsToDouble(0x3fa336b11b3f3820L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 7, 10, "\000", "\ubb77\000", "\ud900\udd6e",
        27, 58101, -653449216, 73129226036736L, -95634L, true, false, (char) 27597, (char) 58819,
        Double.longBitsToDouble(0x3fcc0d762002d958L), Double.longBitsToDouble(0x3fbc9872271ea778L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[B:[[5, -63, 46, -4, -79, -52, -38, -121]] |a0=[B:[[5, -63, 46, -4, -79, -52, -38, -121]]\012",
        Z.run(T, 1, 9, 7, 10, "\uda35\udcf1\uda5e\udc2c\ud9e1\udffc\ud90a\udfb7\ud888\uddbf\udb2e\udf6b\ud985\udf8f\ud900\udd6e\udbcd\udfcd\ud86e\udcdb\ud973\uddc8\ud882\udf3c\u2ad3", "\u0f22\u7a7a\u1801\uc791\u2be3", "\ud8dd\udc05\udab5\uddbe\u6c13\udb58\udd75",
        41, 53867, 1442836404, 2049049641601697247L, -1063L, false, true, (char) 30689, (char) 43182,
        Double.longBitsToDouble(0x3fbbd58a2aefaf58L), Double.longBitsToDouble(0x3fdba7eedc45610eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 1, 7, 8, "\uda6c\udd0f", "\u40cd\uafc2", "\ud900\udd6e",
        27, 24341, -876544748, 5326424113797580084L, -93734L, false, true, (char) 58032, (char) 52821,
        Double.longBitsToDouble(0x3fe6f30e46f6bdd5L), Double.longBitsToDouble(0x3fb658599cc4d738L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[B:[[-59, -63, -82, -89, -26, -83, -38, -80]] |a0=[B:[[-59, -63, -82, -89, -26, -83, -38, -80]]\0121=java.lang.Boolean:false |a0=[B:[[-59, -63, -82, -89, -26, -83, -38, -80]]\012",
        Z.run(T, 2, 9, 5, 5, "\udaf5\udcf1\ud9de\udfd7\udb16\udfdd\ud90a\udfe0\udbdd\ude88\ud936\uddfe\ud84f\udc3d\ud8f2\udff5", "\ud26b\u9e1a", "\udbdf\udc7a\udac7\udfef\ud903\uddb9\udb56\udcf6\udb68\udee0\ud88f\uddc2\ud8f4\udea5",
        -4, 69653, -1408044136, 6665730451130343310L, -8924L, true, false, (char) 7166, (char) 45347,
        Double.longBitsToDouble(0x3fc69c2f095ef630L), Double.longBitsToDouble(0x3fe28dc85bef77bcL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 7, 7, 10, "\uda35\udcf1\ud8db\ude1f\udb16\udfe5\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud844\ude1c", "\u69ea\u3b70", "\ud9d0\udfee\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88\ud93f\udcdb\ud8fc\udff9\ud9a6\udea0\udb3e\ude63\udb57\udea5\ud9c8\uddc2\udb36\udd1a\ud83b\udfbe\ud89e\udef2\uda17\udc41\u194b\udb83\ude8b\ud86c\ude5e\udadb\udd0a\udb15\udcaf\ud87d\udcfc\udad0\udc57\udb8f\ude31\ud9bd\udfa6\udb82\udd76\ud824\udd78\udaaa\udd7c\udba0\udc04\uda36\udda8",
        59, 26804, -1087733371, -6503857170727000154L, 44650L, false, true, (char) 35805, (char) 57298,
        Double.longBitsToDouble(0x3fd71519d120afaaL), Double.longBitsToDouble(0x3fbb6cf485f2f720L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 4, 8, 4, "\uda04\udf33\udb4e\udd57\u405f\uda68\udc2d\ud8e0\udd88\udb15\udea9\uda5e\udd55", "\u61d4", "\u2a72\udb6e\ude95\udac1\udd4d\udabb\udd80\ud96b\udf6d\udaf1\udeb5\udaae\ude88\ud806\udda2\udada\udf5c",
        -5, 66969, -651414960, 7596555613257949516L, 86143L, false, true, (char) 44777, (char) 34085,
        Double.longBitsToDouble(0x3fe5168408bbbe63L), Double.longBitsToDouble(0x3f616438ff1dad00L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[B:[[103, -48, -48, -48, -48, 94, 118, -89]] |a0=[B:[[103, -48, -48, -48, -48, 94, 118, -89]]\012",
        Z.run(T, 1, 9, 7, 10, "\u0397\000\000\000\000\ud98e\udda6\udbd7\udef9\ud900\udd6e", "\uc1c6\u0083", "",
        14, 8023, 134, -1235847680L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd64fc0000001d2L), Double.longBitsToDouble(0x3e4c031400000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[B:[[5, -63, 1, -70, -68, -3, -38, -80]] |a0=[B:[[5, -63, 1, -70, -68, -3, -38, -80]]\0121=[B:[[66, 99, 69, 66, 117, 114, 122, 57, 50, 114, 65, 61]] |a0=[B:[[5, -63, 1, -70, -68, -3, -38, -80]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 10, 4, "\uda35\udcf1\uda31\udfea\udaec\udc2d\ud90a\udfe0\ud888\uddbf\ud9d8\udedf\udbec\udefd\ud890\udf28", "\u2859\u54e0", "\ud81c\uded9\udad0\udfcd\ud96b\udf6d",
        3, 63665, 1640503295, -3103229241143776541L, -96847L, true, true, (char) 52022, (char) 20553,
        Double.longBitsToDouble(0x3fe8f93f4e5b90e7L), Double.longBitsToDouble(0x3fecf62b8b0f1c6fL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[B:[[103]] |a0=[B:[[103]]\012",
        Z.run(T, 1, 9, 11, 11, "\u0397", "\u40cd\u7fb9", "\ud900\udd6e",
        -5, 66240, -653449196, -8897350884597799174L, -95634L, true, false, (char) 27597, (char) 58819,
        Double.longBitsToDouble(0x3fe7035d8fffb656L), Double.longBitsToDouble(0x3fd7261c80000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 1, 18, 13, 10, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\ud858\udfe2\udbd7\udef9\ud900\udd6e\udbc7\udd59\ud86e\udcdb\ud973\uddc8\ud882\udc3c", "\u87fa\u429d\u7a7a\u1801\uc791", "\ud9a6\udea0\udb3e\ude63\ud803\udd9a\ud9c8\uddc1\udb36\udd1a\ud83b\udfbe",
        1, 42172, 477053136, -5517143676181832132L, -56374L, false, true, (char) 31962, (char) 26006,
        Double.longBitsToDouble(0x3fd85f9e47a5fa9aL), Double.longBitsToDouble(0x3fedb5fec897e129L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.math.BigInteger:245 |a0=[B:[[-11, 57, -98, -117, -64, 101, -38, -80]]\012",
        Z.run(T, 1, 8, 16, 0, "\udb25\udc69\ud9ce\uddbb\udaf0\udc95\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\ud8cf\uddf4\uda63\udd0c",
        10, 26138, 1634116835, -7284668773450976360L, -9556L, false, true, (char) 16681, (char) 12369,
        Double.longBitsToDouble(0x3fefd19c0b0f1c6fL), Double.longBitsToDouble(0x3f466de2eef98c00L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]]\012",
        Z.run(T, 2, 1, 7, 10, "\uda6c\udcf1\udb4e\udd6d\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\ud9fb\uded4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        8, 26090, 1634116835, -7284668773450976360L, -9556L, false, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fecf62c0b0f1c6fL), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 17, 4, 10, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0", "\u57e3\ub138\uc163\u9aa2\u69ea", "\u9494\ud9d0\udfd4",
        33, 35374, 1806825565, -5307924404724295681L, -11139L, true, false, (char) 36479, (char) 3954,
        Double.longBitsToDouble(0x3fd4c696cac9f97aL), Double.longBitsToDouble(0x3fe8f93f4fb440e7L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[B:[[108, 99, 108, 117, 69, 66, 85, 83, 50, 114, 65, 61]] |a0=[B:[[-107, -55, 110, 16, 21, 18, -38, -80]]\012",
        Z.run(T, 1, 13, 13, 2, "\ud9c5\udcf9\ud89e\udd40\udb45\udc42\ud90a\udfe0\udb45\udcd6\udb7f\udd41\udbd7\udef9\udb5d\udd7a", "\u8f5e\uc82a", "\ud92d\udf62\ud3d1\ud923\uddc5\udae5\ude0f\ud826\udc23",
        25, 31722, 1794001541, -7312139422930898024L, -9556L, false, true, (char) 18877, (char) 49730,
        Double.longBitsToDouble(0x3fed7b4b030f1c6fL), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[B:[[33, -54, 74, -26, -74, -38, -80]] |a0=[B:[[33, -54, 74, 10, -26, -74, -38, -80]]\012",
        Z.run(T, 1, 9, 14, 10, "\udb51\uddfa\ud97a\udc3a\udb16\udfe6\ud90a\udfe0", "\ud371\ub1cf\u169f\u53ed\u1f2e\u9926\ud2f2\u80ba\u87fa\u1d82\u906f\u7164\uc797", "\ud9b5\udde5\udbca\ude63\ud91f\udea9\ud9c8\uddc2\udae3\udf20\uda27\uddc1",
        48, 74964, -48760315, -216664724473668034L, -36776L, true, true, (char) 12082, (char) 22790,
        Double.longBitsToDouble(0x3fd8b972d02c394cL), Double.longBitsToDouble(0x3fdaabb49fb707a6L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[B:[[-29, 63, -116, -11, 66, -38, -80]] |a0=[B:[[-29, 63, -116, 13, -11, 66, -38, -80]]\012",
        Z.run(T, 1, 9, 7, 10, "\udb13\ude6f\ud8bc\ude3d\ud825\ude72\ud90a\udfe0", "\u57e3\ub138\uc163\u9aa2", "\uda80\udc15\ud94d\udc7a\ud9d0\udfd4",
        13, 94401, 1806816713, -5307924404724295681L, -42346L, true, false, (char) 36479, (char) 3999,
        Double.longBitsToDouble(0x3fd4c696cac9f97aL), Double.longBitsToDouble(0x3fe8f93f4fae405eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[B:[[120, -112]] |a0=[B:[[17, -31, 101, -26, -84, 74, -26, 65]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 16, 12, "\uda41\udf11\ud895\ude16\udbdc\udd7a\uda16\udd71\ud888\uddbf\uda2d\udc49\ud9da\udf2b\udbcc\udcaa", "\u69ea\uc82a", "\ud9d1\udc54\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        10, 26138, 1634116835, -7284668773702634600L, -9556L, false, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fee06f3eb0f6443L), Double.longBitsToDouble(0x3fe1e59b7c657363L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 12, 10, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        10, 26138, 1634116835, -390502168876878952L, -9556L, true, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fecf62c0b0f1c6fL), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[B:[[-110, -68, -24, 20, -26, -33, -38, -6]] |a0=[B:[[-110, -68, -24, 20, -26, -33, -38, -6]]\012",
        Z.run(T, 1, 9, 7, 16, "\ud8c2\udfec\udb18\ude44\udb16\udf0f\ud90a\udf2a\ud888\uddbf\uda2d\udc49\ud81d\udefc\ud900\udd6e\ud9a1\udd17\ud86e\udcdb\udb73\udec8\ud882\udf3c\u2ad3\u9494\ud9ae\udca2\udac7\udfef\ud96b\udf6d\udaa7\udd28\udaa6\udc2a\uda78\ude89\uda27\ude37", "\uc86a\u37ce\u653a\u4cb1\ud0e5\uc612\uc951\u6533\ub078\u9696\u4e48\ua951\u5813\uc9e6\u199d\u1a16\u8df6\u97a1\ua46f\u0f7d", "\ud99f\uddb8\ud839\udf51\uda45\udd96\ud86e\udec2\udbca\udd8e\ud995\ude24\udaa7\udd02\ud87b\udfc9\udbe9\udfa2\ud83d\uddff\ud986\ude84\ud8ef\udc13\ud956\udd9b\ud969\udc7d\uda2f\ude98\udb3f\udcfe\udb79\udc61\ud86e\udf87\ud8c2\udc62\ud97c\udfc9\udb45\udebd\udbb8\udd6b\uda40\udcc5",
        40, 91125, 625488420, -8168535079151661977L, -94549L, true, false, (char) 6070, (char) 22836,
        Double.longBitsToDouble(0x3f9446e98b651840L), Double.longBitsToDouble(0x3fd4ef4d8a8b7c50L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[B:[[25, 39, 30, 39]] |a0=[B:[[25, 39, 30, 39]]\012",
        Z.run(T, 1, 9, 7, 10, "\uda49\udd57\udb4e\udd57", "\u1d97\u6bd5\u57e3\ub138\uc163\u9aa2\u69ea\uc82a\u9b77\u70c0\u87fa\u429d", "\udaae\ude88\ud88f\uddc2\ud8f4\udee8\ud9a6\udea0\udb3e\ude63",
        29, 99052, -54697652, 2875853357382620959L, -79422L, true, true, (char) 20907, (char) 44830,
        Double.longBitsToDouble(0x3feeeb6552ba2da2L), Double.longBitsToDouble(0x3fd7c577a979ccc6L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[B:[[60, -96, -25, -91, 17, 49, -106]] |a0=[B:[[60, -96, -25, 9, -91, 17, 49, -106]]\012",
        Z.run(T, 1, 9, 7, 2, "\udb6c\uddd0\ud817\udd39\ud8d5\udd41\ueb61\ud8c6\udda4\ud92a\udd66\ud9fb\udd8c\u6e7f\udbce\udc6e\uda16\udf39\ud9f7\uddbe\ud882\udf3c\u2ad3\udb1b\udfc4\u107a\ud823\udf01", "\u9b0e\u3add\u3267\u9853\u6087\u101d\u7708\u0b47\u2a59\u75f7\u6f7b\u17f1\ud04f\ub078\ud2d1\u0fde\u9c77\u0770\u5117\u21c1", "\udb5c\udeab\ud9ba\udf9f\ud91f\udf29\ud8e7\udd33\udacc\uddb3\ud8c4\udf62\ud84d\uddf2\ud80d\udd63\ud8ac\udd4a",
        14, 23241, 2124111254, -1648575282481221049L, -16951L, false, false, (char) 22652, (char) 9491,
        Double.longBitsToDouble(0x3fdb4b6c646b9292L), Double.longBitsToDouble(0x3fc522b57854e308L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 12, 6, 14, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u78c8\u2186", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\ud852\udd86\uda20\uddca",
        51, 77863, 1634018384, -7284668773450976360L, 141L, false, true, (char) 65287, (char) 17645,
        Double.longBitsToDouble(0x3fcd7e02eaee5490L), Double.longBitsToDouble(0x3fe1e59b7ff3d0d4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[5, -63]] |a0=[B:[[5, -63]]\012",
        Z.run(T, 1, 9, 7, 14, "\uda35\udcf1", "\u17cd", "\ud9be\udc2b\ud8f4\udc90\udbcd\udfcd\ud86e\udcdb\ud973\uddc8",
        -3, 91994, 896360814, -6388337319677110217L, 33027L, false, false, (char) 52821, (char) 32570,
        Double.longBitsToDouble(0x3fcc7a9de1658598L), Double.longBitsToDouble(0x3fecc4d73b8cac12L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-76, -40, 100, -124, -45, -114, -42, 61]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 7, 10, "\ud8e4\udf08\ud994\udfb4\udb03\udcbe\uda06\udd6d\ud888\udccd\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u6078\ub827", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        10, 26138, 1634116835, -7284668770548517992L, -9556L, false, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fecf62c0b0f1c6fL), Double.longBitsToDouble(0x3fb183dbc5ddf318L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[B:[[66, 99, 69, 101, 74, 43, 97, 50, 50, 114, 65, 61, 13, 10]] |a0=[B:[[5, -63, 30, 39, -26, -74, -38, -80]]\012",
        Z.run(T, 1, 15, 7, 15, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\udbee\uddb8\uda3c\udf24\ud809\udcbe\ud8f6\udc18", "\u18a9\u5a22\u817a\ub902\u87fa", "\udaf1\udeb5\udaae\ude88\uda82\uddfc\ud90f\udee8\ud904\udc50\udb3e\ude63\udb57\udea5\ud87c\udc37\ud97f\udd94\ud82a\udc85\ud89e\uded6\uda17\udc41\ud913\udf8a\udb73\udf91\ud8ed\udda5\udad9\udf89\udb51\udc90",
        -1, 37824, -658463942, -106018611812239842L, -19227L, true, false, (char) 6616, (char) 12263,
        Double.longBitsToDouble(0x3fdbd5b6f9d446d4L), Double.longBitsToDouble(0x3fefe066caf53343L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=[B:[[65, 81, 67, 55, 122, 118, 115]] |a0=[B:[[1, 0, -69, -50, -5]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 15, 11, 1, "\udb31\udd30\ue0eb\udafe\udf2b", "\u8841\u57e3", "\ud86e\udcdb\ud856\udd91\ud88c\udfa0\ud83e\uddc4\udb56\udef9\uda0a\udc89\ud837\udea3\ud96b\udfb1\udaf1\udeb5\udbaa\udef4\ud9f5\ude92\uda45\ude4c\ud9a6\udea0\udba5\udd4c\ud8a6\uddaf\ud958\udf2f\u7ef1\ud83b\udfbe\ud89e\udef2\uda46\udcc3\udb76\ude13\ud903\udcb8\udb01\udf67\ud9ee\udee0\udbb6\udf0c\ud84b\ude8c\ud803\ude50\udb95\udf80\ua374\ud9c4\ude4f\ud87e\uddb2\ud947\udfab\udba8\udc9e\udbb4\udf13\ud8a9\udc17\udb0b\udfd8\ud910\uddba\ud8a4\udc94",
        39, 42448, 96552173, 8706699450468902296L, 44861L, false, true, (char) 28851, (char) 61462,
        Double.longBitsToDouble(0x3febbd9db2a3c3b2L), Double.longBitsToDouble(0x3fecbd89543bbac0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 18, 16, "\udaa9\ude27", "\ubd29\u39c8\u0809\u57e3\ub138\u1b77", "\ud882\udf3c\u2ad3\u9494\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\uda37\udcab\ud88f\udd35\ud8f4\udee8\uda86\udf9e\udb3e\ude63\udb57\udea5\ud9c8\uddc2\udb36\udd1a\ud83b\udfbe\ud89e\udef2\uda17\udc41\udb9f\udeb7\ud99b\udc53\ud8fa\udd49\udb1d\udebe\udb81\udd19\ud9f6\udd1c\ud978\udda2\udbf5\udc2b\udb8f\udd38\uda20\ude28",
        53, 7717, -611986109, 4137718032506431613L, 64477L, true, false, (char) 27385, (char) 46512,
        Double.longBitsToDouble(0x3fe2e9403b3eed29L), Double.longBitsToDouble(0x3fd73e43785328fcL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=[B:[[19, 29, 30, 39]] |a0=[B:[[19, 29, 30, 39]]\0121=[B:[[]]\012",
        Z.run(T, 2, 9, 7, 10, "\uda43\udc4d\udb4e\udd57", "\u7fb9\u6bd5\u57e3\ub138\uc163\u9aa2\u69ea\uc82a\u9b77\u70c0\u87fa\u429d", "\udaae\ude88\ud88f\uddc2\ud8f4\udee8\ud9a6\udea0\udb3e\ude63",
        29, 99052, -54697652, 2875853354542815007L, -62243L, true, true, (char) 20907, (char) 44830,
        Double.longBitsToDouble(0x3fe0c364459726d3L), Double.longBitsToDouble(0x3fe424583366f0f2L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[B:[[74, 121]] |a0=[B:[[83, 110, -88, 107, -26, -74]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 2, 10, "\ud883\udc9e\udbd8\udd9b\udb16\udfe6", "\u1202\u6631\u9659\u472c\u9aa2\u69ea\u26b0\u9b12\u70c0\u8348", "\udaf1\udeb5\udaae\ude88\ud88f\uddc2\ud8f4\udee8\ud9a4\udde9\ud8c5\udd7f\udb15\udc23\ud9c8\uddc2\udb36\udd1a\ud83b\udfbe\ud89e\udef2\uda17\udc41\udb83\uddc8\udb89\udd20\ud86c\ude5e\udb3c\udfda\u77bf",
        17, 95130, 612264846, -3329761849453733666L, -11486L, true, true, (char) 40174, (char) 18904,
        Double.longBitsToDouble(0x3fa97852e27fe8d0L), Double.longBitsToDouble(0x3fed84801ccb9d36L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[B:[[48, 78, 68, 109, 51, 57, 113, 119, 87, 73, 56, 61]] |a0=[B:[[-48, -48, -26, -33, -38, -80, 88, -113]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 11, 10, "\000\000\udb16\udf0f\ud90a\udfe0\ud888\uddbf\ud9ad\udc49\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\000\uda29\udfb4\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        10, 26024, 1634116835, -7284668773450976360L, -34464L, false, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fecf62c0b0f1c6fL), Double.longBitsToDouble(0x3fae59b780000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[B:[[5, -51, 30, 39, -26, -74, -38, -80]] |a0=[B:[[5, -51, 30, 39, -26, -74, -38, -80]]\012",
        Z.run(T, 1, 9, 7, 10, "\uda35\udcfd\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\ud9fb\udc50\udbd7\udef9\ud900\udd6e\udbcd\udfcd\ud86e\udcdb\ud973\uddc8\ud882\udf3c\u2ad3\u9494\ud9d0\udfd4\udac7\udfef\ud94c\ude75\udaf1\udeb5\udaae\ude88\ud88f\uddc2\ud8f4\udee8\ud9a6\udea0\udb3e\ude63\ud987\udd5c\ud9c8\uddc2\udb36\udd1a\ud83b\udfbe\ud89e\udef2\uda17\udc41\u194b\udb83\ude8b\ud86c\ude5e\ud89b\udf69\udba6\udf57\udbdc\uddd4\ud87f\udc5a\ud954\udf59\ud938\udd46\ud815\udf47\ud8c3\udfed\udb27\udcd2\ud838\udfac\ua775\uda9c\udc57", "\u4dee\u106e", "\ud823\udd83\uda9a\udf48\udbb0\udfc3\ud934\udd53\udbbc\udf50\ud812\udf0f\ud893\udc2f\ud93c\udc93\uda23\udfb1\uda05\udf06\udaca\udc10\uda7c\ude33\ud934\udf4c\ud9e0\udcbd\uda5e\udf90\uda03\udc86\udaf2\udff5\ud844\udd17\ud944\udd3e\uda7b\ude22\udb68\udf1e",
        35, 73303, 24394212, 5446352330176522261L, 11984L, false, true, (char) 55561, (char) 15969,
        Double.longBitsToDouble(0x3fe36fea56b309edL), Double.longBitsToDouble(0x3feb0f0bef77e9aaL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[50, -27, 79, -72, 32, 116, 122, 89]]\012",
        Z.run(T, 1, 5, 16, 10, "\ud962\udf15\udb7f\udfe8\udb50\udda4\ud9aa\ude89\ud888\uddbf\uda2d\udc49\ud933\udee7\ud837\udcc1\ud812\udd6a\udb06\ude4a\udbf4\udf09\ud882\udf02\u2ad3\udb9f\udfce\udadf\udfa7\ud890\udea1", "\u7d13\u2be3\ub4e6\u23bf\u9945\ua81f\ub07e\uad6e\u3843\u2c0c\u8a60\uc951\ud04f\u5eda\u6ab3\uc2ad\u23ae\u4f3b\u46ca\u5dee\ud782\ua74f\ud31e\u0d4d\u1648\u4042\u8127\uaaa4\u7a82\uad68\ud28c\u52e0\u81df\ud3e7\u8fb3\u40de\u7769\u2a08\ud4b2\u9f29\ua6b8\u66cc", "\ud8ec\udd18\udada\ude8f\udb98\udd72\ud9e9\udda3\ud934\udc19\ud8c7\udc50\ud972\udf7b\ud9cc\ude03\udb47\udc69\ud99d\udc7b\ud919\udce6\ud9d7\udf22\udae3\udf75\ud91a\udd09",
        54, 61543, -337028180, -4507272537547709914L, -30867L, false, true, (char) 5280, (char) 13327,
        Double.longBitsToDouble(0x3fd2200dd985f568L), Double.longBitsToDouble(0x3feda4ad3b3aeb5aL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=[B:[[66, 99, 71, 49, 48, 115, 56, 117, 50, 114, 65, 61]] |a0=[B:[[5, -63, -75, -46, -49, 46, -38, -80]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[66, 99, 71, 49, 48, 115, 56, 117, 50, 114, 65, 61, 13, 10]] |a0=[B:[[5, -63, -75, -46, -49, 46, -38, -80]]\012",
        Z.run(T, 2, 10, 14, 2, "\uda35\udcf1\udbe5\udc02\udaff\udf5e\ud90a\udfe0\ud888\uddbf\uda2d\udc49\ud924\udc1f\ud900\ude13", "\u69ea\uc82a", "\ud9d0\udfd4\u1ff6\ud96b\udf6d\udaf1\udeb5",
        30, 70994, -722920656, 7018478362471915468L, 91132L, true, true, (char) 39176, (char) 30058,
        Double.longBitsToDouble(0x3fe878e37e3cb36fL), Double.longBitsToDouble(0x3fc777cc6fb78df4L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[5, -63]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 0, 11, "\uda35\udcf1", "\u40cd\u5181", "\ud900\udd6e",
        27, 24341, -653449196, -8897350884597799174L, -99986L, false, false, (char) 27597, (char) 58819,
        Double.longBitsToDouble(0x3fe7035d8fffb656L), Double.longBitsToDouble(0x3fd7261c89c7a9deL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=[B:[[-18, -75, -69, 58, 43, -38, -80]] |a0=[B:[[32, -18, -75, -69, 58, 43, -38, -80]]\012",
        Z.run(T, 1, 9, 12, 10, "\ud850\udf1e\ud9e5\udeeb\uda6a\udf5b\ud90a\udfe0\ud888\uddbf\uda2d\udc49\ud8e5\udc1e\udabc\ude60", "\u1282\uc82a\u9b77\u8f90\u1abe\u54be\u7a7a\ubba5\ud142\u4b61\uba4d\u9853\u839c\ua81f\u6196\ua849\u5b26\u2c0c\u9b96\uc951\u6347", "\ud919\ude38\udb57\udf9b\ud90b\udf2e\ud951\udd34",
        10, 39053, 890420778, -1026076508544972921L, 39802L, false, true, (char) 35237, (char) 19616,
        Double.longBitsToDouble(0x3fd725f35b17b14cL), Double.longBitsToDouble(0x3fe76976f46780fbL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[5, -63, 30, 39, -65, -61, 95, 106]]\012",
        Z.run(T, 1, 5, 7, 10, "\uda35\udcf1\udb4e\udd57\udbef\udff3\udb8f\udc9a\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\ud9d0\udfd4\udb09\udd49\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        10, 26138, 1634116835, -7284668773450976360L, -9556L, false, false, (char) 25329, (char) 12443,
        Double.longBitsToDouble(0x3fecf62c0b0f1c6fL), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=[B:[[98, 67, 52, 72, 116, 82, 112, 106, 72, 84, 111, 61]] |a0=[B:[[108, 46, 7, -75, 26, 99, 29, 58]]\012",
        Z.run(T, 1, 13, 3, 11, "\udb9c\ude5e\ud937\udde5\udb4a\ude93\uc64d\udb6a\udca6\ud998\udd8a\ud99a\udc20\ud91b\udfe7\udbcd\udfcd\uda92\uded4\udb17\udf43\ud831\udff3\ud959\udf29\udae4\udfbf\ud967\udc42\udb50\udd57\ud829\ude8f\uda35\udef1\ud872\ude8a\ud94f\udd61", "\u5b61\u87af\ud374\u94b2", "\udb2e\udec3\uda25\udd3c\ud81c\udd65\udafb\udec6\ud868\udeee\ud911\udf1b\udbbe\uddcf\ud8d6\ude5f\uda9f\udf8c\uda84\udfe4\udb3d\udc0d\udbcc\udc6c\udbea\udded\udb0d\udd74\uba1e\udbe9\udec3",
        58, 5005, 42068191, -7457085663949841657L, 43743L, false, true, (char) 30352, (char) 14095,
        Double.longBitsToDouble(0x3fe30b221b99e0f7L), Double.longBitsToDouble(0x3fe18e864b5ed835L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 17, 3, 18, "\udb7c\udde3\ud937\ude07\udbbd\udf02\uda91\udd79\udb02\uddd8\uda2d\udc49\udbd7\ude46\ud900\udd95", "\u9358\uc82a", "\ud967\udc42\udac8\udc93\ud9bb\udc2f\udaf1\udf3c\ud872\ude8a",
        57, 24869, 1415515276, 3963192053207331768L, -9556L, false, true, (char) 56266, (char) 14122,
        Double.longBitsToDouble(0x3feca828bde91c13L), Double.longBitsToDouble(0x3fe1e59b08bbda63L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=[B:[[49, 74, 66, 110, 89, 119, 61, 61]] |a0=[B:[[-44, -112, 103, 99]]\012",
        Z.run(T, 1, 13, 1, 2, "\uda04\udec0\uda97\udf93", "\001\u9c6d\uc649\u30c1\u6a7f\u5e72\ub301\u86ca", "\ud967\udc42\udac8\udc93\ud99d\udf2f\udaf1\udf3c\ud859\ude6f",
        57, 59341, 1869902963, 3963192055584070948L, 71700L, false, true, (char) 56266, (char) 14122,
        Double.longBitsToDouble(0x3feca828ba50712bL), Double.longBitsToDouble(0x3fdaa8a787bed2b6L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=[B:[[118, 98, 113, 82, 97, 49, 97, 66, 89, 88, 81, 61]] |a0=[B:[[-67, -70, -111, 107, 86, -127, 97, 116]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 3, 18, "\udbed\udeea\ud9c1\udc9b\ud986\udfb1\uda91\udda4\udadb\udd23\ud821\udc44\uda02\udfcc\ud8f2\udc6f", "\u9358\uc82a\u9b77\u70c0\uc87f\u4341\u1577\u1888", "\ud96e\udda8\udb76\udd84\udb02\udd6a\udb57\udec5\ud9c8\uddc2\udb36\udd1a\ud82a\udcc1\ud811\udefb\udb01\udefa",
        52, 19105, 1249064521, -3293029591822248302L, 44919L, true, true, (char) 47038, (char) 11254,
        Double.longBitsToDouble(0x3fd4ca87f5e14c18L), Double.longBitsToDouble(0x3feeef98c271d466L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-81, -96, 7, -41, -115, -46, 13, 62]]\0121=java.lang.Boolean:false |a0=[B:[[-81, -96, 7, -41, -115, -46, 13, 62]]\012",
        Z.run(T, 2, 6, 5, 16, "\udadf\udfd0\ud937\ude07\udbbd\udf02\ud93d\udd6e\udb02\ude17\uda2d\udc49\ud9ad\udc91\ud900\udd95", "\u821f\uc82a\u9b77\u70c0\u1906\u304b\u07c4", "\ud987\udd5d\ud96e\udd28\udb76\udd84\udb02\udd6a\udb57\udec5\ud9c8\uddc2\ud963\udfc8\ud823\udec2\ud811\udefb",
        -2, 27381, -1285452311, -3585602819484367958L, 3894L, true, false, (char) 6886, (char) 48702,
        Double.longBitsToDouble(0x3fdd65719906afccL), Double.longBitsToDouble(0x3fe53169e904d221L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=[B:[[84, 76, 77, 61]] |a0=[B:[[76, -77]]\012",
        Z.run(T, 1, 13, 3, 6, "\udb7c\udde3", "\u0153", "\udbd7\ude46\ud900\udd95\udbcd\udfcd\uda92\uded4",
        35, 34067, -1182112006, 3849840379821560401L, -78312L, false, false, (char) 58001, (char) 55150,
        Double.longBitsToDouble(0x3fb752997f8a0cb0L), Double.longBitsToDouble(0x3fe16e033bb83700L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 13, 3, 18, "", "\u81b8\u0153\u8f6b", "\ud900\udd95",
        27, 72494, -653438590, -8897350884597799174L, -95311L, true, false, (char) 42638, (char) 2107,
        Double.longBitsToDouble(0x3fe7035d88ffb66fL), Double.longBitsToDouble(0x3fb7400024628ad8L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-84, 111, -35, 120, -115, 43, -40]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 12, 18, "\udbdc\udf9f\uda0d\udfa8\udbbd\udf5b\uc408", "\u2b82", "\udaa8\udcd4\ud97d\udf36\ud8e6\udc43\u9c18\uda18\udf3d\ud967\udc99\ud97a\udd0c\ud9bb\udc17\udaf1\udf3c\ud9d7\udc21\ud88a\udc6d\ud8f3\uded3\udaa5\udd43\ud941\udfac\uda87\udebf\ud9ad\udd14\udbba\uded4\ud896\udc0a\uda28\udeab",
        32, 64629, -1283905355, 3244653281116003259L, 30641L, true, true, (char) 62221, (char) 17892,
        Double.longBitsToDouble(0x3fcbbccc6e5b99e8L), Double.longBitsToDouble(0x3fa58a606b41a140L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=[B:[[45, -10]] |a0=[B:[[76, -77, -13, -41, 102, 97, 8, -46]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[45, -10]] |a0=[B:[[76, -77, -13, -41, 102, 97, 8, -46]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 0, 18, "\udb7c\udde3\ud923\udc07\u8796\uda91\udd38\udb02\uddd8\uda2d\udc49\udbd1\uddc2\ud900\udd95", "\u6ca5\u47f8", "\udac0\udf1f\uc0eb\ud9bb\udc2f\uda9f\udeb4",
        47, 54654, 238286841, 6079591818331166253L, -19149L, true, false, (char) 14122, (char) 22700,
        Double.longBitsToDouble(0x3fde91c13c7966c2L), Double.longBitsToDouble(0x3fc19b4c7df372e0L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 17, 18, "\udb87\udca3\ud937\ude07\udbbd\udf02\uda91\udd79\udb02\uddd8\uda2d\udc49\udbd7\ude46\ud900\udd95", "\u9358\uc82a", "\ud967\udc42\udac8\udc93\ud9bb\udc2f\udaf1\udf3c\ud872\ude8a",
        57, 24869, 1415515276, 3963192053207331768L, -9556L, false, true, (char) 56266, (char) 14122,
        Double.longBitsToDouble(0x3feca828bde91c13L), Double.longBitsToDouble(0x3fe1e59b08bbda63L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 3, 18, "\udb7c\udde3\ud937\ude07\udbbd\udf02\uda91\udd79\udb02\uddd8\uda2d\udc49\udbd7\ude46\ud900\udd95", "\u9358\uc82a", "\ud967\udc42\udac8\udc93\ud9bb\udc2f\udaf1\udf3c\ud872\ude8a",
        57, 24869, 1415515276, 3963192053207331768L, -9556L, false, true, (char) 56266, (char) 14122,
        Double.longBitsToDouble(0x3feca828bde91c13L), Double.longBitsToDouble(0x3fe1e59b08bbda63L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 3, 18, "\udb7c\udde3\ud937\ude07\udbbd\udf02\uda91\udd79\udb02\uddd8\uda2d\udc49\udbd7\ude46\ud900\udd95", "\uc1c6\uc82a", "\ud967\udc42\udac8\udc93\ud9bb\udc2f\udaf1\udf3c\ud872\ude8a",
        57, 24869, 1415515276, 3963192053207331768L, -9556L, false, true, (char) 56266, (char) 14122,
        Double.longBitsToDouble(0x3feca828bde91c13L), Double.longBitsToDouble(0x3fe1e59b08bbda63L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=[B:[[56, 48, 43, 84, 103, 53, 48, 49, 81, 86, 89, 61]] |a0=[B:[[-13, 79, -109, -125, -99, 53, 65, 86]]\012",
        Z.run(T, 1, 13, 3, 13, "\ud923\udd7f\ud8c3\udeb3\ud9cd\udc65\ud871\ude86\udb11\udfca\uda2f\udfd9\udbd7\ude84", "\ud40c", "\ud939\udcfd\u9494\ud967\udc42\udac8\udc93\ud9bb\udc2f\ud826\udef7\ud872\ude8a\ud94f\udd61\ud96e\udd28\udb76\udd84\u244e\uda90\udd3a\ud9c4\udcce\udb36\udd1a\ud813\udd9d\ud811\udefb\udb2e\udec3\uda25\udd3c\ud81c\udd65\uda39\udc04\ud9b0\udcb4\udb9c\uddc7\ud813\ude5c\udac1\udd09\ud9b6\udcf5\ud963\udf5d\udb1a\udd1b\ud9a9\udd36\ud965\udf4c\u995f\udac9\udf08\uda6e\ude6c\udab8\udfb2\ud8d3\ude57\udaa2\udf14\ud8d2\udda3\udb77\udf25\uda1d\udefd\udb2c\udd31\udb4a\udd3a\udb65\udd85\ud899\udfde\ud8fa\udcf7\ud971\udffa\ud820\udc51\udada\udcbd\u02c1\udb30\ude9d\udb50\udee0\uda7a\udcc4\ud990\udc82\ud9e6\ude50\ud963\udd2e\udb70\udeb6\ud9d5\ude23\ud992\ude58\ud826\udc7e\ud886\uddb2\uda03\udd1c\udaeb\udc78\ud95a\udfb4\ud832\udd27\uda98\uddda\ud857\udcdc\udbd5\ude89\udabc\udc4e\u8fd9\uad4a\ud9bf\udcd5\uda4b\udfaa",
        55, 92027, 443519639, 3114777948715038180L, -16807L, false, true, (char) 43783, (char) 43321,
        Double.longBitsToDouble(0x3fee2a460fa75ea6L), Double.longBitsToDouble(0x3fd1d46874f89c98L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=[B:[[90, 76, 77, 61]] |a0=[B:[[100, -77]]\012",
        Z.run(T, 1, 13, 16, 5, "\udb94\udfe3", "\u0153", "\udbd7\ude46",
        27, 56386, 256542805, -2806497376065928573L, 71666L, true, true, (char) 61971, (char) 42638,
        Double.longBitsToDouble(0x3fcc81eafb81aec4L), Double.longBitsToDouble(0x3fe9a9fb7cf5220aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=[B:[[84, 72, 77, 72, 49, 52, 51, 83]] |a0=[B:[[76, 115, 7, -41, -115, -46]]\012",
        Z.run(T, 1, 13, 3, 4, "\udb7c\udda3\ud937\ude07\udbbd\udf02", "\u6bd5\u5730\ub15f\uc163\ud40c\u9358\uc82a\u9b77\u70c0\uc87f\u4341\u1577\u1888\u77af\u592b\u94c9\u488b\uaf5c\ua83f\ub07e\uad6e\uafd9", "\uda25\udd3c\ud81c\udd65",
        31, 75779, -123748019, 121877273878287671L, 54864L, false, false, (char) 62350, (char) 40184,
        Double.longBitsToDouble(0x3fa7b34f25cd2870L), Double.longBitsToDouble(0x3fef17855a2a8f27L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=[B:[[84, 76, 77, 72, 49, 52, 51, 83, 89, 85, 107, 61, 13, 10]] |a0=[B:[[76, -77, 7, -41, -115, -46, 97, 73]]\0121=[B:[[]]\012",
        Z.run(T, 2, 15, 7, 17, "\udb7c\udde3\ud937\ude07\udbbd\udf02\uda91\udd79\udb02\uddd8\uda2d\udc49\ud896\ude85\ud900\udd95", "\u9358", "\u9494\ud9d5\udc01",
        0, 65536, 1806825700, -8422163547443325464L, 99820L, true, false, (char) 10936, (char) 50749,
        Double.longBitsToDouble(0x3fd4c63ad2c9f97aL), Double.longBitsToDouble(0x3fef42f15954fcccL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=[B:[[48, 65, 61, 61]] |a0=[B:[[-48]]\012",
        Z.run(T, 1, 13, 3, 18, "\000", "\u0153", "\udbd7\ude46\ud900\udd95\udbcd\udfcd\uda92\uded4",
        35, 34067, -1182112006, 3849840379821555712L, -78312L, false, false, (char) 58001, (char) 55150,
        Double.longBitsToDouble(0x3fb7529964628ad8L), Double.longBitsToDouble(0x3fe16aa2fbb83700L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[32, -84, 49, -100, 12, -111, 126, 52]]\012",
        Z.run(T, 1, 5, 17, 0, "\ud850\udddc\ud961\udecc\uda3c\udcc1\ud8ae\udf64\udaaa\udcab\uda2d\udc20\udb7b\ude38\ud99d\udd37\udb37\udded\ud3c6\ud97d\udf36\ud9d9\udd5d\u2ad3", "\u4341\u1577", "\ud94f\udd61\udb6d\udc99\udb76\udd84\udb02\udd6a\udb65\udecc\ud85c\uddac\udb36\udd24\ud813\udd56\ud811\udf31\ud855\udd66\udba9\udcef\ud81c\udd65\udb9d\udef6\udb72\udedc\ud919\udde9\ud85f\udf83\uda55\udfe5\uda18\udd15\udbfc\udf68\udacf\udd2e\udad3\udde4\ud8b9\udc39\uda34\udfa5\ue336\udab5\uddb8",
        27, 77738, 2106299039, -5835065556439019889L, 95857L, true, true, (char) 39242, (char) 53935,
        Double.longBitsToDouble(0x3fbda4c61a357f60L), Double.longBitsToDouble(0x3feb5cfe90068ee0L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=[B:[[-21, 83, -65, -35, -26, 34, 45, -93]] |a0=[B:[[-21, 83, -65, -35, -26, 34, 45, -93]]\012",
        Z.run(T, 1, 9, 7, 10, "\udb1b\udd83\udaef\udf0d\ud916\ude52\ud85d\udfd3\ud888\uddbf\ud87f\udce8\ud8d0\ude70\ud900\udd6e\udbcd\udfcd\ud86e\udcdb\ud973\uddc8", "\ua6ea\ud182", "\uda03\udd37\ud94c\udfc8\ud88f\uddc2\ud845\udf90\ud9a6\udea0\udb3e\ude63\udb57\udea5\uc154\ud829\udf0b\ud83b\udfbe\ud89e\udef2\uda17\udc41\ud954\udd96\udb94\udcc0\ud86c\ude5e\udb6e\udc13\ud94f\udc21\ud937\udc6b\ud9cf\ude5d\ud9ea\udd69\ud833\udf75\uda43\udf8c\ud8fd\udd2e\udac1\udf2b\uda8c\ude8d\ud8d0\udead\ud935\udfc1\ud857\udd9a\u163d\ud83f\udc38\udb39\ude65\ud838\ude60\udad1\udfd9",
        32, 75561, -519493756, -895121706375399011L, 47167L, false, false, (char) 51076, (char) 38436,
        Double.longBitsToDouble(0x3fe2ecd0e20c727aL), Double.longBitsToDouble(0x3fd8eeabf6cebe46L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-43, 58, 41, 56, -18, 42, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[-43, 58, 41, 56, -18, 42, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 3, 9, "\ud805\udc6a\uda59\udc68\udb1e\udc5a\udb33\udff4\ud888\udd4b\uda4b\udc78\udb8a\ude32\udbc6\udf4f\ud937\udd41\ud840\udf3f\ud973\uddc8", "\uacc0\u7416", "\udb1e\udf86",
        8, 86694, -722526862, 5162949131827994690L, 67364L, true, false, (char) 17643, (char) 29983,
        Double.longBitsToDouble(0x3fe878e7a63cb36fL), Double.longBitsToDouble(0x3fc777cc74c61b28L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 1, 9, "\u815d\uda59\udc68\udb1e\udc5a\udb71\uddf3\udbc8\udd03\uda2d\udc00\udbd7\udef9\ud814\udc86\udb72\udd10\ud86e\udce2\ud973\uddc8", "\uacc0\u87fa", "\udb04\udf8b\ud992\udd1d\ud806\udd11",
        39, 63698, 1813751121, 6225679145047717475L, 26900L, true, false, (char) 18435, (char) 20907,
        Double.longBitsToDouble(0x3fc777cc6b8a7afcL), Double.longBitsToDouble(0x3fedfed40d59e37bL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-43, 58, 41, 56, 35, -35, -14, -40]]\0121=[B:[[49, 84, 111, 112, 79, 67, 80, 100, 56, 116, 103, 61, 13, 10]] |a0=[B:[[-43, 58, 41, 56, 35, -35, -14, -40]]\012",
        Z.run(T, 2, 8, 15, 9, "\ud805\udc6a\uda59\udc68\u9853\uda0d\udd22\ud908\ude9f\uda2d\udc49\ud8aa\udc5a\ud8f0\udd37\udbce\udc45\ud86e\udcdb\ud973\uddc8", "\uc54a\u768d", "\udb04\udf8b\ud992\udd1d\ud8a9\udce1",
        3, 63698, -2080074173, -4557289004111726920L, -5090L, true, false, (char) 47595, (char) 30104,
        Double.longBitsToDouble(0x3fe718e7a6d9fdefL), Double.longBitsToDouble(0x3fc777d314c61b28L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 17, 0, "\ud919\udfa0\ud8cb\udd45\uda2e\udf65\udbfe\udc7b\ud8d2\uddf6\uda2d\udc49\udbd7\udef9\ud8f0\udc6e\ud956\udcb2\ud86e\udcdb\ud973\uddc8", "\uacc0\u87a3", "\ud87c\uddb5\ud992\udd4e\ud8a9\udce1\ud81e\ude1c\udba9\udcde\ud96b\udefd\ud85a\udd26\ud93f\udf89\udb30\udca5\u5ab9\uda82\udd9c\ud90b\udc42",
        5, 57887, -1100767684, -8734018190621790927L, -27098L, false, true, (char) 47938, (char) 19688,
        Double.longBitsToDouble(0x3fdef594ca6b9340L), Double.longBitsToDouble(0x3fbfd816ac7ba6e8L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-43, 58, 41, 56, -18, 42, 3, -60]]\0121=[B:[[]] |a0=[B:[[-43, 58, 41, 56, -18, 42, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 6, 16, 9, "\ud805\udc6a\uda59\udc68\udb1e\udc5a\udb33\udff4\ud888\udd4b\u334e\udb11\udf54\udb61\udc0c\ud9f0\udfd7\ud927\udeea\ud973\uddc8\ud882\udf3c\u2ad3\ud094\ud9d0\udfd4", "\u8acc\u030f\u9302", "\uda1a\udd8b\uda54\udf2e\ud93f\udf89",
        17, 54100, 1429722263, -4214824219383124066L, -74972L, true, false, (char) 46075, (char) 57862,
        Double.longBitsToDouble(0x3fc36c5ad862bb38L), Double.longBitsToDouble(0x3feadc4fa5ca8927L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=[B:[[-3]] |a0=[B:[[-43, 58, 95, 39, 125, 3, -60, 88]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 1, 9, "\ud805\udc6a\u578f\ud857\udcad\udb33\udff4\ud888\udd4b\uda2d\udc49\udbd7\udef9\ud8f0\udc6e\udbce\udc45\ud86e\udcdb\uda29\udd62", "\ua413\u1753\u277f\u1ea6\u8acc\u7c3e\u3d98", "\uda1a\udd8b\uda54\udf29\ud992\udff5",
        28, 54100, 1429722263, -4214824219383108962L, -44252L, true, false, (char) 46075, (char) 6384,
        Double.longBitsToDouble(0x3fe65a23642c3343L), Double.longBitsToDouble(0x3fe334367bee95acL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=[B:[[63]] |a0=[B:[[80, -105, 41, 56, -18, 42, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[63]] |a0=[B:[[80, -105, 41, 56, -18, 42, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud980\udec7\uda59\udc68\udb1e\udc5a\udb33\udff4\ud888\udd4b\uda2d\udc49\udbd7\udef9\ud8f0\udc6e\udbce\udc45\ud86e\udcdb\ud973\uddc8", "\uacc0\u87fa", "\udb04\udf8b\000\000",
        -5, 63472, -2080055078, -8088111113396259144L, 67364L, true, false, (char) 61183, (char) 29983,
        Double.longBitsToDouble(0x3fe878e0063cb36fL), Double.longBitsToDouble(0x3f47cc74c4000000L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=[B:[[-16]] |a0=[B:[[-43, 58, 41, 56, -18, 80, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[-43, 58, 41, 56, -18, 80, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 12, 14, "\ud805\udc6a\uda59\udc68\udb1e\udc80\udb33\udff4\ud888\udd4b\uda2d\udc49\udbd7\udef9\ud8f0\udc6e\udbce\udc45\ud86e\udcdb\ud973\ude22", "\uacc0\u87fa", "\udb04\udf8b\ud992\udd1d\udadd\udd7b",
        10, 6198, -2080055186, -8088111113396259144L, 67364L, true, false, (char) 17643, (char) 29983,
        Double.longBitsToDouble(0x3fe878e7a63cb36fL), Double.longBitsToDouble(0x3fc777cc74c61b28L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=[B:[[-73, -49, -105]] |a0=[B:[[116, 41, 56, 43, 3, -60, 88, 27]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[116, 41, 56, 43, 3, -60, 88, 27]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 12, 9, "\u19a4\uda59\udc68\u7a5b\udb33\udff4\ud888\udd4b\uda2d\udc49\udbd7\udef9\ud8f0\udc6e\udbce\udc45\ud86e\udcdb\ud969\uddb4", "\uac52\000", "\udb04\udf8b\ud992\udd1d\ud8a9\udce1",
        5, 35690, 218, -8088111989569587528L, 67364L, true, false, (char) 17643, (char) 29983,
        Double.longBitsToDouble(0x3fe878e7a03cb36fL), Double.longBitsToDouble(0x3e44c61b28000000L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=[B:[[49, 84, 111, 112, 79, 79, 52, 113, 65, 56, 81, 61, 13, 10]] |a0=[B:[[-43, 58, 41, 56, -18, 42, 3, -60]]\0121=[B:[[49, 84, 111, 112, 79, 79, 52, 113, 65, 56, 81, 61]] |a0=[B:[[-43, 58, 41, 56, -18, 42, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 14, 10, 9, "\ud805\udc6a\uda59\udc68\udb1e\udc5a\udb33\udff4\ud888\udd4b\uda2d\udc49\udbd7\udef9\uda76\udfe1\udbce\udc45\ud86e\udcdb\ud973\uddc8", "\uacc0\u87fa", "\uda1e\udd45\ud9d5\udd84\ud8a9\udce1",
        -2, 63665, -2080055078, -6229543934373817520L, 67364L, true, false, (char) 17643, (char) 29983,
        Double.longBitsToDouble(0x3fe878e7a63cb36fL), Double.longBitsToDouble(0x3fc777cc74c61b28L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[11, 5, -89, 42]]\0121=[B:[[]] |a0=[B:[[11, 5, -89, 42]]\012",
        Z.run(T, 2, 8, 6, 2, "\ud83b\udd35\udad7\udd5a", "\u39fe\u70ca\u8046\u378e\uc6ed\ua9f2\u0111", "\ud9e9\udda8\ud9d0\udfd4\ud8a0\ude9c\udbce\udcfc\udb04\udf8b\ud992\udd1d",
        8, 78680, 1201257698, -8933768535285349940L, 77961L, false, false, (char) 63126, (char) 25791,
        Double.longBitsToDouble(0x3fe2b3254f3e01c5L), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 15, 14, 9, "\ud939\udfbe\u900d\udb1e\udc2f\udb33\udff4\ud888\udd4b\uda2d\udc72\ufb4b\uda5a\ude06\udbe0\udf23\ud86e\udcdb\ud84e\udccc", "\uacc0\u87fa\u277f\u1ea6\u8acc\u030f\u27fe\u248f\ub134\u32a8\000\u4e49\u0306\u4c0eE\ua67f\uca17\uc3e9\ub078\u63e2\u31ce", "\uda9e\ude6f\ud838\udc29\ud877\udce2\ud83a\ude76\ud941\uddd5\udb8b\udf8b\ud8c5\udd10\udbcb\udf15\ud857\udf66\udab4\ude63\udb43\udeb1\ud942\udec0\ud9b8\uddfa",
        10, 45391, 2068505523, -6241767629001090878L, -81193L, true, false, (char) 150, (char) 25008,
        Double.longBitsToDouble(0x3fd589ccc55a4800L), Double.longBitsToDouble(0x3fe0e973e7615767L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 1, 9, "", "\ua21d", "\uda2d\udc49\udbd7\udef9\ud8f0\udc6e\udbce\udc45\ud86e\udcdb\ud973\uddc8\ud882\udf3c\u2ad3\ud094\ud9d0\udfd4\ud8a0\ude9c\udbce\udcfc\udb04\udf8b\ud992\udd1d\ud8a9\udce1\ud825\udd80",
        1, 38922, -1883160116, -8781888740781111081L, 96608L, false, true, (char) 29983, (char) 18435,
        Double.longBitsToDouble(0x3f466de2eef98c00L), Double.longBitsToDouble(0x3fd3186ca9cc9d3cL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.math.BigInteger:0 |a0=[B:[[]]\012",
        Z.run(T, 2, 0, 8, 9, "", "\ua21d", "\000",
        -5, 20872, 138, 1137510667374110740L, 4710L, false, true, (char) 18043, (char) 22671,
        Double.longBitsToDouble(0x3fdc3a0e5df66d7eL), Double.longBitsToDouble(0x3fd334d78e3d7562L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 1, 9, "\ufac6", "", "",
        22, 93034, 1546076928, -4035124617847160851L, 56306L, false, true, (char) 88, (char) 25856,
        Double.longBitsToDouble(0x3f2b000004d78000L), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-120, 42, 26]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 1, 17, "\u81b8\udb5a\udf4a", "\u3ad4\u6bd5\u57e3\u7038\u0f6a\u9aa2\u69ea\u59a7\u9b19\uacc0", "\udbce\udcfc\udb04\udf8b\ud992\udd1d\ud8a9\udce1\ud8f4\udee8\ud8a2\udd1a\uda1a\udd8b\uda54\udf2e\ud93f\udf89\udb20\udc9d\u5ab9\uda82\udd9c\uda17\udc41\udb6e\udd9f\udb83\udc42\ud86c\ude5e\ud958\udd96\udb60\udfbb",
        22, 5438, -1007143397, -5827673751930794173L, 72845L, false, true, (char) 44779, (char) 20558,
        Double.longBitsToDouble(0x3feeee1309f6fd95L), Double.longBitsToDouble(0x3f8bad055e556140L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-48]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 9, 11, "\000", "", "\uda2d\udc49",
        24, 85568, -929735918, 1137510667374110740L, -95634L, true, false, (char) 27597, (char) 58819,
        Double.longBitsToDouble(0x3fe7035d8fffb656L), Double.longBitsToDouble(0x3fd7261c89c7a9deL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]]\012",
        Z.run(T, 2, 7, 7, 10, "\udae2\ude87\ud94a\ude4c\udb08\udc46\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbb7\ude68\ud900\udd6e", "\u6cfc\u356a\u9b20\u611b\u2c8c\u4274\u1e64\ua080", "\ud818\udee1\ud9a6\udea0\udb3e\ude63\ud877\udcad\ud9c8\uddc2\udb36\udd1a\ud83b\udfbe\ud854\udd4d\udb1c\ude99",
        18, 57887, -1100767684, -4402285426667109815L, 24173L, true, false, (char) 16712, (char) 61791,
        Double.longBitsToDouble(0x3fd9f30f86ef04ceL), Double.longBitsToDouble(0x3fdf361021cb0c2cL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-78, 87, 26, 28, -40, 22, -38, -80]]\012",
        Z.run(T, 1, 5, 7, 10, "\udae2\ude87\ud94a\ude4c\udb08\udc46\ud90a\udfe0\ud99c\udd68\uda2d\udc08\udbb7\ude68\ud900\udd6e", "\u6cfc\u8980\u9b20\u70c0\u87fa\u429d\u8e1a\ua080", "\ud818\udee1\ud9a6\udea0\udb3e\ude63\ud877\udcad\ud9c8\uddc2\udb36\udd1a\ud83b\udfbe\ud854\udd4d\udb1c\ude99",
        18, 57887, -1100767684, -4461958121729768887L, 24173L, true, false, (char) 16712, (char) 61791,
        Double.longBitsToDouble(0x3fd9f30f86ef04ceL), Double.longBitsToDouble(0x3fdf342ef1cb0c2cL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 7, 3, "", "", "",
        22, 30395, -1654823936, 6640421309744831250L, 46452L, true, true, (char) 51270, (char) 6905,
        Double.longBitsToDouble(0x3fd0e356d06f4eb0L), Double.longBitsToDouble(0x3fec37da30ddbeebL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=[B:[[115, 108, 99, 97, 72, 78, 103, 87]] |a0=[B:[[-78, 87, 26, 28, -40, 22]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 1, 10, "\udae2\ude87\ud94a\ude4c\udb08\udc46", "\u0a5a\u4a68\ub138\u7235\u7f8e\u6cfc\u356a\u9b20\u70c0\u0568", "\udadd\udf35\udaae\ude88\ud854\ude26\ud818\udee1\ud9a6\udea0\udb3e\ude63\ud877\udcad\ud9c8\uddc2\udb36\udd1a\ud83b\udfbe\ud854\udd4d\udb1c\ude99\ud82a\udd80\udb83\ude8b\udabe\udf46\udb75\ude9a\udaaa\udca8",
        46, 83091, -2027014013, -100738412652302629L, -46019L, true, true, (char) 42462, (char) 36597,
        Double.longBitsToDouble(0x3fccb0c2cf8cbda4L), Double.longBitsToDouble(0x3fe8e57bc150a86bL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]]\012",
        Z.run(T, 2, 2, 7, 10, "\udaf6\ude5b\ud94a\ude4c\udb20\ude46\ud90a\udfe0\ud9f2\udfca\ud8c5\udc3f\udb39\udc19\ud975\udf25\ud90d\udc3b\ud9fe\udff8\ud9be\udc51\udad0\udd97\udacb\udc28\udb95\uded4\ud9e7\udeee\udac7\udfef\ud991\udcb1", "\u2be3\u86b1\u4c1d\ubc08\u06b3\ub07e\u5967\u4cd5\u44f6\u74db\u8acd\ud120\u3476\u79b5\ubd19\uccac\ua803\ub150\ub0ac\ud28d\u58ba\u0382\u58c3\u627b\u5e6b", "\ud999\udd50\uda18\uddc9\ud993\udfa9\uda19\ude0a\udb1d\udfee\uda7c\udf9f\ud9bf\udf7e\uda27\udcba\udbad\udff0",
        15, 43051, -1512609989, 5656103448932060749L, 51018L, true, true, (char) 9475, (char) 2515,
        Double.longBitsToDouble(0x3fc436970d3a7014L), Double.longBitsToDouble(0x3fd1c5dab69735caL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "\u3b3b", "\uda2d\udc49",
        1, 85568, -1371120878, -91768465393335316L, 57347L, false, true, (char) 18043, (char) 65423,
        Double.longBitsToDouble(0x3fec37da30ddbeebL), Double.longBitsToDouble(0x3fe7035d8fffb656L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=[B:[[66, 88, 99, 101, 74, 43, 97, 50, 50, 114, 65, 61, 13, 10]] |a0=[B:[[5, 119, 30, 39, -26, -74, -38, -80]]\0121=[B:[[66, 88, 99, 101, 74, 43, 97, 50, 50, 114, 65, 61, 13, 10]] |a0=[B:[[5, 119, 30, 39, -26, -74, -38, -80]]\012",
        Z.run(T, 2, 14, 14, 17, "\uda35\udca7\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\uda09\udeb4", "\u69ea", "\udaa5\udc6b\uda2f\udf25\udb25\udeb8\ud97e\udc82\udaf1\udeb5\udaae\ude88\ud88f\uddc2\ud8f4\udee8",
        -5, 98881, -1408044136, 7596556124359057740L, -79422L, true, true, (char) 2925, (char) 10555,
        Double.longBitsToDouble(0x3f83cd6997f6b340L), Double.longBitsToDouble(0x3fcb6c1ef2254710L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=[B:[[66, 81, 52, 84, 73, 119]] |a0=[B:[[5, 14, 19, 35]]\012",
        Z.run(T, 1, 15, 4, 18, "\uda35\udd3e\ud843\udf53", "\u843f\u6c22\u57e3\ub035\u876f\u9aa2\u4b6c\ub9a3\u0102\u09d3\u1dd1\uca07\u23a4\u180d\u10dc\u3e41\u1b16\ubff4\u6087\u98ce\u6cfe\uad6e\u4cb1\u2c5f\u8a60\ubaef\ud04f\ub8c4\u80ad\u8d22\u0799\ua2ba", "\ud831\udd81\ufda8\ud849\udf0d\udbbb\udf90\udae9\ude1b",
        35, 64894, 840733659, -4495463057322411374L, -5383L, false, true, (char) 40944, (char) 1396,
        Double.longBitsToDouble(0x3fe9fc06e8a75595L), Double.longBitsToDouble(0x3fe3ef9126265a12L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-124, -91, 123, -117, 41, 125, -58, 2]]\012",
        Z.run(T, 1, 8, 15, 6, "\ud9b4\uded5\ud9ab\udcbb\udb59\udead\ud8f6\udc32", "\u57e3\u9183\uc163\u9aa2\u69ea", "\u9494\ud9d0\udfd4",
        33, 85623, 1806825617, 6725693799609669631L, -11139L, true, false, (char) 36479, (char) 3999,
        Double.longBitsToDouble(0x3fd4c696cac9f97aL), Double.longBitsToDouble(0x3fe8f93f4c317277L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[5, -63, 34, -61, -20, -27, 124, 126]]\012",
        Z.run(T, 1, 5, 12, 10, "\uda35\udcf1\udb52\udff3\uda1c\udc15\udaac\udeae\udb98\udc13\uda46\uddd5\ud9b4\uddaa\ud9a1\udec0", "\ua113\uc82a\u9b77\u70c0\ud5cb\u429d\u7a7a\u1801\uae70\ud6af\u89a6\ud646\u6087\uabcc\u814e\uad91\u18b2\u2c0c\u8a60", "\udb12\udc11\ud841\udc3c",
        6, 13575, -1503330294, -2144399730366205314L, -23694L, true, true, (char) 3396, (char) 19429,
        Double.longBitsToDouble(0x3fe63ce5871e5438L), Double.longBitsToDouble(0x3fd10e0e14cb90c4L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=void |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 3, 17, 10, "", "", "\udb48\udcfe\000\udb9e\ude2f\ud8fc\ude6e\udab8\udd30\000\000\u18840\ud831\udeeb\u1110\uda29\udfb4",
        -2, -907, -1235847456, 56321378603703666L, -58763L, true, true, (char) 30591, (char) 13104,
        Double.longBitsToDouble(0x3fe38d3e1e948e9dL), Double.longBitsToDouble(0x3fd604d86bb527f6L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 17, "\ud96d\udc75", "\ua044\u3d4c", "\ud8fc\ude6e",
        49, 24341, 1957364500, -9113766439737977552L, 46448L, true, false, (char) 16745, (char) 49702,
        Double.longBitsToDouble(0x3fdda3a0c08ca31eL), Double.longBitsToDouble(0x3fd7261c83c7a9deL)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=[B:[[66, 84, 56, 57, 74, 119, 61, 61, 13, 10]] |a0=[B:[[5, 63, 61, 39]]\012",
        Z.run(T, 1, 14, 17, 6, "\uda35\udc6f\udb6d\udf57", "\u7fb9\u51d5\u57e3\ua238\u2e8f\u9aa2\u7d5a\u8fce\uc9ad\u2829\u2e63\u429d", "\udaae\ude88\ud88f\uddc2\ud8f4\udee8\ud8bf\udd2d\ud93d\udc5e\udb9e\ude16",
        58, 24565, -419665875, 6728756232403577040L, -98028L, true, true, (char) 33917, (char) 6890,
        Double.longBitsToDouble(0x3fc560147c0b26e4L), Double.longBitsToDouble(0x3feb5447c32fc015L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 1, 14, 8, 0, "", "\u8fbf", "\uda2d\udc49",
        24, 81728, 52, 1957364480L, -100000L, false, false, (char) 0, (char) 65335,
        Double.longBitsToDouble(0x3fc94008c0000000L), Double.longBitsToDouble(0x3e1ff6cac0000000L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=[B:[[66, 99, 69, 108, 74, 121, 81, 86, 50, 118, 103, 61]] |a0=[B:[[5, -63, 37, 39, 36, 21, -38, -8]]\0121=[B:[[66, 99, 69, 108, 74, 121, 81, 86, 50, 118, 103, 61]] |a0=[B:[[5, -63, 37, 39, 36, 21, -38, -8]]\012",
        Z.run(T, 2, 15, 13, 10, "\uda35\udcf1\udb55\udf57\uda54\udd45\ud90a\udf28\ud96d\udc91\udbad\udd3c\udaff\udce6\ud8be\udfcf\udbb5\ude1e\uda14\ude99\ud913\udf54\ud8ae\udc84", "\u884a\ud049\u7182\uc786\uc0e6", "\udab8\ude6a\udb98\udc0f\udb25\udca3\ud94a\udc7b\ud924\udfa9\ud83c\udc3b\ud89e\udef2\udbc8\ude41\udb80\ude93\ud905\ude51\udacf\udcbf\ud8bf\udd11\ue176\ud840\uddd7\uda7c\uddf3\ud97e\udca6\uda62\udd5d\ud8d2\udf0b\uda12\udf69\udbb9\udcdf\ud99d\udd84\udb97\udd19\ud9a4\udc5e\udbdf\ude26\ud817\ude6d\ud99c\udd62\ud84a\udcad\udae5\udc74\ud8bc\ude34\ud8f6\udc01\uda2b\udd02\uda92\uddd5\uda76\udf50\ud8d9\udc9a\ud92d\udec9",
        50, 70522, -950154108, 6773564927193219053L, 78103L, false, false, (char) 35684, (char) 42924,
        Double.longBitsToDouble(0x3fd3e9248113d484L), Double.longBitsToDouble(0x3fe699f25df36708L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-81, 22, 61, 72, -26, -74, -38, -80]]\012",
        Z.run(T, 1, 5, 13, 10, "\ud8df\udd46\udb6d\ude78\udb16\udfe6\ud90a\udfe0\ud888\uddbf\udbb8\udf11\udbce\udd81\ud900\udd6e\udbcd\udfcd\ud897\ude4f\ud9eb\udcd5\udbfc\udd17", "\u87fa\ud049\u7a19\u1801\ubf45\u2be3\u3267\u0f11\u2758\ua615\ud092", "\u2087\uda17\udc41\ud9ac\udf9c",
        42, 30316, -893128517, -4078783741878094119L, 89811L, true, true, (char) 27735, (char) 39304,
        Double.longBitsToDouble(0x3fdb3f382f166cf0L), Double.longBitsToDouble(0x3fe13d5ba8575e3eL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[108, 42, -82, -89, -26, -83, 14, -83]]\0121=java.lang.Boolean:true |a0=[B:[[108, 42, -82, -89, -26, -83, 14, -83]]\012",
        Z.run(T, 2, 5, 5, 5, "\udb9c\udd5a\ud9de\udfd7\udb16\udfdd\uaf3e\udbdd\ude88\ud936\uddfe\ud84f\udc3d\ud8f2\udff5\udbcd\udfcd\ud8f6\uddb5\ud888\udef6\udaf0\udcc6\ud939\ude1a\ud4e4\udbdf\udc7a\ud963\udf1d", "\u6800\u2be3", "\udb22\udc37\udb57\udea5\udb1d\udd2a",
        8, 75956, 1206376223, 6809782729751637918L, -8924L, true, false, (char) 2827, (char) 45436,
        Double.longBitsToDouble(0x3fc69c2f095ef630L), Double.longBitsToDouble(0x3fe28dc85befbabcL)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 2, 18, 16, "\uda63\ude35\uda31\udfea\udaec\udc59", "\u7f63\u4675\u1124\uc163\u39e9", "\ud964\udfec\udafc\udd84\ud94d\ude71\ud9ea\ude7b\ud96b\udf6d\ud81f\udc6c\udbfa\udd62\ud83b\udfa7\ud82e\udfd1\ud9d0\udea8\udb15\udcde\udae5\udc72\ud945\udf66\udb97\udd36\ud83b\udf61\udbdc\udc92\uda24\udee7\udac9\ude4c\udb0b\udc97\udad1\ude01",
        26, 74510, -697950075, 3473243332396885885L, -70273L, false, true, (char) 6651, (char) 62685,
        Double.longBitsToDouble(0x3fd9c7e7dd8774e0L), Double.longBitsToDouble(0x3fe8523113601c1cL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[5, -63]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[5, -63]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 0, 0, 0, "\uda35\udcf1", "\ub604\u7fb9", "\ud890\udf28",
        27, 54875, 796534804, 3910369739728104833L, 30475L, true, false, (char) 27597, (char) 8362,
        Double.longBitsToDouble(0x3fdb9faf1fff7e36L), Double.longBitsToDouble(0x3fd7261c85c7a9deL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=[B:[[112, 119, 71, 54, 121, 56, 106, 101, 121, 119, 61, 61]] |a0=[B:[[-89, 1, -70, -53, -56, -34, -53]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[112, 119, 71, 54, 121, 56, 106, 101, 121, 119, 61, 61]] |a0=[B:[[-89, 1, -70, -53, -56, -34, -53]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 10, 10, 4, "\u5fd7\uda31\udfea\udbfb\udef8\uda0e\udcfb", "\u4675\u1124\uc163\u39e9\u6848\ub6db\u0364\u879c\u2cf4\u667b", "\udbfa\udde5\ud88f\uddc2\ud8f4\udee8\udabc\udc9a\udb15\udcde",
        31, 6607, 473063756, 46552434082750087L, -79422L, true, false, (char) 19577, (char) 37612,
        Double.longBitsToDouble(0x3fec08ff1202f01dL), Double.longBitsToDouble(0x3fbadbfe954e5f18L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=[B:[[-115, -28, -99, -15, -68, -3, -38, -80]] |a0=[B:[[-115, -28, -99, -15, -68, -3, -38, -80]]\0121=[B:[[-115, -28, -99, -15, -68, -3, -38, -80]] |a0=[B:[[-115, -28, -99, -15, -68, -3, -38, -80]]\012",
        Z.run(T, 2, 9, 9, 4, "\ud9bd\udf14\ud9cd\udd21\udaec\udc2d\ud90a\udfe0\ud888\uddbf\ud9d8\udedf\udbec\udefd\ud890\udf28", "\u2859\u0edc", "\ud81c\uded9\udad0\udfcd\ud96b\udf6d",
        3, 63665, 1640503295, -3103229242733515549L, -96847L, true, true, (char) 52022, (char) 20553,
        Double.longBitsToDouble(0x3fe8f93f4e5b90e7L), Double.longBitsToDouble(0x3fecf62b8b0f1c6fL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=void |a0=[B:[[-48]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 12, 0, 0, "\000", "\u40cd", "\udbd7\udef9",
        53, -1000, 251658240, -2806542928489069949L, 71666L, false, false, (char) 65423, (char) 28806,
        Double.longBitsToDouble(0x3fb77b5980035d88L), Double.longBitsToDouble(0x3feff80000000000L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=[B:[[108, 99, 108, 117, 69, 66, 85, 83, 50, 114, 65, 61]] |a0=[B:[[-107, -55, 110, 16, 21, 18, -38, -80]]\0121=[B:[[108, 99, 108, 117, 69, 66, 85, 83, 50, 114, 65, 61]] |a0=[B:[[-107, -55, 110, 16, 21, 18, -38, -80]]\012",
        Z.run(T, 2, 13, 13, 2, "\ud9c5\udcf9\ud89e\udd40\udb45\udc42\ud90a\udfe0\udb45\udcd6\udb7f\udd41\udbd7\udef9\udb5d\udd7a", "\u0cbf\uc82a", "\ud92d\udf62\ud3d1\ud923\uddc5\udae5\ude0f\ud826\udc23",
        25, 31722, 1794001541, -7312139422930898024L, -9556L, false, true, (char) 18877, (char) 49730,
        Double.longBitsToDouble(0x3fed7b4b030f1c6fL), Double.longBitsToDouble(0x3fd3cb36f610fc00L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=[B:[[-29, 63, -116, -11, 66, 73]] |a0=[B:[[-29, 63, -116, 13, -11, 66, 13, 73]]\012",
        Z.run(T, 1, 9, 7, 10, "\udb13\ude6f\ud8bc\ude3d\ud825\ude72\ud83d\ude79", "\u57e3\ub138\uc163\u9aa2", "\uda80\udc15\ud94d\udc7a\ud9d0\udfd4",
        13, 94401, 1806816713, -5307924404815441033L, -42346L, true, false, (char) 36479, (char) 3999,
        Double.longBitsToDouble(0x3fd4c696cac9f97aL), Double.longBitsToDouble(0x3fe8f93f4fae405eL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=[B:[[1, -30, 64]] |a0=[B:[[65, -11, 101, -26, -84, 74, -26, 65]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[1, -30, 64]] |a0=[B:[[65, -11, 101, -26, -84, 74, -26, 65]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 16, 12, "\uda71\ude25\ud895\ude16\udbdc\udd7a\uda16\udd71\ud888\uddbf\uda2d\udc49\ud9da\udf2b\udbcc\udcaa", "\u69ea\uc82a", "\ud9d1\udc54\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udac9\udf80",
        18, 26138, 1634116835, -7284668112277671016L, -9556L, false, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fee06f3eb0f6443L), Double.longBitsToDouble(0x3fe1e59b7c657363L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[103]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 16, 12, "\u2f97", "\uad6a\u10f9\u6bd5\u211d\u7f5c\uc228\u9aa2\u69ea\uc82a\u9b77", "\udac7\udfef\ud94f\udf6d\udab3\udeb5\udaae\ude88\ud889\uddc3\ud8f4\udee8\ud9a6\udea0\udb3e\ude63\uda13\uddc3\ud9c8\ude1c\udb36\udd1a\ud83b\udf5a\ud89e\udef2\ud9c9\uddba\uda77\udda8",
        42, 40412, -1379509147, -5896266946977913542L, -28420L, true, false, (char) 6340, (char) 61487,
        Double.longBitsToDouble(0x3fdea444443b04e6L), Double.longBitsToDouble(0x3fe4547a90fd9b21L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 12, 10, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        7, 78671, 1634116835, -390502168876878952L, -9556L, true, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fce58b02e0fc004L), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=[B:[[65, 87, 109, 55, 122, 118, 115]] |a0=[B:[[1, 105, -69, -50, -5]]\0121=[B:[[65, 87, 109, 55, 122, 118, 115]] |a0=[B:[[1, 105, -69, -50, -5]]\012",
        Z.run(T, 2, 15, 15, 11, "\udb31\udc99\ue0eb\udafe\udf2b", "\u8841\u57e3", "\ud86e\udcdb\ud856\udd91\ud88c\udfa0\ud83e\uddc4\udb56\udef9\uda0a\udc89\ud837\udea3\ud96b\udfb1\udaf1\udeb5\udbaa\udef4\ud9f5\ude92\uda45\ude4c\ud9a6\udea0\udba5\udd4c\ud8a6\uddaf\ud958\udf2f\u7ef1\ud83b\udfbe\ud89e\udef2\uda46\udcc3\udb76\ude13\ud903\udcb8\udb01\udf67\ud9ee\udee0\udbb6\udf0c\ud84b\ude8c\ud803\ude50\udb95\udf80\ua374\ud9c4\ude4f\u5cff\000\udba8\udc9e\udbb4\udf13\ud8a9\udc17\udb0b\udfd8\ud910\uddba\ud8a4\udc94",
        39, 42448, 96552173, 8706699450464075928L, 44861L, false, true, (char) 34296, (char) 0,
        Double.longBitsToDouble(0x3febbd9db2a3c3b2L), Double.longBitsToDouble(0x3fecbd89543bbac0L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=[B:[[48, 76, 118, 115]] |a0=[B:[[-48, -69, -20]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 15, 11, 1, "\000\ue0eb\u751c", "\u0f12\u57e3", "\ud86e\udcdb\ud856\udd91\ud88c\udfa0\ud83e\uddc4\ud8ad\udf25\000\ud837\ude31\ud96b\udfb1\udaf1\udeb5\udbaa\udef4\ud9f5\ude92\uda45\ude4c\ud9a6\udea0\ub671\ud943\udee1\ud958\udf2f\u7ef1\ud83b\udfbe\ud89e\udef2\uda46\udcc3\udb76\ude13\ud903\udcb8\udb01\udf67\ud9ee\udee0\udba5\udd0c\000\ud803\ude50\udb95\udf80\ua374\ud9c4\ude4f\ud87e\uddb2\ud947\udfab\udba8\udc9e\udbb4\udf13\ud8a9\udc17\udb0b\udfd8\ud910\uddba\ud8a4\udc94",
        39, 42448, 96552173, 8706699450468902296L, 44861L, false, true, (char) 28851, (char) 61462,
        Double.longBitsToDouble(0x3febbd9db2a3c3b2L), Double.longBitsToDouble(0x3fecbd89543bbac0L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=[B:[[114, 111, 49, 68, 114, 115, 55, 55]] |a0=[B:[[-82, -115, 67, -82, -50, -5]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[114, 111, 49, 68, 114, 115, 55, 55]] |a0=[B:[[-82, -115, 67, -82, -50, -5]]\012",
        Z.run(T, 2, 10, 13, 1, "\ud9de\udebd\ud873\udcde\udafe\udf2b", "\u8841\u57e3", "\udb41\udd64\ud9a3\udcfa\ud88c\udfa0\ud83e\uddc4\udb56\udef9\uda0a\udc89\ud837\udea3\ud96b\udfb1\udaf1\udeb5\udbaa\udef4\ud9f5\ude92\uda45\ude4c\ud9a6\udea0\udba5\udd4c\ud8a6\uddaf\ud958\udf2f\u7ef1\ud83b\udfbe\ud91b\ude28\uda9f\udd88\uda22\udf90\ud903\udcb8\udb01\udf67\ud9ee\udee0\udbb6\udf0c\ud84b\ude8c\ud803\ude50\udb95\udf80\ua374\ud9c4\ude4f\ud87e\uddb2\ud947\udfab\udba8\udc9e\udbb4\udf13\ud8a9\udc17\udb0b\udfd8\ud910\uddba\ud8a4\udc94",
        39, 42448, 96552173, 8706699450468902296L, 44861L, false, true, (char) 28851, (char) 61462,
        Double.longBitsToDouble(0x3febbd9db0a3c3b2L), Double.longBitsToDouble(0x3fecbd89543bbac0L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 12, 2, "\udb31\udd30\ue0eb\udafe\udf2b", "\u8841\u57e3", "\udbfa\udc99\udaf7\uddec\ud88c\udff4\ud982\udd65\udb59\udfc7\ud828\udc18\ud837\udea3\ud96b\udfb1\udaf1\udeb5\udbaa\udef4\ud9f5\ude92\uda45\ude4c\ud9fd\ude6d\udaa0\udf98\udbbe\udcee\ud958\udf2f\u7ef1\ud83b\udfbe\udacd\udc91\udbb5\udfae\udb76\ude13\ud903\udcb8\udb01\udf67\ud9ee\udee0\udbb6\udf0c\udaf7\ude82\ud803\udeea\udb55\udeb0\ua374\ud9c4\ude4f\ud87e\uddb2\ud947\udfab\udba8\udc9e\udb9b\udd45\udbef\uddbf\udacb\ude29\udbf9\udc71\ud8a4\udc6b",
        39, 42448, 2143372525, -7241337035301245494L, 44861L, false, true, (char) 28851, (char) 61462,
        Double.longBitsToDouble(0x3febbd9db2a3c3b2L), Double.longBitsToDouble(0x3fecbd89543bbac0L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=[B:[[-37, -33, 115]] |a0=[B:[[50, -27, 57, -52, 32, 57, 122, 89]]\0121=[B:[[-37, -33, 115]] |a0=[B:[[50, -27, 57, -52, 32, 57, 122, 89]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 6, 16, 15, "\ud962\udf15\ud969\uddfc\udb50\udd69\ud9aa\ude89\ud888\uddbf\ud921\udfe3\ud933\udee7\ud837\udcc1\ud812\udd6a\udb1d\ude16\ud99a\ude23\ud8a1\uddcb\udaad\udee2\ud857\uddad\udae0\udc44\ud890\udea1", "\uc859\u2b15\ub4e6\u23bf\u9945\ua81f\u8457\u634c\u5142\u2c0c\u7279\uc951\ud04f\uc47b\uabcb\u67c9\u7f39\u4f2d\u46ca\u5dee\ud782\ua74f\ud31e\uac71\u1648\u4042\ubeaf\uaaa4\u7a82\uad68\u02da\u52e0\u06ec\ud150\u8fb3\u0257\u387f\u2945\ud4b2\u9f29\ua6b8\u66cc", "\ud8ec\udd18\udbb3\ude9c\ud9c8\udd65\uda3c\udebb\udafd\udd7e\ud866\udefd\udae4\udda2\ud9b0\udcfd\udba6\udfb9\ud99d\udc7b\uda2e\udd8c\udb7f\udd5b\udae3\udf75\ud91a\udd09",
        49, 73076, -337002373, 5641589222835079568L, -30794L, false, true, (char) 5280, (char) 25263,
        Double.longBitsToDouble(0x3fd2200dd985f568L), Double.longBitsToDouble(0x3feda4ad3b7c60ffL)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 2, 1, 3, "\udbb3\udf30\udb12\udd68\ud930\udc10\uda91\udda4\udadb\udd23\ud821\udc44\uda02\udfcc\udb99\udfc1\uda63\udd69\uda92\ude44\ud97d\udf36\ud918\udcc6\u3588\u9494\ud967\udc42\ud905\udd92\ud99a\udd2c\udaf1\udf3c\ud872\ude8a\uda20\udfac\ud966\udca6\udb76\udd84\udb02\udd6a\ud971\udf51\ud885\udea7\udb1f\udc2b\ud82a\udcc1\ud811\udefb\udb01\udefa\ud835\udfd5\ud9c5\ude7a\ud896\udeac\uda11\udc57\ud854\udc01\ud82e\udcc4", "\u0a03\ub317\u3e40\u41e8\u66af\uc3a4", "\ud9c8\udce6\uda54\udf56",
        47, 96651, -1798776998, -9096164181186491350L, 3603L, true, true, (char) 39294, (char) 63030,
        Double.longBitsToDouble(0x3fecf126e48215a6L), Double.longBitsToDouble(0x3fe60bc62e5cbfddL)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=void |a0=[B:[[76, -77, 7, -41, -115, -46, 97, 73]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[76, -77, 7, -41, -115, -46, 97, 73]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 3, 16, "\udb7c\udde3\ud937\ude07\udbbd\udf02\uda91\udd79\udb02\uddd8\uda2d\udc49\ud956\udcc4\udbf5\udeb3", "\u9358\uc82a\u9b77", "\udac8\udc93\ud99f\udf2f\udaf1\udf3c\ud872\ude8a\ud94f\udc9c",
        54, -724, 922752557, -6011320647590059124L, -81924L, true, false, (char) 24367, (char) 20539,
        Double.longBitsToDouble(0x3fde9ac7cc7966c2L), Double.longBitsToDouble(0x3fc76aec6f9fa7b4L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=[B:[[51, 110, 81, 72, 49, 52, 51, 83]] |a0=[B:[[-34, 116, 7, -41, -115, -46]]\0121=[B:[[51, 110, 81, 72, 49, 52, 51, 83]] |a0=[B:[[-34, 116, 7, -41, -115, -46]]\012",
        Z.run(T, 2, 13, 13, 18, "\ud90e\udfa4\ud937\ude07\udbbd\udf02", "\u6bd5\u5730\ub15f\uc163\ud40c\u9358\uc82a\u9b77\u70c0\uc87f\u4341\u1577\u1888\u77af\u592b\uc318\u1665\u1721\uadcc\ub07e\uad6e\uafd9", "\uda25\udd3c\ud81c\udd65",
        31, 75779, 594198861, 6135502521666757042L, 7280L, false, false, (char) 62350, (char) 40184,
        Double.longBitsToDouble(0x3fa7b34f25cd2870L), Double.longBitsToDouble(0x3fef17855a2a8f27L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=[B:[[21]] |a0=[B:[[-43, 58, 70, 35, 85, 61, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[-43, 58, 70, 35, 85, 61, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 3, 9, "\ud805\udc6a\uda76\udd53\ud885\udf6d\udb33\udff4\ud888\udd4b\uda4b\udc78\udb8a\ude32\udbc6\udf4f\ud937\udd41\ud840\udf3f\ud973\uddc8", "\uacc0\u7416", "\udb1e\udf86",
        8, 86694, -722526862, 5162949131827994690L, 67364L, true, false, (char) 17643, (char) 30077,
        Double.longBitsToDouble(0x3fe878e7a63cb36fL), Double.longBitsToDouble(0x3fc777cc74c61b28L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.math.BigInteger:16498737 |a0=[B:[[45, 41, 56, -53, 28, 65, 120, -108]]\0121=java.math.BigInteger:16498737 |a0=[B:[[45, 41, 56, -53, 28, 65, 120, -108]]\012",
        Z.run(T, 2, 8, 8, 16, "\u815d\uda59\udc68\ud9fb\udf4c\udb71\udda8\udbc4\udc64\uda2d\udc00\udbd7\udef9\ud8d5\ude1d\udb72\uddd1\ud86e\udce2\udb56\uddbc", "\uacc0\u87fa", "\udb04\udf8b\ud992\udd1d\u028e",
        1, 10809, 1813751060, 6261570503364867683L, 26900L, true, false, (char) 18435, (char) 20907,
        Double.longBitsToDouble(0x3fc777cc676e7afcL), Double.longBitsToDouble(0x3fa27132559b88d0L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-43, 58, 41, 56, -72, 61, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[-43, 58, 41, 56, -72, 61, 3, -60]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 0, 5, "\ud805\udc6a\uda59\udc68\udae8\udc6d\udb33\udff4\ud9a2\udd78\ud84d\udf5f\udbd2\udef7\ud8f0\udc6e\udbce\udc45", "\uc82a\u9b77\uacc0\u87fa\u277f\uc1a5\ub350\u58f1\u2b0e\u2f9d\ud23c\u7d7c\u54c3\u1646\u94f9", "\uda17\udc41",
        15, 58113, -1100767684, -8734018191564919503L, 94483L, false, false, (char) 13997, (char) 8054,
        Double.longBitsToDouble(0x3fe0dd2c7e7ed593L), Double.longBitsToDouble(0x3fc8b4c27b04c624L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=[B:[[-57, -49, -83, -104]] |a0=[B:[[120, 41, 56, 43, 116, 92, 109, 68]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[-57, -49, -83, -104]] |a0=[B:[[120, 41, 56, 43, 116, 92, 109, 68]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 16, 9, "\u9ca8\uda59\udc68\u7a5b\ud9a4\udd8c\ud89d\udd74\udb50\uddff\udbff\udd20\ud8f0\udc6e\udbce\udc45\ud86e\udcdb\ud969\uddb4", "\uac52\000", "\udb04\udf8b\ud992\udd1d\ud8a9\udce1",
        5, 69834, 218, -8088111989569587528L, 67364L, true, false, (char) 17643, (char) 20743,
        Double.longBitsToDouble(0x3fe878e7a03cb36fL), Double.longBitsToDouble(0x3e44c61b28000000L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[116]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[116]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 0, 0, 0, "\u19a4", "\u050e\u7f45", "\000",
        17, 24341, 851968, -8935141660703064064L, -100000L, true, false, (char) 26280, (char) 48569,
        Double.longBitsToDouble(0x3fd334d78e3d7562L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 10, 10, 4, "\udb7c\udd68\uda31\udf7b\udbfb\udef8\uda0e\udcfb\ud93e\udd6f\udb41\udf67", "\uc163\u39e9\u5530\ub6db\u0364\u879c\u2cf4\u667b\u7a7a\u3912\ud11c\u2bca\u3267\u25e0\ua184", "\ud96c\udef5\udaec\udf3a\ud8ae\udd69\ud825\udf9b\udace\ude38\uda16\udd52\ud9c1\udec5\ud921\uddc8\udb9c\udd9c\ud946\udc9b\udb47\udd58\ud8bf\udf21\ud934\udec4\ud955\udf20\ud8dc\udcbe\uda4d\udc5b\ud9c4\ude42\ud835\ude72\uda01\udf1e\uda35\udfb8\udade\udc2b\ud8d2\udec1\udb9f\ude2e\ud99e\udea3\udbfa\ude3a\udbd7\udc17\ud862\udcd3\ud903\udd4b",
        11, -924, -2121831005, -4581152579718196061L, -68294L, false, false, (char) 40797, (char) 25485,
        Double.longBitsToDouble(0x3fb63b082af30100L), Double.longBitsToDouble(0x3feadc3a45c016faL)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=[B:[[65, 87, 108, 122, 85, 77, 55, 111]] |a0=[B:[[1, 105, 115, 80, -50, -24]]\0121=[B:[[65, 87, 108, 122, 85, 77, 55, 111]] |a0=[B:[[1, 105, 115, 80, -50, -24]]\012",
        Z.run(T, 2, 15, 15, 11, "\udb31\udc99\ud8a3\ude80\udafe\udf18", "\u8841\u57e3", "\ud86e\udcdb\ud856\udd91\ud88c\udfa0\ud83e\uddc4\udb56\udef9\uda0a\udc89\ud837\udea3\ud96b\udfb1\udaf1\udeb5\ud871\udc78\uda46\udd2d\uda45\ude4c\ud9a6\udea0\ud9cb\udc73\ud839\udf1b\ud958\udece\u7ef1\ud83b\udfbe\ud89e\udef2\uda46\udcc3\udb76\ude13\ud903\udcb8\udb01\udf67\udbf9\udda6\udb72\udc90\uda61\udef9\ud803\ude50\udb95\udf80\ua374\ud9c4\ude4f\uda4c\ude79\udbf2\udcde\udba8\udc29\udbb4\udf13\ud8a9\udc17\udb0b\udfd8\ud910\uddba\ud894\uddad",
        7, 73999, -988573739, 7772682307787487628L, 44861L, false, true, (char) 34296, (char) 0,
        Double.longBitsToDouble(0x3fe22d78d1b2cf18L), Double.longBitsToDouble(0x3fecbd88f43bbac0L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=[B:[[98, 55, 118, 79, 45, 119]] |a0=[B:[[111, -69, -50, -5]]\0121=[B:[[98, 55, 118, 79, 45, 119]] |a0=[B:[[111, -69, -50, -5]]\012",
        Z.run(T, 2, 15, 15, 11, "\ua09f\ue0eb\udafe\udf2b", "\u8841\u57e3", "\ud86e\udcdb\ud856\udd91\ud88c\udfa0\ud83e\uddc4\udb56\udef9\uda0a\udc89\ud837\udea3\ud96b\udfb1\udaf1\udeb5\udbaa\udef4\ud9f5\ude92\uda45\ude4c\ud9a6\udea0\udba5\udd4c\ud8a6\uddaf\ud958\udf2f\u7ef1\ud83b\udfbe\ud89e\udef2\uda46\udcc3\ud88a\ude1d\ud903\udcb8\udb01\udf67\ud9ee\udee0\udbb6\udf0c\ud84b\ude8c\ud803\ude50\udb95\udf80\ua374\ud9c4\ude4f\u5cff\000\udba8\udc9e\udbb4\udf13\ud8a9\udc17\udb0b\udfd8\ud910\uddba\ud8a4\udc94",
        39, 42448, 96552173, 8706699450464075928L, 44861L, false, true, (char) 34296, (char) 0,
        Double.longBitsToDouble(0x3febbd9db2a3c3b2L), Double.longBitsToDouble(0x3fecbd89543bbac0L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\0121=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 2, 15, 15, 11, "", "\u2ef1", "\ud8a1\udfc4",
        26, 86506, 1076948214, 1137510668166719764L, -37085L, false, true, (char) 60115, (char) 58819,
        Double.longBitsToDouble(0x3fe7035d8aabd72dL), Double.longBitsToDouble(0x3fcc5cd7138f50a0L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=[B:[[-110, 48, -40, -70, -83, -38, -80]] |a0=[B:[[-110, 10, 48, -40, -70, -83, -38, -80]]\012",
        Z.run(T, 1, 9, 7, 1, "\ud8c2\udd3a\ud960\udd08\udaea\udddd\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e\udbcd\udfcd\ud86e\udcdb\ud973\uddc8\ud882\udf3c\u2ad3\u9494\ud9d0\udfd4\udac7\udfef", "\uc791\u2be3\u3267\u9853\u6087", "\udb36\udd1a",
        8, 53711, -981340236, 2049049447331998479L, -30555L, false, false, (char) 2974, (char) 5937,
        Double.longBitsToDouble(0x3fc28b782987e078L), Double.longBitsToDouble(0x3f9817c5e4183680L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 4, 10, "\uda35\udcf1\udb4e\udd57\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\ud900\udd6e", "\u69ea\uc82a", "\ud9d0\udfd4\udac7\udfef\ud96b\udf6d\udaf1\udeb5\udaae\ude88",
        10, 26138, 1634116835, -390502168876878952L, -9556L, true, true, (char) 65287, (char) 12443,
        Double.longBitsToDouble(0x3fecf62c0b0f1c6fL), Double.longBitsToDouble(0x3fe1e59b78bbbe63L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=[B:[[-18, 14, 29, 58, -38, -80]] |a0=[B:[[32, -18, 14, 29, 58, 32, -38, -80]]\012",
        Z.run(T, 1, 9, 12, 10, "\ud850\udf1e\uda3e\udc4d\uda6a\udf50\ud90a\udfe0\ud888\uddbf\uda2d\udc49\ud8e5\udc1e\udabc\ude60", "\u1282\uc82a\u9b77\u8f90\u1abe\u54be\u7a7a\ubba5\u4f7c\ub7f5\uba4d\u9853\u839c\ua81f\u6196\ua849\u5b26\u2c0c\u9b96\uc951\u6347", "\ud919\ude38\udb57\udf9b\ud90b\udf2e\ud951\udd34",
        10, 39053, 890420778, -1026076508544972921L, 39802L, false, true, (char) 35237, (char) 19616,
        Double.longBitsToDouble(0x3fd725f35b17b14cL), Double.longBitsToDouble(0x3fe76976f43f80fbL)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-96, -2, -43, -111, 39, 125, -17, -60]]\0121=java.lang.Boolean:false |a0=[B:[[-96, -2, -43, -111, 39, 125, -17, -60]]\012",
        Z.run(T, 2, 5, 5, 5, "\udbd0\ude2e\ud905\udfc1\ud857\udcad\udb1f\uddf4\ud888\udd4b\uda2d\udc49\udbd7\udef9\uf074\udbce\udc45\ud86e\udcdb\uda29\udd62", "\ua413\u1753\ua8b4\u1ea6\u8acc\u7c3e\u4e7b", "\uda1a\udd8b\uda54\udf29\ud992\udff5",
        28, 54100, 1429722263, -4214824218165888866L, -44192L, false, false, (char) 16123, (char) 6384,
        Double.longBitsToDouble(0x3fca288d90b0cd0cL), Double.longBitsToDouble(0x3fe334367bee95acL)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=[B:[[53, 77, 50, 67, 56, 101, 97, 50, 50, 114, 65, 61]] |a0=[B:[[-28, -51, -126, -15, -26, -74, -38, -80]]\0121=[B:[[53, 77, 50, 67, 56, 101, 97, 50, 50, 114, 65, 61]] |a0=[B:[[-28, -51, -126, -15, -26, -74, -38, -80]]\012",
        Z.run(T, 2, 14, 14, 17, "\udb14\udffd\ud8b2\udd21\udb16\udfe6\ud90a\udfe0\ud888\uddbf\uda2d\udc49\udbd7\udef9\uda09\udeb4", "\u69ea", "\udaa5\udc6b\uda2f\udf25\udb25\udeb8\ud97e\udc82\udaf1\udeb5\udaae\ude88\udbb1\udd5e\ud8f4\udee8",
        -5, 98881, -1408044136, 7596556124359057740L, 6238L, false, true, (char) 14014, (char) 59692,
        Double.longBitsToDouble(0x3fcb6c1ef2254710L), Double.longBitsToDouble(0x3fd1c7125f679a60L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-116, 88, 123, -117, 41, 125, -58, 2]]\0121=[B:[[]] |a0=[B:[[-116, 88, 123, -117, 41, 125, -58, 2]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 8, 16, 6, "\ud9bc\ude88\ud9ab\udcbb\udb59\udead\ud8f6\udc32", "\u57e3\u9183\uc163\u9aa2\u69ea\uc82a", "\ud9d0\udfd4\udac3\udf62\ud893\udd8b",
        36, 42616, 1640515229, -3103212477880032029L, -31288L, false, true, (char) 51896, (char) 4642,
        Double.longBitsToDouble(0x3fe8f93f4c317277L), Double.longBitsToDouble(0x3fe6825bee8d85c7L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=[B:[[-127]] |a0=[B:[[103, 101, -26]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 16, 3, "\u2f97\ud895\ude16", "\u10f9\u6bd5\u211d\u7f5c\uc228\u9aa2\u69ea\uc82a\u9b77\ua117\u887a\u429d\u0a7a\ucfff\uc791\u13e4\u3267\u9853\u6087\u7e58\ub0d8\uad6e\u4c4d\u2c0c\u2ffd\u4e95\ud04f\ua406\u0822\u1879\u8984\u50ec\u91f7\u7a89\u175b\ud25f\ucd1c\u7c91\u72fd\u55ba\u986a\u5db2\u6000\u7d1c\u30b5\uc2e5\u502b\u1d82\u46eb\u3ace\u812e\u4a92\ub1ac\u2e89\u9ddc\u4212\u35f1\u23b9\ud030\ud6e6\uc9ee\u9506\u6148\uabea\u0852\u1450\u422a\uc2b2\ua72c\u4766\u36c4", "\udb71\udc62\ud97e\udc9b\udb6e\udeff\udab5\udc90\udb8c\udfd5\udb93\udc57\udb7d\udf3e\ud8e5\udeb9\uda31\udc74\udbe4\udcbf\udac7\udf79\udb2a\udcca\udb3a\uddd0\udafc\uddb0\ud9ae\udd01\udab0\udf03\ud8aa\udd81\udbf7\udc64\ud974\uddf2\udb66\ude6e\ud82a\udf15\udbf5\udf9f\udb61\ude5a\ud8c3\uded9\uda2c\udd00\u8624\udbdb\ude98\ud92f\udc99\ud87b\udf46\udb7f\udf16\udb29\ude05\ud87b\udfa4\ud8a8\udd5b\uc26c\ud9ed\uddcd\ud90f\udc1c\ud804\udc1c\uda2c\udf00\u0a70\ud87d\udfb0\ud8ca\uddea\ud809\udc7f\ud952\ude21\udabd\uddc5\ud9eb\udf76\ud8c7\udd2b\udbc1\ude5a\udadc\udcbd\ud9c7\udfe4\udab6\uddc9\udbb3\uddcf\ud912\udd12\ud9c6\udcc2\udbd2\udd29\ud9aa\ude6e\ud9f9\udd9d\udbfd\ude11\ud931\udcc3",
        38, 47973, -1984856299, -1580879184795618558L, 35132L, true, false, (char) 49707, (char) 28189,
        Double.longBitsToDouble(0x3fb9149a5b498740L), Double.longBitsToDouble(0x3fec9bbd5a2eb145L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-96, -2, -43, -111, -14, -51, -17, -21]]\0121=java.lang.Boolean:false |a0=[B:[[-96, -2, -43, -111, -14, -51, -17, -21]]\012",
        Z.run(T, 2, 5, 5, 5, "\udbd0\ude2e\ud905\udfc1\ud822\udffd\udb1f\udd1b\ud860\udc35\uda2d\udc49\udbd7\udef9\uf074\udbce\udc45\ud86e\udcdb\uda29\udd62", "\ua413\u1753\ua8b4\u1ea6\u8acc\u7c3e\u4e7b", "\uda1a\udd8b\uda54\udf29\ud992\udff5",
        28, 54100, 1429722263, -4214824218165888866L, -44192L, false, false, (char) 16123, (char) 6384,
        Double.longBitsToDouble(0x3fca288d90b0cd0cL), Double.longBitsToDouble(0x3fe334367bee95acL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base64|decode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.String|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|avail||new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|containsBase64Byte|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|java.lang.String|static",
    "M|org.apache.commons.codec.binary.Base64|decodeInteger|[B|static",
    "M|org.apache.commons.codec.binary.Base64|discardWhitespace|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|decode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.String|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
