package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base64_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368090622818L, 48547L, true, true, (char) 6210, (char) 31247,
        Double.longBitsToDouble(0x3fe7912deedc0cf7L), Double.longBitsToDouble(0x3fe7b6d31c49ee81L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 1, 9, 12, "\ud8cf\ude60\ud964\udc92\ud903\udf1a\ud9f5\udfed", "\u0a3e\u5b28\u90fd\u1f23\ub9f0\ubb9b\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368090622818L, 48547L, true, true, (char) 6210, (char) 31247,
        Double.longBitsToDouble(0x3fe7912deedc0cf7L), Double.longBitsToDouble(0x3fe7b6d31c49ee81L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-97, 48]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud8cf\ude60", "\u33bc", "\udab3\udeec\udbc2\udf3d\uda23\udda8\ud9a2\ude5b\ud82b\udebf\ud92b\udf97\uea31\uda2d\ude03\udad9\uddf2",
        28, 142, -670045860, 6311688951247927671L, 58227L, true, false, (char) 49020, (char) 18128,
        Double.longBitsToDouble(0x3fb3003b5b325050L), Double.longBitsToDouble(0x3fd871a8612c004eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-97, 48]]\012",
        Z.run(T, 1, 5, 9, 18, "\ud8cf\ude60", "\u33bc\ucef1\u3682\u0a3e\u5b28\u8dc3\u1f23\u9f46\ua562\u94ee", "\000",
        37, 88140, 1469554601, 1145033017674772279L, -23249L, false, false, (char) 15728, (char) 15373,
        Double.longBitsToDouble(0x3fc2cbc4ffd8dc90L), Double.longBitsToDouble(0x3fcd1cfcc99b036cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-97, 48, -97, -113, -72, -57, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud8cf\ude60\ud9cf\uddbf\ud9e8\uddf7\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\u5205\ub57b", "\ud88d\ude5f\ud951\udfe6\ud9c5\udf01\ud9bd\udcd2\udac6\udf66",
        39, 74557, -1621107153, -8070133749823210417L, 21485L, false, true, (char) 34237, (char) 60455,
        Double.longBitsToDouble(0x3fcd1cfcc99b036cL), Double.longBitsToDouble(0x3fcf89b2d8c54f74L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[B:[[110, 122, 65, 48, 89, 113, 78, 83, 120, 82, 69, 61]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]]\012",
        Z.run(T, 1, 13, 9, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u9420\u78d3\u8e6e\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udb2f\uddaf\ud844\udc25",
        47, 42847, 453058589, -7211059259049844660L, 86358L, false, false, (char) 2914, (char) 6802,
        Double.longBitsToDouble(0x3fe18a9ee953d89bL), Double.longBitsToDouble(0x3fe6b192449ecb4eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u4f4d\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\udb4c\udc88\udbaa\udc91\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368090622818L, 85413L, false, true, (char) 2223, (char) 19411,
        Double.longBitsToDouble(0x3fe7b6d31c49ee81L), Double.longBitsToDouble(0x3fc07cc333d24c28L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]]\012",
        Z.run(T, 1, 6, 18, 6, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\ud146\u5b28", "\ud840\udca4\udaa1\udc11\ud8aa\udc74\ud8b5\ude07\uda23\ude58\ud89a\udc19\ud9e8\udd11\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\uda83\udef9\udb9e\udc73\udb32\udca1\ucca9\ud89f\udcf6\ud9b0\udfdc",
        29, 55522, -548423448, 5590737455773727532L, 80980L, true, true, (char) 39140, (char) 30234,
        Double.longBitsToDouble(0x3fb0cd3508faa570L), Double.longBitsToDouble(0x3fecb4c55dc27c4dL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[B:[[-45, -122, -54]] |a0=[B:[[-97, 48, 52, 98, 75, 70, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 7, "\ud8cf\ude60\ud964\udc92\udb7b\udc76\ud9f5\udf41\ud8f1\udf25\ud925\ude09\udab3\udeec\udbc2\udf3d\uda23\udda8", "\u98f0\u9b8d\u67ce\u3552\u9202\u04bc\u4a06\u8bcd\u0824\u728a\ub870\u7ba9", "\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\uda1e\ude69\ud97d\udd2f\ud9f9\udef8\ud8d8\udded\uda7b\udff9\uda4a\udf38\u8bbb\uda47\udf17\ud973\udd56\udb3a\udc68",
        16, 39883, -1733600993, 5153157369315589570L, -73101L, false, false, (char) 51221, (char) 64774,
        Double.longBitsToDouble(0x3fdc1ceb02f7ebc6L), Double.longBitsToDouble(0x3fb877f5bfa92da8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[B:[[-72, 126, 27]] |a0=[B:[[117, 72, 52, 98, -93, 82, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud8a5\udc78\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud9c5\udea6",
        16, 25351, -2103890121, 5556762358763740719L, -23249L, true, false, (char) 15728, (char) 15373,
        Double.longBitsToDouble(0x3fc2cbc4fc48e490L), Double.longBitsToDouble(0x3fcd1cfcc99b036cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.math.BigInteger:208 |a0=[B:[[-97, 48, 16, -48, -99, 80, 3, 127]]\012",
        Z.run(T, 1, 8, 9, 12, "\ud8cf\ude60\ud940\ude00\ud9cd\ude80\uda33\uddaf", "\u0a3e\u5b28\uc0b8\u816e\ub998\u7189\u0126\u720d\u3552", "\udbae\udcd7\udb65\ude47\udade\uddf8\udbf7\udfcd\ud97e\ude78\udb68\udc18\udad2\udf05\ud8bf\udde9\ucca9\ud86a\uddd1\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud862\udc0c",
        -5, 61129, 843635027, -3796984368090622818L, 48547L, true, true, (char) 6197, (char) 31247,
        Double.longBitsToDouble(0x3fce44b7bfa433dcL), Double.longBitsToDouble(0x3fe7b6d6a449ee81L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -28]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\u6514", "\u0a3e\u5b28\u8dfc", "\ud92b\udf97\uec51\uda2d\ude03\udad9\uddf2\ud88d\ude5f\ud951\udfe6\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\uda10\udd84\udb82\udf65\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8\ud8d8\udded\udaca\udfde\uda65\udc49\u8bbb\uda47\udf17\ud973\udd56\udb3a\udc68",
        16, 39883, -1347725025, 8988737342747311554L, -94953L, false, false, (char) 7947, (char) 32991,
        Double.longBitsToDouble(0x3fc97c137d95f674L), Double.longBitsToDouble(0x3fe28f7332981172L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 11, 9, 15, "\udac2\ude9a\ud8b3\udcb8\u9eed\ud8f6\udea4", "\u22c2\u669e\u8dfc\u1f23\ub9f0\ua562\u94ee\u9aca\u3552\u9202\u04bc\u4a06", "\ud80d\udc3d\ud97e\udd98\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud999\ude87\ud97d\udd2f\ud9f9\udef8\udb08\udd1a\uda08\udd3a\uda33\udeb0\ud806\udf38\uda47\udee8\ud973\udd56\udb3a\udc68\u09ab\uda0e\udd40\ud828\udf08",
        18, 38258, 217572082, 460280701242175600L, 53394L, false, true, (char) 29992, (char) 35911,
        Double.longBitsToDouble(0x3fdd441a50661154L), Double.longBitsToDouble(0x3fb6e6d889babcb0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 12, 11, 17, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\udba5\udf39", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u0765", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78",
        0, 72589, -1678955569, 5335323326040961894L, -97802L, false, true, (char) 41166, (char) 2882,
        Double.longBitsToDouble(0x3fcf89b2d8c54f74L), Double.longBitsToDouble(0x3fd53d89bdac6490L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\udaa6\udffe", "\u3580\u5b23\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552\u9202\u04bc", "\udade\ude66",
        39, 74557, -1619927505, 1945871821247949775L, 93382L, true, true, (char) 26301, (char) 3866,
        Double.longBitsToDouble(0x3fcd1cfcc99b036cL), Double.longBitsToDouble(0x3fcf89b2d8c54f74L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 12, "\ud8cf\ude97\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9cd\udcfa\udade\uddf1\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\uda18\ude1c\udb68\ude8b\ud9a3\udef2\ud842\udc14\u33a2\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 1598609747, -3796863469056207714L, -60256L, false, false, (char) 30999, (char) 44493,
        Double.longBitsToDouble(0x3fecb4c55dc27c4dL), Double.longBitsToDouble(0x3fe7912de9dc0cf7L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[B:[[-31, -76]] |a0=[B:[[-43, 22, 52, 98, -93, 82, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud905\ude46\ud964\udc92\ud9d3\udc82\ud9f5\udf41\ud8f1\udf25\ud925\ude09", "\u8dfc\u9f58\u9f69\ua59d\u94ee\u71cf\u3552\u9202\u04bc", "\udade\ude66",
        39, 53309, -1621107031, -962609113107049658L, 93382L, true, true, (char) 26301, (char) 3866,
        Double.longBitsToDouble(0x3fcd1cfcc99b036cL), Double.longBitsToDouble(0x3fcf89b2d8c54f74L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 10, "", "", "",
        37, 66419, 1717797092, -6147334030046720711L, -71656L, true, false, (char) 44675, (char) 3385,
        Double.longBitsToDouble(0x3fe86e545a6a312aL), Double.longBitsToDouble(0x3febb219415c4b52L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 9, 12, "\ud9f1\udc91\ud962\ude49\udbe0\ude48\udbb2\udeb7", "\u0a3e\u5b28\u1778\u5685\ub957\ua562\u94ee\u71cf\u35e7", "\ud991\udf1d\ud9bd\udcd2\ud960\udd86\ud869\ude3d\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\uda16\udc95\udb89\uded5\udb9c\udc88\ud97d\udd46\udbc2\udcfd",
        51, 69105, 843635027, -3796984368090622818L, -60859L, false, true, (char) 46524, (char) 44493,
        Double.longBitsToDouble(0x3fe9fcc5596b561fL), Double.longBitsToDouble(0x3fe793da06dc0cf7L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 8, 2, "\ud9b8\uddd3\ud9fb\udc55\ud9d8\udd2d", "\u150b\u0a3e\u28fc\u8307\ub181\u515a\u1591\u1aa8\u71de\u4765\u924f", "\udbd4\udeee\ud996\udf63\udaad\udd3a\uda96\udc63\udb82\udd2f\ud9a5\uddb6\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\udb36\udd8b\uda1b\udea0\ud9fb\udf7f\udb53\udeb9\ud92f\udfae",
        -1, 31828, -1856701476, 6308587878107043982L, -70623L, false, false, (char) 30345, (char) 58948,
        Double.longBitsToDouble(0x3fb4d1885aecd828L), Double.longBitsToDouble(0x3fef149d18028a98L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[B:[[110, 122, 65, 48, 89, 116, 51, 81, 13, 10]] |a0=[B:[[-97, 48, 52, 98, -35, -48]]\012",
        Z.run(T, 1, 14, 0, 0, "\ud8cf\ude60\ud964\udc92\015\000", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud9e3\udd22\ud9f9\udef8",
        -5, 61129, 843579475, -3796984368090622818L, 48547L, true, true, (char) 32683, (char) 31247,
        Double.longBitsToDouble(0x3fe7912deedc0cf7L), Double.longBitsToDouble(0x3fcedb4c7127ba04L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-92, 10, -11, -60, 0, 25, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\udad4\udf3a\uda25\udff4\ud830\ude49\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud9c5\udf43\ud901\udcb4\udb0c\udf10\ucb2a\ud97e\ude78\ud8a9\udcc6\ud938\udd7e\ud8cd\uded7\ucca9\udbbd\udf75\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368090622818L, 48547L, true, true, (char) 6210, (char) 31247,
        Double.longBitsToDouble(0x3fe7912deedc0cf7L), Double.longBitsToDouble(0x3fe7b6d31c49ee81L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 2, 9, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\udbf3\ude8a\ud892\udd3c\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368090622818L, 48547L, true, true, (char) 6210, (char) 31247,
        Double.longBitsToDouble(0x3fe7912deedc0cf7L), Double.longBitsToDouble(0x3fe7b6d31c49ee81L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-97, 48]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 11, 13, "\ud8cf\ude60", "\u33bc\ucef1\u3682\u0a3e\u5b28\ua5b0\u1f23\ub9f0\ua562\u94ee", "\ud88d\ude5f\ud951\udfe6",
        5, 3601, 266598775, -9036139262778698259L, 88387L, true, true, (char) 31801, (char) 15728,
        Double.longBitsToDouble(0x3fd871a8612cbc4eL), Double.longBitsToDouble(0x3fefb1b920e8e7e6L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u1f19", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8\ud8d8\udded\udaca\udfde\uda65\udc49\u8bbb\uda47\udf17\ud973\udd56\udb3a\udc68\u09ab\uda0e\udd40\uda1f\udc4e\ud909\udf29\ud973\udffb\uda80\udfb5\uda21\udca4\ud831\uddee\ud9c2\udd4c\udab7\ude7e\uda07\udeaf\uda60\udf44\udae2\udfbc\udbd1\udca6\udbda\udf7d\udb3b\udce6\uda5e\udcaf",
        -1, 59100, 1415625519, 3819134723187724655L, 51339L, true, true, (char) 17869, (char) 63437,
        Double.longBitsToDouble(0x3fedd6b320131f05L), Double.longBitsToDouble(0x3fda6ea2453ee480L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[B:[[110, 122, 66, 120, 103, 97, 119, 85, 120, 82, 69, 61]] |a0=[B:[[-97, 48, 113, -127, -84, 20, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 5, 17, "\ud8cf\ude60\udba1\udeb1\udadc\udc44\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\udbd3\ude17\ud9bd\udc91\udade\ude66\ud843\udf40\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\uda78\ude59\ud9a3\udf5b\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368090622818L, 48547L, true, true, (char) 1196, (char) 31247,
        Double.longBitsToDouble(0x3fba496f76e067b8L), Double.longBitsToDouble(0x3fe7b6d31c49ee81L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[B:[[110, 122, 65, 48, 89, 111, 116, 71, 120, 82, 69, 61, 13, 10]] |a0=[B:[[-97, 48, 52, 98, -117, 70, -59, 17]]\012",
        Z.run(T, 1, 15, 7, 18, "\ud8cf\ude60\ud964\udc92\udabb\udc76\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\ud110\u3555", "\ud9c5\udef6\ud9bd\udcd2\uda80\ude57\udba4\udcf8\ud97e\ude78\ud8af\udcc9\ud852\udc86\ud8bf\uddc8\uda05\udcd2\ud9dd\udef6\uda95\udd1e\udb82\udfd5\ud99f\ude8a\ud94b\udfcf\ud9fc\udcef",
        7, 12383, -491827270, 7026509621115321166L, 69277L, true, false, (char) 30999, (char) 63692,
        Double.longBitsToDouble(0x3fecb4c55ec27c4dL), Double.longBitsToDouble(0x3fe08c8d6edc0cf7L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 14, 17, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82", "\u3682\u0a3e\u5b28\u8dfc\u1f23\u9f46\ua562\u94ee\u71cf\u3552\u9202", "\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8\ud8d8\udded\udaca\udfde\uda65\udc49",
        21, 65126, -1856701476, 6308587878105751182L, 30498L, false, false, (char) 19411, (char) 55641,
        Double.longBitsToDouble(0x3fb27ba063514378L), Double.longBitsToDouble(0x3fa46c3dd2ae0370L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 14, 8, 2, "\ud997\udc4e\ud964\udc92\ud9d3\udc82\ud9f5\udf41\ud8f1\udf25\ud925\ude09\ud98c\uddf9\udbc2\udfcb\uda23\udda8\ud9a2\ude5b\ud9fe\udce9\ud92b\udf97\uec51\uda2d\ude03\udad9\uddf2\ud88d\ude5f\udafa\udd5b\u81f0\ud9bd\udce6\udade\ude66\ud843\udfd3\ud880\ude0c\ud8d4\udd2d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud904\udee5\udbc9\uddbf\ud99f\ude8a\udb53\udd7a\uda82\udfcb\ud936\udc07\udabb\udc7e\uda65\udc49\u8bbb\udaf6\ude6e\ud973\udc93\udb3a\udc68\udb80\uddd8\uda0e\udd8e\ud828\udf08\ud909\udee9\ud8a3\udf45\uda3d\uddb4\uda21\udca4\ud831\uddee", "\u064d\u87f6\u7dab\u30c6\uc015\u8421\u5998\u36be\u814f\ub4eb\ua0d4\u7410\u55d8\u9782\u7214\u9b85\u53ba\ub771\u2cba\u67b0\u20ec\u69d3\ub057\u3f24\uac72\u1bc5\u4f9a\ua131\ua253\u8128\ub7cb\u7919\u2d41\ua298\uaf00\u4273\u5667\u2a04\u75e6\u1ed5\u5826\ubd79\u139e", "\udb31\udeb9\ud94d\ude11\ud8f1\udcbf\u5024\ud95f\udcb5\ud8bd\ude71\udb7a\uddf3\ud90a\udc08\uda4e\udf82\ud909\udf41\udb4e\udde3\ud8e0\udf47\ud893\udc25\uda85\udc10\ud97f\udc2e\uda4c\udff6\udb4e\udc50\ud886\udce3",
        17, 63697, -1290029741, -1812423839125252074L, 35838L, true, true, (char) 23674, (char) 50878,
        Double.longBitsToDouble(0x3fe0a25b4bafd3c5L), Double.longBitsToDouble(0x3fd8c6b4db8fec74L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[10, -94, 52, -125, -78, -81, 125, -23]]\012",
        Z.run(T, 1, 5, 9, 12, "\uda3a\udcd2\ud964\udcb3\ud8e2\udcdf\ud8ad\udf19\ud8f1\udf25\ud925\ude09\ud890\udd34\udad9\udc88\udb3d\udc79\udb61\udf3b\ud95b\udcf4\udb0f\udf01\ud986\udd4b\ud9f6\ude83\udad9\uddf2\ud88d\ude5f\ud951\udfe6\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\uda6f\udfec\uda6b\udca4", "\u70eb\u7ad1\u865c\u64a9\u3b66\u00dc\uc65a\u36fc\u0fc0\u3cec\u085a\u3580\uc0b1\u7b03\ubd2a\u30a0\u1ea7\u0a6a\u627d\ua250\uca47\u8a3a\u6393\u3cef", "\uda1a\udff8\uda54\ude62\u6241\udaaf\udfd4\ud8e4\ude52\udaab\udfa1\udb45\udc04\ud8ef\udd43\ud8bc\udc50\uda5f\udcf6\ud8cc\udd52",
        9, 96933, -2049915452, 512489673140445921L, -42704L, true, false, (char) 50003, (char) 57248,
        Double.longBitsToDouble(0x3fabc2cdc894e9a0L), Double.longBitsToDouble(0x3fe4d5b5e339d270L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]]\012",
        Z.run(T, 2, 16, 7, 14, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368090622818L, 48547L, true, true, (char) 6210, (char) 31247,
        Double.longBitsToDouble(0x3fe7912deedc0cf7L), Double.longBitsToDouble(0x3fe7b6d31c49ee81L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[B:[[110, 122, 65, 48, 89, 113, 78, 83, 120, 82, 69, 13, 10]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]]\012",
        Z.run(T, 1, 15, 9, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u0d06", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 954587475, 6109638917412050087L, 48547L, true, true, (char) 6210, (char) 31247,
        Double.longBitsToDouble(0x3fe7912deedc0cf7L), Double.longBitsToDouble(0x3fe7b6d31c49ee81L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 4, 17, 10, "\ud8cf\ude74\ud964\udc92\ud9d3\udc82", "\u3682\u9a8b\u8309\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552\u9202", "\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\uda23\udfca\ud8d8\udded\udaca\udfde\uda65\udc49",
        21, 65126, -1848708267, 6308587878105751182L, 30498L, false, false, (char) 19411, (char) 55641,
        Double.longBitsToDouble(0x3fb27ba048c8d7d8L), Double.longBitsToDouble(0x3fe14125fa6d8711L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[-31, -80]] |a0=[B:[[-97, -102, 52, 98, -97, 68, 23]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 16, 12, "\ud8cf\uddca\ud964\udc92\udacf\udc74G", "\000", "\ud9a2\ude5b",
        0, 45443, 605020721, -3851728688862579955L, 79062L, false, true, (char) 30648, (char) 20750,
        Double.longBitsToDouble(0x3fe9b87f1ded8299L), Double.longBitsToDouble(0x3fe17a68e81d9f5fL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[B:[[-7, -83, 52, 29, -93, 82, -59, 17]] |a0=[B:[[-7, -83, 52, 29, -93, 82, -59, 17]]\012",
        Z.run(T, 1, 9, 11, 8, "\ud829\udedd\ud964\udd4d\ud9d3\udc82\ud9f5\udf41", "\u6b22\ud20b\u67f2\u5417\ub9f0\ud48f\u0535\u98d2\u1a6a\u84d9\u04bc\u874f\ua166\u544c\u8302\u6502\u7ba9\u681e\u38ea\uc6d7\u3810\u5f53\u709a\u3b66\u6269\uc65a\u2062\u0f81\u8470\uc6e2\ud329\u9c56\ud58a\ubd2a\u30a0\u1ea7\u0ae9\u627d\ua250\uca47\u8a3a\u2b73\uc1e2\u15f1\u68e9\ucd75", "\ud9fd\udcb3\uda32\udf9c\ud857\udcbe\ud9c3\udc4f\uda13\ude70\ud91e\udda6\ud893\udc60\ub545\udb8c\udf31\ud9fe\udc95\u7a7c\ud8f0\udec6",
        9, 92973, -1177548137, 7922788040933621693L, 9112L, false, true, (char) 54164, (char) 8877,
        Double.longBitsToDouble(0x3fd26a2980c938beL), Double.longBitsToDouble(0x3fdeba4a2f47dfa6L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-20, 114]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[55, 72, 73, 61]] |a0=[B:[[-20, 114]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 10, 9, "\uda1c\udfa2", "\u33bc\ucef1\u3682\u0a3e\u6915\u4f92\u3996\u3569\u42e4\u94ee", "\ud88d\ude5f\ud9b1\udd0d\udb14\udd84\ud9bd\udcd2\udae2\udc53\udb83\udfe0\ud850\udeff\udbf6\udee2\ud8aa\udc7d\udad3\ude1c",
        4, 91862, 690430343, 1685806415968888014L, 16245L, false, false, (char) 4622, (char) 40704,
        Double.longBitsToDouble(0x3fe2de27549ef3c6L), Double.longBitsToDouble(0x3fb6b94fdaea5760L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 17, 9, 12, "\ud8cf\ude6f\ud964\udc92\ud9d3\udc82\ud9f5\udf41\u87db\ud9df\udd08\ud937\udc8c\ud816\udec1\uda59\udd82", "\uc822\u94ee\u71cf\u3552\u42e5\u8742\u4a06\uce74\ua65f", "\ud8d4\udc7d\ud965\udfd9\ud8e0\udc1b\ud8f2\udea6\uda0a\uded4\udabc\udf03\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud80c\udf42",
        49, 32650, -1633104439, -5090989811301479228L, -62722L, true, false, (char) 53120, (char) 28019,
        Double.longBitsToDouble(0x3fd9925025716a60L), Double.longBitsToDouble(0x3fe7b6d31f49ee81L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 7, 17, 12, "\u82d9\udb44\ude5b\uc9d8\udb19\ude63", "\uc430\u5b28\ua0a3\u9479\u6ce8", "\ud884\uddd9\ud996\ude39\udbed\udcf7\ud99f\udf8e\ud9f3\uddd7\ud853\udfee\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud8cc\ude60\udb57\udf13\udb7c\udec8\u605a\udad7\udc61\uda65\udc49\u8bbb\uda47\udf17\ud973\udd56\udb1f\udc68\u09ab\uda0e\udd40\ud828\udf08\ud909\udee9\ud973\udffb\uda80\udfb5\uda2c\udfa4\ud9d0\udcbe\udab5\udf29",
        0, 77938, -2003002373, -2868837977620425739L, -38582L, true, false, (char) 44397, (char) 3672,
        Double.longBitsToDouble(0x3fe91ee3952bb3c1L), Double.longBitsToDouble(0x3fd4f15e7ca045deL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[102]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\u0096", "\u33bc\ucef1\u3682\u0a3e\u5b28\u8dfc\u1f23\ub9f0\000\u94ee", "\ud88d\ude5f\ud951\udfe6\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9",
        4, 44750, 1579622791, 3973310211181434870L, 12026L, false, false, (char) 4622, (char) 45550,
        Double.longBitsToDouble(0x3fe6b192449ecb4eL), Double.longBitsToDouble(0x3feee511fb409154L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-78, -109, -12, 60, -72, 61, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 12, "\ud9e2\udec3\ud824\ude6c\ud9e8\udf6d\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\ub193\ub149", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\uf4dd\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368090622818L, 48547L, true, true, (char) 6210, (char) 31247,
        Double.longBitsToDouble(0x3fe5ff1e22d21dcaL), Double.longBitsToDouble(0x3fefb1c8e97df15fL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[B:[[-47]] |a0=[B:[[-97, 48, 37, -4, 34, 90, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[-97, 48, 37, -4, 34, 90, -59, 17]] |a0=[B:[[-97, 48, 37, -4, 34, 90, -59, 17]]\012",
        Z.run(T, 2, 16, 9, 5, "\ud8cf\ude60\ud955\ude2c\ud852\udf8a\ud9f5\udf41", "\u6ba5\u795f\u6498\u8a56\u2154\u890e\ud33a\u9006\u479f", "\ud8d0\udf0e\udb97\udf48\udb15\udda0\ud8d9\udd20\ud97e\ude78\ud8d4\udc7d\udb77\ude79\ud950\udef2\uedb7\ud9a2\udd7f\ud9c7\uddf7\u8e88\ud995\udc3c\ud99f\ude58\ud88b\udde8",
        33, 50825, 1787910837, -3796845125250886498L, 48547L, true, true, (char) 6210, (char) 1460,
        Double.longBitsToDouble(0x3fe1ae45eedc0cd7L), Double.longBitsToDouble(0x3fe7b6d31e49ee81L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 18, 2, "\ud8cf\ude60\ud9ff\udea0\ud9ad\udfb3", "\u3682\ucd96\u2a7a\u8dfc\u1f23\ub9f0\ua562\u94ee\u319e\u560a\u91c2", "\ud9bd\udcd2\udade\ude66\ud800\udd50\ud8fd\uddde\udbf3\ude50\ud978\uddb4\udad9\udeb6\ud8ef\udcd9\ud89f\udce9\ud9a3\udf13\udb82\udfd5\ud89a\udcd9\uda37\udff9\ud9f9\udef8\ud8d8\udded\ud890\udf00\ud8f5\udee6",
        26, 65212, -1856701476, 9134342734398798534L, 30498L, false, false, (char) 19411, (char) 25689,
        Double.longBitsToDouble(0x3fb24bd3cf58c758L), Double.longBitsToDouble(0x3fe17d1ce9c2197cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 1, 18, 4, 4, "\ud8cf\ude60\ud964\udc92\ud906\udee4\ud824\udd0c", "\u9a4e\u5b28\uaf8b\u279b\u392c\ua562\u0148\u9d2e\u2571", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66",
        39, 39541, -1620189137, 1945871821247949775L, -81800L, false, false, (char) 46954, (char) 53390,
        Double.longBitsToDouble(0x3fd53d89bdac6490L), Double.longBitsToDouble(0x3fc29969cf72b794L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-81, -81, 108, 65, -93, 82, -59, 17]]\012",
        Z.run(T, 1, 5, 13, 18, "\ud8df\udfdf\ud89c\udc71\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\uc501\u1f23\u1289\uadca\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udb4e\udc46\udbbf\udc55",
        22, 17892, 453058589, -7211107139345260468L, -68822L, false, true, (char) 57953, (char) 61266,
        Double.longBitsToDouble(0x3fe336058cfc5b96L), Double.longBitsToDouble(0x3fe5f79e81532e9bL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 1, 15, 16, 18, "", "\u98d5\u33bc\000\ub07e\u0a3e", "\ud9a2\udd87\ud9fe\udce9\ud92b\udf97\uec51\uf12a\udad9\udde5\u826a",
        17, -1000, 1469513728, 1080864421670027319L, -23249L, false, false, (char) 62207, (char) 15373,
        Double.longBitsToDouble(0x3fc2cbc4ffd8dc90L), Double.longBitsToDouble(0x3f4cfcc99b036c00L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=[B:[[110, 121, 52, 48, 89, 113, 78, 83, 47, 119, 61, 61]] |a0=[B:[[-97, 46, 52, 98, -93, 82, -1]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 9, 12, "\ud8cf\ude5e\ud964\udc92\ud9d3\udc82\u832f", "\u0a3e\u5b28\u8dfc\u1f23", "\uec51\uda2d\ude03\udad9\uddf2\ud88d\ude5f\ud951\udfe6",
        5, 3601, 266598775, -9036139262778698259L, 88387L, true, true, (char) 31801, (char) 15728,
        Double.longBitsToDouble(0x3fd871a8612cbc4eL), Double.longBitsToDouble(0x3fefb1b926e8e7e6L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.math.BigInteger:13862609 |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]]\0121=java.lang.Boolean:true |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]]\012",
        Z.run(T, 2, 8, 5, 5, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ud8e5\udc21\ud868\udc12\ud9a3\udf24\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        19, 68879, 843632576, -3796984368090622818L, -74208L, false, false, (char) 30999, (char) 44493,
        Double.longBitsToDouble(0x3fecb4c55dc27c4dL), Double.longBitsToDouble(0x3fe7912deedc0cf7L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 1, 0, 18, "\ud8cf\ude60\ud996\udc8b\ud9d3\udc82\ud9f5\udf41", "\u0a3e\000\u8dc3\u1f23\ub9f0\ua562\u94ee\ua92a\u3552", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ud97b\udc5c\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f",
        44, 51476, 0, 3602879701901534934L, -100000L, false, false, (char) 30234, (char) 30999,
        Double.longBitsToDouble(0x3fd1f54aef2d3156L), Double.longBitsToDouble(0x3fdc27c4d5e44b7aL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[102]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 17, 4, "\u0096", "\u33bc", "\udb6c\udce9",
        32, 53193, 1858749184, -7133580074074243072L, 96608L, true, true, (char) 45971, (char) 17192,
        Double.longBitsToDouble(0x3e4ea76000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 1, 9, 12, "\ud8cf\ude60\ud964\udc92\ud903\udf1a\ud9f5\udfed\ud8f1\udf25\u94e9\ud867\ude8a\uda77\udf25\uda58\udcbb\ud9a2\ude5b\ud9fe\udce9\udac4\udde3\uec51\uda2d\ude03\udad9\uddf2\ud88d\ude5f\ud951\udfe6\ud9c5\udf01\ud9bd\udcd2\udbb9\udfb3", "\u7ba9\u681e\u5533\u600d\u92d6\u291e\u59f0\u3b66\ud611\uc65a", "\ud893\udf84\ud90b\udd2b\uda47\udf17\ud973\udd56\udb3a\udc68\u09ab\uda0e\udd40\ud828\udf08\ud8b3\udfdf\ud88b\udc3c\uda59\udf56\uda21\udca4\ud831\uddee\udb5e\ude79\udb7b\udf75\udb41\udccd\ud95c\udc99\udba2\udf56\ud8d1\ude6c\ud803\udf94\udb4f\udfcd\ud9ca\udcd2\uae48\udb39\udfcb\uda0f\udeb7\ud822\uddfa\uda44\udf9d\ud83a\udd4c\ud88e\udcee\udbb8\udc45\ud885\udcaf\ud949\udef2\uda9b\udc08",
        45, 56426, -1112935661, 5383137680825247721L, -21077L, false, true, (char) 29539, (char) 11197,
        Double.longBitsToDouble(0x3f97fa39f01d44c0L), Double.longBitsToDouble(0x3fef822e3b1696a5L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[49, 52, 98, -45, -22, -59, -67]]\012",
        Z.run(T, 1, 5, 16, 0, "\u5161\ud964\udc92\ud903\udf1a\ud9f5\udfed", "\u5878\ub8f6\u2c1b\u0e6c\u2867\ubbef\u94ee\u71cf\u3552", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb6\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud981\udd8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635007, 598488186292753566L, 48547L, true, true, (char) 64162, (char) 8832,
        Double.longBitsToDouble(0x3fe7912deedc0cf7L), Double.longBitsToDouble(0x3fe7b6d31f5ad76fL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 15, 17, 12, "\000", "", "",
        -5, 31996, -1431287739, 28684304171811796L, -100000L, true, false, (char) 3385, (char) 64920,
        Double.longBitsToDouble(0x3fe3518953764328L), Double.longBitsToDouble(0x3fd5c4b52f53b01eL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 1, 9, 9, "\uda83\udf3e\ud964\udc92\ud935\udf13\ud9f5\udfed\ud8f1\udf25\ud925\ude09\udab3\udeec\ud874\udf5e\ud95e\udffe\ud9aa\udfca\ud9fe\udce9\udac4\udde3\uec51\ud946\udc40\udb06\uddf6\ud88d\ude5f\uda47\udfe3\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud92a\udf88\ud81f\ude7f\ud9b7\ude32\uda5a\udd72\udaca\udfde\ud8b9\udcb3\udbcf\udf39\udb5f\udc19\udbe7\udf24\udb9d\udff4\u09ab\ud94c\ude69\ud844\udd08\ud909\udee9\ud973\udffb\uda80\udfb5\ud9f6\udfef\ud843\udd7a\udba9\udf55", "\u39db\ud173\u1660\u6d66\ua49f\u728c\u8692\u3691\u9ede\u901b\u0f55\u03b5\uc7a7\u4f84\u8eff\u7051", "\ud8d6\udcc7",
        30, 2316, 2137200591, -8127044915527000856L, 59102L, false, true, (char) 29976, (char) 27950,
        Double.longBitsToDouble(0x3fe845bb6256c92bL), Double.longBitsToDouble(0x3fdc2ee74e9f0df8L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=[B:[[-97, 48]] |a0=[B:[[-97, 48]]\012",
        Z.run(T, 1, 9, 5, 6, "\ud8cf\ude60", "\u33bc", "\udab3\udeec\udbc2\udf3d\uda23\udda8\u38f1\ud82b\udebf\ud92b\udf97\uea31\uda2d\ude03\udb29\uddfa",
        28, 142, -670045860, 6311688951247927671L, 58227L, true, false, (char) 49020, (char) 18128,
        Double.longBitsToDouble(0x3fb3003b5b325050L), Double.longBitsToDouble(0x3fd871a8612c004eL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 18, 1, 11, "\ud8cf\ude60", "\u3639", "\udab3\udeec\udbc2\udf3d\uda23\udda8\ud9a2\ude5b\udb77\udec5\ud92b\udf97\uea31\udbd4\udfb7\udad9\uddf9",
        28, 142, -670045860, 6311688951247927671L, 58227L, true, false, (char) 49020, (char) 18128,
        Double.longBitsToDouble(0x3fb3003b5b325050L), Double.longBitsToDouble(0x3fd871a8612c004eL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-18, -120, 15]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 12, 10, "\uc31e\ud8b8\udf3f", "\ucef1\u3682\u0a3e\u5b28\u2b06\uc98e", "\uea31\uda2d\ude03\udad9\uddf2\ud88d\ude5f\ud951\udfe6\uda99\udc8a\udb26\udcfa\ud91f\udd86\uda20\udfdd",
        32, 41206, -1447516899, -1617456467546215992L, 30046L, false, true, (char) 6112, (char) 26405,
        Double.longBitsToDouble(0x3fe05b9d4e934fe2L), Double.longBitsToDouble(0x3fe16ebec53a6794L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-105, -103, 39, -93, 82]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[108, 53, 107, 110, 111, 49, 73, 61]] |a0=[B:[[-105, -103, 39, -93, 82]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 10, 8, "\udac7\udcc9\u7557\ud9d3\udc82", "\u3682\u0a3e\u5b28\u8dfc\u1ef1", "\ue831\udad6\udcd7\udad9\udecd\udac8\uddc8\ud951\udfe6\ud9c5\udf01\ud9bd\udcd2\udade\ude5c\ud843\udfd3\udb14\udfaa\udb39\ude30\ud978\udddb\udbe6\udfdc\ud81b\ude7c\ud89f\udd1a\ud90e\udd89\ud881\udc74\ud83a\udc00\uf44c\ud90b\udd50",
        41, 408, 1697534711, -2888521744788363139L, 43182L, true, true, (char) 20827, (char) 20413,
        Double.longBitsToDouble(0x3fb3d9fe21454788L), Double.longBitsToDouble(0x3fb0de49730aa750L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[9, 74]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[74]] |a0=[B:[[9, 74]]\012",
        Z.run(T, 2, 16, 9, 12, "\ud939\udf7a", "\u870d", "\udbaa\udf0c\ud905\udc77\ud92a\udcf2\ud8d5\udd0a\ud82b\udebf\ud92b\udf97\uea31\uda2d\ude03\u76d5\udb5c\ude16\ud952\udc2f\ud9c5\udf01\ud9bd\udcd2\uda5a\ude64\udaf5\udd37\udaf0\udd8c\ud8d4\udc7d\ud978\uddb4\udb02\udf85",
        5, 44797, -1238949497, 8665948736997632071L, -47501L, true, true, (char) 5374, (char) 16725,
        Double.longBitsToDouble(0x3fe129530bcaad93L), Double.longBitsToDouble(0x3fa75d1475302b80L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-58, -60, -22, 60, -94, 113]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[-58, -60, -22, 60, -94, 113]] |a0=[B:[[-58, -60, -22, 60, -94, 113]]\012",
        Z.run(T, 2, 16, 9, 12, "\ud8f6\udcf4\udb1a\ude6c\ud9d2\udfa1", "\u3682\u0a3e\u5b28\u9b1a\u04c1", "\uea31\udad6\uddf8",
        57, 42949, 1263713142, -2868061674263830615L, -22377L, true, true, (char) 11084, (char) 49020,
        Double.longBitsToDouble(0x3fed50d80c9a5fedL), Double.longBitsToDouble(0x3feb301ea9871a86L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=[B:[[48, 65, 61, 61]] |a0=[B:[[-48]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 0, 2, "\000", "", "\ud925\ude09\udab3\udeec\udbc2\udf3d\uda23\udda8\ud9a2\ude5b\ud82b\udebf\ud92b\udf97\uea31\uda2d\ude03\ud8c8\udef0\udb47\ude5c",
        17, -1000, 1469554432, 1145032506573664055L, -23249L, false, false, (char) 0, (char) 15373,
        Double.longBitsToDouble(0x3fc2c004fa245f84L), Double.longBitsToDouble(0x3fb567e08f511088L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=[B:[[110, 117, 86, 115, 121, 98, 120, 109]] |a0=[B:[[-98, -27, 108, -55, -68, 102]]\012",
        Z.run(T, 1, 15, 10, 3, "\ud9ce\udd15\ud99c\udff9\ud9ec\udd96", "\u2608\u0a3e\ucc73\u8dfc\u1f23\u9f46\ua562\uad28\u199a\u7411\u2c13\u0484", "\udade\ude66",
        50, 74567, -1621107153, 1945871822942448591L, -73298L, false, true, (char) 28866, (char) 34451,
        Double.longBitsToDouble(0x3fdc9e0cb72c7504L), Double.longBitsToDouble(0x3fe2d465e8f60dc7L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-42, 124]]\012",
        Z.run(T, 1, 5, 9, 18, "\uda06\udeac", "\u33bc\u854c\u6ffa\u5fb1\u6fda\u15b6\ubb73\u0767\ua562\u94ee", "\000",
        37, 88140, 1469554601, 1145033017674772279L, 22803L, true, false, (char) 14806, (char) 53990,
        Double.longBitsToDouble(0x3fd99554c0b43cb4L), Double.longBitsToDouble(0x3fe6b0ac72d7bb55L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |a0=[B:[[-97, 48, -97, -40, -119, -51]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 12, 0, 0, "\ud8cf\ude60\udacf\udc08\udab9\udcfd", "\u3d33\u5a5e\uab75\u8e77\u1f23\uc762\u84d2\u0eee\u1eb8\u00c9\u592f", "\uda02\ude96\ud825\ude77\ud9c9\udfda",
        56, -878, -1798094618, -7215703926105886812L, -70425L, true, false, (char) 3866, (char) 32128,
        Double.longBitsToDouble(0x3fe043860e9352bcL), Double.longBitsToDouble(0x3fe9f1e673cf8c85L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[-97, 48]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 18, 3, 2, "\ud8cf\ude60", "\ua9bc\ucef1\u3682\u0a3e", "\udad5\udfe8\udb0c\udf20\ud92b\udf97\uec51\udae7\udc8c\u4fa5\000\ud8a4\ude5c\uda4b\udfa0\ud88f\udc55\udad8\udf3b",
        39, 74557, -1621126429, 1945871823372797135L, 93382L, true, true, (char) 26301, (char) 31662,
        Double.longBitsToDouble(0x3fb1f46413360588L), Double.longBitsToDouble(0x3fe2009f087a0e0dL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-22, -11, -62, -26, -78, 38, -59, 17]]\012",
        Z.run(T, 1, 5, 9, 10, "\ud91a\udd25\udaf2\udf16\ud9e2\udc56\ud9f5\udf41\uda33\udc7d\udaa3\udcb3\ud870\udd24\udbb8\udc40\uda23\ude0b\ud9a2\ude5b\ud942\udccb\ud841\udd7f\uec51*\000", "\u4a06", "\ud843\udfd3\udbd2\ude5c\ud8d4\udc82\uda3d\udcd6\ud8bf\udde9\u2956\ud8bf\udf2c\ud887\ude65\uda0f\udf7e\ud99f\ude8a\ud97d\udd2f\udb6c\ude71\udb6e\udfeb\ud9e7\udcb7\u5a17\ud9fe\uddba\ud805\ude00\uda33\udd43\ud8f9\ude77\udabc\udf23\ud90d\udd07\udab1\udd3d",
        3, 87124, -1254184917, 6902648217045095106L, 31919L, true, false, (char) 53599, (char) 28692,
        Double.longBitsToDouble(0x3faa966cc54b2770L), Double.longBitsToDouble(0x3fc654b0d3c96fd0L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]]\012",
        Z.run(T, 2, 1, 7, 4, "\ud961\udce8\ud92b\udf67\ud9d3\udc82\ud99e\udd4a\ud8f1\udf04\ud91b\udc5c\u2195\udabb\udf06\ud930\udd81\ud9a2\uddcf\ud9fe\udce9\ud92b\udf97\uec51\uda2d\ude03\u2b19\ud8fb\udd97", "\u8779\ube49\u7a07\u96a0\u03b6\u68a64\u600d\u92d6\u291e\u2df6\u27c6\u3d95\u4876\u20c5\u0f81\ua034\u0862\u3f2d\u31f2", "\udb70\udc31\udaf8\udfa8\uda0d\udca4\udb90\ude98\uda36\udcc3\uda11\udc6b\ud87f\udcd2\uda94\ude21\ud906\udeb8\udb3c\uddf2\udb7d\uddf5\ud985\udc19\udac3\uddac\udab0\uddc6\ud8f9\udc5c\udacd\udcd0",
        19, 83650, 254802554, 3873994749468796901L, 80908L, false, true, (char) 25740, (char) 63779,
        Double.longBitsToDouble(0x3feb9313f5a7888dL), Double.longBitsToDouble(0x3fec52697493c36dL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=[B:[[-126, 98]] |a0=[B:[[127, 103, 27, -124, 33, 126, 109, 73]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 0, 7, 4, "\ud9af\udc97\ud94b\udfb4\uce51\ud9ae\ude9d\ud879\udda5\ud803\udfae", "\u8e01\uced6\ub99e\u4897\u8bdb\u71cf\u3801\u629a\u2689\u49f9", "\ud85e\uddee\udb3a\udd37",
        57, 72589, -553214001, 5335323325228053350L, -53639L, false, true, (char) 6189, (char) 2914,
        Double.longBitsToDouble(0x3fcf89b2d8c54f74L), Double.longBitsToDouble(0x3fd53d89b7ac6490L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=[B:[[120, 50, 52, 122, 90, 109, 80, 82, 108, 109, 77, 61]] |a0=[B:[[-57, 110, 51, 102, 99, -47, -106, 99]]\012",
        Z.run(T, 1, 13, 12, 11, "\udbf7\udc9e\ua763\udb96\udd93\uda01\udfc6\ud893\udd44\ud925\ude09\u2195\udabb\udf06\uda23\ude1a\ud9a2\ude5b\ud923\udef8\ud872\ude82\uda8f\udc4f\uda2d\ude03\udad9\uddf2\ud978\udfea\uda5d\ude88\ud9c5\udf01\ud9bd\udcd2\udb2f\uddaf\ud844\udc25\ud97e\ude78\udbc8\udc77\ud988\udc83\ud54c\udab6\udd67\ud880\udc7c", "\ubdd6\u24e8\uc65a\u2062\u0fed\u46ba\u1f55\u84d9\u03c6\u3ff7", "\u3392\udb08\ude70\ud930\udf41\ud982\udcd2\udacb\ude9a\uda77\udecc\ua2a9\ud919\udfff\uda1f\udd10\udb03\udce4\ud893\udf4a\udb81\udfe6\udb2a\udc27\ud8a8\uddd3\ud805\udfbe\udab9\udc19\ud842\ude6d\uda35\udd38\uc38b\ud80f\udd4b\ud89c\ude84\uda8a\udf0a\udadc\uddf2\ud9c2\udd13\udac5\udf45\uda47\udc97\udb24\udc59\ud878\udcbd\uda5c\ude65\ud9ff\ude02\ud896\udc99\ua856\ud9b5\udf7a\udacb\udfc8\udb7c\udc85\uda43\udf0e\udb64\udf41\uda51\udf63\ud8f1\udd21\udba0\udcaa\udb49\udcf7\udb13\udf4b\udb75\ude81\u3bc1\udb87\udd6c\udb7a\udcf3\ud800\udd2a\ud991\ude9e\udb2b\udd09\ud891\ude9f\ud83f\udeec\ud886\udf30\uda4d\ude9e\ud96b\udc2e\ud8ca\udcbf\uda71\udc16\ud806\udee8\udaf2\udc93\ubf46\udab3\ude4b\uda5a\udd04\ud947\udcd6\uda04\udc5c\ud844\udddc\udb07\udca7\udb1b\udd1d\udaba\uddc1\ud8fb\udfc5\udbf4\udfc2\ud8bd\udf70",
        24, 1843, 1392048431, -6627484942169753047L, -21472L, false, true, (char) 15355, (char) 57253,
        Double.longBitsToDouble(0x3fcf162cc2e210fcL), Double.longBitsToDouble(0x3fa139e0af3d0950L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=[B:[[57, 49, 119, 48, 89, 113, 78, 83, 68, 82, 85, 61]] |a0=[B:[[-9, 92, 52, 98, -93, 82, 13, 21]]\0121=[B:[[-9, 92, 52, 98, -93, 82, 21]] |a0=[B:[[-9, 92, 52, 98, -93, 82, 13, 21]]\012",
        Z.run(T, 2, 13, 9, 12, "\uda27\udc8c\ud964\udc92\ud9d3\udc82\ud93d\udc45", "\u9420\u78d3\u816a\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud851\udec2\ud9a6\ude33\udb2f\uddaf\ud844\udc25",
        44, 42847, 453058589, -7211059259049844660L, 86358L, false, false, (char) 2914, (char) 6802,
        Double.longBitsToDouble(0x3fe18a9ee953d89bL), Double.longBitsToDouble(0x3fe6b192449ecb4eL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=[B:[[110, 122, 67, 66, 105, 109, 51, 107, 55, 48, 89, 61]] |a0=[B:[[-97, 48, -127, -118, 109, -28, -17, 70]]\012",
        Z.run(T, 1, 13, 9, 12, "\ud8cf\ude60\ud9b1\uddba\uda9d\udd14\uda1f\ude76", "\u9420\u61d3\u9dbc\u1f23\ub9f0\ua562\u94ee\u71cf\u3476", "\ud9c5\udf01\ud9bd\udcd2\udb2f\uddaf\ud844\udc25",
        47, 42847, 453058589, -7211059259049844498L, 57398L, false, false, (char) 48698, (char) 43948,
        Double.longBitsToDouble(0x3fc6f4eaaeb0ceb0L), Double.longBitsToDouble(0x3fc515e7e0f445e8L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.math.BigInteger:13862609 |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]]\012",
        Z.run(T, 2, 16, 8, 10, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41\udba4\udd9e", "\ud0c0\u05bf\u232a\u517d\u5771\u0918\u0219\ud46d\uc3bc\u1c3c", "\udade\ude66",
        39, 74557, 979338121, -7231709675016427825L, 93382L, false, false, (char) 44415, (char) 33310,
        Double.longBitsToDouble(0x3fcd1ce60db9253cL), Double.longBitsToDouble(0x3fe9659b5bbe7e9fL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=[B:[[]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 3, 3, "\ud8cf\ude60\ud964\udc92", "\u9bed\u88d3c\u5b28\u8dfc\u47a2\uaf78\u5771\u1018\u0219\ud46d\uab5b\u964c\u8649\ub583\u544c\u7296\u264f\u48e7\u2174\ub97f\u8f6a\u92d6\u5de7\u0662\u2220\u611e\uc60c\u6691\u0f81\ud4eb\u0862\u794b\uc329\u7ac7\ubd2a\u3141", "\ud804\udc24\ud8d7\udc42",
        2, 77068, 1626925519, 5163019575487922698L, -58496L, true, false, (char) 26680, (char) 19639,
        Double.longBitsToDouble(0x3fb1dca4ddbec990L), Double.longBitsToDouble(0x3fc0ba077df146e0L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]]\0121=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, -59, 17]]\012",
        Z.run(T, 2, 6, 6, 6, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41\udba4\udd9e\ud9f8\udc17\udbda\udef3\udbc2\udf3d\uda23\udda8\udbf5\udfe8\ud8a1\udfba\ud871\udfc4\ud8aa\udc5c", "\uc3bc\u1c3c\u4a06\u8779\u544c\u7296\ub952\u20b8\u5f6b\u08d0\u600d\u7aef", "\udaa6\udd83\udb53\udefa\ud9f9\udeaa\ud8b4\udc1d\udaca\udfde\uda65\udc49\u8bbb\ud9cf\udf6c",
        23, 89516, 886316686, 6101889597953497375L, 30498L, true, true, (char) 26441, (char) 28575,
        Double.longBitsToDouble(0x3fdd4723fc73dbb6L), Double.longBitsToDouble(0x3fdeeef6049b828cL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=[B:[[110, 122, 65, 48, 89, 113, 78, 83]] |a0=[B:[[-97, 48, 52, 98, -93, 82]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 7, 6, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82", "\u98b7\u5a59\u5b28\u5a6e\ucc04\u517d\u5771\u1018\u0219\ud46d\uc3bc", "\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\uda83\udef9\udb9e\udc73\udb32\udca1\ucca9\ud90b\udc4b\ud908\udd7a\uda2c\udc2b\udaa6\udd83\udb53\udefa\ud9f9\udeaa\ud8b4\udc1d",
        2, 96445, -204099436, -8792166258198967351L, -92178L, true, false, (char) 44374, (char) 6210,
        Double.longBitsToDouble(0x3fdc27c4d54111d4L), Double.longBitsToDouble(0x3fc5b95112bc4fd8L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null\012",
        Z.run(T, 2, 16, 14, 16, "\ud8cf\ude60\ud964\udc92\ud94b\uddbc\ud994\udd59\u080c\ud92a\udff0\ud97f\udd33\ud8cb\udc14\uda23\udda8\udad5\udd95\udb1e\uddf0\udb4b\udc4d", "\u033f\u48ec", "\ud9e3\udd6d\uda7d\udc9a\udb73\udc3e\ud9e2\udfca\ud8d4\udc7d\ud978\uddb4\udbc5\udd06\udb70\udc13\ud90a\uded5\ud94b\udc3c\udbe2\ude88\uda1e\ude43\ud97d\udd2f\ud9f9\udef8\udb24\udeed\ua245\uda4a\udf38",
        21, 65126, -1856701476, 6308587878105751182L, 31646L, false, false, (char) 48163, (char) 19095,
        Double.longBitsToDouble(0x3fe1b2933aaf7a20L), Double.longBitsToDouble(0x3fd7d8a9016cdca0L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=[B:[[110, 122, 68, 50, 111, 54, 50, 108, 114, 73, 111, 61]] |a0=[B:[[-97, 48, -10, -93, -83, -91, -84, -118]]\0121=[B:[[110, 122, 68, 50, 111, 54, 50, 108, 114, 73, 111, 61]] |a0=[B:[[-97, 48, -10, -93, -83, -91, -84, -118]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 13, 10, 12, "\ud8cf\ude60\ud826\uddd3\ud8dd\udfd5\udadc\uddba", "\u0a3e\u5b28\uc0b8\uc2e9\uc990\u35e7\ud15e\u720d\u3552", "\udbae\udcd7\udb65\ude47\udade\uddf8\udbf7\udfcd\ud97e\ude78\ud9ec\uddbb\udad2\udf2e\ud8bf\udde9\ucca9\ud8a4\udfaf\ud9cc\udc16\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud862\udc0c",
        -5, 61129, 843635027, 6195233084430857874L, 48547L, true, true, (char) 6197, (char) 31247,
        Double.longBitsToDouble(0x3fce44b7bfa433dcL), Double.longBitsToDouble(0x3fe4e71ea449ee81L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[61, 106, 16, -98, -99, 80, 3, 127]]\012",
        Z.run(T, 1, 8, 9, 12, "\ud86d\udf9a\ud940\udece\ud9cd\ude80\uda33\uddaf", "\u0a3e\u44ef\u3444\u816e\u7001\u7189\u0126\u720d\u5955", "\udbae\udcd7",
        35, 58665, -2109591753, 5556762360644914991L, -23249L, false, false, (char) 47316, (char) 2207,
        Double.longBitsToDouble(0x3fe8970ee0ffbed7L), Double.longBitsToDouble(0x3fcd1cf5699b036cL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.math.BigInteger:224 |a0=[B:[[52, -56, 36, -99, 80, 3, 127]]\0121=[B:[[-32]] |a0=[B:[[52, -56, 36, -99, 80, 3, 127]]\012",
        Z.run(T, 2, 8, 6, 11, "\u9964\udbf8\udd54\ud9cd\ude80\uda33\uddaf", "\u72da\u19ed\uc0b8\u816e\ub998\u7189\u0126\u69c1", "\ud882\ude7e\ud875\udc47\udb72\udef8\udade\uddf8",
        12, 74557, 260067119, -1286270926735443115L, 39329L, true, true, (char) 26301, (char) 3866,
        Double.longBitsToDouble(0x3fa950c32664da80L), Double.longBitsToDouble(0x3fcf8bfb78c54f74L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 3, 0, 12, "\000\000\000\ud9a1\udef0", "\u99c8\u5b28\uc0b8\u816e\000\u3e85\u0126\u720d\u3552", "\udbae\udcd7",
        47, -991, 0, 260046848L, -23249L, false, false, (char) 19019, (char) 0,
        Double.longBitsToDouble(0x3fc2c004e0000000L), Double.longBitsToDouble(0x3fcd1cfcc99b036cL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=[B:[[-59, -21, 15, -109, -50, 94, -58, -22]] |a0=[B:[[-59, -21, 15, -109, -50, 94, -58, -22]]\0121=[B:[[-59, -21, 15, -109, -50, 94, -58, -22]] |a0=[B:[[-59, -21, 15, -109, -50, 94, -58, -22]]\012",
        Z.run(T, 2, 9, 9, 15, "\ud9f5\udc1b\ud93f\udcc3\ud8fe\udf8e\ud8f6\udf1a", "\u69e0\u669e\u8dfc\u1f23\ub9f0\ua562\u94ee\u9aca\u3552\u9202\u04bc\u4a06", "\ud80d\udc3d\ud97e\udd98\udac8\udd57\udbff\udc7a\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud999\ude87\ud97d\udd2f\ud9fd\udfdc\udb08\udd1a\uda08\udd3a\uda33\udeb0\ud806\udf38\uda47\udee8\ud973\udd56\udb3a\udc68\u09ab\ud8ef\udc91\uda0f\udebb\ud909\udee9\ud973\udffb",
        47, 5452, -293474114, -131189017442408242L, 50225L, true, true, (char) 55777, (char) 12493,
        Double.longBitsToDouble(0x3fc73cf59ce94b6cL), Double.longBitsToDouble(0x3fedf936b2ee45e0L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 12, 12, "\udac2\ude9a\ud8b3\udcb8\u9eed\ud8f6\udea4", "\u22c2\ud252\u41c0\u1f0b\u2a4d\ua562\u94ee\u9aca\u0ffc\u6170\u429c\u0a1f", "\ud80d\udc3d\ud97e\udd98\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud999\ude87\ud97d\udd2f\ud9f9\udef8\udb08\udd1a\ud8ce\udfbd\uda33\udeb0\ud806\udf38\uda47\udee8\ud973\udd56\udb3a\udc68\u09ab\ud93e\udd38\ud828\udf08",
        18, 38258, 217572082, 460280701242175600L, 53394L, false, true, (char) 29992, (char) 35911,
        Double.longBitsToDouble(0x3fdd441a50661154L), Double.longBitsToDouble(0x3fb6e6d889babcb0L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 9, 15, "\udac2\ude9a\ud8b3\udcb8\u9eed\ud8f6\udea4", "\u936a\u6655\u8dfc\u1f23\ub9f0\ua562\u94ee\u9aca\u3552\u9202\u04bc\u4a06", "\ud80d\udc3d\ud97e\udd98\ud8d4\udc7d\udb57\udf07\ud8c3\ude98\ucca9\ud89f\udcf6\ud98d\udde9\ud9c2\udd11\ud800\udd06\uda8a\udfbf\ud91a\udc8f\udb08\udd18\ud9ae\udf97\udbef\uded8\ud806\udf13\uda47\udee8\ud973\udd56\udb2f\uddec\ud835\udf0b\uda2c\udd45\ud828\udfda",
        18, 38258, 217572082, 460280701242175600L, 53394L, false, true, (char) 29992, (char) 35911,
        Double.longBitsToDouble(0x3fdd441a51eb1554L), Double.longBitsToDouble(0x3fb6e6d889babcb0L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 14, 13, 15, "\udac2\ude9a\ud8b3\udcb8\u9eed\ud8f6\udea4", "\u22c2\u669e\u8dfc\u1f23\ub9f0\ua562\u94ee\u9aca\u3552\u9202\u04bc\u4a06", "\ud80d\udc3d\ud97e\udd98\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud999\ude87\ud97d\udd2f\ud9f9\udef8\udb08\udd1a\uda08\udd3a\uda33\udeb0\ud806\udf38\uda47\udee8\ud973\udd56\udb3a\udc68\u09ab\uda0e\udd40\ud828\udf08",
        18, 38258, 217572082, 460280701242175600L, 53394L, false, true, (char) 29992, (char) 35911,
        Double.longBitsToDouble(0x3fdd441a50661154L), Double.longBitsToDouble(0x3fb6e6d889babcb0L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 8, 15, "\udac2\ude9a\ud8b3\udcb8\u9eed\ud8f6\udea4", "\u22c2\u669e\u8dfc\u1f23\ub9f0\ua562\u94ee\u9aca\u3552\u9202\u04bc\u4a06", "\ud80d\udc3d\ud97e\udd98\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud999\ude87\ud97d\udd2f\ud9f9\udef8\udb08\udd1a\uda08\udd3a\uda33\udeb0\ud806\udf38\uda47\udee8\ud973\udd56\udb3a\udc68\u09ab\uda0e\udd40\ud828\udf08",
        18, 38258, 217572082, 460280701242175600L, 53394L, false, true, (char) 29992, (char) 35911,
        Double.longBitsToDouble(0x3fdd441a50661154L), Double.longBitsToDouble(0x3fb6e6d889babcb0L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=[B:[[-31, -76, 111]] |a0=[B:[[-97, -12, 52, 98, -93, 82, 118, -50]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[-97, -12, 52, 98, -93, 82, 118, -50]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 12, 0, "\ud8cf\ude24\ud964\udc92\ud9d3\udc82\udaa6\udffe\ud854\udf4a\udba4\ude95\ud8b8\udf7a\udbc2\udf38\uda23\udda8\ud9a2\ude5b\ud9fe\udce9", "\u7230", "\ud951\udfe6\ud9c5\udf01\ud9bd\udcd2\udade\ude66",
        14, 11701, 2055885764, 1998928862220463055L, 93382L, true, true, (char) 26301, (char) 3866,
        Double.longBitsToDouble(0x3fcd1cfcc99b036cL), Double.longBitsToDouble(0x3fcf836558c54f74L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[113, 23, 30, 10, 41, -66, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[113, 23, 30, 10, 41, -66, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 0, 1, "\ud9a1\udc47\uda4e\udc3a\uda59\uddee\ud9f5\udf41\ud8f1\udf25\ud925\ude09\udab3\udeec\ud9a8\udf4f\uda23\udda8\ud821\uddba\u7b95\ud9a4\udd6d\uda6e\udc33\udbdf\udebb\udacf\udf4d\u262e\ud951\udfe6\udb23\udd03\ud9bd\udcd2\udade\ude66\uda13\udf9a\ud81d\udd07\ud8ab\udfd4", "\u6033\u92d6", "\uda37\udfdb\udb0a\udd64\udbcf\udf2b\ud8d8\udda2\uda04\ude5b\udac5\udd7d\udbfa\udf18\ud99a\ude3e",
        26, 84399, 1816278239, -3389167081176279982L, -87810L, true, false, (char) 20519, (char) 46364,
        Double.longBitsToDouble(0x3fe1ffb3c84cac6bL), Double.longBitsToDouble(0x3f95b7564ce4aba0L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 1, 1, 7, "", "\000", "\uda8b\uddcb",
        28, 83261, 124069740, 7983267865535505848L, -92369L, false, true, (char) 64920, (char) 57470,
        Double.longBitsToDouble(0x3febb22e215c4b52L), Double.longBitsToDouble(0x3fed7794c7354dd6L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=[B:[[-47, -47, 98, 30, 119, -46, -78]] |a0=[B:[[-47, -47, 98, 32, 30, 119, -46, -78]]\012",
        Z.run(T, 1, 9, 5, 14, "\udb01\udf01\uda92\udf50\ud94e\udda7\uda02\udee2\ud940\udc9d\u15d5\udaa3\udec5\udbc2\udf3d\udba2\udc37\udac3\udd3e\ud8d4\ude97\ud8f7\udfa8\uec51\ud9ff\udf03\ud98b\ude6b\udad9\udc28\ud872\udcd7\uda9f\udea8\ud915\udfbe\udb7b\udd1f\uda27\udc08\udb72\uded9\ud878\udc28\ud8f7\udc3d\udbdf\ude5c", "\u51bf\u910a\ub04e\u6f3c\ud765\ubdfb\u6c34\u4b4c", "\ud927\uddd3\uda50\udc28\ud941\udec6\ud73b\udb89\udcb1\ud9ce\udd28\ud8b5\uded5\udbd1\uddcf\uda63\ude05\uda0e\udf4b\ud9de\udc72\udb46\udd7a",
        48, 205, -406046723, -1733462344816098610L, -41438L, false, false, (char) 58001, (char) 45455,
        Double.longBitsToDouble(0x3fdeed25a88c93eeL), Double.longBitsToDouble(0x3fb7adebd917adc8L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=[B:[[107, 81, 69, 111, 13, 10]] |a0=[B:[[-111, 1, 40]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 3, 15, "\u29c1\ud931\udf58", "\u73c2\u2f98", "\ud97e\udcf5\ud839\udc01\ud96c\udcfe\ud9fb\udc41",
        23, 62592, 824854797, 3515682288524572298L, 72897L, true, false, (char) 32956, (char) 35722,
        Double.longBitsToDouble(0x3fd342d69cc33156L), Double.longBitsToDouble(0x3fec7ad4fecff0dfL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 10, 7, 16, "", "\u0fa0\000\uce4c\u3682\u0a3e\u5b28\u8dfc\u1f23\ub9f0\u109b\u3731\u1287\u3552\ub2d7", "\udb35\udf03\ud93a\udd90\uda97\udebd\udab2\udf9a\udb2c\uddba\ud848\udf57\ud9bb\udf1b\ud80e\udc31\uda77\udebf\ud838\udcba\ud8cc\udf59\udbf6\udc07\ud854\ude2d\uda4c\udc6e\udb32\udf66\ud9c0\udf0b\ud84a\ude5a\ud81e\ude23\udb3d\udd0c\udb81\udc3d\udb44\udcf8\ud85f\uddd3\ud908\ude57\uda2a\udd34\udb0c\udfae\ud9eb\udfc7\ud9d7\ude28",
        42, 40400, -1094664651, -605876678023206169L, 81509L, false, false, (char) 11652, (char) 34013,
        Double.longBitsToDouble(0x3fe147b221c8a628L), Double.longBitsToDouble(0x3fe15f4064e1bf64L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-63, 97, 50, 25, -80, 24, -126, -121]]\0121=java.lang.Boolean:true |a0=[B:[[-63, 97, 50, 25, -80, 24, -126, -121]]\012",
        Z.run(T, 2, 5, 5, 12, "\ud9f1\udc91\ud962\ude49\udbe0\ude48\udbb2\udeb7", "\u0a3e\u5b28\u5760\u325f\u73eb\ucdd7\u6848\u78b1\u1ec1", "\ud991\udf1d\ud9bd\udcd2\ud960\udd86\udbb1\ude40\ud97e\uddfc\ud8bb\udd7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\udada\ude5f\ud803\udfcc\udb9c\udc6a\uda5d\udd95\udbde\udd61",
        51, 69105, 843635027, -3796984368090622818L, -60859L, false, true, (char) 46524, (char) 44493,
        Double.longBitsToDouble(0x3fc4731565afcc48L), Double.longBitsToDouble(0x3fbe1ed036e05a88L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=[B:[[110, 122, 65, 48, 89, 116, 51, 81]] |a0=[B:[[-97, 48, 52, 98, -35, -48]]\0121=[B:[[110, 122, 65, 48, 89, 116, 51, 81]] |a0=[B:[[-97, 48, 52, 98, -35, -48]]\012",
        Z.run(T, 2, 14, 14, 0, "\ud8cf\ude60\ud964\udc92\015\000", "\u0a3e\u5b28\ua15c\u1eb9\ub9f0\ua562\u94ee\u71cf\u3552", "\ud8f0\udd8a\ud9bd\udcd2\uda86\uddda\ud806\udcb4",
        43, 42847, 453058589, -7211059259049844660L, 86358L, false, true, (char) 51300, (char) 6802,
        Double.longBitsToDouble(0x3fe74f376c14b29bL), Double.longBitsToDouble(0x3fe87c3a449ecb0aL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=[B:[[110, 122, 65, 48, 89, 103]] |a0=[B:[[-97, 48, 52, 98]]\012",
        Z.run(T, 1, 15, 9, 4, "\ud8cf\ude60\ud964\udc92", "\u5f52\u3682\u0a0a\u5b28", "\ud9fe\udce9\ud92b\udf97\uec51\ud9a0\ude1a\udad9\udecb\ud88d\ude5f\ud925\udee6\ud9c5\udf01\ud9bd\udcd2\udade\ude66\udbf3\udebd\ud892\udd3c\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13",
        29, 166, -1059342104, 5590737789339028732L, -56126L, false, true, (char) 11412, (char) 30234,
        Double.longBitsToDouble(0x3fb0cd3508faa570L), Double.longBitsToDouble(0x3fecb4c55dc27c4dL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=[B:[[110, 122, 65, 48, 89, 113, 78, 83, 13, 10]] |a0=[B:[[-97, 48, 52, 98, -93, 82]]\0121=[B:[[110, 122, 65, 48, 89, 113, 78, 83, 13, 10]] |a0=[B:[[-97, 48, 52, 98, -93, 82]]\012",
        Z.run(T, 2, 14, 15, 1, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82", "\u3682\u0a3e\u5b28\u618a", "\ud92b\udf77\uec51\uda2d\ude03\udad9\uddf2\ud88d\ude5f\ud951\udfe6",
        5, 3601, 266598775, -9036139262778698259L, 88340L, true, true, (char) 31801, (char) 15728,
        Double.longBitsToDouble(0x3fd87f98612cbc4eL), Double.longBitsToDouble(0x3fefb1b920e8e7e6L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 14, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41\ud8f1\udf25\ud925\ude09\udab3\udeec", "\u1f23\ub9f0\ua562\u94ee\u71cf\u3552\u9202\u46ab\u4a72\u8779\uabc8", "\ud8d4\udc7d\ud930\udf30\ud8bf\udd1f\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5",
        46, 45896, 1308020070, 6043211657044016689L, 57398L, false, false, (char) 40475, (char) 11412,
        Double.longBitsToDouble(0x3fe472bc644334d4L), Double.longBitsToDouble(0x3fd1f54aef2d3156L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-79, -82]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[-79, -82]]\012",
        Z.run(T, 2, 16, 6, 11, "\udae1\udfde", "\u33bc\ucef1\u3682\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua4f3\u94ee", "\ud88d\ude5f\ud951\udfe6\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4",
        16, 71740, 445040535, -1286022303961577353L, -87432L, false, false, (char) 6802, (char) 4622,
        Double.longBitsToDouble(0x3fed7af5570b126fL), Double.longBitsToDouble(0x3fdd243f86400624L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]]\012",
        Z.run(T, 2, 2, 7, 14, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41\ud9b9\udd74\ud925\ude09\udab3\udeec\udbc2\udf3d\uda82\udfaa\udae6\udf3d\ud9c9\udd33\ud92b\udf52\uec51\uda19\udc38\udad9\uddf2\ud8f1\udef2\ud907\udf05\udae9\uddd3\ud9bd\udc6e\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\u1eb9\ucca9\ud89f\udcf6\uda6f\ude5a\udb82\udfb9\ud99f\ude8a\ud97d\udd2f\ud906\udd5f\ud834\udf97\udadb\udc8f\uda65\udc49\u8bbb", "\u7b03\u70ae\uaaaa\u050d\u2ddf\u627d\ua250\uca47", "\udb29\uddb4\ud89d\udc98\ud898\udf08\ud984\udd95\udabe\udf9d\ud838\udefe\uda23\udf9e\ud9fe\uddd9\ud83a\udce3\ud9cf\uddc6",
        -5, 26635, 488922368, 8368221428637589433L, -899L, false, false, (char) 29814, (char) 20350,
        Double.longBitsToDouble(0x3fd34a8820532012L), Double.longBitsToDouble(0x3fd437cb1ea6efb0L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 18, 18, 12, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\ud9f5\udf41", "\u0a3e\u1ae8\ub46b\u491a\uc145\ud530\u94ee\u71cf\u3552", "\ud97b\udc3c\ud9bd\udd1d\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud92d\udd4f\ud9bf\udca1\udaee\udfb0\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368090622818L, 96296L, true, false, (char) 6210, (char) 31247,
        Double.longBitsToDouble(0x3fe7912deedc0cf7L), Double.longBitsToDouble(0x3fefc93b1c498a5dL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=[B:[[110, 48, 53, 106, 111, 49, 73, 68, 69, 71, 119, 61]] |a0=[B:[[-97, 78, 99, -93, 82, 3, 16, 108]]\0121=[B:[[110, 48, 53, 106, 111, 49, 73, 68, 69, 71, 119, 61]] |a0=[B:[[-97, 78, 99, -93, 82, 3, 16, 108]]\012",
        Z.run(T, 2, 14, 13, 17, "\ud8cf\ude7e\u9093\ud9d3\udc82\ud833\udf40\udb9c\ude1a\ud9b7\udfbd\udaa1\udc80\uda41\udf6b", "\ua3b5\ua562\u94ee\u71cf\u3989\ucbd7\u81da\u8ecc\u38e7\u384e\u0f39\ub952\u7ba9\u66ee\ud79c\u3a72\u00d3\u247c", "\ud97d\udd2f\ud9f9\udef8\ud8d8\udded\udaca\udfde\uda65\udc49\u8bbb\ud9a8\udc06\ud8dc\uded2\ud886\udd8b\ud8bc\udfc2\udac0\udd68\ud828\udf2d\ud909\udee9\ud973\udffb\uda80\udfb5\uda21\udca4\ud831\uddee\ud908\udc5d\udb50\udfe9\udb3f\udcb7\ud962\udc07\ud885\udd8e",
        35, 41844, 976433246, -7619755223090857607L, 50844L, false, false, (char) 6917, (char) 14599,
        Double.longBitsToDouble(0x3fe0e4fcac6ffa26L), Double.longBitsToDouble(0x3fecf719d2478749L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=[B:[[-31, -76]] |a0=[B:[[-114, -117, 52, 98, -93, 82, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[-31, -76]] |a0=[B:[[-114, -117, 52, 98, -93, 82, -59, 17]]\012",
        Z.run(T, 2, 16, 6, 9, "\ud8be\udfbb\ud964\udc92\ud9d3\udc82\ud9f5\udf41\ud8f1\udf25\ud912\udef1\udab3\udeec\ud988\ude5f\uda3c\udc0b\ud99b\udd27\ud8bc\udce8\ud92b\udf97\uec51", "\u4300\u31a3\u83f2\u5436\u544c\u7296\ub952\u33db\u2df2\u1b6d", "\ud9a3\udf13\udb82\udfd5\udb0e\udc21\ud97d\udd2f\uda04\udef8\ud8d8\udded\udaca\udfde",
        1, 97349, -1572907874, -6578356231901242560L, 48547L, true, true, (char) 6210, (char) 59775,
        Double.longBitsToDouble(0x3fe7912de9dc0cf7L), Double.longBitsToDouble(0x3fe355547449ee81L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-20, 114]]\0121=java.math.BigInteger:0 |a0=[B:[[-20, 114]]\012",
        Z.run(T, 2, 8, 8, 10, "\uda1c\udfa2", "\u33bc\ucef1\u3682\u0a3e\u6915\u4f92\u3996\u3569\u42e4\u7ef1", "\ud9cd\udd72\ud9a2\udc2e\udaec\udcd9\ud9bd\udcd2\ud8c7\uddc7\udb84\udc15",
        29, 70182, -2004811896, -2184078805092848445L, -43047L, true, false, (char) 31795, (char) 41166,
        Double.longBitsToDouble(0x3fdebc74f73df38cL), Double.longBitsToDouble(0x3fe18a9ee9cbc535L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[61, 38]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[61, 38]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 0, 5, "\ud86d\udf56", "\u1fda\ucef1\u3682\u0a3e\u6915\u4f92\u3996\u64b7\u42e4\u94ee\u71cf\u3552\u9202\u5706", "\udae2\udc53\udb83\udfe0",
        29, 5334, 1606610167, -2184079518057419581L, 12907L, true, true, (char) 45246, (char) 38879,
        Double.longBitsToDouble(0x3fdcf545193d8b7cL), Double.longBitsToDouble(0x3fe4529ee9cbc535L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[102]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[102]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 0, 16, 12, "\u0096", "\u33bc\u9736\u2b40\u7748\u0ffb\u9648\u1e69\ub9f0\000\u94ee", "\ua492\ud945\udd24\udb57\udfc3\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud8f8\udec1\ud971\udde2",
        4, 62558, 1579622791, 3973310211181434870L, 12026L, false, false, (char) 4622, (char) 45550,
        Double.longBitsToDouble(0x3fe6b192449ecb4eL), Double.longBitsToDouble(0x3feee511fb409154L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-78, -109, -12, 60, -72, 61, -59, 17]]\012",
        Z.run(T, 1, 5, 14, 12, "\ud9e2\udec3\ud824\ude6c\ud9e8\udf6d\ud9f5\udf41", "\u0a3e\u5b28\u8dfc\u1f23\ub9f0\ua562\u94ee\ub193\ub149", "\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\uf4dd\ud99f\ude8a\ud97d\udd2f\ud9f9\udef8",
        -5, 61129, 843635027, -3796984368078629730L, 48547L, true, true, (char) 6210, (char) 31247,
        Double.longBitsToDouble(0x3fe5ff1e22d21dcaL), Double.longBitsToDouble(0x3fefb1c8e97df15fL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 13, 13, 13, "\ud8af\udc50\ud964\udca8\ud9d3\udc82\ua874", "\u9420\u78d3\u815b\u1f23\ub9f0\ua562\u94ee\u71cf\u3552\u625b\u08f6\u6a3b\u1a19\ud407\uaf2f", "\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6",
        40, 48374, -404563978, -4540982722343222426L, -99816L, false, false, (char) 62844, (char) 4,
        Double.longBitsToDouble(0x3fba16bcf0d18b50L), Double.longBitsToDouble(0x3fed1408b29f91cbL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=[B:[[100, 52, -41]] |a0=[B:[[90, 13, 68, 84, -93, 88, 13, 21]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[90, 68, 84, -93, 88, 21]] |a0=[B:[[90, 13, 68, 84, -93, 88, 13, 21]]\012",
        Z.run(T, 2, 16, 9, 12, "\uda8a\udf3d\udb74\ude84\ud9d3\udc88\ud93d\udc45", "\u9420\u78d3\u816a\u1f23\ub9f0\ua562\u94ee\u71cf\u3552", "\ud851\udec2\ud9a6\ude33\udb2f\uddaf\ud8cd\udc67",
        49, 42847, 453058589, -7211059259049844660L, 86358L, false, false, (char) 2914, (char) 6802,
        Double.longBitsToDouble(0x3fe18a9eecfcd89bL), Double.longBitsToDouble(0x3fe1ad316c9edfb4L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=[B:[[57, 49, 119, 48, 89, 103, 61, 61]] |a0=[B:[[-9, 92, 52, 98]]\0121=[B:[[57, 49, 119, 48, 89, 103, 61, 61, 13, 10]] |a0=[B:[[-9, 92, 52, 98]]\012",
        Z.run(T, 2, 13, 14, 9, "\uda27\udc8c\ud964\udc92", "\ucef1\u3682\u9420\u2ebb\u9631\u1e54\ub9f0\ua562\u94ee\u71cf\u3552\u3d27\u4e97\u37de\u2cda\u4d7b\u72e8\u2395\u7ba9\u681e\u0b6c\u4a0a\ucd4a\u291e\u59f0\u7361\u3d95\uc65a\u2229\u0f81\ud4eb\u0862\u9c5c\u9196\u132d\ubeb0\ud285", "\uda14\udc8c\ud985\udc41\ud93a\udf97\ud9cb\udd99\uda0b\udca8\ud876\udffb\ud8d3\udd64\ud8c9\udd86\udba7\udc75\ud9bf\udf94\udb08\udeb7\udaad\ude9c\ud9c0\ude4a\ud80c\uddc0\udadf\udcba\ud91d\ude45\ud930\uded8\udaa2\udf1d\udae9\udf6a\ud9d3\udf59\ud998\udccb\udb4b\ude75",
        21, 31805, 69105026, -8818729442281354404L, 74034L, true, false, (char) 3102, (char) 55769,
        Double.longBitsToDouble(0x3fb7f64d3239bd38L), Double.longBitsToDouble(0x3feeac8b30306d32L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 4, 3, "\ud8cf\ude60\ud964\udc92", "\u9bed\u88d3c\u7702\u4128\u06a0\ua224\u4626\u100d\u0219\ud46d\uab5b\u964c\u8649\ub583\u544c\u7296\u264f\u48e7\u2174\ub97f\u8d5a\u92d6\u5de7\u0662\u7220\u611e\uc60c\u6691\u0f81\ud4eb\u0862\uc249\uc329\u3228\u8958\u9f51", "\u2b24\ud8d7\udc42\ud860\udce2\udac5\udc74\udbe9\udf85",
        11, 20082, -234634166, -5306544517825429501L, 51946L, true, true, (char) 36073, (char) 50368,
        Double.longBitsToDouble(0x3febe28dc33922cfL), Double.longBitsToDouble(0x3fdfba511f3a2d8cL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, 51, 8]]\0121=[B:[[-45, -122, -47]] |a0=[B:[[-97, 48, 52, 98, -93, 82, 51, 8]]\012",
        Z.run(T, 2, 6, 6, 7, "\ud8cf\ude60\ud964\udc92\ud9d3\udc82\uda63\udf38\udba4\udd9e\ud993\udf84\uda8d\udc13\u3d25\uda23\uddff", "\u0e3e\u1000\u0219\ud46d\u941e\u4bd7\u4a06\u4d47\u544c\u7296\u8cf0", "\ud960\udc4c\ucca9\ud9a1\udcf7\ud9b0\udfdc\udb82\udfd5\udac5\udd52\ud8ce\udc46\ud9f9\udeaa\ud8b4\udc1d",
        34, 14507, 1145505691, -6939394929518904428L, 30498L, true, true, (char) 26441, (char) 28575,
        Double.longBitsToDouble(0x3fdd4723fc73dbb6L), Double.longBitsToDouble(0x3fdeeef6049b828cL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 3, 15, "\udb5e\ude96\uda7c\udff3\uda8f\udf37\ud9c7\udf12", "\u4c90\ua0ca\ua85b\uc4dc\u1dde\ubedf\ud575\uab1c\u49f9\u9204\u68ab\u4be9\u0222\ud56a\ubf5a\u1fa9\ubebb\u51c9\ub1a1\uc8f9\u318d\u3989\u1b14\u1b99\ubfa9\u5cfe\ua95b\u06e9\ucc5f\u2efa\ubf7e", "\udabf\udd42\udadd\ude06",
        -4, 53480, 1423371768, 7239975077019580818L, -34618L, true, true, (char) 15669, (char) 23807,
        Double.longBitsToDouble(0x3fd2db30838c5f26L), Double.longBitsToDouble(0x3fe8d22f16a8b50fL)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-43, -105, 24, 16, -20, -122, 94]]\0121=java.lang.Boolean:false |a0=[B:[[-43, -105, 24, 16, -20, -122, 94]]\012",
        Z.run(T, 2, 5, 5, 12, "\ubb05\udbc7\udd48\ud940\udf1c\ud9b6\ude8e", "\u47a2\u7a7f\ua656\u325f\u73eb\ucdd7\u6848\u78b1\u1ec1", "\ud991\udf0d\ud9bd\udcd2\uda16\udd20\udbb1\ude40\ud97e\uddfc\ufd5f\ud978\uddb4\ud8bf\udde9\ua1a9\ud89f\udcf6\udada\ude5f\ud803\udfcc\udb9c\udc6a\uda5d\udd95\udbde\udd61",
        51, 12529, -2088029840, -3796985124004866914L, -60859L, false, true, (char) 62908, (char) 44493,
        Double.longBitsToDouble(0x3fc4731571afcc48L), Double.longBitsToDouble(0x3fbe1ed036e05a88L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=null\0121=void |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 15, 3, 15, "\udb5e\ude96\uda7c\udff3\uda8f\udf37\ud9c7\udf12", "\u4c90\ua0ca\ua85b\uc4dc\u48d5\ubedf\ud575\uab1c\u49f9\u9204\u68ab\u4be9\u0222\ud56a\ubf5a\u1fa9\ubebb\u51c9\ub1a1\u984b\u318d\u3989\u1b14\u1b99\ubfa9\u5cfe\ua876\u06e9\ucc5f\u2efa\ubf7e", "\udabf\udd42\udadd\ude06",
        -5, -1000, 1409286144, 7239975077019580818L, -34618L, true, true, (char) 15669, (char) 23807,
        Double.longBitsToDouble(0x3fd2db30838c5f26L), Double.longBitsToDouble(0x3fe8d22f16a8b50fL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-27, -25, -13, 64, -80, -21, -122, 94]]\0121=java.lang.Boolean:false |a0=[B:[[-27, -25, -13, 64, -80, -21, -122, 94]]\012",
        Z.run(T, 2, 5, 5, 12, "\ud815\ude17\ud823\udc70\udae0\udd1b\ud9b6\ude8e", "\u2c6f\u7a7f\ua656\u7ccb\u80bb\ua6f8\u0c02\u5ae2\u1ec1", "\uda6f\udf81\ud98f\udd1c\ud8b0\udd08\udbb1\ude40\ud97e\uddfc\ud924\udd4d\ud978\uddb4\ud9ed\udf7e\udb06\udf92\ud89f\udd24\udada\ude5f\ud803\udfcc\udb9c\udc6a\uda5d\udd95\udbde\udd61",
        51, 12529, -2088029840, -3796985124004866914L, -60859L, false, true, (char) 62908, (char) 34473,
        Double.longBitsToDouble(0x3fd64d5cc940095eL), Double.longBitsToDouble(0x3fbe1ed036e05a88L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=[B:[[-47]] |a0=[B:[[-97, 48, -73, -6, -110, 87, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 16, 9, 9, "\ud8cf\ude60\ud9e7\udd2a\udbc2\udd87\ud9f5\udf41", "\u09b4\ub68c\u8e64\u1f23\ub9f0", "\uda2d\ude03",
        5, 72298, 1263713142, -2877825054050639959L, -22377L, true, true, (char) 11084, (char) 49020,
        Double.longBitsToDouble(0x3fee78d80aaea3edL), Double.longBitsToDouble(0x3fe5cd1851871ac5L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=[B:[[57, 49, 119, 48, 89, 114, 57, 84, 68, 52, 77, 61, 13, 10]] |a0=[B:[[-9, 92, 52, 98, -65, 83, 15, -125]]\0121=[B:[[57, 49, 119, 48, 89, 114, 57, 84, 68, 52, 77, 61, 13, 10]] |a0=[B:[[-9, 92, 52, 98, -65, 83, 15, -125]]\012",
        Z.run(T, 2, 15, 15, 12, "\uda27\udc8c\ud964\udc92\ud8ef\ude83\uda3f\udeb3", "\u9420\u78d3\u816a\u1f23\ub9f0", "\uda2d\ude03",
        5, 72242, -258318226, -8630095554110077686L, 84439L, true, false, (char) 11084, (char) 47996,
        Double.longBitsToDouble(0x3fee78dfb84c9bedL), Double.longBitsToDouble(0x3fd2a6f0afafcfdaL)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[9, 125, -110, -105, -99, 80, 3, 127]]\0121=[B:[[]] |a0=[B:[[9, 125, -110, -105, -99, 80, 3, 127]]\012",
        Z.run(T, 2, 6, 6, 11, "\uda39\uddad\udac2\uddc7\ud9cd\ude80\uda33\uddaf", "\u72da\u19ed\uc0b8\u816e\ub998\u7189\u0126\ua61e", "\ud866\udf44\u84de\udb62\udca0\udac5\udc30",
        12, 74557, 260067119, -1286270926735443115L, 39329L, true, true, (char) 26301, (char) 3866,
        Double.longBitsToDouble(0x3fa8d0c32664da80L), Double.longBitsToDouble(0x3fa9a26de6fdedd0L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\0121=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 2, 14, 15, 16, "", "\u0fa0\000\uce4c\u3682\u0a3e\u5b28\u8dfc\u1f23\ub9f0\u109b\u3731\u1287\u3552\ub2d7", "\udb35\udf03\ud93a\udd90\ud8da\udfb0\udac3\udded\udb2c\uddba\ud848\udf57\ud9bb\udf1b\ud80e\udc31\uda77\udebf\ud838\udcba\ud875\uddce\udbb0\udf0d\udb12\udfa2\udaec\uddea\udb32\udf66\ud8fb\udc48\ud84a\udee0\ud81e\ude23\udb3d\udd0c\udb81\udc3d\ud9ec\udecc\uda7a\udf09\ud908\ude57\ud989\udcc3\ud88b\udf0c\ud9eb\udfc7\ud9d7\ude28",
        42, 40400, -1103905227, -605876678023231788L, 81509L, false, false, (char) 11652, (char) 34013,
        Double.longBitsToDouble(0x3fe147b221c8a628L), Double.longBitsToDouble(0x3fe15f4064e1bf64L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=[B:[[57, 49, 119, 13, 10]] |a0=[B:[[-9, 92]]\0121=[B:[[57, 49, 119, 13, 10]] |a0=[B:[[-9, 92]]\012",
        Z.run(T, 2, 15, 15, 18, "\uda27\udc8c", "\u0f66\000\u82df\u9420\u78d3\u816a\u1f23", "\uec51\uda2d\ude03\udad9\uddf2\udbdb\udee6\udac7\udf85",
        12, 81402, -1075578505, -9036138910591363025L, -83389L, true, true, (char) 31564, (char) 23604,
        Double.longBitsToDouble(0x3e4d2c4ae0000000L), Double.longBitsToDouble(0x3fc752627194cd90L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=[B:[[57, 49, 119, 48, 89, 114, 57, 84, 109, 103]] |a0=[B:[[-9, 92, 52, 98, -65, 83, -102]]\0121=[B:[[57, 49, 119, 48, 89, 114, 57, 84, 109, 103]] |a0=[B:[[-9, 92, 52, 98, -65, 83, -102]]\012",
        Z.run(T, 2, 15, 15, 12, "\uda27\udc8c\ud964\udc92\ud8ef\ude83\uaeca", "\u9420", "\ud9a2\ude5b\ud9fe\udce9\000\000\uda2d\uddd9\udad9\uddf2\000\000\uda5a\udced\ud9a6\ude33\udb2f\uddaf\ud844\udc25/\000",
        -5, 67224, 1862983756, -1734469517506881577L, -85409L, false, true, (char) 36794, (char) 53063,
        Double.longBitsToDouble(0x3fe407966118a6d3L), Double.longBitsToDouble(0x3fae100745ee0860L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 10, 10, 9, "\ud8cb\ude44\ud968\udf01\uef56\u9921\ud8f1\udf25\ud828\uddcb\udbea\udf8d", "\u3996\u3569\ua2e4\u70ee\u1d5e\ua30c\u9202\u5706\u8d4e\u8779\u7175\u4009\u6f94\u5a34\u49e7\u6bf9\u4aaa\u7ab1\u32d7\u3ee9\ucf89\u4e0e\ud3ef\u0f32\u4883", "\ud96e\udf0a\ud935\udcc4",
        21, 86077, 1122582475, 6341553122906980437L, 65806L, false, true, (char) 28042, (char) 42962,
        Double.longBitsToDouble(0x3fd9b1d109e583ecL), Double.longBitsToDouble(0x3fef20d474d544baL)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[28, 46, 37, 59, 34, 90, -59, 17]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.lang.Boolean:true |a0=[B:[[28, 46, 37, 59, 34, 90, -59, 17]]\012",
        Z.run(T, 2, 16, 5, 5, "\udb4c\udd5e\ud955\ude6b\ud852\udf8a\ud9f5\udf41\ud8f1\udf25\uda54\udee0", "\u64c9\u8a56\u2154\u890e\ud33a\u9006\u479f\u9202\u4833", "\ud935\udd0e\udb2b\ude2d",
        47, 42847, -2113933027, -4406069246777689686L, -13384L, false, false, (char) 25547, (char) 49547,
        Double.longBitsToDouble(0x3fe18a9fcfb54174L), Double.longBitsToDouble(0x3f9ee53145c1b280L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 7, 4, 0, "\ud8cf\ude60\udacf\udc08\udab9\udcfd\ud9f5\udf41", "\u5a5e\uab75\u9ed1\u1f23\uc762\u84d2\u0eee\u1eb8\u00c9\u592f\ua437\u6304\uc1a6\u114f\u8c97\uaf68\u57fa\ua9df\ub467\uc5f1\ua3f4\u1700\u3870\ub4b4\u662f\u7cff\u45f2\ua28c\u4fab\ucf385\u8263\u13b8\u72fe\u5fa2\u468d\u754f\u60bd\u4d37\u8a2c\u4ce2\u068f\u572e\ud77b\ub050\ua9d0\uca1b\ud193\u1dab\u1ddb\u47ce\u8c38\ud2f8\u9bee\u90f1\u7e2a\u6db6\u928c\u52d7\ua574\u87f9\u988a\u16be\u48af\u35d7\uc17d\u8741\ua4d9\u1070\u9721\u5245", "\ud979\ude34\ud885\udca0\udad1\udfc1\udaa9\udf59\uda45\uddd3\uda43\udd55\udbd8\udcfe\ud83b\udf2a\ud810\udcec\u4759\ud81f\udfb1\udabb\udd30\ubb78\ud8da\udd48\udac9\udef3\udbbd\udf85\ud8fe\ude60\u6f9d\ud8f6\udcc2\uda80\udfa5\ud88c\udebd\uda6b\udd22\uda3b\udf89\udba3\uddde\udbce\udcfb\u34d5\ud8ba\ude12\udbfe\udf8a\udb27\udc0d\ud861\udd9c\udb78\udf94\udaf0\udd90\ud956\udd9f\ud8ea\uddf3\ud9e1\udf6c\ud8b4\udc73\ud9a3\udc0f\ud894\udea5\udb83\ude10\ud8fd\udd3a\udb72\udf10\ud9af\udea5\ud80a\udf8e\uda5d\udea6\ud89e\udcef\ud9dc\ude21\udac0\udd9e\uda3a\uddb0\udb76\ude2b\ud870\ude5b\udb5e\ude66\ud826\udf50\udb5a\udfcc\ud8c5\udd27\ud97d\udfae\ud9b5\ude46\uda76\udef3\ud8a1\udeea\ud9ce\udc9a\udb9e\ude8e\ud95b\udf60\uda12\udf8c\ud89e\ude5f\udb00\udc44\ud9e5\udc14\udaec\udf38\ud853\udcda\ud873\udc65\ud967\ude47\ud8cc\ude87\ud90f\udc5a\udb90\udc18\udb7a\udf3c\uda44\udd28\ud89b\ude3d\uda90\udf16\ud8d4\udf8b\ud96a\udfc7\udb01\udd80\ud911\udd3b\uda88\udfaf\udaa7\ude21\ud815\udc0a\ud915\uddd8\ud987\ude25\udb5f\ude7c\ud8a4\udc6b\ud896\udfc1\ud845\udf68\udb0f\udc8b\ud94b\udc4d\uda46\udd2d\udb6f\udffa\ud971\udc09\udb5d\udffa\udba9\udeab\ud8a6\udf8d\u482c\udac5\udcf3\ud9c7\udf98\ud9da\udcc5\udb50\udee6\ud99f\udd5a\uda5a\udf30",
        3, 39356, -1955359872, -3978972939755354090L, -48636L, false, true, (char) 32745, (char) 25644,
        Double.longBitsToDouble(0x3fd012ae1a18168aL), Double.longBitsToDouble(0x3fe4d77bb5e2c9deL)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=[B:[[110, 43, 88, 50, 111, 54, 50, 108, 114, 73, 111, 61]] |a0=[B:[[-97, -27, -10, -93, -83, -91, -84, -118]]\0121=[B:[[110, 43, 88, 50, 111, 54, 50, 108, 114, 73, 111, 61]] |a0=[B:[[-97, -27, -10, -93, -83, -91, -84, -118]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 13, 10, 12, "\ud8cf\ude15\ud826\uddd3\ud8dd\udfd5\udadc\uddba\ud8f1\udf25\ud822\udd47\udab3\udeec\udbc2\udf3d\ud826\ude56\ud9cc\udc5f\ud87c\udc6a\udade\udd8f\ud92c\udc3e\uda2d\ude41\udad9\uddf2\ud9b5\udcfa\ud8cd\udebd\udba3\udd4f\udb65\ude47\udade\uddf8\udbf7\udfcd\ud97e\ude78\ud9ec\uddbb\udbaf\udd5c\udb5f\ude92\ud92f\udd8d\ud8a4\udfaf\ud9cc\udc16\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\ud862\udc0c\ud8d8\udded\udaca\udfde\uda65\udc49\ud81e\udcbc\uda60\udd0b\ud973\udd56\ud9d9\udcc3\u09e9\ud884\udc5b\ud934\udd9b", "\u9450", "\ud970\udc62\ud90b\udce1\ud890\udded\udadc\udd12\ud859\udc04\ud88d\uddf7\uda56\udc0b\ud8cd\udf9b\ud9bc\udda8\udbf5\udd7c\u4510\ud912\udf06\udb81\udd27\udb36\udd5e\udb9f\udc90\udba9\udd2f\ud89c\udf03\uda34\udcaa\ud959\udd6f\udb30\udd5d\ud905\ude92\udbe6\uddd4\udb00\udf0b\udb5f\udfa9\ud93f\udfe1\uda42\udcb1\uda34\udc65\udb53\uded7\ud8f4\udda0\ud841\udecb",
        45, 38181, 587937754, 178695271339263653L, 92732L, true, false, (char) 54699, (char) 55384,
        Double.longBitsToDouble(0x3fd5cfff391d85b6L), Double.longBitsToDouble(0x3fee3d3adcdf0c77L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=[B:[[-47, -47, 98, 37, -71, 19]] |a0=[B:[[-47, -47, 98, 32, 37, -71, 19, 32]]\012",
        Z.run(T, 1, 9, 5, 14, "\udb01\udf01\uda92\udf50\udb55\udee9\ud943\udf50\ud940\udc9d\u15d5\udaa3\udec5\udbc2\udf3d\udba2\udc37\udac3\udd3e\ud8d4\ude97\ud8f7\udfa8\uec51\ud9ff\udf03\ud98b\ude6b\udad9\udc28\ud872\udcd7\uda9f\udea8\ud915\udfbe\udb7b\udd1f\uda27\udc08\udb72\uded9\ud878\udc28\ud8f7\udc3d\udbdf\ude5c", "\u51bf\u910a\ub04e\u6f3c\ud765\ubdfb\u6c34\u1398", "\ud927\uddd3\uda50\udc28\ud941\udec6\ud73b\udb89\udcb1\ud9ce\udd28\ud8b5\uded5\udbd1\uddcf\uda63\ude05\uda0e\udf4b\ud9de\udc72\udb46\udd7a",
        48, 205, -406046723, -1733462344816098610L, -41438L, false, false, (char) 58001, (char) 45455,
        Double.longBitsToDouble(0x3fdeed25a88c93eeL), Double.longBitsToDouble(0x3fb7adebd917adc8L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-43, -105, 24, 10, 41, -122, 94]]\0121=java.lang.Boolean:false |a0=[B:[[-43, -105, 24, 10, 41, -122, 94]]\012",
        Z.run(T, 2, 5, 5, 12, "\ubb05\udbc7\udd48\ud83a\udd59\ud9b6\ude8e", "\u47a2\u7a7f\ua656\u325f\u73eb\ucdd7\u67be\u78b1\u1ec1", "\ud991\udf0d\ud9bd\udcd2\uda16\udd20\udbb1\ude40\ud97e\uddfc\ufd5f\ud9a7\udc14\ud8bf\udde9\ua1a9\ud89f\udcf6\udada\ude5f\ud803\udfcc\udb9c\udc6a\uda5d\udd95\udbde\udd61",
        51, 12529, -2088029840, -3796985124004866914L, -60859L, false, true, (char) 62908, (char) 44493,
        Double.longBitsToDouble(0x3fc4731571afcc48L), Double.longBitsToDouble(0x3fbe1ed036e05a88L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=[B:[[80, 108, 113, 117, 118, 49, 79, 97]] |a0=[B:[[62, 90, -82, -65, 83, -102]]\0121=[B:[[80, 108, 113, 117, 118, 49, 79, 97]] |a0=[B:[[62, 90, -82, -65, 83, -102]]\012",
        Z.run(T, 2, 15, 15, 12, "\u666e\udb8a\udfde\ud8ef\ude83\uaeca", "\u9420", "\ud9a2\ude5b\ud9fe\udce9\000\000\uda2d\uddd9\udad9\uddf2\000\000\uda5a\udced\uda27\udeb5\udaf7\uddc2\ud844\udc25/\udba7\udeb6",
        32, 67224, 1862983756, -1776157118621919273L, -85409L, false, true, (char) 28832, (char) 63580,
        Double.longBitsToDouble(0x3fc16dba7ae1825cL), Double.longBitsToDouble(0x3fb9fb03941963c8L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[13, -11, -38, -12, -78, 61, 37, 49]]\0121=java.lang.Boolean:true |a0=[B:[[13, -11, -38, -12, -78, 61, 37, 49]]\012",
        Z.run(T, 2, 5, 5, 18, "\udb3d\udc25\udb0a\udf24\udae2\udf6d\uda55\udc61\ud8df\udc51\ud90d\udcd7\ud9fd\uddc5", "\ubb73", "\uec51\ud8fa\ude30\000",
        -1, 2976, 200855495, 6323006757008570743L, -7309L, false, true, (char) 30302, (char) 54358,
        Double.longBitsToDouble(0x3fcf412469fc0168L), Double.longBitsToDouble(0x3fee7b68959a8f2bL)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=[B:[[-39, 82, 77]] |a0=[B:[[10, -39, 82, 77]]\0121=[B:[[-39, 82, 77]] |a0=[B:[[10, -39, 82, 77]]\012",
        Z.run(T, 2, 9, 9, 8, "\ud83a\udd09\ud982\udd7d", "\ucdff\u88d3c\u5b28\u343c\u79d5\uaf78\u5771\u1018\u83cf\u72a6\uab5b\u964c\u4b64\u6ea2\u5456", "\uda8d\ude6b\uda23\udee5\uda18\udfd7\udb80\udc19\udaaf\udd1f\ud9bd\udcd2\ud8fa\ude11\udba8\ude49\uda49\ude48\uda0d\udecd",
        0, 54737, 843635027, -3796984365098648308L, -60117L, false, false, (char) 29933, (char) 8238,
        Double.longBitsToDouble(0x3fecb4c55dc27c4dL), Double.longBitsToDouble(0x3fed66757bd1d57bL)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.binary.Base64:@?\0121=void |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 3, 7, "\udb5e\ude96\uda7c\udff3\uda8f\udf37\udbd4\udc38", "\u4c90\ua0ca\u6e3d\uc4dc\u48d5\ubedf\ud575\uab1c\u49f9\u9204\u68ab\u4be9\u0222\ud56a\ubf5a\u1fa9\ubebb\u51c9\ub1a1\u984b\u318d\u3989\u1b14\uc5db\u792a\u5cfe\u18ff\u066c\u5bc7\u21d3\ubf7e", "\ud93f\uddb1\udb39\ude4b",
        38, -1000, 1409286144, -4406615035047032703L, -34618L, true, true, (char) 15669, (char) 23807,
        Double.longBitsToDouble(0x3fd2db30838c5f26L), Double.longBitsToDouble(0x3f9a45e267a1e6e0L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-114, 119, -26, -37, 124, 70, -59, 17]]\012",
        Z.run(T, 1, 5, 16, 7, "\udbbe\udda7\uda16\ude0b\ud9ac\udd76\ud9f5\udf41\ud8f1\udf25\ud925\ude09\udab3\udeec\udbc2\udf3d\uda23\udd6f\ud86b\ude00\ud97d\udc92\ud932\ude97\uec51*\000\000\ud951\udfe6\ud9c5\udf01\ud9bd\udcd2\udade\ude66\ud843\udfd3\ud97e\ude78\ud8d4\udc7d\ud978\uddb4\ud8bf\udde9\ucca9\ud89f\udcf6\ud9a3\udf13\udb82\udfd5\ud99f\ude8a\ud97d\udd2f\udae9\ude91\udac8\udda0\ud8b0\ude2a\ud90b\udfa7\udada\udd6d\udbf7\udc15\udbea\udc92\ud926\udd06\uda00\udfbe\udba0\udd4c\ud85e\udf9f\ud822\uddab\ud8c4\udfc4\ud99e\udebf\ud8db\udc6a\udb7e\udc13\ud8c8\uded0\ud91a\udfc4\ud9f3\udd14\ud845\udc3f\udbc5\udccb\ud107\ud8bd\udf38\ud8fd\udf00\udad0\udf04\udbe3\udcea\ud8cf\udfe4\ud8af\udc9e\uda14\udfa1\ud9b8\ude78\ud84a\udf29\ud978\udf92\uda8d\udf82\u2305\udaf8\udf8b\udbc5\udd6d\udaba\udc2d\ud9aa\udc74\uc654\uda16\udd82\ud914\udcc1\uda6d\udffa\ud8a0\udec2\udaba\udf2a\ud893\udf55\ud919\udcf5\ue8b8\uda7d\udf91\ub053\ud84c\udd74\ud9ae\udc92\udadb\udd28\ud973\udee3\ud83d\ude4f\udabc\udd83\uda04\udd03\ud86e\udf10\ud981\udf6f\ud8bb\udef3\ud99f\udebf\udb51\udd5b\ud971\udf52\ud817\udf13\ud8ad\udefe\udb9b\udc3f\udb32\udf49\udab3\ude7f\ud95c\ude8f\udbfb\udf46\uda97\udd4c\ud971\udf15\ud84f\udc97\udb09\udcb3\udb21\udfa7\uda77\udc98\uda89\ude66\ud86b\udea6\ud8d2\uddf1\ud9a6\udc10\udac0\udd6e\udbf9\uddfb\ud936\udc04\udb2b\udf94\ud887\udd8c\uda8b\udd33\ud9d5\ude1c", "\u66f2\u29d3\u8f3c", "\ud86b\udeee\ud9f2\udebc\ud9d7\udc72\udb09\udec8\ud97a\udea6\uda44\udf50\udad4\udca2\uda4e\udd72\uda3c\udcaa\udb98\udea0\udaa9\udfbf\uda23\udc83\udb71\udf17\uda9a\udef1",
        33, 87389, 157029004, -1509934153765367652L, -21308L, true, true, (char) 52754, (char) 1216,
        Double.longBitsToDouble(0x3fe95c80de4ee0c0L), Double.longBitsToDouble(0x3fbc21b01ebb5570L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base64|decode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.String|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|avail||new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|containsBase64Byte|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|java.lang.String|static",
    "M|org.apache.commons.codec.binary.Base64|decodeInteger|[B|static",
    "M|org.apache.commons.codec.binary.Base64|discardWhitespace|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|decode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.String|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
