package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base64_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.math.BigInteger:56 |a0=[B:[[-4, -119, 79, 73, -35]]\012",
        Z.run(T, 1, 12, 14, 15, "\ud82c\udeb9\ud87f\ude79\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, 66188, 244715426, -4733087677068040828L, 97636L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.math.BigInteger:56 |a0=[B:[[-4, -119, 79, 73, -35]]\012",
        Z.run(T, 1, 12, 5, 11, "\ud82c\udeb9\ud87f\ude79\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, 66188, 244715426, -4733087677068040828L, -48796L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-4, -119, -66, -81, -24, 90]]\012",
        Z.run(T, 1, 12, 14, 15, "\ud82c\udeb9\ud8ee\udddf\udb18\udc8a", "\u688d\uaf12\u4f30\ubde8\u0133\ucf90", "\ud974\ude8f",
        8, 66188, 244715426, -4733087677068040828L, 97636L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3feb0a86e2d48478L), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.math.BigInteger:40162 |a0=[B:[[39, 110, 79, 73, -35, -9, -45, -117]]\012",
        Z.run(T, 1, 12, 4, 7, "\udb57\udd9e\ud87f\ude79\u200d\udb27\udf03\udbbb\udde0\udb42\uddcb", "\u965f\u8007\u3039\u6f9b\u0e89\u4322\ub610\u2925\u88eb", "\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud93d\udf68\ud878\udfb3\udb91\udd16\udb53\udfe2\udb22\ude19",
        53, 20072, -1743726849, -2839706735720366078L, -30428L, false, true, (char) 27524, (char) 25572,
        Double.longBitsToDouble(0x3fe95f1797843146L), Double.longBitsToDouble(0x3fe32560193a715bL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 8, 17, "\u48f2\ud87f\ude79\u200d\ud931\udca8\udb05\ude46\ud8b9\udd94\ud96c\udd4f\uda69\udf48\udaf0\udf09\udb42\udc01\udb54\udf2a\ud9f6\udc7d", "\ua62f", "\udb12\udcb8\ud844\ude84\ud9a1\udeaa\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud93a\udd47\ud89f\udd61",
        53, 19902, -682098718, 2151959134468179766L, -64892L, false, false, (char) 4395, (char) 59806,
        Double.longBitsToDouble(0x3f7892e945300300L), Double.longBitsToDouble(0x3fd2c8a9de7fe9aaL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[117, 6, -90, -35]]\012",
        Z.run(T, 1, 12, 14, 15, "\ud8a5\udc36\u52d6\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, 66188, 244715426, 1103577440004135335L, -84357L, true, true, (char) 32814, (char) 1404,
        Double.longBitsToDouble(0x3fef39c1d8534070L), Double.longBitsToDouble(0x3fdfa50dcd0040ceL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-7, -57, 79, 126, -35]]\012",
        Z.run(T, 1, 12, 6, 12, "\udb29\uddf7\ud87f\udeae\u200d", "\u688d\uadfd\u4a07\u31ad\ubcd5\u94aa", "\ud974\ude8f",
        11, 66188, 244715426, -4733087964830849660L, 97636L, true, true, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c418c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[B:[[55, 90, 80, 103, 100, 116, 48, 66, 101, 73, 115, 61, 13, 10]] |a0=[B:[[-19, -109, -32, 118, -35, 1, 120, -117]]\012",
        Z.run(T, 1, 18, 12, 4, "\udb1d\uddc3\ud810\udca6\u200d\ud931\udca8\udbbb\udde0\udb42\uddcb\ud864\udf98", "\u6f6b\u94aa\u8774\u0e89\u4322\ub610\u2925\u88eb\ua6c7\u726f\u78a5\u0381\u70af\u6daf\u76bd\ubb16\uc828\u4461\u8eea\u822d\u2e71\u3ee1\u650c\u0843\u157a\u7e60\u2bf0\u8bba", "\uda1e\ude46\udbc5\udee6\udab3\udcae\ud834\udfaa\ud957\udf92\uda3a\udd62\udadb\udff6\udbbb\udce9\ud936\ude01\udb02\udd88\u1f1a\uda0c\udddc\uda45\udc0e\uda8f\udf43\udb44\ude4e\ud95f\udd90\ud958\udf3d\uda35\udfdf\uda97\udf2c\u2cee\ud8b8\ude66\uda4e\udd4b\ud90a\ude8a\ud905\uddad\udab9\ude34\udabe\udf03\udbd0\ude98\uda58\udea7\u7a05",
        0, 52795, 1939082148, -3494661290890426367L, 35114L, true, false, (char) 13918, (char) 25380,
        Double.longBitsToDouble(0x3fdd89ff926d4262L), Double.longBitsToDouble(0x3fab4cae544b2dc0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[B:[[-4, -119, 92, 7, 15]] |a0=[B:[[-4, -119, 92, 7, 15]]\0121=[B:[[47, 73, 108, 99, 66, 119, 56, 61]] |a0=[B:[[-4, -119, 92, 7, 15]]\012",
        Z.run(T, 2, 13, 17, 13, "\ud82c\udeb9\ud98c\udf37\u203f", "\u8b83", "\udaf0\udf09\uda99\udd2d\ue664\udac3\udec5\udb4b\udf25\ud974\ude8f\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\udbe4\udc81\ud9d4\ude76\ud968\ude24\uad44\udbb6\uddc8\udb13\udfda\udab3\uddd7\uda27\udca3\uda8f\udc42\ud997\udd12\udb4b\udf8c\uda7e\udfcf\ud867\udc2a\uda51\uddf2\ud9c1\ude92\ud9d2\udfb2\ud8b9\udfa0\u2513\ud8ab\udd65\uda3e\udcae\ud8e5\udfa6\ud8bd\udd32\u7e53\ud893\udd96\ud8fd\udd87",
        52, 43386, -611240463, -1697210817103832090L, -85873L, false, true, (char) 41071, (char) 45124,
        Double.longBitsToDouble(0x3fde6304615b7ee6L), Double.longBitsToDouble(0x3fe1b663b63b3eb8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.math.BigInteger:224 |a0=[B:[[-4, -119, 11, 52, 66, 96]]\012",
        Z.run(T, 1, 12, 0, 10, "\ud82c\udeb9\ud83b\udd64\uda72\ude90", "\u1536\u5d37\ub9bc", "\udb7d\udf66\udbe3\udf8b\ud934\uddb6\ud98a\ude8f\udbc4\udc0a\udbcd\udd27\uf87e\ub5f7\ud889\udf33\ud96f\udc2f\ud9d5\ude04\ud8c7\udcc6\udba7\uddf7\ud851\udf72\ud878\udfb3",
        40, 39650, 1025095296, -3967606434462854368L, -29899L, false, true, (char) 977, (char) 19475,
        Double.longBitsToDouble(0x3feed396b16252bfL), Double.longBitsToDouble(0x3febcdca0966a866L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-4, -119, -128, 0, 16, -57]]\012",
        Z.run(T, 1, 12, 14, 15, "\ud82c\udeb9\ud9b0\udc30\uda40\udcf7", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa\u8774\u0e89\u4322\ub610\u2925\u88eb", "\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud93d\udf68\ud878\udfb3\udb91\udd16\udb53\udfe2\udb22\ude19",
        25, 4376, -224754746, -2082318256649090641L, -44515L, false, true, (char) 48211, (char) 44022,
        Double.longBitsToDouble(0x3fe02eaf026b3943L), Double.longBitsToDouble(0x3fec9a941326d7e7L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[B:[[111, 66, 118, 48, 72, 55, 111, 61]] |a0=[B:[[-96, 27, -12, 31, -70]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 14, 2, 5, "\ud8d0\udc4b\uda24\ude4f\uf0ea", "\u5804\ua271\uc0cd\uc8ea\u9e60\u973e\u783e\u4dfb\u431c\ub610\u1611\ud27c\u53fc\u5354\uab18\u7744\u9dc5\u7985", "\ud872\udff9\udb53\udf20",
        50, 68227, 1949617472, -2806748368886596697L, -53025L, false, true, (char) 28410, (char) 9650,
        Double.longBitsToDouble(0x3f8d077f099d6800L), Double.longBitsToDouble(0x3fe1baa6cf069353L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.math.BigInteger:3705923 |a0=[B:[[-4, -119, 79, 73, -35, 1, 120, 68]]\012",
        Z.run(T, 1, 12, 14, 18, "\ud82c\udeb9\ud87f\ude79\u200d\ud931\udca8\udb74\udd3c\uda6e\udf1c\ud95f\uded6\uda69\udf48\udaf0\udf09\uda99\udd2d\udb7d\udf66\ud9d8\udf1a\ud934\uddb6\ud974\ude8f\udbc4\udc0a\udbcd\udd27\uf87e\ub5f7\uda32\udca8\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6", "\u5bec\ucdaf\u1bf1\u8eed\u81b5\u83ce\u5b8b\uc9a1\u9c89\u3e35\u552d", "\ud893\uddae\udb53\udfbb\uda2d\udeb8\ud8ac\uddc3\udbec\udfd1\ud856\ude20\ud86f\ude8a\ud930\udcb1\udaa7\udf8a\ud94a\ude31\udb91\udf5e\ud97e\ude6d\udb65\udf4e\ud9e1\uded4\ud8a8\udd96\udb8d\udc91\ua11c",
        53, 41498, 1325941962, 2161106280400686317L, 88794L, true, true, (char) 39208, (char) 29308,
        Double.longBitsToDouble(0x3f913204732a8220L), Double.longBitsToDouble(0x3fd770c5a182b404L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[B:[[71, 83, 80, 113, 82, 100, 49, 51, 43, 113, 56, 61]] |a0=[B:[[25, 35, -22, 69, -35, 119, -6, -81]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 14, 9, 4, "\ud949\udc53\uda1a\udc75\u200d\ud8a7\udf2a\udbdf\udf30\udb42\uddcb\ud95f\uded6\uda69\udf48\udaf0\udf09\ud894\udd6b\udb7d\udece\ud882\udc8e\udacb\udef4\udaf3\udde7\udb83\ude15\udbcd\udd27\uf87e\ub5f7\udaa6\udfd2\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\ud9fb\ude61\ud924\udf73\udb93\udce0\ud8e2\udfc3\udb53\udfe2\uda67\udff5\ud911\udfb9\uda3d\udd63", "\u3cca\u6e17\u80ef", "\ud85c\ude9d\ud9a2\udc8b\ud8a8\ude7a\ud888\udcdb",
        16, 11023, -169042668, -4847581474545170036L, -31394L, false, false, (char) 39718, (char) 1171,
        Double.longBitsToDouble(0x3feb61d0ba9b7e87L), Double.longBitsToDouble(0x3fc9d4dae39cf854L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-48, -48, -48]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 6, 7, 15, "\ue700\000\000", "", "",
        -5, -1000, 99, -1710478573068268296L, -72916L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd33ad94d5aca9aL), Double.longBitsToDouble(0x3fd758a000000000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 18, 18, 14, "\ud82c\udeb9\ud9d8\udc6c\u4286", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa\u8774\u0e89\u4322\ub610\u40d9\u97ff\u53fc\uc3d4\u7543\uc0ca\u809e\ub265\u76bd\u9c46\uc828\u4461\u8eea\u81b5", "\udb73\udcd6\ud9c4\udd5c\ud8ad\udd7f\ud985\uddff\udb4a\uddd7\ud9b2\uddfd\udb2b\udd0e\udbf2\udc1e\udba6\udf0c\uda2d\uddd6\ud900\udd12\ud8cf\udc4c\u9ffd\ud9a5\udd00\ud871\uddde\udab2\udc49\uda9d\udd39\ud9a2\ude5e\udba0\udf56\ud9d7\udd5d\ued6b\uda12\udc6f\ud941\udd33",
        57, 95106, -1735786339, -4251501421031234668L, -8765L, false, false, (char) 51451, (char) 41588,
        Double.longBitsToDouble(0x3fc447619f89060cL), Double.longBitsToDouble(0x3fecd6d88ca8cc12L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 8, 14, 15, "\ud82c\udeb9\ud87f\ude79\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, -479, 244715283, -4733087677068040798L, 97636L, false, false, (char) 45090, (char) 42179,
        Double.longBitsToDouble(0x3fd49e42bd0040ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 15, 13, 15, "\000\ud85e\udecf\u0084", "\ub7b4\uadfd\u4f30\ube4bc\000", "",
        -5, -1000, 0, 0L, -34464L, true, false, (char) 4104, (char) 32814,
        Double.longBitsToDouble(0x3f98996300000000L), Double.longBitsToDouble(0x3fb4d0002fd00000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.math.BigInteger:56 |a0=[B:[[1, 79, 73, -35]]\012",
        Z.run(T, 1, 12, 14, 15, "\u7431\ud87f\ude79\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, 66188, 244715426, -4733087677068040828L, 97636L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[B:[[89, 110, 49, 80, 120, 116, 48, 61]] |a0=[B:[[98, 125, 79, -58, -35]]\012",
        Z.run(T, 1, 0, 1, 15, "\uda92\udead\ud87f\uddf6\u200d", "\u3f29\u8ee3\u4f30\ube4b\u9f19\u94aa", "\uda8f\udd72\uda81\udc75\udbcd\udd27\uda70\udff3\u5dfc",
        -3, 49139, -1100845395, 8947110345561015300L, -69305L, true, false, (char) 22230, (char) 56364,
        Double.longBitsToDouble(0x3fe7c1e8c820c8f0L), Double.longBitsToDouble(0x3fca9d4fcd6af3f0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-4, -119]]\012",
        Z.run(T, 1, 12, 14, 15, "\ud82c\udeb9", "\u8c53\u8c12\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa\u8774\u0e31\u4322\ub610\u2925\u88eb\u53fc\uc3d4\u7543\u0381\u809e\ub265\u76bd\u9c46\uc828\u4461\u8eea\u9c14\u2dc2\u13b1\ub3e5\u2876\u754e\u03c5\u76ce\u49c1\u9e37\ua7b7\u2a64\u8491", "\udb58\udedb\uda56\ude4a\uf9e6\ud839\udf1d\ud994\udc46\ud93d\uded8",
        49, 25138, -539161787, -6230072680856762556L, -30593L, false, false, (char) 11819, (char) 22124,
        Double.longBitsToDouble(0x3fe5817b8418bfb2L), Double.longBitsToDouble(0x3fe2b8829a1a1ef6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[B:[[95, 73, 109, 116, 87, 72, 119, 95, 65, 88, 103]] |a0=[B:[[-4, -119, -83, 88, 124, 63, 1, 120]]\012",
        Z.run(T, 1, 18, 14, 15, "\ud82c\udeb9\udadd\udf88\ud9ac\udf6f\ud931\udca8\udbbb\udde0\udbd6\udebb\ud95f\uded6\uda69\udf48\ud821\udfa0", "\u0ba1\ucdb7\u4322\ub610\u3026\u8ab2\u1bc1\uc3d4\u7543\u22f2\u809e\ub265\u76bd\u24fd\u2da2\u8af9\u8efc\u81b5\u0e30\u75cd\u336a\u70d9\u21f6\u66c0", "\ud948\udf79\ud9a8\ude0b\ud8ae\udcb7\ud93f\udcda\uda7e\udf0d\ud8e2\udce0",
        22, 3268, -1239833788, 2875695736847348145L, 87507L, false, true, (char) 52420, (char) 22984,
        Double.longBitsToDouble(0x3fecd56ce7e21d74L), Double.longBitsToDouble(0x3fe38baa401a7dccL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[B:[[47, 73, 108, 80, 83, 100, 48, 61, 13, 10]] |a0=[B:[[-4, -119, 79, 73, -35]]\012",
        Z.run(T, 1, 17, 14, 1, "\ud82c\udeb9\ud87f\ude79\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        19, 4653, 244715370, -4733087677077346940L, -72940L, true, true, (char) 32814, (char) 1404,
        Double.longBitsToDouble(0x3fd93515e7156d48L), Double.longBitsToDouble(0x3fe6e64200e72067L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 4, 2, 5, "\uda38\udebf\ud87f\ude79\ud85a\udc15\ud931\udca8\ud818\ude2e\uda4d\ude26\udaac\udc9d\ud8b9\udcf9\udb36\udf21\uda75\udd9d", "\u5b88\u5073\ud76b\u6384\u552c\u478b\uc344\uce4c\u0381", "\uda42\ude0f\ud88c\udfd2\ud936\udca2\udb64\udd53\ud8b9\ude53\ud96b\udfdd\ud847\udc33\ud93f\udf19",
        42, 70084, 1400767682, -471723084813842253L, -74519L, false, true, (char) 48282, (char) 36388,
        Double.longBitsToDouble(0x3fb2ef10f6ae4f48L), Double.longBitsToDouble(0x3fc01480ad257ba0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[]]\012",
        Z.run(T, 1, 12, 14, 7, "", "\ub0f1\u8c53\u8c12\u688d\000\uc76e\ube4b\u6f6b\u28cd\ub469\u0e31\u4322\ub610\u2925", "\uda32\udca8\ud912\udf2b\u6ead\ud8a5\udf51\udba7\uddf7\ud93d\udf68\ud878\udfb3\udb91\udd16\udb53\udfe2\udb22\ude19",
        25, 16808, 932730011, 5974402410558499675L, -8299L, false, false, (char) 28251, (char) 30602,
        Double.longBitsToDouble(0x3fee9441313e5645L), Double.longBitsToDouble(0x3fcbb08d5e682afcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 10, 14, 15, "\ud82c\udeb9\ud87f\ude79\u200d", "\u688d\u0722\u4f30\ube4b\u6f6b\u94aa\u8774\u90cc\u4317\ub610\u2925\u88eb\u53fc\uc3d4\u7543", "\udba7\ude00\ud93e\udc14\udaf9\uddb1\udb91\udd16\uda9e\udc48\udb22\udde9\ud911\udfb9\u94f8\udb1d\ude93\udb2a\udf91",
        25, 35316, 1862569884, 5550824819168175585L, 10816L, true, true, (char) 1695, (char) 26608,
        Double.longBitsToDouble(0x3f8296bdd381aac0L), Double.longBitsToDouble(0x3fe5841ef1762045L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[B:[[47, 73, 108, 80, 83, 85, 57, 51, 13, 10]] |a0=[B:[[-4, -119, 79, 73, 79, 119]]\012",
        Z.run(T, 1, 1, 4, 6, "\ud82c\udeb9\ud87f\ude79\ud87f\udfa7", "\u4686\u6f5a\u4f30\u6538\u6f6b\u94aa\u04d8\u97c3\u42bf\ub610\u304d\ub962\u090d\uc416\u050d\u0381\u809e\u0a0d\u6d5c\u31ad\u3e0c\uc1b6\u9f06\ubf6f\u1ad5\u45a3\uc358\u954e\u3d10", "\ud91a\udcb4\ud971\udffd\ud840\udd95\ud9d4\ude9d",
        21, 25949, 1186621276, -1330967867135597622L, 95162L, true, false, (char) 38432, (char) 32166,
        Double.longBitsToDouble(0x3fefde8da35566a2L), Double.longBitsToDouble(0x3fe87714fb828575L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[B:[[47, 73, 110, 72, 66, 97, 119, 61]] |a0=[B:[[-4, -119, -57, 5, -84]]\012",
        Z.run(T, 1, 3, 14, 15, "\ud82c\udeb9\udaf7\udf35\u1fdc", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, 66188, 1587436962, -5974035510183190908L, 97636L, false, false, (char) 45090, (char) 25366,
        Double.longBitsToDouble(0x3fe28b706335467cL), Double.longBitsToDouble(0x3fe27ffd68206182L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[107, 110, 88, 55, 79, 116, 48, 61]] |a0=[B:[[-110, 117, -5, 58, -35]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 14, 15, "\udac2\udea5\ud82b\udc6a\u200d", "\u85c0\u55fb\u4ecd\ube4b\u6f6b\u94aa", "\udae8\udcb5\ud870\udd58\udbd4\udf3c\ud983\uddb2\udabc\udd4a",
        22, 49308, -1970049363, 2317811694071645297L, -73913L, false, false, (char) 1038, (char) 17885,
        Double.longBitsToDouble(0x3fe8cbbe9c225b8dL), Double.longBitsToDouble(0x3fd4320b67dc08ccL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 7, 9, 10, "\ud82c\udeb9\ud87f\ude79\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u9443", "\ud974\ude8f",
        8, 66188, 244715426, -4733087677068040828L, -69398L, true, false, (char) 22230, (char) 55014,
        Double.longBitsToDouble(0x3fe7c1e8ca8b16f0L), Double.longBitsToDouble(0x3fd5a1f05d07d88eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.math.BigInteger:56 |a0=[B:[[-4, -119, 79, 73, -35]]\0121=[B:[[47, 73, 108, 80, 83, 100, 48, 61]] |a0=[B:[[-4, -119, 79, 73, -35]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 14, 15, "\ud82c\udeb9\ud87f\ude79\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, 77012, -1164746159, -8376517758866798728L, 97636L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 11, 7, 15, "\udbab\udc79\udbed\udc0d\u9d80", "\u9024\ub2b5\u8e7c\ub8aa\u264b\ud273", "\ud974\ude8f",
        8, 66188, 244715426, -4733087677068040828L, -69305L, true, true, (char) 40069, (char) 55163,
        Double.longBitsToDouble(0x3fe7c1e8c820c8f0L), Double.longBitsToDouble(0x3fb8a1769f718910L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[B:[[48, 65, 61, 61]] |a0=[B:[[-48]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 14, 14, 15, "\000", "\u8c53\ub32e\u688d\u0bc2\u00c1\000\u107a\000\u8774X\u6471\ub610\u2925\u88eb", "\000",
        34, 35461, -1721564156, 118851416096768L, 98138L, false, false, (char) 30737, (char) 51440,
        Double.longBitsToDouble(0x3fcb87da28f8909cL), Double.longBitsToDouble(0x3fe03736891b3a62L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[65, 107, 26, -13, 73, 88]]\0121=[B:[[2, 66, 23]] |a0=[B:[[65, 107, 26, -13, 73, 88]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 5, 6, 15, "\udb71\udc9b\udb4a\udf23\udb79\udd88", "\u688d\uadfd\ucf54\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        15, 66188, 1708789666, 455059158087280039L, 97838L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c1e8ccefc8f0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 9, 10, 17, "\uda96\uddae\udaf6\udd75\ud84e\udea2", "\u688d\uadfd\u4f30\ub6be\u6f6b\u94aa\u8774\u0e89\u4322\ub610\u2925\u88eb\u53fc\u312c\u7203\uc735\u9c63\ub265\u7714\u9c46\u1753\ub11e\ubae5\u81b5\u9533\u816d", "\ud8f2\ude4b\ud973\udd4b",
        40, 59409, 247085971, -914297342410598518L, 92182L, true, true, (char) 58032, (char) 23607,
        Double.longBitsToDouble(0x3fdffe56d5bfbc04L), Double.longBitsToDouble(0x3fdf8e10ade19004L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-79, -115, 79, 21, -35, 4, -38, -90]]\012",
        Z.run(T, 1, 12, 14, 15, "\udbe1\uddbd\ud87f\ude45\u200d\udb34\ude0a\ud9d6\udc05\udb42\uddcb\ud95f\uded6\uda69\udf48\ud86f\udd87\udb51\udf18\ud8e8\udd25\ud9d8\udee9\udb4f\udee5\udb41\ude4f\udbc4\udc0a\udbcd\udd27\ud849\uddc3\u72a7\uda32\udca8\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\u6210\ud809\udf45\ud80d\udcd5\udb5e\ude14\udb22\ude19\ud911\udfb9\ud869\uded9\udb96\ude36\ud89b\udf89\ud9c4\udc58\uda9b\udcdb\ud862\udf30\udb51\udceb\ud974\udc7b\ud802\udcb8\ud957\udf7b\ud9c2\udc9e\ud8db\udf6d\ud8e3\udc09\ud814\udc89\ud80b\ude74\ud8a8\udddc", "\uacfb\u3617\u8b1e\ubfbe\ua55b\u67e7\u565d\u16d3\uab75\u1019", "\ud83e\udcbe\uda79\udcc3\u11c6\uda8a\ude16\ud8d6\udc84\udaad\udf17\udb32\udea9\ud94c\udd06\ud9d5\ude75\ud906\uddf8\ud8e7\udd9c\ud9ce\udf49\ud81f\udcc5\ud802\uded8\ud85b\udc81\udb59\udf7e\ud8ff\udf50\ud95f\udda1\ud857\uddb3\ud95c\udf3a\uda5c\udfc2\ud84d\udcc5\ud8fe\udc82\ud9ce\udeab",
        32, 71836, 417319363, -5598915602048660840L, 90541L, false, false, (char) 50199, (char) 25079,
        Double.longBitsToDouble(0x3fe5fd4024c36440L), Double.longBitsToDouble(0x3fd27a00a090a8ceL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 14, 0, 0, "", "\ub0f1\u8c41\u8c12\u30d9\uadfd\u4f30\ube4b\u6f6b\u94aa\u4cf8\ud258\ubd40\000\u28f1", "\000\uda29\udd04\000\000\ud81d\uddee\ud93d\udf68\u77e7\udb91\udd16\udb53\udfe2\udb22\ude19",
        25, 37368, 710742841, -5513230001743200399L, 27751L, true, true, (char) 42084, (char) 60905,
        Double.longBitsToDouble(0x3fef435a2edd17eeL), Double.longBitsToDouble(0x3fe2fcf6466a46e2L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.math.BigInteger:73 |a0=[B:[[83, 86, 61, -125, 4, 83]]\012",
        Z.run(T, 1, 12, 14, 15, "\uda83\udf86\ud86d\udeb3\ud934\udf83", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, 66188, 244715426, -4733087677068040828L, 97636L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=[B:[[47, 73, 107, 61]] |a0=[B:[[-4, -119]]\012",
        Z.run(T, 1, 17, 16, 15, "\ud82c\udeb9", "\u8c53\u8c12\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa\u867c\u1488\u4322\ub6104\u88eb\u53fc\uc3d43\u3c25\u809e\ub265\u6c18\u9c46\uc828\u4461\u8eea\u81b5\u4834\u3b71\ud56b\u68b5\ub5ff\u9d8f\u1fa5\u7211\u66ed\u0266\ud612\u3d40", "\udaf2\udfd7\udaca\uddd3\udb37\udf55\ud9ab\udf13\ud83b\udd7d\udbb6\udc41\ud824\udded\udb9b\ude49\uad9c\ud862\udd71\ud9a7\udd33",
        4, 83157, -18983478, 4750219578755032677L, 40544L, false, true, (char) 19447, (char) 8284,
        Double.longBitsToDouble(0x3feb89487a9df036L), Double.longBitsToDouble(0x3fedbf27c2fc4fedL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[]]\012",
        Z.run(T, 1, 12, 14, 3, "", "\ub0f1", "\udb42\uddcb\ud95f\uded6\uda69\udf48",
        55, 86123, -398251827, -2280707106153115048L, -100000L, false, false, (char) 64930, (char) 49259,
        Double.longBitsToDouble(0x3fd84be50a675b28L), Double.longBitsToDouble(0x3fe56b2a6d758a93L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-33, -56]]\012",
        Z.run(T, 1, 5, 14, 15, "\ud80f\udff8", "\u1d2d\u8c12\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa\u8774\u0e89\u4322\ub610\u2925\u88eb\u53fc\uc3d4\u01df\ucc0d", "\ud93d\udf68\ud893\udc66\udb91\udd16\udb53\udfe2\udb22\ude19\ud911\udfb9\udb03\udea6\uc4e5\uda85\ude00\ud91f\uddc7\udb60\udc1b\udbc4\udc58\udafe\uddbf\ud983\udf64\udafe\udcc3\u1baa\udbe3\udd0b\ud970\udd27\uda02\udd66\uff02\u4874\ud849\udc13\ud9bd\udd68\uda3b\udd4f\ud8ed\udcb0\udaec\uddb7\uda1d\udc58",
        26, 34407, -102004050, 8604350089735061101L, 93802L, true, true, (char) 44455, (char) 9366,
        Double.longBitsToDouble(0x3fdd8e17d10c9b32L), Double.longBitsToDouble(0x3fe09aa7f1b72d28L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 7, 5, 8, "\ud82c\udeb9\ud87f\ude79\u200d\ud966\ude76\ud8fb\ude31\udb54\udd6c\ud95f\uded6\uda69\udf48\udaf0\udf09\uda99\udd2d\udb7d\udf66\ud9d8\udf1a\ud934\uddb6\ud974\ude8f\udbc4\udc0a\udbcd\udd27\uf87e\ub5f7\uda32\udca8\ud939\udcea\ud9d0\udeb4\udb7d\udf65\ud885\udd9f\udbee\udcd5\udad3\udea1\ubc94", "\u81b5\ubfda", "\udaeb\udef9\ud935\ude7f",
        45, 16869, -1366744812, 7936404721962981338L, -81044L, true, true, (char) 44660, (char) 45249,
        Double.longBitsToDouble(0x3fe41cc7dfcbe240L), Double.longBitsToDouble(0x3fdd01a2daf0ad56L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 8, 12, 0, "\ud82c\udeb9\udac4\uddba\u065c\ud931\udca8\udaf1\uddda\uda38\udcb0", "\u6aa1\u4351", "\ud824\udc2e",
        56, 27417, -1882742513, 1063607267742495190L, -66515L, true, false, (char) 4104, (char) 32814,
        Double.longBitsToDouble(0x3fd8d8363fce7014L), Double.longBitsToDouble(0x3fb4d01c2fd286e0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=[B:[[-8, 79, 73, -63, -63]] |a0=[B:[[-8, 13, 79, 73, -63, -63]]\012",
        Z.run(T, 1, 13, 11, 15, "\uda28\udf3d\ud87f\ude79\udbf1\udcf1", "\u688d\uadfd\u42eb\u1b6c\ube76\u9fae", "\ud974\ude8f",
        38, 70462, 244715426, -4733087677068040828L, 97636L, false, true, (char) 24733, (char) 38664,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.math.BigInteger:3638692134 |a0=[B:[[14, 50, 79, 73, 74, -27, 74, 113]]\0121=[B:[[68, 106, 74, 80, 83, 85, 114, 108, 83, 110, 69, 61]] |a0=[B:[[14, 50, 79, 73, 74, -27, 74, 113]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 14, 6, "\ud83e\udd62\ud87f\ude79\udb7a\udc15\ud97a\udfa1\ud8db\udd2f\udb42\uddcb\u60d2", "\u6fc6\u94aa\u8774\u1e21\u4322\u3a02\ud292\u8937\u53fc\uc404\u7584\u7464\u809e\u97bb\u69e6", "\udac8\udcfd\ud8f2\udea5\ud911\udfb9\udb40\udd53\ud9f0\udced\ud876\udeb4\ud96f\uddd1\ud9d6\udd19\uda5e\udffa\ud9df\udc3d",
        6, 50686, -1146608156, 2278449272929870344L, -98443L, true, false, (char) 20343, (char) 32471,
        Double.longBitsToDouble(0x3fe979ff36c24687L), Double.longBitsToDouble(0x3fe0391fd8593abeL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 8, 11, 7, "\ud82c\udeb9\ud9c4\udd84\udb22\udc0f\u9d24\ud9a2\udcfc\ud8f0\udc74\ud9d1\udfb2\udb49\uddfe\ud940\udedb\uda99\udd2d\udb7d\udf66\ud9d8\udf1a", "\ub610\u2925\u88eb", "\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud949\ude8a\ud878\udfb3\udb91\udd16\udb53\udfe2\udb22\ude19",
        25, 84344, 1908785244, -3191542968684566999L, 33738L, false, false, (char) 13053, (char) 14899,
        Double.longBitsToDouble(0x3fc04948d0fb9d1cL), Double.longBitsToDouble(0x3fef9ddce6164008L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 17, 13, 4, "\uda0a\udcb6\ud88b\udffe\udbde\udf10", "\u688d\uadfd\u4f30\u5a39\u6f6b\u94aa", "\ud974\ude8f",
        8, 34180, -2037863275, -1560166349621195984L, -14566L, true, true, (char) 32814, (char) 1404,
        Double.longBitsToDouble(0x3fef39c1d8f945bbL), Double.longBitsToDouble(0x3fdfa50dcd0040ceL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-127, 44, 77, 39, 113, -59]]\012",
        Z.run(T, 1, 5, 14, 15, "\ud8b1\udd5c\ud87d\ude57\ud9a1\udef5", "\u688d\uadfd\ub694\u1396\u6f6b\u94aa\u8774\u0e89\u4322\ub610\u2925\u88eb", "\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud94e\udc06\uda92\udcbf\udb91\udd16\udb53\udfe2\udb03\udc89",
        58, 51816, -1954861129, 6881869385977412335L, -86588L, true, false, (char) 12893, (char) 13331,
        Double.longBitsToDouble(0x3fda6cea358d6052L), Double.longBitsToDouble(0x3fddc0889c00f4d2L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[]]\012",
        Z.run(T, 1, 12, 16, 8, "", "", "\013",
        -5, -1000, 12935105, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3faa464c70000000L), Double.longBitsToDouble(0x3f0d2d612f800000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |a0=[B:[[14, -28, 79, 73, -35, 1, 120, -117]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 9, 6, 5, "\ud83e\udf14\ud87f\ude79\u200d\ud931\udca8\udbbb\udde0\udbc6\udc8d\ud819\udc66\uda0e\udd49\udb75\ude8a\udb87\udfd7\ud909\udfa0\ud966\udff4\ud98b\udfd4\ud974\ude8f\udbc4\udc0a\udbcd\udd27\uda5b\udfc7", "\u7543\u0381\u809e\ub265\u76bd\u9c46\u5e08\uc5dc\u8ec1\u81b5\u543d", "\udbbf\udfdd\ud9ce\udcf3\udab8\udfa8",
        41, -210, -2099612161, -5358841653318774806L, -82628L, true, true, (char) 1613, (char) 53270,
        Double.longBitsToDouble(0x3fe45102d7903605L), Double.longBitsToDouble(0x3fcb44c17b8caa44L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=[B:[[47, 73, 108, 80, 83, 101, 108, 88, 73, 52, 115, 61]] |a0=[B:[[-4, -119, 79, 73, -23, 87, 35, -117]]\012",
        Z.run(T, 1, 16, 18, 7, "\ud82c\udeb9\ud87f\ude79\ud819\udc87\uf153\udbbb\udde0\udb42\uddcb\ud95f\uded6\ud888\udc99\uda0b\ude0a\uda1f\ude7b\ud800\ude0a\udb9d\udc11\ud934\uddb6\ud86d\ude4b\udbc4\udc0a\udbcd\udd27\uf87e\ub5f7\uda32\udca8\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud93d\udf68\ud94b\ude93\ud805\udd25\udb27\udd7f\ud82a\uddfc\uda76\udd44\udace\ude00\udba9\udd2f\uda93\udd46\uda35\ude9e\ud8fe\udffd\udb10\udeee\udb01\uddcc\ud878\uddff\ud83d\udc9b\uda47\udec5\ud91c\udcdb\ud8f4\udc60\ud9f5\udc4d\ud867\uddd4\ud9ce\udd9c\uda57\ude60\uda91\udfe8\uda6a\ude95\ud98a\udf8b\uda6b\udffc\udbc4\ude77\ud84e\udeea\ud96b\ude12\ud8b9\udd69\ud825\udf10\udbd5\udf72\ud953\udc9e\udb13\uddb5\udb2e\ude8f\uf5cd", "\u8187\u6d81\u2b5f\u5137\u01c0\ucd6d\u6225\uc0eb\uc942\ua170\u1c99\u73e6\u0447\u4405\u2ca7\u520f\u5352\u0718\u34ff\u779a\ua4a2\u8187\u811c\u7e33\uc31d\u4189\u0c2f\uccde\u3ee3\u6215\u509f\u008b\u5141\u0885\u65b0\u0e6d\u9408\u9a39\u0a75\u8c45\u3832\u1423\u67fa\u3f9a", "\ud97e\udd58\ud92c\udf91\udbea\uded1\udb95\uddda\uda82\uddf5\udbbd\udcba\udb91\udd9c\ud974\udd1a\udb5e\udf17\udb30\udf10\ud917\ude07\ud83f\udce3\ud907\udc9d\ud9b7\ude24\ud815\udcfb\uda2f\udef9\udba9\udf22\udae7\udef1\udbcb\udcea\udbb5\ude7b\udbe0\udfc2\ud88a\udcf6\ud9a2\uddd8\ud93d\udeb9\ud9e2\udee4\ud968\udf9a\ud9a3\udc40\uda5a\ude61\udb9b\udf01\udb36\udc70\ud860\ude0b\ud805\uddfc\ud8c7\udcf8",
        10, 85472, -1127638247, 1551195654896655406L, -42496L, true, false, (char) 60336, (char) 47282,
        Double.longBitsToDouble(0x3fd078934ee0637eL), Double.longBitsToDouble(0x3fe8e80d83aa3ca8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 11, 10, 2, "\u8f9b\ud87f\udea5\u200d\ud931\udca8\ud983\udf65\udb42\uddcb\ud95f\uded6\uda69\udf48\udaf0\udf09\uda99\udd2d\ud98d\udf0d\ud9f5\udee3", "\ub610\ubce3\u7fd5", "\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud93d\udf68\ud800\udfb7\udb91\udd16\udb53\udfe2\udb22\ude19",
        25, 94584, -30625861, -6363553975179069258L, -63061L, true, false, (char) 4453, (char) 51141,
        Double.longBitsToDouble(0x3fe7ffc817088433L), Double.longBitsToDouble(0x3fb998c54a2794d0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=[B:[[104, 74, 57, 69, 120, 119, 61, 61]] |a0=[B:[[-124, -97, 68, -57]]\012",
        Z.run(T, 1, 1, 10, 15, "\ud9b4\udecf\ud874\udef7", "\ub4b3\u17e4\u751a\ud03c\u08a7\u6f6b\u94aa\u8774\u68fe\u405c\u362e\u88d2\u88eb\u53d9\u34d5\ua91c\u5d70\u809e\ub265", "\udb32\udd08",
        -5, 35103, 1587895600, -3137847201037303770L, -90836L, false, false, (char) 65392, (char) 56413,
        Double.longBitsToDouble(0x3fdec619eb09d3d6L), Double.longBitsToDouble(0x3fdee589ad962ab0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[19, -107, -39, 12, 124, 125]]\012",
        Z.run(T, 1, 12, 14, 15, "\ud943\udcc5\uda09\udc3c\ud8ac\udcad", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, 66188, 244715426, -4733087677068040828L, -2367L, false, false, (char) 45090, (char) 9796,
        Double.longBitsToDouble(0x3fdfa50b7d0040ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=[B:[[56]] |a0=[B:[[-3, -92, 79, 73]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[47, 97, 82, 80, 83, 81, 61, 61]] |a0=[B:[[-3, -92, 79, 73]]\012",
        Z.run(T, 2, 6, 16, 0, "\ud82d\udfd4\ud87f\ude79", "\u1a00\u119e\u8734\u4a98", "\ud970\udda0\udb15\udd60",
        38, 45521, -1838958466, -4566297819831645682L, -57660L, true, true, (char) 22849, (char) 4144,
        Double.longBitsToDouble(0x3f71f0aa61c6b180L), Double.longBitsToDouble(0x3feece69d8534070L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 14, 14, 15, "\ud82c\udeb9\ud87f\ude79\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud95d\udcae",
        8, 66188, 0, -4733087677068040828L, 97636L, false, false, (char) 45090, (char) 16579,
        Double.longBitsToDouble(0x3fdfa50dc00000ceL), Double.longBitsToDouble(0x3fe7c000c8000000L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-4, -119, 79, 73, -35]]\012",
        Z.run(T, 1, 5, 4, 15, "\ud82c\udeb9\ud87f\ude79\u200d", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa", "\ud974\ude8f",
        8, 66188, 244715426, -4733087677068040828L, 97636L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 14, 17, "\ud82c\udeb9\udaae\udf36\ud9f8\ude5e", "\u4a37\uadfd\u4f30\ube4b\u6f6b\u94aa", "\udbd1\uddcc",
        8, 66188, 1117130658, -4733082063545784956L, 97636L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd1c40ceL), Double.longBitsToDouble(0x3fe7c1e8c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=[B:[[-4, -119, 79, 73, -35, 1, 120, 80]] |a0=[B:[[-4, -119, 79, 73, -35, 1, 120, 80]]\012",
        Z.run(T, 1, 13, 14, 15, "\ud82c\udeb9\ud87f\ude79\u200d\ud931\udca8\uda80\udf1d\udb42\udd9e\ud95f\uded6\uda69\udf48\udaf0\udf09\uda99\udd2d\udb7d\udf66\ud9d8\udf1a", "\u1e11\uc057\u88eb", "\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud93d\udf68\ud878\udfb3\udb91\udd16\udb53\udfe2\udb22\ude19",
        25, 45944, -1431972251, 703913984311302113L, 64926L, true, true, (char) 28134, (char) 44311,
        Double.longBitsToDouble(0x3fd207d9619bd2b4L), Double.longBitsToDouble(0x3fd891ff0ef91932L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.math.BigInteger:14476 |a0=[B:[[-4, -119, 79, 73, -35, 3, 120, -117]]\0121=[B:[[47, 73, 108, 80, 83, 100, 48, 68, 101, 73, 115, 61, 13, 10]] |a0=[B:[[-4, -119, 79, 73, -35, 3, 120, -117]]\012",
        Z.run(T, 2, 12, 18, 10, "\ud82c\udeb9\ud87f\ude79\u200d\ud933\udea8\udbbb\udde0\udb42\uddcb\ud95f\uded6\udaee\uddeb\udaf0\udf50\uda99\udd2d\ud89a\udfca\ud9d8\udf1a\ud934\uddb6\ud92d\uddeb\udbd4\udd1f\udbcd\udd27", "\uc3d4\ubfde\u7281\u809e\ub265\u76bd\u9c46\uc3bd\u83fe\u728b", "\ud8ed\udcde\udbb4\udffc\udb63\ude07",
        25, 50283, 888379015, -7713232242427581026L, -24947L, true, false, (char) 34471, (char) 31635,
        Double.longBitsToDouble(0x3fb92cfbec28cfa8L), Double.longBitsToDouble(0x3f959dc71881f7e0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=[B:[[82, 111, 53, 80, 83, 100, 48, 66, 101, 73, 115, 61]] |a0=[B:[[70, -114, 79, 73, -35, 1, 120, -117]]\0121=[B:[[82, 111, 53, 80, 83, 100, 48, 66, 101, 73, 115, 61]] |a0=[B:[[70, -114, 79, 73, -35, 1, 120, -117]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 16, 14, 1, "\ud976\udebe\ud87f\ude79\u200d\ud931\udca8\udbbb\udde0\udb42\uddcb\ud95f\udec7\udbb7\udccf\udaf0\udf09\ud9b5\udd92\udb4a\udefe\ud874\udc31\ud926\udfb7\u7377\ud871\udf1a\uda6b\udf37\ud877\udfb4", "\u8518\u460b\u809e\ub265\u76bd\u8864\uc828\u4461\u8eea\u81b5\u8034\u1860\ua3b4\ua225\u1eff\uce0e\u61bd\u40af", "\ud941\udda8\ud967\ude90\udb49\udf98\ud9d4\ude50\uda23\udeaa\udb98\udc95\ud9ea\udeaf\ud93c\udf30\u0fc3",
        -4, 75125, 1791830685, -2397384438306330287L, 13589L, false, false, (char) 21785, (char) 30225,
        Double.longBitsToDouble(0x3fe94d84afb2bce3L), Double.longBitsToDouble(0x3fe09496b6c76e2cL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.math.BigInteger:67 |a0=[B:[[11, 0, 81, -35, 91, 1, 120, -117]]\012",
        Z.run(T, 1, 12, 7, 16, "\ud83b\udc30\uda81\udc0d\u1f8b\ud931\udca8\udbbb\udde0\udb42\uddcb\ud95f\uded6\uda69\udf48\udaf0\udf09", "\ud00b\ubf1c\u4322\ub610\u2925\ub0ec\u75b2\uc8f4\ud0d7", "\udba7\uddf7\ud93d\udf68\ud878\udfb3\udb91\udd16\udb53\udfe2\udb22\ude19\ud911\udfb9\u8d56\ud872\udffd\ud966\ude7c",
        58, 2335, 2049539179, -59616803816983634L, 56169L, true, false, (char) 6748, (char) 51034,
        Double.longBitsToDouble(0x3fe30569f322b85bL), Double.longBitsToDouble(0x3fedf008bf9f5642L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=[B:[[56]] |a0=[B:[[-120, 15, 79, 73, -104, 38]]\0121=[B:[[56]] |a0=[B:[[-120, 15, 79, 73, -104, 38]]\012",
        Z.run(T, 2, 10, 10, 1, "\udbb8\udd3f\ud87f\ude79\ud8c8\udd56", "\ubc8a\u357a\u4f30\ube4b\u6f6b\u2fdb\u8774\u1937\u4322\ub610\u2925\u88eb\u6d2b\u75e9\u2101\ube2b\u57b0\u0a11\u4ae5\u9c46\ua8e0\u085c\ud065\u81b5\u9b11\u3b06\u687e\u2d48\ua613\u2f9d\ub3e5", "\ud809\udf02\udbdc\udf12\udbe1\uddf2\uda17\uded4\ud86d\udf2b\udab3\ude49\ud98d\udd8f\udba2\udf60\ud976\udc7b\ud804\udf08\ud93e\uddd7\ud9df\udf64\udb4e\uddc0\udb73\ude64\ud94d\udca1\uda25\udc58",
        16, 22433, -2079448051, -95869642947246809L, 97451L, true, true, (char) 22521, (char) 53052,
        Double.longBitsToDouble(0x3fb93992a2e754a0L), Double.longBitsToDouble(0x3fd31aa5ed94b746L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 11, 2, 12, "\ud82c\udeb9\udbb7\uddce\u1f91\ud86b\udde5\ud8fa\udf80\ud9e2\udc00\ud963\udc39\uda69\udf48\udaf0\udf09\uda99\udd2d\ud8cb\udfda\udaa5\udc7a\udb1d\udf4b\ud974\uddf7\udb2f\ude3e\udb3b\udca2\uf87e\udb3d\ude7e\uda32\udca8\ud912\udf2b\ud9c3\udfc1\ud946\udd86\udaaa\udd7b\ud992\udde9\ud8f2\ude41\udb42\udd9f\ud9b3\udc57\udb03\udf63\uda67\udd73\udab3\udf84\uda29\udc5b\udb3f\udf95\udbca\udd7d\udb79\udf92\uda6e\udee9\ud8f7\udc54\ud908\udd61\udacd\ude70\ud917\ude0e", "\u0ccc\u99a0\u3d3e\ua5df", "\udb8f\udea3\udb18\udf31\ud9ff\udc08\ufd4f\udbce\udc87\udaab\udfbd\ud9d2\udee7\udbe1\udeb9\ud8cb\udcbe\ud8a7\udf67",
        43, 72614, 938739106, 5614256981845983143L, 26174L, true, false, (char) 23105, (char) 31022,
        Double.longBitsToDouble(0x3fe6eddd7b87064fL), Double.longBitsToDouble(0x3fb9e8ee52164590L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 1, 8, 16, 15, "\uab19", "\ud55f\u0155\u2c83\u928b\ud73a\u03de\u012a\ucf90", "\ud974\ude8f",
        27, 31924, 241831842, -4733087677068069572L, 50276L, false, false, (char) 32285, (char) 63262,
        Double.longBitsToDouble(0x3feb0a86e2d48478L), Double.longBitsToDouble(0x3fe7c1e8ccd0c8f0L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-4, -119, -66, -81, 96, 14]]\012",
        Z.run(T, 1, 5, 16, 16, "\ud82c\udeb9\ud8ee\udddf\uda90\ude3e", "\u84cd\uc83e\u9730\uca13\u0133\ub949\u8774\u61f8", "\uda59\udf98\ud9dc\ude40\udbaf\udd97\uda45\udfe9\udb7a\udd28\uda6b\udf7c\ud8c7\udc54\udba7\uddf7\ud93d\udf68\uda0a\uddbd\ud902\udf9c\ud852\udd25\ud85f\udee1\ud909\udc85\udbcb\udf2a\ud8e6\uddf5\udbcb\udf28\ud9c6\udfc6\ud90d\udc32\ud86f\udfe1\udba7\udcec\udba2\udcf8\u7fab\ud9c1\udfc6\udb11\udeef",
        -5, 72846, 1455638176, 1303399362376091116L, -33218L, false, false, (char) 27371, (char) 11759,
        Double.longBitsToDouble(0x3fec4b6f6041b8e8L), Double.longBitsToDouble(0x3fb3417fb50e4970L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-71]]\012",
        Z.run(T, 1, 12, 16, 12, "\u28e9", "\u1e4c\u540a\u4b71\uaf12\u4f30\ucc5b\u1687", "\ud934\uddb6",
        4, 5888, -298084812, 1051044750394700246L, -44978L, false, false, (char) 14968, (char) 32814,
        Double.longBitsToDouble(0x3f989963fce70760L), Double.longBitsToDouble(0x3fb4d01c1b0a86e0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=[B:[[-4, -119, -66, 74, -24, 90, 102, -46]] |a0=[B:[[-4, -119, -66, 74, -24, 90, 102, -46]]\0121=[B:[[-4, -119, -66, 74, -24, 90, 102, -46]] |a0=[B:[[-4, -119, -66, 74, -24, 90, 102, -46]]\012",
        Z.run(T, 2, 13, 13, 15, "\ud82c\udeb9\ud8ee\udd7a\udb18\udc8a\udb96\ude02\udae3\udcba\udb42\uddcb\udafe\udc56\ud849\udc38\ud9e5\ude18\uda7c\udd83\uf270\ud9d8\udf1a\udb2f\udf75\ud974\udfbc\udbc4\udc0a\udbcd\udd27\uf87e\udb2e\udcfa\uda32\udca8\ud86e\ude79\udae5\uddb0\ud8c7\udcc0\udb4b\udd58\ud93d\udf7a\ud878\udfb3\udb91\udd16\ud933\udc19\udb25\ude6d\ud911\udfb9\uda4d\udc4c", "\ucee2\u6ac2\u6afd\u8030\u785b\u154c\ub9fa\u9994\u4b6b", "\uda8d\udf30\uda43\ude8b\ud837\udf1f\udb79\udea7\ud9d5\udf76\udb28\udd11\ud935\udf8c\ud881\udcfd\ud849\udc7e\udbfa\udc94\u0e1d\udaa7\ude49",
        -5, 81504, 2115160539, -2257448933480651852L, 73232L, false, true, (char) 15969, (char) 52463,
        Double.longBitsToDouble(0x3feb2beaf6fa35ddL), Double.longBitsToDouble(0x3fecb74c9b528e79L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.math.BigInteger:5121261 |a0=[B:[[8, -93, -128, 84, 38, 105, 84, 116]]\012",
        Z.run(T, 1, 12, 14, 15, "\uda38\udfd3\udbb0\udc84\ud856\udf99\ud984\udda4\udbbb\udde0\ud89f\udc0f", "\ubde8\ua264\u3e4e\u8dbd\u15a5\u4275\uaa2d\u25cd\u88eb", "\ud968\udc96\udae5\ude3c\ud8c7\udd3d\udb1f\uddf3\ud8c5\udecf\ud878\udfb3\udb72\udda7\uda5a\udd0c",
        4, 9013, 1971650728, 2354078016001692498L, 4584L, true, false, (char) 40099, (char) 65262,
        Double.longBitsToDouble(0x3fe1de6e6370ac32L), Double.longBitsToDouble(0x3fd89728971f0936L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 15, "\ud9a7\udda9\ud98f\ude0b\udb18\udc8a", "\u688d\uaf12\u4f30\u5879\u292e\u026c", "\ud974\ude8f\udbc4\udc0a\udbcd\udd27\uf87e",
        0, 22772, 1501461811, -5403208923758295691L, 68936L, true, false, (char) 24771, (char) 23613,
        Double.longBitsToDouble(0x3fe6a423c2f83d19L), Double.longBitsToDouble(0x3fa064782d773210L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=[B:[[]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 9, 18, "\uda12\udd41", "\u15f3\uafea\u6911\uaea3\u4f30\ubde8\u5e6e", "\udad0\udf05",
        40, 5888, -328800972, 1051044436862087638L, -979L, false, false, (char) 14968, (char) 6958,
        Double.longBitsToDouble(0x3fe87eb5ff514d8eL), Double.longBitsToDouble(0x3fd211c704c96d74L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[39, 110, 79, 73, -35, -9, -45, -117]]\012",
        Z.run(T, 1, 5, 4, 7, "\udb57\udd9e\ud87f\ude79\u200d\udb27\udf03\udbbb\udde0\udb42\uddcb", "\u965f\u8007\u3039\u6f9b\u0e89\u4322\ub610\u2925\u88eb", "\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud93d\udf68\ud878\udfb3\udb91\udd16\udb53\udfe2\udb22\ude19",
        53, 20072, -1743726849, -2839706735720366078L, 8184L, false, true, (char) 13568, (char) 53803,
        Double.longBitsToDouble(0x3fe95f1797843146L), Double.longBitsToDouble(0x3fe325601aae715bL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[39, 110]]\0121=[B:[[39, 110]] |a0=[B:[[39, 110]]\012",
        Z.run(T, 2, 12, 13, 15, "\udb57\udd9e", "\u23bc\u224b\u67ce\u10e0\ub96f\u6f49\u7fdc\u3039\u3e03\u0e6c\u0b0c\ucf10\u5fa6\u7a6c\u8d25\ub1fa\u9cdf\ud2f7\u8058\ub265\u76bd\uc0cf\uc828\ud299\u5059\ub0e3\u12d8\ucc50\u422a\u1e11\u72a1\uc614\u8605\u6cda\u802c\u9191\u1529\ud613", "\ud9d2\udf12\udb3e\udf16",
        14, 5031, -2076940505, -5507962089610819720L, -63125L, true, false, (char) 40000, (char) 43113,
        Double.longBitsToDouble(0x3fe39c0e82410280L), Double.longBitsToDouble(0x3fb21ac5f6715840L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=[B:[[74, 50, 53, 80, 83, 100, 51, 51, 48, 52, 115, 61]] |a0=[B:[[39, 110, 79, 73, -35, -9, -45, -117]]\0121=[B:[[74, 50, 53, 80, 83, 100, 51, 51, 48, 52, 115, 61]] |a0=[B:[[39, 110, 79, 73, -35, -9, -45, -117]]\012",
        Z.run(T, 2, 17, 0, 7, "\udb57\udd9e\ud87f\ude79\u200d\udb27\udf03\udbbb\udde0\udb42\uddcb", "\u965f\u8007\u3039\u6f9b\u4cdd\u614d\ub541\u99d6\ua6df\u53fc\uc3d4\u7543", "\udba7\ude06\ud93d\udf68\ud878\udfb3\udb91\udd16\udb53\udfe2\udb22\ude19\udb7b\udfae\ud9c8\udee9\udbf4\udcde\ud9b0\udf72",
        14, 25310, 309260348, -2057230388886403055L, 4661L, false, true, (char) 35109, (char) 17045,
        Double.longBitsToDouble(0x3fd3c1f60f42f0c6L), Double.longBitsToDouble(0x3fc23d6ac9a23050L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[77, 81, 79, 73, -35]]\012",
        Z.run(T, 1, 5, 0, 15, "\udb7d\ude81\ud87f\ude79\u200d", "\u1f3f\u175e\u3ccb\ua65f\u8007\u3039", "\ud974\ude8f\udbc4\udc0a",
        15, 79371, -1102008018, -5938940020540998397L, 62443L, false, false, (char) 37687, (char) 9817,
        Double.longBitsToDouble(0x3fb4d01c2fd286e0L), Double.longBitsToDouble(0x3fe401033af83d19L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=[B:[[119, 107, 57, 74, 70, 84, 111, 61]] |a0=[B:[[-62, 79, 73, 21, 58]]\0121=[B:[[119, 107, 57, 74, 70, 84, 111, 61]] |a0=[B:[[-62, 79, 73, 21, 58]]\012",
        Z.run(T, 2, 16, 16, 11, "\u48f2\ud87f\ude79\ud945\ude6a", "\u55d4\u0877\u4f30\ube4b\u9356\u4e27\ua62b\u4ae2\u99c4\u1ab1\u6ac3\u6829\ubcaa", "\ud9c3\udfc1\ud8fc\udf01\udbcd\udd70\ud93a\uddd9\ud89f\udd61\udbb6\udf2b\uda75\udc02\ud818\uddd9\ud942\udc6e\udb23\udc0a",
        35, 4868, -301999560, -5539670348435671425L, -29840L, true, true, (char) 19477, (char) 15985,
        Double.longBitsToDouble(0x3fe16424078b7a78L), Double.longBitsToDouble(0x3fe03116550b69a1L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 12, 18, "\u48f2\ud87f\ude79\u200d\ud931\udca8\udb05\ude46\ud8b9\udd94\ud96c\udd4f\ud962\ude65\ud806\udd25\udad6\udddb\udb54\udf2a\ud9f6\udc7d", "\ua62f", "\udb12\udcb8\ud844\ude84\ud9a1\udeaa\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud93a\udd47\ud89f\udd61",
        53, 19902, -682098718, 2151959134468179766L, -64892L, false, false, (char) 4395, (char) 59806,
        Double.longBitsToDouble(0x3f7892e945300300L), Double.longBitsToDouble(0x3fd2c8a9de7fe9aaL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-104, -68, -124, -20, -35, 16, -44, -43]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 8, 17, "\ud8c8\udcec\udbb4\udd1c\u200d\ud940\ude04\udb05\ude46\ud8b9\udd94\ud96c\udd4f\ud945\udfd6\ud856\ude96\udae9\udc9f\uda0e\udefb\uda0f\udf7d", "\ua62f", "\udb07\udddb\uda80\udd24\udb48\udd18\udb7d\udc2c\ud8c7\udcc6\ud913\udfcd\udbb8\udca1\ud898\udc00",
        22, 19793, 1817706466, -3224734489665943213L, -64892L, false, false, (char) 4395, (char) 59806,
        Double.longBitsToDouble(0x3fd3e0bba514c00cL), Double.longBitsToDouble(0x3fd2c8a9de7fe9aaL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 4, 7, 17, "\u48f2\ud87f\ude79\u200d\ud931\udca8\udb05\ude46\ud8b9\udd94\ud96c\udd4f\uda69\udf48\udaf0\udf09\udb42\udc01\udb54\udf2a\ud9f6\udc7d", "\ua62f", "\uda70\udfd2\ud844\ude23\ud9a1\udeaa\ud9c3\udfc1\ud8da\udf2b\ud856\udff7\ud93a\udd47\ud89f\udd61",
        53, 19902, -682098718, 2151959134704240438L, 5086L, false, false, (char) 2423, (char) 59806,
        Double.longBitsToDouble(0x3f7892e8964e1000L), Double.longBitsToDouble(0x3fd2c8ad5e7fe9aaL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=null\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 10, 6, 11, "\u48f2\ud87f\ude79\u200d\ud931\udca8\udb05\ude46\ud8b9\udd94\ud96c\udd4f\uda69\udf48\udafc\ude02\udb42\udc01\udb54\udf2a\ud9f6\udc7d", "\ua62f", "\udb12\udcb8\ud844\ude84\ud9a1\udeaa\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\ud93a\udd47\ud89f\udd61",
        36, 19902, -682098718, 2151959134468179766L, -64892L, false, false, (char) 8346, (char) 59886,
        Double.longBitsToDouble(0x3febd715d28a6006L), Double.longBitsToDouble(0x3fd2c8a9de7fe9aaL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 8, 17, "\u48f2\udb25\udebd\u200d\ud931\udca8\udb05\ude46\ud88f\ude16\ud96c\udd4f\uda69\udf48\udb80\uddcf\ud962\udd30\ud95a\udc27\ud9f6\udc7d", "\ua62f", "\udb12\udcb8\udaff\uddc2\ud9a1\udeaa\ud9c3\udfc1\ud8c7\udcc6\uda25\udf16\ud93a\udd47\ud89f\udd61\ud86c\ude0a\udb14\udcb7",
        58, 81030, 1696728886, -6018638484144949540L, -43467L, true, false, (char) 15552, (char) 29328,
        Double.longBitsToDouble(0x3fd2c8a9d32687aaL), Double.longBitsToDouble(0x3fe9ee2641c67d0bL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=[B:[[-62]] |a0=[B:[[-62]]\012",
        Z.run(T, 1, 13, 8, 16, "\u48f2", "\u8c53\u532e\u5611\u0877\u4f30\u3a70\u8a9c\u4e27\ua62b\u49e0\u7dea\u8cb5\u0f62\u997d\ud21f\uc868\uc1b4\u0381\u809e\ub265\u837a\u9e56\u54a9\u35c7\u4fb2\u36d3\u0713\u4531\u2735\u54e2\u180d\u7a06\uba0e\u5f69\u8bef\u6888\ua468\ua380", "\udad8\udd70\ud9f0\udccd\u5be1\ud91b\udf18\udbdd\udcad\ud8e1\uddab\udafe\ude53\ud86a\udfb1\uda4b\udc47\ud98c\udd3e\ud8e4\ude09\ud8b9\ude34\udad1\udefa\udbb7\udc9c\ud9da\udefd",
        25, 6987, -344938121, -139139074873211446L, -66292L, false, true, (char) 50818, (char) 31727,
        Double.longBitsToDouble(0x3fdae69d3d5daa78L), Double.longBitsToDouble(0x3fe25bdaa3b0a864L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=[B:[[100, 81, 97, 109, 51, 81, 13, 10]] |a0=[B:[[117, 6, -90, -35]]\012",
        Z.run(T, 1, 18, 0, 8, "\ud8a5\udc36\u52d6\u200d", "\000\000\u5f00\000\u6f08\u28cd", "\ud820\ude85",
        8, 66188, 244715426, 1103577441396644263L, -84357L, true, true, (char) 46, (char) 0,
        Double.longBitsToDouble(0x3e04d00000000000L), Double.longBitsToDouble(0x3e10000000000000L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[123, -87, 50, -65, 83]]\012",
        Z.run(T, 1, 5, 3, 16, "\ud9ab\uded9\ud862\udeef\u2083", "\u688d\uadfd\u4a07\u3155\ubcd5\u94aa", "\ud974\ude8f",
        11, 54916, 249677773, -4733087964825016956L, 97636L, true, true, (char) 16715, (char) 26563,
        Double.longBitsToDouble(0x3fdfa0bd2d0040ceL), Double.longBitsToDouble(0x3fe7c418c820c8f0L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-7, -57, 79, 126, -35]]\0121=[B:[[]] |a0=[B:[[-7, -57, 79, 126, -35]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 6, 12, "\udb29\uddf7\ud87f\udeae\u200d", "\u688d\uadfd\u4a07\u31ad\ubcd5\u94aa", "\ud974\ude8f",
        11, 66636, 244715347, -4733087964830849660L, 97636L, true, true, (char) 45090, (char) 652,
        Double.longBitsToDouble(0x3fe533a21bb37358L), Double.longBitsToDouble(0x3fe7c41c5f20c8f0L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[32, -68, -93, -101, -91, 17, 64, 4]]\012",
        Z.run(T, 1, 5, 11, 12, "\ud950\uddec\ud8d3\udecb\ud8d5\udf41\uda70\ude34\udb7d\udee3\ud9c5\udec0\udb99\udf9c\udb72\udd52\ud936\ude0c", "\ub2c8\u4ff2\u4322\ub790\u2925\uc34a\u869b\u18fa\u75b3\u0381\u78b1", "\ud878\udfa7\udb91\udd16\udb81\udf73\udab3\udf23\ud911\udfb9\ud852\udeae\ud82b\udf92\uda15\udd76\udb35\udd4a\u8157\udb24\udfea\ud912\udfc6\ud817\udee8\ud962\udc58\ud977\udef9\ud8df\udecd",
        31, 52725, 858011824, 1754056679316360062L, 84085L, true, false, (char) 42376, (char) 1154,
        Double.longBitsToDouble(0x3fd0986d747920dcL), Double.longBitsToDouble(0x3fe533fbf1259520L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=[B:[[56, 121, 52, 77, 105, 73, 111, 86]] |a0=[B:[[-13, 46, 12, -120, -118, 21]]\0121=[B:[[56, 121, 52, 77, 105, 73, 111, 86, 13, 10]] |a0=[B:[[-13, 46, 12, -120, -118, 21]]\012",
        Z.run(T, 2, 0, 1, 12, "\udb23\ude5e\udb3c\udeb8\udbba\udd45", "\u42d0\uadfd\u0f12\u74a5\ubcd5\u94aa\u8774\u0e89\u4a22\u0330\u2925\u88eb\u53b9\u67dc\u7543\u0381\u78b1\u0df4\ud3bc\u9c46\uc828\u4270\uaf0a\u8166\uc9e9\u704b\u6f5f\u5839\u35b1\u065d\ua0c5\uca87\u7f2b\u70ab\u70dc\ua685\u2f61\uaaed\u3772\u6b7a\ud275\u0d70\u21f0\ub613\u0b35\ubc29\uc9d9\ucd5f", "\udbf1\udcb6",
        -2, 41408, -2074072446, 6581421410629645419L, 63167L, true, false, (char) 45904, (char) 35839,
        Double.longBitsToDouble(0x3fca0e407ec921d4L), Double.longBitsToDouble(0x3fba1b45541e5c58L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=[B:[[-19, -109, 86, -12, -35, 1, 120, -117]] |a0=[B:[[-19, -109, 86, -12, -35, 1, 120, -117]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 3, 4, "\udb1d\uddc3\ud886\ude24\u200d\ud931\udca8\udbbb\udde0\udb42\uddcb\ud864\udf98", "\u154e\u94aa\u8774\u0e89\u0f36\u1a75\ud077\u86e2\ua6c7\u726f\u78a5\u0381\u70af\u6daf\u76bd\ubb16\uc828\u4461\u8eea\ubdbd\u2de2\u3ee1\u650c\u0843\u8bfe\u7e60\u2bf0\u8bba", "\uda1e\ude46\udbc5\udee6\udab3\udcae\ud983\udd36\ud8d2\udd03\uda3a\udd62\udb47\udceb\uda7c\udd9e\ud936\ude01\udb02\udd88\u1f1a\uda0c\udddc\uda45\udc0e\uda8f\udf43\udafc\udf6a\ud95f\udd90\ud958\udf3d\uda35\udfdf\uda97\udf2c\u2cee\ud8b8\ude66\uda4e\udd4b\uda11\udcfb\ud8e2\udf6b\udab9\ude34\udabe\udf03\udbd0\ude98\uda58\udea7\u7a05",
        0, 52795, 1939082148, -3494661290890426367L, 35114L, true, false, (char) 34915, (char) 25428,
        Double.longBitsToDouble(0x3fdd89ff926d4262L), Double.longBitsToDouble(0x3fee0ccae58a9727L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 16, 17, 13, "\ud82c\udeb9\ud98c\udf37\u203f", "\u8b83", "\udaf0\udf09\uda99\udd2d\ue664\udac3\udec5\udb4b\udf25\ud8ee\ude8c\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\udbe4\udc81\ud9d4\ude76\ud968\ude24\uad44\udbb6\uddc8\udb13\udfda\udab3\uddd7\uda27\udca3\uda8f\udc42\ud997\udd12\udb4b\udf8c\uda7e\udfcf\ud867\udc2a\uda51\uddf2\ud9c1\ude92\ud9d2\udfb2\ud8b9\udfa0\u2513\ud8ab\udd65\uda3e\udcae\ud8e5\udfa6\ud8bd\udd32\u7e53\ud893\udd96\ud8fd\udd87",
        52, 99298, -611223032, -1697210817103832090L, -85873L, false, true, (char) 41071, (char) 56355,
        Double.longBitsToDouble(0x3fde6304615b7ee6L), Double.longBitsToDouble(0x3fe1b663b63b3eb8L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=[B:[[105, 86, 119, 72, 68, 119, 61, 61]] |a0=[B:[[-119, 92, 7, 15]]\0121=[B:[[105, 86, 119, 72, 68, 119, 61, 61]] |a0=[B:[[-119, 92, 7, 15]]\012",
        Z.run(T, 2, 0, 0, 13, "\ucbb9\ud98c\udf37\u203f", "\u8b83", "\udaf0\udf09\uda99\udd2d\ue664\udac3\udec5\udb4b\udf25\ud974\ude8f\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\000\ud9d4\ude76\ud968\ude24\udb9f\ude5e\udbb6\udd01\udb13\udfda\udab3\uddd7\uda27\udca3\uda8f\udc42\ud997\udd12\ua0dc\uda48\udf44\ud867\udc2a\uda51\uddf2\u00a4\000\udb40\uddc0\u2513\ud8ab\udd65\uda3e\udcae\000\ud81c\uddee\u7e53\u0e8f\ud8fd\udd87",
        52, 43386, -611240463, -1697210817103832090L, -85873L, false, true, (char) 41071, (char) 44872,
        Double.longBitsToDouble(0x3fde6304615b7ee6L), Double.longBitsToDouble(0x3fab663b00000000L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=[B:[[47, 73, 108, 99, 66, 119, 56, 61, 13, 10]] |a0=[B:[[-4, -119, 92, 7, 15]]\0121=[B:[[47, 73, 108, 99, 66, 119, 56, 61, 13, 10]] |a0=[B:[[-4, -119, 92, 7, 15]]\012",
        Z.run(T, 2, 1, 17, 13, "\ud82c\udeb9\ud98c\udf37\u203f", "\u7124", "\ud8c7\udc3e\ud804\ude8f\udae8\udd78\udac3\ude71\udb4b\udf25\ud974\ude8f\udbc4\udc0a",
        57, 22512, -1133547773, 1876953178438911957L, 78600L, true, false, (char) 10633, (char) 25779,
        Double.longBitsToDouble(0x3fd804e64038f246L), Double.longBitsToDouble(0x3fe41df580dce791L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=[B:[[-4, 92, 95, 15]] |a0=[B:[[32, -4, 92, 95, 15]]\0121=[B:[[73, 80, 120, 99, 88, 119, 56, 61]] |a0=[B:[[32, -4, 92, 95, 15]]\012",
        Z.run(T, 2, 13, 17, 13, "\uda50\udc2c\ud98c\ude8f\u203f", "\u8b83", "\udaf0\udf09\uda99\udd2d\ue664\ud9ac\ude59\udb4e\udfdf\ud974\ude8f\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\udbe4\udc81\ud9d4\ude76\ud968\ude24\uad44\udbb6\uddc8\udb13\udfda\udab3\uddd7\ud9f4\ude6a\ud9de\ude2f\ud997\udc9a\udb4b\udf8c\uda7e\udfcf\ud867\udc2a\ud8ee\ude61\ud9c1\ude92\ud9d2\udfb2\ud8b9\udfa0\u2513\ud8ab\udd65\uda3e\udcae\ud8e5\udfa6\ud8bd\udd32\u7e53\ud893\udd96\ud8fd\udd87",
        52, 43386, -611240463, -1697210817103832090L, -85873L, false, true, (char) 41071, (char) 45124,
        Double.longBitsToDouble(0x3fde63046fd37ee6L), Double.longBitsToDouble(0x3fd4a34a4344b5e2L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=[B:[[80, 80, 66, 99, 66, 54, 106, 47, 113, 52, 48, 61, 13, 10]] |a0=[B:[[60, -16, 92, 7, -88, -1, -85, -115]]\0121=[B:[[80, 80, 66, 99, 66, 54, 106, 47, 113, 52, 48, 61, 13, 10]] |a0=[B:[[60, -16, 92, 7, -88, -1, -85, -115]]\012",
        Z.run(T, 2, 17, 2, 10, "\ud96c\udd20\ud98c\udf37\ud9d8\udc2f\udbdb\uddbd", "\uc9cb", "\ud97a\ude3d\ue664\udac3\udec5\uda15\udc1f\ud9d5\uddbc\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\udbe4\udc81\ud9d4\ude76\ud968\ude24\uad44\udbb6\uddc8\udb13\udfda\udab3\uddd7\uda27\udcec\uda8f\udc42\ud997\udd12\udb4b\udf8c\uda7e\udfcf\ud867\udc2a\uda51\uddf2\udae1\udf43\uda06\udf11\ud8b9\udfa0\u2513\ud8ab\udd65\uda3e\udcae\ud8e5\udfa6\ud8bd\udd32\u7e53\ud893\udd96\ud8fd\udd87\ud883\udfa9\udad1\udde3\ud942\udfcb\uda8c\ude5d\ud9b9\udc76\udb70\ude11\udb58\udf73\ud856\udfec\ud9a4\udc3e\ud91b\ude21\ud87e\ude18\u4f2b",
        36, 27685, 1400554202, -143393465278554582L, -85704L, true, false, (char) 343, (char) 5822,
        Double.longBitsToDouble(0x3fc0cffb7fd1a644L), Double.longBitsToDouble(0x3fc3b3add764e114L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 18, 18, 14, "\ud9fe\udfe7\ud9d8\udc6c\u4286", "\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa\u8774\u0e89\u4322\u2d88\u40d9\u97ff\u53bf\uc3d4\u7543\u785d\u4241\ub265\u76bd\u9c46\uc828\u4461\u8e6e\u81b5", "\udb73\udcd6\ud9c4\udd5c\ud8ad\udd7f\ud985\uddff\udb4a\uddd7\ud9b2\uddfd\udb2b\udd0e\udbf2\udc1e\udba6\udf0c\uda2d\uddd6\ud9c6\udd15\ud8cf\udc4c\u9ffd\ud9a5\udd00\ud871\uddde\udab2\udc49\uda9d\udd39\ud9a2\ude5e\udba0\udf56\ud9d7\udd5d\ued6b\uda12\udc6f\ud941\udd33",
        57, 95106, -1735786339, -4251501421031234668L, -8765L, false, false, (char) 51451, (char) 41588,
        Double.longBitsToDouble(0x3fc447619f89060cL), Double.longBitsToDouble(0x3fecd6d88ca8c112L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 8, 15, 7, "\ud899\udd8f\uda87\udf30\ud98f\uddaa", "\u01fb\u8ab3\u4f30\u3f3a\u8f40\u4167\u1db0\u0e9c\u4322\ub6109\u69ec", "\ud912\udf2b\ud9c3\udfc1\ud8c7\udcc6\udba7\uddf7\udbf5\udf64\ud887\ude62\udb76\ude81\ud9c1\udfc7\udb22\ude19\ud911\udfb9\udb39\ude31",
        3, 41895, 1439100227, -4134947686600866243L, 67673L, false, true, (char) 25206, (char) 9647,
        Double.longBitsToDouble(0x3fda4511e0e1d646L), Double.longBitsToDouble(0x3fed5ff2df75f392L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 14, 14, 0, "\ud82c\udeb9\udaa8\ude28\udbd1\udf87", "\u1a55\uaead\u4f30\u32be\u6f84\u94aa", "\ud974\ude8f",
        8, 66188, -2036441694, -1795075976632852893L, 39524L, true, false, (char) 43425, (char) 25366,
        Double.longBitsToDouble(0x3fe02b7063354605L), Double.longBitsToDouble(0x3fe27ffd68206182L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 4, 15, "\ud854\ude86\ud842\udd65\u200d\ud931\udca8\ud8f6\udd63\udb49\udefe\uda77\uddfb\uda52\udf78\udaf0\udf09\uda99\udd2d\udb7d\udf66\uda95\ude78", "\ubae8\u6ff0\uc440\u5b4d\u467f\u75ec", "\udba7\ude64\ud93d\udf68\ud874\uddb3\ud87c\udc13\uda6f\udcb3\udb08\udc01\ud8ab\udc7e\ud96a\udf74\uda6c\udd7d\udbb2\ude69",
        40, 32305, 1416787740, 3633891728504468513L, -38211L, true, false, (char) 22279, (char) 55916,
        Double.longBitsToDouble(0x3fd2e13a0ade8268L), Double.longBitsToDouble(0x3feea8929d8f3faeL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-110, 117, -5, 58, -35]]\0121=java.lang.Boolean:true |a0=[B:[[-110, 117, -5, 58, -35]]\012",
        Z.run(T, 2, 5, 5, 15, "\udac2\udea5\ud82b\udc6a\u200d", "\u0c0c\uc6be\u6f91\u6976\u7501\u2d80", "\udae8\udcb5\ud870\udd58\udbd4\udf3c\ud8fe\ude6b\udabc\udcfe",
        22, 49308, -1181520211, 8398329864317235542L, -39825L, false, true, (char) 46533, (char) 14993,
        Double.longBitsToDouble(0x3fdc9dad3844b7dcL), Double.longBitsToDouble(0x3fd4320b67dc08ccL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 7, 7, 16, "\udac2\udea5\ud82b\udc6a\ud821\udeb9", "\u7bdc\u2395\u4ecd\u2380\u6fbb\u94aa", "\udae8\udd84\ud870\udd58\udbd4\udf3c\ud983\uddb2\udabc\udd4a",
        22, 49308, -1970049363, 2317811694071645297L, -8377L, false, false, (char) 1038, (char) 3429,
        Double.longBitsToDouble(0x3fe8cbbd7c225b8dL), Double.longBitsToDouble(0x3fd4320b6b0208ccL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[6, 46, 9, 93, 22, 60]]\0121=[B:[[66, 105, 52, 74, 88, 82, 89, 56]] |a0=[B:[[6, 46, 9, 93, 22, 60]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 5, 14, 15, "\ud836\udd5e\uda39\udf8d\uda46\udd6c", "\u688d\uadfd\uaf9f\ube4b", "\udb35\udc61\ud885\ude84\udb78\udc42\udbaf\udd0a\udbcd\udd27\uda47\udda2\udb6b\udd63\ud9c2\udf26\u6005",
        9, 36211, -1721563954, 4051951141166020583L, 98138L, false, true, (char) 30737, (char) 17888,
        Double.longBitsToDouble(0x3fe8f638a18faeb7L), Double.longBitsToDouble(0x3fe70a31056697a5L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.math.BigInteger:147991 |a0=[B:[[65, 107, 40, -13, 73, 88]]\0121=[B:[[2, 66, 23]] |a0=[B:[[65, 107, 40, -13, 73, 88]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 6, 15, "\udb71\udc9b\udb58\udd23\udb79\udd88", "\u1a06\u1464\ucf54\ube4b\u6f6b\u94aa", "\uda56\udfb0",
        16, 66188, 1708789666, 455059158087280039L, 97838L, false, false, (char) 45090, (char) 24771,
        Double.longBitsToDouble(0x3fdfa50dcd0040ceL), Double.longBitsToDouble(0x3fe7c1e8ccefc8f0L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[61, 61, 83, 100, -85, 1, 11, -81]]\0121=[B:[[]] |a0=[B:[[61, 61, 83, 100, -85, 1, 11, -81]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 5, 6, 15, "\uad6d\udb6d\udf83\udb94\udddb\ud931\udd3b\udbdf\udee0\udb42\uddcb\udab3\udc1f\uda98\udffe\uda87\udda2\udbc6\ude79\ud97f\udd70\udb11\udc16\ud90b\udc19\ud974\ude8f\udbaf\udd0a\udbcd\udd27", "\uc3f7\u7543\uabcd\uae79\ub32f\u76bd", "\udb53\udfe2\ud84a\udcae",
        18, 32959, -1884922500, 7725772585904765978L, -52499L, false, true, (char) 39058, (char) 15378,
        Double.longBitsToDouble(0x3fe98700259332c6L), Double.longBitsToDouble(0x3fe79b484c71be17L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.math.BigInteger:588 |a0=[B:[[65, 107, 26, -13, -80, 12, -6, 120]]\0121=java.math.BigInteger:588 |a0=[B:[[65, 107, 26, -13, -80, 12, -6, 120]]\012",
        Z.run(T, 2, 12, 12, 2, "\udb71\udc9b\udb4a\udf23\ud9e0\udf3c\udb2a\udea8\udbdf\udee0\udb42\uddcb\ud927\udcab\ud865\udceb\ucdfa", "\ubcf3\u64d9\ud622\ua339", "\ud8ec\ude44\u838a\udbca\udf87\ud8aa\udf4a\ud94d\udc5f\udba7\udec1\udabc\udc28\ud862\udf95",
        8, 39447, 924432000, 2805867746043794997L, 68673L, true, false, (char) 4369, (char) 64272,
        Double.longBitsToDouble(0x3fd2989484498a84L), Double.longBitsToDouble(0x3fe13445c28a7f0dL)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[123, -87, -99, 123, 73, 88]]\0121=[B:[[33]] |a0=[B:[[123, -87, -99, 123, 73, 88]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 5, 6, 15, "\ud8ab\udcd9\udbcd\udfab\udb79\udd88", "\u688d\uadfd\ucf54\ube4b\u6f6b\u94aa\u8774", "\udbaf\udd0a\udbcd\udd27\uda47\udda2",
        22, 22807, 1699577139, 7103142727689803917L, -62136L, true, true, (char) 24771, (char) 22230,
        Double.longBitsToDouble(0x3fe401033af83d19L), Double.longBitsToDouble(0x3fcdf91e018488c8L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=[B:[[2, 66, 23]] |a0=[B:[[65, 107, 26, -13, 73, 88, 103, -110]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[2, 66, 23]] |a0=[B:[[65, 107, 26, -13, 73, 88, 103, -110]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 6, 6, 15, "\udb71\udc9b\udb4a\udf23\udb79\udd88\uda97\udec2\ud82f\udcad\udb22\udf1b\udaa1\udc72\ud9e4\ude8a\uda1c\udf05\udab7\udd05\ud807\ude7c", "\u3e19\u7ead\u2925\u2059\u1961\uc3f7\u7543\ud419\u4569\ub32f\u76bd\u9c46\uc874\u491b\ubdee\u81b5\u332f", "\udb1f\udc27",
        14, 45578, -891932448, -6600970974619415209L, 87166L, true, false, (char) 40515, (char) 4555,
        Double.longBitsToDouble(0x3f97ef74bbde6d80L), Double.longBitsToDouble(0x3fe9c7af6bed2dc4L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]]\012",
        Z.run(T, 2, 8, 11, 0, "", "\u5cd7\u8c41\u725b\u30d9\uadfd\u4f30\u2f22\u6f68\uc167\u8fca\ud258\ubd40\000\u28f1", "\udb55\udc51\ud862\uded9\udb84\udda6\000\ud9e0\udda2\ud93d\udf68\uda55\udefc\udb0a\udd6c\udb74\udc90\ud834\udeca",
        55, 37368, 710742841, 5347103742832662994L, 34319L, true, true, (char) 42084, (char) 60905,
        Double.longBitsToDouble(0x3fef435a29eb7c22L), Double.longBitsToDouble(0x3fc674743add3938L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=[B:[[111, 107, 73, 88, 121, 99, 72, 66, 13, 10]] |a0=[B:[[-94, 66, 23, -55, -63, -63]]\0121=[B:[[111, 107, 73, 88, 121, 99, 72, 66, 13, 10]] |a0=[B:[[-94, 66, 23, -55, -63, -63]]\012",
        Z.run(T, 2, 2, 2, 18, "\ud8d2\ude72\ud847\udff9\udbf1\udcf1", "\u5403\uae6c\u42eb\u2959\u599e\uca4b", "\udb29\udf55",
        49, 70462, 244726690, 6055566705274692996L, 70138L, true, true, (char) 32814, (char) 55461,
        Double.longBitsToDouble(0x3fdfc0f2dc6334daL), Double.longBitsToDouble(0x3fea0d09afba2071L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=[B:[[-4, -119, -66, 74, -48, -52, -77]] |a0=[B:[[-4, -119, -66, 74, -48, -52, 13, -77]]\0121=[B:[[-4, -119, -66, 74, -48, -52, -77]] |a0=[B:[[-4, -119, -66, 74, -48, -52, 13, -77]]\012",
        Z.run(T, 2, 13, 13, 15, "\ud82c\udeb9\ud8ee\udd7a\000\udafc\udf3d\udae3\udcba\udb42\uddcb\udafe\udc56\ud849\udc38\ud9e5\ude18\uda7c\udd83\uf270\ud9d8\udf1a\udb2f\udf75\ud974\udfbc\udbc4\udc0a\udbcd\udd27\uf87e\udb2e\udcfa\uda32\udca8\ud86e\ude79\udae5\uddb0\000\udb4b\udd54\ud93d\udf7a\ud878\udfb3\udb91\udd16\ud933\udc19\udb25\ude6d\u00f8\uda4d\udc2c", "\ucee2\u6ac2\u6afd\u8030\u785b\u154c\ub9fa\u9994\u4b6b", "\uda8d\udf30\uda43\ude8b\ud837\udf1f\udb79\udea7\ud9d5\udf76\udb28\udd11\ud935\udf8c\ud881\udcfd\ud849\udc7e\udbfa\udc94\u0e1d\udaa7\ude49",
        -5, 81504, 2115160539, -2257448933480651852L, 73232L, false, true, (char) 15969, (char) 52463,
        Double.longBitsToDouble(0x3feb2beaf6fa35ddL), Double.longBitsToDouble(0x3fecb74c9b528e79L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]]\012",
        Z.run(T, 2, 11, 11, 12, "\uda12\udd41\ud8ee\udddf", "\ud7ab", "\ud8ef\uddd8",
        28, 90106, -400249802, -2280707107052351792L, 27143L, false, true, (char) 25556, (char) 16997,
        Double.longBitsToDouble(0x3fd995734aea01e0L), Double.longBitsToDouble(0x3fe823e1570fd6bfL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=[B:[[]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 9, 18, "\udb60\udfdf\uda67\udcfc\udb38\udda1\ud8a7\udcb5\ud81f\udcf5\ud9de\udd91\udafd\udfe7\uda69\udf48\udaf0\udea6\udbb7\ude5d\ud8ff\udee9\ud9d8\ude25\udad0\udf05\ud974\ude3e\udbc4\udc0a\ud92b\udc0c\uf835\ub5f7\ud911\uddc8\ud86e\ude79\uda59\udd8a\ud8c7\udc59\uda8b\udc95\ubba1\ue8fe\uda21\udccf\uda59\udf55\ud89a\uddc7\ud87b\udddd\ud987\udd3b\udb27\udf3c\ud842\udd43\u2898\ud9c5\uddd8\udada\udfd0\udbb9\udfda\ud826\udc4d\udba8\ude0f\uda4f\ude63\ud935\udf67\ud903\ude5d\uda6a\udfd0\udb17\ude6a\ud98e\udf3f\ud871\ude18\udae4\udee5\udae6\ude6d\udb9f\udc26\uda2a\udd94\ud8e9\udf82\uda2f\udfa8\udb75\udde8\ud8d1\udd2d\udb72\udffb\ud8f3\udd9d\u30f0\uda80\udca4\ud997\udc6f\udbaf\ude16\ub3a3\ud972\udfef\ud92b\uded8\ud828\udf64\ud9f5\udc0f\udbd1\udcb2\uda69\udc2c\uda0b\udf51\uda16\udf8e\ud9b7\udfe9\uda8e\udc0b\uda57\udd10\u3ccf\ud939\ude62", "\ub3e4\uca26\u1245\u4997\u03d8\ucc7c\u1b59\u5001\u7ce4\ub00a\u0ebc\u336c", "\udb8b\uddf0\ud89b\udcb8",
        14, 52178, 1978196373, -6838730625266841826L, -17141L, false, true, (char) 37812, (char) 11266,
        Double.longBitsToDouble(0x3fb9538c0a495df8L), Double.longBitsToDouble(0x3fcdaec13e0a18b4L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 9, 13, 16, "\ud8a5\udc36\u52d6\u200d\ud907\uddec\ud943\udefd\udbbd\udfda\uac00\u5f00\udb5a\udf4c\udb9d\ude7e\udae2\udfa7\ud92f\udc4c\ud9e8\udd7d\udafd\udd23\ud947\udcf6\uda02\udd7a\udae5\uddb5\udbe8\ude8e\ud923\udd16\uf422\udb4d\udeaf\ud9e7\udd77\ud943\udee5\ud88c\udd32\udb64\uddf1\udb07\udcfe\udb4e\udcd3\udbd4\udff9\udabe\udd43\ud849\udf44\ud96a\udf55\ud915\udc55\udaaa\udc36\udb0e\udf77\ud9f9\udef5\ud8a1\udf42\udb6d\uddca\ud942\udf24\udbdb\udce4\uefa1\ud8af\udc14\ud82e\udce4\uda0f\udd60\ud8d5\udc7e\ud835\udc6b\udac2\ude1b\ud833\udcf3\u4881\udb83\udd86\udb37\udd4d", "\u177e\u8354", "\ud9a0\udfe0\ud8cd\udde1\uda1a\udc3d\ud85b\udc1d\ud91f\udc1a\uda47\udff3\ud85c\udd1e\ud902\udcb7\uda0e\ude43\ud876\ude8c\uda17\udec8\ud9d6\ude33\ud88e\ude1b\udb63\udc3e\uda58\uddc7\uda11\udd94\udb90\udd61\ud932\udfdf\ud966\udf77\ud93f\udcd8\udbe8\udca3\ud9cc\ude8d\udb10\ude7f\ud9ad\udc3e\ud95f\udfff\ud993\udc43\uda77\udc4a\ud860\udc35\ud88a\udc4f\ud8a3\udff0\udb0b\uddf7\udb48\ude49\udaa2\ude93\ud809\udee2\uda68\udfc7\ud90a\udca5\udb33\udd67\ud8b7\ude38\udbcd\udcf4\ud825\udd6b\ud95b\ude35\ud960\udc0e\ud97a\ude48\udb57\udcdd\udbf3\ude4f\ud805\udf8f\uda46\udd9a\udb2a\udd62\udaaf\uddb0\ud825\udea3\ud8e9\udc39\ud91f\ude27\ud89f\udec8\ud8ea\udf4a\udb36\udf26\ud8af\udd60\udb14\ude7f\ud9a0\uddb4\ud80c\udd58\ud90f\udd1d\ud88e\udd93\udb0c\udd5c\uda91\ude8c\ud992\udcaa\ud8da\udd06\u2a94\ud828\udc69\ud9a1\udd8f\udace\uddce\ud81e\udfad\ud95b\udc21\uf512\ud81b\udc3f\uda74\udd24\uda76\udd6c\uda99\udd78\udbc7\udef7\udbfb\udcef\udbe3\uddf3",
        -3, 7769, 1829980160, 5132995360345733195L, 74543L, false, false, (char) 27682, (char) 416,
        Double.longBitsToDouble(0x3fc567fd1803df10L), Double.longBitsToDouble(0x3fcbc79d1010fcdcL)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=[B:[[100, 81, 90, 115, 65, 88, 74, 111, 65, 88, 103]] |a0=[B:[[117, 6, 108, 1, 114, 104, 1, 120]]\0121=[B:[[100, 81, 90, 115, 65, 88, 74, 111, 65, 88, 103, 61]] |a0=[B:[[117, 6, 108, 1, 114, 104, 1, 120]]\012",
        Z.run(T, 2, 3, 0, 4, "\ud8a5\udc36\ud99c\udd31\udba2\udd98\ud931\udca8\013\000\000\uda6b\udf69\ud91a\ude05\uda99\udcca\u28cd\ud8bb\ude1d\ud934\uddb6\ud820\ude85", "\u88eb\ub3fc", "\udb78\udc1c\ud9e7\udd1c\udbde\udf0a\000\uda0c\udfc5",
        13, -1000, 150470784, 1148777385178196080L, -24938L, false, true, (char) 62272, (char) 19165,
        Double.longBitsToDouble(0x3fd7e034909cf016L), Double.longBitsToDouble(0x3fe2d9ee2481c08dL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-7, -57, 79, 126, 126, -104]]\0121=[B:[[]] |a0=[B:[[-7, -57, 79, 126, 126, -104]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 6, 12, "\udb29\uddf7\ud87f\udeae\udaae\udfc8", "\u688d\uc6bd\u4a07\u31ad", "\ud9d8\udf1a\ud934\uddb6\ud9d7\ude40\uda80\udefc\udad0\udce9\uf82f\ub5b4\uda32\udca8\ud8f3\udefb\uda62\udd38\ud86b\ude83",
        37, 199, -958433305, 8377806382524052134L, -38944L, false, false, (char) 59250, (char) 7420,
        Double.longBitsToDouble(0x3fe12788633cafeaL), Double.longBitsToDouble(0x3fd853b6c4f9399aL)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=[B:[[92, 95, -19, 57]] |a0=[B:[[10, 10, 92, 95, -19, 57]]\0121=[B:[[67, 103, 112, 99, 88, 43, 48, 53]] |a0=[B:[[10, 10, 92, 95, -19, 57]]\012",
        Z.run(T, 2, 13, 17, 13, "\uda3a\ude3a\ud98c\ude8f\uda1d\udd69", "\u8b83", "\udaf0\udf09\uda99\udd2d\ue664\ud9ac\ude59\uda69\udc3c\ud97d\uddba\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\udbe4\udc81\ud9fc\ude6a\ud968\ude24\uad44\udbb6\uddc8\udb13\udfda\udab3\uddd7\ud9f4\ude6a\ud9de\ude2f\ud997\udc9a\udb4b\udf8c\uda7e\udfcf\ud867\udc2a\ud8ee\ude61\ud9c1\ude92\ud9d2\udfb2\uda18\udc0e\u2513\ud8ab\udd65\uda3e\udcae\ud8e5\udfa6\ud8bd\udd32\u7e53\ud893\udd96\ud8fd\udd87",
        52, 43386, -611240463, -1697210817103832090L, -85873L, false, true, (char) 41071, (char) 45124,
        Double.longBitsToDouble(0x3fde63046fd37ee6L), Double.longBitsToDouble(0x3fe251a523a6251bL)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=[B:[[-4, 92, 95, 15]] |a0=[B:[[32, -4, 92, 95, 15]]\0121=[B:[[-4, 92, 95, 15]] |a0=[B:[[32, -4, 92, 95, 15]]\012",
        Z.run(T, 2, 13, 13, 13, "\uda50\udc2c\ud98c\ude8f\u203f", "\u8b83", "\udaf0\udf09\uda99\udd2d\ue664\ud9ac\ude59\udb4e\udfdf\ud974\ude8f\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\udbe4\udc81\ud9d4\ude76\ud968\ude4e\uad44\udbbc\udcc8\udb13\udfda\udab3\uddd7\ud9f4\ude6a\ud9de\ude2f\ud997\udc9a\udb4b\udf8c\uda7e\udfcf\ud867\udc2a\ud8ee\ude61\ud9c1\ude92\ud9d2\udfb2\ud8b9\udfa0\u2513\ud8ab\udd65\uda3e\udcae\ud8e5\udfa6\udaca\udc92\u7e53\ud893\udd96\ud8fd\udd87",
        52, 43386, -611240463, -1697210817103832090L, -85873L, false, true, (char) 41071, (char) 45124,
        Double.longBitsToDouble(0x3fde63046fd37ee6L), Double.longBitsToDouble(0x3fd4a34a4344b5e2L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=[B:[[122, 112, 121, 111, 80, 70, 89]] |a0=[B:[[-50, -100, -88, 60, 86]]\0121=[B:[[122, 112, 121, 111, 80, 70, 89]] |a0=[B:[[-50, -100, -88, 60, 86]]\012",
        Z.run(T, 2, 18, 18, 14, "\ud9fe\udfcc\ud9d8\udc6c\u4286", "\u6d47\uadfe\u4f30\ube4b\u6f6b\u94aa\u8774\u0e89\u4322\u2d88\u40d9\u97ff\u53bf\uc3d4\u7543\u785d\u1676\uc805\u76cd\u9c46\uc828\u4461\u271b\u81b5", "\uda6e\uddb4\udb7a\udf69\ua164\uda9d\udc8f\ud8f3\ude51\udb4e\udfe5\ud8a1\udf51\udaf8\ude43\udba6\udf0c\uda2d\uddd6\ud9c6\udd15\udab4\udedd\udacb\udcb8",
        18, 48124, -2081011815, 7072102155581144149L, -55546L, false, true, (char) 32093, (char) 22988,
        Double.longBitsToDouble(0x3fe97996e992bb8eL), Double.longBitsToDouble(0x3fee60c943f86e3bL)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 7, 7, 16, "\udb86\udd66\ud841\ude23\ud93b\udfc7", "\u01af\u84af", "\uda99\udd7d\udb7d\udf66\uda95\ude78\uda5d\udcac\udaa0\udcb8\ud870\udced\udbd4\udf3c\ud983\uddb2\udabc\udd4a\uda12\udf53\ud8f5\udc6e\udacd\udf33\ud8ed\udf5a\udba7\ude64\ud93d\udf68\ud873\udcf2\ud87c\udc13\ud9d2\udf24\ud9f4\uddab\ud936\udc81\uda7c\ude13\uda5f\udc49\ub276\uda86\udd70\ud899\ude76\udacd\uddb7\ud9e4\udc51\ud854\udeca",
        36, 84519, -1754013135, -2324535181903019673L, -807L, false, false, (char) 13868, (char) 38024,
        Double.longBitsToDouble(0x3fc863f8a0c19d00L), Double.longBitsToDouble(0x3fdc513c5aa0b2e2L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[61, 61, 83, 100, 110, 1, 11, -81]]\0121=[B:[[]] |a0=[B:[[61, 61, 83, 100, 110, 1, 11, -81]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 10, 6, 15, "\uad6d\udb6d\udf83\udb94\udd9e\ud931\udd3b\udbdf\udee0\udb42\uddcb\udab3\udc1f\uda98\udffe\uda87\udda2\ud982\ude77\ud97f\udd70\udb11\udc16\ud90b\udc19\ud9f9\udc66\udbaf\udd0a\udbcd\udd27", "\uc3f7\u7543\uabcd\uae79\ub32f\u76bd", "\udb53\udfe2\ud84a\udcae",
        18, 95790, -1885891904, 7725772585982419994L, -24439L, true, true, (char) 50996, (char) 43091,
        Double.longBitsToDouble(0x3fce6d2131c6f85cL), Double.longBitsToDouble(0x3feb84f352921831L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[61]]\0121=java.lang.Boolean:true |a0=[B:[[61]]\012",
        Z.run(T, 2, 5, 5, 8, "\uad6d", "\u8ce6\u4513\u688d\uc04e\u7a8c\uca93\ua449\u5d56\ua62e\u40eb", "\ud9a6\udc34\uda47\uddea\udbf0\udc06\uda32\udccb\ud912\udf2b\ud832\uddb7\ud8b9\udcd5\udba7\udec1\ud93d\udf68\ud878\udfb3\ud8fb\ude8c\ud9e5\ude8f\ud84a\udcae\ud93b\ude01\udbaf\udffc\u5edd\uda02\udf8d\ud9fc\udd18\uda08\udc3f\ud96d\udd9a\udbeb\udc8e\udaef\udcba\ud9f2\udfae\ue22e\uda9c\udfc3",
        25, 70209, -1408475620, -3703202899528790504L, 12727L, false, true, (char) 33971, (char) 56430,
        Double.longBitsToDouble(0x3fcdcd81fb5dc360L), Double.longBitsToDouble(0x3feb7ede9be6ea51L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=[B:[[76, 71, 53, 80, 83, 81, 61, 61]] |a0=[B:[[44, 110, 79, 73]]\012",
        Z.run(T, 1, 0, 14, 15, "\uda5c\udd9e\ud87f\ude79", "\u3ec8\u688d\uadfd\u4f30\ube4b\u6f6b\u94aa\u8774", "\udbc4\udc0a\udbcd\udd27\uf87e",
        0, 22772, 1699577139, -8461297583507470987L, -62136L, true, true, (char) 24771, (char) 22230,
        Double.longBitsToDouble(0x3fe401033af83d19L), Double.longBitsToDouble(0x3fa0647862202f30L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=[B:[[95, 73, 108, 99, 66, 119, 45, 114, 106, 81, 13, 10]] |a0=[B:[[-4, -119, 92, 7, 15, -85, -115]]\0121=[B:[[95, 73, 108, 99, 66, 119, 45, 114, 106, 81, 13, 10]] |a0=[B:[[-4, -119, 92, 7, 15, -85, -115]]\012",
        Z.run(T, 2, 3, 3, 18, "\ud82c\udeb9\ud98c\udf37\u203f\udbdb\uddbd", "\uc9cb", "\udbd8\udebc\u79bb\udac3\udec5\udb4b\udf25\ud975\udd18\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\udbe4\udc81\ud9d4\ude76\ud968\ude24\uad44\udbb6\uddc8\udb13\udfda\udab3\uddd7\udac4\udd5c\uda8f\udc42\ud997\udd12\udb4b\udf8c\uda7e\udfcf\ud867\udc2a\uda51\uddf2\ud9c1\ude92\ud9d2\udfb2\ud855\udf0d\udaa5\udd03\ud8ab\udd65\uda3e\udcae\ud8e5\udfa6\ud8bd\udd32\u7e53\ud990\udfcb\ud873\udfbe\udb0f\udc33\udad1\udde3\ud942\udfcb\uda8c\ude5d\ud9b9\udc76\udb70\ude11\udb58\udf73\ud856\udfec\udbaf\ude03\ud905\udd21\ud87e\ude18\ud81a\udd05",
        31, 65760, -50593905, -5736781951544016362L, 42960L, true, true, (char) 32263, (char) 7589,
        Double.longBitsToDouble(0x3feb2c732e46bf6dL), Double.longBitsToDouble(0x3fc3687da3f9ab18L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 8, 8, 15, "\udaad\udcc6\ud993\udd7d\u200d", "\u1ec0\u55fb\u4ecd\u5569\u63dc\u054b", "\udae8\udcb5\ud92b\ude37\udbd4\udf84\udb46\udc2e\ud922\udec9",
        33, 22714, -1963735825, 2317811694071645297L, -73913L, false, false, (char) 1038, (char) 17885,
        Double.longBitsToDouble(0x3fe8cbbe9c225b8dL), Double.longBitsToDouble(0x3fd4320b67dc08ccL)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.binary.Base64:@?\0121=void |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 9, 15, "\udb71\udc9b\udb4a\udf23\udb79\udd88", "\u809b\u0bc2\000\ubde4\u5ef1\u811c", "\ud974\ude8f",
        16, -1000, 0, 455058174539769255L, -71667L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f2c000000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 11, 17, 8, "\000\000\000\ud931\udc96\013\000\000\uda6f\udfcc\000\udb57\udd2b\000\ud8bb\ude1d\ud258\000\udb8b\udd25\ud98b\udfc2\udba5\udc93\udb6f\udcf8\udae0\ude4a\ud8e0\udfe5\ud8ea\ude18\udab0\udd92\ud928\udd76\uda62\udc5c\udaaa\udc4f\ud8b4\udc3f\ud902\udcc1\ud8fe\udc95\uda93\ude1c\ud9b7\udf69\ud930\udd18\udb1c\udc6c\ud815\udcb6\u7618\ud8a6\udf61", "\u61e6\ucf28\u6d48\u7e29\u7845", "\ud8fc\udea9\ud84b\udc34\ud8e6\udea9",
        1, 77219, 1996745064, -2517312225999928108L, -31956L, false, false, (char) 49698, (char) 26530,
        Double.longBitsToDouble(0x3fea52d566991eeaL), Double.longBitsToDouble(0x3fe6826e8866440bL)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=[B:[[-4, -119, -66, 74, -24, 90, 102]] |a0=[B:[[-4, -119, -66, 74, -24, 90, 102, 9]]\0121=[B:[[-4, -119, -66, 74, -24, 90, 102]] |a0=[B:[[-4, -119, -66, 74, -24, 90, 102, 9]]\012",
        Z.run(T, 2, 13, 13, 15, "\ud82c\udeb9\ud8ee\udd7a\udb18\udc8a\udb96\ude39\udae3\udcba\udb42\uddcb\udafe\udc56\ud849\udc38\ud9e5\ude18\ud964\udfb8\uf270\ud9d8\udf1a\ud894\udd2e\ud991\udf14\udbc4\udc0a\udbcd\udd27\udaca\udcbf\udbb1\ude79\ud9d0\udd16\ud86e\ude79\udae5\uddb0\ud8c7\udcc0\uda9c\ude00\ud973\udec7\ud878\udf67\udb91\udd16\ud933\udc19\udb25\uddbd\ud911\udfb9\uda4d\udc4c", "\ucee2\u6ac2\u6afd\u8030\u785b\u154c\ub9fa\u0c06\u4b6b", "\uda8d\udf30\uda43\ude8b\ud88c\udc89\udb49\udf10\ud9d5\udf76\udb28\udd11\ud935\udf8c\uda3a\udd9a\ud849\udc7e\udbfa\udc94\u0e1d\ud881\udcfa",
        -5, 81504, 1511180763, 3044845187369610797L, 73232L, false, true, (char) 65378, (char) 52463,
        Double.longBitsToDouble(0x3fe2c3eaf6fa35ddL), Double.longBitsToDouble(0x3fecb74c9b528e79L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[60, -16, 92, 7, -88, -1, -85, -115]]\0121=java.lang.Boolean:false |a0=[B:[[60, -16, 92, 7, -88, -1, -85, -115]]\012",
        Z.run(T, 2, 5, 5, 4, "\ud96c\udd20\ud98c\udf37\ud9d8\udc2f\udbdb\uddbd", "\uc9cb", "\ud97a\ude3d\ue664\udac3\udec5\uda15\udc1f\ud9d5\uddbc\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\udbe4\udc81\ud9d4\ude76\ud968\ude24\uad44\udbb6\uddc8\udb13\udfda\udab3\uddd7\uda98\ude45\uda8f\udc42\ud997\udd12\udb4b\udf8c\uda7e\udfcf\ud867\udc2a\uda51\uddf2\udae1\udf43\uda06\udf11\ud8b9\udfa0\u2513\ud8ab\udd65\uda3e\udcae\ud8e5\udfa6\ud8bd\udd32\u7e53\ud893\udd96\ud8fd\udd87\ud883\udfa9\udad1\udde3\ud942\udfcb\uda8c\ude5d\ud9b9\udc76\udb70\ude11\udb58\udf73\ud856\udfec\ud9a4\udc3e\ud91b\ude21\ud87e\ude18\u4f2b",
        36, 27685, 1400554202, -6484461743326123097L, -85704L, true, false, (char) 343, (char) 5822,
        Double.longBitsToDouble(0x3fc0cffb7fd1a644L), Double.longBitsToDouble(0x3fc3b3add764e114L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 18, "\ud82c\udeb9\ud87c\uddaf\u206a\uda0c\udf8f", "\ucb5e\u2dcb", "\u79bb\uda26\udcda\udb4b\udf25\ud975\udd18\udbc4\udc0a\udbcd\udd27\uf87e\ud9f7\udc5d\udbe4\udc81\ud9d4\ude76\ud968\ude24\uad44\udbb6\uddc8\udb13\udfda\udab3\uddd7\ud813\ude1f",
        10, 73147, 1904757421, -5785761530326958545L, 66820L, false, false, (char) 9896, (char) 28926,
        Double.longBitsToDouble(0x3fbc8f9f247880f8L), Double.longBitsToDouble(0x3fc077c6ecfeb5f8L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=[B:[[111, 66, 118, 48, 72, 55, 111, 61]] |a0=[B:[[-96, 27, -12, 31, -70]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 14, 2, 8, "\ud8d0\udc4b\uda24\ude4f\uf0ea", "\u5804\u89c3\uc0cd\uc8ea\u9e60\u973e\u783e\u4dfb\u431c\ub610\u1611\uc7da\u8bbc\u5354\uab18\u7744\u9dc5\u7985", "\ud996\udeca\udb53\udf20",
        50, 68227, 1949617472, -2806748368886596697L, 49994L, false, false, (char) 14712, (char) 57897,
        Double.longBitsToDouble(0x3fe64e5c1eab2352L), Double.longBitsToDouble(0x3febf504dff3ffa0L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 14, 14, 5, "", "", "\ud8db\udd2f\ud828\udc9e\000\ud879\ude05\u00d7\uda96\uddca\udb7d\udf66\ud9d8\udf1a\ud938\udd4e\ud820\ude85\ud9fc\udcdb\ud866\udc40",
        43, -1000, -1382767360, 7299628506136407725L, 97636L, false, true, (char) 47872, (char) 45468,
        Double.longBitsToDouble(0x3fdfa50c7e1956ceL), Double.longBitsToDouble(0x3fe000000000c8f0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean,boolean,int|static",
    "M|org.apache.commons.codec.binary.Base64|avail||new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|containsBase64Byte|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.String|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|java.lang.String|static",
    "M|org.apache.commons.codec.binary.Base64|decodeInteger|[B|static",
    "M|org.apache.commons.codec.binary.Base64|discardWhitespace|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean,boolean,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
