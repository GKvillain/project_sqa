package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class CharSequenceUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda0e\ude5d\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udae8\udff0\ud875\udf9f",
        39, 69430, -1970382620, -8263755903336693019L, -50277L, true, true, (char) 41973, (char) 45679,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe640449925622aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 11, 15, "\uda0e\udd7e\ud864\ude50", "\ucccd\u1ac4\u19c1\ua95c\ua033\u78a5\ua9d2\u11fa\u978a", "\ud85b\udcff\udbcc\udc9c\ud9e1\uddab\ud875\udf9f\ud867\udecd\ud8cc\udc1b\ud87e\uddf8\udb49\udf07\udb26\udf4f\udb2b\udfe6\ud87b\udf20\udb7a\udf90\ud97f\ude81\udadc\udded\uda94\udff1\ud983\udfae\udaa5\udf92\ud8a2\udc4e\udbb6\udc19",
        39, 70492, 1081416784, -7135068665946851225L, -5794L, false, true, (char) 14038, (char) 29525,
        Double.longBitsToDouble(0x3fc4640246bd25e8L), Double.longBitsToDouble(0x3fc16793bc9e6f08L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\udbf7\udff2\ud98b\udf7e\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\ud95f\udd95\ud808\ude6a\udbae\udedc", "\ubcc1\u8d3a\u40ef\uc86d\u4b38", "\ud8e1\udc1b\ud87e\uddf8\udb49\udf07\udb26\udf4f\udb2b\udfe6\ud87b\udf20\udb7a\udf90\udab0\ude67\ud8e7\udd33\udbac\udd48\ud984\udc78\udbee\udc90",
        -1, 24180, 467838720, 1921312628129995400L, 82541L, false, false, (char) 34671, (char) 41329,
        Double.longBitsToDouble(0x3fe42b9dedd4c8fcL), Double.longBitsToDouble(0x3fd675759eeb7368L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ud859\udf5e\ud890\udf46\udb41\udd74\udb66\ude27\u88b9\ud82e\ude1a\udb0a\udec5\ud827\udfeb\udb63\udcb6\ud98d\udefc\ud8a2\uddc9: null\0121=[B:[[89, -40, 94, -33, -112, -40, 70, -33, 65, -37, 116, -35, 102, -37, 39, -34, -71, -120, 46, -40, 26, -34, 10, -37, -59, -34, 39, -40, -21, -33, 99, -37, -74, -36, -115, -39, -4, -34, -94, -40, -55, -35]]\012",
        Z.run(T, 2, 13, 11, 15, "\ud859\udf5e\ud890\udf46\udb41\udd74\udb66\ude27\u88b9\ud82e\ude1a\udb0a\udec5\ud827\udfeb\udb63\udcb6\ud98d\udefc\ud8a2\uddc9", "\u4cb0", "\udbcc\udc9c\udae8\udff0\ud875\udf9f\ud867\udecd\ud8e1\udc1b\ud87e\uddf8\udb49\udf07",
        27, 9376, -883899845, -7470678291315291229L, -53031L, true, false, (char) 63571, (char) 39759,
        Double.longBitsToDouble(0x3f95f869f189abe0L), Double.longBitsToDouble(0x3fef36dba4ec05d7L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 3, 4, 7, "\uda0e\ude5d\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud875\ude04\udb63\udcb6\ud98d\udefc\ud873\udedd", "\ubcc1", "\udb38\udce3\ud945\udc20\ud851\ude1e",
        39, 69430, -1970382620, -8263755804552445211L, -50277L, true, true, (char) 6389, (char) 45452,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe640449925622aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\u91a3\udb9a\udc16\udb41\udceb\udb66\ude27\u88b9\udb25\uded4", "\u0eb4\ua5c7\u366f\u12ba\u5ba8\ud6e9", "\uda3f\udcd6\udae8\udff0\ud875\udf9f",
        39, 69430, -1970382620, -913881311682120991L, -50277L, true, true, (char) 43161, (char) 35474,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe640449eafa054L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 4, 17, "\ud8a4\ude56\ud902\udd04\udaaf\udefe\ud979\udcb3\ud8fa\udd30\udb13\udcca\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc", "\uc837\ubcc1\u30e9", "\udae8\udff0\udacc\udf9c\ud867\udecd",
        10, 25380, -1921394230, 527839133730356249L, -10569L, true, true, (char) 45679, (char) 27011,
        Double.longBitsToDouble(0x3fefbb93bb4b3c89L), Double.longBitsToDouble(0x3fd25622a3c85142L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[B:[[63]]\012",
        Z.run(T, 1, 6, 10, 0, "\ud816\udd6a", "\u1cfd\u929e\u1ac4\u19c1\u5c9f\u1084\ua56d\ua61e\uc6b9\uc837\ubcc1\u8d3a\u1194\uc86d\u3ad4\u405b\uc805\000\u3c25\u3dca\uc348\u8899\u036b\u2ecc", "\udbac\udd48",
        22, 12680, -1919993563, 5078288474764164488L, -57973L, false, false, (char) 25322, (char) 1233,
        Double.longBitsToDouble(0x3fe741d39ff77ac1L), Double.longBitsToDouble(0x3fe6ce5652200476L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda0e\ude5d", "\u1cfd\ucccd\u1ac4\u19c1\u5c9f\u0508\ua5c7\ua61e\u12ba\uc837\ubcc1\u8d3a\u41ad\uc86d\u4b38\u405b\u1062\u45e2\u8a02\uaddd\uc348\u8899\ub3c9\u2ecc", "\udbac\udd48\ud984\udc78\udbee\udc90",
        41, 110, -267324501, -6769339062140232668L, -96667L, false, true, (char) 65278, (char) 57541,
        Double.longBitsToDouble(0x3fc90b9c1c7265ecL), Double.longBitsToDouble(0x3fd3b236c9fc58e4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -40, 106, -35, -69, -40, 100, -34, 80, -37, 65, -36, -21, -37, 102, -34, 39, -120, -71, -39, 3, -35, 36, -37, 10, -34, -57, -18, -98, -38, -82, -36, 81, -39, -115, -33, -108, -37, -41, -36, -33]]\012",
        Z.run(T, 1, 9, 4, 7, "\ud86a\uddbb\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\ud903\udd24\udb0a\udec7\uee9e\udaae\udc51\ud98d\udf94\udbd7\udcdf", "\ubcc1", "\ud820\udc06\udab2\udd60\ud81b\udd2a\ud867\udecd\uda44\udd01\ud8b1\uddef\udb49\udf07\udb26\udf4f\ud8d3\udf5b\ud87b\udf20\udb7a\udf90\ud97f\ude81\udb56\ude6b",
        52, 2543, 1646946867, 6482696525435102760L, -25968L, true, true, (char) 1276, (char) 52710,
        Double.longBitsToDouble(0x3fe658e05ba7c156L), Double.longBitsToDouble(0x3fd5900a7d4205d4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ub0ed\ud864\ude50\000\udb66\ude27\u88b9\udb25\uded4\000\000\000\000\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udae8\udff0\ud875\udf9f",
        39, 35510, -1970382848, -8263755903336693019L, -99941L, false, false, (char) 2979, (char) 45679,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe640449925622aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda0e\ude5d", "\u1f01", "\udb0a\udec5",
        21, -1000, 0, 0L, -100000L, false, false, (char) 20967, (char) 18029,
        Double.longBitsToDouble(0x3f3a98b5fdc00000L), Double.longBitsToDouble(0x3faa800009e2c050L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.CharSequenceUtils:@?\0121=new org.apache.commons.codec.binary.CharSequenceUtils:@?\012",
        Z.run(T, 2, 4, 4, 7, "\uda0e\ude5d\udbb9\ude76\ud9ce\udf15\udb3c\udd36\u88b9\uda79\udf3f\ud8b0\udec9\ucb3e\ud804\uddcc\uafd4\udbdb\udd15", "\ubd9a\ubc5d\uc095\u3ebe\u28da\u38e8\u1062\uc503\ud5b1\uaddd\uc348\uc5ee\ub953\u2ecc\ub5ec\u6c0e\uca34\u9a21\u9f20\ub207", "\ud869\ude3f\ud9fc\udf21\udb05\udebf\udae6\udcfe\uda54\udc79\uda50\udeb1\ud8da\udf83\udbf1\udff3\ud8a3\udca9",
        33, 14138, -1222822371, 8423845838774261223L, 83171L, false, false, (char) 27762, (char) 58652,
        Double.longBitsToDouble(0x3febd01c77d02335L), Double.longBitsToDouble(0x3fe33664a5e0fb34L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda84\udcad\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd\udad9\udff4\u0335\ud9cd\ude4f\uda3a\udf2e\ud85b\udcff\udbcc\udc9c\udae9\udc33\ud875\udf9f\ud867\udecd\ud8e1\udc1b\ud87e\uddf8\udb49\udf07\udb26\udf4f\udb2b\udfe6", "\uac70\u82f3\u0f64\u39e5\u9f20\u66ba\u6093\u89d7\u1dd6\u157f\u7d19\u55d4\u7881\u0216\ua9af\u6fcc\u48a4", "\ud9ba\ude76\uda92\udd10\udb51\udc68\ud83d\udcb4\udac6\udf7f\ud8fc\udfd9\ud8c7\udc7d\udbd0\udc22\ud901\ude55\ud867\udeb8\uda6d\udd52\udb57\udd2e\ud84a\uddee\udb4f\uddbc\u5988\udbf6\udf5b\udb49\udd09\udb36\udcdb\ud8ed\udee2\ud97a\udc18",
        19, 86255, 1570123179, 6819181349814620490L, -56971L, false, true, (char) 40389, (char) 14960,
        Double.longBitsToDouble(0x3fea240ef37cc5a7L), Double.longBitsToDouble(0x3fccba1144d72f60L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 7, 7, "\uda0e\ude5d\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\udbb3\udcbe\ud98d\udefc\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udaf7\uddf0\ud875\udf9f",
        39, 35726, 41018072, -3280840842015391003L, -50124L, true, true, (char) 55541, (char) 64675,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe640449925622aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 4, 4, "\ud940\udec8\ud864\ude50\udb41\udd22", "\u1ac4\u19c1\u5c9f\u2b07\ua5c7\ua21c\u120d\uc4a4", "\ud85b\udcf6\udbcc\udc9c\udae8\udff0\ud874\udd9f\ud988\udfd8\ud8e1\udc1b\ud87e\uddf8\udb61\udd07",
        27, 9249, -883899845, 2479887645359634662L, -82730L, true, false, (char) 20838, (char) 8866,
        Double.longBitsToDouble(0x3fed1ee0decae3d6L), Double.longBitsToDouble(0x3fbe147346c4a6a8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda0e\ude5d\ud864\ude50\udb41\udceb\udb66\ude27\ud9ae\udc48\udb25\uded4\udb0a\udec5\ud875\udee4\uda4f\ude61\ud9af\uddc7\ud937\udedf", "\ucfc2\u8d3a\u41ad\uc86d\ub403\u3b76\u1062\u5867", "\udaeb\udc34\ue086\ud9b3\udd7b\ud9a5\udf8e\ud85b\udf09\udb51\udefa\udbac\udd1a\ud99c\udd78",
        21, 18837, 1001519441, -2327192946923644546L, 45196L, true, false, (char) 42982, (char) 7897,
        Double.longBitsToDouble(0x3feddf3703f63f35L), Double.longBitsToDouble(0x3fdaa5797738320cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 7, 12, 7, "\uda0e\ude5d\u00c1\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\u548c\ub636\udb63\udcb6\ud98d\udefc\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udae8\udff0\u00bf",
        -5, -1000, -1970405376, 867584721637L, 28093L, true, false, (char) 27011, (char) 29303,
        Double.longBitsToDouble(0x3fe640400125622aL), Double.longBitsToDouble(0x3fe593bce57d63caL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[B:[[-14, -109, -87, -99, -16, -87, -119, -112, -13, -96, -109, -85, -13, -87, -88, -89, -24, -94, -71, -13, -103, -101, -108, -15, -68, -122, -95, -16, -112, -73, -85, -13, -82, -77, -117, -15, -71, -89, -68, -16, -84, -69, -99]]\012",
        Z.run(T, 1, 12, 7, 7, "\uda0e\ude5d\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\ud9b0\udda1\ud803\uddeb\udb7b\udccb\ud9a6\uddfc\ud873\udedd", "\ub10f", "\ud981\udcd7",
        39, 91072, 738579584, 6711927626951186660L, -50277L, true, true, (char) 41973, (char) 45679,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe640449925622aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 15, 6, 7, "\uda0e\ude5d\uc0f7\ud9dd\udccd\udb49\udeb6\u88b9\udb25\uded4\uda37\udf3c\udb8f\udc71\udb63\udcb6\ud98d\udefc\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udae8\udff0\ud875\udf9f",
        39, 69430, -1970382620, -4877048983554080027L, -50277L, true, true, (char) 41973, (char) 45679,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe640449f25622aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 3, 4, 13, "\ud91c\ude2a\ud917\udfcb\ud83a\udcf2\ud912\udcdc\ud86d\udcbf\uf24e\ud977\udce9\ud9dc\udf6a\udb5e\udc7d\u4aa0\udbc6\udd39", "\u6a33\u8d3a\ua8ac\uc81a", "\ud867\udecd\ud8e1\udc1b\uda0d\udf21\ud8b9\uddc0\uda53\udf4a\ud815\udcbb\ud97a\udd19\udbf9\udf71\udb45\uddb4\ud8e7\udd2f\ud86e\ude02\ud9bb\udcc6\ud991\udc48\uda8e\udeaa\udb02\ude11",
        41, 66137, -303151331, -8855618960430863817L, -64790L, false, true, (char) 48466, (char) 32487,
        Double.longBitsToDouble(0x3f86cd89b0651440L), Double.longBitsToDouble(0x3f8de243751bd140L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 6, 11, "\ud984\ude16\u1499\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud94d\udc0a\udbf6\udd82\ud85e\udce5\ud9cd\udf26\uda3a\udf2e\uda55\udcdb\udbcc\udc9c\udae8\udff0\ud875\udf9f\ud867\udecd\uda21\udedc\ud87e\ude01\ud98e\udc48\udbca\udf4f\ud816\udce3\uda90\ude4b\udb7a\udef9\ud97f\ude81\ud8e7\udd33\udbac\udd48\ud984\udc78\udbee\udc90\ud906\udda0\ud8ed\udde1\ud8f9\udd1d\ud847\udeed\uda34\udf0d\udad5\udd0e\udb26\udf56\uda1d\udc11\udbcb\udee3\uda87\ude81\ud90c\udf81\udaac\udf10\ub445\uda19\ude09\udabb\udc02\ud8a3\udff4\udbf0\udea1\udbd4\udfa1\ud8c9\udd62\ud9a3\udec7", "\u8306\u2c03\u21ab", "\udb0f\ude35\udafc\uddf8\uda1e\udc51\udb63\udcd4\ud985\udd5f\uda75\udee7\ud80c\udc92\ud8cc\udff0\udb87\uddcb\u9864\u9fc5\ud81d\udd2b\udbcc\ude23\ud9e3\ude20\ud818\uddb9\udb3f\udd71\uda8e\udd62\ud8c1\udfee\ud810\udc52\ud919\ude50",
        -3, 28368, 1003035117, -6336579060446707883L, 73922L, true, true, (char) 44365, (char) 21183,
        Double.longBitsToDouble(0x3fd874d2751d7008L), Double.longBitsToDouble(0x3fc36e2b37fa16c0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 3, "\ud9d4\uddc0\udb53\udd78", "\ucccd\u02ed", "\udb63\udcb6\ud98d\udefc\ud873\udedd\udbf6\udd82\u0277\ud9cd\ude4f",
        10, 35628, 1784808024, -5164379548107902725L, 2046L, false, false, (char) 51288, (char) 53302,
        Double.longBitsToDouble(0x3f9907144769b180L), Double.longBitsToDouble(0x3fdadcb5074730a4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \uda0e\ude5d\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd: null\0121=new org.apache.commons.codec.binary.CharSequenceUtils:@?\012",
        Z.run(T, 2, 13, 4, 7, "\uda0e\ude5d\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udae8\udff0\ud875\udf9f",
        39, 69430, -1970382620, -8263755903336693019L, -50277L, true, true, (char) 41973, (char) 45679,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe6404499eaee30L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 0, "\uda0e\ude5d\ud864\ude50\u032b\udb66\uddb4\u88b9\uda32\udd3b\udb0a\ude39\ud803\uddeb\udb63\udcb6\udad8\udc62\ud873\udedd", "\000", "\udbcc\udc9c",
        16, 55215, 738579509, 6711927626951186660L, -50277L, true, true, (char) 41973, (char) 45679,
        Double.longBitsToDouble(0x3fe455b7c8f77277L), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud952\ude17\ud94b\ude18\ud8be\udf56\uda7a\ude3b\ud800\uddab\udb25\uded4\udb40\uddc1\ud803\uddeb", "\ua5bb\u4b51\u32e9\ubcc1\u8d3a\u41ad\uc86d\u52e5\u405b\uc4d0\u158f\ud514\uaddd\uc348\u8899\ub3c9\u08e0", "\udbac\udd48\ud984\udc78\udbee\udc90\ud86e\udff4\uda5b\uddd0\udbc9\udd03\ud913\uddb1\udb4e\udc02\udad2\udfd7\uda06\ude82\ud904\udd57\udb89\udfdc\ud964\udebd",
        35, 41605, 454267850, -4438612392072700653L, 14694L, false, true, (char) 6559, (char) 37940,
        Double.longBitsToDouble(0x3fe0ce56b9af063cL), Double.longBitsToDouble(0x3fcd03b591d68bb4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ub0ed", "\u3fa8", "",
        35, 39221, 1191241859, 8112135604450337785L, 96608L, false, false, (char) 18029, (char) 28770,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e1c8ba4a0000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 13, 7, "\uda0e\ude5d\uda10\udde6\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udae8\udff0\ud875\udf9f",
        52, 3523, 1473835678, 358331621022555551L, 28093L, true, true, (char) 39126, (char) 21801,
        Double.longBitsToDouble(0x3fe7c3f70e7d62e9L), Double.longBitsToDouble(0x3f876d0df5e2ba00L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.CharSequenceUtils:@?\012",
        Z.run(T, 1, 4, 4, 7, "\u225b\ud871\udc50\ud82a\ude02\ud98b\ude59\u88b9\uffcf\udb0a\udec7\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud860\udf0f", "\ubcc1\u8d3a", "\udae9\udc01",
        20, 30901, 1576778352, -8462728915430851126L, -84615L, true, false, (char) 40189, (char) 41973,
        Double.longBitsToDouble(0x3fe3ddc7728ab6f9L), Double.longBitsToDouble(0x3fdf772775901126L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 15, 14, 11, "\uda0e\ude5d", "\u1cfd\ucccd\u1ac4\u19c1\u5c9f\u0508\ub28b\u905f\ua18c\uc15b\ub4e3\u091a\uc0c5\uc827\uc8fe\u7efb\u1062\uc503\ud5b1\uaddd\uc348\u8899\ub3c9\u2ecc", "\udbac\udd48\uac62\udba4\udfdd",
        -5, 35534, -90463133, -5600716186543123718L, -36240L, true, true, (char) 46474, (char) 43616,
        Double.longBitsToDouble(0x3fdcd36ac83d2af2L), Double.longBitsToDouble(0x3fe45efe9a6c9000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda0e\ude5d\ud864\ude50\ud8b2\udea3\udb63\udf03\ud82b\udd5d\udb25\uded4\udb0a\udec5\ud8c7\udf18\u1c15\ud98d\udefc\ud873\udedd\udbf6\udd82\u0277\ud9cd\ude4f\uda3a\udf2e", "\u4f46\u405b\u1062\uc503\u28a1\uaddd\uc348", "\udb7a\udf90\ud97f\ude81",
        33, 32114, 143917047, 7073583573140388133L, -25555L, false, false, (char) 65163, (char) 63651,
        Double.longBitsToDouble(0x3fe764b12c105944L), Double.longBitsToDouble(0x3fd76600c62d052cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 1, 8, 4, 7, "\uda0e\ude5d\ud864\ude50\ud848\udd4f\udb3e\udd4d\ud874\ude25\ud8b9\udfc0\udb0a\udec5\uda17\udc35\ud9e8\udc3d\ud98d\udefc\ud873\udedd", "\u0d8d\uaefe\u1989\uc86d\u9374\u09f2\u1062\uc503\ud5b1\ub725\uc2b6\u628b\u3b06\u7e79\u8171\u82f3", "\udbee\udc90\udaf9\udf79\uda3c\udfbf\ud9b1\ude38\ud930\udcfb\ud828\udc3d\ud825\udf20\ud88c\udda9\udb12\udec3",
        25, 49468, 1021631950, -4770682659542225040L, -57493L, false, false, (char) 2359, (char) 61692,
        Double.longBitsToDouble(0x3fed0f19995b5bc1L), Double.longBitsToDouble(0x3fe513f488405600L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[B:[[-12, -39, -127, -34, -108, -37, 72, -34, 65, -37, -21, -36, -83, -40, 42, -33, 91, -40, 89, -35]]\0121=[B:[[-2, -1, -39, -12, -34, -127, -37, -108, -34, 72, -37, 65, -36, -21, -40, -83, -33, 42, -40, 91, -35, 89]]\012",
        Z.run(T, 2, 11, 9, 14, "\ud9f4\ude81\udb94\ude48\udb41\udceb\ud8ad\udf2a\ud85b\udd59", "\u5c9f\u0508\ua5c7\u2061\u864b\uc5e8\u13d1\u0f04\u41ad\uc86d\u4b38\u405b\u1062\uc503\ud5b1\ub443\uc28f\u8899\ub3c9\u2ecc\uac70\u82f3\uca34\u9a21\u9f20\u61a0\u7b17\u84f6\uabfd\u7a29\u6748\u7a74\u7969\u9a67\u94f9\u4970\u7abf", "\udac4\udcc4\uda4a\ude32\udafd\udeef\ud8eb\udc4d\udbe5\udd13\udb1a\udf30",
        29, 42689, 888301950, -3596632481264998094L, 96344L, true, true, (char) 33894, (char) 4221,
        Double.longBitsToDouble(0x3fe94e0e53a5b0c3L), Double.longBitsToDouble(0x3fe507695e25d7c1L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[14, -38, -115, -35, 100, -40, 80, -34, 22, -39, 92, -36, 102, -37, 39, -34, -71, -120, 37, -37, -44, -34, 10, -37, -59, -34, 3, -40, 99, -35, -16, -38, -67, -34, -125, -38, 23, -35, 115, -40, -35, -34, -44, -38, 8, -36, 79, -39, 102, -33, -57, -40, -102, -36, -34, -38, 122, -35, 125, -37, -82, -36...\012",
        Z.run(T, 1, 11, 11, 12, "\uda0e\udd8d\ud864\ude50\ud916\udc5c\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\udd63\udaf0\udebd\uda83\udd17\ud873\udedd\udad4\udc08\ud94f\udf66\ud8c7\udc9a\udade\udd7a\udb7d\udcae\udbcc\udcd5", "\u77de", "\udb49\ude89\udb51\udf64\ud845\udf37\udbf1\udeb5\udb02\udf33\ud94c\udf76\ud808\uded7\uda07\udc9a\ud984\udc78",
        59, 57700, -1676528757, 2734231399222445259L, 84148L, true, true, (char) 51304, (char) 879,
        Double.longBitsToDouble(0x3fe68f8808a60e1eL), Double.longBitsToDouble(0x3fd24f06a45ba388L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 15, "\ud8ae\udfae\ud864\ude38\udb20\udd19\udaf1\ude7e\uda36\udfed\udb72\udffc\ud991\udceb\udb33\udcef\ud979\udf46\ud98d\udefc\udb1c\udc31", "\u3b20", "\uda87\udcf4\udb65\uddd3\ud895\udfc7\ud867\udecd\ud9dd\udfde\ud87e\udd7f\udb71\udf07\udb26\ude6d\udb2c\udc9b\ud87b\udf20\udb68\udcc2",
        41, 2577, 1637993982, -9037727647301568015L, 45835L, true, false, (char) 37791, (char) 14654,
        Double.longBitsToDouble(0x3feafe6392a48c17L), Double.longBitsToDouble(0x3fc4bd9b1f4e87d0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 11, 17, 7, "\uda0e\ude5d\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\udbb2\udd73\udad7\udeba\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udae8\udff0\ud875\udf9f",
        39, 69430, -1963429916, -8263755903336693019L, -50277L, true, true, (char) 41973, (char) 45679,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe640449925622aL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 15, 12, 9, "\uda0e\ude2e\ud864\ude50", "\u2f6a", "\ud803\uddeb\udb63\udcb6\ud8e0\udfc0\udb39\udd23\udb75\udd88\udaf1\udee0\ud9cd\ude4f\ud82e\udfc4\ud886\udeff\udb2a\udf8d\ud832\udf89\udb2f\udc3a\ud92f\udf9d\ud805\ude7d\udb24\udda7\udb4a\udd96\udb26\udf4f\udb1e\udf20\uda14\udd6c\ud89f\udd0f\ud8cd\ude63\ud8e7\udd4b\udbea\udc33\ud983\ude1e\ud809\ude7e\ud906\udc60\ud9f8\udef4\udb0a\udfc4\ud832\udf8d\ud84b\udfdf\udadf\udebb",
        2, 73388, -1202165691, -7859335785034698086L, -77003L, true, false, (char) 54764, (char) 21031,
        Double.longBitsToDouble(0x3fec0302084c5a64L), Double.longBitsToDouble(0x3fe1af814b0b73d7L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[B:[[-39, -99, -35, 4, -38, 76, -33, 83, -37, 17, -36, 78, -37, 102, -34, 39, -38, -83, -33, -30, -39, -80, -35, -96, -37, 10, -34, -59, -40, 3, -35, -21, -37, 99, -36, -74, -39, -7, -35, 51, -40, 116, -33, -24]]\012",
        Z.run(T, 1, 10, 7, 7, "\ud99d\udd04\uda4c\udf53\udb11\udc4e\udb66\ude27\udaad\udfe2\ud9b0\udda0\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud9f9\udd33\ud874\udfe8", "\ubd22\u8d3a", "\ud90d\udf09",
        52, 75003, 1704650513, -9096554935991400836L, -74655L, true, false, (char) 63559, (char) 21767,
        Double.longBitsToDouble(0x3fd81a8285156df2L), Double.longBitsToDouble(0x3fefbb93bac80893L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud816\udd6a\ud864\ude50\udb41\udcc6s\000\000\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\000", "",
        36, 79186, 249286335, 3172174838213480094L, 80790L, false, false, (char) 15385, (char) 711,
        Double.longBitsToDouble(0x3fdadcb5074730a4L), Double.longBitsToDouble(0x3f451dc000000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ud815\udd55\udb35\udf3e\udb0e\udd13\udb7e\udfa0\ud9b5\udffa\uda23\uddd9\ud986\udec4\udadc\udef8\udab9\udd1e\ud81e\udfb1\udabf\udf53\ud832\udc40\u8e05\ud9a7\udf9d\uda3a\udf2e\udbf4\udc4b\ud8e0\udfc4: null\0121=null\012",
        Z.run(T, 2, 13, 11, 15, "\ud815\udd55\udb35\udf3e\udb0e\udd13\udb7e\udfa0\ud9b5\udffa\uda23\uddd9\ud986\udec4\udadc\udef8\udab9\udd1e\ud81e\udfb1\udabf\udf53\ud832\udc40\u8e05\ud9a7\udf9d\uda3a\udf2e\udbf4\udc4b\ud8e0\udfc4", "\u1062\u7103\u0aaa\ud2df\u991d\u8896\u0546\u67ff\u03a7\u87fa\u4551\u9957", "\ud904\udecb\ud819\udd19\udaa3\udd57\ud9a2\udc1c\ud9a7\ude08\uda8c\udfdb\uda34\udedc\ud81c\udc08\ud809\udceb",
        15, 65406, 929179727, 4367812834466358411L, -4377L, false, false, (char) 32965, (char) 24457,
        Double.longBitsToDouble(0x3fe47325f9dced36L), Double.longBitsToDouble(0x3fd938b00927acfeL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 11, 15, "\ud9ba\udc14\000", "", "",
        -5, -1000, 0, -3777675664422410672L, -68324L, false, false, (char) 45735, (char) 20967,
        Double.longBitsToDouble(0x3fe2c220a82a6a62L), Double.longBitsToDouble(0x3fe5faeb6c350edbL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 11, 15, "\uda0e\udd7e\ud864\ude50", "\ucccd\u1ac4\u19c1\ua95c\ua033\u78a5\ua9d2\u20fb\u5c53", "\ud85b\udcff\udbcc\udc9c\ud9e1\uddab\ud875\udf9f\ud986\udd6e\ud8cc\udc1b\ud87e\uddf8\udb49\udf07\udb26\udf4f\udb2b\udfe6\ud87b\udf20\udb7a\udf90\ud891\udd0a\udadc\udded\uda94\udff1\ud983\udfae\udaa5\udf92\ud8a2\udc4e\udbb6\udc19",
        41, 70492, 1081416784, -7135068664302159769L, 62211L, true, true, (char) 35329, (char) 24866,
        Double.longBitsToDouble(0x3fae49bea7d64720L), Double.longBitsToDouble(0x3fdd27b0a58fa3e6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 6, 7, 4, "\ub00e\000", "\u925e", "\udadc\ude43\udab9\udd1e\ud81e\udfb1",
        14, 3972, 0, 0L, -100000L, false, false, (char) 24108, (char) 57908,
        Double.longBitsToDouble(0x3e74000000000000L), Double.longBitsToDouble(0x3e37280288000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 9, "\uda0e\udd7e\ud864\ude50", "\ucca3\u1ac4\u19c1\ua902\ua033\u78a5\ua9d2B\u43c1", "\ud85b\udcff\udbcc\udc9c\udbea\udec0\ud907\udf08\ud937\udf11\udab0\ude93",
        10, 94394, 118768357, 4651158593663451707L, 13750L, true, true, (char) 47665, (char) 34724,
        Double.longBitsToDouble(0x3fdc8089324ac48eL), Double.longBitsToDouble(0x3fa822177cb33d60L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 15, 12, "\uda0e\udd7e\ud864\ude50", "\ucccd\u1ac4\u19c1\ua95c\ua033\u2517\ud757\u11fa\u0d37", "\uda90\udf5b\udbab\udea7\udbc4\udf56\ud875\udef4\ud867\udecd\uda48\udd13\ud87e\uddf8\ud984\udda3\u5881\udb2b\udfe6\ud87b\udf20\udb7a\udf90\ud97f\ude81\ud9cf\ude86",
        18, 91845, 1648835016, -1025913459394152098L, 61028L, false, true, (char) 25935, (char) 21858,
        Double.longBitsToDouble(0x3fe68ff1b802de90L), Double.longBitsToDouble(0x3fdf21bb65a1980aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\000\000", "\ucccd\u1ac4\u19c1\u5c9f\u0d9f\u368d\u91f0", "\ud9ca\udf44",
        34, 16944, 1778384984, 123325940223488L, 2046L, false, false, (char) 51146, (char) 53302,
        Double.longBitsToDouble(0x3f99071447681180L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\udbf7\udff2\ud98b\udf7e\udb41\udceb\udb66\ude27\u88b9\udb25\uded4", "\u0d9f\u368d\u5791\ua8c5\ub038\u0149", "\udb79\udda0\udae8\udff0",
        20, 48333, 1562742430, -8462728915430851126L, -84615L, true, false, (char) 40189, (char) 13557,
        Double.longBitsToDouble(0x3fdcdda215156df2L), Double.longBitsToDouble(0x3fefbb93bac80893L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 7, 16, "\uda9b\udc7e\ud890\udf46\ud827\udc47\uda8d\udfda\uda9c\udf7c\ud82e\ude1a\udb0a\udec5\ud827\udfeb\udabc\ude24\ud8ec\udef1\ud8b3\udd8e", "\ud535\u727c\u9088\uc86d\u4b38\u405b\u1062\u47d0\u8a24\u3415\uc348", "\udb7a\udf48\u81df",
        32, 55389, 1416721743, -6222538014297867831L, 24140L, true, false, (char) 2319, (char) 12272,
        Double.longBitsToDouble(0x3fb43992c39b0c30L), Double.longBitsToDouble(0x3feb2c11f4206cccL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \udbc9\udcf4\ud9a9\uddb1\udb8c\udd2b\udb66\ude27\u88b9\ud82e\ude1a\ud854\ude2b\ud836\udef5\ud962\ude75\ud98d\udf79\ud8a2\uddc9: null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 3, "\udbc9\udcf4\ud9a9\uddb1\udb8c\udd2b\udb66\ude27\u88b9\ud82e\ude1a\ud854\ude2b\ud836\udef5\ud962\ude75\ud98d\udf79\ud8a2\uddc9", "\u2464\u99b3\u2d66\ua9ff", "\ud867\udf52",
        56, 61268, 2075892937, 510105784995822744L, -22557L, true, true, (char) 46968, (char) 51673,
        Double.longBitsToDouble(0x3fceebab6b22362cL), Double.longBitsToDouble(0x3fd25622a02bf16aL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=[B:[[89, -40, 94, -33, -112, -40, 70, -33, 65, -37, 116, -35, 102, -37, 39, -34, -71, -120, 46, -40, 26, -34, 10, -37, -59, -34, 39, -40, -21, -33, 99, -37, -74, -36, -115, -39, -4, -34, -94, -40, -55, -35]]\0121=[B:[[89, -40, 94, -33, -112, -40, 70, -33, 65, -37, 116, -35, 102, -37, 39, -34, -71, -120, 46, -40, 26, -34, 10, -37, -59, -34, 39, -40, -21, -33, 99, -37, -74, -36, -115, -39, -4, -34, -94, -40, -55, -35]]\012",
        Z.run(T, 2, 11, 11, 15, "\ud859\udf5e\ud890\udf46\udb41\udd74\udb66\ude27\u88b9\ud82e\ude1a\udb0a\udec5\ud827\udfeb\udb63\udcb6\ud98d\udefc\ud8a2\uddc9", "\u4cb0", "\udbd4\udf38\udae8\udff0\ud875\udf9f\ud867\udecd\ud8e1\udc1b\ud87e\uddf8\udb49\udf07",
        27, 37368, -883899845, -7470678291315291229L, -53031L, true, false, (char) 63571, (char) 39759,
        Double.longBitsToDouble(0x3f95f869f189abe0L), Double.longBitsToDouble(0x3fef36dba4ec05d7L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\ud890\udf46", "\ucccd\u7994\u0380\u1c89\u0508\ua5c7\u4954\u5598\u6233", "\ud90a\udc57\ud957\udd3a\uda7b\udcb8\udae5\udf05\ud867\udecd\ud99d\udc39\ud862\udd15\ud9e0\udf26\uda68\udc1c\ud9d4\udce1\ud87b\udf20\udb7a\udf90\udb0e\ude28\udb84\udd01\ud995\ude07\uda6a\udc4d\uda08\udd0d\ud9ea\udcb2\ud91b\udca4\uda75\udd64\ud847\udc3e\ud90c\uded4\udac2\udce5\u2030\udae2\udca7\ud9ba\uddb2\udb76\udc33\uda59\udd66\ud806\udff2\uda7b\udd29\udb0a\ude6a\udbef\udf03\uda00\udff2\uda89\udee8\ud931\udc4b\udbdb\udc4e",
        56, 67652, 589415540, -234797863404882570L, -37962L, true, true, (char) 487, (char) 21238,
        Double.longBitsToDouble(0x3fd2039792db686cL), Double.longBitsToDouble(0x3fc5d27d4fd7731cL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 11, 5, "\ud955\udc3c\uda3f\ude60\udbab\udef6", "\u6203\u1502\u60d6\ub84e\ube44\u4aaa", "\ud951\udda6\ud8f0\udd73\ud85b\udcff",
        55, 79186, 1379636636, -276259377317035363L, 80893L, true, false, (char) 17324, (char) 711,
        Double.longBitsToDouble(0x3fdadcb50746d8a4L), Double.longBitsToDouble(0x3fc15cddc21e0548L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -40, 89, -33, 94, -40, -112, -33, 70, -37, -73, -36, -41, -40, 89, -36, 108, -37, 15, -35, 54, -40, 46, -34, 26, -40, -12, -35, -34, -40, -25, -33, 5, -37, 99, -35, 25, -39, -58, -35, -4, -40, -94, -35, -55]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 15, "\ud859\udf5e\ud890\udf46\udbb7\udcd7\ud859\udc6c\udb0f\udd36\ud82e\ude1a\ud8f4\uddde\ud8e7\udf05\udb63\udd19\ud9c6\uddfc\ud8a2\uddc9", "\uc204", "\udbcc\udc9c\udb65\udded\ud875\udf9f\ud867\udecd\ud866\udd1c\udaba\udc16\udb49\udf07",
        19, 9400, -883899845, -7470678291315291229L, -53031L, true, false, (char) 63571, (char) 39759,
        Double.longBitsToDouble(0x3f957469f189abe0L), Double.longBitsToDouble(0x3fef36dba4ec05d7L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 17, 15, "\ud859\udf5e\ud890\udf46\udb41\udd74\udb66\ude27\u88b9\ud82e\ude1a\udb0a\udec5\ud827\udfeb\udb63\udcb6\ud98d\udefc\ud8a2\uddc9", "\u4cb0", "\udbcc\udc81\udae8\udff0\ud875\udf9f\ud867\udecd\ud8e1\udc1b\ud87e\uddf8\udb49\udf07",
        27, 9376, -883899845, -7470678291315291229L, -53031L, true, false, (char) 63571, (char) 39759,
        Double.longBitsToDouble(0x3f95f869f189abe0L), Double.longBitsToDouble(0x3fef36dba4ec05d7L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 9, "\ud859\udf5e\ud890\udf46\udb41\udd74\udb66\ude27\u88b9\ud82e\ude1a\udb0a\udec5\ud827\udfeb\udb63\udcb6\ud98d\udefc\ud8a2\uddc9", "\u4cb0", "\udbcc\udc9c\udae8\udff0\ud875\udf9f\ud867\udecd\ud8e1\udc1b\ud87e\uddf8\udb49\udf07\udb26\udf4f",
        1, 51155, -1739402835, -1806493607946694518L, -19835L, true, false, (char) 23787, (char) 12123,
        Double.longBitsToDouble(0x3fcd80bae8e4c7a4L), Double.longBitsToDouble(0x3fe3e55e1d1c258eL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=null\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 3, 15, "\ud859\udf5e\u2483\udb46\udcd4\udac6\ude3b\u88ef\ud82e\ude1a\udb0a\udec5\ud827\udfeb\udb96\udd65\ud9fe\udf92\ud8a2\uddc9", "\u4ca0", "\udbcc\udc9c\udae8\udff0\ud875\udf9f\ud867\udecd\udacd\udcad\ud87e\uddf8\udb49\udf07\udb1e\ude4f\udb2c\udc65\ud87b\udf20\udb7a\udf90\udb0e\ude28\udb84\udd12\ud995\ude07\udadf\uddee\udb2e\udf98\uda15\udf01\ud91b\udca4\uda75\udd64\ud847\udc3e",
        55, 58758, 665461496, 4637546643268231621L, 4826L, false, true, (char) 28891, (char) 57090,
        Double.longBitsToDouble(0x3fdcfacbd4827f70L), Double.longBitsToDouble(0x3fde820141267806L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 0, 0, "\ud859\udf5e\ud890\udf46\udb41\udd74\udb66\ude27\u88b9\ud82e\ude1a\udb0a\udec5\ud827\udfeb\ud861\udc2f\ud98d\udefc\ud8a2\uddc9", "\u4cb0", "\udbcb\ude44\udae8\udff0\ud875\udf9f\ud867\udecd\ud8e1\udc1b\ud87e\uddf8\udb49\udf07",
        27, 9376, -883899845, -7470678291315291229L, 3736L, true, true, (char) 57470, (char) 23787,
        Double.longBitsToDouble(0x3f4b6e8000000000L), Double.longBitsToDouble(0x3feb9aeaaf4aae5bL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\0121=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 2, 6, 6, 15, "\uda9d\udee1\udbac\uddd8\uda47\udf74\udb66\ude27\u88b9\ud82e\ude1a\udb0a\udec5\ud827\udff9\udb63\udcb6\ud98d\udefc\ud8a2\uddc9", "\u1072", "\u12a5\udae9\udc77\ud875\udf9f\ud867\udecd\ud8e1\udc1b\udbed\udc8f\udb49\udecd",
        27, 9376, 1928274416, -7470713196514505821L, -89108L, true, false, (char) 63571, (char) 39759,
        Double.longBitsToDouble(0x3f95f869f189abe0L), Double.longBitsToDouble(0x3fef36dba4ec05d7L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 3, 3, 15, "\uda47\udf1d\ud8a9\udf7e\udb41\udd74\udb66\ude27\udae6\udcba\ud82e\ude1a\udbbf\udea1\udb96\udf83\udb63\udca9\ud98d\udefc\ud8a2\uddc9", "\u4cb0", "\udbcc\udc9c\ud8a9\udf12\ud875\udf7d\ud867\udef6\uda55\ude36\ud9ae\udcfa\ud8eb\udf2d",
        13, 75730, -883899696, -7470678291315291229L, -53031L, true, false, (char) 63571, (char) 39759,
        Double.longBitsToDouble(0x3f95f8dbf189abe0L), Double.longBitsToDouble(0x3fef36dba3d4e878L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\u90b6", "\000", "\u008c",
        -5, -1000, 0, 3554184529990198476L, 79200L, false, false, (char) 24576, (char) 48574,
        Double.longBitsToDouble(0x3fa5125880000000L), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 15, 4, 5, "", "", "\u0cd5",
        -5, 28088, 1768247221, 5138581351080138842L, -25044L, false, true, (char) 25955, (char) 14194,
        Double.longBitsToDouble(0x3f320012c2200000L), Double.longBitsToDouble(0x3fa535312bfb8540L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 2, 15, "\ud8a4\ude56\ud902\udd04\ud93b\udc43\ud809\udc92\ud907\udd58\uda2d\udc98\udb0a\udec7\ud803\uddeb\udb63\udcb6\ud98d\udefc", "\ua4efO", "\ud9ae\udeba\ud889\ude82\ud81b\udc0d",
        30, 56781, 1368283358, -8252325380450204955L, -50277L, true, false, (char) 17141, (char) 38173,
        Double.longBitsToDouble(0x3fe45535a7f77277L), Double.longBitsToDouble(0x3fe739e449ff84c7L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 0, 0, "", "", "\ud8fa\udd30\udb13\udcca\udb0a\udec5\000",
        13, 52754, 823108601, -4016888932530100956L, -100000L, true, false, (char) 18234, (char) 55948,
        Double.longBitsToDouble(0x3eb521a800000000L), Double.longBitsToDouble(0x3fe4f16028000025L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ub0ed\ud864\ude50\000\udb66\ude27\u88b9\ud966\ude7eT\000\000\000\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udae8\udff0\ud875\udf9f",
        39, 35510, -1970382848, -8263755903336693019L, -99941L, false, false, (char) 2979, (char) 45679,
        Double.longBitsToDouble(0x3fe57db7cff77277L), Double.longBitsToDouble(0x3fe640449925622aL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda6c\udd52", "\u1f01\000\u9194\u19c1\u5c9f\000\000\000\000\u984ar\u8d3a", "\udb02\udfc1",
        12, 66509, 179568798, 4984348988774872009L, -67104L, false, false, (char) 29816, (char) 13227,
        Double.longBitsToDouble(0x3fe8bb78bc50df78L), Double.longBitsToDouble(0x3fc72e85b1a0ef44L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=[B:[[-38, 14, -34, 93, -40, 30, -36, -57, -39, -4, -36, -27, -37, 60, -35, 54, -120, -71, -38, 121, -33, 63, -40, -80, -34, -55, -53, 62, -40, 4, -35, -52, -81, -44, -37, -37, -35, 21]]\0121=[B:[[-38, 14, -34, 93, -40, 30, -36, -57, -39, -4, -36, -27, -37, 60, -35, 54, -120, -71, -38, 121, -33, 63, -40, -80, -34, -55, -53, 62, -40, 4, -35, -52, -81, -44, -37, -37, -35, 21]]\012",
        Z.run(T, 2, 10, 10, 7, "\uda0e\ude5d\ud81e\udcc7\ud9fc\udce5\udb3c\udd36\u88b9\uda79\udf3f\ud8b0\udec9\ucb3e\ud804\uddcc\uafd4\udbdb\udd15", "\ubd9a\ubc5d\uc095\u3ebe\u28da\u38e8\u1062\uc503\ud5b1\uaddd\uc348\u50df\uccc9\u2ecc\ub5ec\u315d\u5400\u3f96\u9f20\ub207", "\ud869\ude3f\ud9fc\udf21\udb05\udebf\udae6\udcfe\uda54\udc79\uda50\udeb1\ud8da\udf83\udbf1\udff3\ud8a3\udca9",
        33, 20402, -1222822371, -4402405898862593662L, 83284L, false, false, (char) 27762, (char) 58652,
        Double.longBitsToDouble(0x3febd01c77d02335L), Double.longBitsToDouble(0x3fe33664a5e0fb34L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.CharSequenceUtils:@?\0121=new org.apache.commons.codec.binary.CharSequenceUtils:@?\012",
        Z.run(T, 2, 4, 4, 7, "\uda0e\ude5d\udbb9\ude76\ud9ce\udf15\udb3c\udd36\u88b9\uda79\udf3f\ud8b0\udec9\ucb3e\ud804\uddcc\uafd4\udbdb\udd15", "\ubd9a\ubc5d\uc095\u3ebe\u28da\u38e8\u1062\u5639\ud5b1\uaddd\uc348\uc5ee\ub953\u2ecc\ub5ec\u6c0e\ub28a\u9a21\u9f20\ub207", "\ud869\ude3f\ud9fc\udf21\udb05\udebf\udae6\udcfe\uda54\udc79\uda50\udeb1\ud8da\udf83\udbf1\udff3\ud8a3\udca9",
        19, 14138, 13853, 0L, 83171L, false, false, (char) 27762, (char) 58652,
        Double.longBitsToDouble(0x3febd01c77d02335L), Double.longBitsToDouble(0x3fe33664a5e0fb34L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 7, 7, "\u37a6", "\u1cfd\ucccd", "\ud803\udd3b",
        26, 36676, 273938517, -6034340899568655097L, 30365L, false, false, (char) 34579, (char) 8265,
        Double.longBitsToDouble(0x3fe3692dead86325L), Double.longBitsToDouble(0x3fef353b8de143e3L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 4, 4, "", "", "\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\u0083\ud98d\udefc\ud81c\uddee",
        21, 77620, 910297867, 1385843174258591987L, -71286L, true, false, (char) 4112, (char) 47970,
        Double.longBitsToDouble(0x3fcc8ba4af2a2a38L), Double.longBitsToDouble(0x3fe72c6a8c190714L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 9, "\ud91c\udd74\udbb4\udeb0\udb35\udd6e\udb66\ude27\u88b9\udb25\uded4\u548c\udafa\udd5d\udb63\udcb6\ud98d\udefc\ud873\udedd\udb1d\udf5f\ud920\udd27\ud9f7\udd84\uda3a\udf2e\ud85b\udcff\ud99d\udc86\udae8\udff0\u00bf\000\u438d\ud868\uddca\u00ca\ud894\udee6\ud80a\udf9d\ud8b9\udfa3\udb6a\udfe3\ud993\udc51\ud8e5\udc33\udbac\udd48\udab2\udc78\udbee\udc90\ud9ea\udc31\ud9dc\udc93\udb73\udf1c\udb62\udc95\ud815\udf4a\uda52\udcde\ud991\ude96\ud87e\udf8e\udb5e\udc8b\u3904\udaa2\udc2f\u34ca\udaaa\udc04\ud8f9\udd6a\ud35f\ud9c4\udfe3\ud9a7\udd81\ud866\udee2\udad6\udd48\udbcf\udc32\ud9ac\uddf0\ud8bb\udf08\ud950\udfdd\ud91e\udec0\udb01\udd2c\ud98d\uded3\ud99e\udfec\ud8b1\udfbf\ud9af\udcb5\udae0\udfa8\uda66\udde2\ud99a\udddd\ud9da\uddd8\uda01\uddfb", "\u4052\u429d\u05e3\ud2c5\u6278\u1e35\u27bb\u293b\ua0ba\u289f\u5071\u6b53\u8431\u72ff\u34be\u7ceb\u8615\u5beb\u79d0\u82cd\u0d20\u33cd", "\udbda\udc9f\uda2d\udfd9\uda34\udf12\ue754\ud8ae\udf5c\ud8e7\uddd4\ud95c\uddfb\ud958\udd3b\ud8a3\udd7d\udb7a\udc06\ud8cf\udf61\uda42\udc0d\uab76\uda54\udfa2\uda92\ude1e\ud8b6\uddac\uda81\ude02\ud8db\ude74\udb9b\udd7f\udb7a\ude6c\udab8\uddc2\ud8cf\ude29\ud917\udefe\u6df9\udbea\udda2\uda90\udc03\ud9bc\udfd9\ud8dc\udeab\udbd7\udd2a\ud955\udca3\udb79\udf31\ud9fd\udcee\ud867\udf52\uda02\udf38\ud920\udd1c\udbb4\udfec\ud8d2\udd65\udb09\uded6\ud991\udc89\uda91\udce6\uda2f\udfe6\ud913\udcfa\ud862\udeee\ud8ad\uded9\ud9c4\ude0d\ud9bb\udcbf\ud941\ude21\ud815\udc8b\ud9b3\udddf\ud988\udc70\uda40\udd2b\ud9a5\ude69\ud8f6\ude84\udb56\udef5\ud9b1\ude8b\udba8\ude30\ud831\ude43\udbe9\ude12\uea30\udbeb\udda4\udbfa\udd5c\udb33\ude98\ud83b\udded\udb45\udd63\ud872\uddd0\uc0c6\udb85\udf8e",
        17, 8701, 213278072, -4022951672704153817L, -80275L, true, true, (char) 57098, (char) 55817,
        Double.longBitsToDouble(0x3fe5fdfd6dbd3368L), Double.longBitsToDouble(0x3fe70c764fcc9674L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 3, 15, "\uda0e\ude5d\u00c1\ud823\udc8a\udb66\ude27\u88b9\udb7a\udc3e\u548c\ub636\udb63\udcb6\ud98d\udefc\ud873\udedd\ud89b\udecc\ud905\udc68\ud9cd\ude4f\uda3a\udf2e\ud85b\udcff\udbcc\udc9c\udae8\udff0\u00bf\000\000\ud910\udcc6\u93b0\ud894\udee6\000", "\u1c06\u79f3\uca34\u417b\u9f20\u7016\ubfe8\uce69\u1c44\u6234\ud307j\u461c\u9d80\u0c67\ucb8a\u4860", "\ud82a\udd9e\udb4b\udee9\ud896\udf89\ud903\udcae\ud972\udc9e\ud86e\udc6a\udaf3\ude28",
        20, 80424, -131116835, -5663202437303308130L, -76678L, false, true, (char) 61131, (char) 24846,
        Double.longBitsToDouble(0x3fe38fe66fd98c71L), Double.longBitsToDouble(0x3fe29bf183628d26L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 6, 17, "\ud984\ude16\u1499\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\udadb\udf1e\udbf6\udd82\ud85e\udce5\ud9cd\udf26\uda3a\udf2e\uda55\udcdb\udbcc\udc9c\udae8\udff0\ud875\udf9f\ud867\udecd\uda21\udedc\ud87e\ude01\ud98e\udc48\udbca\udf4f\ud816\udce3\uda90\ude4b\udb7a\udef9\ud97f\ude81\ud8e7\udd33\udbac\udd48\ud984\udc78\udbee\udc90\ud906\udda0\ud8ed\udde1\ud8f9\udd1d\ud847\udeed\uda34\udf0d\udad5\udd0e\udb26\udf56\uda1d\udc11\udbcb\udee3\ud939\udefa\ud927\ude74\udac4\udc10\ub445\uda19\ude09\udabb\udc02\udaee\udfb9\ud857\udf4b\ud8b7\uddb6\ud8a2\udc7a\ud9a3\udec7", "\u8306\u2c03\u38ab\u861d", "\udafc\uddf8\uda1e\udc51\udb63\udcd4\ud985\udd5f\uda75\udee7\ud80c\udc92\ud8cc\udff0\udb87\uddcb\u9864\u9fc5\ud81d\udd2b\udbcc\ude23",
        35, 15479, 1174141266, 3790735976005436591L, 6521L, true, false, (char) 21183, (char) 59053,
        Double.longBitsToDouble(0x3fe475c0249b7159L), Double.longBitsToDouble(0x3fdfe85b09cb7ff8L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 0, "\uda0e\ude5d\ud8a2\udc4f\ud995\udd85\udb66\ude2a\u88b9\uda32\udd3b\udbcc\udedb\uda5e\udf59\udb63\udc47\udad8\udc62\ud873\udedd\udb8a\udd8c\u6524\000\000\ud85b\udc03\udbcc\udc9c\udae8\udff0\ud8a8\udd92\ud867\udecd\ud827\uddd2\ud87e\uddf8\udb49\udf07\udb16\udd4f\udb2b\udfe6\ud87b\udf20\udb7a\udf90\ud97f\ude81\ud8e7\udd33\udbac\udd48\uda04\ude19\uda7f\uded9\udad5\udfdb\udbd1\udea7\ud8d6\udd49\udb91\udfe7\ud8eb\ude9e\udbe1\udfae\ud960\udf52\ud862\udf72\ud923\udc07\ud998\udf55\u0bd3\udb5d\udfb0\udaf3\udc45\udafe\udff1\udba5\udfdc\ud956\udca5\uda6f\udebe\ud9e9\udd9a\udb36\ude0b\ud85a\udfe6\udb28\udcfa\uda5a\udd23\ud9b6\udde9", "\ud032\u16c3\u1f59\u7cd3\u4057\u6c43\u4d86\u9cc1\ua521\u125d\ud1a5\u1a1a\u42e3\u06d1\uba37\u161f\u1698\u7b87\u8b74\u4d37\ubf7b\ua75f\u012c\uae7e\ub6aa\u1f99\uc776\uc1b0\u88bc\ubacf", "\uda65\udde4\ud880\udc89\udbad\udd11\ubce4\ud942\udf8e",
        19, 86250, -651706107, -3190154951401175671L, -1738L, false, true, (char) 60926, (char) 48627,
        Double.longBitsToDouble(0x3fefc05e07f808cdL), Double.longBitsToDouble(0x3fe17d570b44aef2L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 6, "\uda0e\ude5d\ud864\ude50\u032b\ud9fc\udd1e\ud882\ude79\udbf7\ude3c\udad3\ude7d\ud803\uddeb\udaba\udddf\ud8dd\udcd4\ud85d\uddcb", "\u4bd4\ub5e9\u7a5a\ub76f\u6f5e\ua956\u53ea\u6f86\u5685\ua3e7\u8148\u8899\ub3c9\u1158\u62a0\ud069\uca34g\000\u067a\ucb0f\ub115\u4f04\u930b\u517b\u8b6d", "\ud974\uddb7\uda93\udfe8\udb45\udc3b\ud825\ude01",
        59, 87526, 946267596, -4501501506458359760L, 91238L, false, false, (char) 37229, (char) 5883,
        Double.longBitsToDouble(0x3fcda6207d5a32c4L), Double.longBitsToDouble(0x3fe1c6e554c7ab69L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 11, "\uda0e\ude5d\ud864\ude50\u032b", "\u01f0\u641e\u5c0b\u0508\u6b65\ua61e\u12ba\u6524", "",
        46, 36024, -1202425814, 2377901425204232194L, -17876L, false, true, (char) 61043, (char) 17197,
        Double.longBitsToDouble(0x3fe1da0467d9cb50L), Double.longBitsToDouble(0x3fed1cc291cba8eeL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=[B:[[-12, -39, -127, -34, -108, -37, 72, -34, 65, -37, -21, -36, -83, -40, 42, -33, 91, -40, 89, -35, -40, -38, -20, -36, 82, -39, 112, -34, 3, -40, -21, -35, 99, -37, -74, -36, -115, -39, -4, -34, -79, -37, -70, -33, 69, -38, 101, -36, 37, -38, 8, -35, 44, -37, 127, -35, 27, -38, -8, -36, 91, -40, -1,...\0121=[B:[[-2, -1, -39, -12, -34, -127, -37, -108, -34, 72, -37, 65, -36, -21, -40, -83, -33, 42, -40, 91, -35, 89, -38, -40, -36, -20, -39, 82, -34, 112, -40, 3, -35, -21, -37, 99, -36, -74, -39, -115, -34, -4, -37, -79, -33, -70, -38, 69, -36, 101, -38, 37, -35, 8, -37, 44, -35, 127, -38, 27, -36, -8, -40,...\012",
        Z.run(T, 2, 11, 9, 14, "\ud9f4\ude81\udb94\ude48\udb41\udceb\ud8ad\udf2a\ud85b\udd59\udad8\udcec\ud952\ude70\ud803\uddeb\udb63\udcb6\ud98d\udefc\udbb1\udfba\uda45\udc65\uda25\udd08\udb2c\udd7f\uda1b\udcf8\ud85b\udcff\udbcc\udc9c\udae8\udff0\ud875\udf9f\ud867\udecd\ud8e1\udc1b\ud87e\uddf8", "\u756d\u4465\u2ecc\uac70\u82f3\uca34\u9a21\u9f20\u61a0\u7b17\u84f6\uabfd\u79ce\u6748\u7a74\u7969\u9a67\u94f9\u4970\u7abf\u9a25\u34ed\u8df7", "\ud8eb\udc4d\udbe5\udd13\udb1a\udf30\ud809\udcf0",
        49, 5950, -837406256, 7390804128924977131L, 16405L, false, true, (char) 4221, (char) 11508,
        Double.longBitsToDouble(0x3fed2d861aa0ed2bL), Double.longBitsToDouble(0x3fe12ebe0f059947L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\0121=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 2, 8, 8, 11, "\ud8ae\udfae\ud864\ude38\udb20\udd19\udaf1\ude7e\uda98\udffe\udb80\udf44\ud991\udceb\uda6c\udccf\ud979\udf46\ud98d\udefc\udb1c\udc31", "\u3b20", "\uda87\udcf4\udb65\uddd3\ud895\udfc7\ud867\udecd\ud933\udd8a\ud87e\udd7f\udb71\udf07\udb26\ude6d\udb2c\udc9b\ud87b\udf20\udb68\udcc2",
        41, 34149, 1637993939, -9037727647301568015L, 16463L, true, false, (char) 37791, (char) 47165,
        Double.longBitsToDouble(0x3fd122ecf549182eL), Double.longBitsToDouble(0x3fc4bd9b1f4d27d0L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=[B:[[-16, -69, -82, -82]]\0121=[B:[[-16, -69, -82, -82]]\012",
        Z.run(T, 2, 12, 12, 15, "\ud8ae\udfae", "\u0d27\u7137\u20b0\u1b34\ud3fe\u9906\000\u37e8\uc38c\u7524\000\ubf1b\ucbbb\uad71\u05a3\u6d16\u1062\u5ea4\ud538\u75de\000\u5bda\ub3c9\u1748", "\ud9a4\udfb5\u0097\ud9e8\udf94",
        17, 55939, 725298829, 2943498609304403968L, 348L, false, false, (char) 46122, (char) 64250,
        Double.longBitsToDouble(0x3fea617859c5a29fL), Double.longBitsToDouble(0x3fd5e59765387dc2L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 13, "\ud816\udd6a\ud864\ude50\udb41\udcc6s\000", "\u5c9f", "\ud873\udedd\udbf6\udd82\ud867\udc81\ud8b5\udd99\u520a\000\ud91d\ude4d\udae8\udff0\ud875\udf9f\uc113\ud9f6\udedf\udb42\ude33\udb19\uddce\000\udb2b\udfe6\ud87b\udf20\uda62\udc76",
        -1, -1000, 1535508480, 8704471918280529555L, 96604L, true, true, (char) 60082, (char) 29827,
        Double.longBitsToDouble(0x3faaa7cef2200d60L), Double.longBitsToDouble(0x3f9a1e196afb4c40L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 6, 7, "\ud816\uddea\ud864\ude50\udb41\udcc6s\000\000\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\udb63\udf37\udbf6\udd82\ud8a5\udd29\ud8ef\udd77n\000\ud881\ude3f\udae8\udff0\ud875\udf9f\ud867\udecd\ud8e1\udc1b\udb2c\uddef\udb19\uddce\000\udb2b\udfe6\ud87b\udf20\udacd\udf99\ud97f\ude81\000\udb36\udd3b\ud824\udc37\ud9b9\ude77", "\uc923\ua843\u3317\ud41c\uc6f6\u0f9b\u6e42\u628a\ud4d5\u43dc\u804a\u1f32\u3558\u045b\u42f4\u3ae3\u0634\ud679\u91bc\u1eef\ud454\u9d73\u10df\u587e\u55a7\uc393\u73c0\u24c2\u641c\u2731\ud263\ua70c\u0b6e\u15e0\u9d76\u7ac3\ua3da\u19f9\u9ba9\u9ada\u9b94\uaac1\u3a18\u2bfa\ub020\u0d17\u4e11\u1438", "\uaebc\ud9cf\udebd\udb11\ude65\ued19",
        4, 94719, -1534998074, 3989077720202656130L, -41938L, false, false, (char) 2938, (char) 55846,
        Double.longBitsToDouble(0x3fe2d6e1747bad2aL), Double.longBitsToDouble(0x3fd459e09de7a5aaL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud816\udd6a\ud864\ude50\uda0d\udd66\ud943\udf07\u00c7\000\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\000", "",
        36, 79186, 249286335, 3172174838213480094L, 80790L, false, false, (char) 15385, (char) 711,
        Double.longBitsToDouble(0x3fdadcb5074730a4L), Double.longBitsToDouble(0x3f451dc000000000L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 13, 8, "\ud816\udd6a\ud9a8\udf32\udbf7\ude7a\u00d1\000\000\udb0a\udec5\ud803\uddeb\u8941\ud89c\udc04\ud873\udedd", "\000", "",
        12, 55733, 249286335, 3172174838213492638L, 80790L, false, false, (char) 25, (char) 31319,
        Double.longBitsToDouble(0x3fdadcb5074730a4L), Double.longBitsToDouble(0x3f451dc000000000L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud816\udd6a\ud978\udd7a\udaad\ude9a\udbc2\ude73C\000\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\000\000", "\ud9ae\uddb3",
        9, 66509, 1562742430, -8502698360194384438L, -84615L, true, false, (char) 40189, (char) 41973,
        Double.longBitsToDouble(0x3f451dc000000000L), Double.longBitsToDouble(0x3fee12f7e03b5ef8L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud8ee\udd76\ud864\ude50\udb41\udcc6s\000\uce47", "\u0508\ua5c7\ua61e\ud00f\u45c9\uaa18", "",
        36, 79186, 249286335, 3172174838213480094L, 80790L, false, false, (char) 8729, (char) 8749,
        Double.longBitsToDouble(0x3fe5dfc71ba3cfc2L), Double.longBitsToDouble(0x3f451dc000000000L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 2, 7, "\ud8d9\udc67", "s", "\udb0a\udec5",
        16, 51171, 1888792666, 76460007396221388L, -100000L, false, false, (char) 55850, (char) 34579,
        Double.longBitsToDouble(0x3fea0076de9e2cf6L), Double.longBitsToDouble(0x3fcc8ba4b72a2800L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud827\ude29", "O\000\ua995\u8bb5\u5c9f\u0508\ua5c7\ua61e\ub7d5\ua58c\000\000\000\ua5a1\u4b38\u405b\u1062\uc503", "\uda46\udf5c\udb23\udeb3\ud87b\udf20\udb7a\udf90\uda99\udceb\u9fc2\uda38\ude7a",
        59, 48665, -369205980, 1337322765452193923L, 90898L, true, false, (char) 61580, (char) 21327,
        Double.longBitsToDouble(0x3fe37f2e23f660e0L), Double.longBitsToDouble(0x3fbd470c02fbe190L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 13, "\ud816\uddaf\uda9c\udfd9\udb2d\udffas\udab5\ude99f\udb0a\udec5", "\u5a5b\ua61e\u12ba\ua58c\000", "\ud881\ude3f\udae8\udff0\ud875\udf9f\ud867\udecd\ud8e1\udc1b\udb2c\uddef",
        14, 14232, 1082932249, -3796320928953871955L, -100000L, false, false, (char) 7434, (char) 239,
        Double.longBitsToDouble(0x3fdd2f4d95ff82f4L), Double.longBitsToDouble(0x3fcc183a1999ed8cL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud816\udd6a\ud864\ude50\udb41\udcc6s\uda70\ude92P\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud8c9\udee8", "\000", "",
        36, 79186, 249286335, 7085935953338901913L, -18687L, false, false, (char) 15385, (char) 711,
        Double.longBitsToDouble(0x3fdadcb5074730a4L), Double.longBitsToDouble(0x3f451dc000000000L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 11, 9, "\uda0e\udd7e\ud864\ude50", "\u238b\u89cf\u19d0\ua902\u5222\u71c2\ubb5ae\u43c1", "\ud85b\udcff\udbcc\udc9c\udbea\udec0\ud907\udf08\ud937\udf11\udab0\ude93",
        10, 94394, 118768357, 4651158593663451707L, 13750L, true, true, (char) 47665, (char) 34724,
        Double.longBitsToDouble(0x3fdc8089324ac48eL), Double.longBitsToDouble(0x3fa822177cb33d60L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 13, "\uda0e\udd7e\ud885\udc0c", "\u64cb\u1ac4\u19c1\u56c2\ua033\u78a5\ua9d2B\u43c1", "\ud85b\udcff\udbcc\udc9c\udbea\udec0\ud907\udf08\ud937\udf11\udab0\ude93",
        10, 37418, 118768261, -5558783236019664046L, -90795L, true, true, (char) 47665, (char) 35236,
        Double.longBitsToDouble(0x3fcadc940495891cL), Double.longBitsToDouble(0x3fc72885df2ccf58L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\udbf7\udff2\ud98b\udf7e\udb41\udceb\udb66\ude27\u88b9\udb25\uded4", "\u0d9f\u368d\u5791U\u056e\u0149", "\udb79\udda0\udae8\udff0",
        20, 48333, 1562742430, -8462728915430851126L, -84615L, true, false, (char) 40189, (char) 13557,
        Double.longBitsToDouble(0x3fe07ed10b6060c7L), Double.longBitsToDouble(0x3fefbb93bac8ed38L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 4, 7, "\udbf7\udff2\ud98b\udf7e\udb41\udceb\ud938\udd50\ud95c\ude3b\uda73\udf47", "\uc23a\u7647\u640a\ua8fa\u5cbew", "\uda21\udd44\udae8\udff0",
        20, 48333, 1562742430, -8462728915425083190L, -84615L, false, true, (char) 40142, (char) 13557,
        Double.longBitsToDouble(0x3fdcdda215156df2L), Double.longBitsToDouble(0x3fefbb93bac80893L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\udbf7\udff2\ud98b\udf7e\000\udb66\uddb4\u88b9\udb25\uded4", "\u0d9f\u368d\u5791N\u6f14\u0149", "\udb79\udda0\udae8\udff0",
        20, 48333, 1562742430, -8462728915430851126L, -84615L, true, false, (char) 40189, (char) 13557,
        Double.longBitsToDouble(0x3fdcdda215156df2L), Double.longBitsToDouble(0x3fefbb93bac80893L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -40, 89, -33, 70, -40, -112, -33, 70, -37, 65, -35, 116, -37, 102, -34, 39, -120, -71, -39, 89, -35, 46, -39, -87, -36, 35]]\0121=[B:[[-2, -1, -40, 89, -33, 70, -40, -112, -33, 70, -37, 65, -35, 116, -37, 102, -34, 39, -120, -71, -39, 89, -35, 46, -39, -87, -36, 35]]\012",
        Z.run(T, 2, 9, 9, 12, "\ud859\udf46\ud890\udf46\udb41\udd74\udb66\ude27\u88b9\ud959\udd2e\ud9a9\udc23", "\ua5c7\u4954\u5598\u6233\u4cb0", "\udac5\udf50\udbd3\udc23\udae5\udf05\ud867\udecd\ud99d\udc39\ud862\udd15\ud9e0\udf26",
        50, 56992, 38847035, -5896959058099945606L, -53031L, true, true, (char) 45381, (char) 21781,
        Double.longBitsToDouble(0x3f95f869f189abe0L), Double.longBitsToDouble(0x3fef36dba4ec05d7L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\udb63\udfcf", "\ucccd\u7994\u0380\u1c89\u0508Z\u485b\u5598\u6233", "\ud90a\udc57",
        31, 33370, 237692464, 3172174838247034526L, -100000L, false, false, (char) 40189, (char) 41973,
        Double.longBitsToDouble(0x3fbe79bb843c0a90L), Double.longBitsToDouble(0x3fefbaeadf68c1ddL)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 13, "", "\uc684", "\ud959\udd2e\ud9a9\udc23\uc5d5\udb63\udcb6\ud98d\udefc\ud8a2\uddc9\u1c61\uda3a\uddcf",
        12, 60720, -183154436, 7686807772445569066L, 19861L, false, false, (char) 26507, (char) 3143,
        Double.longBitsToDouble(0x3fb6201be8c7e080L), Double.longBitsToDouble(0x3fe1da0211adcb50L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\ud890\udf46", "\ucccd\u7994\u0380\u7a72\u8e28w\u78c2\u5598\u6233\u4cb0\u7030\u940b\ub55f\ubbd0\u86fa\uc9d8\uabaa\u6628", "\ud9d4\udce1\ud87b\udf20",
        39, 56931, -2125279111, 6727050212023333879L, -19835L, true, false, (char) 8171, (char) 12218,
        Double.longBitsToDouble(0x3fcd80bafcf590f4L), Double.longBitsToDouble(0x3fea6744d1e952fcL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 2, 15, "\ud8a2\udf0d\ud97d\udd02\udb8b\udee5\ud809\udca5\ud907\udd58\udbf3\udc9b\udb0a\udec7\ud893\udc9b\udb36\ude88\ud98d\udefc", "\ua4efO\u12cb\u19a8\uc8c0\u34c4\u54a8\u80c0\ucc6d\u8b5f", "\udb2b\udfe6\ud87b\udf20\uda6f\uddeb\ud9f8\udcdc\udb47\udf31",
        9, 13455, -2065317642, -3120289238768417434L, 5981L, true, true, (char) 25939, (char) 10116,
        Double.longBitsToDouble(0x3fd44e8efa8feef2L), Double.longBitsToDouble(0x3fefea5c910763a3L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 2, 15, "\ud8a4\ude47\ud902\udd04\ud93b\udc43\ud809\udc92\ud907\udd58\uda2d\udc98\udb0a\udec7\ud803\uddeb\udb63\udcb6\ud98d\udefc", "\uc07e6\u30e9\ub05e\uc8c5\u34c4\u54a1\u80c0\u578f\u6d01\uc683\u98cf\uad0a\u0321\u0354\u6cb6\u629f\uc793\u147d\ub80c\u4142\ub09b\u9627\u06ee\u628b\ud1e1\u8f40\u597a\u3b1b\u82ee\uaa1c\u0aa6\u4a1e\ub485d\u48d8\uac35\ub95e\u52f8\uc05b\u63fc\ua706", "\uda3d\udf97\ud8e8\udee4\udb8f\udfd9",
        29, 10608, 665911756, -3817218407301487562L, -38480L, true, true, (char) 24004, (char) 60819,
        Double.longBitsToDouble(0x3fcfdfbf6260ff74L), Double.longBitsToDouble(0x3fe861bd10163755L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 0, 12, "\000\000\udaaf\udefe\ud979\udcb3\ud8fa\udd30\ud849\ude8f\uda47\uddf3\u8210\udba2\uddcc\ud9bc\udc80\ud873\udedd\udbf6\udd82\u0277\u22af\ud8bf\udc3e\ud8b1\uded0\udbcc\udc9c\udbe6\udc2e\000\ud867\udecd\ud867\ude9f\udb0d\udeb1\udb42\udff5\ud97d\udde7\udb1e\udc25\udafa\udc7c\uda5c\udc1a\udacc\udf45\uda14\udd6c\ub90d\uda17\udf1f", "\u9e7a\u22b7\ud654\u65d2w\u6aa9\ud4a1\u2d63\uae79\u641d\ua3e7\u9681\ub959\u5b60\u90eb\u2d94\u70fb\u8c35\u085e\u9781\u1b08\ud0d9\u1c00\u3088\ub47b\u2e31\u026d\ubd0c\uaf6b\ub930\ubd31\u996a\ub75b\ubda6\u4c07\u3ead\u4b90", "\uda73\udc7f\ud839\ude74\ud8ae\udc00",
        52, 77261, -1036225669, 208857485742854964L, -64945L, true, false, (char) 59616, (char) 37809,
        Double.longBitsToDouble(0x3fe81c1297baced2L), Double.longBitsToDouble(0x3feb97f6bf815198L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\udaa6\udfe5\udbaa\udecb\ud9b3\udfd7\udb66\ude9a\u88b9\ud966\ude7eT\000\ud9d1\udda8M\ud873\udedd", "\ubcc1\u65d0\ud0b0\uc86d\u4b38\ud328\u1682", "\udb49\udf07",
        27, 56329, 59, -1460794461L, -54607L, true, true, (char) 29531, (char) 39759,
        Double.longBitsToDouble(0x3fe32815b1db5751L), Double.longBitsToDouble(0x3fe5b3142f4865b4L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 12, "\ubf0e\ud87c\udfd2\uf2eb\ud981\udea7\ud845\ude81\uda09\ude40\uda0c\udcaf\ud853\udc46Y\000\udaf8\ude80", "\u40b0", "\udbcc\udc9c",
        10, 41927, 749047355, 1917419860556793035L, 28093L, true, true, (char) 21160, (char) 63552,
        Double.longBitsToDouble(0x3fe640449ec6622aL), Double.longBitsToDouble(0x3f8ac00fcf63f2c0L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ub0ed\ud864\ude50\000\udb66\ude27\u88b9\ud966\ude7e\uda2a\udc08\ud9a8\udf34A\ud996\uddca\ud91b\udc1d", "\ubcc1", "\udbcc\udc9c\udae8\udff0\ud875\udf9f",
        39, 23790, 499689417, -8263755903336693019L, 96563L, false, false, (char) 16430, (char) 45450,
        Double.longBitsToDouble(0x3fe57db7cff77277L), Double.longBitsToDouble(0x3fe640449925622aL)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda7f\udeeb\ud8cd\udd5c*\uff00\000\udb0d\udda5\udb0a\udec5", "\000\u8f87\uad25\u984ar", "\udbcc\udc9c\udb02\udfc1\ucebf",
        39, 82942, 1166346719, 4647982860277387939L, 12081L, true, true, (char) 44406, (char) 21031,
        Double.longBitsToDouble(0x3fba0ef443bf82a8L), Double.longBitsToDouble(0x3feafe984f632bcfL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda6c\udd52", "\u1f01\000\u9194\u19c1\u9b6f\ucd53Q\000\uc12e\u984ar\u8d3a\ua30e\uc8f5\u3aaa\ucebf\u1062\u654d\u80fa\u383c\u69f8\u7b30\u089c\u3160\u474e\u231f\u3c54\uaf9e\uc3c8\ub0c9\u356f", "\udac7\udd8c\udb31\uddc8\uda31\uddb4\uda47\udf4f\u42f4\ud9bf\udcaa\ud936\udf13\udb86\udcc5\ud976\udc64\udabc\udebf\uda7b\udcac",
        -5, 49325, 878329519, -5329015555532900007L, 18025L, false, true, (char) 4657, (char) 51823,
        Double.longBitsToDouble(0x3fe2fe0db60b7ac8L), Double.longBitsToDouble(0x3fe225eac172c71bL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 7, 15, "\uda0e\ude5d\u00c1\ud823\udc8a\000\u88b9\udb7a\udc3e\u548c\ub636\udb63\udcb6Z\ud84a\udee4\ud89b\udecc\ud905\udc68\ud9cd\ude4f\uda3a\udf2e\ud85b\udcff\udbcc\udc9c\udae8\udff0\u00bf\000\000\ud910\udcc6\u93b0\ud894\udee6\000", "\u1c06\u79f3\uca34\u417b\u9f20\u7016\ubfe8\uce69\u1c44\u6234\ud307j\u461c\u9d80\u0c67\ucb8a\u4860", "\ud82a\udd9e\udb4b\udee9\ud896\udf89\ud903\udcae\ud972\udc9e\ud86e\udc6a\udaf3\ude28",
        20, 80424, -131116835, -5663202437303308130L, -76678L, false, true, (char) 61131, (char) 24846,
        Double.longBitsToDouble(0x3fe38fe66fd98c71L), Double.longBitsToDouble(0x3fe29bf183620026L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 3, 15, "\uda0e\ude5d\u00c1\ud823\udc8a\udb66\ude27\u88b9\udb7a\udc3e\u548c\ub636\udb63\udcb6\udb03\ude64\ud877\udec8\ud89b\udecc\ud905\udc68\ud9cd\ude4f\uda3a\udf2e\ud85b\udcff\udbcc\udc9c\udae8\udff0\u00bf\000\u00df\ud910\udcc6\u93b0\ud894\udee6\000", "\ubd70\uca61\u91bd\u417b\u9f20\u7016\u77e8\uce69\u1c44\u6234\ud307\u2bf7\ucddf\u9d80\u0c67\ud012\u4860", "\ud82a\udd9e\udb4b\udee9\ud896\udf89\ud903\udcae\ud972\udc9e\ud86e\udc6a\udaf3\ude28",
        20, 80424, -131116835, -5663202437303308130L, -76678L, false, true, (char) 61131, (char) 24846,
        Double.longBitsToDouble(0x3fe38fe66fd98c71L), Double.longBitsToDouble(0x3fe29bf183628d26L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 3, 15, "\udbf7\udff2U\ud823\udc8a\udb66\ude27\u88b9\udb7a\udc3e\u548c\ub636\udb63\udcb6\ud98d\udefc\ud873\udedd\ud89b\udecc\ud905\udc68\ud9cd\ude4f\uda3a\udf2e\ud85b\udcff\udbcc\udc9c\uda47\udcbfH\ud904\udee5\u5716\ud93b\ude37\u93b0\ud894\udee6\000", "\u1c06\u79f3\uca34\u417b\uca62\u3af3\ubfe8\uce69\u1c44\u6234\ud307j\u461c\u9d80\u0c67\ucb8a\u4860", "\ud82a\udd9e\udb48\udcdb\ud896\udf89\ud903\udcae\udabe\uded0\ud951\ude31\ud85f\udd07",
        33, 80424, -131116835, -2840735198081403572L, 35507L, true, false, (char) 38718, (char) 33866,
        Double.longBitsToDouble(0x3fe29bf183628d26L), Double.longBitsToDouble(0x3fc9ae46951fc490L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 3, 15, "\uda0e\uddfbI\ud823\udc8a\udb66\ude27\udb49\udcab\udb7a\udc5c\u548c\ub636\udb63\udcb6\ud878\udc74\ud873\uddf8\ud89b\udecc\ud905\udc68\ud9cd\ude4f\uda3a\udf2e\ud85b\udcff\udbcc\udc9c\ud814\udd85\uda73\udc7f\ueaec\u3f15\ud910\udd62\u93b0\ud894\udee6\000", "\u1c06\u8048\uca34\u417b\u9f20\u7016\ubfe8\uce69\u1c44\u6234\u9ba1\uc47a\u461c\u9d80\u0c67\ucb8a\u4860", "\ud82a\udd9e\udb4b\udee9\ud896\udf89\ud903\udcae\ud972\udc9e\ud86e\udc6a\udaf3\ude28",
        20, 80424, -131116835, -475055666572496872L, -93452L, true, false, (char) 38718, (char) 33866,
        Double.longBitsToDouble(0x3fe29bf183628d26L), Double.longBitsToDouble(0x3fdc00124c411538L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 6, "\uda0e\ude5d\ud864\ude50\ud95c\udcfc\ud9fc\udd98\ud882\ude79\udbf7\ude3c\udad3\ude7d\ud803\uddeb\udaba\udddf\ud8dd\udcd4\ud9e1\udd6c", "\u4bd4\ub5e9\u7a5a\ub76f\u6f5e\ua956\u53ea\u6f86\u5685\ua3e7\u6af5\u82e7\u8400\u9771\u531e\ud069\uca34g\000", "\udbf8\udd40\uda61\udd31\ud9f6\udedb\udb08\ude58\udaa6\udf0c\ud986\udff5\ud987\udef0\ud974\uddb7\uda93\udfe8\udb45\udc3b\udb51\udcbb\ud959\udf91\uda8a\udd42\udba0\udd1e\uda00\udc8c\ud9b9\uddcf\uda1a\udebc\ud8aa\udc6a\ud8d2\udc0c\ud9ac\udd8c\uda0c\udeea\uda46\udca6\ud9b2\ude24\udbb5\ude1a\udba5\udd40\udb7a\udd3b\ud9ac\udd30\ud85f\udfa3\udb40\udf4f\uda11\udeca\ud949\ude1d\udaff\udcc0\ud815\udd72",
        5, 8681, -1090353566, -3198067392144576890L, -84571L, true, false, (char) 7072, (char) 13807,
        Double.longBitsToDouble(0x3f9171a7eb1687a0L), Double.longBitsToDouble(0x3fa2adf0fc4d9030L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 6, "\uda0e\ude5d\ud9ed\uddd4\udbdb\udd28\ud9fc\udd1e\ud882\ude79\udbf7\ude3c\udad3\ude7d\ud803\uddeb\ud87c\udee0\ud8dd\udcd4\ud85d\uddcb", "\u4bd4\ub5e9\u7a5a\ub76f\u9616\uc9eb\u871c\u6f86\u5685\ua3e7\u8148\u8899\ub3c9\u1158\u62a0\ud069\uca34ge\u067a\ucb0f\ub115\u4f04\u930b\u517b\u8b6d", "\ud974\uddb7\uda93\udfe8\udb45\udc3b\ud825\ude01",
        59, 87526, 946267596, -4501501506458359760L, 91238L, false, false, (char) 37229, (char) 5883,
        Double.longBitsToDouble(0x3fcda6207d5a32c4L), Double.longBitsToDouble(0x3fe1c6e554c7ab69L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 6, "\uda0e\ude5d\udbce\ude45\u032b\ud9be\ude1e\ud882\ude79\udbf7\ude3c\udad3\ude7d\ud803\uddeb\udaba\udddf\ud8dd\udcd4\ud85d\uddcb", "\u4bd4\ub5e9\u7a5a\ub76f\u6f5e\u00bf\u8767\u6f86\u5685\ua3e7\u8148\u4c80\ub3c9\u1158\u62a0\ud069\uca34g\000\u067a\ucb0fg\ucfb3\u930b\ua509\u8a95", "\ud974\udd06\uda93\udfe8\u0d5c",
        29, 13984, -1409366474, 252663288001536L, 21867L, false, false, (char) 63020, (char) 47187,
        Double.longBitsToDouble(0x3ec2a00000000000L), Double.longBitsToDouble(0x3fe8000004ed3103L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 6, 10, "\uda0e\ude5d\ud864\ude50\u032b\ud9fc\udd1e\ud882\ude79\udbf7\ude3c\udad3\ude7d\ud803\uddeb\udaba\udddf\ud8dd\udcd4\ud85d\uddcb\ud908\udd4c\u6550\uda66\udef8\ud88b\udd0a\udb29\udd92\ud94b\udecf\uda19\ude88\ud8a8\udd92\ud90d\udd08\ud8dd\udd7f\uda96\udcee\udb95\udd5c\udb16\udd4f\udb2b\udfe6\ud87b\udf20\udbb4\udc6b\uda65\udce0", "g\000\u067a\ucb0f\ub115\u4f04\u930b\u517b\u8b6d\u77b4\uaa63", "\udb45\udc3b\ud825\ude01",
        59, 87526, 949609932, -4501501506458359760L, 91238L, false, false, (char) 37229, (char) 5883,
        Double.longBitsToDouble(0x3fcda6207d5a32c4L), Double.longBitsToDouble(0x3fe1c6e554c7ab69L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 10, 15, "\uda0e\ude5d\udba2\udcc5\u03fc\udb66\uddb4\ud9e7\udfda", "\u9abe\u245bl\u96cc\u12ba\u6524\000", "\udbcc\udc9c",
        16, 66319, 1613856770, -495100833910163148L, 47424L, true, false, (char) 18548, (char) 51905,
        Double.longBitsToDouble(0x3fe666d63109d1f4L), Double.longBitsToDouble(0x3fa4b4023ff91360L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 4, "\uda25\udd6d\uda47\udf71\udb41\udcc6\uda54\udcdc\udb6b\udf4az", "\u224d\u03b9\ua61e\u12ba\u3f03\u3098", "\ud91d\ude4d",
        2, 17335, -891870496, 6999725379627823400L, -50277L, true, true, (char) 63248, (char) 43246,
        Double.longBitsToDouble(0x3e4c5d6e18000000L), Double.longBitsToDouble(0x3fc74f198cc39944L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 15, 13, "\ud87f\ude6a\udba4\udcf5\ud977\ude7a\uda2e\udd88V\000\udb0a\udec5\udb37\udccf\ud82c\udcbf\ud89c\udc04\ud873\udedd", "\000\000", "\udae4\udc06",
        18, 91299, -1178463891, 1907753678942572063L, -74573L, true, true, (char) 43246, (char) 0,
        Double.longBitsToDouble(0x3fcda3f898b4519cL), Double.longBitsToDouble(0x3fe82ddb4bfa1278L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud816\udd6a\ud978\udd7a\udaad\ude9a\udbc2\ude73C\000\udb0a\udec5\ud803\uddeb\udb39\udfb6\ud98d\udefc\ud873\udedd", "\u544cs\000\ua5a1\u8e2e", "\ud8e1\udc1b\udb2c\uddef\udb19\uddce\000\udb2b\udfe6\ud87b\udf20\udb7a\udf90\ud97f\ude81\000\udbf3\udd98\udb2b\udd5a\ud9df\udf4a",
        50, 27737, -99229401, -2811017469643105091L, 89532L, true, false, (char) 32806, (char) 6740,
        Double.longBitsToDouble(0x3fed9960fd9445acL), Double.longBitsToDouble(0x3fe28fae3ef296a2L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 4, 7, "\ud816\udd6a", "\u08bfC\000\u19c1", "\ud98d\udefc\ud873\udedd\ud959\udf11\ud8a5\udd29\ud9df\udcef",
        45, -918, 1778384896, -7902568120188202158L, 2046L, false, false, (char) 51146, (char) 81,
        Double.longBitsToDouble(0x3f99000047681180L), Double.longBitsToDouble(0x3fdadcb5074730a4L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud816\udd6a\ud978\udd7a\udaad\ude9a\udbc2\ude73C\000\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\000X", "\ud9ae\uddb3",
        9, 66509, 1562742430, -8502698360194384438L, -82926L, false, false, (char) 41406, (char) 64983,
        Double.longBitsToDouble(0x3f451dc000000000L), Double.longBitsToDouble(0x3fee12f7e03b5ef8L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 7, 11, "\uda9f\udf9b\ud920\udd34", "C\u652c\u0bd4\u65f3\ub088\u7a55\ua61e\u02c2\u5a74", "\ud8b1\udf78\ud931\udf14",
        1, 70354, 738579679, 6711927626941880464L, 75525L, false, false, (char) 44525, (char) 40168,
        Double.longBitsToDouble(0x3fed1cc29000a8eeL), Double.longBitsToDouble(0x3e4f097bf0000000L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud827\ude29\udb7e\udc1d\udae4\ude15O\000\ud976\udda1\ud817\udda1\ud8e8\ude81\ud8c7\udd9f\udaea\uddc3\ud873\ude48\ud947\uded0\udb42\udd85\ud96e\udc4aK\000\ud881\ude3f\udae8\udff0\ud875\udf9f\ud867\udecd\ud8e1\udc1b\udb2c\udd93\ud8c4\udf8e\ud95a\udcea\udaa6\uddf7\ud886\udeed\udb5d\udf60\udb03\udd8c\uda9e\udc58", "\u08f7", "\udbea\ude60\ud897\udc72\ud8b1\udedb\ud807\udc20\ud947\udf8c\udabf\udc50\udbf2\udccd\ud8de\udda0\ud9f4\udc24\ud8f1\udd9f\udab0\udfba\ud873\ude3d\uda3b\udebb",
        17, 60549, 1021251045, 7228319320320562343L, -96603L, false, false, (char) 26749, (char) 34395,
        Double.longBitsToDouble(0x3fe000e17fd5cd83L), Double.longBitsToDouble(0x3fda5183ff9014c0L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud827\ude29", "O\000\ua995\u8bb5\u5c9f\u7cd8\u4cc8\ua61e\ub7d5\ua6bcX\000\000\ua5a1\u4b38\u405b\u9187\u759b", "\uda46\udf5c\udb23\udeb3\ud87b\udf20\udb7a\udf90\uda99\udceb\u9fc2\uda38\ude7a",
        59, 13409, -369205980, 1337322765452193923L, -82253L, false, true, (char) 24291, (char) 40409,
        Double.longBitsToDouble(0x3fb5f60d59640118L), Double.longBitsToDouble(0x3fe37f2e23f660e0L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 7, 13, "\ud816\uddaf\udb5b\udc39\ud9eb\udc17s\ud9b1\udcdbs\udb0a\udec5", "\u5a5b\ua61e\uad0c\u6b66\000\u7965\000\ua5a1\u4b38\u405b\u1062\uc503\u9509\u3e2a", "\udbdd\udf44\ud883\udcf3\ud97f\ude81\000\u5a4b\ud817\udcfa\udb19\udcf0\udb07\udc22\udbc3\udf45\ud9e0\udc25",
        46, 70788, -1191055567, 3496245092459742210L, -35121L, false, false, (char) 37706, (char) 36879,
        Double.longBitsToDouble(0x3fa2dd4307f0ce40L), Double.longBitsToDouble(0x3fdc2ab896b2961cL)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 3, "\udb84\udd82\uda89\udf7e\udb19\udce0\udaa9\udd98\uffdc\udb39\ude30\udb0a\uded4", "\uca0d\ubb5ae\u43c1\u162f\u8c9e\u41ad\uc86d\u73dd\u2481\ub142\u495d\ud5b1\uaddd\u1f51\u8899\u083c\u6d74\u9865\u048d\u453b", "\uda85\udd29\ud80c\udf3e",
        4, 10400, -1203406090, -6324612655106094060L, 47165L, true, false, (char) 7737, (char) 40877,
        Double.longBitsToDouble(0x3fd23a4afca989daL), Double.longBitsToDouble(0x3fe5a33b4d45743cL)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 4, 5, "\uda01\ude20\ud98b\udf7e\udb41\udceb\ud938\udd50\ud95c\ude3b\uda98\udf6d\udbf2\ude26\udb6d\ude63\ud9eb\ude8d\ud997\uddd7\ud848\udc11", "w\u6ecb\ud491\u7cc1\u4b38", "\ud89c\udfae\ud902\udd41\u8000\ud910\udcc4\udaf2\udca8\ud9ae\udd99\udb7a\udf90\ud8ca\udef3\uda47\udc20\udbac\udd48\ud984\udc78\uda36\udc35",
        55, 3348, 311187914, -6429855807104472088L, -741L, false, true, (char) 39667, (char) 22977,
        Double.longBitsToDouble(0x3fc28f8473b104b4L), Double.longBitsToDouble(0x3fb79bf66bc73d40L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\udb63\udfcf", "\ucccd\u7994\u0380\u1c89\u1c16\ua5a0\u485bD\u644b", "\ud90a\udc57",
        31, 33370, 237692464, 3172174838247034526L, -15150L, false, false, (char) 40189, (char) 41973,
        Double.longBitsToDouble(0x3fbe79bb843c0a90L), Double.longBitsToDouble(0x3fefbaeadf68c1ddL)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 17, "\ud859\udf46\udb63\udfcf", "\ucccd\u7994\u3fac\ua79c\u0508Z\u485b\u5598m", "\ud90a\udc57\ud95e\udc35\uda7b\udcb8\udae5\udf05\ud867\udecd\ud99d\udc39",
        37, 34083, 11003009, -883899904L, 28093L, true, false, (char) 49297, (char) 20982,
        Double.longBitsToDouble(0x3fe3de0eef3b503cL), Double.longBitsToDouble(0x3fddc9bf024aa924L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 13, "", "\u50c6", "\ud913\ude2f\ud985\udc9f\uc5d5\uda91\udec4\u89c0\udba0\ude67\udacf\udca2\ud907\udfa2",
        12, 3512, -136272976, 7703752878717169706L, -97850L, true, false, (char) 47766, (char) 16255,
        Double.longBitsToDouble(0x3fe1da02c9adcb50L), Double.longBitsToDouble(0x3fe9e0a96246722bL)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 0, "", "", "",
        -5, 64687, 44, 29837031542816512L, 31321L, false, true, (char) 65, (char) 58351,
        Double.longBitsToDouble(0x3fe541b800fc91ebL), Double.longBitsToDouble(0x3e95000000000000L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 2, 3, "\ub0ed\ud864\ude50\udab6\udff9\ud897\udf69\uda1b\udf71\ud901\udc43\uda2a\udc08\uda66\udd7fA\ud996\uddca\ua317\ubd98\udbfa\udc69\ud9cd\udeb1\udb88\udeb5\ud849\udc03", "\u405b\u8456\u95b6\u928e\ucae7\u2cbf\u317a\ub0f0\u40f8", "\udb93\udd6d",
        22, 45795, 1186767536, -7778275636729356476L, 47736L, false, false, (char) 7685, (char) 30238,
        Double.longBitsToDouble(0x3fbb568ae75da658L), Double.longBitsToDouble(0x3fb0a66f0c456de0L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 3, 15, "\udbf7\udff2U\ud823\udc8a\udb66\ude27\u88b9\udb7a\udc3e\u548c\ub636\udb63\udcb6\ud98d\udefc\ud873\udedd\ud89b\udecc\ud905\udc68\ubb52\uda3a\udf2e\ud85b\udcff", "H\u7a3c\u4814\u8022\u93b0\u02fd\000\u82ab\u64f8", "\udbac\udd48\udab2\udc78",
        55, 56906, 1674215843, 2001794494017221252L, 64277L, false, true, (char) 62832, (char) 56952,
        Double.longBitsToDouble(0x3fa1f788b1e43b90L), Double.longBitsToDouble(0x3fd7fbcdc78ff09cL)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 3, 15, "\udbf7\udff2U\ud80c\ude8a\ud9fd\udd38\u8930\udb7a\udc3e\u548c\udb13\ude08\udb7a\ude98\ud98e\ude58\ud920\udefc\ud8cc\udcd8\ud905\udc68\ud9cd\ude4f\uda3a\udf2e\ud85b\udcff\udbcc\udc9c\uda47\udcbfH\ud904\udee5\uda7f\udf49\ud93b\ude37\ud9f4\udd76\udadb\udd8f\udac8\udc93", "\u02aa\u79f3\uca34\u5ced\u3319\u55c2\ubfe8\uce69\u6bae\u6234\ud307j", "\udac4\udc20\ud825\udf29\udba2\udd0a",
        23, 69736, -812811143, 3151532686423901543L, -69312L, true, false, (char) 42642, (char) 36319,
        Double.longBitsToDouble(0x3fe1c3090a4320ffL), Double.longBitsToDouble(0x3f67e864e69a5900L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 0, "\ud816\udd6a", "sC\000\000", "\ud98d\udefc\ud873\udedd\ud8b4\ude5e\ud8a5\udd29\000",
        22, -918, 1778384896, -7902568120188202158L, -100000L, false, false, (char) 15616, (char) 81,
        Double.longBitsToDouble(0x3f99000040000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud82b\udda0\udb8f\udde5\udbda\ude0a\udbe7\udc33C\000\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\uac31X", "\ud9ae\uddb3",
        9, 66509, 1562742430, -5265829574212567673L, -82926L, false, false, (char) 41406, (char) 64983,
        Double.longBitsToDouble(0x3f343b8000000000L), Double.longBitsToDouble(0x3fee12f7e03b5ef8L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud902\udf20", "O\000\000\u67cf\u5c9f\u7cd8Z\000\000\ua568X\000\000\000\u4b0e\u00bf\u9152\ube32", "\uda46\udf5c\udb23\udeb3\ud87b\udf20\udb7a\udf90\uda99\udceb\u9fc2\ud9c3\udf00",
        -5, 13216, -369205980, 1337322765452193923L, 90898L, true, false, (char) 61580, (char) 21327,
        Double.longBitsToDouble(0x3fe37f2e23f660e0L), Double.longBitsToDouble(0x3fd18f57fdf8328eL)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 17, 5, "\uda01\ude20\ud98b\udf7e\ud8bd\udce9\ud938\udd50", "\u7139\u6372\u30b6\u04ac\ud420\u9b35\u5d4ew\u6ecb\u63aeR", "\ud9ec\udfd9",
        59, 25118, 1974038077, -2601600168965341984L, 62201L, true, true, (char) 42315, (char) 47617,
        Double.longBitsToDouble(0x3fefbb922a830893L), Double.longBitsToDouble(0x3fc39b2805900d24L)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 0, "\uda84\udda2f", "", ",",
        30, 79912, 1880472479, 959830740034480042L, 12388L, true, true, (char) 0, (char) 13813,
        Double.longBitsToDouble(0x3fe947e9b2c257ecL), Double.longBitsToDouble(0x3fc3d620e473e920L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 12, 1, "\ud816\udd6a", "sC\u8ed5\u00df", "\ud98d\udefc\ud873\udedd\ud8b4\ude5e\ud8a5\udd29\000",
        19, -918, 1778384896, 174637809964969836L, -100000L, false, false, (char) 15616, (char) 81,
        Double.longBitsToDouble(0x3f99000040000000L), Double.longBitsToDouble(0x3e400c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 17, 9, "\ud9f5\udf18\ud98b\udf7e\ud8bd\udce9\ud938\udd50", "\u7c9c\u5375\u4c95\u04ac\ud420\ua491\u5d4ew\u6c20\u63bbR", "\ud9d4\udd17",
        59, 25118, 1974038077, -2601640850895569696L, 45538L, true, true, (char) 18474, (char) 47617,
        Double.longBitsToDouble(0x3fefbb922a830893L), Double.longBitsToDouble(0x3fc39b280ed00d24L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 5, "\udbf4\ude5a\ud8d3\udf97\uda1a\udc8f\ud88b\udd70\ud95c\ude3b\uda98\udf6d", "\u30b6\u04ac\ud420\u9b35\u5d4ew", "\udad4\udcbe\udae8\udff0",
        38, 8493, 1265912331, 8987408554221203005L, 64640L, true, true, (char) 47360, (char) 21547,
        Double.longBitsToDouble(0x3fd62d3e93abd5d4L), Double.longBitsToDouble(0x3fefbb922b830893L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 17, 9, "\ud9f5\udf18\ud98b\udf7e\udb0b\udcf0\ud938\udd50\ud95c\ude3b", "\u5375\u4c95\u04ac\ud420\ua491\u5d4ew\u6c20\u63bbR\u4b38\uba6c\u0726\u1436\u3c49\u19b1\u3aa3\ua440\ua6ac", "\uda2e\ude0b\udbdf\udfd3\ud984\udc78\ud97a\udc3a\uda39\udccd\ud98d\ude40\ud988\udcb5\ud9a4\udf8d\ud991\udfce",
        49, 23672, 1982579602, 4830702122110459863L, 93431L, false, false, (char) 33231, (char) 22011,
        Double.longBitsToDouble(0x3fdf377d73d09bfcL), Double.longBitsToDouble(0x3fe8057c28dfe625L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda0e\ude5d\ud864\ude50\udb41\udceb\udb66\ude27\u88b9\udb25\uded4\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\ud873\udedd", "\ubcc1", "\udbcc\udc9c\udae8\udff0\uda3e\udfdf",
        12, 89715, -1970382620, -8263755903336693019L, -50277L, true, true, (char) 41973, (char) 45679,
        Double.longBitsToDouble(0x3fe455b7cff77277L), Double.longBitsToDouble(0x3fe640449925622aL)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 15, "\ud889\udcc2\ud890\udf46\udb41\udd74\udb66\ude27\u88b9\ud82e\ude1a\udb0a\udec5\ud827\udfeb\udb63\udcb6\ud98d\udefc\ud8a2\uddc9", "\u4cb0", "\udbcc\udc9c\udbf1\udc33\ud849\udd23\ud867\udecd\ud8c2\ude5c\ud87e\uddf8\udb49\udf07",
        27, 9376, -883899845, -7470678291315291229L, -53031L, true, false, (char) 63571, (char) 39759,
        Double.longBitsToDouble(0x3f95f87bf189abe0L), Double.longBitsToDouble(0x3fef36dba4ec05d7L)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 3, 3, 0, "\udb4e\udc9d\uda49\udddd\ud827\udc1f\uda8d\udfda\uda9c\udf7c\ud82e\ude1a\udb0a\udec5\ud827\udfeb\udabc\ude24\ud8ec\udef1\ud8b2\udc7f\udb10\udcbf\uda42\udf07\udbe0\udcb1\ud917\udfe8\udb50\udee7\udbcc\udc9c\udae8\udff0\ud875\udf9f\ud867\udecd\ud8f7\udee7\udbbc\udf56\uda83\udd2f\udb26\udf4f\udb57\udc65\udbff\uddc2\udb7a\udf48\u81df", "\u1328\ua34b\u58ca\ub7a5\u3c3b\u04d3\u1fb1", "\ud88e\udc68\udaf1\udd12\udb24\udd09\ud961\uddce\udbde\udfd6\uda36\udf89\uda3d\udc96\udba5\udea0\ud833\udc6a\uda7b\ude54\u96f5",
        39, 81856, -1399184661, -7410635969758710569L, -40141L, true, true, (char) 8238, (char) 59818,
        Double.longBitsToDouble(0x3fef8572cfa48a5dL), Double.longBitsToDouble(0x3fe350599431b129L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 7, 13, "\ud91c\udd74\udbb4\udeb0\udb35\udd6e\udb66\ude27\u88b9\udb25\uded4\u548c\udafa\udd5d\udb63\udcb6\ud98d\udefc\ud873\udedd\udb1d\udf5f\ud920\udd27\ud9f7\udd84\uda3a\udf2e\ud85b\udcff\ud99d\udc86\udae8\udff0\u00bf\udbab\uddb1\udb10\udeca\ud868\ude0a\u00ca\ud894\udee6\ud80a\udf9d\ud8b9\udfa3\udb6a\udfe3\ud993\udc51\ud8e5\udc33\udbac\udd48\udab2\udc78\udbee\udc90\ud9ea\udc31\ud9dc\udc93\udb73\udf1c\udb62\udc95\ud815\udf4a\uda52\udcde\ud991\ude96\ud87e\udf8e\udb5e\udc8b\u3904\udaa2\udc2f\u34ca\udaaa\udc04\ud8f9\udd6a\ud35f\ud9c4\udfe3\ud9a7\udd81\ud964\udee1\udad6\udd48\udbcf\udc32\ud9ac\uddf0\ud8bb\udf08\ud950\udfdd\ud91e\udec0\udb01\udd2c\ud98d\uded3\ud99e\udfec\ud8b1\udfbf\ud9af\udcb5\udae0\udfa8\uda66\udde2\ud99a\udddd\ud9da\uddd8\uda01\uddfb", "\u4052\u429d\u05e3\ud2c5\u6278\u1e35\u27bb\u293b\ua0ba\u289f\u5071\u6b53\u8431\u72ff\u34be\u7ceb\u8615\u5beb\u79d0\u82cd\u0d20\u33cd", "\udbda\udc9f\uda2d\udfd9\uda34\udf12\ue754\ud8ae\udf5c\ud8e7\uddd4\ud95c\uddfb\ud958\udd3b\ud8a3\udd7d\udb7a\udc06\ud8cf\udf61\uda42\udc0d\uab76\uda54\udfa2\uda92\ude1e\ud8b6\uddac\uda81\ude02\ud8db\ude74\udb9b\udd7f\udb7a\ude6c\udab8\uddc2\ud8cf\ude29\ud917\udefe\u6df9\udbea\udda2\uda90\udc03\ud9bc\udfd9\ud8dc\udeab\udbd7\udd2a\ud955\udca3\udb79\udf31\ud9fd\udcee\ud867\udf52\uda02\udf38\ud920\udd1c\udbb4\udfec\ud8d2\udd65\udb09\uded6\ud991\udc89\uda91\udce6\uda2f\udfe6\ud913\udcfa\ud862\udeee\ud8ad\uded9\ud9c4\ude0d\ud9bb\udcbf\ud941\ude21\ud815\udc8b\ud9b3\udddf\ud988\udc70\uda40\udd2b\ud9a5\ude69\ud8f6\ude84\udb56\udef5\ud9b1\ude8b\udba8\ude30\ud831\ude43\udbe9\ude12\uea30\udbeb\udda4\udbfa\udd5c\udb33\ude98\ud83b\udded\udb45\udd63\ud872\uddd0\ud808\udfc6\udb85\udf8e",
        17, 8701, 213278072, -4022951672704153817L, -80275L, true, true, (char) 57098, (char) 55817,
        Double.longBitsToDouble(0x3fe5fdfd6dbd3368L), Double.longBitsToDouble(0x3fe70c764fcc9674L)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 15, "\ud816\udd6a\ud978\udd7a\udaad\ude9a\udbc2\ude73CG\udb0a\udec5\ud803\uddeb\udbef\udc74\uda24\udef8\ud970\udc6f", "\000\u17f9", "\ud9ae\uddb3\ud67e",
        31, 84649, -1979688732, -4877048983672811283L, -50277L, true, false, (char) 42139, (char) 43246,
        Double.longBitsToDouble(0x3fc968201f097bf0L), Double.longBitsToDouble(0x3fadaf7c73a278d0L)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 2, 7, "\ud8d9\udc67", "s", "\udb0a\ude4c",
        16, 26413, 1888792666, 76460007396221388L, -100000L, false, false, (char) 13866, (char) 25480,
        Double.longBitsToDouble(0x3fea0076de9e2cf6L), Double.longBitsToDouble(0x3fd125d25b951400L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\udb5e\udccf", "\u3a2f\u7965\u0380\u1c89\u0508Z\u485b\u5598w", "\ud90a\udc57",
        31, 33370, 58928, 3172174836653199006L, -100000L, false, false, (char) 40189, (char) 41973,
        Double.longBitsToDouble(0x3fbe79bb843c0a90L), Double.longBitsToDouble(0x3fefbaeadf68c1ddL)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\udb63\udfcf\udb41\udd74\udb66\ude27\u88b9\ud959\udd2e\ud9a9\udc23\ud904\udede\ud894\udd2ep\ud8a2\udcd0\u1c61", "\ua59b\u42f2\u9b93\ubbdf\u86fa\u1062\u9f62\u6628\u6b7a\000\000\ub38e\u2ecc\u55ec\u9a55\u1ae1\ud19d\u49ed\u8293\u75b0\u057a\u906c\u1150\u90f3\u3f1b\u3b41\u9b44\u2367\u86c7\uad88\u8de7\u4b41\u77aa\u64d9\ua0a3\uc804\ucc82\uc3ac\u35a7", "\ud986\udc89\ud903\ude5a\udb87\udf97\udac7\udcf9\ud9d9\udd77\uda7b\udd37",
        35, 44001, -1054869343, -3398562148824853214L, 66518L, false, true, (char) 36613, (char) 41908,
        Double.longBitsToDouble(0x3fddc1dd1e99f266L), Double.longBitsToDouble(0x3fd93fd9bc7ee968L)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\ud91f\udf14\udaf5\udf1b\ud992\udc2e\udb4f\ude2e\udb32\udf77\ud9a9\udc23\ud823\udf0e\udb83\uddb4\udb45\uded2\ud8a2\udcd0\u1c61\uda3a\udd7c\uea6f\ud8f3\udc2b\udb17\ude1d\ud8c3\udf9d\uda7b\udcb8\udae5\udf05\ud867\udecd\ud90b\udcd0\ud893\udfcf\ud9e0\udf26\000h\ud87b\udee5\udb7a\udf90\udb0e\ude28\udb84\udd01\ud995\ude07\uda6a\udc4d\ud860\ude1a\ud9d3\udfe8\udb9c\udffc\ud9f6\udfe3\ud8fc\udd2d\uda78\udeaa\udb3f\udf80\uda0c\udf35\uda2a\udfc0\ud992\udcdf\ud972\udc7b\ud8df\udf0e", "\u1c6b\uca59\u01f1\uca9c\u9282\ua4b7\u335f", "\udbc6\udd3f\ud86f\udca8\uda4c\ude64\ud858\ude00\uda79\udd76\ud95e\udcd4\ud98c\udf9b\ud9f1\udc35\uffaf\ud981\ude9a",
        26, 10391, -458297343, 6907431600650612004L, 31045L, true, false, (char) 5251, (char) 18582,
        Double.longBitsToDouble(0x3fd0bb38781695b0L), Double.longBitsToDouble(0x3fdbdb6d0d96f15eL)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 3, "\ud829\uddcc\ud890\udf46\ud8d9\uddc0\ud8d8\udfed\u88b9\ud959\udd2e\ud9a9\udc23", "w\u09c3", "\ud951\uddba",
        45, 58564, 1789724401, 5572201964892775984L, 58200L, false, false, (char) 46662, (char) 63687,
        Double.longBitsToDouble(0x3fd18fc104768084L), Double.longBitsToDouble(0x3fdadcb50747d8a4L)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\ud890\udf46", "\ucccd\u7994\u0380\u7a72\u8e28L\u78c2\u5598\u6233\u4cb0\u7030\u940b\ub55f\ubbd0\u86fa\uc9d8\uabaa\u6628", "\ud9d4\udce1\ud87b\udf20",
        39, 56931, -2125279111, 6727050212023333879L, -19835L, true, false, (char) 8171, (char) 12218,
        Double.longBitsToDouble(0x3fcd80bafcf590f4L), Double.longBitsToDouble(0x3fea6744d1e952fcL)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 12, "\ubea7\ud87c\udfee\uf2eb\ud981\udea7\ud845\ude81\ud9a1\udf8c\uda03\udf7c\ud853\udc46Y\000\udaf8\ude80", "\u40b0", "\udb72\ude61",
        37, 41927, 749047355, 1917420410308543691L, 1785L, true, false, (char) 4094, (char) 40067,
        Double.longBitsToDouble(0x3fed7db7cf43f8fdL), Double.longBitsToDouble(0x3fd076590d8cc454L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud816\udd6a\ud978\udd7a\udaad\ude9a\udbc2\ude73C\uc411\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\udbe6\uddf0", "\u7d43\u888e", "\ud9ae\uddb3",
        9, 66509, -886731106, -8502698360194384438L, -82926L, false, false, (char) 48505, (char) 35458,
        Double.longBitsToDouble(0x3f451dc000000000L), Double.longBitsToDouble(0x3fee12f7e00a5ef8L)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 0, "\ud816\udd6a", "sC\000x", "\ud98d\udefc\ud873\udedd\ud8b4\ude5e\ud8a5\udd29\000",
        22, -918, 1778384896, -7902568120188202158L, 64008L, true, false, (char) 26411, (char) 20669,
        Double.longBitsToDouble(0x3fe06fc2da000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud96a\udca0", "\u6338k\000\u67cf\u5c9f\u7cd8Z\000\000\ua568", "\000",
        -5, 79144, 191, -1135518434554176098L, 35734L, false, true, (char) 32688, (char) 711,
        Double.longBitsToDouble(0x3fdadcb50db130a4L), Double.longBitsToDouble(0x3fee16faef000000L)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 5, "\uda01\ude20\ud98b\udf7e\ud8bd\udce9\ud938\udd50", "\u7139\u6372\ua4cf\u04ac\ud420\u3123\u7240\u0090\u6ecb\u63aeR", "\ud9ec\udfd9",
        14, 44140, 1974038077, -2601600167910212384L, 62201L, true, true, (char) 42315, (char) 47617,
        Double.longBitsToDouble(0x3fefbb922a830893L), Double.longBitsToDouble(0x3fc39b2805900d24L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 2, 7, "\udb10\udc09\udb86\ude0a\udb0e\udfb3s\ud848\udc03\ud87e\udde9\udb0a\ude4c\udaec\ude21\udb9a\udf85\ud9b3\udefc\u2409\udb0f\uddcf\udb9a\udccd\udb21\ude83\035\000\ud881\ude3f\uda8d\udff7\ud86c\udf9f\ud943\udde6\ud8e1\udc1b\udb4b\ude1d\udaa1\udd52\ud869\uddf4", "\u3c6c\u1782\u826a\u4cd3\u731a\u2563\uc17b\u0709\u011d\u50d6\ud6e3\u00d1\u6230\u2e28\u4b7a\ub339\u90ad\u9059\u5ab5\uaaaa", "\ud9aa\uded9\u97ab\ud852\ude64\ud9ae\udc04\ud88b\udc19\udace\udfd4\udada\ude44",
        25, -486, -1082716972, -6149391928696136265L, -11496L, true, true, (char) 3706, (char) 64633,
        Double.longBitsToDouble(0x3fd2e56f07c7f67cL), Double.longBitsToDouble(0x3fe396850f32e79bL)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 9, "\ud859\udf46\udb5e\udccf", "\u3a2f\u7965\u0380\u1c89\u55eb\u6ae4\uc711\ud0a6K\000\u7030\u940b\ub55f\ubbd0\u0e31\u1062\u6eca\u3de5", "\000\udaf3\udee1",
        20, 56987, -2125270016, 6727050212023333879L, 93814L, true, false, (char) 23032, (char) 44543,
        Double.longBitsToDouble(0x3fe678c42dd73e83L), Double.longBitsToDouble(0x3fea2b621d16efeaL)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 12, "\ud8b7\udd6a\ud8eb\udfed\uf31e\ud981\udea7\ud845\ude81\ud9a1\udf8c\uda03\udf7c\ud853\udc46Ya\udaf8\ude80", "\ua938", "\udb72\ude61",
        37, 41927, 749047355, 1917420410308543691L, 1785L, true, false, (char) 1493, (char) 21418,
        Double.longBitsToDouble(0x3fee3b2ab8948d98L), Double.longBitsToDouble(0x3fd07650dd8cc454L)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud816\udd6a\ud978\udd7a", "C\uc411\u19c1\u5c9f\u0508\ua5c7\u6ce5\u73f2\u4942", "\000\ud881\ude3f\ud9ae\uddb3",
        9, 66509, -1105883490, -1620317519648270323L, -82926L, false, false, (char) 48505, (char) 35458,
        Double.longBitsToDouble(0x3f451dc000000000L), Double.longBitsToDouble(0x3fee12f7e00a5ef8L)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 2, 7, "\udb10\udc09\udb86\ude0a\udb0e\udfb3s\ud848\udc03\ud87e\udde9\udb0a\ude4c\udaec\ude21\udb9a\udf85\ud9b3\udefc\u2409\udb0f\uddcf\udb9a\udccd\udb21\ude83\035\000\ud881\ude3f\uda8d\udff7\ud86c\udf9f\ud943\udde6\ud8e1\udc1b\udb4b\ude1d\udaa1\udd52\ud869\uddf4", "\u3c6c\u1782\u826a\u4cd3\u731ac\uc17b\u0709\u011d\u50d6\ud6e3\u00d1\u6230\u2e28\u4b7a\ub339\u90ad\u9059\u5ab5\uaaaa", "\ud9aa\uded9\u97ab\ud852\ude64\ud9ae\udc04\ud88b\udc19\udace\udfd4\udada\ude44",
        25, -486, -1082716972, -6149391928696136265L, -11496L, true, true, (char) 3706, (char) 64633,
        Double.longBitsToDouble(0x3fd2e56f07c7f67cL), Double.longBitsToDouble(0x3fe396850f32e79bL)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 2, 7, "\udb10\udc09\udb86\ude0a\udb0e\udfb3s\ud848\udc03z\udaf5\ude39\udaec\ude21\udb9a\udf85\ud9b3\udefc\u2409\udb0f\uddcf\udb9a\udccd\udb21\ude83\035\000\ud881\ude3f\uda8d\udff7\ud86c\udf9f\ud943\udde6\ud8e1\udc1b\udb4b\ude1d\udaa1\udd52\ud869\uddf4", "\u3c6c\u1782\u826a\u4cd3\u731ac\uc17b\u0709\u011d\u50d6\ud6e3\u00d1\u6230\u2e28\u4b7a\ub339\u90ad\u9059\u5ab5\uaaaa", "\ud9aa\uded9\u97ab\ud852\ude64\ud9ae\udc04\ud88b\udc19\udace\udfd4\udada\ude44",
        25, -486, -1082716972, -6149391928696136265L, -11496L, true, true, (char) 3706, (char) 64633,
        Double.longBitsToDouble(0x3fd2e56f0600007cL), Double.longBitsToDouble(0x3fe396850f32e79bL)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 9, "\ud859\udefd\ud890\udf46\udb41\udd74\udb66\ude27\u88b9\ud959\udd2e\ud9a9\udc23\uc5d5\udb63\udcb6\ud98d\udefc\ud8a2\uddc9\u1c61\uda3a\uddcf\udb73\udfeb\ud6ba\ud90a\udc57\ud957\udd3a\uda7b\udcb8\udae5\udf05\ud867\udecd\ud99d\udc39\ud862\udd15\ud9e0\udf26\uda68\udc1c\ud9d4\udce1\ud87b\udf20\udb7a\udf90\udb0e\ude28\udb84\udd01\ud995\ude07\uda6a\udc4d\uda08\udd0d\ud9ea\udcb2\ud91b\udca4\uda75\udd64\ud847\udc3e\ud90c\uded4\udac2\udce5\u2030\udae2\udca7\ud9ba\uddb2\udb76\udc33\uda59\udd66\ud806\udff2\uda7b\udd29\udb0a\ude6a\udbef\udf03", "\u8b2b\u7cd9\u3e45\u066a\u6617\u48b9\ud311\u4065\u6fc0\u0bfe\u5d64\u23b1\u8b4c\ua952\u0af0\uab3e\u7ca0\ub8c3\u772e\u986b\u425d\u6f1e\u1ec4\u4f63\u7bd2\ube85\u9c1c\u134a\ua4f2\u37d2\u8d00\ud0e9\ua844\u3944\ubf1f\u4643\ub858\ua06e\ub169\uc40a", "\udb7e\udc51\ud967\ude5d\ud92a\udf88\ud999\udc96\ud9ae\ude5f\udb5c\udf30\u73ad\ud997\udd72\ud84f\udf48\udb97\udc15\uda46\udf4c",
        9, 80059, -994522385, -743823395176987644L, 43842L, false, false, (char) 25983, (char) 33629,
        Double.longBitsToDouble(0x3fe9c9ae4d85d5b1L), Double.longBitsToDouble(0x3fdcefa8b2b6a8eaL)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud94f\udf42\uda5b\udf80", "\ucccd\u7994\u0380\u7a72\u8e28u\u78c2\u5598\u6233\u4cb0\u7030\u940b\u2263\ubbd0\u86fa\uc9d8\uabaa\u6628", "\ud9d4\udce1\ud87b\udf20",
        39, 56931, -2125280391, 6727050212023333879L, 87334L, true, false, (char) 5690, (char) 12218,
        Double.longBitsToDouble(0x3fcd80bafcf590f4L), Double.longBitsToDouble(0x3fea674751e952fcL)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\udaa6\udfe5\udbaa\udecbt\000\000\ud966\ude7eT\000\ud9d1\udda8M\ud873\udedd", "\ubcc1\u65d0\ud0b0\uc86d\u4b38\ud328\u1682", "\udb49\udf07",
        27, 56329, 59, -1460794461L, -54607L, true, true, (char) 29531, (char) 39759,
        Double.longBitsToDouble(0x3fe32815b1db5751L), Double.longBitsToDouble(0x3fe5b3142f4865b4L)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 3, 15, "\udbf7\udff2U\ud823\udc8a\udb66\ude27\u88b9\udb7a\udc3e\uda76\uddbb\ud8d7\udc71\udb63\udcb6\ud98d\udefc\ud873\udedd\ud89b\udecc\udb93\udeb0\udafe\udfc2\uda23\ude2c\udaa4\ude45\ud86c\udf44\ud9e2\udf1cj\ud904\udee5\u5716\ud93b\ude37\u93b0\ud894\udee6\000", "\ucc06\u79f3\uca34\u417b\uca62\u3af3\ubfe8\uce69\u1c44\u6234\ud307j\u461c\u9d80\u0c67\ucb8a\u4860", "\ud82a\udd9e\udb48\udcdb\ud896\udf89\ud903\udcae\udabe\uded0\ud951\ude31\ud85f\udd07",
        33, 80424, -131116835, -2840735198081403572L, 1569L, false, false, (char) 47220, (char) 37474,
        Double.longBitsToDouble(0x3fe38fe66fd98c71L), Double.longBitsToDouble(0x3fe29bf183628d26L)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 2, 5, "\ud992\ude20", "O\000\ua995\u8bb5", "\ud9ad\uddfc",
        11, 46431, 1834509604, 2362552899936546986L, -100000L, false, false, (char) 27494, (char) 59620,
        Double.longBitsToDouble(0x3fcb3627e625e0b4L), Double.longBitsToDouble(0x3fdca8affad9b432L)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 11, "\ud902\udf20", "O\000\000\u67cf\u5c9f\u7cd8Z\000\uc0b8TX\u8426\ubd69\u280d\u4b0e\u00bf\u3ade\u85af", "\uda46\udf5c\udb23\udeb3\ud87b\udf20\udb7a\udf90\uda99\udceb\u9fc2\ud9c3\udf00",
        -5, 13216, -369205980, 1337322765452193923L, 90898L, true, false, (char) 61580, (char) 21327,
        Double.longBitsToDouble(0x3fe37f2e23f660e0L), Double.longBitsToDouble(0x3fd18f57fdf8328eL)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 1, "\ud81a\udd6a\ud992\udc7a\udaad\ude9a\udbc2\ude73CG", "\u6950\u7e38\u303b\u50af\ubd3c\ud715", "\ud881\ude3f\ud9ae\uddb3\u9f77\udaf0\udc6b\ud884\udfce\udac0\uddf9\udb94\uddcc\u90ed\udb2b\udfe6\ud87b\udf20\uda71\udedc\ud97f\ude81\uda6a\udfd4\udbf3\ude63\ud963\ude56\udaa2\udf6e",
        -3, 54326, -2040215177, 2653278387778905277L, 89317L, true, false, (char) 44652, (char) 58958,
        Double.longBitsToDouble(0x3fe9f4892b415848L), Double.longBitsToDouble(0x3fe0827dfedf1cacL)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud83b\udd8c\udb5e\udccf\udb41\udd74\udb66\ude27\u3a2f\ud959\udcff\ud9a9\udc23", "Z\u485b\u5598w\000", "\ud957\udd3a\uda7b\udcb8\uee30\ud867\udecd\udba5\udef9\u1f47\ud9e0\udf26",
        34, 62106, -883899904, -7470678291315291229L, -53031L, true, true, (char) 45381, (char) 5454,
        Double.longBitsToDouble(0x3fe8e2bb0c16610bL), Double.longBitsToDouble(0x3fd880390f34a65cL)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 3, "\ud829\uddcc\ud890\udf46\ud8d9\uddc0\ud8d8\udfed\udbf0\udfff\ud959\udd2e\ud9a9\udc23", "w\u0936\u5598\u6233\u4cb0\u7030\u940b\ub55f\u01f0\u6648\u128b\ua5c1\u6628\u6b7a\ubbad\ub141\u40ca\u4932\u67b3\ud523\u3607\u8b48\u5f81\u58d2\ubac2\ub91b\u0b48\u06a8\u2c4d\u0f0f\u9b6b\u6d19\u1d90\u10c5\ucac2\u5437\ua8e5\u8072\u89cd\u3a75\ua2aa\u0e91\u036a\u9a3f\u9bac\u2824\u8f7c\u95d0\ud487\ud461\u7abb\u6ac4\uccfe\u9653\ua9ac\u725b\uc33b\u0192", "\ud9ec\uddb9\udbcf\udcc6\ud80d\udfbc\u332d\ud930\udc2a\ud9ba\udf7e\udaf0\udfe2\uda1a\udda3\uda07\udda2\u73b3\ud8e9\udc4b\ud993\udd62\udbf5\ude91\ud9cc\udd9a",
        32, 89729, -148348689, 5211587084619068118L, 86303L, false, true, (char) 33857, (char) 37886,
        Double.longBitsToDouble(0x3fed3bda9522e771L), Double.longBitsToDouble(0x3fe78125b30db29cL)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 1, "\ud81a\udd6a\ud992\udc7a\udaad\ude9a\udbc2\ude73\ud83e\udeb0G", "\u6950\u7e38\u303b\u50af\ubd3c\ud715", "\ud881\ude3f\ud9ae\uddb3\u9f77\udaf0\udc6b\ud884\udfce\udac0\uddf9\udb94\uddcc\u90ed\udb2b\udfe6\ud87b\udf20\uda71\udedc\ud97f\ude81\uda6a\udfd4\udbf3\ude63\ud963\ude56\udaa2\udf6e",
        -3, 54326, -1771779721, 2653278387778905277L, 89317L, true, false, (char) 44652, (char) 58958,
        Double.longBitsToDouble(0x3fe9f4892b415848L), Double.longBitsToDouble(0x3fe0827dfedf1cacL)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 3, 11, "\ud83b\udd8c\udb5e\udccf\udb41\udd74\udb66\ude27\udb2a\udcfb\ud894\udd5b\ud9a9\udc23", "Z\u485b\u5598w\000", "\ud957\udd3a\uda7b\udcb8\uee30\ud867\udecd\udba5\udef9\u1f47\ud9e0\udf26",
        34, 62106, -883899904, -7470678291315291229L, -53031L, true, true, (char) 45381, (char) 5454,
        Double.longBitsToDouble(0x3fe8e2bb0c16610bL), Double.longBitsToDouble(0x3fd880390f34a65cL)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud83b\udd8c\udb5e\udccf\udb41\udd74\ud8f8\udc26\ud913\uddb9\uda2c\udd3d\udbfe\udd11", "\ub1db\u71b3\ubc4cV\000\u7030\u940b", "\uee30",
        59, 74944, -1284801284, 8641816493942454126L, 8577L, true, true, (char) 41973, (char) 46951,
        Double.longBitsToDouble(0x3fc2b02a47dd756cL), Double.longBitsToDouble(0x3fee9e0eedba82d7L)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 0, 6, "\uda0e\ude5d\ud920\udee5\udbdb\udd58\ud9fc\udd1e\ud882\ude79\udbf7\ude3c\udad3\ude8b\ud803\uddeb\ud87c\udee0\ud8dd\udcd4\ud85d\uddcb", "\u4bd4\ub5e9\u6e5a\ub76f\u64e8\uc9eb\u17c6\u6f86\u5685\u5e97\u8148\u8899\ub3c9\ub687\u429f\u2677\u6f7bCe\u067a\ucb0f\ub115\u4f04\u930b\uc213\u8b6d", "\uda1f\uddcb\udac7\udf42\udb45\udc3b\ud825\ude01",
        59, 87526, 946267596, -4501497354841823184L, 91238L, false, false, (char) 37229, (char) 5883,
        Double.longBitsToDouble(0x3fcda6207d5a32c4L), Double.longBitsToDouble(0x3fe1c6e554c7ab69L)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud902\udf20", "\u47d6\u29c3x\u67cf\u5c9f\u7cd8Z\000\000\ua568X\000\000\000\u4b0e\u00bf\u9152\ube32", "\uda46\udf5c\udb23\udeb3\ud87b\udf20\udb7a\udf90\uda99\udceb\u9fc2\ud9c3\udf00",
        -5, 13216, -369205980, 1337322765452193923L, 90898L, true, false, (char) 61580, (char) 21327,
        Double.longBitsToDouble(0x3fe37f2e23f660e0L), Double.longBitsToDouble(0x3fd18f57fdf8328eL)));
  }
  @Test(timeout = 4000)
  public void test177() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 7, 13, "\ud91c\udd74\udbb4\udeb0\udb35\udd6e\udb66\ude27\uda3b\udf4e\udafd\ude8f\ud988\udddd\udafa\udd5d\udb63\udcb6\ud98d\udefc\ud873\udedd\udb1d\udf5f\ud920\udd27\ud9f7\udd84\uda3a\udf2e\uda88\udeff\ud99d\udc86\u2b04\uda0e\udd69\ud801\udcf0\udb86\udc60\udbb9\ude43\u6adb\ud894\udee6\ud80a\udf9d\ud8b9\udfa3\udb6a\udfe3\ud993\udc51\ud8e5\udc33\udbac\udd48\udab2\udc78\ud852\udc99\ud9ea\udc31\ud9dc\udc93\udb73\udf1c\udb62\udc95\ud815\udf4a\uda52\udcde\ud991\ude96\ud87e\udf8e\udb5e\udc8b\u3904\udaa2\udc2f\u34ca\udaaa\udc04\ud8f9\udd6a\ud35f\ud9c4\udfe3\ud9a7\udd81\ud964\udee1\udad6\udd48\udbcf\udc32\ud9ac\uddf0\ud8bb\udf08\ud950\udfdd\ud91e\udec0\udb01\udd2c\ud98d\uded3\ud99e\udfec\ud8b1\udfbf\ud9af\udcb5\udae0\udfa8\uda66\udde2\ud99a\udddd\ud9da\uddd8\uda01\uddfb", "\u4052\u429d\u05e3\ud2c5\u6278\u1e35\u27bb\u293b\ua0ba\u289f\u5071\u6b53\u8431\u72ff\u34be\u7ceb\u8615\u5beb\u79d0\u82cd\u0d20\u33cd", "\udbda\udc9f\uda2d\udfd9\uda34\udf12\ue754\ud8ae\udf5c\ud8e7\uddd4\ud95c\uddfb\ud958\udd3b\ud8a3\udd7d\udb7a\udc06\ud8cf\udf61\ud920\udf9e\ud87e\udf78\uda54\udfa2\uda92\ude1e\ud8b6\uddac\uda81\ude02\ud8db\ude74\udb9b\udd7f\udb7a\ude6c\udab8\uddc2\ud8cf\ude29\ud917\udefe\udb7f\udfea\udbea\udda2\uda90\udc03\ud9bc\udfd9\ud8dc\udeab\udbd7\udd2a\ud955\udca3\udb79\udf31\ud9fd\udcee\ud982\udf0b\uda02\udf95\ud920\udd1c\udbb4\udfec\ud8d2\udd65\udb09\uded6\ud991\udc89\uda91\udce6\uda2f\udfe6\ud913\udcfa\ud862\udeee\ud8ad\uded9\ud9c4\ude0d\ud9bb\udcbf\ud941\ude21\ud815\udc8b\ud9b3\udddf\ud988\udc70\uda40\udd2b\ud9a5\ude69\ud8f6\ude84\udb56\udef5\ud9b1\ude8b\udba8\ude30\ud831\ude43\udbe9\ude12\uea30\udbeb\udda4\udbfa\udd5c\udb33\ude98\ud83b\udded\udb45\udd63\ud872\uddd0\ud808\udfc6\udb85\udf8e",
        17, 8701, 213278072, -4022951672704153817L, -80275L, true, true, (char) 57098, (char) 55817,
        Double.longBitsToDouble(0x3fe5fdfd6dbd3368L), Double.longBitsToDouble(0x3fe70c764fcc9674L)));
  }
  @Test(timeout = 4000)
  public void test178() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\ud91f\udf14\udaf5\udf1b\ud992\udc2e\udb9b\udced\udb6b\udcbc\ud9a9\udc23\ud823\udf0e\udb83\uddb4\udb45\uded2\ud8a2\udcd0\u1c61\uda3a\udd7c\uea6f\ud8f3\udc2b\udb17\ude1d\ud8c3\udf9d\uda7b\udcb8\udae5\udf05\ud867\udecd\ud80c\udf65\ud893\udfb9\ud80a\udd61\u00dfh\ud999\udd33\udb30\udd03\udb3e\udfc8\udb84\udd01\ud995\ude07\uda6a\udc4d\ud860\ude1a\ud9d3\udfe8\udb9c\udffc\ud9f6\udfe3\ud8fc\udd2d\uda78\udeaa\udb3f\udf80\udbf3\udf49\ud959\uddfa\ud814\udfd5\ud95a\udc3e\ud839\udf3b", "\u1c6b\ubf59\u2ae8\ucb23\u9282\u7cb6\u335f", "\udbc6\udd3f\ud86f\udca8\uda4c\ude64\ud858\ude00\uda79\udd76\ud95e\udcd4\ud8e8\udc87\udb9e\uddd6\uffaf\ud981\ude9a",
        26, 10391, -458297343, 6907431600650612004L, 31045L, true, false, (char) 5251, (char) 18582,
        Double.longBitsToDouble(0x3fd0bb387d3295b0L), Double.longBitsToDouble(0x3fdbdb68cd96f15eL)));
  }
  @Test(timeout = 4000)
  public void test179() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud816\udd6a\ud978\udd7a\udaad\ude9asC\uc411\udb0a\udec5\ud803\uddeb\udb63\udcb6\ud98d\udefc\udbe6\uddf0", "\u7d43\u888e", "\ud9ae\uddb3",
        9, 66509, -886731106, -8502698360194384438L, -82926L, false, false, (char) 48505, (char) 47163,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test180() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 5, "\uda01\ude20\ud98b\udf7e\ud969\ude1e\ud938\udcf3", "\u7139\u6372\ua4cf\u04ac\ud420\u3123\u7240q\u6ecb\u63aeR", "\ud9ec\udfd9",
        14, 44140, 1974038077, -2601600167910212384L, 62201L, true, true, (char) 35915, (char) 47617,
        Double.longBitsToDouble(0x3fefbb922a830893L), Double.longBitsToDouble(0x3fc39b2805900d24L)));
  }
  @Test(timeout = 4000)
  public void test181() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 1, "\u4803\ud992\udc7a\udad1\uddeb", "G\u19c1\ub36e\u6950\u7e38", "\ud838\udca3\ud8bc\udd93\ud912\udde2\ud8cc\udd7d\ud8fc\udfb8",
        28, 19262, 1241895951, 6749732869686188260L, -50277L, true, false, (char) 42139, (char) 43246,
        Double.longBitsToDouble(0x3fc968201f097bf0L), Double.longBitsToDouble(0x3fc48df4abba9e7cL)));
  }
  @Test(timeout = 4000)
  public void test182() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 2, 16, "\uda0e\ude5d\ud920\udee5\udbdb\udd58\ud9fc\udd1e\ud882\ude79\udbf7\ude3c\udad3\ude8b\ud803\uddeb\ud87c\udee0\ud8dd\udcd4\ud854\udfbf", "\u4bd4\ub5e9\u6e5a\ub76f\u64e8\uc9eb\u17c6\ubfe8\u5685\u5e97\u8148\u8899\ub3c9\ub687\u429f\u2677\u6f7bCe\u067a\ucb0f\ub115\u4f04\u930b\uc213\u8b6d", "\uda1f\uddcb\udac7\udf42\udbd9\ude07\udb70\udef2\ud9b8\udfa9\uda8a\udd8f\udba0\udd1e\uda01\udc52\ud890\ude9b\uda1a\udea3",
        35, 31098, 2026444026, 3412840577882546705L, -6579L, false, true, (char) 43746, (char) 52528,
        Double.longBitsToDouble(0x3fd45e40877fc42cL), Double.longBitsToDouble(0x3fe66b52d8e7017dL)));
  }
  @Test(timeout = 4000)
  public void test183() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud816\udd6a\ud864\ude50\ud854\ude6fs\000\u4100\udab2\udf3a\ufb03\udb63\udc58\ud98d\udefc\udb9e\udd5b", "\000", "\udad1\udd4e",
        22, 21018, 738579593, -8516704240344406020L, -100000L, true, false, (char) 711, (char) 40189,
        Double.longBitsToDouble(0x3fecdd729000a8eeL), Double.longBitsToDouble(0x3fc9800012cc18d4L)));
  }
  @Test(timeout = 4000)
  public void test184() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 3, 15, "\uda0e\ude5d\u00c1\ud823\udc8a\udb66\ude27\u88b9\udb7a\udc3e\u548c\ub636\udb63\udcb6\ud98d\udefc\ud873\udedd\ud89b\udecc\ud905\udc68\ud9cd\ude4f\uda4a\uddce\ud85b\udcff\udbcc\udc9c\udae8\udff0\u00bf\000\000\ud910\udcc6\u93b0\ud894\udee6\000", "\u1c06\u79f3\uca34\u417b\u9f20\u7016\ubfe8\uce69\u1c44\u6234\ud307jN\u9d80\u0c67\ucb8a\u340c", "\udafa\udc06\ud9c5\udd5c\ud839\udd13\ud9ba\udf81\ud972\udc9e\ud86e\udc6a\udaf3\ude28",
        20, 80424, 170873053, 1360971882427904175L, -76678L, false, true, (char) 61131, (char) 24846,
        Double.longBitsToDouble(0x3fe38fe66fd98c71L), Double.longBitsToDouble(0x3fea9bf183628d47L)));
  }
  @Test(timeout = 4000)
  public void test185() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 11, "\ud859\udf46\ud971\uddf3", "\u1e96\u84c8\u0380\u7a72\u8461\u4aeb\u77db\u3d1d\ud059\ua1f7\u04fc\u2d6f\ub486\u83f5\u26af\u5961\uab36\u6608", "\ud9d8\udce3\ud87b\udf20\ud864\udc84\ud874\udd3b\ud938\udd18\uda02\udd42\udb1f\udd8c\uda3d\udcb9\uda2b\udd25\ud91b\udca4\ud8f2\udc6a\udb4a\ude00\ud90c\uded4\ua5dc\ud999\udc56\ud85a\udebe\ud976\udee8\udadc\udcf2\ud967\udc75",
        23, 14162, -1213812802, 5075883877889256200L, -86615L, true, false, (char) 60654, (char) 31882,
        Double.longBitsToDouble(0x3fc0cdecd8596fe4L), Double.longBitsToDouble(0x3fe273da65597267L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.StringUtils|equals|java.lang.CharSequence,java.lang.CharSequence|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|isDoubleMetaphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|isDoubleMetaphoneEqual|java.lang.String,java.lang.String,boolean|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.binary.CharSequenceUtils|regionMatches|java.lang.CharSequence,boolean,int,java.lang.CharSequence,int,int|static",
    "C|org.apache.commons.codec.binary.CharSequenceUtils|<init>|",
    "M|org.apache.commons.codec.binary.StringUtils|getBytes|java.lang.String,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesIso8859_1|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUnchecked|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUsAscii|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Be|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Le|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf8|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|newIllegalStateException|java.lang.String,java.io.UnsupportedEncodingException|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|equals|java.lang.CharSequence,java.lang.CharSequence|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|isDoubleMetaphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|isDoubleMetaphoneEqual|java.lang.String,java.lang.String,boolean|new:org.apache.commons.codec.language.DoubleMetaphone:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
