package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class CharSequenceUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u2f7f\u5e5f\u50d8\ub9fc\u5bf8\u745a\uaeb4\u1749", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f",
        45, 24248, -1360476955, -4620626921282939455L, -79573L, true, false, (char) 63738, (char) 54832,
        Double.longBitsToDouble(0x3fe740c421a6a5e0L), Double.longBitsToDouble(0x3fe8992ac34a0600L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u2f7f\u5e5f\u50d8\ub9fc\u5bf8\u745a\uaeb4\u1749", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f",
        45, 24248, -1360476955, -4620626921282939455L, -79573L, true, false, (char) 63738, (char) 54832,
        Double.longBitsToDouble(0x3fe740c421a6a5e0L), Double.longBitsToDouble(0x3fc9c4ab0d281800L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\ud439\u7b8c\ubde2", "\udba7\ude86\udae0\udea9\uda3e\udccb\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\udb3c\udc89\ud942\udd4d\ud9fa\udfa0\ud9df\ude4e\udb63\udef9\udbc4\uded4\udaad\udfe9",
        47, 35778, -1681243535, -5893566265609081128L, 87373L, false, false, (char) 48425, (char) 53934,
        Double.longBitsToDouble(0x3fccb23cd132bba0L), Double.longBitsToDouble(0x3fdc1bfe0775aaa4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc77\udb3e\udd81\ud9a2\udcf8", "\u23d3\u7b8c\ubde2\u2048\ud2b5\u3833\u0a04\u753d\u09a7\u94ea\u5bf8\u745a\uaeb4\u1749", "\ud8fb\udcf0\uda71\uddca\ud8f8\uddc4\ud832\udc88\udb89\udc2c\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f\udb6c\udc66\udbe5\ude1a\uda62\udc1d\uda40\udc84\ud86e\udf3d\uda95\udeae\udb58\udd4d",
        54, 9358, 411345511, -6494099505586023854L, 29866L, false, false, (char) 11812, (char) 19767,
        Double.longBitsToDouble(0x3fd3f52ea19751d6L), Double.longBitsToDouble(0x3fe822f1bc3b1de9L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3301\u7896\000\u81c6\ud2b5\u5adb\u00df\u5e5f\u00c9\000\u5bf8\u745a\uae32\u1749", "\ud8fb\udcf0\udb51\udca7\u00c1\000\ud895\udd18\ud812\udfe3\ud923\ude43",
        18, -981, 973078528, -2875967548436347752L, 5359L, false, true, (char) 38923, (char) 63738,
        Double.longBitsToDouble(0x3fe3399e52e81884L), Double.longBitsToDouble(0x3fda6a5e0e264ab0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc77\udb3e\udd81\ud8f3\ude41", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u2f7f\u1145\u50d8\ub9fc\u5bf8\u745a\uaeb4\u1749\u153d\ud284\u9790", "\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\ud9ee\udd13\udab3\udd88\ud8df\ude1f\udb6c\udc66\udbe5\ude1a\uda62\udc1d\uda40\udc84\ud86e\udf3d\uda95\udeae\udb58\udd4d\uda8b\udc4a\ud940\udfdb\udb8c\udfd8\ud935\udd98\ud99a\udfd9\uda0b\udf6d\ubb82\uda20\udcca\uea07\u5793\ud8e9\udcfb",
        58, 46132, -442445188, -6436229530932848933L, -51896L, true, true, (char) 45533, (char) 47395,
        Double.longBitsToDouble(0x3febce7342e70a2eL), Double.longBitsToDouble(0x3fec7952cc15b5fbL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb86\udd6a\udb3e\ude00", "\ua6b8\ub1bc\u705d\u3e72\u2048\ud2b5\u5ade\u2f7f\u5e5f\u50d8\u3881\u069a\u745a\uaeb4\u1749\uca9c\ud25f\u9790\u7cf2\ua902\uc35d\u54b6\ucfc4\uacb0\u8781\u388a\u9e6d\u9863\u521a", "\udacd\ude1f\u0270\udb58\udd4d\uda8b\udc4a\ud924\udf4a\udb7e\ude0f\ud935\udd98\ud99a\udfd9\ud859\udcf4\ud996\udddf\ud98e\udede\ud94c\udfcb\udadc\udfc0",
        21, 8107, 176510105, 2768252957735094905L, -42644L, false, false, (char) 7016, (char) 45849,
        Double.longBitsToDouble(0x3fbe39cf27343aa0L), Double.longBitsToDouble(0x3fe554f03503407cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc77\udb3e\udd81\ud9e3\udd18", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u2f7f\u5e5f\u50d8\ub9fc\u5bf8\u745a\uaeb4\u1749\u153d\ud284\u9790", "\ud999\udcdf\ud883\udc74\udb98\udde5\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f\udb6c\udc66\udbe5\ude1a\uda62\udc1d\uda40\udc84\ud86e\udf3d\uda95\udeae\udb58\udd4d\uda8b\udc4a\ud940\udfdb\udb8c\udfd8\ud935\udd98\ud99a\udfd9\uda0b\udf6d\udb1d\udc59\ud81b\udee8\ud860\udce5\udbfe\ude7d\udae0\udda0",
        39, 74046, -1425952444, 1696436896894797266L, -41036L, false, true, (char) 43833, (char) 48564,
        Double.longBitsToDouble(0x3feccb16d06f39d5L), Double.longBitsToDouble(0x3fe4269ac7cd6583L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 11, 6, "\udb25\udf67\ud973\udee7\udad3\udf75\udbdc\udd3d\udbfe\udeb5\ud809\udece\udb84\uddf7\ud9a2\udcfe\uda5f\uddc0\ubd1a\udaad\ude84\udaba\udf90\udad9\uded9\udb7f\udee8\ud9eb\ude50\ud9d5\udd37\udb77\udffe\ud85c\udc53\ud9fa\udfbe\ud9df\ude4e\udb63\udef9\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\udbf4\udfc4\uda98\udebb", "\u67e9", "\uda92\uddf0\uda01\udfc4\ud86b\udc51\ud8cf\udd8c\ud95a\udead\ud960\udd1d\ud95d\udefd\ud9a6\udcaa\ud935\udd98\ud837\udca8",
        36, 27801, 902045228, 8016564666240942815L, -3889L, false, false, (char) 13032, (char) 49441,
        Double.longBitsToDouble(0x3f7b070288f2f700L), Double.longBitsToDouble(0x3fe06c5893ba8172L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 5, 10, "\udb87\udc77", "\u7e6c\ua6b8\u3334\u7b8c\ubde2\u2048\ud2b5", "\ud97c\ude6a\udb86\udcde\udacb\udfc8\ud820\udc06\udb25\udf5d",
        38, 89243, 579939397, -4891592019920937898L, 29986L, false, true, (char) 17898, (char) 31667,
        Double.longBitsToDouble(0x3fe609d34c98d816L), Double.longBitsToDouble(0x3fcca65cd132bba0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 3, 11, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u491d\u2241\u3ffb\u4a25\uc0f2\u2f2a\u8ef7\u50d8\ub9fc", "\ud942\udd4d\ud9fa\udfa0\ud9df\ude4e\udb63\udef9\ud8fb\udcf0",
        25, 80375, -1532849493, -7220796897417111371L, -91993L, true, false, (char) 31667, (char) 48425,
        Double.longBitsToDouble(0x3fc31b02d3964798L), Double.longBitsToDouble(0x3fb32bba2e093f00L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\uda27\uddc8\udb3e\uddfb\ud850\udf50", "\u3334", "\udbab\udfaf\u19ae\udaad\ude84",
        59, 75831, -1089141780, -1726824365221517579L, -11554L, true, false, (char) 46205, (char) 46474,
        Double.longBitsToDouble(0x3fb5af0751e413d0L), Double.longBitsToDouble(0x3fe60a7d9fb22707L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 1, 16, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc56\udb12\udc19\ud851\udcc3", "\u2048", "\udaba\udf90\ud8a6\udd22",
        30, 39155, -1854183691, -3850538441785039230L, 85275L, false, false, (char) 55411, (char) 25782,
        Double.longBitsToDouble(0x3fe60a7d9fb22707L), Double.longBitsToDouble(0x3febdd24c8b59bcaL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\uda81\udf6c\udb3e\udd06\ud850\udf50", "\u3334\u7b8c", "\ubd1a",
        27, 73567, -751053400, -4677755908765706652L, -72175L, true, false, (char) 46474, (char) 38426,
        Double.longBitsToDouble(0x3fe33f0e0462089dL), Double.longBitsToDouble(0x3fc648570dee9264L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 7, 13, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc92\udb12\udc19\ud90a\udf60", "\u2048\u1815\u0fed", "\uda6a\uddf5\ud9b3\udcfa\uda92\udc71",
        6, 41594, -303010639, 2490820742638047994L, -16253L, true, false, (char) 40633, (char) 14356,
        Double.longBitsToDouble(0x3fc6b3795b62b8d4L), Double.longBitsToDouble(0x3fc73ec4b04e83fcL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 13, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\ud2b5\u0d3c\u2ed9\u5e5f\u50d8\ub9fc\u5bf8\u745a\uaeb4\u1749", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f",
        45, 24248, -1360476955, -4620626921282939455L, -79573L, true, false, (char) 63738, (char) 54832,
        Double.longBitsToDouble(0x3fe740c421a6a5e0L), Double.longBitsToDouble(0x3fe8992ac34a0600L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 3, 13, 16, "\ud98d\udd38\udb1d\udd7f\ud850\udf50\uda5a\udc95\ud833\udfe0\ud90a\udf64\udb84\ude21\ud9a2\udcfe\uda5f\uddc0\ubd1a\udaad\ude84\ud879\uded0\udb28\udf88\uc898\ud9c2\udda6\uda34\udcb3\uda16\uddb7\ud942\udd4d\udae2\udf93\ud99e\udea0\udaaa\udfec\uda28\uddfa", "\u8a43\u6adf\u021f\ucb29\u8820\u388a\u67e9\u34a1\u526a", "\ud86e\udf2d\udb95\udd4f\udb58\udd4d\ud917\udf47\ud983\udd9c\ud935\udebf\ud9fc\ude16\ud835\udd62\udb15\udc31\ud8c2\ude9e\ud996\udd85\u7ab0\uda23\udd6e",
        0, 65422, 2130443345, 8648354874940579525L, -33727L, false, true, (char) 35669, (char) 26793,
        Double.longBitsToDouble(0x3fd2152170c9c52eL), Double.longBitsToDouble(0x3fbd69484a308e90L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[B:[[-37, -121, -36, 119, -37, 62, -35, -127, -40, 80, -33, 80]]\012",
        Z.run(T, 1, 10, 7, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u2f7f\u5e5f\u50d8\ub9fc\ua84f\u73fd\uaeb4\u1749", "\uda60\ude50\ud98f\udee0\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f",
        45, 24248, -1360476955, -4620626921282939455L, -79573L, true, false, (char) 22779, (char) 54832,
        Double.longBitsToDouble(0x3fe740c4211d60e0L), Double.longBitsToDouble(0x3fe8992ac34a0600L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc77", "\u7e6c\ua6b8\u3334\u7b8c\ubde2\u2048\ud2b5", "\uda3e\udccb\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\udb3c\udc89\ud942\udd4d\ud9fa\udfa0\ud9df\ude4e\udb63\udef9",
        40, 48924, 654791361, -6586101375345978501L, 84616L, true, false, (char) 50450, (char) 31667,
        Double.longBitsToDouble(0x3eba400000000000L), Double.longBitsToDouble(0x3fccb23cd132bba0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63]]\012",
        Z.run(T, 1, 6, 13, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u428a\u5e5f\u678f\ub9fc\u8e0b\ub4eb\u3f1e\u1749", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f",
        45, 1581, -1360476955, -4620626921282939455L, -79573L, true, false, (char) 63738, (char) 54832,
        Double.longBitsToDouble(0x3fe740c421a6a5e0L), Double.longBitsToDouble(0x3fe8992ac34a0600L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 7, 9, 2, "\uda7a\udd9e", "\u7e6c\ua6b8\u0686\u7b8c\ubde2\u597d\uc3f3", "\uda3e\udccb",
        -4, 22372, -1854183691, -3850538441785039230L, 85275L, false, false, (char) 55411, (char) 25782,
        Double.longBitsToDouble(0x3fe60a7d9fb22707L), Double.longBitsToDouble(0x3febdd24c8b59bcaL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 8, 13, 6, "\ud850\udd48", "\u00df\ua668\u3334\u7b8c\ubde2\u2048\ud2b5", "\uda3e\udccb\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\udb3c\udc89\ud942\udd4d\ud9fa\udfa0\ud9df\ude4e\udb63\udef9",
        40, 48924, 654791361, -6586101375345978501L, 84616L, true, false, (char) 50450, (char) 31667,
        Double.longBitsToDouble(0x3fe609d34c98d816L), Double.longBitsToDouble(0x3fccb23cd132bba0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[B:[[-13, -79, -79, -73, -13, -97, -90, -127, -16, -92, -115, -112]]\012",
        Z.run(T, 1, 12, 8, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u2f7f\u2229\u503b\ub9fc\u5bf8\u745a\uaeb4\u1749", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\uda26\ude20\uda1f\udc2f\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ua665\udb7c\udf16\udbe5\ude1a\uda0c\udc12\uda40\udc84\ud860\udc3e\uda95\udeae\udb58\udd4d\uda8b\udc4a\ud940\udfdb\udb8c\udfd8",
        12, 71782, 100685587, -995300699327916769L, -26059L, true, true, (char) 56702, (char) 37091,
        Double.longBitsToDouble(0x3fad5855b80e9040L), Double.longBitsToDouble(0x3fe1fd143128810bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=[B:[[-2, -1, -37, 8, -36, 55, -37, 62, -35, -127, -40, 80, -33, 80]]\012",
        Z.run(T, 2, 1, 9, 6, "\udb08\udc37\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u4fb0\u7893\u854b\uaa24\u2a92\u72db\u6e6d\u5bf8\u745a\uaeb4\u1749", "\udbd1\udeeb\udb18\uddeb\udb2f\udd0d\ud818\ude4f\ud895\udd93",
        13, 664, -1593843527, -7996945898323449170L, -2872L, true, false, (char) 3469, (char) 38305,
        Double.longBitsToDouble(0x3fbc7554be593030L), Double.longBitsToDouble(0x3fe13c8f20ce682dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 10, "\ud83c\udf71\udb3e\udd0f\uda90\udc3d", "\u33be\u03f0\u138c\uc43a\u5fd7\u2410\u2f30\ub31d\u5061\uc12c\uc307\u73fc\u2845", "\udb63\ude0f\udaaf\udcea\ud94b\udd84\uda24\udf05\udb96\udfe1\ud895\udd5e\ud812\udfe3",
        24, 36473, -1861934061, -7013355946985554981L, -23649L, true, false, (char) 49192, (char) 36100,
        Double.longBitsToDouble(0x3fec4f46306733caL), Double.longBitsToDouble(0x3fde818849cbd436L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ud9f6\udff9\ud99a\udc0d\ud862\uddc3: null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 6, "\ud9f6\udff9\ud99a\udc0d\ud862\uddc3", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u2f7f\u5e5f\u50d8\ub9fc\u5bf8\u745a\uaeb4\u1749", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\ud817\ude7a\ud8df\ude1f\udb6c\udc66\udbe5\ude1a\uda62\udc1d\uda40\udc84\ud86e\udf3d\uda95\udeae\udb58\udd4d\uda8b\udc4a\ud940\udfdb\udb8c\udfd8\ud935\udd98\ud99a\udfd9\uda0b\udf6d\udadf\ude39",
        40, 41452, 1940243779, -6325561234421492934L, 65899L, true, false, (char) 16671, (char) 7397,
        Double.longBitsToDouble(0x3fb1f6314e59ed70L), Double.longBitsToDouble(0x3fde3eca80daebc0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.CharSequenceUtils:@?\012",
        Z.run(T, 1, 4, 13, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u59a7\u05a2\u2048\ud2b5\u5ade\u368c\u5e5f\u50d8\ub9fc\u5bf8\u745a\uaeb4\u1749", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f",
        31, 24248, -1360476955, -4620626921282939455L, -79573L, true, false, (char) 63738, (char) 54832,
        Double.longBitsToDouble(0x3fe740c421a6a5e0L), Double.longBitsToDouble(0x3fe8992ac34a0600L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc4a\udb3e\udd81\u4e00", "", "\000\uda23\udf30\uda90\ude49\udaad\ude84\udaba\udf90\uda3e\udccb\uda6a\uddf5\ud9b3\udcfa\000\000\000\000\000",
        -5, -1000, 1337131008, 2812307481208387506L, -100000L, false, false, (char) 55006, (char) 50431,
        Double.longBitsToDouble(0x3fe574882ac13a69L), Double.longBitsToDouble(0x3fc31b02d3964798L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "\ud978\udfd0\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\u3be6\u0731\u2f7f\u5e5f\u50d8\u6f4b\u86fe\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u6e54\u1944\u00af\uc84b\u5b2c\u3982\ua54a\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda51\ude43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud9ea\udfe9\udba1\uddc7\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\udb36\udf0c\ud8cd\ude1e\uda28\udee8\ud8cd\udd28\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\uddf5\ud937\udc4d\udaa2\udcb1\udaab\udf64\ud941\ude71",
        44, 86487, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3fd137ac042f9ed2L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.IllegalStateException:java.lang.IllegalStateException: \udb87\udc77\udb3e\udd81\ud850\udf50: null\012",
        Z.run(T, 2, 16, 13, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\ud625\u7b8c\u2140\u13cb\ud2b5\u5ade\u987f\u5e5f\u50d8\ub9fc\u5bf8\u745a\uaeb4\u1749", "\udac3\udec2\ud937\udcb4\udb23\udff2\ud818\ude4f\ud999\udedf\u8e2a\uda08\udef6\uda23\udf46\udab3\udd88",
        -4, 4185, -1847163752, 8869493005209086818L, -15134L, true, true, (char) 48266, (char) 3063,
        Double.longBitsToDouble(0x3fe3399e52e81884L), Double.longBitsToDouble(0x3fda6a5e0e264ab0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 15, 7, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u9b3d\u512f\u4b2b\u39e3\u5e5f\u2ff7\u7615\uc008\u3bca\uaeb4\u1749", "\ud9ed\udcfb\ud99f\udf41\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f",
        45, 24248, -1360476955, -4620626921282939455L, -63004L, true, false, (char) 47867, (char) 54635,
        Double.longBitsToDouble(0x3fe740c421a6a5e0L), Double.longBitsToDouble(0x3fe8992ac34a0600L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 15, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\ud2b5\uab08\u2f7f\u5e5f\u50d8\ub9fc\u3a7d\uc4f0\ua51e\u1e99", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud9cf\ude9d\udb04\udf1f\udab3\udd88\ud8df\ude1f",
        45, 24248, -1360476955, -4620626921282939455L, 68142L, true, false, (char) 27500, (char) 28550,
        Double.longBitsToDouble(0x3fe8992e734a0600L), Double.longBitsToDouble(0x3fd3221d92ab33caL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 15, 8, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc92\udb04\udf53\ud909\udd71\udb84\ude21\ud9a2\udcfe\uda5f\uddc0\ud8c7\udfa4\u1a40\udaba\udf90\uda3e\udccb\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\udb3c\udc89\uda43\ude52\udae1\udd7b\ud9d9\udead\udb63\udef9\ud8fb\udcf0\udae8\udd34\uda70\udf0b\ud818\ude4f", "\u7bb6\u8820\u20aa\u6fc3\u6133\u0e27\u04c9\uc04b\u6ab2\u3982\u2e7b\u67aa\u1e30\u1776\u4017\u25e1\ube2f\u00e3\uc18c\u46f4\ub69e\u4ac4\u8966\ucb2a\ud3e0\uca85\u25c0\u2449\u9687", "\ud884\udeeb\ud848\uddea",
        0, 54316, 1280849726, -8859253097061799613L, -3080L, true, true, (char) 3474, (char) 28885,
        Double.longBitsToDouble(0x3f8d5ef5d28aa640L), Double.longBitsToDouble(0x3f8a877e581d03c0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[-121, -37, 119, -36, 34, -37, 115, -35, 80, -40, 80, -33]]\012",
        Z.run(T, 1, 11, 16, 16, "\udb87\udc77\udb22\udd73\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u2f7f\u21ba\u79ff\ub99a\u5bf8\u745a\uaeb4\ua697", "\ud8fb\udcf0\ud99f\udeee\uda6f\udece\udb64\udc56\udb8d\udcda\ud88c\udd51\udb29\udfc7\udb09\ude9f",
        34, 15886, -669613375, -7933507906557131547L, 48974L, true, false, (char) 30161, (char) 6798,
        Double.longBitsToDouble(0x3fc9cd05a99ccf28L), Double.longBitsToDouble(0x3fde8188434d4ba6L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63]]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 7, 6, "\udb59\udc77\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ube42\u2048\ud2b5\u5ade\u2f7f\u5e5f\u50d8\ub9fc\u5bf8\u745a\uaeb4\u1749", "\ud9c3\ude5f\ud839\udf0b\udb2f\udd44\ud8df\udcb2\ud895\udd93\udac9\udc7d\ud923\ude3c\udb04\udf1f\uda01\udd8f\ud8df\ude1f\ud83a\udf6d\udbe5\ude1a\uda62\udc1d\uda40\udc84\ud86e\udf3d",
        37, 81659, 1747781159, 3731852201497502311L, 29866L, false, false, (char) 36835, (char) 677,
        Double.longBitsToDouble(0x3fcd2ca10e5a4fd8L), Double.longBitsToDouble(0x3fd69b8f566c50ceL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 9, 2, "\ud8a8\udff5\udb07\udded\ud850\udf50\uda5a\udc92\udb12\udc19\ud90a\udf60\udb84\ude21\ud9a2\udcfe\uda5f\uddc0\ubd1a\udaad\ude84\udaba\udf90\uda3e\udccb\ud926\udd12\ud9b3\udcfa\uda92\udc71\ud806\udebc\ud942\udd4d\ud9fa\udfa0\ud9df\ude4e\udb63\udef9\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\ud952\udcb7\udaf2\uddc7\udb6c\udc66\udbe5\ude1a\uda62\udc1d", "\u394f\ua54a\u419f\u24cc\ud7dd\u4017\u6de9\u1f5f\u202e\u8e3a\ua380\u7446\u98eb\u9391\u3ed8\u3db8\u2d5b\u7d15\u19d0\u231a\u3bab\u4c6c\u29c3\ua060\u36fb\u5f44\uce9d\u274d\u39d3\u2119\u022e\u10ef\u4e66", "\ud9ca\ude4b\udbae\udfb4\ud83f\udcb4\ud8f0\udfc7\udb33\udde6\ud93d\ude4a\ud8e6\udee4\u0693\uda43\udd29\ud967\ude8e\ud95d\udc4d\ud927\uddf3\ud829\udd54\ud9ca\udfba\ud8e6\udf7e\uda7f\uddaf\ud885\ude1d\ud989\ude4d\udbfe\uddf2\ud9d4\uddfc\udb15\udfbe\ud94a\udcb3\ud903\uddfb\uda82\ude01\uda65\udf2a\ud891\udfb1\udab8\udf0b\u42c5\udb6d\udeb2\uda7a\udddc\uda39\udf10",
        30, 43775, 389104316, -2238283209589041952L, 72384L, false, false, (char) 51121, (char) 62854,
        Double.longBitsToDouble(0x3fd785a2e9da622cL), Double.longBitsToDouble(0x3fce6221ed5ff650L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "-\000\000", "\ud439\u7896.", "",
        14, 87600, 0, -4677756772054133148L, -72175L, true, false, (char) 46474, (char) 55411,
        Double.longBitsToDouble(0x3fe49733d222d2e7L), Double.longBitsToDouble(0x3fed91383871a499L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 16, "\000", "\000", "",
        -5, 66072, 2061792768, -6294921497441958653L, -39328L, false, true, (char) 54649, (char) 59646,
        Double.longBitsToDouble(0x3e4a0b2800000000L), Double.longBitsToDouble(0x3fc625ed400003c0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 13, 6, "\udb87\udc77\udaad\uddda\ud90f\udc65\udb19\uded1\udb35\udf98", "\ubde2\u2028\ud2b5\uc7a2\uc695\u8f42\u50bc\ub9fc", "\ud942\udd4d\ud9fa\udfa0\ud9df\ude4e\udb63\udef9\udbc4\uded4",
        6, 49154, -1533446222, -7220886000808634187L, -91993L, true, false, (char) 31667, (char) 48425,
        Double.longBitsToDouble(0x3fe4c508b4e591e6L), Double.longBitsToDouble(0x3fb32bba2e4dc358L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 16, 2, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u8d74\u7b8c\ubde2\u1029\u105d\u4a98", "\uda6a\uddf5\uda62\udc52\uda92\udc71",
        6, 41594, -303010639, 2490820742638047994L, -98610L, false, false, (char) 40633, (char) 59146,
        Double.longBitsToDouble(0x3fc6b3795b62b8d4L), Double.longBitsToDouble(0x3fc73ec4b04e83fcL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63]]\0121=[B:[[-13, -79, -120, -108, -13, -97, -90, -127, -16, -92, -115, -112]]\012",
        Z.run(T, 2, 6, 12, 4, "\udb84\ude14\udb3e\udd81\ud850\udf50", "\ucb01\u7b8c\ubde2", "\udba7\ude86\udae0\udea9\uda3e\udccb\ud9a2\udfd0\udb3a\udd25\udb7a\udc4e\udb3c\udc89\ud942\udd4d\ud9fa\udfa0\ud9df\ude4e\udb63\udef9\udbc4\uded4\udaad\udfe9",
        47, 35778, -1681243535, -3731838444471243048L, 70439L, false, false, (char) 48425, (char) 53934,
        Double.longBitsToDouble(0x3fccb23cdd1abfa0L), Double.longBitsToDouble(0x3fb560f69dd6aa90L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 4, "\udb87\udd0c", "\u4b6d\u226c\ub8f5\u7b8c\ubde2\u43a0\uc597\u4a98\uc698", "\udb51\udfca\uda92\udc6f\udb3c\udc89\ud942\udd4d\ud9fa\udfa0\ud9df\ude4e\udb63\udef9\udbc4\uded4\uda00\udde9\ud9db\udfd3\ud82f\udc32\ud881\udc4f\ud812\udfe3\ud923\ude43\udb04\udf1f\ud9ed\udde5",
        43, 15625, -1847133544, -5840952227929363636L, 51603L, false, false, (char) 31179, (char) 19221,
        Double.longBitsToDouble(0x3fd6f66df417387cL), Double.longBitsToDouble(0x3fdfaca775ecce64L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 1, 6, "\ube6f\udb3b\udeee\ud850\udf50", "\ud439\ud458\ubdba", "\udba7\ude86\udae0\udea9\uda3e\udccb\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\ud980\uddca\ud9f7\udc3e\uda1d\uddec\ud9df\ude4e\udb63\udef9\udbc4\uded4\udaad\udfe9",
        47, 23269, 188239535, -5893566673630974248L, 87373L, false, false, (char) 48425, (char) 60492,
        Double.longBitsToDouble(0x3fccb23a9132bba0L), Double.longBitsToDouble(0x3fdc1bfe0775aaa4L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -37, -121, -36, 119, -37, 62, -35, -127, -40, 80, -33, 80, -38, 90, -36, -110, 0, 80, -39, 10, -33, 45, -37, 93, -33, -115, 0, 0, -38, 65, -33, 63, -67, 26, -38, -83, -34, -127, 0, -33, -38, 62, -36, -53, 0, -55, 0, 0, -38, -110, -36, 113, -37, 60, -36, -119, -39, 66, -36, -53, -39, -6, -3...\012",
        Z.run(T, 1, 9, 10, 8, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc92P\ud90a\udf2d\udb5d\udf8d\000\uda41\udf3f\ubd1a\udaad\ude81\u00df\uda3e\udccb\u00c9\000\uda92\udc71\udb3c\udc89\ud942\udccb\ud9fa\udfa0\udbc2\ude00\udb3f\udcf9\ud8fb\udcf0\udb51\udca7\u00c1\000\ud895\udd18\ud812\udfe3", "\023\uccbd\u2373\u521a\u04c9\uc84b\u5b2c\u7c78", "\ud940\udfdb\udb8c\udfd8\ud935\udd98\ud99a\udfd9\udadd\udf76\udaaa\udec1\udb33\udfc9",
        44, 38041, 2048360578, 4922469550401178732L, 35782L, true, true, (char) 45538, (char) 21692,
        Double.longBitsToDouble(0x3fdc8da3e1723beaL), Double.longBitsToDouble(0x3fefc3e9beca36c0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 9, 6, "\udb87\udc77\udb3e\udd81\ud850\udf50", "\u3301\u7896\000\u81c6\ud2b5\u5adb\u00df\u5e5f\u00c9\000\u5bf8\u745a\uae32\u1749", "\ud8fb\udcf0\udb31\udc58\uda8d\udcea\ud9a4\udd37\ud895\udd18\ud812\udfe3\ud923\ude43",
        18, 36019, 973078528, -8227204801605761896L, 5359L, false, true, (char) 38923, (char) 13852,
        Double.longBitsToDouble(0x3fe3399e52e81884L), Double.longBitsToDouble(0x3fc64dfc1c4c9560L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 6, "\ud8a6\udce3\udb3e\udd4f\ud850\udf50\uda5a\udc92P\ud90a\udf2d\ud8bf\udcdb\ud9ce\udd59\uda41\udf3f\ubd1a\udaad\ude81", "/", "\udb3c\udc89",
        34, 43329, 381456503, -4891621062489793450L, -99807L, false, false, (char) 37631, (char) 29823,
        Double.longBitsToDouble(0x3fb5eb8d45cfb138L), Double.longBitsToDouble(0x3f93a0ff00168000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 0, 0, "\udb58\udc24\udb3e\udd81\ud850\udf50\uda5a\udc92P\ud90a\udf2d\udb5d\udf8d\000\uda41\udf3f\ubd1a\udaad\ude81\u00df", "\ub554\u5bf8\u745a\uae32\u1749\u2b8c\u4084\u0fbc\u85a1\u00c1\000\u2a29\ucf97", "\023\u5b6b\udb6c\udc66\udbe5\ude1a\uda62\udc1d\uda40\udc84\ud86e\udf3d\ud95b\udc71",
        31, 76159, 868913358, 1766715515589382888L, -54793L, false, true, (char) 38716, (char) 32952,
        Double.longBitsToDouble(0x3f8fa3b151f26540L), Double.longBitsToDouble(0x3fe88dca7f9bbf05L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc77\udb3e\udd81\ud9e3\udd18", "\u3334\u7b8c\ubde2\u2048\ud2b5\u5ade\u2f7fo\000\ua398\u5bf8\u745a\uaeb4\u1749\u153d\ud284\u9790", "\uf571\000\udb98\udd30\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f\udb6c\udc66\udbe5\ude1a\uda62\udc1d\uda40\udc84\ud86e\udf3d\uda95\udeae\udb58\udd4d",
        54, 9358, 411345511, -6494099505655789146L, -83278L, false, true, (char) 61039, (char) 27046,
        Double.longBitsToDouble(0x3fef73f1b944a5e6L), Double.longBitsToDouble(0x3fb7eac06e90bc50L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 6, "-\000\u4e00", "\u3334\u0780\ubde2\u0081\u8fb3\003\000\u5df0\u50d8\ub9fc\000\u73aa\ua682\u8297\u2c45\000\u9ce6", "\ud999\udcdf",
        -3, 15205, -165335336, -6845505825268236269L, 64545L, false, false, (char) 22219, (char) 15668,
        Double.longBitsToDouble(0x3fdc100e08e3aaa4L), Double.longBitsToDouble(0x3fee5930362791e4L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 13, 4, "\udb8d\ude79\udb3e\udd81\ud9e3\udd18\uda5b\ude9a\udb12\udc19\ud90a\udf60\udb84\ude08\ud9a2\udcfe\uda5f\uddc0\ud942\udec2\uda8d\udd2e\udaba\udf90\uda3e\udccb\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\udb3c\udc89\ud942\udd4d\ud8b8\udc1d\ud9e2\ude47\udb63\udef9\ud8fb\udcf0\ud99f\udeee\udb45\ude3e\ud98c\udf8c\udbf5\udc4d\udaba\udcda\udae1\udf58\udb04\udf1a\udab3\udd88\ud8df\ude1f", "\u04c9", "\uda95\udeae\udb58\udd4d\uda8b\udc4a\ud940\udfdb\udb8c\udfd8\ud935\udd98\ud99a\udfd9\uda0b\udf6d\udb1d\udc59\ud81b\udee8\ud860\udce5\udbfe\ude7d\udae0\udda0\ud871\udfdb\udadc\ude9e\udae7\udc41\ud885\uddc2\udb4a\udc1e\ud801\udff7\ud92b\udc1d\ud84b\udea9\udb3e\udcee\ud947\udd9d\ud9ef\udf01\ud8ff\uddcd\ud9d1\udc7f\udb71\udee1\ud836\udd4f\udab2\udf00\ud8f0\udf1c\udb2e\udf3c\uda2c\udecf\ud8b6\udf2b",
        27, 79958, -1413352046, -2038968547439573250L, -18616L, true, false, (char) 43644, (char) 34933,
        Double.longBitsToDouble(0x3fcda7d98364a9e0L), Double.longBitsToDouble(0x3fd1214e5a2c6756L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 11, 6, "\udb25\udf67\ud973\udee7\udad3\udf75\udbdc\udd3d\ud832\udfb5\ud809\ude31\udb84\uddf7\ud807\uddaf\ud936\udfdc\udacb\udfb7\udaad\udee5\udaba\udf90\udad9\uded9\udb7f\udee8\ud9eb\ude50\ud9d5\udd37\udb77\udffe\ud85c\udc53\ud9fa\udfbe\ud9df\ude4e\udb63\udef9\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\udbf4\udfc4\uda98\udebb", "\u67e9", "\uda92\uddf0\uda01\udfc4\ud86b\udc51\ud8cf\udd8c\ud95a\udead\ud960\udd1d\ud95d\udefd\ud9a6\udcaa\ud935\udd98\ud837\udca8",
        36, 27801, 902045228, 8016564666240942815L, -3889L, false, false, (char) 13032, (char) 49441,
        Double.longBitsToDouble(0x3f7b070288f2f700L), Double.longBitsToDouble(0x3fe06c5893ba8172L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud9a4\udde5\udb37\uded9\ud850\udf50", "\u4f14\u7847\u4fff\u2048\ud2b5\u24de\u2f7f\u2683\uce56\u3827\u5bf8\u745a\uaeb4\u1749", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93\uda71\udf12\ud95a\ude66\udbc8\ude10\udae4\udc60\uda1b\udca4",
        10, 89605, -2077858552, -6264624695363789742L, -17825L, false, true, (char) 60536, (char) 48595,
        Double.longBitsToDouble(0x3fe57d29ab7226e6L), Double.longBitsToDouble(0x3febdb71bd6303feL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 3, 3, 16, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc56\udb12\udc19\ud851\udcc3", "\ua7c5", "\udaba\udf90\ud8a6\udd22",
        30, 39155, -1854183691, -3850538441013287294L, 10655L, false, false, (char) 39419, (char) 25737,
        Double.longBitsToDouble(0x3fe60a7d9fb22707L), Double.longBitsToDouble(0x3febdd24c8b59b5fL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 15, 17, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc56\ub047\udab2\udf5f\udb65\udfd5\ud9a2\udcfe\uda5f\uddc0\ubd1a\udaa0\udc84\udaba\udf90\ud8a6\udd22", "\u5bf8", "\ud9fa\udfd4\ud9df\ude4e\udb63\udef9\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\uda4e\uddef\ud9ee\udeb0\ud9a3\udf49",
        6, 22133, 409014947, 2282013385955852630L, -55392L, false, true, (char) 37396, (char) 21890,
        Double.longBitsToDouble(0x3fc43cf8ea107c64L), Double.longBitsToDouble(0x3f9bfe4d079e83c0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 16, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc56\udb12\udc19\ud851\udcc3", "\u2048", "\udaba\udf90o",
        -5, -1000, 0, -3850577680606255486L, 85275L, false, false, (char) 55411, (char) 25782,
        Double.longBitsToDouble(0x3fe60a7d9fb22707L), Double.longBitsToDouble(0x3ec3200000000000L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=[B:[[20, -38, 4, -36, -100, -40, -103, -35, -51, -40, 79, -36, -75, 46, 18, -37, 25, -36, 123, -39, -53, -35, -53, -38, 88, -33, 31, -38, 0, -35, 82, -37, -99, -35, 73, -40, -99, -36, 36, -39, 39, -34, -96, -39, 48, -33]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 14, "\uda14\udc04\ud89c\udd99\ud8cd\udc4f\u2eb5\udb12\udc19\ud97b\uddcb\udacb\udf58\uda1f\udd00\udb52\udd9d\ud849\udc9d\ud924\ude27\ud9a0\udf30", "\u3827\u5bbd\ub12d\u10af\u6146\u5c1f\u9e08\u9790\ub0b2\u5e69\u406a\u14b6\u615e\u6fd7\u5d5c\ucf4d\uba51\ub484\ud48c\u2e63\u5eab\u9b98\u090c\ua739\u8f53\u6230\ucef8\u70af\u1d14\u4eb1\u3588\uab00\ucc4f\u1711", "\uda80\udff0\udbe6\udf4b\uda07\uded8\ud883\udd5d",
        14, 44254, -2061258006, -8865112611122409973L, 88857L, true, true, (char) 50012, (char) 49748,
        Double.longBitsToDouble(0x3feb2024ae59797bL), Double.longBitsToDouble(0x3fc0a811efee9ab4L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 0, 1, 4, "", "\u7848\u7e30\ua6b8\u4f14\u7847\ubde2\u2048", "\udaba\udf90\ud8a6\udd22",
        30, 39155, -1854183691, -3850538441785039230L, 85275L, false, false, (char) 55411, (char) 25782,
        Double.longBitsToDouble(0x3fe60a7d9fb22707L), Double.longBitsToDouble(0x3febdd24c8b59bcaL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.CharSequenceUtils:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 4, 1, 16, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda2f\udfa1\udbc8\ude60\ud827\udc1e", "\u2048", "\udb2e\ude6a\ud8a2\ude24",
        30, 39155, -1854183691, -3850538441785039230L, -79973L, false, false, (char) 55411, (char) 25782,
        Double.longBitsToDouble(0x3fe60a7d9fb22707L), Double.longBitsToDouble(0x3febdd24c8b59bcaL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 1, 12, "\000", "\000", "\udb65\udfd5",
        10, 30240, -1465650624, 7955725289326075359L, -49708L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 1, 16, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc56\udb12\udc19\ud851\udcc3\udb65\udfd5\ud9a2\udcfe\uda5f\uddc0\ubd1a\udaa0\udc84\udaba\udf90", "\u3827\u5bf8\u15ff\uaf12\u1749\u153d\ucf8e\u9790\ub0b2\u406b\u3e26\u2d5f\ub028\ucde2\ub1a4\u6300\u83ab\u0e14\u1e9a\uaae7\u7fef\u84ea\u4998\ua4bc\u7c93\ud4a8\u0fa2\u5ed1\ub923\ud5f7\u5cfb\u6023\u4ce0\u5705", "\ud8eb\udc38\ud907\udf2a\udb8a\ude1f\ud960\udf52\uda57\udf1f\udb6a\udf2e\ud951\udd34\udad7\udd95\u672e\u6f9b\udbb5\udf11\ud901\ude5f\ud9a9\udf76\udb0d\udf97\u5f3a\ud9b4\udd0b\udbfd\udddd\udb20\udd3b\udb74\udf1f\ud927\uddab\ud864\udc26\udb26\udcd3\u6232\ud959\udf71\udaf7\udff5\uda97\udcc2\uda47\udf80\ud81b\udf03\udb4c\udf0d\udaeb\udd22\ud92f\uded8\udb63\ude49\ud988\uddaf\ud9be\udcf1\ud8c8\udceb\ud947\udecc\udbc7\udd49\udb02\uded6\udbf0\ude7a\udb3e\ude0d\ud8d0\udffe\ud8ed\udf34\ud9b3\udc17",
        -4, 66513, 588770438, 7755255385933264199L, 97027L, false, false, (char) 5408, (char) 38702,
        Double.longBitsToDouble(0x3fe73f22254adebdL), Double.longBitsToDouble(0x3fe655a8da049086L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 0, 1, 16, "\ud850\udd75\udb3e\udd81\ud850\udf50\uda5a\udc56P\000", "\u2048", "\udaba\udf90\ud8a6\udd22",
        30, 67203, -1854183691, -3850538442580515198L, -23131L, false, false, (char) 55411, (char) 25782,
        Double.longBitsToDouble(0x3fe60a7d9fb22707L), Double.longBitsToDouble(0x3febdd24c8b59b00L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 8, 10, 16, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc56\ud8e9\udd20\ud851\udcc3", "\u2048", "\ud9b5\udc55\uda79\udf23",
        52, 39155, -1854164704, -3850538441785039230L, 85275L, false, false, (char) 55411, (char) 25782,
        Double.longBitsToDouble(0x3fe60a7d9fb22707L), Double.longBitsToDouble(0x3febdd24c8b59bcaL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 0, 6, "\udba4\udc64\ud914\ude00\uda71\udc7a", "\u0d5b\u7b8c\ubde2\u2048\ud2b5\ube1fv\u5e98\u50d8\u15eb\u57b7\u745a\uaeb4\u343b\u223f", "\ud918\udf54",
        45, 47874, -1681222789, -5893566265640704263L, 87373L, false, false, (char) 48425, (char) 23726,
        Double.longBitsToDouble(0x3fd0d9fb1898721eL), Double.longBitsToDouble(0x3fdc1bfe0717c4a4L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 13, 6, "\uda71\udf66\udb3e\udd81\ud850\udf50", "\u3334\ub3a1\u671a\u2048\ud2b5\u0d3c\u2ed9\u5e5f\u00b3\u53be\u0989\u745a\u1fea\u9b6f", "\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\uda7f\ude35\ud9aa\udd99\udbeb\ude8b\udaa4\udd37\ud9fe\ude8d\udae0\uddf4",
        25, 25762, 1749004357, -9082593450673384138L, 78927L, false, true, (char) 12635, (char) 4629,
        Double.longBitsToDouble(0x3fde1de03537a104L), Double.longBitsToDouble(0x3fe40d04fb862dd5L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 3, 6, "\ud850\udd48", "\u00df\ua668\u3334\u7b8c\ubde2\u2048\ud2b5", "\uda3e\udccb\uda6a\uddf5\ud84b\udd06\uda92\udc71\udb3c\udc89\ud942\udd4d\ud9fa\udfa0\ub7b6\ud8c5\uddfe\ud8b4\udc60\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud895\udd93",
        13, 11824, -1593843527, -7996945898323449170L, -31276L, true, false, (char) 60212, (char) 58886,
        Double.longBitsToDouble(0x3fb26ebe84dfe240L), Double.longBitsToDouble(0x3feb89d0967816adL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 8, 8, 6, "\udbdb\udde1\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u0801\ud560\u76fb\u820b\u2229\u503b\ub9fc\u5bf8\u745a\uaeb4\u1749", "\ud8fb\udcf0\udbd3\udf48\udb2f\udd48\ud8f6\ude5d\uda3a\udde6\ud812\udfe3\ud923\ude43\ud850\ude5b\udac7\udcd5\ua665\udb7c\udf16\udbe5\ude1a\uda0c\udc12\udb3e\udf85\ud860\udc3e\uda95\udeae\udbfd\udc49\uda8b\udc4a\ud940\udfdb\udb8c\udf80\ud935\udd98\ud99a\udfd9\uda0b\udf6d\ud861\udf9a\udb6c\udc6b\udbb7\udc5f\ud807\udd34\udb7a\udc67\ud820\udfa3\ud88a\udc6f\udad1\udeeb\udaff\uddfd\udab8\udec3\ud983\udf64\udac6\udef6\uda86\udc03\udb3b\ude2b",
        30, 88967, 80998001, 9117286382638339661L, 98287L, true, false, (char) 52190, (char) 14948,
        Double.longBitsToDouble(0x3fe3a60d6b34bc85L), Double.longBitsToDouble(0x3fe85b3a3257bf92L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 6, "\udb87\udc77", "", "",
        -5, 26088, -1476327890, 130296422858816L, -76192L, false, false, (char) 6202, (char) 54649,
        Double.longBitsToDouble(0x3fe7af404bb0917bL), Double.longBitsToDouble(0x3fe416548400006aL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -37, 8, -36, 55, -37, 62, -35, -127]]\0121=[B:[[-2, -1, -37, 8, -36, 55, -37, 62, -35, -127]]\012",
        Z.run(T, 2, 9, 9, 0, "\udb08\udc37\udb3e\udd81", "\ub641\u3334\u7b8c\ubde2\u4fb0\u7893\u854b\uaa24\u2a92\u3395", "\udb3c\udc89",
        34, 89361, 26038770, -4891592148774773162L, -55649L, false, true, (char) 14297, (char) 29823,
        Double.longBitsToDouble(0x3fe6c571a8b9f625L), Double.longBitsToDouble(0x3f93a0ff55d220a0L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=[B:[[17, -37, -90, -35, 62, -37, -127, -35, 80, -40, 80, -33, 90, -38, -110, -36, 37, -38, 90, -33, -54, -40, 96, -33, -124, -37, 33, -34]]\0121=[B:[[17, -37, -90, -35, 62, -37, -127, -35, 80, -40, 80, -33, 90, -38, -110, -36, 37, -38, 90, -33, -54, -40, 96, -33, -124, -37, 33, -34]]\012",
        Z.run(T, 2, 11, 11, 7, "\udb11\udda6\udb3e\udd81\ud850\udf50\uda5a\udc92\uda25\udf5a\ud8ca\udf60\udb84\ude21", "\u7893", "\ud8af\udf01\ud9da\udc48\udb32\udd04\ud90e\udc6f\udb51\udeaf\ud942\udd4d\ud9fa\udfa0\ud984\ude09",
        27, 55046, -89202116, 2812307479664883634L, 41131L, false, false, (char) 21162, (char) 56209,
        Double.longBitsToDouble(0x3fe574882ac13a69L), Double.longBitsToDouble(0x3fc31b02d3961b98L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.CharSequenceUtils:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 4, 17, 9, "\udb08\udc37\udb24\ude66\ud850\udf50\uda5a\udc92\uda25\udf5a\udb14\udfe5\ud924\udd7b\ud9a2\udd0a\ud979\udced\uda00\ude1e", "\u2a92\u72db\u6e6d\u4dde\u04ed\uaeb4\u1749\u44f8", "\uda38\udee7",
        11, 69538, -1917851411, -5893566265609081128L, -25151L, false, false, (char) 48425, (char) 23726,
        Double.longBitsToDouble(0x3fe72c3734a4d0e8L), Double.longBitsToDouble(0x3fdc1bf7d8e3aaa4L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=[B:[[-2, -1, -37, 8, -36, 55, -37, 62, -35, -127, -40, 80, -33, 80, -38, 90, -36, -110, -38, 37, -33, 90, -39, 10, -33, 96, -37, -124, -34, 33, -39, -72, -34, -89, -38, 96, -33, 98, -37, 41, -34, -89, -38, -65, -33, 21, -37, 48, -34, -58, -40, -81, -33, 1, -37, 74, -34, 40, -37, 50, -35, 4, -38, -110, ...\012",
        Z.run(T, 2, 1, 9, 6, "\udb08\udc37\udb3e\udd81\ud850\udf50\uda5a\udc92\uda25\udf5a\ud90a\udf60\udb84\ude21\ud9b8\udea7\uda60\udf62\udb29\udea7\udabf\udf15\udb30\udec6\ud8af\udf01\udb4a\ude28\udb32\udd04\uda92\udc71\udb3c\udc89\ud942\udd4d\ud9fa\udfa0\ud984\ude09\udb63\udedb\udbd1\udeeb\ud9fa\udf9d\uda6b\udc94\ud807\udc9b\ud895\udd93\ud812\udfe3\ud923\ude43\udb04\udf1f\udab3\udd88\ud8df\ude1f\udb6b\udfef\u6575\uda24\ude1e\udbf0\udfdc\ud83a\udcb6\uda95\udeae\udb58\udd4d\uda8b\udc4a\ud87f\udffb\udaf8\udd39\udb34\ude05\ud90f\udfba\uda4a\udcaa\ud9b1\udd25\ud9f3\ude3c\ud86b\udc8c\udb74\udea5\ud8d7\udca0\ud8cf\ude9c\ud915\udc68\udbdc\udda7\ud895\udf71\ud92f\udf47", "\ucb0f\u2a05\u41d7\u0668\u36e5\u7892\u3238\u6ceb\ua611\u28ae\u70e6\u90b5\u80ab\u4f6d\u656e\ubca6\u9bcd\u46ef\u383b\u7d19\u92fe\u6b7b\u295d\ub897\u110f\u106a\u716e", "\udbc4\ude51\uda41\uddd1\udab4\udd08\ud899\udd58\ud826\udfbc\udb75\udcbe\ud8de\udf3c",
        4, 56441, -1020670257, -3754317497616083872L, 26708L, false, true, (char) 13382, (char) 24112,
        Double.longBitsToDouble(0x3fb9968626a9a418L), Double.longBitsToDouble(0x3fd90d0617281972L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.CharSequenceUtils:@?\0121=new org.apache.commons.codec.binary.CharSequenceUtils:@?\012",
        Z.run(T, 2, 4, 4, 10, "\ud83c\udf71\udb3e\udd0f\uda90\udc3d", "\u33be\u03f0\u138c\uc43a\ua89b\u23f6\u2f30\ub31d\u5061\uc12c\uc307\u746d\u2845", "\udbd2\udd05\ud8c4\ude25\ud94b\udd84\uda24\udf05\udb96\udfe1\ud895\udd5e\ud812\udfe3",
        24, 36473, -1861934061, -7013355946985554981L, 46271L, true, false, (char) 53652, (char) 31683,
        Double.longBitsToDouble(0x3fecb824905cc4a8L), Double.longBitsToDouble(0x3fec4f46306733caL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=[B:[[-13, -124, -68, -74, -14, -66, -83, -102, -14, -76, -128, -67]]\0121=[B:[[-13, -124, -68, -74, -14, -66, -83, -102, -14, -76, -128, -67]]\012",
        Z.run(T, 2, 12, 12, 10, "\udad3\udf36\udaba\udf5a\uda90\udc3d", "\ud1a9\u03f0\u138c\uc43a\u5fd7\u2410\u0afa\ub9dd\u5061\uc12c\uc307\u73fc\u2845", "\ud894\udd90\udaaf\udcea\ud94b\udd84\ud817\udfbe\udb95\udc03\ud8de\udfb0\ud812\udfe3",
        12, 40153, -893603621, -7013356724374635557L, -23649L, true, true, (char) 56996, (char) 36100,
        Double.longBitsToDouble(0x3fec4f46306733caL), Double.longBitsToDouble(0x3fe1c8c424e5eaadL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "\000\udb05\ude01\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\u3be6\u0731\u2f7f\u5e5f\u50d8\u6f4b\u86fe\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u00f2\u1944\u00afL\000\u6400\u2471\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud9ea\udfe9\udba1\uddc7\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\udb36\udf0c\u0238\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\uddf5\ud937\udc4d\udaa2\udcb1\udaab\udf64\ud941\ude71",
        44, 86487, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3fd137ac042f9ed2L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "\ud884\udca2\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\u3be6\u0731\u2f7f\u5e5f\u50d8\u6f4b\u86fe\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u6e54\u1944\u00df\uc7ff\u5b2c\u3982\ua54a\u419f\u1e30\u1776\u4017\u94f1\u259d\000\000\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda51\ude43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud9ea\udfe9\udba1\uddc7\ud8a1\udc44\ud8fc\uddc8\ua9d9\udacc\udf7a\ud9ba\udf6f\ud985\udda7\uda48\udee6\udb36\udf0c\ud8cd\ude1e\uda28\udee8\ud8cd\udd28\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\uddf5\ud937\udc4d\udaa2\udcb1\udaab\udf64\ud941\ude71",
        44, 86487, -1331860020, -642982818519853003L, -100000L, true, true, (char) 26035, (char) 4148,
        Double.longBitsToDouble(0x3fd96e9eff284a1eL), Double.longBitsToDouble(0x3fd137ac042f9ed2L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "\ud978\udfd0\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\u3be6\u0731\u2f7f\u454e\u50d8\u6f4b\u86fe\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u6e54\u1944\u00af\uc84b\u5b2c\u3982\ua54a\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94C", "\ud992\udf5b",
        47, 72593, 419637067, 5658878418119791862L, 26922L, true, false, (char) 64049, (char) 52613,
        Double.longBitsToDouble(0x3fdd98fbb59f94f8L), Double.longBitsToDouble(0x3fe8663ad5a4fdf9L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "\ud978\udfd0\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\u3be6\u0731\u2f7f\u5e5f\u50d8\u6f4b\u86fe\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u6e54\u3ee5b\uc84b\u5b2c\u3982\ua54a\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda51\ude43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud9ea\udfe9\udba1\uddc7\ud8a1\udc44\uda9f\udd19\uda9c\ude25\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\udb36\udf0c\ud8cd\ude1e\uda28\udee8\ud8cd\udd28\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\uddf5\udb46\udc09\ud972\uddc9\udaab\udf64\ud941\ude71",
        44, 86487, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3fd137ac042f9ed2L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\ud978\udfd0\udb26\ude81\ud850\udf50", "\u3334\u7b8c\ucb84\u85dd\u3bba\u06b0\u2f7f\u5e5f\u5c4d\u1432\u86fe\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\uc867\u38b3\u67e9\u6e54\u1944\u00af\ua1d1\u6496\uc646\ua54a\u419f\u1e30\u1776\u4017\u94f1\u57fc\u0e74\u8c52\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94C\u1f53", "\ud9c5\udfa6\uda51\ude43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud9ea\udfe9",
        40, 25465, -1883512730, -3856020433319337265L, 33724L, false, false, (char) 49749, (char) 35082,
        Double.longBitsToDouble(0x3fc4174d6c9a7bfcL), Double.longBitsToDouble(0x3f9c205610730200L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "\ucb2d\000\ud850\ude7e", "\u3334\u7b8c\ubde2\u2048@\u0731\u2f7f\000\u22f6d\u86fe\u745a\u795d\ua4ac\u2a9f\ud284\u7d73\u84b0\ua902\uc35d\u54b6\000\000\u876f\u388a\u67e9\u6e54,\ucfce\uc84b\u5b2c\u3982\ua54a\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\u5f04\u68bb\ub7b2\u3a94C\u0885", "\000\000\udb71\uded3\000\ud8fa\udf37\ud81f\udc9c\ud9ea\udfe9\udba1\uddc7\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\u00cf\ud9ba\udf6f\ud948\udc03\ud855\udeac\ud99e\udccf\ud8cd\ude1e\u60a0\ud8cd\udd02\udbcd\uddfb\udaf4\udfdd\uda37\udc34\000\uda03\ude60\ud937\udc4d\udaa2\udcb1\udaab\udf64\ud941\ude71",
        44, 31983, -1331860020, -648330840946649035L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3fd137ac042f9ed2L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "\ud978\udfd0\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\u2b4b\u2048\u3be6\u0731\u2f7f\u5e5f\u50d8\u6f4b\u86fe\u745a\uc74a\u6291h\ud284\u7d73\u84b0\ua902\u9fbb\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u6e54\u1944\u00af\uc84b\u5b2c\u3982\ua54a\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda51\ude43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud9ea\udfe9\ud88b\uddbc\udae3\udc45\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\udb8b\udfb8\ud93e\udc39\ud8b1\uddd7\ud8fc\udeda\ud8cd\ude1e\uda28\udee8\ud8cd\udd28\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\uddf5\ud937\udc4d\udaa2\udcb1\udaab\udf64\ubd29",
        -1, 86487, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3fd137ac042f9ed2L), Double.longBitsToDouble(0x3fe294d1009fbbb3L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 15, 7, 6, "\000", "\u7e6c\uadb7\u5400\u7b8c\u2e2f\u9abc\u512f", "o\000\000",
        -5, -1000, 795518464, -1301420784265122579L, -100000L, false, false, (char) 14203, (char) 40063,
        Double.longBitsToDouble(0x3fe6c00000b9f625L), Double.longBitsToDouble(0x3f93a0ff55d220a0L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 15, 2, "\udb87\udc77\ud93e\ude61\ud81e\udff1", "\u33b0r\u524c\u2048\ua5df\uab08\u2f7f\ucad1\u5097\ub9fc\u3a7d\uc4f0\ua51e\u1e99\u153d\ud284\u9790\u0abd\u541d\u4922\u54b6\ucfc4\u93e6\u4480\ua127\ua40e\ubb66", "\uda40\udc84\ud86e\udf3d\ud9b5\ude5f\udb58\udd08\uda8b\udc4a\ud946\udd4a\udb8c\udfd8\ud935\udd98\ud968\udfe0\uda0b\udf6d\udabd\udd48\uda68\udf2d\uda27\udff6\ud8ed\udcbe\u4a01\udbf5\udd79\ud97b\udcef\ud9fa\udd96\ud998\udde8\uda7d\uddc8\ud838\udff0\ud9f9\udc97\uda65\udd7b\udbc2\udeea\udb0a\udea5\ud82e\udfff\uc7f7\udbdf\udc4f\ud96e\udf27\uda17\ude71\ud8ba\udd5c\ud98b\udd83\ud9e5\udd00\udb74\udee2\ud885\uddcc",
        45, 51777, -382433347, -6572311693520142766L, 27284L, false, true, (char) 57224, (char) 56021,
        Double.longBitsToDouble(0x3fd4e9121056b958L), Double.longBitsToDouble(0x3fda6c5f54f730fcL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 15, 8, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc92\udb04\udf53\ud909\udd71\udb84\ude21\ud9a2\udcfe\uda5f\uddc0\ud8c7\udfa4\u1a40\udaba\udf90\ud982\udcad\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\udb3c\udc89\uda43\ude52\udae1\udd7b\ud9d9\udead\udb63\udef9\ud8fb\udcf0\udae8\udd34\uda70\udf0b\ud818\ude4f", "\u7bb6\u8820\u20aa\u6fc3\u6133\u0e27\u04c9\uc04b\u6ab2\u3982\u2e7b\u67aa\u1e30\u1776\u4017\u25e1\ube2f\u00e3\uc18c\u46f4\ub69e\u8ee7u\ucb2a\ud3e0\uca85\u25c0\u2449\u9687", "\ud884\udeeb\ud848\uddea",
        0, 54316, 1280849726, -8859253097061799613L, -3080L, true, true, (char) 3474, (char) 28885,
        Double.longBitsToDouble(0x3f8d8471d28aa640L), Double.longBitsToDouble(0x3f8a877e581d03c0L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 6, "\udb59\udc77\udb3e\udd81\ud850\udf50\uda5a\udc92\udb12\udc19\uda95\udc85\udb84\ude21\ud8ac\udd03\uda5f\uddc0\ubd1a\udaad\ude84\udaba\udf90\uda3e\udccb\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\udb3c\udc89\ud942\udd4d\ud9fa\udfa0\ud90e\udf46\udb63\ude4d\ud9c3\ude5f", "\u328f\uc190\u8c07\ucb22\u8820\ua113\u6678\uaef0\u6961\ud11e\u3bb1\u907e\ub079\u03c4\u1528\u992f\u800d\u2741\u6de9", "\udb6f\udeaa\ue2ab\ud8cb\udc47\ud80c\ude8b\udbc2\udd71\uda14\udfca\udb6e\ude57",
        6, 85749, 409765748, 1963232581821870467L, 19352L, true, false, (char) 25179, (char) 60005,
        Double.longBitsToDouble(0x3fcf5c5f4eedd2e0L), Double.longBitsToDouble(0x3fe9991d2546c72bL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=[B:[[-66, 111, -37, 59, -34, -18, -40, 80, -33, 80, -37, 25, -34, -47, -38, 79, -34, -59, -39, -37, -35, 33, -82, -14, -39, -94, -36, -42, -40, -93, -33, -71, -40, 118, -36, 122, -37, 26, -35, 123, -40, -98, -33, -62, -38, 99, -33, 56, -38, 106, -35, -11, -39, -77, -36, -6, -38, -110, -36, 113, -39, -1...\0121=[B:[[-2, -1, -66, 111, -37, 59, -34, -18, -40, 80, -33, 80, -37, 25, -34, -47, -38, 79, -34, -59, -39, -37, -35, 33, -82, -14, -39, -94, -36, -42, -40, -93, -33, -71, -40, 118, -36, 122, -37, 26, -35, 123, -40, -98, -33, -62, -38, 99, -33, 56, -38, 106, -35, -11, -39, -77, -36, -6, -38, -110, -36, 113,...\012",
        Z.run(T, 2, 10, 9, 13, "\ube6f\udb3b\udeee\ud850\udf50\udb19\uded1\uda4f\udec5\ud9db\udd21\uaef2\ud9a2\udcd6\ud8a3\udfb9\ud876\udc7a\udb1a\udd7b\ud89e\udfc2\uda63\udf38\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\ud980\uddca\ud9f7\udc3e\uda98\udf8a\udb3d\udf6c\udb57\udd99\udbe1\udec3\ud8d3\udfa6\udb44\udfd1\uda7b\udc47\ud8f0\udcda\ud812\udf84\ud923\ude43\ud98c\udee3", "\u32a8\ua18d\u126a", "\udb50\uddee\udbd0\ude93\ud939\udfb6\uda17\udc50\uda8a\udd49\udad4\udfe5\udae5\ude9e\udb5b\udec0",
        13, 92618, -1782716858, -7166869357158472349L, -73205L, true, true, (char) 44105, (char) 2966,
        Double.longBitsToDouble(0x3fefa8d8ca3223b0L), Double.longBitsToDouble(0x3feda7757aad865cL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 9, 6, "\ud8f4\udde4\ud91a\ude31\uda75\udc81", "\u3301\u7896\u17b4\u1d6a\u4eb4\u684aI\u5e5f\u00c9\u6ea9\u5657\u7402\uc67a\u1749", "\ud8fb\udcf0\udae3\udef4\uda8d\udd28\ud9a4\udd37\ud895\udd18\uda71\udcf2\ud923\ude43",
        50, 7751, 973078528, -6768144075453987688L, 5359L, false, true, (char) 21593, (char) 13852,
        Double.longBitsToDouble(0x3fe3399e52e81884L), Double.longBitsToDouble(0x3fc64dfc1c4c9560L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 9, 6, "\udb87\udc77\ud93e\udc81\uda99\udc5f", "\u3301\ubbc5\000\u81c6\ud2b5\u5adb\u00df", "\000\uda92\udc71\uda46\udc8d\ud89e\udefe\ud9fa\udfa0\ud885\udeb9\ud9de\udfb8\ud8fb\udd31\udb31\udc58\uda8d\udcea\ud9a4\udd37\ud895\udd18\udb11\udc68\ud923\ude27\udb04\udf1f\uda0a\uddd8",
        53, 86739, -1847181430, -5843204029762487220L, -92177L, false, true, (char) 38923, (char) 13852,
        Double.longBitsToDouble(0x3fe33b3654e81807L), Double.longBitsToDouble(0x3fc64df5bc4c9560L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 14, 11, "\udb7c\udf60\udb3e\udd81\ud850\udf50\udbc0\udc20x\ud90a\udf2d\udb5d\udf8d\000\uda41\udf3f", "\u3ee6\u5e5f", "\uda92\udc71",
        6, -776, -303010639, 2449958196150599930L, -34464L, false, false, (char) 22230, (char) 40200,
        Double.longBitsToDouble(0x3fc6b3795b62b8d4L), Double.longBitsToDouble(0x3fc73ec4a05283fcL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 16, 9, 6, "\udb87\udc77\ud9bf\udcd7\ud850\udf65\uda5a\udc92\ud92e\udf57\ud90a\udf2d\udb5d\udf8d\000\uda41\udf3f\ubd1a\udaad\ude81\ud88b\ude65\ud8a2\udf3c\ud8a7\ude21\udb39\uddeb\uda92\udc71\udb3c\udc89\ud942\udccb\ud9fa\udfa0\udbc2\ude00\udb3f\udc32\ud8fb\udcf0\udb31\udc58\uda8d\udcea\ud9a4\udd37\ud86e\ude84\ud810\udeec\ud923\ude43", "\uccbd\u9980\u521a\ud24a\u8749\u0a49\u7c78\ua47f\u4aa5\u1e33\u1776\u9780\ubca7\u7cb0\u1538\u4d76\u59f3\u693c\u2584\uc6aa\u2b5a\u72b4\ucb64\ua870\u706d\u263d\u8610\u82a6\uc149\ua435\uaed7\uad21\u1b1b\u914c\u23cb\u80c5\ud1a3\u6831\u5b27\u5d27\u4ebc\u9b7a\u506d\u1be6\u1a40\uc916\u746c\u86c7\u0171\u68ca\u8bfd\u64dc\u4135\u7bac\uc348\u3f21\u0c72\u8f65\uc33b\ud55a\u2934\ua4da\u97b9\u8ed8\u0be3\u28bc\ubeff\u6826\u29fc\u9c6c\u1ef7\u6b74\u36b2\ub28d\u915d\u770b\u42c7X\uc89e\u962b\u6271\u0733\ub599\u3dbd\ua05b\u50ec", "\udaed\udcaa\ud8ac\udd70\udb81\udc8c\ud9b4\udda0\ud990\udf2c\uda28\uddef\uda28\uddd2\uda2e\udf8d\ud8a7\udd82\ud9a0\udcc0\uda41\udcf3\udaae\udc08\udad4\udf40\udafe\udf23\ud852\udd8f\uda33\ude01\udba7\udec5",
        2, 72170, -251210021, -7131465071255409219L, -35148L, true, false, (char) 55751, (char) 17040,
        Double.longBitsToDouble(0x3fed6f3b5330b578L), Double.longBitsToDouble(0x3fe14d8e56618d5cL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 16, 16, "\uda13\udf11\uda26\ude10\ud850\udf50\ud9b9\ude75e\ud90a\udf2d\ud8bf\udcdb\udba4\udda4\uda6b\udfcf\ubd1a\udaad\ude81", "/", "\udb3c\udc89\ud942\udccb\ue8ff\ud98d\udf97\udb70\udf12\ud8fb\udcf0\ud8c5\udcc2\ud8ac\udcff\ud953\ude96\ud895\udd18\ud812\udfe3\ud9c7\udfc2\udb04\udf1f\ud9fd\udc71",
        46, 69764, -233774610, -6185511301534918961L, 63761L, false, false, (char) 41572, (char) 33611,
        Double.longBitsToDouble(0x3fe9614ec6bd7721L), Double.longBitsToDouble(0x3fccae623f02dd3cL)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 6, "\ud8a6\udce3N\ud850\udf50\uda59\udfb3P\ud90a\udf2d\ud8bf\udcdb", "\u4302\u5a5f\u00df", "\000",
        -1, 52656, 795518464, 2291044343294496887L, -92746L, false, false, (char) 20224, (char) 0,
        Double.longBitsToDouble(0x3d93600000000000L), Double.longBitsToDouble(0x3fb5eb8d40000000L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 15, 1, "\ud8a6\udce3\uda5a\udee9\ud850\udf50\udb1c\udf94\u00f1\ud90a\udd8c\ud8de\udd64\ud9ce\udd59\ud982\udd00\ubd1a\udaad\ude81\u00df\udbcd\udc72\uda51\ude71\uda3e\udccf", "\uae32\ub75c\u7b69\ub81a\u9790\u85a1\u00c1", "\ud812\udfe3\ud9c7\udfc2\udb04\udf1f\ud98a\udf98",
        36, 83192, 574531616, -7301898481323128674L, -6731L, true, true, (char) 50225, (char) 54095,
        Double.longBitsToDouble(0x3fed2293e0f4ac24L), Double.longBitsToDouble(0x3fe059e8df8c05cdL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 10, "\ud8a6\udce3\udb3e\udd4f\ud850\udf50\uda5a\udc92P\ud90a\udf2d\ud8bf\udcdbz\000\ubd1a\udaad\ude81", "/", "\udb3c\udc89",
        34, 43329, 36983, -4899915778209735594L, -99807L, false, false, (char) 37631, (char) 29823,
        Double.longBitsToDouble(0x3fb5eb8d40000000L), Double.longBitsToDouble(0x3f93a0ff00168000L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 6, "\ud8a6\udce3\udb6d\udea8\ud850\udf50\uda5a\udc92P\ud9d6\udebf\ud8bf\udcdb\ud9ce\udd59\uda41\udf3f\ubd1a\uda5a\udf2b", "F", "\udb3f\udf16",
        34, 43329, 381456503, -4891621062489793450L, -88648L, true, false, (char) 28300, (char) 55008,
        Double.longBitsToDouble(0x3fe8218c28009216L), Double.longBitsToDouble(0x3fe3aa1e5439dd30L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 6, "\ud8a6\udce3\udb3e\udd4f\ud850\udf50\uda5a\udc92P\ud90a\udf2d\ud8bf\udcdb\ud9ce\udd59\ud903\udff4\ubd1a\udaad\ude81", "S", "\udb3c\udc89",
        34, 43329, 381456503, -4891621062489793450L, -99807L, false, false, (char) 37631, (char) 29823,
        Double.longBitsToDouble(0x3fb5eb8d45cfb138L), Double.longBitsToDouble(0x3f93a0ff00168000L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 15, 6, "\udb87\udd3a\udb3e\udd81\ud9e3\udd18", "\u3334\u2714\ubde2\u2048\u2ff2\u5b05\u80ffM\000\ud4fe\u7201\u745a\uaeb4\u6d74\u9be7\u0794\ua229", "\uf571\000\udb98\udd30\ud96a\uddab\udb04\udf1f\udab3\udd88\ud8df\ude1f\udb6c\udc66\udbe5\ude1a\uda62\udc1d\udaf2\udc7d\ud86e\udf3d\uda95\udeae\udb58\udd4d\uda8b\udc4a\ue677\udb8d\udc3f\uda8c\udec3\ud99a\udfd9\uda0b\udf6d\udb1d\udc59",
        41, 56621, -1481269326, 3547506898279807083L, 51228L, true, false, (char) 56667, (char) 14590,
        Double.longBitsToDouble(0x3fd0bc3dbf2fac1eL), Double.longBitsToDouble(0x3fe0bc1073583d3cL)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 6, 6, 6, "\udb87\udc77\udb3e\udd81\ud9e3\udd18", "\u33a3\u7b8c\u2c2f\u20a2\ud2b5\u5ade\uca29o\000\u1702\u5bf3\u745a\uaeb4\u1749\u153d\ud284\u9790", "\uf571\000\udb98\udd30\ud923\ude43",
        18, 79160, -1601310606, -6642740307540141808L, 5359L, true, true, (char) 8414, (char) 61677,
        Double.longBitsToDouble(0x3fce26794ba060dcL), Double.longBitsToDouble(0x3fda6a5e0e264ab0L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=[B:[[-119, -39, 21, -36, 55, -37, -39, -34, 84, -37, -15, -36, 90, -37, 82, -34, 18, -37, 25, -36, 81, -40, -61, -36, 101, -37, -43, -33]]\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 11, 2, 7, "\ud989\udc15\udb37\uded9\udb54\udcf1\udb5a\ude52\udb12\udc19\ud851\udcc3\udb65\udfd5", "\u2865\u8e0d\u3eac\u2683\uce56\u3827\ud44e\u745a\u208d\u7397\u1597\uc76a\u0384\u97ce\ua902\ua9f1\u54b6\u07d7\ucf68\u818c\uae75\u7a30\ud700\uae6a\u423e\u75fd\ub615\u0f9c\ucad6\u689b\u8b18\uc6a0t\ube12\u6e88\ubfb3\ub7b0\ua2ba\u3688\u570d\uab0f\u6c30\u164e\ua627\u4768\u4d4d\ub9e7", "\ud818\udcd7\u3a3b\uda38\udd28\ud86a\udcfe\ua294\ud8ee\udef1\ud88d\udc6d\udbaf\udc19\udae7\ude83\uda7f\ude48\udb10\udd46\ud962\udca4\udad8\udfcc",
        23, 52183, -659343922, 4330868834525092684L, -58462L, false, true, (char) 56807, (char) 21000,
        Double.longBitsToDouble(0x3fe4ac1a9b675f3bL), Double.longBitsToDouble(0x3fd242f362f093ecL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 3, 3, 4, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc56\ub047\udab2\udf5f\udb65\udfd5\ud9a2\udcfe\uda5f\uddc0\ubd1a\udaa0\udc84\udaba\udf90\ud8a6\udd22", "\u5bf8", "\ud9fa\udfd4\ud9df\ude4e\udad1\udf90\ud8fb\udd85\ud99f\udeee\udb2f\udd0d\ud818\ude4f\uda4e\uddef\ud9ee\udeb0\ud9a3\udf49\ud9cb\udef4\ud959\udf5a\ud9f4\udc7a\ud9c9\udd8d\ud966\udc8f\uda1d\ude1f\udb79\udd25\ud320\uda25\udd40\uda38\ude2b\ud87d\ude76\ud8ad\ude1d\ud838\ude01\ud849\udcd8\ud988\udc03\ud931\udee3\uda44\udd22\udb83\udc44\udb44\ude5d\ucf12\ud99d\udfff\udb68\ude21\udad4\udfbe\uda44\udcff\uda07\udf8f\uda86\udc3b\udaef\ude62\ud9b1\udf1c\uda08\uddcb",
        20, 1544, -1751657663, -8625253672146128695L, 57627L, false, true, (char) 31347, (char) 59472,
        Double.longBitsToDouble(0x3feeb8a124c5fdeaL), Double.longBitsToDouble(0x3fdea5fe4402e4e2L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 10, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc56\udb12\udc19\ud851\udcc3\udb65\udfd5\ud9a2\udcfe\ud945\udd93\ud9c4\ude2d\udaa0\udd0f\udb60\udc43o\000", "", "\ud9fa\udfa0\ud9df\ude4e\udb63\udef9\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ubfbb\000\ud929\udcf8\ud927\uded9",
        49, 27069, -1647924927, -6002794963961290834L, -97235L, true, true, (char) 26163, (char) 43993,
        Double.longBitsToDouble(0x3fb28d0a5541f790L), Double.longBitsToDouble(0x3fd0cf45347d79a8L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 1, 4, "", "\u77f7\u7e30\u0833\u4fbb\ud5e5\u3422\u2048\ud2b5\u0529", "\u1bb3\udb10\udee9\uda92\udc71\udbce\udc29\ud9bc\ude92\ud954\ude01\udb42\udd33\udbb1\ude4b\udb61\udf21\udb1a\uded2\ud8e4\udd95\udb94\udf41\ud980\ude00\uda2a\udc0d\ud93e\udd60\ud943\udf1a\ud986\udc27\ud930\udd8e\udb43\udd2f\ud95c\udcc1\uda4f\udcd7\ud92a\udedb\ud822\udc7f\ub774\udbdd\udc10\ud8a5\udf91\ud91f\ude2b\ud959\udcd9\udaec\udee6\ud9fa\udc7b\ud85d\udfda\udae1\ude6e\udaaf\udce3",
        50, 41400, 933743729, -6114861153334811710L, 9570L, true, true, (char) 45109, (char) 12971,
        Double.longBitsToDouble(0x3fe88c86d27c580cL), Double.longBitsToDouble(0x3fbbadc716c67e40L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 1, 12, "\000", "\000", "\udb65\udfd5",
        10, 30240, -1465650624, 7926335343515622879L, -49708L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 1, 12, "Q", "\000", "\udb65\udfd5",
        10, 30240, -1465650624, 7955725289326075359L, -49708L, false, false, (char) 17893, (char) 54256,
        Double.longBitsToDouble(0x3ecee00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=[B:[[-39, -124, -34, 80, -39, -40, -36, 99, -38, 114, -36, -105, -37, 12, -36, 102, -37, -39, -35, -40, -38, 64, -36, 58, -39, -6, -36, -72, -40, -92, -36, 109, 94, 12, -37, -3, -36, 3, -37, -66, -34, -28, -39, -92, -33, 90, -39, 34, -35, -3, -38, 56, -36, -106, -39, 87, -33, -79, 0, 0, -38, 106, -33, ...\012",
        Z.run(T, 2, 17, 10, 17, "\ud984\ude50\ud9d8\udc63\uda72\udc97\udb0c\udc66\udbd9\uddd8\uda40\udc3a\ud9fa\udcb8\ud8a4\udc6d\u5e0c\udbfd\udc03\udbbe\udee4\ud9a4\udf5a\ud922\uddfd\uda38\udc96\ud957\udfb1\000\uda6a\udfd4K\ud931\ude98\udb74\udc2f\ufe82\udb82\uddfe\udb7e\udf16", "\u522c\u526c\u5c6d\u6e68\ua7f0", "\ud81a\udc45\uda0f\udf35\uaa4e\udafe\ude2d\uda9c\ude70\ud8c2\udd45\uda90\udd9e\udbb3\udc24\ud942\udf91\ud9e3\udf7b",
        14, 2031, 1714255884, -8952923975196547570L, 36568L, false, true, (char) 8729, (char) 4729,
        Double.longBitsToDouble(0x3fb98de483c2ed68L), Double.longBitsToDouble(0x3fee8e8244c71393L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 1, 12, "\000", "r", "\udb65\udfd5",
        10, 30240, -1465650624, -3501432162704466465L, -49708L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 1, 12, "\000", "\u7950J\u4f14\u7847\ubde2\u1fc7\ud2b5\u24db\u2f7f\u2683\uce3b\u50eb\000\000\000", "",
        59, 9814, -1689206182, 1045011547786744128L, 78657L, true, true, (char) 47318, (char) 6333,
        Double.longBitsToDouble(0x3fdf315135ba4be2L), Double.longBitsToDouble(0x3fe979b439ffee27L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 1, 16, "\uda81\ude43\ud8f3\udf1e\udae8\udf87\uda32\ude76\udb12\udc19\ud9c1\udeec\udb5d\udc50\ud9a2\udcfe\uda42\ude73\ud97f\udeb0\udabc\udcfb\udaba\udf90", "\u3827\u4d64\u15ff\uaf12\u1749\u153d\ucf8e\u9790\ub0b2\u5b31\u9d75\u2d5f\u71a3\ucde2\ub1a4\u6300\u179b\u0e14\u1e9a\uaae7\u295e\ub651\u9b63\uad8d\u2096\ud4a8\u101a\u5ed1\u3a69\uc45f\ua1f2\uc892\u39cd\u848c", "\udb90\uddeb\udaec\udf92\udb6a\uddcd\ud960\udf52\uda57\udf1f\udb6a\udf2e\ud951\udd34\udad7\udd95\udba5\ude0d\u6f9b\udbb5\udf11\udb17\udd57\ud80d\udc68\uda1e\udc1f\ud45b\ud9b4\udd0b\ud885\udca1\udb20\udd3b\ud850\udc2c\ud927\uddab\ud864\udc26\u8dd0\udaa4\udedb\ud805\udf66\udaf7\udff5\uda97\udcc2\uda47\udf80\ud81b\udf03\udb4c\udf0d\udaeb\udd22\ud82b\udc55\udb2d\ude87\ud988\uddaf\ud9be\udcf1\ud850\udcef\ud9d3\uddb1\udada\udc2a\udb26\ude71\udbf0\ude7a\udb3e\ude0d\ud8d0\udffe\ud8ed\udf34\uda4e\ude25",
        20, 28263, 588770438, 7755255385933264199L, -40381L, true, false, (char) 62251, (char) 45760,
        Double.longBitsToDouble(0x3fe655aa5815bf86L), Double.longBitsToDouble(0x3fe0b1fcf84b03c0L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 1, 16, "\ud850\udd75\udb3e\udd81\ud996\udea2\uda5a\udc56P\000", "\u2048\ud2b5\u11de\u2f7f", "\ud87a\udee8\uda90\udc71\udb3c\udc89\ua682\000\udbf3\udfd8\udb63\udef9\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ud818\ude4f\ud83b\udce5\ud937\udeb5\uda2a\udd0d\udae2\udfa1\ua39b\ud831\udd94\uc5b5\udb80\ude32\ud931\udcd6\udbb7\udd7c\udb15\udda7\udbbb\udca5\ud9ce\udcf6\ud8f8\udfd5\u6409\udbd3\udc26\udab8\udd8d\u42f1\udb69\udd4e\ud935\udfd1\ud9d1\udf7b\uda3a\udfd0\ud992\udc26",
        51, 51490, 2051300428, 337996082862218480L, 97208L, false, true, (char) 38370, (char) 56634,
        Double.longBitsToDouble(0x3f71ed62fea39980L), Double.longBitsToDouble(0x3fed4131189605c2L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 0, 6, "\udba4\udc64\ud951\udfff\uda71\udc7a", "\u0d5b\u7b8c\ubde2\u2048\ud2b5\ube1fvw\u50d8\u15eb\u57b0\u745a\uaeb4\u343b\u4f3f", "\ud918\udf54",
        45, 47874, -1681222789, -5893566265640704263L, 87378L, false, false, (char) 48425, (char) 23726,
        Double.longBitsToDouble(0x3fd0d9fb1898721eL), Double.longBitsToDouble(0x3fdc1bfe0b17c4a4L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\000\udb05\ude01\ud850\udf50", "\u3334\u7b8c\ubde2\u2f82\u3be6\u0731\u2f7f\u5e5f\u50d8\u6f4b\u86fe\u745a\u795d\u1459\ud4d5\u69bf\u7dd0\u84b0\ua902\ud337\u54b6\ucfc4\ub0de\u18f7\u388a\u67e9\u00f2\u1944\u00afL\000\uc285\u39be\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94\u5ff5\u8d0b", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud9ea\udfe9\udba1\uddc7\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\ud9ba\udd9e\udb3e\udc4b\u0238\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\uddf5\ud937\udc4d\ud8c9\udfc5\udaab\udf64\ud941\ude71",
        44, 86487, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3fd137ac042f9ed2L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "\000\udb05\ude5d\ud850\udf50", "\u3334\u7b8cg\u4371\u3be6\u0731\u2f7f\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u00f2\u1944\u00afL\000\u64bc\u2471\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud9ea\udfe9\ud940\ude55\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\ud8c5\udcb3\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\udb42\udec2\ud936\udfc3\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 86565, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\000\udb05\ude01\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\u3be6\u0731\u2f7f\u5e5f\u50d8\u5371\u65e3\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u00f2\u1944\u00afL\000\u6400\u2471\u419f\u1e30\u1776\u8708\ud331\u0764\u3c7a\u8c52\u1a6a\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\ud95f\udc55\ud943\udf2c\ud90a\ude9c\ud81f\udd1e\ud9ea\udfe9\udba1\uddc7\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\udb36\udf0c\udb44\ude19\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\udd7d\ud937\udc4d\udaa2\udcb1\udaab\udf64\ud941\ude71",
        44, 86487, -1331860020, 983062938223404424L, -83958L, true, false, (char) 59941, (char) 29458,
        Double.longBitsToDouble(0x3fe9e968c217cf69L), Double.longBitsToDouble(0x3fd529a20d2d86eaL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "j\udb05\ude01\ud861\udd50", "\u3334\u7b8c\ubde2\u2048\u3be6\u0731\u2f7f\u5e5f\u8711\u6d61\u86fe\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\uc78b\u95c2\u2d9c\u388a\u67e9\u00f2\u1944\u00af\u29fd\ud251\u1689\uaf83\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\ucd57\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud874\ude07\ud917\udefa\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\udb36\udf0c\u0238\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\uddf5\ud937\udc4d\ud951\udfca\ud874\udd60\ud877\udc5a",
        45, 86487, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3fd784bc042f9ed2L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\ud978\udfd0\udb3e\udd81\ud850\udf50", "\u3334\u7b8c\ubde2\u2048\u3be6\u0731\u2f7f\u5e5f\u50d8\u6f4b\u86fe\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\u5312\ua2e3\u3ce9\u388a\u67e9\u6e54\u3ee5b\uc84b\u5b2c\u1c52\ua4ba\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\ub753\u68bb\ub743\u3a94C\u0885", "\ud9c5\udfa6\uda51\ude43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud9ea\udfe9\udba1\uddc7\ud8a1\udc44\uda9f\udd19\uda9c\ude25\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\udb36\udf0c\ud8cd\ude1e\uda28\udee8\ud8cd\udd28\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\uddf5\udb46\udc09\ud972\uddc9\udaab\udf64\ud941\ude71",
        44, 86487, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3fd137ac042f9ed2L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 17, 6, "\udb09\udd17\ub1c0\ud850\ude7e", "\u3334\u7b8c\ubde2\u2048@\u0731\u2f7f\000\u22f6d\u86fe\u745a\u795d\ua4ac\u2a9f\ud284\u7d73\u84b0\ua902\uc35d\u54b6\000\000\u876f\u388a\u67e9\u6e54,\ucfce\uc84b\u479e\ua73f\ua54a\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\u5f04\u4d0c\ub7b2\u3a94C\u0885", "\000\000\ud9ef\udff2\ud801\ude85\ud8fa\udf37\ud81f\udc9c\ud9ea\udfe9\udba1\uddc7\ud8a1\udc44\ud8fc\uddc8\ud9e9\udd38\uf017\ud9ba\udf6f\udbd9\udf8d\ud855\ude57\ud99e\udccf\ud8cd\ude1e\u60a0\ud8cd\udd02\udbcd\uddfb\udbc1\udc42\uda37\udc34\000\uda03\ude60\ud937\udc4d\udba8\udf94\udaab\udf64\ud941\ude71",
        44, 31983, -1331860020, -648330840946649035L, 49348L, false, true, (char) 24454, (char) 53028,
        Double.longBitsToDouble(0x3fcfbfae285f3e8cL), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 9, 6, "\ud8f4\udde4\ud91a\ude31\uda75\udc81", "\u3301\u7896\u17b4\u00e7\ub874\u684aI\u136f\000\u6ea9\u00f5\000\000\u8297", "\ud8fb\udcf0\021\uda8d\udd28\ud9a4\udd37\ud895\udd18\uda71\udcf2\ud923\ude43",
        50, 7751, 973078528, -6768144075453987688L, 56785L, false, true, (char) 21593, (char) 13852,
        Double.longBitsToDouble(0x3ec94ba062100000L), Double.longBitsToDouble(0x3fc64dfc1c4c9560L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 16, "\ud8f4\udde4\ud91a\ude31\uda75\udc81", "\u3301\u7896\u17b4\u1d6a\u9c56\u1fd2I\u5e5f\u00c9\u974b\u2b9e\u7402\u0a92\ucca5", "\ud8fb\udcf0\udae3\udef4\uda8d\udd28\ud9a4\udd37\ud895\udd18\uda71\udcf2\ud923\ude43",
        46, 56087, 973078528, -6768144075453987688L, -30398L, false, true, (char) 21593, (char) 30077,
        Double.longBitsToDouble(0x3fe3399e52e81884L), Double.longBitsToDouble(0x3fc64dfc1c4c9560L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 6, 4, "\udb7c\udf60\udb3e\udd81", "x\u69b0", "\uda41\udf3f\ubd1a\ud91c\uded9",
        -3, 27229, 1404190631, 6741950754136483573L, 51073L, true, false, (char) 56304, (char) 65273,
        Double.longBitsToDouble(0x3f8066d600209e80L), Double.longBitsToDouble(0x3fd15c2031410c6cL)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 14, 11, "\uda5b\udeab\udb3e\udd81\ud850\udf50\udbc0\udc20x", "\000\u81c6\ud2b5\u914b\u3ee6\u13dc\ua563\u78e3\u1efc\u449c\u5905\u1749\u084c", "\udb31\udc58",
        40, 47392, -1681222912, -5893566265609081128L, 31052L, false, true, (char) 30842, (char) 41979,
        Double.longBitsToDouble(0x3fb781aa4a5c5088L), Double.longBitsToDouble(0x3fe207592481240aL)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 16, 16, "\uda13\udf11e\ud850\ude7e\ud9b9\ude75e\ud90a\udf2d\ud8bf\udcdb\udba4\udda4\uda6b\udfcf\ubd1a\udaad\ude81", "/", "\ud923\udd81",
        34, 26825, 5642496, 0L, -75646L, false, false, (char) 0, (char) 55476,
        Double.longBitsToDouble(0x3fb5eb8d45cfb138L), Double.longBitsToDouble(0x3f93a0ff00000000L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 17, 16, 16, "\uda13\udf11\uda26\ude10", "e\u3301", "\uda6b\udfcf",
        51, 9464, 223, 1241607489733001263L, -11424L, true, false, (char) 25153, (char) 13161,
        Double.longBitsToDouble(0x3fb5af07400413d0L), Double.longBitsToDouble(0x3fcbd920094008ccL)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 7, 14, "\ud8a6\udce3\udb6d\udea8\ud850\udf50\uda5a\udc92P\ud9d6\udebf\ud8bf\udcdb\ud9ce\udd59\uda41\udf3f\ubd1a\uda5a\udf2b\u00df\udbea\udc61F\ud982\udce1\u843c\udb3f\udf16\ud942\udccb\uda9b\ude90\u49ce\udb5d\udc8f\udae2\udc22\ud92c\udfeaq\uda1c\udeee\udb9f\uddbd\ud812\udfe3\ud9c7\udfc2\ud850\udfa4\udb0e\udc89", "\u3e28\u816e\u7d32\u1c8c\u21cd\u466f\u9baa\u6f2f\u0346\u90b5\ucf0d\ub526\u4f39\u73ec\u6271\u9190\u3d58\u3fe1\ubaae\uc0a2\ubde1\u3c59\u0535\u6465\u29cc\u16ab\uaed6\ubc3d\u3314", "\uda94\udcbb\uda3e\udc98\ud927\udff1\ud88b\uddb3\ud9ee\udf29\ud909\udc64\udb5f\ude9f\u3360\u0fb5\ud82e\udcd3\udadf\udd91\ud982\uddbc\udaba\ude1f\udb27\udd6a\uda56\udd0a\ud8fc\udfd7\udb78\uddb7\ud8ef\udcb6\ud93e\udcdc\ud8b9\udefc",
        22, 77328, -483001214, -3972771070193091497L, -5550L, true, true, (char) 6482, (char) 58015,
        Double.longBitsToDouble(0x3fca0cf4f4c4a18cL), Double.longBitsToDouble(0x3fa8861e08fae530L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 6, "\ud8a6\udce3\udb5b\udda8\ud850\udf50\uda5a\udc92P\ud9d6\udebf\ud8bf\udcdb\ud9ce\udd59\uda41\udf3f\uda59\udcce\udbc8\udec6", "\ubee5c\u03dd\u38eb\uae32\uc25f", "\ud85b\udf1f\udb76\udd3cq\uda1c\udeee\udb9f\uddbd\ub3da\ud9c7\udfc2\ud850\udfa4\udb0e\udc89\udaa9\udffa\udb2c\udc67",
        0, 52695, 953718055, 6963279286445517400L, -33753L, false, false, (char) 44308, (char) 7252,
        Double.longBitsToDouble(0x3fe66a85b935e525L), Double.longBitsToDouble(0x3fd872943f35f434L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 6, "\ud8a6\udc40\udb3e\udd4f\ud850\udf50", "\u3301\u88ff\u4f5d\u07ff\ud2b5\u5adb\u00df\u8e77S\000\u5bf8\u745a\uae32\uc25f", "\ud8fb\udcf0\udb51\udca7\u00c1\000\ud895\udd18\ud812\udfe3\ud9c7\udfc2\udb04\udf1f\ud98a\udf98\ud945\udc66\ud935\ude45",
        33, 97760, -1071685995, -5890061687242682673L, 66554L, false, true, (char) 29338, (char) 9752,
        Double.longBitsToDouble(0x3feb67e7b561b090L), Double.longBitsToDouble(0x3feda6f5d3bf1b4dL)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 6, "\ud8a6\udce3\udb3e\udd4f\ud850\udf50\uda30\udd92P\ud90a\udf2d\ud8bf\udcdb\ud9ce\udd59\ud903\udff4\ubd1a", "\u8f4eS\000\u5bf8\ud57d\u111a\u76ed\u7b20\ub81a", "\u00c1\000\ud895\udd18\ud812\udfe3\ud9c7\udfc2\udb04\udf1f\uda7e\udd31\ud902\udc45\ud96a\udebc\ud99d\uddf8",
        29, 99727, 1520602746, 8664010784756362743L, 73113L, true, true, (char) 62050, (char) 33060,
        Double.longBitsToDouble(0x3fba1eeb9ccd0830L), Double.longBitsToDouble(0x3fe60038504b89a7L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 2, 7, "\ud989\udc15\udb37\uded9\udb54\udcf1\udb5a\ude52\udb12\udc19\ud851\udcc3\udb65\udfd5", "\u2865\u8e0d\u3eac\u2683\uce56\u3827\ud44e\u745a\u208d\u7397\u1597\u2474\u5985\u94ab\ua902\ua9f1\u444e\ua173\u80d3\u818c\uae75\u7a30\ud700\uae6a\u423e\u75fd\ub615\u0f9c\ucad6\u689b\u8b18\uc6a0t\ube12\u6e88\ubfb3\ub7b0\ua2ba\u3688\u570d\uab0f\u6c30\u164e\ua627\u4768\u4d4d\ub9e7", "\ud818\udd70\u3a3b\uda38\udd28\ud86a\udcfe\ua294\ud8ee\udef1\ud88d\udc6d\udbaf\udc19\udae7\ude83\uda7f\ude48\udb10\udd46\ud962\udca4\udad8\udfcc",
        23, 52183, -659343922, 4330868834525092684L, -58462L, false, true, (char) 56807, (char) 21000,
        Double.longBitsToDouble(0x3fe4ac1a9b675f3bL), Double.longBitsToDouble(0x3fd242f362f093ecL)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 10, "\udb87\udc77\udb3e\udd81\ud850\udf50\uda5a\udc56\udb12\udc19\ud851\udcc3\udb65\udfd5\ud9a2\udcfe\ud945\udd93\ud9c4\ude2d\udaa0\udd0f\ud892\udeb4g\000", "", "\ud9fa\udfa0\ud9df\ude4e\udb63\udef9\ud8fb\udcf0\ud99f\udeee\udb2f\udd0d\ubfbb\u6454\ud929\udcf8\ud927\uded9",
        49, 27069, -1647924927, -6002794963961290834L, -97235L, true, true, (char) 26163, (char) 43993,
        Double.longBitsToDouble(0x3fb28d0a5541f790L), Double.longBitsToDouble(0x3fd0c648447d79a8L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]]\012",
        Z.run(T, 2, 10, 10, 4, "", "\u77f7\u7e30\u0833\u4fbb\ud5e5\u3422\u2048\ud2b5\u0529", "\u1bb3\udb10\udee9\uda92\udc71\udbce\udc29\ud9bc\ude92\ud954\ude01\udb42\udd33\udbb1\ude4b\udb61\udf21\udb1a\uded2\ud8e4\udd95\udb94\udf41\ud980\ude00\uda2a\udc0d\ud93e\udd60\uda2d\ude15\ud986\udc27\ud930\udd8e\udb2d\udc76\ud95c\udcc1\uda4f\udcd7\ud92a\udedb\ud822\udc7f\ub774\udbdd\udc10\ud8a5\udf91\ud91f\ude2b\ud959\udcd9\udad7\udfe6\ud9fa\udc7b\ud85d\udfda\udae1\ude6e\u00e4",
        50, 41400, 933743729, -6114861153334811710L, 9570L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe88800027c580cL), Double.longBitsToDouble(0x3fbbadc716c67e40L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 12, "Q", "\000", "\udb66\udc07",
        10, 30240, -1465650624, 296979189517505235L, -49708L, false, false, (char) 17893, (char) 54256,
        Double.longBitsToDouble(0x3ecee00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 17, 12, "\ud984\ude50\ud9d8\udc63\uda72\udc97\udb0c\udc66\udbd9\uddd8\uda40\udc3a\ud9fa\udcb8\ud8a4\udc6d\u5e0c\udbfd\udc03\udbbe\udee4\ud9a4\udf5a\ud922\uddfd\uda38\udc63\ud957\udfb1\000\uda6a\udfd4K\ud931\ude98\udb74\udc2f\ufe82\udbce\ude41\udb7e\udf16", "\u522c\u526c\u219a\u6e68\ua7f0", "\ud81a\udc45\uda0f\udf33\uaa4e\udafe\ude2d\uda9c\ude70\ud8c2\udd45\uda90\udd9e\ud812\udf2a\ud942\udf91\ud9e3\udf7b",
        14, 2031, 1714255884, -8952923975196547570L, 36568L, false, true, (char) 8729, (char) 4729,
        Double.longBitsToDouble(0x3fb98de483c2ed68L), Double.longBitsToDouble(0x3fee8e8244c71393L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 12, "\000", "r\000\u4f14\u5ecd\ubde2\u1fc7\ud2b5\u7068\u2f7f\u2683\uce3b\u50eb\000\000\000\000\000\ub801", "\ud842\udfff\ud884\udf26\ud838\uddbf\udbd2\ude3d\ud9f7\ude9d\ud9e3\udf59\ud983\udc42\udbf0\udc2d",
        15, 17829, -607091136, -635385687992703772L, -45085L, true, false, (char) 43504, (char) 24767,
        Double.longBitsToDouble(0x3fe9b3e06369a298L), Double.longBitsToDouble(0x3fc48d7777ed869cL)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 12, "\000", "r", "\udb65\udf94",
        10, 84560, -1465650624, -3501432162048016161L, -49708L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 12, "\ub7c0", "\u7950J\ud0da\u7847\ubde2\u1fc7\ud2b5\u24db\u2f7f\u2683\uce3b\u50eb\000\000\000", "",
        59, 9814, -1689206182, 1045011547786744128L, 78657L, true, true, (char) 63377, (char) 44926,
        Double.longBitsToDouble(0x3feadae821df8b40L), Double.longBitsToDouble(0x3fe979b609ffee27L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 3, 1, 12, "\000\ud832\udcee\udb2d\udc76\udb3f\uddffJ", "\ubde2\u808a\ucde2\u4996\uba17\u2634\uce3b\u50eb\000", "\000\000\udb7a\udf9d\ud9dc\udf24\u446b\udb1e\udd51\udadb\uddba",
        20, 20637, -460077243, 7910931319818412299L, -39664L, true, true, (char) 57549, (char) 11702,
        Double.longBitsToDouble(0x3fdffee27ea4767aL), Double.longBitsToDouble(0x3fdc07502a18fb0cL)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 0, 0, "\udba4\udc64\ud951\udfff\uda71\udc7a", "\u0d5b\u7b8c\ubde2\ua390\ud2b5\ube80\u7652w", "\ud9bf\udc40\udb3c\udc89\ud942\udd4d\udbe1\udf73\ud912\udf92\ud983\uddb0\ud997\uddac\ud918\udf54\ud926\udfa0\ud978\udfff\ud895\udd93\ud812\udfe3\udb87\ude47\udb6f\udef1\ud8ea\udecd",
        34, 15625, -1615756136, 8472037313447214156L, -54315L, false, false, (char) 15492, (char) 5863,
        Double.longBitsToDouble(0x3facb6ced13b3770L), Double.longBitsToDouble(0x3fe0c85c1fafb8edL)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\000\udb9d\udd13\ud850\udf52", "\u3334\u7b8cg\u4371\u3be6\u0731\u2f7f\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u00f2\u1944\u00af\ud228\u5124\u64bc\u2471\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u71d9\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud95b\ude5c\ub37f\ud8c7\udf80\ud940\ude55\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\ud8c5\udcb3\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 86565, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 17, 6, "\000\udb05\ude5d\udb2d\udd48", "\u3334\u7b8cg", "\udaae\udd11\udaba\udf90\uda3e\udccb\uda27\uddd3\ud824\udf31\ud9e2\udf2e\udb3c\udc89\ud83a\uded1\udaba\uddd3\udae4\ude10\udb78\udd7f\uda21\uddd9\udb36\udcac\udb2f\udd0d",
        38, 22211, -1372202827, -4673277534673051640L, 36530L, false, false, (char) 52011, (char) 22722,
        Double.longBitsToDouble(0x3fb32bb5c0000000L), Double.longBitsToDouble(0x3fc7800000000000L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "j\udb05\ude01\ud861\udd50", "\u3334\u7b8c\ubde2\u2048\u3be6\u0731\u2f7f\u5e5f\u8711\u6d61\u86fe\u745a\u795d\u1459\u0095\ud284\u7d73\u84b0\ua902\uc35d\u54b6\uc78b\u95c2\u2d9c\u388a\u67e9\u00f2\u1944\u00af\u29fd\ud251\u1689\uaf83\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\ucd57\u8421\ub753\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud8fa\udf37\ud81f\udd1e\ud874\ude07\ud917\udefa\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\udb36\udf0c\u0238\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\uda0e\uddf5\ud937\udc4d\ud951\udfca\ud874\udd60\ud877\udc5a",
        45, 86487, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3fd784bc042f9ed2L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 2, 16, "\uda5b\udeab\udb3e\udd81", "x\u3301", "\uda41\udf3f\ubd1a\ud91c\uded9",
        42, 12559, 5295364, 54043194169911029L, -47648L, true, false, (char) 60912, (char) 8954,
        Double.longBitsToDouble(0x3fb5af07400413d0L), Double.longBitsToDouble(0x3f98c2030030c6c0L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 4, "\ud91a\udcf4\udb64\udc0e", "e\u15f7", "\ud8ac\udea8\ubd1a\udaad\ude81\u00df",
        16, -953, 1140850688, -374352833634360400L, -67857L, true, true, (char) 13161, (char) 1908,
        Double.longBitsToDouble(0x3fe578eafacd643eL), Double.longBitsToDouble(0x3fde7d2e548d2442L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 10, "\ucd87\udb3e\udd81\ud850\udebb\uda5a\udc56\udb12\udc19\ud851\udcc3\udb65\udfd5\ud9a2\udcfe\ud945\udd93\ud9c4\ude2d", "g\000\000\000\u50aa\uaeb4\u1749\u153d\ud284", "\udb2f\udd0d\ubfbb\u6454\ud929\udcf8\ud927\uded9",
        49, 27069, -1647924927, -6002794963961290834L, -97235L, true, true, (char) 26163, (char) 43993,
        Double.longBitsToDouble(0x3fde8fbd98e00948L), Double.longBitsToDouble(0x3fd0c648447d79a8L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 12, "\000\ud832\udcee\udb2d\udc76\udb3f\uddffJ", "\ubde2\000\000\u4996\uba17\u2614\uce3b\u50eb\000", "\000\000\ud9e8\udf94\u0136\u4411\udb1e\udd51\uda5b\uddba",
        9, 42341, 69, 56653569276829952L, -39664L, true, true, (char) 241, (char) 63231,
        Double.longBitsToDouble(0x3fdffee27ea4767aL), Double.longBitsToDouble(0x3fdc07502a18fb0cL)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\000\udb9d\udd13\ud850\udf52", "\u3334\u7b8ch\u4371\u3be6\u0731\u2f7f\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u00f2\u1944\u00af\ud228\u5124\u64bc\u2471\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u71d9\u8421\ub753\u9ed7\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud95b\ude5c\ub37f\ud8c7\udf80\ud940\ude55\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\ud8c5\udcb3\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 41630, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "w\udb9d\udd13\ud850\udf52", "\u33e1\u7b8cg\u1b70\u3be6\u0731\uad6e\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u08e4\u8bfe\u6ec3\u876f\u388a\u67e9\u5480\ud642\u00b5\ud228\u7840\u3a21\u2471\u4417\u6aad\u1776\u4017\u94f1\u6e34\u3c08\uae52\u71d9\u8421\ub753\u68bb\u84e7\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud95b\ude5c\uda0c\udc6e\ud800\udd44\ud82a\udce0\ud8ff\uded7\ud884\uddea\udbab\uddfe\ud9ba\udf30\ud903\ude2f\ud985\udda7\udb53\udcd5\udb9f\udc78\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\u922c\ud933\udfe8\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 86565, -1331860020, -642982814969677771L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\000\udb9d\udd13\ud850\udf52", "\u3334\u7b8cg\u4371\u3be6\u0731\u2f7f\u5e5f\u45c9\000\u8650\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u67e9\u00f2\u1944\u00df\ud1dc\u5124\u64bc\u2471\u419f\u1e30\u1776\u4017\ua3f0\u6e34\u3c08\u8c52\u71d9\u8421\ub753\u68bb\u899e\u3618C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud95b\ude5c\ub37f\ud8c7\udf80\ud940\ude55\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\ud855\udeac\ud8c5\udcb3\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 86565, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 4, "\ud9d2\udcf0\udb64\udc0e\udb90\udf56\ud9b9\ude75\ud9dd\udff3\udbfa\udc71\ud838\udfa4\ud80e\udd55\ud8ac\udea8\ubd1a\udaad\ude81n", "\u1098\u99ec\u745a\ud448", "\udac0\udf12\ud84b\udd79\ud94e\udc97",
        8, 48087, 95754822, 683492562344209932L, 63488L, false, true, (char) 26500, (char) 3893,
        Double.longBitsToDouble(0x3feafdf41cb8a45aL), Double.longBitsToDouble(0x3feb1f80562b9388L)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 2, 1, 8, 10, "\ucd87\udb3e\udd81\ud850\udebb\uda5a\udc56\udb12\udc19\ud851\udcc3\udb65\udfd5\ud9a2\udcfe\ud945\udd93\ud9c4\ude2d", "g\000\000\000\u5135\uaeb4\u51f3\u153d\ud284", "\udb2f\udd0d\ubfbb\u6454\ud929\udcf8\ud927\uded9",
        49, 27069, -1647924927, -6002794963961290834L, 4009L, false, false, (char) 44174, (char) 54535,
        Double.longBitsToDouble(0x3fd032f63586d22cL), Double.longBitsToDouble(0x3fde8fbd98e00948L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 10, "\ucd87\udb3e\udd81\ud850\udebb\uda5a\udc56\udb12\udc19\ud851\udcc3\udb65\udfd5\ud9a2\udcfe\ud945\udd93\ud9c4\ude2d", "gX\000\u6c00\u50aa\uaeb4\u1749\u30da\u7b30", "\udb2f\udd0d\ubfbb\u6454\ud929\udcf8\ud927\uded9",
        29, 27069, -1647924927, -6002794963961290834L, -97235L, true, true, (char) 26163, (char) 43993,
        Double.longBitsToDouble(0x3fde8fbd98e00948L), Double.longBitsToDouble(0x3fd0c648447d79a8L)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 10, "\ucd87\udb3e\udd81\ud850\udebb\uda5a\udc56\udb12\udc19\ud851\udcc3\udb65\udfd5\ud9a2\udcfe\ud945\udd93\ud9c4\ude2d", "g\000\000\000\u50aa\u00c7\u3824\ub233\ud284", "\udb2f\udd0d\ubfbb\udac2\udcc8\ud8b0\ude51\ud826\udfcb",
        48, 27061, -1647924927, -6002794963961290834L, 16785L, false, true, (char) 14539, (char) 60611,
        Double.longBitsToDouble(0x3fe2df9ebac36916L), Double.longBitsToDouble(0x3fde8fbd98e00948L)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 2, "\ucd87\udb3e\udd81\ud850\udebb\uda5a\udc56\udb12\udc19\ud851\udcc3\udb65\udfd5\ud9a2\udcfe\ud89c\udca0\ud9c4\ude2d", "\u00f1\u3100\000\000\u50aa\u17ce\u2a97\u1565\ud284", "\ud9ad\udf80\ud94a\udd3e\u6454\ud929\udcf8\ud927\uded9",
        49, 4637, -1647924927, -6002794963961290834L, -97235L, true, true, (char) 26163, (char) 43993,
        Double.longBitsToDouble(0x3fde8fbd98e00948L), Double.longBitsToDouble(0x3fd0c648447d7808L)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=new org.apache.commons.codec.binary.CharSequenceUtils:@?\012",
        Z.run(T, 2, 2, 4, 6, "\000\udb9d\udd13\ud850\udf52", "\000\000h", "\udaae\udd11\udaba\udf90\uda3e\udccb\ud92d\udfb6\ud85c\udd35\ud9e2\udf2e\udb3c\udc89\ud83a\uded1\uda91\uddd3\udae4\ude10\udb78\udd7f\uda21\uddd9\udb36\udcac\udb2f\udd0d",
        38, 22211, -1372202827, -4673277534673051640L, 36530L, false, false, (char) 52011, (char) 22722,
        Double.longBitsToDouble(0x3fb32bb5c81c4098L), Double.longBitsToDouble(0x3fc7800380000000L)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "w", "\uc781\ud231\u33e1\u7b8c\u29f5\u1b70\u3be6\u0731\uad6e\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u08e4\u8bfe\u6ec3\u7f6e\u388a", "\udb28\udefa\uda67\udc1c\udadc\udd3a\ud9e5\ude30\ud981\udc91\ud96a\udd75\ud83b\udd30\ud8c3\udd78\000",
        12, 35134, -1117760213, -3342133813492738536L, -32014L, false, true, (char) 8011, (char) 41881,
        Double.longBitsToDouble(0x3fbee2af9c2b1d20L), Double.longBitsToDouble(0x3f98e240c54b0360L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "w\udb9d\udd13\ud850\udf52", "\u2d3d\u90a1y\u1b70\u3be6\u0731\uad6e\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u08e4\u8bfe\u6ec3\u876f\u388a\u67e9\u5480\ud642\u00b5\ud228\u78c8\u3a21\u2471\u4417\u6aad\u1776\u4017\u94f1\u6e34\u3c08\uae52\u71d9\u8421\ub753\u68e8\u84e7\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\uda18\ude24\udb80\udef9\ud9e3\udc41\uda2c\udf85\ud800\udd44\ud82a\udce0\ud8ff\uded7\ud884\uddea\udbab\uddfe\ud9ba\udf30\ud903\ude2f\ud985\udda7\udb53\udcd5\udbb6\udf78\ud97f\udee2\udbba\udd90\ud87a\ude26\udbcd\uddfb\u9281\ud933\udfe8\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udbcc\udfd4\ud9c5\udf14",
        53, 86523, -1331860020, -642982814969677771L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 7, 15, "w\udb9d\udd13\ud850\udf52", "\u33e1\u7b8cg\u1b70\u3be6\u0731\uad6e\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u08e4\u8bfe\u6ec3\u876f\u388a\u67e9\u5480\ud642\u00b5\ud228\u7840\u3a21\u2471\u4417\u6aad\u1776\u4017\u94f1\u6e34\u3c08\uae52\u71d9\u7627\u6de7\u68bb\u84e7\u3a94C\u0885", "\udb0b\udf1d\uda68\udff6\udb71\udf1e\udb80\udef9\ud95b\ude5c\uda0c\udc6e\ud800\udd44\ud82a\udce0\ud8ff\uded7\ud884\uddea\udbab\uddfe\ud9ba\udf30\ud903\ude2f\ud985\udda7\udb53\udcd5\udb9f\udc78\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\u922c\ud933\udfe8\udac6\udd66\udb42\udec2\uda33\udf5b\udbdf\udd87\udabe\ude3b\ud941\ude71",
        37, 86565, -1331860020, -642982814969677771L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "w\udb9d\udd13\ud850\udf52", "\u33e1\u7b8cg\u1b70\ud206\u145b\uad6e\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459s\u4d0b\u7d73\u84b0\ua902\uc35d\u08e4\u8bfe\u6ec3\u876f\u388a\u67e9\u5480\ud642\u00b5\ud228\u7840\u3a21\u2471\u4417\u6aad\u1776\u4017\u4984\ub238\u3c08\uae52\u71d9\u8421\ub753\u68bb\u84e7\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud95b\ude5c\uda0c\udc6e\ud800\udd44\ud82a\udce0\ud8ff\uded7\ud884\uddea\ud9c3\udd8b\ud9ab\udcae\ud903\ude78\ud985\udda7\udb53\udcd5\udb9f\udc78\ud97f\udee2\uda28\udee8\ud87a\uddfd\udba3\ude17\u922c\ud933\udfe8\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udb75\udc48\udabe\udff1",
        16, 86565, -1331860020, -642982815732516811L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 14, "\u00df\udb9d\udd13\ud850\udf52", "\u33e1\u7b8cg\u6f49\uc4a1\u0731\uad6e\u5e5f\ubc4b\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\ubda7\u8bac\u6ec3\u8800\u388a\u67e9\u86ba\u566d\ua982\ud228\uc882\u3a21\uafcc\u4417\u99ac\u1776\u4017\u1141\u6e34\u3c08\uae52\u71d9\u8421\ub753\u68bb\u84e7\u3a94\u4e81\ub393", "\ud9c5\udfa6",
        13, 8595, 1781394616, 8474911855384536430L, 8061L, true, true, (char) 55174, (char) 3287,
        Double.longBitsToDouble(0x3fab880d65baab90L), Double.longBitsToDouble(0x3fda4fd1a5540072L)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\000\udb84\udead\ud850\udf52", "\u3334\u8fcfg\u4371\u3be6\u0731\u2f7f\u5e5f\u45c9\000\u8650\u745a\u7063\u1566\u8b3a\u4aa6\u7d73\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u876f\u388a\u74e8v\u1944!\ud1dc\u5124\u64bc\u2471\u419f\u1e30\u1776\u4017\ua3f0\u6e34\u3c08\u4541\u7160\u8421\ub753\u68bb\u899e\u3618C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud95b\ude5c\ub37f\ud8c7\udf80\ud940\ude55\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda55\udeac\ud8c5\udcb3\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 86565, -1331860020, -642982818519853003L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 17, "\000\u80c8\ud850\udf63\udad1\udced", "\u9b09", "\ud9bb\udc06\ud8e8\udd7c\ucbb4\uda65\udd67\ud8d9\ude4a\ud85c\udd85\udbf9\udfdd\udbfc\udcac\u653d\uda91\uddd3\udae4\ude10\udb78\udd7f\uda21\ude1a\ud900\ude51\udb2f\udd0d\ud818\ude63\ud849\udf5d\udaa1\udf9c",
        40, 42394, -1381459908, 7970784948560901920L, -70523L, true, true, (char) 37905, (char) 34860,
        Double.longBitsToDouble(0x3fe2144eee486a4fL), Double.longBitsToDouble(0x3fe64662e14ef500L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 9, "\000\udb9d\udd13\ud850\udf52", "\000\000h", "\udb37\udcb6\udaba\udf32\udbf0\udf24\ud953\udcd2\ud85c\udd35\ud9e2\udf2e\udb3c\udc89\ud83a\uded1\uda91\uddd3\udae4\ude10\udb78\udd7f\uda21\uddd9\udb36\udcac\udb2f\udd0d",
        38, 22211, 2056949179, -4658502533004664824L, 36530L, false, false, (char) 52011, (char) 22722,
        Double.longBitsToDouble(0x3fb32bb5c81c4098L), Double.longBitsToDouble(0x3fc7800380000000L)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=[B:[[0, -15, -77, -124, -84, -15, -101, -71, -80]]\012",
        Z.run(T, 2, 2, 12, 2, "\000\ud98c\udd2c\ud92f\ude70", "\ubc25sh", "\udaae\udd11\udaba\udf90\uda3e\udccb\ud878\udc1c\ud85c\udd35\ud9e2\udf2e\udb3c\udc89\ud83a\uded1\uda91\uddd3\udae4\ude10\udb78\udd7f\ud8ce\udc54\ud9ac\udea5\udb2f\udc56",
        38, 4761, -1372202773, -4673277534673051640L, 36530L, false, false, (char) 52011, (char) 22505,
        Double.longBitsToDouble(0x3fb32bb5c81c4098L), Double.longBitsToDouble(0x3fc7800380000000L)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 14, "\ud9e4\udc1c\ud98c\udd2c\ud92f\ude70", "\ubc25sh", "\udaae\udd11\udaba\udf90\uda3e\udccb\ud878\udc1c\ud85c\udd35\ud9e2\udf2e\udb21\udc9c\udaf4\udd43\ud9a9\udd4e\udbe9\udf34\udb78\udd7f\ud8ce\udc54\ud9ac\udea5\udb2f\udc56",
        38, 4761, -1372202773, -4673277534673051640L, 36530L, false, true, (char) 52138, (char) 22505,
        Double.longBitsToDouble(0x3fb32b898b1b4098L), Double.longBitsToDouble(0x3fc7800380000000L)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 14, "\ud9e4\udc1c\ud98c\udd2c\udb7b\udd35", "\ubc25s", "\ud869\udeb5\udaae\udd11\udaba\udf90\uda43\udecb\ud878\udc1c\uda02\udc68\uda8f\udcdd\udb21\udc9c\udaf4\udd43\ud9a9\udd4e\udbe9\udf34\ud956\ude0d\ud8ce\udc54\ud9ac\udea5\udb2f\udc56\ud818\ude4f\ud8a9\udcbc\ud813\udc19",
        34, 36296, -1861934061, 4209153359807987698L, 22886L, false, false, (char) 37238, (char) 25816,
        Double.longBitsToDouble(0x3e4dac1a14000000L), Double.longBitsToDouble(0x3fd340d49f140664L)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 13, 6, "\udb87\udc77", "\u7e6c\ua6b8\u3334\u7b8c\ubde2\u2048\ud2b5", "\uda3e\udccb\uda6a\uddf5\ud9b3\udcfa\uda92\udc71\udb3c\udc89\ud942\udd4d\ud9fa\udfa0\ud9df\ude4e\udb63\udef9",
        40, 48924, 654791361, -6586101375446641797L, 84789L, true, false, (char) 50450, (char) 31667,
        Double.longBitsToDouble(0x3fe609d34c98d816L), Double.longBitsToDouble(0x3fccb23cd132bba0L)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 9, 1, 10, "\ufb00", "r\000\u4f14\u0a14\u97cc\u3c11\u726a\u0653\u2f7f\u2683", "\ud921\udc41",
        -5, -1000, 0, -1049427968L, 53465L, true, true, (char) 36464, (char) 62165,
        Double.longBitsToDouble(0x3fed54eee077aa35L), Double.longBitsToDouble(0x3fe3f9d0f7f88e6bL)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\000\udb05\ude01\ud8f4\udec1", "\u3334\u7b8c\ubde2\u2048\ub0ef\u965b\u2f7f\u5e5f\u2ce1\u5371\u97ab\u745a\ua5e6\u1459\u0095\u28e0\u7fc0\u84b0\ua902\uc35d\u54b6\ucfc4\u31fa\u1be2\u4a00\u67e9\u00f2\u1944\u00af\u224d\u4600\u1c4b\uc0a7\u419f\u1e30\u4563\uada6\u8e99\u0783\u3c7a\u8c52\u3cfb\u5411\ub753\u68bb\ub7b2\u3a94C", "\ud992\udf5b\ud9c5\udfa6\uda37\udd43\ud95f\udc55\ud943\udf2c\ud90a\ude9c\ud81f\udd1e\ud822\udc64\udba1\uddc7\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7",
        5, 71753, -33553864, -6989761858055962624L, -252L, true, true, (char) 17380, (char) 38696,
        Double.longBitsToDouble(0x3fe113216e073718L), Double.longBitsToDouble(0x3fdcc6f4f513613aL)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 5, 6, "\ud8a6\udce3\udb5b\udda8\ud850\udf50\uda5a\udc92P\ud9b3\udcb7\ud8bf\udcdb\ud9ce\udd59\uda41\udf3f\uda59\udcce\udbc8\udec6\ud90f\udd97", "c\u03dd\u38eb\u0f9c\uc25f\u7b69\u540a\u1af4\u49e1q\u6a12\u64b5\u3fbb\ud4ab\uc36a\u9cbe\u3407\u7932\u690f\u89b4\ub086\u3c26\u1079\u0c05\ucf88\u6616\u6466\u94fe\u7ef9\u621d\ud289\uc6ac\u5ab9\u4dc7\uadb8\u936f\u95c5\u6566\u835a\u55d0\u8300\u5310\ube6a\u6b84\u41ed\u871d\ub80f\u4ddf\u07fc\ud078\u5f88\ua113\uacf4\u68a1\u9d9e\u4ac4\u4947\u32fd\u744a", "\udb9b\uddf2\ud981\udd8d",
        -5, 55388, -1336351913, 8318900808525402519L, -70524L, true, true, (char) 19323, (char) 47193,
        Double.longBitsToDouble(0x3fd6decc45f4132cL), Double.longBitsToDouble(0x3fec5daca6b1fa89L)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 1, 6, "\ud8a6\udce3\udb3e\udd4f\ud850\udf50\uda30\udd92P\ud90a\udf2d\ud8bf\udcdb\ud9ce\udd59\uca6d\u4839\udaad\ude81\u00df\ud97b\udf5cS", "\ud57d", "\u4985\udb5d\udc8f\ud902\udfeb\udb51\udca7\ud883\ude06\uda1c\ude37\ud8a5\udd97\ud812\udfda\ud9c7\udfc2\ud91e\udfab\uda7e\udd31\ud902\udc45\ud96a\udebc\ud99d\uddf8\ud8dd\uddc4\udb55\udcf3\ud954\udfd1\udbdd\udefd\ud936\udc84\ud893\udf38\ubb5c\udab4\udd77\ud82b\udeb9",
        25, 16200, -1312105336, 4773238493341382750L, 61100L, false, true, (char) 42891, (char) 61020,
        Double.longBitsToDouble(0x3fe9b634b3acd181L), Double.longBitsToDouble(0x3fe8a13f029afb62L)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "\000\udb9d\udd13\ud850\udf52", "\u3334\u7b8ch\u4371\u3be6\u0731\u2f7f\u47db\u803f\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\ub970\ucfc4\u31fa\u876f\u388a\u723aW\u1944\u00af\ud228\u5124\u64bc\u2471\u419f\u1e30\u1776\u4017\u94f1\u6e34\u3c08\u8c52\u71d9\u8421\ub753\u9ed7\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud95b\ude5c\uda68\udd1d\u9d11\ud940\ude55\ud8a1\udc44\ud8fc\uddc8\uda9b\udeb1\udacd\udc49\ud9ba\udf6f\ud985\udda7\uda48\udee6\ud8c5\udcb3\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 41630, -1331860020, -642982818519883979L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "w\udb9d\udd13\ud850\udf52", "\u33e1\u7b8cg\u1b70\u3be6\u0731\uad6e\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u08e4\u8bfe\u6ec3\u876f\u388a\u67e9\u5480\ud642\u00b5\ud228\u7840\u3a21\u2471\u4417\u6aadg\u3f2f\u94f1\u6e34\u3c08\uae52\u71d9\u8421\ub753\u68bb\u84e7\u3a94C\u0885", "\ud87f\udfa3\uda37\udd43\udb71\udf1e\udb80\udef9\ud95b\ude5c\uda0c\udc6e\ud800\udd44\ud82a\udce0\ud8ff\uded7\udbd2\ude71\udbab\uddfe\ud9ba\udf30\ud903\ude2f\ud985\udda7\udb53\udcd5\udb9f\udc78\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\u922c\ud933\udfe8\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 86565, -1331860020, -642982814969677771L, -99998L, false, true, (char) 7710, (char) 3569,
        Double.longBitsToDouble(0x3feb20f2796e66c6L), Double.longBitsToDouble(0x3fd96e9eff284a1eL)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 0, "\ud9e0\udf0a\udb52\ude27\uda3b\udef0\ud976\udca0\uda28\udef2\ud90b\udc0d\udb84\ude21\udbd1\udf15\uda28\udce9\ud845\ude84\udaae\udd11\ud990\udf76\uda3e\udcba\ud92d\udfb6\ud85c\udd35\ud9e2\udf2e\udb3c\udc89\ud83a\uded1\udaba\uddd3\udae4\ude10\udb78\udd7f\uda21\uddd9\udb36\udcac\udb2f\udd0d\ud818\ude4f\uda45\udd2f\u1f28\uda35\udfce\udb04\ude6e\udab3\udd88\ud8df\ude1f\uda4a\udeb6\udb37\udfbe\uda67\udc1c\udadc\udd3a\ud9e5\ude30\ud981\udc91\ud96a\udd75\ud83b\udd30\uda78\udfb3\ud9c4\udfd4\ud935\udd98\uda5e\ude9b\uda0c\udd46\ud8e0\udc45\udaf7\ude80\udac0\udc8f\udbb2\udf49\ud908\udc9f", "\u3a94C\u0885\u012b\u7a64\u5872\ua931\u63d3\u2a90\u52ed\u61ce\u4875\u8ee1\u61cf\ua8ab\u7021\uc324\u0aec\u95e8\ua654\ub3b9\u4efd\u2da8\u471c\ua9d8\u09e7", "\udb42\udec2\ud93d\ude07\udaa2\udcb1\udaab\udf64\ud941\ude71\ud933\udd4e\ud8fd\udce4\ud940\udd1e\ud95e\ude02\ud857\udd38\ud9c6\udeb6\uda2a\ude88\udaad\udfd1\ud88d\udcf9\ud8fc\udd9e\ud9f1\udd72\ud852\udc21\ud83d\udfc5\uda75\uddcb\udb83\udcf3\ud817\udc16\uda87\uddc0\u60de\ud98d\ude9a\ud996\udf56\ud96a\udd10\ud85f\udf40\ud92a\udf6a\ud85a\udee0\udbe7\udfec\udbc6\udd12\uda37\udde6\ud83b\udf21\ud926\udd12\udb06\udebe\ud81a\uddfd\udb78\udc62\udbb9\ude9c\uda3d\udea8\udabd\udfd3",
        21, 58480, -1457202379, 2087627540426082731L, 30207L, false, true, (char) 25504, (char) 37652,
        Double.longBitsToDouble(0x3fd0180a79842d72L), Double.longBitsToDouble(0x3fe041052d75c3b1L)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=[B:[[0, 63, 63]]\012",
        Z.run(T, 2, 2, 8, 13, "\000\udb9d\udd13\ud850\udf52", "\u3a3fGh", "\udaae\udd11\udaba\udf90\uda3e\udccb\ud92d\udfb6\ud85c\ude35\ud9e2\udf2e\udb3c\udc89\ud83a\uded1\uda91\uddd3\udae4\ude10\udb78\udd7f\ud83e\udcc8\udb0b\udf71\ud80b\udcc4",
        38, 22211, -1372202827, 3685403373726588960L, 36530L, false, false, (char) 52011, (char) 22722,
        Double.longBitsToDouble(0x3fb32bb5c81c4098L), Double.longBitsToDouble(0x3fc7800380000000L)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "w\uda9b\udd12\udbb3\udc00", "\u1834\ub1e3y\u1b70\u3be6\u0731\uad6e\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua878\u4742\uadbc\u8bfe\u6ec3\u876f\u388a\u67e9\u5480\ud642e\ud228\u78c8\u3a21\u2471\u4417\u2029\ubb14", "\udb7a\udd3d\ud8e0\udc45\udaf7\ude80\udac0\udc8f\udbb2\udf49\ud908\udc9f\u64e2\udbf4\udcf7\ud8f8\ude5a\ud89c\uddc4\ud8cb\udd49\udad5\udc47\ud9bc\udf80\ud9c5\udfa6",
        13, 65443, 1781394616, -3880713864040306555L, -15747L, true, true, (char) 55225, (char) 3287,
        Double.longBitsToDouble(0x3fab880d65baab90L), Double.longBitsToDouble(0x3fda4fd1a5540072L)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 1, 7, "\ufb00", "\u3512\000\u4f14\u0a14\u97cc\u3c11\u726a\u0653\u2f7f\u2683", "\ud921\udc41",
        -5, -1000, 0, -1049427968L, 53465L, true, true, (char) 36464, (char) 62165,
        Double.longBitsToDouble(0x3fdb79ddc0ef546aL), Double.longBitsToDouble(0x3fe719d0f7f88e6bL)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 1, 6, "\ud8cc\udc9f\ud867\udca8\ud9ff\udf92\uda30\udd92P\ud90a\udf2d\udb05\udfea\ud8a4\udf08\ud823\udf50\u4839\ud957\uddf7p\ud94d\udc32\u1657", "\ub862", "\u4985\udb5d\udc8f\ud902\udfeb\udb51\udca7\udbb7\udd01\udaf2\udd3e\ud8a5\uddb6\uccda\udb3c\udc0e\ud91e\udf93\uda7e\udd31\ud902\udc45\ud96a\udebc\ud99d\uddf8\ud8dd\uddc4\udb55\udcf3\ud954\udfd1\udbdd\udefd\ud966\udc7c\ud893\udf38\ud907\udd68\udab4\udd5f\ud82b\udeb9\udbba\uddb9\uda0a\uddd1\ud83f\udfec\ud9bd\udf9f\udb19\udd7f\ud930\uddbb\ud923\uddab\udb0c\udf1a\ud9db\udf08\udb43\udd84",
        32, 86860, 23206676, 274502535144289540L, 52737L, false, true, (char) 22475, (char) 3807,
        Double.longBitsToDouble(0x3fe4e13c692248abL), Double.longBitsToDouble(0x3fd81ebade081ddcL)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 3, "w\udb9d\udd13\ud850\udf52", "\u33e1\u571bg\u1b70\u3be6\u0731\u67cd\u1e6c\u10f0\uc635\u86fe\u745a\u795d\u1459\u0095\u4d60\ub52e\u84b0\ua902\uc35d\u5f41\ua4e3\ubfba\u91b7\u388a\u67e9\ub146\u4c30Z\ud228\u7840\u3a21\u5946\u4417\u6aadg\u5ac7\u226f\u6e34\u3c08\uae52\ubc5e\u0b4a\ub753\u68bb\u84e7\u9630\uc7d3\u0885", "\ud9fe\udc63\uda2b\udf1b\udb7e\ude0c\ud8d4\udd04\ud902\udf85\uda0c\udc6e\ud800\udd44\ud82a\udce0\ud9b4\udd04\uda8c\udf3e\uda9b\udcdf\udb32\udcf1\ud903\ude78\ud985\udda7\udb53\udcd5\udb9f\udc78\uda19\uddcd\udb49\udd4d\ud815\udf86\udbcd\ude66\udb98\udf46\udb4d\udd14\uda40\udd9d\udb48\udd4a\ud941\udd05\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 86565, -1331860031, -642982814969677771L, -99998L, false, true, (char) 7710, (char) 42224,
        Double.longBitsToDouble(0x3feb20f2796e66c6L), Double.longBitsToDouble(0x3fd96e9eff284a1eL)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 0, "\ud9e0\udf0a\udb52\ude27\uda3b\udef0\ud976\udca0\uda28\udef2\ud90b\udc0d\udb84\ude21\udbd1\udf15\uda28\udce9\ud845\ude84\udaae\udd11\ud990\udf76\uda3e\udcba\ud92d\udfb6\ud85c\udd35\ud9e2\udf2e\udb3c\udc89\ud83a\uded1\udaba\uddd3\udae4\ude10\udb78\udd7f\uda21\uddd9\udb36\udcac\udb2f\udd0d\ud818\ude4f\uda45\udd2f\u1f28\uda35\udfce\udb04\ude6e\udab3\udd88\ud8df\ude1f\uda4a\udeb6\udb37\udfbe\uda67\udc1c\udadc\udd3a\ud9e5\ude30\ud981\udc91\udb32\udf39\ud83b\udd30\uda78\udfb3\ud9c4\udfd4\ud935\udd98\uda5e\ude9b\uda0c\udd46\ud8e0\udc45\udaf7\ude80\udac0\udc8f\udbb2\udf49\ud908\udc9f", "\u3a94C\u0885\u012b\u7a64\u5872\ua931\u63d3\u2a90\u52ed\u61ce\u8993\u8ee1\u61cf\ua8ab\u7021\uc324\u0aec\u95e8\ua654\ub3b9\u4efd\u2da8\u471c\ua9d8\u09e7\ua8ee\u0e2a\u2082\u5fbf\ub5a5\u20c9", "\ud8fd\udce4",
        50, 75897, 1426929717, 2891918274446192386L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fd529a20b5f86eaL)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 6, "\000\udb9d\udd13\ud850\udf52", "\u3a3fGh", "\udaae\udd11\udaba\udf90\uda3e\udccb",
        1, 41539, 1312370547, -3850538443674704215L, 75605L, false, true, (char) 6772, (char) 967,
        Double.longBitsToDouble(0x3fe3567f6fb227e8L), Double.longBitsToDouble(0x3febdd24c8679bcaL)));
  }
  @Test(timeout = 4000)
  public void test177() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=[B:[[63, 63, 63, 63]]\012",
        Z.run(T, 2, 2, 8, 17, "\ub136\udb9d\udcfd\ud850\udf52\udb31\ude9e", "Gh\u4371\u3be6\u0731\u0774\u5e5f\u1958\uc735\u86fe\u9068\u795d\u4858\u13c3\u6af0\u1343\u9b65\u61b6\uc35d\u54b6\ucfc4\ub090\u8787\ua536\u0a9d\u00f2\u1944\u00af\u72b4\u2787\u3dd1\ub69d\u5ce1\ub144\u3375\ucfbf\u5a25", "\ud26b\ud827\udf61\u1500\uda15\udfd7\udb8a\udec0",
        2, 35681, 233062632, 2973612509253897329L, -72738L, true, false, (char) 40179, (char) 55958,
        Double.longBitsToDouble(0x3fe0e4515218e319L), Double.longBitsToDouble(0x3fd5255a594f19acL)));
  }
  @Test(timeout = 4000)
  public void test178() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 12, "\ub136\udb9d\udcfd\ud850\udf52\udb31\ude9e", "Gh\u4371\u3be6\u0731\u0774\u5e5f\u1958\uc735\u86fe\u9068\u795d\u4858\u143e\u6af0\u1343\u9b65\u61b6\uc35d\u54b6\ucfc4\u65bb\u4625\ua58d\u0a9d\u00f2\uce98\u9433\u72b4\u2787\u3dd1\ub69d\u1a87\u1f16\u3375\ucfbf\u5a25", "\ud26b\ud827\udf61\u1500\uda21\udfe8\ud9c2\udeae",
        49, 35681, 233062632, 2973612509253897329L, -72738L, true, false, (char) 40179, (char) 36643,
        Double.longBitsToDouble(0x3fe4c7f75a18e319L), Double.longBitsToDouble(0x3fd5255a594f19acL)));
  }
  @Test(timeout = 4000)
  public void test179() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 1, 1, 14, "\ud8a6\udce3", "\u93d0w\u3301\u88ffz\000\ud2b5", "\000/\000\uda92\udc71\udb3c\udc89\ud942\udccb\uda9b\ude90\u9077\ud83d\udc8e",
        40, 77064, 1321254509, 573844394752L, -4512L, true, true, (char) 24565, (char) 7540,
        Double.longBitsToDouble(0x3fc5a04a7450fd18L), Double.longBitsToDouble(0x3fc497c65fb3d758L)));
  }
  @Test(timeout = 4000)
  public void test180() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 1, 2, "\000", "r\u17aa\u9ea1\u5f26\ubde2\u1fc7\ud2b5\u7068\u2f7f\u2683\uce3b\u50eb\000\u86fau\000\000\ub801", "\ud842\udfff\ud884\udf26\ud838\uddbf\udbd2\ude3d\ud9f7\ude9d\ud9e3\udf59\ud983\udc42\udbf0\udc2d",
        15, 17829, -607091136, -635385687992703772L, 8419L, true, false, (char) 43336, (char) 24767,
        Double.longBitsToDouble(0x3fe9b3e06369a298L), Double.longBitsToDouble(0x3fc48d7777ed869cL)));
  }
  @Test(timeout = 4000)
  public void test181() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "w\udb9d\udd13\ud850\udf52", "\u33e1\u7b8cg\u1b70\u3be6\u0731\uad6e\u5e5f\u948a\uc635\u86fe\u745a\u795d\u1459\u0095\u4d0b\u7d73\u84b0\ua902\uc35d\u08e4\u8bfe\u6ec3\u876f\u388a\u67e9\ucb04\u4e40X\ud228\u7840\u3a21\u2471\u4417\u6aad\u1776\u4017\u94f1\u6e34\u3c08\uae52\u71d9\u8421\ub753\u68bb\u84e7\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud95b\ude5c\uda0c\udc6e\ud800\udd44\ud82a\udce0\ud8ff\uded7\ud884\uddea\udbab\uddfe\ud9ba\udf30\ud903\ude2f\ud985\udda7\udb53\udcd5\udb9f\udc78\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\u922c\ud933\udfe8\udac6\udd66\udb42\udec2\ud93d\ude07\udaa2\udcb1\udbf3\ude67\udb90\ude6f",
        43, 86565, -1331860020, -642982814969677771L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e0217cf35L), Double.longBitsToDouble(0x3fdea9a2056c3b06L)));
  }
  @Test(timeout = 4000)
  public void test182() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 17, 17, 10, "\udb02\udd2d\udb0b\udc25\ud850\udebb\uda6b\ude18\ud810\ude1e\ud851\udcc3\udb65\udfd5\ud9a2\udcfe\ud945\udd93\uda62\udc5c", "gX\000", "\uda52\uded5\udb80\uddb2\ud82b\udd03\uda5a\udd57\udb6a\udf3c\ud97a\udf47\udb2f\udd0d\ubfbb\u6454\ud929\udcf8\ud927\uded9\uda95\udd0b\uda72\udded\ud8ec\udd01\udba9\udcd8",
        46, 58110, -471213247, -6011374495667308593L, -97235L, true, true, (char) 26163, (char) 43993,
        Double.longBitsToDouble(0x3fde8fbd98e00948L), Double.longBitsToDouble(0x3fd0c648447d79a8L)));
  }
  @Test(timeout = 4000)
  public void test183() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=[B:[[0, -15, -77, -124, -84, -15, -101, -71, -80]]\012",
        Z.run(T, 2, 2, 12, 2, "\000\ud98c\udd2c\ud92f\ude70", "\ubc25Yh\u4371\u3be6\u0731\u2f7f\u5e5f\u28aa\uc68f\u2c09\u2705\u8813\u319e\u0095\u4d0b\u57c1\u350f\ua84b\uc35d\uba64", "\udb04\ude6e\udab3\udd88\ud844\udc11\u00f2\udad6\ude3c\uda66\udf3d\udadc\udd3a\ud97c\udc41",
        43, 81632, -1685538, 2418262116324313616L, 96229L, false, false, (char) 7396, (char) 10774,
        Double.longBitsToDouble(0x3fe283d824f5d143L), Double.longBitsToDouble(0x3fc4eeea369b9ea4L)));
  }
  @Test(timeout = 4000)
  public void test184() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 1, 1, 14, "\ud8a6\udce3", "\u93d0w\u3301\u88ffz\000\u5a52\u5adb\u3382\u4d0e", "\uda92\udc71\udb3c\udc89",
        34, 43329, 36983, -4899915775849399722L, -63795L, false, false, (char) 37631, (char) 29823,
        Double.longBitsToDouble(0x3fb5eb8d40000000L), Double.longBitsToDouble(0x3fd04a0ff0016800L)));
  }
  @Test(timeout = 4000)
  public void test185() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:true |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 2, 2, "\000\ud98c\udd2c\ud964\udf70", "\ubc25Yh\u4371\u3be6\u0731\u2efa\u5e5f\u28aa\uc68f\u2c09\u2705\u8813\u319e\u0095\u4d0b\u8133\u350f\ua84b\uc35d\uba64", "\udb04\ude88\udab3\udd88\ud844\udc11\u00f2\udad6\ude3c\uda66\udf3d\ud947\udd0f\ud8fd\ude68",
        43, 81632, 1121983336, 2418379566499990032L, 68765L, false, true, (char) 32954, (char) 49051,
        Double.longBitsToDouble(0x3fe283d827f5d143L), Double.longBitsToDouble(0x3fe966a755a6e777L)));
  }
  @Test(timeout = 4000)
  public void test186() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 3, 6, "\udad6\ude83\udb05\ude5d\ud850\udea6", "\u3334\u7b8cg\u4371\u3be6\u0731\u2f7f\u5e5f\u948a\uc635\u86fe\u745a\u41b2\ucddd\u6fa4\ud2a6\u7d73\u84b0\ua902\uac0f\ud116\ucfc4\u31fa\ub937\u3953\u67e9\u00f2\u44d1jL\000\u64bc\u2471\u419f\u1e30\ucf75\u0160\u94f1\u6e34\u3c08\u8c52\u1a6a\u8421\u4712\u68bb\ub7b2\u3a94C\u0885", "\ud9c5\udfa6\uda37\udd43\udb71\udf1e\udb80\udef9\ud8df\udf20\ud8bc\udfb5\ud9eb\udca6\udbd9\udc26\u666a\ud8d8\udcf4\udac6\udd0f\ud9d4\udc96\udac4\udfad\ud985\uddfd\uda48\udee6\udadf\udf3f\ud97f\udee2\uda28\udee8\ud87a\uddfd\udbcd\uddfb\udb06\udfdd\uda37\udc34\udac6\udd66\udb42\udec2\ud936\udfc3\udaa2\udcb1\udaab\udf64\ud941\ude71",
        37, 86565, -1331860020, -642982350368417739L, 49348L, false, true, (char) 24454, (char) 15523,
        Double.longBitsToDouble(0x3feea70e02172c35L), Double.longBitsToDouble(0x3fd529a2075f86eaL)));
  }
  @Test(timeout = 4000)
  public void test187() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 1, 2, 0, 0, "\udba4\udc64\ud951\udfff\uda71\udc7a", "Z\u02f6\ubde2\ua390\ud2b5\ube80\u7652w", "\ud9bf\udc40\udb3c\udc89\ud8f7\ude88\000\ud8d6\udf2b\ud983\uddb0\ud967\udfa5\ud918\udf54\ud926\udfa0\ud978\udfff\ud895\udd93\ud812\udfe3\udb87\ude47\udb59\ude4c\ud8ea\udecd",
        34, 15625, -1615756136, 8472037313447214156L, -54315L, false, false, (char) 15492, (char) 5863,
        Double.longBitsToDouble(0x3f3b67689d980000L), Double.longBitsToDouble(0x3fe0c85c1fafb8edL)));
  }
  @Test(timeout = 4000)
  public void test188() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\012",
        Z.run(T, 2, 2, 17, 6, "C\udb9d\uddd0\ud850\udf52", "\u33e1\u7b8cg\u1b70\u8522\u0780\uacc0\u5e5f\u948a\uc635\u86fe\u745a\u795d\ucea3\u6b37\u4c98\ub18d\u1920\ua902\uc35d\u7f0a\u35d3\ub88a\u881b\u388a\u67e9\u5480\ud642\u00b5\ud228\u7840\u3a21\u2471\u4417\u6aad\u1776\u4017\u2ca5\u6ef9\uc402\uae52\u6ef7\u3a41\ub753\u68bb\u84e7\u9378C\u0885", "\uda6d\udca4\udba0\ude07\udb71\udf1e\udb80\udef9\ud95b\ude5c\uda0c\udc6e\ud800\udd44\ud82a\udce0\ud8ff\uded7\ud884\uddea\udbab\uddfe\ud9ba\udf30\ud903\ude2f\udbbd\udca7\udbee\udcf5\u215b\ud9bf\ude79\udbb2\ude29\ud875\udf87\uda65\udce4\u922c\ud933\udfe8\udac6\udd66\udb42\udec2\ud93d\ude07\ud888\udcdf\uda95\ude69\ud92c\udeb7",
        23, 86565, -1331860020, -580608843175872459L, 12796L, false, true, (char) 63939, (char) 29266,
        Double.longBitsToDouble(0x3fe1a70e0217cf35L), Double.longBitsToDouble(0x3fd529a20d4786eaL)));
  }
  @Test(timeout = 4000)
  public void test189() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.language.DoubleMetaphone:@?\0121=[B:[[63, 63, 63]]\012",
        Z.run(T, 2, 2, 8, 13, "\u1903\udb9d\udd13\udbd8\udf56", "\u3a3fGI", "\ud9dc\ude3d\udb18\udc72\uda3e\udccb\ud92d\udfb6\ud85c\ude35\ud9e2\udf2e\udb3c\udc89\ud8df\udde3\ud95e\udf59\udb47\udc18\udaa7\uded5\ud83e\udd11\udb0b\udf71\ud80b\udcc4",
        38, 22211, -1191782219, -7866760811893725851L, 36456L, false, false, (char) 52011, (char) 22722,
        Double.longBitsToDouble(0x3f90d5d7f4510260L), Double.longBitsToDouble(0x3fc7800380000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.StringUtils|equals|java.lang.CharSequence,java.lang.CharSequence|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|isDoubleMetaphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|isDoubleMetaphoneEqual|java.lang.String,java.lang.String,boolean|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.binary.CharSequenceUtils|regionMatches|java.lang.CharSequence,boolean,int,java.lang.CharSequence,int,int|static",
    "C|org.apache.commons.codec.binary.CharSequenceUtils|<init>|",
    "M|org.apache.commons.codec.binary.StringUtils|getBytes|java.lang.String,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesIso8859_1|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUnchecked|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUsAscii|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Be|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Le|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf8|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|newIllegalStateException|java.lang.String,java.io.UnsupportedEncodingException|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|equals|java.lang.CharSequence,java.lang.CharSequence|static",
    "M|org.apache.commons.codec.language.DoubleMetaphone|isDoubleMetaphoneEqual|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.DoubleMetaphone:",
    "M|org.apache.commons.codec.language.DoubleMetaphone|isDoubleMetaphoneEqual|java.lang.String,java.lang.String,boolean|new:org.apache.commons.codec.language.DoubleMetaphone:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
