package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base64_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:0 |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]]\012",
        Z.run(T, 2, 9, 10, 15, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u090d\uc142", "\ud85e\udfb6\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud8bc\udd44", "\u2bee\u9821\uc634\uc2d7\u072b\u2730\u3f47\u1886\u8622\u8528\u1482\u220b\ub47d\ubffe\uaee6\u0e93\ub4e8\u7319\u0f67\u90f8\u7ecb\u51d9\u1869\u29df\ua3cc\u31b9\u9901\u3992\u232f\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u66cc", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\uda69\udffd\ud832\udc41\ud85f\udd9b\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, -490, 569859467, -902193739489028469L, 16927L, false, false, (char) 48902, (char) 21916,
        Double.longBitsToDouble(0x3fd9f8dc03cd08e6L), Double.longBitsToDouble(0x3fe4b713bbb4de9eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47", "\udb23\udde6\u8f37\uf966",
        56, 40363, -1283489877, 8122238676550811886L, 55409L, false, false, (char) 46527, (char) 3475,
        Double.longBitsToDouble(0x3fce469c95de5bb0L), Double.longBitsToDouble(0x3fc7ea7995cbf6a8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[-116, 20]] |a0=[B:[[-116, 20]]\012",
        Z.run(T, 2, 9, 11, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud8bc\udd44", "\u3314\u5004", "\ud801\udde8\udbd6\udf91\uda78\udfc4\ub0c1\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad",
        20, 90734, 560362457, 2720174358542292712L, -99230L, true, true, (char) 10357, (char) 204,
        Double.longBitsToDouble(0x3fe3b94f64bf53dfL), Double.longBitsToDouble(0x3fd7218105818038L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-116, 20, 90, -66]]\0121=[B:[[]] |a0=[B:[[-116, 20, 90, -66]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 3, 4, 8, "\ud8bc\udd44\uda8a\udeee", "\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\u8958\u1c49\uaee6\u0845\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df", "\udb3b\udde3",
        29, 2548, -2068196373, -6201606259811548709L, -15557L, true, true, (char) 59153, (char) 30724,
        Double.longBitsToDouble(0x3fcf93ad56466458L), Double.longBitsToDouble(0x3fe3f8c10d90df63L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[85, -114]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 5, 3, "\ud885\udfbe", "\u3314", "\ud97e\udede\ud845\udcea\udb39\ude6d\uda12\udfc3\udaae\udfbc\ud9aa\udeb3\udab2\udc8d\ud986\udd4c\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud925\udd1c\ud99a\udcc3\ud88d\udc46\ud929\uded3\udb86\udfab\ud9a9\udee8\ud878\udd5d",
        19, 33647, -1071880846, -5942549460495008557L, 19787L, true, true, (char) 62534, (char) 11511,
        Double.longBitsToDouble(0x3fddb7ae1283c21aL), Double.longBitsToDouble(0x3fe446dbe1f6ee52L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 16, "\ud8bc\udd44\uda8a\udeee", "\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df", "\udb3b\udde3",
        29, 2548, -2068196373, -809671603159826557L, -15557L, true, true, (char) 33284, (char) 61512,
        Double.longBitsToDouble(0x3fcf93af56466458L), Double.longBitsToDouble(0x3fe3f8c10d90df63L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud8bc\udd44", "\u0a41\u1807\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u9fc4\u6fef\ub47d\ubffe\uaee6\u9c52\u5943\u9024\u0f4f\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u2c69\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\ubb6f", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59",
        56, 31127, -538552660, -5722430511121041557L, -17585L, false, false, (char) 56691, (char) 15809,
        Double.longBitsToDouble(0x3fd66ff3973bcdc0L), Double.longBitsToDouble(0x3fec990fbc419865L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 4, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u9f94\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u8ad9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\u0ae1\uaf80\u34ce\u9d30\u9f02\u7a2a", "\udb3b\udc40\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\ud93a\udce4\ud8de\udf5c\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 1871365277, -7465345746322082751L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u4db8", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a",
        55, 59264, 594838531, -55984602772122266L, 15603L, true, false, (char) 43790, (char) 16353,
        Double.longBitsToDouble(0x3feb63eb58bf17f1L), Double.longBitsToDouble(0x3fc1100bb0b74b64L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 13, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u1b10\u3116\u1482\u21df\ub47d\u3d9c\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\uda53\udf45\udb65\udcd8\udb36\uddf0\uda81\ude32\ud80e\udf92\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -94925L, true, false, (char) 17247, (char) 50777,
        Double.longBitsToDouble(0x3fdae3689d35c23cL), Double.longBitsToDouble(0x3feb3f278e3c0c1dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u7d8c\u2730\u3f47\u3504\ubc1e\u2679\u1482\uc41b\ub472\ubf87\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ua7e1\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u46f8\u8c0d\ub9ab\u4d83\u024b\u4872\u0b00\u4a8b\u7a2a", "\uda0f\udc38\udbb4\udd2e\ud82f\udce6\ud936\udda9\u7e01\udbf2\udfe1\ud8de\udf59\ud832\udc41\udab0\udde4\udacd\udc8a\ud8ef\udd5b\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\udb62\udc17\ud973\udf47\udb8f\ude19\ud8f0\ude41\udbde\udfea\ud983\udd9d\udbf9\udd77\ud8b2\udd03\ud90c\udd38\ud85f\udd80\ud955\udcd3\ud9a6\udd39\udb39\uddde\ud8ff\udf94\ud968\ude37\ud81d\ude57",
        20, 80419, -1629070975, 3600865331171752069L, -3218L, true, false, (char) 48201, (char) 56453,
        Double.longBitsToDouble(0x3fcc956cb0470308L), Double.longBitsToDouble(0x3fd9d4cfe634eb96L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 1, 3, "\ud8bc\udd44", "\u3314\u4ffb\ud099\ua5bb\u8c3e\u5866\u04f3\u4474\u8711\uc8f7\u8e3d\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u696d\u893d\u61da\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc3d\udbbe\udc4d\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c",
        25, 33821, -725223573, 1474491710359715554L, -17585L, false, false, (char) 56691, (char) 15809,
        Double.longBitsToDouble(0x3fd66ff3973bcdc0L), Double.longBitsToDouble(0x3fec990fbc419865L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-9, -23]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 7, 8, "\udb27\udf19", "\u2a71\u5004\u7301\u4039\u8c2f\u2730\u3f47", "\udb23\udde6\ud99f\udcd4\ud8fc\uddf5",
        16, 41991, -1753470266, 2406738427354546219L, -85328L, false, false, (char) 37474, (char) 10357,
        Double.longBitsToDouble(0x3fce407b59de5bb0L), Double.longBitsToDouble(0x3fc7ea7bf5c86040L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 9, 5, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u63c8\000\000\000\u02ab\ub47d\ubffe\uaee6\u0b6f\u790e\u7319\u783f\u90f8\ubf16\u51d9\ube0a\u3a5f\uc471\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub008\ucc51\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc3d\ud97c\udd32\uffbf\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\ude9f\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -100000L, false, true, (char) 57519, (char) 12381,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 13, 5, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud9b4\udf38\udb77\udf90\udbe9\udedb\ud8c2\udd45\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\udbea\udca1\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\ud957\udf9e",
        34, 11454, -1708198682, -7465346004020120511L, -54460L, false, true, (char) 1759, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]]\012",
        Z.run(T, 2, 9, 9, 6, "\ue276", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\u1a12\uaee6\ub1c4\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u59f4\u7f75\u2488\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u0e0f\u7194\u9d30\u9f02\u8a24", "\ud875\udc3d\ud97c\udd32\udac8\udfe2\udb60\udf5e\ud8f2\udfdf\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\uda41\udf21\u86d8\uda8d\udfcc\ud973\udf75\udb07\udd55",
        17, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.lang.Boolean:false |a0=[B:[[-116, 20]]\012",
        Z.run(T, 2, 6, 3, 14, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\u9996\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42", "\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d", "\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1\ud929\uded3\udb86\udfab\ud85f\udd82\udb1b\udec0\uda57\udcf0\ud806\udc33\ud852\uddae\udb3b\udde3\udb31\udf5b\udaaa\udc10\ud8ad\udca7\ud9cb\udf4d\ud840\udfa2\udb45\udf4f\ud82e\udc08\ud85f\udf1a\ud915\udd7d",
        10, 94036, 404845969, -2349851514812789360L, -94183L, true, true, (char) 10607, (char) 47019,
        Double.longBitsToDouble(0x3feb5d84aa66d4c5L), Double.longBitsToDouble(0x3fe710a3b149fc3fL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[B:[[106, 66, 81, 61]] |a0=[B:[[-116, 20]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.math.BigInteger:0 |a0=[B:[[-116, 20]]\012",
        Z.run(T, 2, 12, 10, 3, "\ud8bc\udd44", "\u3314\u5004\u361e\u6492\uc1ba\u2730\u3f47", "\udb23\udde6\ud99f\udcd4\ud8fc\uddf5",
        30, 1275, -1753470266, 2406738427354546219L, 55409L, false, false, (char) 37474, (char) 10357,
        Double.longBitsToDouble(0x3fce407b59de5bb0L), Double.longBitsToDouble(0x3fc7ea7bf5c86040L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[97, 94]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 2, 4, 11, "\udb91\udf8e", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\u1e77\ubffe\u268f\u4d49\ua95e\ub2cb\u0f67\u90f8\ubf16\u51d9\u1869\u37df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\ua4c5\u0e40\u0e1f\u4e8b\u7194\u9d30\u9f02\u718e", "\ud875\udc3d\ud925\udf50\ud82f\udce6\uda7d\udc8d\uda20\udde5\udbf3\udc2a\ud8de\udf59\ud832\udc41\udb6c\ude02",
        25, 33821, -725223573, 1474491710359715554L, -17585L, false, false, (char) 56691, (char) 17089,
        Double.longBitsToDouble(0x3fd66ff9873bcdc0L), Double.longBitsToDouble(0x3fec990fbc419865L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[B:[[]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 1, 3, "\ud8a9\udc44", "\u3314\u5004\000", "\ud949\udd28\udb7f\udfba",
        52, 58033, -1679440947, -7186193915427828224L, 31072L, true, false, (char) 15528, (char) 24825,
        Double.longBitsToDouble(0x3fcfd766ac1e5d6cL), Double.longBitsToDouble(0x3ea6cf2030000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 0, "\ud81a\udf5d\uda7e\udd83\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ub10d\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1\ud929\uded3", "\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02", "\u9a51",
        32, 85344, -72172249, 6798233616618994470L, -1626L, true, true, (char) 14885, (char) 10607,
        Double.longBitsToDouble(0x3fee2eff376bb095L), Double.longBitsToDouble(0x3fe336a62ee21476L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 4, "\udb4b\udd0b\udbe9\ude02\udbaa\udc98\ud9bf\uddd3", "\u4039\ub21b\u4ef1\u92dc\u2ddc\uadfc\u3c2d\u855e\u21df\ub47d\ubffe\u12e7\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\ud262\u1869", "\ud852\uddae\udbed\ude1c\udb1a\ude81\udaaa\udc10\ud8ad\udca7\ud9cb\udf4d\udb7b\uded9\ud98c\udeb8\ud879\udf05\ud85f\udfab\ud915\udd7d\uda63\udc27\ud894\uddc1\uda2a\udc02\udae0\uddab\ud88f\udfeb\ud874\udffb\ud9d5\udc1c\uda0f\udeca\ud92f\udd9f\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75",
        -4, 94069, -1193257626, -2486100748253343310L, -29492L, true, false, (char) 45285, (char) 48902,
        Double.longBitsToDouble(0x3f99d583b3f1b800L), Double.longBitsToDouble(0x3fde68473d06c66eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud94e\ude9e\uda8a\uded4\udbb1\udd1b\ud910\ude7b\udbc3\uded5\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ub10d\ud8ba\udd7c\ud988\udfc8\ud99f\udc41\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud97e\udf60\uda2f\udc91\udba1\ude27\ue4dc\ud88d\udce1\ud929\uded3\udb86\udfab\ud85f\udd82\udb1b\udec0\ud946\udf68\uda88\ude06\ud8a0\uddcb\udb3b\udde3\udb31\udf5b", "\u9aa5\u8b96\ub9ab\u8acc\ua13d\u7194\u9d30\u9f02\u7a2a\u67d8\ud371\ub09c", "\ud92c\udf04\ud987\udd31\udbf2\udfc0\ud8de\udf59\u474c\ud9e1\udc7c\udacd\udcc7\udb98\udf16\ud9a5\udffe\udac6\udf9a\ud97f\udea9\ud819\ude1a\ud886\ude8a\ud973\udf75\udb8f\ude19\ud8f0\ude41\udbde\udfea\ud983\udd9d\udbf9\udd77\ud8b2\udd03\ud90c\udd38\ud85f\udd80\ud899\udcd5\ud9a6\udd39\udb39\uddde\ue9ac\ud968\udd5d\ud81d\ude57\ud866\udfb1\udabc\udd9c\uda26\ude87\udbbe\udd7d\u8046\ud99c\ude10\ud9b8\udd44",
        54, 71444, 469665419, 4618854353417325692L, -6961L, true, false, (char) 11607, (char) 46952,
        Double.longBitsToDouble(0x3fd628fe89d4094aL), Double.longBitsToDouble(0x3fe1902cf94bc802L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[106, 66, 82, 97, 118, 111, 72, 114, 106, 54, 77, 61]] |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 12, 3, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede", "\u3f47\u0bc9\u8622\u8528", "\uda6c\udfad",
        20, 44582, 560362483, 2720174358542292709L, -99230L, true, true, (char) 58200, (char) 204,
        Double.longBitsToDouble(0x3fe3bcb764bf53dfL), Double.longBitsToDouble(0x3fd7218105818038L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[B:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 16, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\uccda\u839e\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\ud908\udf12\udbf3\udc87\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-116, 20]]\0121=java.math.BigInteger:0 |a0=[B:[[-116, 20]]\012",
        Z.run(T, 2, 8, 10, 3, "\ud8bc\udd44", "\u3314\u6d04\u7301\u4039\u8c2f\u7e9f\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\ud8e0\udf1a\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\ud07b\udb98\udf1c\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 2, "\ud85c\udf47\udb79\udf00\udb26\udf5c\ud849\udc2b\ud86d\udf1b\ud9f4\ude06", "\u6470\u3f47\u0bc9\u8622\u8528\u1482\u21df\u840f\ubffe\u0624\uaa8a\uc76b\u64c2\ub5dc\u9072\ubf16\u7218\u10d6\u29df\u5944\u5bb7\u993c\u6fcb\u5460\u09d0\u9aa5\u8b96\ub1be\u4eb3\u5a18\u20e4\u0498\u49a4\u7a2a\u67d8\u4d2c\u81a6\u3975\ub7fb", "\udbf2\udfe1\ud8de\udf59\udb6d\udc3c\udae7\ude5a\ud89c\udf42\ub895\ud9ba\udc8b\ud8fe\udc38",
        32, 86305, 1669948399, 4662239570802541676L, 15603L, true, false, (char) 64047, (char) 26395,
        Double.longBitsToDouble(0x3fee41bd589374eeL), Double.longBitsToDouble(0x3fc1100bb0b74b64L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 2, 5, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u3e92\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\ub453\uc06d\u6176\u504c\uac4b\u111c\u7645\ub904\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u0a0b\u9d30\uaa93\u1203", "\udb5f\udfac\ud890\udc8b\udb19\udcf4\ud92c\udea8\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud98c\udf6f\ud8cd\udc05\uda51\udf8e",
        24, 48531, -13034931, -1810353153058077916L, -80609L, true, false, (char) 16353, (char) 37079,
        Double.longBitsToDouble(0x3fc7e2fe22220174L), Double.longBitsToDouble(0x3fa6e96c819d5830L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 0, "\u4d30", "\u1dfe\u5004\u7301", "\ud949\udc86",
        9, 74897, 1123684033, -7213143944601435467L, -100000L, true, true, (char) 11857, (char) 38997,
        Double.longBitsToDouble(0x3fa580006e800000L), Double.longBitsToDouble(0x3fcdf80153faec00L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[106, 66, 82, 97, 118, 116, 72, 112, 106, 54, 77, 61]] |a0=[B:[[-116, 20, 90, -66, -47, -23, -113, -93]]\0121=[B:[[]] |a0=[B:[[-116, 20, 90, -66, -47, -23, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 15, 4, 16, "\ud8bc\udd44\uda8a\udeee\udb01\udf19\ud9bf\uddd3\ud84f\udcbb\udacf\udd56\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud81a\udf0d\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\udba9\udf26\udae1\udc85\ud9f6\udc48\uf323\ud88d\udcd4\ud929\uded3", "\u17d1\u9022\ua5a4\uca71", "\ud92f\udd55\ud8ad\udca7\uda81\udee7\udb17\uddfa\udb8d\udd11\udafd\udcc9\ud85f\udf1a",
        44, 28883, -1726600964, 1738800196225290111L, 36518L, false, false, (char) 24843, (char) 10536,
        Double.longBitsToDouble(0x3fe932f2c228aab1L), Double.longBitsToDouble(0x3fedd4ac6147b5b6L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[B:[[106, 66, 81, 61]] |a0=[B:[[-116, 20]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 0, "\ud8bc\udd44", "", "\udacf\udd9e",
        21, 22582, 149417122, 6113067752119421601L, 15661L, true, false, (char) 27255, (char) 42078,
        Double.longBitsToDouble(0x3fee5bcbcac6038bL), Double.longBitsToDouble(0x3feeccbbe02b2166L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 9, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ub10d\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1\ud929\uded3\udb86\udfab\ud85f\udd82\udb1b\udec0\ud946\udf68\uce2a\ud852\uddae\udb3b\udde3\udb31\udf5b\udaaa\udc10\ud8ad\udca7\ud9cb\udf4d\udb7b\udedf\udb69\udf45\ud82e\udc08\ud85f\udf1a\ud915\udd7d\uda63\udc27", "\u67d8\u4d2c\ua877\u3975", "\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\uda65\ude41\uda8d\udf85\ud973\udf75\udb8f\ude19\ud8f0\ude41\udbde\udfea\ud983\udd9d\udbf9\udd77\ud8b2\udd03\ud90c\udd38\ud85f\udd80\ud899\udcd5\ud9a6\udd39\udb39\udd5b\ue9ac",
        -5, 30351, -791985690, -6987863805241220331L, -79026L, false, true, (char) 31223, (char) 7996,
        Double.longBitsToDouble(0x3fe160f811619537L), Double.longBitsToDouble(0x3fd2d7c66d2362b2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\u4d30", "\u3314\u5004\000\ubc25\u5a1c\000\000\u8000\u8622\u8528\u5307\u21df\ub47d\ubffe\uaee6\u00d9\u3bda\u1600\u4677\u90f8\u76e1\u51d9\u325e\u8677\000\u2821\000\000\000\uad08\u77f7\000\000\000\000\ua30b\u9d30\u9f02\u7a2a", "",
        -5, -1000, 0, 6798233115539013632L, -1440L, true, true, (char) 55177, (char) 10607,
        Double.longBitsToDouble(0x3fee2eff306bb095L), Double.longBitsToDouble(0x3fe336a000001476L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null\012",
        Z.run(T, 2, 12, 15, 3, "\ud8bc\udd44", "\u2806\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u384c\ub47d\ubffe\uaee6\u0b6f\ub4e8\u9e0a\uab85\u90f8\u4df9\u51d9\u1869\u29df\u5944\u7197\u42ce\u6fcb\u2a60\u09d0\u9aa5\u55ce\u5b38\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc78\ud87c\ude91\uda06\udf75\udbbe\udce2\udbf7\ude0d",
        15, 8050, 1986259338, -3259806617932376404L, 90837L, false, false, (char) 54103, (char) 6465,
        Double.longBitsToDouble(0x3fe767c9e6f38cd1L), Double.longBitsToDouble(0x3f6acf6a4d237400L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 6, 13, 14, "\ud8bc\udd44", "\u3314\u5004\u7301\u92b6\uc76a\u7d2f\u9e17\u6c5f\ud7dc\ud0de\u265a\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u6acd\u5720\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u58b6\u06ed\u2a60\u3686\u9aa4\u8b96\u5cab\ucd2c\u6dfa\u7194\u6bdc\uadae\u7a10", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udb93\udd4e\ud8de\udf6a\ud937\udf45\ud9e1\udcef\udacd\udcc7\udb98\udf16\udb65\udcde\udb62\udd8d\udb43\udf81\ud819\ude1a\uda8d\udfcc\uda4d\udf42\ud8dc\udfa0",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 3, "\uda46\udd20\ud87a\udd51", "\u8a4d\u837c\u1526\u8b7c\u2730\u3f47\u477f\u36aa\u5760\u1482\u3ce5\u10e7\ub813\u0ee2\u4e92\u687a\u03b1\u2db0\u90f8\ubf16\u5e74\u43cd\ua7cb", "\udb1e\uddf4",
        39, 37441, -2068196373, -809671603159826557L, -15557L, true, true, (char) 33284, (char) 24217,
        Double.longBitsToDouble(0x3fe609676e7e44d0L), Double.longBitsToDouble(0x3fe64fce8d90df63L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:102 |a0=[B:[[-116, 20, 90, -66, -127, -21, 118, -43]]\012",
        Z.run(T, 2, 9, 10, 15, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\udba6\udd05\ud9f1\ude38\ud85b\uded5", "\u1943\u3f47\u0e3a\u8622\u8528\u1482\u21df\ub47d", "\udb8d\uddd0\ud861\udec8\uf263\ud88d\udce1\ud929\uded3\udb86\udfab\ud85f\udd82\uda20\ude63\ud946\udef7\uce2a\ud852\uddae\ud8d6\uddb1\ud88e\udd9c\udaa9\udff6\ud8ad\udca7\udb94\uded2\udb69\udf7e\udb69\udf45\ud82e\udc08\ud85f\udf1a\ud915\udd7d",
        10, 52577, 641029114, -2349851950181544560L, 19372L, true, true, (char) 44249, (char) 5447,
        Double.longBitsToDouble(0x3fd47b5b6e4eecc6L), Double.longBitsToDouble(0x3fe5634617c5dfe6L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:22361 |a0=[B:[[-116, 20, 5, 32, 86, -113, 49, 109]]\012",
        Z.run(T, 2, 9, 10, 15, "\ud8bc\udd44\ud835\udc50\u0986\ud9bf\ude61\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9b3\udccf\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\u6d3f\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u090d\uc142", "\ud85e\udfb6\ud97c\udd32\ud82f\udce6\udbe3\ude81\ud8d2\ude9d\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udafd\udf16",
        51, 67310, 569836445, -7465345772091886527L, -54460L, false, false, (char) 5882, (char) 28686,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 16, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u090d\uc142", "\ud85e\udfb6\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:0 |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]]\012",
        Z.run(T, 2, 9, 10, 15, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\000\000\ud88f\udf46\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\ua3df\000\uf23b\ud88d\udce1", "\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u527b\ub9ab\ucd2c\u6dfa\u7194\u9d30\u090d\uc142", "\ud85e\udfb6\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:6750558 |a0=[B:[[-116, 20, 90, -66, 119, 70, -113, 101]]\012",
        Z.run(T, 2, 9, 10, 15, "\ud8bc\udd44\uda8a\udeee\ud9a7\udd76\ud9bf\ude95\ud99d\udc42\udacf\udd9e\ud97e\udede\ud832\udc61\ud924\udd6c\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9ed\udf69\udbe9\udf49\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\u51d9\u1869\u29df\u5944\uc6c2\u3257\u6fcb\u2a60\u09d0\u9aa5\u5b49\u3c61\ucd2c\u6dfa\u5b10\u1829\ub37b\uc142", "\ud8a9\udf6b\ud97c\udd32\udaad\udee4\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud804\udd6b\udbba\ude34\udacd\udc2c\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 34777,
        Double.longBitsToDouble(0x3fa67a135201d3a0L), Double.longBitsToDouble(0x3fdd73aef3cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:0 |a0=[B:[[-116, 20, 61, 112, -127, 51, -113, -93]]\012",
        Z.run(T, 2, 9, 10, 15, "\ud8bc\udd44\ud96d\udca0\udbb1\udd63\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud892\uddc0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8e8\udd08\ud81a\ude06\ud9dd\udc00\ud8b9\udcca\ud8f9\udfe7\uda93\udd06\uda43\udc22\ud933\udd59", "\u51d9\u1869\u4604\u6c93\ud11a\u992b\u8993\u8d56\u9f80\u99ae\u8936\u685c\u332d\u6dfa\u3927\u9d30\u090d\uc142", "\uda49\udc36\ud99e\udee6\ud82f\udce6\ud92c\udf04\ud8e0\udcc6\udbf3\udc2e\ud8de\udf59\udad7\udef4\ud9d5\ude66",
        25, 79557, 412082639, 1474491409711821116L, -17585L, false, false, (char) 56691, (char) 48064,
        Double.longBitsToDouble(0x3fe3356e5b9de6e0L), Double.longBitsToDouble(0x3fb5c87dc73e2698L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:0 |a0=[B:[[-116, 20, -63, 19, 19, 126, -113, -93]]\012",
        Z.run(T, 2, 9, 10, 15, "\ud8bc\udd44\ud9f1\udf43\uda43\udcae\ud9bf\uddd3\uda1a\uddbf\ud8e7\udfe1\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ua9b2\u6dfa\u7194\u9d30\u090d\uc142", "\ud85e\udfb6\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\uda27\udd06",
        33, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]] |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]]\0121=java.math.BigInteger:0 |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]]\012",
        Z.run(T, 2, 11, 10, 15, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\udadf\udfaf\ud8d6\udd67\udb4a\uddbe\udb7f\udf92\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\udb9c\udd7d\udaee\uddf4", "\u51d9\u1869\u29df\u5944\u9434\u9901\uc2e3\ub481\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u090d\uc142", "\ud85e\udfb6\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb4b\udd0e\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7395691710472276927L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-116, 20, 90, -66, -127, -21, -91, -45]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[-116, 20, 90, -66, -127, -21, -91, -45]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 4, 15, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\uadd5\ud803\udf5f\ud802\udf0c\ud9dc\udedf\udbc7\udce2\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udac8\udff8\ud831\udfe8\udb61\udc05\uda60\udeaf\ud9ca\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\u51d9\u1869\u29df\u370e\u31b9\u9901\u42f1\u2a60\u09d0", "\udbe1\udd95\uda81\udcca\uda77\udf08",
        32, 62885, -1210648822, 5331681115472373405L, 33338L, false, false, (char) 9789, (char) 1696,
        Double.longBitsToDouble(0x3fe932f2c228aab1L), Double.longBitsToDouble(0x3feb30446147e058L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 15, 10, 15, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud9a1\udd9a\udb2b\udebd\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\uda05\udd1d", "\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u9780\u09d0\u9aa5\u8510\u1dac\ucd2c\u6dfa\ua9ef\u9d30\u090d\u7cd1", "\udabd\udd11\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f",
        15, 8050, 264144433, -3260022818361420116L, 33269L, false, false, (char) 54103, (char) 52616,
        Double.longBitsToDouble(0x3fdb5c43e06b3d1cL), Double.longBitsToDouble(0x3fbe593b2dc451e0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]] |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]]\0121=java.lang.Boolean:true |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]]\012",
        Z.run(T, 2, 11, 3, 5, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\u51d9\u1869\uc05d\u1a23\uc46b\u0106\u6f98\u2a60\uaf71\u9aa5\u8b96\ub9ab\ucd2c\u1dee\u2470\u9c6b\u090d\uc142\u8384\u75c3\ub206\u3975\ua562\u4546\u1e0b\ua3fc\u47ae\u1d98", "\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19\ud8f0\ude41\udbde\udfea\ud966\udf8c\ud979\udf72",
        21, 47811, -327175628, 1725181484695668927L, 82478L, false, true, (char) 10020, (char) 19045,
        Double.longBitsToDouble(0x3f894659a8d9ca40L), Double.longBitsToDouble(0x3fc8eb3dfdcd3680L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-116, -6, 90, -66]]\0121=java.math.BigInteger:0 |a0=[B:[[-116, -6, 90, -66]]\012",
        Z.run(T, 2, 10, 10, 15, "\ud8bc\udd2a\uda8a\udeee", "\u2304\u7305\u4039\u8c2f\u2730\ua329\ub1c5\u2cf3\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\uc236\u0f67\u90f8\ubfb8\u51d9\u1869\u29df", "\udb3b\udde3",
        29, 48700, -2068196373, -809662807066804349L, -15557L, true, true, (char) 12037, (char) 61475,
        Double.longBitsToDouble(0x3fdd879e07f5d0b8L), Double.longBitsToDouble(0x3fe0d131ad90df63L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 11, "\ud940\ude80\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\udb6d\udf57\ud9d6\udc56\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1\ud929\uded3\udb86\udfab\ud85f\udd82\udb1b\udec0\ud946\udf68\uce2a\ud852\uddae\udb3b\udde3\udb31\udf5b\udaaa\udc10\ud8ad\udca7\ud9cb\udf4d\udb7b\udedf\udb69\udf45\ud82e\udc08\ud85f\udf1a\ud915\udd7d\uda63\udc27\ud968\udfac\ud997\ude3a\u442e\udb91\udcc6\ud85e\udfb6\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\udbea\udc3d\ud9e1\udc7c\uda5d\ude0f\udb98\udf25\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19\ud8f0\ude41\udbde\udfea\ud983\udd9d\udbf9\udd77\ud8b2\udd03\ud90c\udd38\ud85f\udd80\ud899\udcd5\ud9a6\udd39\udb39\uddde", "\ucb30\u728b\u096d\u8501\ub586", "\uda60\ude02\ud996\udcba\ud8f0\udd5d\udaab\udcc5\ud87e\udf42\udb3d\ude80\uda79\udcdd\udbb1\uddfa\udb8e\udc5e",
        18, 5094, 628958869, -7889490533434135845L, 84044L, false, false, (char) 45022, (char) 20281,
        Double.longBitsToDouble(0x3fe9c2831dfceceeL), Double.longBitsToDouble(0x3fd0fc9f1ef18d80L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.math.BigInteger:226 |a0=[B:[[-116, 20, 52, -48, -48, -48, -97, 110]]\012",
        Z.run(T, 2, 5, 10, 15, "\ud8bc\udd44\ucc64\000\000\000\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\uda58\udec7\000\udae1\udecf\uda0c\udfda\000\udb1a\udc0c\000\ud9dc\udf35\000\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\ua548\u24f3\000\u6c13\ua446\u9901\u6fcb\ub8d4\000\000\u2784\000\000A\u7aaa\u9d30\ucd7e\uc142", "\ud85e\udfb6\ud97c\udd32\ud82f\udce6\000\udbf0\udef8\ud8d2\ude08\ud8be\udf9f\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 55926, 569835520, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 12381,
        Double.longBitsToDouble(0x3f4a5b2067560c00L), Double.longBitsToDouble(0x3fd9f8dc020000e6L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[68, 79, 78, 88, 120, 72, 111, 51, 106, 47, 99, 61]] |a0=[B:[[12, -29, 87, -60, 122, 55, -113, -9]]\012",
        Z.run(T, 2, 9, 15, 12, "\ud93c\udd13\ud887\udcf4\ud9aa\udd67\ud9bf\ude27\ud99d\udc42\udacf\udd9e\ud97e\udede\uda68\ude5d\ud949\udd28\udb7f\udfba\ud921\udc9d\ud9e3\udce5\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\ufc23\ud88d\udce1", "\u6cd4\u1869\u29df\u5944\u31b9\u9901\u6fcb\u3dee\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30", "\u442e",
        22, 32254, 828956832, -309977447550931595L, -94183L, false, true, (char) 10656, (char) 47019,
        Double.longBitsToDouble(0x3feb5d84ac66d4c5L), Double.longBitsToDouble(0x3fce01290527f0fcL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=[B:[[-15]] |a0=[B:[[56, -86, 90, -66, -127, -21, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.math.BigInteger:241 |a0=[B:[[56, -86, 90, -66, -127, -21, -113, -93]]\012",
        Z.run(T, 2, 4, 10, 4, "\uda68\udcda\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42", "\u8c2f\u2730\u3f47\ub1c5\u8247\u84b3\u1482\u21df\ub47d", "\udb8d\uddd0\ud9f4\ude64\ud958\udd91\ud8ca\udce8\ud929\uded3\udb86\udfab\ud837\udfd6\udb1b\udec0\ud946\udf68\u7a2a\ud852\uddae\udb3b\udde3\udb31\udf5b\udaaa\udc10\ud8ad\udca7\ud9cb\udf4d\udb7b\udedf\udb69\udf45\ud82e\udc08\ud85f\udf1a\ud915\udd7d",
        10, 52577, 641029114, -2349851950181544560L, -56295L, false, false, (char) 742, (char) 47019,
        Double.longBitsToDouble(0x3feb5d81ea66d4c5L), Double.longBitsToDouble(0x3fe711989149fc3fL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=[B:[[]]\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 9, 13, 15, "\000", "\u3314\u7f72\u00a4\uc8a5\u4314\u2730\u3f47\ub1c5\u00c1\u404b\u1482\u21df\ub47d\ubffe", "\ud9f4\ude64\uf323\ud88d\udce1\ud929\uded3\udb86\udfab\ud85f\udd82\udb1b\udec0\ud946\udf68\uce2a\ud852\uddae\udb3b\udde3\udb31\udf5b\udaaa\udc10\ud8ad\udca7\ud9cb\udf4d\udb7b\udedf\udb69\udf45\ud82e\udc08\ud85f\udf1a\ud915\udd7d",
        10, 32816, 641029114, -2349851950181544560L, -94183L, true, false, (char) 10607, (char) 47019,
        Double.longBitsToDouble(0x3feb5d84aa66d4c5L), Double.longBitsToDouble(0x3fe710a3b149fc3fL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:0 |a0=[B:[[-48]]\012",
        Z.run(T, 2, 9, 10, 15, "\000", "\uad1e\u5004\uaf26\000\000\000\u938e\ub1c5\u8622\u8528\u6a81\u21df\ub47d\ubffe\000\u0a96\ub4e8\u5d19\u00ef\u8ffa\ubf16\u51d9\u1869w\uc471\u31b9\u9901\u6fcb\000\uad08\u9aa5\u0083\000\ucc51\u6dfa\u7194\u1aaa\u090d\000", "",
        1, 85344, 48423, 6798233115550661414L, -100000L, false, false, (char) 19850, (char) 10607,
        Double.longBitsToDouble(0x3fee2eff376bb095L), Double.longBitsToDouble(0x3fe336a62ee21476L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[-116, 53, 90, -66, -27, -35, -113, 50]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 5, 7, 0, "\ud8bc\udd65\uda8a\udeee\ud915\ude0d\ud9bf\ude62\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud8a9\udec0", "\u1482\u21df\ub47d\uc6db\uaee6\u27d6\ub4e8\u7319\ub09a\u17ce\u2390\u48c6\u9485", "\u0422\ud8ed\udf75\ud8ad\uddba\uda2b\udea5\ud869\udfeb\ud9cb\udec5\udb7b\udedf\udb69\udf45\ud82e\udc08\ud85f\udf1a\ud915\udd7d\uda63\udc27\ud968\udfac\uda90\udce6\u34f5\udb91\udcc6\uda3b\ude04\ud987\udc4d\ud83b\udc2f\ud92c\udf04\u7e1f\u40af\uda04\udf26\ud8da\udc6a\udb8e\udd74\udacd\udcc7\ud8b6\udcc4\udb65\udcde\uda6a\udcab\uda99\ude6c\ud819\ude94\ud81f\ude69\ud974\udc2b",
        28, 94099, -421505690, 2447428893605741459L, 91644L, true, false, (char) 45285, (char) 48902,
        Double.longBitsToDouble(0x3f99d583b3f1b800L), Double.longBitsToDouble(0x3fde6847375b04b0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 12, 6, 9, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud8a1\udc44\udbd2\ude60\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\uac83\ud50a\u74c3\u58ff\u31b9\u9901\u6fcb\u2a60\u09d0\u5ea0\u8b96\ub9ab\u85c5\ua41a\u20ce\u36a4\u7745\ub41a", "\ud90e\ude11\ud983\udf82\ud82f\udce6\ud92c\udf04\udbf8\udd5b\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud8c6\udf6b\udb8f\ude19",
        34, 67310, -1797065571, -7465345772091886527L, 76523L, false, false, (char) 33237, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 2, 2, 16, "\uda5c\udc63\uda8a\udeee\udbab\udc97\udb5c\udce4\ud8a0\ude71\ud8df\udf0e\ub783\udbc7\udccb\ud949\udd28\udb7f\udfba\ud987\uddef\ud9aa\udeb3\ud80e\udcd0\udaf3\udc81\udb17\udd51\udb11\ude8d\ud9e0\udcf9\ud8b9\udc9d\udb8d\uddd0\ud90d\ude72\uf307\udb1a\udd97", "\u51d9\u2e07\u9f40\u5944\u31b9\u9901\u6fcb\u3676\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u10fa\u7194\u9d30\u090d\uc142", "\ud85e\udfb6\ud97c\udd32\udaa1\udcdf\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\udab6\udc43\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\ud919\ude1e",
        12, 67310, 569836445, -7490678519997346495L, -54460L, false, false, (char) 40071, (char) 32741,
        Double.longBitsToDouble(0x3fa6e97704ad5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=[B:[[51, 100, 70, 54, 100, 103, 61, 61]] |a0=[B:[[-35, -47, 122, 118]]\012",
        Z.run(T, 1, 15, 11, 8, "\uda0d\ude01\udaaa\udca6", "\ucc12\uc634", "\ud949\udd28\udae9\udcd0\udb2c\ude66\ud849\uddba\u10cd\ud981\uddbc\ud8fc\ude81\uda6c\udfad\ud9e2\ude00\ud8b9\udc9d\udb8e\udc95\ud9f4\ude64",
        40, 48947, -1755579138, -8634992550407947102L, -74030L, false, false, (char) 10843, (char) 39588,
        Double.longBitsToDouble(0x3fef5bd66ff784b9L), Double.longBitsToDouble(0x3fec1b15d0087cefL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=[B:[[-116, 20, 90, -66]] |a0=[B:[[-116, 20, 90, -66]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 14, 1, "\ud8bc\udd44\uda8a\udeee", "\u9821\uc634", "\ud949\udd28\udb7f\udfba\ua2ec\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\ude21\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8e\udcf4\ud9f4\ude64",
        12, 12703, -1755579138, -1716439875410287288L, -68887L, true, true, (char) 32130, (char) 37596,
        Double.longBitsToDouble(0x3fca75b0e68fa404L), Double.longBitsToDouble(0x3fef5bd66ff784b9L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |a0=[B:[[-116, 20]] |this=org.apache.commons.codec.binary.Base64:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 16, 3, "\ud8bc\udd44", "\u2bee\u9821\uc634\uc2d7\u072b\u2730\u3f47\u1886\u8622\u8528\u1482\u220b\ub47d\u3efe\uaee6\u0e93\ub4e8\u7319\u0f67\u90f8\u7ecb\u51d9\u1869\u29df\ua3cc\u31b9\u9901\u3992\u232f\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u66cc", "\udad5\ude2e\ud9ac\udf9e\ud9d3\udedf\ud9b8\udf7e\u7e1f\udbf2\udfe1\uda69\udffd\ud832\udc41\ud85f\udd9b\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, -490, 569859467, -902193739489028469L, 16927L, false, false, (char) 48902, (char) 6557,
        Double.longBitsToDouble(0x3fd05e7fc3cd08e6L), Double.longBitsToDouble(0x3fe4b713bbb4de9eL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 0, "", "", "\ud974\udcfd",
        13, 17499, 57, 641741653875751611L, 34849L, true, true, (char) 33460, (char) 27299,
        Double.longBitsToDouble(0x3fc0a7fb2f2de5e4L), Double.longBitsToDouble(0x3ec17bf65c000000L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.lang.Boolean:true |a0=[B:[[-109, 61]]\012",
        Z.run(T, 2, 9, 3, 15, "\ud9c3\ude6d", "\u2bee\u9821\uc634\uc2d7\u072b\u2730\u3f47\u1886\u8622\u8528\u1482\u220b\ub47d\ubffe\uaee6\u0e93\ub4e8\u7319\u0f67\u90f8\u7ecb\u51d9\u1869\u29df\uc1fd\uc387", "\uda93\udf57\ud8ad\udca7\ud9cb\udf4d\udb7b\udedf\udb69\udf45\ud82e\udc08\ud85f\udf1a\ud915\udd7d\uda63\udc27\ud968\udeeb\ud894\ude0c\u6c6c\u9a51\ud875\udc3d\ud97c\udd32\ud82f\udce6",
        4, 77206, -1785986520, -4567903764070799033L, 8884L, true, true, (char) 43008, (char) 18220,
        Double.longBitsToDouble(0x3fe710a3b149fc3fL), Double.longBitsToDouble(0x3fdef51bb460c712L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=[B:[[-48]] |a0=[B:[[-48]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 5, 3, "\000", "", "\udacf\udd9e\ud97e\udede\ud8c8\udee3",
        57, 16499, 1828276897, 4826186171077886157L, 78640L, true, true, (char) 53202, (char) 12099,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e1de00000000000L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.lang.Boolean:false |a0=[B:[[0, 125]]\012",
        Z.run(T, 2, 9, 3, 5, "\ud830\udfad", "\u3314\u5004\u40ee\u223b\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\u3a42\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\ubc03\u9aa5\u8b96\ub9ab\u911c\u5de2\u555a\u9d30\u9f02\u7a2a", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\uf0a7\ud813\udf75\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udb2a\udd0c\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772670400378L, 16927L, false, false, (char) 48902, (char) 21916,
        Double.longBitsToDouble(0x3fd9f8dc03cd08e6L), Double.longBitsToDouble(0x3fcf5ab038be2360L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 3, "\ud8bc\udd44", "\000\u246b\u7301\u5c13\u8c2f\ubdb4\000\u8000\u8622\u8528\u1482\uce32\u4ff8\ubffe\uaee6\u0b6f+\000\000\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\ua688\000\000\000", "\ud875\udc3d",
        19, 41751, 1582837109, -6146926409495608792L, -94183L, true, true, (char) 10607, (char) 47019,
        Double.longBitsToDouble(0x3fbaec2553300000L), Double.longBitsToDouble(0x3fe710a3b000fc3fL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-116, 20]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[-116, 20]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 14, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u405f\u6619\u0baf\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u9f02\u7a2a", "\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-116, 20]]\012",
        Z.run(T, 1, 3, 11, 3, "\ud8bc\udd44", "\u3314\u5004\u7301\u4039\u8c2f\u8c28\u48e2\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u42b8\ubcfa\u9d30\u73c0\u7a2c", "\ud875\udc3d\ud97c\udd3b\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud909\udf51\udacd\udcb2\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\ude40\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -54460L, false, true, (char) 57519, (char) 45285,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fd9f8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[106, 66, 82, 97, 118, 111, 72, 114]] |a0=[B:[[-116, 20, 90, -66, -127, -21]]\012",
        Z.run(T, 2, 2, 15, 3, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b", "\u2446\u9f4f\u8c2f", "\ud9df\uddea\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8ec\udff5\uda6c\udfad",
        19, 77554, 560334094, 7080364687148872609L, 42539L, false, false, (char) 43619, (char) 26308,
        Double.longBitsToDouble(0x3fd7218105818038L), Double.longBitsToDouble(0x3fca75b0e350ac04L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 1, 3, "\ud8bc\udd44", "\u7a38\u5004", "\ud9dd\udeb7\uda70\udda2\ud816\udd6b\ub0c1\udbd8\udd0d\ud812\ude41\ud99f\udcd4\ud8fc\uddf5\ud8ff\udde6",
        13, 35131, -1805169651, 5029828376072159722L, -71362L, false, true, (char) 45154, (char) 51237,
        Double.longBitsToDouble(0x3fd6da0105818038L), Double.longBitsToDouble(0x3fe06292d55d012dL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-116, 20, -108, 13, -3, -118, -91, -37]]\012",
        Z.run(T, 1, 3, 4, 8, "\ud8bc\udd44\udac4\ude3d\ud82d\uddba\ud9d5\udd0b\ud99d\udc42", "\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\u8958", "\udbd8\udc16\udac7\udded\uda0f\udd8b\ud9e9\udc7a",
        7, 95383, 64660808, 5038680198125318613L, 64653L, false, false, (char) 51700, (char) 16243,
        Double.longBitsToDouble(0x3fceb733faadab50L), Double.longBitsToDouble(0x3fddb98ac283c21aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=[B:[[106, 66, 81, 61]] |a0=[B:[[-116, 20]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[106, 66, 81, 61]] |a0=[B:[[-116, 20]]\012",
        Z.run(T, 2, 12, 15, 8, "\ud8bc\udd44", "\u9014\u15b9\u7301\u4039\u8c2f\u8f7c\u31da\u0bc9\ua119\u8491\u2169\u191a\u90ab\uc17f\uaee6\u0845\u4627\uc3df\u73ea\u78dd\ubf16\u51d9\u1869\u29df\u5944\u97f5\u9901\u6fcb\u2a60\u09d0\ucaf5\uc221\u2f22\ucd2c\u8fb7\u0725\ua3f9\u9f02\u7a2a", "\uda01\ude5b\udb2c\udc6d\uda57\udda0\ud9b3\ude95\udaa2\udc1d\ud9d5\udc9e\udaf8\udc5d\ud9e7\ude97\ud8af\udcbe\ud933\udd35\ud8c0\udf70\udad8\udf9a\udbd1\ude89\ud9fa\udead\ud9bd\udeea\udbee\udeb8\udaed\udcce\ud88c\udfa2",
        55, 82168, 756951386, 8545927010756833110L, 62546L, false, false, (char) 62729, (char) 30603,
        Double.longBitsToDouble(0x3fecbcfb81803f19L), Double.longBitsToDouble(0x3fc3ab916122b734L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-85, -43, -5, -6, -127, -21, -113, -93]]\0121=[B:[[]] |a0=[B:[[-85, -43, -5, -6, -127, -21, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 3, 4, 8, "\ud8db\ude05\ud92b\udf2a\udbb1\udd1b\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ub10d\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\ud89a\udc84\udb37\udcd1\udae4\udf24\udbd8\udc16\ud9f4\ude64\udac2\udee6\ud959\udf3f\ud929\uded3\udb86\udfab\ud85f\udd82\udade\udcc1\ud915\uddc1\uce2a\udaa1\udfb1", "\u95ed\u09d0\uc1f5\u715f\uba39", "\ud8f2\udce5\udaa0\udf02\ud968\udeeb",
        58, 95409, -1355499549, -5394407430309555103L, 74171L, true, true, (char) 63109, (char) 7137,
        Double.longBitsToDouble(0x3fe38f5ebdb8267cL), Double.longBitsToDouble(0x3fa3f7676c5efe30L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-116, 20, 90, -66]]\0121=java.lang.Boolean:true |a0=[B:[[-116, 20, 90, -66]]\012",
        Z.run(T, 2, 3, 3, 16, "\ud8bc\udd44\uda8a\udeee", "\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\u8958\u1c49\uaee6\u0845\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u29df", "\udb3b\udde3",
        29, 2548, -2068196373, -6201606259811548709L, -15557L, true, true, (char) 59153, (char) 30724,
        Double.longBitsToDouble(0x3fcf93ad56466458L), Double.longBitsToDouble(0x3fe3f8c10d90df63L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-116, 20, 90, -66]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 1, 14, "\ud8bc\udd44\uda8a\udeee", "\u5004\u7301\u4039\u8c2f\u2730\u0866\u0bc6\u8622\u6d74\u14a0\u21df\u8958\u1c49\uaee6\u0845", "\ud993\udfc4\ud90d\uddf9\udb86\udfab\ud85f\udd82\udaf0\uddc0\ud83c\udd0e",
        2, 42026, 862071232, 3098895429556615380L, -65175L, true, true, (char) 34734, (char) 50364,
        Double.longBitsToDouble(0x3fd41e10d3beba66L), Double.longBitsToDouble(0x3fe6c8ffa6bf1735L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 11, "\ud885\udfbe\uda88\ude98\udbb2\uddc0\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud917\ude0b\udaeb\udc9f\udb39\ude6d", "\u8622\u2a7e\u88f9", "\ud9dd\udc00\udb14\uddfc\udb8d\uddd0\ud9b7\udf66\ud9a2\udfa1\ud88d\udc46\ud929\uded3\udb86\udfab\ud9a9\udee8\ud858\udf5d\ud94e\udf0c\uce2a\udb80\udc25\udb3b\udde3\uda4f\udf6a\udaaa\udc10\udb41\udc50\ud83c\udeb1\udb64\udc10\ud93c\ude87\ud969\udc17\ud853\ude3a\ud915\udd7d\udaf8\udf92\udb5f\ude69\u94f7\udada\udd3c\udb32\ude58\udbbc\udda6\ud877\ude76\ud8ec\udc0a\ud91f\udf85",
        7, 16574, -357448203, -6367570578419814754L, 67844L, true, false, (char) 56549, (char) 16198,
        Double.longBitsToDouble(0x3fef9b1f3b7b7eecL), Double.longBitsToDouble(0x3fd755141bd738a0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 10, "\ud908\ude07\udaaa\udc55\udbb1\uddd6\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\uda90\udcaf\udbff\udfa3\uda12\udfc3\udaae\udfbc\ud9aa\udeb3\udab2\udc8d\ud986\udd4c\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\udb06\udd11\udb8d\uddd0\ud925\udd1c\ud99a\udcc3\ud88d\udc46\ud929\uded3\udb86\udfab\ud9a9\udee8\ud878\udd5d\ud94e\udf0c\uce2a\ud902\udc81\udb3b\udde3\udb31\udf5b\udab2\ude35\ud8ad\udca7\ud9cb\udf4d\udbda\uddde\uda51\udf39\uda45\udc73\ud85f\udf32\ud915\udd7d", "\u923d\u5754\u8fa9\u68a6\u7005\ua173\u717c\u3dce\uba15\u56fc\uba56\u9fc4\ub2a2\u06cb\u0fc2\ua73f\u17ed", "\udbf9\ude88\udacb\udf96\ud993\uddf4\uda1e\udc62\ud846\uddd7\ud804\udce6",
        25, 39900, -1971042213, -6800260930369109413L, 71789L, true, true, (char) 5398, (char) 46159,
        Double.longBitsToDouble(0x3fde6bb3e1de9228L), Double.longBitsToDouble(0x3fec932ba3483552L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 13, 3, "\ud885\udfbe", "\u3314\u5004\u7301\u4039\u668e\u64c1\u4379\u8e38\u8622\u2a7e\u88f9\u21df\ub47d\u6830\u511d\u2906\u30f3\u3a4b\ud229\u90f8\ubf16", "\ud94e\udf0c\uce2a\ud852\uddae\udb3b\udde3",
        -5, 80057, -2068196373, -809671603159826557L, -15557L, true, true, (char) 33284, (char) 61512,
        Double.longBitsToDouble(0x3fe8609400d1ce17L), Double.longBitsToDouble(0x3fda1a2ed0692fb4L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=[B:[[39]] |a0=[B:[[32, 39]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 1, 3, "\ud950\udf57", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u8b22\u0bc9\u8d3b\u3116\u1482\u21df\ub47d\u3d9c\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u8072\u29df\u5944\u31b9", "\udaaa\udc10\ud8ad\udca7\ud9cb\udf4d\udb7b\udedf\udb69\udf45",
        46, 94584, 1600540296, -7099120929542362884L, 62490L, false, false, (char) 24843, (char) 10536,
        Double.longBitsToDouble(0x3fe932f2c228aab1L), Double.longBitsToDouble(0x3fedd4ac6147b5b6L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-52]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[122, 65, 61, 61]] |a0=[B:[[-52]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 12, 11, "\uc7fc", "\ud280\u6f9f\u7301\u03bb\ud2dd\u2730\u3f47\u0bc9\u1b10\u3116\u1482\u52de\ub47d\u3d9c\uaee6\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869\u0a7b\u24be\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\uce4e\u47c2\u6e71\u7194\u9d30\u9f02\u7a2a", "\udba9\udc37\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\uda53\udf45\udb65\udcd8\udae5\udea7\uda81\ude32\ud80e\udf92\uda94\udc50\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465345772091886527L, -94925L, true, false, (char) 17247, (char) 50777,
        Double.longBitsToDouble(0x3fdae3689d35c23cL), Double.longBitsToDouble(0x3feb3f278e3c0c1dL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-9, -23, -85, 126, -49, -33, -115, 0]]\0121=[B:[[]] |a0=[B:[[-9, -23, -85, 126, -49, -33, -115, 0]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 8, 4, 14, "\udb27\udf19\ud8db\udcae\udbff\ude0f\ud9bd\udd30\ud99d\udc42\udacf\udd9e\ud97e\udede\uda34\udf03", "\uc67c\u4824\u6101\u7091\u588a\u5b23\u7112\u0b4b\u7c13\uc4e8\u8a82\ub7e2\u90f8", "\udabb\udeb7\udab4\udf1f\ud9fb\udfec\ueaef\udb48\udcee\udbd7\udd43\ud899\udf4a\ud8c5\udd19\ud8c6\ude9c\udb7e\udc26\udb55\udd41",
        18, 71326, 713578522, -7985459850996485196L, 16631L, false, true, (char) 39537, (char) 20537,
        Double.longBitsToDouble(0x3fd33d0f6dae44c0L), Double.longBitsToDouble(0x3fefd16ffed06700L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=void |a0=[B:[[-9, -23]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[-9, -23]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 14, 7, 8, "\udb27\udf19", "\u2a71\u883f\u7301\u4039\u8c2f\u26e2\u6294", "\udb23\udde6\ud99f\udcd4\ud9f1\udd0a\ud872\udf31\uda00\ude70\ud8f4\udc39\udb8d\uddd0\ud9f4\ude64\udb6e\udfdb\ud9f5\udd43\ud929\uded3\udb86\udfab\ud9de\udee1\udb0c\udf2b\ud946\udf68\uce2a\uda64\udd36\uda3e\ude27\udbba\udfe7\udab0\udf3e\udbbc\uddb4\ud9e7\udc76\ud98d\udef5\u01c4\ud888\udcc6\udae6\udfcb\ud97f\udd45\udb93\udc17\udbb1\udee3\udb9f\uded4\udba9\udf40\ud8d0\udd16\ud8f2\udf7a\ud8bf\udfa7\udb42\uded1\ud993\udeea\ud873\udf7c\ud983\ude4b\ud8bb\udc08\ufa29\ud930\udc24\udaf2\udeed\u8a9c\udb32\udd11\uda50\udea5\ud81b\udd25\u8844\udb0b\udda0",
        28, -649, -1482113726, -3979949130448226202L, -75189L, true, false, (char) 36792, (char) 27619,
        Double.longBitsToDouble(0x3fe4a2855f7fd64bL), Double.longBitsToDouble(0x3fc5568361f4a290L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=[B:[[47]] |a0=[B:[[-69, 76, -112, -113, 52, -75, 61, 2]]\0121=void |a0=[B:[[-69, 76, -112, -113, 52, -75, 61, 2]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 8, 7, 0, "\ud9eb\udc7c\udac0\udebf\uda64\udfe5\ud86d\udd32", "\u318d\u8c2f\u2730\u3f47\u071a\u6c04\u8528\u1f68", "\udb07\ude14\udb52\udd48\udb8d\uddd0\ud9f4\ude64\udb6e\udfdb\ud9f5\udd43\ud929\uded3\ud8ba\udf64\ud86d\uddac\udb1b\udec0\ud946\udf68\uce2a\ud9b1\udffe\ud908\udfd4\ud8ce\udcbf\udabe\udf2c\uda82\ude01\ud82b\udedd\udb7f\udc4b\ud98e\udc2f\uce51\uda03\udd8d\udb82\ude4f\udbe7\udc9a\ud966\ude15\ud909\udea8\ud9b2\udf0d\uda90\udcd6\ud9cd\udcb6\udb9b\uddff\ud81e\udcf1\ud941\udf0e",
        0, 90719, -509259014, -2025350793990704919L, 48640L, false, true, (char) 64935, (char) 6274,
        Double.longBitsToDouble(0x3feece3cfd476b46L), Double.longBitsToDouble(0x3fb60ee3bcff7658L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 12, 0, "\udbfc\udef3\uda43\ude12\ud9bb\udff2\uda23\udc64\ud8e1\udc44\udacf\udd9e\ud97e\udede\udacf\udeb0\udaeb\udfbe\udb7f\udfba\ub0d7", "\u1a10\u08c0\u7a4e\u85b5\uaee6\u0b6f\ub4e8\ub416\u670d\u676a\u07e7\u1717\u4573", "\udb7b\udee5\udabf\ude0e",
        28, 30282, 1391872902, -3087336481894069348L, 11588L, false, false, (char) 18883, (char) 25345,
        Double.longBitsToDouble(0x3fe25dfc90d164eaL), Double.longBitsToDouble(0x3fce45ddbbedea1cL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=[B:[[57, 43, 107, 61]] |a0=[B:[[-9, -23]]\0121=[B:[[57, 43, 107, 61]] |a0=[B:[[-9, -23]]\012",
        Z.run(T, 2, 15, 15, 3, "\udb27\udf19", "\u2a71\u5004\u7301\ub79c\u8c2f\u2730\u3f47", "\udb23\udde6\ud99f\udcd4\ud8fc\uddf5",
        16, 41991, -1753470266, 2406738427354546219L, -85328L, false, false, (char) 37474, (char) 10357,
        Double.longBitsToDouble(0x3fee4bced67796a6L), Double.longBitsToDouble(0x3fc7ea7bf5c86040L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-20, 37, -118]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 1, 15, "\udb1c\udf55\ubfba", "\u5004\u7301\u4039\u8c2f\u2730", "\ud9aa\udeb3\udb14\ude0d\u15c9",
        -1, 75046, 63976112, -7531097446418058279L, 36936L, false, true, (char) 47178, (char) 37474,
        Double.longBitsToDouble(0x3fd48832d7b4edb4L), Double.longBitsToDouble(0x3fd52f1b20f91630L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=null\0121=void |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 8, 7, 8, "\udb27\udf19", "\000\000\000\uaccb\u00e6\000\u3f47", "\uda0c\udfda\ud99f\udcd4\uce32",
        -5, -1000, 0, 2406738426721206272L, -100000L, false, false, (char) 37383, (char) 10357,
        Double.longBitsToDouble(0x3fce406019de5bb0L), Double.longBitsToDouble(0x3fc7ea7bf4000040L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=[B:[[106, 66, 82, 97, 118, 111, 72, 114, 106, 54, 77, 61]] |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[106, 66, 82, 97, 118, 111, 72, 114, 106, 54, 77, 61]] |a0=[B:[[-116, 20, 90, -66, -127, -21, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 12, 11, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3", "\u4039\u4939\u9467\u3f47\u0bc9\u8622\u8528\u1482\u21df\ub47d\ubffe\u9996\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u1869", "\ud852\uddae\udb3b\udde3\udb31\udf5b\udaaa\udc10\ud8ad\udca7\ud9cb\udf4d\udb7b\udedf\udb69\udf45\ud82e\udc08\ud85f\udf1a\ud915\udd7d\ud9e8\udc29\ud968\udeeb\ud6fd\u4493\u9a51\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud850\udd10\uda8d\udfcc\ud973\udf75",
        -4, 94069, -421505690, 2447428893605741459L, -29492L, true, false, (char) 58098, (char) 39195,
        Double.longBitsToDouble(0x3f99d583b3f1b800L), Double.longBitsToDouble(0x3fe124239a12b60dL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=[B:[[106, 66, 83, 55, 77, 73, 70, 55, 116, 67, 65, 61]] |a0=[B:[[-116, 20, -69, 48, -127, 123, -76, 32]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[106, 66, 83, 55, 77, 73, 70, 55, 116, 67, 65, 61]] |a0=[B:[[-116, 20, -69, 48, -127, 123, -76, 32]]\012",
        Z.run(T, 2, 12, 15, 4, "\ud8bc\udd44\udaeb\udd60\udbb1\udcab\ud9e4\udd50\ud966\ude85", "\u35b2\u19b6\u06eb\u1cb7\ua489\u564c\u1d3d\u26ef\u3f60\u6f23\u9f33", "\udbbb\ude68\udad5\ude7c\ud9dd\udef3\udbd3\udd47",
        26, 21133, 1615619305, 7295209021441984558L, -59721L, false, true, (char) 27675, (char) 14580,
        Double.longBitsToDouble(0x3fed57cbd36f436bL), Double.longBitsToDouble(0x3fdeb2246e5f4d36L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.math.BigInteger:0 |a0=[B:[[]]\012",
        Z.run(T, 2, 12, 10, 0, "", "", "\ud99c\udfa9",
        24, 82931, -1536487866, 641740958091049659L, -100000L, false, false, (char) 0, (char) 27186,
        Double.longBitsToDouble(0x3ecb2f2de4000000L), Double.longBitsToDouble(0x3fe6301c5bd9977cL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 3, "\ud8bc\udd44\udaeb\udd60", "\u5004\ub8c9\u7a1d\uc1ba\u2730\u3f47\u2008\u5104\u8528\u0082\u21df\u9c0a\ubffe\ub6ce\u0aff\u1424\u9fae", "\ud868\udc37\ud871\ude54\u7096\ud8af\udf79\uce2a",
        4, -912, 511608308, 396404047506521285L, -35427L, false, true, (char) 4974, (char) 38339,
        Double.longBitsToDouble(0x3fe33bd9c1a063fdL), Double.longBitsToDouble(0x3fec99f04c0f6ea3L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[97, 94]]\0121=[B:[[97, 94]] |a0=[B:[[97, 94]]\012",
        Z.run(T, 2, 3, 11, 9, "\udb91\udf8e", "\u3314\u5004\u7301\u4039\u8c2f\u2730\u23b8\u0bc9\u8622\u8528\u1482\u21df\u1e77\ubffe\u268f\u4d49\ua95e\ub2cb\u0f67\u90f8\ubf16\u51d9\u1869\u37df\u6324\u31b9\u9901\u6fcb\u2a60\u3a68\u19cc\u7729\u0e40\u0e1f\u4e8b\u7194\u9d30\u9f02\u718e", "\ud875\udc3d\ud925\udf50\ud82f\udce6\uda7d\udc8d\uda20\udde5\udbf3\udc2a\ud8de\udf59\ud832\udc41\udb6c\ude02",
        25, 33821, -725223573, 1474491710359715554L, -17585L, false, false, (char) 56691, (char) 17089,
        Double.longBitsToDouble(0x3fd66ff9873bcdc0L), Double.longBitsToDouble(0x3fec990fbf699865L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=[B:[[114, 73, 80, 104, 73, 119, 61, 61]] |a0=[B:[[-84, -125, -31, 35]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[114, 73, 80, 104, 73, 119, 61, 61]] |a0=[B:[[-84, -125, -31, 35]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 12, 16, "\ud9dc\udfb3\ud811\udc53", "\u5004\u7301\u4039\u8c2f\u2730\u3f47\u0bc9\u8622\u8528\u1482\u21df\u1e77\ubffe\u268f\u84e2\ua95e\ub2cb\u0f67\u90f8\ubf16\u51d9\u1869\u37df", "\udb3b\udde3",
        29, 2548, -2068196373, -809671604049019005L, -20165L, false, true, (char) 33284, (char) 61512,
        Double.longBitsToDouble(0x3fcf93af430c109cL), Double.longBitsToDouble(0x3fe3fc70b5906663L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=[B:[[]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 1, 3, "\ud8a9\udc14", "\u3314\u5004\000", "\u00a2\000",
        52, -1000, 15007744, -7186337629328519680L, 31072L, true, false, (char) 15528, (char) 24825,
        Double.longBitsToDouble(0x3fcfd766ac1e5d6cL), Double.longBitsToDouble(0x3ea6cf2030000000L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.math.BigInteger:7537490 |a0=[B:[[99, 119, 78, 83, -127, -21, -113, -93]]\0121=[B:[[115, 3, 82]] |a0=[B:[[99, 119, 78, 83, -127, -21, -113, -93]]\012",
        Z.run(T, 2, 10, 8, 11, "\ud893\udea7\uda7e\udd83\udbb1\udd1b\ud9bf\uddd3\uda22\udec9\udacf\udd77\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ub10d\ud9aa\udeb3\udb18\udc5c\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9dd\udc00\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1\ud929\uded3", "\ua773\u29df\u5944\u31b9\ucfc7\ua8fc\u5c6a\u0962\u9aa5\u8b96\u5e1c\ucd2c\u6dfa\u7194\u9d30\u9f02", "\u9a51",
        32, 20184, -72172249, 6798233617313366054L, -1626L, true, true, (char) 14885, (char) 10607,
        Double.longBitsToDouble(0x3fee2bcf37d9b095L), Double.longBitsToDouble(0x3fe336a62ee21476L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 15, 15, 11, "\ud99b\udd32\ud844\udd4a\udbb3\udc53\ud9bf\uddd3\ud99d\udc42\ud9d2\udd60\ud996\udf14\udbc7\udccb\uda69\uddd9\ud86b\ude40\ub10d\ud9aa\udeb3", "\uada1\ub47d\ucfe2\u874e\u50a9\ub4e8\u7316\u0f67\u90f8\ubf16\u0cbc\u1869\u29df\u5944\uc1fb\ub35a\u8e9d\u7b9d\ud716\ud27f\u7e12\u8d20\u253e\u1b92\ucaa7\ua29e\u4b5b\ua8e7\u5b89\u7ab4\ub759\ub9a3\u9646\u74a2\u75dd", "\ud974\udd2f\uda1b\udd9b\ud9fb\udd3f\ud9bd\ude59\uda1f\uddbc",
        46, 91664, -338811221, 3408467182322738860L, -27854L, true, false, (char) 30644, (char) 46877,
        Double.longBitsToDouble(0x3fed29d9a5ce374dL), Double.longBitsToDouble(0x3fede8626cd4a771L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 0, "", "\u066b\000\000\u5d33\uc57d\uacc6\u6470\u3f47\u0bc9\u8622\u8528", "\ud862\udfa8",
        20, 7662, -1603898407, 3601520906318217300L, -99096L, true, true, (char) 27509, (char) 2256,
        Double.longBitsToDouble(0x3fe3bcb64cbf53dfL), Double.longBitsToDouble(0x3fd1018105f67df8L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 4, 13, "", "\uc2c5\000\u90e6", "\000\000\udb7f\udfba\ud81a\udf0d\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\000\uda6c\udf28",
        20, 97014, -1989774461, 2720180836426716904L, -99230L, true, true, (char) 21537, (char) 13074,
        Double.longBitsToDouble(0x3fbdc03b25f803c0L), Double.longBitsToDouble(0x3f40104c00000000L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=[B:[[106, 66, 82, 97, 118, 116, 72, 112, 106, 54, 77, 61]] |a0=[B:[[-116, 20, 90, -66, -47, -23, -113, -93]]\0121=[B:[[]] |a0=[B:[[-116, 20, 90, -66, -47, -23, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 15, 4, 16, "\ud8bc\udd44\uda8a\udeee\udb01\udf19\ud9bf\uddd3\ud877\udd26\udacf\udd56\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud81a\udf0d\ud8c4\udcd9\udb23\udde6\ud99f\udcd4\ud8ed\udde9\uda6c\udfad\ud9dd\udc00\udba9\udf26\udae1\udc85\ud9f6\udc48\uf323\ud88d\udcd4\ud929\uded3\ud984\udc48\uda33\ude2d\udb1b\ude28\udbde\ude6f\uda55\udd3b\uda84\udf6c\uda3c\ude52\ud9f2\udf19\uda4f\udda5\udb2c\uddca\udb72\udcf7\udb17\uddfa\udb8d\udd11\ud81b\udff6\ud85f\udf1a\ud9ee\udd8a\uda6f\udc7c\ud968\udeeb\ud6fd\udbfb\udd92\udbc0\ude72\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\udb58\udfb6\uda8c\udf18\ubaa5\udb11\uddc0\ud866\udffc\ud832\udc9b\udb09\udf46\ud96f\udfff\uda2b\udd54\ud9b3\ude85\ud93d\udf00\uda2f\udebd\udb59\udfb6\ud969\udedb\udb27\udec8\uda01\udd95\ud987\udeff\ud859\udcd5\ud83a\udf73\ud830\udea6\ue9ef\udaf8\udd7c\ud9b1\ude8d\udbf0\udc54\ud9d5\udc16\ud8ac\udc19\udb9c\udc42\udbc2\udd0e\u78ec\udae2\udecf\udba0\udc14\ud8e3\ude33", "\u4be0\u2431\u8543\u5350\u404e\u2987\u17b7\u072a\u6733\u88a2\u79de\u8f7f\u918f\ubef5\u2674\u9a85\ub208\u792e\ub8c7\uad8d\u5ac9\u6694\u9a3b\uc0bb\ua259\u6efe\u8cd6\ub108\u27a8\u721d\ud3d7\u9044\u1037\u6b0d\ub46c\u97fe\u0930\u0dcb", "\u2a4c\uda1b\udf91\udb12\udce0\udae9\udf6a\ud95c\udc2f\uda43\udcc0\udbda\udc37\ud8ed\udc75\udafd\udc74\udadf\udea1\ud9e2\udfca\udb48\udefd\uda2d\udeec\udb16\udc42\uda28\udcf6\ud894\udfb2\ud9ff\ude1f\uda25\udf97\ud965\udec9\udb0d\udfb2\ud821\udc17\udbbf\udfe0\ud962\ude5f\ud9c8\ude35\udae0\uddb5\ud90c\ude92\ud8d8\udf9e\ud831\uded2",
        25, 78484, -126281728, -6767207771636676455L, -95681L, true, true, (char) 41185, (char) 633,
        Double.longBitsToDouble(0x3fc46f084eafeca0L), Double.longBitsToDouble(0x3feeda2356ebd2adL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.math.BigInteger:26002 |a0=[B:[[-116, -75, 90, -66, 11, 37, 90, 75]]\0121=[B:[[101, -110]] |a0=[B:[[-116, -75, 90, -66, 11, 37, 90, 75]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 10, 4, 15, "\ud8bc\udde5\uda8a\udeee\ud83b\udd55\u978a\ud87b\udc5c\ud9b4\udf31\udb54\udda6\udbc7\udccb\ud949\udd28\udb7f\udfba\ud81a\udf0d\udb25\udd88\ud86c\udc9d\ud99f\udcd4\ud8fc\uddf5\udad4\udf62\ud9dc\udfd3\ud8c7\udf6d\udae1\udc85\ud9f6\udc48\ud95b\udd91\uf5a8\ud911\udf13", "\u17d1\u9022\ua5a4\uc266", "\udb79\udf0d\u32b2\uda81\udee7\udbab\udf64\u80df",
        53, 721, -1414968283, -7099306566618830596L, 36518L, false, false, (char) 24843, (char) 44435,
        Double.longBitsToDouble(0x3fe932f2c228aab1L), Double.longBitsToDouble(0x3fedd4ac6147b5b6L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=[B:[[106, 66, 82, 97, 118, 110, 100, 71]] |a0=[B:[[-116, 20, 90, -66, 119, 70]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[106, 66, 82, 97, 118, 110, 100, 71]] |a0=[B:[[-116, 20, 90, -66, 119, 70]]\012",
        Z.run(T, 2, 12, 15, 3, "\ud8bc\udd44\uda8a\udeee\udba7\ude76", "\u7301\u4039\u8c2f\u2730\u3f47", "\udb23\udde6\ud99f\udcd4\udbe0\udd1b",
        30, 1275, -1753470266, 2406738427354546219L, -60334L, false, false, (char) 43106, (char) 10549,
        Double.longBitsToDouble(0x3fce407b59de5bb0L), Double.longBitsToDouble(0x3fe74f0119721810L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-116, 20, 5, 32, 86, -113, 49, 109]]\0121=java.lang.Boolean:true |a0=[B:[[-116, 20, 5, 32, 86, -113, 49, 109]]\012",
        Z.run(T, 2, 3, 3, 13, "\ud8bc\udd44\ud835\udc50\u0986\ud9bf\ude61\ud99d\udc42\udacf\udd9e\ud959\udfec\udbc7\udc33\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9b3\udccf\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\u6d3f\u1869\u29df\u5944\u31b9\u9901\u6fcb\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u090d\uc142", "\ud85e\udfb6\ud97c\udd32\ud82f\udce6\udbe3\ude81\ud8d2\ude9d\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udff4\udafd\udf16",
        51, 67310, 569836445, -7465345772091886527L, -54460L, false, false, (char) 5882, (char) 28686,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fdab8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.math.BigInteger:7334917 |a0=[B:[[-116, 20, 98, 45, 119, 70, -113, 101]]\0121=java.math.BigInteger:7334917 |a0=[B:[[-116, 20, 98, 45, 119, 70, -113, 101]]\012",
        Z.run(T, 2, 10, 10, 15, "\ud8bc\udd44\uda92\ude5d\ud9a7\udd76\ud9bf\ude95\ud99d\udc42\udacf\udd9e\ud97e\udede\ud832\udc61\ud924\udd6c\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\uda58\udd1f\ud844\udc11\ud8fc\uddf5\uda6c\udfad\ud9ed\udf69\udbe9\udf49\udb8d\uddd0\ud9f4\ude64\uf323\ud88d\udce1", "\u51d9\u1869\u29df\u5944\uc6c2\u3257\u6fcb\u2a60\u09d0\u9aa5\u5b49\u3c61\ucd2c\u6dfa\u5b10\u1829\ub37b\uc142", "\ud8a9\udf6b\ud97c\udd32\udaad\udee4\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\ud804\udd6b\udbba\ude34\udacd\udc2c\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udf75\udb8f\ude19",
        34, 67310, 569836445, -7465291135812914111L, -54460L, false, true, (char) 57519, (char) 34777,
        Double.longBitsToDouble(0x3fa67a135201d3a0L), Double.longBitsToDouble(0x3fdd73aef3cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-116, 20, 61, 112, -127, 51, -113, -93]]\0121=java.math.BigInteger:0 |a0=[B:[[-116, 20, 61, 112, -127, 51, -113, -93]]\012",
        Z.run(T, 2, 10, 10, 15, "\ud8bc\udd44\ud96d\udca0\udbb1\udd63\ud9bf\uddd3\ud99d\udc42\udacf\udd9e\ud97e\udede\udbc7\udccb\ud949\udd28\udb7f\udfba\ud892\uddc0\uda65\uddd3\u409c\ud983\uddd4\ud8e8\udd08\ud81a\ude06\ud9dd\udc00\ud8b9\udcca\ud8f9\udfe7\uda93\udd06\uda43\udc22\ud933\udd59", "\u51d9\u1869\u4604\u6c93\ud11a\u00ea\u8993\u8d56\u9f80\u99ae\u8936\u685c\u332d\u6dfa\u3927\u9d30\u090d\ub60c", "\uda49\udc36\ud99e\udee6\ud82f\udce6\ud92c\udf04\ud8e0\udcc6\udbf3\udc2e\ud8de\udf59\udad7\udef4\ud9d5\ude66\udacd\udcc7\ud923\udf1b\uda1e\udf41\udac6\udf54",
        47, 87145, 1669939695, 6445102073287836675L, 39790L, true, true, (char) 60259, (char) 41973,
        Double.longBitsToDouble(0x3fe54ff64b22bfebL), Double.longBitsToDouble(0x3fcb63e9d32ca2a4L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=[B:[[-116, 53, 90, -66, 30, 55, -113, -27]] |a0=[B:[[-116, 53, 90, -66, 30, 55, -113, -27]]\0121=[B:[[-116, 53, 90, -66, 30, 55, -113, -27]] |a0=[B:[[-116, 53, 90, -66, 30, 55, -113, -27]]\012",
        Z.run(T, 2, 11, 11, 14, "\ud8bc\udd65\uda8a\udeee\uda4e\udf67\ud9bf\ude15\ud99d\udc42\udacf\udd9e\ud97e\udede\u2b4f\ud812\ude0d\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6", "\ub47d", "\udbbd\ude08\ud9f4\ude64\ud915\udfe0\ufa5f\ud8f8\uddd8\ud825\ude79\ud8e9\udf52\ud99d\udfb4\ud946\udf68\uce2a\ud877\udca3\ud873\udf6c\ud973\ude0f\uda2b\udea5\ud869\udfeb\ud9cb\udec5\ud813\udccc\udb6c\udccc\ud82e\udc05\ud85f\udf1a\ud915\udd7d\ud91d\udc24\ud968\udfac\uda90\udce6\ud816\udd99\ud80e\udfca\uda3b\ude04\ud987\udc4d\ud83b\udc2f\ud92c\udf04\u7e1f\u40af\uda04\udf26\ud8da\udc6a\udb8e\udd74",
        25, 15117, -725223573, 7668911522595653497L, 50244L, false, false, (char) 56691, (char) 26111,
        Double.longBitsToDouble(0x3fd66ff3973bcdc0L), Double.longBitsToDouble(0x3fec990fbc419865L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-112, 123]]\0121=java.lang.Boolean:false |a0=[B:[[-112, 123]]\012",
        Z.run(T, 2, 3, 3, 15, "\udac0\udeab", "\u2bee\u9821\uc634\u361a\u072b\u2730\u1f73\u1886\u8622\u8528\u1482\u220b\ub47d\ubffe\uaee6\u0e93", "\ud88d\udce1\ud929\uded3\uda70\udd9f\ud85f\udd82\udb1b\udec0\ud946\udf68",
        36, 65510, -1288112384, -4274088422826745829L, -65175L, true, true, (char) 11511, (char) 50364,
        Double.longBitsToDouble(0x3fd41e10dd11b6f8L), Double.longBitsToDouble(0x3fdf6ee521f93af4L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-109, 61]]\0121=java.lang.Boolean:true |a0=[B:[[-109, 61]]\012",
        Z.run(T, 2, 3, 3, 15, "\ud9c3\ude6d", "\u2bee\u9821\uc634\uc2d7\u072b\u2730\u3f47\u1886\u8622\u8528\u1482\u220b\ub47d\ubffe\uaee6\u0e93\ub4e8\u7319\u0f67\u90f8\u7ecb\u51d9\u1869\u29df\uc1fd\uc387", "\uda93\udf57\ud8ad\udca7\ud9cb\udf4d\udb7b\udedf\udb69\udf45\ud82e\udc08\ud85f\udf1a\ud915\udd7d\uda63\udc27\ud968\udeeb\ud894\ude0c\u6c6c\u9a51\ud875\udc3d\ud97c\udd32\ud82f\udce6",
        4, 77206, -1785986520, -4567903764070799033L, 8884L, true, true, (char) 43008, (char) 18220,
        Double.longBitsToDouble(0x3fe710a3b149fc3fL), Double.longBitsToDouble(0x3fdef51bb460c712L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=[B:[[106, 66, 82, 97, 118, 111, 72, 114]] |a0=[B:[[-116, 20, 90, -66, -127, -21]]\0121=[B:[[106, 66, 82, 97, 118, 111, 72, 114]] |a0=[B:[[-116, 20, 90, -66, -127, -21]]\012",
        Z.run(T, 2, 15, 15, 3, "\ud8bc\udd44\uda8a\udeee\udbb1\udd1b", "\u2446\u9f4f\u8c2f\uc919\u7a6e\uceb7\u8622", "\ud8d6\udff5\uda6c\udfad\udac1\udd66\uda24\udd73\udb71\udf05\ud977\udff5\ud816\udddc\ud888\ude43\u0d86\ud856\udfe4\ud841\udd05\udb1b\udec0\u7aa4\uce2a\ud852\uddae\udb36\udf95\udb31\udf5b\ud8dc\ude2b\ud8ce\udcff\ud900\udd81\uafe4\uda78\udcae\ud9fd\udfd3\ud921\udcff\ud8c8\uddbb\ud901\udeff\u6e12\uda94\udd4e\udb69\udef1\uda30\ude54\ud883\uddea\udb1c\udc55\ud8b5\uddf1\ud8f5\ude6b\udb8d\udea3",
        7, 7448, -272167376, 5569649575239514944L, 2504L, true, false, (char) 7029, (char) 36200,
        Double.longBitsToDouble(0x3f60c66ccc89d400L), Double.longBitsToDouble(0x3fbc40e2f44b3878L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=[B:[[39, -36, -9, 54]] |a0=[B:[[32, 39, -36, 32, -9, 54]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 1, 3, "\ud950\udf57\udb0c\ude50\ud927\udc66", "\u7301\u4039\u8c2f\u2730\u8b22\u0bc9\u8d3b\u3116\u1482\u21df\ub446\u3d9c\u7675\u0b6f\ub4e8\u7319\u0f67\u90f8\ubf16\u51d9\u8072\u29df\u5944\u044b\u0ccc\u0537\u2a60\u09d0\u9aa5\u8b96\ub9ab\u0e5c\u4f14", "\ud968\udeeb\ud6fd\u4493\ud869\ude42\ud88e\uddb1\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\udb26\udcfd\uda31\ude35\ud87d\uddf8\ud8d2\udda4\ud891\udf9f\udbbe\udd58\ud930\udefe\ud972\udf06\udbfd\ude34",
        -1, 40901, -1453312143, -9159149738278041130L, -23425L, true, false, (char) 43948, (char) 9110,
        Double.longBitsToDouble(0x3fdb6e02cc46ee2cL), Double.longBitsToDouble(0x3fe14e280bdb80edL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=[B:[[-57]] |a0=[B:[[-9, -23, -85, 126, 31, 120, 127, 50]]\0121=[B:[[-57]] |a0=[B:[[-9, -23, -85, 126, 31, 120, 127, 50]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 8, 4, 14, "\udb27\udf19\ud8db\udcae\ud84f\udea8\udbaf\udf62\ud99d\udc42\udacf\udd9e\ud97e\udede\uda34\udf03", "\uc67c\u4824\u6101\u7091\u588a\u5b23\u6c12\u0b4b\u7c13\uc4e8\u8a82\ub7e2\u90f8", "\udabb\udeb7\udab4\udf1f\ud9fb\udfec\ueaef\udb68\uddee\udbd7\udd43\ud899\udf4a\ud8c5\udd19\ud8c6\ude9c\udb01\udef5\udb55\udd41",
        18, 71326, 713578522, -7985459850996485196L, 16631L, false, true, (char) 39537, (char) 20537,
        Double.longBitsToDouble(0x3fd33d0f6dae44c0L), Double.longBitsToDouble(0x3fefd16ffed06700L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 12, 12, 10, "", "\u9235", "\uda2c\udf2e",
        28, 33479, 149384008, 6113067752232569761L, 19334L, false, false, (char) 50632, (char) 12249,
        Double.longBitsToDouble(0x3fe65bcbb2c6b171L), Double.longBitsToDouble(0x3feecfa3e1aa00acL)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\0121=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 2, 15, 15, 0, "", "\u1a3e", "\ud9f8\udfd4",
        56, 46678, 149416972, 6113067752119421601L, -100000L, false, false, (char) 27186, (char) 36057,
        Double.longBitsToDouble(0x3fee5bc802c6038bL), Double.longBitsToDouble(0x3fe6ccbbe0d9b469L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=[B:[[49, -39, -48, 62, 31, 21, 81]] |a0=[B:[[49, -39, -48, 13, 62, 31, 21, 81]]\0121=[B:[[-43]] |a0=[B:[[49, -39, -48, 13, 62, 31, 21, 81]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 4, 0, "\uda61\udc09\000\ufa3d\udb6e\ude4f\ud945\udf81\ud9c6\udc32", "\ubea5\uae39\u0afc", "",
        25, 43874, 2030101644, 255513078768872134L, 39641L, false, true, (char) 45157, (char) 5638,
        Double.longBitsToDouble(0x3fe5a6b99e52c926L), Double.longBitsToDouble(0x3fed9e24070687cfL)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.binary.Base64:@?\0121=void |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 14, 7, 3, "\ud8bc\udd44\ucc64", "\u5004", "\000\ud949\udc86\000\uc46c\ud8be\uddce\udb23\udde6\u6eb5\ud8fc\uddc3\uda68\udc62\ud9dd\udc00\ud987\udec6\000+\ubab8\000\000\ud834\udef9",
        23, -1000, 0, 0L, -3220L, false, true, (char) 16965, (char) 39,
        Double.longBitsToDouble(0x3fae99dc73628880L), Double.longBitsToDouble(0x3fc0cf5d09ec0d24L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=[B:[[97, 119, 73, 85, 71, 110, 115, 105, 100, 109, 48, 61]] |a0=[B:[[107, 2, 20, 26, 123, 34, 118, 109]]\0121=[B:[[97, 119, 73, 85, 71, 110, 115, 105, 100, 109, 48, 61]] |a0=[B:[[107, 2, 20, 26, 123, 34, 118, 109]]\012",
        Z.run(T, 2, 15, 15, 11, "\ud99b\udd32\ud844\udd4a\u66ab\udb52\udda6\ud99d\udc28\ud9d2\udd60\ud996\udf14\udbc7\udccb\uda69\uddd9\ud86b\ude40\ub10d\ud905\ude00", "\u4378\u3967\u66a4\u874e\u50a9\ub4e8\u7316", "\udb86\udfab\ud84e\udc65\udb1b\udec0\ud946\udf68\uce2a\ud9a8\uddb1\udbb0\udedd\ud828\udca9\ud9cd\udd1c\ud892\udd89\udb5a\udfa1\ud982\udfb3\ud891\udd43\ud952\udf66\uda4f\udcdd\ud925\udfe1",
        38, 43201, -159095771, 7858490714252377783L, -19335L, false, false, (char) 22613, (char) 50672,
        Double.longBitsToDouble(0x3faf5ab7b90c1810L), Double.longBitsToDouble(0x3fe69bee43c66befL)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-87, -51, 5, 32, -85, 64, -113, 49]]\0121=java.lang.Boolean:true |a0=[B:[[-87, -51, 5, 32, -85, 64, -113, 49]]\012",
        Z.run(T, 2, 3, 3, 13, "\udad9\uddfd\ud835\udc50\udbdb\ude70\ud9bf\ude61\ud99d\udc42\udacf\udd9e\ud959\udfec\udbc7\udc33\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\udb4e\udc83\ud8fc\udeac\uda6c\udfad\ud9b3\udccf\ud8b9\udc9d\ud865\udc66\ud9f4\ude64\uf323\ud975\udcc3", "\u6d3f\u1869\u29df\u5944\u72e9\u7c5f\u3997\uab57\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u090d\uc142", "\ud963\uddb8\ud841\udd68\ud95e\udf43\udbe3\udef5\ud8d2\ude9d\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\ud966\uded9\ud973\udff4\udafd\udf16",
        51, 67310, 559285149, -7465345769222982591L, 18877L, true, false, (char) 48902, (char) 21964,
        Double.longBitsToDouble(0x3fdab8dc03cd08e6L), Double.longBitsToDouble(0x3fede2348bde6be7L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-116, 20, 5, 32, 4, 47, -113, 49]]\0121=java.lang.Boolean:true |a0=[B:[[-116, 20, 5, 32, 4, 47, -113, 49]]\012",
        Z.run(T, 2, 3, 3, 13, "\ud8bc\udd44\ud835\udc50\uda34\udf5f\ud9bf\ude61\ud99d\udc42\udacf\udd9e\ud986\udf82\udbc7\udc5d\ud949\udd28\udb7f\udfba\ud8a9\udec0\ud9aa\udeb3\udb23\udde6\ud99f\udcd4\ud8fc\uddf5\uda6c\udfad\ud9b3\udccf\ud8b9\udc9d\udb8d\uddd0\ud9f4\ude64\uda1a\uddb1\udb83\uddc8", "\u6d3f\u1869\u29df\u5944\u31b9\u5b69\u6f1f\u2a60\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\u7194\u9d30\u090d\uc142", "\ud85e\udfb6\ud97c\udd32\ud82f\udce6\udbe3\ude81\ud8d2\ude9d\udbf2\udfe1\ud8de\udf59\ud832\udc41\ud9e1\udc7c\udacd\udcc7\udb98\udf16\udb65\udcde\udac6\udf9a\ud97f\udea9\ud819\ude1a\uda8d\udfcc\ud973\udff4\udafd\udf16",
        51, 67310, 569836445, -7465345772091886527L, 14139L, false, false, (char) 5882, (char) 28686,
        Double.longBitsToDouble(0x3fa6e96c819d5830L), Double.longBitsToDouble(0x3fdab8dc03cd08e6L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=[B:[[14, -64, -4, 62, 31, -1, -26]] |a0=[B:[[14, -64, -4, 13, 62, 31, -1, -26]]\0121=[B:[[14, -64, -4, 62, 31, -1, -26]] |a0=[B:[[14, -64, -4, 13, 62, 31, -1, -26]]\012",
        Z.run(T, 2, 11, 11, 13, "\udb3e\uddf0,\ufa3d\udb6e\ude4f\ud82f\udc16\ua5ac\uda5a\udf20\ud9e7\ude4d\ud9ba\udc1c\ud8d7\udc3b\udb9c\udd27\udaee\udf9b", "\u95e0\u03f6\ubffe", "\udac1\udeb1\ud87b\udda2\udb44\udcb0\ud9e3\udd4c\uda15\udd48\ud992\udfd8\u0752\ud80e\udce4\udbc3\udce3\udb89\udeda\ud8be\udd44\udb95\udc6d\udba8\udf05\udb23\udfa2\ud8aa\uddc8\udb68\udc3d\ud863\udf0e\u11a1\uda34\uddbe\u7e91",
        -3, 6284, -1706133105, 4828082303767537116L, 74086L, false, true, (char) 41212, (char) 1732,
        Double.longBitsToDouble(0x3fdd9c3574b491a4L), Double.longBitsToDouble(0x3fe26624d11df946L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 9, 5, 3, "\ud8ef\udd9d\uda8a\udeee\uda91\udc6a\udb12\udf2b", "\u4039\u9500\u3a73\u3f47\u0c3a\u1351\u8528\u1482\u21df\u4ab6\ubf71\uaee6\u0b6f\uc383\u5216\u49c1\u90f8\ubf16\u51d9\u1869\u29df", "\udb3b\udde3\udb31\udf5b",
        13, 80627, -188516361, 9002695120304320520L, 31456L, false, false, (char) 3752, (char) 48799,
        Double.longBitsToDouble(0x3fd90df63394eb56L), Double.longBitsToDouble(0x3fdc01207a4f47c8L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:43353 |a0=[B:[[7, 113, -64, 86, -78, -127, 109, 18]]\012",
        Z.run(T, 2, 9, 10, 15, "\u8537\ud9a1\udef0\u0986\ud8e2\udcb1\ud99d\udc42\000\000\000\ud949\udd28\udb7f\udfba\ud8a9\udec0\000\000\000\000\000\000\000\000\000\uf23b\ud88d\udce1", "\000\u1777\u29df\u6cd2\000\000\000\u298c\u09d0\u9aa5\u8b96\ub9ab\ucd2c\u6dfa\ucee9\u1ca0\u090d\uc142", "\ud85e\udfb6",
        47, -1000, -1978389131, -6179299695424437720L, -94183L, true, true, (char) 10607, (char) 47019,
        Double.longBitsToDouble(0x3feb5d84aa66d4c5L), Double.longBitsToDouble(0x3f14000000000000L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 6, 5, 3, "\ud8bc\udd44\uda8a\udeee\udb01\udf19\ud9bf\uddd3\ud877\udd26\udacf\udd56\udb2a\ude74\ud838\ude3e\ud949\udd34\udb7f\udfba\ud81a\udf0d\ud8c4\udcd9\udb23\udde6\uda60\udc22\ud8fe\uddd0\uda6c\udfad\ud995\udd73\ud835\udc80\ud876\uddc9\ud9f6\udd03\uf323\ud88d\udcd4\ud929\uded3\ud8f9\ude24\ud9d7\udf84\ud97c\udfdb\ud97b\ude77\ud8e1\udc7e\uda84\udf6c\uda3c\ude52\udb0d\udd07\ud9ad\udd42\udb1e\ude3e\udb72\udcf7\udb17\uddfa\udb8d\udd11\ud81b\udff6\ud85f\udf1a\ud9ee\udd8a\uda6f\udc7c\ud968\udeeb\ud6fd\udbfb\udd92\udbc0\ude72\ud875\udc3d\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\ud8de\udf59\udb58\udfb6\uda8c\udf18\ud9d0\udd95\u03d8\ud866\udffc\ud832\udc9b\udb09\udf46\ud96f\udfff\uda2b\udd54\ud9b3\ude85\ud93d\udf00\uda2f\udebd\udb59\udfb6\udae7\udebf\udb27\ude35\ud8bd\udcb3\udb29\udf62\ud859\udcd7\ud86e\udfc6\udb92\udc77\ud92f\udc40\udb0c\udee1\ud833\ude59\udaaf\udfab\udb8d\udf88\ud8ac\udc19\udb9c\udc42\udbc2\udd0e\u78ec\udae2\udecf\udab8\udf0c\ud847\udf3d\udb35\udfbc\ud89b\udf42\ud9c5\udd49", "\u8f04", "\uda41\udc53\uda6d\uddff\ud890\udde1\ud815\udf2b\udabc\ude83",
        5, 65748, -2141968825, -8349164178572644848L, 77386L, true, true, (char) 28605, (char) 63575,
        Double.longBitsToDouble(0x3f9eb07751b96940L), Double.longBitsToDouble(0x3fe3d219d8b40e27L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=[B:[[39, -36, -9, 54]] |a0=[B:[[32, 39, -36, 32, -9, 54]]\0121=[B:[[39, -36, -9, 54]] |a0=[B:[[32, 39, -36, 32, -9, 54]]\012",
        Z.run(T, 2, 11, 11, 14, "\ud950\udf57\udb0c\ude50\ud927\udc66", "\u7301\u4039\u8c2f\u2730\u819b\u0bc9\u8d3b\u3116\u1482\u21df\u1a4f\u3cdc\u7675\u0b6f\u0a06\u689c\u6f83\u90f8\ubf16\u51d9\u8072\u29df\u5944\u044b\u0ccc\u0537\u2a60\u09d0\u9aa5\u8b96\ub9ab\u0e5c\u4f14", "\ud968\udeeb\ud6fd\ud8b9\udd66\ud869\ude8c\ud88e\uddb1\ud97c\udd32\ud82f\udce6\ud92c\udf04\u7e1f\udbf2\udfe1\udb26\udcfd\uda31\ude35\ud87d\uddf8\ud8d2\udda4\ud891\udf9f\udbc0\uddff\ud902\udd13\ud972\udf07\udbfd\ude34",
        -1, 40901, -1453312143, -9159149740761069098L, -86758L, true, false, (char) 43948, (char) 31125,
        Double.longBitsToDouble(0x3fdb6e02cc46ee2cL), Double.longBitsToDouble(0x3fe14e280bdb80edL)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=[B:[[]]\0121=java.math.BigInteger:1746278 |a0=[B:[[32, 71, 113, -12, 86, -78, -127, 109]]\012",
        Z.run(T, 2, 9, 10, 6, "\ud850\udd77\ud9a1\udf24\u0986\ud8e2\udcb1\ud99d\udc42\000\000\000\ud949\udd28\udb7f\udfba\ud8a9\udec0\000\000\000\000\000\000\000\000\000\ud93c\ude3b\ud88d\udce1\udb2d\uded5\007\000\udb1b\uddce\ud946\udf68\udbdf\udcbf\000\000\000\udaa9\udf3c\ud8ad\udca7\uda71\udc00\udb7b\udef0\udb69\udf45\ud82e\udc08\ud85f\udf1a\udb73\ude8c\ud995\udc20\ud968\udfac\ud997\ude3a\ud992\udc22\udb91\udcc6\ud85e\udfb6\ud9b3\udead\000\udbe3\ude81\ud8d2\ude9d\udbf2\udfe1\ud8de\udf59", "\u50a0\u79a5\u642f\u9458\ub2fd\u1a64\uc807\uc9eb\u051f", "\ud901\udf2e\udbc1\udc89\udb11\ude89\ud98c\udeec\ud8e0\udcd9\ud8de\udfe0\uda95\ude65\uda34\udf79\udbc9\udc3a\ud80c\ude10\udb19\udccb\uda1c\udc9f\ud8a3\udc41\udb66\udccb\ud93c\udeed\udbca\udf50\ud93a\udf52\ud997\udd82\ud998\udcb5\uda9b\udff1\ud93e\udf6b\ud805\udfd1\ud8e9\ude02",
        59, 14679, -1409595958, -3723299487343487343L, 51060L, true, false, (char) 20415, (char) 18248,
        Double.longBitsToDouble(0x3fe49fa0e53b3affL), Double.longBitsToDouble(0x3fcaafb9fc6fff8cL)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[22, 34, 90, -66, -127, -21, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[70, 105, 74, 97, 118, 111, 72, 114, 106, 54, 77, 61]] |a0=[B:[[22, 34, 90, -66, -127, -21, -113, -93]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 12, 3, "\ud946\udf52\uda8a\udeee\udbb1\udd1b\ud9bf\uddd3\ud99d\udc9b\udacf\udd9e\ud85c\udd4d", "\u3f47\u0bc9\u8622\u8528", "\uda6c\udfad\ud9dd\udc00\udb28\udc93\udb8d\uddea\ud9f4\ude64\udae5\udd34\ud818\udea2\ud929\ude6e\udb86\udfab\ud84e\udc65\udb1b\udec0\ud946\udf68\uce2a\ud852\uddae\ud828\udcee\ud844\udc22\udbaf\udcd2\ud95f\ude21\ud84a\udd2f\ud849\udc70\ud9c3\ude58",
        56, 64271, -809266845, 4616159933081226571L, 54522L, false, true, (char) 27691, (char) 25790,
        Double.longBitsToDouble(0x3fcd5c68e476f1f4L), Double.longBitsToDouble(0x3fe8699e678d0919L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-123, 124, -27, -27, 126, -59]]\0121=java.lang.Boolean:false |a0=[B:[[-123, 124, -27, -27, 126, -59]]\012",
        Z.run(T, 2, 3, 3, 3, "\ud8b5\udcac\udb15\ude15\udaae\uddf5", "\uc432\uc8a5\u43fa\u00a2\uc55f\u45e6\u6ea0\u96cf\u1318\u9a6e\u78d0\ubffe\uaee6\u6f95\ub4e8\u3dee", "\udac4\udf09\ud8dc\udc2d\udaf2\ude4b\udaf6\udf7f",
        29, 43896, -874301880, 6254746815198982391L, 57704L, false, true, (char) 51897, (char) 47267,
        Double.longBitsToDouble(0x3fe82b737372f558L), Double.longBitsToDouble(0x3fcaaeaeb1b2eb08L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base64InputStream|read||new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|read|[B,int,int|new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64|avail||new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|containsBase64Byte|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.String|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|java.lang.String|static",
    "M|org.apache.commons.codec.binary.Base64|decodeInteger|[B|static",
    "M|org.apache.commons.codec.binary.Base64|discardWhitespace|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64InputStream|read||new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
    "M|org.apache.commons.codec.binary.Base64InputStream|read|[B,int,int|new:org.apache.commons.codec.binary.Base64InputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
