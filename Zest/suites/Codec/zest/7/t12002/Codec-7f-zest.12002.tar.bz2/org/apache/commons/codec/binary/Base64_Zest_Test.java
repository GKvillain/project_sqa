package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class Base64_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        35, 83109, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 6, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\u6950\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud833\ude75\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        35, 83109, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ue9e8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\udba9\udf6f\ud8f7\ude94\ue6af\ud8ba\udff7\ud8b9\udef7\ud88d\udf4d\ud84c\udf9f\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u7414", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\uac97\udb4f\udc54\udab9\udca3\ud94d\udfa9",
        38, 41998, -1667866969, -4609591745284411161L, 50858L, false, false, (char) 1250, (char) 31286,
        Double.longBitsToDouble(0x3fe35abe37864372L), Double.longBitsToDouble(0x3fccb46e703431fcL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 0, "\ud81a\uddc8\032\000\000\000\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udc42\ud81a\udec8\u2f62\000\000\000\ud9e8\udf94\ud84c\udfd5\udaee\udd42\ud949\ude28\ue51e\000", "", "\ud884\udeea",
        27, 7719, 1543503872, 5209764453528109056L, -100000L, false, true, (char) 54293, (char) 19168,
        Double.longBitsToDouble(0x3fe53fe660bb9c96L), Double.longBitsToDouble(0x3fccf800f0f7dafcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\012",
        Z.run(T, 1, 7, 7, 7, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1", "\u1a38\u407d\ub839\u60ec", "\uda30\uded6",
        35, 41916, 960166707, -2536615040745080415L, -63117L, false, false, (char) 24533, (char) 28436,
        Double.longBitsToDouble(0x3fea8dc62556858aL), Double.longBitsToDouble(0x3fe53fe660bb9c96L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 1, "\ud81a\uddc8\ud939\udfc0", "\u2c13\u767a\u9efe\u1c2a\u2a45\u9ab2\u2872", "\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1",
        57, 66045, -1534927193, 3731992168460442910L, -49331L, true, false, (char) 61116, (char) 50176,
        Double.longBitsToDouble(0x3fd8a0663774f9b8L), Double.longBitsToDouble(0x3fe079c9d1a1dcccL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\uda35\udd06\ud8ec\uddc0\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        35, 50301, 1477487865, 3694577661741641000L, 93307L, false, true, (char) 38480, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 3, 11, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\ud921\udca0\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud83f\udfa4\ud8ff\udea2\ud806\udd88", "\u5bd1\u75ee\u0a56\u5f07\u1056\u773b\ua2db\u9626\u279d\u1d95\u6f6f\uc22c\u098b\uc8d3\u54e9\u4df0\u1989\ua6e9\u6a9c\u8f55\u6dcd\u4a5b\u61d5\u784c", "\ud92d\udd58",
        50, 4571, -1078262896, 2177199435895472580L, -98237L, false, true, (char) 61289, (char) 46330,
        Double.longBitsToDouble(0x3fd933ea32771bbaL), Double.longBitsToDouble(0x3fef35237366ff03L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 1, 5, 1, "\udb0f\uddaa\udadb\udc44\ud9cf\ude8a", "\u50dc\u853d\u137e", "\udb2c\udfd5\ud98f\udf52\ud837\udd32\udb85\uddbd\ud9af\ude2d\udbde\udedd",
        35, 69857, -1663503955, -6592462094151732453L, 30038L, false, false, (char) 52882, (char) 61116,
        Double.longBitsToDouble(0x3fe1720665ec176aL), Double.longBitsToDouble(0x3fe99aa5ce8c393aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\012",
        Z.run(T, 1, 9, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud8e2\udfdc\udb28\ude3a\udb59\udf9f\ud822\ude7e\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda12\udd7f\ud968\udda0", "\u5bd1", "\ud9ec\udddd\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a3\udd20\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        35, 83109, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 8186,
        Double.longBitsToDouble(0x3fc036777b8d6aa8L), Double.longBitsToDouble(0x3feb40e8a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\uda79\udf05\ud82c\udc0b\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\u821b\ud9f2\udc2d\uda24\udc6e\udaa3\ude40\udabd\udc77\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udaec\ude78\ud9da\udc4d\ud98a\udfd0\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\uda90\udd05\ud8b5\uddb5\udb91\udcf5",
        37, 81517, 1834896714, 1441207851504759010L, 62411L, false, true, (char) 47170, (char) 47243,
        Double.longBitsToDouble(0x3fe67ac085283345L), Double.longBitsToDouble(0x3fd630334636c54aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 8, "\ud81a\uddc8", "\u76b5\u7cbc\u940f\u9da4\u1c2a\u1684\u9b87", "\ud81a\udec8\udb3b\udf19\ud81c\uddfd\udaa7\uddbd",
        35, 37581, -1667163509, -6592462094807157989L, 54158L, false, true, (char) 20460, (char) 23369,
        Double.longBitsToDouble(0x3fda1dccca56b8f2L), Double.longBitsToDouble(0x3f93484c4f417c00L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 1, "\ud81a\uddc8\ud9d7\uddbe\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udb03\udd3e\ud96c\udd11", "\u259f\ud354\u0647\ub428\u1a38\u407d\u191e", "\ud88f\ude7b\uda30\uded6\ud8da\udf8f\ud884\udeea\ud882\ude54\udba1\udffb\ud867\udf14\udb32\udd69\udab5\udd9a\ud9ac\uddb4\ud8ec\uddc7\ud9a9\udf18\ud998\uddf0\udaa3\ude0f\ud8a0\udccb\udb91\udcf5\udab6\ude56\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64\udaf4\ude11",
        44, 58629, -762263857, -3575359429662151689L, -34827L, true, true, (char) 24973, (char) 39152,
        Double.longBitsToDouble(0x3fc8b82d48bf5c7cL), Double.longBitsToDouble(0x3fe86ae2935f2443L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:6pgJkJ9w0GQ= |a0=[B:[[-22, -104, 9, -112, -97, 112, -48, 100]]\012",
        Z.run(T, 1, 0, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\000\ud894\udf89\u1340\ud82b\udfa6\ud957\udf56\uda4d\udc8a\udb97\ude38\u0091\udabf\udd3e\ud81a\udec8\u2f62\000\udbbc\udf1e\udafc\udff1\ud8e7\udec6\000\udaee\udc9b\000\ud870\udf58\ud968\udda0", "\u2f05", "\ud97f\ude92",
        47, 35633, 1212992811, 855842340220564090L, -49482L, true, false, (char) 0, (char) 45294,
        Double.longBitsToDouble(0x3faefb5f80000f80L), Double.longBitsToDouble(0x3fe7400000e21400L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 13, 5, 1, "\ud81a\uddc8\ud939\udfc0\udb81\udda9\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud8f5\udd44\ud958\udfb1\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92",
        47, 35633, 1212992811, 855842340220564090L, -63323L, true, false, (char) 64252, (char) 31298,
        Double.longBitsToDouble(0x3fe0c90f80e214a6L), Double.longBitsToDouble(0x3fdc5b4714e4af8cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[B:[[54, 112, 103, 74, 107, 74, 57, 119, 117, 115, 103, 61]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\012",
        Z.run(T, 1, 15, 14, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud984\udecb\ud98f\udc81\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\uda44\udea2\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        45, 51388, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 48930, (char) 25665,
        Double.longBitsToDouble(0x3fd4d6b00dc6b572L), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[B:[[52, 84, 69, 87, 86, 74, 57, 119, 118, 115, 111, 61]] |a0=[B:[[-31, 49, 22, 84, -97, 112, -66, -54]]\012",
        Z.run(T, 1, 14, 13, 1, "\uda11\ude61\ud946\ude84\ud9cf\udea0\ud8ee\uddfa\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud845\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a", "\u407d\ub839\u2512", "\uda53\udea4",
        3, 41916, -530777293, -2536615040745080415L, -63117L, false, false, (char) 24533, (char) 58972,
        Double.longBitsToDouble(0x3fed7b928ed5a4ceL), Double.longBitsToDouble(0x3fe3485d30bb9c96L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[B:[[54, 112, 103, 74, 107, 74, 57, 119, 117, 115, 103, 61]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 11, 5, 8, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud926\ude3d\ud965\udc96\udb9a\udc8e\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\udb85\ude72\ud94d\udfa9\udb76\udea7\ud82b\udd67\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\ud84f\udfe8\ud8ca\udc70\ud855\udc56\ud8cc\udef1\uda13\ude64",
        41, 83109, 1477487629, 3694577661741641000L, 27771L, true, true, (char) 26928, (char) 42875,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 1, "\000\032", "", "\u7eba\ud957\udee7",
        59, 32290, -2125031791, 6433532448496958339L, -100000L, true, true, (char) 50860, (char) 39124,
        Double.longBitsToDouble(0x3fdadb559c0001b0L), Double.longBitsToDouble(0x3fe8dd24151e33caL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-22, -104, 1, -112, -97, 112, -70, -56]] |this=org.apache.commons.codec.binary.Base64:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 3, 1, 1, "\ud81a\uddc8\ud931\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        35, 83109, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[B:[[54, 112, 103, 61]] |a0=[B:[[-22, -104]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 11, 5, 8, "\ud81a\uddc8", "\u279c\u2216\u5124\u6007\u1c2a\u1684\u9b87", "\ud81a\udec8\udaec\ude12\ud97d\udc41\udbaa\udf83",
        7, 69857, -1663503955, -6592462094807157989L, 54177L, false, true, (char) 2657, (char) 23369,
        Double.longBitsToDouble(0x3fda1dccca56b8f2L), Double.longBitsToDouble(0x3f93484c4f417c00L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-41, -106, -111, -11, 104, -76, -25, -98]]\012",
        Z.run(T, 1, 9, 5, 1, "\ud807\udec6\udac1\udf25\ud998\udfe4\ud917\udfce\ud85b\udeef\ud90c\udcc6\u0d6b\ud935\uddac\ud961\udd32\ud9d1\uddaf\ud837\udf2d\udbe7\udcef\udb34\udd90\udbb3\uddc9\ud991\udf2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\ubc9f", "\ud97f\ude92\udacc\udee9\ud9be\udd22\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud8c3\udfa4\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\ud997\ude6d\ud854\udfb1\ud8cc\udef1\uda13\ude64",
        25, 32278, 1477487629, -1279736086351738773L, -28730L, false, true, (char) 46869, (char) 8227,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.math.BigInteger:114 |a0=[B:[[99, -10, -112, -9, -97, 112, -70, -56]]\012",
        Z.run(T, 1, 9, 5, 1, "\ud993\udc26\udbc0\udc27\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63", "\u1684\u20d3\u2872\u917e\uacd3\u5c99\u9a80\u3110\u206b\u1946\u39a9\u0873\u407d\ub839\u60ec\u0ee0\u9614\u5bd1\u775a\u0a56\u5f07\u75f7\u04ff\u13ca\u8999\u1835\u6948\uab49\uc216\u098b\u3c16\u1efb\u17a8\u9fd2\ua6e9\u6a9c\u8f55\ud08d", "\uda03\udda1\uda4e\udd3d\ud9fe\uddd4\ud92d\udd58\ud8a6\udf33\udb7b\uddd9\udb34\udc1f\udba0\udcc5\ud9ae\ude1a\udb51\udd50\ud90a\udd87\udb5c\udc2b\ud854\udfc9\ud97b\udf1e\ud8da\uddee\ud90a\udc88\udb7f\udc62\udb43\udf20\ud94d\udda5",
        32, 51034, -1882196660, -342027680755410439L, -44779L, false, false, (char) 2521, (char) 18546,
        Double.longBitsToDouble(0x3fc62bc5dbd2f948L), Double.longBitsToDouble(0x3f8ad7e390e82a00L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 4, 5, 1, "\ud81a\uddc8\ud92b\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        35, 83109, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[B:[[54, 112, 103, 74, 107, 74, 57, 119, 117, 115, 103, 61, 13, 10]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\012",
        Z.run(T, 1, 15, 5, 7, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud8fc\udc1a\udb3d\udcfa\ud964\udecb\ud886\udcd1\uda4d\udcc6\ud953\udda0\ud845\udfa3\ud81a\ude5f\ud974\udfd5\ud8d0\uddc6\ud880\udcdb\udafd\ude47\udb0e\ude5a\ud85d\udca6\ud911\udeed\ud949\udec9\uda3a\udc7f\ud968\udda0", "\u5bd1", "\udaac\udfea\udb03\udd63\u8fd5\udafa\udd6d",
        43, 51482, -1556582593, 3867971799212218558L, -96135L, true, false, (char) 31298, (char) 41030,
        Double.longBitsToDouble(0x3fcc42801716d1c4L), Double.longBitsToDouble(0x3fa04f637893f0b0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb20\udfae\ud848\uddd1\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u4543\ua74e\u5e79\u5f07\u1056\u773b\ua2db", "\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\ud908\ude14\ud94d\udf34\ud8da\udf29\ud9a6\udc73\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\udb15\udfcb\udb7f\udcf0\udaf4\udde2\uda03\udda1\uda4e\udd3d\ud9fe\uddd4\ud92d\udd58\ud8a6\udf33\udb7b\uddd9\ud96d\udfc6\udb4e\udd21\ud9ae\ude1a\udb51\udd50\ud90a\udd87\udb5c\udc2b\ud91b\udd6c\udb78\udd24\ud877\udc7c\ud8f1\udd3b\ud95e\udd18\ud997\udef6\ud9ba\udc1a\uda6e\udd0e",
        41, 60937, 1165879214, -591214760794071959L, 61651L, true, false, (char) 22629, (char) 50563,
        Double.longBitsToDouble(0x3fdeb5ec029bff0aL), Double.longBitsToDouble(0x3fe6376b3326d692L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[B:[[-22, -104, -109, 36, -97, -52, -70, -56]] |a0=[B:[[-22, -104, -109, 36, -97, -52, -70, -56]]\012",
        Z.run(T, 1, 10, 1, 1, "\ud81a\uddc8\ud8c3\udd54\ud9cf\udefc\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9ac\udf5c\udbde\udedd\udafc\udfe9\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud9d0\udddb\ud91b\udec8\ud840\udff5\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\udae9\udc15\u4b10\ud912\udfe4\uda11\ude17",
        35, 83109, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 8186,
        Double.longBitsToDouble(0x3fc34e067ab874b4L), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 5, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud9d8\ude28\ud82b\udfae\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udeaa\ub78a\udb0e\uddb0\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud90f\ude53\ud8a6\udf6d\uda13\ude64",
        35, 83109, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[B:[[-22, -104, -112, -97, 112, -70, -56]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\012",
        Z.run(T, 1, 10, 7, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\udac0\udcd6\ud98d\udf63\ud82c\udc60\ud957\udf56\uda0a\udd49\ud82b\udca3\ud84c\uddb2\udbd2\udeef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafe\udef1\udb0e\ude5a\ud8c0\udf8e\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\u46c9\ud9ac\udd29\ud8ec\uddc7\udbcc\udd28\ud9e8\uddee\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud9c7\udf07\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        1, 83109, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[B:[[54, 112, 103, 74, 107, 74, 57, 119, 117, 115, 103, 61]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 14, 5, 6, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\u6950\ud965\udc96\udb97\ude38\ud8e2\udf23\udae8\ude83\ud84c\udcce\udaec\ude12\ud9af\ude2d\uda0f\uded4\udaf9\uddd0\udb0e\ude5a\ud833\ude75\udaee\udd42\ud951\udd28\uda3a\udc7f\uda5b\udd42\ud980\udd5c\ud88f\ude7b\uda30\uded6\udb25\udead\ud89c\udec4\ud97f\ude92\ud8be\ude8c\ud867\udf16\udb9e\udd00\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9e0\udd19\u71ea\ud904\udd77\ud86d\udfaa\ud98e\udd35\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda11\ude64\udaf4\ude11\uda03\udda1\uda4e\udd3d\ud9fe\uddd4\ud92d\udd58\ud8a6\udf33\udb7b\uddd9\ud96d\udfc6", "\u336e\u2257\ua1af\u5a76\uc8eb\u7d2f\u1e73\uad21", "\u5adc\ud9bd\ude5d\ud9c7\udc8f\ud823\udce2\uda92\udd20",
        16, 84838, -490775727, 612518651290409003L, -49061L, false, true, (char) 6448, (char) 543,
        Double.longBitsToDouble(0x3fc0d50b4659ef90L), Double.longBitsToDouble(0x3fd07e9579f0b79eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 0, 11, "\udbe7\udc6e", "\000", "\ud82c\udc60",
        54, 63249, 674915290, 2834618566488653568L, 24416L, false, true, (char) 32372, (char) 26705,
        Double.longBitsToDouble(0x3fd6c88c07c16abaL), Double.longBitsToDouble(0x3fd798cca0009470L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-65]]\012",
        Z.run(T, 1, 7, 7, 7, "\u73ef", "\000\000\u8b43\u20fe\u02fb\u1643\u9b87", "\ud80b\udf45\udaec\ude12\000\000",
        -5, 41504, -1663504128, 244808840904704L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe99aa0000f393aL), Double.longBitsToDouble(0x3fda1dc00a56b8f2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:ng== |a0=[B:[[-98]]\012",
        Z.run(T, 1, 0, 7, 0, "\u95ce", "\u4665\u8457\u763a\u9efe\u1c2a\u1684\u9b87", "\ud80b\udf45",
        0, 21757, -1389000769, 509848677888L, -25927L, true, true, (char) 4328, (char) 55601,
        Double.longBitsToDouble(0x3ecc800000000000L), Double.longBitsToDouble(0x3fe82df8022e4000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[-5, 89, 123]] |a0=[B:[[43, 49, -1, -124, 108, 55, -88, -46]]\012",
        Z.run(T, 1, 7, 7, 7, "\ud85b\ude61\uda2f\udfb4\ud99c\udd67\ud9d8\udc02\udb86\udfa9\ud98d\udf63\ud844\udf60", "\u9b87\u83e2\u7c34\uacd3\u6eba\u9a80\u259f\ud354\ucd07\u41cb\ud711\u01bc\ubdea\u6098\u5839\u966a\u8a4a\u75f4\u0a56\u1e4e", "\ud8de\udd1e\ud9db\uddba",
        12, 28512, -1195062308, -8824210486737937066L, 69500L, true, false, (char) 44447, (char) 21264,
        Double.longBitsToDouble(0x3fe55f2c3b291ce5L), Double.longBitsToDouble(0x3fef787443e4b9e4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[B:[[-128]] |a0=[B:[[-22, -104, 9, -112, 13, 7, 103, 71]]\012",
        Z.run(T, 1, 7, 7, 7, "\ud81a\uddc8\ud939\udfc0\ud93d\udf37\ud897\udf77\udb86\udfc6\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1", "\ub02b\u407d\ub839\u60ec\u69c5\u84a4", "\ud884\udeea\ud97f\ude92\uda6d\ude43",
        18, 82811, 199266399, -1110715128833609921L, 24079L, false, false, (char) 20189, (char) 3410,
        Double.longBitsToDouble(0x3fe2000fe7f93b04L), Double.longBitsToDouble(0x3fe7680e5664911aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-22, -13]]\012",
        Z.run(T, 1, 7, 7, 7, "\ud81a\udd23", "\u3abe\u66bd\u85f0\u7960\ub501\u4425\u67f9", "\u3513\ud998\ude07\ud9af\udeae\udbde\udedd",
        47, 69857, -1663503955, -6592462095834762469L, 54149L, false, true, (char) 51069, (char) 57046,
        Double.longBitsToDouble(0x3fda12764a56b8f2L), Double.longBitsToDouble(0x3f93484c4f417c00L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[100, -107, 9, -112, -14, 61, -26, 64]]\012",
        Z.run(T, 1, 7, 7, 4, "\udb94\uddc5\ud939\udfc0\ud822\udf6d\ud816\udc70\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud978\udd66\ud93f\udcbe\udb97\ude38\ud837\udf1a\udbe7\udcef", "\u9a80\u7507\ubce6\ubb52\ub3a8\u1a38\u407d\ub839\u2512\u7e04\ucdee\u5bd1\u75ee\u0304\u5fa5\u1056\u773b\ua2db\u3ccd\u08f3\u692c\u6f6f\uc22c", "\u8f5f\ud900\udd71\udafd\udd66",
        36, 62390, -875601835, -2631158910264806351L, 91342L, true, true, (char) 57445, (char) 61603,
        Double.longBitsToDouble(0x3fef4334c3486369L), Double.longBitsToDouble(0x3fe640bbb7878133L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 5, 11, 13, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\uda3b\ude43", "\u1c2a\u1684\u9b87\ub8bc\u0bf5\u78ef\u71ad\u9b45\u259f\ud354\u0647\ub428\u1a38\u5160", "\ud871\ude1f\uda14\ude4e\ud87f\ude37\udabd\udc7a\ud97b\udd51\ud97f\udedf\udbd3\udc05\udaea\udf16\udafa\udd6d\udbda\ude4e\ud89c\ude63\ud892\udc47\ud909\udf6c",
        38, 41998, -1667866969, -2538780340332120177L, -46700L, false, true, (char) 22289, (char) 10076,
        Double.longBitsToDouble(0x3fe99a52b4375d62L), Double.longBitsToDouble(0x3fde08e952c11602L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 7, 7, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud9b2\udffe\u5498\ud9ea\udfc1\udb83\uddf4", "\u1f7b\u5c66\u9a80\u46e8\u7398\u6506", "\ud949\ude28\udbc2\udfa2\ud986\udf59",
        13, 87445, 1087123205, 1687260165440134380L, -47415L, true, false, (char) 65113, (char) 24533,
        Double.longBitsToDouble(0x3feee519c351b8c4L), Double.longBitsToDouble(0x3fd56858ad4ff998L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[26, 102, -28, 44]]\012",
        Z.run(T, 1, 7, 14, 12, "\ud84a\udd96\uda14\udc5c", "\u8caa\u7250\uc816\uc86b\ud50f\u4188\u2872\u0e5b\u28a6\uca86\u00d3\u843f\u5309\u9b40\u0a5e\u9f8e\u4a03\u667b\u60ec\u8169\uc227\u5bd1\u8551\u7405", "\ud966\ude2d\ud961\ude22\ud976\udc7d\ud989\udd01",
        7, 39546, -980804855, -4098543002811378199L, 29147L, false, true, (char) 56599, (char) 25456,
        Double.longBitsToDouble(0x3fc5443fc9af8860L), Double.longBitsToDouble(0x3fccc80402ee93b8L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[B:[[54, 112, 105, 49, 74, 112, 47, 90, 117, 115, 103, 61]] |a0=[B:[[-22, -104, -75, 38, -97, -39, -70, -56]]\0121=[B:[[]] |a0=[B:[[-22, -104, -75, 38, -97, -39, -70, -56]]\012",
        Z.run(T, 2, 15, 7, 3, "\ud81a\uddc8\udae5\udf56\ud9cf\udf09\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud957\udf56\ud8c3\udfe3\udb52\uddc9\ud830\udd69\udbf5\udcab\ud81a\udec8\udaec\ude12\uda0d\udd7c\udb03\udeec\udafc\udff1", "\u7d2d\u407d\ud119\uba66", "\uda30\uded6",
        11, 51333, 960166707, -2536615040745080415L, -63117L, false, false, (char) 24533, (char) 28436,
        Double.longBitsToDouble(0x3fea8dc62756858aL), Double.longBitsToDouble(0x3fe004f110bb9c96L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[B:[[-115, -114, -125]] |a0=[B:[[106, -13, 20, 89, 54, 68, 83, -83]]\012",
        Z.run(T, 1, 7, 7, 7, "\udb9a\ude23\udb44\udc89\ud966\udd74\udb83\udedd\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud8e5\uddd1\ud8cb\udc8c", "\u917e", "\ud9af\ude2d\udbde\udedd\ud8d2\udd3c\uc96c\ud918\ude7c\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0\ud980\uddf3\ud8d0\uddc7\uda30\udf93\ud8da\udf8f\ud884\udeea\ud97f\ude92\udba2\udc0f\ud867\udf14\udaf0\udde9\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19",
        18, 46031, -2088406853, 6865946243902312154L, -9072L, true, false, (char) 36729, (char) 25007,
        Double.longBitsToDouble(0x3fd127e5d9751f8cL), Double.longBitsToDouble(0x3fe87cb403aab404L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\0121=[B:[[]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\012",
        Z.run(T, 2, 7, 7, 7, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\udad8\ude21\ud981\ude15\ud98e\udf4f\ud838\ude81\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud9ea\ude8f\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1", "\u1a38\u407d\u06ec\u540b", "\uda34\ude57",
        35, 41916, 960166707, -2536615040745080415L, -63117L, false, false, (char) 24533, (char) 28436,
        Double.longBitsToDouble(0x3fea8dc62256858aL), Double.longBitsToDouble(0x3fe53effd0bb9c96L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 8, 13, 14, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udae3\udef8\udb86\udfa9\ud995\udd63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1", "\u1a38\u7b4d\ubec3\u60ec", "\uda30\uded6",
        35, 41916, 960166707, -2536615040745080415L, -63117L, false, false, (char) 24533, (char) 28436,
        Double.longBitsToDouble(0x3fea8dc62556858aL), Double.longBitsToDouble(0x3fe53fe6607bdc96L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-22, -104, 9, -112, -97, 112]]\012",
        Z.run(T, 1, 2, 7, 7, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0", "\u767a\u9efe\u1c2a\u1684", "\udacf\udf3d",
        3, 90290, -293079243, -5965712876267955849L, -14779L, false, true, (char) 55601, (char) 59600,
        Double.longBitsToDouble(0x3fdb4a44c6dcd1d4L), Double.longBitsToDouble(0x3fe5dc805dec176aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=[B:[[-92, -86]] |a0=[B:[[-22, -104, 9, -112, -97, 112, 75, 112]]\012",
        Z.run(T, 1, 7, 7, 7, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udb7b\udfa0\udb86\udfb9\ud98d\udf63\ud82c\udc60\ud957\udf56\ud9fb\udcf0\u2958\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\ud996\udffe", "\u1a38\u407d\ub839\u60ec", "\uda30\uded6",
        35, 41916, 960166707, -348170188741126990L, -63117L, false, false, (char) 57937, (char) 32617,
        Double.longBitsToDouble(0x3f89f0ea378556c0L), Double.longBitsToDouble(0x3fe53f8446107296L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=[B:[[-66]] |a0=[B:[[118, 125, 9, -106, -97, 112, -70, -56]]\012",
        Z.run(T, 1, 7, 7, 5, "\udaa6\uddad\ud939\udfc6\ud9cf\udea0\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud957\udf56", "\u2872\u917e\uacd3\u5c99\u500c\u6231", "\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0\ud980\uddf3\ud88f\ude7b",
        15, 69427, 1421415916, 4123884604682412559L, -47477L, true, false, (char) 65113, (char) 24533,
        Double.longBitsToDouble(0x3feee519c351b8c4L), Double.longBitsToDouble(0x3fd56858ad4ff998L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[23, 45, -14, 10]]\012",
        Z.run(T, 1, 2, 15, 12, "\uda47\udd5d\ud922\udc3a", "\u3f3c\u767a\u9efe\u1c2a\u1684\u9b87\u2872", "\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1",
        57, 66045, -1536271449, 3731992168460442910L, -49331L, true, false, (char) 61116, (char) 39674,
        Double.longBitsToDouble(0x3fdec176a666a972L), Double.longBitsToDouble(0x3fe079c9d1a1dcccL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-22, -104, -20, 66, 36, 53, -70, -56]]\012",
        Z.run(T, 1, 2, 3, 7, "\ud81a\uddc8\ud81c\udd72\uda54\udc65\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud88b\udf8f\udab0\udf0a\udaeb\udec5\ud849\udc1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1", "\u1a38\u407d\u7439\u1c16", "\uda30\uded6\ud8da\udf8f",
        35, 72105, -590601642, 6663631594769403179L, 27610L, true, true, (char) 28436, (char) 54293,
        Double.longBitsToDouble(0x3fd56858ad4fdfa4L), Double.longBitsToDouble(0x3fc77392dc9ee8fcL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-22, -104, 9, -112, -127, -127, 13, -90]]\012",
        Z.run(T, 1, 2, 7, 7, "\ud81a\uddc8\ud939\udfc0\ud9b1\udcb1\udb3d\udcd6\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\uda7d\udc9e\ud837\udf1a\udb29\udcf0\ud81a\udec8\ud91b\udd67\ue862\ud956\udeb1\udaf8\udc20", "\u1a38\u309d\ub839\u60ec", "\uda02\ude1b",
        34, 2092, -1703678925, -7018480399442053734L, -63117L, false, false, (char) 13488, (char) 8088,
        Double.longBitsToDouble(0x3fea8dc62556858aL), Double.longBitsToDouble(0x3fe53fe6601dc696L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\012",
        Z.run(T, 1, 7, 7, 7, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud851\udfa9\ud8d1\udf02\ud85b\uddb6\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a", "\u407d\ub839\u60ec", "\ud9ab\udccd\udad3\udc65\uda41\udc4c\udb24\udff2",
        36, 35633, 1212992811, 855842340220564090L, -26562L, false, false, (char) 7620, (char) 9482,
        Double.longBitsToDouble(0x3fd9b1a66b58a498L), Double.longBitsToDouble(0x3fbe88f21e9d9a68L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 7, "\000\000\000\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\uaf15\udbe7\udcef\ud81a\udec8b", "\ud354", "\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0",
        13, 8485, 0, 1687259966450171904L, -91281L, true, true, (char) 10660, (char) 55390,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-22, -104, 9, -112, -11, 59, 12, 17]]\012",
        Z.run(T, 1, 7, 7, 7, "\ud81a\uddc8\ud939\udfc0\ud925\udc6b\udb3c\udc41\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1", "\u1a38\u407d\ub839\u60ec", "\uda30\uded6",
        42, 14958, 960166897, -2536615043215374190L, -63117L, false, false, (char) 24533, (char) 28436,
        Double.longBitsToDouble(0x3fea8dc62556858aL), Double.longBitsToDouble(0x3fe53fe660bb9c96L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[53, 61, -104, -15, 105, 21, -70, -56]]\012",
        Z.run(T, 1, 7, 7, 7, "\ud965\ude6d\ud9c8\udd21\ud999\udc45\udaea\uddf8\udb86\udfa9\ud888\udfe2\ud8d4\udeb6\ud9e5\udca3\ud965\udc96\udb97\ude38\udbed\udf54\udb3f\udca8\udb31\udcdc\ud820\ude18\ud9af\ude23\udbde\udedd\udafc\udff1", "\u97f6\ubcf7\ub839\u60ec", "\uda30\uded6",
        -3, 41916, 960166707, -6643897901320156968L, 24079L, false, true, (char) 23412, (char) 3410,
        Double.longBitsToDouble(0x3fdf79d432431e44L), Double.longBitsToDouble(0x3fce662a780831fcL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 1, 3, 8, "\uda58\uddc7\ud939\udfc0", "\u8669\u9d52\ua0ac\u1c2a\u1684\u990d\u2822", "\udaec\ude12\ud9af\ude2d\udbde\udedd\u0ed5",
        42, 66045, -154847833, 3731992254359788852L, -49331L, true, false, (char) 61116, (char) 11164,
        Double.longBitsToDouble(0x3fef60bb5333fdd9L), Double.longBitsToDouble(0x3fe3f6746ea1dcccL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 1, 7, 7, 7, "", "\u9072", "\ud803\udc20\ud82c\udc60\ud957\udf56",
        59, 32290, -2125031791, 6433532448496958339L, -34464L, true, true, (char) 50860, (char) 39124,
        Double.longBitsToDouble(0x3fdadb559d4f39b0L), Double.longBitsToDouble(0x3fe8dd24151e33caL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[85]]\012",
        Z.run(T, 1, 7, 7, 7, "\u2a85", "\u2876\ua127\u3449\u6458", "\udb97\ude38\ud837\udf1a\udbce\ude63\ud81a\udec8\uda18\udfdb\udacb\udc4a\udbde\ude5b\udb1c\udef1\ud9e8\udde7\u50d3\ud82a\udfeb\ud81d\udc2f\uda3a\udc7f\ud968\udda0\udb4e\uddfa\ud8a6\udd7b\uda30\uded6\ud8da\udf8f\ud91c\uded7\ud948\udf82",
        47, 35633, 1212992811, 855842340220564090L, 38634L, true, false, (char) 4120, (char) 64641,
        Double.longBitsToDouble(0x3fef7a470c968f7aL), Double.longBitsToDouble(0x3fcaf28050926b68L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 8, 7, 7, "\uda1c\uddfa\ud930\udd3a\ud9cf\udea0\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud957\udf56", "\ud0e3\u5c15\uacd3\u5c99\u9a80\u259f", "\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0\ud980\uddf3\ud88f\ude7b",
        20, 55870, 1421415916, 4123884604682412559L, -47477L, true, false, (char) 65113, (char) 54228,
        Double.longBitsToDouble(0x3feee0c34351b8c4L), Double.longBitsToDouble(0x3fd56858ad4ff998L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-39, -22, 7, -113]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 7, 5, 14, "\ud809\udd1a\ud937\udfbf", "\u2c13\u767a\u73bc\u1c2a\u2a45\u9ab2\u2872", "\ud82d\ude91\udbb0\udf92\udbde\udedd\udb28\uddf1",
        57, 66045, -485761921, -7941514159343056807L, -49331L, true, false, (char) 61116, (char) 50176,
        Double.longBitsToDouble(0x3fd8a0663774f9b8L), Double.longBitsToDouble(0x3fe079c9d055dcccL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[72, 88, -105, -97, 112, -70, -56, 21]]\012",
        Z.run(T, 1, 2, 14, 1, "\u8f78\ud888\uddc7\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63", "\u9d96", "\ud921\udd19\ud826\uddac\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\uda52\ude3c\ud84c\udf49",
        27, 41987, -1314923234, 2514178001144169965L, -28852L, true, true, (char) 23369, (char) 29549,
        Double.longBitsToDouble(0x3fe15ae3ca6e0811L), Double.longBitsToDouble(0x3fd7a0b6ce707872L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 4, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\uda35\udd06\ud8ec\uddc0\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\ud99a\udeac\udb17\udf47\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        35, 50301, 1477487865, 3694577661741641000L, 93307L, false, true, (char) 38480, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=[B:[[54, 112, 103, 74, 107, 74, 57, 119, 117, 115, 103, 61]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 15, 5, 12, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\udbf6\ude97\udb7f\udf50\ud837\udf1a\ud838\udc1a\ud81a\ude5c\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfe5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\uda35\udd06\ud8ec\uddc0\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud89a\udcc8\ud87e\udc12\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\ud806\udc63\u796c\ud8cc\udef1\ud94a\udf40",
        5, 49053, -653215495, 3745288705677733160L, 93307L, false, true, (char) 38480, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a1c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 3, 11, "\udbdf\ude8a\udada\udfb2\udbbd\udfce\u27e9\ud846\udc8a\ud9a5\udc06\ud82c\udc60\ud957\udf56\ud965\udc96\ud921\udca0\ud837\udf1a\udbe7\udcef\ud81a\udec8\ud86f\udd98\udb45\udf3e\ud825\udf42\ud8d9\udea3\udb8e\udecf\ud971\udff1\ud93e\udef0\ud83f\udfa4\ud8ff\udea2\ud806\udd88\ud882\udfe9\uda18\udd9e\udad8\udf3f\ud8d8\udff7\ud884\udeea\ud97f\ude92\udba1\udffb\ud867\udf14\ud8ae\udd88\ud88c\udcf7\udb95\udf26\ud90f\ude13\ud8bd\ude01\ud9f1\udc3e\ud8b1\ude22\ud8b0\udfb2\ud9ba\udc60\ud9a6\udc5b\ud98f\udee3\udb63\ude31\uda43\udf28\ud855\udd39\ud8cc\udef1\uda13\ude64\udaf4\ude11", "\u0c4a\u10f4\u124d\uc252\u76e2\u7329\ub90b", "\udbe0\udd5c\ud838\udef5\u19db\ud84b\uded9\udb8a\udc96\udbfc\udf18\udafc\udf43\udaa3\udc2c\udb8a\uddae\ud89d\udda9\udaa3\udfd0\udb13\ude85\ud929\udf73\uda50\udd19\udbba\udc51\ud8de\udf13\uda3c\udebb",
        31, 71743, -11271099, 5434536452295341283L, -37957L, true, false, (char) 1097, (char) 22637,
        Double.longBitsToDouble(0x3feb0088b2db38a5L), Double.longBitsToDouble(0x3fb4389b083fb9c0L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 6, 3, 11, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\ud921\udca0\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud83f\udfa4\ud8ff\udea2\ud806\udd88", "\u5bd1\u75ee\u0a56\u5f07\u1056\u773b\ua2db\u9626\u279d\u1d95\u6f6f\uc22c\u098b\uc8d3\u54e9\u4df0\u1989\ua6e9\u6a9c\u8f55\u6dcd\u4a5b\u61d5\u784c", "\ud92d\udd58",
        50, -973, 0, 2176927469976355268L, -98237L, false, true, (char) 61289, (char) 46330,
        Double.longBitsToDouble(0x3fd933ea32771bbaL), Double.longBitsToDouble(0x3fef35237366ff03L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 3, 11, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\ud921\udca0\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbaf\udebe\udafc\udff1\udb0e\ude5a\udb1e\udc07\udabb\ude22\ud83f\udfa4\ud8ff\udea2\ud806\udd88", "\u5bd1\u75ee\u0a56\u5f07\u1056\u773b\ua2db\u9626\u279d\u1d95\u6b6f\uc22c\u098b\uc8d3\u54e9\u4df0\u1989\ua6e9\u6a9c\u8f55\u6dcd\u4a5b\u61d5\u784c", "\ud88d\udfe8",
        7, 5503, -542191952, 2170756881872257476L, -98237L, false, true, (char) 61289, (char) 46330,
        Double.longBitsToDouble(0x3fd933ea32771bbaL), Double.longBitsToDouble(0x3fef35237763f426L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.String:ngmQ |a0=[B:[[-98, 9, -112]]\012",
        Z.run(T, 1, 0, 3, 11, "\u95ce\ud939\udfc0", "\u2c13\u767a\u9efe\u3b9e\u1684\uc3df\u27e1", "\udaec\ude12\ud9af\ude2d\udbde\udedd\uda74\udef0",
        57, 66045, -1534927193, -4236001469603962392L, -69562L, true, false, (char) 61116, (char) 39674,
        Double.longBitsToDouble(0x3fdec176a666a972L), Double.longBitsToDouble(0x3fe079c9d1000000L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.String:33qrFNE= |a0=[B:[[-33, 122, -85, 20, -47]]\012",
        Z.run(T, 1, 0, 0, 1, "\udb0f\uddaa\udadb\udc44\uf101", "", "\ud955\udeaa",
        59, 2454, -1480371959, 8709179045892171244L, -100000L, false, false, (char) 61868, (char) 31615,
        Double.longBitsToDouble(0x3fe8dd2414fc5adbL), Double.longBitsToDouble(0x3f85633e9a2b8780L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=[B:[[53, 66, 54, 114, 80, 104, 67, 122]] |a0=[B:[[-28, 30, -85, 62, 16, -77]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 11, 5, 1, "\udb14\udf4e\udadb\udc6e\uda40\udfe3", "\u764d\u4133", "\ud96f\udc9d\udb91\udcd5\ud9a3\ude1c\ud81a\udd43\ud8ae\ude84\uda9a\udcf2\uf479\udba9\udcb1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud973\udee8\udb7a\udea5\udb7f\udffd\ud808\udf38\ud87b\udf84\uda30\uded6\ud8da\udf8f\ud884\udeea\ud97f\ude92",
        57, 42257, -1733207206, -4645361953595976135L, -78959L, false, false, (char) 63412, (char) 20700,
        Double.longBitsToDouble(0x3febabe7ab05c590L), Double.longBitsToDouble(0x3fd2c46de60a73d8L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 8, 5, 1, "\udb0f\uddaa\udaac\ude9b\ud9cf\ude8a", "\u50dc\ub50b\u137e", "\udb2c\udfd5\ud98f\udf52\ud837\udd32\udb85\uddbd\ud9af\ude2d\udbde\udedd",
        35, 69857, -1663503955, -6592462094151732453L, -36748L, true, true, (char) 2661, (char) 61116,
        Double.longBitsToDouble(0x3fe1720665c1176aL), Double.longBitsToDouble(0x3fe99aa5ce8c393aL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=[B:[[-77, 59]] |a0=[B:[[-77, 59]]\012",
        Z.run(T, 1, 10, 5, 1, "\udae3\udd6b", "\ucd09\u0301\u3726\ucae8\u137e\u1684\uc8a6\u2745\u5c78\u8227\u2745\u9a80\u229d\ud354\u88f2\u26c9\u81a6\u1c01\u9903", "\ud9f8\uddba\udb26\udf1a\ud8da\udf8f\ud987\udceb\ud86b\udeb2\ud821\udf85\udb08\udd56\uda8b\udda6\ud8ec\ude94\udbad\udcd2\udb30\udf58\uda2f\udf3d\udb85\udd6f\ud87a\udeba\uda01\udd23",
        8, 2052, -1153865988, -2272972019688641293L, 57444L, true, false, (char) 36362, (char) 32481,
        Double.longBitsToDouble(0x3f94d7108abcb440L), Double.longBitsToDouble(0x3fe0bf7050f56800L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 11, 2, 1, "\uda07\udddd\udacc\ude48\ud9cf\ude8a\uda4b\ude69\udb47\udf88\ud9ab\udfda\ud87f\ude2a", "\ud5e1\uaa84\u3e43\ucfda\uca43\u7e30", "\udb0e\ude5a\ud8ea\uddd5\udaee\udd42\udae8\udc77",
        34, 69266, 1146020456, -4632081661682766075L, -28852L, true, true, (char) 28614, (char) 29567,
        Double.longBitsToDouble(0x3fe5b2be0e01a9caL), Double.longBitsToDouble(0x3feedf8e370d1b88L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 1, 5, 0, "", "\001\000\000\000\u00fb\000\u1684\000\ua06b", "\udb85\uddbd",
        -5, 16671, 705894775, -5379146506373107283L, -34491L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe22a227005bfb7L), Double.longBitsToDouble(0x3fe1700005ec176aL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=[B:[[54, 112, 104, 122, 53, 103, 61, 61, 13, 10]] |a0=[B:[[-22, -104, 115, -26]]\012",
        Z.run(T, 1, 15, 15, 1, "\ud81a\uddc8\udba3\ude16", "\u1b2d\u767a\u9efe\uc9aa", "\ud822\ude7e",
        56, 93043, -1511575710, -1258765765203180875L, -6111L, true, true, (char) 31615, (char) 32782,
        Double.longBitsToDouble(0x3fe0f19e56b1799fL), Double.longBitsToDouble(0x3fec0e24c26c1303L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\012",
        Z.run(T, 1, 9, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud8e2\udfdc\udb28\ude3a\udb59\udf9f\ud822\ude7e\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\ud9eb\uddbb\udafa\udd6c\ud84c\udfd5\udaee\udd42\ud880\udd44\udabd\uddff\ud968\udda0\ud980\uddf3\ud88f\ude7b\uda30\uded6\ud8da\udf8f\ud847\udceb\ud9ec\udddd\udba1\udffb\ud867\ude9a\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud882\udfd5\udb91\udcce", "\ua6e9\u6a9c\u8f55\u6dcd\u4a5b\u61d5\u8bb4\u146d\u389c\u1122\u124d\uc252", "\ud943\udd45\udb5d\uddd8\udab0\udc99\udb5b\udfb7\ud9aa\ude33\ud93e\udf3e\uda25\udfb6\uda11\udc11\udbf4\ude98\udaa5\udded\udac2\ude09\uda8a\udc0e\ud8fd\udcba\udabe\uddfe\ud9d6\udf5a\ud9e2\ude37\ud913\udc5d\uf89f\ud822\udf5a\ud9c9\udff1\ud9de\uddd4\ua501\uda39\ude24\ud8fa\udeb4\uda2d\uded8\udb93\ude79",
        11, 10228, -881794206, -9080011881345533685L, 71015L, true, true, (char) 43923, (char) 48426,
        Double.longBitsToDouble(0x3fed3a49e5ac6738L), Double.longBitsToDouble(0x3fd69e0e12ba8b8cL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.math.BigInteger:154 |a0=[B:[[-31, -119, 9, -112, 109, -99, -81, 117]]\0121=java.math.BigInteger:154 |a0=[B:[[-31, -119, 9, -112, 109, -99, -81, 117]]\012",
        Z.run(T, 2, 9, 9, 3, "\ud811\uddb9\ud939\udfc0\ud99d\uddcd\udadf\udca5", "\u9efe\ua63c", "\ud822\ude7e",
        56, 93043, -1511575710, -1258765765210437697L, -6111L, true, true, (char) 31615, (char) 22429,
        Double.longBitsToDouble(0x3fe0f19e5792b19fL), Double.longBitsToDouble(0x3fded22e448a8898L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-77, 124, 125, -97, 112, -70, -56, -18]]\012",
        Z.run(T, 1, 9, 5, 1, "\udae3\udfac\u9cad\ud9cf\udea0\udaea\uddf8\ud91e\udff5\ud98d\udf35\ud82c\udc60\ud8e2\udfdc\udb28\ude3a\udb59\udf9f\ud822\ude7e\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\ud946\ude49\ud811\udc31\uda12\uddbb\ud968\udda0", "\u5bd1", "\ud9ec\udddd\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a3\udd20\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        42, 14485, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 35667,
        Double.longBitsToDouble(0x3fcab7fe5b8d6aa8L), Double.longBitsToDouble(0x3feb40e8a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=null\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 15, 1, 4, "\ud81a\uddc8", "\u76b5\u7cbc\u64a7\u5f16\u1c2a\u1684\u9b87", "\ud81a\udec8\udb3b\udf17\udbd2\udf83\uda9e\udcbd\ud90c\udcca\ud83d\udeb5\udb4f\udcaf\udaee\udd42\ud949\ude28",
        32, 54506, 1145881961, -4632081661682766075L, -28852L, true, true, (char) 13897, (char) 1474,
        Double.longBitsToDouble(0x3fe137e108d9f404L), Double.longBitsToDouble(0x3fe3d05f079ba822L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String: |a0=[B:[[]]\012",
        Z.run(T, 1, 0, 0, 8, "", "\u9072", "",
        53, 7106, -881450385, -4483078062501895206L, -100000L, true, false, (char) 7654, (char) 8815,
        Double.longBitsToDouble(0x3fe8eb10028bb53dL), Double.longBitsToDouble(0x3fe53ce50b1ba482L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 8, "\000", "\u76b5\u6db9\u9360\u45a5\ub88b\000\000", "",
        -5, 24432, 878622208, 5116089760808435713L, 89813L, false, false, (char) 22429, (char) 202,
        Double.longBitsToDouble(0x3e4626c1e0000000L), Double.longBitsToDouble(0x3fe22a226000bfb7L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=[B:[[-22, 72, 108, -103, 72, 42]] |a0=[B:[[-22, 72, 10, 108, -103, 72, 42, 32]]\012",
        Z.run(T, 1, 10, 15, 1, "\ud81a\udd78\ud93a\udc9c\u74c9\ud878\udc5a\udb50\udd55\u1340\ud82b\udfa6\ud957\udf56\uda4d\udc8a\udb97\ude38\u0091\udabf\udd3e\udb1b\udd89\udba9\udfae\udaeb\ude3b\ud8df\ude5f\ud8ca\udfb6\uda6c\udfc8\ud83a\udc9c\ud8bb\udcee\u009a\uda47\udfc0\ud9be\udc24", "\u2f05", "\ud97f\ude92",
        47, 83937, 965578945, 2489374756878807591L, -49482L, true, false, (char) 0, (char) 45294,
        Double.longBitsToDouble(0x3faefb5f99d00f80L), Double.longBitsToDouble(0x3fe7420a28e21400L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:6piio5KU/sI= |a0=[B:[[-22, -104, -94, -93, -110, -108, -2, -62]]\012",
        Z.run(T, 1, 0, 5, 1, "\ud81a\uddc8\udbd2\udfd3\udac2\uddc4\ud82e\udff2\ud895\ude00\ud862\udc1d\ud82c\udc35\ud82a\udddf\ud9df\udd52\udbb4\udd7a\u0091\udabf\udd3e\ud81a\udec8\ud9d8\udea7N\udbbc\udf1e\udafc\udff1\ud8e7\udec6\000\udbba\udfa0\u43c1\ud870\udf58\ud968\udda0", "\u2f05", "\ud97f\ude92",
        47, 35633, 1212992811, 855842340220564090L, -49482L, true, false, (char) 0, (char) 45294,
        Double.longBitsToDouble(0x3faefb5f80000f80L), Double.longBitsToDouble(0x3fe7400000e21400L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String:6pgJkJ9wazw= |a0=[B:[[-22, -104, 9, -112, -97, 112, 107, 60]]\0121=[B:[[54, 112, 103, 74, 107, 74, 57, 119, 97, 122, 119, 61]] |a0=[B:[[-22, -104, 9, -112, -97, 112, 107, 60]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 0, 11, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\ud99b\ude6c\ud894\udfa1\u1340\ud82b\udfa6\ud957\udf56\uda4d\udc8a\udb97\ude38\ud9d8\udc9b\ud881\udffa\ud81a\udf15\u2f62\000\udbbc\udf1e\udafc\udff1\ud8e7\udec6\udbad\udda2\ud9a3\uddba\uda58\udfc9\ud870\udf58\ud896\udd97", "\u2f05", "\ud896\udc55\ud881\udd3d\ud838\udf26\udafa\udd6d\udb19\uddac\uda4c\udc82\udadd\udfce",
        -3, -919, -53689002, -7665380936290424686L, 8266L, false, true, (char) 13036, (char) 1250,
        Double.longBitsToDouble(0x3fe1ef27d3607859L), Double.longBitsToDouble(0x3fed976dab6ef21bL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 14, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udb9c\udc0d\ud894\udf89\ud88d\udc5a\uda0f\udd65\ud8ea\udf24\uda4d\udc8a\udb97\ude38\u0091\udbdd\udde5\ud812\udd6e\u2f62\000\ud921\udc10\ud95d\uddd2\ud8e7\udec6\000\udaee\udc9b\000\ud870\udf58\ud968\udda0", "\u66b9\u0081\u096a\u5f07\u1056\u773b\ua2db\u9626\u1835", "\udb45\udf73\udad1\udd25\u5ea7\udb75\udc3a\ud946\udf82\uda5f\udc4b\000\udae9\udc15\ud8dd\udeb1\ud80a\udcc5\u3893\ud970\udf51\ud951\ude81\udb24\ude3d\ud819\udfc9\udb44\udd99",
        54, 94293, -22640856, -6800432193660430354L, -84062L, false, true, (char) 14196, (char) 56802,
        Double.longBitsToDouble(0x3fedbe5b3be34465L), Double.longBitsToDouble(0x3fe1c30090ff1909L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=void |a0=[B:[[-54]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 13, 5, 1, "\ucbfa", "\000\000\u767a\u015e\u2085\u1684\u9b87", "\ud80b\udf45\udaec\ude12\ud9af\ude2d\udbde\udedd",
        35, -1000, -1663504128, -6629053841779543269L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fa7206620540190L), Double.longBitsToDouble(0x3fe99d4f920f393aL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[-22, -104, 9, -112, -88, 1, 88, 37]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 6, 1, "\ud81a\uddc8\ud939\udfc0\ud8d8\udf31\udb88\ude55\udb94\uddee\ud98d\udf63", "\u4fb3\ud57e\ub4e4\uaaae\ub16e\u5c99\u9a80\u259f\ud354\u0647\u8798\u42e7\u07c6\u5239\u60a7\u642c", "\u99a5\ud88a\udd31\ud97f\ude92\udba1\udffb\ud867\udf14\ud909\udf96\ud80c\udcc6\ud9ac\udd91\ud8ec\uddc7\uda03\udfa4\ud9d7\udc19\udab7\ude25\ud8a0\udccb\udb57\udd17\ud976\udfd6\udb77\udc8e\ud8e4\uddb6\uda2a\udf50\u0505\ua3f4\ud8e8\udc80\uda3e\udc42\ud810\udfea\uda2c\udd20\ud8ca\udc25\ud91f\udc3f",
        -2, 85541, -1930586134, 8918066716798752906L, -25639L, true, false, (char) 50773, (char) 2587,
        Double.longBitsToDouble(0x3fe7bfac1b472045L), Double.longBitsToDouble(0x3fe0c46111eb36b9L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=[B:[[54, 112, 103, 74, 107, 74, 57, 119, 117, 115, 103, 61]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\0121=[B:[[54, 112, 103, 74, 107, 74, 57, 119, 117, 115, 103, 61]] |a0=[B:[[-22, -104, 9, -112, -97, 112, -70, -56]]\012",
        Z.run(T, 2, 15, 14, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\udaf5\udc40\ud806\udfe1\ud9d1\udef6\ud988\udd77\ud965\udc96\udb95\udc38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udbbb\udc47\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud80d\udec1\udb72\udec6\ud94d\udfc7\ud9d7\udc19\udad1\udd25\uda40\udea0\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud855\udc6e\ud8cc\udef1\uda13\ude64",
        45, 51388, 1477487629, 3694577661741641000L, 93307L, false, true, (char) 48930, (char) 25665,
        Double.longBitsToDouble(0x3fd4d6b00dc6b572L), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 15, 14, 1, "\ud81a\udd50\ud94b\ude52\ud9af\udfa0\udaea\uddf8\ud9ea\udd40\ud82f\udcf5\ud984\udee9\ud98f\udc81\ud965\udc96\udb97\ude38\udb3b\ude28\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udac8\udd87\ud81f\ude9f\ud891\udf15\ud84c\udfdb\ud876\ude65\uda6f\udd2b\ud90b\udf38\ud939\udc5b", "\u4dca\u75ee", "\udbd8\udeb5\udabf\udfdd",
        32, 93323, -258608518, -6685471331652940836L, -63323L, false, false, (char) 64252, (char) 31298,
        Double.longBitsToDouble(0x3fe7436af6971c00L), Double.longBitsToDouble(0x3fe23ea7486b09c6L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=[B:[[97, 112, 81, 81, 116, 89, 84, 47, 118, 115, 111, 61]] |a0=[B:[[106, -108, 16, -75, -124, -1, -66, -54]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 13, 6, "\udb9a\udfc4\uda40\udee5\ud9b4\udf2f\ud8ee\uddfa\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud845\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\ud886\udc70", "\u407d\ub839\u28cf", "\uda53\ude8c\udae8\udd55\ud884\udeea\udac4\udd55",
        47, 35633, 1212992811, 855842340220564090L, 28220L, true, true, (char) 5028, (char) 27151,
        Double.longBitsToDouble(0x3fc77392d8692030L), Double.longBitsToDouble(0x3fb74455d74c3818L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 13, 5, "\udbc4\uddfe\udbd5\udccc\ud2b9\ud85d\ude0d\ud845\udfce\udacb\udc03\ud9a2\udd70\udbad\ude9b\ud91e\udc63\udbbe\udfea\ud845\udf1a\udbe7\udcef\uda2e\ude62\udb07\udcc2\ud9af\ude2d\udbde\udedd\udafc\udff1\udac1\udfc0\ud895\ude18", "\u1bde\u9814\u0e61\u2316\u9dd8\u8a55\ucb9b\uc9c7\u52fc\ub0fa\ua336\u9626", "\uda90\udce0\ud8b4\ude4f",
        -4, 62138, 1330599389, -3578479419924591694L, -22544L, true, false, (char) 3509, (char) 51800,
        Double.longBitsToDouble(0x3fda070edbcb0e72L), Double.longBitsToDouble(0x3febb58b2a6e540fL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=void |a0=[B:[[-31, 49, 22, 84, -97, 112, 2, -84]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 13, 1, "\uda11\ude61\ud946\ude84\ud9cf\udea0\uda32\udedc\udb78\udc33\ud98d\udf63\udbb0\udd54\ud957\udf56\udb55\ude8d\udb97\uddb4", "\uacd3\u4372\u1d38\u04b1", "\udbc8\uddf8\udaeb\udd2f\ud84c\uddea",
        23, 93145, 1145881966, -7124430430269556013L, -28852L, true, true, (char) 19754, (char) 21493,
        Double.longBitsToDouble(0x3fd2b36710269098L), Double.longBitsToDouble(0x3fe3d17f073ff095L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.String:6pg= |a0=[B:[[-22, -104]]\0121=java.lang.String:6pg= |a0=[B:[[-22, -104]]\012",
        Z.run(T, 2, 0, 0, 1, "\ud81a\uddc8", "\000\u2c13\u767a\000\000\u1643\u9b87", "\ud81a\udec8\udaec\ude12\ud9af\ude2d\ud869\udf03",
        35, 95153, -1663503955, -6592462094807157989L, -76914L, false, true, (char) 0, (char) 14665,
        Double.longBitsToDouble(0x3e44ac0000000000L), Double.longBitsToDouble(0x3f93484c4f416000L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud81a\uddc8\ud931\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\udbf8\udfbb\ud9eb\udfd7\ud839\udc1c\udb07\udc7c\udaf2\udf5a",
        43, 42132, 1477466686, 3694577661741641000L, 93307L, false, true, (char) 46869, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 4, 5, 0, "\ud81a\uddc8\ud92b\udfc0\ud9cf\udea0\udaea\uddf8W\ud803\udc20\u00ba\ud957\udf56\ud965\udc96\u00da\000\000\000\000\ud9a1\udef0\udb36\udfda\ud84a\udd78\u6e00\000\000\udbc4\udf26\ud98b\udd27\000", "\u5bd1", "\000\udb81\udde0",
        53, 82811, 199229459, 266604243349248L, 6841L, true, false, (char) 61446, (char) 64252,
        Double.longBitsToDouble(0x3f267c0000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 5, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud9d8\ude28\ud82b\udfae\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udeaa\ub78a\uda20\udd99\ud883\udfc4\u9a95\ud949\udee0\uda3a\udc7f\ud968\udda0", "\u5bd1", "\udb9f\udc61\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\ud9ac\udd91\ud8ec\uddc7\ud94d\udfa9\ud9d7\udc19\ud899\udeaa\ud98e\udf9d\ud290\ud96e\udce3\ud98f\udee3\udbf8\udfbb\udae9\udc15\ud90f\ude53\udafd\udf1a\uda13\uded7\udaf4\ude11\uda03\udda1\uda4e\udd3d\ud9fe\uddd4\ud92d\udd58\ud8a6\udf33",
        1, 12104, 506918746, 412925733680873465L, -31356L, true, false, (char) 46666, (char) 36518,
        Double.longBitsToDouble(0x3fe9e23c458bdd75L), Double.longBitsToDouble(0x3fea7f789aff0878L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 7, "\u73ef", "\u7dcd\u2f99\ubfa9\u2959\u02fb\u1643\u9b87", "\udb67\udc92",
        10, -1000, 0, 7926335342919639384L, -79893L, true, false, (char) 38474, (char) 57183,
        Double.longBitsToDouble(0x3fe80000012670b1L), Double.longBitsToDouble(0x3fced1dddbb25e60L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=[B:[[-65]] |a0=[B:[[-65]]\012",
        Z.run(T, 1, 10, 15, 7, "\u73ef", "\000\u85a1\u8bba\u20fe\u02fb\u1643\u1882", "\udb29\ude93\udb0b\udc52\ud800\udd65\000\000\ud954\udcc9\ud85a\udc6f\udab5\udf08\u00d0\uda3a\udc7f\ud968\udda0\uc500\000\000 \ud956\udd38\ud979\udee3",
        39, 35633, 133811499, 4028156949389323916L, -4898L, true, true, (char) 8822, (char) 57302,
        Double.longBitsToDouble(0x3fe72feb0a43e5f5L), Double.longBitsToDouble(0x3fae6f532e75f400L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=[B:[[-5, 89, 123]] |a0=[B:[[43, 49, -1, -124, 108, 55, -88, -46]]\0121=[B:[[-5, 89, 123]] |a0=[B:[[43, 49, -1, -124, 108, 55, -88, -46]]\012",
        Z.run(T, 2, 7, 7, 7, "\ud85b\ude61\uda2f\udfb4\ud99c\udd67\ud9d8\udc02\udb86\udfa9\ud98d\udf63\ud844\udf60", "\u6463\ud64b\u9417\u4732\u6eba\u7e28\u35ac\ud354\ucd07\u426d\ub3c5\u375f\ubdea\u6098\u5839\u966a\uafda\u084a\u0996\u1e4e", "\ud8de\udd1e\ud9db\uddba",
        12, 28512, -1195525412, -2764070554738270890L, 69500L, true, false, (char) 25142, (char) 21264,
        Double.longBitsToDouble(0x3fe6cf2c39291c29L), Double.longBitsToDouble(0x3fef787443e4b9e4L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=[B:[[66, 94]] |a0=[B:[[81, -111, -15, 125, 108, 55, -88, -46]]\0121=[B:[[66, 94]] |a0=[B:[[81, -111, -15, 125, 108, 55, -88, -46]]\012",
        Z.run(T, 2, 7, 7, 7, "\ud881\udec1\uda21\udfad\ud99c\udd67\ud9d8\udc02", "\u382a\u7722", "\udbd7\udf91\udbfa\ude11\ud81a\udf3a\uda9b\udfcd\ud9af\ude2d\udbd8\udd2a",
        8, 75594, -1289794410, -3574355529392872556L, -89954L, true, false, (char) 10521, (char) 61116,
        Double.longBitsToDouble(0x3fe1a3e215ec176aL), Double.longBitsToDouble(0x3fa9aa5cafccf270L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[100, -107, 9, -112, -14, 61, -26, 64]]\0121=[B:[[]] |a0=[B:[[100, -107, 9, -112, -14, 61, -26, 64]]\012",
        Z.run(T, 2, 7, 7, 4, "\udb94\uddc5\ud939\udfc0\ud822\udf6d\ud816\udc70\udb86\udfa9\ud98d\udf63\uda7c\uddf8\ud978\udd66\ud93f\udcbe\udb97\ude38\ud837\udf1a\udbe7\udcef", "\u9a80\u7507\ubce6\ubb52\ub3a8\u1a38\u407d\ub839\u2512\u7e04\ucdee\u5bd1\u75ee\u0304\u5fa5\u1056\u773b\ua2db\u3ccd\u08f3\u692c\u6f6f\uc22c", "\u8f5f\ud900\udd71\udafd\udd66",
        36, 62390, -875601835, -2631158910264806351L, 91342L, true, true, (char) 57445, (char) 61603,
        Double.longBitsToDouble(0x3fef4334c3486369L), Double.longBitsToDouble(0x3fe640bbb7878133L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=[B:[[-106, -49, -93, -67, -6, -70, -56]] |a0=[B:[[-106, 13, -49, -93, -67, -6, -70, -56]]\012",
        Z.run(T, 1, 10, 6, 7, "\ud9c6\ude3d\ud9ff\udfd3\udbed\ude2a\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud9b2\udffe\u5498\ud9ea\udfc1\udb83\uddf4", "\u1f7b\u5c66\u9a80\u46e8\u7398\u6506", "\udad5\udf4f\udbc2\udfa2\ud986\udf59",
        13, 87445, 689299052, -2271607625907315476L, -47415L, true, false, (char) 65075, (char) 24533,
        Double.longBitsToDouble(0x3feee519c351b8c4L), Double.longBitsToDouble(0x3fd56858ad4e225aL)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=[B:[[-115, -114, -125]] |a0=[B:[[106, -13, 20, 89, 54, 68, 83, -83]]\0121=[B:[[-115, -114, -125]] |a0=[B:[[106, -13, 20, 89, 54, 68, 83, -83]]\012",
        Z.run(T, 2, 7, 7, 7, "\udb9a\ude23\udb44\udc89\ud966\udd74\udb83\udedd\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud8e5\uddd1\ud8cb\udc8c", "\u7353", "\ud9af\ude2d\ud8e4\udfc0\ud805\udd94\uc96c\ud918\ude7c\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0\ud980\uddf3\ud8d0\uddc7\uda30\udf93\ud8da\udf8f\ud884\udeea\ud8a7\udcdc\ud83f\uddfd\ud812\udcf7\udae7\udc1d\ud8b6\udfc1\ud9ac\udd91\ud9ac\udc06\ud8f1\udcfa\ud9d7\udc15",
        18, 46031, -2088406853, 6865946243902312154L, -9072L, true, false, (char) 36729, (char) 25007,
        Double.longBitsToDouble(0x3fd127e5d9751f8cL), Double.longBitsToDouble(0x3fe87cb403aab404L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[61, -49, 20, 73, 82, 44]]\012",
        Z.run(T, 1, 2, 7, 14, "\udb6d\udeff\uda44\ude79\ud882\udd5c", "\u767a\u9efe\u750e\u6a9e", "\udacf\udf3d",
        3, 90290, -293079243, -5965712876267955849L, -14779L, false, true, (char) 55601, (char) 59600,
        Double.longBitsToDouble(0x3fdb4a44c6dcd1d4L), Double.longBitsToDouble(0x3fe5dc805dec176aL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.math.BigInteger:0 |a0=[B:[[-22, -104]]\0121=[B:[[]] |a0=[B:[[-22, -104]]\012",
        Z.run(T, 2, 9, 7, 7, "\ud81a\uddc8", "\u5829\u66cd\u767a\u9efe\u1c2a\u43ac\ua575\u2872\u917e", "\udb17\udcb6\udbde\udedd\ud996\udffe\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0\ud980\uddf3\ud88f\ude7b\uda30\uded6\ud8da\udf8f\ud884\udeea\ud97f\ude92\ud833\udcc6\ud930\ude7f\ud8aa\udee9\udafd\udc2d\ud9a7\udf81\udad0\udf86\ud8a8\uded9\ud8a3\udd4e",
        11, 22255, 1683641872, -4995507592936638348L, -97888L, false, false, (char) 55460, (char) 44991,
        Double.longBitsToDouble(0x3fed51e8ba33818aL), Double.longBitsToDouble(0x3fed4747843c2c3fL)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=[B:[[94, -112]] |a0=[B:[[38, 88, 5, 30, -97, 112, 66, 8]]\0121=[B:[[94, -112]] |a0=[B:[[38, 88, 5, 30, -97, 112, 66, 8]]\012",
        Z.run(T, 2, 7, 7, 5, "\udb56\udc88\ud835\udf4e\ud9cf\udea0\ud972\udc38\u7a47\ud98e\udc0c", "\u9b83", "\ud950\uddb0",
        21, 90010, 1930160810, -5853828939841078990L, 38610L, false, true, (char) 36215, (char) 36707,
        Double.longBitsToDouble(0x3fe22a229a05bfb7L), Double.longBitsToDouble(0x3fe91e38ddec176aL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.String:0A== |a0=[B:[[-48]]\0121=java.lang.String:0A== |a0=[B:[[-48]]\012",
        Z.run(T, 2, 0, 0, 7, "\000", "\u0c8e\u976c\u767a\u9efe\u50e8\uab35\u1932\u9d62\u7f67\u4072", "\udbde\udedd",
        35, 99127, -1674904097, 4544481287137206355L, -91816L, true, false, (char) 18439, (char) 37391,
        Double.longBitsToDouble(0x3fe14ed6185408a8L), Double.longBitsToDouble(0x3fe81416df420924L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 7, "\u53ea\000\000\udaea\uddf8\udb86\udfa9\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\uaf15\ud8c4\ude9f\ud8c5\uddc1b", "\ud354", "\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0",
        13, 8485, 0, 1687259966450171904L, -91281L, true, true, (char) 10660, (char) 11575,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 11, 7, 7, "", "\ua505", "\ud8f5\ude1f\ud82b\udfb6\ud957\udf56",
        59, 32290, -2125031791, 6433531795661929347L, -94112L, true, false, (char) 23863, (char) 57667,
        Double.longBitsToDouble(0x3fdadb559d4f39b0L), Double.longBitsToDouble(0x3fe8dd24151e33caL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.String: |a0=[B:[[]]\0121=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 2, 0, 14, 7, "", "\u9072", "\ud94f\udffd\ud82c\udc60\ud957\udf56",
        59, 66065, -2125031791, 6433532449048602243L, -34464L, false, false, (char) 42863, (char) 59617,
        Double.longBitsToDouble(0x3fdadfa09d4f39b0L), Double.longBitsToDouble(0x3fe8dd24151e33caL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[85]]\0121=[B:[[]] |a0=[B:[[85]]\012",
        Z.run(T, 2, 7, 7, 7, "\u2a85", "\u2876\ua127\u3449\u6458", "\udb97\ude38\ud837\udf1a\udbce\ude63\ud81a\udec8\uda18\udfdb\udacb\udc4a\udbde\ude5b\udb1c\udef1\ud9e8\udde7\u50d3\ud82a\udfeb\ud81d\udc2f\uda3a\udc7f\ud968\udda0\udb4e\uddfa\ud8a6\udd7b\uda30\uded6\ud8da\udf8f\ud91c\uded7\ud948\udf82",
        47, 35633, 1212992811, 855842340220564090L, 38634L, true, false, (char) 4120, (char) 64641,
        Double.longBitsToDouble(0x3fef7a470c968f7aL), Double.longBitsToDouble(0x3fcaf28050926b68L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\uda28\udccd\ud845\udfef\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0\ud980\uddf3\ud88f\ude7b\uda30\uded6\ud8da\udf8f\ud884\udeea\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\uda35\udd06\ud8ec\uddc0\ud94d\udfa9", "\uc8d3\u54e9\u4df0\u1989\u4994", "\ud8cc\udef1",
        10, 59150, -2105596699, 6345762061272073935L, -31037L, true, true, (char) 12838, (char) 38480,
        Double.longBitsToDouble(0x3fdc41e36ff20b76L), Double.longBitsToDouble(0x3fe71ad553dca514L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null\012",
        Z.run(T, 2, 4, 8, 1, "\ud81a\uddc8\ud939\udfc0\ud8b7\udd97\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\udb97\ude38\ud837\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\u5bd1", "\ud97f\ude92\udba1\udffb\ud867\udf14\udafa\udd6d\ud88c\udcc6\uda35\udd06\ud8ec\uddc0\ud94d\udfa9\ud9d7\udc19\udad1\udd25\ud8a0\udccb\udb91\udcf5\ud9a6\udc5b\ud98f\udee3\ud99a\udeac\udb17\udf47\ud855\udc6e\ud824\udc1d\ud9ad\ude75",
        21, 50301, 1477487865, 3694577661741641000L, 93307L, false, true, (char) 38480, (char) 8186,
        Double.longBitsToDouble(0x3fefc82ddee35aaaL), Double.longBitsToDouble(0x3feee528a6c5c16aL)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 5, 0, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0|\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\ud965\udc96\000\000\000\000\udaec\ude12\u373d\ud869\udfc2\000\000\udada\udc0c\udaee\udd42\ub31b\000\ud95e\ude0e", "\u5bd1", "\ud97f\ude92\udba1\udffb",
        18, -1000, 199229440, 4339615687098527544L, 38065L, false, true, (char) 23412, (char) 3410,
        Double.longBitsToDouble(0x3fccf800f0f7dafcL), Double.longBitsToDouble(0x3fd4a2cf8c34b6bcL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=[B:[[54, 112, 103, 74, 107, 74, 47, 103]] |a0=[B:[[-22, -104, 9, -112, -97, -32]]\0121=[B:[[54, 112, 103, 74, 107, 74, 47, 103]] |a0=[B:[[-22, -104, 9, -112, -97, -32]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 15, 11, 4, "\ud81a\uddc8\ud939\udfc0\ud9cf\udf10", "\u64a7\u5f16\u1c2a\u1684\u9b87\u29a2\u3cd7\uacd3\ucdda\u5133\u2eaf\u276e\ub4e0\u7bd4\u1a76\u6cf5\u2818\uc70c\u0e5c\u9614\u5bd1\u75ee\u0a56\u5f07\uc171\u2efa\uc7f1\u96ec\u1257\u54f7\ub0b8\ua6af\ua5bb\u92b9\u80d9\u0325\ubdf3\u7922\u1eea\u86da", "\ud8b6\udc86\ud9c5\udc14\ud9e2\uddfa\udbd6\udc4c\udac6\udf49\u7dde",
        16, 79340, -1417793394, 8014472771984738180L, -97919L, false, false, (char) 6418, (char) 48927,
        Double.longBitsToDouble(0x3fd00a29cbd0cb68L), Double.longBitsToDouble(0x3fd79224e836f20aL)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 15, 15, 14, "\ud97d\ude41", "\u76b5\u7cbc\u8239\u5f16\u1c2a\u1684\u9b87", "\ud81a\udec8\udb3b\udf17\ud9a6\udd6d\uda9e\udc49\ud90c\udcca\ud83d\udeb5\uda49\udf36\udaee\udd42\ud949\ude28",
        32, 54506, 1145881961, -4632081661682766075L, -28852L, true, true, (char) 13897, (char) 1474,
        Double.longBitsToDouble(0x3fe137e108d9f404L), Double.longBitsToDouble(0x3fe3d05f079ba822L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.String:0ESfcN2H |a0=[B:[[-48, 68, -97, 112, -35, -121]]\0121=java.lang.String:0ESfcN2H |a0=[B:[[-48, 68, -97, 112, -35, -121]]\012",
        Z.run(T, 2, 0, 0, 7, "\000\ua674\ud9cf\udea0\uda0d\udcb7", "\u9c29\u1c2a\ubad0\ucd9d\u2872\u1258\u078d\u1800\u9cf8\ua631\u58f8\u7a81\u8cc4\ua59b\u03e6\u7016\u14d8\ud6af\u21c6\u2b20\ua28d\u750b\u0384\u965d\u0209\u2892\u5183\u5918\u1982\ub317\u0f87\u41dc\u46aa\uc963\u90cf\ucbd4\uc712\u3a5c\u1a8d\u5fe8\uc91c\u82df\u8bcb\u8b5d\u19c6", "\udb03\uddd5\udb90\udc03\udbda\udf6a",
        17, 45974, 1426604919, 3856103394926828463L, 33546L, false, true, (char) 13533, (char) 53314,
        Double.longBitsToDouble(0x3f84e77f9023bc00L), Double.longBitsToDouble(0x3fe91480aa948703L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.binary.Base64:@?\0121=null |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 11, 5, "\ud81a\udd50\ud94b\ude52\ud9af\udfa0\udaea\uddf8\ud9ea\udd40\ud82f\udcf5\ud984\udee9\ud98f\udc81\ud965\udc96\udb97\ude38\udb3b\ude28\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udac8\udd87\ud81f\ude9f\ud891\udf15\ud84c\udfdb\ud876\ude65\uda6f\udd2b\ud90b\udf38\ud939\udc5b", "\u4dca\u75ee", "\udbd8\udeb5\udabf\udfdd",
        32, 93323, -258608518, -6685471331652940836L, -63323L, false, false, (char) 64252, (char) 31298,
        Double.longBitsToDouble(0x3fe7436af6971c00L), Double.longBitsToDouble(0x3fe23ea7486b09c6L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=[B:[[106, 115, 16, -75, -124, -1, -66, -54]] |a0=[B:[[106, 115, 16, -75, -124, -1, -66, -54]]\0121=[B:[[106, 115, 16, -75, -124, -1, -66, -54]] |a0=[B:[[106, 115, 16, -75, -124, -1, -66, -54]]\012",
        Z.run(T, 2, 10, 10, 13, "\udb9a\udfa3\uda40\udee5\ud9b4\udf2f\ud8ee\uddfa\udbdf\udce6\ud8a2\uddcb\udb6c\udc21\ud957\udf56\ud965\udc96\udb97\ude38\ud845\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udb32\udd4e\udaad\udd44", "\u15bd\ub853\u28cf", "\ud885\ude85\udae8\udd55\uda0a\udeed\udac4\udd55",
        47, 78601, -1077553363, 1409607098057486970L, 28220L, true, true, (char) 5028, (char) 27151,
        Double.longBitsToDouble(0x3fc4b392c0205b68L), Double.longBitsToDouble(0x3fb74455d74c3818L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=[B:[[122, 99, 117, 98, 104, 80, 43, 43, 121, 103, 61, 61]] |a0=[B:[[-51, -53, -101, -124, -1, -66, -54]]\0121=[B:[[122, 99, 117, 98, 104, 80, 43, 43, 121, 103, 61, 61]] |a0=[B:[[-51, -53, -101, -124, -1, -66, -54]]\012",
        Z.run(T, 2, 14, 14, 2, "\u22fd\udbfb\udccb\ud9b4\udf2f\ud8ee\uddfa", "\u9efe\u1c2a", "\ud845\udf1a\udaf8\udf0d\ud837\udea9\ud91d\ude09\ud9e7\udc35\udb67\udce0\uda9a\udd04",
        23, 66045, 1644680871, -7606584081803969509L, -52197L, false, false, (char) 36694, (char) 20460,
        Double.longBitsToDouble(0x3fe07f02e0a1dcccL), Double.longBitsToDouble(0x3fef0e97d0ca6d42L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.binary.Base64:@?\0121=void |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 6, 13, 1, "\ud860\udd5e\ud946\ude84\ud874\ude53\ud9df\udeae\udb2d\udeb5\ud9d7\udd53\ud914\udda2\udb7d\udc8d\uda1a\udd2c\uda49\udfae", "\u99ba\u5450\u163b\u8d15", "\udbc8\uddf8\ud9c7\udfe5\ud9fd\udc92\udbca\ude53\ud9d2\udddf\ud980\uddbb\ud848\udc28\ud8ca\udf9e\ud8f3\udc0e\udb54\udf1d\udac4\udd3a\ud960\uddcf\ud94e\uddea\udafa\udd6d\uda59\udfde\ud9ac\udd91\ud976\udeeb\ud886\udfc5\ud8e9\ude3a",
        23, -118, -342296528, -7358565869183005454L, 62052L, false, true, (char) 52811, (char) 238,
        Double.longBitsToDouble(0x3fc0d52d1df24de4L), Double.longBitsToDouble(0x3fe5d70e3b058388L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=[B:[[]]\0121=[B:[[]]\012",
        Z.run(T, 2, 8, 8, 1, "\uda11\ude61\ud946\ude84\ud9cf\udea0\uda32\udedc\ud82b\udeee\ud98d\udf26\ud978\udc38\udb29\udd42\udb55\ude8d\udb97\uddb4", "\u810b\u4372\u1d38\ua62c", "\udae5\udc94\udaeb\udd2f\ud84c\uddea\uda27\udd46\ud913\udfa0",
        15, 37359, -523453741, 8748905240150480364L, -21758L, true, false, (char) 8794, (char) 28946,
        Double.longBitsToDouble(0x3fe92b03e84c2935L), Double.longBitsToDouble(0x3fbe2ee5df5c99e8L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-31, 49, 22, 84, 125, -79, 12, 72]]\0121=java.lang.Boolean:true |a0=[B:[[-31, 49, 22, 84, 125, -79, 12, 72]]\012",
        Z.run(T, 2, 2, 2, 1, "\uda11\ude61\ud946\ude84\ud9ad\udce1\u7c3c\udb78\udc33\ud98d\udf63\udbb0\udd54\ud957\udf56\u2e89\ud8dc\udf3c", "\uacd3\u4372\u1d38\u13f2\u2916", "\udaeb\udd2f",
        47, 10498, -685796855, 4959806164805173061L, 54158L, true, false, (char) 4794, (char) 19754,
        Double.longBitsToDouble(0x3fd0fa840a194b1aL), Double.longBitsToDouble(0x3fed0dc262d4a7f0L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=[B:[[-106, -49, -93, -62, -79, -44]] |a0=[B:[[-106, 13, -49, -93, 13, -62, -79, -44]]\012",
        Z.run(T, 1, 10, 6, 12, "\ud9c6\ude3d\ud9ff\udfd3\uda3d\uddf2\ud8e1\ude04\udb87\udc0d\ud995\udf63\udabb\udc02\ud867\udd40\ud9ea\udfc1\udbac\uddb9", "\u8bfd\ub624\u2560\u3bdb\u44e5\u6506", "\udad5\udf4f\udbbd\udea2\ud986\udf59",
        54, 19085, 2089432909, 8464973257278383855L, 70022L, true, false, (char) 14142, (char) 22207,
        Double.longBitsToDouble(0x3fdd503baba8f080L), Double.longBitsToDouble(0x3fdc2a3386a20388L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=[B:[[42, -122, -46]] |a0=[B:[[123, -5, 126, 75, 111, 98, 83, -83]]\0121=[B:[[42, -122, -46]] |a0=[B:[[123, -5, 126, 75, 111, 98, 83, -83]]\012",
        Z.run(T, 2, 7, 7, 7, "\udbab\udf2b\udaae\ude7b\ud99f\ude92\udb83\udedd\udac4\uddd4\ud850\udd6d\ud82c\udc60\ud8e5\uddd1\ud8cb\udc8c", "\u7353\uad4d\u5c99\u9a80", "\uc96c",
        35, 69807, 868922139, -5647552286195177582L, 43173L, false, true, (char) 39674, (char) 11606,
        Double.longBitsToDouble(0x3fe99aa5c99a1c2fL), Double.longBitsToDouble(0x3fce094e3f511160L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 11, 11, 9, "", "\ua505", "\uda78\udc27\ud937\udfbc\ud957\udf56",
        59, 32290, -2125031791, -4660757299892307069L, -94112L, true, true, (char) 23863, (char) 57667,
        Double.longBitsToDouble(0x3fdadb55974467a2L), Double.longBitsToDouble(0x3fe8dd24151e33caL)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=[B:[[84, 82, 69, 74, 107, 74, 47, 103, 13, 10]] |a0=[B:[[77, 17, 9, -112, -97, -32]]\0121=[B:[[84, 82, 69, 74, 107, 74, 47, 103, 13, 10]] |a0=[B:[[77, 17, 9, -112, -97, -32]]\012",
        Z.run(T, 2, 15, 15, 14, "\ud97d\ude41\ud939\udfc0\ud9cf\udf10", "\u8239\u5f16\u1c2a\u1684\u9b87\u29a2\u4bf4\uacd3\u49b4\u7735\u80bd\u2760\u203f\u9d85\u1a3e", "\ud876\ude87\ud980\udd6f\ud88f\ude7b\uda30\uded6\ud8da\udf8f\ud884\udeea\ud97f\ude92\ud9d4\uded8\ud887\udf9f\ud89f\udd71\ud88c\udd8c\ud9a1\udd4c\udbf0\udca8\uda39\ude86\ud853\ude12\ud993\udda7\ud9e3\uddad\u6786\ud8ea\udfaa\udb90\udf85\ud8db\udea7\udaf6\udecb\u0469\udaaf\ude6b\ud9db\udd1f\ud84a\udd4b\udb57\udf40\udb63\ude38\udb77\udfe3",
        33, 22778, 1368601726, -8898818246427313472L, -7411L, true, true, (char) 40143, (char) 15453,
        Double.longBitsToDouble(0x3fdb2977afc0f9faL), Double.longBitsToDouble(0x3fe3301dff7db5e0L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=[B:[[-8, 16, -75, -124, -1, -11, -26]] |a0=[B:[[10, -8, 16, -75, -124, -1, -11, -26]]\0121=[B:[[-8, 16, -75, -124, -1, -11, -26]] |a0=[B:[[10, -8, 16, -75, -124, -1, -11, -26]]\012",
        Z.run(T, 2, 10, 10, 13, "\ud93a\udd28\uda40\udee5\ud9b4\udf2f\uda25\ude16\ud9f8\udedb\udb89\udfaa\udbb6\udd15\uda75\udcb1\ud965\udc62\udb97\ude38\ud845\udf1a\udbe7\udcef\ud81a\udec8\udaec\ude12\ud9af\ude2d\udbde\udedd\udb32\udd4e\udaad\udd44", "\u15bd\ub853\u28cf", "\ud885\ude85\udae8\udd55\uda0a\udeed\udac4\udd55",
        47, 78601, -1077553363, 1409607098057486970L, 28220L, true, true, (char) 5028, (char) 27151,
        Double.longBitsToDouble(0x3fc4b392da74e768L), Double.longBitsToDouble(0x3fb03b8328de6050L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=[B:[[104, 52, 80, 76, 51, 52, 84, 47, 118, 115, 111, 61]] |a0=[B:[[-121, -125, -53, -33, -124, -1, -66, -54]]\0121=[B:[[104, 52, 80, 76, 51, 52, 84, 47, 118, 115, 111, 61]] |a0=[B:[[-121, -125, -53, -33, -124, -1, -66, -54]]\012",
        Z.run(T, 2, 14, 14, 2, "\udbb7\udfb3\udbfb\udc0f\ud9b4\udf2f\ud8ee\uddfa\ud845\udfe8", "\u1c2a\u1f29\u56f4\u196a\u81d5\ud453\u514a\ua541", "\ud8ae\ude10\ud95f\udc41\ud991\ude9b\ud98d\udec2\u4f85\ue040\udabb\udfe2\ud9a7\udecc",
        22, 26596, 1421415916, -2279671115489402353L, -10881L, false, false, (char) 23298, (char) 41098,
        Double.longBitsToDouble(0x3fbe6f79823203a0L), Double.longBitsToDouble(0x3fcac3a91728e3d0L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-3, 31, -4, -77, -30, -80, 12, 72]]\0121=java.lang.Boolean:true |a0=[B:[[-3, 31, -4, -77, -30, -80, 12, 72]]\012",
        Z.run(T, 2, 2, 2, 1, "\ud92d\udd4f\ud82c\udee3\ud812\udde0\u7c3c\udb78\udc33\ud98d\udf63\udbb0\udd54\ud957\udf56\u2e89\ud8dc\udf3c", "\uacd3\u4372\u1d38\u13f2\u2916", "\udaeb\udd2f",
        47, 10498, -685796855, 4959806164805173061L, 54158L, true, false, (char) 4794, (char) 19754,
        Double.longBitsToDouble(0x3fd0fa840a194b1aL), Double.longBitsToDouble(0x3fefc5c262d4a7f0L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-3, 31, 25, -22, -30, 61, 12, -106]]\0121=java.lang.Boolean:true |a0=[B:[[-3, 31, 25, -22, -30, 61, 12, -106]]\012",
        Z.run(T, 2, 2, 2, 1, "\ud92d\udd4f\ud949\ude1a\ud812\udd6d\u7c3c\udac6\udfff\ud964\udfdd\uda15\udf67\udaf1\udeed\udb9f\udc1c\ud8dc\udf3c", "\uacd3\u4372\u0dd0\u13f2\u2916", "\ud9cb\udc7e",
        47, 12546, -685796855, 4959806164805173061L, 54158L, true, false, (char) 4794, (char) 31766,
        Double.longBitsToDouble(0x3fdbea0bea18269eL), Double.longBitsToDouble(0x3fefc5c262d4a7f0L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-3, 31, -4, -77, -30, -80, 30, -30]]\0121=java.lang.Boolean:false |a0=[B:[[-3, 31, -4, -77, -30, -80, 30, -30]]\012",
        Z.run(T, 2, 2, 2, 1, "\ud92d\udd4f\ud82c\udee3\ud812\udde0\ud94e\udc12\uda01\uddf5\ud98d\udf63\udbb0\udd54\ud89f\udd59\ud866\udfef\udae9\udf61", "\u9330\u4372\u1d38\ub639\u28fe", "\udaeb\udd2f",
        47, 10498, -685796855, 4959596836689100613L, 54158L, true, true, (char) 23485, (char) 19754,
        Double.longBitsToDouble(0x3fd35aecfa05751aL), Double.longBitsToDouble(0x3feae3857ad4a7e9L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-3, 31, 9, 26, 30, -30, 30, -30]]\0121=java.lang.Boolean:false |a0=[B:[[-3, 31, 9, 26, 30, -30, 30, -30]]\012",
        Z.run(T, 2, 2, 2, 1, "\ud92d\udd4f\ud939\ude4a\ud84e\udd12\ud94e\udc12\uda01\uddf5\ud98d\udf63\udbb0\udd54\ud89f\udd59\ud866\udfef\udae9\udf61", "\u9388\u4372\ua87a\u9f18\u28fe", "\udaeb\udd2f",
        36, 1292, -567433063, 4959827223029825349L, 54158L, true, true, (char) 624, (char) 2566,
        Double.longBitsToDouble(0x3fd35aecfe04dd1aL), Double.longBitsToDouble(0x3feae77d5ad4a7e9L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 12, 5, 1, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0\udaea\uddf8\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56\udbbd\udd21\udb97\ude38\ud936\udd99\udb8f\udffc\udac8\ude02\udaec\ude12\ud9af\ude2d\udbde\udedd\udafc\udff1\udb0e\ude5a\ud84c\udfd5\udaee\udd42\ud949\ude28\uda3a\udc7f\ud968\udda0", "\ubd3a\ub93f\u4ddc\u5f07", "\udafa\udd6d\udb4f\ude8a\udb6f\udcba",
        44, 8756, -2061057020, -3289662553246868955L, 50858L, false, false, (char) 1250, (char) 31286,
        Double.longBitsToDouble(0x3fe35abe37864372L), Double.longBitsToDouble(0x3fccb46e703431fcL)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |a0=[B:[[]]\012",
        Z.run(T, 2, 5, 7, 7, "", "\u9072", "\ud803\udc20\ud82c\udc60\ud957\udf56",
        59, 32290, -2125031791, 6433532448496958339L, -34464L, true, true, (char) 50860, (char) 39124,
        Double.longBitsToDouble(0x3fdadb559d4f39b0L), Double.longBitsToDouble(0x3fe8dd24151e33caL)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=[B:[[108, -103, 72, 42, 37]] |a0=[B:[[32, 10, 108, -103, 72, 42, 32, 37]]\012",
        Z.run(T, 1, 10, 11, 1, "\u2c50\ud93a\udc9c\u74c9\ud878\udc5a\udb50\udd55\u1340\ud82b\udfa6\ud957\udf56\uda4d\udc8a\udb97\ude38\u0091\udabf\udd3e\udb1b\udd89\ud8eb\udfaf\udaeb\ude3b\ud8df\ude5f\ud8ca\udfb6\uda6c\udfc8\ud83a\udc9c\ud8bb\udcee\u009a\uda47\udfc0\ud9be\udc24", "\u2f05", "\ud97f\ude92",
        53, 83937, 965578945, -2122311261548580337L, -49482L, true, false, (char) 0, (char) 45294,
        Double.longBitsToDouble(0x3faefb5f99d00f80L), Double.longBitsToDouble(0x3fe7420a28e21400L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 5, 0, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0|\ud845\udfe8\ud98d\udf63\ud82c\udc60\ud957\udf56A\000\000\000\000\udaec\ude12\u373d\ud869\udfc2\000\000\udada\udc0c\udaee\udd42\ub31b\000\ud95e\ude0e", "\u5bd1", "\ud97f\ude92\udba1\udffb",
        18, -1000, 199229440, 4339615687098527544L, 38065L, false, true, (char) 23412, (char) 3410,
        Double.longBitsToDouble(0x3fccf800f0f7dafcL), Double.longBitsToDouble(0x3fd4a2cf8c34b6bcL)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\0121=[B:[[]] |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 2, 4, 5, 0, "\ud81a\uddc8\ud939\udfc0\ud9cf\udea0|\ud845\udfe8\ud98d\udf63\ud82c\udc60\udbd6\ude75A\000\000\000\000\uda67\udf6f\000\ud869\udfc2\000\000\udada\udc0c\udaee\udd42\000\000\ud95e\ude0e", "\u5bcc", "\ud800\udf33\udba1\udffb",
        -5, -1000, 199229440, 4339615687098527544L, 38065L, false, true, (char) 23412, (char) 40273,
        Double.longBitsToDouble(0x3e40f7dafc000000L), Double.longBitsToDouble(0x3fd4a2cf8c34b6bcL)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.binary.Base64:@?\012",
        Z.run(T, 1, 1, 11, 1, "\uda11\ude61\ud923\udfcf\ud9cf\udea0\ud8ee\uddfa\udbfb\uded0\ud98d\udf63\udaa1\ude9f\udaee\udf30\ud965\udd43\udb97\ude38\ud845\udf1a\udbe7\udcef\ud9b9\udd98\ud877\udd6f\ud9af\ude43\udbde\udedd\udafc\udfec\uda01\udef3", "\u407d\ub839\u2512\u0e61\u819b\u0fa0\u0215\u0a56\ua728\u930b\u3e61\ua2db\u4024\u1835\u3f81\u4742\u00f0\u733d\uc895\u71a0\u2a6c\ub495\u63a9\ubc13\u6084\u3af8\u821c\uc6db\u29dd\ud0ec\u4522\u0573\u75a2\uc20c\u9516\u7978\u74f1\u3b6b\u3ac3\u1e41\u9a61\ubcaf\ud26e\uab75\ua164\u410b\uad96\u7e28\u6afa\u4547\u807c\u1228\u756e\u16ce\u5e70\ubf89\u4e2c\ub422\u413f\u61aa\u49dc\ub95d\u6e1c\u38c5\u4f5e\u1e38\ub0ab\ua855\u694a\u6f1e", "\udaed\udc5c\udaf7\udc43\udb96\udc90\ud86e\udfa1\udb18\udeee\udb01\udeeb\u08a6\ud9d8\udd13\udbf6\udffa\ud952\udcf5\ud847\udd7e\ud9c9\udd92\ud9b9\udd08\uda47\udfac\ud918\ude8c\u5297\ud9d9\udee8\ud8d3\udefd\udb33\ude95\ud999\udc0d\udaf6\udf3e\ud8a1\udd3d\udb78\ude72\u5b03\udba1\udf9f\udae3\udc12\udb98\udd5e\ud8bd\ude2a\ud81e\udded\ud97e\udf04\ud9ff\uddf0\uda9e\udd53\u9c76\ud9e8\udd65\ud934\udea0\udb52\udc64\udb17\udf8e\ud838\udc3e\udb3e\udd76\ud965\udf2f\udb5c\udfef\udb2d\udc0f",
        46, 66498, 137766918, -6989859576135359279L, 40961L, true, true, (char) 21024, (char) 32528,
        Double.longBitsToDouble(0x3fc79a221df0a15cL), Double.longBitsToDouble(0x3fe0d7ed58869bd4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.Base64|encodeBase64String|[B|static",
    "M|org.apache.commons.codec.binary.Base64|avail||new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|containsBase64Byte|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.String|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|decodeBase64|java.lang.String|static",
    "M|org.apache.commons.codec.binary.Base64|decodeInteger|[B|static",
    "M|org.apache.commons.codec.binary.Base64|discardWhitespace|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encode|[B|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|java.lang.Object|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encode|[B,int,int|new:org.apache.commons.codec.binary.Base64:",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64|[B,boolean|static",
    "M|org.apache.commons.codec.binary.Base64|encodeBase64String|[B|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
