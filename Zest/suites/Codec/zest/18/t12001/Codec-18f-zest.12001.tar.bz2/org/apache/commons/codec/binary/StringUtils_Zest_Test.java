package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 12, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud991\udc2a\ud938\uddf1\ud9e8\udf98\ud928\udcc9\ud907\udeda", "\uc70c\u030b\u0de4\u29f1\u7d83\u8f5d\u198d\u4abc", "\udb08\udd9e\uda8f\udc03",
        26, 32810, -1699846374, -2387695852957030627L, -88130L, false, true, (char) 62275, (char) 63553,
        Double.longBitsToDouble(0x3fc72c3b8acd80f8L), Double.longBitsToDouble(0x3feee945e0623d60L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 12, 2, "\ud836\uddf5\ud95a\ude5a", "\ud2b1\ub33d\u5f7e\ud5af\u1688\u4402", "\ud9a6\udc04\u76dc\udb5a\udfcb\udbc9\ude5a\udb27\udcc9\ud8ac\ude7e\ud837\udcb5\ud89f\ude2c",
        1, 56768, 133320036, -4463571349915408614L, -11709L, true, true, (char) 32336, (char) 60069,
        Double.longBitsToDouble(0x3fe51c05035a64e8L), Double.longBitsToDouble(0x3fc72c3b8acd80f8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 2, "\ud836\uddb8", "\u19da\000", "",
        -5, -1000, 0, 8197958696697856L, 82379L, false, false, (char) 64108, (char) 2043,
        Double.longBitsToDouble(0x3fcf008745840000L), Double.longBitsToDouble(0x3fe291c00259db7eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 12, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud991\udc65\ud938\uddf1\ud9e8\udf98\uda55\udef8\ud907\udeda", "\uc70c\u3bb1\ua049\u29f1\u7d83\u8f5d\u198d\u4abc", "\udb08\udd9e\u7e27",
        40, 32810, -1699846374, -2387695852807360991L, 61977L, true, false, (char) 40089, (char) 13762,
        Double.longBitsToDouble(0x3fdb8c38f855b1c4L), Double.longBitsToDouble(0x3fe46dd715842bbeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=32 cap=32]\012",
        Z.run(T, 1, 2, 9, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud991\udc2a\ud938\uddf1\ud9e8\udf98\ud928\udcc9\ud907\udeda", "\u14e7\u030b\u0de4\u944e\u7d83\u2cb2\u198d\u4abc", "\udb08\udd9e\uda8f\udc03",
        26, 32810, -1699846374, -2387695852957030627L, -88130L, false, true, (char) 62275, (char) 63553,
        Double.longBitsToDouble(0x3fc72c3b8acd80f8L), Double.longBitsToDouble(0x3feee945e0623d60L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 12, 2, "\ud836\uddf5\ud95a\ude5a\udb29\udc4b\ud998\ude22\ud938\uddf1\ud9e8\udf98\ud928\udcc9\ud907\udeda", "\uc70c\u030b\u0de4\u29f1\u7d83\u88d7\u50ee\u49f1", "\udb08\udd9e\uda8f\udc03\udac2\udfd0\ud9c0\udddb\ud9a8\udd21\ud826\udd52\udb4c\udeae",
        2, 56122, -2136992826, 7271187644436747098L, -31725L, true, true, (char) 13762, (char) 54996,
        Double.longBitsToDouble(0x3fa81e776ec96480L), Double.longBitsToDouble(0x3fec7cd1a7675770L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:2Q**3\u00f8a\u00fa |a0=[B:[[50, 81, 42, 42, 51, -8, 97, -6]]\012",
        Z.run(T, 1, 14, 1, 13, "\ud862\udd81\ud95a\ude5a\udb63\ude28\ud991\udc2a\ud92e\ude3f\ud9e8\udf98\udb93\ude9e\udb04\udc57", "\u8446\u81e4\u0de4\u42f0\u686d\u8f5d\u198d\u4abc\u1c52\ub306\u4b6b\u018d\ube43\u3417\u7f04\u1c00\u3e03", "\ud941\udc44\ud944\udc95",
        59, 18873, 683412147, 4422662225664966498L, -71835L, false, true, (char) 6400, (char) 3905,
        Double.longBitsToDouble(0x3fbd49367e863c70L), Double.longBitsToDouble(0x3fefc23309a76d22L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 12, 2, "\ud824\udc4c\ud95a\ude4c\udb63\ude28\ud991\udc2a\ud938\uddf1\ud9e8\udf98\ud928\udcc9\ud907\udeda", "\uc70c\u030b\u105a\u19a4\u7d83\u8f5d\u198d\u4abc", "\udb08\udd9e\uda8f\udc03",
        26, 32810, -1699846374, -2387695852957030627L, -88130L, false, true, (char) 62275, (char) 63553,
        Double.longBitsToDouble(0x3fc72c3b8acd80f8L), Double.longBitsToDouble(0x3feee945e0623d60L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 12, 2, "\ud836\uddf5\ud95a\ude5a\uda51\udd05\ud990\udfb7\ud938\uddf1\ud9e8\udf98\ud928\udcc9\ud907\udeda", "\uc70c\u030b\u0de4\ua1ae\u31a5\u6735\u198d\u4abc", "\udb08\udd9e\uda8f\udc03\udb83\udddb\ud9c0\udddb\ud9a8\udd21\ud9db\udc4a\udb4c\udeae\u5846\uda1b\udf35\ud941\udc44\ud944\udc95\ud970\udd1e\udbf7\ude64\ud92b\udd86\udb5e\udc29\udba9\ude57\udad6\udede\uda9e\udeff\udabc\udecd\udbef\udd85",
        32, 92894, -565894983, 50876674305658053L, -57002L, true, false, (char) 17661, (char) 31936,
        Double.longBitsToDouble(0x3fee98d69579b490L), Double.longBitsToDouble(0x3fd2ab9bfd0e0280L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 2, 2, "\ud861\udf39\udbcd\udf43\udb38\udd0a\ud991\udc2a", "\uc3a4\u975d\u0826\u0a04\ud7e9\u030b\u0d9b", "\udbc9\ude5a\u9108",
        39, 29393, -584128887, -8382341907068496403L, -65870L, true, true, (char) 24564, (char) 14281,
        Double.longBitsToDouble(0x3feacb53b2cfaaf8L), Double.longBitsToDouble(0x3fdf071e08878178L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 12, 2, "\udb71\udeb7", "\u96b0", "\ud928\udcc9\ud99d\udc64\ud828\uddf4\ud80e\udc46\ud93d\udcc0\udb3a\udf47\ud9a5\udf77\u76dc\udb57\udfcb\udbc9\ude5a\udb27\udcc9\ud8ac\ude7e\ud837\udcb5\ud8dd\udc2b\udb08\udd9e\uda8f\udc03\udb83\udddb\ud9c0\udddb\ud9a8\udd21\ud826\udd52\udb4c\udeae\u5846\uda1b\udf35\ud941\udc44\ud944\udc95\ud970\udd1e\udbf7\ude64\uda11\udd19\udbd9\udf7a\ud991\udc4a\uda24\udc2d\ud8e8\ude5b\udbcb\ude0e\udb2c\ude90\udac3\udcd2\ud89d\udf03\ud9cd\udd01",
        54, 90232, -372493493, -3390737734261400137L, 95076L, false, true, (char) 40088, (char) 54023,
        Double.longBitsToDouble(0x3fe657ab08292d4eL), Double.longBitsToDouble(0x3f9957fb30176b80L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 2, "\ud836\uddf5\ud95a\ude5a\ud89e\udf1d\ud991\udc2a\ud938\uddf1\ud9e8\udf98\ud928\udcc9\ud907\udeda", "\uc70c\u030b\000\u29f1\u7d83\u8f5d\u198d\u4abc", "\udb08\udd9e\uda8f\udc03",
        26, 32810, -1699846400, -2387695852957030627L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e08800000000000L), Double.longBitsToDouble(0x3fe1ba732464161bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 0, "\ud8c4\udf3d\000\000\000\ud938\uddec\uda2d\uddd5\udbf7\udf31\ud8fe\ude7f", "\u7684", "\u0095\udb5a\udfcb\udbc9\ude5a\u9c8a\ud8ac\ude7e\ud837\udcb5\ud8dd\udc2b\udb08\udd9e\uda8f\udc03\udb83\udddb\udb4f\udd82\ud9a8\udd21\ud826\udd52\ud98a\udf85\u5846\uda1b\udf35\ud941\udc44\ud944\udc95\ud970\udd1e\udbf7\ude64\uda11\udd19\udbd9\udf7a\udb17\ude0e\ud92a\udc80\ud94b\udece\ud84a\uddf4\udbd9\ude8c\udaf1\uddab",
        19, 85455, -447164424, -8756295560565866009L, -40341L, true, true, (char) 14952, (char) 14792,
        Double.longBitsToDouble(0x3fc74c42de579334L), Double.longBitsToDouble(0x3fdf1cbf2a289784L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[B:[[-10, -38, 109, -35, 49, -38, 44, -34, 27, -40, 55, -33, 79, -37, -31, -35, -24, -38, 114, -36, -82, -38, -66, -35, -68, -40, -12, -33, -69, -40, 103, -36]]\012",
        Z.run(T, 1, 9, 1, 2, "\udaf6\udd6d\uda31\ude2c\ud81b\udf37\udb4f\udde1\udae8\udc72\udaae\uddbe\ud8bc\udff4\ud8bb\udc67", "\uac7e\u9a6a\ua7e9\u0684\u7e76\u8f5d\u198d\u4abc\u1c52\u976b\u0f67", "\udb10\uddf5\ud9a8\udd4e\ud826\udd52\udb4c\udf4f",
        2, 56122, -2136992826, 5837814808439101803L, -97261L, true, false, (char) 5701, (char) 30695,
        Double.longBitsToDouble(0x3fe5898004a45724L), Double.longBitsToDouble(0x3fdcb0eb8720e74eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ud836\uddf5\ud95a\ude5a\ud9e1\udc67\udb65\udc34\udba5\ude6e\udad7\udd18\ud9c8\udd9d\ud907\udeda: null\012",
        Z.run(T, 1, 11, 12, 2, "\ud836\uddf5\ud95a\ude5a\ud9e1\udc67\udb65\udc34\udba5\ude6e\udad7\udd18\ud9c8\udd9d\ud907\udeda", "\u3cf4", "\u76dc\udb7f\udcaf",
        6, 47026, 718632952, 4069900980328506968L, -20928L, false, true, (char) 15732, (char) 10537,
        Double.longBitsToDouble(0x3fea34d60f1ddeddL), Double.longBitsToDouble(0x3fd2fb4d2145595cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 1, 6, 12, 15, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud991\udc2a\ud938\uddf1\ud9eb\udc98\ud928\udcc9\ud907\udeda", "\u20c5\u030b\u0de4\u29f1\u7d83\ud27a\u19a6\u4abc", "\udad7\udd9e\uda8f\udc03",
        26, 86770, 692738940, -197853025065816510L, -29259L, false, true, (char) 62275, (char) 63553,
        Double.longBitsToDouble(0x3fc72c3b8acd80f8L), Double.longBitsToDouble(0x3feee945e08c3d60L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[B:[[-16, -99, -88, -125, -16, -98, -107, -118, -13, -88, -74, -76, -16, -95, -68, -74, -13, -127, -114, -128, -13, -75, -93, -66, -15, -126, -68, -84, -14, -77, -83, -88, -16, -102, -121, -84, -16, -109, -95, -122, -15, -97, -109, -128, -16, -71, -88, -128, -14, -128, -124, -92, -25, -101, -100, -29, ...\012",
        Z.run(T, 1, 10, 12, 2, "\ud836\ude03\ud839\udd4a\udb63\uddb4\ud847\udf36\udac4\udf80\udb96\udcfe\ud8cb\udf2c\uda8e\udf68\ud828\uddec\ud80e\udc46\ud93d\udcc0\ud8a6\ude00\ud9c0\udd24\u76dc\u378a\ud931\udfd4\ud904\udc12\ud948\udfca\ud8d6\udeee\uda71\udd84", "\u0efd\u3417\u7504\u1c00\ub764\u93fe\u0ee4\u7cae\u1009\u33ba\uac50\u52fa\u6c9b\u7165\u2562\u5e6c\u74f1\uace8\uc2c6\u5223\ubf71", "\ud989\udc0b",
        24, 25077, 1850340663, 5245105740257957753L, -52662L, false, false, (char) 45738, (char) 11767,
        Double.longBitsToDouble(0x3fd35f19e707ff46L), Double.longBitsToDouble(0x3fe2519ca7d83cbdL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 1, 4, 12, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud991\udc2a\ud938\uddf1\ud9e8\udf98\udb3f\udd95\ud823\ude02", "\uc70c\u030b\u0de4\u29f1\u7d83\u8f5d\u198d\u4abc", "\udb08\udd9e\uda8f\udc03",
        26, 32810, -1699846374, -2387695852957030627L, -88130L, false, false, (char) 40894, (char) 63553,
        Double.longBitsToDouble(0x3fc72c3b8acd80f8L), Double.longBitsToDouble(0x3feee945e0623d60L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -40, 54, -35, -11, -39, 90, -34, 90, -37, 99, -34, 40, -39, -111, -36, 42, -39, 56, -35, -15, -39, -47, -36, -104, -39, 40, -36, -55, -39, 7, -34, -38]]\012",
        Z.run(T, 1, 7, 4, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud991\udc2a\ud938\uddf1\ud9d1\udc98\ud928\udcc9\ud907\udeda", "\uc70c", "\u76dc\udb5a\udfcb\udbc9\ude5a\udb27\udd16\ud8ac\ude7e\ud927\udc2d\udbfb\udd1e\uda76\udcf7\uda7c\udf40\udb83\udddb\ud9c0\udddb\ud9a8\udd0c\ud826\udd52\udb4c\udeae\u5846\uda1b\udf35\udadb\udc01\ud944\udc1f\ud970\udd1e\udbf7\ude64\uda11\udd19\udbd9\udf7a\u1826\ud927\udfc2\ud855\udc84\ud851\uddb8\ud9d3\udda6\ud920\ude9d",
        4, 53792, -51697552, 2080939959644265634L, 91856L, true, true, (char) 25465, (char) 36273,
        Double.longBitsToDouble(0x3fe12ab24cfa71afL), Double.longBitsToDouble(0x3fea588b006e689eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 0, "\ud836\uddf5", "\u972f", "\000\udb6a\ude75\ud828\uddf4\ud80e\udc46\uda79\udcbe\udb3a\udf47\ud9a5\udf77\u76dc\udb5a\udfcb\006\udb27\udc3f\uda92\ude71\ud837\udcb5\ud8dd\udc2b\udb08\udd45\uda8f\udc03\udb83\udddb\u0082\ud9a8\udd21\ud826\udd52\udb4c\udeae\u5846\u00a2\000\uda8b\udde4\ud970\udd1e\udaa6\udcbc\uda11\udd19\udaa8\udf05\udad5\uddca\udbc0\udf9d\udaca\udde5\udab4\uddc3\uda54\udcaa\udb89\uddd6\udab8\udefa\ud985\udeb3",
        7, 63567, 1375959133, -3781243104607003027L, -40708L, true, false, (char) 35555, (char) 58472,
        Double.longBitsToDouble(0x3fa93c15136e7e70L), Double.longBitsToDouble(0x3fe47cbaf1a876b8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 2, "\udb74\uddb7", "\u8daf", "\ud928\udcc9",
        3, 8068, -659375465, 8198396779823104L, 82379L, false, false, (char) 0, (char) 39935,
        Double.longBitsToDouble(0x3ef0e80000000000L), Double.longBitsToDouble(0x3e32c80000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\006\ufffd**3\ufffdMQ |a0=[B:[[6, -59, 42, 42, 51, -8, 77, 81]]\012",
        Z.run(T, 1, 15, 12, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud87d\udc81\ud938\ude69\ud9e8\udf98\ud928\udcc9\ud907\udeda", "\uc70c\u030b\u0de4\u29f1\u7d83\u8f5d\u198d\u6fbf", "\udb08\udd9e\uda8f\udc03",
        26, 32810, -1699846374, -2387695852957030627L, -88114L, false, true, (char) 62275, (char) 63553,
        Double.longBitsToDouble(0x3fc72c3b8acd80f8L), Double.longBitsToDouble(0x3feee945e068fe83L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 12, 2, "\ud834\uded8\ud95a\ude5a\udb63\ude28\ud977\ude2a\ud938\uddf1\udbdb\udd32\ud928\udcc9\ud907\udeac\ud828\uddf4\ud80e\udc46\ud9e2\udd73\udbf0\ude76\ud9a5\udf77\ud889\udf0b\uda6a\udc3a\udaa1\udfa6\udb15\udfad\ud8ac\ude7e\ud837\udcb5\ud8dd\udc2b\udb08\udd9e\ud96c\ude08", "\u7f8e\u1c00\u3e03\u426f\uc8e3\ubcce\uaa3b\u6756\u92ca\u52fa\u6c9b\u4bab\u0384\u970a\u0349\u7007\u2879\u6ce1\ua14d\u2142\ua8f5\ua67f\u982f\u953b\ud632\u20c2\uc727\u6ca0\uaba6\uac23\u5688\u0425\u98cc\u63d5\uc332\u22d0\u986e\ucbef\u4b34\uaf33\u9373", "\udbee\udf42\ud9af\udee3\uda32\uddd6\ud8e8\udf83\ud913\udd7f\ud853\uddb3\ud991\udfea\udbba\udebe\ud992\udcc7\udace\uddd7\udb1d\ude81\ud82d\udce1\ud8cd\udd65\uda4f\udde2\uda52\udcf9\uda45\udcb7\udb13\uddb6\udb1d\udd8f\udbca\uddaa\udb83\udeac\uda9a\udf05\udbae\udcc8\ud81b\udd19\udbc2\ude36\uda16\udca7\uda02\udc21\ud976\uded3\udbe0\udc2a\ud999\udc17",
        19, 64675, -1579577723, -3201593568035824086L, 87093L, false, false, (char) 7249, (char) 27962,
        Double.longBitsToDouble(0x3fe5536a10ead288L), Double.longBitsToDouble(0x3fae24dcdb103ca0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[B:[[47, -40, -77, -35, -42, -37, 90, -36, 99, -37, 40, -34, -111, -39, 42, -36, 56, -39, -15, -35, -41, -38, -91, -36, 40, -39, 5, -35, 7, -39, -38, -34]]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 5, 6, "\ud82f\uddb3\udbd6\udc5a\udb63\ude28\ud991\udc2a\ud938\uddf1\udad7\udca5\ud928\udd05\ud907\udeda", "\u28a9\u438a\u0de4\u29f1\u7d83\u8f5d\u7b92\u3cc0", "\uda66\udc45\uda61\udd4c",
        26, 32810, -1699846374, -2387695852074822179L, 80689L, false, true, (char) 62275, (char) 63553,
        Double.longBitsToDouble(0x3fc72c3b8acd80f8L), Double.longBitsToDouble(0x3feee945e0623d60L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\036\ufffd\011\ufffd\017\ufffd/\ufffd |a0=[B:[[30, -40, 9, -101, 15, -42, 47, -112]]\012",
        Z.run(T, 1, 15, 12, 2, "\udb4e\udc08\uda39\uddcb\udb3f\udf06\ud95f\udfc0\ud938\uddf1\udbbc\udc04\ud928\udcc9\ud8d2\udd0b", "\ud054", "\ud920\udd3d\udbcb\udcd7\udbc9\ude5a\uda19\udd62\ud8a2\ude20\ud837\udcb5\ud8dc\udfe9\udb08\udd9e\uda8f\udc03\uda42\udf1a\ud9e3\udcdb\ud9a8\udd21\ud9fc\udd9d\udb5f\udc79\u5846\udaa7\udc3b\udbb5\udd3d\ud8c7\udd28\udaf2\ude04\ub68d\udb3d\udf59\udaa8\udf46\ud99d\udcc8\uda30\udcbd\ud96e\udd1d\ud8eb\udcd8\ud947\udc30\ud8af\ude7c",
        -2, 2191, 1075139871, 750397645117779451L, -49107L, true, true, (char) 44384, (char) 11553,
        Double.longBitsToDouble(0x3fe16db2e3f5752bL), Double.longBitsToDouble(0x3fbeb679f08dc2b8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 12, 2, "\ud836\uddf5", "\u972f\ud2b1", "\ud907\udeda",
        53, 52535, -1038278554, -15196029180943535L, -96896L, false, false, (char) 1930, (char) 31794,
        Double.longBitsToDouble(0x3fd612ad5ca470f6L), Double.longBitsToDouble(0x3fe2cedbf5387b67L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 12, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\udbd8\uddd4\ud938\uddf1\udaf5\udeff\ud980\udf5a\ud907\udeda", "\uc70c\u030b\u0de4\u29f1\u7d83\u8f5d\u198d\u4abc\u1c52\ub30d", "\uda55\ude4f\ud898\udc64\udbf2\udf1a\udb6b\udd2f\ud8db\udc55\ud89c\udc89\uda1b\udf35\ud941\udc44\ud944\udc95\ud970\udd88\udbf7\ude64\uda11\udd19\udbea\udc7a\ud85a\ude90\udbf6\udfed\ud88a\udf05\udbdc\udd26\udb40\ude44\udbe3\udc4c\ud9da\udf91\ud8d6\udd85\ud8bb\ude06\ud90a\ude4c\ud846\uddeb\uda46\uddd5\udb00\udf93\udaa0\udf8b\udb32\udd10\ud922\udcf1\uda00\udeb3\uda41\ude8f\ud9c7\udd4b\ud9f8\udc10\udb3c\udde5\ud95b\udec0\ud873\udee4\udbc3\udc26\udb19\ude21\ud9bb\udc60\uda22\udc2f\uda18\udcb4\ud985\udfa1\udbd1\udc78\ud9f2\ude38\udb90\udd31\ud856\udc7d\ud905\udcd5\ud99e\ude9d\ud85d\udff6\udaec\ude65\uda98\udebc\ud99f\udec3\ud844\udcb3\udb24\udd5e\ud94e\uddc3\ud9a7\udc5a\udb15\ude79\ud885\udfb2\udafb\udcdf",
        1, 53993, -729955818, 4230952841392907135L, 57264L, false, true, (char) 48024, (char) 61797,
        Double.longBitsToDouble(0x3fdbcd2c62af5388L), Double.longBitsToDouble(0x3f942b79c450eac0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[B:[[-40, 54, -35, -11, -39, 90, -34, 90, -37, 99, -34, 40, -39, 107, -35, 42, -39, 56, -35, -15, -39, -47, -36, -20, -39, 52, -34, -3, -39, 7, -34, -38, -40, 40, -35, -12]]\012",
        Z.run(T, 1, 8, 10, 8, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud96b\udd2a\ud938\uddf1\ud9d1\udcec\ud934\udefd\ud907\udeda\ud828\uddf4", "\u030b\u0de4", "\udbc9\ude5a\udb27\udcc9\ud8ac\ude7e\ud837\udcb5\ud8dd\udc2b\udb08\udd9e\ud8f0\udcb4\ud868\ude45\ud917\udf45\udaba\udd90\udb87\udd3a\udb4c\udeae\u5846\ud935\ude62\ud941\udc72\u1d79\ud970\udd1f\udbf7\ude64\uda11\udd19\uda82\udfee",
        11, 97899, 1174017696, 4090032526442269709L, -12941L, true, false, (char) 18890, (char) 2082,
        Double.longBitsToDouble(0x3fa226d74d0bfc30L), Double.longBitsToDouble(0x3fd512987b3bc58cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 12, 2, "\uda74\udcf4\udbd0\udd29\uda64\udc5e\ud991\udc2a\ud938\uddf1\ud9e8\udf98\ud928\udcc9\udb50\uddbe", "\uc70c", "\u76dc\udb5a\udfcb\udbc9\ude5a\udb27\udcc9\ud8ac\ude7e\ud837\udcb5\ud8dd\udc2b\udb08\udd9e\uda8f\udc03\udb83\udddb\ud9c0\udddb\ud9a8\udd21\ud826\udd52\udb4c\udeae\u5846\uda1b\udf35\ud941\udc3b\ud944\udc95\ud970\udd1e\udbf7\ude64\ud941\udd11\udbd9\udf7a\ud99c\udff1\ud8d5\udf71\uda33\uddcd\u26ed\udb68\udc3c\ud987\udf93",
        39, 26025, -1041773832, -743530224283251562L, -34843L, false, false, (char) 30200, (char) 7169,
        Double.longBitsToDouble(0x3fe9e0c56e49efcbL), Double.longBitsToDouble(0x3fcea44d3ae32f60L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 13, 8, 11, "\ud86f\udcf5\ud95a\ude5a\udb63\ude28", "\ud3d1\u5f7e", "\ud80e\udc46\ud93d\udcc0\udb3a\udf47\ud8f3\udfbd\u76dc\udb5a\udfcb\uda65\udf70\udb27\udca3\ud9a6\udd62\ud837\udd4c\ud8dd\udc2b",
        9, 56768, 133320036, -4463571349915408614L, -11709L, true, true, (char) 32336, (char) 60069,
        Double.longBitsToDouble(0x3fe51c05035a64e8L), Double.longBitsToDouble(0x3fc72c3b8acd80f8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 9, 1, 9, "\udb1e\uddef\udbf0\udf29\udb08\ude22\ud931\ude9c\ud926\udce8\ud8d4\udfef\ud8ab\udd61\udae2\udf87", "\u0986\u6ecc\u7df7\u8817", "\uda14\udf22\ud8ab\uddd0\ud837\udcb5\udaa5\udfb0\udb11\udf72",
        56, -964, -1039256190, -7338220757012630714L, 88369L, false, true, (char) 15947, (char) 62143,
        Double.longBitsToDouble(0x3fead32740b961dcL), Double.longBitsToDouble(0x3fe59b01f3dde03bL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:\006\u00c5**3\u00f8k{ |a0=[B:[[6, -59, 42, 42, 51, -8, 107, 123]]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 14, 13, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\uda9b\udcab\ud82b\udf8c\udb9b\udd49\ud928\udcc9\ud907\udeda", "9\ubdb5\u5f07\u9ca9\u2010\u8f5d\u198d\u3353", "\udbe0\udf1b\ud857\udcdc",
        53, 67450, -1699846196, -2423125416138856675L, -88130L, false, true, (char) 62275, (char) 62556,
        Double.longBitsToDouble(0x3fed923c92b3603eL), Double.longBitsToDouble(0x3fdb128bce87a340L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 13, 8, 2, "\ud91c\ude0c", "\u859e\u633c\ub0ae\u5c2f\u77c8\u9190\u00b5\u7022\000\u0de4\u29f1\u7d83\u4118\u198d\u00f8\u4bc0\ub30d\u3fbd\u57f4\ub5e6\u3312\ucc67\u1cbb\u6799\u4627\u993b\ucb28\u6643\u467d\u203e\u4555", "\ud814\udd79\ud867\uddb0\ud969\ude25",
        4, 49816, 2083911447, -3570091817951574975L, -43640L, false, true, (char) 17929, (char) 18973,
        Double.longBitsToDouble(0x3fe278955a2a272dL), Double.longBitsToDouble(0x3fd084243b63109aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 2, "\u0b00", "\u19da\000", "",
        -5, -1000, 0, 8197958696697856L, -20384L, false, false, (char) 64108, (char) 0,
        Double.longBitsToDouble(0x3fcf008745840000L), Double.longBitsToDouble(0x3f2c00259db7e000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 0, "\ud8c4\udf00", "", "",
        -5, -1000, 0, 0L, -100000L, true, false, (char) 62869, (char) 34717,
        Double.longBitsToDouble(0x3ebb24535b880000L), Double.longBitsToDouble(0x3fcf008745840000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[B:[[-40, 54, -35, -72]]\0121=[B:[[-40, 54, -35, -72]]\012",
        Z.run(T, 2, 8, 8, 5, "\ud836\uddb8", "\u19da\000\000\000\000", "",
        17, -1000, -1095998639, 8898329551750082592L, 71146L, false, false, (char) 19499, (char) 56913,
        Double.longBitsToDouble(0x3fe2cedbf40738ffL), Double.longBitsToDouble(0x3fe883de679456ebL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 15, 12, 2, "\ud836\uddb8", "\u19da\u00b3", "",
        -5, -1000, 0, 8197958696697856L, 82379L, false, false, (char) 64108, (char) 2043,
        Double.longBitsToDouble(0x3fcf008745840000L), Double.longBitsToDouble(0x3fe291c00259db7eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 2, 12, 2, "\ud836\uddb8", "\u5cf3", "\u0087",
        -5, -1000, 0, 8197958696697856L, -66613L, false, true, (char) 59878, (char) 2043,
        Double.longBitsToDouble(0x3fcf008745840000L), Double.longBitsToDouble(0x3fe2c2800259db7eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ud836\uddb8: null\0121=null\012",
        Z.run(T, 2, 11, 15, 2, "\ud836\uddb8", "\u19da\u0f28\u77b4\u8539\000\u18e4\u9e34\ua20d\u597d\ud630\u96ca", "\udbb0\udeae\u5093\ud88d\ude8b\ud8dc\udfe5\ud98f\udda3\ud872\ude8c\ud9ba\udd89\ud84b\udec5\udb5b\udc07\udb0f\ude32\udae3\ude4f\uda60\udfcb\udb6f\udf48\ud9de\udd9f\udbd2\udddf\ud9b1\udeea\ud8c4\udccf\ud8e3\udddd\udb50\udcca",
        32, 19002, -1735207481, 4693950009808775680L, -91826L, true, true, (char) 61337, (char) 37746,
        Double.longBitsToDouble(0x3fce707ba88c0038L), Double.longBitsToDouble(0x3fe0da7df9577720L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 12, 6, "\ud955\udf3f\udbd9\udfe1\udb63\ude28\ud991\udc65\ud938\uddf1\ud9e8\udf98\uda55\udef8\ud92b\uddda", "\u63cb\u082e\u35d5\ua6f1\u7d83\u8f5d\u198d\u4ad7", "\udafc\udd0e\ud990\udde8\ud863\uddec\ud9c0\udddb\ud9a8\udd21\ud826\udd52\ud8b0\ude9c\ud9aa\uddf0\udba4\udf44\udabf\udec2\uda2b\udc2d\uda2c\udd89\udbf7\ude64",
        -3, 66063, -1013974942, -2818635751596344278L, -77115L, true, false, (char) 15445, (char) 26126,
        Double.longBitsToDouble(0x3fe8c97da8b776a4L), Double.longBitsToDouble(0x3fd4f245a683ab8aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ud836\uddf5\udb22\ude5e\udb63\ude28\udb18\udf8f\ud8e5\udebf\uda56\ude11\ud928\udcc0\ud907\udeda: null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 3, "\ud836\uddf5\udb22\ude5e\udb63\ude28\udb18\udf8f\ud8e5\udebf\uda56\ude11\ud928\udcc0\ud907\udeda", "\u457f\u87f6\u91df\u24d8", "\udb27\udcc9\ud8ac\ude7e\ud837\udcb5\ud9e7\uded2\udb0c\udec0\uda8f\udc03\udb83\udddb\ud9c0\udddb\ud9a8\udd21",
        48, 23925, -1397840593, -2963419538208582714L, -62278L, true, false, (char) 14938, (char) 40089,
        Double.longBitsToDouble(0x3fb88f5823ede178L), Double.longBitsToDouble(0x3fc70565f85ff4acL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:\006\ufffd**\ufffd\033h\ufffd |a0=[B:[[6, -59, 42, 42, -7, 27, 104, -14]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 12, 11, "\ud836\uddf5\ud95a\ude5a\udb29\udc4b\ud998\ude22\ud938\uddf1\ud9ba\udc98\ud945\udf96\ud907\udeda", "\u7759\u030b\ub9f2\u29f1\u7d83\u88d7\u50ee\u49f1", "\udb08\udd9e\uda8f\udc03\udac2\udfd0\ud9c0\udddb\ud9a8\udd21\ud826\udd52\udb4c\udeae",
        2, 56122, -2136992826, 7271187644436747098L, -31725L, true, true, (char) 13762, (char) 54996,
        Double.longBitsToDouble(0x3fa81e776ec96480L), Double.longBitsToDouble(0x3fec7cd1a0bd5770L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\004\u00de**3\u00f8a\u00fa |a0=[B:[[4, -34, 42, 42, 51, -8, 97, -6]]\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 0, 13, "\ud834\udf0e\ud95a\ude5a\udb63\ude28\ud991\udc2a\ud92e\ude3f\udb5d\uddb3\udb93\ude9e\udb04\udc57", "\u8446\u81e4\u0de4\u42f0\u686d\u8f5d\u198d\u4abc\u1c52\ub306\ub7a4\u017e\u7a1b\u3417\u7f04\u1c00\u3e03", "\ud92c\udd22\ud944\udc6a",
        59, 18873, 683412147, 4422662225664966498L, -71835L, false, true, (char) 6400, (char) 3905,
        Double.longBitsToDouble(0x3fbd49367e863c70L), Double.longBitsToDouble(0x3fefc23309a76d22L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 12, 2, "\000", "", "\ud9e8\udf98\ud928\udcc9\ud907\udeda\ud828\uddf4",
        16, -1000, -3538101, 4197182577276092488L, -100000L, false, false, (char) 1082, (char) 23393,
        Double.longBitsToDouble(0x3fe291c3da59db7eL), Double.longBitsToDouble(0x3fd387b67ac8e69eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:1\011\ufffd\023\010\ufffda\ufffd |a0=[B:[[49, 9, -99, 19, 8, -38, 97, -6]]\0121=java.lang.String:1\011\u009d\023\010\u00daa\u00fa |a0=[B:[[49, 9, -99, 19, 8, -38, 97, -6]]\012",
        Z.run(T, 2, 15, 14, 2, "\ud861\udf39\udbcd\udf43\udb38\udd0a\ud991\udc2a", "\uc3a4\u975d\u0826\u0a04\ud7e9\u030b\u0d9b", "\udbc9\ude5a\u9108",
        39, 29393, -584128887, -8382341907068496403L, -65870L, true, false, (char) 48628, (char) 14281,
        Double.longBitsToDouble(0x3feacb53b2cfaa1bL), Double.longBitsToDouble(0x3fd975ae08876c42L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 0, "\ud8c4\udf3d\udae0\udc3c\ud993\udced\000\ud80b\udc75\uda3c\ude54\udbf7\udf31\ud8fe\ude7f", "\u22f6", "\ud8a9\udc93\udb85\udfcb\udbc9\ude5a\u9c8a\ud8ac\ude7e\ud8cb\udfe2\udb2c\ude08\udb08\ude29\uda8f\udc03\udb83\udddb\ud9e3\udd8c\ud9a8\udd21\ud826\udd52\ud98a\udf85\u5846\uda1b\udf35\ud941\udc44\ud944\udc51\ud970\udd1e\ud92e\udc80\uda11\udd19\udbd9\udf7a\udb17\ude0e\ud92a\udc80\udb2a\udfbd\ud84e\ude5f\udbd9\ude8c\udaf1\uddab",
        19, 85455, -447164424, -8756295560565866009L, -40341L, true, true, (char) 14952, (char) 42704,
        Double.longBitsToDouble(0x3fb051731caf2668L), Double.longBitsToDouble(0x3fdf1be9fa289784L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 10, "\ud8c4\udfbf\000\uefc1\uda23\udf30\ud916\udc14\uda2d\uddd5\udbf7\udf31\ud8fe\ude7f", "\u7684", "\uc795\uda09\ude23\ud9b3\ude49\ud8f0\udda5\ud8ac\ude7e\ud837\udcb5",
        12, 27244, 1857591174, 563403158371317122L, 83482L, false, false, (char) 22831, (char) 32336,
        Double.longBitsToDouble(0x3fc2ae7bea8e038cL), Double.longBitsToDouble(0x3fead32740b961dcL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 9, 14, 5, "\udaba\ude0c\udad2\udf98", "\ud368\u6d68\u7de6\ud5af\u7002\u8152", "\udb62\ude34\udb22\ude8f\ud9fe\udf1d\udbc9\udef3\udac1\udfb7\ud927\ude11",
        35, 26378, 983638964, 856089090744367464L, 32784L, false, true, (char) 62275, (char) 63553,
        Double.longBitsToDouble(0x3fc72c3b8acd80f8L), Double.longBitsToDouble(0x3fee3085e0b110fdL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=[B:[[47, -40, 9, -34, -61, -38, -111, -34, 99, -37, 40, -34, -111, -39, 42, -36, 56, -39, -15, -35, -41, -38, -91, -36, 40, -39, 5, -35, -96, -37, -123, -33]]\0121=[B:[[47, -40, 9, -34, -61, -38, -111, -34, 99, -37, 40, -34, -111, -39, 42, -36, 56, -39, -15, -35, -41, -38, -91, -36, 40, -39, 5, -35, -96, -37, -123, -33]]\012",
        Z.run(T, 2, 9, 9, 6, "\ud82f\ude09\udac3\ude91\udb63\ude28\ud991\udc2a\ud938\uddf1\udad7\udca5\ud928\udd05\udba0\udf85", "\ua8dc\u438a\u1190\ua2a5\uc8a8\u84c2\u66ea\u5773\u078f\u620c\ub26f\u82b8\u0ecf", "\uf4de\ud85d\udc69",
        19, 90241, -2136992826, 5181517417336837080L, -97261L, true, true, (char) 47188, (char) 31865,
        Double.longBitsToDouble(0x3fe1e514814f6ee3L), Double.longBitsToDouble(0x3fe1297a68978ea4L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 9, 10, 0, "\ud9b8\udcdc\u67a1\udb63\ude28\ud991\udc2a\ud938\uddf1\udad7\udca5\ud928\udd05\ud81c\ude75", "\u28a9\u438a\u0de4\u29f1\u7d83\u8f5d\u7b92\u3cc0\u1c52\u620c", "\udb83\udddb\ud9c0\udddb",
        16, 75238, -379054627, 5982988316881109457L, 61977L, true, false, (char) 40089, (char) 13896,
        Double.longBitsToDouble(0x3fd929e09f9b714eL), Double.longBitsToDouble(0x3f9479b248985ca0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.String:\u00ac\u00e1v[3\u0095k{ |a0=[B:[[-84, -31, 118, 91, 51, -107, 107, 123]]\0121=java.lang.String:\u00ac\u00e1v[3\u0095k{ |a0=[B:[[-84, -31, 118, 91, 51, -107, 107, 123]]\012",
        Z.run(T, 2, 14, 14, 2, "\ud9dc\udd11\udba6\udd8b\udb63\uddc5\uda9b\udcab\ud82b\udf8c\ud8a4\udcd2\ud928\udcc9\ud907\udeda\ud828\uddf4\ud80d\udfd4\udade\udfc2", "\ud65a\u65ce\u8f5d\u2853\ua2fd\uac61\u9224\u37bc\u3d68\u7d3f\u124f\u3d3f\ucc6a\u5e3c\u1cca\uc8e3\ubcce\uaa3b\u0449\u39f6\u4307\u2abb\u381c\u447a\ubeb3", "\udae5\udf8e\ud9bf\udc4d\ud9cb\udd20\ud86a\udeed\uda6e\udc42\ud95d\ude67\udb6c\udf41\ud99a\udc70\uda74\udf72\uda7f\udd10\ud8a3\udd93\udb69\udef8\udba0\uddfc\ud993\ude68\uda11\udd93\ud9b3\udee2\uda30\udf5b\ud9a7\ude0b\ud9b7\ude54\ud9c5\ude18\uec35\ud82e\udf80\ud8a1\uded2\ud8ab\udcb6\ud857\udd4a\udbfa\udc2c\ud9de\uddc7\udb95\udec1\udb52\ude7d\udbac\udf72\udbf3\udea6\ua730\udbf2\udce8\uda4f\udf98\udae1\udf47\ud8fd\udd0f\uda2b\udf4a\udb5a\uddfb\uda9b\udd5a\udab4\udf02\uda21\udf60\udbdb\udde5\uda18\udc1e\udb7f\udf1c\ud892\udedb\udbea\udebc\ud9d6\udd8c\ud9c0\udde1\udaa7\udd76\udbcb\udc71\ud9b3\udd3b\udbb1\uddd5\udae5\udf22\udae8\udede",
        28, 86574, -1867685319, -7489828497202498346L, 59105L, true, false, (char) 8290, (char) 7773,
        Double.longBitsToDouble(0x3fec0604663d3425L), Double.longBitsToDouble(0x3fdcbf414aca1a0cL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -37, 80, -35, -64, -39, 38, -33, -37, -39, -85, -36, -83, -38, -101, -36, -112, -37, 68, -36, 16, -37, -101, -35, 81, -39, 40, -36, -55, 97, 6, -37, 23, -33, 79, -40, 101, -36, 105, -38, -34, -33, -62, -37, -71, -35, 102, -37, 22, -36, -90, -39, 42, -36, -11, -40, -67, -33, 18, -39, 48, -3...\0121=[B:[[-2, -1, -37, 80, -35, -64, -39, 38, -33, -37, -39, -85, -36, -83, -38, -101, -36, -112, -37, 68, -36, 16, -37, -101, -35, 81, -39, 40, -36, -55, 97, 6, -37, 23, -33, 79, -40, 101, -36, 105, -38, -34, -33, -62, -37, -71, -35, 102, -37, 22, -36, -90, -39, 42, -36, -11, -40, -67, -33, 18, -39, 48, -3...\012",
        Z.run(T, 2, 7, 7, 2, "\udb50\uddc0\ud926\udfdb\ud9ab\udcad\uda9b\udc90\udb44\udc10\udb9b\udd51\ud928\udcc9\u6106\udb17\udf4f\ud865\udc69\udade\udfc2\udbb9\udd66\udb16\udca6\ud92a\udcf5\ud8bd\udf12\ud930\udc31", "\u41e2", "\uda5a\udeff\uda66\udc61\uda47\udf28\uda37\uded9\uda9e\ude81\ud81a\udd08",
        2, 45119, -43552556, -2444513909330899170L, -97261L, true, true, (char) 8922, (char) 39626,
        Double.longBitsToDouble(0x3feddf826a9a5de9L), Double.longBitsToDouble(0x3feb0a05acf03117L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.String:\006\ufffd**3\ufffdk{ |a0=[B:[[6, -59, 42, 42, 51, -8, 107, 123]]\0121=java.lang.String:\006\ufffd**3\ufffdk{ |a0=[B:[[6, -59, 42, 42, 51, -8, 107, 123]]\012",
        Z.run(T, 2, 15, 15, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\uda9b\udcab\ud82b\udf8c\udb9b\udd49\ud928\udcc9\ud907\udeda", "9\u8731\u5e32\u9ca9\u2010\u8f5d\u198d\u3353", "\udbe0\udf1b\ud857\udcdc",
        27, 93662, -1699846196, -5405071319417557632L, -88130L, false, true, (char) 62275, (char) 62556,
        Double.longBitsToDouble(0x3fed923c92b3603eL), Double.longBitsToDouble(0x3fed938de1c51dbeL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 14, 15, 2, "\ud836\uddf5\ud95a\ude5a\udb5f\udce7\udac7\udcfa\ud82b\udf8c\udbbe\uddbc\ud887\udd6d\ud91e\ude57", "9\ubdb5\u5f07\u9ca9\u2010\u8f5d\u198d\u3353", "\udbe0\udf1b\ud819\udee9",
        53, 52362, 1524500173, -2423043098795661539L, -88130L, false, true, (char) 62275, (char) 62556,
        Double.longBitsToDouble(0x3fed923c92b3603eL), Double.longBitsToDouble(0x3fdb128bcf2ba340L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 6, 6, 0, "\ud9c9\udde8", "\u128d\u901b\u94d9\u68cb", "\ud883\udc08",
        14, -1000, -1095998624, 8905261974747286560L, 71146L, true, true, (char) 22593, (char) 57037,
        Double.longBitsToDouble(0x3fe2cedbf3b73fe4L), Double.longBitsToDouble(0x3fa85d0c76f6e9c0L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud991\udc2a\ud938\uddf1\ud9e8\udf98\ud928\udcc9\ud907\udeda", "\uc70c\u030b\u0de4\u29f1\u7d83\u8f5d\u198d\u6d0e", "\udb08\udd9e",
        58, -964, -1039256190, -7300784585110113466L, -11215L, false, true, (char) 60069, (char) 62275,
        Double.longBitsToDouble(0x3fead32740b961dcL), Double.longBitsToDouble(0x3fe59b01f3dd28bcL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63, 63]]\0121=[B:[[63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 2, 4, 4, 6, "\ud82f\uddb3\udbd6\udc5a\udb63\ude28\ud991\udc2a\ud829\ude55\udadc\udd78\ud928\udd05\ud907\udeda", "\u28a9\u438a\u04f7\u9013\ubeb8\u8f5d\ua689\u5735", "\uda66\udc7a\u4c00",
        0, 49215, -1582405862, -2387695504182471203L, 80689L, false, true, (char) 14928, (char) 63553,
        Double.longBitsToDouble(0x3fc72c3b8acd80f8L), Double.longBitsToDouble(0x3fc99997818a57fcL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=[B:[[-16, -99, -89, -75, -15, -90, -87, -102, -13, -88, -72, -88, -16, -107, -74, -87, -14, -121, -112, -88, -13, -74, -73, -128, -15, -89, -71, -124, -14, -91, -120, -111]]\0121=[B:[[-16, -99, -89, -75, -15, -90, -87, -102, -13, -88, -72, -88, -16, -107, -74, -87, -14, -121, -112, -88, -13, -74, -73, -128, -15, -89, -71, -124, -14, -91, -120, -111]]\012",
        Z.run(T, 2, 10, 10, 2, "\ud836\uddf5\ud95a\ude5a\udb63\ude28\ud817\udda9\ud9dd\udc28\udb9b\uddc0\ud95f\ude44\uda54\ude11", "\u365c\u6763\u5f07\u9ca9", "\udb22\udf09",
        14, 41279, -608207588, 956257740175278591L, 44770L, false, true, (char) 43172, (char) 34124,
        Double.longBitsToDouble(0x3fd2f15d2345595cL), Double.longBitsToDouble(0x3fee36b6faa380a0L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 2, 2, 14, "\ud99c\uddec\ud91d\udc5a\udb63\ude28", "\ud2ab\uac14\u317c\u4065\u63c2", "\ud9a5\udf77\udb8e\udeea",
        59, 19680, 70950026, 1065020633441L, -39994L, true, false, (char) 51202, (char) 50217,
        Double.longBitsToDouble(0x3fd4674c5e9cf746L), Double.longBitsToDouble(0x3feb2080e42df299L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=32 cap=32]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud9c5\udf8d\ud95a\ude5a\udb63\ude28\uda9b\udcab\ud82b\udf8c\udb9b\udd49\ud928\udcc9\ud907\udeda", "9\u8731\u5e32\u9ca9\u2010\u8f5d\u198d\u7253", "\udbe0\udf1b\ud8d4\udeb2\ud8be\udcdf\ud95a\udd5f\ud9a8\udd9f\ud93d\udfda\ud994\udd0c\u5846\uda1b\udf35",
        14, 60603, 1200787317, 458370668631972477L, 30012L, false, false, (char) 7608, (char) 39601,
        Double.longBitsToDouble(0x3fe8a090885266a4L), Double.longBitsToDouble(0x3fa9b950eb2ce300L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String:\006\ufffd\ufffd.\ufffd\ufffd\ufffd\ufffd |a0=[B:[[6, -59, -78, 46, -105, -49, -109, -60]]\012",
        Z.run(T, 1, 15, 12, 5, "\ud836\uddf5\udbe2\ude5e\udac7\udfff\ud8c3\udff4\ud935\udf35\ud9e8\udf98\ud928\udcc9\ud907\udeda\ud980\udc7e\ud93b\uddeb\udb4f\ude39\ud847\udeb8\udbcc\udd49\ud847\udcc3\uda14\udc77\ud9c3\udf9c\udbce\ude56\ud9db\ude08\ud8f3\udea6\ud80f\udda3\udb45\udf53\ud92a\ude1a\ud87f\udc39\udb95\udcb8\ud9a8\udde1\ud8f2\udc91\ud910\udd27\u75aa\uda1b\udf25\ud984\ude69\ud98b\udc99\ud9f8\udf75\ud813\uddf4\uda2b\udcb0\udaed\udeb9\uda62\udc68\udab2\udcd9\ud9b7\udedb\udb8b\udf5d\ud8ea\udf21\uc637\ud8a5\udd34\udbc4\udda1\ud862\udd30\udac4\udde7\uda89\ude71\u2b73\ud9c7\udff0\u4daf\udb3f\udcab\uda71\ude6d\ud9d1\udc54\udbcb\uddf9\udbb7\udec3\udbc3\udd31\ud86f\ude1f\ud89c\udf47\uda70\udc0e\udae1\udc05\uda2e\udfec\ud85c\udc33\ud9b6\udc47\ud903\udcca\udaee\udd1b\ufa6d\udbf3\udd20\udbed\udee1\udb6b\udde3\udb78\udd3c\ud936\uddfc\udbb4\udc88\udbc5\udd8f\ud80d\udeed\ud83b\udd9a\udac5\udf4a\ud924\udfe9\uda8d\ude73\udb6c\udeb9\uda40\udc82\u4ef9\ud8e8\udf67\ud8f8\udf99\ud8c3\udf12\ud8c0\ude2e\ud815\udfc8\uc13f\udad1\udced\udafe\uddc3\u4375\ud9a0\udd00\udb84\ude85\uda20\udf0e\uda87\udd9c\ud9d4\udca1\udae2\ude76\udba5\udde9\ud8ce\udee7", "\u1104\u1314\u8a0c\u341b\ucf57\u0c3d\u0a67\ua4cd\u42cf\u798f\uc862\u226b\u78e0\u1a79\uc609\u3b69\u180b\uaea9\uc1fd\ucccc\u4852\ubdd5\ua675\ua78e\u38bb\ub541\u5837\u4975\u2798\u0bdb", "\udbbf\udd07\udb20\udf0c\udbda\udf89\ud820\udf0b\ud81e\udce0",
        51, 90300, -840382671, -5718293870571262822L, 69849L, true, false, (char) 15309, (char) 3888,
        Double.longBitsToDouble(0x3fec59f246a5dc0fL), Double.longBitsToDouble(0x3fe8c5a78e0f0e94L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.StringUtils|equals|java.lang.CharSequence,java.lang.CharSequence|static",
    "M|org.apache.commons.codec.binary.StringUtils|getByteBuffer|java.lang.String,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|getByteBufferUtf8|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytes|java.lang.String,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesIso8859_1|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUnchecked|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUsAscii|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Be|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Le|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf8|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|newIllegalStateException|java.lang.String,java.io.UnsupportedEncodingException|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|newStringIso8859_1|[B|static",
    "M|org.apache.commons.codec.binary.StringUtils|newStringUsAscii|[B|static",
    "M|org.apache.commons.codec.binary.StringUtils|equals|java.lang.CharSequence,java.lang.CharSequence|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
