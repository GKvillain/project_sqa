package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -13, -72, -115, -78, -13, -113, -126, -95, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -15,...\012",
        Z.run(T, 1, 10, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\u7ade\u98c3\u36ec\ub81f\uafaf\uceaf\u6850\u8c67\u6555\u07b2\u0482\u961f\u9581\u98ff\u3329\uca07\u29e5\ube91", "\udb03\udeaa\uf3a4\udbac\udfac",
        0, 47082, -1282608989, 6411468943939676371L, 57845L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fe0203be489424eL), Double.longBitsToDouble(0x3f878ed812057c40L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -13, -72, -115, -78, -13, -101, -121, -102, -14, -74, -97, -86, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -15...\012",
        Z.run(T, 1, 10, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udb2c\uddda\uda99\udfea\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\u3e91", "\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd21\udae0\udfaf\ud814\udf95\ud965\udca8\ud93c\udee7",
        42, 3546, 391595614, 283555485598545L, 29902L, false, false, (char) 57874, (char) 61311,
        Double.longBitsToDouble(0x3fe98db13800dfd8L), Double.longBitsToDouble(0x3e4426cc00000000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[B:[[-20, -78, -106]]\012",
        Z.run(T, 1, 10, 13, 13, "\ucc96", "\u51b8\ua95a\u8a36\u148c", "\ud8ca\udd98\ud962\uded9\u1696\ud80c\udd0b\u8457\ud8d2\udcbd\udb3a\uded3\ud974\udc35\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud8d6\udc17\ud9da\ude3f\ud959\udd24\ud9e4\uddb5\uda87\uddf0\u009d\ud8d2\udd88\000\000\ud8fb\udc09\ud994\ude2a\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udb94\udd71",
        43, 63674, -997778900, 7456023139687303175L, 23639L, true, false, (char) 4864, (char) 48101,
        Double.longBitsToDouble(0x3fe011ebf61dc8d5L), Double.longBitsToDouble(0x3fd0ab5554080ef8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 0, "\ud801\ude7d\ud876\udd7a\udb58\udd10\ud941\udd21\ud9b8\ude67\000\uda96\uddea\ud877\udf06\uda85\udfc8\000\ud81a\udf03\000\000\ud9f7\udc7a", "\u2ddd\u36e9b", "",
        -5, -1000, 0, 1862271133L, -90187L, false, false, (char) 39935, (char) 52494,
        Double.longBitsToDouble(0x3fd839ddb0000000L), Double.longBitsToDouble(0x3fd2a0cd50000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 10, 13, 6, "\ud801\ude7d\ud876\udd7a\udbe3\udeec\udb55\udd2b\uda8a\udcec", "\u0cbf\u18d6\u178a\u191b\u1605\uc6f1\uae69\u0fb2\ub81a\u2ddd\u49e9\u55d0\u7ade\u98c3\u36ec\ub81f\uafaf", "\udb8d\udc88\udbce\udd76\udae0\udfaf",
        14, 65921, 396282243, 924717634192106794L, -33980L, true, true, (char) 37872, (char) 26917,
        Double.longBitsToDouble(0x3fe15aa3dd8b6f87L), Double.longBitsToDouble(0x3fbe0c1e798ddbb8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -13, -72, -115, -78, -13, -113, -126, -95, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -15,...\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\ubbe0\ua5ee\u0a85\ub799\uafaf\uceaf\u6850\u8c67\u6555\u07b2\u0482\u961f\u9581\u98ff\u3329\uca07\u29e5\ube91", "\udb03\udeaa\uf3a4\udbac\udfac",
        0, 47082, -1282608989, 6411468943939676371L, 57845L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fe0203be489424eL), Double.longBitsToDouble(0x3f878ed812057c40L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -15, -120, -83, -77, -13, -113, -126, -95, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -91, -116, -77, -31, -104, -86, -12, -123, -124, -113, -14, -106, -125, -111, -15, ...\012",
        Z.run(T, 1, 10, 13, 14, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\ud8e2\udf73\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud954\udf33\u162a\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udbf8\udce4\ud97f\udd81\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud8d6\udc17\ud9a8\udf14\ud959\udd24\uda1a\uddb5\udaa5\udcf0\ud996\udf29\uda8f\udea4\udbce\udd76\udae0\udfaf\ud814\udf95\ud965\udca8\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udb94\udd71\uda09\udcb1\uda7c\uddcf\udb03\udeaa\uf3a4\udbac\udfac\udb8f\udd4b\uda7a\udf5d", "\u340d\u2653\u0177\ua09f\u7507\u1b20\u8470\u017b\ube0c\u98c0\u38d8\u2b1d\u5b11\u5344\u6b99\u2481\u5cb9\ub867\u27be\u3de6\u7ccf", "\ud81c\udd07\uda6e\udd2b\udaa4\udf46\uda85\ude9b\udabf\udecb\ud8b8\udd41\ub9e9\uda21\ude00\udaaf\ude62\udb7a\udc99",
        33, 66878, 831408542, 2163645380920952683L, -57637L, true, false, (char) 5867, (char) 61698,
        Double.longBitsToDouble(0x3fe9b8df6807293dL), Double.longBitsToDouble(0x3fe77ed89393444bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[B:[[-40, 1, -34, 125, -40, 118, -35, 122, -38, -117, -34, -10, -37, 73, -35, -77, -37, -96, -33, 114, -38, -83, -33, -69, -38, -102, -36, 67, -40, 119, -33, 6, -38, -123, -33, -56, -38, 65, -36, -12, -39, 98, -34, -39, 22, -106, -37, -44, -36, -28, -38, 24, -36, -47, -40, -46, -36, -67, -37, 58, -34, ...\012",
        Z.run(T, 1, 8, 13, 13, "\ud801\ude7d\ud876\udd7a\uda8b\udef6\udb49\uddb3\udba0\udf72\udaad\udfbb\uda9a\udc43\ud877\udf06\uda85\udfc8\uda41\udcf4\ud962\uded9\u1696\udbd4\udce4\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\u7c2e\u68ef\u36ec\u4d1f\uafaf\uceaf\u54c6\u226b\u8f55\uad51\u13d2\u582d\uc692\u439a\uaccc\u4bd7\u29e5\ube91", "\ud8e9\udfdc\ud91c\udc73\udbac\udfac",
        55, 47047, -1282608989, 2287661454799508349L, 57860L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fe0203be489424eL), Double.longBitsToDouble(0x3fd20c76c0ea01a4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -101, -101, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85]]\012",
        Z.run(T, 1, 10, 13, 4, "\ud801\udedb\ud876\udd7a\udb58\uddfb\udb55\udd2b", "\u148e\u0cbf", "\ud962\uded9\ud8f8\udc0d\udbd4\udcf0",
        12, 37246, -1281175132, 2409385484445946684L, 83284L, true, false, (char) 38757, (char) 8970,
        Double.longBitsToDouble(0x3fa2487fc3a1a9d0L), Double.longBitsToDouble(0x3fc3b0a51e09bc78L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\u7ade\u98c3\u36ec\ub81f\uafaf\uceaf\u6850\u8c67\u6555\u07b2\u0482\u961f\u9581\u98ff\u3329\uca07\u29e5\ube91", "\udb03\udeaa\uf3a4\udbac\udfac",
        0, 47082, -1282608989, 6411468943939676371L, 57845L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fe0203be489424eL), Double.longBitsToDouble(0x3f878ed812057c40L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -13, -72, -115, -78, -13, -113, -126, -95, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -15,...\012",
        Z.run(T, 1, 10, 13, 1, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud8d6\udc17\udb4b\udf47\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\udae0\udfaf\ud814\udf95\ud965\udca8\ud93c\udee7\uda54\ude8b", "\u6cc3\ube91\ub219\u1d14\u4baf\u102e\u4081\ub914\uc1f4\u3607\ua67d\u340d\u2653\u0177\ua09f\u3d9e\u39e9\ua09a\u017b\ube0c\u57b2", "\uda68\ude33\ud951\udfbe\uda20\udf97\udbb2\udd6b\ud876\udce7\ud98e\udca8\ud8c0\udf21\udba0\udcd7\ud883\udeb9\ud8be\udc16\ud952\uded0",
        57, 74688, -1297402993, 6609774572017432244L, 11022L, false, false, (char) 32717, (char) 44232,
        Double.longBitsToDouble(0x3fefbc812d5ed2edL), Double.longBitsToDouble(0x3feba2bd7e2312ebL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=67 cap=67]\012",
        Z.run(T, 1, 2, 13, 13, "\ubd4d\ud876\udd7a\udb58\uddfb\udb55\udd2b\ud852\udeeb\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\udbfc\udc95\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\uae6c\u9823\u36ec\ub81f\uafaf\u3405\u6895\u0249\u65d4\ub175\u4533\ua50e\u419f\u89cb\u36a6\uca7a\u29e5\ube91", "\udb03\udec0\ud8e9\udcfb\uda9d\udddc\udb8f\udd4b\uda7a\udf5d",
        12, 51976, -67557165, -2321844046282200939L, 68419L, false, true, (char) 59775, (char) 58701,
        Double.longBitsToDouble(0x3f874c4e12057c40L), Double.longBitsToDouble(0x3fd78f8c81089a2aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\u7bb6\u98c3\u36ec\ub81f\uafaf\uceaf\u754f\u8c67\u6555", "\ud965\udca8\ud93c\udee7\uda54\ude8b",
        27, 68485, -874770651, 7493500843098450930L, 23639L, true, false, (char) 3983, (char) 48101,
        Double.longBitsToDouble(0x3fe011ebf61dc8d5L), Double.longBitsToDouble(0x3fd0ab5554080ef8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 10, 13, 0, "", "\000\000", "\uda99\udfec",
        13, 16023, -1823512484, 906238099456L, -100000L, false, true, (char) 45296, (char) 0,
        Double.longBitsToDouble(0x3ebbcb113b100000L), Double.longBitsToDouble(0x3f89147b2a590000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udccb\udba0\udf72\udbf2\udc9c\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud881\udd74\000\000", "\u7ade", "\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\udae0\udfaf\ud814\udf95\ud965\udca8\ud93c\udee7",
        42, 3602, 391595614, 283555485598545L, 29902L, false, false, (char) 57874, (char) 121,
        Double.longBitsToDouble(0x3fe98db004b2dfd8L), Double.longBitsToDouble(0x3fc47d2e1426ce30L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -13, -72, -115, -78, -13, -113, -126, -95, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -15,...\012",
        Z.run(T, 1, 10, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud860\udc8c", "\u7ade\u98c3\u36ec\ub81f\u49af\uceaf\u6850\u8c67\u5695\u8bd6\u0482\u961f\u9581\u98ff\u3329\uca07\u29e5\ube91", "\udb03\udeaa\uf3a4\udbac\udfac\udb8f\udd4b\uda7a\udf5d\uda79\udc21\ud946\ude47\ud85d\udd1c",
        10, 79485, -925541886, -5380273108865492726L, -29385L, false, true, (char) 58874, (char) 32689,
        Double.longBitsToDouble(0x3fe54300807ad7c3L), Double.longBitsToDouble(0x3fefcf940b674a09L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 2, 14, 6, "\ud801\ude7d", "\ua0e1\u6534\u1a83\u148e", "\ud8ca\uddb1\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udabe\udef6\udb16\ude79\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud99f\udcfb\ud9da\ude3f\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\udae0\udfaf\ud814\udf95\ud965\udca8\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udb94\udd71",
        43, 68090, -102247446, 7456023022095796231L, 69806L, true, true, (char) 53270, (char) 33229,
        Double.longBitsToDouble(0x3fecafdfc8955350L), Double.longBitsToDouble(0x3fe011ebf61dc8d5L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -13, -72, -115, -78, -12, -114, -84, -127, -15, -82, -93, -68, -15, -112, -93, -109, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -14...\012",
        Z.run(T, 1, 10, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udbfa\udf01\ud97a\udcfc\ud902\udcd3\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\uda5b\udce1\ud837\udef7\udb0c\udf9b", "\u7ade\u98c3\u36ec\u0617\uafaf\u6663\uc3c3\u8c5c\u6555\u07b2\u0482\u961f\u9581\u98ff\u3329\uca07\u29e5", "\uda7c\uddcf\udb03\udeaa\uf3a4\udbac\udfac\udb8f\udd4b\uda7a\udf5d\uda79\udc21\ud946\ude47\ud8d2\udc96\udb98\udc7d\udadb\udc34\udad5\udec1\uda0e\uddb6\udbb8\udd7a\ud94b\uddec\uda30\udd32\ud556\ud9d8\udf16\uda6e\udfbe\uda67\udfc1\ud9be\udd14\ud9d7\ude0b\udb9a\udf22\ud8bf\ude24\udaaa\udc19\udb39\udfa3\uda3b\udd31\ud830\udfb9\ud9bf\udd20\uda0c\udcac\uda64\udfb6\udae1\udc2a\u053c\ud8d8\udc88\uda1b\udebd\udbfb\udfc4\ud802\udc93\udaef\udcd0\uda7f\udd2e\ud94d\ude05\ud807\udf29\udb9a\udea1\ud9d8\udf15\udad9\udc60\ud86e\ude6d\ud933\udf23\ud8ea\uddde\uda64\udfa6\udaa5\ude56\udb22\ude6f\udb04\ude60\ud96c\uddb8\udb09\ude4d\ud96a\udd17\ud930\udc73\udb3d\udda1\udaa6\ude31\uac39\uda99\udd17\uda58\udd8e\udb8c\udda7",
        56, 72750, 1860433993, 7332963116299691144L, 50767L, true, false, (char) 53026, (char) 29058,
        Double.longBitsToDouble(0x3fd88033d061b3e4L), Double.longBitsToDouble(0x3fd1a10623c6acd6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[B:[[-2, -1, -40, 1, -34, 125, -40, 118, -35, 122, -37, 88, -35, -5, -37, 85, -35, 43, -37, -96, -33, 114, -38, -4, -36, -95, -38, -103, -33, -20, -40, 119, -33, 6, -38, -123, -33, -56, -40, -54, -35, -12, -39, 98, -34, -39, 22, -106, -37, -44, -35, 15, -38, 24, -36, -47, -40, -46, -36, -67, -37, 58, -...\012",
        Z.run(T, 1, 7, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\u7ade\u98c3\u36ec\ub81f\uafaf\uceaf\u6850\u8c67\u6555\u07b2\u0482\u961f\u9581\u98ff\u3329\uca07\u29e5\ube91", "\udb03\udeaa\uf3a4\udbac\udfac\udb8f\udd4b\uda7a\udf5d\uda79\udc21\ud946\ude47\ud8d2\udc96\udb98\udc7d",
        50, 21114, -1252692451, 539403955972727300L, 64853L, false, false, (char) 15927, (char) 8071,
        Double.longBitsToDouble(0x3fe7065c7c3ae76dL), Double.longBitsToDouble(0x3fd3c9052de11e16L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\ufffdM\ufffd\ufffd(\ufffd%\ufffd |a0=[B:[[-47, 77, -21, -3, 40, -53, 37, -5]]\012",
        Z.run(T, 1, 15, 13, 13, "\ud801\ude7d\udb1b\udf2d\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\u7ade\u7b01\u5c58\u01ea\uafaf\uceaf\u6850\u8c67\u6555\u07b2\u0482\u961f\u9581\u0b12\u80a5\uca07\u29e5\ube91", "\udb03\udeaa\uf3a4\udbac\udfac",
        0, 47082, -1282608989, 6411468943939676371L, 57845L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fe0203be489424eL), Double.longBitsToDouble(0x3f878ed812057c40L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\ud9b8\udc6d\udbd4\udd0f\ud801\udda6\ud8d4\udc21\udb3a\uded3\ud974\udc35", "\u7ade\u98c3\u36ec\ua3ff\uc64f\ud4ac\u14db\u8c67\u6555\u07b2\u0482\u961f\u9581\ucc4f\u7e2d\ub6d7\u77a8\u5ebd", "\udbe3\udef9\uf3a4\udbac\udfac",
        0, 47082, -1282608989, 6411468943939676371L, 57845L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fe0203be489424eL), Double.longBitsToDouble(0x3f878ed812057c40L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 4, 13, 13, "\ud801\ude7d\ud876\udd7a\ud94c\udcda\ud86e\udc18\udbb8\udc61\udafc\udca1\uda99\udfec\ud995\uddf0\udac0\udd24\ud804\udf7a\ud962\ude91\u1696\udbd4\udd0f\uda06\ude4e\ud8d2\udcbd\udb3a\uded3\uda21\udd6c", "\u7ade\u98c3\uafd5\ub800\uafaf\u45c1\u67ea\u8c67\u21f1\u077c\uca1a\u963d\ub681\u6921\u00e2\u957a\u29e5\ube91\ub219\u4922\u726a\ud6c8\u4081\u4136\u3261\u2b3e\u4a13\u3323\u6e0f", "\uda0e\uddb6\udbb8\udd7a\ud94b\uddec\ud9b2\udd33\ud556",
        22, 42465, 464569980, -6700585604764192860L, 66615L, true, false, (char) 65448, (char) 3764,
        Double.longBitsToDouble(0x3fb31e51d37ccb68L), Double.longBitsToDouble(0x3fede3a9dae71188L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[B:[[-15, -122, -66, -86, -16, -78, -120, -84, -27, -65, -67, -16, -69, -120, -112]]\012",
        Z.run(T, 1, 10, 13, 13, "\ud8db\udfaa\ud888\ude2c\u5ffd\ud8ac\ude10", "\u0d72", "\ud8ca\uddf4",
        58, 73282, 206798934, 5476241179776421222L, 98243L, false, true, (char) 55491, (char) 24649,
        Double.longBitsToDouble(0x3fe0ab81fcefb24eL), Double.longBitsToDouble(0x3fdaabc3a0499c32L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[B:[[]]\012",
        Z.run(T, 1, 10, 13, 0, "", "\uc7af\u51b8", "\uda99\udfec\ud877\udf06",
        43, 41516, 1999915987, -7713658025280307114L, -63802L, true, true, (char) 15525, (char) 13483,
        Double.longBitsToDouble(0x3fd622762819147aL), Double.longBitsToDouble(0x3fc52c8833bec9d8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[B:[[63, -52]]\012",
        Z.run(T, 1, 9, 7, 2, "\ucc3f", "\u51b8\ua95a", "\ud9fd\udfac",
        48, 3273, 1999915987, -1156416967712668364L, -6124L, false, true, (char) 15525, (char) 13483,
        Double.longBitsToDouble(0x3fd622762819147aL), Double.longBitsToDouble(0x3fc52c8833bec9d8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:f |a0=[B:[[102]]\012",
        Z.run(T, 1, 14, 13, 13, "\ucc96", "\u51b8\u679c\u6c2e\u148c", "\ud8ca\udd98\ud962\uded9\u1696\ud80c\udd0b\u8457\udbfd\udcd1\udb3a\ude65\ud974\udc35\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud8d6\udc17\ud9da\ude3f\ud959\udd24\ud9e4\uddb5\uda87\uddf0\u009d\ud8d2\udd88\000\000\udadf\udc9b\ud994\ude9e\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udb94\udd71",
        43, 43826, 1698730030, 5019118718104864939L, 23639L, true, false, (char) 4864, (char) 48101,
        Double.longBitsToDouble(0x3fe011ebf61dc8d5L), Double.longBitsToDouble(0x3fe89aa2c204077cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ucc96: null\012",
        Z.run(T, 1, 11, 2, 6, "\ucc96", "\u51b8\ua95a\u8a36\ucb21", "\ud8ca\udd98\ud962\uded9\udb49\ude77\ud80c\udd0b\u8457\ud8d2\udcbd\udb3a\uded3\ud974\udc35\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud8d6\udc17\ud9da\uddce\ud934\udf24\udbbd\udcea\uda87\ude62\u009d\ud8d2\udd88\000\000\ud8fb\udc09\ud994\ude2a\ud93c\udee7\ud868\ude82",
        37, 17614, 66020, 7455693040409258994L, -41164L, true, true, (char) 41857, (char) 7513,
        Double.longBitsToDouble(0x3fc64821a28fa5c0L), Double.longBitsToDouble(0x3fd09b38c1a6b1f4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[B:[[63]]\012",
        Z.run(T, 1, 6, 13, 13, "\ud849\uddc4", "\uc77e\u7703\u8a36\uc8f8", "\ud89e\ude61\udb33\uddef\u1696\udb29\uddba\uda66\udfd8\ud8d2\udd4e\udb3a\uded3\uda1a\udef2\ud898\udd98\udb92\udc36\uda6f\udd8f\ud8fd\uddb7\ud8b1\udf06\uda2d\udff2\udb08\udd5c\uda72\udcf0\ud861\udccc\ud8d2\ude28\udb01\uddd4\ud866\udca0\uda59\udd13\ua53e\ud92f\udc6b\uda54\ude8b\uda9b\udcaa\ud87f\udcbe\ud802\udde4\udb94\udd71",
        43, 63674, -997778900, 7456023138949105671L, 88667L, true, false, (char) 35733, (char) 10183,
        Double.longBitsToDouble(0x3fcd855342554decL), Double.longBitsToDouble(0x3fe011ebf4b51af2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 10, 0, 13, "\000", "\000", "",
        3, -1000, 0, -7854277748134229037L, -67232L, false, false, (char) 36197, (char) 61583,
        Double.longBitsToDouble(0x3fe001b3433c2100L), Double.longBitsToDouble(0x3fb889d8a0600000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[B:[[63]]\0121=java.lang.String:f |a0=[B:[[102]]\012",
        Z.run(T, 2, 4, 14, 13, "\ucc96", "\u51b8\ua95a\u8a36\u148c", "\uda95\udcb9\ud962\uded9\u1696\ud80c\udd0b\u8457\ud8d2\udcbd\udb3a\uded3\ud974\udc35\ud86b\udd8e\ud98a\ude71\udb51\ude4e\uda2f\udcc7",
        45, 49535, 1201471524, 4337845061229835860L, -100000L, false, false, (char) 39935, (char) 160,
        Double.longBitsToDouble(0x3fd839d003942f3cL), Double.longBitsToDouble(0x3fcac19aa6ec08b8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[B:[[-20, -78, -106, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85]]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 13, 13, "\ucc96\ud876\udd7a\udb58\uddfb\udb55\udd2b", "\u148c\u0cbf", "\ud962\uded9",
        32, 65446, 33879, -5696898058484695137L, 35996L, false, true, (char) 48713, (char) 18666,
        Double.longBitsToDouble(0x3fc9564ecd3d89b4L), Double.longBitsToDouble(0x3fa2487fc3a1a9d0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:f |a0=[B:[[102]]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 14, 5, 13, "\ucc96", "\u51b8\ub1a6\u8a36\u148c", "\ud9d1\uddba",
        59, 5037, 201359446, 145508204017510L, 96580L, false, false, (char) 31210, (char) 38757,
        Double.longBitsToDouble(0x3fed7e92102490ffL), Double.longBitsToDouble(0x3fef3c7259a1416aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 0, "\ud801\ude7d\ud876\udd7a\ud854\udf4e\udb6d\udce4\ud9f4\udf67\000\udaca\ude47\ud877\udf06\uda85\udfc8\ud600\ud81a\udf03\000\uda92\udcba\ud9f7\udce0", "\u2e83\u36e9b", "\000",
        4, 23280, 709308066, 2799342661286016290L, -90385L, true, true, (char) 0, (char) 29183,
        Double.longBitsToDouble(0x3e1a711fa0000000L), Double.longBitsToDouble(0x3fc33cbbc1bc3144L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 0, "\ud801\ude7d\ud876\udd7a\udb58\udd10\ud941\udd21\ud9b8\ude67\000\uda96\uddea\ud877\udf06\uda85\udfc8\000\ud81a\udf03\000\000\ud8e3\udc70", "\u089b\uc36ab", "",
        -5, -1000, 0, 1862271133L, 56907L, false, false, (char) 64516, (char) 52494,
        Double.longBitsToDouble(0x3fd839ddb0000000L), Double.longBitsToDouble(0x3fd2a0cd50320000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 6, 0, "\uf234\ud876\udd7a\udb58\udd10", "\000\u068c\u0cbf\u18d6\000\u04cc\000\000\u2a12\u0f4c\u4000\u2ddd\u36e9\u6ba4\ud565\u00db\000\ucb8d\u708d\000", "\ud94f\ude57\000\ud814\udf36\ud965\udca8\uc983\uda44\udcc1\u652a\udb57\udd36\udbf3\udff0\ud813\ude0e\ud8fd\udf17\udb71\udc32\uda7f\udd04\ud83c\ude70",
        48, 92348, 1218439383, -9180875442219192950L, 91192L, false, false, (char) 39302, (char) 57340,
        Double.longBitsToDouble(0x3fd79ca6ba97e5f8L), Double.longBitsToDouble(0x3fd904d0a592ed6cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63]]\0121=[B:[[-2, -1, -40, -50, -35, -126, -38, 38, -33, 124, -37, -29, -34, -20, -37, 85, -35, 43, -38, -118, -36, -20]]\012",
        Z.run(T, 2, 4, 7, 6, "\ud8ce\udd82\uda26\udf7c\udbe3\udeec\udb55\udd2b\uda8a\udcec", "\ubfa2\u18d6\u689d\ud0f9\u227f\uc6f1\u75ce\u66c1\ub81a", "\ud822\udf88\ud9e0\udeb3\uda92\ude94\ud9da\udd63\udbd0\udd53\udabd\udce3\ud9be\udfce\uda91\ude07\ud83d\udd7b\udbce\udd76",
        45, 71159, -1646536079, -3136602759292944393L, -52478L, false, true, (char) 56657, (char) 2863,
        Double.longBitsToDouble(0x3fd4506d008cd0dcL), Double.longBitsToDouble(0x3fd8bd41e0f060f2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\ufffdM\ufffd\ufffd>\ufffd%# |a0=[B:[[-47, 77, -67, -27, 62, -14, 37, 35]]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 15, 13, 13, "\ud801\ude7d\udbed\udc15\ud86e\udf22\udb55\udd53\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\ubbe0\ua5ee\u0a85\ub799\uafaf\uceaf\u6850\u8c67\u6555\u07b2\u0482\u961f\u9581\u98ff\u3329\uca07\u29e5\ube91", "\udb03\udeaa\uf3a4\udbac\udfac",
        0, 54042, -1282608965, 6411468943939676371L, 57845L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fe0203be489424eL), Double.longBitsToDouble(0x3f878ed812057c40L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[B:[[1, -40, 125, -34, 118, -40, 122, -35, 88, -37, -5, -35, 85, -37, 43, -35, 26, -38, 22, -34, -4, -38, -81, -36, -103, -38, -20, -33, 119, -40, 6, -33, -123, -38, -56, -33, -54, -40, -12, -35, -34, -37, -102, -35, -106, 22, -44, -37, 15, -35, 24, -38, -47, -36, 108, -40, -21, -33, 58, -37, -45, -34,...\0121=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -14, -106, -88, -106, -13, -113, -126, -81, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -12, -121, -90, -102, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -1...\012",
        Z.run(T, 2, 9, 10, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\uda1a\ude16\udafc\udcaf\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\udbde\udd9a\u1696\udbd4\udd0f\uda18\udcd1\ud86c\udfeb\udb3a\uded3\ud974\udc35", "\ubbe0\ua5ee\u0a85\ub799\uafaf\u1af7\u683d\u8c67\u6555\u07b2\u0482\u961f\u95c2\u98ff\u3329\uca07\u29e5\ube91", "\udb03\udeaa\ud820\udda4",
        52, 75065, -378499918, -5508763660579431159L, -93529L, false, false, (char) 38784, (char) 31936,
        Double.longBitsToDouble(0x3fe64f1c62040702L), Double.longBitsToDouble(0x3fc12849d02f1db0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\0121=[B:[[63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]]\012",
        Z.run(T, 2, 4, 4, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\ud8ab\udd68\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\uc523\ua5ee\u0a85\ub799\uafaf\uceaf\u6850\u8c67\u6555\u07b2\u0482\u961f\u9581\u98ff\u3329\uca07\u29e5\ube91", "\udb03\udeaa\uf3a4\udbac\udfac",
        0, 47082, -1282608989, -2451615122725459757L, 57845L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fe0203be489424eL), Double.longBitsToDouble(0x3f878ed812057c40L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[B:[[-13, -116, -96, -121, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -12, -126, -98, -100, -13, -113, -126, -95, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -15...\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 13, 13, "\udaf2\udc07\ud876\udd7a\udb58\uddfb\udb55\udd2b\udbc9\udf9c\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35\ud86b\udd8e\ud9ab\udc81\ud858\ude9e\ud8d9\udd7c\ud81b\uddfb\ud959\udc9e\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\udae0\udfaf\ud814\udf95\ud965\udca8\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udb94\udd71\uda09\udcb1\uda7c\uddcf\udb03\udeaa\uf3a4\udbac\udfac\udb8f\udd4b\uda7a\udf5d\uda79\udc21\ud946\ude47\ud8d2\udc96\udb98\udc7d\udadb\udc34\udad5\udec1\uda0e\uddb6\udbb8\udd7a\ud94b\uddec\udb98\uddc6\ud9fb\udd31\ud9ff\udd68\udb4a\udf16\ud8f3\udc83\ud8d0\udd28\uda4c\udf2a\ud8bb\udc7e\udafd\udd6e\ud8ce\ude7d\udb69\udf8c\ud811\udeae\ud93c\udcac\ud85a\udf8d\ud9ce\udc3e\ud89c\udeb3\udaf8\udd52\udb0e\udd22\udafc\udd52\udaab\udc9e\ud979\udc13\udaf0\udd56\udac4\ude14\uaa45\u62fc\udad8\udea0\uda0a\udc5c\ud996\udd24\udab5\udc11\udb85\udca6\u799b\udb99\ude1b\uda54\ude98\udbd2\udf0c\ud9f4\udcd0\ud94a\udc68\uda08\udd85\ud80c\uddb0\ud8d3\udedc\ud8a2\udc1f\uda88\udd2a\uda99\uddf3\ud984\udeaa\ud8bf\udc29\ud9e5\ude5f\udae1\udcbf\ud817\udcff\ud949\udf26\ud830\uddb5\udad8\udf02\ufebd\ud829\udc3d\ud818\udc1b\ud952\ude12\udad7\udf06\ud9cc\udf45", "\u538a\u5d51", "\ud90e\udd4b\ud94d\ude47\ud95a\ude80\ud825\ude5b\u62bd\udb38\udffe\udbe0\uddf7\ud94a\ude38\udb8e\udcf6\ud8fe\udf44\u2936\ud96b\udf01\ud8dd\udce4\ud9b0\uddfc\udb26\udca9\uda17\udf67\udadc\udf85\uda40\udebc\ud9db\udc73\uda68\uddfc\ud833\uddcc\ud8ab\udf9d\uda06\udeff\udb3a\ude91\ud999\udcc8\ud803\ude91\ud980\udc91\ud9a3\ude8a\ud837\udfe7\udb43\ude59\udbeb\udc1c\uda77\udce6\udbfe\udf59\udafb\udf7d\ud1dd\udb81\udf00",
        -2, 98559, -364808336, 98351398402497004L, 64288L, true, false, (char) 58873, (char) 48268,
        Double.longBitsToDouble(0x3fb81e75174aded8L), Double.longBitsToDouble(0x3fe330e388b8749dL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -16, -72, -112, -88, -13, -72, -115, -78, -13, -113, -126, -95, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -15,...\0121=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -16, -72, -112, -88, -13, -72, -115, -78, -13, -113, -126, -95, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -15,...\012",
        Z.run(T, 2, 10, 10, 3, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\ud8a1\udc28\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud9f6\udda4\ud86b\udd8e\ud9ab\udc81\ud858\ude9e\ud8d9\udd7c\ud868\udf23\ud959\udc9e\udbc6\ude62\uda87\uddf0\ud996\udf29\uda8f\udea4", "\u0482\u961f\u9581\u98ff", "\ud802\udde4\udb94\udd71\udb28\udc63\uda7c\uddcf\uda05\udf51\ud82e\uddf2\ud882\udf56\uda46\udd60\uda7a\udf5d\uda79\udc21\ud946\ude47\ud8d2\udc96\udb98\udc04\udadb\udc34\udad5\udec1\uda0e\uddb6\udbb8\udd7a\ud94b\uddec\ud805\udcac\ud8ac\udf8a\ud88b\uddb4",
        52, 4001, -84234765, 7569933990830688013L, -10495L, true, true, (char) 16832, (char) 46904,
        Double.longBitsToDouble(0x3febc12df64bfe2cL), Double.longBitsToDouble(0x3fd1b6dce7321bc4L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \uc0f9\uda9f\uddc4\u49ad\udb55\udd2b\udba0\udf72\udae3\udc4a\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8cf\uddbd\udb3a\uded3\udb3c\udfba: null\0121=java.lang.IllegalStateException:java.lang.IllegalStateException: \uc0f9\uda9f\uddc4\u49ad\udb55\udd2b\udba0\udf72\udae3\udc4a\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8cf\uddbd\udb3a\uded3\udb3c\udfba: null\012",
        Z.run(T, 2, 11, 11, 15, "\uc0f9\uda9f\uddc4\u49ad\udb55\udd2b\udba0\udf72\udae3\udc4a\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8cf\uddbd\udb3a\uded3\udb3c\udfba", "\u7ade\u98c3\u36ec\ub81f\ub000\uceaf", "\uda17\udf13\uda99\udee9\ud814\udf95\ud965\udca8\ud93c\udee7\ud871\udd7a\uda9b\udcc1\ud853\udfbe\ud802\udde4\udb94\udd71\uda09\udcb1\ud88e\udcb8\udb1d\udde2\uf3a4\udbac\udfac",
        0, 47082, -1282608989, 6351174749929416915L, 57845L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fdf1827ca2999e8L), Double.longBitsToDouble(0x3f8688b4aac57c40L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=67 cap=67]\0121=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=67 cap=67]\012",
        Z.run(T, 2, 2, 2, 14, "\ubd10\uda32\udda0\udb58\uddef\udb55\udd2b\udb4e\udcdf\uda4b\udce6\uda9a\udc0a\ud877\udf06\uda85\udfc8\udaf3\ude83\ud944\udd8a\udbfc\udc95\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\u7f85\u390f\u36ec\ub81f\uafaf\ube32\u5230\u0249\u65d4\u16cb\u1ef3\u009a\u45f4\u7a6a\ub10d\u0951\u29b6\ube91", "\udafa\udc1b\ud8d0\udf0b\uda9d\udddc\ubd7c\udaa1\udd43",
        12, 51976, -67557165, -1385095323789133684L, 88932L, true, true, (char) 6619, (char) 1593,
        Double.longBitsToDouble(0x3fd78f8c81089a2aL), Double.longBitsToDouble(0x3fdc035cd8678714L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.IllegalStateException:java.lang.IllegalStateException: \ud801\ude7d\ud876\udd7a\udb01\udcf4\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\udaed\ude7c\udad9\udc7c\ud962\ude6a\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\uda52\udc3f\ud88b\udffb: null\012",
        Z.run(T, 1, 11, 13, 13, "\ud801\ude7d\ud876\udd7a\udb01\udcf4\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\udaed\ude7c\udad9\udc7c\ud962\ude6a\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\uda52\udc3f\ud88b\udffb", "\u7bb6\u98c3\uae6f\ub81f\uafaf\uceaf\u754f\u8c67\u6555", "\ud965\udca8\ud85c\ude98\uda4f\udfe0",
        27, 68485, -651109851, 7493500843098450930L, -53336L, false, true, (char) 44177, (char) 59970,
        Double.longBitsToDouble(0x3fc35271b4ae5664L), Double.longBitsToDouble(0x3fec1ae4bb3aded6L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 0, "", "\000", "",
        -5, 2586, -272269568, -4539123203091464192L, -100000L, false, false, (char) 0, (char) 102,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3ebbc3113b100000L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\ufffdF |a0=[B:[[-2, 70]]\0121=java.lang.String:\u00feF |a0=[B:[[-2, 70]]\012",
        Z.run(T, 2, 15, 14, 6, "\ud82e\ude76", "\u019a\u65e7\u1a83\uc867", "\ud8ca\uddb1\ud962\uded9\u1696\udbd4\udd0f\uda1a\udda7\ud8d2\udcbd\ud8da\udfeb\udb16\ude79\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud99f\udcfb\ud9da\ude3f\ud814\udf65\ud812\udc9e\uda87\uddc9",
        59, 68001, 1730684541, 8221513097589402603L, 29223L, false, false, (char) 11032, (char) 15854,
        Double.longBitsToDouble(0x3fde417576a20002L), Double.longBitsToDouble(0x3fc194b23c9b9e10L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 15, 14, 6, "\ud801\ude7d", "\ua0e1\u6534\u1a83\u148e", "\ud8ca\uddb1\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udabe\udef6\udb16\ude79\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud99f\udcfb\ud9da\ude3f\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\udae0\udfaf\ud814\udf95\ud965\udca8\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udb94\udd71",
        43, 68090, -102247446, -4793767964352269013L, 69806L, true, true, (char) 53270, (char) 33229,
        Double.longBitsToDouble(0x3fecafdfc8955350L), Double.longBitsToDouble(0x3fe011ebf61dc8d5L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 14, 14, 6, "\ud801\ude7d", "\ua0e1\u6534\u1a83\u148e", "\ud8ca\uddb1\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udabe\udef6\udb16\ude79\ud86b\udd8e\ud98a\ude71\udb85\udd48\udb6a\udc4e\ud9a4\udfaf\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\ud839\udd84\ud932\udc08\ud92e\ude7f\ud883\udcc7\udb91\udfd2\uda9b\udcce\ud853\udfbe\ud802\udde4\udb94\udd71",
        43, 68090, -102247446, 7456023022095796231L, -7628L, true, true, (char) 53270, (char) 33229,
        Double.longBitsToDouble(0x3fecafdfc8955350L), Double.longBitsToDouble(0x3feb1643f61dc8d5L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 2, 2, 6, "\ud801\ude7d", "\ua0e1\u6534\u1a83\u148e", "\ud8ca\uddb1\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udabe\ude68\udb16\ude79\ud8db\ude67\ud975\ude71\ud9e0\uddf4\ud8be\udce1\ud9da\uddbe\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\udb31\udef8\ud814\udfc0\ud965\udca8\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udb94\udd71",
        43, 68090, -1126049372, 7456019092200720391L, 69806L, true, true, (char) 53270, (char) 33229,
        Double.longBitsToDouble(0x3fecafdfc8955350L), Double.longBitsToDouble(0x3fe011ebf61dc8d5L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 9, 9, 6, "\ud801\ude7d", "\ua0e1\u6534\u1a83\u148e", "\ud8ca\uddb1\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udabe\udef6\udb16\ude79\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud99f\udcfb\ud9da\ude3f\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\udae0\udfaf\ud814\udf95\ud965\udca8\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udb94\udd71",
        43, 68090, -102247446, 7456023022095796231L, 69806L, true, true, (char) 53270, (char) 33229,
        Double.longBitsToDouble(0x3fecac7fc8955350L), Double.longBitsToDouble(0x3fe011ebf1fc4dd5L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=[B:[[-52, -106, -40, -101, -35, 122, -38, 68, -34, 82, -39, 36, -34, -14, -37, 54, -33, -83, -40, -25, -35, -102, -38, -103, -33, -22, -40, -116, -36, -79, 114, -65]]\0121=[B:[[-52, -106, -40, -101, -35, 122, -38, 68, -34, 82, -39, 36, -34, -14, -37, 54, -33, -83, -40, -25, -35, -102, -38, -103, -33, -22, -40, -116, -36, -79, 114, -65]]\012",
        Z.run(T, 2, 8, 8, 13, "\ucc96\ud89b\udd7a\uda44\ude52\ud924\udef2\udb36\udfad\ud8e7\udd9a\uda99\udfea\ud88c\udcb1\u72bf", "\u15a9\u768f\u8457\u993f\uc54a\ub6cc\ub5fc\u9ce5\u94ff\ua1ff\u3eb9\uce58\ub15f\ub5c3\u3497\u9499", "\uda07\ude7a",
        53, 43192, 1341486162, -8365942206935865315L, -5856L, true, true, (char) 53280, (char) 21157,
        Double.longBitsToDouble(0x3fdb858727dbd866L), Double.longBitsToDouble(0x3fc927a04afd5838L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 6, 6, 6, "\ud8f3\udf76", "\u2e02\u6568\u1a83\u148e", "\ud8ca\uddb1\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udab2\ude68\ud940\ude2e\ud90c\udc8f\ud975\ude71\ud9e0\uddf4\ud8be\udce1\ud9da\uddbe\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\udb31\udef8\ud814\udfc0\ud965\udca8\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udb94\udd71",
        43, 68090, -1126049372, 7456019092200720391L, -91370L, true, true, (char) 53270, (char) 33229,
        Double.longBitsToDouble(0x3fc2bf7f22554f38L), Double.longBitsToDouble(0x3fe011ebf61dc8d5L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=[B:[[-16, -112, -103, -67, -16, -83, -91, -70, -13, -90, -121, -69, -13, -91, -108, -85, -13, -72, -115, -78, -13, -113, -126, -95, -14, -74, -97, -84, -16, -83, -68, -122, -14, -79, -97, -120, -15, -126, -89, -76, -15, -88, -85, -103, -31, -102, -106, -12, -123, -124, -113, -14, -106, -125, -111, -15,...\012",
        Z.run(T, 1, 10, 13, 13, "\ud801\ude7d\ud876\udd7a\udb58\uddfb\udb55\udd2b\udba0\udf72\udafc\udca1\uda99\udfec\ud877\udf06\uda85\udfc8\ud8ca\uddf4\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udb3a\uded3\ud974\udc35", "\u7ade\u98c3\u36ec\ub81f\uafaf\uceaf\u6850\u8c67\ub739\u3073\u0482\u961f\u9581\u98ff\u3329\uca07\u29e5\ube91", "\udb03\udeaa\uf3a4\udbac\udfac",
        0, 47082, -1282608989, 6411468943939676371L, 57845L, false, false, (char) 14067, (char) 3680,
        Double.longBitsToDouble(0x3fe0203be489424eL), Double.longBitsToDouble(0x3f878ed812057c40L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 15, 15, 6, "\ud801\ude7d", "\ua0e1\u8c05\u1328\u148e\u9ce9\uc915\u1747\u191b\u7066\uc6f1\u99ab\uc9c8\ubd21\u84cc\u28fc\ua9cf\u430e\ud322\u36ec", "\uda87\uddf0\ud996\udf29\uda8f\udea4",
        36, 88925, 295541855, -2578940780666238677L, -33980L, true, true, (char) 32051, (char) 26815,
        Double.longBitsToDouble(0x3fcd5d7d15bfe748L), Double.longBitsToDouble(0x3f7d9de7e12a9380L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 6, "\ud801\ude7d", "\ub13b\u6534\u65db\u8c42", "\ud8ca\uddb1\ud962\uded9\u1696\udbd4\udd0f\uda18\udcd1\ud8d2\udcbd\udabe\udef6\udb16\ude79\ud86b\udd8e\ud98a\ude71\ud9e0\uddf4\ud99f\udcfb\ud9da\ude3f\ud959\udd24\uda1a\uddb5\uda87\uddf0\ud996\udf29\uda8f\udea4\udbce\udd76\udae0\udfaf\ud814\udf95\ud965\udca8\ud93c\udee7\uda54\ude8b\uda9b\udcaa\ud853\udfbe\ud802\udde4\udbb9\udf26",
        43, 68090, -102247446, 7456023022095796231L, 69806L, true, true, (char) 53270, (char) 64663,
        Double.longBitsToDouble(0x3fd2115b5069ed96L), Double.longBitsToDouble(0x3fc2e7afd419cb14L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.StringUtils|equals|java.lang.CharSequence,java.lang.CharSequence|static",
    "M|org.apache.commons.codec.binary.StringUtils|getByteBuffer|java.lang.String,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|getByteBufferUtf8|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytes|java.lang.String,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesIso8859_1|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUnchecked|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUsAscii|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Be|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf16Le|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|getBytesUtf8|java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|newIllegalStateException|java.lang.String,java.io.UnsupportedEncodingException|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.nio.charset.Charset|static",
    "M|org.apache.commons.codec.binary.StringUtils|newString|[B,java.lang.String|static",
    "M|org.apache.commons.codec.binary.StringUtils|newStringIso8859_1|[B|static",
    "M|org.apache.commons.codec.binary.StringUtils|newStringUsAscii|[B|static",
    "M|org.apache.commons.codec.binary.StringUtils|equals|java.lang.CharSequence,java.lang.CharSequence|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
