package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class BaseNCodecInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u6f38", "\udac7\udd25\udbdd\udd7d\ud94b\udf89\ud868\udfb8\uda4a\ude62\udb2d\udd4d",
        2, 81161, 69934581, -4492484230088683541L, 89767L, true, true, (char) 22184, (char) 25865,
        Double.longBitsToDouble(0x3fc1b7c96a267cd0L), Double.longBitsToDouble(0x3fe651a68ad38fbcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u6f38", "\udac7\udd25\udbdd\udd7d\ud94b\udf89\ud868\udfd0\uda4a\ude62\udb2d\udd4d",
        2, 81161, 287186421, -4492484231447638037L, 89767L, true, true, (char) 22184, (char) 25865,
        Double.longBitsToDouble(0x3fc1b7c966267cd0L), Double.longBitsToDouble(0x3fe651a63ad38fbcL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 5, "\ud940\udfba\u008c\ud805\udc02", "\u6f38", "\000\udbb9\udcfb\udac3\udfc5\ud8c6\udf0e\ud829\udeb4\udb2d\udd4d",
        2, 81161, 2825717, 0L, -87712L, false, false, (char) 0, (char) 30091,
        Double.longBitsToDouble(0x3e323ed000000000L), Double.longBitsToDouble(0x3fc1b7c96a267cd0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u6f38", "\udac7\udd25\udbdd\udd7d\ud94b\udf89\ud868\udfb8\uda4a\ude62\udb2d\udd4d",
        2, 81161, 69934581, -4492484230088683541L, 33594L, true, false, (char) 57048, (char) 53693,
        Double.longBitsToDouble(0x3fe651a68ad38fbcL), Double.longBitsToDouble(0x3feca7b0751824efL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\ud940\udfba\ud921\udd44", "\uc6cd", "\ud982\udc3b\udac7\udd25\udbdd\udd7d\ud94b\udf89\u7754\uda6f\udeef\udb2d\udd4d\udb6d\uddce\udbbb\udf09\udb85\ude33\ud986\uddb8\ud826\udd7b\uda0b\ude8b\udbf8\udeea\ud978\udefb\udaec\udc4a\udad5\udc11\ud85f\udfa8\udae3\ude67\uda9e\uded8\uda6b\ude19\ud93a\udf6d\uda46\udc89\ud834\udc1b\udb23\udd43\udba6\udd1f\ud991\udfc9\ud970\udc16\udbbe\udd16\uda1d\udead\uda70\udc43\udad3\ude23\udb5e\udd00\uda34\udfd8\uda16\udcab\ud84d\udd43\udba2\udc2b\udb48\udeef\ud9f5\udd3d\u23b1\uda12\udf89\udbce\udc7e\udac7\udcde",
        34, 89625, 1139911401, 7131824885284217467L, 71282L, false, false, (char) 7754, (char) 46044,
        Double.longBitsToDouble(0x3feaeb0ba65c66aaL), Double.longBitsToDouble(0x3fe5de14ab18ee85L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 5, "\ud940\udfba\ud921\udd44\udb3b\udca7\u60b1\ud926\udccb\uda3b\uddcd\ud961\udcee\ud8c0\udc3a\ud8a6\udf96\udb96\uddd1\ud96d\udd45\udb0b\udc7a\ud84e\udc60\ud8a5\uddd6\ud859\ude00\ud893\udebe\uda6d\udc31\udadf\udc2e\udb12\udfd2\udbf0\ude7e\ud82f\ude65\u754e\ud918\udd17\uda6d\udf89\udbb8\ude7f\uda13\udf27\ud814\udcee\u868b\udbb0\udf8d\uda44\udf7f\udbbd\udf4a\udbd5\udfb3\ud820\udf9e\ud9e7\udef5\ud938\ude16", "\u8c89\u2337\u6710\u6231\u2c36\u03c3", "\udadd\udfc4\ud9cc\ude22\udb10\udc81\ud9da\udf7e\ua99a\udad2\udc84\udaf6\ude1b\ud47d",
        45, 80715, 1732534811, 3560971626670979907L, 28200L, false, false, (char) 59021, (char) 16907,
        Double.longBitsToDouble(0x3fd9191c1122aab8L), Double.longBitsToDouble(0x3fe8a5167098fc36L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 5, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u6f38", "\udac7\udd25\udbdd\udd7d\ud94b\udf89\ud868\udfb8\uda4a\ude62\udb2d\udd4d",
        2, 81161, 69934581, -4492484230088683541L, 89767L, true, true, (char) 22184, (char) 25865,
        Double.longBitsToDouble(0x3fc1b7c96a267cd0L), Double.longBitsToDouble(0x3fe651a68ad38fbcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u6f38\u4f17\uafae\uad57\u7cbf\u8315\ud3a7\u1a64\u84de\u1337\u6b86\ua2e5\u6b80", "\udbf8\udeea\ud978\udefb",
        24, 15859, -624817702, -4734538543831691891L, -52600L, true, true, (char) 23773, (char) 65382,
        Double.longBitsToDouble(0x3fc92005836048dcL), Double.longBitsToDouble(0x3fd106ab0a319cf2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 4, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\ud7cf", "\udac7\udd25\udbdd\udd7d",
        27, 67873, -357420124, 550810330108205794L, 66411L, true, true, (char) 53650, (char) 42907,
        Double.longBitsToDouble(0x3faac878a1f2e000L), Double.longBitsToDouble(0x3fe5cc34d78b5e81L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 6, "\ud940\udfba\ud921\udd44\ud840\udf1a\ud856\ude0b\udb31\udeea\uda43\udfcd\ud961\udcee\ud982\udc3b\udac7\udd25\udbdd\udd7d\ud94b\udf89\uda90\udfcc\ud869\udc58\udb2d\udd4d\udb6d\uddce\udbbb\udf09\udb85\ude33\ud986\uddb8\ud826\udd7b\uda0b\ude8b\udbf8\udeea\ud978\udefb\udaec\udc4a\udad5\udc11\ud85f\udfa8", "\u5922\u25bc\u2429\uacd0\u8a87\u53b4\ubfff\u029e\ua2aa", "\uda7e\udfb7\udbad\udd67",
        20, 31273, -1460224392, 1837867214253010859L, -61278L, false, false, (char) 19838, (char) 18321,
        Double.longBitsToDouble(0x3fc7897c8bbba2b0L), Double.longBitsToDouble(0x3fd91a7902246c20L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 4, "\ud98a\udffa\udaf1\udd0b\ud840\ude4a", "\u1817", "\ud8a5\uded3\udbdd\udd7d",
        27, 42700, -357420124, 7612454545942583920L, -69013L, true, true, (char) 9088, (char) 47545,
        Double.longBitsToDouble(0x3fe7b948921f2e00L), Double.longBitsToDouble(0x3fe5cc36e78b5e81L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u348e", "",
        38, 6930, -66320443, -4042110043802716L, -42133L, true, true, (char) 53650, (char) 42907,
        Double.longBitsToDouble(0x3ece287cb8000000L), Double.longBitsToDouble(0x3fe5cc36e78b5e81L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 4, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u6f38", "\ud89e\udda0",
        49, 35557, -941127, -1535107741739852012L, 70178L, true, true, (char) 33168, (char) 53650,
        Double.longBitsToDouble(0x3fd177885aff21e2L), Double.longBitsToDouble(0x3fe465b532b986dcL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 1, "\ud959\udd4e\ud921\udd44\ud840\udf1a\ud856\ude0b\ud81e\udd48\uda49\uddc9\ud961\udcee\ud982\udc3b\udac7\udd25\udbdd\udd7d\udb0b\udc69\ud868\udfb8\uda4a\ude62\udb2d\udd4d\udb6d\uddce\ud9d9\udd34\udb85\ude33\uda8d\udc9b\ud826\udced\ud822\udcf6\udbd9\uddfe\ud803\ude71\ud8f8\udc33\ud930\udecc\ud85f\udfa8\udae3\ude67\uda9e\uded8\udb47\udda5\ud93b\udc2c\ud9c9\udf4b\uda26\uddb8\ud853\udf80\ud96a\ude76\ud91f\ude7e\udb36\udf1d\udbba\udcdf\uda68\udd2b\ud9c8\udf4e\ud980\udd3a", "\u81e9\u59f0\u0e2a\u1ad0\ub3d6\u1513\uaefa\uab09\u2294\u6c25\uab11\u1700\u26b4\ub3de\u9dd1", "\ud923\ude80\udbf3\udd98\ud8ec\udd3d\uda68\udcb7\ud9ad\udf43\ud834\ude15\udb65\uded3\uda80\ude6b\u8d4f\udaef\udfd3\udaf7\ude6d\u709c",
        8, 33028, -1292052876, 6781965607928713671L, -80816L, false, true, (char) 56146, (char) 93,
        Double.longBitsToDouble(0x3fcc17f8cc50e1c0L), Double.longBitsToDouble(0x3fee0f581930ea1fL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 6, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u51e1", "\udac7\udc7f\udbdd\udd7d\ud94b\udf89\ud868\udfb8\uda72\udf62\ud9e0\udd87\udba3\udefd",
        51, 41581, -1045987995, 1910951117017126561L, -99457L, true, false, (char) 30220, (char) 22184,
        Double.longBitsToDouble(0x3fe23ed6108dbe4bL), Double.longBitsToDouble(0x3fe44cf9a2ca34d1L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 0, "\000\ube8c\000", "\000", "",
        -5, -1000, -66320640, -4042110043802716L, -42133L, false, false, (char) 53415, (char) 6789,
        Double.longBitsToDouble(0x3faa800021f2e000L), Double.longBitsToDouble(0x3fe5cc36e78b5e81L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 5, "\udbb6\udc34\ud921\udd44\ud861\udd2a", "\u6f38\u4f17", "\udbdd\udd7d\ud94b\udf89\udb31\udf7b\uda88\udec8\ud850\uddf5\udb6d\uddce",
        51, 41581, -1045987995, 1910951117017156887L, 37099L, false, true, (char) 16251, (char) 57082,
        Double.longBitsToDouble(0x3fe44cf9a2537fd1L), Double.longBitsToDouble(0x3fe69c7b46eeed3bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 5, 5, 6, "\ud940\udfba\udaf7\udd8f\udbfd\udfea\ud856\uddf4\uda8a\udfcf\u763a\uda09\udfc2\ud800\udce0\udb3e\udf9f\udaab\ude26\ud970\ude9c\uda99\uddf1\ud953\ude24\ud92d\udf00\u4beb\udbe6\udc5a\ud92b\ude99", "\ucd3d\u0d88\u0d47\ua4e2", "\ud800\ude85\udbf9\udec8\udbcf\udf1a",
        12, 23570, -418528395, -2600462217636448690L, -13848L, true, true, (char) 17337, (char) 48955,
        Double.longBitsToDouble(0x3fd7a7a5e463df8aL), Double.longBitsToDouble(0x3fbf4ca33fa752d8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 0, "\000\000\000", "", "",
        -5, 29464, 0, -941127L, 70183L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd171a0006b21e2L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=java.lang.Long:0 |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 5, 1, 0, "\u6908\ud8f1\udeb8\030", "\ucc05", "\000\000\ud949\udfc4\ud868\udfb8\ud9e2\udfae\000",
        -5, 81161, 67109109, 0L, -100000L, true, false, (char) 41365, (char) 268,
        Double.longBitsToDouble(0x3e01c00000000000L), Double.longBitsToDouble(0x3e344cf9a0000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 6, 5, "\ud940\udfba\ud921\udd44\udae3\ude6a", "\u6f38", "\udac7\udd25\ud8a8\udd84\udad5\udfc4\ud93a\udf9e\ud8e5\udf75\udb2d\uddc1",
        -1, 22826, 1760894382, 4987932486182506457L, 89767L, true, true, (char) 22184, (char) 25865,
        Double.longBitsToDouble(0x3fc1b7c96e267cd0L), Double.longBitsToDouble(0x3fe28ce90161995cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 6, 0, "\udaf6\udef7", "\u1245\u9278\u0213\u4f17\uafae\uad57\u7cbf\u8315\ud3a7", "\udb6d\uddce",
        51, 85761, -1045987995, 1910951117017156887L, 36971L, false, true, (char) 25865, (char) 57048,
        Double.longBitsToDouble(0x3fe44cf9a1bfafd1L), Double.longBitsToDouble(0x3fe69b4d2a5bfc82L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 6, 5, "\ud940\udfba\ud8d8\ude00\ud962\udd8d\ud856\uddff\udb31\udf82\uda43\udfcd", "\uad57\u7cbf\u8315", "\udb8b\udccb\uda92\udc22\ud90d\udf14\udad3\udc49\uda87\udf73\udbbc\udf18\uda0b\ude8b\udbf8\udeea\ud978\udefb\udaa7\ude09\udad5\udc11\ud85f\udfa8\udae3\ude67\uda9e\uded8\udb41\udcbc\ud93b\udc2c\udbc0\udde5\udbd8\udc54\ud9ec\udfd5\ud888\udfda\udb58\udc90\ud98a\udc27\u8de0\ud9f1\udf43\ubca1\uda09\udfbe\udac1\udd52\ud9c3\udf7f\u289e\ud997\udf2f\udb6b\udff7\ud81e\udc8b\ud934\ude4d\ud968\ude65\udb60\udfe3\udaec\udf63\uda56\udf23\uda17\udeb4\ud93c\udfaa\ud8a5\udd42\udae4\udcd3",
        20, 62249, -1073247804, -7659766397625632225L, 94970L, true, false, (char) 5041, (char) 12772,
        Double.longBitsToDouble(0x3f95db13f1b5a320L), Double.longBitsToDouble(0x3fec69d54449a539L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 0, "\udb12\udd44\ud98c\udd0e\udba5\udd76", "\u5b67\u4f17\uafae\uad57\u7cbf\u8315\ub07a\u1a29\u5177\u22c4\u6b86", "\ud838\udd8d\uda0b\ude8b\udbf8\udeea\ud978\udefb\udaec\udc4a\udaaa\udf5c\ud85f\udfa8\ud813\udfff",
        7, 51193, -1883448630, 228384865375479082L, 44698L, false, true, (char) 54907, (char) 57513,
        Double.longBitsToDouble(0x3fee812543cddf19L), Double.longBitsToDouble(0x3fc8ab1a2597b280L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 5, 5, "\000\000\ud83c\udffe", "\u2eb0", "\u77b2",
        -5, 35360, -941127, -1535107741739852012L, -8096L, true, true, (char) 33168, (char) 49575,
        Double.longBitsToDouble(0x3fd171a8506b21e2L), Double.longBitsToDouble(0x3fe0f97002b986dcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u0794\u1e6f\u2785\uc359\u7cbf\u8315\ud3a7\u1a64\u674a\ud409\u6b86\u7087\u6b1c\u5f59\u0977\u2eba\u528b\ub2ba\u8a92\u3db6", "\udb47\udda5\ud93b\udc2c\uda93\udccf\udb9a\udc04\u67f6\udaef\ude68\udb2e\udcd1\udb43\udead\udafc\ude4f",
        55, 28908, 239003359, 1955090863564215119L, 18527L, true, true, (char) 17947, (char) 13053,
        Double.longBitsToDouble(0x3fe0617187101433L), Double.longBitsToDouble(0x3fd00b8477594554L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a\ud856\ude0b\udb31\udeea\uda43\udfcd\ud961\udcee\ud982\udc3b\udac7\udd25\udbdd\udd7d\ud94b\udf89\ud868\udfb8\uda4b\udf24\udb2d\udd4d\udb6d\uddce\udbbb\udf09\udb85\ude33\ud986\uddb8\ud826\udd7b\uda0b\ude8b\udbf8\udeea\ud978\udefb\udaec\udc4a\udad5\udc11\ud85f\udfa8\udae3\ude67\udade\udff8\udb47\ude05\ud93b\udc2c\udacf\udd8d", "\u91a2", "\ud9b7\udf93\ud852\ude13\ud93c\udeef\ud9ed\udda0\uda78\udfc4\udb21\ude76\ud956\udd20\udadc\udfdf\ud88a\udc13\ud857\udfef\ud8ee\udf59\ud9e8\udfd5\ud86d\ude97\udbb9\udf0d\ua77e\uda8f\udd31\ud907\udc64\ud842\ude4b\ud943\udc03\uda64\udce6\ud9b4\udef1\ud973\udc6d\udbef\ude45\u287d\ud966\ude44\uda26\ude97\udb80\udfef\ud853\ude16\uda0f\ude80\udb6f\udd7f\udab2\udcee\u9701\udb4d\udd6f\udbed\udf67",
        -3, 67497, 1995238722, -3436931905620963179L, 15071L, true, true, (char) 37283, (char) 5792,
        Double.longBitsToDouble(0x3fe69d77e87738a5L), Double.longBitsToDouble(0x3fe6f8d5b78980a5L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 1, "\u9baf", "\u1245\uc6cd\u6f38\u4f17\u8dca\u7f92\ua86c\u34dd\u38f0", "\udb3c\udf06\uda70\udfb8\ud9f0\ude08",
        40, 77618, -1873179369, 3314702327903683103L, -69863L, true, false, (char) 23723, (char) 3888,
        Double.longBitsToDouble(0x3fe69c7de5a39adfL), Double.longBitsToDouble(0x3fef941750874e87L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "", "", "\000",
        22, 65757, 1302684584, 6666303481245307010L, 54695L, false, true, (char) 51654, (char) 33823,
        Double.longBitsToDouble(0x3fe9cd8005f5fce1L), Double.longBitsToDouble(0x3fd65042bfd7834eL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 4, 5, "\ud845\udf7d\u0ac3\ud840\udf1a", "\u2d72", "\udac7\udd25\udbdd\udd7d\ud94b\udf89\ud868\udfb8\uda4a\ude62\udb2d\udd4d",
        2, 81161, 1160452451, -4539035245809954837L, 89767L, true, true, (char) 22184, (char) 25865,
        Double.longBitsToDouble(0x3fc1b7c970b67cd0L), Double.longBitsToDouble(0x3fef73be881b31aaL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\uda7a\udc77\ud860\udd6c\uda9e\udc06", "\u3052\u4639", "\ud8dc\ude1e\ud8bf\udc4a\ud88e\udca4\udb2d\udd14\udb2d\udd62\ud8d8\udf44\ud95d\uddfa\udb85\udd49\ud986\uddb8\ud87d\udf27\uda81\uddb8\udbf8\udeea\ud87b\udfdc\udaeb\udfd8",
        34, 87115, -1102345657, -6974914131672354167L, 79148L, false, false, (char) 30804, (char) 10858,
        Double.longBitsToDouble(0x3fe1d494332acd46L), Double.longBitsToDouble(0x3fc224fecaec5d28L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 4, 5, "\ud89b\udfe9\ud921\udd44\ud837\udc1a", "\u6f38\ud516\ua1af", "\ud94b\udf89\ud868\udfb8",
        51, 63692, 179772027, -224785011811082758L, 92533L, true, true, (char) 49446, (char) 60871,
        Double.longBitsToDouble(0x3fbf3c3b5c71fa60L), Double.longBitsToDouble(0x3fc7a5d525e85378L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 4, 5, "\ud808\uddbe\u1c3e\ud840\udf1a", "\u8de1", "\udbd4\udd8c\ud9c5\uddb9\ud827\udf73\ud873\udc57\udada\udf8e\ud801\udc08",
        54, 14037, 1819777020, -8181805445066078370L, -45525L, true, false, (char) 22184, (char) 25865,
        Double.longBitsToDouble(0x3fc1b7c96bca7cd0L), Double.longBitsToDouble(0x3fe93635cfee1f5dL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 4, "\ud939\udf6c\udb1c\uddbe\udb1d\udd25\ud8f3\udc68\uda12\uddde\uda44\udca6", "\u35d4\ucbec\u463e\u7b48\u37fe\ua449\ubd5c\u6d29", "\udbd5\udcb4",
        54, 68164, -2032389602, -6477764262616100451L, -69863L, true, false, (char) 11869, (char) 39358,
        Double.longBitsToDouble(0x3fe414ac5f239922L), Double.longBitsToDouble(0x3fb8924817f7c9c8L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 2, 2, 5, "\ud940\udfba\u008c\ud805\udc02", "\u6f38", "\000\udbb9\udcfb\udac3\udfc5\ud8c6\udf0e\ud829\udeb4\udb2d\udd4d",
        2, 81161, 2825717, 0L, -87712L, false, false, (char) 0, (char) 62090,
        Double.longBitsToDouble(0x3e323ed000000000L), Double.longBitsToDouble(0x3fc1b7c96a267cd0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 1, 5, 6, 0, "\ud940\udfba\u008c\ud805\udc02", "\u6f38", "\000\udbb9\udcfb\udae2\udd15\udbb1\udf75\ud962\udd49\ud982\udca2",
        57, 24521, 2843735, 0L, -87712L, false, false, (char) 0, (char) 30091,
        Double.longBitsToDouble(0x3e323ed000000000L), Double.longBitsToDouble(0x3fd8dbe4b5128940L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 4, 4, "\ud940\udfba\u008c\udace\udd1b\ud83f\ude4a\udbcf\udd58\uda43\udfcd", "\uc3f3\uc43c\u37d3\u541e\uc5ec\u10bb\u9f9d\u7b0b\u1628", "",
        -5, 11288, 1436794112, 6810872706074941323L, -69863L, true, false, (char) 53890, (char) 34457,
        Double.longBitsToDouble(0x3feec84c6e54b7f6L), Double.longBitsToDouble(0x3fe49cf2da0267a1L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 3, 5, "\ud947\ude8f", "\u802b\u8225\u8b12\u0433", "\u91b2",
        31, -224, -369062133, -1951145309657163264L, -100000L, true, true, (char) 4879, (char) 26898,
        Double.longBitsToDouble(0x3f34c023b1f08000L), Double.longBitsToDouble(0x3fdada99548f9a3eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=java.lang.Long:0 |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 1, 1, 5, "\ud940\udfba\u008c\ud805\udc02", "\u6f38", "t\udbb9\udcfb\udac3\udfc5\ud8c6\udf0e\ud829\udeb4\udb2d\udd4d",
        2, 81161, 2825717, 0L, -87712L, false, false, (char) 0, (char) 30091,
        Double.longBitsToDouble(0x3fe16000050bb95eL), Double.longBitsToDouble(0x3fc1b6a10a267cd0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 5, "\ud971\udc98\u00c9\ud805\udc02", "\u6f38", "\000\udbb9\udcfb\udac3\udfc5\ud8c6\udf0e\ud829\udeb4\udb2d\udd4d",
        2, 81161, 2825717, 0L, -87712L, false, false, (char) 0, (char) 30091,
        Double.longBitsToDouble(0x3e323ed000000000L), Double.longBitsToDouble(0x3fc1b7c96a267cd0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 4, 1, "\ud940\udfba\u008c\ud9e5\ude12", "\u9208\u4f1d\u63a8\000\uc43c\u6056\u327b\u6d12\ua449\ud482", "\000\000\ud824\uddf6",
        44, -1000, 1577058304, 25885130358784L, -97642L, false, true, (char) 46625, (char) 11749,
        Double.longBitsToDouble(0x3fdba49148296880L), Double.longBitsToDouble(0x3fe8587397d8f756L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 4, "\udb79\udc48", "\u0cd2\u16fb", "\udbb4\udc9c\u625d\ud8db\udea7\udb27\udf9f\ud8c6\udf0e\ud829\udeb4\udb91\udde0\ud8b3\udff0\udb96\udfd8\uda0d\uddf7\000\000\000\ud89d\udf78\026\ud857\udd8a",
        18, 60390, -1102345657, -2357317137999470132L, 54856L, false, true, (char) 34875, (char) 27468,
        Double.longBitsToDouble(0x3fe72ef5eee7e715L), Double.longBitsToDouble(0x3fd7e52f2d4cf32cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 2, "\ud973\udf98\ud828\udef2\ud8e1\udcf0\ud880\udf2b\udb31\udeea\uda43\udfcd\udbc3\ude47\udbfc\udd02\ud87f\ude2a\ud8f6\udda9\udb8d\udfa2\udb89\udd47\uda61\udd39\udb2d\uddf7\ud849\udf9b\uda0a\udfa9\udb29\udd14\u73d9\u1265\ud844\udd01\u3000\udadc\udda3\udaba\udfc3\udb7e\udffd\udac5\uddc2\udaf3\ude6f\ud85f\udff8\uda1a\udf9f\udb28\udfd4\uda8a\uddb7\ud89e\udf9f\ud8a7\ude50\ua6b9\ud979\udecd\udaa3\udd71\udb9c\udf9b\ud8a1\udc6c\ud92c\ude45\udaf3\udebd\ud818\udcc9\ud8d5\udc86\ud94e\ude5a\ud87c\udf4d", "\u82a4\u82b2\u8d54\u4cf6\ubfac\u382b\u7b69\u0409\u239d\u45b0\u10aa\u4c95\u952f\u2f01\u38b7\u8e1b", "\uda9b\udd39\udb5e\udd97\uda7c\udcf4\ud9dc\udf15\ud987\udc80\ud837\ude98\ud937\udedf\ud95d\udf01\ud9b5\ude62\ud92d\udc79\uda4a\ude7c\ud8bc\udee5\udaec\udf4a\ud89f\udeb4\ud86b\udea4\ud9d0\udece\udba7\udd37\uda4f\udca6\udabb\udcb0\udbf9\uded6\udbd3\udcaf\udb95\udd1a\uda87\udc53\uda47\ude54\ud826\ude2a\udb41\udfae\ud953\udf87\udac6\udf1a\ud8fe\ude83\uda8c\uddeb\ud97c\udc93",
        7, 70255, -857264615, -7600626337862260451L, -56619L, false, true, (char) 24268, (char) 35388,
        Double.longBitsToDouble(0x3fca6b001de76a90L), Double.longBitsToDouble(0x3feed17e07f6d1e1L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 1, 5, 0, 0, "\ud940\udfba\u008c\000", "\u6f38", "\000\udbb9\udcfb\udac3\udfc5\ud8c6\udf0e\ud829\udeb4\udb2d\udd4d",
        2, 55136, 0, 0L, -87712L, false, false, (char) 0, (char) 30091,
        Double.longBitsToDouble(0x3e323ed000000000L), Double.longBitsToDouble(0x3fc1b7c96a267cd0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 5, "\ud94c\udcc0\ud85d\udfad\udb2f\udc8a\u60b1\udac7\udf93\uda43\udf67\ud961\udcee\ud8c0\udc3a\ud8a6\udf96\udb96\uddd1\udb82\udfb8\udb0b\udc6f\ud84e\udc60\ud8a5\uddd6\ud9a3\udf66\ud893\udebe\uda6d\udc31\udadf\udc2e\udb12\udfd2\u20e1\ud82f\ude65\u754e\ud918\udd17\uda6d\udf89\ud875\udebf\uda13\udf27\ud814\udcee\u868b\udbb0\udf8d\uda44\udf7f\udbbd\udf4a\udbd5\udfb3\uda50\udf96\ud8e3\ude6e\ud882\udf30", "\u8c89\u2337\u6710\u6231\u2c36\u03c3\uc5ad\u831d\u7bd8\u34f2\u93e1\u3704\u0841\u6eb1\u701c\u2b2f\ua57d\u8dc7\u6fb0\u2766\ubc1c\u32cd\u7c1a\uc101\u4f67\u8292\u96bc\uca1c\u1697\u92e8\ud587\u321e\ucdd9\ubb5b\u8885\u5d5e\ua189\u7d9e", "\ud9a9\udf2d\udbe6\udcec\udb15\udfcb\ud8e9\udf0c\ud914\udcd3\uda43\ude89\ud9f4\udecf\ud8d7\ude71\ud8d6\udd5b\udad1\udce8\ud93a\udc54",
        13, 25941, -1810572056, 7508379726106316835L, 24270L, true, true, (char) 27477, (char) 30008,
        Double.longBitsToDouble(0x3fdb10673606a724L), Double.longBitsToDouble(0x3fd4d4207b15da48L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 5, "\udbb6\udc34\ud921\udd44\ud878\udc95", "\u6f38\u4f17\uafae\uad57\u7cbf\u8315\u18b2\u6a45\u1f5d\ud482\ua80b\u91f9\ub9c8\u5f59\u0977\u7aca\u7610\ub298\u8a92\u6fc9\u2601\u9dd3\u5206\ucce0\u1695\u7ade\ub269\ub33a\u7795\u7c72\u8532\u0142\ua924\u6867\u40d4\u7661\u3338\u3136\u1538\u27fa\ud1ae\u4462\u3212\u2d10\u3b6c\ua6d3\u93a6\u4f0d\u8444\u2db8\u8b08\u7396\u6ecc\ub513\u9c35\ub679\u7315\u05a0\u74f3\u2dc8\u2505\u775a\u1b25\u1cb0\u0cc1\ud1f8\uafcb\u3977\u0521\ub54f\u71a1\u0b24\u5b87\ub53d\u4706\u213a\u33a6\ua35a\u97b0\ud286\ud2ef\u2790\u08e1\u145a\u2e59\u547a\u890b\u443d\u458f\u61a0\u6a41\u6301\u517d\u65a1\u79e0\u4b6c\u62e6\u7360\u12df\uaf51\u699c\u45a2\uab08\u6a16\u7731\ub602\u1676\u3bfd\u7a71\u2afd\u9bf2\u5f46\u7790\ua9c8\ua695\u7229\u9640\uc135\ub48a\u7099\u8c04\uaf5b\u64bc\u428e\u9c46\u92c1\u601b\u262e\u92b7\u79ff\u49bb", "\ud8c8\ude87\ud9ea\udce1\uda1c\udcb8\udbd3\udee5\ud8c2\udc4f\ud8e5\udfe2\udadb\uddcf\ud9d7\udc9c\udb01\udc18\udab5\udf9f\ud86f\udef8",
        6, -732, 505667131, 5581977964119454528L, 89766L, false, false, (char) 27382, (char) 26004,
        Double.longBitsToDouble(0x3fef76f7120c9317L), Double.longBitsToDouble(0x3fe0ff24218323c1L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 5, "\u6908\udab2\udfa3\030", "\ucc05", "k\000\uda63\udef8\ud868\udf55\ud9e2\udfae\uda60\udef0\ud857\uddcf",
        47, 65314, 48202, 194L, -99457L, true, false, (char) 268, (char) 0,
        Double.longBitsToDouble(0x3fb1c00000000000L), Double.longBitsToDouble(0x3fe44cf9a1c01bc7L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 6, 5, "\ud940\udfba\ud921\udd44\ud840\udf1a", "\u6f38", "\udac7\udd25\ud912\ude71\ud94b\udf89\ud868\udfb8\ud8d7\udca8\udb05\uddc1",
        2, 81161, 69934581, -4492484230088683541L, 89767L, true, true, (char) 22184, (char) 25865,
        Double.longBitsToDouble(0x3fc1b7c96a267cd0L), Double.longBitsToDouble(0x3fb0c5b461e47558L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[16, -118, 118, 22, 34, -11, 38, -60]] |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 4, 5, 2, "\ud940\udfba\udaa6\ude46\ud852\udc25\ud856\uddf4\uda8a\udfcf\ud857\udd28\uda09\udfc2\udb37\uddfc\uda95\uded4\udaab\ude26\ud970\ude9c\uda99\uddf1\udb8b\udda0\ud92d\udf00\u4beb\udbe6\udc5a\ud92b\ude99", "\ucd3d\u0d88\u0d47\u2fe8", "\ud800\ude85\udbf9\udec8",
        3, 0, 1891653570, -1797565769577837212L, -85172L, false, false, (char) 49345, (char) 17337,
        Double.longBitsToDouble(0x3fd8b91022f4f4bcL), Double.longBitsToDouble(0x3fe18f7e287d328cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[16, -118, 118, 22, 73, 55, -85, 15]] |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 2, "\ud940\udfba\udaa6\ude46\ud279\uda67\udddb\uda3f\udd23\ud83e\ude22\uda09\udfc2\udb37\uddfc\uda95\uded4\udaab\ude26\ud970\ude9c\uda99\uddf1\udb8b\udda0\ud92d\udf00\u4beb\u75d6\ud92b\udf7b", "\ucd3d\u0d88\u0d47\u2fe8", "\ud800\ude85\udbf9\udec8",
        3, 0, 1891653570, 6272884762670091703L, -85172L, false, false, (char) 49345, (char) 17337,
        Double.longBitsToDouble(0x3fd8b91022f4f4bcL), Double.longBitsToDouble(0x3fe18f7e287d328cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[16, -118, 118, 22, 34, -11, 38, -60]] |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=java.lang.Integer:0 |a0=[B:[[16, -118, 118, 22, 34, -11, 38, -60]] |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud940\udfba\udaa6\ude46\ud852\udc25\ud856\uddf4\uda8a\udfcf\ud854\udf28\ud907\udfc1\udbc0\udcc0\udac2\udff1\uda5a\udef7\udb21\uded3\ud890\ude2d\udb8b\udda0\ud89f\uddb8\ud891\udd94\ud8ff\uddf9\ud92b\ude99", "\ub833\u0df0\u0d47\u2fe8", "\ud800\ude85\udbf9\udec8",
        3, 0, 1891653570, -1797565767933670044L, -32981L, true, false, (char) 40983, (char) 33954,
        Double.longBitsToDouble(0x3fd8b91022f4f4bcL), Double.longBitsToDouble(0x3fe18f7e287d328cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|available||new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|skip|long|new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|markSupported||new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|read||new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|read|[B,int,int|new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "C|org.apache.commons.codec.binary.BaseNCodecInputStream|<init>|java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|available||new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|skip|long|new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
