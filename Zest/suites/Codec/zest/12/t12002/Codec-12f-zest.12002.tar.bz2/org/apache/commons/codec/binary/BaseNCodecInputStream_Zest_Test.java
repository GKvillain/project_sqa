package org.apache.commons.codec.binary;
import org.junit.Test;
import static org.junit.Assert.*;
public class BaseNCodecInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\uba4c", "\udbea\udc55",
        55, 17691, 1428259967, -7777645875966619113L, -15585L, true, false, (char) 32028, (char) 24113,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fef7cf25122c9d4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\uba4c", "\udbea\udc55",
        57, 17748, 1428259967, -7777645875966619113L, -15585L, true, false, (char) 32028, (char) 24113,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fef7cf25122c9d4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 5, "\udb97\udd5d", "\uc762\ua8d9\u59ba\u1988\u0222\000", "\u2867\ud8bb\ude1d\udb60\udc61\uda0a\udd18\ud92c\udd83",
        25, 6207, 785445262, 6079015071798056455L, 31072L, true, false, (char) 7320, (char) 46649,
        Double.longBitsToDouble(0x3fd22c9d45dcb34cL), Double.longBitsToDouble(0x3fe9ed5dea56491aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\udb97\udd5d\udafa\udc3f\udb81\udfb6\u0dc0\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\uce18", "\udbea\udc55\udb60\udc61\uda0a\udd18\ud92c\udd83\ud997\udf6b\ud8dc\udfdb\ud903\udc50\ud9c1\uddd5\ud967\udd3f",
        14, 11069, 44048081, -7040786515406612497L, -51848L, true, false, (char) 12710, (char) 19070,
        Double.longBitsToDouble(0x3fda5b80a0fb7e06L), Double.longBitsToDouble(0x3fd6e8b7b5fe2b72L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 2, "\udabe\uddce\ud819\udc0c", "\ub40b\ud48e\u5980", "\ud94e\udf31",
        58, 18551, 292748985, -386676879320304420L, 35323L, true, true, (char) 10852, (char) 32028,
        Double.longBitsToDouble(0x3fded7c3b091d848L), Double.longBitsToDouble(0x3f9472da1b69ed60L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\uba4c", "\ud97c\udcc3\udb60\udc61\uda0a\udd18\ud92c\udd83\uda56\uddec\ud8dc\udfdb\ud903\udc50\udb05\udeb7\ud967\udd3f",
        22, 11069, 44048081, -7040786515406612497L, -3943L, true, false, (char) 5431, (char) 6182,
        Double.longBitsToDouble(0x3feb65588a8a9d69L), Double.longBitsToDouble(0x3fe4cc80c142b10cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 5, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\udba4\ude86\udbb2\udebd", "\uba4c", "\udbea\udc24",
        5, 89958, 1428259967, 8791378628106154593L, -15585L, true, false, (char) 52236, (char) 24221,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fef7cf25122c9d4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 2, 0, "\ud886\udc7a\udbb2\udd29\udbcb\udf68\uda2b\udf66\uda44\ude12", "\u7396\u5d3b\u27ee", "\udbea\udc55\udb60\udc61",
        42, 70449, -169590711, -5170747759898988710L, 87221L, false, true, (char) 5126, (char) 16212,
        Double.longBitsToDouble(0x3feda947b36e9e4aL), Double.longBitsToDouble(0x3fe9cc9393eb337fL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 6, "\udacc\ude99\udba0\udf00\udbd6\udda7\udae7\udd43\udaa7\udc62\udb22\uddb0\ud85d\udcf9", "\uc836\u279e\ub735\u8d0b\u9bb9\u8ff3\uc254\u306d\u9ac2\u9db7\u35bc\u6e58\u197a\u485c\u176d\u3adb\u8fba\uae0c\u0a00\u2e8a\u19e4\u6338\uc55a\u4f9d\u4b93\u41b2\u8d9b\u56e4\ubb63\u3663", "\ud800\uddaa\ud830\udd69\ud948\udddc\ud8d1\udd87\ud97b\udd59\ud84e\ude4c\ud8f3\udc08\ud817\udd82\uda8f\udd1b\ud839\udf24\udb64\udcd0\ufef3",
        17, 29713, 306553859, -7200099131555984445L, 1609L, false, false, (char) 49958, (char) 55961,
        Double.longBitsToDouble(0x3fefe09b95282de6L), Double.longBitsToDouble(0x3fe360ea719720d0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 6, 5, "\ud9ed\udd68\udba0\udf7c\udbcb\udefc\ud800\udf70\udaf4\udd6e\ud8ae\udd34\udbcc\udfc3", "\uba4c", "\udbed\udd70",
        55, 17691, 1428259967, -7777645875966619113L, -15585L, true, false, (char) 32028, (char) 24113,
        Double.longBitsToDouble(0x3fca3df5c7e174e4L), Double.longBitsToDouble(0x3fef7cf25122c9d4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 2, "\ud818\ude8e\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\uba4c", "\udbea\udc55",
        47, 43137, 1430682842, 288301057933888820L, -15585L, true, false, (char) 32028, (char) 24113,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fef7cf25696c8d4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 1, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud9a8\uddc3\ud964\udd6a", "\ub8d2\u5d3b\uba4c", "\udbea\udc55\udb60\udc61\udb25\uddc1\ud919\udf50",
        25, 6207, 785445262, 6105273331433657863L, -44812L, false, true, (char) 7320, (char) 46649,
        Double.longBitsToDouble(0x3fe1164ea1af124cL), Double.longBitsToDouble(0x3fe08d82561859ddL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 5, 2, 6, "\udb67\udfdb\ud862\ude1e\uda6f\udc0e\ud923\ude5f\ud8a3\udd2b\ud8ae\udd34\udbcc\udfc3\ud92c\uded7\udb51\uddcc\ud92b\udc7a\ud99f\udd4d\udb2a\udf0b\udbea\udc55", "\u99ab\u6490\u1e8b", "\ud967\uddd7\udb0d\udc0d\udb0c\udceb\uda57\udef8\udb81\udc35\udae3\udcbd\udb92\udef3\ud8b3\udc58\ud91a\ude42\udabc\udfd9\udb5e\udce3\udb01\udf6b",
        58, 46735, 728739531, -683804690954067061L, 53120L, false, false, (char) 52725, (char) 60484,
        Double.longBitsToDouble(0x3fe039901acdb357L), Double.longBitsToDouble(0x3fd605b8892d7100L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 5, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbcc\udf39", "\uba4c", "\udbea\udc55",
        55, 17713, 1428259967, -7777645875966619113L, -15585L, true, false, (char) 32028, (char) 24113,
        Double.longBitsToDouble(0x3fe6881577f80267L), Double.longBitsToDouble(0x3fea8e459922c9d4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 6, 3, "\udb97\udd56", "\u5edc\ua63d\u76bf\ua0e1\uc924\u094a", "\udb2a\udf17\udbea\udc55\udb60\udc61\uda0a\udd18\ud9ee\udc05\uda56\ude79\ud8dc\udfdb\ud933\udff9\udb05\udeb7\ud967\udd3f\uda6b\udd7b\udb1d\udff6\uda57\udef8\ua44e\udae6\udc56\udbe3\udc7e\uda27\udc3c\udb8a\udcfe\ud857\ude2b",
        8, 9224, 1434024918, 2681788513711204845L, -68715L, false, false, (char) 61808, (char) 59615,
        Double.longBitsToDouble(0x3fc88ea65e70d800L), Double.longBitsToDouble(0x3fd42c41890c7f5eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 5, "\udb97\udd5d\ud80f\udd74\udab0\udf1c\ud800\udf74\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\uba4c\u70bf\u7d9f\u8cdf\u9bb9\u901b\u0622\ubedd\u4cba\u2591\u35bc\u6e58\u197a\u2d95", "\udb0d\uddbd\ud91d\udf78",
        18, 87608, 631323121, 4798300394259370318L, -78176L, false, false, (char) 23958, (char) 38751,
        Double.longBitsToDouble(0x3fe037664c5f8bf1L), Double.longBitsToDouble(0x3fbfc701153df1a0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\uba4c", "\ud8f3\udcca",
        55, 17691, 1428259967, -7777645875966619113L, -89347L, false, false, (char) 26262, (char) 62510,
        Double.longBitsToDouble(0x3fe3fbd00e798572L), Double.longBitsToDouble(0x3fdbd560a8cad43aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 4, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\u88ee\udb4b\udd21\udb51\uddcc\ud94e\udf31\udb1e\udccf\udb2a\udf17\udbea\udc55\udb60\udc61\uda0a\udd18\ud92c\udd83\uda4c\udfec\ud8dc\udfdb\ud903\udc50\udb05\udeb7\ud967\udd3f\uda6b\udd7b\udb1d\udff6\uda57\udef8\udb81\udc35\udb24\udcdd\ud8b3\ude9b", "\uca13\u9c1f\ub02d\u9722\u771b\u821b\uc842", "\udbc9\udd1b\uda6f\ude4e\udb28\udd21\udb77\udf69\ud922\udf7c\ud9f9\udf0a\ud8db\udfac\uda02\uded6\ud9bb\uddb0",
        40, 15019, -1534479382, -2206601445475350092L, -78650L, false, true, (char) 56790, (char) 20157,
        Double.longBitsToDouble(0x3f881f6c47f7cb80L), Double.longBitsToDouble(0x3fc82cac6e6b19d0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 4, 5, "\udb71\udeb5\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd27\ud850\uddcf\udbe2\udfd1", "\uba4c\u70bf\u67ab\u8cdf\u9bb9\u901b\ub164\u9018", "\ud92c\udc4b\ud967\ude2a\ud8fd\ude5f\udb21\ude1d\uda57\udef8\udb81\udc35\udae3\udcbd\udbb5\udfc0",
        16, 9600, -852721728, -363209431523101443L, 52161L, true, false, (char) 12451, (char) 34473,
        Double.longBitsToDouble(0x3fdd0ca70c0420aeL), Double.longBitsToDouble(0x3fdb38afb6c178caL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 6, "\udb97\udd5d\udad2\udf75\udbcb\udefc\ud800\udf70\ud848\ude15\ud827\ude08\ud9a4\udf68", "\uca26", "\udaa2\uddf2",
        29, 71668, 615195067, -7777645875966619113L, 85673L, true, false, (char) 32028, (char) 4146,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fe7dcf25122c9a6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 0, "\udb97\udd5d\udb69\ude01\000\ud800\udea0\000\ud8ae\udd34\udbcc\udfc3", "\ub9e5", "\000",
        -5, -1000, 0, 23L, -100000L, false, false, (char) 0, (char) 24113,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fef7800000000d4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 3, "\udb97\udd5d\udba0\udf7c\ud8ad\ude42\ud8cb\udfb5\u86be\ud8dc\udc0a\uda2b\udfec\uda9e\udff4\udb72\udfc9\ud94e\udf31\udb1e\udccf\ud90b\udd2f\ud943\udfab\ud969\udd69\ud84a\udcc7\ud92c\uddb5\ud9ac\udeb7\ud966\udf0c\udb94\udeb2\udb69\udfeb\ud95b\udf3f\ud93f\ude51\ud8d9\uddfb\uda63\udc08\ud9fd\udf53\udb27\udfec\ud9e8\ude56\ud825\udd9e\ud91d\udc66\uda88\udc67\ud835\ude63\ud8bf\udfbe\uda22\udcc6\udb1e\ude2f\udaaf\ude91\ud8c8\ude51\uda08\udd2c\ud805\udc73", "\u009c", "\uda48\udea7\ud8ce\udfae\ud9b9\udeae\udb0d\udd64\ud147\udb50\udd66\ud94e\ude2c\ud93f\udd7b\udb11\udd4e\uda93\ude98\ud8c0\udf6b\ud971\uddb6\udb51\udd78\ud850\ude0e\ud9e3\udeba\ud825\udc2c\ud875\udd1b\ud9f4\udc98\ud9f9\udc9c\uda51\udda8\ud8b1\ude17\ud9d7\udc6a\udaa9\udcaa\udaa7\udc18\udb94\udda4\udafa\ude62\udbe7\udeda\ud98f\udc50\ud94d\ude44\ud8b9\udc80",
        26, 82501, -1808021721, 2777790548035017603L, 5277L, true, false, (char) 13456, (char) 53725,
        Double.longBitsToDouble(0x3fe88fdc9549ad59L), Double.longBitsToDouble(0x3fee659fa2934cf6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 5, "\udbeb\udec7\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbaa\udd74", "\uba52\u70bf\u7d9f\u8cdf\uc3bd\ub7fc", "\ud8dc\udfdb\ud903\udc69\udb05\udeb7\ud967\udd3f",
        22, 11069, 44048081, -7040786515406612497L, -89636L, true, true, (char) 13067, (char) 33655,
        Double.longBitsToDouble(0x3fed2659a4267f7eL), Double.longBitsToDouble(0x3fe2071316e30f6eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 5, 5, 0, "\udb97\udd5d\uda9a\udc99\udbcb\udefc\ud800\udf70\udad7\uddd1\ud8ae\udd34\udbcc\udfc3\ud92c\uded7\udb51\uddcc\ud94e\udf31\udb1e\udccf", "\u9bb9\u901b\u4061\u829c\u4cba\u890a\u19bc", "\udb1d\udff6\uda57\udef8\udb81\udc35\udae3\udcbd\udbde\ude99\ud88a\udf7d\ud975\udd13\udac8\udc1c\ud805\udc8b\ud820\udddc\ud968\udd17\udbc0\udcaa",
        48, 21032, -788706472, -1374823967730783830L, -87694L, true, true, (char) 54235, (char) 55438,
        Double.longBitsToDouble(0x3fed34a9b4df5b27L), Double.longBitsToDouble(0x3fe8fe743cc82115L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 5, "\udb97\udd5d", "\u1bd5\000\u59ba\000\000\000", "\000",
        28, 53003, 0, 0L, -99993L, false, false, (char) 24113, (char) 3712,
        Double.longBitsToDouble(0x3fcf00541fbe7928L), Double.longBitsToDouble(0x3fd22c9d400ffe58L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 5, "\udb97\udd5d\ud9e7\udc14\udafc\uddb5\ud85a\udc3e\udacc\uddcc\ud83b\udf2c\udbc7\uddd7", "\u2329\u0495", "\uda37\udce1\uda0a\udd18\ud92c\udd83\uda56\uddec\ud9e7\udcdf\ud970\ude9f\uda97\udec0",
        17, 35312, 278942189, 7114032498583810528L, 47166L, true, true, (char) 20651, (char) 24811,
        Double.longBitsToDouble(0x3fdce7928a529a88L), Double.longBitsToDouble(0x3fd5e269a8248230L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 4, 5, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\uba4c", "\udbea\udc55",
        55, 17691, 1428259967, -7777645875966619113L, -15585L, true, false, (char) 32028, (char) 23888,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fef7cf25122c9d4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 3, 4, "\udb97\udd5d\udba0\udf7c\uda6f\udf7f\u4ca6\ud8a3\udd84\ud8ae\udd34\udab2\udf96", "\uac5f", "\ud884\udf38",
        8, 25390, 1435305938, -5111514896563298290L, -92111L, false, true, (char) 46649, (char) 35574,
        Double.longBitsToDouble(0x3fdf0ef4ae7e51ccL), Double.longBitsToDouble(0x3fa89a194f583970L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 2, 5, "\000\udba0\udf7c\udbcb\udefc\ud90d\uded7\ud8a3\udcdc\ud8ae\udd34\ud9af\uded4", "\uba4c", "\udbea\udc55",
        54, -1000, 1428259967, 70682276790272L, -34464L, true, false, (char) 62236, (char) 10477,
        Double.longBitsToDouble(0x3fe68f7d700000a0L), Double.longBitsToDouble(0x3fef7cf00122c9d4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 5, "\udb97\udd5d", "\u1bd5\u7975\u59ba", "\udb51\uddcc",
        42, 20748, 10343, 0L, -545L, true, false, (char) 58919, (char) 58,
        Double.longBitsToDouble(0x3fdbf2ed0c0ea8baL), Double.longBitsToDouble(0x3fe2c79620003544L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb97\udd58\udba0\udf7c\ud949\udefb\ud800\udf70\ud8a3\udd77\udb9f\udf28\ud82b\ude11", "\u614b", "\udbea\udc55",
        3, 17691, 1428259967, -3093902263501303273L, -15585L, true, false, (char) 64796, (char) 24261,
        Double.longBitsToDouble(0x3fe68f7d738c5c31L), Double.longBitsToDouble(0x3f86d2b509233bc0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 1, "\ud957\udd5d\udba0\udefa\udb81\udea6\u7345\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\uba4c", "\udbcd\udd11",
        -2, 95726, 963161727, -7777539974958018793L, -86575L, true, false, (char) 3712, (char) 12258,
        Double.longBitsToDouble(0x3fdaf804ae4457d8L), Double.longBitsToDouble(0x3f97f0f0f45ec440L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 1, 5, 6, 4, "\udb97\udd5d\udba0\udf7c\udb72\udff7\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\u4289", "\udbea\udc55",
        55, 17691, 1435522175, -7777645875966619113L, -15585L, true, false, (char) 32028, (char) 24113,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fef7cf25122c9d4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 0, "\udb97\udd5d", "\000\000\000\u7f29\000\000", "",
        -5, -1000, 0, 0L, 31072L, false, true, (char) 11984, (char) 54790,
        Double.longBitsToDouble(0x3fe2c79620000044L), Double.longBitsToDouble(0x3fe68f7d71f800a0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 1, 5, 6, 5, "\udb97\udd5d", "\uc6aa\ua8d9\u59ba\u1988\u7891\ub38e", "\uda17\udff2\ud84d\udcc3\udb60\udc92\uda0a\udd18\ud92c\udd83",
        25, 6207, 785445262, 6079015071798056455L, 31072L, true, false, (char) 7320, (char) 46649,
        Double.longBitsToDouble(0x3fdc2288fc203258L), Double.longBitsToDouble(0x3fe9aa8c5a56491aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 1, "\udb97\udd5d", "\uc762\ua8d9\u59ba\u1988\u0222\000", "\u2867\ud8bb\ude1d\ud861\ude00\uda0a\udd18\ud92c\udd83",
        25, 6207, 785445262, 6079015071798056455L, 31072L, true, false, (char) 7320, (char) 46649,
        Double.longBitsToDouble(0x3fd22c9d45dcb34cL), Double.longBitsToDouble(0x3fe9ed5dea56491aL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 2, "\udb6b\udd67\udba0\udf7c\udbcb\udefc", "\u6910\u16cd", "\ud94e\udfa4",
        21, 5311, 1694463274, -5928059567408565109L, -83543L, true, false, (char) 5064, (char) 11984,
        Double.longBitsToDouble(0x3fe03aa2ea58f2c4L), Double.longBitsToDouble(0x3eb13689ed700000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 5, "\u96a6", "\uc762\ua8d9\u1240\u340a\u0222\000", "\u2867\ud8bb\ude1d\ud9e4\udda2\uda0a\udd18\ud92c\udd83",
        25, 38047, 785445262, 5070208753777440681L, 96608L, false, false, (char) 58657, (char) 2094,
        Double.longBitsToDouble(0x3fd22c9d45dcb34cL), Double.longBitsToDouble(0x3fe9ed5dea56491aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "", "\uc5e7", "\ud8ae\udd34\udbcc\udfc3",
        21, -1000, 218103808, 2043252299328923751L, -54235L, false, false, (char) 0, (char) 38250,
        Double.longBitsToDouble(0x3fe0bca0018e963aL), Double.longBitsToDouble(0x3f2768007545d000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 5, "", "\uc8d4\ud76b\ub40b\ud48e", "\000",
        -5, -1000, 0, -90046464L, -545L, true, false, (char) 37607, (char) 26181,
        Double.longBitsToDouble(0x3fdbf2e7ac0ea8baL), Double.longBitsToDouble(0x3fe2c79625ed7c3bL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\udb8b\udc85", "", "",
        -5, 66200, 201654272, 98956046499840L, -100000L, false, false, (char) 16242, (char) 44926,
        Double.longBitsToDouble(0x3fbfd35040000108L), Double.longBitsToDouble(0x3f32d6c4daa80000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 4, 6, "\udb97\udd5d\udba0\udf7c\ud9c6\udc55\ud800\udf38\ud8a3\udd77\udba4\ude86\udbb2\udebd", "\uba4c", "\udbea\udc24",
        5, 89958, 1428259967, 8791378628106154593L, -15585L, true, false, (char) 52236, (char) 24221,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fef7cf25122c9d4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 4, 0, "\u00f0\udb91\udd87\udbcb\udefc\000\ud879\udcdc\udba4\ude86\ud92a\udcf9", "\000", "\udbea\udc24",
        -5, 89792, 1428259967, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=java.lang.Long:0 |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 2, 1, 1, 5, "\ud9ed\udd68\udba0\udf7cG", "\u3b45", "\000",
        -5, -1000, 15214592, 0L, -545L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f27680000000000L), Double.longBitsToDouble(0x3fe2c79000000044L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 4, 1, "\udb71\udeb5\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd27", "\ubca7\u5d3b\uba4c\u70bf\u67ab\u8cdf\u9bb9\u901b\ub164\u9018\u4cba\u64db\u348c\u6e8f\u5762\u6ac8\u81ed\u4e29\u44a2\uab6f\ud2f9", "\udbcf\udea5\uf92c\udb18\udc0a\ud83d\ude13\ud85c\udf09\uda33\udea3\ud86e\ude6e\udaaa\udfb1\udbce\udc30\uda16\udec6",
        45, -69, -1164803232, 6836274967034755797L, 75904L, true, false, (char) 62249, (char) 15844,
        Double.longBitsToDouble(0x3fdf92bb445336c8L), Double.longBitsToDouble(0x3fe582e2f402a175L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.codec.binary.BaseNCodecInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 0, "\udb76\udf61\ud8d1\udd14\000\udb75\uddbb\uda30\udecd\udabd\udd23\u2983", "\ub9e5", "\000",
        -5, -1000, 0, 23L, -100000L, false, false, (char) 0, (char) 24113,
        Double.longBitsToDouble(0x3fe68f7d71f802a0L), Double.longBitsToDouble(0x3fef7800000000d4L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 5, "\udb97\udd5d\udba0\udf7c\udbcb\udefc\ud800\udf70\ud8a3\udd77\ud8ae\udd34\udbcc\udfc3", "\u9da9", "\udbea\udc55",
        55, 17691, 1428259967, -7777645874859322857L, -15585L, true, false, (char) 10781, (char) 33747,
        Double.longBitsToDouble(0x3fcb9df5d3e00a80L), Double.longBitsToDouble(0x3fc8a8409f69837cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.binary.BaseNCodecInputStream:@?\012",
        Z.run(T, 1, 5, 6, 4, "\udb7e\udf9f\udba0\udf7c\udb72\udff7\ud800\udf70\ud8a3\udd77", "\uc060\u5d3b\u481d", "\udbea\udc55",
        55, 78499, 1435522175, -7777645485124595177L, 84633L, false, false, (char) 61659, (char) 1073,
        Double.longBitsToDouble(0x3fec3fed39f4bd2fL), Double.longBitsToDouble(0x3fe18bbcad71c1d2L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 3, 4, "\udb97\udd5d\udba0\udf7c\uda6f\udf7f\ud9e0\udcec\uda68\udd45\ud8ae\udd34\udab2\udf96\ud92c\uded7\udb51\uddcc\udbb6\udee5\udad0\ude49\udb49\ude22\u928a\uda6e\ude19\uda69\ude5c\uda99\udcdc\udaae\udd77\ud989\udfdb\ud826\udde7\ud895\udeba\ud967\udd3f\uda7a\udc15\ueb05\uda57\udef8\udb81\udc35\udae3\udcbd\udbb8\udc25\ud801\udc59\udadd\ude50\ud9f8\ude21\udb06\udd9b\ud8ee\ude19\udbdb\udce5\ud991\udfbd\udb8b\udfcf\u460e\ud9ce\udf81\udad7\udd05\uda33\udea4\udb59\udd21\udb31\udeb7\udb6b\udc8b\udbb4\udfad\udb63\udf26\ud870\udedc\ud86d\udec7\ud8e0\udf83\ud863\udd36\ud9f9\udfba\ud835\udc4b\udb4b\udea0\ud8f2\udf19\uda5b\udd97\udb61\udca2\ud9dc\ude74\uda06\udd20", "\u81bc\u6cbc\uc1cc\ub8e1\ub578\u9d15\u8f4f\u798c\uc4c2\ua3d7\u38f0\u80ee\u0fc9\u2182\u7ea8\u3a11\u2801\uc4c1\u0b8e\u9ae3\u49cd\u586e\u864d\u4134\u362a\u6cbe\u4021\u3024\ubdfd\u298b\u2a73\u468c\uc1e4\u0601\u131e\u555f\ua9e1\ub8d5\u8efb\ua7b1\ub34b\uab04\u97fe\u1f21\ua5e3\u60fd\u5bde\u3bd4\u785d", "\udb81\udf19\udb53\udfd9\ud84e\udeb9\uda77\udc97\ud942\udd6a\ud92c\udef1\udb76\ude42\udb38\udeeb\ud98a\udc7a\ud88b\ude37\uda52\udd25\u199c\ud8e5\ude03\uda1a\udc1e\ud957\udccf\ud9e4\udf1b\udad4\uddf9\ud91a\udd71\ud8de\udc27\uda9c\udff6\ud988\ude11\ud927\udfd0\ud922\ude80\udb55\udfc4\udb7e\udf0b\udb56\udc9b\udbd5\udf0c\ud8d5\uddd4\udba0\ude71",
        31, 33469, 179932195, 5033561620969853001L, -97612L, false, true, (char) 48032, (char) 46655,
        Double.longBitsToDouble(0x3fefc29ec788a39cL), Double.longBitsToDouble(0x3fea6b6d5516d7b3L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 5, "\uda8d\ude8d\ud8f1\udd90\000\udbc0\udf20\ud9b4\udf0f\udabd\udd23\uda13\udf18\uab29\020\ud94e\udeca\udb1e\udccf\u00f3\uda86\udee2\ud86c\udf5d\udac5\udc42\ud8ab\udf2e\uc4cb\027\ud8fe\ude7e\ud9dc\ude9e\udb66\ude32\u6f3f", "\u28d1\u8ed6\u2a6b\ua6a6\u2dcc\ubfb1\ub739\u0789\u4abe\u5709\u8942\ub6c5\u8aed\u62a7\u96f0\u8d14\u9e78", "\udb47\ude02\udbfa\uddb8\uda14\ude26\uda30\udd9b\udb5e\udc5d\udb73\ude84\ud80a\uddbc\ud91d\udddd\udb0c\udef1\udbb0\ude03\ud8d8\udf09\ud8aa\udc68\udafa\udd5d\ud974\udd3d\ud956\udcc4\ud961\udf3d\udbc4\udee7\uda3c\udd8a\uda44\udcd4\ud8d0\uddc9\ud99a\udf04\udae2\udcb3\ud8c5\udddb\ud882\ude05\udb32\udd37\uda7a\udd51\uacea\ud9a5\udf18\ud982\udf59\uda31\udca1\ud885\udf17\u02a6\ud898\udd3d\uda12\udced\ud849\udde6\uac1d\udb8c\udeb9\ud801\udf81\udbd8\uddf4\u71d0\uda3a\udc37\uda35\udded\ud98e\udddd\udaf1\udd2f\ud900\udc90\ud845\udcad\uda8e\ude79\uda41\udda3\udbaa\udcde\ud884\udd83\udaf8\udc3a\ud962\udfdd\ud9ac\udf7c\udaac\udcc8\ud9ba\udd5b\ud8b6\udd91\ud9a3\udcbc\udb8b\udce3\udbc9\udc5c\uda41\udf8e\udb20\udc04\ud81f\udd78\ud94a\udf1b\ud836\udfaa\ud9bb\udced\ud959\udfeb\uda3d\udf56\udb50\udff2\uda3a\ude2f\ud883\ude0a\udb4f\udf64\ud8dd\udcc2\udacb\uddcd\uda1b\udcf0\ud822\udc29\uda42\udce5\uda0e\udf7b\ud8f0\ude5e\udb5f\udf8d\uda4e\udeb4\ud975\udedd\udb89\udc70\ud942\ude0d\uda8c\ude78\ud83f\uddc2\udaf4\ude5a\ud83f\udea8\udb59\ude2f\udb04\udf20\uda48\uddca\ud996\udf5a\uda6c\udc23\ud80b\udf80\ud9ff\udeda\ud9f2\udecf\udaed\udd3f\ud8c3\udcdf\u1643\udaf2\uddc5\ud899\udf5a\ud91c\udd20\ud8e5\udd61\ud85a\udd78\uda70\ude98\udad8\udc75\ud9b8\udeca\ud92b\udc1d\udada\ude34\udb38\udc96\udb7e\ude31\udae3\udfa6\uda5d\udece\udbb6\udc97\ud82a\udf41\udb36\udc35\ud8fe\ude84\udae9\ude1e\ud889\uddd2\udbcb\udec8\ud8ee\udfaa\ud8c1\udd56\ud99f\ude4b\ud86f\udf8c\udb3f\udee4\ud80a\udfa6\udb4b\udde3",
        10, 55528, 1587486181, 844438149792261006L, -29978L, false, false, (char) 33260, (char) 40854,
        Double.longBitsToDouble(0x3fd2cbf27c77fbc8L), Double.longBitsToDouble(0x3fd4548f073517b0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|available||new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|skip|long|new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|markSupported||new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|read||new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|read|[B,int,int|new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "C|org.apache.commons.codec.binary.BaseNCodecInputStream|<init>|java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|available||new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
    "M|org.apache.commons.codec.binary.BaseNCodecInputStream|skip|long|new:org.apache.commons.codec.binary.BaseNCodecInputStream:java.io.InputStream,org.apache.commons.codec.binary.BaseNCodec,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
