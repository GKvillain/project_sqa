package org.apache.commons.codec.net;
import org.junit.Test;
import static org.junit.Assert.*;
public class QuotedPrintableCodec_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 10, "\ud861\udc0b", "\ub455\u62c3\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\u3a20\u83a0\ua80a\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        2, 64102, 1442965295, 8325293550910675286L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 10, "\ud861\udc0b", "\u305b\u62f2\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\u3a20\u83a0\ua80a\u6d82\u1671\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udb53\uddbb",
        18, 63985, 1442965295, 8325293550910675286L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fe55cc009448151L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 10, "\ud92a\udee9", "\ud68f", "\uda21\udd97\ud97e\udc75",
        56, 8053, -322728169, -2245544283845522163L, 53255L, false, false, (char) 4900, (char) 25877,
        Double.longBitsToDouble(0x3fa70c736c812f60L), Double.longBitsToDouble(0x3fe1c15dc10b9359L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 10, "\ud861\udc0b", "\ub455\u62c3\u63ee\ua3d1\u711b\u5d39\u9a95\u0946\ua7a1\u90e0\u35ad\u3a20\u83a0\ua80a\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udaf0\udf07",
        2, 64102, 1442965295, 8325293550910675286L, -95172L, true, true, (char) 58926, (char) 3788,
        Double.longBitsToDouble(0x3fedf588094481e4L), Double.longBitsToDouble(0x3fe67536aa23cb00L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 1, "\ud855\ude0b", "\ub455\u62c3\u1472\u7ee9\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0", "\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\ud92a\ude39\udb9b\udedf\udaa6\udd78\ue587\udbde\udf89\ud876\udd0f\uda2e\udcda\udaeb\udf07\ud986\udfe9\uda9f\ude17\uda1f\udc40\ud9cd\udd1a\ud9b3\udf18\ue1fd\udaf9\uddff\ud835\udc84\udb38\udc5e\udbac\udd98\udacd\udca0\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00\udaab\udfd8\udabf\udce0\uda37\udd5e\uda95\udffb\udaa7\udc45\udbdc\udecd\ud8b3\ude14",
        43, 36540, 2112313021, 2451127425177438423L, 14847L, true, true, (char) 52158, (char) 62381,
        Double.longBitsToDouble(0x3fe5d07a2867a77cL), Double.longBitsToDouble(0x3fcc27941c52bb2cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:=F2=BD=A1=B5 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 5, 10, "\udab6\udc75", "\ub455\u62c3\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u6bad\u3a20\u83a0\ua80a\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        2, 64102, 1442965295, 8325293550910661718L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:=F0=A8=90=8B |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 10, "\ud861\udc0b", "\ub455\u62c3\u4aab\u4205\u7459\ua9ad\u6895\u7092\ua7a1\ud1de\u35ad\u3a20\u83a0\uaf76\u3644\u161e\u2a06\u17c1\u72a6\u6456\u026d", "\uda2e\udcda\udaeb\udf07",
        2, 64102, 1442965295, -3438953100711192194L, 17687L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8a461ae46L), Double.longBitsToDouble(0x3fedf58d494481e4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 10, "\ud861\udc0b", "\ub455\u66e9", "\udbf7\udec0\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\udbb5\udc3e\uda11\udda3\udafa\udcc0\ud963\ude6d\ud8e0\udc88\ud967\udfbe\udb9c\udca1\ud83a\udcc2\ud9a7\ude8b\ud8a4\udf42\udb6b\udfdf\udaa6\udd78\ue587\udb89\uddc2\ud876\udd0f\uda2e\udcda\udaeb\udf07\ud986\udfe9\ud92e\udf20\uda1f\udc40\ue92f\udaa4\ude54",
        28, 89299, 320392036, -4786705965282687036L, 3943L, false, true, (char) 3788, (char) 36031,
        Double.longBitsToDouble(0x3fd4481e4da3205aL), Double.longBitsToDouble(0x3fcc843698768c80L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 0, "\u00a7", "\ub455", "\udbc4\udcc8\udbf7\udec0",
        26, 43864, -322727950, 8405913037583322381L, -77817L, true, false, (char) 8749, (char) 25877,
        Double.longBitsToDouble(0x3fed27da4ec812f6L), Double.longBitsToDouble(0x3f93fbfc00000b40L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 8, 2, "\ud868\udd3e", "\ub455\u62c3\u4aab\u4205\u7459\uc998\u6f01\u708d\ua7a1\u90e0\u35ad\u3a20\u83a0\ua80a\u3644\u8da1\uafa7\u8c5c\u650e\u9dd0\ub872", "\ud975\udedd\udace\udc3b\ud986\udfe9",
        2, 78295, 1938383456, 7413375056957489968L, 39187L, true, false, (char) 53907, (char) 12867,
        Double.longBitsToDouble(0x3fdf99642b557d14L), Double.longBitsToDouble(0x3fed46b91bbeb1e2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:UTF-8 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 5, 10, "\ud861\udc0b", "\ub455\u62c3\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\u3a20\u83a0\ua63e\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        2, 64102, 1442965295, 8325293550910675286L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fedf58aa44481e4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[B:[[49, -37]] |a0=[B:[[49, -37]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.io.UnsupportedEncodingException\012",
        Z.run(T, 2, 6, 13, 10, "\ud861\udc0b", "\ub745\u62c3\u4aab\u7afa\u7400\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\u3a20\u83a0\ua80a\u3644\u161e\u8301\ubb80\u6995\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        0, 64102, 1442965295, 8325293550910675286L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 10, "\udbc8\udeac", "\ub455\u62c3\u4aab\u9de0\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\uc70d\u38ec\ua80a\u6193\u0ef2\u2a06\u17c1\u6b8a\u55fd\u194d", "\uda2e\udcda\udaeb\udf07\ud986\udfe9\uda9f\ude17\udb79\udc4d\udb2c\uddc0\udaa4\ude54\u3462\udaf9\uddff\ud835\udc84\udb38\udc5e\udbac\udd98",
        53, 47841, -414316374, 8745387600679668606L, 77787L, false, true, (char) 39974, (char) 82,
        Double.longBitsToDouble(0x3fde2198097431b4L), Double.longBitsToDouble(0x3fdfe9c8405b27caL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 5, 15, 15, "\ud861\udc0b", "\ub455\u62c3\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\u3a20\u83a0\ua80a\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        2, 64102, 1442965295, 8325293550910675286L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 0, 15, "\ud861\udc0b", "\000", "\u0ce8",
        22, 82841, 56299, 0L, -62695L, false, false, (char) 25877, (char) 60141,
        Double.longBitsToDouble(0x3fe64097b400fbfcL), Double.longBitsToDouble(0x3fc22d0b57e7d108L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 5, 0, "\ud861\udc0b", "\ub455\u62c3\u4aab\u2cfc\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\u3a20\u83a0\ua80a\u3644\u161e\u2a06\023\000\000\u7de8", "\uda2e\udcda\udaeb\udf07",
        2, 64102, 1442965295, 8325293550910675286L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fd000000f51ae46L), Double.longBitsToDouble(0x3fedf58809440000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 18, 5, 10, "\uda2a\udd48", "\u51c5\u62c3\u9acc\u9ff3\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\u3ad1\u5861\ua722\u3644\u161e", "\udb6b\udfdf\udaa6\udd78\ue587\udb89\uddc2\ud876\udd0f\uda2e\udcda\udaeb\udf07\ud986\udfe9\udbcc\udf8e\udb9a\uddef\udbc5\udc0d\udaa4\ude2a\u3462\udaf9\uddff\ud835\udc84\udb38\udc5e\udbac\udd98\udacd\udca0\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00\ud9d9\udc4f\ud9d4\ude6a\ud94e\udda7\udb63\ude83\uda29\udfaa\ud957\udc08\ud9cc\udf67\ud983\udca7\udb0b\ude36\ud946\ude0e\uda47\uddb0\uda9b\udc34\ud9aa\udc03\udbbf\udc7c\ud887\udd72\udb0a\udd91\ud8b6\udec8\uda55\udde0\ud9d7\ude93\ud971\uddc3\ud805\udcbc\ud82e\udf13\udb32\udc71\ud8b1\udcea\ud89b\udea4\udae7\ude1d\udbeb\udfe3\uda82\uddb9\u49b4\uda52\uddff\ud8d2\udc37\ud82a\udf0c\udb17\ude7b",
        46, 65039, 2031869152, 640448594741453919L, 99152L, true, false, (char) 15885, (char) 33653,
        Double.longBitsToDouble(0x3fdce7874754c6deL), Double.longBitsToDouble(0x3fcd287395eac7dcL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 10, "\ud861\udc0b", "\ub455\u5781\u261e\u6a14\ucd48", "\ua2c4\uda4b\udc2e\uda11\udda3\udafa\udcc0\ud963\ude6d\ud8e0\udc88\ud967\udfbe",
        42, 22092, -67338552, 7538859830549887121L, -85037L, false, true, (char) 42388, (char) 11269,
        Double.longBitsToDouble(0x3fde295a6fc19f30L), Double.longBitsToDouble(0x3fe7b643572f7903L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 16, "\ud860\udf64", "\ub455\u4447", "",
        16, 83121, 0, 1946157056L, -62695L, false, true, (char) 25877, (char) 60068,
        Double.longBitsToDouble(0x3ecec04c00000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 18, 5, 10, "\ud861\udc0b", "\u1756\u62c3\u4aab\u4205\u4ef4\u5cdb\u50e1\u0da5\ua840\ua3e0\u35ad\u0da6\u0f3c\ua80a\u3644\u161e\u2a06\uc924\u72b2\u6456\ubc90", "\uda2e\udcda\udaeb\udf07\ud986\udfe9\uda68\udda8\uda1f\udc40\ue92f\udaa4\ude54\u3462\udb7f\udffa\ud835\udd1a\ud9ba\udd55\ud921\udfc2\udacd\udca0\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00\udbe8\ude22\ud987\udce3\uda90\uddc2\uda0a\udf48\ud87c\udce1\udb9e\udd79\ud906\udef2\uda97\udcf8\uda6a\udf19\udad5\udf6a\ud85d\udec1\udb8d\ude14\ud8cc\udc03\udb81\udef1\ud84b\udf80\ud84d\ude95\ud850\udf5f\ud876\udd17\uda4f\udeda\udbe4\udfb0\ud945\udc6f\ud911\udf5b\ud90f\udcde\ud81b\ude84\ud94e\udd9f\udab3\udfcc\uda3e\ude69\ud881\udf62\uda08\udcb4\udb02\udcad\ud99a\uddae\ud96b\ude5c\ua306\u2a2b\udb3b\udf36\uda06\udd86\udbb7\uddf3\udbe7\udd7c\ud889\udc17\uda42\uddb4\ud95f\udcd8\uda47\ude63\udb1f\udf9a\udbd4\ude2c\udb0c\ude59\ud8d6\udf7a\udb5f\udd10\uda37\udf9c\udb7d\udd27\udae8\udc27\uda74\udc1c\uda93\udcb1",
        46, 81296, -777154733, 5959247160985115200L, -84373L, true, true, (char) 6420, (char) 7667,
        Double.longBitsToDouble(0x3fd0069559ac1748L), Double.longBitsToDouble(0x3fedcb68851c4290L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 18, 3, "\udaf3\udc74\ud889\ude36\udb32\udd15\ud930\udca8\ud940\udc62\udac3\ude39\ud911\udf4f\ud999\ude04\uda46\udf00\udab3\udf9d\udba5\udfd9\ud902\uddc5\ud9e9\udf8d\udafa\udcc0\ud984\udef5\ud8e0\udc88", "\u161e\u7118\u17c1\u72a6", "\udae6\udf72\ud86a\udd11\uda2e\udcda\udaeb\udf07\ud3ab\ud9fc\udfdd\uda1f\udc40\ue92f\ud98b\udcc8\udb43\udc21\udaf9\uddff\ud835\udc84\udb38\udc5e\udbac\udd98\udacd\udca0\ud902\udd27\ud811\uddff\ud8e3\udcc9",
        35, 59044, 205972403, -6119110374311048106L, -83352L, false, true, (char) 1146, (char) 2021,
        Double.longBitsToDouble(0x3fcfbf7f8b337eccL), Double.longBitsToDouble(0x3fe0abf6750355beL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.io.UnsupportedEncodingException\012",
        Z.run(T, 2, 9, 15, 10, "\ud861\udc0b\ua26f\uda4f\udc82\ud92e\udf2c", "\u9e9e\ua9dc", "\udb1f\udecf\udbb5\udc3e\uda11\udda3\udafa\udcc0",
        30, 97351, -1187251222, -339551343780368476L, 3405L, true, false, (char) 64204, (char) 58215,
        Double.longBitsToDouble(0x3fbc8b41770661f0L), Double.longBitsToDouble(0x3fea37d2f3e295a6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[B:[[49, -37]] |a0=[B:[[49, -37]]\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 5, 10, "\ud861\udc0b", "\ub455\u62c3\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u136a\u39f0\u83a0\u10b2\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        2, 64102, 1442965295, 8325293550910675286L, -21079L, true, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8ae01ae46L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.io.UnsupportedEncodingException\012",
        Z.run(T, 2, 7, 9, 10, "\ud8e8\udfd3", "\ub455\u62c3\u4aab", "\ud9fd\udf51\ud877\udc2a\udb1f\udecf\udbb5\udc3e\uda11\udda3\udb6d\udf5a\ud92a\udffd\udac2\udf71\udbed\udefd\udb9c\udf92\ud965\udc81\ud9a7\uddd6\ud9ff\udee5\uda03\ude24\ud905\ude35\ud76b\udbcd\udcb7\udaba\udc15\udb2c\udd01\uda4d\udc4b\ud986\udfe9\uda9f\ude17\uda17\udffe\ue971\udaa4\ude54\uda51\udc8d\udafe\udc54\ud9aa\udc8d\udb12\udc73\udb5a\udc91\udafa\udfcb\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00",
        35, 90436, -1195636825, -7488653311596218376L, 17167L, true, false, (char) 51144, (char) 7739,
        Double.longBitsToDouble(0x3fe39268eb34d57bL), Double.longBitsToDouble(0x3fcd48d686f4c178L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:UTF-8 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 14, 5, 18, "\ud861\udc0b\ua26f\udb32\udd15\ud91e\udd2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8\udbf7\udec0\u7f9f\ud83c\udca1\ud8a0\ude0b\ud81f\ude77\uda11\udda3\udafa\udcc0\ud9d4\udfc6\uda40\ude56\ud967\udfbe\udb9c\udf92\ud83a\udcc2\uda3d\udc15\ud8f7\udec1\ud93d\udf5c\udac2\ude06\uda2b\ude4f\udb76\udf80", "\u7083\ubd4e\ud662", "\ud8ac\udc3c\udb40\udf95",
        9, 9436, -1114491831, 2239704926307619548L, -46154L, false, true, (char) 36031, (char) 39720,
        Double.longBitsToDouble(0x3fe82266d56cfb0dL), Double.longBitsToDouble(0x3fe7f4723696e5d1L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[B:[[-10, -98]] |a0=[B:[[-10, -98]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 5, 10, "\udb26\udfce", "\uaae5\u62c3\u74aa\u4205\u4246\u4aaf\u50e1\u7125\ua7a1\u0f65\u35c4\u3a20\u0a87\u6573\u5df4\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\ud989\udc27\udaeb\udc59",
        2, 64102, 1442908367, 8325293551765264726L, 85638L, true, true, (char) 44633, (char) 50518,
        Double.longBitsToDouble(0x3fc1a3e2a7e65908L), Double.longBitsToDouble(0x3fdaabe8af51ae46L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:UTF-8 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[48, 89, 63, 61, 48, 50, 61, 69, 53, 61, 70, 69, 61, 70, 67, 61, 70, 65]] |a1=[B:[[48, 89, 63, 2, -27, -2, -4, -6]]\012",
        Z.run(T, 2, 14, 3, 4, "\ud860\udf89\ua26f\udb32\udd15\ud92e\udf2c\udb2a\udcb3", "\ube20\u5cdb", "\udb08\udf49",
        5, 35317, -64072025, 2757168646915357446L, -30276L, false, false, (char) 26640, (char) 41195,
        Double.longBitsToDouble(0x3fcf3e8848e49480L), Double.longBitsToDouble(0x3fc1a6939b9bc3ccL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 5, 10, "\ud861\udc0b\ua26f\udb32\udd15\udb2b\ude0b\ud80e\udd4a\udadf\ude8c\udbc4\udcc8\udbf7\udec0\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\udb83\udf47", "\u3a20\u83a0\ua80a\u3644\u161e\u2a06\u17c1", "\ue587",
        42, 2671, -1784226017, -3487895104668414160L, 24719L, false, false, (char) 3295, (char) 10976,
        Double.longBitsToDouble(0x3feed9440364683fL), Double.longBitsToDouble(0x3fb244c63e25ec90L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F0=A8=90=8B |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 15, 11, 10, "\ud861\udc0b", "\ub455\u62c3\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u1667\000\u8359\ua80a\u3644\u90c8\000\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda",
        42, 75992, 2030266102, 6197488751287992416L, -93345L, true, true, (char) 52030, (char) 18273,
        Double.longBitsToDouble(0x3ec2480000000000L), Double.longBitsToDouble(0x3fdf99642b557d14L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:=F0=A8=AC=BF |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F0=A8=AC=BF |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 11, 10, "\ud862\udf3f", "\ub455\u62c3\u4aab\u6319\u36cb\u5cdb\u50e1\u4cff\ua815\u90e0\u35ad\u3a20\u83a0\ua80a\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda33\udc36\udaeb\udf07",
        2, 64102, 1442965295, 8325293550910675286L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 1, 0, "\u00a7", "", "",
        50, 28296, 5873913, 3264642613495463936L, -100000L, false, false, (char) 27254, (char) 8749,
        Double.longBitsToDouble(0x3feed5c9dfa4fb49L), Double.longBitsToDouble(0x3fe64097b413fbfcL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 10, "\ud861\udc0b\ua26f\udb32\udd15\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8\uda96\uddef\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\udbb5\udc3e\uda11\udda3\udafa\udcc0\udb96\udc27\udb67\udf2b", "\u161e\u2a06\u17c1", "\ue587",
        42, 2671, -1784226017, -3487895104665727184L, 30095L, false, false, (char) 47806, (char) 51167,
        Double.longBitsToDouble(0x3fe711522c37a2b2L), Double.longBitsToDouble(0x3feda82f17c491a2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[B:[[61, 65, 56, 79, 111, 61, 57, 57, 61, 49, 54, 92, 61, 70, 69, 61, 70, 67]] |a1=[B:[[-88, 79, 111, -103, 22, 92, -2, -4]]\012",
        Z.run(T, 1, 19, 16, 10, "\udbd8\ude7f\ud99f\udfc9\udb46\ude8c\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8", "\u679c\uaf6c\ua7a1\u22f3\u35ad\u3a20\u454f\ua80a\ub94a", "\udae5\udd5b\udab7\udfd3\udaa6\udd78\ue587\udb89\uddc2\ud876\udd0f\ud838\udcff\udafc\udfcd\ud986\udfe9\uda9f\ude17\uda1f\udc40\ue92f\udaa4\ude54",
        47, 66210, 321068422, -4786705965282687036L, 3943L, false, true, (char) 3788, (char) 36031,
        Double.longBitsToDouble(0x3fd4481e497f5440L), Double.longBitsToDouble(0x3fd046d2f21292c0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[B:[[49, -37]] |a0=[B:[[49, -37]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[49, -37]] |a0=[B:[[49, -37]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 6, 6, 10, "\ud861\udc0b", "\ub455\u62c3\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\u3a20\u83a0\u3982\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        2, 64102, 1442965295, 8325293550910675286L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[B:[[61, 57, 53, 79, 61, 48, 50, 119, 61, 48, 50, 61, 69, 53, 61, 48, 53, 61, 70, 67]] |a1=[B:[[-107, 79, 2, 119, 2, -27, 5, -4]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 17, 10, "\udac5\udd7f\uda32\udfa7\udb32\udd15\ud935\udc2c\ud80e\udd05\ud9d8\udfa9\ud9e3\udf7e\u26a8\uda82\ude9e\ud97a\udce7\udae3\udf24\ud936\udd1f", "\u3a20\u2351\u6ce4\u1756\ub5cb\u2fe6\u17c1", "\ue587\udb89\uddc2",
        11, 38983, -1785167390, -4005305714959227146L, -9280L, false, true, (char) 65046, (char) 60834,
        Double.longBitsToDouble(0x3feb2341fc491318L), Double.longBitsToDouble(0x3fee25ec2adc1f15L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null\0121=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 0, 15, 0, "\000", "", "\uf21a\000\000\000\000\000\udb81\udedf\udb01\udd1b\u1600\ud963\ude6d\u6e47\ud928\udfd4\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b",
        -5, 96857, 0, 0L, -100000L, false, false, (char) 7881, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd5673001fe21c2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:=F3=87=A5=98=F2=B9=9F=8D=F3=9C=A4=95=F1=9B=AC=AC |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[61, 65, 69, 40, 117, 61, 57, 68, 61, 48, 50, 61, 69, 53, 61, 70, 69, 61, 70, 67]] |a1=[B:[[-82, 40, 117, -99, 2, -27, -2, -4]]\012",
        Z.run(T, 2, 12, 3, 10, "\udade\udd58\udaa5\udfcd\udb32\udd15\ud92e\udf2c", "\u4205\u7459", "\udb1f\udecf\udbb5\udc3e\uda11\udda3\udafa\udcc0",
        30, 97351, -1187251222, -339551343780368476L, 3405L, true, false, (char) 45883, (char) 50216,
        Double.longBitsToDouble(0x3fdbd4f641f89d58L), Double.longBitsToDouble(0x3fe8fa64d1e295a6L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:UTF-8 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null\012",
        Z.run(T, 2, 14, 19, 10, "\ud861\udc18\ua26f\udb32\udd15\ud92e\udf2c\udbc4\udc40\uda93\udf2b\ud892\udd01\ud93c\ude9b\uda64\udda5\ud876\udffb\udb1f\udecf\udbb5\udc3e\uda11\udda3\udafa\udcc0\ud967\ude6d\uda2e\udcbf", "\ub0d3\u9805\u17c1\u72a6\u6456\ub5e9\u3232\u0087\u057a\uc77d\ubd4e\ud25f\ua51e\ud784\u5720\u7540\u8109\u5d95\u3796\u64a5\u4200\u85eb\ua53b", "\ud8fe\udcff\ud8b7\ude1f\ud9fb\udc99\udb8a\ude38\udab2\udeb8\ud98c\udd85\ud90f\udfca\ud923\udfe4\udbcf\uddbe\ud940\ude79",
        48, 79137, -1243412947, -1958637584811538072L, -11853L, true, false, (char) 2901, (char) 8205,
        Double.longBitsToDouble(0x3f9fe1fc5dc65dc0L), Double.longBitsToDouble(0x3fd738041f9d12a0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 12, 10, 10, "\ud861\udc0b", "\ub455\ucaa1\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u9d1e\uce3a\u9e4a\u883c\u3644\u161e\u2a06\u17c1\ucfc0\u12c8\u7853", "\uda2e\udcda\udb02\uddaa",
        2, 64102, 1452630333, 8325293550910675286L, 44457L, false, true, (char) 3882, (char) 13540,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[B:[[49, 61, 68, 66, 33, 61, 66, 49]] |a0=[B:[[49, -37, 33, -79]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 5, 9, "\ud861\udc0b\ud851\udce1", "\u4747\u6f82\u4205\u7459\u760a\u28fc\u8cb5\u435e\u90e1\u35ad\u3a20", "\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\udb4d\udfac\udb6c\udc03\udaa6\udd78\ue587\udb89\uddc2",
        11, 38983, -812088862, -4005301851803916554L, -9280L, true, true, (char) 10976, (char) 65530,
        Double.longBitsToDouble(0x3feb2341fc491318L), Double.longBitsToDouble(0x3fee25ec92dc1f15L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:149 |a1=[B:[[15, -50, -19, -21, 89, -113, -107, 15]]\0121=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 20, 15, 2, "\uda3f\udffe\udb1d\udc1b\ud889\udcbf\udac5\udf3f\ud9dd\udd7c\udbd4\ude03\uda44\ude95", "\u9eda\u0924\ub2fe\u6c76", "\udb77\ude1c\udadb\udc4c\udb99\ude99\ud880\udf22\ud99a\udebd\ud96b\udd06\udad9\udc9c\udae7\ude90\uda8e\uddb2\ud8df\udcc6\ud91a\uddfa\udaed\udf1a\udae3\udee2\udbd5\udc2a\ud9b4\udc10\ud955\ude5d\uda3d\udda3\ud9c7\udc14\uda87\udf3a\uda8c\udd55\ud859\uddb4\udb5d\udfbf\ud91b\udda9\udbb4\udde9\ud977\udcae\ud8a5\ude64\uda2c\ude9b\udb7e\udd46\ud833\udc69\udae1\udd3c\ud812\udc3f\u4d64\uda3a\udc0e\udb29\udf4d",
        6, 68361, -1091938305, 8538500575962817608L, 20815L, false, true, (char) 28676, (char) 57476,
        Double.longBitsToDouble(0x3fda0f0cabf030aaL), Double.longBitsToDouble(0x3fd71c6650873f0aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.io.UnsupportedEncodingException\012",
        Z.run(T, 2, 9, 10, 9, "\ud861\udc0b\ua26f\udb32\udd15\ud92e\udf2c\ud80e\udd05\ud802\udc5d\ud898\udd61\udb7c\udebf\ud9ee\ude32\u6e3d\udb6f\udd84\udbb5\udc3e\uda11\udda3\udafa\udcc0\ud963\ude6d\ud8e0\udc88", "\u161e\u2a06\u17c1\u72a6", "\udb89\uddc2\ud876\udd0f\uda2e\udcda\udaf0\udf07\ud986\udfe9\uda9f\ude17\uda1f\udc40\ue92f\udaa4\ude54\u3462\udaf9\uddff\ud8fd\ude44\ud933\ude10\udbce\udd74\udaeb\ude4f\udbb4\udcfd\ud9fa\udea2\ud8be\udf00",
        35, 27196, -889144626, 8605053029273410874L, 82900L, false, true, (char) 52986, (char) 29074,
        Double.longBitsToDouble(0x3fe851373561567eL), Double.longBitsToDouble(0x3fc4bfa8bc1c07d4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 0, "\ud861\udc0b", "\000\000\u88c8\u414f\u00c4\000\u1639\u0946\ua7a1\u90e0\u1f74\000\000\ua720\000\000\000\u6c13\000\000\000", "\000",
        27, 19272, 0, 1929405024L, -100000L, true, true, (char) 63, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e442c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 1, "\udaeb\ude9d", "\ub455\u62c3\u1472\u7ee9", "\ud877\udc2a\udb1f\udecf\udbb5\udc3e\uda11\udda3\udafa\udcc0\ud9f3\udd98\ud8e0\udc88\ud9f9\udf27\uda53\udf08",
        37, 27448, 1750756371, -845841576853858823L, 88191L, false, true, (char) 7881, (char) 12129,
        Double.longBitsToDouble(0x3fef84c81a605601L), Double.longBitsToDouble(0x3fcfd4d19e699e40L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 5, 5, 1, "\ud855\ude0b", "\ub455\u62c3\uc718\u7ee9\u7459\u5d87\u50e1\u7125\ua7a1\u90e0", "\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\udb27\udd18\udb9b\udedf\udaa6\udd78\ue587\udbde\udf89\ud876\udd0f\uda2e\udcda\udaeb\udf07\ud986\udfe9\uda9f\ude17\uda1f\udc40\ud9cd\udd1a\ud9b3\udf18\udb1f\udd12\udb30\udcae\ud835\udc2b\udb38\udc5e\udbac\udd98\udacd\udca0\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00\udaa5\udc94\udabf\udd72\uda37\udd5e\uda95\udffb\udaa7\udc45\udb7b\udc9d\ud8b3\ude14",
        43, 36540, 2112313021, 2451127423500978903L, 68141L, false, true, (char) 52158, (char) 62381,
        Double.longBitsToDouble(0x3fe5d07a2867a77cL), Double.longBitsToDouble(0x3fcc27941c52bb2cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 5, 18, "\ud855\ude0b", "\ub455\u62c3\u1472\u7ee9\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0", "\ud8e0\udc88\ud967\udfbe\uda00\ude93\uda5a\udf7f\ud9a7\ude8b\ud92a\ude39\udb9b\udedf\ud995\udff0\uc9f6\udbde\udf89\udbd8\udca1\uda2e\udcda\udaeb\udf07\ud986\udfe9\uda60\ude71\uda1f\udc40\ud9cd\udd1a\ud9b3\udf18\ue1fd\udaf9\uddff\ud835\udc84\udb38\udc5e\udbac\udd98\udacd\udca0\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00\udaab\udfd8\udabf\udce0\uda37\udd5e\uda95\udffb\udaa7\udc45\udbdc\udecd\ud8b3\ude14",
        43, 36540, 2112313021, 2451127425177438423L, 14847L, true, true, (char) 52158, (char) 62381,
        Double.longBitsToDouble(0x3fe5d07a2ada0c79L), Double.longBitsToDouble(0x3fe000b12f14aecbL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=[B:[[-32, 88, -91, 44, 2, -59, -2, -4]] |a0=[B:[[-32, 88, -91, 44, 2, -59, -2, -4]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[-32, 88, -91, 44, 2, -59, -2, -4]] |a0=[B:[[-32, 88, -91, 44, 2, -59, -2, -4]]\012",
        Z.run(T, 2, 6, 16, 1, "\udb10\udd88\udbd5\udd5c\udb32\udcf5\ud92e\udf2c\ud80e\udd05\u5aa9\ud954\udc34\udbf7\udec0\ud9ee\uddd4\ud877\udc2a\udb1f\udecf", "\u35ad\u3a20", "\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\ud92a\ude39\udb9b\udedf\udaa6\udd78\ue587\udbde\udf89",
        11, 38983, -1404861982, -4005301198422871771L, -74816L, false, false, (char) 10026, (char) 57434,
        Double.longBitsToDouble(0x3fcedfc7f1244dc4L), Double.longBitsToDouble(0x3fbc5fa48493c608L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 5, 1, "\ud855\ude0b\ud92e\udf51\udb32\udd40\ud92e\udf2c\ud8bf\udc28\udb91\udd25\ud9af\udef7\udbf7\ude1e\ud98c\ude5d\udae5\udc67\udb1f\ude07\udbb5\udc3e\uda11\udda3", "\u1818\u33cd\ucc92\ua460\u2a11\ubb15\u953a\uc866\u68b4\u7ad6\ud6a3\u8113\u21c5\u7934\ud662\ua51e\u305b\u43bd\u179b\ubb68\u3206\u8595\u9c9a\u7588\uac63\ua53b\ub207\u7d64\uc104\ub84a\u2a75\u5905\uc29f\uc9d5", "\ud9af\ude28\ud88e\udd69",
        -3, 92938, 1928988971, -92399974144431158L, -57318L, true, false, (char) 46465, (char) 62943,
        Double.longBitsToDouble(0x3f5a37e16f7a7e00L), Double.longBitsToDouble(0x3fc7e06bdbd077b0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=[B:[[37, -37, -2, 33, 2, 16, -2, -4]] |a0=[B:[[37, -37, -2, 33, 2, 16, -2, -4]]\0121=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 0, 15, 4, "\ud855\ude0b\ud92e\udf51\udb32\udd40\ud92e\udf2c\udbfd\udefe\ud894\udda9\ud99d\udeae\ud89e\ude29\udb3c\ude50\ud983\udd5f\udb1f\udecf\ud97f\udd12\udbac\udc0e\uda32\udd7c\ud963\ude14\ud8e0\udc88\udafd\udf39\udb8e\ude8c\ud83a\udcc2\ud9a7\ude8b\ud92a\ude39\udb9b\udedf\ud9ac\udea4\udb02\udd7b\ud8b2\ude61\ud818\udff6\uda2e\udcda\udaeb\udeaf\ud986\udfe9\ud83d\udee7\ud970\udefd\uda74\udf59\ud9a9\udd0d\udaa7\ude55\ud893\udec0", "\u0f23\u3289\uac63\ua53b\ub207\u7d64\uc104", "\udaa7\udc45",
        25, 23089, 436973655, 3201109556694832829L, 14847L, true, true, (char) 10175, (char) 62375,
        Double.longBitsToDouble(0x3fe5d07a2867a77cL), Double.longBitsToDouble(0x3fe4c4ff5740dd4cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:???????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:???????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 8, 1, "\ud855\ude0b\udbc6\uddce\u15fb\ud92e\udf2c\ud80e\udd05\u5aa9\ud954\udc34\udbf7\udec0\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\udbb5\udc3e", "\u3a20\ua374\ua80a\u3644\u161e\u2a06\u17c1", "\ue587",
        31, 2671, -778814177, -3487895104668414160L, 24719L, false, false, (char) 38794, (char) 51498,
        Double.longBitsToDouble(0x3feed9440364683fL), Double.longBitsToDouble(0x3fb244c63e25ec90L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 1, "\ud902\udd15\udbf2\udd07\uda98\udd0e\udb92\ude8c\ud80e\udd05\u5aa9\ud954\udc34\udbec\udfc0\ud9ee\uddd4\ud905\udfd6\udb1f\ude5d\udbb1\ude1d\uda15\udf90\udafa\udcc0\ud963\ude6d\ud8e0\udc88\ud967\udfbe\udb8d\udf68\ud990\udf8d\ud92c\udcd8\udb52\ude0d\ud9e0\udde7\u1391\udafa\udc04\ud8fc\uddcd\ud876\udd0f\udb84\udf13", "\ud662\ua51e\u305b\u43bd\u179b\u8238\ud217\uc5f5\ua479\u7588\uac63\ua53b\u02c0\u0341\uc104\ub84a\u2a75\u5905\uac39\u746e\u1228\uc562", "\uda4a\udd5a\udbb1\udd7d\udbef\ude04\ud9e3\udde4\ud86e\udddb\udbb9\ude92\ud820\ude31",
        33, 92041, 1701857044, -8694271771955637100L, 331L, true, false, (char) 20875, (char) 47518,
        Double.longBitsToDouble(0x3fd14939aa443670L), Double.longBitsToDouble(0x3fb28b10521286c8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:=F2=84=9C=9E=E9=8D=9B=F3=9C=A4=95=F3=8E=B3=92=F0=93=BD=97=F3=87=BA=8C=F4=81=\015\012=83=88=F4=8D=BB=80=F2=8B=B9=84=F0=AD=B0=AA=F3=97=BB=8F=F1=92=89=89=F3=A4=84=\015\012=A6=F0=92=A8=B1=F1=80=8E=BB=F0=AC=82=90=F2=AD=BB=A9=F3=B7=8E=92=F0=A4=B4=A0=\015\012=F0=B2=B5=88=F2=93=BC=AE |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 12, 5, 18, "\ud9d1\udf1e\u935b\udb32\udd15\udafb\udcd2\ud80f\udf57\udadf\ude8c\udbc4\udcc8\udbf7\udec0\ud9ef\ude44\ud877\udc2a\udb1f\udecf\ud908\ude49\udb50\udd26\ud80a\ude31\ud8c0\udfbb\ud870\udc90\uda77\udee9\udb9c\udf92\ud853\udd20\ud88b\udd48\uda0f\udf2e", "\ub85b\u6957\u87ab", "\uda94\udcca\udb21\udd9a\ud87b\uded8\ud900\udd04\uda97\udd54\ud924\udf2b",
        9, 19036, 2093757513, -2337658333420187020L, -46154L, false, true, (char) 36031, (char) 39720,
        Double.longBitsToDouble(0x3f4fb5b9bc97b000L), Double.longBitsToDouble(0x3fedace7c6589dc2L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=[B:[[61, 56, 54, 69, 43, 61, 65, 54, 117, 61, 69, 66, 94, 61, 68, 69]] |a1=[B:[[-122, 69, 43, -90, 117, -21, 94, -34]]\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 19, 5, 10, "\udab6\udc75\ucd5b\ud8d6\udfa5\ud81b\udf8e\ud80e\udd05\udadf\ude8c\udbc4\udcc8\udbf7\udec0\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\uda12\ude13\uda11\udda3\udb07\udec0\ud969\ude70\ud8e0\udd2a\ud967\udfbe", "\ua665\u2a01\uc698\u6456\ub85b\u6957\u87ab\u8113\ua1ff", "\uda1f\udc40\ue92f\uda97\udd54\u3462\udaf9\uddff\uda8d\udcc6\udb30\ude6f\udbac\udce0\udad8\udea0",
        38, 80328, -1985080443, -7043458855606740668L, -19998L, true, false, (char) 32180, (char) 64098,
        Double.longBitsToDouble(0x3fea36ed47fd1a81L), Double.longBitsToDouble(0x3fc8997c118e24acL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String:=F2=BD=A1=B5=E9=8D=9B=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F1=A0=82=BC=F2=86=\015\012=A1=8A=F3=A1=AB=AB=F2=8A=92=A7=F1=92=A4=A1=F2=B3=93=91=F3=BC=A7=9A=F2=94=96=\015\012=A3=F3=91=BB=80=F1=8F=9D=94=F1=A9=A6=82=F1=A9=BD=96=F3=B7=8E=92=F0=9E=A3=82=\015\012=F1=B9=BA=8B=F1=9A=A8=B9=F3=AA=BF=9F=F2=B9=85=B8=EE=96=87=F3=B2=97... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 5, 10, "\udab6\udc75\u935b\udb32\udd15\ud92e\udf2c\ud80e\udd05\ud940\udcbc\ud9da\udc4a\udb46\udeeb\ud9e9\udca7\ud90a\udd21\uda8d\udcd1\udbb2\uddda\uda11\udda3\udb07\udec0\ud8fd\udf54\ud966\udd82\ud967\udf56\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\ud92a\ude39\udb6b\udfdf\udaa4\udd78\ue587\udb89\uddc2\ud876\udd0f", "\ubd4e\ud662\ua51e\u434f\ua057\u49ff", "\udb38\udc5e",
        10, 9308, -1098225159, -8204663889296541765L, 90140L, false, true, (char) 58548, (char) 7891,
        Double.longBitsToDouble(0x3fc99d8802d8fd00L), Double.longBitsToDouble(0x3fb23b17a879ea70L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:=F2=BD=A1=B5=E9=8D=9B=F3=9C=A4=95=F1=9B=AC=AC |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 5, 10, "\udab6\udc75\u935b\udb32\udd15\ud92e\udf2c", "\u4205\u7459", "\udb1f\udecf",
        43, 57053, 669207655, -275187251321541049L, 52614L, false, true, (char) 23230, (char) 12636,
        Double.longBitsToDouble(0x3fe48b42d752e503L), Double.longBitsToDouble(0x3fe399daf08d343cL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String:=F3=AF=A1=90=E9=8D=9B=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F2=99=BA=89=F4=81=\015\012=83=88=F4=8D=BB=80=F2=8B=A7=94=F0=A8=94=AA=F3=97=BB=8F=F3=BD=90=BE=F3=AA=AB=\015\012=A1=F3=9A=AC=8D=F4=82=A0=99=F1=88=82=88=F1=A9=BE=BE=F3=B7=8E=92=F0=9E=A3=82=\015\012=F1=B9=BA=8B=F1=9A=A8=B9=F3=AA=BF=9F=F2=B9=A5=B8=F1=9F=96=AA=F3=B2... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 5, 10, "\udb7e\udc50\u935b\udb32\udd15\ud92e\udf2c\ud80e\udd05\uda27\ude89\udbc4\udcc8\udbf7\udec0\ud9ee\uddd4\ud861\udd2a\udb1f\udecf\udbb5\udc3e\udb6a\udee1\udb2a\udf0d\udbca\udc19\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\ud92a\ude39\udb6b\udfdf\udaa6\udd78\ud93d\uddaa\udb89\uddc5\ud876\udd0f\uda2e\udcda\udaeb\udf07\ud986\udfe9\uda9f\ude17\uda1f\udc40\ue92f\uda97\udd54\u3462", "\u858d", "\ud9a3\ude1d\ud9fc\udf42\ud8be\udf00\ud9d9\udc2f\udbc3\udf01\ud8e9\udda0\udab5\udd7b\ud84b\udfe7\udb2d\udf85\ud835\udc8d\ud807\uded8\ud883\udc69\ud9a2\ude0b\ud9fe\udca2",
        14, 22533, -595887223, 2817313309213038434L, -24992L, true, false, (char) 55842, (char) 38985,
        Double.longBitsToDouble(0x3fe7b099067a999aL), Double.longBitsToDouble(0x3fe0a04c24ed5f54L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String:=F2=B2=95=A6=E9=8D=9B=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F3=87=BA=8C=F4=81=\015\012=83=88=F4=8D=BB=80=F2=8B=A7=94=F0=AD=B0=AA=F3=97=BB=8F=F3=BD=90=BE=F2=94=96=\015\012=A3=F3=91=BB=80=F1=A8=B9=AD=F1=88=82=88 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 5, 10, "\uda89\udd66\u935b\udb32\udd15\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8\udbf7\udec0\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\udbb5\udc3e\uda11\udda3\udb07\udec0\ud963\ude6d\ud8e0\udc88", "\u161e\u2a06\u17c1\u72a6", "\udb89\uddc2\ud876\udd0f\uda2e\udcda\udaeb\udf07\ud986\udfe9\uda9f\ude17\uda1f\udc40\udba6\uddc5\u343a\uda73\udfe1\udaf9\uddff\ud835\udc84\udb38\udc5e\udbac\udd98\udacd\udca0\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00",
        35, 54124, 1128083266, 6305229314743728611L, -69180L, true, true, (char) 32438, (char) 41103,
        Double.longBitsToDouble(0x3fe6b2080059a6dfL), Double.longBitsToDouble(0x3febee2a783d3d0aL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.String:=F0=99=96=88=F2=84=97=A7=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F3=87=BA=8C=F4=\015\012=81=83=88=F4=8D=BB=80=F2=8B=A7=94 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 5, 10, "\ud825\udd88\ud9d1\udde7\udb32\udd15\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8\udbf7\udec0\ud9ee\uddd4", "\ub59e", "\ud9f0\uddb3\ud8fe\uddd8\ud967\udfbe\udae1\udebe\ub27c\udb19\uddf4\ud88f\udf57",
        26, 57158, 876362355, 6371028375051865223L, -60822L, true, true, (char) 47099, (char) 55263,
        Double.longBitsToDouble(0x3fe7e0870f4b50afL), Double.longBitsToDouble(0x3fe8e2b7cc49f2e4L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:=F2=BD=A1=B5=E9=8D=9B |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 5, 10, "\udab6\udc75\u935b", "\u62c3\u4aab\u4205\u7459\u2101\u584b\u706b\u4fde\u6962\ua8b5\u3a20", "\udb9c\udf92\ud83a\udcc2\ud9a2\udd6f\ud92a\ude39\udb6b\udfdf\udaa6\udd78\ud849\udd9e\ud835\udd6f",
        37, 3684, -812088862, -4005138021752805642L, -9280L, false, false, (char) 10976, (char) 57434,
        Double.longBitsToDouble(0x3feb2341fc491318L), Double.longBitsToDouble(0x3fee25ec92dc1f15L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String:=F2=BD=A1=B5 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 12, 5, 10, "\udab6\udc75", "\ub455\u62c3\u4aab\u4205\u7659\u165d\u50e1\u7125\ua7a1\u90e0\u6bad\u3a20\u83a0\ua80a\u3644\u8160\u22e1\u3425\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        32, 29169, 1442965295, 8325293550910661718L, 44457L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8adf92e98L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String:=F4=8B=A6=9D=E9=8D=9B=F3=9C=A4=95=F1=9B=AC=AC=F3=AC=A8=91=F3=87=BA=8C=F1=83=\015\012=BB=8D=F0=BC=AD=9D=F2=8B=A7=94=F0=AD=B0=AA=F3=97=BB=8F=F3=BD=90=BE=F3=B6=8C=\015\012=99=F1=94=B9=A5=F0=93=B2=B1=F1=88=83=AB |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[61, 66, 69, 109, 43, 61, 48, 50, 61, 69, 53, 61, 70, 69, 61, 70, 67, 66]] |a1=[B:[[-66, 109, 43, 2, -27, -2, -4, 66]]\012",
        Z.run(T, 2, 12, 3, 10, "\udbee\udd9d\u935b\udb32\udd15\ud92e\udf2c\udb72\ude11\udadf\ude8c\ud8cf\udecd\ud8b2\udf5d\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\udbb5\udc3e\udb98\udf19\ud913\ude65\ud80f\udcb1\ud8e0\udceb", "\u161e\u2a06\uc34e\u72a6", "\udb89\uddc2\ud876\udd0f\uda2e\udcda\udaeb\udf07\udbf4\uddf2\uda9f\udda3\uda1f\udc40\udac5\udcc8\uda97\udd54\ud804\udf79\udaf9\uddff\ud835\udc84\udb38\udc5e\udbac\udd98\ud9cf\udca1\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00",
        25, 81196, 1877123503, 1768131527026617931L, 39218L, false, false, (char) 36191, (char) 26674,
        Double.longBitsToDouble(0x3fb0e5586158c4b8L), Double.longBitsToDouble(0x3fd741b3155225f4L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.String:? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 7, 3, "\udab6\udc75", "\ub455\u62c3\u39c8\u7280\u1b42\u33c9\u2b3b\u7125\ua7a1\u90e0\u6bad\u3a20\u83a0\ua80a\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        2, 64102, 1442965295, 8325293550910661718L, 17540L, false, true, (char) 12785, (char) 60,
        Double.longBitsToDouble(0x3fdaabe8af51ae46L), Double.longBitsToDouble(0x3fedf588094481e4L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 12, 12, 11, "\udab6\udc75\udaf3\udc21\ud9c0\udf8d\ud92e\udf2c", "\u4205\u7459", "\udb1f\udecf\ud8e4\udf9c\ufee3\udb07\udec0\ud963\ude6d\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b",
        21, 63265, 996054521, 3763947655653912717L, 88191L, false, true, (char) 40698, (char) 59046,
        Double.longBitsToDouble(0x3fe97bc81a605601L), Double.longBitsToDouble(0x3fb59ce24ff88708L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String:=F2=BD=A1=B5=E9=8D=9B=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F3=87=BA=8C=F4=81=\015\012=83=88=F4=8D=BB=80=F2=8B=A7=94=F0=AD=B0=AA=F3=97=BB=8F=F3=BD=90=BE=F2=94=96=\015\012=A3=F2=90=A3=BD=F1=A8=B9=AD=F1=88=82=88=F1=A9=BE=BE=F3=B7=8E=92=F0=9E=A3=82=\015\012=F1=B9=BA=8B=F1=9A=A8=B9=F3=AA=BF=9F=F2=B9=A5=B8=F0=90=AE=87=F3=B2... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[-122, 69, 43, 2, -27, -2, -4, -34]] |a0=[B:[[-122, 69, 43, 2, -27, -2, -4, -34]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 12, 6, 10, "\udab6\udc75\u935b\udb32\udd15\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8\udbf7\udec0\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\udbb5\udc3e\uda11\udda3\uda02\udcfd\ud963\ude6d\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\ud92a\ude39\udb6b\udfdf\udaa6\udd78\ud802\udf87\udb89\uddc2\ud876\udd0f\ub14a\uda07\udd3d\ud9b1\uddce\uda9f\ude17\uda1f\udc40\ue92f\udbd5\udd53\u3462\udaf9\uddff\ud835\udc84", "\u7588\uac63\ua53b\ud5e2\uae47", "\ud825\ude73\ud904\udf25\uda81\ude7a\ud974\udd16\udb79\udce0\u081c\ud853\udc5a\udb2f\udcce",
        27, 172, 478837769, 3631774998315703516L, -90910L, false, true, (char) 63610, (char) 63479,
        Double.longBitsToDouble(0x3fae1b33eb8864f0L), Double.longBitsToDouble(0x3fe5f68ae4ef2e6aL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 11, 18, "\ud861\udc0b", "\u2e44\uca2d\u4a9d\u4205\u7459\ua9ad\u6895\u7092\ua7a1\ud1de\u35ad\u3a20\u83a0\uaf76\u3644\u161e\u2a06\u17c1\u72a6\u6456\u026d", "\ud9fb\ude61\udaeb\udf07\ud986\udfe9\uda9f\ude17\uda01\udcbb",
        15, 15371, 679483903, -8484861021848181716L, 94620L, false, false, (char) 60, (char) 60468,
        Double.longBitsToDouble(0x3fe186b91bbeb1a9L), Double.longBitsToDouble(0x3fd4481e4b6f1578L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 15, 15, 10, "\ud861\udc0b", "\ub455\u62c3", "\udbf7\udec0\uda9b\udd0d\uda22\udfc0\ud9ae\udc01\udbb5\udc3e\ud82f\udf30\udafa\udcc0\ud963\ude6d\ud8e0\udc88\ud914\udefc\udb9c\udf92\u20ad\ud9b1\udc73\ud92a\ude39\udb6b\udfdf\udaa6\udd78\ud8a5\udede\udb89\uddc2\ud876\udd0f\uda2e\udcda\udaeb\udf07\ud986\udfe9\uda9f\ude17\uda1f\udc40\udbf7\udf8f\udaa4\ude7c",
        28, 23347, -131177428, -4786705965282687036L, 3943L, false, true, (char) 2388, (char) 36199,
        Double.longBitsToDouble(0x3fd4481e49dc0634L), Double.longBitsToDouble(0x3fb98eb4a4461c70L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.String:=F3=BB=8A=B1=F3=8A=A0=BA=F2=88=8E=A7 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[124, -127, -70, -80, 119]] |a0=[B:[[124, -127, -70, 10, -80, 119]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 6, 15, "\udbac\udeb1\udaea\udc3a\ud9e0\udfa7", "\u4a9a", "\ud8b2\udd19\uda6d\udcd2\udb1f\ude3c\udbb5\udc3e\ud82f\udf30\udafa\udcc0\ud963\ude6d",
        21, 31138, 1883876314, 1366543026362250440L, 45611L, true, true, (char) 9370, (char) 64688,
        Double.longBitsToDouble(0x3fc0eb0d5c7d3398L), Double.longBitsToDouble(0x3fde295a6e619f30L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.String:=F0=A8=90=8B=EA=89=AF=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F3=87=BA=8C=F4=81=\015\012=83=88=F4=8D=BB=80 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Integer:49 |a1=[B:[[49, -37, 63, 2, -27, -2, -4, -34]]\012",
        Z.run(T, 2, 11, 4, 7, "\ud861\udc0b\ua26f\udb32\udd15\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8\udbf7\udec0", "\u7092\ua7a1\ud1de\u35ad\u3a20\u83a0\uaf76\u3644\u161e\u2a06\u17c1\u72a6\u6456\u026d\u6957\u87ab\u8113", "\uda9f\ude17\uda1f\udc40\udbf7\udf8f\udaa4\ude7c\u3462\uda0c\udcea\ub3b6\udb38\udc5e\udbac\udd98\udacd\udca0\ud9a3\ude1d\ud9fa\udf41\ud851\udd92\ud9d9\udc4f\uda20\ude91\ud942\udcca\uda71\udcee\ud896\udd45\ud985\udf80\uc06b\uda35\udfc9\ud937\udf93",
        0, 12220, 579898162, 9059875157261240449L, -19941L, true, true, (char) 10194, (char) 61832,
        Double.longBitsToDouble(0x3fd4a04e8afecdf0L), Double.longBitsToDouble(0x3fda2db4ae193ec6L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.String:?\000??????????????????????????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 15, "\u00a7\000\udb29\udd93\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8\udbf7\udec0\uda5f\udf2d\ud93a\udc3c\udb1f\udecf\udbb5\udc3e\uda11\udda3\udafa\udcc0\u56a7\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\ud927\udc18\ud9e4\ude72\udb07\ude40\udb7f\udfb1\udab9\udc47\ud8cb\udd1b\ud978\udfd7\ud8f4\uddcf\ud824\udff0\udb89\udfca\udb3f\udd47\ud88d\udcae\udbd6\udfc5", "\u5e26\ud179", "\ud9a3\udca0\udb6b\udc46\ud907\udfdd",
        13, 96114, 1253218464, -1208265738007907459L, -74895L, true, false, (char) 14902, (char) 40701,
        Double.longBitsToDouble(0x3fd77a577550cf16L), Double.longBitsToDouble(0x3fc3df2f14dd1e84L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=[B:[[119, 61, 68, 48, 61, 70, 57, 99, 61, 70, 69, 61, 70, 67, 50, 61, 70, 69]] |a1=[B:[[119, -48, -7, 99, -2, -4, 50, -2]]\0121=[B:[[119, 61, 68, 48, 61, 70, 57, 99, 61, 70, 69, 61, 70, 67, 50, 61, 70, 69]] |a1=[B:[[119, -48, -7, 99, -2, -4, 50, -2]]\012",
        Z.run(T, 2, 3, 19, 10, "\u00a7\000\udb29\udd93\ud92e\udf2c\uda62\udd2e\udb1f\ude42\udbef\udcd4\udbf7\udec0\uda5f\udf2d\ud93a\udc3c\udb1f\udecf\udbb5\udc3e\uda11\udda3\udafa\udcc0\u56a7\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\ud927\udc18\udbaf\uded7\ud814\udf95\ud968\uddeb\uda42\udc38\ud835\udd50\u90f9\ubeaf\udb90\ude6c\udb52\udf9e\udb54\udc57\ud9ec\udfb4\ud82b\ude66\udab0\ude00\udab4\udedd\u8bda\ud923\ude1a\ud9d4\uddc6\ud9ab\udd54\udab8\udd13\ud88a\uddea\ud95f\udd20\ud883\ude26\udaf5\udd5b\ud873\udf4a\ud94a\udcfb", "\ubf94\uc3d8\ubb34\ua6ec\u215c\ubaf3\u561d\ub06b\u1c4b\u1232\ud39f\u6b7f\u174e\u6de3\u6606\u60cd\u2c37\u9633", "\udb2d\udcfc\ud97b\udc2a\udbdf\udd3a\uda77\udcf2\ud92c\udd69\udb2c\uddf6\ud978\udf90\udbb7\uddf6",
        -3, 11804, 859084062, -4203176381890551602L, -43379L, false, true, (char) 43389, (char) 36510,
        Double.longBitsToDouble(0x3fc6339dd18504e0L), Double.longBitsToDouble(0x3fc2955367b0cdc8L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.String:????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 0, "\ud851\udeb8\015\uda12\udeb6\ud92e\udf2c\ud80e\udd05\ud953\udc49", "\ub785\u8cbd\u7125\u7caa\u7266\u35ad\u56a7", "\udb9c\udf92\uda33\udcff\ud9a7\ude8b\ud977\udf61\udb22\ude70\udb7c\udf2b\ud8d2\udd63\ud82b\ude62",
        15, 53714, 508577885, 5078216108498801428L, 67206L, false, false, (char) 59041, (char) 45288,
        Double.longBitsToDouble(0x3fa5538a3bdf2c40L), Double.longBitsToDouble(0x3feb1b7ed4f19152L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Integer:221 |a1=[B:[[27, -35]]\0121=java.lang.Integer:221 |a1=[B:[[27, -35]]\012",
        Z.run(T, 2, 4, 4, 20, "\ud94b\udc0d", "\u10fc\u97f7\u606d\u24fb\u8816\u01fc\u2a6b", "\ua987\ud95b\ude3d\u56a7\ud8e0\udc88\ud967\udfbe\u6a91\ud941\udf95\ud9a7\ude8b\ud927\udc18\ud80d\udd65\udba2\uddff\ud9a0\udef8\udbaa\udf22\udb50\udf8a\udb81\udc58\udace\udf6a\ud955\ude68\uda99\uddbd\udbef\udfc2\udb2c\udf79\udaee\udf4c\uda07\udeed\ud9c9\udf73\ud9cb\ude11\udb16\udeaf\uda72\udecc\ud9ab\udee3\ud806\ude6b\udbb4\udd15",
        1, 79865, -1748450094, -8032795492281863204L, 20113L, false, false, (char) 8188, (char) 32841,
        Double.longBitsToDouble(0x3fe7c79ba33e4db1L), Double.longBitsToDouble(0x3fcd364fb47c1638L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=[B:[[119, 61, 49, 51, 61, 55, 70, 73, 61, 51, 68, 61, 66, 56, 102, 61, 67, 67]] |a1=[B:[[119, 19, 127, 73, 61, -72, 102, -52]]\0121=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 3, 6, 13, "\u00a7\ub843\udbaf\ude79\udb6d\udce8\udb96\uddfc", "\u5122\ub785\u8cbd\ubf70\u2ebd\u5280\u35ad\u56a7\u80f5\ua80a\u209c\u161e\u2a06\u247e\u9927\u4370\u991f\u4cb6\u6446\u32e8\u4ded\u1fe5\ua70e\u9dff\u0d51\u4366", "\udaf0\udc1e\ud8be\ude0a\ud84d\udc84\ud840\uddb8\ud8b5\udc2a\ud879\udfa7\udb00\udcdd\udbb0\udec8\ud9a3\udec4\ud811\udf2e\udb7b\udd7e\udad2\udc6f\ud901\udf59\udb41\udd4c\ud945\udca3\uda0d\udf12",
        55, 23023, 1200523577, -7866628263735492281L, 91205L, false, false, (char) 46165, (char) 22577,
        Double.longBitsToDouble(0x3fe4a4e2da048043L), Double.longBitsToDouble(0x3fd08ca316613450L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=null\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 19, 10, 19, "\ud8d5\udfb8\ua35e\udb32\udd15\u2dc3\uda8e\uddc4\udaa6\uddb2\ud9c6\udc09\udbf7\ude67\ud9ee\uddd4\uda8a\udd3e\ud9da\udcfa\udbb5\udcb3\uda11\udda3\udafa\udcc0\ud963\ude6d\udbc1\udfb4\udae0\udcee\udb13\udc1e\ud800\ude4d\udbf1\udc4f\uda0e\udc47\ud81f\udfc4\ud8d1\uddea\ue587\udb89\uddc2\udb99\udc38\udaa9\udfb1\udaeb\ude4d\ud987\udcab\uda9f\ude17\ud8fb\udd6e\ud922\ude33\uda77\udd50\ud9ef\udc82\udaf6\uddff", "\u2b5f\u7588\ubb11\ua9fd\u86ae\u36a5\u3574\u9949\u2848\u1774\u9b2c\uaaa4\u4ab5\u72b6\u24ab", "\ud95a\udc21\ud81b\ude5e\ud88f\ude56\u9d90",
        34, 72886, -1781606162, 8506265691793482191L, 94257L, false, false, (char) 38357, (char) 56809,
        Double.longBitsToDouble(0x3fea2bad1fafdf1aL), Double.longBitsToDouble(0x3fe277e148c6f284L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=[B:[[61, 66, 69, 68, 108, 91, 61, 66, 57, 61, 49, 53, 61, 56, 50, 126]] |a1=[B:[[-66, 68, 108, 91, -71, 21, -126, 126]]\0121=[B:[[61, 66, 69, 68, 108, 91, 61, 66, 57, 61, 49, 53, 61, 56, 50, 126]] |a1=[B:[[-66, 68, 108, 91, -71, 21, -126, 126]]\012",
        Z.run(T, 2, 19, 19, 11, "\u56ee\ua274\uda9c\udf8b\udbe9\udc45\udab2\udcae\uda70\udfb6\ud97c\ude76\ud8c7\udf27\ud9ee\uddd4\udb0e\udf6d\udb9f\udf1c\udbb5\udc3e\uda11\udda3\udafa\udcc0\ud963\ude6d\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\023\000\000\ua314\udb89\uddc2\ud876\udd59\udb2b\udd18\udaeb\udf07\ud986\udfe9\uda9f\ude17\uda1f\udc40\ue92f\udaa4\ude54\uda0a\udcbf\udaf9\udd73\ud835\udc84", "\uc40c\u69f9\ua491\ub207\u03bf", "\udb6e\udf64",
        40, 5740, -1664666592, 7791941437721466355L, -91619L, true, true, (char) 11909, (char) 27350,
        Double.longBitsToDouble(0x3f9e4ca3d145b260L), Double.longBitsToDouble(0x3fd06ce82543392aL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=[B:[[49, 61, 68, 66, 63, 61, 48, 56, 105, 9, 61, 69, 55, 61, 48, 54]] |a1=[B:[[49, -37, 63, 8, 105, 9, -25, 6]]\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 5, 0, "\ud861\udc0b\ua26f\udb38\udd99\ud939\udf17\ud936\udd4d\udbd8\udf2f\ud86f\udd53\udb13\ude84\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\ud897\udcf0\udbf8\udc37\ud88a\udeea\ud953\udff3\uda4a\udf88\udb5f\udd95\udbae\udc32\ud83a\udcc2\ud9a7\ude8b", "\000", "\ud876\udd0f",
        58, 51138, -15839440, -7484671376029292478L, 4790L, true, true, (char) 57434, (char) 13219,
        Double.longBitsToDouble(0x3fb244c63e25ec90L), Double.longBitsToDouble(0x3fe6e0f8a9f99642L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 0, "\uda07\udd80\udab6\ude07\ud938\udf65\ud825\udc11\ud9cb\udd86\udadf\ude8c\u14e9\udbf7\udec0\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\udbb5\udc3e", "\u3a20\u95fe\u6797", "\ud9a7\ude8b\u89ff\000",
        -5, 70392, 1483370637, 5541270901190221599L, 45883L, false, false, (char) 3295, (char) 39346,
        Double.longBitsToDouble(0x3feed9440364683fL), Double.longBitsToDouble(0x3fb244c63e25ec90L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 5, 15, "\udaf3\udc74\ud889\udd8d\udb32\udd15\ud930\udca8\ud940\udc62\udac3\ude39\ud911\udf4f\ud999\ude04\uda46\udf00\udab3\udf9d\udba5\udfd9\ud902\uddc5\ud9e9\udf8d\udafa\udcc0\ud984\udef5\ud8e0\udc88", "\u161e\u7118\u17c1\u72a6\u6456\ub85b\u4ef8\u738b", "\ud3ab\uda65\udca5\uda1f\udc40\ue92f\ud98b\udcc8\udb43\udc21",
        9, 19036, -1113669815, 2239704926307619548L, -90718L, true, true, (char) 43557, (char) 39374,
        Double.longBitsToDouble(0x3fb5aac503d7ae40L), Double.longBitsToDouble(0x3fd08457826988c0L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=[B:[[49, 61, 68, 66, 61, 65, 49, 61, 66, 50, 61, 67, 48, 61, 49, 65, 61, 70, 54, 61, 48, 57]] |a1=[B:[[49, -37, -95, -78, -64, 26, -10, 9]]\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 19, 5, 14, "\ud861\udc0b\udad1\udfe2\udaf0\udf4a\ud926\ude39\ud810\udfdd\udadf\ude8c\udbc4\udcc8\udbf7\udec0\u7f9f\ud83c\udca1", "\u1777\u35ad\u94ca\uad3f\ua80a\u3644\u107d\u30df\uab8a\u2ac5\uaf7e\u7d23\u12c3\u8808\u27a4\u7083\uc2ae", "\u93a1\ud8ac\udc3c\udb40\udf95\ud8b4\udebe\ud966\uded3\ud86a\udeb9",
        5, 24713, -1106860022, -2944459524527794952L, 24604L, false, true, (char) 49273, (char) 39236,
        Double.longBitsToDouble(0x3fe4b72e8aed8cddL), Double.longBitsToDouble(0x3feb921ea855cec9L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=[B:[[49, -37, 63, 43, 79, -18, -4, -34]] |a0=[B:[[49, -37, 63, 43, 79, -18, -4, -34]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[49, -37, 63, 43, 79, -18, -4, -34]] |a0=[B:[[49, -37, 63, 43, 79, -18, -4, -34]]\012",
        Z.run(T, 2, 6, 16, 18, "\ud861\udc0b\ua26f\udb5b\udc7f\ud91e\udd2c\ud80e\udd05\udb6d\udfd0\udbc4\udcc8\udbf7\udec0\u7f9f\udb3d\udc00\ud8a0\ude0b\ud81f\ude77\uda11\udda3\udafa\udcc0\ud9d4\udfc6\uda40\ude56\ud851\uddb2\uda05\ude80\ud83a\udcc2\uda3d\udc15\ud8f7\udec1\ud8c8\udfe2\uda66\ude88\udb6c\udf51\ud8fa\udce6\udb89\udcfa\ud8d1\udfcc\udbd6\udc7e\ud9aa\udf3f\uda9f\ude17\udaad\ude47\u93a1\ud8ac\udcc0\udb40\udf95\udaf9\uddff\ud918\udd66\udb38\udc5e\udbac\udd98\ud90b\udcbe\ud8db\udf85\ud9fa\udf41\ud8be\udf00\ud9d9\udc4f\ud997\uddcb\ud95f\udeb9\uda10\udd9b\udbec\udd04\udb96\udd92\ud90d\uddb8\ud946\udf47\udb4e\udc36\ud953\udc22\udac8\udd37\ud8de\udfc7\ud892\udf84\udafb\udeba\uda3d\uddd1\ud883\udce4", "\u73fc\u9b2f\u4c48\u197a\u4ad8\ucedb\u3562\u282b\u4444\u1377\u8ff5\u7ff0\u9357\u24ce\ud0d6\u4084\u6e0d\u828f\u951e\u40c2\u6b88\u779f\ub364\u21d9\u8ad1\ubb6a\u15e6\u26f7\u9707\u4016\uba11\uab7a\u46e5\u04a2\ub88f\u5125\u18e2\u877c\u45c6\u0246\u79d4\u633b\u22d2\u1175\u586b\u27df\u8f0f\u0789\u290a\u7cdb\u3b8b\u9a62\uac11\u072d\u2c23\u57c7\u43bf\u22ea\u596e\ua13b\u3dec", "\ud996\udd86\udb37\udc9d\ud94f\uddf3\ud84f\udd67\uda3c\udcf2\ud8e9\udcac\ud8c6\udf11\ud9b0\udc6b\ud9ac\udc49",
        -3, 38211, -774570115, -5464029819979214432L, -58346L, false, true, (char) 8183, (char) 21984,
        Double.longBitsToDouble(0x3fef4475f3c750b2L), Double.longBitsToDouble(0x3fea4e79b08342d4L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:=F0=A8=90=8B=EA=89=AF=F3=9C=A4=95=F1=97=A4=AC=F0=93=A4=85=F3=87=BA=8C=F4=81=\015\012=83=88=F4=8E=9F=80=E7=BE=9F=F0=9F=82=A1=F0=B8=88=8B=F0=97=B9=B7=F2=94=96=A3=\015\012=F3=8E=A3=80=F4=87=91=BD=F1=8C=A5=83=F3=89=8E=B3=F3=B7=8E=92=F0=9E=A3=82=F2=\015\012=9F=90=95=F1=8D=BB=81=F1=9F=9D=9C=F3=80=A8=86=F2=9A=B9=8F=F3=AD=AE... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F0=A8=90=8B=EA=89=AF=F3=9C=A4=95=F1=97=A4=AC=F0=93=A4=85=F3=87=BA=8C=F4=81=\015\012=83=88=F4=8E=9F=80=E7=BE=9F=F0=9F=82=A1=F0=B8=88=8B=F0=97=B9=B7=F2=94=96=A3=\015\012=F3=8E=A3=80=F4=87=91=BD=F1=8C=A5=83=F3=89=8E=B3=F3=B7=8E=92=F0=9E=A3=82=F2=\015\012=9F=90=95=F1=8D=BB=81=F1=9F=9D=9C=F3=80=A8=86=F2=9A=B9=8F=F3=AD=AE... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 11, 18, "\ud861\udc0b\ua26f\udb32\udd15\ud91e\udd2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8\udbf9\udfc0\u7f9f\ud83c\udca1\ud8a0\ude0b\ud81f\ude77\uda11\udda3\udafa\udcc0\udbdd\udc7d\ud8f2\udd43\udae4\udfb3\udb9c\udf92\ud83a\udcc2\uda3d\udc15\ud8f7\udec1\ud93d\udf5c\udac2\ude06\uda2b\ude4f\udb76\udf80", "\uc2bd\ubd4e\ud662", "\ud8ac\udc3c\udb40\udf95",
        46, 62812, -1114491831, 2239704926307619548L, -46154L, false, true, (char) 36031, (char) 39720,
        Double.longBitsToDouble(0x3fe82266d56cfb0dL), Double.longBitsToDouble(0x3fcfd1c8da591a58L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=[B:[[49, 61, 68, 66, 61, 67, 57, 61, 65, 53, 61, 68, 48, 102, 61, 69, 69, 61, 65, 51]] |a0=[B:[[49, -37, -55, -91, -48, 102, -18, -93]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[49, 61, 68, 66, 61, 67, 57, 61, 65, 53, 61, 68, 48, 102, 61, 69, 69, 61, 65, 51]] |a1=[B:[[49, -37, -55, -91, -48, 102, -18, -93]]\012",
        Z.run(T, 2, 10, 3, 17, "\ud861\udc0b\udaf9\udfd5\ud800\udd96\ud91e\udcd3\udbd0\udfa5\udbf9\udf44\udbcd\udcdc\ud852\udda8\ua1e9\uda78\udc5f\udbd0\uddbc\ud882\udd1d\udb25\udfee\ud80e\udd99\uda83\udc33\udbb4\uddcc\ud967\udfbe\ud952\ude40\ud83a\udc5c\uda3c\udfdc\ud897\udc10\udb3e\udc5c\udac2\uddb6\ud92e\ude51\uda4b\udecb\ud876\udd13\ud8ea\ude2e\uda02\ude54\uda60\ude28\udb63\udebf\udae7\ude44\u93a1\ud88e\udcfe\ud8ec\udd93\ud860\udd15\ud986\udf02\udba0\udfec\udbac\udd98\ud991\udda2\ud87b\udcb5\ud802\udcc9", "\uc739\u5c2f\u07ee\u7011\ub431\ub2a6\u271e", "\uda00\udce0\ud82b\ude6a\ud8ad\udf05\ud8b3\udfdb\udbef\uddd0\udb63\ude3e\ud82c\udf83\ud86f\udf96\uda5c\udc9d\uda4c\udec0\uda71\udd78\udbf4\udd71",
        3, 35125, -633585208, -8006779346068749063L, 45662L, false, false, (char) 36444, (char) 61728,
        Double.longBitsToDouble(0x3fe223ec2acff577L), Double.longBitsToDouble(0x3fe7e2647fa325bbL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=[B:[[41, 52, 76, 91, 105, 61, 69, 67, 61, 70, 69, 61, 70, 67]] |a1=[B:[[41, 52, 76, 91, 105, -20, -2, -4]]\0121=[B:[[41, 52, 76, 91, 105, 61, 69, 67, 61, 70, 69, 61, 70, 67]] |a1=[B:[[41, 52, 76, 91, 105, -20, -2, -4]]\012",
        Z.run(T, 2, 19, 3, 4, "\ud859\udc64\uda7c\ude8b\udb99\udc1c\ud92e\udf2c\udb5a\udc33", "\u5738\u3894\ud5df\uc9d4\u9cf4", "\udac0\udf1b\ud8e0\udc88\ud967\udf82\udbc8\udea3\ud9b1\udd00\ud9a7\ude8b\ud92a\ude39\ud9a2\udc3a\ud9b4\udd35\udacb\udcd6\udbd5\udfa9\uda4f\udc7b\udbb4\udcca\ud8b8\udccc\ud95a\udfb1\ud896\udd71\uda4d\ude19\ud876\udd0d\uda96\udddc\ud84b\ude7b\udbc6\udf5c\ud952\ude18\ud95e\udc16\ud993\ude7f\ue0d4\ub24f\udbc0\ude0c\udad1\uddc0\ud9e1\udf87\ud8a2\udcb7\ud957\udc8d\ud9ca\udeb8\uda56\udd14\ud9ca\ude63\ud8db\udc59\ud9f6\udc7b\udb3c\udd5a\ud908\udf19\udabf\udcba\uda54\udc7a\ud954\ude0e\udab9\udf2a\udb02\udcdd\ud9af\udc5e\udbd8\udc20\udadc\uddfe\uda16\udeea\ud918\udff3\u5b1a\ud9a6\udcf7\udb01\udecf",
        44, 51378, 53935837, -7160647898577691416L, 53904L, true, true, (char) 13681, (char) 47665,
        Double.longBitsToDouble(0x3fb433128e3abfc8L), Double.longBitsToDouble(0x3fe920c4b31ddd0fL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.String:=F0=AF=AC=8F=F0=AB=BA=88=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F3=87=BA=8C=F2=\015\012=B8=83=96=F2=A9=B8=A6=F2=8B=A7=94=F0=AD=B0=AA=F4=8B=B0=B7=F3=BD=92=B2=F2=94=\015\012=96=A3=F3=8E=A3=80=F1=A8=B9=AD=F1=88=82=88=F1=A9=BE=BE=F3=B7=8E=92=F0=9E=A3=\015\012=82=F1=B9=BA=8B=F1=9A=A8=B9=F3=84=BF=B2=F2=BD=A9=80=EE=96=87=F3=B2... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F0=AF=AC=8F=F0=AB=BA=88=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F3=87=BA=8C=F2=\015\012=B8=83=96=F2=A9=B8=A6=F2=8B=A7=94=F0=AD=B0=AA=F4=8B=B0=B7=F3=BD=92=B2=F2=94=\015\012=96=A3=F3=8E=A3=80=F1=A8=B9=AD=F1=88=82=88=F1=A9=BE=BE=F3=B7=8E=92=F0=9E=A3=\015\012=82=F1=B9=BA=8B=F1=9A=A8=B9=F3=84=BF=B2=F2=BD=A9=80=EE=96=87=F3=B2... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 11, 10, "\ud87e\udf0f\ud86f\ude88\udb32\udd15\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udaa0\udcd6\uda67\ude26\ud9ee\uddd4\ud877\udc2a\udbef\udc37\udbb5\udcb2\uda11\udda3\udafa\udcc0\ud963\ude6d\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\ud92a\ude39\udad3\udff2\udab6\ude40\ue587\udb89\uddc2\udba5\ude27\uda33\udc36\udaeb\udf07", "\u8117\u43ce\ud557", "\u0f34\uda48\udce6\udbd5\udeac",
        53, 47841, -685560406, -5692207261441270850L, 36399L, false, true, (char) 34391, (char) 26586,
        Double.longBitsToDouble(0x3fcbf405e9a09e08L), Double.longBitsToDouble(0x3fdb16dbdd16b164L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:????????????????????????????????????????????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.io.UnsupportedEncodingException\012",
        Z.run(T, 2, 8, 9, 11, "\ud861\udc0b\ua26f\udb32\udd15\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udbc4\udcc8\udb03\udc28\udad0\udc2f\ud850\udeb2\udb1f\udecf\udbb5\udc3e\uda11\udda3\udaab\udfbd\udb11\udd84\ud843\udd6f\ud828\udd2f\udb9c\udec1\ud83a\udcc2\ud9a7\ude8b\ud92a\ude39\udb6b\udfdf\udaa6\udd78\ue587\udb89\uddc2\ud876\udd0f\uda74\ude44\udaeb\udf07\udb4a\udfeb\udb80\udf09\ud874\udce9\ud903\udc54\udaa4\ude94\udaea\udd7c\ud95f\udd62\udb23\udc8f\udbe3\udd33\udb39\udc3f\ud99b\udf5f\uda2d\udf87\ud998\udc31\udbd4\udd19\udaac\udeba\udaa4\udd9e\ud9cf\udeab\ud908\udc97\udb94\udc1e\ud952\uddf0\ud9f1\udfad", "\u19ab", "\ud8ef\udd92\udafd\udff9\udb53\ude66\ud90a\udecc\udbe7\ude06\ud866\udca5\udb1e\udff7\udb96\udcfc\udb2a\udc4b\udab8\udce8\uda1a\udc08\ud9ee\udeaa",
        12, 65369, -481238391, -6928763252574880280L, -55142L, false, false, (char) 63915, (char) 21571,
        Double.longBitsToDouble(0x3feb8aac10205adaL), Double.longBitsToDouble(0x3feef6494ba7201cL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 8, 8, 10, "\ud988\udd89\ud97b\udf21\u4ed5\ud806\udf75\uda42\udd5f\udadf\uded2\udb6d\udf3c\ud91c\udc7a\ud864\ude22\udaa3\ude21\ud972\udfa3\ud92e\udc1b\uda11\ude32\udafa\udcc0\udb96\udc27\udb67\udf2b", "\u6644\ua6e2\u17c1", "\ue587",
        42, 2671, -1784226017, -3487895101915285514L, 30095L, false, false, (char) 24396, (char) 8231,
        Double.longBitsToDouble(0x3fda1d40786f4564L), Double.longBitsToDouble(0x3feda82f17c4d7a2L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 7, 3, "\udaeb\ude9d", "\ub455\u62c3\u1472\u7ee9", "\ud877\udc2a\udb1f\udecf\udbb5\udc3e\uda11\udda3\udafa\udcc0\ud9f3\udd98\ud8e0\udc88\udaa9\uddb8\ud919\udf6f",
        37, 27448, 1750756371, -845841576853858823L, 88191L, false, true, (char) 7881, (char) 13921,
        Double.longBitsToDouble(0x3fef84c81a605601L), Double.longBitsToDouble(0x3fcfd4d19e699e40L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:=F0=9E=88=9C=F1=A3=B4=A9=F3=9C=A4=A9=F1=9B=AC=AC=F0=BF=B0=A8=E7=B6=88=F2=9F=\015\012=A7=8C=F4=8A=A2=BA=F1=B3=89=9D=F3=89=91=A7=F3=97=B8=87=F3=BD=90=BE=F2=94=\015\012=96=A3 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F0=9E=88=9C=F1=A3=B4=A9=F3=9C=A4=A9=F1=9B=AC=AC=F0=BF=B0=A8=E7=B6=88=F2=9F=\015\012=A7=8C=F4=8A=A2=BA=F1=B3=89=9D=F3=89=91=A7=F3=97=B8=87=F3=BD=90=BE=F2=94=\015\012=96=A3 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 12, 4, "\ud838\ude1c\ud94f\udd29\udb32\udd29\ud92e\udf2c\ud8bf\udc28\u7d88\uda3e\uddcc\udbea\udcba\ud98c\ude5d\udae5\udc67\udb1f\ude07\udbb5\udc3e\uda11\udda3", "\u1818\u33cd\ucc92\ua460\u2a11\ubb15\u953a\uc866\u68b4\u7ad6\ud6a3\u8113\u21c5\u85a6\ud5dc\ua51e\u305b\u8583\u179b\ubb68\u3206\u34d9\u670f\u7588\uac63\ua53b\ub207\u7d64\uc104\ub84a\u2a75\u5905\uc29f\uc9d5", "\ud9af\ude28\ud88e\udd69\udbb1\ude45\udbb1\udd68\uda51\udff1\uda88\udea3",
        7, 81681, -1485003078, 4368571243975043809L, -35489L, true, false, (char) 27677, (char) 46303,
        Double.longBitsToDouble(0x3fe656d5abf68439L), Double.longBitsToDouble(0x3fe00fc7139d704cL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String:=F2=84=9C=9E=E9=8D=9B=F3=A5=99=B6=F3=8E=B3=92=F0=93=BD=97=F3=87=BA=8C=F4=81=\015\012=83=88=F2=BD=AF=BF=F2=8B=B7=93=F0=B9=82=81=F0=95=81=9B=F1=92=89=89=F3=A4=84=\015\012=A6=F0=92=A8=B1=F1=80=8E=BB=F0=AC=82=90=F2=AD=BB=A9=F3=B7=8E=92=F0=A4=B4=A0=\015\012=F0=B2=B5=88=F1=93=BE=9C=F2=AF=AC=A3=F2=89=B7=83=EE=96=87=F3=B2=97... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 5, 9, "\ud9d1\udf1e\u935b\udb55\ude76\udafb\udcd2\ud80f\udf57\udadf\ude8c\udbc4\udcc8\udab6\udfff\ud9ef\uddd3\ud8a4\udc81\ud814\udc5b\ud908\ude49\udb50\udd26\ud80a\ude31\ud8c0\udfbb\ud870\udc90\uda77\udee9\udb9c\udf92\ud853\udd20\ud88b\udd48\ud90f\udf9c\uda7e\udf23\ud9e7\uddc3\ue587\udb89\uddc2\ud876\udd0f\uda2e\udcda\udb39\udfed\uda94\udcca\udb21\udd9a\ud87b\uded8\ud900\udd04\uda97\udd54\udbb3\udd73\ud82c\uddfa\uda12\udf41\udb04\udfa3\uda2b\ude38\udacd\udc38\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00\ud9d9\udc4f\ud83e\udd3f\ua1df\udbf0\udc98\udb87\uddea\udaae\udc5a\ud8db\ude12\ud8e8\udc62\udb40\udfab\udbb0\udfad\udbef\udc85\udb35\udd43\udba8\udcab\ud871\ude20\udb7d\udc54\ud9f3\udd25\ud8b0\udd66\ud9a3\ude70\udaa3\udfa0\ud93d\udd44\uda7d\ude2b\ud811\udf72\udaf5\uded9\udbdb\udd48\uda05\udca2\ud96b\udd2a\ud899\udc6d", "\u334f\u0201\u8aa2\uca9c", "\ud966\udd59\ud89b\uddb7\udb57\udca3\ud916\udfc0\uda14\uddda\ud847\udd74\ud9a2\udf08\udadd\uddf7\udb91\udf4c\uda93\udc15\uda43\udf80\u52bd\udbfe\udd35\ud938\udffb\udaf7\ude58\ud8ff\udde2",
        41, 456, 1267261211, -1842461174557481171L, 96825L, true, true, (char) 35840, (char) 53971,
        Double.longBitsToDouble(0x3fef44230e6b4e7aL), Double.longBitsToDouble(0x3feeba22861d8e26L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 5, 10, "\udab6\udc75", "\ub455\u62c3\u4aab\u4205\u7659\u165d\u8af0\u7125\ua7a1\u90e0\u6bad\u452c\u83a0\ua80a\ucbc4\u812f\u22e1\u3425\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        32, 18345, -707572688, 8325294049126868054L, -54215L, false, true, (char) 21184, (char) 50613,
        Double.longBitsToDouble(0x3fe6e0f8a9f99642L), Double.longBitsToDouble(0x3fdaabe8a31d322cL)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.String:=F3=9E=B4=B2=F3=8B=88=AC=F2=8B=A1=AD |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 11, 6, 15, "\udb3b\udd32\udaec\ude2c\ud9ee\udc6d", "\u4a9a", "\ud8b2\udd19\uda86\udfbf\ud8a6\udde3\udbb5\udccc\ud82f\udf30\udae8\udcb7\uda5d\udc8a",
        -5, 77830, 1247272377, 5058637718005620430L, 45611L, true, true, (char) 20989, (char) 36272,
        Double.longBitsToDouble(0x3fc0eb0d4c91bf98L), Double.longBitsToDouble(0x3fde295a6e619f30L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=[B:[[124, -127, -70, -80, 119, -90, -7]] |a0=[B:[[124, -127, -70, 10, -80, 119, -90, -7]]\0121=[B:[[124, -127, -70, -80, 119, -90, -7]] |a0=[B:[[124, -127, -70, 10, -80, 119, -90, -7]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 0, 6, 10, "\udbac\udeb1\udaea\udc3a\ud9e0\udfa7\udbd6\ude29\ud80e\udd5e", "\u7459\uca23\u2006\u7092\ua7a1\ud1de\u35ad\ud5f8\u433b\ud3a8\u78cb\u161e\u45cd\ucfcb\ub58b\ud4df\u9c7e\u0274\u87ab\u8113\uc6e0\u5b7b\ub9b9\u9e4a\u6eee\ub3ca", "\ud8af\udc7a\ud96e\udca5",
        38, 66164, -1756414866, -341406677524343390L, -99812L, false, true, (char) 52644, (char) 8198,
        Double.longBitsToDouble(0x3fee0c7f51626154L), Double.longBitsToDouble(0x3fefd7d198a2caa6L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.String:?????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:?????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 7, 13, "\ud851\udeb8\015\uda12\udeb6\ud92e\udf2c\ud80e\udd05\ud953\udc49\ud89f\udf9c\ud92d\udf27\udab7\uddb8\udb77\udc58\udb1f\ude90", "\u07c0\u1d04", "\udb9c\udf92\uda33\udcff\ud9a7\ude8b\udbec\udfe1\udb5c\udeca\udb7c\udf2b\ud8d2\udd63\ud82b\ude62",
        15, 53714, 508577885, 3713598698319397486L, -6488L, true, true, (char) 1628, (char) 7985,
        Double.longBitsToDouble(0x3fa5538a3bdf2c40L), Double.longBitsToDouble(0x3fedfdfed4f19152L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=[B:[[61, 65, 53, 61, 56, 56, 46, 61, 48, 50, 61, 69, 53, 61, 48, 66, 36, 60]] |a1=[B:[[-91, -120, 46, 2, -27, 11, 36, 60]]\0121=[B:[[61, 65, 53, 61, 56, 56, 46, 61, 48, 50, 61, 69, 53, 61, 48, 66, 36, 60]] |a0=[B:[[-91, -120, 46, 2, -27, 11, 36, 60]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 19, 10, 19, "\ud8d5\udfb8\ua35e\udb32\udd15\ud93b\udc54\uda6c\udf9a\udaa6\uddb2\ud9c6\udc09\udbf7\ude67\ud9ee\uddd4\udb38\udd74\ud9b1\udfc6\udbb5\udcb3\uda11\udda3\udafa\udcc0\ud963\ude6d\udbc1\udfb4\udae0\udcee\udb13\udc1e\ud800\ude4d\udbf1\udc4f\uda0e\udc47\ud81f\udfc4\ud8d1\uddea\ue587\udb89\uddc2\udb99\udc38\udaa9\udfb1\udaeb\ude4d\ud987\udcab\uda9f\ude17\udb48\udf96\ud9db\udefa\ud8f3\ude0a\udba6\ude9b\udab8\udcf3", "\u2b5f\u7588\ubb11\ua9fd\u86ae\u36a5\u3574\u9949\u8061\u969d\u18ad\u0b9e\u530b\u72b6\u24ab", "\ud95a\udc21\ud81b\ude5e\ud88f\ude56\u9d90",
        2, 72906, -855911696, 8565375686010823119L, 94257L, false, false, (char) 14014, (char) 45117,
        Double.longBitsToDouble(0x3fea2bad1fafdf1aL), Double.longBitsToDouble(0x3fe277e148c6f284L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=[B:[[49, 61, 68, 66, 63, 61, 48, 56, 105, 9, 61, 69, 55, 61, 48, 54]] |a1=[B:[[49, -37, 63, 8, 105, 9, -25, 6]]\0121=[B:[[49, 61, 68, 66, 63, 61, 48, 56, 105, 9, 61, 69, 55, 61, 48, 54]] |a1=[B:[[49, -37, 63, 8, 105, 9, -25, 6]]\012",
        Z.run(T, 2, 3, 19, 0, "\ud861\udc0b\ua26f\udb38\udd99\ud939\udf17\ud936\udd4d\udbd8\udf2f\ud86f\udd53\udb13\ude84\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\ud897\udcf0\ud811\udfc3\ud88a\udeea\ud954\udc01\uda4a\udf88\udb5f\udd95\udbae\udc32\uda6b\ude80\ud9a7\udea3", "\u17d5", "\ud838\udf10\udb6d\udef1\uc0a3\udaf7\udf21",
        22, 28306, 1938383456, 1216421969692465663L, 94620L, false, false, (char) 59764, (char) 3642,
        Double.longBitsToDouble(0x3facfd28f85856a0L), Double.longBitsToDouble(0x3fc573f8e05e66c4L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=[B:[[49, 61, 68, 66, 63, 61, 48, 56, 105, 54, 61, 70, 69, 60]] |a1=[B:[[49, -37, 63, 8, 105, 54, -2, 60]]\0121=[B:[[49, 61, 68, 66, 63, 61, 48, 56, 105, 54, 61, 70, 69, 60]] |a1=[B:[[49, -37, 63, 8, 105, 54, -2, 60]]\012",
        Z.run(T, 2, 3, 3, 0, "\ud861\udc0b\ua26f\udb38\udd99\ud866\ude2e\uda6c\udc25\udbd8\udf2f\ud86f\udd53\udb13\ude84\ud9ee\uddd4\ud877\udc2a\udb1f\udecf\ud897\udcf0\udbf8\udc37\ud88a\udeea\ud979\udf45\uda69\ude53\udb5f\udd95\ud8d9\udf80\ud83a\udcc2\ud9a7\ude8b", "\000", "\ud876\udd0f",
        58, 51138, -15839440, -7484671376029292478L, 37857L, true, true, (char) 57434, (char) 28769,
        Double.longBitsToDouble(0x3fb27f17be25eea0L), Double.longBitsToDouble(0x3fe6e0f8a9f99642L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=[B:[[49, 61, 68, 66, 61, 65, 49, 61, 66, 50, 61, 67, 48, 61, 49, 65, 61, 70, 54, 61, 48, 57]] |a1=[B:[[49, -37, -95, -78, -64, 26, -10, 9]]\0121=[B:[[49, 61, 68, 66, 61, 65, 49, 61, 66, 50, 61, 67, 48, 61, 49, 65, 61, 70, 54, 61, 48, 57]] |a0=[B:[[49, -37, -95, -78, -64, 26, -10, 9]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 19, 10, 3, "\ud861\udc0b\udad1\udfe2\udaf0\udf4a\ud926\ude39\ud810\udfdd\udadf\ude8c\udbc4\udcc8\udbf7\udec0\u7f9f\ud83c\udca1", "\u1777\u35ad\ua8ba\uad3f\ua80a\u3644\u107d\u30df\uab8a\u2ac5\uaf7e\u7d23\u12c3\u8808\u4d9c\u29f3\u1dfd", "\u93a1\ud8ac\udc3c\uda09\udf79\ud896\udf12\ud966\uded3\ud86a\udeb9",
        5, 24713, -1106860022, -2944459524527794952L, 24604L, false, true, (char) 49273, (char) 53824,
        Double.longBitsToDouble(0x3fe4b346caed8cddL), Double.longBitsToDouble(0x3fede21ea855cec9L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.String:=F0=AF=AC=8F=F0=AB=BA=88=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F3=87=BA=8C=F2=\015\012=B8=83=96=F2=A9=B8=A6=F2=8B=A7=94=F0=AD=B0=AA=F4=8B=B0=B7=F3=BD=92=B2=F2=94=\015\012=96=A3=F3=8E=A3=80=F1=A8=B9=AD=F1=88=82=88=F1=A9=BE=BE=F3=B7=8E=92=F0=9E=A3=\015\012=82=F1=B9=BA=8B=F1=9A=A8=B9=F3=84=BF=B2=F2=BD=A9=80=EE=96=87=F3=B2... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F0=AF=AC=8F=F0=AB=BA=88=F3=9C=A4=95=F1=9B=AC=AC=F0=93=A4=85=F3=87=BA=8C=F2=\015\012=B8=83=96=F2=A9=B8=A6=F2=8B=A7=94=F0=AD=B0=AA=F4=8B=B0=B7=F3=BD=92=B2=F2=94=\015\012=96=A3=F3=8E=A3=80=F1=A8=B9=AD=F1=88=82=88=F1=A9=BE=BE=F3=B7=8E=92=F0=9E=A3=\015\012=82=F1=B9=BA=8B=F1=9A=A8=B9=F3=84=BF=B2=F2=BD=A9=80=EE=96=87=F3=B2... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 11, 10, "\ud87e\udf0f\ud86f\ude88\udb32\udd15\ud92e\udf2c\ud80e\udd05\udadf\ude8c\udaa0\udcd6\uda67\ude26\ud9ee\uddd4\ud877\udc2a\udbef\udc37\udbb5\udcb2\uda11\udda3\udafa\udcc0\ud963\ude6d\ud8e0\udc88\ud967\udfbe\udb9c\udf92\ud83a\udcc2\ud9a7\ude8b\ud92a\ude39\udad3\udff2\udab6\ude40\ue587\udb89\uddc2\udba5\ude27\ud9d8\ude48\udaeb\ude6b\udbc7\udeb4\ud857\udd83\uda19\udf3b\ue9ae\udaa4\ude54\udae0\udc40\udaf9\uddff\u0f34\uda48\udce6\udbd5\udeac\udacd\udca0\ud9a3\ude1d\ud9fa\udf41\ud8be\udf00\ud9d9\udc4f\ud938\ude9d\ud829\udf88\ud808\udede\ud9a1\udc75\ud9d8\ude69\ud828\udf33\uda58\udcdf\ud863\udeeb\ud951\uddb8\uf399", "\u4fc9\u2a35\ua936\uab18\u033b", "\uda85\udcfc\udb0b\uddb6\uda75\udc98\udaa3\udfa5\uda16\udc1c\udb2c\udf03\ud931\udeff\udb3f\udcf8\ud885\ude78\udbd5\udd04\udabc\udf7f\ud898\uddfe\udb9d\udede\ud980\uddf5\udbed\uded4\ud85c\udcc1\ud9cd\udffc\ud9f0\udd6b\ud990\uded7",
        2, 93351, 1822943127, -7922273009541120026L, 41197L, false, false, (char) 56969, (char) 13778,
        Double.longBitsToDouble(0x3fc9b51923525a04L), Double.longBitsToDouble(0x3fdbdb084af703aaL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.String:=F3=9E=B4=B2=F3=8B=88=AC=F2=8B=A1=AD=F0=9F=9B=9D=F1=AE=A1=98 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[11, 2, -68, -4, -66, -83]] |a0=[B:[[11, 2, -68, -4, -66, 61, 13, -83]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 6, 15, "\udb3b\udd32\udaec\ude2c\ud9ee\udc6d\ud83d\udedd\ud97a\udc58", "\u5e24\u8746\ud26b\u84e0\u5691\u5059\ub0c0\u832a\u9ea4\u25c1\u9d6f\u5768\u76f1\u607b\u0923\ua6f2\uc1e0\u1374\ubf42\u0556\u2083\u46ec\u6e24\u22e6\u3a60\ub16f", "\udbdf\udd97\uda32\ude50\ud929\udc0f\udb9f\udfe3\udae4\udf92",
        58, 9152, 941716396, -9045408923753347934L, 21524L, false, true, (char) 42341, (char) 57316,
        Double.longBitsToDouble(0x3fcb4b616a38707cL), Double.longBitsToDouble(0x3fe14d99c347cadeL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=[B:[[11, 2, -68, -4, -66, -83]] |a0=[B:[[11, 2, -68, -4, -66, 61, 13, -83]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[11, 2, -68, -4, -66, -83]] |a0=[B:[[11, 2, -68, -4, -66, 61, 13, -83]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 6, 6, 15, "\udb3b\udd32\udaec\ude2c\ud9ee\udc6d\ud83d\udedd\ud97a\udc58", "\u5e24\u8746\ud26b\u84e0\u5691\u5059\ua9ef\u8cb5\uab41\u52fc\u9d6f\u5768\u76f1\u607b\u0923\ua6f2\uc1e0\u1374\ubf42\u0556\u2083\u46ec\u6e24\u22e6\u3a60\ub16f", "\udbdf\udd97\uda32\ude50\ud8bd\udf3a\ud8c2\udc01\uda3f\udd50",
        7, 9147, 941716396, -9045408923753347934L, 21524L, false, true, (char) 57188, (char) 57316,
        Double.longBitsToDouble(0x3fcb4b616a38707cL), Double.longBitsToDouble(0x3fe14d99c347cadeL)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.String:=F3=9E=B4=B2=F3=8B=88=AC=F2=8B=A1=AD=F2=B4=A5=87=F1=AE=A1=98 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 11, 6, 15, "\udb3b\udd32\udaec\ude2c\ud9ee\udc6d\uda92\udd47\ud97a\udc58", "\u5e24\u8746\ud26b\u7a53\u5681\u5059\u488a\u832a\u9ea4\u25c1\u9d6f\u5768\u76f1\u607b\u0923\ua6f2\uc1e0\u1374\ubf42\u0556\u2083\u46ec\u6e24\u22e6\u3a60\ub16f", "\udbdf\udd97\uda32\ude50\ud929\udc0f\udb9f\udfe3\udae4\udf92",
        58, 9152, 941716396, -9068239183192488798L, 21524L, false, true, (char) 42341, (char) 57316,
        Double.longBitsToDouble(0x3fcb4b616a38707cL), Double.longBitsToDouble(0x3fe14d99c347cadeL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 5, 10, "\ud861\udc0b", "\ub455\u62c3\u4aab\u4205\u7459\u5cdb\u50e1\u7125\ua7a1\u90e0\u35ad\u3a20\u83a0\ua80a\u3644\u161e\u2a06\u17c1\u72a6\u6456\ub85b", "\uda2e\udcda\udaeb\udf07",
        27, 97727, -1827103699, 8325293739889236310L, 52795L, false, true, (char) 62192, (char) 53546,
        Double.longBitsToDouble(0x3fdf3f0343641f5aL), Double.longBitsToDouble(0x3fdaabe8af51ae46L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.String:=F0=B7=8A=AF=F1=9B=AD=81=F3=9C=A5=80=F1=9B=AC=AC=F0=BF=B0=A8=00=E8=88=90W=\015\012=F2=A4=80=87=F3=82=83=84=F3=97=B8=87=F3=BD=90=BE=F2=94=96=A3 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 5, 1, "\ud89c\udeaf\ud92e\udf41\udb32\udd40\ud92e\udf2c\ud8bf\udc28\000\u8210W\uda50\udc07\udac8\udcc4\udb1f\ude07\udbb5\udc3e\uda11\udda3", "\000\000\ucc92\ua460\u2a11\ubb15\u953a\uc866\u68b4\u7ad6\ud6a3\u8113\u21c5\u7934", "\ud9cd\udd1a\ud9b3\udf18\ue1fd",
        19, 67968, -1114491823, 2239704926307619548L, -46154L, false, true, (char) 36031, (char) 55080,
        Double.longBitsToDouble(0x3fef55ac591c90f2L), Double.longBitsToDouble(0x3f4d9c7af6bbe800L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.String:=F2=84=B4=9E=E9=8D=9B=F3=A5=99=B6=F3=8E=B4=B5=F2=90=AE=91=F3=84=90=B4=F4=81=\015\012=83=88=F1=A9=BE=BC=F2=8B=B7=93=F2=9A=A2=84=F0=95=81=9B=F1=92=89=89=F3=A4=84=\015\012=A6=F0=92=A8=B1=F1=80=8E=BB=F0=B2=AA=90=F2=AD=BB=A9=F3=B7=8E=92=F0=A4=B4=A0=\015\012=F1=BF=A0=99=F0=90=84=B3=F3=8B=BA=AA=F1=82=8E=A7=EE=96=87=F3=B2=97... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F2=84=B4=9E=E9=8D=9B=F3=A5=99=B6=F3=8E=B4=B5=F2=90=AE=91=F3=84=90=B4=F4=81=\015\012=83=88=F1=A9=BE=BC=F2=8B=B7=93=F2=9A=A2=84=F0=95=81=9B=F1=92=89=89=F3=A4=84=\015\012=A6=F0=92=A8=B1=F1=80=8E=BB=F0=B2=AA=90=F2=AD=BB=A9=F3=B7=8E=92=F0=A4=B4=A0=\015\012=F1=BF=A0=99=F0=90=84=B3=F3=8B=BA=AA=F1=82=8E=A7=EE=96=87=F3=B2=97... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 12, 11, 17, "\ud9d3\udd1e\u935b\udb55\ude76\udafb\udd35\uda02\udf91\udad1\udc34\udbc4\udcc8\ud967\udfbc\ud9ef\uddd3\uda2a\udc84\ud814\udc5b\ud908\ude49\udb50\udd26\ud80a\ude31\ud8c0\udfbb\ud88a\ude90\uda77\udee9\udb9c\udf92\ud853\udd20\ud9be\udc19\ud800\udd33\udaef\udeaa\ud8c8\udfa7\ue587\udb89\uddc2\ud876\udd0f\uda2e\udcda\udb39\udfed\uda94\udcca\uda07\udfec\ud87b\ude3f\ud900\udd04\uda97\udd54\ud8ca\ude89\ud82c\uddfa\uda12\udf41\udb04\udfa3\uda2b\ude38\udacd\udc38\ud954\ude9c\uda0e\udc04\ud8be\udf00\ud9d9\udc8c\udb1a\udcec\ua217\udbf0\udc98\udb87\uddea\udaae\udc5a\ud8db\ude12\ud8e8\udc62\udb40\udfab\ud9c8\udfb9\udbef\udc85\udb35\udd43\udba8\udcab\ud871\ude20\udb7d\udc54\ud9f3\udd25\ud8b0\udd66\ud9a3\ude70\udaa3\udfa0\ud93d\udd44\uda7d\ude2b\ud811\udf72\udaf5\uded9\udbdb\udd48", "\ube9b\u46bb\u2cb1\u334f\u0201\u8aa2\uca9c\ua8c2\u0ace", "\udb57\udca3\ud916\udfc0\uda14\uddda",
        54, 12721, 762577738, -5039453915254919077L, -21881L, false, false, (char) 21762, (char) 9843,
        Double.longBitsToDouble(0x3fe3c335071bec67L), Double.longBitsToDouble(0x3fea9a5c472de66eL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.String:=F3=9E=B4=B2=F3=8B=88=AC=F2=8B=A1=AD=F0=B5=99=A8=F2=BF=96=BE |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[11, 2, -68, -4, -66, -24]] |a0=[B:[[11, 2, -68, -4, -66, 61, 101, 56]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 6, 14, "\udb3b\udd32\udaec\ude2c\ud9ee\udc6d\ud895\ude68\udabd\uddbe", "\u5e24\u8746\ud26b\u84e0\u5691\u5059\ub0c0\u832a\u9ea4\u25c1\u5827\u3a65", "\u0a96\ud892\udc10\uda8b\udfa9\ud893\udc81",
        57, 39290, -407012672, -6339010581447767133L, -84938L, true, true, (char) 3090, (char) 27383,
        Double.longBitsToDouble(0x3fe319fc773aaeaaL), Double.longBitsToDouble(0x3fd623467c74e29aL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.String:=F4=84=BF=A9=F1=9B=B0=9D=F3=9C=A5=80=F1=9B=AC=AC=F0=BF=B0=A8=00=E8=88=90W=\015\012=F2=A4=80=87=F3=82=83=84=F2=96=97=A4=F3=BD=90=BE=F2=94=96=A3 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F4=84=BF=A9=F1=9B=B0=9D=F3=9C=A5=80=F1=9B=AC=AC=F0=BF=B0=A8=00=E8=88=90W=\015\012=F2=A4=80=87=F3=82=83=84=F2=96=97=A4=F3=BD=90=BE=F2=94=96=A3 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 12, 7, "\udbd3\udfe9\ud92f\udc1d\udb32\udd40\ud92e\udf2c\ud8bf\udc28\000\u8210W\uda50\udc07\udac8\udcc4\uda19\udde4\udbb5\udc3e\uda11\udda3", "\ub920\000\ucc92\ua460\u2a11\ubb15\u953a\uc866\u68b4\u7ad6\ud6a3\u8113\u21c5\u7934", "\ud9cd\udd1a\ud9b3\udf18\ue1fd",
        19, 67968, -1114491823, 2239704926307619548L, -46154L, false, true, (char) 36031, (char) 55080,
        Double.longBitsToDouble(0x3fef55ac59d37085L), Double.longBitsToDouble(0x3fc2d33a5af6bbe8L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=[B:[[-110, 95, -68, -90, -66, -24]] |a0=[B:[[-110, 95, -68, -90, -66, 61, 101, 56]]\0121=[B:[[-110, 95, -68, -90, -66, -24]] |a0=[B:[[-110, 95, -68, -90, -66, 61, 101, 56]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 16, 6, 14, "\udbc2\udc8f\udaec\uddd6\ud9ee\udc6d\ud895\ude68\udabd\uddbe", "\ub45d\u0cc9\ud26b\u84e0\u4c17\u2232\u2624\uc277\u34ec\u8e0b\ua5e7\u3a65", "\u0a96",
        13, 33985, 474821406, -9116430474536969374L, -54806L, true, false, (char) 52016, (char) 50726,
        Double.longBitsToDouble(0x3fd7236e04f0b31eL), Double.longBitsToDouble(0x3fd5b599c8c67f1cL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=[B:[[-116, 108, -43, 66, 102, 41]] |a0=[B:[[10, -116, 10, 108, -43, 66, 102, 41]]\0121=[B:[[-116, 108, -43, 66, 102, 41]] |a0=[B:[[10, -116, 10, 108, -43, 66, 102, 41]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 16, 6, 15, "\u873a\udbbc\ude3a\uda9c\udc05\udb72\udd96\u4d59", "\ud185\u87b6\ud26b\u18cc\ub8be\u2682\ua6af\u165f\ud4c5\u25c1\u9d6f\uaf5a\uaa2d\u5fe9\u0923\ua6f2\ua282\u8111\u7a86\u3930\u1dc0\u5eb6\ua4d0\u9b58\u3b30\ub16f", "\uda13\udd91\ud947\udd61\ud845\ude68\ud893\uddf8\udae4\udf92",
        13, 58802, 941716396, -4528610758803028830L, 21524L, false, false, (char) 14264, (char) 29596,
        Double.longBitsToDouble(0x3fa1686228e1c1f0L), Double.longBitsToDouble(0x3fa4d99c347d9870L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decodeQuotedPrintable|[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeByte|int,boolean,java.io.ByteArrayOutputStream|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeQuotedPrintable|int,java.io.ByteArrayOutputStream|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeQuotedPrintable|java.util.BitSet,[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|getUnsignedOctet|int,[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|isWhitespace|int|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decode|[B|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decode|java.lang.Object|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decode|java.lang.String|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decode|java.lang.String,java.lang.String|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encode|[B|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encode|java.lang.Object|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encode|java.lang.String|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encode|java.lang.String,java.lang.String|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|getDefaultCharset||new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "C|org.apache.commons.codec.net.QuotedPrintableCodec|<init>|",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decodeQuotedPrintable|[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeByte|int,boolean,java.io.ByteArrayOutputStream|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeQuotedPrintable|int,java.io.ByteArrayOutputStream|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeQuotedPrintable|java.util.BitSet,[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|getUnsignedOctet|int,[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|isWhitespace|int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
