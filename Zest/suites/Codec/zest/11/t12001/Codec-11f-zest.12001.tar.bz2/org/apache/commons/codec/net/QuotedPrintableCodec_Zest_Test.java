package org.apache.commons.codec.net;
import org.junit.Test;
import static org.junit.Assert.*;
public class QuotedPrintableCodec_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:?????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\udbf3\udfa4",
        3, 54849, -236854420, -7696416100439412662L, -93103L, false, true, (char) 32350, (char) 6940,
        Double.longBitsToDouble(0x3fe3fe2e9dbd81e3L), Double.longBitsToDouble(0x3fe12fdec289bdb4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[B:[[-56, 122, -61, 126, 32, -41, 58, -63]] |a0=[B:[[-56, 122, -61, 126, 32, -41, 58, -63]]\012",
        Z.run(T, 1, 0, 14, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\ud810\udfb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\udbf3\udfa4\udb60\udfc0\udb44\udf3f\u3a97",
        16, 10482, -715885953, 8944322691726437481L, -8588L, true, false, (char) 6940, (char) 4179,
        Double.longBitsToDouble(0x3fdbd81e3c4bf7b0L), Double.longBitsToDouble(0x3fe44deda6d2f715L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 4, "\udbf8\udcaa", "\ub33e\u727c\u3fd6\u4d60\u5a4f\uc519", "\ud895\udc8a",
        49, 43043, -314107275, 7236002269916251129L, 23756L, false, false, (char) 50554, (char) 62517,
        Double.longBitsToDouble(0x3fe0ceaaa4697cd8L), Double.longBitsToDouble(0x3fe78ae68d147ce8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\ua9c5", "\udbf3\udfa4\udb60\udfc0",
        44, 87793, -19260262, -9099851810384612737L, 26057L, true, false, (char) 57852, (char) 32350,
        Double.longBitsToDouble(0x3fd7a45a24ff8ba6L), Double.longBitsToDouble(0x3fdbd81e3c4bf7b0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 15, 3, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb5a\udeee\ud988\udd5e\udafb\udf66\ud8fe\udcb2\udb98\uddcc\uda05\udeef\ud8de\ude8f", "\u6d5b\u96fd\u5c44\u88be\uaf8f\u538d\u72b0\uadf7\u6062\u104b\u0d5b\ub857\u58ab\u6a57\u6c13\u1f7f\ucd06\ua0d0\u8f92", "\udba2\udcc6\ud899\udca9\ud8cb\udd03\udb91\udc8c\udaa4\udcf3\ud90e\udf77\ud867\udf36\udbe6\udc33\ud80b\udcdd\ud993\ude83\ud9b1\udc98\udb0c\udccd\u898e\udb22\udc7b\uda39\udc97\ud8ba\udf6d\udbe2\udf37\ud900\udd46\uda38\udd59\udb79\ude19",
        59, 34364, 1589481770, -8239556000791047525L, -89154L, false, false, (char) 53997, (char) 33904,
        Double.longBitsToDouble(0x3fb3585fb047cd00L), Double.longBitsToDouble(0x3fe19d4976e1a7ceL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 4, "\ud8aa\udd80\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7", "\u5acd\uc519\u6a48", "\ud9f9\udfdb",
        8, 1725, 1684763066, -268170914763958623L, 26057L, true, false, (char) 57852, (char) 32350,
        Double.longBitsToDouble(0x3fd7a45a24ff8ba6L), Double.longBitsToDouble(0x3fc27f263897ef60L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:?????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 12, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud998\ude1f", "\u6d8c", "\udbe0\udcda\udb60\udfc0\udb44\udf3f\u3a97\uda5e\udc0a\udae8\udcd8\ud8d5\udffb\ud9e1\udd74",
        57, 37033, 1848468756, 5017590736507622778L, -81510L, false, false, (char) 56944, (char) 3890,
        Double.longBitsToDouble(0x3fed61fd9e65035dL), Double.longBitsToDouble(0x3fe28b2329a57fcfL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:??????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 4, "\u9292\ud9f3\udeae\udb50\udce7\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5", "\u94ca\u2a31\ucb28\u6d8c\u96fd\u5c44\ub223\ucfc0", "\ud993\udfd6\udae8\udcd8\ud8d8\udcf8\uda90\udccc\ud92e\ude67\ud982\ude4d\ud898\udf92\ud9fb\udc4b\uda81\udeff",
        17, 3173, 1253365285, -7585278020008708738L, 89112L, true, false, (char) 5182, (char) 43440,
        Double.longBitsToDouble(0x3fb62323a495c558L), Double.longBitsToDouble(0x3feffcf15d940840L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 15, 14, 15, "\udb94\udc17\ud93c\udd61\ud850\udc25\udb6a\udff1\uefb7\ud925\uddf7\ud9a6\udec8\udb98\uddc6\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\udbf3\udfa4",
        3, 54849, 1776411500, 2192679311859165314L, 25176L, true, true, (char) 42095, (char) 15004,
        Double.longBitsToDouble(0x3fe70fdec28943abL), Double.longBitsToDouble(0x3fe3cf27c80e2132L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:=F1=BD=82=B6=F0=A5=A2=80 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 11, 8, 11, "\ud9b4\udcb6\ud856\udc80", "\u727c\ub21e", "\ud928\ude40\ud9e0\udfdb\uda4c\uddc5\ud88a\udc8a\ud9f3\udc4a\udb1f\udd04\uda21\ude5a\ud89e\udedb\udaab\udfc9\uda00\ude5d\udb90\udfc5\uda5e\udc0a\uda64\udcd6\ud907\udfdd\uda00\uddbb\ud9f6\ude0e\udb55\udce4\u8f39\ud9fb\udc4b\ud95a\ude0c\ud974\udf10\ud92f\udd7e\udb64\ude3c\udba4\udc4e\udb9b\udc02\udb39\udcd0\ud8b5\udc7f\ud8b9\udf0a\ud9a9\udd18\ud897\udd3b\udb02\udcbe\udb49\udf65\ud899\udcb3\udb18\udf77",
        39, 27868, 504094723, 1088835369093286349L, -13598L, false, true, (char) 40275, (char) 45985,
        Double.longBitsToDouble(0x3fea41324e1b5cebL), Double.longBitsToDouble(0x3fe4f57812366ecfL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[B:[[61, 67, 56, 122, 61, 67, 51, 126, 32, 61, 68, 55, 61, 65, 48, 61, 67, 50]] |a1=[B:[[-56, 122, -61, 126, 32, -41, -96, -62]]\012",
        Z.run(T, 1, 3, 3, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udbd0\udef2\ud86f\udd34\ud925\uddf7\ud83e\uddd5\ud929\udd54\ud960\udea2\ud811\udfd2", "\ucdda\u60b3\u5c44\u75d6\uaf8f\u538d\u1851\u97be\u6a9c\u7c0f\ucece\uaa6b\u3efb\u7d78\uc088\u98e6\u7530\ubbec\u4aea\u4768\ua051\ua0cb\ub855\u0e3c\u0d4c\u7405\uabad\u4ba2\u22d3\u8a53\u8f28\u568d\uba8d\u0876\u3898\uafb0\u8fd7\ua96e\ud5ee\u5a19\u9814\u04f5\u33be\u1a2c\ud179", "\ud842\udf91",
        8, 56229, -582450807, 8973764587550273524L, -31916L, true, false, (char) 25572, (char) 7963,
        Double.longBitsToDouble(0x3fd3ff377f0f5d56L), Double.longBitsToDouble(0x3fc3b2ad77191f84L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[B:[[61, 57, 55, 61, 69, 50, 61, 67, 51, 126, 32, 61, 68, 55, 58, 61, 67, 49]] |a0=[B:[[-105, -30, -61, 126, 32, -41, 58, -63]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 10, 13, 4, "\udac7\udd12\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud9da\udc3a\ud9e0\udfdb", "\u1450\u0b49\u5c44", "\udb44\udf3f\u3a97",
        49, 60732, -1657703809, 8996147807229439081L, -59689L, false, false, (char) 13144, (char) 13518,
        Double.longBitsToDouble(0x3fe37d6462571e29L), Double.longBitsToDouble(0x3febf66584204586L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:????????????????????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb\ud994\uddc9\ud895\udc8a\ud9f9\udfdb\udb19\udfbd\uda12\udd5a\udbf3\udfa4\udb60\udfc0\udb44\udf3f\u3a97\uda5e\udc0a\udae8\udcd8\ud9b6\udc4a\ud9e1\udd5e\ud92e\udde1\ud982\ude4d", "\u9887\ucd06\ua0d0\u8f92\u4c41\u3868\u27fb\u91d0", "\udbe2\udf5c\ud933\udefe\uda0d\udff2\uda85\uddd0\ud9d5\udf90\ud80d\udd15\ud8f5\uddb9\ud9b5\udf1e\ud96d\ude64",
        52, 46894, -1869913057, -3154831610456065932L, 81304L, true, true, (char) 25873, (char) 30825,
        Double.longBitsToDouble(0x3fe2bb1b7b33b86aL), Double.longBitsToDouble(0x3fd99df0f3f65250L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[B:[[61, 56, 70, 126, 61, 67, 51, 61, 65, 49, 32, 61, 68, 55, 61, 66, 52, 49]] |a1=[B:[[-113, 126, -61, -95, 32, -41, -76, 49]]\012",
        Z.run(T, 1, 3, 18, 0, "\ud9bf\uddae\ud9f3\uded1\ud850\udc07\udbe4\ude61\uefb7\ud925\uddf7\ud83e\uddd5\uda1e\udfbb\ud960\ude3c\udbb4\udd0d", "\u8d4c\u96fd\u5c44\u88be\uaf8f", "\uda5e\udc0a\udae8\udcd8\udb58\udd3b\uda29\udc0a\ud8b4\uddd3\udbf0\udf1e\ud892\udd2c\ud985\udc03\uda33\uddc7",
        0, 61688, -1112222171, 484808248830359917L, 66683L, true, false, (char) 45764, (char) 59942,
        Double.longBitsToDouble(0x3febdc95b269552fL), Double.longBitsToDouble(0x3fd604eec46b421eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:?? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 9, 18, "\udbf8\udcaa\ud992\udc59", "\ua6a3\u3f9a\u2e21\u1afb\u5f8a\uc342\u08fc\u1c43\u599d\u96c9\u9eb2", "\udaae\udd16\udb9b\udd21\uda5e\udc0a\udae8\udcd8\ud979\udd0c\ud9e1\ude16",
        57, 37033, 1853646100, 5017590738407773562L, 15752L, false, false, (char) 57414, (char) 33748,
        Double.longBitsToDouble(0x3fe9eca6b9a6fbb2L), Double.longBitsToDouble(0x3fe79d6b788d58b5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:=E1=90=80=F2=8C=BA=AE=00=00=00=00=F0=9F=A7=95~=00=F3=A0=A0=80 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 12, 14, 4, "\u1400\ud9f3\udeae\000\000\000\000\ud83e\uddd5~\000\udb42\udc00", "\u6d56", "\u00ba",
        3, 71641, 108, -7696416469806600118L, -100000L, false, true, (char) 28205, (char) 0,
        Double.longBitsToDouble(0x3fe3fe2800000000L), Double.longBitsToDouble(0x3fe128000289bdb4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:??? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:UTF-8 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 14, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07", "\u3fd6\u4800\u5a66\uc519", "\ud895\udc8a",
        49, 43043, 1055332981, -2327037036499352583L, 23756L, false, false, (char) 50554, (char) 62517,
        Double.longBitsToDouble(0x3fe0ceaaa4697cd8L), Double.longBitsToDouble(0x3fe78ae68d147ce8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 4, 4, "\ud84c\udfaf\uda7c\ude3f\udb2e\udf64\uea1b\uefb7\ud9a7\ude37\ud83e\uddd6\udb98\uddcc\udbb4\uddfd\ud96a\udf64\ud994\uddc9\ud84e\udee6", "\u5cb2\u115d\u1caf\u538d\u72b0\u595d\uc127", "\ud922\udcf5\ud9ea\ude41\ud898\udf92\ud9fb\udc4b\udb9b\udf2c\ud851\udd53\ud910\udfc8",
        39, 27424, -1908618320, -5024356133382999337L, -18385L, true, true, (char) 57071, (char) 51405,
        Double.longBitsToDouble(0x3f940b3d40583060L), Double.longBitsToDouble(0x3fd24daf5050b02cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[B:[[62, 61, 57, 52, 61, 69, 70, 55, 45, 76, 61, 49, 56, 61, 69, 57]] |a1=[B:[[62, -108, -17, 55, 45, 76, 24, -23]]\012",
        Z.run(T, 1, 19, 17, 12, "\uda6e\uddc4\ud91f\udd67\udb5d\udc7c\udb48\udd19\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\ud9b8\udf08",
        3, 5817, -236854420, -7644105275674841014L, -93103L, false, true, (char) 32350, (char) 63508,
        Double.longBitsToDouble(0x3fe3fc1ff62107e3L), Double.longBitsToDouble(0x3fe12fdec289bdb4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:=F0=BA=A5=B4=F0=BE=B9=B5=F0=A4=81=BF=F1=8E=8C=85=EE=BE=B7=F1=99=97=B7=F2=B8=\015\012=BB=95=F3=B6=87=8C=F1=A8=88=BC=F3=BD=B2=A5 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 11, 3, 4, "\ud8aa\udd74\ud8bb\ude75\ud850\udc7f\ud8f8\udf05\uefb7\ud925\uddf7\udaa3\uded5\udb98\uddcc\ud960\ude3c\udbb7\udca5", "\ua38b", "\udbf3\udfa4",
        19, 55507, -236854420, -7696416097102009014L, 37842L, false, false, (char) 30658, (char) 57852,
        Double.longBitsToDouble(0x3fa8b716b7a45a20L), Double.longBitsToDouble(0x3fe3fe224dbd81e3L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.io.UnsupportedEncodingException\012",
        Z.run(T, 1, 13, 14, 4, "\udbf8\udcaa\ud9f3\udeae\uda05\udd22\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\udbf3\udfa4",
        3, 54849, -236854420, -7696416100439412662L, -93103L, false, true, (char) 32350, (char) 6940,
        Double.longBitsToDouble(0x3fe3fe2e9dbd81e3L), Double.longBitsToDouble(0x3fe12fdec289bdb4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:???????????????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb\ud9e3\udf73\ud895\udca6\udac3\udfa0\udbf1\udff8\udaf1\udf1e\udbf3\udfbe\ud985\udec2\udb15\uddc7\u5232\uda5e\udc0a", "\uc38a\u2be6\u0a23\u0ba2\u7ab8\u9887", "\udb64\ude3c\udaac\uddf1\uda75\udcaa\uda85\udfa6\ud8d2\udc17\ud89f\ude9a\ud9ca\udc01\ud85f\udc79\udab1\uded9\ud919\udd67\ud8e0\udcd7\udac2\udce9\ud94e\udef1\ud8ab\udd50\uda6c\udd96\uda9e\udefa\udbbc\ude72\uda52\udfb4\udaa9\udfc9\ud88f\udce6\ud858\udd17\uda80\udd09\ud839\ude86\ud8f4\udee3\ud9f0\udcf8\ud804\udc6c\udab9\udeeb\udad1\udc02\uda26\udc5e\u332d\udafb\udceb\ud87a\udc78\uda71\ude60\uda83\udc07\ud9b7\udffc\uda91\udd6a\ud8b2\udc39\udbb9\udcd0",
        9, 39965, -1252108110, -6943795469525505075L, 99388L, false, false, (char) 51664, (char) 46688,
        Double.longBitsToDouble(0x3f9d0f4a157280a0L), Double.longBitsToDouble(0x3fc9644a1f507188L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 10, "\ud8b3\uddc4\udb75\udd31\ud850\udc07\udb0e\uddf5\udad4\udfe5\ud98a\udfef\ud956\uded0\udb72\udc48\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\ud907\udfae\ud8fd\ude7a\ud9f9\udd26\udbd7\ude96\uda5e\udc0a\udb8b\udd21\ud8d6\udc51\ud9e1\udd74\ud92e\uddf9\ud993\udc83\ud84d\udef4\udb6c\uddbf\ud95a\ude0c\ud974\udf10\ud92f\udd7e\udb64\ude3c\ud99d\udf48\ud97a\udfa2\ud8ba\uddd4\uce35\uda30\udff2\ud9f0\udd69\udb2e\ude9d\udbc3\udd08",
        19, 91135, -1152681648, 5967774998910669206L, -92573L, true, true, (char) 28147, (char) 25866,
        Double.longBitsToDouble(0x3fc323562f4d2c24L), Double.longBitsToDouble(0x3fbe407f48a600e0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:?????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F4=8E=82=AA=F1=A5=89=BF=F1=B6=A5=AD=F2=92=B9=A5=EE=BE=B7=F1=99=97=B7=F1=BD=\015\012=A8=91=F1=9E=92=8E=F0=B1=A7=AE=F3=A6=BB=91 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 12, 4, "\udbf8\udcaa\ud954\ude7f\ud99a\udd6d\uda0b\ude65\uefb7\ud925\uddf7\ud9b6\ude11\ud939\udc8e\ud886\uddee\udb5b\uded1", "\u24b7", "\udbe3\udcbd",
        6, 99825, -990515112, -3312859185494478774L, -93103L, false, true, (char) 32350, (char) 3356,
        Double.longBitsToDouble(0x3fdb4b70bb7b0274L), Double.longBitsToDouble(0x3fe12fdec289bdb4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:126 |a1=[B:[[-56, 122, -61, 126, 32, -41, 58, -63]]\012",
        Z.run(T, 1, 20, 17, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud86f\udfdb\ud82c\uddf0\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\ud87a\uddcb",
        3, 54849, -236854420, 4265144511429407760L, -59527L, true, false, (char) 30658, (char) 57852,
        Double.longBitsToDouble(0x3fa8b716d7a45a20L), Double.longBitsToDouble(0x3fe3fe2e9dbd81e3L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 6, 4, "\udbf8\udcaa", "\ubaa7", "\ud83e\udd75",
        15, 59902, -1810994632, 25932823295792499L, 96608L, false, true, (char) 51255, (char) 38266,
        Double.longBitsToDouble(0x3e48675400000000L), Double.longBitsToDouble(0x3fba5f360002e688L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:???????????????????????????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 1, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\ud983\ude1c\ud96e\udc72\udb5b\udd0b\ud83e\uddd5\udaee\udd18\ud841\ude3c\ud9e0\udfdb\ud994\uddc9\ud895\udc8a\ud9f9\udfdb\udaf0\udeaf\uda8b\udc82\ud9f6\udfae\uda55\udef5\ud8f6\udfe4\u9de9\ud98c\ude19\ud96a\udefe\ud8d5\udffb\ud9e1\udd74\uda70\ude01\udb5e\udded\ua892\uda66\udf2b\ud95a\ude0c\ud9f6\udf11\udb76\udf22\udb64\ude40\uda80\udf3c", "\u4e08\u11b0\u29b4\u0512\u2562", "\ud953\udfda\ud948\udf73\ud933\udffa\udb5c\udd68",
        8, 87485, -77680769, -318006568380095489L, -18430L, true, false, (char) 60252, (char) 12222,
        Double.longBitsToDouble(0x3fefb2fb429631bfL), Double.longBitsToDouble(0x3fd34d3b4fefb11cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 16, 14, 4, "Q\ud99b\ude6c\ud850\udc07\udb36\udff1\uefb7\ud925\udcfb\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "", "\uda12\udd5a\udbf3\udfa4\ud89a\udffd",
        -5, 90580, -1791961514, 317111693951L, -100000L, false, false, (char) 57852, (char) 28254,
        Double.longBitsToDouble(0x3fd7a45a24ff8ba6L), Double.longBitsToDouble(0x3fdbd81e3c4bf7b0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 19, 0, "\udbf8\udcaa", "\000\000\000", "",
        -5, 35368, 6037956, -1111943311830024192L, -34581L, false, true, (char) 43108, (char) 4841,
        Double.longBitsToDouble(0x3fbb0019c0000000L), Double.longBitsToDouble(0x3fb2a54000040db0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:UTF-8 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 14, 4, "\udbf8\udcaa\ud9f3\udeae\ud870\ude17\udb6a\udfc8\ud9e4\udd2c\ud9e3\uddf6\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\u8fb3", "\udbe2\udda5\udb60\udf38\udad9\udd09\u3af3\ud815\udea6\udb41\ude8b\uda04\uddd7\ud9a0\ude33\ud942\udd31\udbd3\uddf9\ud898\udf92\ud9fb\udc4b\ud95a\ude0c\ud974\udf10\ud92f\udd7e\udb64\ude3c\udbf9\ude59\ud9b6\udcb6\ud955\udfa3\ud89d\udc88\uda8d\udf9f",
        38, 44251, 1891446242, -376746053013651444L, -41853L, false, true, (char) 52254, (char) 14971,
        Double.longBitsToDouble(0x3feb455bb5554d84L), Double.longBitsToDouble(0x3fdeba5ee8552462L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[B:[[61, 67, 56, 122, 61, 57, 50, 61, 69, 54, 32, 98, 72, 111]] |a1=[B:[[-56, 122, -110, -26, 32, 98, 72, 111]]\012",
        Z.run(T, 1, 3, 17, 9, "\udbf8\udcaa\udbc2\ude16\ud850\udc92\ud978\udc9f\udb42\udffc\ud85e\ude69\ud80f\uddda\ud969\udfc5", "\u2a31\ucb28\u6d8c\ub649\ua06c\u754a\u5b68\u2f7a\u1bc1\u97be", "\ud9e1\udd74\ud880\udf2a",
        3, 66967, 1168248881, -5830944933356772666L, 1828L, false, true, (char) 18497, (char) 52007,
        Double.longBitsToDouble(0x3fbef8e2c0452ee0L), Double.longBitsToDouble(0x3fea6113b222d138L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 13, 3, "\udbf8\udcaa", "\u2472\u47f6\u58ba\ua442\u2c07\u928b\u250c\u2a31\u48f2\uc6d7\ubf39", "\udb60\udf2f\udb44\udf3f\ud820\udcff\udb1a\udf92\udaf0\udccd\ud8d5\udffb\udb3f\udc24\udbb5\udedb",
        58, 71560, 1161933587, -4191772110304884202L, -59129L, true, true, (char) 14908, (char) 20290,
        Double.longBitsToDouble(0x3fe55e74d7d9a76cL), Double.longBitsToDouble(0x3fd84aa904e580a0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[B:[[61, 67, 56, 122, 61, 67, 51, 126]] |a0=[B:[[-56, 122, -61, 126]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 10, 4, 5, "\udbf8\udcaa\ud9f3\udeae", "\u5873\u3fd6\u2e21\u5acd\uc519\u6a48\u2a31\ucb28\u6d8c\u96fd\u5c44", "\udb44\udf3f\u3a97",
        16, 10482, -715885953, 8996114087441198185L, 70671L, true, false, (char) 30567, (char) 46035,
        Double.longBitsToDouble(0x3fdbd81e3c4bf7b0L), Double.longBitsToDouble(0x3fe44deda6f77a79L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 8, 0, 4, "\udb38\udd77\ud97a\udf9d\uda81\udc28\udacd\udc15\uefb7\ud883\udf65\udbdb\udefb\ud8b1\ude38\ud9b5\udc31\udb84\udfac", "\u9d0d\uca25\u7697\u88bb", "\u3a97\uda5e\udc0a\udae8\udcd8\udb6b\udc65\udb12\udf6d\udbec\udea9\udb20\udc25\ud898\udfcb",
        12, 89966, -1193063809, -299399607911315163L, 34176L, true, false, (char) 9333, (char) 55985,
        Double.longBitsToDouble(0x3fc178e84181aa98L), Double.longBitsToDouble(0x3fd71b17c4f60d06L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[B:[[38, 61, 48, 54, 121, 102, 32, 61, 49, 68, 63, 61, 50, 48]] |a1=[B:[[38, 6, 121, 102, 32, 29, 63, 32]]\012",
        Z.run(T, 1, 19, 4, 2, "\udb56\udc36\udba9\udf96\ud850\udc4d\udb6f\udc50\ud9bb\udeb7\ud925\udd43\ud9c0\uddd6\udb98\uddcc\ud801\udc36\udb0e\udeb4\udb26\ude25\udb52\udd61", "\u5c44\u88be\uaf8f\u538d\u72b0\u97be\u6a9c\u43c6\u7d02\uaaf2\u42f6\u33fb\u8e64\u9887\u5cd0\u1a53\ud388\u292e\u7640\u243c\u27b9\u242c\u39e8\u0977\u3167", "\ud9af\udeb0\ud837\udc8b\udb21\udf2e\ud966\udf2a\ud9a2\udff8\ud885\udf67",
        8, 69467, 527461294, 8156289794984570614L, -99474L, false, true, (char) 29352, (char) 29738,
        Double.longBitsToDouble(0x3fab1d808ec45ca0L), Double.longBitsToDouble(0x3fe0d90589ef4237L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:?????????????????????????????????????????????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 4, "\ud914\ude68\ud9f3\udeae\ud937\udc5c\udb6d\udca3\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb\u54ca\ud891\udc0c\ud9f9\udfdb\udb19\udfbd\uda12\udd5a\udbf3\udfa4\udb60\udfc0\udb44\udf3f\u3a97\uda5e\udc0a\ud94f\uddab\udbaa\udc07\ud9e1\udd5b\ud92e\udde1\ud982\ude4d\ud898\udf92\udb15\udc78\udb52\udd71\uda4e\udddd\ud92f\udd7e\udb64\ude3c\udb82\udd7c\ua573\udb4d\udd66\udb88\udebb\udb4c\udc40\ud8e3\udefc\ud9c1\ude41\uda1e\udc15\uda85\udc9f\uda13\udf23\udbbf\uddd6\udb3b\udf4f\ud84f\udcd1\uda04\udf11\ud866\ude7e\udb5b\udffd\ud8cd\udf2d\ud8b9\udf2b\ud8e6\udd7b", "\ubec1\u26fe\ua27d\u27c2\uba7a\u4064\u6442\u4d89\u73ec\ua342\u6962\u1d4a\u6ec9\ua143\u7781\u138e\u17dc\u152b\u85f9\u77f4\u3cfe\ud1c9", "\ud8c8\udc3f\ud82f\udd75\udb68\udecc\ud9d7\udf1f\uda88\ude0f\uda2a\udc2a\ud9cd\udeda\uda52\udd27\ud9ba\ude0a\udb38\udf41\ud8ae\udfbe\ud81c\udff0\ud99b\udfc0\uca85\ud824\udfd5",
        21, 82400, 1220479865, -3617782824447629280L, 12345L, false, true, (char) 11066, (char) 34798,
        Double.longBitsToDouble(0x3fd24afe97d112deL), Double.longBitsToDouble(0x3fe1db511f6dc3b1L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:?????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 7, 14, 4, "\udb45\udc95\udafe\udf37\ud850\udc07\udb6a\udff1\ud951\udf62\ud915\udece\ud83e\udd9a\ud84d\udda6\udbae\udca9\ud9e0\udfdb", "\u6d8c", "\uda1e\udc47\udb60\udfc0\udb44\udf3f\u3a97\uda5e\udc0a\udac3\udc9d",
        57, 32033, -1440104599, 4244672272788455256L, 86186L, false, true, (char) 34245, (char) 57189,
        Double.longBitsToDouble(0x3fe228babf45ee23L), Double.longBitsToDouble(0x3fa1e7ad48b0bc30L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 19, 14, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\000\ud960\ude26\ud9e0\udfdb", "\u6d8c", "\udbf3\udfa4",
        3, 89001, 0, 0L, -100000L, false, false, (char) 30449, (char) 57852,
        Double.longBitsToDouble(0x3fa8b716d7a45a20L), Double.longBitsToDouble(0x3fe3fe2e9dbd81e3L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 14, 0, "", "", "\000",
        -5, 21824, 0, 0L, -100000L, false, false, (char) 4147, (char) 59,
        Double.longBitsToDouble(0x3e38000000000000L), Double.longBitsToDouble(0x3d8399c000000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[B:[[-116]] |a0=[B:[[-116]]\012",
        Z.run(T, 1, 0, 14, 15, "\u1abc", "\ub33e\uc67c\u3fd6\u812d\ua705\uc519", "\uda33\udd8d\ud9f9\udfdb\ud85d\ude9f",
        13, 46178, 1195852701, 1565025162088861269L, 86119L, false, true, (char) 45201, (char) 26761,
        Double.longBitsToDouble(0x3fe78ae68d1000e8L), Double.longBitsToDouble(0x3fcfedc5b5e91688L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 1, 0, 14, 4, "\udbf8\udcaa\uda6d\ude37\ud850\udc07\udb6a\udff1\ud810\udfb7\ud925\uddf7\ud83e\uddd5\udb88\udd72\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\udbf3\udfa4\udb60\udfc0\udb44\udf3f\u3a97",
        16, 10482, -715885953, 8944322691726437481L, -8588L, true, false, (char) 6940, (char) 4179,
        Double.longBitsToDouble(0x3fedec0f1e25fbd8L), Double.longBitsToDouble(0x3fe44deda6d2f715L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:=F4=8E=82=AA=F2=8C=BA=AE=F0=A4=80=87=F3=A1=83=B1=F2=9D=BD=8B=F3=A6=B4=B6=F0=\015\012=9F=A7=95=F1=BB=BB=8B=F2=B8=97=A0=F1=8C=91=A3=F0=A6=95=A5=F3=BE=A4=9D=F2=8E=\015\012=A1=9A=F0=A7=9A=9F=F3=A1=B9=A6=F4=8C=BE=A4=F3=A8=8F=80=F3=A1=8C=BF=E3=AA=97=\015\012=F2=A7=A0=8A |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 11, 6, 6, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb44\udcf1\uda37\udf4b\udb5b\udd36\ud83e\uddd5\ud9af\udecb\udaa1\udde0\ud8f1\udc63\ud859\udd65\udbba\udd1d\ud9fa\udc5a\ud85d\ude9f\udb47\ude66\udbf3\udfa4\udb60\udfc0\udb44\udf3f\u3a97\uda5e\udc0a", "\ub936\uaa6b\u3efb\u2fa9\u7ab8", "\ud92f\udd7e\udb64\ude3c\ud9cc\ude02\ud926\uddc6\ud954\udc2e\ud900\ude47",
        47, -880, -1640303698, 6313504147766286355L, -30533L, true, true, (char) 9235, (char) 65476,
        Double.longBitsToDouble(0x3fd863dec9f68d58L), Double.longBitsToDouble(0x3fcfaf771d878e64L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 1, 0, 14, 4, "\udbf8\udcaa\ud9f3\udeae\udba0\ude50\udb6a\udf6d\ud810\udfb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\udbf3\udfa4\udb60\udfc0\udb44\udf3f\u3a97",
        16, 10482, -715885953, 8944322692212976745L, -8588L, true, false, (char) 6940, (char) 4179,
        Double.longBitsToDouble(0x3fdbd81e3c4bf7b0L), Double.longBitsToDouble(0x3fe44deda6d2f715L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=[B:[[61, 67, 56, 122, 61, 67, 51, 126, 32, 61, 68, 55]] |a1=[B:[[-56, 122, -61, 126, 32, -41]]\012",
        Z.run(T, 1, 19, 5, 6, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07", "\ub0bd\u1247\u731d\u971f", "\ud85d\udd1a",
        15, 31939, -927649367, -1375501441680173606L, -8152L, true, true, (char) 64278, (char) 40045,
        Double.longBitsToDouble(0x3fef73657c6987d9L), Double.longBitsToDouble(0x3fe78ae68d147ce8L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 1, 0, 14, 4, "\udbf8\udcaa\ud81d\ude63\ud877\udd17\ud96d\ude91\ud810\udfb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\u6d8c\ub878", "\udb60\udfc0\udb44\udf3f",
        50, 80486, -2118766518, -3074706753718280679L, -93103L, false, true, (char) 32350, (char) 6940,
        Double.longBitsToDouble(0x3fe3fe2e9dbd81e3L), Double.longBitsToDouble(0x3fe12fdec289bdb4L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=[B:[[-56, 122, -61, 126, 32, -41, 58, -63]] |a0=[B:[[-56, 122, -61, 126, 32, -41, 58, -63]]\012",
        Z.run(T, 1, 0, 14, 20, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\ud810\udfb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb\ud994\uddc9\ud895\udc8a\ud9f9\udfdb\ud85d\ude9f\udb47\ude66\udbf3\udfa4\udb60\udfc0\udb44\udf3f\u3a97\uda5e\udc0a\udae8\udcd8\ud8d5\udffb\uda8b\udd69\ud92e\udde1\ud982\ude4d\ud898\udf92\ud9fb\udc4b\ud95a\ude0c\ud974\udf10", "\u87f7\u8219\u6360\u8c3b\u39bb\u59c3\u88fe\u77e3\u1dda\u4d88\u2ca9\ub2d8\u8f01\u61b1\u8812\u9915\u9151\u67e4\ubd38\u346f\u973c\ub69d\u6ab4\ub36d\ubd91\u7e5e\u1992\u9e6a\u7353\u8176\u6f8a", "\ud810\udc0f\udb1a\ude8d\uda66\udfeb\udb5e\udc0f\uda46\ude15\ud838\udc45\udb5f\udc9c\uda66\udc91\ud840\udc9e\ud960\udfe5\udb8e\udf8f\ud890\udf4b\ud91d\ude1e\ud853\udde5\ud9ee\ude1c\ud916\udc10\ud901\udd33\ud811\udfdc\ud94a\udca8\uda69\ude24\udb83\udc60\udb63\udfc2\ud9b4\udda4\ud9da\udfad\uda49\udcab\ud9d1\udd3d\ud9ef\udf4f\uda58\udd8c\ud8b9\udfab\ud996\ude6a\ud899\ude98\udb08\udd5a\udb58\udc9f\uda73\udf2e\uda92\udedc\ud80a\udf67\ud950\uded6\ud962\udcea\ud828\udfb1",
        53, 33855, -1757614256, -2526259319413191015L, -15993L, true, true, (char) 27954, (char) 1880,
        Double.longBitsToDouble(0x3f91a57de1804bc0L), Double.longBitsToDouble(0x3fe8d2e761b874eaL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:=F4=8E=82=AA=F1=BE=9F=B2=F0=AB=91=86=F3=AA=AF=B1=F0=AB=86=97=F3=95=9F=8E=F3=\015\012=80=86=81=F3=BD=9A=A6=F0=A5=9B=9C=F3=BB=A9=BA=F1=B5=86=AC=F1=B4=B1=8A=F4=8B=\015\012=80=82 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 12, 18, 14, "\udbf8\udcaa\ud9b9\udff2\ud86d\udc46\udb6a\udff1\ud86c\udd97\udb15\udfce\udac0\udd81\udbb5\udea6\ud855\udedc\udbae\ude7a\ud994\uddac\ud993\udc4a\udbec\udc02", "\u23ea\uaf8f\u538d\u5e05\u39dc\u6a9c\u47ec", "\ud9e5\udeb6",
        55, 11444, -979145274, -9087337713851912771L, -19630L, false, false, (char) 24871, (char) 2802,
        Double.longBitsToDouble(0x3fe186f39e261fa6L), Double.longBitsToDouble(0x3f9c291fb29bfce0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=[B:[[-123, 120, 6, 21, 18, -104, 9]] |a0=[B:[[10, -123, 120, 6, 21, 18, -104, 9]]\012",
        Z.run(T, 1, 0, 14, 4, "\udb3a\udeb5\ud8a8\udd36\ud845\udd42\ud8c8\udf39\ud810\udfb7\uda4c\udeea\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud251", "\u6d8c", "\udbf3\udfa4\udb60\udfc0\udb44\udf3f\u3a97",
        16, 47154, -715906945, 8944322691726437481L, -8588L, true, false, (char) 6940, (char) 4179,
        Double.longBitsToDouble(0x3fec5a670e25973bL), Double.longBitsToDouble(0x3fe44deda6d2f715L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 5, 14, 10, "\udbf8\udcaa\ud9f3\udf41\ud850\udc07\udb6a\udff1\uab06\uda44\udc85\ud83e\uddd5\udb98\uddcc\ud952\ude35\ud9e0\udfdb", "\u0fa5", "\udbf3\udfa4\udb60\udfc0",
        44, 87793, -19260262, -9099851811559017857L, 35975L, true, false, (char) 55036, (char) 32350,
        Double.longBitsToDouble(0x3fd7a45a24ff8ba6L), Double.longBitsToDouble(0x3fdbd81e3c4bf7b0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 12, 14, 4, "\ud944\udc01\ud9f3\udeae\ud849\udca3\ud8a4\udf58\uefb7\ud8f6\udcfb\udacf\udcc7\u0081\ud960\ude26\ud9e0\udfdb", "6", "\udbf3\udfa4",
        3, 88233, 0, -82753645271657218L, -59527L, true, false, (char) 6656, (char) 31996,
        Double.longBitsToDouble(0x3e45e91400000000L), Double.longBitsToDouble(0x3fe3fe2e980081e3L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:193 |a1=[B:[[99, 4, -61, 126, 65, 48, 58, -63]]\012",
        Z.run(T, 1, 20, 9, 17, "\ud893\udd34\ud9f3\udeae\ud871\udf60\udb6a\udff1\uefb7\ud97e\udceb\ud83e\uddd5\uda3a\udcb4\udba7\udd3d\ud952\ude0a\u7911\ud895\udc76\uda7b\udcd1\uda7d\udf02\uda12\udd5a\udbf3\udfa4\udb60\udfc0\ud933\udc58\uda75\udf14\udaa5\udc88\uda4f\udcea\uda11\uddbb\udb44\udfd2\ud9ea\udf08\ud89a\udda7\ud8d1\udf91\ud9fb\udc4b\ud95a\ude0c\uda18\uddec", "\u6381\u8302\u29d7\ubf96\u3881\u607c\u9e4d\u51db\u6b24\u8a30\u40a1\u32b6\u5756", "\uda39\ude65\ud962\ude4e\ud806\udec6\ud84b\uddd3\ud8c2\ude2c\uda94\udd18",
        7, 14321, 1009872631, 8447617041940738235L, 10337L, false, false, (char) 31412, (char) 55781,
        Double.longBitsToDouble(0x3fb0361eb79238b0L), Double.longBitsToDouble(0x3fec9832e6fe0aa3L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:???????????????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[9, 39, -93, 116, 74, 25, -13, 28]] |a0=[B:[[9, 39, -93, 116, 74, 25, -13, 28]]\012",
        Z.run(T, 2, 8, 0, 4, "\ud939\ude57\ud9d3\udfa4\ud97a\udf49\udb23\udd4c\udaad\udc8e\ud925\udd20\uda72\ude2f\udb85\udcff\ud960\ude3c\ud9a6\udfab\ud98f\uddc9\ud895\udc8a\ud84f\ude68\ud9c5\udd02\uda12\udd5c\ud8a5\udf1d\ud9f4\ude41\ud951\ude31\uda73\udeb2\ud8cc\udf14", "\u936d\u821f\u25ac\ud014\u2139\u9887\ucd06\ua0d0\u607a\u9f55\u2069\uad14\u9d9e\u7e25\u93b1\ub247\u7d9f\u47d8\ua49d\u160e\ucf4f\u62d6\u2568\ubabb\u92b4\uc59c\uc1cb\ud5ad\u4397\uad37\u354e\u9c7f\u42ec\u5f4d", "\ud9ea\udf7b\ud7a6\udb97\ude3d\ud8f5\udd2f",
        2, 61666, -2066603220, 6590579837597923894L, 86742L, false, true, (char) 1483, (char) 18433,
        Double.longBitsToDouble(0x3fd8de461d12fa28L), Double.longBitsToDouble(0x3f6257a2b562d500L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.String:UTF-8 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 14, 15, 3, "\udb5b\udd93\uda29\udeea\ud967\udcfc\ud87b\udcf1", "\ud460", "\ud8de\ude8f\ud8e7\ude77\ud944\udc55\udb6b\udd5f\ud9d8\udffd\udb21\udd07\udbb5\ude36\udbe6\udd2a",
        16, 47572, 1901600026, -9118093102175980920L, -55530L, false, true, (char) 32039, (char) 52692,
        Double.longBitsToDouble(0x3fd3812564fedbd6L), Double.longBitsToDouble(0x3fdbd81e384bf7b0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String:=F1=98=B6=A4=F2=8C=BA=AE=F0=A4=80=87=F3=A6=AB=AE=F1=B2=85=9E=F3=8E=BD=A6=F1=\015\012=8F=A2=B2 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 11, 5, 16, "\ud923\udda4\ud9f3\udeae\ud850\udc07\udb5a\udeee\ud988\udd5e\udafb\udf66\ud8fe\udcb2", "\u82c1\uc222\u74b6\u6da6\uc7a8\u5b07\u88be\uaf8f", "\udbf6\ude56\udbd5\udee6\uda9f\udc68\udb97\udccf\udb19\ude0a\ud96a\uddb7\ud81d\udf0a\uda71\udf6c\ud918\udfb2",
        16, 3022, -1112222171, 3132080405775603746L, 41864L, true, true, (char) 44961, (char) 33872,
        Double.longBitsToDouble(0x3fe2c906504f8b3aL), Double.longBitsToDouble(0x3fe7876b1009d199L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:?????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F2=A8=93=8B=F2=8C=BC=A6=F0=A4=80=87=F3=A6=AB=AE=F1=B2=85=9E=F3=8E=BD=A6=F1=\015\012=8F=A2=B2=F3=B6=87=8C=F0=AD=9F=86=F3=8D=AA=86 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 11, 3, "\uda61\udccb\ud9f3\udf26\ud850\udc07\udb5a\udeee\ud988\udd5e\udafb\udf66\ud8fe\udcb2\udb98\uddcc\ud875\udfc6\udaf6\ude86", "\u542f\u96fd", "\ud9a4\udd0c",
        1, 90580, -1137650090, -9084231742457039628L, 75207L, false, true, (char) 32039, (char) 24789,
        Double.longBitsToDouble(0x3fd5912564fedbd6L), Double.longBitsToDouble(0x3fc645655897ef60L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=[B:[[98, -61, 126, 32, -73, -13, 124, -89]] |a0=[B:[[98, -61, 126, 32, -73, -13, 124, -89]]\012",
        Z.run(T, 2, 5, 16, 5, "\u9292\ud9f3\udeae\udb50\udce7\ud823\udfac\ud9d7\ude49\ud91c\udc41\ud9a5\udc38", "\uaaf3\u1525\u5538\ua706\u25f3\u1686\ua8ea\u8777\u5ca5\u5ed9\u8e88\u6a9c\uc180\u447b\uaaf1\u3efb\u2fa9\u7ab8\u5416\ube62\ua0d0", "\udb3f\udf08\u4102\ud9d4\udcae",
        6, 46682, 411319369, -7883894166717592535L, -78092L, false, true, (char) 265, (char) 2564,
        Double.longBitsToDouble(0x3fcffd347cce81b0L), Double.longBitsToDouble(0x3feeee312a8ffd5cL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=[B:[[100, 61, 69, 55, 61, 48, 67, 49, 32, 61, 70, 53, 61, 66, 65, 61, 66, 65]] |a0=[B:[[100, -25, 12, 49, 32, -11, -70, -70]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[100, -25, 12, 49, 32, -11, -70, -70]] |a0=[B:[[100, -25, 12, 49, 32, -11, -70, -70]]\012",
        Z.run(T, 2, 10, 0, 17, "\udb94\udc17\ud93c\udd61\ud850\udc25\udaea\udcea\uefb7\ud925\uddf7\ud9a6\udec8\udb98\uddc6\ud9b2\ude9d\ud9e0\udfdb", "\u246c\u0a32", "\udb60\udfc0\udb44\udf3f\udb6b\udee4\ud8c5\udc83",
        -3, 55241, -136798695, -2019716645250338264L, 25176L, true, true, (char) 46599, (char) 47772,
        Double.longBitsToDouble(0x3fe8c77d0e8943abL), Double.longBitsToDouble(0x3fe3cf27c80e2132L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 11, 20, 5, "\ud8c7\udf98\ud8f5\ude54\ud965\udd35\ud9a7\udf53\ud8a5\udc06\udb83\udfcd\ud9a6\udec8\udb98\uddc6\ud960\ude3c\ud901\udf4a\ud948\udde8\ud8bf\udfac\uda61\udeb7\uda47\udf29\uda29\udeeb\ud844\udced\ud8cc\udffa\ud9ee\udc95\ud976\udda9\ud816\udc03", "\uca10\u7d30\u3e33\u58a9\u1fb0\ubd34", "\udb8b\udedd\ud92c\udcce\ud98e\ude33\udae0\udf48\uda96\udf08\uda79\udcc2\uda90\udfcd\ud82e\udd9d\ud954\udee1\ue0d5\ud864\udc79\ud87f\ude80\ub1b4\udb8c\udf16\ud943\udd46\ud893\udc32\ud9d8\udcf5\ud80f\ude8c\ud8b7\udf03\ud82a\ude55\udb5e\udd09\ud844\udebd\udb03\udd4b\ud95b\udf42\ud83d\udf31\udb30\ude66\uda38\ude2f",
        52, 74661, 657296871, 3486565466540815253L, -23016L, false, false, (char) 25719, (char) 58910,
        Double.longBitsToDouble(0x3fb08eae62ca5940L), Double.longBitsToDouble(0x3fe4593fcd28b883L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:=F1=BD=82=B6=F0=A5=A2=80=F3=99=8B=AE=F1=9E=BD=BA=EE=BE=B7=F1=A9=A1=B7=F0=AA=\015\012=AC=8A=F1=BD=9F=94=F1=9A=89=80=F2=88=8F=9B=F0=9E=8D=BB=F1=88=9F=8A=F2=8C=B1=\015\012=8A=F3=97=B4=84=F2=98=99=9A=F1=9D=BA=86=F2=BA=BF=89=F2=90=89=9D=F3=B4=8D=A1=\015\012=F2=A7=A0=8A=F2=A9=83=96=F1=91=BF=9D=F2=90=86=BB=F2=8D=A8=8E=F3=A5... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 11, 8, 1, "\ud9b4\udcb6\ud856\udc80\udb24\udeee\ud93b\udf7a\uefb7\ud966\udc77\ud86a\udf0a\ud9b5\udfd4\ud928\ude40\ud9e0\udfdb\ud838\udf7b\ud8e1\udfca\ud9f3\udc4a\udb1f\udd04\uda21\ude5a\ud937\ude86\udaab\udfc9\uda00\ude5d\udb90\udf61\uda5e\udc0a\uda64\udcd6\ud907\udfdd\uda00\uddbb\ud9f6\ude0e\udb55\udce4\u8f39\ud9fb\udc4b\ud95a\udddd\ud974\udf10\ud92f\udd7e\udb64\ude3c\udba4\udc4e\ud961\udc05\udb39\udcd0\ud8b5\udc7f", "\u17f7", "\ud899\udcb3\udb18\udf77\ub4b3\uda56\udd7b",
        23, 3240, -777008691, 5095775080492650882L, 48187L, false, false, (char) 37265, (char) 60165,
        Double.longBitsToDouble(0x3fe4f57812366ecfL), Double.longBitsToDouble(0x3fe2620ec6b93f3fL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String:=EA=AD=AE=F0=9C=8D=B6 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.io.UnsupportedEncodingException\012",
        Z.run(T, 2, 11, 13, 11, "\uab6e\ud830\udf76", "\u3101\ub1cd", "\u0cfb\ud9e0\udfdb\ud8f8\udd2d\udb7b\udd9f\ud877\uddf4\udb3f\udf7c\ud9e7\uddab\ud89e\udee4\udaab\udfc9\uda00\ude5d\udb90\udfc5\uda5e\udc0a\ud88d\ude4a\udb81\udc93\udb4d\udfd6\udbe7\udc63\ud9ba\udf23\ue27e\ud9fb\udc4b\ud95a\ude0c\ud870\udf0e\ud92f\udd7e\udb64\ude3c\udba4\udc4e\udb9b\udc02\udb39\udcd0\ud8b5\udc7f\ud8b9\udf0a\ud9a9\udd18\ud897\udd3b",
        2, 96254, -1593365940, -2006559156165019204L, 75660L, false, true, (char) 40275, (char) 10969,
        Double.longBitsToDouble(0x3fd067d7e43795aeL), Double.longBitsToDouble(0x3fe4f5781166a2b1L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String:=F1=BD=82=B6=F0=A5=A2=80=F3=99=8B=AE=E1=B7=BB |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 11, 8, 11, "\ud9b4\udcb6\ud856\udc80\udb24\udeee\u1dfb", "\u2e21\u5165\u4569\u6a48\u21e4\u603f\u52c4\uac44\u9944\u078e\ub22f\u10e2\u1ca3\u97be\ub271\u8b59\u224f\u9e1e\u8161\uabe5\u7ab8\u9887\ucd06\u7cc1\u905b", "\udb39\udcd0\ud8b5\udc7f\ud8b9\udf0a\ud9a9\udd18\ud897\udd3b\udb02\udcbe\udb49\udf99\ud899\udcb3",
        9, 61084, 1485132868, 2165070349624693248L, -90596L, true, true, (char) 45985, (char) 37347,
        Double.longBitsToDouble(0x3fe0dae75a9eaf02L), Double.longBitsToDouble(0x3fe1b3767d84f59aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 8, 11, "\ud9b4\udcb6\ud856\udc80", "\uc7d0\u3277", "\ud87d\udd92\ud9e0\udfdb\uda4c\uddc5\ud88a\udc8a\uda1c\udf53\udb1f\udcaa\udab3\udcc5\uda50\ude33\ud827\uddaf\udbba\uddac\udb90\udfc5\uda5e\udc0a\uda64\udcd6",
        48, 90252, 1609733223, 8988196994135775411L, 85722L, true, true, (char) 3982, (char) 1222,
        Double.longBitsToDouble(0x3fe44deda683da36L), Double.longBitsToDouble(0x3fe7deac96481f24L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.String:=F1=BD=84=92=F0=A5=A2=80 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F1=BD=84=92=F0=A5=A2=80 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 11, 1, "\ud9b4\udd12\ud856\udc80", "\u727c\ub21e", "\ud928\ude70\ud9e0\udfdb\uda4c\uddc5\ud88a\udc8a\ud9f3\udc4a\uda65\ude88\ud999\udd96\ud899\udf42\udaab\udfc9\uda00\ude5d\udb90\udfc5\uda5e\udc0a\ud9b4\udf9d\udba1\udf62\uda70\ude0b\udb87\udf86\ud909\udd94\u8f39\ud9fb\udc4b\ud95a\ude0c\ud974\udf10\ud92f\udd7e\ud91b\udfb7\udb99\udd27\udb9b\udc02\udb39\udcd0\ud8b5\udc7f\ud8b9\udf0a\ud9a9\udd18\uda77\udd61\u905f\udb49\udf65\uda1a\udd93\udb18\udf77",
        39, 84347, 2138542935, -3422755978752276285L, -13598L, false, true, (char) 40275, (char) 45985,
        Double.longBitsToDouble(0x3fea41324e1b5cebL), Double.longBitsToDouble(0x3fe4f57812366ecfL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=[B:[[61, 67, 56, 122, 61, 57, 66, 34, 77, 61, 68, 57, 61, 65, 48, 61, 67, 50]] |a1=[B:[[-56, 122, -101, 34, 77, -39, -96, -62]]\0121=[B:[[61, 67, 56, 122, 61, 57, 66, 34, 77, 61, 68, 57, 61, 65, 48, 61, 67, 50]] |a1=[B:[[-56, 122, -101, 34, 77, -39, -96, -62]]\012",
        Z.run(T, 2, 3, 3, 4, "\udbf8\udcaa\udbcb\ude52\ud87d\ude09\udbd0\udef2\ud86f\udd34\ud925\uddf7\ud83e\uddd5\ud929\udd54\ud960\udea2\ud811\udfd2", "\ucdda\u60b3\u5c44\u75d6\uaf8f\u538d\u1851\u97be\u6a9c\u7c0f\ucece\uaa6b\u3efb\u7d78\uc088\u98e6\u7530\ubbec\u91a0\u4aa5\ud4b2\ua0cb\ub855\u0e3c\u0d4c\u7405\uabad\u4ba2\u22d3\u8a53\u8f28\u568d\uba8d\u0876\u3898\uafb0\u8fd7\ua96e\ud5ee\u5a19\u9814\u04f5\u33be\u1a2c\ud179", "\ud842\udf91",
        8, 56229, -582450807, 8973764587550273524L, -31916L, true, false, (char) 25572, (char) 7963,
        Double.longBitsToDouble(0x3fd3ff377f0f5d56L), Double.longBitsToDouble(0x3fc3b2ad77191f84L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=[B:[[61, 67, 56, 122, 67, 126, 32, 61, 68, 55, 61, 56, 68, 61, 66, 53]] |a1=[B:[[-56, 122, 67, 126, 32, -41, -115, -75]]\0121=[B:[[61, 67, 56, 122, 67, 126, 32, 61, 68, 55, 61, 56, 68, 61, 66, 53]] |a1=[B:[[-56, 122, 67, 126, 32, -41, -115, -75]]\012",
        Z.run(T, 2, 3, 3, 4, "\udbf8\udcaa\ud973\udeae\ud850\udc07\ud9bd\udce5\ud88c\uded0\ud83b\udc02\ud83e\uddd5\ud929\udd54\ud960\udea2\ud811\udfd2", "\ucdda\u60b3\u5c44\u986d\uaf20\u538d\u1851\uc77d\u8ec2\u7c0f\ucece\uaa6b\u3efb\u7d78\uc088\u98e6\u7530\ubbec\u4aea\u4768\u9394\ub260\ub855\u0e3c\u020a\u7405\uabad\u4ba2\u22d3\u8a53\u8f28\u568d\uba8d\u0876\u3898\uafb0\u8fd7\ua96e\ud5ee\u0612\u2bb4\u04f5\u33be\uc57b\ud255", "\uadc9",
        8, 56229, -582450807, 8973764587550273524L, -27952L, true, true, (char) 36695, (char) 12193,
        Double.longBitsToDouble(0x3fdab74be9779a32L), Double.longBitsToDouble(0x3fd3ff377f0f5d56L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.String:?????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:?????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 8, 6, "\udac7\udd12\ud8c7\udf79\ud850\udc07\udb6a\udff1\ua1b7\ud925\uddf7\ud83e\uddd5\ud998\udccc\uda57\uddd9\uda01\udcc7", "\u1450\u0b49\ucd1a", "\udb44\udf3f\u3a97",
        49, 60732, -1657703809, 8996147807229439081L, -59689L, false, false, (char) 13144, (char) 13518,
        Double.longBitsToDouble(0x3fe37d6462571e29L), Double.longBitsToDouble(0x3febf66584204586L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Integer:55 |a1=[B:[[-105, -30, 106, 84, 38, -6, 55, -116]]\012",
        Z.run(T, 2, 5, 20, 8, "\udac7\udd12\uda9a\udc84\ud956\udf2a\udb67\udebc\uda7f\uddfb\ud925\udd97\ud83e\uddd5\u8b97\ud8d4\ude4a\ud967\udf2a\ud866\uddd2\udac8\ude8f\ud99d\ude48\uf6cf\uda12\udd5a\u13f1\udb60\udfc0\udb44\udf3f\u3a97\uda09\ude35\udaae\udd8f\ud937\udcac\ud9e8\udf6d\ud997\udf61\udb34\udfde", "\u0bbf\u63a5\ua0d0\u8f92\uc241\u7201\u3197\u5c82\u1afb\uc586\u7249\u1705\u7447\u2495", "\uda51\udf7d\ufdc9\udbbb\udc6d\udac7\udc54\ud8ad\ude48\udb71\udfb5\ud955\udf7b\ud8c5\udd8e\udb86\udda3\ud9a1\udc90\ud9b5\udc07\udbd4\udc8f\udb59\udd90\uda4a\udc8b\ud949\udd8e\ud8e2\udd22\ud893\udf5d\uda59\udcfc\ud900\udfd5\udb33\udca1\udafb\udf36\ud8d5\ude84\ud98d\udf1b\udaaa\ude68\ud89f\udcd7\ud991\udc1a\ud847\ude84\ud946\udffd\u8667\udb8f\udc78",
        6, 83115, 1483466882, -5143386722524435803L, 11517L, false, true, (char) 22060, (char) 45586,
        Double.longBitsToDouble(0x3fd762d1fd51d424L), Double.longBitsToDouble(0x3fe88df207383752L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=[B:[[61, 57, 55, 61, 69, 50, 61, 67, 51, 126, 37, 9, 58, 61, 67, 49]] |a0=[B:[[-105, -30, -61, 126, 37, 9, 58, -63]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 10, 13, 4, "\udac7\udd12\ud9f3\udeae\ud855\udd39\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud9da\udc3a\ud9e0\udfdb", "\u1450\uc4c3\u657e", "\udb44\udf3f\ud8e7\udca3",
        49, 60732, -1657703809, 8996147807229439081L, 81608L, false, false, (char) 6976, (char) 4179,
        Double.longBitsToDouble(0x3fdbd81e3c4bf7b0L), Double.longBitsToDouble(0x3fe44deda4d886a3L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.String:=F4=8F=A8=86=F2=8C=BA=AE=00=00=00=F2=8D=9F=91=F0=9F=A8=BB~=C3=BB=F3=A0=A0=80=\015\012=F1=B5=84=85=F1=8D=9A=BA=F2=8E=9E=A5=F3=96=9E=BD=F0=98=A1=B8=F2=94=AE=8D=F3=\015\012=A8=8F=80=F3=8E=8C=B9l=F2=A7=9E=B4=F3=8A=83=98=F1=85=9F=BB=F2=88=95=B4=F3=A6=\015\012=8E=96=00=F0=B6=8E=92=00=F3=B2=B2=85=F1=84=9A=BD=C2=AD=F3=A9=88=... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 12, 3, 4, "\udbfe\ude06\ud9f3\udeae\000\000\000\ud9f5\udfd1\ud83e\ude3b~\u00fb\udb42\udc00\ud994\udd05\ud8f5\udeba\ud9f9\udfa5\udb19\udfbd\ud822\udc78\uda12\udf8d\udb60\udfc0\udaf8\udf39l\uda5d\udfb4\udae8\udcd8\ud8d5\udffb\ud9e1\udd74\udb58\udf96\000\ud898\udf92\000\udb8b\udc85\ud8d1\udebd\u00ad\udb64\ude3c\ud85b\udca9\ud911\ude04\ud948\ude65\ud814\udf2b\ud80c\ude69\ud81c\udcef\ud825\udeda\uda9f\udd94\uda55\ude72\ud954\udea9\uda91\udde0\udb2e\udd8e\udbd7\udffe\ud934\udf1f\ud8d5\udc61\uda45\udde9\udab3\udfa9\ud961\udc99\uda1b\udc82\udb05\udc4c\uda98\udf69\ud90c\udcbd\udbf5\udf00\uda7d\udf48\ud909\udd99\ud85a\ude21\ud9a8\udfcf\ud89d\udc19\uda66\udc85", "\uc1a9\u4cb1\u1f29\u25cc\u6703", "\uda1e\udd11\udb78\udc54\ud949\uddca\udb6e\ude3a\udba6\udf35\ud96b\udc26\ud8ca\udd57\udb08\udd98\ud819\udeff\ud94e\uddf1\ud9da\udf88\udae6\udeab\udac4\udd26\udac1\udc6b\udac4\udd65\u437a\udb73\ude2b\ud848\udd1c\udbb2\udd9a\ue9eb\udaca\udf3b\udaa0\ude32\udafd\udc84\ud9d5\ude42\ud95c\udcee\udbae\ude37\udbb5\udcfa\ud92a\ude69\ud97b\udebd\ud9e3\udd3c\ud878\udf20\ud8c4\udcf4\ud8e0\ude30\ud80a\udd5e\uf22c\ud93c\udc5b\ud897\ude5e\ud962\udd2b\udb03\ude23\uda14\ude80\ud8b9\udd44\udb9c\udea7\ud824\udf90\ud9d1\uddb2\ud84d\udd23\uda20\udf47\udb7f\uddc4\ud946\udfd8\udadc\udedd\uda44\udd93\udb18\udf0a\udb11\uddd2\udb1c\udc69\u369d\udb7e\udfe6\uda85\ude58\ud86c\udf3e\udb50\udd4c\ud88d\udc47\ud9eb\udf02\ud836\udd8d\ud899\uddff\udb53\udfc6\uda5e\ude5b\udba2\ude2c\ud975\ude0e\udbfd\uddfd\uda35\udf8e\udaf1\udf97\uda95\ude20\ud9fd\udc24",
        9, 85129, 1072037482, 4713010844263875568L, -14225L, true, true, (char) 44370, (char) 52126,
        Double.longBitsToDouble(0x3fd25768ac99602eL), Double.longBitsToDouble(0x3fe272ac074eddf4L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.String:=E1=90=80=F2=8C=BA=AE=F3=9C=85=98=00=F2=8F=AE=BE=F1=9D=B8=80=F0=9F=A7=95~=\015\012=00=F3=A0=A0=80 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 12, 14, 4, "\u1400\ud9f3\udeae\udb30\udd58\000\ud9fe\udfbe\ud937\ude00\ud83e\uddd5~\000\udb42\udc00", "\u6d56", "\uda8a\udcbe",
        3, 71641, 108, -7696416469806600118L, -100000L, false, true, (char) 28205, (char) 0,
        Double.longBitsToDouble(0x3fe3fe2800000000L), Double.longBitsToDouble(0x3fe128000289bdb4L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 4, "\u1400\ud9f3\udeae\000\ua803\ud8c6\udc79\u84cf\ud814\udd20\uda5f\udc62\ud97a\udf04\uda86\udf28\ud994\udd05\ud895\udc8a\ud88a\ude0d\ud8cc\udecf\ud9aa\udeeb\ud805\udc21\ud93d\udffc\ud9d1\ude46", "\u0925\ub164\uca10\ub385\u7083\u50c7\u967e\u31ef\uc3fa", "\uda00\udd9c\udbbc\udf9e\ud8b7\ude3a\ud991\udea7\ud9f6\udffa\ud9ea\udd0c\ud9b0\udf98\udaf9\ude25\ud81f\udd41\uda58\udcd0\udaad\udf93\ud902\ude70\u0a03\udbe1\udcdb\uda24\udef6",
        53, 94855, -1532439888, 6140224630882521037L, 11014L, false, true, (char) 35145, (char) 16866,
        Double.longBitsToDouble(0x3fec243ea3303dbdL), Double.longBitsToDouble(0x3fefebc9ac4a6f70L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 6, 12, 4, "\udbf8\udc6d\ud891\udc3e\ud868\udd44\ud8e8\udff0\uf002\ud940\udfc0\udb75\udc2f\udb98\ude22\uda3b\ude4b\udbe4\udd23\ud994\uddc9\uda95\udd87", "\ua28a\u75f4\uaec7\uc942\uc147\u97be\u6a9c\u205e\u613d", "\udbe2\ude38\uf508\ud88c\udc46\udacc\ude4a\ud9e3\uded2\u1d3a\ud9a5\uddcb\uda8b\udeae\udad0\udd83\udbc2\ude35\udaa5\udf0b",
        28, 82361, -517303839, -7798084345429064533L, -71922L, false, true, (char) 39543, (char) 15302,
        Double.longBitsToDouble(0x3fefa8101f39206cL), Double.longBitsToDouble(0x3fe7d7aad248d9f2L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 16, 4, "\ud949\udc52\ud99b\ude6c\ud84f\udfa3", "\u00fc\000\000\000", "\ud895\udc8a",
        49, 31771, 0, -62455808L, 23756L, false, false, (char) 50554, (char) 62517,
        Double.longBitsToDouble(0x3fe0ceaaa4697cd8L), Double.longBitsToDouble(0x3e44500000000000L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 7, 4, "\udbf8\udccb\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud925\uddf7\udad0\udca4\udb98\udd65\ud960\ude3c\ud9e0\udfdb\ud994\uddc9\ud895\udc8a\ud9f9\udfdb\udb19\udfbd", "\uaf8f\uc942\u72b0\u97be\u6a9c\u47ec\uca10\uaa6b\u2121\u849d\u3055\u3d40\ubbeb", "\udb97\udee4\udaff\udec0\ud8c7\udc09\udaa9\udd8b\ud949\udf7c\uda34\udd0a\ud804\udf93\udbb0\ude5a\ud91b\udf53\udbb8\udee6\uda30\uddc9\ud99b\udcd0\u839c",
        8, 8398, 792006215, -4450889312749149687L, -79878L, true, true, (char) 36916, (char) 38631,
        Double.longBitsToDouble(0x3febdbd58d087e0eL), Double.longBitsToDouble(0x3fdfdad1dbc163eaL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=[B:[[61, 67, 56, 122, 61, 67, 51, 126, 44, 61, 68, 49]] |a1=[B:[[-56, 122, -61, 126, 44, -47]]\0121=[B:[[61, 67, 56, 122, 61, 67, 51, 126, 44, 61, 68, 49]] |a1=[B:[[-56, 122, -61, 126, 44, -47]]\012",
        Z.run(T, 2, 19, 3, 4, "\udbf8\udcaa\ud9f3\udeae\uda5c\ude01", "\u3fd6\u4800\u5a66\uc519", "\ud990\udc70",
        22, 43043, 1055332981, -2327037036499352583L, 23756L, false, false, (char) 50554, (char) 62517,
        Double.longBitsToDouble(0x3fe0ceaaa4697cd8L), Double.longBitsToDouble(0x3fe78ae68d147ce8L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:??? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:??? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 7, 4, "\udba6\udd4b\ud962\udf83\udbb9\udd39", "\u3fd6\u4800\u5a66\uc519", "\ud895\udc8a",
        7, 99709, 1055332981, -4272592075523407056L, 23756L, true, true, (char) 11825, (char) 62517,
        Double.longBitsToDouble(0x3fe8ceaaa4697c5fL), Double.longBitsToDouble(0x3fe78ae68d147c42L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=[B:[[-120, -103, -32, 45, 76, 86, -37]] |a0=[B:[[-120, -103, 13, -32, 45, 76, 86, -37]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 6, 17, 12, "\udbb8\uddc9\ud93d\udd10\udb5d\udc7c\ud886\udf0b\uefb7\ud925\uddf7\udbd5\udd11\udb98\udd55\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\ud9b8\udf08",
        3, 5817, -236854420, -7644105275674841014L, -56218L, true, false, (char) 53757, (char) 8254,
        Double.longBitsToDouble(0x3fe014028510dc16L), Double.longBitsToDouble(0x3fecac4ded2191c4L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:?????????????????????????????????????????????????????????????????????? |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F4=8E=82=AA=F1=A5=89=BF=F1=B6=A5=AD=F2=92=B9=A5=EE=BE=B7=F1=99=97=B7=F1=BD=\015\012=A8=91=F1=A6=9D=A0=F0=B1=A7=AE=F3=A6=BB=91=F0=A2=82=98=F1=AB=98=9C=F2=AB=88=\015\012=89=F3=AC=B3=84=F2=94=A5=9A=F4=88=B2=BD=F3=A8=8E=82=F2=A7=A9=AC=F1=91=B3=9D=\015\012=F1=AB=85=AA=F3=8A=83=98=F1=85=9F=BB=F2=88=95=B4=F1=9B=A7=A1=F1=B0... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 7, 12, 0, "\udbf8\udcaa\ud954\ude7f\ud99a\udd6d\uda0b\ude65\uefb7\ud925\uddf7\ud9b6\ude11\ud959\udf60\ud886\uddee\udb5b\uded1\ud848\udc98\ud96d\ude1c\uda6c\ude09\udb73\udcc4\uda12\udd5a\udbe3\udcbd\udb60\udf82\uda5e\ude6c\ud907\udcdd\ud96c\udd6a\udae8\udcd8\ud8d5\udffb\ud9e1\udd74\ud92e\udde1\ud982\ude4d\ud898\udf92\uda1d\udc4b\ud958\udf6f\ud9a7\ude3b\ud92f\udd7e\udb64\ude3c\ud975\udd56\ud936\udd1d\uda98\udc81\ud804\uddab\udb95\udd5d\ud957\ude6a\uda5c\udc21\udb86\udc0b\ud830\udfd0\udb42\udde3\ud9bb\udcfb\ud8c5\udd33\ud999\ude50\ud98f\udf15\ud826\ude60\ud924\udc07\ud9d9\uddad\ud83f\udf00\ud98c\uddc5\ucdc5\udb64\udca2\ud8ee\uddee\udb86\ude10\ud9af\udf78\ud87a\ude7a\ud91f\ude22\ud813\udd3d\ud934\ude66\uda62\ude22\ud999\udcb9\udb50\udf01\udb66\ude15\udb13\udf15\u8a5a\uda14\udcc4\ud984\udf64\ud83c\ude04\ud9ca\ude3b\ud829\udcb7", "\u0e6c\u2b99\u696e\u9780\u866b\u0a23\u9f9f\u555a\u9cae\uc33d", "\u7340\ud836\uddbb\udb75\udeca\ud9ef\udd05\uda3c\udeaf\uda1d\udcaf\u3dd1\udb3d\udd84\ud95b\udf9b\udb67\udd36",
        50, 6982, -945837745, -8286842169951592617L, -75886L, false, false, (char) 22291, (char) 62293,
        Double.longBitsToDouble(0x3fec4a278f760c3fL), Double.longBitsToDouble(0x3fe4bd7b32029abfL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=[B:[[-63, 107, 60, 94, 119, 60, 72]] |a0=[B:[[-63, 107, 60, 94, 119, 60, 10, 72]]\0121=[B:[[-63, 107, 60, 94, 119, 60, 72]] |a0=[B:[[-63, 107, 60, 94, 119, 60, 10, 72]]\012",
        Z.run(T, 2, 16, 0, 18, "\u82f1\ud99b\ude6c\ud98e\udea7\udb6c\udf3a\uda78\udd59\ud9ab\ude44\uda4d\uddea\ud999\udc83\ud82a\udf47\uda22\udfeb\udbe0\ude3c\ud9e4\udf8b\ud904\udefe\ud928\udcb2\ud948\udc79\udaaa\udd84\uda90\udf07\udaee\uded1\u958b\uec0b\uda6f\ude28\uda63\udfc9\udbf3\ude06\u7eb8", "\u8965\u4929\u5c9c\uc9f4\u17d1\u017a\u4855\u27ec\u5656\u2717\u4634\uc335\ubc01\ub8f7\u7ddf\u5c9c\u0346\u28ed\ua746\u5812", "\udb02\ude7f\ud862\udcc1\ud8ae\udf51\udaa6\udd6d\u4e71\udbea\udd5c",
        51, 8834, 438624955, -8992712880421645545L, -80258L, false, true, (char) 26561, (char) 31028,
        Double.longBitsToDouble(0x3fd54cd0571fa66aL), Double.longBitsToDouble(0x3fe5f6adf57a09ecL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=[B:[[38, 61, 48, 54, 121, 102, 32, 61, 49, 68, 63, 61, 50, 48]] |a1=[B:[[38, 6, 121, 102, 32, 29, 63, 32]]\0121=[B:[[38, 61, 48, 54, 121, 102, 32, 61, 49, 68, 63, 61, 50, 48]] |a1=[B:[[38, 6, 121, 102, 32, 29, 63, 32]]\012",
        Z.run(T, 2, 19, 3, 15, "\udb56\udc36\udba9\udf96\ud850\udc4d\udb6f\udc50\ud900\udcd9\uda86\udf73\ud9b9\udd02\udb98\uddcc\ud801\udc36\udb0e\udeb4", "\ud2ee\ua95e\u5c44", "\udb44\udf3f\u3a97",
        16, 10482, -1001098625, -8334581703610602256L, 56536L, true, true, (char) 64284, (char) 4179,
        Double.longBitsToDouble(0x3fde781b5bf69864L), Double.longBitsToDouble(0x3f88f95e00209700L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=[B:[[-101, 50, -73, 1, 12, -85]] |a0=[B:[[-101, 50, -73, 1, 12, 61, 97, 66]]\012",
        Z.run(T, 1, 0, 14, 10, "\ueccb\uda62\udce7\uda31\udf3c\ud96d\ude91\udb72\udfe9\udb6a\udc85\ud9b9\ude05\udb98\uddd3\ud960\ude3c\ud9e0\udfdb", "\u6e35\ub878", "\udb0c\udda2\ud9ec\ude18",
        0, 82461, -2118759115, 7661874754752573120L, -93103L, false, true, (char) 32350, (char) 6940,
        Double.longBitsToDouble(0x3fe3fe2e9dbd81e3L), Double.longBitsToDouble(0x3fe12fdec2899cb4L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=new org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 15, 15, 3, "\udb5b\udd93\ud9a1\ude26\ud939\udd3c\udbf4\udf56", "\ud460", "\ud8de\ude8f\ud8e7\ude77\ud944\udc55\udb6b\udd5f\ud9d8\udffd\udb21\udd07\udb94\udc36\udbe6\udd2a",
        16, 47572, 1901600026, -9118093102175980920L, -55530L, false, true, (char) 32039, (char) 52692,
        Double.longBitsToDouble(0x3fd0abbea4feda04L), Double.longBitsToDouble(0x3fdbd81e384bf7b0L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=[B:[[62, 61, 48, 48, 70]] |a1=[B:[[62, 0, 70]]\0121=[B:[[62, 61, 48, 48, 70]] |a0=[B:[[62, 0, 70]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 3, 10, 4, "\uab6e\ud830\udf76", "\u3101\ub1cd", "\udb39\udcf5\ud9e0\udfdb\ud8f8\udd2d\udb7b\udd9f\ud877\uddf4\udb3f\udf7c\ud9e7\uddab\udb41\ude34\udbbb\udd35\ud92c\uddd4\udb90\udfc5\uda5e\udc0a\ud88d\ude4a\udb81\udc93\udb4d\udfd6\udbe7\udc63\ud9ba\udf23\ue27e\ud9fb\udc4b\ud95a\ude0c\ud870\udf0e\ud92f\udd7e\udb64\ude3c\udba4\udc4e\udb9b\udc02\udb39\udcd0\ud8b5\udc7f\ud8b9\udf0a\ud9a9\udd18\ud897\udd3b",
        2, 96371, -1593365940, -2006559156165019204L, 88419L, true, true, (char) 15229, (char) 42527,
        Double.longBitsToDouble(0x3fdd49fb7689d01aL), Double.longBitsToDouble(0x3fd25e02e6eefec4L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 11, 11, 1, "\ud9b4\udd12", "\u712a\u727c\ub21e\u2e21\u0900\u4599\u6a48\u21e4", "\uda65\ude88\ud999\udd96",
        12, 74070, 1063720609, 1078949538773915222L, 89546L, true, true, (char) 65288, (char) 28431,
        Double.longBitsToDouble(0x3fc67302c0c5bac8L), Double.longBitsToDouble(0x3fd7a45a24ff8ba6L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 4, "\udbf8\udcaa\ud973\udeae\ud850\udc07\ud9bd\udce5\ud88c\uded0\ud83b\udc02\ud83e\uddd5\ud929\udd54\ud960\udea2\ud811\udfd2", "\ucdda\u60b3\u22f2", "\uda81\ude84\ud9db\udc37\ud84c\udfc9\uda18\udf70\uda55\ude87\ud9c1\udfc1\ud92e\udde1\ud982\ude4d\ud9d8\ude33",
        58, 81115, -1773787050, 7930717427944680961L, 53895L, true, false, (char) 3070, (char) 19033,
        Double.longBitsToDouble(0x3fe9f80b8197d47dL), Double.longBitsToDouble(0x3fe6ffa1ce59d416L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=[B:[[60, -32, 109, 86, -57, -121]] |a0=[B:[[60, 13, -32, 109, 13, 86, -57, -121]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 1, 6, 17, 12, "\u086c\ud93d\udd10\ud89d\udd3d\ud886\udef7\uefb7\ud925\uddf7\udbd5\udd11\udb98\udd55\ud960\ude3c\ud9e0\udfdb", "\u6d8c", "\ud9b8\udf08",
        3, 5817, -236854420, -7644105275674841014L, -56218L, true, false, (char) 53757, (char) 8254,
        Double.longBitsToDouble(0x3fe014028510dc16L), Double.longBitsToDouble(0x3fecac4ded2191c4L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.String:=F4=8E=82=AA=F1=A5=89=BF=F1=B6=A5=AD=F2=92=B9=A5=EE=BE=B7=F1=99=97=B7=F1=BD=\015\012=A8=91=F1=A6=9D=A0=F0=B1=A7=AE=F3=A6=BB=91=F0=A2=82=98=F1=AB=98=9C=F2=AB=88=\015\012=89=F3=AC=B3=84=F2=94=A5=9A=F4=88=B2=BD=F3=A8=8E=82=F2=A7=A9=AC=F1=91=B3=9D=\015\012=F1=AB=85=AA=F3=8A=83=98=F1=85=9F=BB=F2=88=95=B4=F1=9B=A7=A1=F1=B0... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F4=8E=82=AA=F1=A5=89=BF=F1=B6=A5=AD=F2=92=B9=A5=EE=BE=B7=F1=99=97=B7=F1=BD=\015\012=A8=91=F1=A6=9D=A0=F0=B1=A7=AE=F3=A6=BB=91=F0=A2=82=98=F1=AB=98=9C=F2=AB=88=\015\012=89=F3=AC=B3=84=F2=94=A5=9A=F4=88=B2=BD=F3=A8=8E=82=F2=A7=A9=AC=F1=91=B3=9D=\015\012=F1=AB=85=AA=F3=8A=83=98=F1=85=9F=BB=F2=88=95=B4=F1=9B=A7=A1=F1=B0... |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 12, 12, 0, "\udbf8\udcaa\ud954\ude7f\ud99a\udd6d\uda0b\ude65\uefb7\ud925\uddf7\ud9b6\ude11\ud959\udf60\ud886\uddee\udb5b\uded1\ud848\udc98\ud96d\ude1c\uda6c\ude09\udb73\udcc4\uda12\udd5a\udbe3\udcbd\udb60\udf82\uda5e\ude6c\ud907\udcdd\ud96c\udd6a\udae8\udcd8\ud8d5\udffb\ud9e1\udd74\ud92e\udde1\ud982\ude4d\ud898\udf92\uda1d\udc4b\ud958\udf6f\ud9a7\ude3b\ud92f\udd7e\udb64\ude3c\ud975\udd56\ud936\udd1d\uda98\udc81\ud804\uddab\udb95\udd5d\ud957\ude6a\uda5c\udc21\udb86\udc0b\ud830\udfd0\udb42\udde3\ud9bb\udcfb\ud8c5\udd33\ud999\ude50\ud98f\udf15\ud826\ude60\ud924\udc07\ud9d9\uddad\ud83f\udf00\ud98c\uddc5\ucdc5\udb64\udca2\ud8ee\uddee\udb86\ude10\ud9af\udf78\ud87a\ude7a\ud91f\ude22\ud813\udd3d\ud934\ude66\uda62\ude22\ud999\udcb9\udb50\udf01\udb66\ude15\udb13\udf15\u8a5a\uda14\udcc4\ud984\udf64\ud83c\ude04\ud9ca\ude3b\ud829\udcb7", "\u0e6c\uc34d\uc053\u6895\u362b\u0a23\u9f9f\u555a\u9cae\uc33d", "\u7340\ud836\uddbb\udb75\udeca\ud9ef\udd05\uda3c\udeaf\uda1d\udcaf\u3dd1\udb3d\udd84\ud95b\udf9b\udb67\udd36",
        47, 96810, -945837745, -8286842169951592617L, -75886L, false, false, (char) 22291, (char) 62293,
        Double.longBitsToDouble(0x3fec4a278f760c3fL), Double.longBitsToDouble(0x3fe4bd7b32029abfL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=[B:[[33, 61, 68, 48, 61, 67, 51, 104, 63, 32, 61, 68, 48, 61, 49, 68]] |a1=[B:[[33, -48, -61, 104, 63, 32, -48, 29]]\0121=[B:[[33, 61, 68, 48, 61, 67, 51, 104, 63, 32, 61, 68, 48, 61, 49, 68]] |a1=[B:[[33, -48, -61, 104, 63, 32, -48, 29]]\012",
        Z.run(T, 2, 19, 3, 15, "Q\000\udaf3\udc98\udb6f\udc50\ud900\udc4d\uda86\udf73\u008c\udb98\udd4b\ud801\udc36\udb2f\udcc4", "", "\u1a75\uda8b\udde4\udb60\udfc0\000\000\000\udae8\udc8e\udaf7\udc7b\u0f48\uf4f0\ud96b\udd26\ud8ee\udf82\000\000\000\000\ud80f\udd54\uda16\udca4\ud8a8\udea0\ud9cc\udec2\ud9ce\udef1\uda12\udd27\udb86\udc1e\ud935\udfa3\udb6b\udfb4",
        6, 45698, -810230900, 8367670911726068375L, 27449L, false, false, (char) 11388, (char) 64083,
        Double.longBitsToDouble(0x3fedda9d0edf6e45L), Double.longBitsToDouble(0x3fd9ba62eadb3080L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=[B:[[-56, 122, -61, 126, 32, -41, 58, -63]] |a0=[B:[[-56, 122, -61, 126, 32, -41, 58, -63]]\012",
        Z.run(T, 1, 16, 2, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udb6a\udff1\uefb7\ud925\uddf7\ud83e\uddd5\udb98\uddcc\ud960\ude3c\ud9e0\udfdb", "\u41d2", "\udbf3\udfa4",
        3, 54849, -236854420, -7696416100439412662L, -93103L, false, true, (char) 32350, (char) 6940,
        Double.longBitsToDouble(0x3fe3fe2e9dbd81e3L), Double.longBitsToDouble(0x3fe12fdec289bdb4L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 10, "\ud813\udf2e\udb7d\ude17", "\u3eb4\ub6ee\ub20f\u5f36\u0787\u5dc7\u2977\u41d8\u6d8c\u2ba5\u5421", "\uda1a\udfaf\udbd7\ude96\udb1d\udc88\udb8b\udd02\ud960\udf57\ud90c\ude1d",
        50, 80798, -1849217677, 4985781293885412730L, -82343L, true, true, (char) 28147, (char) 25866,
        Double.longBitsToDouble(0x3fc323562f4d2c24L), Double.longBitsToDouble(0x3fbe407f48a600e0L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 5, 7, "\u1400\ud9f3\udeae\000\ua803\ud8c6\udc79\u84cf\ud814\udd20\uda5f\udc62\ud97a\udf04\uda86\udf28\ud994\udd05\ud895\udc8a\ud8de\udd45\udb77\udddb\ud9aa\udeeb\ud805\udc21\ud93d\udffc\ud9d1\ude46\ud8da\udd17\uda44\udf52\udac9\udffa\ud8f0\udd73\ud9e1\udd74\udb51\udf70\ud90a\udc31\ud9ac\udcb2\ud842\ude83\udbab\udc61\ud9e6\ude7c\udb99\udf9f", "\u50f9\u4080\u49b8\u8665\ucfa2\u14bc", "\uda58\udcd0\udaad\udf93\ud902\ude70\u0a03\udbe1\udcdb\udb9e\ude93",
        45, 94693, -1532439888, 6140224630882521037L, 11014L, false, false, (char) 35287, (char) 16866,
        Double.longBitsToDouble(0x3fec243ea3303dbdL), Double.longBitsToDouble(0x3fefebc9ac4a6f70L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=[B:[[-56, 4, 56, 20, -72, 81]] |a0=[B:[[-56, 61, 13, 4, 56, 20, -72, 81]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=java.lang.String:=F4=8E=81=AD=F3=9F=90=B4=F0=AA=85=84=F1=8A=8E=81=EF=80=82=F1=A0=8F=80=F3=AD=\015\012=90=AF=F3=B6=88=A2=F2=9E=B9=8B=F4=89=84=A3=F0=B4=94=87=F2=B5=96=87 |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 6, 12, 4, "\udbf8\udc6d\udb3d\udc34\ud868\udd44\ud8e8\udf81\uf002\ud940\udfc0\udb75\udc2f\udb98\ude22\uda3b\ude4b\udbe4\udd23\ud891\udd07\uda95\udd87", "\ua28a\u75f4\uaec7\uc942\uc147\u97be\u6a9c\u205e\u613d", "\udbe2\ude38\uf508\ud88c\udc46\udacc\ude4a\ud9e3\uded2\u1d3a\ud9a5\uddcb\uda8b\udeae\udad0\udd83\udbc2\ude35\ud8ca\udc59\udb03\udd78\udabb\udd05",
        21, 34947, 558175727, 2696031622538308799L, -92248L, false, false, (char) 18148, (char) 52010,
        Double.longBitsToDouble(0x3fe7d7aad748d9f2L), Double.longBitsToDouble(0x3fd2f2c3f9d992d8L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 12, 12, 0, "\udb11\ude7f\uda50\udd58\ud909\udec4\uda0b\ude65\uefb7\ud925\uddf7\ud9b6\ude11\ud959\udf60\ud886\uddee\udb5b\uded1\ud848\udc98\ud96d\ude1c\uda6c\ude09\udb73\udcc4\uda12\udd5a\udbe3\udcbd\udb73\udc2b\uda5e\ude23\ud907\udcdd\ud96c\udd6a\udae8\udcd8\ud8d5\udffb\udad7\udd70\udb15\udd2e\udbf8\uddbc\ud898\udfcf\uda1d\udc4b\ud958\udf6f\ud9a7\ude3b\ud92f\udd7e\udb00\ude0a\ud907\udd6d\ud936\udc72\udbae\ude8d\ud804\ude26\udb95\udd5d\ud957\ude6a\uda5c\udc21\udb86\udc0b\ud830\udfd0\udb42\udde3\ud9bb\udcfb\ud8c5\udd33\ud999\ude50\ud98f\udf15\ud826\ude60\ud924\udc07\ud9d9\uddad\ud83f\udf00\ud98c\uddc5\ucdc5\udb64\udca2\ud8ee\uddee\udb86\ude10\ud9af\udf78\ud87a\ude7a\udba4\uddc5\ud813\udd4d\ud934\ude66\uda62\ude22\ud999\udcb9\udb50\uded8\udb66\ude15\udb13\udf15\udb62\udf9e\uda14\udcc4\ud984\udf64\ud83c\ude04\ud9ca\ude3b\ud81f\ude12", "\u2eab", "\udbc8\udf87\u86ac\ud94c\ude8a",
        38, 76395, 246213450, -916022590643670482L, -13054L, true, true, (char) 37686, (char) 57303,
        Double.longBitsToDouble(0x3fecddb45c97bc26L), Double.longBitsToDouble(0x3feab854c07a9b0dL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.DecoderException\012",
        Z.run(T, 2, 6, 12, 4, "\udbf8\udc6d\udb3d\udc34\ud878\udc6d\udad4\udf37\uf002\udabb\ude5f\ud839\udc31\udb98\ude22\uda3b\ude4b\uda62\ude42\ud8a0\udc5c\ud861\udef9", "\u453c\u75c1\uaec7\u0697\u6ed7\u9b45\uc7ef", "\uda42\udc69\udbc7\udc30\udbdc\udf2a\uf508\ud9e7\udd57\udb80\udc0f\ud9c9\udda3\u1d3a\udb6d\udc0f\ud841\udd7c",
        4, 48610, 1278704736, 6470172570007679786L, 87493L, true, true, (char) 23487, (char) 53800,
        Double.longBitsToDouble(0x3fd51fc9dc9062f4L), Double.longBitsToDouble(0x3fe7266743f50241L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=[B:[[-56, 4, 56, 20, -72, 81]] |a0=[B:[[-56, 61, 13, 4, 56, 20, -72, 81]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[-56, 4, 56, 20, -72, 81]] |a0=[B:[[-56, 61, 13, 4, 56, 20, -72, 81]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 6, 6, 10, "\udbf8\udc6d\udb3d\udc34\ud868\udd44\ud8e8\udf81\uf002\ud940\udfc0\udb75\udc2f\u0ef8\uda3b\ude4b\udbe4\udd23\ud891\udd07\uda95\udd87", "\ua28a\u01cb\uaf2c\uc942\uc147\u97be\u6a9c\u205e\u613d", "\udbe2\ude38\uf508\ud88c\udc46\udacc\ude4a\uda5e\udebd\uda66\udc0e\ud887\udf98\uda8b\udf3c\udad0\udd83\udbc2\ude35\udbc3\udf76\ud9a1\udc01\uda16\udcd4",
        0, 34947, 558175727, 2696031622538308799L, -92248L, false, false, (char) 18148, (char) 55035,
        Double.longBitsToDouble(0x3fe7d7ac4f48d9f2L), Double.longBitsToDouble(0x3fd2f2c3f9d992d8L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=[B:[[-56, -93, 56, -53, -72, 81]] |a0=[B:[[-56, 61, 65, 51, 56, -53, -72, 81]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=[B:[[-56, -93, 56, -53, -72, 81]] |a0=[B:[[-56, 61, 65, 51, 56, -53, -72, 81]] |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 6, 6, 8, "\udbf8\udc6d\ud971\udc63\ud868\udcfb\ud8e8\udf81\uda36\udce0\ud8d2\udc82\uda11\udef5\ud896\udd25\uda80\udf7b\udbfa\udc9f\ud891\udd07\udbc6\udd35", "\ua28a\u01cb\uaf2c\uc942\uc147\u97be\u6a9c\u205e\u613d", "\udbe2\ude38\uf508\ud88c\udc46\udacc\ude4a\uda5e\udebd\uda66\udc0e\ud887\udf98\uda8b\udf3c\udad0\udd83\udbc2\ude35\udbc3\udf76\ud9a1\udc01\uda16\udcd4",
        29, 34947, 558175727, 2696031622538308799L, -92248L, false, false, (char) 18148, (char) 55035,
        Double.longBitsToDouble(0x3fe7d7ac4f48d9f2L), Double.longBitsToDouble(0x3fd2f2c3f9d992d8L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=[B:[[61, 67, 56, 122, 61, 67, 51, 126, 32, 61, 68, 55, 61, 65, 48, 61, 67, 50]] |a1=[B:[[-56, 122, -61, 126, 32, -41, -96, -62]]\012",
        Z.run(T, 1, 3, 3, 4, "\udbf8\udcaa\ud9f3\udeae\ud850\udc07\udbd0\udef2\ud86f\udd34\ud925\uddf7\uda35\udc30\ud929\udce7\ud960\udea2\ud811\udfd2\udad7\ude3b\ud89c\ude64\udb13\udefd\udaee\udd14\uda12\udd5a\udb9a\uded0\udb60\udfc0\udb44\udf3f\ud9d7\udc1b\uda5e\udc0a\udae8\udcd8\uda55\ude87\ud9c1\udfc1\ud92e\udde1\ud982\ude4d\udb5b\ude55\udba0\udd52\ud95a\ude6b\udbdb\udc43\ud99f\udff7\ud87e\udfd1\udbdb\udfbf\ud89b\udf59\ud954\uded9\uda5a\udef1\ud931\udca7\udab9\udf99\udac0\ude66\udb89\udcad\ud946\udce5\ud9e1\udc48\udb39\ude25\udac6\udef6\uda03\ude1d\ud9d4\uddc8\ud9bb\udd84\uda72\udd79\ud8a7\udd64\u6244\ud951\udf8c\udb21\ude6e\udb12\udffd\uda4a\uddc2\udb19\uddb5\ud8a3\udf30\ud9de\udeb9\uda1e\udc58\udb6e\udcd8\ud919\uded0\ud842\udf91\uda58\udc3b\uda55\udfbf\ud8c9\udf7d\udb3d\udeaf\udb7f\udeb5\udbf1\udfc2\udbfb\udffd\ud915\uddfe\ud800\ude7e\uda32\udde2\udb29\uddc7\udbac\udffd\u1074\ud80a\udd3f\ud9ac\udcd9\udac3\udefe\ud860\uddc7\u978f\ud86b\udc77\udb98\udcd6\udb4a\udd4e\ud884\udc8b\udbab\udc16\udb08\udfad\udaa7\udceb\udb87\udcf0\udb5b\udd37\udbaf\udc8f\udb91\ude7f\ud842\udff9\u58e2\ud865\udcbd\udae6\udc35\ua4f5\ud8b5\udc7d", "\u265b", "\udb5b\udebc\uda1d\udfaf\ud9aa\udea7\udb29\udfd7\ud873\udd62\uafe3\udb4c\udd7f\ud869\udd6a\ud979\udcf9\ud96d\udc71\ud9b0\udeb4\uda21\udfc0\udb57\udf8e\ud97d\udc2b\u868c\udab0\udfab\ud967\udc4d\udb06\udeb3\ud81d\udc7d\uda4f\udf21\uda2f\ude1b\udba3\udd19\ud8e3\udf6e\udbe8\udd18\uda90\ude4b\ud96d\udc38\ud903\udef9\udacb\udda4\udb78\udccd\udb44\udded\udb00\udf9e\ud9ac\udcc0\udb46\ude87\ud97d\uddf8\uda5a\udc02\ud871\udeb6\uda9a\ude84\ud856\ude4d\u8942\ud9fa\udf07\uda15\udfcc\ud977\ude19\udaa9\udd54\ud9c9\udcc8\ud840\ude61\ud905\udd7d\uda73\udc97\ud92b\udde2",
        15, 95039, -403232346, -9021231787711712660L, 97518L, true, true, (char) 20516, (char) 64391,
        Double.longBitsToDouble(0x3fcd0cd4b615412cL), Double.longBitsToDouble(0x3feb4d964f975351L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\0121=null |this=org.apache.commons.codec.net.QuotedPrintableCodec:@?\012",
        Z.run(T, 2, 8, 8, 11, "\ud9b4\udcb6\ud856\udc80", "\uc7d0\u3277", "\ud87d\udd92\ud9e0\udfdb\uda4c\uddc5\ud88a\udc8a\uda1c\udf53\udb1f\udcaa\udab3\udcc5\uda50\ude33\uda73\udc7a\ud9bc\udf3e\ud9ee\udcb5\udaf7\udc8d\uda64\udcd6",
        48, 90252, 1609733223, 8988196994135775411L, 85722L, true, true, (char) 3982, (char) 1222,
        Double.longBitsToDouble(0x3fe44deda683da36L), Double.longBitsToDouble(0x3fe7deac96481f24L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decodeQuotedPrintable|[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeByte|int,boolean,java.io.ByteArrayOutputStream|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeQuotedPrintable|int,java.io.ByteArrayOutputStream|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeQuotedPrintable|java.util.BitSet,[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|getUnsignedOctet|int,[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|isWhitespace|int|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decode|[B|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decode|java.lang.Object|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decode|java.lang.String|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decode|java.lang.String,java.lang.String|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encode|[B|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encode|java.lang.Object|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encode|java.lang.String|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encode|java.lang.String,java.lang.String|new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|getDefaultCharset||new:org.apache.commons.codec.net.QuotedPrintableCodec:",
    "C|org.apache.commons.codec.net.QuotedPrintableCodec|<init>|",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|decodeQuotedPrintable|[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeByte|int,boolean,java.io.ByteArrayOutputStream|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeQuotedPrintable|int,java.io.ByteArrayOutputStream|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|encodeQuotedPrintable|java.util.BitSet,[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|getUnsignedOctet|int,[B|static",
    "M|org.apache.commons.codec.net.QuotedPrintableCodec|isWhitespace|int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
