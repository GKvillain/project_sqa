package org.apache.commons.codec.language;
import org.junit.Test;
import static org.junit.Assert.*;
public class Soundex_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 5, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\ufc14\udb83\udf52\ud928\udf5b\udafc\udfa8\ud92f\udf9d\udbd2\udfed", "\u199a\ud117\u1636\u19c4\u78d7\ua1ab", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\udb8f\udfce\uda9d\udea8\ud9fd\udf9b",
        -2, 98932, 408451893, -7022317969876347557L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fdac2f357c0e5fcL), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 5, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\ufc14\udb83\udf52\ud928\udf5b\udafc\udfa8\ud92f\udf9d\udbd2\udfed", "\u199a\ud117\u1636\u19c4\u78d7\ua1ab", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\udb8f\udfce\uda9d\udea8\ud9fd\udf9b",
        -2, 98932, 408451893, -7022317969876347557L, 93457L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fdac2f357c0e5fcL), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 9, 4, "\ud846\udedc\010\000\uef00\udb7e\udf3e\udaf1\udee0\udafc\udfa8\ud92f\udf9d\ud8fa\udfe1", "\u4fd3\u5c0e\u1636\u19c4\u78d7\ua1ab", "\ud03f\uda4a\uded3\ud858\udd50\udab9\udf18\ud834\ude81\u8a00\000",
        -2, -804, 408420352, -7022317969876347557L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fdac2f351c0e5fcL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 9, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\ufc14\udb83\udf52\ud914\udf5b\uda83\udea5\ud92f\udf9d\ud947\ude57", "\u199a\uc181\ucd19\u99e6\u08cd\ua189", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\udbc6\ude0c\udaa3\udd10\ud9fd\udf9b",
        -2, 53564, 408424672, -7022317970099038885L, 9423L, true, false, (char) 49242, (char) 14982,
        Double.longBitsToDouble(0x3fdac2f357c0e5fcL), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 8, 6, 7, "\udb66\udcde", "\ucafd\u455a\ub1e7\u4cca\u48ee\u3cad\u552c\u5460\u199a\ub8f7\u5d95\u19c4\u78d7\ua1ab\u39db\u074a\u4e2c\u0b6e\u74b2\u07dd\ub639\u3764\u17da\u90b8\u7196\ua80f\u8ec5\u84cb\u3bc3", "\ud94d\udd26\ud8a5\udc0d\udb78\udc72\uda8e\ude0a\udab2\udd4d\uda0d\udef8\ud803\udd8a\ud89f\udf55\udb1f\uddde\ud964\udd7c\udb31\udda3\ud8f4\udc99\udb57\udd33\ud883\udca9",
        49, 9202, -1113626536, -4898552344620657888L, 20697L, false, true, (char) 39644, (char) 6077,
        Double.longBitsToDouble(0x3fd9bd11f05cc9caL), Double.longBitsToDouble(0x3fa94660a2f9a900L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 5, 11, "\ue245\ud956\udc8c\udb9c\udec7\ufc14\udb83\udf52\udaea\ude79\ud8be\udef4\udacb\udc5f\ud8ba\ude17\udb3d\udcda\ufaec\ud9d8\udf19", "\u19c4\u78d7\ua1ab\u39db\u27f7\ub30c\u2b35\u74b2\u07dd\ub639\u0ecd\u17da\u88cb\u629c\ua80f\u1b82\u8063\u886e\uaf93\u0ead\u57a8\u7938\u7814\u09c2\ubdc2\u723d", "\udb33\ude66\ud83c\udcab\udb60\udfdd\uda07\udf68\ud929\udca1\udaa2\udc07\udaa5\udf9c\ud9ff\udc36\udaa2\udda9\ud864\udeef\udb67\udc17\uda9c\udf66\ud99f\udc79\ud8b2\udc92\ud924\ude5a\udb69\uddaa\ud8b3\udeee\ud8b3\udf7d\ud9dd\udf29\uda87\udf87",
        36, 60637, -2119709501, 6167162945684642302L, -44459L, false, true, (char) 8120, (char) 32623,
        Double.longBitsToDouble(0x3fe2fb5f74577b12L), Double.longBitsToDouble(0x3fef1b1bf4875c27L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 4, 5, 3, "\ud8ac\udec9\ud93f\udf7e\udba2\uddf3\ud813\udc8d\udb37\udc4d\u867e\udafa\udffc\ud806\udc47\ua9dd", "\u199a\ud117\u1636\u19c4\u50b6\uc9be", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udb82\udf24\udb8f\udfce\uda9d\udea8\ud9fd\udf9b",
        -2, 41596, 408452029, -7022317969876347557L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fe529044b306edaL), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\ud846, \udedc, \ud882, \udc55, \udb96, \ude41, \ufc14, \udb83, \udf52, \ud928, \udf5b, \udafc, \udfa8, \ud92f, \udf9d, \udbd2, \udfed]]\012",
        Z.run(T, 1, 10, 5, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\ufc14\udb83\udf52\ud928\udf5b\udafc\udfa8\ud92f\udf9d\udbd2\udfed", "\u199a\ud117\u1636\u19c4\u78d7\ua1ab", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\udb8f\udfce\uda9d\udea8\ud9fd\udf9b",
        -2, 98932, 408451893, -7022317969876347557L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fdac2f357c0e5fcL), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 11, 5, 3, "\udaf8\udc0b\ud882\udc55\ud94b\ude3a\u9263\ud9ca\udc16\ud928\udf5b\ud8c0\udc4f\u0385\udbe0\udc96", "\ua06b\u6c8a\uaa06\u19c4\u78d7\ua1ab", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\ud995\udf52\udb0a\ude8b\ud9fd\udeec",
        23, 98932, 408451893, -7022317969876347557L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fd4b08357c0e5fcL), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 3, "\ud846\udedc\udbef\uded4\ud8bd\udcf8\ud8c7\udee0\udbb2\udea0\ud928\udf5b\ud943\uddeb\ud92f\udf90", "\u99f8\u14ed\u5144\u1636\u5553\u9d31", "\udb6f\udcb9\ud9e3\udf41\ud8b1\udf07\ud858\udda1\udab9\udf18\udb8f\udfce\uda9d\udea8",
        56, 95058, 157236420, -1056336943114407286L, 88544L, false, true, (char) 46578, (char) 41818,
        Double.longBitsToDouble(0x3fd45505c3585e6aL), Double.longBitsToDouble(0x3fef0397f667eae3L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 3, 11, 3, "\ud846\udedc\ud882\udc55\ud848\udc69\udbb8\udd55\udb83\udf52\ud928\udf5b\udafc\udfa8\ud92f\udf9d\udbd2\udfed", "\u199a\ud117\u1636\u19c4\u78d7\u60a3", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\udb8f\udfce\uda9d\udea8\ud9fd\udf9b",
        -2, 98932, 408451893, -7022317969876347557L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fdac2f357c0e5fcL), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\0121=void |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 5, 7, 3, "\u71d6\ud9b3\udffe\udb93\ude97\udba3\udf9a\udb9c\udc91\ud9ce\ude57\udb29\ude32\ud8df\ude2a\ud98d\udcf3\udb93\udd6b\ud9fe\udcc6\udab7\udc28\udbfe\uded8", "\u78d7\ua1ab\u39db", "\uda3b\udfc6\uee21\ud942\udcca\udb8f\udfce\uda9d\udea8\uda75\udda2\ud956\udf97\udb67\ude1a\ud930\udf67\udae4\udead\ud81f\udf57\ud853\udd0d\udbfd\uddc3\ud831\udd1a\udb45\udd6a\uda08\udfc9\ud8a1\udc9b\ud906\udf3e\ud896\udee1\udb9f\uddfc\udb0b\udefd\udb5c\udfbf\udafe\udebd\uda46\udceb\uda1b\udffc\ud87e\udd4f",
        33, 30326, 945000474, -8162144534178402091L, -34672L, false, true, (char) 18130, (char) 58137,
        Double.longBitsToDouble(0x3fc5f511f4461e1cL), Double.longBitsToDouble(0x3fd24c3c70e69fceL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 5, 3, "", "\u7369", "\ud928\udf5b\udafc\udfa8\ud92f\udf9d\udbd2\udfed\udb48\udf53\ufaec\ud8a1\udefd",
        -5, 88280, -1873775069, -1952274206490606648L, -100000L, false, false, (char) 0, (char) 12043,
        Double.longBitsToDouble(0x3fdc126854e71e10L), Double.longBitsToDouble(0x3fe062d779bc4e42L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 5, 3, "\ud846\udedc\udaf9\udf32", "\uc84d", "\ud930\udc22\udbd2\udfed\udb48\udf53",
        50, 4554, 196848432, 5785286096473585187L, 68245L, true, true, (char) 12303, (char) 34104,
        Double.longBitsToDouble(0x3fdc126854e71e10L), Double.longBitsToDouble(0x3fe062d779bc1942L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 2, "\ud846\udedc\ud882\udc55\udb96\ude41\ufc14\udb83\udf52\ud928\udf5b", "\u3c72", "\ud8fe\udc2c\u33e1\ud8d6\udfc9\uc78e\ud8d7\udf5b\uda78\ude7b",
        11, 469, -181819419, -3622339089966747893L, -57619L, false, false, (char) 16382, (char) 45394,
        Double.longBitsToDouble(0x3fe1f7fe137baa9fL), Double.longBitsToDouble(0x3fe818c2c635c698L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 5, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\ufc14\udb83\udf52\ud928\udf5b\udafc\udfa8\ud8c5\ude21\uc872", "\u199a\ud117\u1636\u19c4\u78d7\ua1ab", "\ud9d7\udea2\ud843\uddbc\ud858\udd50\udab9\udf18\udba7\ude50\uda9d\udea8\ud9f1\udd75",
        53, 98932, 408451893, -7022317969876347557L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fdac2f357c0e5fcL), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 11, 9, 4, "\ud874\uded3\ud882\udcbb\udb96\ude0f\ufb6a\udb83\udf52\ud928\udf5b\udafc\udfa8\ud92f\udf9d\udbd2\udfed", "\u199a\ud117\u1636\u19c4\u78d7\ua1ab", "\ud9e3\udf41\uda4a\uded3\uda88\udd48\udab9\udf18\udb8f\udfce\uda9d\udea8\udb1e\udc4c",
        -2, 98932, 408451893, -7022317969876347557L, 33852L, true, false, (char) 12667, (char) 25915,
        Double.longBitsToDouble(0x3fdf01f197c12b44L), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\ufc14\udb83\udf52\ud928\udf5b\udafc\udfa8\ud92f\udf9d\udbd2\udfed", "\u199a0\u06d1\u19c4\u20f4\u34ee", "\ud9e3\udf41",
        28, 63539, 0, 6485183464726497804L, -80118L, false, false, (char) 60798, (char) 0,
        Double.longBitsToDouble(0x3fd009e8b100435aL), Double.longBitsToDouble(0x3fd24c57a5caa61aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 5, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\ufc14\udb83\udf52\ud928\udf5b\udafc\udfa8\ud92f\udf9d\udbd2\udfed", "\u199a", "\uc78e\ud8d7\udf5b\uda78\ude7b\ud834\udd7c\udb6f\udcb9\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\udb8f\udfce\uda9d\udea8\ud9fd\udf9b\uda39\ude9c\udb33\uddac\ud8ff\udca4\udaf0\udd44\ud81f\udf57\ud853\udd0d\u2209\udbd2\udc40\ud94d\udd26\ud8a5\udc0d\udb78\udc72\ud9fc\udea1\udad1\uddfd\udb6d\udec7",
        2, 5035, 1987238562, 7827767304528812000L, 7064L, true, false, (char) 34443, (char) 55865,
        Double.longBitsToDouble(0x3fcd4f58079ca598L), Double.longBitsToDouble(0x3fe88e252d5c8156L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 5, 3, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\ud8ad\udd2b\ud9e1\ude67\uda9a\udff8\ud965\udc44\ud930\udc15\udbd2\udfed", "\u199a\ud117\u1636\u19c4\u78d7\ua1ab", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\udb8f\udfce\uda9d\udea8\ud9fd\udf9b",
        32, 12772, 293525900, 3756148019895834065L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fef2ed5dbe07238L), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 3, 3, "\u512b\ud882\udc9c\udb96\ude41\u5714\udb79\ude81\ud928\udf5b\ud932\udde2\udb82\ude45\udbd2\udfed\udb7a\udc4a\ufb59\uda2a\ude07\uda54\udc18\ud8d6\udfc9\uc78e\ud8d7\udf5b\uda78\ude7b\ud834\udd7c\udb6f\udcb9\ud9e3\udf41", "\u07dd\ub639\u0ecd\u17da\u90b8\u18d5\ua80f\ubff4\u4d45\u3b24\uaf93", "\ud916\udd66\ud923\udc33\ud9fc\udea1\udad1\uddfd\ud9e3\udf82\ud891\ude61\uda8f\udd7c\ud8e9\udfc3\udb17\udff4",
        26, 50629, -1562494361, -5491566130133555297L, -81163L, false, true, (char) 8468, (char) 37899,
        Double.longBitsToDouble(0x3fe90df415fab308L), Double.longBitsToDouble(0x3fe16fec2f301a79L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 7, 5, 3, "\ud846\udedc\ud882\udc55\ud92e\ude8d\udbab\udd5a\udb83\udf52\ud928\udf5b\udafc\udfa8\ud81f\udd74\udba3\udf18", "\u199a\ud117\u1636\u19c4\uce6a\ua3ab\u39db\u9ffa\ub30c\ua134\u74b2\u07dd\ub639\u733e\u95a0\u491b\u18d5\ua80f\u1b82\u1be4\u2434", "\ud94d\udd26\ud8ab\udc10\udb78\udc72\ud864\udd74\udad1\uddfd\ud8c1\uded2\ud924\udea8\udb48\udd6c\udb67\udf92\ud973\udeb0\ud952\udcd7\udb5b\udd96\udaa7\uddc1\udb75\udc90\ud90c\uddcd\udaa8\ude57\ucfef\ud82a\ude25\udaeb\udc25\uda2e\udf2b\udb47\udc1e\ud9d3\udc52\udb6a\udc3d\u92d9\udac4\udc0d\ud80b\udd1a\udb51\ude0e\ud85f\udfcc\uda6d\udecf\ud96d\udcc9\ud938\udde9\ud990\udf9c\uda6a\udeb1\uda69\udeaf\ud829\ude97\ud87a\ude66\udb03\udd77\ud80a\udd85\ud844\udfda",
        12, 37131, -77638604, 5413404880454110579L, -11155L, false, false, (char) 39630, (char) 36552,
        Double.longBitsToDouble(0x3fef976e28be0643L), Double.longBitsToDouble(0x3fde5c6b6cb4547eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 5, 3, "\ud846\udedc", "\ud2ea\u455a\ub1e7\u4cca\uc943\u3c08\u552c\u5460\u199a\ud117\u1636\u19c4\u77e3\ua1ab\u39db\u9ffa\ub30c\u5a35\u74b2\u07dd\ub639\u0ecd\u17da\u4daa\u1811\ua80f\u1b82\u4d45\000\uaf93\u00e5\000\u78f3\ub9f6\u02db", "\u3540\ud8f8\ude0d\udb31\uddeb",
        30, 47873, -998309831, 6014929828238753754L, 40678L, true, true, (char) 52128, (char) 58878,
        Double.longBitsToDouble(0x3fed656806c49f0aL), Double.longBitsToDouble(0x3fec2901bd2c54deL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 11, 5, 3, "\udb81\ude6e\udb2a\udd05", "\u455a\ub1e7\u4cca\u2a73\u4c5c\u98bb\u17ad\ubb5c\ud117\u1636", "\uda78\ude7b",
        36, 33433, -181819419, -3622339089966747893L, 26900L, false, false, (char) 16382, (char) 45394,
        Double.longBitsToDouble(0x3fe62080a310d97eL), Double.longBitsToDouble(0x3fe81bd81d5b9e8bL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\000\000\000\000\000\000\000\000\udbc7\udd83", "", "",
        1, 29243, 0, 69880321336487561L, -100000L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e30600000000000L), Double.longBitsToDouble(0x3fdbc4e420000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 1, 1, "\udb3c\udc38\ud882\udc55\ud8f5\udc1f", "\ub1e7\u4cca\u2a73\u3c72", "\ud9d8\udf19\u33e1\udb58\udd4b\ud810\ude8e\ud8d7\udf5b\uda78\ude7b",
        11, 469, -181819419, -3622339089966747893L, -57619L, false, false, (char) 2046, (char) 45348,
        Double.longBitsToDouble(0x3fdc41014c75dafcL), Double.longBitsToDouble(0x3fd35a05cab73d16L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 6, 1, "\ud818\udcdc\ud882\udc55\ud8b4\udffa\ud805\udcd2\ud857\uddfb\u9a73\udafc\udfa8\ud92f\udf9d\udbd2\udfed\udb48\udf53\ud825\udd80\ud9d8\uded1\u33e1\udad0\udc7c\ud808\udda6\ud8d7\udf5b\uda78\ude7b\ud834\udd7c", "\u59f5\u74b2\u58c5\uc7d7\u7e35\ua850\u454f\u18d5\u1fc3\u1c2c\ud00c\u324e\u679f\u1c9a\u57a8\u7938\u790e\u02db\u1691\u5150\u4fec\ud30a\u7920\u70a9\u2956", "\ud8d4\udded\ud866\udcc3\udb2c\udd35\udb78\ude6b\udb65\ude07\udbf4\udfb2\ud969\udca0\udb85\udd32\udbee\udf84",
        -1, 95654, 81034639, -1100382063673265642L, 64319L, false, false, (char) 19731, (char) 8869,
        Double.longBitsToDouble(0x3fe5b7bcbac3064dL), Double.longBitsToDouble(0x3feb3d8fd10f4bc8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 2, 7, 6, "\ud88c\ude4d\uda74\udffb\uda08\udc79\udabd\udfa4\ud98a\ude7a\ud928\udf66\udafc\udfa8\ud952\udfa6\udb31\ude4f\ud8c5\udf26", "\u108f\u9005\u8442\u5635\u6f50\u39db\u9ffa", "\ud90c\udde5\uda27\ude1b\udbb7\udd0c",
        4, 92540, 981487814, -6970450122598798938L, 58373L, false, false, (char) 58750, (char) 47486,
        Double.longBitsToDouble(0x3feb52d787d6b565L), Double.longBitsToDouble(0x3fee0ae84a5bf701L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 8, "\ud846\udf17\ud882\udc55\udb96\ude41\ud8fb\ude53\udbbd\udfcb\ud933\udd19\ud87e\ude63\udafb\uddbe\udbd2\udfed\ud941\ude0f\uda66\udc22\ud9d8\udf19\u33e1\ud8d6\udfc9\uc78e\ud8d7\udf5b\uda78\ude7b\udaf8\udfbf\uda9d\udeeb\ud9e3\udf41\uda41\udcd3\ud9bc\udcd0\ud9e2\udc87\ud9d6\udcb2\udab0\udf42\ud9fd\udf9b\uda39\ude9c\udb4a\udc57\ud909\uddd8\udaf0\udd44\ud81f\udf57\ud839\udf3f\u22a4\udbd2\udc40\ud94d\udd26\ud8a5\udc0d\udb78\udc72\ud9fc\udea1\udad1\uddfd\uda2a\udfe6\udb6e\ude1a\udbe7\udc10\ud8ca\ude8b\udb22\udf38", "\u580fE\u2570\u28a8\uc0fa\u1f8d\u0edc\u5321\u70eb\uc6e3\ubaab\u8ff8\ubbae\ub250\u9038\u2b25\ubf70\u97e4\ub546\ud23e\uaab1\u2e7a\u91dc\ud71c", "\ud8dd\udc13\ud8d9\udc97\udbbe\udcef\ud81a\udc24\ud9a1\ude2c\ud990\ude15\uda39\udd1b\u883b\udb65\uded4\uda78\ude93\ud8e9\udca8\ud8c4\udf7f\ud821\udee6\ud94c\uddbe\ud8a3\ude43\ud932\udc4d\uda8f\udf7b\udb5b\udebe\udab5\uddae\uda1e\ude96\ud804\udcb0\ud962\udc74",
        5, 24061, -956603407, 6222048238007614906L, -50704L, true, true, (char) 25605, (char) 29545,
        Double.longBitsToDouble(0x3fe0c9018f5e2dc4L), Double.longBitsToDouble(0x3fd9aad6b0302d8cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=void |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 2, 7, 3, "\ud846\udedc\ud882\udc55\udba2\udccd\udbd1\udcad\ud946\udced\ud928\udebd\udafc\udfa8\ud8af\udf9d\udbd2\udfed", "\ua4dc\u4f9b\u390e\u066e\u49a4\u2782", "\ud9e3\udf41\uea4b\ud858\udd60\udab9\udf18\udb8f\udfce\uda9d\udea8\ud9fd\udf9b",
        -2, 36564, 408451893, -7022317969876347643L, 51229L, true, true, (char) 41399, (char) 12806,
        Double.longBitsToDouble(0x3fd4597a17c0954eL), Double.longBitsToDouble(0x3fe33f571c658480L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 5, 0, "", "\u7369\ucafd\u455a\u5213\u4cca\u2a73\u3c72\u552c\u5460\u199a\ud117\u1636\u7bc3\u78d7\ua1ab\000\000\000\000\u2f0b\u07dd\ub639\u0ecd\u17da\u90b8\u18d5", "\ud81f\udf57",
        15, 26652, 1525703397, 5790582840995367237L, -92800L, true, false, (char) 44493, (char) 4282,
        Double.longBitsToDouble(0x3fec571ffb96bb22L), Double.longBitsToDouble(0x3fe34d0b0b1f7157L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 4, 5, 0, "\000", "", "\000",
        -5, -1000, 0, 0L, 96608L, false, false, (char) 0, (char) 45300,
        Double.longBitsToDouble(0x3e48000000000000L), Double.longBitsToDouble(0x3faa990680000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 1, 2, 10, 3, "\ud831\udce0\ud882\udc55\ud9a2\udc77\uda9c\udcf7\uda71\udd4b\ud928\udf5b\ud977\udea6\ud8ef\udf9d\udbd2\udfed\udb48\udf53\ufaec\ud9d8\udf19\udb58\udf37\ud8c7\udd29\udb88\udc7a\ud8ce\udd3c\udb6f\uddcd\ud8da\ude3e\ud9af\udf88\udae2\uddac\udb9b\ude48\ud8e9\udcb9\udab5\udf57\udb8f\udfce\udbaa\udd66\uda22\udc4e\ud981\udd0c\ud8ca\udea5\ud9af\udf44\udaf0\udd44\ud836\udd1d\ud843\udc0d\u2209", "\u7938\ub9f6\u02db\u7676\ub05c\u91bd\u4640\u6511\u4729\u023f\uad40\u4975\u26e9", "\u3d1a",
        11, 11250, -1813766591, 6549487036453955380L, -758L, true, false, (char) 34985, (char) 53271,
        Double.longBitsToDouble(0x3fbb37ec1ede7e10L), Double.longBitsToDouble(0x3fef8455aa7a391bL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 3, 3, 11, "\ud893\udcb9\ud898\udc22\udb06\udd6a\ud96a\ude23\udb7e\udf95\udaf1\udee0\udafc\udfa8\ud92f\udf9d\ud8fa\udfe1", "\u2e1d\u3de6\ud7bd\u4ab6\u096f\uc9de", "\ud9f0\uded6\ud9d3\udcba\ud995\udd6e\udab9\udf18\ud834\ude81\u8a68\000",
        -2, 11004, 411366361, -7022317969876347557L, 89028L, false, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fdac2f351c0e5fcL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 7, 9, 4, "\ud818\udc71\010\000\udb57\udebe\udbca\udd8a\udaf1\udee0\udafc\udfa8\ud92f\udf9d\udada\udcca\udbd4\udcf1\udbc6\udd02\ud8a1\udefd\ud9ff\ude1a\ud8d7\udc2a\u918e", "\uc7af\ua097", "\ud858\udd50\udab9\udf18\ud834\ude81\uda16\ude84",
        17, 95058, 196, 1754152572916840193L, 88544L, true, true, (char) 14829, (char) 61080,
        Double.longBitsToDouble(0x3fd45505c5fdd650L), Double.longBitsToDouble(0x3fc080ffde5b0000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 9, 3, "\ud846\udedc\uf56c\ud841\udf48\ufc14\udb83\udf52\ud84b\ude77\uda83\udf39\ud92f\udf9d\ud947\ude57", "\u199a\uc181\ucd19\ube98\u08cd\ua189", "\ud9e3\udf41\uda4a\udeb8\udb55\udf1f\udb37\udeb7\ud893\udf05\udaa3\udd3a\ud9fd\udf9b",
        40, 97610, 408460038, -7022317970099038885L, 85967L, false, false, (char) 43490, (char) 14982,
        Double.longBitsToDouble(0x3fdac2f357c0e5fcL), Double.longBitsToDouble(0x3fe33f571c5df905L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 9, 3, "\ud846\udc5f\ud882\udc55\udb0b\udcaf\uda7b\udd21\udae2\udf51\ud914\udf5b\udaa2\udda4\uda55\udeca\ud947\ude57\udae0\udedb\ufb52\ud9d8\udf19\udb84\udffd", "\u141c\uacbf\u4b96\ub476\ub270\u5a35\u74b2\ub468", "\ud896\ude43\udbb1\uddab\ud9e5\udefc\ud8e4\ude4f\udaf0\udd44\udb4d\ude8e\ud811\udd17\udaa8\udd2b\uda5e\udee9\ud9dd\udc8b\ud8a5\udc0d\udb78\udc72\ud9fc\udea1\udad1\uddfd\ud811\udd99\udaf9\udfc8\ud83d\udcb2\uc4d9\udaed\udce5\udaa3\udcaa\ud9a2\udd6c\uda4e\udf1a\ud88a\udf18\ud898\ude97\uda05\udcbb\ud927\udc9d\ud6b0\ud9de\udc13\ud8c2\ude34\udac7\udd3f\uda99\udd8a\ud9d7\udcdc\udb88\udd55\udaf4\uddfe\ud8ea\ude5e\uda97\udc77\udbc3\ude5c\ud84f\udd0e\ud855\udcb5\udaec\udcb1\u05a5\uda1d\udf48\ud8c1\udfbf\u921b\ud816\ude2a\udb62\udc0f\udb5f\uddcf\udb5c\ude0e\udb31\udcdd\udb45\udd31\uda77\udd99\ud8c9\udd31\udb48\uddf9\uda9c\udc1c\uda4e\udc4d\u1e5f\ud856\udc4c\udb11\udc47\ud8b7\udcaf\ud821\udfbf\ud941\udf25\uda01\uded0\ud943\udeed\ud866\udd9e\udbc3\udfe7\ud829\ude12\uda4b\udc47",
        40, 24147, -1893208869, 6358535390493524850L, -81981L, true, true, (char) 14152, (char) 7014,
        Double.longBitsToDouble(0x3fdaee8157af1b92L), Double.longBitsToDouble(0x3fd83456469bc8d2L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 9, 3, "\ud81d\udef5\ud882\udc55\udb96\ude41\ufc14", "\u4dac\u0e7d\u6896\u8a35\u54c6\u199a\uc181\ucd19\u99e6\u08cd\ua189\u39db\u9ffa\ub30c", "\udab9\udf18\udbc6\ude0c\udaa3\udd10\ud9fd\udf9b\ud93c\udcdd\ud9d2\udc11",
        27, 77187, 342332763, 788847789366684527L, -74038L, true, true, (char) 53472, (char) 22238,
        Double.longBitsToDouble(0x3fe33f571cc8f905L), Double.longBitsToDouble(0x3fc392ab7629c104L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:V000 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 8, 10, 7, "v", "\ucafd", "\uff6a\udb57\udd2b\udbd3\udc28\uaac4\000\ud9d8\udf19\udba6\udead\uda32\ude89\uc78e\ud8d7\udf5b\uda78\ude7b\ud834\udd7c\ud900\udd42\000",
        41, 63539, -1895289407, 6552555432551025164L, -80118L, false, true, (char) 42302, (char) 53082,
        Double.longBitsToDouble(0x3f91728b20001fa0L), Double.longBitsToDouble(0x3fd24c57a5caa61aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 6, 7, "\ud90a\udcb4", "\ucafd\u7d0e\u33e1\u4cca\u48ee\u3cad\u552c\u5460\u199a\ub8f7\u5d95\u19c4\u78d7\ua1ab\u39db\u074a\u4976\u9767\u74b2\u07dd\ub639\u3764\u17da\u90b8\u7196\ua80f\u8ec5\u84cb\u3bc3", "\ud94d\udd26\ud8a5\udc0d\udb78\udc72\uda8e\ude0a\udab2\udd4d\uda0d\udef8\ud803\udd8a\ud89f\udf55\udb1f\uddde\ud964\udd7c\udb31\udda3\ud8f4\udc99\udb57\udd33\ud883\udca9",
        13, 9202, -1113626536, -4898552344620657888L, 20697L, false, true, (char) 39644, (char) 6077,
        Double.longBitsToDouble(0x3fd9bd11f05cc9caL), Double.longBitsToDouble(0x3fa94660a2f9a900L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\udb66, \udcde, \ud994, \udc5e]]\0121=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\udb66, \udcde, \ud994, \udc5e]]\012",
        Z.run(T, 2, 10, 10, 11, "\udb66\udcde\ud994\udc5e", "\u455a\ub1e7\u81b8\u49bf\u3cad\u552c\u5460", "\ud885\udf3e",
        50, 50740, -369605688, 3606590043191349557L, 27542L, true, true, (char) 21574, (char) 59771,
        Double.longBitsToDouble(0x3fe062d779bcf042L), Double.longBitsToDouble(0x3fdaa63a8f882028L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 8, 6, 7, "\000", "\ucafd\u455a\ub1e7\u1f6b\000\u3509\u552c\u5460\u199a\u0df7\u5d95\u19c4\u78d7\ua1ab", "\udb32\ude21\udbd4\ude71\ud858\udd50\udab9\udf18\udb8f\udfce\uda08\udd1e\ud9fd\udf9b",
        -2, 78508, 408451893, 8253891965213315089L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fdac2f357c0e5fcL), Double.longBitsToDouble(0x3fe33f071cc8313aL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 3, 7, "\udb66\udcde", "\ucafd\u455a\u65e8\u4cca\u48ee\u3cad\u552c\u5460\u199a\ub8f7\u5d95\u19c4\u78d7\ua1ab\u39db\u6ba4\u4e2c\u0b6e\u74b2\u07dd\ub639\u3764\u17da\u90b8\u7196\ua80f\u8ec5\u84cb\u3bc3", "\ud94d\udd26\ud8a5\udc0d\udb78\udc72\uda8e\ude0a\udab2\udd4d\uda0d\udef8\ud803\udd8a\ud89f\udf55\udb1f\uddde\ud964\udd7c\udb31\udda3\ud8f4\udc99\udb57\udd33\ud883\udca9",
        49, 9202, -1113626536, -4898552344620657888L, 20697L, false, true, (char) 39644, (char) 6077,
        Double.longBitsToDouble(0x3fd9bd11f05cc9caL), Double.longBitsToDouble(0x3fa94660a2f9a900L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 8, 6, 7, "\000", "\ucafd\u455a\ub1e7\u4cca\u48ee\u63ae\u552c\u5460\u199a\ub8f7\u5d95\u19a1\000\u5de3\u8698\u0715\u4e2c\u0b6e\ub7a8\u071c\ub639\u3764\u17da\u90b8\u7196\ua80f\u7fa8\000", "",
        57, 76130, 792021317, 8286238123992802272L, 23880L, true, false, (char) 51154, (char) 53866,
        Double.longBitsToDouble(0x3fe7d8000202d8a3L), Double.longBitsToDouble(0x3fec9001b858f419L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 6, 7, "\000", "", "",
        48, 81178, -795676380, -3037908137433628476L, -90030L, false, false, (char) 42239, (char) 50937,
        Double.longBitsToDouble(0x3fce920a0f2393a0L), Double.longBitsToDouble(0x3fe44f4fc135320dL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 5, 11, "\ue245\ud956\udc8c\udb9c\udec7\ufbb9\udb83\udf52\udaea\ude79\ud8be\udef4\udacb\udc5f\ud8ba\ude17\udb3d\udcda\ufaec\ud9d8\udf19", "\u1e8a\u781e", "\udaaf\udcb9\ud910\udfb8\ud92f\udfe8\ud8ac\ude9a\udb0f\udc74\udb15\uddfe\ud814\udc4f",
        18, 50983, 570274110, 1754343123435894531L, 7208L, false, true, (char) 46578, (char) 41818,
        Double.longBitsToDouble(0x3fd45505cb585e6aL), Double.longBitsToDouble(0x3fe5c8e84608538fL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.language.Soundex:@?\0121=void |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 7, 7, 6, "\ud899\udce2\ud882\udc55\udb96\ude41\ufc14\udac7\udec5\udaa6\udf5a\udafc\udfa8\ud92f\udf9d\udbd2\udfed", "\u199a\ud117\u943f\u1968\u8c47\ua0f4", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\udb8f\udfce\ud80f\udd42\udbe9\udfff",
        20, 83168, 408451893, -7022317969876347557L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fcd3306af81cbf8L), Double.longBitsToDouble(0x3fd3feae31c96662L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 5, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\u0d14\udb83\udf52\ud928\udf5b\ud8fc\udfa8\ud92f\udf9d\ud8ef\udd77", "\u00f2\u5bde\u1628\ua341\u78d7\ua1ab", "\000\000\000\ud8ae\udd57\udb8f\udfce\uda9d\udea8\ud9fd\udf9b",
        -2, 98932, 5767221, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e38000000000000L), Double.longBitsToDouble(0x3fe33f5718000000L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 3, "\ud846\udf4d\udbef\uded4\ud977\udc35\ud8e7\uded5\udbb2\udea0\ud928\udf5b\udac1\udeab\ud952\udf9a", "\ua960\u14ed\u5144\ua78b\u5553\u1f91\ua1f2\ube45\u9ffa\ub30c\u6dd1\u7503", "\uda4a\udcb5\ud9fd\udf32\uda39\ude9c\ud96b\udd51\udb4e\ude48\udacf\udccb\ud805\udf57\ud853\udd0d\u2209\udbd2\udc40\ud94d\udd26\ud8a5\udc0d\udb78\udc72\ud981\udd9f",
        44, 70422, 1305245839, -3547465202838902870L, 84172L, true, false, (char) 52395, (char) 55808,
        Double.longBitsToDouble(0x3fbdf2c26bd96ad8L), Double.longBitsToDouble(0x3feca96598bdeb2fL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 5, 11, "", "\u086a", "\000",
        55, -1000, 0, 0L, -34464L, false, true, (char) 20588, (char) 43557,
        Double.longBitsToDouble(0x3febee30ae89e9f8L), Double.longBitsToDouble(0x3fd35320d000016cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 3, "v\000\000\000\udb7e\udf3e\ud928\ude87\ud943\uddeb\uf917", "\u99f8\u146d\000\u1636#\u9d31", "\udb6f\udcb9\ud986\udc02\000",
        22, -1000, 0, 5639221417697931708L, -47402L, true, true, (char) 557, (char) 0,
        Double.longBitsToDouble(0x3e0a96bc00000000L), Double.longBitsToDouble(0x3fd45005c3585e6aL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 3, "\ud846\udedc\udbef\uded4\ud8bd\udcf8\ud8c7\udee0\udbb2\udea0\u17eb\ud918\udc22\ud92f\udf90", "\u99f8\u14ed\u5144\u1636\u5553\u9d31", "\udb6f\udcb9\ud9e3\udf41\ud8b1\udf07\ud858\udda1\udab9\udf18\udb8f\udfce\uda9d\udea8\ud9fd\udf9b\uda39\ude9c\ud96b\udd51\udb4e\ude48\udaef\udc0c\ud81f\udf57\ud853\udd0d\u2209",
        -2, 76130, 792021317, 8286238124160574432L, -21177L, false, false, (char) 49111, (char) 43725,
        Double.longBitsToDouble(0x3fd9c7bea59e76caL), Double.longBitsToDouble(0x3fec8e49ba6bd322L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 3, "\ud846\udedc\udbef\uded4Y\000\udbb2\udea0\ud928\udf5b\ud943\uddeb\ud92f\udf90", "\u99f8\u14ed\u5144\u1636\u5553\u9d31", "\udb6f\udcb9\ud9e3\udf41\ud8b1\udf07\ud858\udda1\udab9\udf18\udb8f\udfce\u8a0c",
        29, 95058, 157236420, -1056336943114407286L, 88544L, false, true, (char) 46578, (char) 41818,
        Double.longBitsToDouble(0x3fd45505c3585e6aL), Double.longBitsToDouble(0x3fef0397f667eae3L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 1, "\ud846\udedc\udb53\ude2b\uda27\ude9f\ud9a3\udeb5\udbb2\udea0\ud928\udf5b\ud92e\uddbc\ud92f\udf90", "\u99f8\u14ed\u5144\u1636\u5553\u9d31\u0c13\u419b\ub850\u5b8f\uce5f\u2bfe\u07dd\ub639\u0ecd\u17da\u7bfa\u85a9\u11c6\u6f08\u966f\u211c\u3c9e\u96a1\u3b56\u796f\ub9f6\u02db\u2772\ubc96\u2fdf\u1522\uce45\u0fea\u1f57\ubd9b\ua19f\u36c4\uc30d\u6403\u215b\u97d7\u7d88\u54f3\ub877\u9b6a\uc551", "\udbed\udcf1\ud896\udc7f",
        18, 94919, 1113581675, -7585057357501008790L, 14873L, true, false, (char) 8371, (char) 62330,
        Double.longBitsToDouble(0x3fed31c5ba237e95L), Double.longBitsToDouble(0x3fa350fed98b0330L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 10, "\uda0f\udda9\udb08\ude20\u1a90\ud97b\udf08\udbcf\udfeb\uda4d\udc7d\ud94a\udd1f\ud9a4\udd20\ud98d\udcf3\udb93\udd6b\udb66\udc3e\ud92b\udd1e\udbfe\uded8", "\u798b\u22a3\u9ee0", "\ud9ac\udd65\udab9\udcfd\udbab\udf71\ud9e5\udc24\ud858\uddf9\ud866\uded4\ud9f8\ude5f\udad1\uddc6\ud931\udc08\udae4\udead\udbc2\udf2a\ud931\udfea\ud90b\udc58\udbac\udff6\ud87b\udc11",
        24, 72309, 1817443548, -1713747026848589589L, 94160L, true, false, (char) 22414, (char) 18970,
        Double.longBitsToDouble(0x3fe8fb2917089d61L), Double.longBitsToDouble(0x3fc05494497e4dccL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 4, 2, 0, "", "\u744c", "\ud879\udc65\ud8ca\udc61\ud8d1\udf8e\u131b\uda96\udf7a\uba91\ud8be\ude4c",
        19, 88280, -1873775069, -1952274206490606648L, -5671L, true, true, (char) 37534, (char) 8852,
        Double.longBitsToDouble(0x3fe062d779bc4e42L), Double.longBitsToDouble(0x3fcb385c3d50151cL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 11, 1, 6, "\ud846\udedc\ud882\udc55\uda2b\udecb\ud803\udc20\udb83\udf52\ud928\udf5b", "j", "\ud8fe\udc2c\u33e1\ud8d6\udfc9#\000\uda78\ude7b",
        26, 469, -181819419, -3622339090613010421L, -100000L, false, false, (char) 16382, (char) 45394,
        Double.longBitsToDouble(0x3fe1f7fe137baa9fL), Double.longBitsToDouble(0x3f18580000000000L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 2, "v\ud85d\udf4d\udb96\ude41\ufc14\udb83\udf52\ud928\udf5b", "\u3c72", "\ud8fe\udc2c\u33e1\ud8d6\udfc9\uc78e\ud8d7\udf5b\uda78\ude7b",
        11, 469, -181819419, -3622339089966747893L, -57619L, false, false, (char) 16382, (char) 45394,
        Double.longBitsToDouble(0x3fe1f7fe137baa9fL), Double.longBitsToDouble(0x3fe818c2c635c698L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=null |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 3, 11, "\ud893\udcb9\udbb4\ude40\ud98c\udd63\uda8a\udc20\u43ea\udaf1\ude56\udafc\udfa8\uda03\udf4c\ud925\udead", "\u2e1d\u3de6\ud7bd\u4ab6\u096f\uc9de", "\ud9f0\uded6\ud9d3\udcba\ud995\udd6e\udab9\udf18\ud834\ude81\u8a68\udbfc\udf99",
        25, 11004, 411366361, -7022317969876347557L, -26907L, false, false, (char) 41818, (char) 15874,
        Double.longBitsToDouble(0x3fdcae5351c0e41eL), Double.longBitsToDouble(0x3fd2500000000000L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String:V000 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 8, 1, 7, "v", "\u17d6", "\uff6a\udb57\udd2b\udbd3\udc28\uaac4\000\ud9d8\udf19\udba6\udead\ud86c\udcb9\uc809\ud8d7\udf5b\uda78\ude7b\ud834\udd7c\ud87b\ude9f\000",
        41, 63539, 2114465217, 6552555432551025164L, -80118L, false, true, (char) 42302, (char) 53082,
        Double.longBitsToDouble(0x3f91728b200331c0L), Double.longBitsToDouble(0x3fe9262bd2e55316L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 6, 7, "\ud90a\udcb4", "\ucafd", "\udafc\udfa8$\udaa5\udeb1\u1884\ud88d\udc34\ud9cf\udc27\udba6\udead\uda32\ude89\uc78e\udaa4\udd01\000\ud828\udef3\uda16\ude7f\ud8ed\udf04",
        57, 41331, -1895289407, 6552555432551025164L, -99830L, false, false, (char) 0, (char) 53082,
        Double.longBitsToDouble(0x3f91728b241d1fa0L), Double.longBitsToDouble(0x3fd24c57a5caa61aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 5, 0, "", "", "\ucf62\000\udb49\udf05\000\000\000\000\u1f00\uda98\udcab\ud8d6\udfc9\udaca\udc27\ud8d7\ude6c\uda78\ude30\ud834\udd7c\udafa\udd3f\udada\udfad\ud845\udc37\uda33\udce6",
        44, 98517, 2134749490, 7434706094026479543L, -49147L, false, true, (char) 50305, (char) 28952,
        Double.longBitsToDouble(0x3fe8d6236b2c552eL), Double.longBitsToDouble(0x3fe9a4c7f85ba931L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 0, 0, "v\000\000\000\udb7e\udf3e\ud928\ude87j\000", "\u99f8\u146d\000\u1636#\u91ef", "\udb6f\udcb9\ud986\udc02\000",
        22, -1000, 0, 5639221416036987324L, -42528L, false, false, (char) 0, (char) 41818,
        Double.longBitsToDouble(0x3fd45005c3585e6aL), Double.longBitsToDouble(0x3fb9dc51b1752b50L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 3, "v\000\ud8fc\ude3dx\udb7e\udf3e\ud928\ude87\ud943\uddeb\uf917", "\u928b\u146d\000\u1636#\u9d31", "\udb6f\udcb9\ud986\udc02\000",
        22, -1000, 0, 5639221417697931708L, -47402L, true, true, (char) 557, (char) 0,
        Double.longBitsToDouble(0x3e0a96bc00000000L), Double.longBitsToDouble(0x3fd45005c358b46aL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 1, 1, 6, "\udbf2\udf4b\ud860\uddcb\ud9ba\udd72\ud818\ude94\udb83\udf52\ud928\udf5b", "\u5cfa\u5468\ub859\u4485\u67e6\u1636\ud622", "\udb0d\ude3b",
        34, 50885, -843391542, 49191333120L, -42895L, false, true, (char) 45394, (char) 18945,
        Double.longBitsToDouble(0x3febdd54fb821858L), Double.longBitsToDouble(0x3ecdca4c33f40000L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 0, "\ud846\udedc\ud882\udc55\uda2b\udecb\ud803\udc20\udb83\udf52\ud928\udf5b", "\000", "",
        -5, -1000, 0, 0L, 84695L, true, true, (char) 58266, (char) 54003,
        Double.longBitsToDouble(0x3f879b7540000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 2, 2, 4, "\ud800\udfc0\ud87d\udd54\udb41\udcb9\uda50\ude48\ud869\udcb9", "\u8e66\u58d1\ub7d2", "\ud912\uddca\ud95e\udd38\ud83b\udcdf\u7979\ud94a\udf4b",
        -3, 94077, -1925248263, -8429700153614865352L, 96608L, true, true, (char) 7709, (char) 45514,
        Double.longBitsToDouble(0x3feae7359b7baa9fL), Double.longBitsToDouble(0x3f2b2c32e56e9000L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 0, "v\000v\udac8\udd51\uda2c\udf6a\ud928\ude87j\000", "\u99f8\u146d", "#\ud9a7\udf01\u26a5\ud834\udd7c\udb6f\udcb9\ud986\udc02\000\\\udad6\udf21\ud9b7\ude1c\uda9d\ude9c\udbd0\uddc5\000\ud96b\udd51\ud8ef\udf44\u328a\ud81f\udefc\ue880",
        19, 19734, 6047850, 3401705656150303148L, -66766L, false, true, (char) 28185, (char) 55953,
        Double.longBitsToDouble(0x3fe21bc3d5e32699L), Double.longBitsToDouble(0x3fed03f67e1e0d4bL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 0, "v\000N\000\udb7e\udf3e\ud928\ude87j\000", "\u99f8\u146d", "#",
        -1, 44032, 839724681, 4302786150821068800L, -99908L, false, false, (char) 32855, (char) 23385,
        Double.longBitsToDouble(0x3fdbc4e420000150L), Double.longBitsToDouble(0x3fc880000098257cL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 0, "v\000\ud823\udeb1x\udb7e\udf3e\ud928\ude87j\000", "\u99f8\u146d\000\u1636#\u91ef", "\udb6f\udcb9",
        1, -1000, 92, 0L, -38116L, false, false, (char) 15556, (char) 2437,
        Double.longBitsToDouble(0x3fe4578abd000000L), Double.longBitsToDouble(0x3fc00435a0000000L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 0, 0, "v\000\ufb00\000\udb7e\udf3e\udb35\ude96\uda4f\udf80\000\uda08\udca3\ud965\udc55\ud8bd\udf99\uda58\ude00", "\u3554", "\ud834\udd7c\udb6f\udcb9\ud986\udc02\uda62\ude31\udac3\udeb3\000\000\uda9d\ude9c\uda4b\ude84\000\ud96b\udd51",
        45, 11938, 766350592, -4867937786080002048L, -81462L, true, true, (char) 24545, (char) 38425,
        Double.longBitsToDouble(0x3fe1752b537092aaL), Double.longBitsToDouble(0x3fe06c5c6b94bcdaL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String:V200 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 8, 0, 0, "v\000v\udac8\udd51\uda2c\udf6a\ud8ac\ude89j\000", "\u61dd\u146d", "#\ud9a7\udf01\u26a5\ud834\udd7c\udb6f\udcb9\ud986\udc02\u38de\\\udad6\udf21\ud9b7\ude1c\uda9d\ude9c\udbd0\uddc5\udb38\ude8e\ud83b\udd51\udac7\udce9\udae4\udd8f\ud81f\udefc\ue880",
        19, 19734, 6047850, 3401705656150303148L, 91186L, true, false, (char) 17836, (char) 11047,
        Double.longBitsToDouble(0x3fd2fc158811dac8L), Double.longBitsToDouble(0x3fed03f1f61e0d4bL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 5, "v\000v\udac8\udd51\uda2c\udf6a\ud940\udca4jO", "\u19b7\u68ef", "#\ud9a7\udf01\u26a5\ud842\udc03\ud9ff\udc6b\ud931\udd6f\u00d5\\\udad6\udf21\ud9b7\ude1c\udbab\udf21\udbd0\uddc5\000\ud96b\udd51\ud96b\udf1b\u32e9\udb4b\uded6\ud9ec\udd09\udb72\uded1\ud931\udd31\ud99e\udc6f\ud8a5\udc0d\udb55\udedc\ud986\udf10\ud95e\udd6d\ud80b\udd2b\ud951\udcbc\ud8a7\udfd8\uda4e\udf6f\ud81a\ude97\uda18\uddf7\ua084\ud9c3\udf67\ud852\uddac\udbff\udd0d\udb30\udf03\uda59\udf23",
        34, 28249, -1606271771, 2090326779544320410L, 11036L, true, false, (char) 27828, (char) 6240,
        Double.longBitsToDouble(0x3fcc50c05e588e78L), Double.longBitsToDouble(0x3feb9551fc00bbdaL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.String:V120 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 8, 6, 5, "vIv\udac8\udd51\uda2c\udf6a\ud928\ude87j\000", "\u99f8\u35da", "\udb44\udc04\ud942\uddb5\u4854\ud834\udd7c\u4bb6\udb6f\udef8\000",
        22, 45410, 431994008, 5639221417465637308L, 18134L, false, true, (char) 24101, (char) 23656,
        Double.longBitsToDouble(0x3fd4659000d4b500L), Double.longBitsToDouble(0x3fd45005c3585e6aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:V200 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 8, 0, 0, "v\000v\udac8\udd51\uda2c\udf6a\ud8ac\ude89j\u00df", "\u61dd\u146d", "#\udbfc\ude76\ud883\ude13\ud800\udeea\udb6f\udcb9\ud986\udc02\u38de\\\udad6\udf21\ud9b7\ude1c\ud942\ude4f\udb9a\udffd\udb38\ude8e\ud83b\udd51\udac7\udce9\udae4\uddb2\ud81f\udefc\ue880",
        19, 19734, 6047850, 3401705656150303148L, 91186L, true, false, (char) 17836, (char) 11047,
        Double.longBitsToDouble(0x3fd2fc158811dac8L), Double.longBitsToDouble(0x3fed03f1f61e0d4bL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 0, 5, "v\000v\udac8\udd51\uda2c\udf6a\ud940\udca4jO", "\u19b7\u68ef", "\u0084\ud9a7\udf01\u26a5\uda7a\ude60\udaec\udf4f\ud922\udc83\u00d5\\",
        40, 16008, 1321044606, 47553585843535872L, -54948L, true, false, (char) 20027, (char) 28085,
        Double.longBitsToDouble(0x3fef03001cdc75d8L), Double.longBitsToDouble(0x3fba96a00a2802e0L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 5, "v\000v\udac8\udd51\uda2c\udf6a\ud940\udca4\udad4\udc73O", "\u19b7\u68ef", "\ud91f\udf53\ud9ca\uddcf\u26a5\uda7a\ude60\udaec\udf4f\ud922\udc83\u00d5\\",
        21, 15996, 1321044606, 8626267660946942452L, -79973L, true, true, (char) 37859, (char) 35508,
        Double.longBitsToDouble(0x3fba96bb4a2802e0L), Double.longBitsToDouble(0x3fd5b5b86ee06b68L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 5, "v\000v\udac8\udd51", "jO\u2bc4\u0123\u19b7\u68ef\u2b6d\u2b9d\u0084\u7815\u6cbd\u3c29\uab1c\u977f\u00d5\\\u61ee", "\udbd0\uddc5\000\ud96b\udd51\ud96b\udf1b\u32e9\udb4b\uded6",
        35, 50232, 1518343388, 25975319781722437L, 35536L, false, false, (char) 10331, (char) 8202,
        Double.longBitsToDouble(0x3fdd757c9a943fd2L), Double.longBitsToDouble(0x3fd53129d73e8712L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 5, "\uda63\udd2b\000v\ud836\ude48\uda2c\udfc6\ud8ca\udca0\ud879\udfbc\udbf8\ude50", "\u82b1\u2d8b\u2b5a\u94d0\u0084\u1d6b\u16be\u3c29\uab1c\u977f\u00d5\\\u25a6\u731c\ub7d0\u3284\u0426\u7fdf\u16ef\u3258\u0a79\u8d2c\u778b\ud01e\u50d7\u224f\u0bb0\u8923\ua920\u7cf1\u2f9a\u56b8\ubf60\u7b74\ub721\u87ef\u2ffb\u17c9\u1503\u04ff\ua4b8\u7022\u19c1\u3377\ud405\uad7a\ub735\u42b7\u0f0d\u0856\uc6ac\uc8a5\u5452\uc36f\ub274\u0b8c\u0fce\uce70\u4d70\u4749\uced3\u740c\u0192\u3b3c\u5ebc\u4791\u2b86\ub4c0\u997f\u5a6b\u533d\u3062\u440c\ud6af\u6d62\u322e\ub8df\ub0cc\u8a2c\u88f8\ud639\ub7d5\u7aef\u4294", "\uda10\udcb2\udbce\udcd3\ud88f\udc46\udb34\udf4d\udb8f\udc6b\ud9de\ude4f",
        27, 84499, 1157149244, -7743759305446663376L, -62287L, false, false, (char) 54574, (char) 20635,
        Double.longBitsToDouble(0x3fd7c986d0a2b436L), Double.longBitsToDouble(0x3fe6cad4c16a5716L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 9, 5, 3, "\ud846\udedc\ud882\udc55\udb96\ude41\ufc14\udb83\udf52\ud928\udf5b\udafc\udfa8\ud92f\udf9d\udbd2\udfed", "\u199a\ud117\u1636\u19c4\u78d7\ua1ab", "\ud9e3\udf41\uda4a\uded3\ud858\udd50\udab9\udf18\udb8f\udfce\uda9d\udea8\ud9fd\udf9b",
        -2, 98932, 408451893, -7022317969876347557L, 33852L, true, false, (char) 41818, (char) 39329,
        Double.longBitsToDouble(0x3fdac2f357c0e5fcL), Double.longBitsToDouble(0x3fe33f571cc8f905L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 1, 1, 6, "\uda3c\ude89\ud882\udc55\uda2b\udecb\ud803\udc20\udb83\udf52\uda2c\udf5d", "j", "\ud8fe\udc2c\ud806\udd5c\ud8d6\udfd3#\000\uda78\ude7b",
        26, 469, -181819419, -3622339090613010421L, -100000L, false, false, (char) 16382, (char) 5633,
        Double.longBitsToDouble(0x3fe37d0b837baa9fL), Double.longBitsToDouble(0x3f18580000000000L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 4, 5, "v\ud861\udd10w\udabf\udd09\uda2c\udf6a\ud928\ude87j\000", "\u99f8\u8f67", "\udaa2\udf24\ud89b\udecb\u26a5\ud834\udd7c\ud9f1\udf18\ud986\udc02\000\uda2e\udc52\uda2a\udedc\udb26\udc86\ud889\ude32\udbd0\uddc5\000\ud96b\udd51\ud8ef\udf44\u328a\ud81f\udefc\ue880",
        55, 21141, 6047850, 303229112519401771L, -66766L, false, true, (char) 28185, (char) 64457,
        Double.longBitsToDouble(0x3fe5391f5de32699L), Double.longBitsToDouble(0x3fed03f67e1e0d4bL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Integer:2 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 0, 0, "v\000\ud823\udeb1x\udb7e\udf3e\ud928\ude87j\000\udbc7\udd83\udb48\udf53\udb4e\udea5\ud8c5\uddb3\udab4\udcda\uda48\udd7a#\ud8ee\uddd7\ud8bb\ude1d\ue308\udb6f\udcb9\ud986\udc02\000\\\000\000\uda9d\ude9c\udbd0\uddc5\000\ud96b\udd51\udb45\udf48\u328a\ud81f\udefc\ue880\udbb9\udcbb\ud941\uddec\uda0d\udfb6\ud9a0\udfd3\uda88\udc6f\ud8d6\ude5e\ud8c9\uded1", "X", "\ud9c4\udff4\udbf5\udf16\ud8b8\udfa7\ud8b9\udfd9\ud867\udc47\udb93\udd56\uda1b\udcca\ud855\udc6b\ud919\udd10\uda9f\udc22\udb99\udc7d\udb81\ude80\u4823\uda84\udfd2\udb1b\udc5e",
        53, 12309, -626218891, -28799421372925828L, -75228L, true, true, (char) 39069, (char) 14084,
        Double.longBitsToDouble(0x3fc5bc4f9c6cfcd8L), Double.longBitsToDouble(0x3fe104435ab944a8L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 0, 0, "v", "x", "j",
        -5, 72952, -2117555516, 9169666552977432420L, -3986L, true, false, (char) 43477, (char) 21,
        Double.longBitsToDouble(0x3fdb3740006bbed8L), Double.longBitsToDouble(0x3cf4800000000000L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:V200 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.String:V200 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 8, 2, 5, "v\000v\udac8\udd51\uda2c\udf6a\ud940\udca4jO", "\u19b7\u68ef", "\ud9db\udd9d\ud9a7\udf01\u26a5\uda7a\ude60\udaec\udf4f\ud922\udc83\ud910\udc5c\ud864\udf93\udad6\udf0c\ud9b7\ude1c\udbab\udf21\udbd0\uddc5\000\ud96b\udd51\ud96b\udf1b\u32e9\udb4b\uded6\ud829\udfca\ud86e\udfc4\ud92f\udd11\ud99e\udc6f\ua2d1\udaa2\udcc1\ud823\udd26\udaad\udee4\udadc\uddc2\ud892\udc7e\ud88b\udd53\ud97e\udcad\uda35\udcff\ud8fb\udd25\udac5\udd0b\udaa7\ude5a\ud99a\udc4b\uda62\uddb0\udbc3\ude91\ud9e6\udccc\ud94f\udf5f\ud8d7\udfae\uda25\udf28\ud908\udfe6\ud868\udd6e\ud9da\udcc3\udb5b\ude07\udaaa\udf43\ud94b\udd94\udbbb\udeaf\udb93\ude42\udb49\udf31\uda0e\udfc1\u0087\udaaf\udf6d\uda49\ude20\udb32\udfa4\ud87c\udd05\ud90f\udc78\ud9a9\udcdb\ud862\udf4b\uda8c\udefa",
        11, 37027, -1683152148, -1696384434106336848L, 63634L, false, false, (char) 62626, (char) 32658,
        Double.longBitsToDouble(0x3fc19c3e3d1b06e8L), Double.longBitsToDouble(0x3fd31fac4ce32f26L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 0, 5, "v\uda57\ude8aw\udac8\udd51\uda2c\udf6a\ud940\udca4jO", "\u19b7\u68ef", "\u0084\ud9a7\udf01\u26a5\uda7a\ude60\udaec\udf4f\ud922\udc83\udb9f\udce3\ud894\ude1b",
        59, 16008, 1321044606, 47553585843535872L, -54948L, true, false, (char) 20027, (char) 28085,
        Double.longBitsToDouble(0x3fef03001cdc75d8L), Double.longBitsToDouble(0x3fba96a00a2802e0L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 0, 0, "\000\000\ud823\udeb1x\udb7e\udf3e\ud928\ude87j\000\udbc7\udd83\udb48\udf53\udb4e\udea5\ud8c5\uddb3\udab4\udcda\uda48\udd7a#\ua9d6\000\ue232\udb6f\udcb9\ud986\udc02\000\\\000\000\uda9d\ude9c\udbd0\uddc5\000\ud96b\udd51\udb45\udf48\u328a\ud81f\udefc\ue880\udbb9\udcbb\udb64\udee1\uda0d\udfb6\ud9a0\udfd3\uda88\udc6f\ud8d6\ude5e\ud8c9\uded1", "X", "\ud9c4\udff4",
        51, 68748, -152098718, -5964840511609026697L, 49735L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e30000000000000L), Double.longBitsToDouble(0x3ec32e5000000000L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 1, 0, 2, "v\000\ud823\udeb1x\udb7e\udf3e\ud928\ude87j\000\udbc7\udd83\udb48\udf53\udb4e\udea5\ud8c5\uddb3\udab4\udcda\uda48\udd7aD\ud8ee\uddd7\ud8bb\ude1d\ue308\udb6f\udcb9\ud986\udc02\000\\\000\000\uda9d\ude9c\udbd0\uddc5\000\ud96b\udd51\udb45\udf48\u328a\ud81f\udefc\ue880\udbb9\udcbb\ud94a\udd7e\uda0d\udfb6\ud9a0\udfd3\uda88\udc6f\ud8d6\ude5e\ud8c9\uded1", "X", "\ud9c4\udff4\udbf5\udf16\ud8b8\udfa7\ud8b9\udfd9\ud867\udc47\uda4e\udf15\udadb\ude6f\ud855\udd15\ud919\udd10\uda9f\udc22\udb99\udc7d\udb81\ude80\u4823\uda84\udfd2\udb1b\udc5e",
        53, 12309, -626218891, -28799421372925828L, -75228L, true, true, (char) 39069, (char) 14084,
        Double.longBitsToDouble(0x3fc5bc4f9c6cfcd8L), Double.longBitsToDouble(0x3fe104435ab944a8L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 10, "\udb83\udfea\uda57\ude8aw\udac8\udd51\uda2c\udf6a\ud95b\udcf2\010\ud80c\udfa8\uda43\udd0a\udbfd\udc8b\ud87f\udd02\ud8bd\udd46\ud91e\udf80\udb45\udc09\ud89d\udeab\ud95b\uddb7\u26a5\uda7a\ude60\udaec\udf4f\ud8d4\udf5b\ud82a\ude77\ud870\udd57\ud877\ude80\ud98e\udf47\udba6\udceb\udbd0\uddc5\000\ud96b\udd51\ud96b\udf1b\u32e9\ud949\udda7\ud8a4\udec9\udb72\uded1\ud822\udca9\ud99e\udc6f\uda4f\ude43\uda6b\udcd3\uda8b\udd2e\ud80c\udf3e\ud91e\udfda\ud8fb\udce0\udbf1\udfff\ud88b\udd74\udb1e\ude3d\ud8da\udc97\ud8b6\udf50\udaeb\udf84\ud9aa\udf7a\ud8a9\udc4d\udb3b\udfe7", "\u96cd\u0eea\uba9e\u24f6\u77eb\u7ba9\u638c\u3147\u4387\u675a\u9d8c\u9729\u1dcc\uaee3\u0f98\ud17b\u6ec6\u9d35\ud60e\u2e31\u4c9f\u4c01\u2f21\u435b\u2c0f\u74c2\u1e5c\u6921\u0405\u2ac1\u86d1\u2356\u1d29\ube8e\uc741\u4493\u7887\ub414\ua82d\u595a\u4009", "\ud863\udf8f\ud872\udd39\ud8e9\udfe6\ud9aa\udd0f\uda02\udc60\udb86\udd1b",
        53, 83868, 341183659, 2025670833689606876L, 84798L, true, true, (char) 52911, (char) 51832,
        Double.longBitsToDouble(0x3fe3b77da08a067eL), Double.longBitsToDouble(0x3feb562273577f76L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 7, 6, 7, "\uda86\udf46", "\ucafd\u455a\ub1e7\u4cca\u48ee\u3cad\u552c\u5460\u199a\ub8f7\u5d95\u19c4\u78d7\ua1ab\u39db\u6196\ub168\u0b6e\u74b2\u07dd\ub639\u3764\u17da\u90b8\u3867\u2d91\u8ec5\u84cb\u3bc3\uaf93\u0ead\u57a8\u7938\ub9f6\ubf00\u88bf\u07ed\u25b3\u1f69\u16a0\uc41e\u81e6\ud541\ucea6\u5054\uc539\u2ca7\ub519\u9006\u2acd\u389f\u90a1\ud1d6", "\ud868\udf8d\ud934\udd63\udab7\ude37\ud847\udc1b\ud969\ude2a\uda6c\uddd7\udb40\udfe0\udaa6\udc6f\uda60\udcc4\udbbe\uddd9\ud95a\uddbb\ud818\udfd9\udbb3\udc4e\ud8c4\udf25\ud8ba\ude18\udbcc\udf05\ud9e1\udc78\ud957\udc4f\ud9fd\ude9c\udaeb\uddc0\ud995\ude51\ud823\udf48\ud868\udcd7\ud9f5\uddaf\ud84b\uddfd\udb07\udfca\uda47\ude9b\u270d\udb15\udfb2\ud925\udf2c\ud8ba\udd1b\u509f\ud8b4\udcfc\udadc\udc4c\ud8fa\udcfb\ud862\udce7\u4e87\ud800\ude11\uda50\udd15\uda4c\udca8\ud863\udcd4\u65cc\udae3\udd1e\ud8d8\udd26\udb5d\udfa8\udbba\udca4\u3db1\uda4e\udc1e\udbce\udd04\ud937\udf1d\ud84b\udc9e\ud8cc\uddbc\udb22\ude51\ud870\udc0c\uda11\udd3d\udbbe\udd9f\ud8b6\udf94\udb01\ude39\ud9d5\udf96\u516c\uda31\udcdc\ud9db\udef6\udb57\udf3d\udb2a\udd6e\udb1d\udf29\ud84a\ude3a\ud8de\udca3\ud89c\uddef\u9434\udb14\udec2\uda9b\udef9\ud898\ude1e\udac1\udc4a\udae6\udf3c\udb0b\udfc4\udbaf\udc71\uda10\ude87\ud814\udeb5\ud939\udfd4\uda1e\udc3a\u3ff4\ud93a\ude27\u21c5\udb48\udfee\udb52\udd26\udad2\udd57\ud9cc\udc0f\ud9e2\udc7e\udb5c\udef0\ud845\udcd3",
        -1, 12644, -91934694, -8676525471002966325L, 66048L, true, true, (char) 56467, (char) 56579,
        Double.longBitsToDouble(0x3fe84ee03b87a71bL), Double.longBitsToDouble(0x3fe6bfc35377dadfL)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 1, 1, 6, "\udbf2\udf4b\ud860\uddcb\ud9ba\udd72\ud818\ude94\udb83\udf52\ud928\udf5b", "\000", "\ud8fe\udc0e\udb76\uddf7\ud8d6\udfc9",
        28, -1000, 16270280, 50831939768629L, -100000L, true, false, (char) 11520, (char) 17203,
        Double.longBitsToDouble(0x3fe88bf801bc4e3cL), Double.longBitsToDouble(0x3fdaa63a847dff84L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\uda84, \ude18, \udb02, \udfab, v, \ud9e2, \udc7e, \uda2c, \udf6a, \ud8ac, \ude89, j, \000, \ud93a, \udf42, \udba9, \udde3, \ud9bf, \udfd0, \uda58, \uddac, \ud913, \udd72, \ud8d6, \udfc9, #, \ud9a7, \udf01, \u26a5, \ud834, \udd7c, \udb6f, \udcb9, \ud986, \udc02, \u38de, \udbe9, \udf50, \udb04, \udf3f, \ud9b7, \ude1c, \uda9d, \ude9c, \udbd0, \uddc5, \udb38, \ude8e, \ud83b, \udd51, \udac7, \udce9, \u05bb, \udb7e, \udead, \ue870, \udabf, \udd3e, \ud93c, \ude9b, \ud99e, \udc6f, \ud8a5, \udc0d, \u74a7, \ud986, \udef6, \ud809, \udd1c, \uda0d, \udd27, \udad4, \udcab, \udbac, \udcee, \ud8e8, \udc16, \uda44, \udf78, \u601f, \ud94b, \udc00, \udbaf, \uddb6, \ud8b6, \ude81, \ud9fa, \udcc0, \udb7a, \udcab, \ud9e6, \udc2f, \ud9a2, \udd3f, \ud820, \udde3, \ud848, \udfff, \ud801, \udf5b...\012",
        Z.run(T, 1, 10, 0, 0, "\uda84\ude18\udb02\udfabv\ud9e2\udc7e\uda2c\udf6a\ud8ac\ude89j\000\ud93a\udf42\udba9\udde3\ud9bf\udfd0\uda58\uddac\ud913\udd72\ud8d6\udfc9#\ud9a7\udf01\u26a5\ud834\udd7c\udb6f\udcb9\ud986\udc02\u38de\udbe9\udf50\udb04\udf3f\ud9b7\ude1c\uda9d\ude9c\udbd0\uddc5\udb38\ude8e\ud83b\udd51\udac7\udce9\u05bb\udb7e\udead\ue870\udabf\udd3e\ud93c\ude9b\ud99e\udc6f\ud8a5\udc0d\u74a7\ud986\udef6\ud809\udd1c\uda0d\udd27\udad4\udcab\udbac\udcee\ud8e8\udc16\uda44\udf78\u601f\ud94b\udc00\udbaf\uddb6\ud8b6\ude81\ud9fa\udcc0\udb7a\udcab\ud9e6\udc2f\ud9a2\udd3f\ud820\udde3\ud848\udfff\ud801\udf5b\udb90\udffd", "\u45d3", "\udb30\ude47\ud846\udfbe\ud925\uddda\ud93f\udef8\udb00\udf65\udac7\udddd\udadc\ude2c\udac4\udf34\ud836\udf75\ud9b6\udd5c\uda3a\udc1a\ud891\ude67\ud91c\udfc3\ud8a2\udf57",
        2, 40586, 518792691, -890784759736944628L, 26748L, false, false, (char) 51776, (char) 9021,
        Double.longBitsToDouble(0x3fb6b25764ea56b0L), Double.longBitsToDouble(0x3fe65b6dfeed5b10L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 0, "v\000\ud823\udeb1x\udb7e\udf3e\ud928\ude87j\000\udbc7\udd83\udb48\udf53\udb4e\udea5\ud8c5\uddb3\udab4\udcda\uda48\udd7a#\ud917\udcb0\ud8bb\ude1d\ue308\udb6f\udcb9\ud986\udc02\udbbf\udc18\uda4f\udd5c\016\u0092\uda9d\ude9c\udbd6\ude49\ud938\udda5\udb22\ude89\uda25\udc59\u32d7\ud81f\udefc\ue880\udbb9\udcbb\ud941\uddec\uda0d\udfb6\ud9a0\udfd3\uda88\udc6f\ud8d6\ude5e\ud89b\udffb\udb03\udda5\uda7b\ude9f\u5b9b\udade\udd76\ud9a0\udc96\ud9c4\udff4\udbf5\udf16\ud8b9\udc10\ud8b9\udfd9\ud833\udecd\udb93\udd18\uda1b\udcca\ud855\udc6b\ud919\udd10\uda9f\udc22\udb99\udc7d\udb81\ude80\u4823\uda84\udfd2\udb1b\udc5e\ud804\ude36\ud9c1\udc3c\udb83\ude41\udbdf\udf0d\ucb46\ud9c3\udfcb\u5bc4\uda58\udfe8\udad6\udd19\udaf2\udcc8\udaaf\udc66\udbd4\udc0e\udb50\ude2b\udba5\udc4e\udb24\udd41\udb21\udf7b\ud925\udf3f\ud956\udf7b\uda19\udcd1\udbae\ude5d\ud97f\ude2e\uda5a\ude27\ud812\udfa6\ud869\udd7f\uda91\udc4f\ud8a8\udfb8\udb03\udf27\ud96b\ude6b", "\u265e\u8612\ubd45\u7ab8\uc1d4\u1858\u2435\u6689\u1cf9\u23d8\u58dc\u83ee\uc7df", "\ud912\udfc5\udbd8\udf87\udb8a\uded3\udb1b\udf14\uda2e\udc46",
        18, 26036, -180262112, -1926202667573210131L, 5392L, true, true, (char) 46032, (char) 16557,
        Double.longBitsToDouble(0x3fea3a27aeedb677L), Double.longBitsToDouble(0x3fea797bef10a6d5L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.language.Soundex|getMappingCode|java.lang.String,int|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|difference|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|encode|java.lang.Object|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|encode|java.lang.String|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|getMaxLength||new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|getSoundexMapping||new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|map|char|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|setMaxLength|int|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|soundex|java.lang.String|new:org.apache.commons.codec.language.Soundex:",
    "C|org.apache.commons.codec.language.Soundex|<init>|java.lang.String",
    "C|org.apache.commons.codec.language.Soundex|<init>|[C",
    "C|org.apache.commons.codec.language.Soundex|<init>|",
    "M|org.apache.commons.codec.language.Soundex|getMappingCode|java.lang.String,int|new:org.apache.commons.codec.language.Soundex:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
