package org.apache.commons.codec.language;
import org.junit.Test;
import static org.junit.Assert.*;
public class Soundex_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u5ec1", "\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud920\udd42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99\udb7f\udf4b\udaf1\udd10\uda2a\udf1b",
        42, 52567, 1481954062, -2985448135944318613L, 14103L, true, true, (char) 4944, (char) 43620,
        Double.longBitsToDouble(0x3fe9f73f7f5b268bL), Double.longBitsToDouble(0x3fcc99aeea0640b4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:4 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 4, 10, "\ud92e\udd71\ud970\udec6\uda30\ude3c", "\u5ec1\u29ca\u45d7\u7f5e\ua1e2\u738d\uaf90\u453b\ua84e\uc676\ub6d1\u18c9\u620a\u3b93\ubfc9\uaf3a", "\udb38\udd12\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9",
        -2, 62472, -348352950, -5542541754812353413L, -88075L, false, false, (char) 14807, (char) 1111,
        Double.longBitsToDouble(0x3fdcb65857b44d16L), Double.longBitsToDouble(0x3fe9f73f7f5b268bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\udb03\ude50\uda62\uddfa\uda30\ude71", "\u5ec1", "\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud920\udd42\ud92a\udc79\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66",
        53, 19858, -926087620, -6956265384714981675L, -67905L, false, false, (char) 21500, (char) 18072,
        Double.longBitsToDouble(0x3fe43e3f03688a77L), Double.longBitsToDouble(0x3fe255d217a4eb3cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u5ec1", "\uda6a\udce2\ud954\udf7e\uda5f\udce1\ud835\udfa1\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud920\udd42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\udbca\udf28\udbf8\udfc1\ud8ac\udcfc\udab8\udf2e",
        43, 57399, -1718832976, -896011336596080370L, -27144L, false, false, (char) 56032, (char) 26511,
        Double.longBitsToDouble(0x3fc6fe546c39b10cL), Double.longBitsToDouble(0x3fe5eac2a16bd691L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 9, 0, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u3a9b", "\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud81d\udc80\udae6\udc77\udbe1\udcb3\ud9d1\ude4d",
        27, 99558, 15215946, 0L, -100000L, true, false, (char) 45231, (char) 21500,
        Double.longBitsToDouble(0x3fd0e009050f8eeeL), Double.longBitsToDouble(0x3feb4453be4aba42L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 8, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u5ec1", "\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud920\udd42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99\udb7f\udf4b\udaf1\udd10\uda2a\udf1b",
        42, 52567, 1481954062, -2985448135944318613L, 14103L, true, true, (char) 4944, (char) 43620,
        Double.longBitsToDouble(0x3fe9f73f7f5b268bL), Double.longBitsToDouble(0x3fcc99aeea0640b4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 7, 5, 10, "\ud92c\udd9e\ud970\udec6\uda30\ude3c", "\u5ec1", "\uda5b\udc05\udba0\udf9b\udbfe\udc9a\uda4e\udfbc\ud88f\uddae\ud950\ude49\ud91f\udce9\udafa\udd90\ud903\udc32\ud808\udceb\ud920\uddb9\ud98d\udfaa",
        56, 30150, 1790920683, 4546134969682505034L, 6115L, true, false, (char) 33189, (char) 53361,
        Double.longBitsToDouble(0x3fc611ca69c26630L), Double.longBitsToDouble(0x3fe07e0c81960b77L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 0, 2, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u9d3e", "\u5ff9\ud89e\uddac\ud866\ude9c\udafc\udfe4\ud8c7\udcdc\ud950\ude49\ud91f\udce9\uda75\udeed\udac2\ude4d\udb07\ude77\ud920\udd42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99\udb7f\udf4b\udaf1\udd10\uda2a\udf1b",
        24, 55631, 1481954062, -2985448135944318613L, 14103L, true, true, (char) 4944, (char) 62820,
        Double.longBitsToDouble(0x3faf73e275b26060L), Double.longBitsToDouble(0x3fcc99aeea0428b4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u5ec1", "\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud81c\udc67\uda7e\udec6\uda8e\ude52\ud936\udc69\ud920\udd42\udb4d\udf2b\uda2f\udd94\udbba\udd5e\udaec\udf63\udb38\udd7d\ud9ad\udf3a\uda51\udef2\ud96a\ude10\udb7e\ude2b\udb5c\udc58\uda35\udc32\udaaf\udc86\ud95e\udc22\ud845\uddb9\udb42\udf99\udb7f\udf4b\udaf1\udd10\uda2a\udf1b",
        6, 13918, 1481905266, -2985448135944318613L, 14103L, true, true, (char) 4944, (char) 43620,
        Double.longBitsToDouble(0x3fe9f73f7f5b268bL), Double.longBitsToDouble(0x3fcc99aeea0640b4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 6, "\ud905\udec9\ud970\udec6\uda30\ude3c", "\u307e", "\uda6a\udce2\ud819\udc3f\udbee\ude5f\ud9b8\uddb6\udb5d\udcb6\ud956\ude99\u96c7\uda7d\udfa7\uda8e\ude52\ud936\udc69\ud920\udd42\ud96a\ude1a\udbe1\udc1e\ud9d1\ude4d\ud8c1\udc62\udb38\udd7d\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\uda0b\udc7e\ud978\uddb9\ud845\uddb9\udb42\udf99\udb7f\udf4b\udaf1\udd10\uda2a\udf1b",
        18, 20476, -984296690, -2985448445181963925L, 14103L, true, true, (char) 4944, (char) 43620,
        Double.longBitsToDouble(0x3fe9f73f7f5b268bL), Double.longBitsToDouble(0x3fcc99aeea0640b4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\ud905\udefd", "\uaf52\u24a5\u9464\ud12d\u4530\u7f5e\ua1e2\u9b8d\u4c9a\u0833\u906f\uc696\ub6b4", "\ud920\udd42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\ud9ad\udf3a",
        56, 3148, 213364437, 1824692777600893279L, -65831L, false, true, (char) 15756, (char) 56032,
        Double.longBitsToDouble(0x3fe46598a1ca58c5L), Double.longBitsToDouble(0x3fec7364067faee3L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 3, "\ud905\udefd\ud970\udec6", "\u24a5\u5ec1\u29ca\u45d7", "\ud9a4\udda4\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\ud8b0\udf24\ud936\udc69\ud920\udd42\ud9a7\ude57\udbe1\udc4c\uda02\udc65\udbc9\udc22\uda15\udf8c\ud834\udd48\ud8c0\udf55\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99\udb7f\udf4b\udaf1\udd10\ud920\udd27\ud93b\udf5f\udae7\ude66\uda60\udc42\udbc8\udd4b\ud954\udc1a\udaa2\udd86\uda2c\udc75\uda78\uddf6",
        21, 63241, 730575678, -3641363257899238172L, -46501L, true, false, (char) 23570, (char) 18965,
        Double.longBitsToDouble(0x3fd2b6503a5bebf0L), Double.longBitsToDouble(0x3fdcff24a1bdf998L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\ud905\udefd", "\uaf37\u24a5\u5ec1\u29ca", "\ud96f\udc09\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49",
        31, 24617, 1645474955, -1431245741466442633L, -34884L, false, false, (char) 620, (char) 57885,
        Double.longBitsToDouble(0x3fd4a3f17c7841d0L), Double.longBitsToDouble(0x3fd7dc8cddab3eecL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 10, "\ud905\udefd\ud8a1\udd5e\ud945\udd25\ud972\udd12\ud8c1\ude3b", "\u45d7\u7f5e\ua1e2", "\uda07\uddfc\udae2\udc95\ud922\udf74\uda75\udeed\uda8e\ude52\ud936\udc69\udbe8\udd46\udae6\udc77\udbe1\udcb3",
        20, 97083, 1058479558, 2371194998735308348L, -79221L, true, true, (char) 2072, (char) 16296,
        Double.longBitsToDouble(0x3fe384cc610ef390L), Double.longBitsToDouble(0x3fe43e3bbb688a77L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 5, 10, "\udab9\udc4b\ud8c8\udd76\uda15\udf4f", "\u5ec1\u29ca\u45d7\u7f5e\u5525\u7872", "\ud96b\udc5b\uda51\udec4\uda95\ude12\uda8e\ude52\ud936\udc99\uda2a\ude46\udae6\udc8e\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udaea\ude9e\udb6b\udcfd\ud8d1\udd73\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud800\udd78\ud9c2\udeb7\udb46\udd5c\udb7f\udf4b\udaf1\udd10\uda2a\udf1b\ud99a\udfb1",
        27, 81062, -695103811, -1607836282373735882L, 32101L, true, true, (char) 43620, (char) 39725,
        Double.longBitsToDouble(0x3fbbe085e4edfee8L), Double.longBitsToDouble(0x3fe40c816cbe09f8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\ud905\udefd\ud8f0\udd60\uda31\udef3\ud972\udd3e\ud8c1\ude3b\ud436\ud8e3\ude0d\ud931\udff7\uda6a\udce2\ud954\udf7e\udb1a\ude69\ud910\uddae", "\u6e4e\u523f\ubfdd\ua419\ud3fd\ubfd9\uaf3a\ub806\u9135\u588c\u9a7f\u6d8f\u366c\u5c5f\u320f\u5f68\u2f43", "\udb42\udf99\udb7f\udf4b\udaf1\udd10\ud97b\udc02\ud99a\udfac\ud90b\udf18\uda60\udc42\udbc1\udc4b\ud954\udc1a\uccb0\udb60\udd7c\ud81e\udf10\ud9f7\udfd9\udbca\ude6e\ud9f9\udd83\ud820\uddc1\ud948\udefb\ud8c6\udff0\ud9b0\uded5\uda45\udd62\udb4c\udef2\ud17b",
        39, 82881, -629112778, -6359655928470319806L, -88337L, false, false, (char) 6460, (char) 6914,
        Double.longBitsToDouble(0x3fbfff816ea9ff18L), Double.longBitsToDouble(0x3fdc71cf22615256L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 5, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u5ec1", "\udb89\ude12\ud954\udfa9\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud937\udc7b\uda2d\udf11\uda75\udf0f\uda26\udf9e\ud936\udc37\ud920\udd42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udad0\uddea\ud8bf\udfe7\ud860\udf09\udacc\udc41\ud9a5\udf93\udb6b\udf1c\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99\udb7f\udf4b\udb22\udc88\udb41\udfdc",
        42, 52567, 1481954291, -2985448135944318613L, 14103L, true, true, (char) 43099, (char) 5809,
        Double.longBitsToDouble(0x3fe9f738205b268bL), Double.longBitsToDouble(0x3fa9a7c42811b630L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u5ec1", "\uda6a\udce2\ud9a4\udff1\udbb9\udfdc\ud9b8\uddf0\ud87c\uded3",
        30, 34919, -1707133008, 7067264940299727253L, -89888L, true, false, (char) 46706, (char) 36345,
        Double.longBitsToDouble(0x3fdc6c457a947e2eL), Double.longBitsToDouble(0x3fe1e10741b5c8cdL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=null |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 3, 10, "\ud944\udc68\ud970\udec6\uda30\ude3c", "\uaf75", "\udb7b\udd4d\ud9a1\udca8\uda0d\ude6e\ud8e9\udf91\ud881\udde0\ud950\ude49\ud8e7\udee9\uda75\udeed\uda8e\ude52\ud936\udc69\ud920\uddba\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\ud910\udfce\ud8d2\udc60\udb2f\udf39\ud8b7\udc70\ud9f2\udecd\uda20\udffe\ud958\ude93\ud83d\uddf9\ud845\uddb9\udb42\udf99\ud9a8\ude04",
        15, 92388, -224152453, 7801106155275866894L, 22549L, true, true, (char) 19804, (char) 17612,
        Double.longBitsToDouble(0x3fdcb65857b5f3aaL), Double.longBitsToDouble(0x3fe9f73f7f5b268bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\ud8f8\ude37\ud8cf\ude94\ud9c5\udcf3\ud972\udd12\ud9b7\udf10\uda60\ude77\ud953\ude33\ud931\udff7\udb0b\udf74\ud956\udcc7\ud8a2\udf4d\ud9b8\uddc5\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud920\udd42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\ud83c\uddcf\udb38\udd7d\ud9ad\udf3a", "\u8de7\u326d\u00d2\u12cb\u23b3\u4e0d\ubf39\u50c0\u15ae\u047a\u34a5\u1907\ubbbe\u25a2\ubef8\u3d54\u5c04\u6c4e\u337a\u7754\u38ed\u4376\ud05b\u08c5\ub6ae\u790a\u37c2\u0353\u6b59\ucd2a\u2acc\u7a25\ud396\u47d9", "\udb5c\udf8d\u9753\u4078",
        30, 76476, -1759508108, -3522783535383142425L, -46980L, false, false, (char) 16873, (char) 29044,
        Double.longBitsToDouble(0x3fced6c8a5c302ccL), Double.longBitsToDouble(0x3fd95c18051c8124L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 2, 8, 10, "\ud905\udefd\udb7a\udfc4\udb07\uddbb", "\u5ec1\u55b2", "\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\u695e",
        43, 3548, -1473150921, -3096716445470809070L, -34884L, false, false, (char) 620, (char) 57885,
        Double.longBitsToDouble(0x3fd533f17c78417aL), Double.longBitsToDouble(0x3fd7dc8cddab3eecL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 10, "\ud92c\udf91", "\uaf37\u24a5\u5ec1\u29ca", "\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud805\udc35\ud950\ude49",
        31, 24617, -1491864437, -1392724072414436233L, -34884L, false, false, (char) 620, (char) 57885,
        Double.longBitsToDouble(0x3fd4a3f17cc5dba6L), Double.longBitsToDouble(0x3fd7dc8cdd0868ecL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 0, "\ud905\ude22", "\uaf37", "\ud8b5\ude1a\ud931\udff7\ud9a0\udffe",
        -5, -1000, 0, -863664896L, 69279L, true, false, (char) 37800, (char) 4251,
        Double.longBitsToDouble(0x3fc019334693fdccL), Double.longBitsToDouble(0x3e1d774000000000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 5, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c\ud972\udd12", "\ub435\u96d0\u7f5e\ua1e2\u738d\u4c9a\u0833\ua84e\uc676\ub6b4\u18c9\ub3eb\ud3a2\ubfd9\uaf3a\ub806\u9135\u588c\u544a\ubccf\u3712\u8de7\u326d\u5f68\u2f43\u23b3\u4e0d\ubf39\u50c0\u15ae\u047a\u9d3c\u1907\ubbbe\u25a2\ubef8", "\uda78\uddf6",
        13, 63458, 646689598, -3641363319414211356L, 33341L, true, false, (char) 25029, (char) 59523,
        Double.longBitsToDouble(0x3fa20d34ada52d10L), Double.longBitsToDouble(0x3fe75e16a00e2c05L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\ud905, \udefd, \ud970, \udec6, \uda30, \ude3c]]\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 10, 5, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u5ec1", "\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud8a2\udff4\udb3b\udc3f\uda75\udf00\uda8e\ude52\ud936\udc69\ud920\udd42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\ud8e6\udc54\ud90a\ude49\ud8ab\udd2a\ud8c3\udde6\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99\ud842\uddab\udaf1\udd4c\uda2a\udf1b",
        42, 52567, 1481954062, -2985448135944318613L, 14103L, true, true, (char) 4944, (char) 43620,
        Double.longBitsToDouble(0x3fe9f73f7f5b268bL), Double.longBitsToDouble(0x3fcc99aeea0640b4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 5, 10, "\ud905\ude22\000\uda30\ude13", "\000", "\uda6a\udce2",
        42, 341, -1625321620, 4767625114038928722L, -100000L, false, false, (char) 25256, (char) 4251,
        Double.longBitsToDouble(0x3fc019334693fdccL), Double.longBitsToDouble(0x3f29fb8000000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 5, 10, "\ud932\udf3c\ud970\udec6\uda30\ude3c\ud972\udd12\ud8c1\ude3b\ud436\ud8e3\ude0d\ud931\udff7\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud920\udd42\udae6\udc77", "\u9135\u588c\u544a\ubccf\u48da\u8dcb\u326d\u5f68\u2f43\u23b3\u4e0d\ubf39\u50c0\u15ae\u047a\u34a5\u1907\ubbbe\u25a2\ubef8\u3d54\u5c04\u6c4e\u337a\u7754\u38ed\u4376\ud05b\u7b86\u0254\u1d5a\u2218\u1ca7\u7173\u89e2\u3beb\ub7d1\u6467\uaf98\u3d2e\uc46d\u53e9\u89e2\u34f5\uc405", "\uda08\udf93\udb2e\udde7\uda89\ude5b\uda88\ude68\udb3b\udc1a\ud9b1\udfa5\udb0b\udd24\udb4e\udeee\ud867\udf0b\ud90c\uddc9\uda30\udcc6\uda51\udf92\ud827\udc1d\udb50\udda7\udb04\udcb4\udb7d\udf0a\udb2e\udcf8\uda56\udd56\ud924\udea1\ud830\udc09\udb5e\udfae\uda3d\udf17\udbf2\udfc4\udadb\udc02\ud8ac\ude1d",
        -4, 74122, -57992779, -9178847420048753153L, 48652L, true, false, (char) 2410, (char) 11775,
        Double.longBitsToDouble(0x3fd41b35b37b43a2L), Double.longBitsToDouble(0x3fb34ee5f1207380L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 0, 10, "\ud905\udefd", "\000\ub684\u5ec1\u29ca", "\ud9c8\udc03\udbcb\udee5",
        51, 58224, -863664814, -1436122618895439167L, -89888L, false, true, (char) 15965, (char) 0,
        Double.longBitsToDouble(0x3e4528fc5c000000L), Double.longBitsToDouble(0x3fe1e107417dc8cdL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 2, "\ud905\udefd\ud970\udec6\uda30\ude3c\ud972\udd12\ud8c1\ude3b\ud436\ud8e3\ude0d\ud931\udff7\udba1\udfa2\ud954\udf7e\ud84a\ude6c\ud876\udc19\ud88f\udd1b\ud950\ude49\ud91f\udce9\ud918\udf3f\ub1ab\udbce\udc74\ud920\udd42\ud893\udc7a\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\u1985\ud9ad\udf3a\ud8c0\udefb\uda9c\udc7c\udb6b\udf8d\u8de8\udbaa\udd36\ud958\udea6\ud978\uddb4\ud884\udf38\udb2b\udcf6\udb7f\udf4b", "\u19c4\u1907\ubbbe\uc143\u05f9\u3e18\u5c04\ubd89\uac45\u7754\u38ed\u4376\ud05b\u4d1f\uc5b3\u13d6", "\ud8f2\ude64\udaea\udcaf\ud879\uddf9",
        35, 47212, 1832146411, 5079604789239006787L, 8917L, true, true, (char) 30057, (char) 42987,
        Double.longBitsToDouble(0x3fdc53e1d6250c90L), Double.longBitsToDouble(0x3fee3e5d1b979712L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 11, 9, 10, "\ud9c2\udf61\udbc6\udef4\ud8d4\udfed\ud8f5\udd40\uda46\udda4\ud436\ud8e3\ude0d\uda80\ude39\ud8bf\udc53\ud863\udf32\ud95d\udd36", "\u1aef\uc676\ubb7f\u46ec\uacdf\u60eb\u988f\uc02c\u3d25\u529b\u6057\u544a\ub214\u6744\u02aa", "\uda7e\udcf8\ud9f8\udee8\ud95c\udc64\udab6\udd1a\uda19\uddb7\udaf1\udd10\ud9e4\ude0a\udb29\udfc7\ud90b\udf18",
        12, 2205, 1840238955, 1134004653467851502L, -55509L, false, false, (char) 39500, (char) 28134,
        Double.longBitsToDouble(0x3f9b57acec6481a0L), Double.longBitsToDouble(0x3fea78903262a5a6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 4, "\ud905\udefd\ud970\udec6\uda30\ude3c\ud972\udce0\ud83f\uddfb\udb16\udcf0\uda4a\udd8f\ud929\udd3b\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\udbd7\udd46\ud88b\udcdf\udb7b\udc33\ud98f\ude56", "\u9135\u588c\u95ed\u83a0\u3712\u2175\u4776\uc5ff\u2226\u23b3\u4e0d\ubf39\u50c0\u15ae\u047a\u34a5\u1907\u7ca2\uc752\ub6dc\u5340\u57de\u6803\u8ca9\u7754\ub7db\u548d\u8353\u631d\u1a7d\u7a8c\ud2b5\u14fd\u92b3\uc148\u2bec\ubb51\ua72b\u04bd\ud143\u6c30\u54c9\u1980\u9820\u291a", "\ud99a\udc06\ud905\udec1\uda4e\udc43\udbfa\udf93\udaad\udf65\ud882\udd2f",
        58, 94441, -637915643, -142321701328788569L, 29756L, false, false, (char) 59884, (char) 13885,
        Double.longBitsToDouble(0x3fd87d3488c43ffeL), Double.longBitsToDouble(0x3fe15b06d3b3c6e1L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.language.Soundex:@?\0121=void |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 7, 7, 10, "\ud905\udefd\ud970\udec6\udaa1\udf95", "\u5ec1", "\uda6a\udcea\uda39\udc95\udbfe\udc9a\ud9bf\udcb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud86c\udf85\ud931\udc42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\uda3e\udf79\udb40\uded6\ud845\ude34\udb42\udf99\udb7f\udf4b\udb4d\udcfd\uda0f\udc70",
        8, 56183, 1481911788, 2562986604976132459L, 14103L, true, true, (char) 4944, (char) 43620,
        Double.longBitsToDouble(0x3fe6d51f7c2d9973L), Double.longBitsToDouble(0x3f929b44ec3205a0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "", "\ua824", "\udb30\ude97",
        23, 5764, 1407456241, -6756656161685059147L, 31528L, false, true, (char) 52379, (char) 27329,
        Double.longBitsToDouble(0x3e29562000000000L), Double.longBitsToDouble(0x3f4d846203266800L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 5, 5, 10, "\ud905\udefd\ud9a1\udd3a\udbed\ude6d\ud972\udc73\udacd\uddb6\uda61\udf22\ud8e3\udd52\ud931\udff7\uda6a\udce2\uda3d\ude91\udbfe\udcae\ud9b8\uddb6\ud8ac\udc64\ud950\ude49\ud91f\udce9\uda75\udeed\ud8ba\udf9d\ud963\udd30\ud9a9\udc73\uda5d\udfb3\udbe1\udcb3\ud9e5\udc7e\ud8c5\udf23\ud9f2\udcc4\ud9df\udec0\ud813\ude34\ud849\udd0e\udb6b\udef4\ue332\udb0b\ude99\uda80\udd6f\ud84b\udcdf\ud9f6\udc19\udb42\udf69\udb7f\udf4b\udbd3\udfc2\uda2a\ude96\ud800\udfe3\ud860\ude8d\ud8fb\udef2\udbc1\udc4b\ud954\udc1a\ud96d\udcdf\uda23\udf6c\uda78\uddf6\ud83e\udff4\ud9fa\udc4b\udb49\udd03\uda7b\udcaf\ud974\udf0e\uda67\ude99\ud8af\ude33\udbc1\udf41", "\u70ec\u080d\ubdbd\u39f9\uc7ed\u9499\ubb9e\u8eb3\u0287\ub1ee\u556f\ucbe4\u20bb\ubeb1\u467e\u4c3b\u59c1\ua129", "\u0cac\uda07\udcd4\udbd0\udf84\udb9e\ude5d\uda62\udff4\udbc1\udd05\ud803\udd7a\u3b50\ud80c\ude36\udb86\udf36\u446d\uda18\ude7c\uda9f\udc2e\uda92\udee3\ud910\udfef\udb1a\udc4b\uda57\udd6a\uda7b\udc6e\udb39\udd85\uda12\udf92\udba8\udf0e\ud84b\ude20\udb7a\udd4c\ud930\udff0\udace\ude8c",
        27, 53931, 1951976247, -8579224441999600854L, 13504L, false, true, (char) 55558, (char) 34096,
        Double.longBitsToDouble(0x3fde6cd2bea3c750L), Double.longBitsToDouble(0x3fc88f938a627d44L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 3, 2, 8, "\ud92e\udd71\ud970\udec6\uda30\ude3c", "\u5ec1\u29ca\u45d7\u7f5e\ua1e2\u738d\uaf90\u453b\ua84e\uc676\ub6d1\u18c9\u620a\u3b93\ubfc9\uaf3a", "\udb38\udd12\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9",
        -2, 62472, -331575734, -3768469083296017020L, -88075L, false, false, (char) 5079, (char) 1111,
        Double.longBitsToDouble(0x3fdcb65857b44d16L), Double.longBitsToDouble(0x3fe9f73f7b5b268bL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 10, "\ud92e\udd71\ud970\udec6\ud932\ude3d", "\u5ec1\u29ca\u45d7\u7f5e\ua1e2\u738d\uaf90\u453b\ua84e\uc676\ub6d1\u18c9\u620a\u3b93\ubfc9\uaf3a", "\udb38\udd12\ud9ad\udf3a\ud86c\udf50\udb88\udf5f\u50c8\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9",
        -2, 62472, -348352950, -5542541754812377477L, -88075L, false, false, (char) 14807, (char) 23382,
        Double.longBitsToDouble(0x3fdf293af7b44d16L), Double.longBitsToDouble(0x3fe9f73f7c08558bL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:O000 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:4 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 4, 10, "O\ud970\udec6\udbe3\udc10", "\u5ec1\u30d7\u96ba\u3a5f\u2897\u5212\u57ff\u453b\ua84e\uc676\ub6d1\u18c9\u620a\u3b93\ubf58\000", "\udb38\udd12\ud9ad\udf3a",
        5, 3253, 213364437, 1824692776222621023L, -65831L, false, true, (char) 18572, (char) 60,
        Double.longBitsToDouble(0x3fbeecc507a00000L), Double.longBitsToDouble(0x3fe8755a18000054L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 10, "\ud92e\udd5f\ud970\udec6\uda30\ude3c", "\u5ec1\u29ca\u45d7\u7ecc\ua1e2\uc074\uaf90\u453b\ua84e\uc676\ub6d1\u18c9\u620a\u3b93\ubfc9\ua58d", "\udb38\udd12\udb91\udf67\ud8a3\udf0c\uda36\udfcc",
        47, 46922, -558862290, -5278372428504800136L, -80667L, false, false, (char) 32337, (char) 59174,
        Double.longBitsToDouble(0x3fd6bd69106dd35eL), Double.longBitsToDouble(0x3fdb77c20b0b4da2L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!org.apache.commons.codec.EncoderException\012",
        Z.run(T, 2, 2, 0, 10, "\ud929\ude71\ud970\udec6\uda33\udfff", "\u5ec1\u29ca\u4516\u2a9b\u3c55\u31ce\u0efb\u453b\ua84e`\u8bb3\u1869\u620a\u9392\u9dc7\u7d6d", "\udb38\udd12\ud9ad\udf3a\uda44\udd28\ud9bf\udf09\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\udbc8\ude89\ud8a6\udd9d",
        -2, 62472, 592809546, -2495562497786661765L, -88075L, false, false, (char) 14807, (char) 1111,
        Double.longBitsToDouble(0x3fdb9e7857b44d16L), Double.longBitsToDouble(0x3fe9f73f7f5b268bL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 11, 4, 6, "\uda2b\udf58\ud89c\udfbf\uda30\ude5c", "\u4bf6\ub668\u121e\u7f5e", "\udb70\udf77\udab4\udd5e\ud950\ude49\udad8\udd45\ud938\udddb\ufe30\ud961\udebc\ud93f\ude26",
        21, 61780, -1164343262, -2604769932929983141L, -32868L, true, false, (char) 20025, (char) 29427,
        Double.longBitsToDouble(0x3fd5f19521611df0L), Double.longBitsToDouble(0x3fe384cc610ef390L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 10, "O\u3400\uda30\ude3c", "\u5e30\u29ca\u45d7\u7f5e\ua1e2\u738d\uaf90\u00fd\ua7fc\uc676\ub6d1\u80b2\u620a\u3b93\ubfc9\uaf3a", "\udb38\udd12",
        58, 81380, -1619631747, 916393279469296746L, -81838L, true, false, (char) 28127, (char) 18572,
        Double.longBitsToDouble(0x3fed2759e47bb314L), Double.longBitsToDouble(0x3fce97f46c3aad0cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 1, 3, 5, 10, "", "\ua824", "\000",
        27, 5764, 1407456241, 0L, -100000L, false, true, (char) 43675, (char) 22227,
        Double.longBitsToDouble(0x3f31b54000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\ud905\udefd\uda73\udf88\uda30\ude3c", "\ud636", "\uda6a\udce2\ud954\udf7e\uda5f\udce1\ud835\udfa1\ud88f\uddae\ud950\ude49\ud91f\udce9\ud86b\udf48\udaae\udf02\ud936\udc69\ud920\udd42\uda9d\udcc0\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\udbca\udf28\uda59\udfd0\ud8f7\udc1d\ud9f9\udcef",
        18, 38878, -1718832976, -879136029769809321L, -26461L, false, true, (char) 3341, (char) 47905,
        Double.longBitsToDouble(0x3fe8c9b498373ed5L), Double.longBitsToDouble(0x3fa990b0b6f15da0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 8, 9, 0, "\000", "\uaf37\u24a5\u3a9b\u50e3", "\ud954\udf7e\udbcb\udf9a\udb67\udf6d\ud88f\uddae\ud950\ude49",
        -3, 24617, 1645474955, -1431245740543695753L, -34884L, false, false, (char) 47744, (char) 57798,
        Double.longBitsToDouble(0x3fd4a3f1700001d0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=new org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 9, 0, "", "\000", "",
        4, 32872, 564192764, 6044978525649996037L, -71180L, false, true, (char) 51067, (char) 0,
        Double.longBitsToDouble(0x3fe00000040046d5L), Double.longBitsToDouble(0x3fd9562130efd846L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\ud905, \udefd, \ud970, \udec6, \uda30, \ude3c]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 6, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u3a9b", "\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud81d\udc80\udae6\udc77\udbe1\udcb3\ud9d1\ude4d",
        27, 99558, 15215946, 0L, -100000L, true, false, (char) 45231, (char) 21500,
        Double.longBitsToDouble(0x3fd0e009050f8eeeL), Double.longBitsToDouble(0x3feb4453be4aba42L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6\uda30\ude3c\ud972\udd12\ud8c1\ude3b\ud8c6\udd9e\ud85d\ude0e\ud931\udff7\udbd5\udc58\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud81d\udc80\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbb7\udc7b\udb38\udd7d\uda91\udf47", "\000", "\ud958\udea6",
        42, 34846, -1971881337, 6035561718026374730L, -45756L, true, false, (char) 62077, (char) 27785,
        Double.longBitsToDouble(0x3fd7a484a6183934L), Double.longBitsToDouble(0x3febbc52cc7d87f6L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 6, "\ud905\udec9", "\u4971\u24a5\u307e\u29ca", "\ud819\udc3f\uda6c\udf7e\000\udb5c\udfee\ud956\ude99",
        37, 32995, 1645474955, -1431299617536203657L, -34735L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd4a3f17c7841d0L), Double.longBitsToDouble(0x3fd7dc8cddab3eecL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 10, "", "\u0a0b", "\ud436",
        26, -1000, 1407456000, -6756656159988987467L, 96294L, false, false, (char) 65395, (char) 22210,
        Double.longBitsToDouble(0x3fc168daa000004cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 10, "\ud905\udefd\ud8a1\udd5e\ud945\udd25\ud972\udcaf\ud8c1\ude3b\udbbd\uddf9\ud8e3\ude0d\ud931\udff7\uda6a\udce2\ud954\udf7e\ud86b\ude90\udaf7\udeac\uda07\uddfc\udae2\udc3e\ud922\udf74\uda75\udeed\uda8e\ude52\ud936\udc69\udbe8\udd46\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb4b\udd84\ud8ba\uddb1\udb1c\udf28\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99", "\u23f9", "\ud986\udea0",
        4, 55745, 1899949671, -8276867423501573467L, -36249L, true, false, (char) 35406, (char) 26844,
        Double.longBitsToDouble(0x3feeeecf9e20df2cL), Double.longBitsToDouble(0x3fefc46f87ef7d80L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\udab9, \udc4b, \ud8c8, \udd76, \ud86a, \udd50, \uda75, \uded3]]\0121=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\udab9, \udc4b, \ud8c8, \udd76, \ud86a, \udd50, \uda75, \uded3]]\012",
        Z.run(T, 2, 10, 10, 5, "\udab9\udc4b\ud8c8\udd76\ud86a\udd50\uda75\uded3", "\u4569\u52c0", "\udab7\udff8\ud874\udcac\ud9ec\udc1c\ud96b\udc5b\uda51\udec4\uda95\ude12\uda8e\ude52\ud936\udc99\uda2a\ude46\ud930\ude53\udbe1\udce2\ud9d1\ude4d\udbc9\udc66\udaea\ude9e\udb6b\udcfd\ud8d1\udd73\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\uda8d\udec0\udbad\udf40\ud9dd\udcc1\u653e\udb7f\udf4b\udaf1\udd10\uda2a\udf1b\udb94\udfae\ud90b\udf18\ud9dc\udc3c\ud98d\udd34\udac7\udf99\uda77\udfef\uda2b\udfc8\udbc3\udefd",
        13, 63458, -2112376002, -4648985376022741859L, 4700L, true, true, (char) 57742, (char) 60451,
        Double.longBitsToDouble(0x3fefd1a82da2a09dL), Double.longBitsToDouble(0x3fc8394770f31ed8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 2, 2, 10, "\ud905\udefd\udb7a\udfc4\udb07\uddbb", "\u5ec1\u55b2", "\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\udb62\udcd7\u699b",
        43, 3548, -1473150921, -3096716443011701742L, -34884L, false, true, (char) 64462, (char) 57885,
        Double.longBitsToDouble(0x3fdcf3f17bd50654L), Double.longBitsToDouble(0x3fd7dc8cddab3eecL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 2, 10, "\ud905\udefd\udb7a\udfc4\ud8f3\udf71\uda53\ude50\ud984\uddcc\ud86c\udeb4\ufd72\ud931\udff7\ud9f1\udf47\ud821\udd83\ud9f9\udd72\ud9bc\udf50\ud88f\uddae\u695e\ud2c3\udb6e\ude4a\ud8c9\ude10\ufe72\ud86d\udf13\ud9b8\udc3f\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\ud99e\udf11\udbc8\udf40\ud865\udc2d\uda70\udf07\ud839\udc9a\ucf0a\ud951\udf9d", "\ud27f\u4e7a\u5752\uc717\u1db3\ub632\u6555\u1a5d\u6100\u84d9\u71fe\uad02\u9d29\u24ce\u0fe4\u2e12\ubba0\u9872\uc23f\u1243\ucd0a\u16f2\uc33d\uc173\u556f\u05bf\u678b\u5d7b\u1697\u997e\u5d53\u09b6\uac59\u5f12\u3401\u383d\u6fe6\u466b\u0320\u933e\u0a01\u6243\u5a68\u0df5\u6758\u062c\u8c24\ub2d2\ud566\u72b2\uc320\ubb93\u4cfe\u8f40\u3638\u2c96\u6d92\u6450\u75c0\u0d72\u12c1\ua4a7\u04db\u29e0\u0172\u3ecc\u1031\ucc9c\uc33c\u6180\ud51b\ub1d1\ubb66\ub6fe\u7994\ud103\u39b2\ub73d\u5ff7\u4cca\u9066\u23f2\uc650\ud4ed\u2061\u1a15\u5fec\u5a9b\u35fe\u55df\u97a6\ud093", "\ud986\udee9\uda3e\udead\u056d\ud8da\udee1\ub9ae\u0ecc\ud821\udc83\udbec\udd9f\ud9cd\ude82\uda84\udd7d\ud8a5\udc53",
        28, 79953, 303323694, 3429260451802677892L, -68719L, false, true, (char) 53760, (char) 14359,
        Double.longBitsToDouble(0x3fdfad6317c7300aL), Double.longBitsToDouble(0x3fc3b5fdebf6c3d0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\ud905, \udefd, \ud970, \udec6, \uda30, \ude3c, \ud972, \udd12, \ud8c1, \ude3b, \ud436, \ud8e3, \ude0d, \ud931, \udff7, \uda6a, \udce2, \ud954, \udf7e, \udbfe, \udc9a, \ud9b8, \uddb6, \ud88f, \uddae, \ud8a2, \udff4, \udb3b, \udc3f, \uda75, \udf00, \uda8e, \ude52, \ud936, \udc69, \udaff, \udd71, \udae6, \udc82, \udbe1, \udcb3, \ud9d1, \ude4d, \ud8e6, \udc54, \ud90a, \ude49, \ud8ab, \udd2a, \ud8c3, \udde6, \uda36, \udfcc, \udb6b, \udf94, \u8de8, \udb0b, \udeb5, \ud958, \udea6, \ud978, \uddb4, \ud845, \uddb9, \udb42, \udf99, \ud842, \uddab, \udaf1, \udd4c, \uda2a, \udf1b, \ud99a, \udfb1, \ud90b, \udf18, \uda60, \udc42, \udbc1, \udc4b, \ud954, \udc1a, \udaa2, \udd86, \uda2c, \udc75, \uda78, \uddf6, \ud9f8, \udc10, \udbca, \ude6e, \ud9f9, \udd83, \uda5d, \udc60, \udbff, \ude4c, \ud813, \uddff...\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 10, 5, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c\ud972\udd12\ud8c1\ude3b\ud436\ud8e3\ude0d\ud931\udff7\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud8a2\udff4\udb3b\udc3f\uda75\udf00\uda8e\ude52\ud936\udc69\udaff\udd71\udae6\udc82\udbe1\udcb3\ud9d1\ude4d\ud8e6\udc54\ud90a\ude49\ud8ab\udd2a\ud8c3\udde6\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99\ud842\uddab\udaf1\udd4c\uda2a\udf1b\ud99a\udfb1\ud90b\udf18\uda60\udc42\udbc1\udc4b\ud954\udc1a\udaa2\udd86\uda2c\udc75\uda78\uddf6\ud9f8\udc10\udbca\ude6e\ud9f9\udd83\uda5d\udc60\udbff\ude4c\ud813\uddff\ud844\ude78\ud8d8\udc99", "\ubb49\u800c\ubfb3\u89b4\u26e0\u0739\ucf5c\uaece\u061f\u7415\u6b1b\ubb3d\ucebf\u255dC\u9c3f", "\uda4e\udccc\ud81c\udd94",
        12, 94616, -1842695741, -5074473499128706884L, 96417L, true, true, (char) 55032, (char) 2057,
        Double.longBitsToDouble(0x3fdbef799a9bc7c4L), Double.longBitsToDouble(0x3fef1b83028e5f75L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 1, "", "\u45af\u6962\u90b5\u2b57\u29ca\u032c\ub4c9\u95e3\u737f\u0a08\u6c71\u4f1d\ua8b3\u1005\ua31e\u192a\u3d6f", "\udafb\ude8a",
        33, 28213, -1282295693, -3899572893385256698L, -29932L, true, false, (char) 11716, (char) 15110,
        Double.longBitsToDouble(0x3fc694c4873f7238L), Double.longBitsToDouble(0x3fea6ac1e2a18523L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String:O000 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.String:O000 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 2, 8, "O\ud919\ude2c\uda30\ude3c", "\u5ec1\u29ca\u45d7\u7f5e\ua1e2\u738d\uaf90\u45fd\u725e\uc676\ub6d1\u18c9\u3195\000\ubf59\u0d16", "",
        38, 10520, -926087620, 213364437L, -67905L, false, false, (char) 21500, (char) 0,
        Double.longBitsToDouble(0x3fc0f8e00da229dcL), Double.longBitsToDouble(0x3fe250000556ec3cL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String:O000 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.String:O000 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 2, 4, "O", "\ua14a\u24a5\u5ec1\u29ca", "\ud954\udf7e\udbfe\udc9a\ud9ec\udd10\udab4\udded\ud950\ude49",
        31, 24646, 1645474955, -1431245739320703881L, -34884L, false, false, (char) 47628, (char) 63796,
        Double.longBitsToDouble(0x3fd4a3f17c7841d0L), Double.longBitsToDouble(0x3fd7dc8cddab3eecL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 3, "O\ud9cd\ude94\ud9e4\udfba\ud32c\uda49\udefa\ud436\udadc\udf89\ud9b9\ude03\ud88b\udce4\udb6a\ude75\uda7c\uddb9\uda84\udda2\udab4\uddbe\ud88a\udfda\ud933\udd5c\uda75\udf0a\uda82\udc51\udabb\udd6b\ud999\udcf3\udab0\udc66\u775e\uda10\udc07\udac3\udfb1\udac4\udc27\ud9ad\udfdd\ud878\udd37\ud844\udf2b\udb6b\udf94\ud9ea\udd6a\udb0b\ude79\ud958\udea6\ud978\uddb4\ud845\uddb9\udaa6\ude09\ud845\udccd\udb1a\udec4\ud9ee\udf77\udab6\udf02\uda0c\udc99\udbfe\udf12\uda8e\uddc6\udbc0\ude53\uda77\ude70\udbe9\udc50\udacc\udc9f\uda71\udd00\ud972\udf00\uda3b\ude37\udb37\ude53\u0a54\udb87\udf1f\ud9e4\udfba\ud890\ude92\uda6b\udd2a\uda24\udc1e\udb14\udf0b\u65c9\ud905\udc08\ud80e\ude25\udb0d\udde4\udbbe\udd65\udb8a\udfcd\u4865\ud939\udf69\udbc9\ude65\udb10\ude64\uda54\udd8d\ud98d\ude2d\uda74\udc95\ud848\ude89\ud995\udf87\ud82b\udc3c\udb96\udec0\udb19\udfc0\uda8a\ude3d\udb13\udd08\ud8fc\udc9a\uccf1\ud94e\udcc2", "\u8aed\ubde9\u0bdf\u4e28\u30f8\u7aeb\ub4db\ub3c8\ub418\u47ff\u5f62\ud6bf\u47f2\u3925\u8d13\u6ab1\u280a\ub45e\uc497", "\udb87\udffa\ud9fc\udc5e\uda11\udfa8\uda5e\udc13\udb32\ude9b\udb7b\udf17\udb66\udf03\ud8ee\udfc6\ud985\udd8d\ud95b\udf54\udb96\udc20\udb9d\udf70\ud80d\udd92\ud989\udf39\ud9a9\udeae\uda73\udf4a\ud966\udca5\u7b17\udb55\ude55\ud88c\udd92\ud955\udf3d\ud9e8\udc7e\ud8ff\ude1f\uda1d\udc66\uda22\udcc4\ud9e4\udf7a\uda9c\uddcb\ud8d0\uddbd\udbb7\udff0\udb07\udfb1",
        58, 55308, 1467073460, 7922565244197265660L, 21068L, true, false, (char) 65045, (char) 57757,
        Double.longBitsToDouble(0x3fef555459e2cb42L), Double.longBitsToDouble(0x3f6feb62d20ff400L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\ud905, \udefd, \ud970, \udec6, \uda30, \ude3c, \ud972, \udd12, \ud8c1, \ude3b, \ud436, \ud8e3, \ude0d, \ud931, \udff7, \uda6a, \udce2, \ud954, \udf7e, \udbfe, \udc9a, \ud9b8, \uddb6, \ud88f, \uddae, \ud8a2, \udff4, \udb3b, \udc3f, \uda75, \udf00, \uda8e, \ude52, \ud936, \udc69, \udaff, \udd71, \udae6, \udc82, \udbe1, \udcb3, \ud9d1, \ude4d, \ud8e6, \udc54, \ud90a, \ude49, \ud8ab, \udd2a, \ud8c3, \udde6, \uda36, \udfcc, \udb6b, \udf94, \u8de8, \udb4f, \ude4e, \ud958, \ude7c, \ud978, \uddb4, \ud845, \uddb9, \udb42, \udf99, \ud842, \uddab, \udaf1, \udd4c, \uda2a, \udf1b, \ud99a, \udfb1, \ud90b, \udf18, \uda60, \udc42, \udbc1, \udc4b, \ud954, \udc1a, \udaa2, \udd86, \uda2c, \udc75, \uda78, \uddf6, \ud9f8, \udc10, \udbca, \ude6e, \ud9f9, \udd83, \uda5d, \udc60, \udbff, \ude4c, \ud813, \uddff...\0121=new org.apache.commons.codec.language.Soundex:@? |a0=[C:[[\ud905, \udefd, \ud970, \udec6, \uda30, \ude3c, \ud972, \udd12, \ud8c1, \ude3b, \ud436, \ud8e3, \ude0d, \ud931, \udff7, \uda6a, \udce2, \ud954, \udf7e, \udbfe, \udc9a, \ud9b8, \uddb6, \ud88f, \uddae, \ud8a2, \udff4, \udb3b, \udc3f, \uda75, \udf00, \uda8e, \ude52, \ud936, \udc69, \udaff, \udd71, \udae6, \udc82, \udbe1, \udcb3, \ud9d1, \ude4d, \ud8e6, \udc54, \ud90a, \ude49, \ud8ab, \udd2a, \ud8c3, \udde6, \uda36, \udfcc, \udb6b, \udf94, \u8de8, \udb4f, \ude4e, \ud958, \ude7c, \ud978, \uddb4, \ud845, \uddb9, \udb42, \udf99, \ud842, \uddab, \udaf1, \udd4c, \uda2a, \udf1b, \ud99a, \udfb1, \ud90b, \udf18, \uda60, \udc42, \udbc1, \udc4b, \ud954, \udc1a, \udaa2, \udd86, \uda2c, \udc75, \uda78, \uddf6, \ud9f8, \udc10, \udbca, \ude6e, \ud9f9, \udd83, \uda5d, \udc60, \udbff, \ude4c, \ud813, \uddff...\012",
        Z.run(T, 2, 10, 10, 6, "\ud905\udefd\ud970\udec6\uda30\ude3c\ud972\udd12\ud8c1\ude3b\ud436\ud8e3\ude0d\ud931\udff7\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud8a2\udff4\udb3b\udc3f\uda75\udf00\uda8e\ude52\ud936\udc69\udaff\udd71\udae6\udc82\udbe1\udcb3\ud9d1\ude4d\ud8e6\udc54\ud90a\ude49\ud8ab\udd2a\ud8c3\udde6\uda36\udfcc\udb6b\udf94\u8de8\udb4f\ude4e\ud958\ude7c\ud978\uddb4\ud845\uddb9\udb42\udf99\ud842\uddab\udaf1\udd4c\uda2a\udf1b\ud99a\udfb1\ud90b\udf18\uda60\udc42\udbc1\udc4b\ud954\udc1a\udaa2\udd86\uda2c\udc75\uda78\uddf6\ud9f8\udc10\udbca\ude6e\ud9f9\udd83\uda5d\udc60\udbff\ude4c\ud813\uddff\ud844\ude78\ud8d8\udc99", "\ubb49\u800c\ubfb3\u89b4\u26e0\u0739\ucf5c\uaece\u061f\u7415\u6b1b\ubb3d\ucebf\u255dC\u9c3f", "\uda4e\udccc\ud81c\udd94",
        12, 94616, -1842695741, -5074473499128706884L, 96417L, true, true, (char) 55032, (char) 2057,
        Double.longBitsToDouble(0x3fdbef799a9bc7c4L), Double.longBitsToDouble(0x3fef1b83028e5f75L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 3, "\u8a4f\ud9cd\ude94\ud9e4\udfba\ud32c\uda49\udefa\ud436\udadc\udf89\ud9b9\ude03\ud88b\udce4\udb6a\ude75\uda7c\uddb9\uda84\udda2\udab4\uddbe\ud88a\udfda\ud933\udd5c\uda75\udf0a\uda82\udc51\udabb\udd6b\ud999\udcf3\udab0\udc66\u775e\u34b7\ud853\udd3e\ud8af\udd2e\ud9ad\udfdd\ud878\udd37\ud844\udf2b\udb6b\udf94\ud9ea\udd6a\udb0b\ude79\ud958\udea6\ud978\uddb4\ud845\uddb9\udaa6\ude09\ud845\udccd\udb1a\udec4\ud9ee\udf77\udb50\udd0e\ud900\udd25\udbfe\udf12\uda8e\uddc6\udbc0\ude53\uda77\ude70\udbe9\udc50\udacc\udc9f\uda71\udd00\ud972\udf00\uda3b\ude37\udb37\ude53\u0a54\udb87\udf1f\ud9e4\udfba\ud890\ude92\uda6b\udd2a\uda24\udc1e\udb14\udf0b\u65c9\ud905\udc08\ud80e\ude25\udb0d\udde4\udbbe\udd65\udb8a\udfcd\u4865\ud939\udf69\udbc9\ude65\udb10\ude64\uda54\udd8d\ud98d\ude2d\uda74\udc95\ud848\ude89\ud995\udf87\ud82b\udc3c\udb96\udec0\udb19\udfc0\uda25\udd8b\ud8df\ude28\ud95a\udc10\uccd8\ud94e\udcc2", "\u8aed\ubde9\u0bdf\u4e28\u30f8\u7aeb\ub4db\ub3c8\ub418\u47ff\u5f62\ud6bf\u47f2\u3925\u8d13", "\u3122\ud908\udf06\udbaf\uddcc\uda8a\ude7f\udb87\udffa\ud9fc\udc5e\uda11\udfa8\uda5e\udc13\udb32\ude9b\udb7b\udf17\udb66\udf03\ud8ee\udfc6\ud985\udd8d\ud95b\udf54\udb96\udc20\udb9d\udf70\ud82c\udd92\ud989\udf39\ud9a9\udeae\ue3ff\ud97f\udc63\u7b17\udb55\ude55\ud88c\udd92\ud955\udf3d\ud9e8\udc7e\ud8ff\ude1f\uda1d\udc66\uda22\udcc4\ud9e4\udf7a\uda9c\uddcb\ud8d0\uddbd\udbb7\udff0\udb07\udfb1\ud81a\udd48\ud82d\udc64\ud8c2\udcdb\udade\udd97\udb64\udff1\udb0d\ude0c\udb74\uddca\ud92d\udd4e\udb31\udc81\udb26\udd7e\ud915\udcce\ud850\uddbb\udaab\udcf3\ud920\udf04\uf7cf\udb62\ude54",
        31, 98498, -486823406, -7004516868074731486L, -99060L, true, false, (char) 16738, (char) 38662,
        Double.longBitsToDouble(0x3fed349eb0def99dL), Double.longBitsToDouble(0x3fc327c61b278a2cL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 3, "O\ud9cd\ude94\ud9e4\udfba\ud32c\uda49\udefa\ud436\ud822\udff8\udb43\udc75\ud88b\udce4\udb6a\ude75\uda7c\uddb9\uda84\udda2\udab4\uddbe\ud88a\udfda\ud933\udd5c\uda75\udf0a\uda82\udc51\udabb\udd6b\ud999\udcf3\udab0\udc66\u775e\uda10\udc07\udac3\udfb1\udac4\udc27\ud9ad\udfdd\ud878\udd37\ud844\udf2b\udb6b\udf94\ud9ea\udd6a\udb0b\ude79\ud958\udea6\ud978\uddb4\ud845\uddb9\ud872\uddaf\ud845\udccd\udb1a\udec4\ud9ee\udf77\udab6\udf02\uda0c\udc99\udbfe\udfb3\udaa3\udd84\udbc0\ude53\uda77\ude70\udbe9\udc50\udacc\udc9f\uda71\udd00\ud972\udf00\uda3b\ude37\udb37\ude53\u0a54\udb87\udf1f\ud9e4\udfba\ud890\ude92\uda6b\udd2a\uda24\udc1e\udb14\udf0b\u65c9\ud905\udc08\ud80e\ude25\udb0d\udde4\udbbe\udd65\udb8a\udfcd\u4865\ud939\udf69\udbc9\ude65\udb10\ude64\uda54\udd8d\ud98d\ude2d\uda74\udc95\ud848\ude89\ud995\udf87\ud82b\udc3c\udb96\udec0\udb19\udfc0\uda8a\ude3d\udb13\udd08\ud8fc\udc9a\uccf1\ud94e\udcc2", "\u8aed\ubde9\u0bdf\u4e28\u30f8\u7aeb\ub4db\ub3c8\ub418\u47ff\u5f62\ud6bf\u47f2\u3925\u8d13\u6ab1\u280a\ub45e\u5a1a", "\udb87\udffa\ud9fc\udc5e\uda11\udfa8\uda5e\udc13\udb32\ude9b\udb7b\udf17\udb66\udf03\ud8ee\udfc6\ud985\udd8d\ud95b\udf54\udb96\udc20\udb9d\udf70\ud80d\udd92\ud989\udf39\ud9a9\udeae\ud83d\ude6f\ud82c\ude9b\ud955\udfe1\udb55\ude55\ud88c\udd92\ud955\udf3d\ud9e8\udc7e\ud8ff\ude1f\uda1d\udc66\uda22\udcc4\ud81e\uddcd\ud968\ude29\ud8d0\uddbd\udbb7\udff0\udb07\udfb1\ubd4e\ud82d\udc64\ud8c2\udcdb\udade\udd97\udb64\udff1\udb0d\ude0c\uda7f\uddaf\ud9e5\udd4f\ud8b0\udfbb\udb26\udd7e\ud915\udcce\ud850\uddbb\udaab\udcf3\udaef\udcd9\ud97f\udd64\udbf0\ude0f\ud81f\udd53\uda9c\udefd\ud9b5\udddb\udb43\udf5b\ud9e0\udd47\ud869\udde6\ud961\udff7\udba8\udf3a\udade\udcdf\uda19\udcfa",
        -1, 9418, 912435243, -2302421928243749210L, 41634L, true, false, (char) 49027, (char) 8002,
        Double.longBitsToDouble(0x3fe611e415be0b58L), Double.longBitsToDouble(0x3fe2f816fc23d37fL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 3, "\udba6\udcf7\ud9cd\ude94\ud9e4\udfba\ud32c\uda49\udefa\ud436\ud822\udff8\udb43\udc75\ud88b\udce4\udb6a\ude75\uda7c\uddb9\uda84\udda2\udab4\uddbe\ud88a\udfda\ud933\udd5c\uda75\udf0a\uda82\udc51\udabb\udd6b\ud999\udcf3\udab0\udc66\u775e\uda10\udc07\udac3\udfb1\ud997\udd3f\ud9c1\udf70\ud878\udd37\ud844\udf2b\udb6b\udf94\ud9ea\udd6a\udb0b\ude79\ud958\udea6\ud978\uddb4\ud845\uddb9\ud872\uddaf\ud845\udccd\udb1a\udec4\ud9ee\udf77\udab6\udf02\uda0c\udc99\udbfe\udfb3\udaa3\udd84\ud814\udffe\uda77\udee8\udbe9\udc50\udacc\udc9f\uda71\udd00\ud972\udf00\uda3b\ude37\udb6a\udc53\u0a54\udb87\udf1f\ud9e4\udfba\ud890\ude92\uda6b\udd2a\uda24\udc1e\udb14\udf0b\u65c9\ud87d\udf11\ud80e\ude25\udb0d\udde4\udbbe\udd65\udb8a\udfcd\ud96f\udec4\ud905\udc70\udbc9\ude65\udb10\ude64\uda54\udd8d\ud98d\ude2d\uda74\udc95\ud848\ude89\ud995\udf87\ud82b\udc3c\uda6b\udfac\ud9cb\udd79\uda8a\ude90\udb13\udd08\ud8fc\udc9a\uccf1\ud94e\udcc2", "\u8aed\ubde9\u0bdf\u4e28\u30f8\u7aeb\ub4db\ub3c8\ub418\u47ff\u5f62\ud6bf\u47f2\u3925\u8d13\u6ab1\u34c4\u3cd5\u5a1a", "\ud93a\ude42\ud89a\udeb1\uda29\udf70\uda5d\udffc\udb32\ude9b\udb7b\udf17\udb66\udf03\ud8ee\udfc6\ud985\udd8d\ud95b\udf54\udb96\udc20\udb9d\udf70\ud80d\udd92\ud989\udf39\ud9a9\udeae\ud83d\ude6f\ud82c\ude9b\ud955\udfe1\udb55\ude55\ud88c\udd92\ud955\udf3d\ud80a\udff9\ud8ff\ude1f\uda1d\udc66\uda22\udcc4\ud81e\uddcd\ud968\ude29\ud8d0\uddbd\udbb7\udff0\udb07\udfb1\ubd4e\ud82d\udc64\ud8c2\udcdb\udade\udd97\udb64\udff1\udb0d\ude0c\uda7f\uddaf\ud9e5\udd4f\ud8b0\udfbb\udb26\udd7e\ud915\udcce\ud850\uddbb\udaab\udcf3\udaef\udcd9\ud97f\udd64\udbf0\ude0f\ud81f\udd53\uda9c\udefd\ud9b5\udddb\udb43\udf5b\ud9e0\udd47\ud869\udde6\ud961\udff7\udba8\udf3a\udade\udcdf\uda19\udcfa",
        -1, 9418, 912435243, -2302421928243749210L, 41634L, true, false, (char) 49027, (char) 8002,
        Double.longBitsToDouble(0x3fe611e412be0b58L), Double.longBitsToDouble(0x3fe38e0c0423d3e8L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 10, "\ud905\udefd\ud970\udec6\uda30\ude3c", "\u5ec1", "\uda6a\udce2\ud954\udf7e\udbfe\udc9a\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud91f\udce9\uda75\udeed\uda8e\ude52\ud936\udc69\ud920\udd42\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99\udb7f\udf4b\udaf1\udd10\ud94a\udc34",
        42, 52567, 1481954062, -2985448135944318613L, 14103L, true, true, (char) 4944, (char) 43620,
        Double.longBitsToDouble(0x3fe9f73f7f5b268bL), Double.longBitsToDouble(0x3fcc99aeea0640b4L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 1, 1, 3, "\ud905\udefd\ud970\udec6", "\u0db3\u5ec1\u5fe4\ua464", "\ud9a4\udda4\ud9b8\uddb6\ud88f\uddae\ud950\ude49\ud9d5\udc83\udb10\udef7\ud8b0\udf24\ud936\udc69\ud920\udd42\ud9a7\ude57\udbe1\udc4c\uda02\udc65\udbc9\udc22\uda15\udf8c\ud834\udd48\ud8c0\udf55\uda36\udfcc\udb6b\udf94\u8de8\udb0b\udeb5\ud958\udea6\ud978\uddb4\udbc0\ude9b\uda8e\udeab\ud9d2\udfe0\ud9f4\ude24\ud93c\udd6f\ud93b\udf5f\udae7\ude66\ud8b0\ude8b\ud868\udcd8\udba0\udd73\udaa2\udd86\uda2c\udc75\uda78\uddf6",
        21, 63241, 730575678, -3641363257899238172L, -46520L, true, false, (char) 23570, (char) 18965,
        Double.longBitsToDouble(0x3fd2b6503a5bebf0L), Double.longBitsToDouble(0x3fbebf1286f7e660L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 1, 1, 10, "\ud905\udefd\ud8a1\udd5e\ud945\udd25\ud972\udcaf\ud8c1\ude3b\udbbd\uddf9\ud8e3\ude0d\ud931\udff7\uda6a\udce2\ud954\udf7e\ud86b\ude90\udaf7\udeac\uda07\uddfc\udae2\udc3e\ud922\udf74\uda75\udeed\uda8e\ude52\ud936\udc69\udbe8\udd46\udae6\udc77\udbe1\udcb3\ud9d1\ude4d\udbc9\udc66\udb38\udd7d\ud9ad\udf3a\ud8c0\udefb\uda36\udfcc\udb4b\udd84\ud8ba\uddb1\udb1c\udef8\ud958\udea6\ud978\uddb4\ud845\uddb9\udb42\udf99", "\u23f9", "\ud986\udea0",
        4, 55745, 1899949671, -8276867423501573467L, -36249L, true, false, (char) 35406, (char) 26844,
        Double.longBitsToDouble(0x3feeeecf9e20df2cL), Double.longBitsToDouble(0x3fefc46f87ef7d80L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.String:R000 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6)\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69w\000\ud984\udf01\ud9d1\ude4d\udb2d\udc76\udb38\udd7d\uda91\udf47", "\000", "",
        52, 90912, -956301298, -8469165852602491032L, -100000L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3f4ca38000000000L), Double.longBitsToDouble(0x3e0dc00000000000L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6)\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\udbea\ude08\udb3a\udcaf\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69w\000\ud984\udf01\ud9d1\ude4d\udb2d\udc76\udb38\udd7d\uda91\udf47", "\u74e4", "\ud92c\uddf6\uda00\ude78",
        17, 41663, 1405263720, 8791026472627208192L, -100000L, false, false, (char) 58652, (char) 0,
        Double.longBitsToDouble(0x3e0dc00000000000L), Double.longBitsToDouble(0x3fee927b7b813bf7L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.String:R000 |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 8, "\ud905\udefd\ud970\ude39)\000\udb42\uddac\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\ud970\ude7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud916\udfb4w\000\ud984\udf01\ud9d1\ude4d\udb2d\udc76\ud96c\ude66\ud84f\udf46", "\000", "",
        23, 90912, -956301298, -8469165852602491032L, -100000L, false, true, (char) 43432, (char) 19456,
        Double.longBitsToDouble(0x3fcfcc9a43380000L), Double.longBitsToDouble(0x3e0dc00000000000L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.String:R100 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6)\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69\uda3b\uddd3v\ud984\udf01\ud9d1\ude4d\udb2d\udc76\udb38\udd7d\uda91\udf47", "\000", "",
        52, 90912, -956301298, -8469165852602491032L, -100000L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3f4ca38000000000L), Double.longBitsToDouble(0x3e4ce26d84000000L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.String:R000 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6\ud917\udfe8r\ud8c1\ude2c\ud836\udeb6\udbb7\udf6a\ud931\udff7\udbd5\udc58\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69w\000\ud984\udf01\ud9d1\ude4d\udb2d\udc76\udb38\udd7d\uda91\udf47", "6", "",
        52, 90912, -956301298, -8469165852602491032L, -100000L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3fc79ca380000000L), Double.longBitsToDouble(0x3e0dc00000000000L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:3 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 1, 1, 8, "\ud905\udefd\ud98f\udd9f)\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud933\udc5b\udbd5\udc58\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69w\000\ud984\udf01\ud9d1\ude4d\udb2d\udc76\udb38\udd7d\uda91\udf47", "h", "\ud92c\uddf6\uda00\ude78\udb3f\udc8d\ud99a\udd4c\uda89\udc57\000\000\ud987\udecd\000\ud915\ude6a\000\uda91\udec0\udab3\udd4e\ud9d2\udcdf",
        36, 21823, -2025511685, -5425538191092524021L, -1388L, false, true, (char) 7439, (char) 38194,
        Double.longBitsToDouble(0x3fe93b78ae2d4a08L), Double.longBitsToDouble(0x3f771cd0e9726080L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String:T600 |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 8, "\ud905\udefd\ud8aa\udf92t\000\udb42\uddac\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\ud970\ude7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud916\udfb4w\000\ud984\udf01\ud9d1\ude4d\udb2d\udc76\ud96c\ude66\ud84f\udf46", "\000", "",
        23, 90912, -956301298, -8469165852602491032L, -100000L, false, true, (char) 43432, (char) 19456,
        Double.longBitsToDouble(0x3fcfcc9a43380000L), Double.longBitsToDouble(0x3e0dc00000000000L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.String:R100 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6)\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\000\000\udb67\udf01\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69wv\ud984\udf01\ud9d1\ude4d\udb2d\udc76\ud94b\uddc7\000", "\000", "",
        52, 90912, -956301298, -8469165852602491032L, -100000L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3f4ca38000000000L), Double.longBitsToDouble(0x3e4ce26d84000000L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.String:H610 |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 8, "\ud82f\udef8\uda7a\udceah\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udcf7\ud81d\udee1\uda8e\ude52\ud936\udc69\uda3b\uddd3v\ud984\udf01\ud9d1\ude4d\udb2d\udc76", "\uca34\000\000\u4001\u3937\u5692\u731b\u534c\ud07a\u8f61\u19c8\u3fb7\u258f\000\u0821", "",
        16, 87496, -1911013810, -367998975411404567L, 18614L, false, true, (char) 56531, (char) 10725,
        Double.longBitsToDouble(0x3fc171a2f911b680L), Double.longBitsToDouble(0x3fcef2cc8f34e2dcL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:R000 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:3 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6\ud89a\ude95\000\udaaf\ude23\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\udd5dR\ud90c\udc4f\ud81d\udee1\ud8cc\udc61\udbcf\udc41\uda74\udc24\ud892\udc7e\ud984\udf01\ud8d8\udc30\ud9c3\udf88\udb4d\udeb5\uda91\udf47", "s", "\ud8e0\udff4",
        14, 12518, -1971881369, 6035561721316245504L, -45756L, false, false, (char) 0, (char) 58652,
        Double.longBitsToDouble(0x3d91a00000000000L), Double.longBitsToDouble(0x3fe9c4db0f2e35b9L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:R100 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6)\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69\uda3b\uddd3v\ud984\udf01f\udb2d\udc76\udb38\udd7d\uda91\udf47", "\000", "",
        52, 90912, -956301298, -8469165852602491032L, -100000L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3f4ca38000000000L), Double.longBitsToDouble(0x3e4ce26d84000000L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6)\ud863\udca3\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7Y\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69\uda3b\uddd3v\ud984\udf01\ud9d1\ude4d\udb2d\udc76\udb38\udd7d\uda91\udf47", "\u4f68", "\ud92c\uddf6\uda00\ude78\ud809\udcb2",
        -2, 49720, 0, -1448553500L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe9c4db08ae8684L), Double.longBitsToDouble(0x3fecfb3848de02beL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6\ud917\udfe8r\ud8c1\ude2c\ud836\udeb6\udbb7\udf6a\ud931\udff7\udbd5\udc58\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\u4f78\ud832\udc24y\ud984\udf01\ud9d1\ude4d\udb2d\udc76\udb38\udd7d\uda91\udf47", "6", "",
        52, 90912, 285212686, -8469166234854580376L, -100000L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3fc79ca380000000L), Double.longBitsToDouble(0x3e0dc00000000000L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Integer:2 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:2 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 1, 1, 8, "\ud905\udefd\udaed\udee5k\000\ud8c1\ude2c\u0091\udb6a\ude75\ud933\udc5b\udbd5\udc58\ud954\udf7e\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69w\000\ud984\udf01\ud9d1\ude4d\udb2d\udc76\udb38\udd7d\uda91\udf47", "h", "\ud92c\uddf6\uda00\ude78\udb3f\udc8d\ud99a\udd4c\uda89\udc57\000\ud8af\udd33\ud987\udecd\000\ud915\ude6a\000\uda91\udec0\udab3\udd4e\ud9d2\udcdf",
        36, 21823, -2025511685, -5425538191092524021L, -1388L, false, true, (char) 7439, (char) 38194,
        Double.longBitsToDouble(0x3fe93b78ae2d4a08L), Double.longBitsToDouble(0x3f771cd0e9726080L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 4, "\ud905\udefd\ud98f\udd9f)\000\ud8c1\ude2c\u0091\000\ud933\udc5b\udbd5\udc58\udb8c\udf7a\udbfe\udc9a\udb67\udf6d\ud88f\uddaeR\ud8e7\uded3\ud81d\udee1\uda8e\ude52\ud929\udf69w\000\ud984\udf01f\000\udb38\udcb7\uda66\udff2", "\000", "",
        52, 90912, -996605938, -8456704331410661528L, -100000L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3f4ca38c00000000L), Double.longBitsToDouble(0x3fe5a9fd68772c1fL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:P000 |this=org.apache.commons.codec.language.Soundex:@?\0121=[C:[[0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2]] |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 5, 5, "\ud905\udefd\ud970\udec6)\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\000\000\ud83a\udc8a\udb9a\ude98p\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69wv\ud984\udf01\ud9d1\ude4d\udb2d\udc76\ud94b\uddc7\000", "\000", "\ud92c\uddf6",
        42, 66702, -1971881337, 6043443019003199488L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe9c4db0f27f67eL), Double.longBitsToDouble(0x3fdbfcd28eae3434L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String:W610 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:1 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6\uda3d\udc35\ud8e6\udf0a\udba8\udcbc\udaef\udf42\ud85d\ude0e\ud931\udff7\udbd5\udc58\udbfc\ude3dw\udb67\udf01\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud935\udfd5wv\ud984\udf01\ud9d1\ude4d\udb2d\udc76\ud94b\uddc7\000", "\u00df", "",
        52, 41968, 718890282, -8469165852602490912L, -99056L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3f4ca38000000000L), Double.longBitsToDouble(0x3fed1d1807f6b1c2L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.String:R140 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6)\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7\udbd5\udc58\000\000\udb67\udf01\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69wv\ud984\udf01\ud9d1\ude4d\udb2d\udc76\udab9\udf5el", "\000", "",
        52, 90912, -956301298, -8469165852602491032L, -100000L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3f4ca3869a040000L), Double.longBitsToDouble(0x3e4ce26d84000000L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 8, 10, "\ud905\udefd\ud970\udec6\udbc4\ude46\ud972\udd12\u181e\u0d78\ud8e3\ude0d\ud92b\udec3\ud980\udff5\ud930\ude8c", "\u0b64\ud736\uc6a5\u0636\u18c9\u620a\ud3fd\ubfd9\uaf3a\ub806", "\ud9ad\udf3a",
        5, 3253, 371721941, 1824524323310304607L, 67545L, true, false, (char) 19017, (char) 25760,
        Double.longBitsToDouble(0x3fbeecc50dbf9518L), Double.longBitsToDouble(0x3fe873621ebd5854L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:R000 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\ude22\ud970\udec6\ud917\udfe8r\ud8c1\ude2c\ud836\udeb6\udbb7\udf6a\ud931\udff7\udbd5\udc58\ud9ea\udd08\udbfe\udc9a\udb67\udf6d\ud9c6\uddcaR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69w\000\000\000\000\ud9ae\udfb6U", "", "\000",
        52, 90912, -956301298, -8469165852602491032L, -100000L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3fc79ca380000000L), Double.longBitsToDouble(0x3e0dc00000000000L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 7, 1, 8, "\ud905\udefd\ud96c\udfc6\ud957\udc54\udbfd\udf75\ud9e1\udeb7\uda18\ude3f\ud86c\udfae\ud931\udff7\udbd5\udc58\000\000\udb67\udf01\ud88f\uddaeH\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69wv\ud984\udf01\ud9d1\ude4d\udb2d\udc76\ud94b\udd52\000", "\000", "",
        52, 90912, -956301298, -8469165852602491032L, 94842L, false, true, (char) 51763, (char) 43021,
        Double.longBitsToDouble(0x3f4ca38000000000L), Double.longBitsToDouble(0x3e4ce26d84000000L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.String:W100 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:2 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 0, "\ud905\udefd\ud970\udec6\uda3d\udc35\ud8e6\udf0a\udba8\udcbc\udaef\udf42\ud85d\ude0e\ud931\udff7\udbd5\udc58\udbfc\ude3dw\000\ud88f\uddae\000\000\ud81d\ude20\uda8e\ude52\ud935\udfd5wv\ud984\udf01\ud9d1\ude4d\udb2d\udc76\ud94b\uddc7\000", "\u00df", "",
        52, 41968, 718890282, -8469165852602490912L, -99056L, false, true, (char) 43432, (char) 0,
        Double.longBitsToDouble(0x3f4ca38000000000L), Double.longBitsToDouble(0x3fed1d180700b1c2L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:H100 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 8, 1, 8, "\ud905\ude76\ud96c\udfc6\ud957\udc54\udbfd\udf75\ud9e1\udeb7\uda18\ude3f\ud86c\udfae\ud931\udff7\udbd5\udc58\000\000\udb67\udf01\ud88f\uddaeH\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud936\udc69wv\ud984\udf01\ud9d1\ude4d\udb2d\udc76\ud94b\udd52\000", "\000", "",
        52, 90912, -956301298, -8469165852602491032L, 36891L, false, true, (char) 51763, (char) 43021,
        Double.longBitsToDouble(0x3f4ca38000000000L), Double.longBitsToDouble(0x3e4ce26d84000000L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String:S610 |this=org.apache.commons.codec.language.Soundex:@?\0121=java.lang.Integer:0 |this=org.apache.commons.codec.language.Soundex:@?\012",
        Z.run(T, 2, 3, 1, 8, "\ud905\udefd\ud970\udec6)\000\ud8c1\ude2c\u0091\ud85d\ude0e\ud931\udff7\ud87d\udd2c\ud9f0\uddeb\u00df\udb67\udf01\ud88f\uddaeR\ud91f\udce9\ud81d\udee1\uda8e\ude52\ud8ad\udfa5wv\ud984\udf01\ud9d1\ude4d\udb2d\udc76\ud94b\uddc7\000", "\u00a2\000\000", "\ud809\udcb2\udb42\udf99\uda89\udc57\000\000",
        30, -1000, -451149824, 0L, 47656L, false, false, (char) 58834, (char) 19823,
        Double.longBitsToDouble(0x3feebedc41491a2cL), Double.longBitsToDouble(0x3feb66b1e72fb79aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.codec.language.Soundex|getMappingCode|java.lang.String,int|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|difference|java.lang.String,java.lang.String|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|encode|java.lang.Object|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|encode|java.lang.String|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|getMaxLength||new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|getSoundexMapping||new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|map|char|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|setMaxLength|int|new:org.apache.commons.codec.language.Soundex:",
    "M|org.apache.commons.codec.language.Soundex|soundex|java.lang.String|new:org.apache.commons.codec.language.Soundex:",
    "C|org.apache.commons.codec.language.Soundex|<init>|java.lang.String",
    "C|org.apache.commons.codec.language.Soundex|<init>|[C",
    "C|org.apache.commons.codec.language.Soundex|<init>|",
    "M|org.apache.commons.codec.language.Soundex|getMappingCode|java.lang.String,int|new:org.apache.commons.codec.language.Soundex:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
