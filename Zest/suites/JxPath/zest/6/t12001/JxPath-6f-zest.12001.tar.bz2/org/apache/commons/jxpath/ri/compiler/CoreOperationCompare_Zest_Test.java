package org.apache.commons.jxpath.ri.compiler;
import org.junit.Test;
import static org.junit.Assert.*;
public class CoreOperationCompare_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 0, "\uda43\udc11\udb71\udf22\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud94d\udcfc\ud8a7\ude1d\ud981\udde1\ud96f\udec2\uda21\udda9\ud9fb\udf6e\ud856\udf79\uda1a\udde2\ud999\udc2b\ud93c\udd0a\ud812\uddaa\udb6c\udde7\uda34\udce4\uda5e\udc4e\udbd0\udec5\udb1b\udc59\ud84e\udf48\ud9f4\udfe1", "\u4f66\ua2af", "\udbf0\udc07\uda2b\udfa4\ud975\ude8a\udb82\udc7b\udbc1\udcb0\ud95b\udcfe\udb91\ude55\ud9dc\ude45\udabd\udeb2\uda7f\ude03\udacc\udf21\udb49\udd6b\ud828\udfaa\udbe6\udc5b",
        52, 35339, 99846305, -5022372406840640904L, -31117L, false, false, (char) 29516, (char) 37634,
        Double.longBitsToDouble(0x3fe9a87a0571b55eL), Double.longBitsToDouble(0x3fe132eed3592147L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\uda43\udc11\udb71\udf22\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud94d\udcfc\ud8a7\ude1d\ud981\udde1\ud96f\udec2\uda21\udda9\ud9fb\udf6e\ud856\udf79\uda1a\udde2\ud999\udc2b\ud93c\udd0a", "\ua859\u778c\u61de\u1270", "\udb35\udc5b\ud84d\udda0\ud846\udea6\ud937\ude0b\ud8f0\udd33\uda47\udcbb\udbf0\udc07\uda2b\udfa4\ud975\ude8a\udb82\udc7b\udbc1\udcb0\ud95b\udcfe\udb91\ude55",
        54, 66441, 111924639, -8856563550534758935L, -37816L, false, false, (char) 41359, (char) 50445,
        Double.longBitsToDouble(0x3fe4d1df7630751cL), Double.longBitsToDouble(0x3fd010602e6a1e80L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 3, "\uda43\udc11\u00a1\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud94d\udcfc\ud8a7\ude1d\ud981\udde1\ud96f\udec2\uda21\udda9\ud9fb\udf6e\ud856\udf79\uda1a\udde2\ud999\udc2b\ud93c\udd0a\ud812\uddaa\udb6c\udde7\uda34\udce4\u00be\000\000\uda74\ude79\ud9f4\udfe1", "\u45a1\u2a6c", "\udbf0\udc07\uda2b\udfa4\ud975\ude8a",
        39, 82362, -583414005, -1552774734509991797L, -63515L, true, false, (char) 63706, (char) 62660,
        Double.longBitsToDouble(0x3fd05d88a5dba440L), Double.longBitsToDouble(0x3fe4d1df7630751cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 0, "\uda43\udc11\udb71\udf22\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud94d\udcfc\ud8a7\ude1d\ud981\udde1\udbb2\udfbb\uda21\udda9\ud9fb\udf6e\ud856\udf79\uda1a\udde2\ud999\udc2b\udb6c\ude83\ud812\udde8\udb6c\udda9\uda34\udce4\uda5e\udc4e\uda38\ude78\udac2\udd96\ud822\udd6c\uda73\udd60", "\u4f66\ua2af", "\udbf0\udc07\uda2b\udfa4\ud975\ude8a\udb82\udc7b\udba9\udfb0\ud95b\udcfe\udb91\ude55\udabe\udf17\udab7\uddc1\uda7f\ude03\udacc\udf21\udb49\udd6b\ud828\udfaa\udbe6\udc5b",
        52, 87643, 99846305, -5022372406840640904L, 96144L, true, true, (char) 61591, (char) 41269,
        Double.longBitsToDouble(0x3fe132eed3592147L), Double.longBitsToDouble(0x3fee02be5b2a801aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 4, 0, "\udbe5\udd02\udb71\udf22\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud89c\udff7\ud8a7\ude1d\uda41\udc20\ud96f\udf96\uda21\udda9\ud9fb\udf6e\ud856\udf79\ud85e\udc23\ud9b9\ude16\udb0e\udf34\ud8db\ude05\udb6c\udde7\uda34\udce4\uda5e\udc4e\udbd0\udec5\udb1b\udc59\ud84e\udf48\ud9f4\udfe1", "\ub4e2\ua2af", "\udbf0\udc07\uda2b\udfa4\udb4b\udf2f\ud95f\udcc0\udba6\ude9a\ud912\udd43\uda33\udc58\ud9d7\udda3\udabd\udeb2\uda7f\ude03\udacc\udf21\udb49\udd6b\ud828\udfaa\udbe6\udc5b",
        52, 85755, 99846305, 5786266698647222794L, 2927L, false, false, (char) 29516, (char) 37634,
        Double.longBitsToDouble(0x3fe9a87a0571b55eL), Double.longBitsToDouble(0x3fe132eed3592147L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 1, 0, "\uda43\udc11\udb71\udf22\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud94d\udcfc\ud8a7\ude1d\ud981\udde1\ud96f\udec2\uda21\udda9\ud9fb\udf6e\ud856\udf79\uda1a\udde2\ud999\udc2b\ud93c\udd0a\ud812\uddaa\udb6c\udde7\uda34\udce4\uda5e\udc4e\udbd0\udec5\udb1b\udc59\ud84e\udf48\uda32\uddab", "\u4f66\u5e89", "\udbf0\udc07\uda2b\udfa4\ud975\ude8a\udb82\udc7b\udbc1\udcb0\ud95b\udde3\udb91\ude55\ud9dc\ude45\udabd\udeb2\uda7f\ude03\udacc\udf21\udb49\udd6b\ud828\udfaa\ud85b\ude47",
        53, 26675, 99846299, -5022372406840640904L, -31117L, false, true, (char) 29516, (char) 37634,
        Double.longBitsToDouble(0x3fe9a87a0494b95eL), Double.longBitsToDouble(0x3fece1f33b590891L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 0, "\uda5a\udcc6\udb71\udf22\ud89b\udd18\ud905\udc8a\ud880\udebf\uda18\udc99\udad1\udd41\ud8eb\udda7\ud953\ude06\ud96f\udec2\uda21\udda9\ud9fb\udf6e\ud8a1\udc53\ud87e\udc9f\ud97b\udeaf\ud93c\udc46\udb51\udf37\udb6c\udde7\udb2c\udd1a\ud989\udde3\ud882\udf1a\udbbc\udeeb\udbbd\uddb1\ud9f5\udc2d", "\u4f66\ua2af", "\ud836\udf57\uda58\udc66\ud975\ude8a\ud80b\udd80\ud957\udfad\udb63\udc6a",
        29, 10339, 838165441, 480712662059526752L, 30378L, false, false, (char) 23314, (char) 21801,
        Double.longBitsToDouble(0x3fe34eb26ae805faL), Double.longBitsToDouble(0x3fe3c5d26105d88aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 0, "\uda43\udc11\udb71\udf22\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud94d\udcfc\ud8a7\ude1d\u35c7\ud96f\udec2\uda21\udda9\ud9fb\udf6e\ud856\udf79\uda1a\udde2\ud999\udc2b\ud93c\udd0a\ud812\uddaa\udb6c\udde7\uda34\udce4\ud843\uddc2\uda94\ude13\udb1b\udc59\ud955\ude2b\ud9f5\udc00", "\u4f66\ua2af", "\udbf0\udc07\uda2b\udfa4\ud975\ude8a\udb82\udc7b\udbc1\udcb0\ud95b\udcfe\udb91\ude55\ud9dc\ude45\udabd\udeb2\uda7f\ude03\udacc\udf21",
        57, 4734, -687281466, -8880390338775912069L, -37816L, false, false, (char) 41359, (char) 50445,
        Double.longBitsToDouble(0x3fe4d1df7630751cL), Double.longBitsToDouble(0x3fd0106029906f38L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 4, 3, "\ub272,\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud8f6\udd2f", "\u5e23\u98d6\u0437\ua2fd\ua316\u9541\ub3e4\u52f0", "\u00be\ud936\ude1b\uda1d\udfa4\uda74\ude79\ud9f4\udfe1\uda11\udc5c\uda98\udd65\ud874\udd79\udbef\ude07\ud9b4\udcc6\uda50\udffd\udbf0\udc07\uda2b\udfa4",
        -1, 49869, -1480406358, -2505744072787660901L, -8927L, true, true, (char) 12555, (char) 51718,
        Double.longBitsToDouble(0x3ec6831a21b80000L), Double.longBitsToDouble(0x3e27b84c20000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 1, "", "\000\000\000\u592f\u3bd3", "\ud96f\udec2\udaef\ude9a\ud9fb\udf6e\u68fc\ud9fa\udd5d\ud999\udc2b\ud93c\udd0a\u8811\udb6c\udde7\uda34\udce4\000",
        -5, -1000, 0, 1214978072L, -100000L, false, false, (char) 16640, (char) 47869,
        Double.longBitsToDouble(0x3fd2224d3000005cL), Double.longBitsToDouble(0x3fdc1df07a4b0b32L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 4, "\uda43\udc11\udb71\udf22\ud8a7\udf07\ud905\udc8a\uda4b\ude17\ud8b5\udc5c\udb43\udd88\ue3b6\ud823\udce7\ud8b8\ude5d\ud8a8\ude0a\ud9fb\udf9d\ud856\udf79\uda1a\udde2\ud8f5\udc39\uda70\udf61\ud812\uddef\udb6c\udda9\uda34\udce4\uda5e\udc4e\uda4c\ude8f\ud976\udef3\udbdc\udc23\udb47\ude8a", "\u4f66\ua2af", "\udbf0\udc07\uda2b\udfa4\ud975\ude8a\udb82\udc7b\udba9\udfb0\uda4c\udcd9\udb91\uddf1\udabe\udf17\udab7\uddc1\uda7f\ude03\uda15\udc25\udb49\udd6b\ud828\udfaa\udbe6\udc5b",
        -5, 11953, -47697267, -5022372406840640904L, 96144L, true, true, (char) 61591, (char) 43156,
        Double.longBitsToDouble(0x3fdf7f4f06b24228L), Double.longBitsToDouble(0x3fee02be5e2a801aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 4, 0, "\udbe5\udd02\udb71\udf22\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud89c\udff7\ud8a7\ude1d\uda41\udc20\ud96f\udf96\uda21\udda9\ud96d\ude26\000\ud96d\udf96\ud9b9\ude16\udb0e\ude3e\ud8db\ude05\udb6c\udde7\uda34\udce4\uda5e\udc4e\udbd0\udec5,\ud84e\ude87\ud9f4\udfe1", "\ub4e2\ua2af", "\udbf0\udc07\uda2b\udfa4\udb4b\udf2f\uda01\udcb1\udbc2\ude00\ud912\udd43\uda33\udc58\ud9d7\udda3\udabd\udeb2\uda7f\ude03\udacc\udf21\udb49\udd6b\u02b6\udbe6\udc5b",
        52, 85755, 99846305, 5786266699510579210L, 2927L, false, false, (char) 29516, (char) 37634,
        Double.longBitsToDouble(0x3fe9a87a0571b55eL), Double.longBitsToDouble(0x3fe132eed3592147L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 4, 0, "", "", "\ud880\udebf\udb2e\udf2b\ud89c\udff7\ud8a7\ude1d\uda41\udc20\ud96f\udf96\u4f23\ud9d8\udd4c\ud856\udf79\ud85e\udc23\ud9b9\ude16\u45f6\ud923\udcd1\udb6c\udde7\uda34\udce4\uda5e\udc4e\ud9d3\udfe6\000\000\000\uda11\udc5c\ud837\udd95\ud86e\udce9\ud937\ude0b\u0096\000",
        44, 1366, 976206786, -6990648233938296684L, -13846L, false, false, (char) 49318, (char) 1940,
        Double.longBitsToDouble(0x3fe300355de98517L), Double.longBitsToDouble(0x3fe5b7bda2c6886eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 2, "\uda43\udc11\udb71\udf22\udbea\udca8\udbf7\udcca\uda70\udf7e\ud85f\udcc3\uda1b\ude62\ud948\udebf\ud981\ude08\ud96f\udec2\uda21\udda9\ud9fb\udf6e\ud856\udf79\uda1a\udde2\ud9c0\udf51\ud93c\udd0a\ud812\uddaa\udb6c\udde7\uda34\udce4\uc333\udaea\ude92\udb1b\udc59\ud84e\udf48\uda32\uddab", "\u35b5\u48de", "\udbf0\udc07\uda2b\udfa4\ud975\ude8a\ud87d\ude62\u4186\ud95b\udde3\udb91\ude55\ud9dc\ude45\udaa5\udefd\ud8ad\ude41\udacc\udf21\udb49\udd6b\ud97a\udd52\ud85b\ude0a",
        53, 26675, 99846299, -8018955008902284745L, -31117L, false, false, (char) 36005, (char) 8758,
        Double.longBitsToDouble(0x3fe9a87dfb03bc5eL), Double.longBitsToDouble(0x3fdfec48c6b21122L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 1, "\uda5a\udcc6\udb71\udf22\ud89b\udd18\udac5\udc2e\udbfa\udeb3\uda18\udc99\udad1\udd41\ud9f9\ude91\ud979\udce9\ud991\uddd1\udbce\ude9e\ud9fb\udf50\ud98b\udf80\udabb\udc88\ud8d5\udecd\u3eab\udae1\udeaa\udb6c\udd24\udb2c\udd1a\ud989\udde3\ud882\udf1a\uda45\udc77\ud987\udf55\ud9f5\udc2d", "\ua59f\ua2a6", "\ud836\udf57\ud94f\udd93\ud975\ude8a\ud80b\udd80\ud957\udfad\udb63\udc6a",
        29, 12195, 838178554, 480712662059526752L, 30378L, false, false, (char) 23314, (char) 21801,
        Double.longBitsToDouble(0x3fe8bc826d1705faL), Double.longBitsToDouble(0x3fe52c742a05d88aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 0, "", "", "\ud880\udebf\udb2e\udf2b\ud89c\udff7\ud8a7\ude1d\uda41\udc20\ud96f\udf96\u4f23\ud95c\udd4d\ud856\udf1e\ud85e\udc23\ud9b9\ude16\u45f6\ud923\udcd1\udb6c\udde7\uda34\udce4\uda5e\udc4e\ud9d3\udfe6\000\000\000\uda11\udc5c\ud837\udd95\ud86e\udce9\ud937\ude0b\u0096\000",
        44, 1366, 976206786, -7013831638473416556L, -13846L, false, false, (char) 49318, (char) 1940,
        Double.longBitsToDouble(0x3fe300355de985f0L), Double.longBitsToDouble(0x3fe5b7bda2c6886eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 0, "\uda43\udc11\udb71\udf22\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud89a\udf83\ud8a7\uddeb\ud981\ude5f\ud96f\udec2\uda21\udda9\ud9fb\udf6e\ud856\udf79\uda1a\udde2\ud999\udc2b\ud93c\udd0a\ud812\uddaa\udb6c\udde7\uda34\udce4\uda5e\udc4e\udbd0\udec5\ud8a3\uddde\ud9be\udc8e\ud9f5\udc9a", "\u4f66\ua2af", "\udbf0\udc07\uda2b\udfa4\ud975\ude8a\udb7c\udfaa",
        3, 8442, -361533526, 2113481848749646785L, 30378L, false, false, (char) 9971, (char) 63037,
        Double.longBitsToDouble(0x3fc430ce6ba017ccL), Double.longBitsToDouble(0x3fe3c5d26105d88aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 0, "", "", "\ud880\udebf\udb2e\udf2b\ud89c\udff7\ud8a7\ude1d\uda41\udc20\ud96f\udf96\u4f23\ud95c\udd4d\ud856\udf1e\ud85e\udc23\ud9b9\ude16\u45f6\ud923\udcd1\udb6c\udde7\uda34\udce4\uda5e\udc4e\ud9d3\udfe6\000\000\000\uda11\udc5c\ud837\udd95\ud86e\udce9\ud937\ude0b\u0096\000",
        44, 1366, 976206786, -7013831638473416556L, -13846L, true, false, (char) 49318, (char) 1940,
        Double.longBitsToDouble(0x3fe300355de985f0L), Double.longBitsToDouble(0x3fe5b7bda2c6886eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 3, "\ub272,\ud8a7\udf07\ud905\udc8a\ud880\udebf\udb2e\udf2b\ud8f6\udd2f", "\u5e23\u98d6\u5be6\ua2fd\ua316\u4fdf\ub2f1\u52f0", "\u00be\udb16\udf4b\uda1d\udf84\uda74\ude79\ud9f4\udfe1\uda11\udc5c\uda98\udd65\ud874\udd79\udbef\ude07\udbb5\udcd8\udbfa\uded2\udbf0\udc07\uda2b\udfa4",
        -1, 49869, -1480406358, -2505744072787660901L, -8927L, true, true, (char) 12555, (char) 48149,
        Double.longBitsToDouble(0x3fe113f5d0c6886cL), Double.longBitsToDouble(0x3e27b84c20000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|equal|java.lang.Object,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|equal|org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|contains|java.util.Iterator,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|findMatch|java.util.Iterator,java.util.Iterator|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|equal|java.lang.Object,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|equal|org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
