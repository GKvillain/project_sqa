package org.apache.commons.jxpath.ri.model.dom;
import org.junit.Test;
import static org.junit.Assert.*;
public class DOMNodePointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 13, 16, "\uda62\udcf1\udb22\udc51\ud9b1\udebe\ud928\udc01", "\u35f4\u6b9b\u69c2\u3b09\u799a\u3aff\u5470\u48a0\u3fb6\u34d6", "\ud920\udeff\ud876\udd93\ud977\udc14\ud9b0\udebf\ud863\udcc9\udad0\udf10\udab2\ude16\udbee\udffa\udbda\udcfe\udbdb\uddf7",
        2, 49915, -1187432077, -8938287285399434168L, 41741L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fe3d992dcac252dL), Double.longBitsToDouble(0x3fe995b810479e51L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 13, 16, "\uda62\udcf1\udb22\udc51\ud9b1\udebe\ud928\udc01", "\u35f4\u6b9b\u69c2\ub1f1\u799a\u3aff\u5470\u48a0\u3fb6\u34d6", "\ud920\udeff\ud876\udd93\ud977\udc14\ud9b0\udebf\ud863\udcc9\udad0\udf10\udab2\ude16\udbee\udffa\udbda\udcfe\udbdb\uddf7",
        2, 49915, -1187432077, -8938287285399434168L, 41741L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fe3d992dcac252dL), Double.longBitsToDouble(0x3fe995b810479e51L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 16, "\uda3d\udf2d\ud89a\ude4c\ud950\udd20\ud928\udc30", "\u35a2\u6b9b\u69c2\u3b09\u799a\u3aff\u5470\u48a0\u3fb6\u34d6", "\uda5e\ude15\ud969\udc0c\ud92a\udddd\udb87\udd87\ud93c\udc34\ud953\udf50\ud823\udf4a\ud85a\udd61\udbda\udd48\udbdb\uddf7",
        26, 49915, -1187432077, 7835369526741978184L, 41686L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fe3d992dcac252dL), Double.longBitsToDouble(0x3fe995b8116c9e51L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 6, 3, "\uda62\udcf1\udb22\udc51\ud9b1\udebe\u22c6", "\u59cf\u1323\u69c2\u3b09\u799a\u3aff\u5470\u48a0\u3fb6\u73ab", "\udba4\udeb5\ud88f\udee0\ud977\udc14\ud9b0\udebf\ud863\udcc9\udbdb\udc14\udab2\ude28\udbee\udffa\udbda\udcfe\udbdb\uddf7\ud852\udff2",
        20, 23923, -2081107182, 3269697199960036090L, -51211L, true, true, (char) 32543, (char) 11478,
        Double.longBitsToDouble(0x3fc584a5bccadc08L), Double.longBitsToDouble(0x3fb1e7945c227f90L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 13, 16, "\ud9b5\udf46\ud89b\ude1c\ud936\udec0\uda66\udfb0", "\u35f4\u6b9b", "\uda23\ude8e\ud918\udd5f\ud969\udf4c\udab7\udcd0\udbc5\udcd2\udb88\udd7b\ud920\udcc2\udbdf\udd69\udb55\udc46\ud876\ude85\ud977\udc14\ud9b0\udebf\ud863\udcc9",
        22, 91177, 1761490379, -4163562258481656075L, 53581L, true, false, (char) 51289, (char) 50931,
        Double.longBitsToDouble(0x3fe8169522ac2817L), Double.longBitsToDouble(0x3fed2e306af50ee6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 13, 16, "\uda62\udcf1\udb22\udc51\ud9b1\udebe\ud928\udc01", "\u35f4\u6b9b\u648d\u44a5\u799a\u3aff\u5470\u48a0\u3fb6\u34d6", "\ud920\udeff\udb15\udd84\ud977\udc14\ud9b0\udebf\ud863\udcc9\udad0\udf10\udab2\ude16\udbee\udffa\udbda\udcfe\udbdb\uddf7",
        2, 49915, -1187432077, -8938287285399434168L, -23795L, false, true, (char) 30781, (char) 32543,
        Double.longBitsToDouble(0x3fe3d992dcac252dL), Double.longBitsToDouble(0x3fe995b810479e51L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 13, 16, "\uda62\udcf1\udb22\udc51\ud884\udd47\udb20\udf38", "\u9214\ua775\u69c2\uae5c\u3a71", "\ud8c0\ude75\udbc5\udca2\ud9b6\udc27\uda90\udce9\ud943\udee3\ud920\udeff\ud876\udd93\ud977\udc14\ud9b0\udebf\ud863\udcc9",
        19, 75747, -131451445, -8788510156666548491L, -2555L, true, false, (char) 17229, (char) 18722,
        Double.longBitsToDouble(0x3fe54dd56a7b7604L), Double.longBitsToDouble(0x3fc584a5bccadc08L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 1, 4, 15, "\uda62\udcf1\udb22\udc51\ud9b1\udebe\ud928\udc01", "\u35f4\u6b9b\u69c2\u3b25\u799a\u3aff\u5470\u6846\u67a7\u7384", "\ud920\udeff\ud876\udd93\ud977\udc14\ud9b0\udebf\ud863\udcc9\udb83\udc89\udada\udd7f\udbee\udffa\udbda\udcfe\udbdb\uddf7",
        2, 49915, -1187432077, -8938287285399957688L, 41741L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fe3d8782cac252dL), Double.longBitsToDouble(0x3fe995b8119eeb51L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 9, 13, 16, "\uda62\udcf1\udb22\udc51\ud9b1\udebe\ud928\udc01", "\u35f4\u6b9b\u69c2\u3b09\u799a\u3aff\u5470\u48a0\u3fb6\u34d6", "\ud920\udeff\ud876\udd93\ud977\udc14\ud9b0\udebf\ud863\udcc9\udad0\udf10\udab2\ude16\udbee\udffa\udbda\udcfe\udbdb\uddf7",
        54, 49915, -1187432164, -8938287285399434168L, 44051L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fe3d992dcac252dL), Double.longBitsToDouble(0x3fe995b810479e51L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 12, 15, 10, "\uda62\udcf1\udb22\udc51\ud953\udeaf\ud94a\uddcd", "\u2807\u52ac\u69c2\u3b09\u799a\u3aff\uc353\u4839\u3fb6\u34d6", "\ud920\udeff\ud89c\udee1\ud977\udc14\ud9b0\udebf\ud863\udcc9\udb42\uddd7\uda5e\ude8f\udbee\udf9c\udbda\udcfe\udbdb\uddf7",
        2, 49915, -1187432077, -8938287287078533942L, 79234L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fdeb325b3584a5aL), Double.longBitsToDouble(0x3fe0ed1348479e51L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 1, "\uda62\udcf1\udb22\udc51\ud9b1\udebe\ud928\udc01\ud8a9\udcd7", "\u6b9b\ub277\u3b09\u799a\u3aff\u5470\u48a0\u3fb6\u346c\u6c4b\u56cb", "\ud98d\udc8b\ud9b0\udebf\ud863\udcc9",
        36, 19507, -135532028, -8788580437659817134L, -29606L, true, false, (char) 1823, (char) 30754,
        Double.longBitsToDouble(0x3fe770e18a7b325bL), Double.longBitsToDouble(0x3fea39296f32b702L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 16, "\uda62\udcf1\udb22\udc51\ud9e9\udc39\ud9b1\uddd1", "\u624b\u6b9b\u18df\u5c46\u7a1a\u3aff\u5470\u0e41\u3faa\u34d6", "\ud905\udf96\ud876\udd93\ud977\udc14\ud9b0\udebf\ud863\udcc9\udad0\udf10\udab2\ude16\udbee\udffa\ud9d1\udf07\udbdb\uddf7\ud852\udff2\ud8d0\udfdd\ud91e\udf78\uda55\udc8a",
        44, 60706, 126735955, -6027787098232075318L, 29659L, false, false, (char) 18092, (char) 55703,
        Double.longBitsToDouble(0x3fc392ed26160d2cL), Double.longBitsToDouble(0x3fa12e9b906e4890L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 11, 13, "\udac9\uded2\udab7\udcfe\uda7a\udf0b\udadb\udd70\udaec\udf50\uda6f\ude8f\ud82d\udda1\uda47\udc68\ud914\udc3e\uda56\udd95\udb04\udfe4\udab0\udfab\ud953\udfba", "\u34d6\ub8d9", "\ud975\uddfe\ud977\udc14\ud9b0\udebf\ud863\udcc9\udad0\udf10\udab2\ude16\udbee\udffa\udabd\udff6\udb52\udcab\udbd6\udc0d\ud9d0\udcd1\ud826\udedb\uda54\udfc2",
        44, 60706, 126735955, -6048616246508663862L, 29659L, false, false, (char) 17972, (char) 11928,
        Double.longBitsToDouble(0x3fe0559abf71908aL), Double.longBitsToDouble(0x3fd2d4cac1745c68L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 11, 10, "\uda62\udcf1\ud800\udf04\udad4\udf7e\ud928\udc3e", "\u35e5\u6b9b\u69c2\u3b09\uc0b6\uc69e\u18e1\u48a0\u3fb6\u34d6", "\ud8a7\uddec\ud876\udd93\ud977\udc14\ud9b0\udebf\ud863\udcc9\udad0\udf10\udab2\ude16\udbee\udffa\udb06\udf13\udb20\uddf1",
        2, 49915, -1187432077, -8938287285399434168L, 41741L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fe3d992dcac252dL), Double.longBitsToDouble(0x3fe995b810479e51L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\uda62\udc62\udb12\udefd\ud958\udde4\ud928\udc01 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 16, "\uda62\udc62\udb12\udefd\ud958\udde4\ud928\udc01", "\u35f4\u9f8a\u69c2\u3b09\uc25b", "\ud8c0\ude75\udbc5\udca2\ud9b6\udc27\ud88a\udce6\ud943\udee3\udb10\udd52\ud900\udf9f\udaea\ude1a\ud907\udd36\udbbd\udd02",
        36, 13675, -1584504673, -8764319693969666315L, -29778L, true, false, (char) 18463, (char) 4014,
        Double.longBitsToDouble(0x3fe770e18d7b325bL), Double.longBitsToDouble(0x3fc584a99ccadc08L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 9, "\ud9d2\udce9\udb22\udc51\ud9b1\udebe", "\u2d76", "\ud914\udc3e\uda59\ude95\udab4\udf20",
        6, 45581, 1283581427, -6968842863846561589L, -6485L, true, false, (char) 15638, (char) 55733,
        Double.longBitsToDouble(0x3fe77b13269bb449L), Double.longBitsToDouble(0x3fec27637483a077L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 9, 4, 16, "\uda62\udcf1\udb22\udc51\ud9b1\udebe\ud928\udc01", "\uad51\u4617\u69c2\ua8cd\u799a\u3aff\u5470\u48a0\u3fb6\u349b", "\ud920\udeff\ubef0\ud976\udff5\ud9b0\udebf\ud863\udcc9\udad0\udf10\udab2\ude16\udbee\udffa\udbda\udcfe\udbdb\uddf7",
        2, 49915, -1184024205, -8938287285399434168L, 41741L, true, false, (char) 40688, (char) 32543,
        Double.longBitsToDouble(0x3febd992dcac25e7L), Double.longBitsToDouble(0x3fe995b810479e51L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 15, "\uda62\udd42\udb22\udc51\ud9b1\udebe\ud928\udc01", "\u55f4\u8d71\u54ab\u3f5d\u2bfc\u1b61\u54a7\u0d4d\u349f\u34d6", "\ud850\udf99\ud80a\udcd9",
        55, 22865, -215689859, 6663004617106498098L, -94962L, true, true, (char) 55382, (char) 12672,
        Double.longBitsToDouble(0x3fdc272cc62573c4L), Double.longBitsToDouble(0x3fea4196427bbe18L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 16, "\uda3d\udf2d\ud89a\ude4c\ud950\udd20\ud928\udc30", "\u35a2\u6b9b\u69c2\u3b09\u799a\u3aff\u971b\000\u3fb6\u34d6", "\000",
        41, 34050, -2081905448, 5890808794381783994L, 70943L, true, false, (char) 54525, (char) 45560,
        Double.longBitsToDouble(0x3fe11db3d9734470L), Double.longBitsToDouble(0x3fe895c9c8006cbcL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 10, 16, "\uda3d\udf2d\ud89a\ude4c\ud9de\ude1f\ud928\udc30", "\u35a2\u6b9b\u69c2", "\udab0\udfab",
        16, 72427, -1622560170, 9000699813449644649L, 30038L, false, false, (char) 57163, (char) 58745,
        Double.longBitsToDouble(0x3fa79e6fc41f0d30L), Double.longBitsToDouble(0x3fbe638e77ac3040L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 16, "\uda3d\udf2d\ud89a\ude4c\ud950\udd20\ud928\udc30", "\u35a2\u6b9b\u69c2\u3b09\u799a\u3aff\u5470\u48a0\u3fb6\u34d6", "\uda5e\ude15\ud969\udc0c\ud8d2\udf72\udb87\udd87\ud93c\udc34\ud953\udf50\ud823\udf4a\ud85a\udd61\udbda\udd48\udbdb\uddf7",
        26, 49915, -1187432077, -498823058683789738L, 41686L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fe3d992dcac252dL), Double.longBitsToDouble(0x3fe995b8116c9e51L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 10, 5, "\uda3d\udf2d\ud89a\ude4c\ud950\udd20\ud88c\ude22", "\u35a2\u6b9b\u69c2\u3b09\u0606\u1ab4\u64d0\u9fb6\u3fb6\u34d6", "\udba2\udef7\ud968\udfe7\udabc\udea3\udac0\udcbb\ud941\udf52\ud91c\udc21\ud832\udc4a\ud85a\udd61\udbda\udd48\udbdb\uddf7",
        21, 95507, -1162963977, -16331421364114905L, -51043L, false, true, (char) 30754, (char) 37151,
        Double.longBitsToDouble(0x3fe1a92258ac252dL), Double.longBitsToDouble(0x3fed3928396c9e37L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 3, "\uda8b\udffc\ud9de\udff4\ud9b1\ude4d", "\u2d76\u59cf\u1323\u69c2\u3b09\u93ae\u7ac3", "\udbc5\udca2\ud874\uded6\ud9b0\udc26\ud852\ude0b\ud88f\udf4d\ud88b\udc8c\ud977\udc14\ud9b0\udebf\ud863\udcc9\udbdb\udc14\udab2\ude28\udac3\udf61\udbda\udcfe\udbe4\ude8b\ud852\udfb6\ud868\udf29\udb26\udd94\uda54\udfc2\uda2d\udef4\ud88d\udd3e\ud971\udf10\u4226",
        -1, 84902, 623770235, -5259636279673254020L, -81126L, true, true, (char) 31057, (char) 11839,
        Double.longBitsToDouble(0x3fe580b767936ad5L), Double.longBitsToDouble(0x3fe1fea915a7a51aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 11, "\uda62\udcf1\udb22\udc51\ud908\udfea\ud983\uddf8", "\u59cf\u1323\u69c2\u3b09\u799a\u3aff\ub1ac\u47e1", "\ud9b0\udc26\uda8a\uddb8\udba4\udeb5\ud88f\udee0\ud977\udc14\ud9b0\udebf\ud863\udcc9\udbdb\udc14\udab2\ude28\udbee\udffa\udbda\udcfe\udbdb\uddf7\ud852\udff2\ud9ee\ude2b\ud8b7\udd47\uda54\udfc2\uda2d\udef4",
        46, 36035, -1262174571, 2031628963324584686L, 29794L, false, true, (char) 11928, (char) 24895,
        Double.longBitsToDouble(0x3fe26fea792e03c0L), Double.longBitsToDouble(0x3fe336ca2cf57873L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 0, "\uda62\udcf1\ud82c\udc35\ud9b1\udebe\u22c6", "\u1d89\u81e8\u9d18\u7c3e\u7a3d\u3aff\ubc6b\u48a0\u37a4\u1d38", "\uda44\udf16\ud884\udde0\udaf9\udfbf\ud8ba\udcca\ud878\udefc\ud91c\uddc3\udab2\ude28\udbee\udffa\udbda\udcfe\udbdb\uddf7\ud852\udff2",
        20, 80071, -2094948471, 5554660225664285936L, -51211L, true, true, (char) 32543, (char) 11478,
        Double.longBitsToDouble(0x3fc584a5bccadca4L), Double.longBitsToDouble(0x3fb6cf8b9dcac4f8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 3, "\ud9b5\udf46\ud99e\udede\ud936\udec0\ud8cd\udd13", "\u4df1\ub586\ucf3d\u785d\u92d2\u084f\uac02\ub808\u3fe6\u6df6\u22ac\uaaa6\u6d04\u21ce\ud5c8\u87a8\ucb74\u2d24\u9cf0\u96ef\u69b3\u6211\u63d8\u1eb3\u8371", "\ud976\uddc0\udb5b\udd7f\ud867\udd59\ud819\udee9\ud931\ude26\uda89\ude24\udafe\udd7d\ud980\udfa4\ud925\uddf6\uda31\udec1\ud9c8\udeba\udbdc\udfc6\ud8bb\ude42\udaf1\ude70\udbf0\udeb2\ud86a\udf80\udb21\ude00",
        15, 12747, 1000992085, 3560408100526748005L, 37500L, true, true, (char) 17091, (char) 8196,
        Double.longBitsToDouble(0x3fd67716bff994f0L), Double.longBitsToDouble(0x3fecd4073026f8b5L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 16, "\ud9b5\udf46\ud89b\ude1c\ud936\udec0\ud9a4\ude4a", "\u1c94", "\udafc\ude90\uda34\udd81\ud918\udd5f\ud969\udf4c\ud981\udcd5\udbc5\udcd2\udb88\udd7b\ud920\udcc2\udbdf\udd69\udb55\udc46",
        58, 4000, 1242358821, -8071194379894374104L, 44843L, true, false, (char) 5422, (char) 52938,
        Double.longBitsToDouble(0x3fe11c5bd9734470L), Double.longBitsToDouble(0x3f93b93996e7a620L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 8, "\uda62\udcf1\ud983\udeb4\ud889\udee3\udb20\udf38", "\u9214\u9119\uc52c\uae5c\u6b34", "\ud856\udf36\udbc5\udd20",
        51, 23273, 1178505909, 7271031966394049829L, -41595L, true, false, (char) 51591, (char) 61690,
        Double.longBitsToDouble(0x3fe65af5104f2287L), Double.longBitsToDouble(0x3fe7ac3042d076faL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 1, 13, "\uda62\udcf1\ud9f8\udcfb\uda64\udf0e\ud928\udc01", "\u35f4\u6b9b\u16c2\u3b25\u799a\u3aff\u381b\u6846\u67a7\u7384", "\ud920\udeff\ud876\udd93\ud977\udc14\ud9b0\udebf\ud863\udcc9\udb83\udc89\udada\udd7f\udbee\udffa\udbda\udcfe\udbdb\uddf7",
        2, 49915, -1187432077, -8938287285399957688L, 41741L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fe3d8782cac252dL), Double.longBitsToDouble(0x3fe995b8119eeb51L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 15, 10, "\udb02\udc8e\ud9ab\udcc7\udaaf\uddae\ud853\udc16\ud818\udf00\ud809\udeaa", "\u570e\ubcec\uce8e\u5637\uc353\u6ca8\u1515\u4960\u4cf1\ua5a0\ud181\ud156\uc818\u586a\ua93b\u1e7f\u8ef6\u31dd", "\ud9a0\udcd8\uda13\udf03\uda2d\udc79\uda21\udf4b\uda9e\udd90\ud874\udd83\uda69\ude14",
        10, 3538, -1914368368, 3701852764926248942L, -19985L, false, false, (char) 34367, (char) 55278,
        Double.longBitsToDouble(0x3fe975e3ddfef62aL), Double.longBitsToDouble(0x3fe57d02fcd2ab9bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 15, 10, "\uda62\udcf1\udb22\udc51\ud953\udeaf\ud94a\uddcd", "\u2807\u52ac\u1a58\u3b09\u94d9\ub307\u036d\u4839\u3fb6\u34d6", "\ud920\udeff\ud8d6\udea3",
        4, 54683, -1879221405, 1403391018460657832L, -38513L, true, false, (char) 26647, (char) 56807,
        Double.longBitsToDouble(0x3fd7344700257272L), Double.longBitsToDouble(0x3fe094192df7c94bL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 9, 16, "\uda62\udcf1\udb22\udc51\ud9e9\udc39\ud9b1\uddd1", "\u624b\u6b9b\u18df\u5c46\u7a1a\u3aff\u5470\u0e41\u3faa\u34d6", "\ud905\udf96\ud876\udd93\ud8d1\ude82\ud9b0\udebf\ud863\udcc9\udad0\udf0d\udab2\ude16\udbee\udffa\ud9d1\udf07\udbdb\uddf7\ud852\udff2\ud8d0\udfdd\ud91e\udf78\uda55\udc8a",
        44, 60706, 126735955, -6027787098232075318L, 29659L, false, false, (char) 18092, (char) 55703,
        Double.longBitsToDouble(0x3fc392ed26160d2cL), Double.longBitsToDouble(0x3fa12e9b906e4890L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 0, "\ud9dc\udce9", "\uc0ac\u6a35\u8bed\u35f4\u6b9b\u2fd9\u6f13\u3c71\u2a59\u111b\ua6b0\u3fe1", "\udb53\udf0c\udbc1\udee2",
        47, 82496, -1270281489, -1410050430738155644L, -75254L, true, false, (char) 62426, (char) 24400,
        Double.longBitsToDouble(0x3fe49767ce2ae4d6L), Double.longBitsToDouble(0x3fe3d1b67f819885L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 9, "\ud9d2\udce9\udb22\udc51\ud9b1\udebe", "\u2d76", "\ud914\udc3e\uda59\ude95\udab4\udf20",
        6, 95520, 1953996954, -6942380917500876597L, -72021L, true, false, (char) 15638, (char) 55733,
        Double.longBitsToDouble(0x3fcdec4c9a6c67e8L), Double.longBitsToDouble(0x3fec27637483a077L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 9, 1, "\ud9d2\udce9", "\u10bc\u7708\u2e1f\u35f4\u2aef\u69c2\uafb4\u2905\u8628\u2cac\u48a0\u3fb6", "\ud87e\udc20\ud94c\udc1b\ud876\udd86",
        42, 5904, -54094971, -723613783015265547L, 80444L, true, true, (char) 22153, (char) 44709,
        Double.longBitsToDouble(0x3fe7fd73a01e868cL), Double.longBitsToDouble(0x3fe1b2182ff3eceeL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\udb96\udd7a\ud9e8\udeee\ud934\udf75\uda4a\uddfb\udbec\udff1\uda36\udece |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.String:\udb96\udd7a\ud9e8\udeee\ud934\udf75\uda4a\uddfb\udbec\udff1\uda36\udece |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 2, "\udb96\udd7a\ud9e8\udeee\ud934\udf75\uda4a\uddfb\udbec\udff1\uda36\udece", "\u5ed3\u6d26\u5644\u0cf2\u7bb9\u36d8\u8616\u0d87\u84bd\u5838\ud30a\u35e5\u8b99\u5d88\u2686\u0be0\u5528\uce1e\u9544\u0bf8\u9c2e\u2316\u263f\ubff6\u2df0\u3085\uaf70\uac49\u74ab\uaf26\u8d84", "\ud9c1\ude9a",
        39, 16397, -591961975, 4867484659356703234L, -1489L, true, true, (char) 5272, (char) 21507,
        Double.longBitsToDouble(0x3fe59ff25796e386L), Double.longBitsToDouble(0x3fc252b5096fa870L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 0, "\uda8b\udffc\ud9de\udff4\ud9b1\ude4d", "\u2d76\u59cf\u1323\u69c2\u3b09\u93ae\u7ac3", "\udbc5\udca2\ud874\uded6\ud9b0\udc26\ud847\udce2\ud88f\udf4d\ud88b\udc8cH\ud9b0\udebf\ud863\udcc9\udbdb\udc14\udab2\ude28\u52cb\udbda\udccf\udbe4\ude8b\u3a94\ud868\udf06\udbc5\uddc3\uda54\udfb0\uda2d\udef4\ud88d\udd3e\ud971\udf10\u4226",
        23, 84902, 623770235, -5259636279673254020L, -81126L, true, false, (char) 15616, (char) 47790,
        Double.longBitsToDouble(0x3fe0000007936ad5L), Double.longBitsToDouble(0x3fe1fea915a7a51aL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 13, 16, "\uda62\udcf1\udb33\ude4f\ud9b1\udebe\ud9d9\uddb1", "\u35f4\u6b9b\u69c2\u3b09\u799a\u3aff\u5470\u48a0\u3fb6\u34d6", "\ud920\udeff\ud876\udd93\ud977\udc14\ud9b0\udebf\ud863\udcc9\ud85e\udd0c\udab2\ude16\udbee\udffa\udbda\udcfe\udbdb\uddf7",
        2, 49915, -1187432077, -8938287285399434168L, 41741L, false, true, (char) 30754, (char) 32543,
        Double.longBitsToDouble(0x3fe3d992dcac252dL), Double.longBitsToDouble(0x3fe995b810479e51L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.w3c.dom.Node,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|asPath||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|attributeIterator|org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|childIterator|org.apache.commons.jxpath.ri.compiler.NodeTest,boolean,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|compareChildNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createAttribute|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int,java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equalStrings|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equals|java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|escape|java.lang.String|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|findEnclosingAttribute|org.w3c.dom.Node,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getAbstractFactory|org.apache.commons.jxpath.JXPathContext|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getBaseValue||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getDefaultNamespaceURI||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.w3c.dom.Node,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
