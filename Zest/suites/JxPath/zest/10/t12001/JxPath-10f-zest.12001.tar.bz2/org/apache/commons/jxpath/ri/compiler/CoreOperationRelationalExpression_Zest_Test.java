package org.apache.commons.jxpath.ri.compiler;
import org.junit.Test;
import static org.junit.Assert.*;
public class CoreOperationRelationalExpression_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 7, "\ud97d\udd5e\uda67\ude10\ud99c\udeaf\ud820\udfe2\ud827\udd3d\ud8e2\udf42", "\u0d22", "\ud90a\udff7\udad7\udf9c\ud8d1\uddc8\ud83b\udc12\udb85\udf96",
        33, 26961, 1742122775, 4129776795171041224L, 54532L, true, false, (char) 37136, (char) 53238,
        Double.longBitsToDouble(0x3fe3ee9ab558b2f6L), Double.longBitsToDouble(0x3fb1ac00d7cdc118L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 7, "\ud97d\udd5e\uda67\ude10\ud99c\udeaf\udb71\udecc\ud85d\udda3\ud8e2\udf42", "\u0d22", "\ud90a\udff7\udad7\udf9c\ud8d1\uddc8\ud83b\udc12\udb85\udf96",
        33, 26961, 1742122775, 4129776795171041224L, 54532L, true, false, (char) 37136, (char) 53238,
        Double.longBitsToDouble(0x3fe3ee9ab558c345L), Double.longBitsToDouble(0x3fb1ac00d7cdc118L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 7, "\ud97d\udd5e\uda67\ude10\ud99c\udeaf\ud820\udfe2\ud827\udd3d\ud8e2\udf42", "\u0d22", "\ud948\udd55\udad7\udf9c\ud8d1\uddc8\ud83b\udc12\udb85\udf96",
        33, 26961, 1742122775, 4129776795171053818L, 54532L, true, false, (char) 28944, (char) 53313,
        Double.longBitsToDouble(0x3fe3ee9ab558b2f6L), Double.longBitsToDouble(0x3fb1ac00d7ce5af0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Integer:3 |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 7, "\ud814\udc01\ud93a\ude3f", "\u9423", "\ud9eb\udefa\ud8fb\uddd1",
        18, 46719, -38585318, 3748073011159663376L, 52226L, true, true, (char) 13792, (char) 17774,
        Double.longBitsToDouble(0x3fe0e8bb0fc8396aL), Double.longBitsToDouble(0x3fd415dd206fe840L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 7, "\uda34\ude21", "\u8066\u5226\uaf63\u4248\ua304\u0d22\u5a2c", "\udad7\udf9c\ud8bc\udccb\ud83b\udc12\udb85\udf96\uad28\uda31\udd8c\uda2b\udd35\ud8a4\udc36\ud93d\udd80",
        16, 81572, -1033651017, -5752558332337053748L, -39928L, false, false, (char) 797, (char) 40410,
        Double.longBitsToDouble(0x3fe646d33bd9d2c7L), Double.longBitsToDouble(0x3f7bb071879d9980L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 4, "\ud844\udee1\uda67\ude10\ud99c\udeaf\ud820\udfe2\udb47\udc8c\ud8e2\udf42", "\u0d22", "\ud90a\udff7\udad7\udf9c\ud8d1\uddc8\ud83b\udc12\udb85\udf96",
        33, 26961, 1742122775, 4129776795444186568L, -31524L, true, false, (char) 37136, (char) 53238,
        Double.longBitsToDouble(0x3fc73a6ad51bc4e0L), Double.longBitsToDouble(0x3fb1ac00d7cdc118L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.String:\ud97d\udd5e\uda67\ude10\ud99c\udeaf\ud820\udfe2\ud827\udd3d\ud8e2\udf42 |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 2, "\ud97d\udd5e\uda67\ude10\ud99c\udeaf\ud820\udfe2\ud827\udd3d\ud8e2\udf42", "\u0d22", "\ud90a\udff7\udad7\udf9c\ud8d1\uddc8\ud83b\udc12\udb85\udf96",
        33, 26961, 1742122775, 4129776794852274120L, 54532L, true, false, (char) 37136, (char) 53238,
        Double.longBitsToDouble(0x3fe3ee9ab558b2f6L), Double.longBitsToDouble(0x3fb1ac00d7cdc118L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 7, "\ud97d\udd5e\uda67\ude10\ud99c\udeaf\ud820\udfe2", "\u4248\ua304\u0d22\u5a2c\u5e2c\u4187\ud315\u027c\ua033\u2854\uaa5d\u551f\ud228\ub4da\u6f23\ud3b8", "\uda4a\uddf8\ud885\udd2a\udaff\uddf2\ud8d8\udca1\udb70\udc09\ud8d8\ude5a\ud90c\udfb6\uda8a\udd10",
        0, 33357, -1643725050, -4568292252022786187L, -78355L, true, true, (char) 5764, (char) 64797,
        Double.longBitsToDouble(0x3fe7ecbf2d312705L), Double.longBitsToDouble(0x3fce5ca8e5833578L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 7, "\ud97d\udd5e\ud9e6\udc1b\ud99c\udeaf\ud820\udfe2\ud856\udc3d\ud846\udf75", "\u0d22\u5a2c\u5e2c\u2960\u0232\u48de\u1b4e\u281b\uaa5d", "\uda7d\ude1d\udaa0\ude11\ud81f\udf01\ud807\udd52\udbd6\uded3\ud9f1\udc38\u707c\udaff\uddf2\ud870\udded\uda19\udf5d\uda72\udc1e\udad8\ude6a\udac6\udc4d\ud96a\udf51\uda75\udc62",
        -2, 535, -1285185863, -4300833365744047572L, 73256L, true, true, (char) 40070, (char) 18333,
        Double.longBitsToDouble(0x3fcfc0eefbc19244L), Double.longBitsToDouble(0x3fe599d7af3933a5L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 4, "\ud97d\udd5e\uda67\ude10\ud99c\udeaf\udbff\uddc7\udae4\udcc8\ud8e2\udf42", "\u0d22", "\ud90a\udff7\ud8f1\udeb9\uda37\udf73\udbe5\udfbe\uda5b\udca1",
        58, 75467, 1742115679, -1274542757673553976L, 54532L, true, false, (char) 37136, (char) 53238,
        Double.longBitsToDouble(0x3fe3ee9ab558b2f6L), Double.longBitsToDouble(0x3fb1ac00d7cdc118L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 7, "\udb8f\uddc7\uda67\ude10\ud8ab\uded6\udbd7\ude09\ud827\udd3d\ud8e2\udf42", "\u0d22", "\ud90a\udff7\udac0\ude40\ud8d1\uddc8\ud83b\udc12\udb85\udf96\uad28\ud858\udca0\udb06\uddb8\ud86b\udc75\udb1a\udf94\udb74\ude36\uda20\udd16\udae6\udd9a\uda4a\uddf8\ud885\udd2a\udaff\uddf2\ud8d8\udca1\udb70\udc09\ud975\udeaa\uda65\udfde\ud917\udd2b",
        19, 87427, -1103932036, 6149303978160833485L, -25466L, true, false, (char) 14763, (char) 44017,
        Double.longBitsToDouble(0x3fde2526e811d58aL), Double.longBitsToDouble(0x3fe98f65a2d85257L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 7, "\ud8f2\udf43\uda67\ude10\ud805\udfc6\ud820\udf4a\ud827\udd65\ud8e2\udf42", "\u8d16", "\ud8db\udef5\ud9e3\udfa2\ud8d1\uddc8\ud8e4\udf02\udb86\udc65",
        2, 25225, 2058131136, 4129682267235823560L, 54532L, true, false, (char) 37136, (char) 53238,
        Double.longBitsToDouble(0x3fe3ee9ab083b2f6L), Double.longBitsToDouble(0x3fb1ac00d7cdc118L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 3, 7, "\ud97d\udd5e\uda67\ude10\ud99c\udeaf\ud820\udfe2\ud827\udd3d\ud8e2\udf42", "\ucf75", "\udb0e\udfc2\ud842\udd7b\ud8e7\uddc8\u7625\udae5\ude7b\ud9fe\udc66\uda03\udc44\udbcb\uddd5\udbc5\udc49\ud99d\udd4f\uda04\udc56\uda86\udee1\udafb\ude9d\uda4a\uddf8",
        41, 55293, -1341975208, -5178114525391422727L, -17838L, false, true, (char) 30277, (char) 40635,
        Double.longBitsToDouble(0x3fcd789a6e3f31a0L), Double.longBitsToDouble(0x3fe7e81f7d5dc007L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 3, 0, "\udaed\udf35\udbb4\udc0f\uda8a\udf9d\uc57f\udb91\udf96\udac1\udc74", "\u0d22", "\ud9a1\udca3\ud9a8\udd0c\ud818\udce1\ud83b\udc12\ud8fd\uddd2\ud981\udee8\ud903\ude46\ud9d6\udfcb\udbab\udd03\ud908\udd83\uda04\udc56\udbae\ude5e\udbb4\udd19\uda4a\uddf8\ud885\udd2a\udb23\ude27\ud8a4\udec2\udb2f\udc3f\uda52\udcea\udb06\uddfc\ud8be\udd33\ud883\udf90\ud9ad\udfd1\uda74\udd70\ud8f8\udf49\ud911\udfef\uda6d\udf7e\udb0f\udd99\ud997\ude27\uda94\udd2a\ud800\udce0\ud818\ude1b\ud915\udf0b\udaa5\udd48\udb54\udefd\udbdd\udecd\udbad\udf17\ud812\udf02\udb27\udfaa\udaf1\udcfc\udb94\udd88\ud8e4\udca2",
        20, 7076, 55393712, 2844385696299352224L, 11490L, true, true, (char) 62461, (char) 19638,
        Double.longBitsToDouble(0x3fd6647642434108L), Double.longBitsToDouble(0x3fc6e1319767c648L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "\000\000\000\ud84d\udee5\u18ce\ud8bd\udd3d", "\u0d22", "\000",
        47, -984, 0, 0L, -100000L, false, false, (char) 26903, (char) 49171,
        Double.longBitsToDouble(0x3fb737df45bef208L), Double.longBitsToDouble(0x3e19960000000000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 7, "\ud97d\udd5e\uda67\ude10\ud99c\udeaf\udbca\udd38\ud83c\udf12\ud8e2\udf42", "\u0d22", "\ud951\ude65\udbe0\udccd\udb56\udd5c\ud83b\udc12\ud86f\udc8b",
        33, 26961, 1742122775, 4129776795171041224L, 54532L, false, true, (char) 30779, (char) 33394,
        Double.longBitsToDouble(0x3fe3ee9ab558b2f6L), Double.longBitsToDouble(0x3fb1ac00d7cdc118L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 7, "\ud97d\udd5e\ud977\udfb9\ud98a\udef9\ud820\udfe2\ud859\ude15\ud8e0\udfa3", "\u89b7\u5acc\u5e2c\u2960\u69f8\ubedf\u386c\ub5f0\u758e\u20f0\u1e71\u134d\ucd79\u428f\u0684\u19d8\u7241\u9fc4", "\ud87f\udf91\u414f\ue143\udb67\udd54\udb4c\udd98\udbcc\udfa9\uc2f2\udb2d\udd3e\ud88b\udefc\uda63\ude6a\uda1e\udc9f\ud8ad\udd77\udb8c\udc81",
        47, 59387, 64134700, -8315572444689373444L, -8077L, true, false, (char) 45439, (char) 61016,
        Double.longBitsToDouble(0x3febd085b2c99185L), Double.longBitsToDouble(0x3fe97642ce64999cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 0, "\ud94f\uddca\uda67\ude10\ud99c\udeaf\ud820\udfe2\ud827\udd3d\ud857\udc5d\udb8a\udeff\udaf3\udd7e\udb9b\udebc\uda38\udf66\ud95e\udfde\ud9c8\udfef\udb8d\uddcf\udabc\udf3d\ud83b\udc12\ud86e\udc4b\udac2\udcb4\uda31\uddb7\udb82\udf3d\uda9e\udd72\udaac\ude48\udaff\udda3\ud8db\ude2e\udafb\udfd5\udb35\ude75\udb5f\udca2\uda3c\udc8b\ud8d8\udca1\ud856\udf5c\ud882\uddf8\ud844\uddd1", "\ua0b9\u346e\u8ea3\u2ba7\ua6eb\u9955\u1349\u1835\ucce2\u3def", "\ud905\ude7a\udbc3\udc84\udb81\udc5c\udb25\udea7\uda4d\udff7\ud9b4\uddb1\ud9ff\udee6\udb45\udf3a\ud9ec\udfee\udb1f\udfa9\uda9d\udc8f\u31a6",
        25, 85334, -183626742, 6774552177784723244L, -64049L, false, false, (char) 64295, (char) 20983,
        Double.longBitsToDouble(0x3fdc7a8c0f9ca752L), Double.longBitsToDouble(0x3fe5ef8a6217e609L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 7, "\ud97d\udd5e\uda67\ude10\ud99c\udeaf\ud820\udfe2\ud827\udd3d\ud8e2\udf42", "\u0d22", "\ud90a\udff7\udad7\udf9c",
        54, 25919, 722715917, 7498940907521188409L, -9311L, false, false, (char) 39672, (char) 37136,
        Double.longBitsToDouble(0x3fee6581527dd356L), Double.longBitsToDouble(0x3fd58b2f688d6006L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 7, "\ud97d\udd5e\ud8e5\udc5b\ud96e\ude98\udaa5\udd3b\udab8\udd89\ud9bb\udeef", "\u1c8a", "\udaca\udff7\udad7\udf9c\ud8d1\uddc8\udb2b\udc8a\udb86\udc30\ud900\udced\udaa2\udd5a\ua015\ud8b3\udc3b\udbbd\udea9\uda1b\ude3c\udbae\ude5e",
        50, 89203, -749330484, 6800697958935077720L, 11879L, true, true, (char) 61713, (char) 60137,
        Double.longBitsToDouble(0x3fee7b5ee982d4aaL), Double.longBitsToDouble(0x3fd594d6e3ddb1d2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 7, "\ud814\udc01\ud93a\ude3f", "\u9723", "\ud8c9\ude9d\ud9f7\udcd2",
        18, 46673, -38585318, 3292944367718358888L, 52226L, true, true, (char) 13792, (char) 50510,
        Double.longBitsToDouble(0x3fe0e8bb0fc8396aL), Double.longBitsToDouble(0x3fd415dd206fe840L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 4, "\ud9f6\udd19\uda67\ude10\ud99c\udeaf\ub9e2", "\u4248\ua304\u022b\u5a2c", "\udacb\udff3\ud815\udeb5\ud83b\udc12\udbd9\udc80\uda01\udf7a\uda31\udda2\ud9bc\ude3f\u7e6c\ud8ec\ude11",
        57, 42436, -1033651017, -5752558331814531380L, 77415L, false, true, (char) 47485, (char) 4355,
        Double.longBitsToDouble(0x3fa9602bb65fb890L), Double.longBitsToDouble(0x3fe8e79b03ddfb32L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 2, "\udaa6\ude8a\uda67\ude10\ud99c\udeaf\ud820\udfe2\ud827\udd3d\ud8e2\udf42", "\u0d22", "\ud90a\udff7\udad7\udf9c\ud8d1\uddc8\ud9ac\udc0c\udb85\udff4",
        33, 81001, 1730302595, 4129776794852274120L, -63869L, true, false, (char) 37136, (char) 53238,
        Double.longBitsToDouble(0x3fe3ee9ab458b2f6L), Double.longBitsToDouble(0x3fc04914ebe6e08cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 0, "", "", "",
        8, 26221, 134234229, 25123527425392640L, -20156L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e418e7890000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 7, "", "\u9cc5\u7fce\u5222", "\udaf3\ude27\ud8d8\udc39\ud9ba\udd89",
        2, 66352, 879088780, -6456328911038090305L, -87194L, true, true, (char) 20123, (char) 3792,
        Double.longBitsToDouble(0x3fee41ca7a415dd2L), Double.longBitsToDouble(0x3fb737df65bef208L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 7, "", "\u310f", "\ud8e2\udf42\ud80c\udcf2\ud8dc\uddbc\udb4a\udf73\ud9b9\ude54\uda47\udd27",
        42, 25252, -1503231216, 7733320197512348941L, 39833L, true, true, (char) 20979, (char) 26903,
        Double.longBitsToDouble(0x3fe20aee945cdf7dL), Double.longBitsToDouble(0x3fc6fbc82000018cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 0, "", "", "",
        -5, -1000, 0, 263323648L, -34464L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "", "", "\udae4\udc75",
        41, 4229, 5849527, 1130966458460119627L, -100000L, false, false, (char) 0, (char) 33791,
        Double.longBitsToDouble(0x3fb8e789229017c8L), Double.longBitsToDouble(0x3fbe58a0b679e368L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 0, "4", "", "\uda81\ude12",
        59, 91527, 263323648, 8747576294248364004L, -69910L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e24b9eda0000000L), Double.longBitsToDouble(0x3fcd9d4c7f64cad8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "", "\000", "\udae1\udfe1",
        59, 91527, 263323648, 8747576294248364004L, -100000L, false, false, (char) 52391, (char) 240,
        Double.longBitsToDouble(0x3fc3a000118d6520L), Double.longBitsToDouble(0x3fe37857657db223L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Integer:3 |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 0, "4", "", "\uda81\ude12",
        59, 91527, 464650240, 8747576294259794857L, -69910L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e24b9eda0000000L), Double.longBitsToDouble(0x3fcd9d4c7f64cad8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 0, "4", "\u5ee4", "\udac2\udced\udb3a\udecb\uda17\udd96\udb16\udcb6\ud889\udf7f\ud826\udd5e\uda1b\udc2c\uda33\ude59\udb8e\ude27\000\ud844\udc23\udbce\udc04\ud807\udfe9\ud87f\udf4a\uda92\udf0c\ud806\uddab\ud803\ude74\udb94\udf4d\uda14\ude5f\ud809\udc66\uda06\ude16\udbb7\udf80\ud962\udda3\ud87a\uddea",
        29, 98362, -317419485, -2904047219369267354L, -26021L, true, false, (char) 65037, (char) 61427,
        Double.longBitsToDouble(0x3fe629b65aea1727L), Double.longBitsToDouble(0x3fdb91b2b77f3db8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 0, "4", "", "\uda81\ude12",
        59, 91527, 263323648, 8747576294248364004L, 49197L, false, false, (char) 60636, (char) 2086,
        Double.longBitsToDouble(0x3fcd9d4c7f64cad8L), Double.longBitsToDouble(0x3fe4fabaa1a7c9e8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "4", "", "\uda81\ude12",
        35, 91527, 263323648, -6547594719806660257L, -69910L, true, false, (char) 15745, (char) 1660,
        Double.longBitsToDouble(0x3fb952dee5c1eb18L), Double.longBitsToDouble(0x3fcd9d4c7f4ce8e0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 0, "4", "", "\uda81\ude12",
        59, 91527, 464650240, 8714788856389411688L, -6165L, false, false, (char) 39167, (char) 43389,
        Double.longBitsToDouble(0x3e24b9eda0000000L), Double.longBitsToDouble(0x3fcd9d4c7f64cad8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 7, "\000\000\uda84\udda2\ud820\udfe2\ud827\udd3d\ud8e2\udf42", "\u0087", "\ud90a\udff7\udad7\udf9c\ud8d1\uddc8\ud83b\udc12\udb85\udf96",
        33, 26961, 1742122775, 1574055880L, 54532L, true, false, (char) 37136, (char) 53238,
        Double.longBitsToDouble(0x3fe3ee9ab558b2f6L), Double.longBitsToDouble(0x3fb1ac00d7cdc118L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 0, "", "1", "\udb84\uded4",
        18, 26316, 471944721, 8747606146541134052L, 31072L, false, false, (char) 56324, (char) 39879,
        Double.longBitsToDouble(0x3e418e7890000000L), Double.longBitsToDouble(0x3fc0d9fce5294ae8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 0, "", "1", "\udb84\uded4",
        18, 29236, -1845202729, 8747606146541134052L, 31072L, false, false, (char) 56324, (char) 39879,
        Double.longBitsToDouble(0x3fccd960154544f0L), Double.longBitsToDouble(0x3fc0d9fce5294ae8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|computeValue|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|compute|java.lang.Object,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|containsMatch|java.util.Iterator,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|evaluateCompare|int|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|findMatch|java.util.Iterator,java.util.Iterator|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|getPrecedence||new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|isSymmetric||new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|reduce|java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|computeValue|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
