package org.apache.commons.jxpath.ri.model.beans;
import org.junit.Test;
import static org.junit.Assert.*;
public class PropertyPointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 5, 13, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda22\udf38", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u9e23\u64c8\u45e1\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udadd\udcd2\udbc5\udf8d",
        44, 57763, -460886167, 5879753591349164846L, -57969L, true, true, (char) 5633, (char) 24077,
        Double.longBitsToDouble(0x3fd690f1eddd50f4L), Double.longBitsToDouble(0x3fe0700ac8e6dc85L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 5, 13, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda22\udf38", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u9e23\u64c8\u45e1\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udadd\udcd2\udbc5\udf8d",
        44, 57763, -460886167, 5879753591349164846L, -62890L, true, true, (char) 7705, (char) 20326,
        Double.longBitsToDouble(0x3fa7864c185fa800L), Double.longBitsToDouble(0x3fa920e7e69dfa30L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 5, 13, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda26\udf65\udba6\udcff\uda8a\udecb", "\u2281\u41c7", "\uda7a\ude96\ud8af\udfde\uda05\ude77\uda95\udc3f",
        2, 19132, -863852009, 2575175149391324623L, -58789L, true, false, (char) 32154, (char) 62437,
        Double.longBitsToDouble(0x3fe547c99c9268a5L), Double.longBitsToDouble(0x3fd49aae346d03e8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\ud84a\udfe6\uce34\000\000\udbb5\udd3a", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u9e23\u64c8\u472f\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\uddd9\ud9a0\udd99\udadd\udcd2\udbc5\udf8d",
        44, 57763, -460886167, 5836665929679878958L, -99953L, false, false, (char) 5633, (char) 24077,
        Double.longBitsToDouble(0x3fd690f1eddd50f4L), Double.longBitsToDouble(0x3fe0700ac8e6dc85L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 13, 13, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda22\udf38", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u9e23\u64c8\u45e1\u0568", "\ud990\udf77\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udadd\udcd2\udbc5\udf8d",
        44, 57763, -460886167, 5879753591349164846L, -57969L, true, true, (char) 5633, (char) 24077,
        Double.longBitsToDouble(0x3fd690f1eddd50f4L), Double.longBitsToDouble(0x3fe0700ac8e6dc85L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 12, "\ud96c\uddaa\ud9f4\udfdf\ud8a0\uddea\udb02\udd06\uda22\udf38\ud9aa\udd15\uda8a\udecb\ud858\udda4\uda01\udf4a\u8af0\ud98e\udc70\ud8e4\udd4c\udb97\udefb\ud87c\udc7d\ud993\udcc8\ud978\udd81", "\ud7e3\u4580\ua793\u6aa5\u4073\u3899\u191c", "\ud9d9\udc13\u14cd\udaf6\udd5e",
        39, 29278, 1493444763, -1979491013074807619L, -27789L, false, false, (char) 42796, (char) 45067,
        Double.longBitsToDouble(0x3fe07352c42f0c98L), Double.longBitsToDouble(0x3fd85fa80864839eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 13, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda22\udf38\ud9aa\udd15\uda8a\udecb\ud97f\ude97\uda01\udf4a\u8b34", "\u9ef6\u84f4\u64c8\u45e1\u0568\uc408\u678a\u55f3\u3e83\u768e", "\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\uda63\ude6a\ud9a0\udd99\udadd\udcd2\udbc5\udf8d\ud97a\udddb",
        13, 76833, 1368986813, 3688935377086257683L, -93330L, true, false, (char) 47109, (char) 42636,
        Double.longBitsToDouble(0x3fe34efd1d180f1eL), Double.longBitsToDouble(0x3fe77543d60e0159L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 5, 13, "\ud84a\udfe6\ud9f4\udf73\ud971\ude81\udb9d\udef5\uda22\udecc", "\u9a0d\ud4df\u60b2\u2bc7\u4b2a\u9ef6\u9e23\u64c8\ud666\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udadd\udcd2\udbc5\udf8d",
        44, 57763, -460886167, 5879753591349164846L, -57969L, false, false, (char) 40406, (char) 24077,
        Double.longBitsToDouble(0x3fd690f1eddd50f4L), Double.longBitsToDouble(0x3fe0700ac8e6dc85L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 13, "\udb5a\udce5\ud9af\udde5\u6201\uda77\udc05\uda22\udf38", "\u69f1\ud4fa\u2281\u41c7\ud17c\ud216\u0a38\u64c8\u996f\u3bea", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\udb52\udebb\ud812\ude21\ud9a0\ude25\udadd\udcd2\udbc5\udf8d",
        44, 57763, -460886167, -2118639347635084222L, -58383L, true, true, (char) 7649, (char) 20326,
        Double.longBitsToDouble(0x3fa7864c174fa800L), Double.longBitsToDouble(0x3fa95819e69dfa30L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 2, "\uda84\ude54\ud9dc\udc73", "\uaeb4\u9de8\u7c5f\u9a0d\ud4df\u2281\u62f9\u5fa4", "\ud993\udcc8\ud978\udd81\ud884\ude58\udb87\ude7d\ud86f\udd63\ud899\udff1",
        53, 96975, -432043840, 8968666066503805008L, 35279L, false, false, (char) 41906, (char) 57243,
        Double.longBitsToDouble(0x3fc24d14a288eb8cL), Double.longBitsToDouble(0x3fec15793791e79dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 5, 4, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda22\udf38", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u2f18\u8221\u45e1\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\udb66\udd9c\udadd\udcd2\udbc1\udd7a",
        44, 57763, -460889845, 5879753591349164846L, -57969L, true, true, (char) 7937, (char) 24077,
        Double.longBitsToDouble(0x3fd690f1eddd50f4L), Double.longBitsToDouble(0x3fe0700ac8e6dc85L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 5, 13, "\udbaa\udf76\ud9f4\udf9d\ud8a0\uddea\udb02\udd06\uda22\udf38", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u9f53\u64c8\u45e1\u8c84", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udadd\udcd2\udbc5\udf8d",
        44, 57763, -460886167, 5879753591349164846L, -57969L, true, true, (char) 63793, (char) 24077,
        Double.longBitsToDouble(0x3fd690f1eddd50f4L), Double.longBitsToDouble(0x3fe0700ac8e6dc85L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 13, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda22\udf38", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u7724\u64c8\u45e1\u0568", "\ud899\udff1\ud86f\ude43\udb8d\udd90\udba1\udff7\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udadd\udcd2\udbc5\udf8d",
        44, 57763, -460886167, 5879753589788883758L, 5585L, true, true, (char) 7644, (char) 59376,
        Double.longBitsToDouble(0x3fa78669985fa800L), Double.longBitsToDouble(0x3fa920e7e69dfa30L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 5, 13, "\ud84a\udfe6\ud9f4\udf73\udbb2\udee8\udbdf\udf8c\uda22\udf38", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u9e23\u64c8\u45e1\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde",
        46, 6351, 1095474504, -489852219627858264L, 13454L, true, false, (char) 53134, (char) 39466,
        Double.longBitsToDouble(0x3fcb3a20e838d560L), Double.longBitsToDouble(0x3fa7864c1fbfa800L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 5, 13, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda22\udf38", "\u9a0d\u799a\u2281\u41c7\u4b2a\u05ce\u9e23\u64c8\u45e1\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\uda5f\udf32\ud954\udc99\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udadd\udcd2\udbc5\udf8d",
        44, 57763, -460886167, 5879753591349164846L, -57969L, true, true, (char) 5633, (char) 24077,
        Double.longBitsToDouble(0x3fd690f1eddd50f4L), Double.longBitsToDouble(0x3fd0001591cdb90aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 5, "\ud84a\udfe6\udabe\ude88\u1e0c\udad0\ude5c\uda22\ude72\ud9aa\udd15\uda8a\udecb\ud97f\ude97\uda01\udf4a\u8b34\ud98e\udc70\ud8e4\udd4c\uda30\udfb3\ud911\udf60\ud993\udcc8\ud978\udd81", "\u6700\u55f3\u3e83\u768e\u7a3a\ua4cd\u42db", "\ud821\udd18\ud9a0\udd99\udadd\udcd2\udbc5\udf8d\ud97a\udddb\udbc9\udde3\uda1f\uddca\u918c\ud939\ude32\ud969\uddc3",
        35, 26939, 894979289, 907503972254786607L, 54985L, false, true, (char) 1925, (char) 34155,
        Double.longBitsToDouble(0x3fe9535972b6b3b7L), Double.longBitsToDouble(0x3fd61769676f7ba6L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 5, 13, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda26\udf65\udba6\udcff\uda8a\udecb", "\ubbaf\u41c7", "\uda7a\ude96\ud8af\udfde\uda05\ude77\uda95\udc3f",
        2, 47468, -863883008, 2575175149391324623L, -58789L, true, false, (char) 32154, (char) 62437,
        Double.longBitsToDouble(0x3fe547c99c9268a5L), Double.longBitsToDouble(0x3fea4d5719d58260L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 11, "\ud831\ude86\udb8e\udc62\ud8a0\uddea\udb02\udd06\uda26\udf65\ud962\udea5\uda8a\ude6f\udbd7\udf22\ud94f\udc26\ud8ad\udcb7\udac4\udd4f\ud8ce\udd07\ud8cf\udee2\uda7a\ude77\ud8af\udfde\udbd2\udc1d\u86cb\uda9d\ude6d\ud93f\udfc0\ud899\udf0e\u5995\uda3e\uddf0\udbec\ude6e\udab9\udde8\ud980\udea3\ud52b\udaec\udff0\udb33\udc0e\ud96d\udf72\udbca\udd33\udbc5\udf8d\ud97a\udddb\ud87b\udff0\udb5d\udf50\ud9d6\udece\ud92c\udf6c\udbe0\udfe7", "\u3615\ub50b\u14e5\u4336\uc963\u1711\u15ec\ucfc3\u5c3a\u341f\u71e1\uba13\u047e\uc3b3\u0d88\uae11\u30d8\u1258\u4fcd\u8bbb\u3801\u7d10\uba1a", "\uda72\udfcd\ud846\ude0a\ud903\udc98\u9173\uda50\udfe6",
        46, 58461, 1540548394, -8804178163522510571L, 44229L, false, false, (char) 58435, (char) 61251,
        Double.longBitsToDouble(0x3fd943bb53b136c4L), Double.longBitsToDouble(0x3fdfbfcab9c95b7aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 13, "\udaae\udfd4", "\ub0c1\u7036\uac7d", "\udb13\udc30\uf4a1\ud98e\udc70\ud8e4\udd4c\ud83a\udd58\udb37\udf68\ud923\ude44\ud994\udf30\udb5a\udd44\ud812\udf57\udb10\udc5a\ud961\udfab\uda52\udedf\udbb8\udff7\udb58\udc82\ud97b\udc3d\ud8dc\udede\ud9ef\udd6f\ud9a6\udf25\udafa\udf35\udaac\udcc2\ud801\udfa5\uda39\udc6f\udbed\ude44",
        1, 80640, 1368986813, 3688935375458867731L, 57133L, true, true, (char) 31393, (char) 29007,
        Double.longBitsToDouble(0x3fd85fa80864839eL), Double.longBitsToDouble(0x3fe34efd1d690f1eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 13, "\ud84a\udfe6\ud9f4\udf73\ud8a0\uddea\udb02\udd06\uda22\udf38", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u8568\u64a0\u45e1\u0568", "\ud990\udf77\ud86f\ude43\ud955\udebb\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udadd\udcd2\udbc5\udf8d",
        44, 59427, -460886167, 5879753591349164846L, -57969L, true, true, (char) 5633, (char) 24077,
        Double.longBitsToDouble(0x3fd690f1eddd50f4L), Double.longBitsToDouble(0x3fe0700ac8e6dc85L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 12, "\ud96c\uddaa\uda73\uddfe\ud8ae\udef9\udb02\udd06\uda22\udf38\ud9aa\udd15\uda8a\udecb\ud858\udda4\uda01\udf4a\u8af0\ud98e\udc70\ud8e4\udd4c\udb97\udefb\ud87c\udc7d\ud993\udcc8\ud978\udd81", "\ud7e3\u3df3\ua793\u6aa5\u4073\u3899\u191c\u2b57", "\u14cd\udaf6\udd5e\udbf2\udea9\ud97c\udc0b\udbc9\uddd9\uda1f\uddca\u918c\ud9cd\udf77\udbb2\udfdf\udbde\udf69\udb0e\ude53\ud95e\udf3b\u0acc\ud804\udfdc\udb73\udd65\udbad\udf3f\udb57\udfa5",
        0, 31014, 1056845613, 8741705520260779083L, -33470L, true, false, (char) 5675, (char) 61734,
        Double.longBitsToDouble(0x3fde8f9510f36292L), Double.longBitsToDouble(0x3feb545e0479dd05L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 12, "\ud96c\uddaa\ud9f4\udfdf\ud8a0\uddea\udb02\udd06\uda22\udf38\ud9aa\udd15", "\ubd3c\u5da0\u1ef4\u66ce\u52b4\uc634\u64c8\u45e1\u0568\uc408\ud7e3\u4580\ua793\u6aa5\u4073\u964a\u19da\u2b57\u3364\u95a5\ua16f\u0f3b\u80f6\ube76", "\u918c\ud939\ude32\ud969\uddc3",
        37, 41621, 1784171605, 907503973429191727L, -74626L, true, true, (char) 41804, (char) 3808,
        Double.longBitsToDouble(0x3fe5fb72d73c5ba5L), Double.longBitsToDouble(0x3fcbd8053ca6c89cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 13, "\ud84a\udfe6\ud9f4\udf73", "\uaa7c", "\ud97f\ude97\uda01\udf4a\ud90e\udd86\ud988\ude70\ud8e4\udd4c\u23d6\ud940\udecd\ud27b\udb83\udcf9\udb7a\ude9f\ud842\udf4f\ud86f\udc8b\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud9b9\udccf\ud8d2\ude2c\uda92\uddc1\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udadd\udcd2\udbc5\udf8d\ud97a\udddb\udbc9\uddd9\uda1f\uddca\udba4\udd8b\ud90b\udf7c\ud9aa\udcd1\ud9aa\udd15\ud96c\udffb\udb8c\udffd\ud998\udd15\uda42\ude20\udbbc\udd03\udb24\ude49\ud829\udf4d\uda46\udc40\ud962\udeb6\ud919\udd2d\uda46\udc8d\uda6f\udd26\uda15\udfb7\uda6a\udf2f\ud8f9\udf98\u96bf\uda0e\udcb5\udbc7\udc35",
        -3, 69322, 1433359490, 155757862339637024L, 73878L, false, false, (char) 64794, (char) 9284,
        Double.longBitsToDouble(0x3fdc65cbfcccce66L), Double.longBitsToDouble(0x3feeb0c32fae29ecL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 7, "\ud84a\udfe6\ud9f4\udf73\udbb2\udee8\udbdf\udf8c\uda22\udf38", "\u3845\u6dbb\u4eb5\u5afa\u4b2a\u9ef6\u9e23\u64c8\u45e1\u0568", "\ud899\udff1\ud86f\ude43\udb48\udeae\ud911\udfa2\udb18\ude6c\udbb3\udf85",
        59, 6829, 1095474504, -489852219627858264L, -68664L, true, false, (char) 51309, (char) 63812,
        Double.longBitsToDouble(0x3fe9728cca133370L), Double.longBitsToDouble(0x3fcec7d33decaabcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 5, "\ud948\udfec\uda63\udc07\udbb2\udee3\udbdf\udf8c\uda22\udf38", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u9e23\u64c8\u45e1\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde",
        46, 6351, 1095474504, -489852219627858264L, 13454L, true, false, (char) 20461, (char) 2952,
        Double.longBitsToDouble(0x3fcb3a20e838d560L), Double.longBitsToDouble(0x3fa7864c1fbfa800L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 11, "\ud84a\udfe8\ud9f4\udf73\udbb2\udee8\udbbe\udd5c\uda0a\udf20\ud9aa\udd15\uda8a\udecb\ud97f\ude97\ud9ff\udc4a", "\u4b2a", "\ud993\udcc8\ud978\udd81\udb5a\udd44\ud856\uddda",
        56, 218, 599579688, 7164424151719865205L, 59262L, true, true, (char) 36758, (char) 5772,
        Double.longBitsToDouble(0x3fe007e25ea8f933L), Double.longBitsToDouble(0x3fc24d14b7ad2b8cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 13, "\ud84a\udfe6\ud9f4\udf73\udbb2\udee8\udbdf\udf8c\uda22\udf38\ud9aa\udd15\udb33\udf75\ud974\udcce\udbbc\udd27\ud87f\udfd0\ud98e\udccf", "\u9e23\u64c8\u45e1\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b",
        49, 19238, 1826578181, 527522276825603400L, 90808L, false, false, (char) 1069, (char) 43665,
        Double.longBitsToDouble(0x3feb4ac824bde487L), Double.longBitsToDouble(0x3fe9728cca13cd41L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 10, "\ud84a\udfe6\ud9f4\udf73\udbb2\udee8\udb2e\udedb\ud8cb\udf98", "\u9a0d\ud4df\u2281\u41c7\u4b2a\u9ef6\u6c10\u28ea\u45e1\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\uddde",
        46, 6351, 1095474504, -489852219627858264L, 13454L, true, false, (char) 53134, (char) 39466,
        Double.longBitsToDouble(0x3fb20c81d071aac0L), Double.longBitsToDouble(0x3fa7864c1fbfa650L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 13, 13, "\ud84a\udfe6\ud9f4\udf73\udbb2\udee8\udbdf\udf8c", "\u3250\ud483\u32e0\u2281", "\uda6c\udedc\ud9d6\ude0a\ud85c\udd73\udaca\udf63\udac9\udd0a\ud862\udf30\ud915\uddf5\ud899\udff1\ud86f\ude43\ud8a0\udf39",
        22, 81644, 1906746947, 6548057906713076290L, -80071L, false, false, (char) 42295, (char) 1069,
        Double.longBitsToDouble(0x3fc3703e9da56410L), Double.longBitsToDouble(0x3fca4601b19bfaf0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 13, "\ud84a\udfe6\ud9f4\udf73\udbb2\udee8\udbdf\udf8c\uda22\udf38", "\u8bb7\ud4df\ucc93\u5544\u4b2a\u9ef6\u9e23\u64c8\u45e1\u0568", "\ud899\udff1\ud83d\udf6f\ud955\udf15\ud9d9\udf3b\ud955\udc3c\uc6ea",
        46, 6351, 1095474504, -489852220718377304L, 17469L, false, true, (char) 51346, (char) 36453,
        Double.longBitsToDouble(0x3fe30e41420edc5cL), Double.longBitsToDouble(0x3fcec7d33decaabcL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 15, 14, "\udaf7\udddb\uda53\udf77\udbc7\udd24\udbdf\udf8c\uda22\udf38", "\u36f7\u9576\u2281\u41c7\u4b2a\u9ef6\uace0\u64c8\u45e1\u0568", "\ud899\udff1\uda32\udde6\ud982\udf3a\ud963\udf40\ud955\udc3c\ud8dd\uddde",
        46, 6351, 1095474504, -489852219627858264L, 13454L, true, false, (char) 63302, (char) 39466,
        Double.longBitsToDouble(0x3fcb3a20e838d560L), Double.longBitsToDouble(0x3fa7864c1fbfa800L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 3, "\ud84a\udfe6\ud9f4\udf73\ud89b\udfdc\udbda\ude66\uda22\udf38\ud9aa\udd15", "\ud4df\u2281\u41c7\u4b2a\u9ef6\uaebd\u64c8\u96e1\u0568\u5d37\u6863\u7aee\u3db6\u768e\u7a3a\u3899\u191c\u480e\u3364\u12a9\u51f1\u82bc\u32e0\u420e", "\u91a8\ud939\ude32\ud969\uddc3\udbec\udf79\ud927\udeff\udbd1\udf35\u0acc\ud9b9\udcb7\udb4e\ude71\ud9ce\uded7\uda01\ude53\ud86b\ude65\ud985\udfa5\ud9c4\udc66",
        12, 60052, -401912973, -8158728761500459502L, 61665L, true, true, (char) 55136, (char) 55409,
        Double.longBitsToDouble(0x3fea05ade02f98b2L), Double.longBitsToDouble(0x3fb8993f37180d28L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 1, "\ud96c\uddaa\ud9f4\udfdf\ud8a0\uddea\ud95c\udd07\ud962\udf38\ud9aa\udd15", "\ubd3c\u5da0\u1ef4\u66ce\u52b4\uc634\u64c8\u45e1\u0568\uc408\ud7e3\u4580\ua793\u6aa5\u4073\uaca7\uc0b9\u833a\u3364\u95a5\ua16f\u0f3b\u3afa\ua7cd", "\u918c\ud939\ude32\ud969\uddc3",
        37, 41621, 1784171605, 907503972396409903L, -66081L, false, false, (char) 41621, (char) 3808,
        Double.longBitsToDouble(0x3fe5fb72d73c5ba5L), Double.longBitsToDouble(0x3fcbd8053ca6c89cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:-2147483648 |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 15, "\ud946\ude7d\uda63\udc07\udbb2\udee3\udbdf\udf8c\uda22\udf38\ud9aa\udd15\ud8f3\udf4a", "\u4b6e\u4286\u4b2a\u5990\u1b56\u467f", "\ud9b1\udfed\udb2b\udd07\ud8aa\ude9b\ud86f\ude43\ud955\udf15\ud9d9\udeee\ud955\udc3c\ud8dd\uddde\ud9a1\udc89\ud9a6\udeec\ue54b\ud88e\udd31",
        0, 68421, -2114692791, 6414296416502659852L, -41508L, true, false, (char) 20618, (char) 2952,
        Double.longBitsToDouble(0x3fcb3a20e838d560L), Double.longBitsToDouble(0x3fa7864c1f9fa800L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 3, "\ud84a\udfe6\ud9f4\udf73\ud89b\udfdc\udbda\ude66\udb39\ude83\ud99c\udfb1", "\ud4df\u2281\u41c7\u4b2a\u9ef6\uaebd\u64c8\u96e1\u0568\u5d37\u6863\u7aee\u3db6\u768e\u7a3a\u3899\u191c\u480e\u3364\u12a9\u51f1\u82bc\u32e0\u420e", "\u91a8\ud9e8\udd8a\ud884\ude16\udbec\udecd\ud927\udeff\udbd1\udf35\u0acc\ud9b9\udcb7\udb4e\ude71\ud9ce\uded7\uda01\ude53\ud86b\ude65\ud985\udfa5\ud9c4\udc66",
        12, 60052, -401912973, -8158728761496519662L, 61665L, true, false, (char) 1206, (char) 4727,
        Double.longBitsToDouble(0x3fe35248022b140dL), Double.longBitsToDouble(0x3fec9d5246e301a5L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 1, "\ud96c\uddaa\ud9f4\udfdf\ud8a0\uddea\ud95c\udd07\ud962\udf38\ud9aa\udd15", "\ubd3c\u5da0\u1ef4\ud551\u52b4\ub847\u1262\u45e1\u0568\uc408\ud7e3\u4080\ua793\u6aa5\u54c6\uc1ac\uc0b9\u833a\u3364\u95a5\ua16f\u0f3b\u3afa\ua7cd", "\u918c\ud939\ude32\ud969\uddc3",
        37, 97757, 1784171585, -8853802104151709979L, -66081L, false, false, (char) 16789, (char) 3808,
        Double.longBitsToDouble(0x3fe5fb72d73c5bb3L), Double.longBitsToDouble(0x3fcbd8053ca6c89cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 5, 13, "\uda69\udc7c\uda6e\udf56\udad1\ude2e\udaed\udcb7\uda22\udf38", "\u9a0d\ud4df\u2281\u8d4c\u4b2a\u9ef6\u7f53\u30c6\u45e1\u0568", "\ud899\udff1\ud86f\ude43\ud955\udf15\ud9d9\udf3b\ud955\udc3c\ud8dd\ude3d\ud9ef\udd6f\ud9a6\udf25\ud812\ude21\ud9a0\udd99\udae2\udf46\udbc5\udf8d",
        44, 57763, -454417047, 5879753591349164846L, -57969L, true, true, (char) 64409, (char) 24077,
        Double.longBitsToDouble(0x3fdbc0f1eddd3ae0L), Double.longBitsToDouble(0x3fe0700ac8e6dc85L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getLength||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|compareChildNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int|new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int,java.lang.Object|new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|createPath|org.apache.commons.jxpath.JXPathContext|new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|createPath|org.apache.commons.jxpath.JXPathContext,java.lang.Object|new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|equals|java.lang.Object|new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getBean||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getImmediateNode||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getImmediateValuePointer||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getName||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getPropertyCount||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getPropertyIndex||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getPropertyName||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getPropertyNames||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|hashCode||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
    "M|org.apache.commons.jxpath.ri.model.beans.PropertyPointer|getLength||new:org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.JXPathBeanInfo",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
