package org.apache.commons.jxpath.ri.model.dom;
import org.junit.Test;
import static org.junit.Assert.*;
public class DOMNodePointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 17, 11, 8, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042742331260282162L, -56509L, true, false, (char) 55590, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 17, 18, 2, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9f4\udcd7\ud8b9\udd40\ud8c4\udd61", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042742331260282162L, 10673L, true, false, (char) 55582, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 16, 11, 8, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud81b\ude07", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042742331260282162L, -56509L, true, false, (char) 55590, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 17, 11, 8, "\uda9d\udd51\udaf0\uddad\ud94a\ude3a\ud92e\udce8\ud93b\udea2\ud8f1\udda1\uda5f\udce9\udbfe\uded7\ud881\uddad\uda97\udf2f\udb1d\udc5f\uda0a\udc30\udbf5\udc18\udbd0\udd1a\ud90c\udd25\udbd8\ude9c", "\u3a66\u6ed8\u3ce3\u18a4\u3f89\ub3ef\u4639\u1b3f\u01fc\u9804\u12a5\ua2e1\u0cef\ubaba\u4b91\u2be8\u036d\u1522\u1871\ub430\u04bd\u76f2\u75ef\u6afd\u691d\u9701\u6e4d\ub22a", "\ud90b\ude31\udb89\ude65\udae6\udc77\u9b12\udb44\ude66\uda7e\udc1b\ud991\udddd\ud9b4\udcc0",
        14, 86018, 27804637, 473025074962165343L, 5861L, true, true, (char) 23466, (char) 65098,
        Double.longBitsToDouble(0x3fcd92d992e60314L), Double.longBitsToDouble(0x3fe8b4c0b5ad30a7L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 14, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042742331260282162L, -56509L, true, false, (char) 55590, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 8, "\ud87d\uddc0\udb48\udefd\ud868\udfdb\uda89\udd35\ud816\udf80\uda46\ude27\ud9e5\udffa", "\u48db\u9b8f", "\udae3\udf90\ud93b\udd89\ud844\udccf\ud85b\udf8b\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, 343474310737287834L, -56509L, true, false, (char) 55590, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 13, "\udaff\udcf3\udb44\udc41", "\u6aab\u518f\ucaa2\ua620\u18f5\u48db\u9b8f\u3b38\ud619\ua812", "\ud9b0\udfd3\udbe0\udf84\ud952\udc0c\udbe0\udc53\ud9d6\udd32\udb1e\udd81\udaf7\udd1c\udb2c\udd93\ud91c\udcff\u6c80\ud8c7\ude96\ud83c\udffe\udb45\udc11\ud94a\udf0b\ud800\udcbe\ud849\udfc0\ud9d5\uddff\ud87e\udccc\udb48\udf28\ud8c6\udd91\udbfd\udee8\uda82\udddc\udb70\udd77\udb2e\udecd\ud99d\udd3b\uda62\udfd7\ufc38",
        19, 10425, -548020276, 5941460707804895995L, 84419L, false, true, (char) 56954, (char) 41862,
        Double.longBitsToDouble(0x3fe9582eca561ac3L), Double.longBitsToDouble(0x3fde8ab143e0d32aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 4, "\u4644\udb44\udc41\ud868\udfdb\udbe4\udd82\ud8f3\uddae\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\uda41\udfc6\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042645939309733426L, -56509L, true, false, (char) 27283, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 4, 8, "\ud89b\udf73\udb44\udc41\ud868\udfdb\ud9ea\udd06\udac8\ude92\ud8f1\udda1\ud9eb\ude0f", "\u418b\u9b8f", "\uda37\udc9d\udaf0\udd62\ud844\udccf\ud86e\udcd5\udb14\ude25\u440e\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042741966188062002L, -56509L, true, false, (char) 55590, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fecbba1d748d4bbL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 17, 1, 8, "\ud87d\ude2f\udb44\udc41\u91ab\udb9d\udda3\ud9cb\udfd7\ud8f1\udda1\ud9eb\uddbc", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042742331713266994L, -56509L, true, false, (char) 55590, (char) 63293,
        Double.longBitsToDouble(0x3fe93021f5268277L), Double.longBitsToDouble(0x3fded2a3f649a9a0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.String:\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud9eb\ude60 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 13, 8, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud9eb\ude60", "\u8d01\ub44d", "\uda37\udc9d\ud93b\ude05\ud878\udc29\udaa9\udcb5\ud9f5\ude82\ud952\udc0c\ud9d4\udc4d\ud9d6\udd32",
        33, 72875, 1972880151, 274670437197606841L, -56624L, false, true, (char) 55590, (char) 40599,
        Double.longBitsToDouble(0x3fcfcf485e5a70ecL), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 4, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\ud945\udd33\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\udb67\udc46\udb58\ude1b\uda32\udc08\ud9d6\udd32",
        3, 67995, -694385969, -1050155268719519026L, -56509L, true, false, (char) 2095, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743aa91a91cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 8, "\udb66\udc0c\udb60\ude3e\udaa1\uddc2\uda83\udc99\udb25\ude99\ud8f1\udda1\ud9eb\ude0f", "\uccb0\u2caf", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9c5\udca6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, -186940721, 8338578545229587426L, 60878L, true, true, (char) 40094, (char) 12561,
        Double.longBitsToDouble(0x3fe93021f2268277L), Double.longBitsToDouble(0x3fd867432e91a91cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 14, 8, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\udb52\udfc7\ud914\ude53\ud93f\udcb8", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\udb54\udc62\ud9cf\uddc5\ub897\ud94a\udc85\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042742331269784882L, -56509L, true, false, (char) 52632, (char) 24533,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 16, 4, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud878\udfb6", "\u48db\u9b8f\u2a08\u403b", "\udb6a\udedd\udbee\udf13",
        -2, 32640, 43337801, 8131559789587289533L, -4817L, false, true, (char) 52309, (char) 34432,
        Double.longBitsToDouble(0x3fde376d8e265658L), Double.longBitsToDouble(0x3fe290b6a87ea619L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 17, 11, 8, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042742331260282162L, -56509L, true, false, (char) 55590, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\ud8ea\udfa0\ud8ae\udc10\uda71\ude5f\ud808\uddde\ud9e5\ude94\ud8f1\udda1\uda77\udcf4 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 12, 11, "\ud8ea\udfa0\ud8ae\udc10\uda71\ude5f\ud808\uddde\ud9e5\ude94\ud8f1\udda1\uda77\udcf4", "\u48db\u9b8f", "\ud85a\udfce\udbc3\udd3f\ud844\udcc6\ud9cf\uddcc\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        4, 38494, 1926988495, -1042742331260282162L, -56509L, true, true, (char) 55623, (char) 40599,
        Double.longBitsToDouble(0x3fcacac7c26fe1f4L), Double.longBitsToDouble(0x3fd3936d0e91a91cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 3, 2, 18, "\ud873\udf0a\udb02\uddfb\u6e70", "\u4363\u540c", "\ud99c\udef2\udb20\ude21",
        53, 86324, -259578489, -7984270204213024156L, 13395L, true, false, (char) 55617, (char) 7549,
        Double.longBitsToDouble(0x3fdbd706c8957066L), Double.longBitsToDouble(0x3fe679d7d76072dbL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=null\012",
        Z.run(T, 2, 11, 14, 8, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, -1042742331260282162L, -56509L, true, false, (char) 55590, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 16, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16", "\u1b7f\u0cbc\u96b1\ubf0c\u0798\u3f97\u27f4\ubd26\u78ef\u3519\u8e4d\uabf4", "\udb1e\udd81\udaf7\udd1c\udb2c\udd93\udb70\udf69\ud9f4\udeef\ud90c\udc5b\ud943\udc6e\ud9da\uddd1\udad7\udd05\uda9f\udded",
        40, 83694, -183238396, 7770300112071015812L, -12753L, false, true, (char) 24201, (char) 35108,
        Double.longBitsToDouble(0x3fdefefa887bd202L), Double.longBitsToDouble(0x3f48ba874e556800L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 6, 14, "\uda74\udc1b", "\u43f0", "\u4963",
        12, 76132, 335216941, -1075659643228163718L, 9156L, false, false, (char) 15063, (char) 55016,
        Double.longBitsToDouble(0x3fa6e82ea8c02950L), Double.longBitsToDouble(0x3fc7ae1b268c0000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 3, "\ud87d\uddc0\udb44\udc41", "\u6c69\u58e5\u45f8\uc85e\u769c\u48db\u9b8f\u0798\u6878\u11ce\u8939\u7379\u3519\u8e4d\u3a66\ua33c\u784b\u18a4\u3f89\u50bb\u46cc\u348b", "\ud8c7\udec7\uda7b\udc2f\ud90e\udd71\ud84a\udc64\ud826\udc9e\udbf7\ude29\ud911\udddc\ud881\udca3\u3b7a\ud8d7\udfb4\udacb\udddf\udb22\ude0f",
        -5, 73436, -920848035, -6715099382583554761L, -18159L, false, true, (char) 17349, (char) 52955,
        Double.longBitsToDouble(0x3fdd288e437dd5b8L), Double.longBitsToDouble(0x3fce0662bcf09bbcL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 5, 11, "\ud871\udd5c\udb44\udc41\ud868\udfdb\uda89\udd35", "\u1405\ua20b\ud0ed\u4a63\u9b8f\u0798\u3f97\u0fee\u5c31", "\ud8eb\udeb4\ud952\udc0c\uda8c\ude29\ud9d6\udd32\udb1e\udd81\udaf7\udd1c",
        50, 20632, -654845234, 8563785496091470307L, 15282L, false, false, (char) 23396, (char) 414,
        Double.longBitsToDouble(0x3fd86743ad51a91cL), Double.longBitsToDouble(0x3fede0c06f82ba1cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 8, "\ud87a\ude4e\udbb9\udfc5\udb68\udd11\uda8f\udc28\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f\u0798\u3f97\u7b30\u8939\u7379\u3519\u8e4d\u3a66\ua33c\u784b\u18a4\u3f89\u32f0\u4639\u348b", "\ud9da\uddd1\udad7\udd05\ud86b\udd93\ud849\udfc0\uda97\ude00\uda50\udef6\udb2f\udd52\udb1e\udc68\ud9c4\ude6f\ud934\udf2b\udbf9\udd81\ud937\udfb2",
        37, 48295, -457972347, 7779586965793440313L, 52746L, false, true, (char) 10144, (char) 59321,
        Double.longBitsToDouble(0x3fcdadca0fabb6acL), Double.longBitsToDouble(0x3fd9db21b4b95692L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 6, 18, 8, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\uda13\udc6f", "\u48db\u9b8f", "\uda37\udc9d\ud9c1\ude08\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 26843, 1926988434, -1042742331260282162L, -56509L, true, false, (char) 55590, (char) 40599,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 16, 8, "\ud87d\uddc0>\000\uda71\udf18\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8d0\uddb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 67995, 33487, -654845234L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe9302000008277L), Double.longBitsToDouble(0x3fd860000e91a91cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 0, "\ud86f\udcc0\udafc\uddfd\ud925\uddc3\ud8aa\udf77\ud9c2\udfda\ud8f1\udda1\ud9eb\ude0f\ud94a\udd8b\ud8d8\udf6e\ud995\ude4e\ud86a\ude9c", "\u7b30\u8939\u7379\u7c2e\u8e4d\u4502\u166b\u19ec\u7e09", "\udaa7\ude85\ud85e\udc81\udbef\udc89\ud943\udc6e\ud9da\uddd1\udb29\uddad\ued7d\ud855\udf9d\ud970\uddae\uda50\udef6\u0f7d\udb8a\uddad\ud8f8\ude67",
        11, 90281, 1639963862, 7241184250025579592L, -55594L, true, false, (char) 24366, (char) 48265,
        Double.longBitsToDouble(0x3fe9da18407a86d6L), Double.longBitsToDouble(0x3fd6b06d54262cceL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 9, 5, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\uda5a\udc01\uda58\udd99\ud9eb\ude0f", "\u48db\u9b8f", "\uda6a\udddb\udb51\ude10\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        3, 23019, 1926988294, -1042742331260282162L, -56509L, true, false, (char) 55590, (char) 55900,
        Double.longBitsToDouble(0x3fe930214f268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 8, "\ud824\udff3\ud87a\udc56\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\udbe2\udff0\ud888\udea3\ud952\udc0c",
        58, 96516, 1953916904, 1143341822498258129L, -56509L, true, false, (char) 62246, (char) 40744,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 8, "\ud958\udf4d\udb93\ude94\ud868\udfdb\uda89\udd35\ud9c2\udf16\uda52\udfb2\ud981\udde1", "\u48db\u9b8f", "\ud871\udd7f\ud93b\ude0f\ud8cb\udf72\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9a8\udd5c",
        21, 34784, -988584716, 9014526837660261653L, -56509L, true, false, (char) 55590, (char) 29595,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 1, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1", "\u18ee\u3412\u930e\u32a8\u0fc7\u2481\u89aa\u7379\u3519\u8e4d\u3a66\u1992\uab6e\u7226\u45a2\u27bb\ua607\uc543\ubf3b\ub192\uc4b8", "\ud849\udfc0\ud9d5\uddff\uda50\udec1\ud8d1\udcc2\udb1e\udfee\ud8ac\udea2\ud9fd\ude8a\ud8ca\udddc",
        -2, 39727, 1425848156, 248882149940865665L, -2674L, false, true, (char) 52099, (char) 60103,
        Double.longBitsToDouble(0x3fcf297ade858b44L), Double.longBitsToDouble(0x3fed20aa6c2802c3L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 4, 0, "", "\uac60\u43f0", "\ud8c4\udd61\ub5be\ud8d0\udd68",
        0, 32473, 29050, 2102095807745828231L, 96508L, false, false, (char) 0, (char) 47615,
        Double.longBitsToDouble(0x3fa6e82ea8c02950L), Double.longBitsToDouble(0x3fdbd70d93477066L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 2, 18, 12, "\ud87d\uddc0\udb12\ude41\ud868\udfdb\uda89\udd35\ud9f4\udcd7\ub85c\ud981\udfeb", "\u48db\u9b8f", "\uda39\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        40, 68066, 1926988495, -1042742331260282162L, 15282L, false, false, (char) 23396, (char) 414,
        Double.longBitsToDouble(0x3fd86743ae91a91cL), Double.longBitsToDouble(0x3fe239e9defa10cbL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 2, "\ud90c\uddac\ud963\udd4d\ud868\udfdb\uda89\udd35\ud9f4\udcd7\uda82\udf25\ud8c4\udcee", "\u9f89\u9c28", "\uda37\udc9d\ud9b3\udfa0\ud846\udf33\ud8f2\udfe9\ud904\udfa9\ud951\udf88\udbe0\udc53",
        40, 37820, 1520870127, 2139719738859310652L, 41997L, true, true, (char) 53745, (char) 55582,
        Double.longBitsToDouble(0x3fbfa9867a3739f0L), Double.longBitsToDouble(0x3fe2e5ddb512fb80L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 1, 0, 8, "\ud87d\uddc0", "\u43f0\u7098\uadd9\uadd4", "\ud99c\ude5a\udb1d\udc5f",
        -4, -1000, 0, 0L, 3155L, true, false, (char) 53386, (char) 7457,
        Double.longBitsToDouble(0x3fdbd70d90017066L), Double.longBitsToDouble(0x3fe00000076072dbL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 8, "\udab7\udc6b\uda5e\ude44\ud94a\ude62\udbec\udf0b\ud87a\udc46\ud8f1\udd42\uda5f\udce9\udbfe\uded7\ud881\uddad\uda97\udf2f\udb1d\udc5f\uda0a\udc30\udbb0\uddd7\ud828\udfcb\ud8d7\ude3f\udbd8\udef1", "\u3a66\u4844\u6184\ua561\u6f6d\ub3ef\u4605\u4095\u0546\u9804\u12a5\uaca8\u03c3\ubaba\u4ef4\u2c2c\u036d\u1522\u1871\u5374\u04bd\u76f2\ud331\u71e6\u4384\u17b4\u2ac1\u5618", "\ud9cb\udfdd\ud8d3\udc5d\udae6\udc77\u9b12\udb44\ude66\uda7e\udc1b\ud98f\udd78\udb3b\udd19\uc8e5\u3459\u0bf6",
        28, 97375, -643952183, 7523934409920740845L, 33218L, true, false, (char) 10074, (char) 18235,
        Double.longBitsToDouble(0x3fe5d21eef5f49fcL), Double.longBitsToDouble(0x3fc572ca4570c508L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\ud87d\uddc0\udb48\udefd\udb28\udc61\uda89\ude15\ud816\udf80\uda46\ude27\ud9e5\udffa |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.String:\ud87d\uddc0\udb48\udefd\udb28\udc61\uda89\ude15\ud816\udf80\uda46\ude27\ud9e5\udffa |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 7, "\ud87d\uddc0\udb48\udefd\udb28\udc61\uda89\ude15\ud816\udf80\uda46\ude27\ud9e5\udffa", "\u48db\u9b8f", "\udae3\udf90\ud93b\udd89\ud844\udccf\ud8bc\uddfd\ud857\udfd6\ud951\udf64\udbe0\udc53\ud9d6\udd32",
        3, 67995, 1926988495, 343474310737287910L, 33330L, true, false, (char) 8946, (char) 61795,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 4, "\u4644\udbde\udc4e\ud868\udfdb\udbe4\udd82\ud8f3\uddae\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f\u0798\u3f97\u7b30\u8939\u5078\u5044\uafc8\u1b39", "\udb1e\udd81\udaf7\udd1c\udb2c\udd93\ud87c\udd10\u30f2\udb0c\udc76\uda8c\udffc\udb82\udf46\udad7\udd71\ud800\udcbe\ud85d\udd43\ud9d5\uddff",
        41, 39520, 2052454454, -9189221620008956152L, 3256L, true, false, (char) 20595, (char) 48207,
        Double.longBitsToDouble(0x3fe139acedcfc6feL), Double.longBitsToDouble(0x3fc897af097f0cd0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 14, 14, 0, "\ud87d\uddc0>\ud866\udc72\ud945\udd33\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\udb67\udc46\000\000\000",
        -5, 67995, -694385969, -654845234L, -56509L, true, false, (char) 2095, (char) 40574,
        Double.longBitsToDouble(0x3fe93021f7268277L), Double.longBitsToDouble(0x3d9a91c000000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 17, 11, 8, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\ud9c2\udf16\ud8f1\udda1\ud9eb\ude0f", "\u48db\u9b8f", "\uda37\udc9d\ud93b\ude05\ud844\udccf\ud9cf\udda6\ud8eb\udeb4\ud952\udc0c\udbe0\udc53\ud9d6\udd32",
        31, 67995, 1926988495, -1042742330931291442L, -56509L, true, false, (char) 55590, (char) 31383,
        Double.longBitsToDouble(0x3fbea1b7bd5bb870L), Double.longBitsToDouble(0x3fd86743ae91a91cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.String:\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35&quot;\ud8f1\udcd9\ud9eb\ude60 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 13, 8, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\"\ud8f1\udcd9\ud9eb\ude60", "\000\ub44d", "\uda37\udc9d\ud93b\ude05\ud878\udc29\udaa9\udcb5\ud9f5\ude82\ud952\udc0c\ud9d4\udc20\ud9d6\udd32",
        33, 72875, 1962984215, 216172780762623744L, -56624L, false, true, (char) 5845, (char) 0,
        Double.longBitsToDouble(0x3fcfc00000000000L), Double.longBitsToDouble(0x3fd86743a001a91cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.String:\ud87d\ude08\udb44\udc41\ud868\udfdb\uda89\udd35&quot;\ud8f1\udcd9\ud9eb\ude60\ud94a\udd8b\ud801\udc4c\000\udb09\udea7\uda0a\udc30\ud86f\ude16\udbe2\ude47 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 13, 8, "\ud87d\ude08\udb44\udc41\ud868\udfdb\uda89\udd35\"\ud8f1\udcd9\ud9eb\ude60\ud94a\udd8b\ud801\udc4c\000\udb09\udea7\uda0a\udc30\ud86f\ude16\udbe2\ude47", "\uaeb9\uc705\u3a66\u528d\u5278\u7216\uc69d\u23d9\u338e\u6f8c\ub8be\u75cb\u768b\u00c8\000\ud3a7\u9141\u01a2\u975a\u0ca6\u0599\u59a9", "\ud9fd\udc13\uc008\ud892\udd96\udbe2\udf55\uda4a\udde5\uda1c\udd0b\ud81d\udd6c\ud9cc\udfac\ud965\udc18\ud8a6\udd92\udad1\udedd\ud978\udd0f\uda33\udd8f\ud921\udfa4\uda6a\udd96\ud8f6\udf13\uccf4\ud919\udc5a\udbbe\udfc9\ud88f\ude9d\udbf2\udf3e\udaad\udeb8",
        18, 47240, -2124320706, -8570587788431082968L, 45748L, true, false, (char) 14751, (char) 56756,
        Double.longBitsToDouble(0x3faca4d284d35690L), Double.longBitsToDouble(0x3fbdaf27ff4fcfa8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35&quot;\ud8f1\udcd9\uda63\uded7\uda08\ude5a\udbce\ude06\udb81\ude6d\udb23\udce2\uda0a\udc30\ud83b\udebc\uda37\udc9d\ud90e\ude80\u3cce\ud907\udc31\ud9f5\ude82\ud896\udc0e\ud9d4\udc20\ud944\udfc8\uda91\udfc3\uda57\udf09\ud837\udda3\ud872\udf86\ud938\ude20\udaec\udfdf\uda7d\udd59\udbac\udef1\u4bdb\u2d80 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 17, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\"\ud8f1\udcd9\uda63\uded7\uda08\ude5a\udbce\ude06\udb81\ude6d\udb23\udce2\uda0a\udc30\ud83b\udebc\uda37\udc9d\ud90e\ude80\u3cce\ud907\udc31\ud9f5\ude82\ud896\udc0e\ud9d4\udc20\ud944\udfc8\uda91\udfc3\uda57\udf09\ud837\udda3\ud872\udf86\ud938\ude20\udaec\udfdf\uda7d\udd59\udbac\udef1\u4bdb\u2d80", "\u4b10\u0b88\u7caa\u6554\ubc79\u1715\ub946\u4393\u96f2\u9c21\u6a1e\ucefb\u379a\u1313\u1c9b\u8cd4\u06be\uc000", "\udaa5\ude31\ud806\udc6a\udbfe\udfdb\ud996\uddbd\udbfe\udca1\uda97\udd6d\ud9b4\udeb1\ud951\udd22\udbec\udd73\udba1\udde4\uda0e\udde3\udb55\udeb9\ud868\udc6e\uda0f\udf5e\udbf6\udea8\uda26\udf36\ud821\udcce\uda7e\udedf\ud9b6\udeda\udbc7\udf19\ud980\udc92\ud9d5\udf66\ud9ed\ude9a\ud8e1\udfad\uda58\udc65\ud84c\udc3d\udbd7\udea8\udb4e\uded6\ud887\udd7d\udb68\udfbc\ud8eb\udfd7\uda92\udeda\udbfd\udefb\ud922\udea1\ud93e\udfa5\ud871\ude5a\ud854\udf5f\ud91f\uddc5\uda54\udc7f\u4f2f\ud921\udc74\ud93b\udcb1\uda8e\udf3c\ud925\udeb1\uda3c\udd33\ud83a\ude02\ud878\uddf7\ud9eb\udcde\ud95c\udeb3\uda67\udcc8\ud9ba\udf4f\udbe9\udc87\ud895\udef8\ud9db\udc49\ud929\udf6d\ud890\udd8c",
        55, 71464, 1139035745, -8822446770030177191L, 56023L, false, false, (char) 37335, (char) 62990,
        Double.longBitsToDouble(0x3fb596ef93dac4f0L), Double.longBitsToDouble(0x3fddafc77d8963b6L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:\ud9b7\uddbd\udb44\udc41\ud868\udfdb\uda89\udd35&quot;\uda05\udfd6\udb63\udef3 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.String:\ud9b7\uddbd\udb44\udc41\ud868\udfdb\uda89\udd35&quot;\uda05\udfd6\udb63\udef3 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 8, "\ud9b7\uddbd\udb44\udc41\ud868\udfdb\uda89\udd35\"\uda05\udfd6\udb63\udef3", "\000\ub44d\u0798\u3f97\u7b30\u8939\ud66f", "\ud952\udc0c\ud9d4\udc20\ud9d6\udd32\udbce\udc58\uda56\ude8b\ud87e\uddfc\ud8dc\udc2d\udbfc\ude40\ud87a\udfe6\udb22\udeeb\ud9b3\udcd4\000\000\u00fe\ud9b5\uded9\uda50\udef6\ud9be\udfdf\uda46\udecc\udbf9\udca6\ud9ad\udeb9\uda65\ude91\udacd\udc8a",
        52, 22567, 248575028, 8568428047536436241L, -2415L, false, true, (char) 8021, (char) 48451,
        Double.longBitsToDouble(0x3fb393d665dcd280L), Double.longBitsToDouble(0x3fe3880fffc2e980L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35&quot;\ud8f1\udcd9\uda63\uded7\uda0b\ude5a\udbce\ude06\udb81\ude6d\udb23\udce2\uda0a\udc30\ud83b\udebc\ud8d6\udcac\ud90e\ude80\u3cce\ud907\udc31\ud9f5\ude82\ud896\udc0e\ud9d4\udc20\ud944\udfc8\uda91\udfc3\uda57\udf09\ud837\udda3\ud872\udf86\ud938\ude20\udaec\udfdf\uda7d\udd59\udbac\udef1\u4bdb\u2d80\ud989\udee7\ud9c6\udc5e\udab1\udd66\udba1\udfc4\uda23\udd3d\ud868\udc39\ufe7b\ud8c3\udf66\uda12\udcc0\udac6\udfa2 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 17, "\ud87d\uddc0\udb44\udc41\ud868\udfdb\uda89\udd35\"\ud8f1\udcd9\uda63\uded7\uda0b\ude5a\udbce\ude06\udb81\ude6d\udb23\udce2\uda0a\udc30\ud83b\udebc\ud8d6\udcac\ud90e\ude80\u3cce\ud907\udc31\ud9f5\ude82\ud896\udc0e\ud9d4\udc20\ud944\udfc8\uda91\udfc3\uda57\udf09\ud837\udda3\ud872\udf86\ud938\ude20\udaec\udfdf\uda7d\udd59\udbac\udef1\u4bdb\u2d80\ud989\udee7\ud9c6\udc5e\udab1\udd66\udba1\udfc4\uda23\udd3d\ud868\udc39\ufe7b\ud8c3\udf66\uda12\udcc0\udac6\udfa2", "\u6a1e\ucefb", "\u2473\udbd7\udfba\udbf9\ude28\ud90b\ude57\u4bd0\udba7\uddbf\udaa5\ude31\ud806\udc6a\udbfe\udfdb\ud996\uddbd\udbfe\udca1\uda97\udd6d",
        4, 827, 1258835208, -3028573582998641382L, -46859L, true, false, (char) 19241, (char) 9245,
        Double.longBitsToDouble(0x3fe2fede3df6e56dL), Double.longBitsToDouble(0x3fdf4cb9c133c632L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=java.lang.String:\021\000\000\uda89\udd18&quot;\ufc00\000 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 13, 13, "\021\000\000\uda89\udd18\"\ufc00\000", "\000", "\ud83b\udeb8\udbd9\udd8e\ud930\udd78",
        55, 55169, 484324559, -3458559064023808000L, 53021L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe8001800000000L), Double.longBitsToDouble(0x3e38000000000000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:\ud9b7\uddbd\udb43\udd41\uda53\udd28\uda89\udd98&quot;\uda05\udfd6\udb63\udecf\uda78\udfef\udb08\udd26\ud800\udce1\udb23\udd1d\uda0a\udc30\ud83b\udebc\uda37\udc9d\ud93b\ude05\ud878\udc29\udaa9\udcb5\ud9f5\ude82\ud952\udc0c\ud9d4\udc20\ud909\ude2d\udbce\udc58\uda56\ude8b\ud87e\uddfc\ud8dc\udc2d\udbfc\ude40\ud87a\udfe6\udb22\udeeb\ud9b3\udcd4\ud8db\udd2d\u640e\u00fe\ud9b5\uded9\uda50\udef6\ud9be\udfdf\uda46\udecc\ud8ab\udc1f\uda1f\ude48\ud9de\udd9a |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.String:\ud9b7\uddbd\udb43\udd41\uda53\udd28\uda89\udd98&quot;\uda05\udfd6\udb63\udecf\uda78\udfef\udb08\udd26\ud800\udce1\udb23\udd1d\uda0a\udc30\ud83b\udebc\uda37\udc9d\ud93b\ude05\ud878\udc29\udaa9\udcb5\ud9f5\ude82\ud952\udc0c\ud9d4\udc20\ud909\ude2d\udbce\udc58\uda56\ude8b\ud87e\uddfc\ud8dc\udc2d\udbfc\ude40\ud87a\udfe6\udb22\udeeb\ud9b3\udcd4\ud8db\udd2d\u640e\u00fe\ud9b5\uded9\uda50\udef6\ud9be\udfdf\uda46\udecc\ud8ab\udc1f\uda1f\ude48\ud9de\udd9a |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 8, "\ud9b7\uddbd\udb43\udd41\uda53\udd28\uda89\udd98\"\uda05\udfd6\udb63\udecf\uda78\udfef\udb08\udd26\ud800\udce1\udb23\udd1d\uda0a\udc30\ud83b\udebc\uda37\udc9d\ud93b\ude05\ud878\udc29\udaa9\udcb5\ud9f5\ude82\ud952\udc0c\ud9d4\udc20\ud909\ude2d\udbce\udc58\uda56\ude8b\ud87e\uddfc\ud8dc\udc2d\udbfc\ude40\ud87a\udfe6\udb22\udeeb\ud9b3\udcd4\ud8db\udd2d\u640e\u00fe\ud9b5\uded9\uda50\udef6\ud9be\udfdf\uda46\udecc\ud8ab\udc1f\uda1f\ude48\ud9de\udd9a", "\u5967\u5dc3\ub7e9\ud128\u192e\u9f14\uccfd\uc77c\u1606", "\udbc1\ude4f\udabd\udfe2\uda33\udc67\ud9f2\udc92\ud80b\udd52\udab7\udd45\udacb\ude6f\udbbc\udc89\ud92f\ude2a\ud9a8\ude5e\udafc\udc29\ud82a\udfbf\udb73\udd34\ud9a0\udd48\uda10\ude21\udad6\uddc5\ud8ae\udce8\ud91c\udebc\ud9c3\udc60\ud8fd\udea4",
        15, 11694, -301056845, -2291228125184236131L, -57991L, true, true, (char) 170, (char) 21463,
        Double.longBitsToDouble(0x3fea54a68d6393bcL), Double.longBitsToDouble(0x3fd685a101c3b712L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=java.lang.String:\021\000\000\uda89\udd18&quot; |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 13, 13, "\021\000\000\uda89\udd18\"", "\u5bda", "\udb23\udd1d\uda0a\udc30\ud83b\udeb8\udbd9\udd8e\ud930\udd78\ud878\udc29\udaa9\udcb5\ud9f5\ude82\udb86\udc06",
        8, 30300, -1522117187, 5738993892859052274L, -38816L, false, false, (char) 0, (char) 768,
        Double.longBitsToDouble(0x3fdaa8cfcf776cd6L), Double.longBitsToDouble(0x3fe334a041885c46L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.w3c.dom.Node,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:org.apache.commons.jxpath.ri.model.NodePointer,java.lang.Object",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|testNode|org.apache.commons.jxpath.ri.model.NodePointer,java.lang.Object,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|asPath||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|attributeIterator|org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|childIterator|org.apache.commons.jxpath.ri.compiler.NodeTest,boolean,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|compareChildNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createAttribute|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int,java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equalStrings|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equals|java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|escape|java.lang.String|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|findEnclosingAttribute|org.w3c.dom.Node,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getAbstractFactory|org.apache.commons.jxpath.JXPathContext|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.w3c.dom.Node,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:org.apache.commons.jxpath.ri.model.NodePointer,java.lang.Object",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|testNode|org.apache.commons.jxpath.ri.model.NodePointer,java.lang.Object,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
