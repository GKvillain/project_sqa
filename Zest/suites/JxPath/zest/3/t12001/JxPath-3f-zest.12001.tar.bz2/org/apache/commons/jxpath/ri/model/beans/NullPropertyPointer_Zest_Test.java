package org.apache.commons.jxpath.ri.model.beans;
import org.junit.Test;
import static org.junit.Assert.*;
public class NullPropertyPointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 1, 14, 11, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\u1a1a\u161f\ua7f0\u36d9\u5fdc\u62b7\u9fd1\ucc02\ubad3\u66d7\u0ab9\u780a\u5abd\ua69a\u9825\u34aa\u4396\u8f8c\u4ec2\u0fd4\ua744\u7253\u6686\u921b\u3fc5\ua7ba\u95e3\uaa0b\uae88\u7d3a\u4097\u8d8b\u7b1a\u1c34\u7921", "\uda11\udf98\udbeb\ude81\uda28\udfd5",
        48, 38643, -414083405, -6923915626359567098L, 23317L, true, false, (char) 37357, (char) 28643,
        Double.longBitsToDouble(0x3fc10ce27b1b6374L), Double.longBitsToDouble(0x3faee604f97baa70L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 1, 7, 11, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\u1a1a\u161f\ua7f0\u36d9\u5fdc\u62b7\u9fd1\u65a3\u01a8\u66d7\u0ab9\u780a\u5abd\ua69a\u9825\u34aa\u4396\u8f8c\u4ec2\u0fd4\ua744\u7253\u6686\u921b\u3fc5\ua7ba\u95e3\u5194\uae88\u7d3a\u4097\u8d8b\u7b1a\u1c34\u7921", "\uda11\udf98\udbeb\ude81\uda28\udfd5",
        48, 38643, -414083405, -6923915626359567098L, 23317L, true, false, (char) 37357, (char) 28643,
        Double.longBitsToDouble(0x3fc10ce27b1b6374L), Double.longBitsToDouble(0x3faee604f97baa70L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=java.lang.Integer:0 |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 2, 14, 11, 4, "\ud858\udc37\ud8b6\udee4\udbca\udd24\u840a\ud8ae\udd17\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260", "\ud914\udef9\udb49\udd70\u7304\uda99\udcae\uda2d\udc60\u5dd1\ud982\ude0c\ud95a\udddf",
        -2, 81736, -1134439688, 7721394996520315707L, 65301L, true, true, (char) 13016, (char) 17658,
        Double.longBitsToDouble(0x3fd35a67b4c15b44L), Double.longBitsToDouble(0x3fe13f14eb4c14c2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 1, 14, 11, 4, "\uda04\uddc6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\uda4e\ude1e\udb5c\udc1e", "\u4260\u2aac", "\udbf1\udc2b\udbf1\udfb7\uda99\udcae\uda2d\udc60\u5dd1",
        -5, 71946, 1874652003, 1467438866190718200L, 58523L, true, false, (char) 56652, (char) 34039,
        Double.longBitsToDouble(0x3fe0ec65dec3be37L), Double.longBitsToDouble(0x3fd5ca67b957893aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.JXPathAbstractFactoryException:org.apache.commons.jxpath.JXPathAbstractFactoryException: Factory null reported success creating object for path: /* but object was null.  Terminating to avoid stack recursion. |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 1, 16, 15, 6, "\uda03\ude53\udb7c\udd74\uda7e\udd37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\udad3\udef1\udbf3\uddd9\ud9c0\udd99\udb62\udf69\udae1\udeb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u642e\ua2c4\u8987\u3066\u895f\u5fdc\u62b7\u9fd1\ucc02\ubad3\ucfb7\ud2f6\u22f3\u2cde\ua6e4\u9825\u34aa\ub953\u042b\u4ec2\u3378\ud366\u14f3\u667f\u18ec\u1554\u12a7\u6272\u4541\u4ed9\u2cf9\ua960\u4ef7\u3397\u1c34\u7921", "\uda11\udf98\ud809\udf4a\udb26\udc55",
        16, 38643, -414083405, -6923915628463933942L, 42797L, false, true, (char) 54171, (char) 43024,
        Double.longBitsToDouble(0x3fc725ec5e5ee880L), Double.longBitsToDouble(0x3fc207d919385facL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 11, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\udb35\udc45\ud8ae\udcdc\udb1e\udc21\ud901\udcc7\udbf3\ude0f\uda1f\ude27\udb52\ude42\udac6\udfb9\udb5c\udcbf", "\u4260\u9733\u7d78\u38e0\u3493\u1a1a\u161f\u9b4c\u0d73\u5fdc\u3f6c\u0431\ucc02\ubad0\u66d7\u0ab9\u481b\u0f63\u6d6b\u0f16\u4209\u80e9\ucde1\u4ec2\u0fd4\ua744\u0851\u1c90\u921b\u3fc5\ua7ba\u95e3\uaa0b\uae88\u7d3a\u4097\u283b\u143f\u1c34\u7921", "\uda11\udf98\udbeb\ude81\uda28\udfd5\uda66\udc49\ud97c\ude69\uda7d\udd3e\ud940\uddc2\ud943\udead\udbd9\udc39\ud893\udc22\ud936\udeb5\udbe4\udd49\ud827\udda9",
        10, 11422, -1163455427, 8984601642207697451L, -1532L, true, true, (char) 40041, (char) 35774,
        Double.longBitsToDouble(0x3fd78bdbc23847a4L), Double.longBitsToDouble(0x3fe571efd96beac8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 4, "\uda9a\udcf6\udbe3\udf27\uda6b\ude42\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\ud892\udc3e\udad5\ude53\udb62\udeab\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\u1a1a\u161f\ua7f0\u36d9\u5fdc\u62b7\u9fd1\ucc02\ubad3\u66d7\u0ab9\u780a\u5abd\ua69a\u9825\u34aa\u4396\u8f8c\u4ec2\u0fd4\ua744\u7253\u6686\u921b\u3fc5\ua7ba\u95e3\uaa0b\uae88\u7d3a\u4097\u8d8b\u7b1a\u1c34\u7921", "\uda11\udf98\udbeb\ude81\uda28\udfd5",
        48, 38643, -414083405, -6923915626359567098L, 23317L, true, false, (char) 37357, (char) 28643,
        Double.longBitsToDouble(0x3fc10ce27b1b6374L), Double.longBitsToDouble(0x3faee604f97baa70L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 11, 4, "\uda9a\udcf6\udb5d\udd23\udbe9\udef7\ud9d7\ude51\ud8ae\udd30\udb19\udc34\ud901\udcc7\ud9fb\ude13\ud814\ude03\udb62\udece\udac6\udfb9\udb5b\ude84", "\u4260\u2b04\u7d78\u62cc\u3493\u1a1a\ud328\uad0e\u36d9\u5fdc\u83e7\uc8f2\u5137\u3e5a\u66d7\u0ab9\u780a\uc244\ua429\u9bd3\u34aa\ua7bc\ubc7a\u4ec2\uc072\ua65d\u0d5d\u8acc\u3d77\u400f\ud0ca\ub488\u545b\u796d\u7d3a\u4097\u8d8b\u773f\u7f38\uc9bf", "\uda2e\udd5a\udbeb\ude81\u8e46",
        10, 71983, -414101480, -5166104396801567351L, 23317L, true, false, (char) 37357, (char) 63397,
        Double.longBitsToDouble(0x3fc10cf53b1b6374L), Double.longBitsToDouble(0x3faee604f97baa70L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 1, 6, 2, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\u1a1a\u161f\ua7f0\u36d9\u5fdc\u62b7\u9fd1\ucc02\ubad3\u66d7\u0ab9\u780a\u5abd\ua69a\u9825\u34aa\u4396\u8f8c\u4ec2\u0fd4\ua744\u7253\u6686\u921b\u3fc5\ua7ba\u95e3\uaa0b\uae88\u7d3a\u4097\u8d8b\u7b1a\u1c34\u7921", "\uda11\udf98\udbeb\ude81\uda28\udfd5",
        48, 38643, -414083405, -6923915626359567098L, 23317L, true, false, (char) 37357, (char) 28643,
        Double.longBitsToDouble(0x3fc10ce27b1b6374L), Double.longBitsToDouble(0x3faee604f97baa70L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 1, 13, 5, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\u1a1a\u161f\ua7f0\u36d9\u5fdc\u62b7\u9fd1\ucc02\ubad3\u66d7\u0ab9\u780a\u5abd\ua69a\u9825\u9dd8\u676d\u7833\u1f5d\u1079\ua744\u7253\u6686\u921b\u3fc5\ua7ba\u95e3\uaa0b\uae88\u7d3a\u4097\u8d8b\u7b1a\u1c34\u7921", "\uda11\udf98\udbeb\ude81\uda28\udfd5",
        48, 38643, -414083405, -6923915626359567098L, 23317L, true, false, (char) 37357, (char) 28643,
        Double.longBitsToDouble(0x3fc10ce27b1b6374L), Double.longBitsToDouble(0x3faee604faebaa70L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.JXPathAbstractFactoryException:org.apache.commons.jxpath.JXPathAbstractFactoryException: Factory null reported success creating object for path: /* but object was null.  Terminating to avoid stack recursion. |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 1, 0, 2, 4, "\uda9a\udcf6\000\000\ud9cb\udf64\ud8ae\udd30l\ud901\udcc7\udbf3\ude0f\ud814\ude03\u5f49\uda61\udd2f\udb5c\udcbf", "\u4260\u2b04\u6c31\u38e0\u6fe2\u1a1a\u161f\ua7f0\u36d9\uadc9\uc341\u9fd1\ucc02\ubad3\u66d7\u6b3b\u780a\u5a08\ua69a\uce5e\u85e65\000\u289a\u234d\ua744\u7253\u6686\u921b\u3fc5\ua7ba\u95e3\u5db1\uae88\u7d3a\u4097\u25ca\u0a8b\u1c34\u7921", "\uda11\udf98",
        43, 42614, -19324837, 412706168722527923L, -100000L, false, false, (char) 24688, (char) 51212,
        Double.longBitsToDouble(0x3fe19dfdd096784dL), Double.longBitsToDouble(0x3e4b1b6374000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=java.lang.Integer:0 |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 2, 14, 11, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udba0\ude3b\ud9f1\uddb2\ud908\udd14\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\u1a1a\u161f", "\ud982\ude0c",
        26, 91003, 341664736, -4872381357446666281L, 98457L, true, false, (char) 17658, (char) 9137,
        Double.longBitsToDouble(0x3fe3056d1627e29dL), Double.longBitsToDouble(0x3fea60a61457db52L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 12, "\udb9d\udd62\ud8b4\udd4f\udbf9\udeba\ud9d7\uddca\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\ud96f\udc69\ud874\uddc6\ud9e7\udea6", "\u6a86\u2b04\u7d78\u38ce\u41fe\u8819\u161f\ua7f0\ud4dd\u8e44\u62b7\u9fd1\u4de6\uc761\ub69a\u0ab9\u780a\u3d1e\u65d3\u9825\u34aa\ud6b4\u8f6d\u4ec2\u0fd4\ua744\u7253\u6686\u921b\u0258\ua7d7\u95e3\uaa0b\u9cfe\u45fc\u5dc8\ua2f7\ua4fd\u1c34\ubb21", "\uda3f\udfdf\udbeb\ude81\ud942\udf02\uda65\udff7\ud9cd\uddb2\uda04\udd26\ud940\udd7a\ud943\udf9e\udbe5\udfc4\udad0\ude54\ud938\udf21\udbe4\udd49\ud827\udda9\uda3e\ude39\u93b6\udbb6\udd65\ud9e3\udd91\udb83\udecc\ud9cd\udec7\ud980\uddca\ud9bf\udd93\ud9f7\udeff\ud974\uddda\udbee\udda7\ud853\udfed\ud9fa\udeeb\udb68\udefa",
        55, 29128, -1390591596, 4623115983118951223L, 85301L, true, true, (char) 24432, (char) 44920,
        Double.longBitsToDouble(0x3fea57afc05ab055L), Double.longBitsToDouble(0x3feb7fcee9375f2bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.QName:* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\udb87\udd6b\udbd8\udfc9\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\uc2c3\u2b04\u7d78\u38e0\u3493\u1a1a\u161f\ua7f0\u36d9\u5fdc", "\ud8c1\udd13\udb7b\udefb\ud873\ude53\udac7\uddd0\uda10\udf37\ud51e\udbef\udc6e\uda28\ude3c\ud9d4\udd7c\ud96a\udc5a\udabe\udca4\ud8b3\udf60\udaac\udd22\udbbf\udfaa\udb56\udd54\udacc\udeb7\ud9a6\udeae\udb37\udee2\ud911\ude1a\ud93b\ude78",
        51, 54070, -1073741547, 6753353680523787249L, -62390L, false, false, (char) 25346, (char) 623,
        Double.longBitsToDouble(0x3fda6d00e9a3541aL), Double.longBitsToDouble(0x3fc83dccc3ca5facL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 17, 4, "\uda9a\udcf6\udb5d\udd23\ud9f5\ude3c\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf\udbe3\udd69\uda7e\udfff\ud807\udcaa\ud9a2\udf0a\udb07\ude4c\ud965\ude42\ud889\ude20\u7304\uda99\udcae\uda2d\udc60\u5dd1\ud982\ude0c\ud9d3\udf5c\ud82f\udf3a\ud8c1\udd13\udb7b\udefb\u63c6", "\u43ec\ua69a\u9825\u34aa\u4396\u8f8c\u4ec2", "\udb4d\udf00\udacc\ude59\ud9a6\udeae\udb37\udee2\ud911\ude1a\ud93b\ude78\ud8da\udcb1\udbc4\uddb0\ud9b5\udd4f\ud927\udcdd\uda22\udcf5\uda59\uddd0\ud94f\udd90\ud840\udcfb\uda89\udf03\udaa9\udeaa\uda1c\udc98",
        43, 42614, -19324837, 412706168725935795L, -86950L, true, false, (char) 24688, (char) 51212,
        Double.longBitsToDouble(0x3fe19dfdd796784dL), Double.longBitsToDouble(0x3fc10ce27b1b6374L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=null |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 2, 7, 7, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udab3\udf76", "\u3315\u9f7e\u490d\u2b71", "\udaa0\udeef\udbd8\udfc1\udb40\udecd\uda2d\udc60\u5dd1",
        58, 27426, 1874652091, 8375679219591672268L, 58523L, true, false, (char) 46054, (char) 33900,
        Double.longBitsToDouble(0x3fe0ec65daf79d7fL), Double.longBitsToDouble(0x3fe1ea9f3a60ada2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=org.apache.commons.jxpath.JXPathAbstractFactoryException:org.apache.commons.jxpath.JXPathAbstractFactoryException: Factory null reported success creating object for path: /* but object was null.  Terminating to avoid stack recursion. |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 2, 14, 16, 4, "\ud858\udc37\ud8b6\udee4\udbca\udd24\u840a\ud8ae\udd17\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260", "\ud914\udef9\udb49\udd70\u7304\uda99\udcae\uda2d\udc60\u5dd1\ud982\ude0c\ud95a\udddf",
        -2, 81736, -1134439688, 7721394996520315707L, 65301L, true, true, (char) 13016, (char) 17658,
        Double.longBitsToDouble(0x3fd35a67b4c15b44L), Double.longBitsToDouble(0x3fe13f14eb4c14c2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.JXPathAbstractFactoryException:org.apache.commons.jxpath.JXPathAbstractFactoryException: Factory null reported success creating object for path: /* but object was null.  Terminating to avoid stack recursion. |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=java.lang.String:\ud858\udc37\ud8b6\udee4\udbca\udd24\u840a\ud8ae\udd17\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 2, 0, 6, 16, "\ud858\udc37\ud8b6\udee4\udbca\udd24\u840a\ud8ae\udd17\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u1fca", "\ud914\udef9\udb49\udd70\ud8fe\udc04\uda99\udcae\uda2d\udc60\u5dd1\ud982\ude0c\ud95a\udddf",
        -2, 81736, -1134439688, 7721394996520315707L, 65301L, true, true, (char) 13016, (char) 17658,
        Double.longBitsToDouble(0x3faad33d9cfad230L), Double.longBitsToDouble(0x3fe13f14eb4c14c2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.QName:* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 1, "\ud9c3\udeb3\ud93c\udee6\udbb1\udd88", "\u9709\ua38b\u74e6", "\udac6\udfb9\ud9e5\udf8b\ud97a\udd18\uda9d\ude24\ud9ce\udefa\ud9a2\udec8\udb07\ude4c\ud914\udef9\udb49\udd70\u7304\uda99\udc24\udb6c\udec0\u5dd1\ud982\ude0c",
        26, 91003, 341664736, -4872381360216804393L, 98457L, true, false, (char) 17658, (char) 6833,
        Double.longBitsToDouble(0x3fe3056d1627e29dL), Double.longBitsToDouble(0x3fea60a6163bb163L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.JXPathAbstractFactoryException:org.apache.commons.jxpath.JXPathAbstractFactoryException: Factory null reported success creating object for path: /* but object was null.  Terminating to avoid stack recursion. |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=org.apache.commons.jxpath.JXPathAbstractFactoryException:org.apache.commons.jxpath.JXPathAbstractFactoryException: Factory null reported success creating object for path: /* but object was null.  Terminating to avoid stack recursion. |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 2, 0, 0, 12, "\ud8cb\udf9c\uda7c\udc3d\ud979\udde2\u840a\ud948\udead\udb71\ude46\udac9\udf4e\udbf3\udda6\ud814\ude03\uda11\udee1\uda95\uddb3\udb5c\udcef", "\u4260", "\uda8f\udd98\uda15\udd5b\ud830\udd6c\ud925\udda0\ud8f9\udc66\u5dd1\ud9f3\udf65\udacb\udfa5\udb1b\udd52",
        30, 88713, 1596943080, -1003621872923285438L, -32615L, true, true, (char) 39680, (char) 51470,
        Double.longBitsToDouble(0x3fe8608172926a1dL), Double.longBitsToDouble(0x3fd4c14c2c4c1968L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 9, "\ud858\udc37\ud8b6\udee4\udbca\udd24\u840a\ud8ae\udd17\udbb8\ude70\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udb34\udeb4\udb5c\udcbf", "\u4260", "\ud914\udef9\udb49\udd70",
        42, 28283, -66089828, -2493111989556232829L, 19544L, true, true, (char) 54882, (char) 23116,
        Double.longBitsToDouble(0x3fc6aaf31ce5f6f8L), Double.longBitsToDouble(0x3fe0ec65dec3be37L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.JXPathAbstractFactoryException:org.apache.commons.jxpath.JXPathAbstractFactoryException: Factory null reported success creating object for path: /* but object was null.  Terminating to avoid stack recursion. |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 4, "\ud858\udc37\ud8b6\udee4\udbca\udd24\u840a\ud8ae\udd17\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\ud99b\udef2\ud95d\ude71\udb5c\udcbf", "\u4260", "\ud914\udef9\udb49\udd70\u7304\uda99\udcae\uda2d\udc60\u5dd1\ud982\ude0c\ud95a\udddf",
        -2, 81736, -1134439688, 7721394996520315707L, 65301L, true, true, (char) 13016, (char) 17658,
        Double.longBitsToDouble(0x3fd35a67b4c15b44L), Double.longBitsToDouble(0x3fe13f14eb4c14c2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 2, 14, 14, 4, "\uda9a\udcf6\udbe3\udf27\uda6b\ude42\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\ud892\udc3e\udad5\ude53\udb62\udeab\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\ub521\u0890\ua7f0\u36d9\u5fdc\u62b7\u9fd1\ucc02\u323c\u7f08\u0a91\u780a\u5abd\ua69a\u9825\u34aa\u4396\u8f8c\u4ec2\u0fd4\ua744\u7253\u6686\u921b\u3fc5\ua7ba\u95e3\uaa0b\uae88\u7d3a\u4097\u8d8b\u7b1a\u1c34\u7921", "\uda11\udf98\udbeb\ude81\uda28\udfd5",
        48, 38643, -414083405, -6923915626359567098L, 23317L, true, false, (char) 37357, (char) 28643,
        Double.longBitsToDouble(0x3fc10ce27b1b6374L), Double.longBitsToDouble(0x3faee604f97baa70L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.JXPathAbstractFactoryException:org.apache.commons.jxpath.JXPathAbstractFactoryException: Factory null reported success creating object for path: /* but object was null.  Terminating to avoid stack recursion. |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 5, 4, "\ud90e\udff6\udbe3\udf27\uda6b\ude42\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\ud892\udc3e\udad5\ude53\udb62\udeab\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\u1a1a\u161f\ua7f0\u36d9\u5fdc\u62b7\u9fd1\ucc02\ubad3\u66d7\u0b68\u780a\u5abd\ua69a\u9825\u2d8e\u43a1\u8f8c\u4ec2\u581c\ua744\u7253\u6686\u921b\u3fc5\ua7ba\u95e3\uaa0b\uae88\u7d3a\u4097\u8d8b\u5bc5\u330a\u7921", "\uda11\udf98\udbeb\ude81\uda28\udfd5",
        48, 38643, -414083405, -6923915628415169274L, 23317L, true, false, (char) 37357, (char) 28643,
        Double.longBitsToDouble(0x3fc10ce27b1b6374L), Double.longBitsToDouble(0x3faee604f97baa70L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\u1a1a\u161f\ua7f0\u36d9\u5fdc\u62b7\u9fd1\ucc02\ubad3\u66d7\u0ab9\u780a\u5abd\ua69a\u266e\ud367\u4396\ub48b\u4ec2\u0fd4\ua744\u7253\u6686\u921b\u3fc5\ua7ba\u95e3\uaa0b\uae88\u7d3a\u4097\u8d8b\u7b1a\u1cf4\u7921", "\uda11\udf98\udbeb\ude81\ud931\udcc0",
        -5, 38643, -414083405, -6923915626359567098L, 23317L, true, false, (char) 37357, (char) 28643,
        Double.longBitsToDouble(0x3fc10ce27b1b6374L), Double.longBitsToDouble(0x3faee604f97baa70L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\uda9a\udcf6\ud923\uddc7\uda92\udcfe\ud9d7\ude16\ud8ae\udd30\udb1e\udc21 |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=java.lang.String:\uda9a\udcf6\ud923\uddc7\uda92\udcfe\ud9d7\ude16\ud8ae\udd30\udb1e\udc21 |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 2, 6, 6, 10, "\uda9a\udcf6\ud923\uddc7\uda92\udcfe\ud9d7\ude16\ud8ae\udd30\udb1e\udc21", "\u903e\u2db0\u5efe\u2e5e\ud2f0\u1893\u4260\u2b04\u4e45", "\u7304\ud868\ude75\u37a0",
        18, 1466, 1893255858, 8051569044607558624L, -93815L, true, true, (char) 23116, (char) 56652,
        Double.longBitsToDouble(0x3fe9cbedf61d8cbbL), Double.longBitsToDouble(0x3fe61df1bd35a67bL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.JXPathAbstractFactoryException:org.apache.commons.jxpath.JXPathAbstractFactoryException: Factory null reported success creating object for path: /* but object was null.  Terminating to avoid stack recursion. |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 4, 1, "\ud9c3\udeb3\ud93c\udee6\ud925\ude44", "\u0305\ua38a\ucee6", "\udac6\udfb9\ud9e5\udf8b\ud97a\udd18\ud8d1\udd98\ud9b6\udd77\ud9a2\udec8\udb07\ude4c\ud914\udef9\udb49\udd70\u7304\uda99\udc24\udb6c\udec0\u5dd1\ud982\ude0c",
        -1, 65296, 341664736, -4872381360216804393L, -90413L, false, false, (char) 17658, (char) 6833,
        Double.longBitsToDouble(0x3fe3056d1627e29dL), Double.longBitsToDouble(0x3fea60a6133bb163L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.NullPointer:/* |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 1, 14, 11, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u38e0\u3493\u1a1a\u161f\ua7f0\u36d9\u5fdc\u62b7\u9fd1\ucc02\ubad3\u66d7\u0ab9\u8ddc\u7cc8\ud3f5\u903d\u9206\u4396\u8f8c\u4ec2\u0fd4\ua744\u7253\u6686\u921b", "\ud93b\ude78\ud8da\udcb1\udbc4\uddb0\ud9b5\udd4f\ud927\udcdd\uda22\udcf5\udad3\udca9\ud94f\udd90\ud840\udcfb\uda89\udf03\udaa9\udeaa\uda11\udf98\udbeb\ude81\uda28\udfd5\uda66\udc49\ud97c\ude69\uda7d\udd3e\ud940\uddc2\ud943\udead",
        18, 50837, -1078319489, 8668815975972599702L, 80282L, true, false, (char) 29246, (char) 50698,
        Double.longBitsToDouble(0x3fd581296969fa34L), Double.longBitsToDouble(0x3fe38e9a591164cbL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\0121=[Ljava.lang.String;:[[]] |this=org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:/*\012",
        Z.run(T, 2, 13, 13, 4, "\uda9a\udcf6\udb5d\udd23\uda6b\ude37\ud9d7\ude16\ud8ae\udd30\udb1e\udc21\ud901\udcc7\udbf3\ude0f\ud814\ude03\udb62\udece\udac6\udfb9\udb5c\udcbf", "\u4260\u2b04\u7d78\u9aca\u28ba\u4cda\u161f\ua7f0\ub724\u5fdc\u9ea0\u9fd1\ucc02\ubad3\u66d7\u0ab9\u780a\u5abd\ua69a\u9825\u64b8\u4396\u5320\ua15f\u0fd4\ua744\u7253\u6686\u8f70\u3fc5\ua7ba\u95e3\ube0b\uae88\u7d3a\u4097\u8d8b\u7b1a\u1c34\u7921", "\uda11\udf98\udbeb\ude81\uda28\udfd5",
        46, 38643, -414083405, -6965930164680143610L, 23317L, true, false, (char) 37357, (char) 10723,
        Double.longBitsToDouble(0x3fd268e0bd8db1baL), Double.longBitsToDouble(0x3faee604f97baa70L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|createBadFactoryException|org.apache.commons.jxpath.AbstractFactory|new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|createPath|org.apache.commons.jxpath.JXPathContext|new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|createPath|org.apache.commons.jxpath.JXPathContext,java.lang.Object|new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|asPath||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int|new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int,java.lang.Object|new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|escape|java.lang.String|new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|getBaseValue||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|getImmediateNode||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|getLength||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|getName||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|getPropertyCount||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|getPropertyName||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|getPropertyNames||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|getValuePointer||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|isActual||new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|createBadFactoryException|org.apache.commons.jxpath.AbstractFactory|new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|createPath|org.apache.commons.jxpath.JXPathContext|new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
    "M|org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer|createPath|org.apache.commons.jxpath.JXPathContext,java.lang.Object|new:org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer:org.apache.commons.jxpath.ri.model.NodePointer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
