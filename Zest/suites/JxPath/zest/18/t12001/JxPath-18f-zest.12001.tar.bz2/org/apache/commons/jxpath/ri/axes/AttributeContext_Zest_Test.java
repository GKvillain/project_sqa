package org.apache.commons.jxpath.ri.axes;
import org.junit.Test;
import static org.junit.Assert.*;
public class AttributeContext_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 0, 0, 4, "\udb86\udf16\ud93d\udcaf\udb39\udc9f\udac2\udc2e\ud808\udfc1\ud838\udc03\ud98f\udda9\ud996\udc01\uda5c\ude17", "\u5a69\uaeff\u0284\ud26a", "\ud99d\ude28\uda19\udd9e\udbf9\udf2e\uda76\ude61\udbe3\uddb7\ud969\udf0b",
        33, 1241, -1471462959, -4973538706043184946L, -72561L, true, true, (char) 10101, (char) 5927,
        Double.longBitsToDouble(0x3fd4704d6e5beb0cL), Double.longBitsToDouble(0x3fa91c918c6dfcf0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 0, 0, 4, "\udb86\udf16\ud93d\udcaf\udb39\udc9f\udac2\udc2e\ud808\udfc1\ud838\udc03\ud98f\udda9\ud9db\udc47\udbe0\udff7", "\u5a69\uaeff\u0284\ud26a", "\ud99d\ude28\uda19\udd9e\udbf9\udf2e\uda76\ude61\udbe3\uddb7\ud969\udf0b",
        33, 1241, -1471462959, -4973538706043184946L, -72561L, true, true, (char) 10101, (char) 5927,
        Double.longBitsToDouble(0x3fd4704d6e5beb0cL), Double.longBitsToDouble(0x3fa91c918c6dfcf0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=void |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 0, 2, 4, "\udb86\udf16\ud93d\udcaf\udaf8\udcb6\udbb6\udf95\u8506\ud838\udc03\udad1\udc8a\udaa6\ude84\uda6b\udf33", "\u1520\u5b91", "\uda60\udf5a\udbf7\udf91\ud99d\ude28\ud8a7\udd66\u61aa",
        2, 74131, 1989914638, 1481990762795684689L, 2170L, false, false, (char) 17756, (char) 10329,
        Double.longBitsToDouble(0x3fd016e07c6f127cL), Double.longBitsToDouble(0x3fef5d99d94704d6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 1, 0, 0, 4, "\udb09\ude14\udb22\udd36\udabc\udd4c\ud954\udf09\u1fff\udaa5\udf3f\ud9a7\udea3\ud978\udd16\ud9a9\udc4c", "\u65c7\u3f01\u96bf\ud26a", "\uda0c\ude4d\uda3d\udf9e\ud812\ude34\uda76\ude61\udb8f\udc4d\ud8cd\udc16",
        20, 99311, 2123928529, -895432340406134100L, -72561L, true, true, (char) 10101, (char) 5927,
        Double.longBitsToDouble(0x3fd4704d6e5beb0cL), Double.longBitsToDouble(0x3fa91c918c6dfcf0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 3, 3, 1, "\udb86\udf16\ud93d\udcaf\uda95\udcad\udac2\udc2e\ud808\udfc1\ud858\ude03\ud98f\udda9\udb29\udd08\udb3e\udd95\udb04\udcf2\udbc9\udf2d", "\ucf34", "\udbf7\udf91",
        57, 22463, -571039676, 4229430470421545526L, 36545L, false, true, (char) 43177, (char) 19710,
        Double.longBitsToDouble(0x3fe28db69f9c35d4L), Double.longBitsToDouble(0x3fc835310407281cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 0, 3, 4, "\udb86\udf16\ud93d\udcaf\udb39\udc9f\udbbe\udc2c\ud808\udfc1\ud838\udc03\ud82c\udf7b\ud921\udc28\ud91f\udcf7", "\u5a69\u6036\u11e1\u4ed9", "\ud99d\ude28\uda19\udd9e\udbf9\udf2e\uda76\ude61\udbe3\uddb7\ud969\udf0b\ud8f3\udff5\udbb7\ude31",
        16, 48686, -710682418, -7815874058787491375L, -65839L, false, false, (char) 50716, (char) 21684,
        Double.longBitsToDouble(0x3fa91c91802dfcf0L), Double.longBitsToDouble(0x3fe0530fcab71127L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 4, 3, 4, "\udb86\udf16\ud93d\udcaf\udaab\udee2\udada\udd33\ud808\udfc1\ud838\udc03\ud849\udda6\ud996\udc01\uda5c\ude17", "\u5a69\uaeff\u0284\ud26a", "\ud99d\ude28\uda19\udd9e",
        15, 24468, -1278901706, 8546618292386731711L, -89966L, false, true, (char) 10329, (char) 42760,
        Double.longBitsToDouble(0x3fe1bc49f3ebb33bL), Double.longBitsToDouble(0x3fd4704d6dfd030cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=new org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 4, 4, 3, "\udb86\udf16\ud8d1\udfda\udb39\udca9\udac2\udc2e\ud808\udfc1\ud838\udc03\ud98f\udda9\udbc9\ude8b\uda61\udfd6", "\u2742\u847f\u02a4\ud26a", "\ud99d\ude28\uda19\udd9e\ud82d\udc88\udadb\udd58\udbe3\uddb7\ud969\udf0b",
        53, 1241, -1469300271, -4973538706043184946L, -72561L, true, true, (char) 10101, (char) 30364,
        Double.longBitsToDouble(0x3fd471de3e5beb0cL), Double.longBitsToDouble(0x3fe9aada36dbf8e0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 0, 0, 4, "\udb86\udf16\ud93d\udcaf\udb39\udc9f\udac2\udc2e\ud808\udfc1\ud838\udc03\ud98f\udda9\ud996\udc01\uda5c\ude17", "\u5a69\uaeff\u0284\ud26a", "\ud99d\ude28\uda19\udd9e\udbf9\udf2e\uda76\ude61\udbe3\uddb7\ud969\udf0b",
        33, 1241, 1358381521, 1504753126724756425L, 2476L, true, true, (char) 10158, (char) 5927,
        Double.longBitsToDouble(0x3fd4704d6e5beb0cL), Double.longBitsToDouble(0x3fa91c918c6dfcf0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 1, 0, 4, "\udb86\udf16\ud93d\udcaf\udb39\udc9f\udac2\udc2e\uda1d\ude12\ud9fd\uddcf\ud946\udeb2\ud996\udc01\uda5c\ude17", "\u5a69\uaeff\u0eb7\ud26a\u97dc\u04be\uabf4\u768a\uc147\uc2df\u3ff8\u34a1", "\udb39\udca5\udab9\udcd4",
        17, 41952, 1845990609, -8557339566787551689L, 80551L, true, true, (char) 36181, (char) 1816,
        Double.longBitsToDouble(0x3fe0f27d89bea37dL), Double.longBitsToDouble(0x3fe8fc3ae2198b81L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 3, 0, 0, "\udb86\udf16\ud93d\udcaf\udb39\udc9f\udac2\udc2e\ud808\udfc1\ud838\udc03", "\uc2a6", "\u7b38\ucc57\ud8b4\ude2f\ud94b\udee4",
        -4, 62054, 1397238080, 2791980350091835257L, 63231L, false, false, (char) 37759, (char) 59361,
        Double.longBitsToDouble(0x3fdd130d81cd5096L), Double.longBitsToDouble(0x3fc9d75f5ee3568cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=void |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 2, 2, 1, "\udb86\udf16\ud93d\udcaf\udb39\udc11\ud97a\udc29\ufce8\udbe4\udc99\ud8ac\udf57\ud9c4\udd1a\ud830\udcd7", "\ubb45\uc7be\u0284\ud26a\u97dc\u04be", "\udbf9\udf2e\uda76\ude61\udadb\uddb3\ud93e\udd0b\ud8f3\udff5\udbb7\ude31\udb39\udca5\uda34\ude1e\udbb7\ude3f\ud857\udd5c\ud9b4\udd5a\ud97d\udc19\udb3c\udf10\ud9ea\udf33\udbf4\udc8b\ud91a\udf6d\ud94a\ude65",
        30, 90433, -1034749792, -4015453737364282793L, -87974L, false, false, (char) 5359, (char) 53700,
        Double.longBitsToDouble(0x3fe69702ec6c4eb4L), Double.longBitsToDouble(0x3fdb4ee0c3289964L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 1, 0, 0, 0, "\udb86\udf16\ud93d\udcaf\udb39\udc9f\udaef\udf04\u3831\ud838\udc03\ud98f\udda9\ud996\udc01\uda5c\ude17\udb04\udcca\ud8f4\udd43\ud950\udc1e\ucbd3", "\u97dc\u04be\uabf4\u2942\u89a8", "\u5810\ud8f3\udff5\udbb7\ude31\udb38\udfec\udab9\udcd4\udbb7\ude4e\uda52\udd53\udbde\udf4c",
        -3, 78659, -2003147797, -8138626720432169171L, 36440L, false, false, (char) 45984, (char) 39348,
        Double.longBitsToDouble(0x3fd5d4ed092503a6L), Double.longBitsToDouble(0x3fc9e8eeee0a6628L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=new org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 0, 4, 4, "\udb86\udf16\u1433\udb2a\udfcf\udac2\udc2e\ud808\udfc1\ud838\udc03\ud98f\udda9\ud996\udc01\uda5c\ude17", "\u5a69\uaeff\ud025\uc01e", "\ud99d\ude28\uda19\udd9e\udbf9\udf2e\uda76\ude61\uda8f\uddac\ud969\udfc1",
        33, 92421, -1471415855, -4973538703731586098L, -7025L, false, true, (char) 27240, (char) 4391,
        Double.longBitsToDouble(0x3fd4704d6e5beb0cL), Double.longBitsToDouble(0x3fa91c918c6dfcf0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=null |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 1, 1, 1, "\udb9b\udc96\ud93d\udcaf\udb2e\udc9f\udac2\udc2e\ud808\udfc1", "\u2471\ua1ba\u7005\u977c\uae50", "\ud94b\udeea\uda60\udf5a\udaeb\udc2a",
        25, 21582, -938526855, 4191837809187739958L, 47919L, true, true, (char) 8004, (char) 11976,
        Double.longBitsToDouble(0x3fd6029faf716f46L), Double.longBitsToDouble(0x3fca32710405bba0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 1, 1, 4, 4, "\udb86\udf16\ud93d\udcaf\udb39\udc9f\udac2\udc2e\ud808\udfc1\ud838\udc03\ud98f\udda9\ud996\udc01\ud9f6\udd85\ud9ff\ude08\udab5\udcdb\ud43f\ucc57\uda0e\udd61\ud94b\udeea\uda60\udf5a\udbf7\udf91\ud99d\ude28\uda19\udd9e", "\ud6c1\u6584\u2f1f\u1652\u97c4\ucacf\u5e99\u9aae\u70b3\u356a\ubb3a\ua1a6\u24dd\u7a99\u78a9", "\ud9e2\ude29",
        56, 63541, -109535619, 6920658391847099657L, 48084L, false, false, (char) 56451, (char) 17963,
        Double.longBitsToDouble(0x3fecbad2fc3dab8bL), Double.longBitsToDouble(0x3fd2169ff7efbe68L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 1, 4, 3, 4, "\udb86\udf16\ud93d\udcaf\udb39\udc92\udac2\udc2e\ud808\udfc1\ud838\udc03\ud98f\udda9\ud996\udc01\uda5c\ude17", "\u638f\u40e1\uc5c5\u5c96", "\ud99d\ude28\uda19\udd9e\udbf9\udf2e\uda76\ude61\ud9b5\udfe8\ud93d\udd16",
        47, 1241, -1471463055, -4973538706043184946L, -72561L, true, false, (char) 10101, (char) 5927,
        Double.longBitsToDouble(0x3fd4704d6e5beb0cL), Double.longBitsToDouble(0x3fa91c918c6dfcf0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 1, 4, 0, 0, "\udb86\udf16\ud93d\udcaf\udb97\udcae", "\u6883\u5df3\u20a0\u8c19", "\udb53\udc7b\ucc57\udaf4\udc5a\ud85f\udef4",
        1, 70743, 1397238080, 2791980350091835257L, -66666L, true, false, (char) 36103, (char) 59361,
        Double.longBitsToDouble(0x3fdd130d80ae0142L), Double.longBitsToDouble(0x3fc9d7461ae3568cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 3, 3, 2, "\udb86\udf16\uda2a\udc26\udaf8\udcb6\ud889\ude5f\udb86\udf6f\ud837\udffa\udad1\udc8a\udaa6\ude84\uda6b\udf33", "\u9a99\u9e84", "\uda60\udf5a\udbf7\udf91\ud99d\ude28\ud8a7\udd66\u61aa",
        2, 74131, 1906028558, -32859801825100460L, 2170L, false, false, (char) 17756, (char) 10329,
        Double.longBitsToDouble(0x3fd4b9339c6f127cL), Double.longBitsToDouble(0x3fdebb33b3bb428eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 3, 3, 1, "\udb86\udf16\ud93d\udcaf\uda95\udcad\udac2\udc2e\ud808\udfc1\u5fe4\ud98f\udda9\udb29\udd08\udb3e\udd95\udb04\udcf2\udbc9\udf2d", "\ucf34", "\udbf7\udf91",
        0, 22441, -571039676, 4229430470421545526L, 36545L, false, true, (char) 43103, (char) 19710,
        Double.longBitsToDouble(0x3fe28db69f9c35d4L), Double.longBitsToDouble(0x3fdc1a988202a598L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 3, 3, 1, "\udb86\udf16\ud942\udd8f\udbc3\udfd0\udae3\udf66", "\u3e75\u1b34", "\uda05\udcab\udb55\ude53\uc00f\ud91d\udf70\udb01\udfb1\ud9a7\udd81\udbf8\udf9a\uda39\udc36\uda7e\ude32\ud9e5\udeaf\ud9ea\udc10\ud97c\udec4\udaac\udceb\ud92d\uddea",
        -2, -247, -1226025829, 3878837675700547484L, -32323L, false, false, (char) 22189, (char) 22022,
        Double.longBitsToDouble(0x3fe8e397866dbdcbL), Double.longBitsToDouble(0x3fed53db6d2c1957L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.AttributeContext:Empty expression context\012",
        Z.run(T, 2, 0, 0, 4, "\udb86\udedf\ud93d\udcaf\udb39\udc9f\udaf9\udda9\ud808\udfb6\ud838\udc03\ud98f\udda9\ud996\udc01\uda5c\ude17", "\u5a69\uaeff\u0284\ud26a", "\ud8d0\udf23\uda26\udd84\udbf9\udf2e\ud896\udf71\udbe3\uddee\ud822\udc08",
        33, 45881, -1463629154, -4973538706043184946L, -72561L, true, true, (char) 10101, (char) 5927,
        Double.longBitsToDouble(0x3fd4704d6e5beb0cL), Double.longBitsToDouble(0x3fa91c918ffdfcf0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.axes.AttributeContext|nextNode||new:org.apache.commons.jxpath.ri.axes.AttributeContext:org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.NodeTest",
    "M|org.apache.commons.jxpath.ri.axes.AttributeContext|getCurrentNodePointer||new:org.apache.commons.jxpath.ri.axes.AttributeContext:org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.NodeTest",
    "M|org.apache.commons.jxpath.ri.axes.AttributeContext|reset||new:org.apache.commons.jxpath.ri.axes.AttributeContext:org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.NodeTest",
    "M|org.apache.commons.jxpath.ri.axes.AttributeContext|setPosition|int|new:org.apache.commons.jxpath.ri.axes.AttributeContext:org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.NodeTest",
    "C|org.apache.commons.jxpath.ri.axes.AttributeContext|<init>|org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.NodeTest",
    "M|org.apache.commons.jxpath.ri.axes.AttributeContext|nextNode||new:org.apache.commons.jxpath.ri.axes.AttributeContext:org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.NodeTest",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
