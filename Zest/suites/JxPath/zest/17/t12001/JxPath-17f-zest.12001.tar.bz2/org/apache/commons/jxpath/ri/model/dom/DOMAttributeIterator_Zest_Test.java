package org.apache.commons.jxpath.ri.model.dom;
import org.junit.Test;
import static org.junit.Assert.*;
public class DOMAttributeIterator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\ud89e\udd24\ud98f\uddc8\udad7\udd79\udbc2\ude19\ud12e\uda2c\ude93\ud863\udfb6\uda9b\udda5", "\u4153\u08eb\ubfce\ucdda\u1fa3\u8764\u9f48", "\ud9cb\udf29",
        33, 12094, 566277349, 3295023415031730413L, 72377L, false, false, (char) 44511, (char) 4867,
        Double.longBitsToDouble(0x3fe6ecbcc2bf98bfL), Double.longBitsToDouble(0x3fe558a3ddabd314L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\ud89e\udd24\ud98f\udde7\ud83c\udfc8\udbf6\udcfd\uda5e\ude8f\uda2c\ude93\ud951\udd19\uda31\ude46", "\u4153\u08eb\u7737\u9f7f\u1fa3\u8764\u9f48", "\udb21\udf91",
        33, 12094, 566277349, -5544135278613000042L, 39534L, false, false, (char) 44511, (char) 58045,
        Double.longBitsToDouble(0x3fe6ecbcc2bf98bfL), Double.longBitsToDouble(0x3fdc1a54b3e7e47eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 0, "\ud89e\udd24\ud98f\uddc8\udad7\udd79\udbc2\ude19\ud12e\u24e3\ud863\udf58\uda9b\udda5", "\u4153\u08eb\u9088\u6e34\u008f\u8735\u9f48", "\ud9cb\udf29",
        33, 12094, -425151259, 3295068606677618925L, 72377L, false, false, (char) 44511, (char) 55964,
        Double.longBitsToDouble(0x3fd0cc06d57f318aL), Double.longBitsToDouble(0x3fe558a3ddabd314L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\ud89e\udd24\ud98f\uddc8\udad7\udd79\udbc2\ude19\ud12e\uda2c\ude93\ud863\udfb6", "\ub086\u4153\u08eb\ubfce\ucdda\u1f5f\u8764\uc0c3\u31f9\u4128\ubd8c", "\ud8a9\udee2\udae2\udcfe\u6a89\ud9e0\udcd2\ud8a4\ude61\udba8\udc30",
        38, 84286, -1852234972, -7523120886988161315L, -91125L, true, true, (char) 40797, (char) 29507,
        Double.longBitsToDouble(0x3fd85b769ec6948aL), Double.longBitsToDouble(0x3fdd11b408d98dccL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 0, "\ud89e\udd10\ud98f\uddc8\udad7\ude13\ud826\udcac\udb1b\ude5c\uda2c\ude93\ud863\udfb6\uda9b\udda5", "\uc65d\u7a2d\u0f36\ucdda\u1fa3\u8764\u9f48", "\ud9cb\udef0",
        33, 12094, 566277349, 3295023415803482349L, 72377L, false, false, (char) 44511, (char) 4867,
        Double.longBitsToDouble(0x3fe6ecbcc2bf98bfL), Double.longBitsToDouble(0x3fb5215eed5e9a18L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 0, "\ud877\ude90\ud919\udf49\udad7\udc49\udbc2\ude19\ud12e\uda2c\ude93\u0124\ud9bb\udfc0", "\u4153\u08eb\ubfce\ucdda\u1fa3\u8764\u9f48\u7897\u4128\ubd8c\u1bb3\u43c0\u04e6\u4c89\u2067\u5ebd\u018c\ucdb6\uac10\ub2b5\ucfc0\ubf81\u0164\uc305\u3d6d\ua327\ua3de\u0784\u5eec\ubda7\u08a9\u7a32\ub89d\u317a\u4fba\uace6", "\ud911\udc12\ud85d\udf7e\ud869\udeb9\ud9dd\udc6c\udb43\uddc8\udabf\udd49",
        53, 28392, 1751133466, -2386257003932488303L, -91200L, true, false, (char) 4196, (char) 46079,
        Double.longBitsToDouble(0x3fecae61a2db667cL), Double.longBitsToDouble(0x3fd89bdc08b0603aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 0, "\ud89e\udd04\uda08\udd30\udb83\udfc8\udbc2\udd91\ud12e\uda2c\ude93\uda68\uddb8\uda9b\uddf1", "\u606b\u4178\ubfce\ucdda\u1fa3\u9cd9\u9f48", "\ud9cb\udf29",
        33, 1200, 65582166, -3395139815009709843L, 72377L, false, false, (char) 44511, (char) 4867,
        Double.longBitsToDouble(0x3fe6ecbcc1bf98bfL), Double.longBitsToDouble(0x3fe558a705abd314L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 5, "\ud89e\udd24\ud98f\uddc8\udad7\udd79\udbfc\udd37\uda12\ude72\uda2c\ude22\ud863\udfb6\uda9b\udda5", "\u8c95\u08eb\ubfce\ucdda\u1fa3\u8764\u9f48", "\ud9cb\udf88\ud854\udc51\ud9a4\udc2f\uda47\udfaa\udba1\udecc\u6a89",
        3, 12756, 1512315617, 6974564374593400934L, -82271L, true, false, (char) 60857, (char) 16798,
        Double.longBitsToDouble(0x3fa744f666c28710L), Double.longBitsToDouble(0x3fe88c39a30b7fa7L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 0, "\ud93a\udd28\ud947\udd6e\udb9f\udec2\ud97c\udfdc\ud12e\udb61\udd31\udaf4\udfb4\uda91\udf44", "\u31e4\u6b48\u09ea\u6e34\u008f\u8735\u9f48", "\ud9ef\udf29",
        8, 12094, -2044021531, 7200444848096086374L, 87612L, false, true, (char) 36800, (char) 52965,
        Double.longBitsToDouble(0x3fe558a3ddabd314L), Double.longBitsToDouble(0x3fe5407be34cd893L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\udb56\udea0\ud98f\uddc8\udad1\udd4e\ud845\ude49\ud12e\ud9bb\udd4e\ud863\udfb6", "\ub086\u4153\u08eb\ubfce\u6782\u1f5f\u8764\uc0c3\u31f9\u37ac\ubd8c", "\ud8a9\udee2\udae2\udcfe\u6a89\ud9e0\udcd2\ud8a4\ude61\udba8\udc30",
        38, 84286, -1852234972, -7523120886988161315L, -91125L, true, true, (char) 40797, (char) 29507,
        Double.longBitsToDouble(0x3fd85b769480948aL), Double.longBitsToDouble(0x3fe9b37af6f3f008L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 2, 6, 8, "\ud89e\udd10\ud98f\uddc8\udad7\ude13\ud826\udcac\udb1b\ude5c", "\u0943", "\udad4\udee5\uf8df\ud9ac\udf8a\udbb7\udf5c\ud852\ude78\uda16\ude72\ud9fa\udf68",
        -3, 54723, -2097371953, 1057609467089502422L, 49079L, true, false, (char) 40621, (char) 24698,
        Double.longBitsToDouble(0x3febe34b41595a13L), Double.longBitsToDouble(0x3fb99832992455d8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 2, 6, "\ud877\ude90\ud919\udf49\udaed\udd58\udbc2\ude19\ud8c5\ude96\uda2c\ude54\u0124\ud9bb\udfc0", "\u3970\u08eb\u47ab\ucdda\u1fa3\u8764\u9f48\ubbd5\ubb56\uba79\u7076\uaa27\u14ed\u7c66\u2067\u5ebd\u018c\ucdb6\uac10\ub2b5\ucfc0\ubf81\u0164\uc305\u3d6d\ua327\ua3de\u0784\u5eec\ubda7\u08a9\u3c40\ucce3\u319b\u220f\uc109", "\ud911\udc12\ud85d\udf7e",
        38, 74625, -25770528, -289448837770186946L, -88454L, false, true, (char) 52339, (char) 49426,
        Double.longBitsToDouble(0x3fe30210dab80f78L), Double.longBitsToDouble(0x3fca454e0ea04290L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\ud877\ude90\ud919\udf49\udad7\udc49\udbc2\ude19\ud12e\uda2c\ude93\u0124\ud91d\udf5c", "\u4153\ub5b0", "\uda5c\udc3b\ud80c\ude34",
        -4, 2136, 774091385, -6245071817539429835L, 53252L, true, false, (char) 64380, (char) 20784,
        Double.longBitsToDouble(0x3fc0c6200558ff30L), Double.longBitsToDouble(0x3fee205fa2bf98bfL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 2, 0, "\ud89e\udd04\uda08\udd30\udb83\udfc8\udbc2\udd91\uda09\udcc6\uda2c\ude93\uda68\uddb8\uda9b\uddf1", "\u606b\ud035\ubfce\ucdda\u1fa3\u9cd9\u9f48", "\ud9cb\udf29",
        33, 1200, 65582166, -3395139815009709843L, 72377L, false, false, (char) 44511, (char) 4867,
        Double.longBitsToDouble(0x3fe6ecbcc1bf98bfL), Double.longBitsToDouble(0x3fe558a705abd314L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 0, "", "", "\000",
        -5, -1000, 1722220517, -5338757906062672717L, 9621L, true, false, (char) 48752, (char) 32087,
        Double.longBitsToDouble(0x3fc6d62db1602800L), Double.longBitsToDouble(0x3fd002afa4f3b04eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 2, 8, "\000", "\000", "\ua37f",
        18, 80560, 1800633523, -5631974475130317877L, -66744L, true, false, (char) 56523, (char) 2731,
        Double.longBitsToDouble(0x3fd002afa4f3b04eL), Double.longBitsToDouble(0x3fd4526e1ffb4c12L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\ud89e\udd24\udb61\udff2\udaf8\udd40\udbc2\ude19\ud12e\uda2c\ude2e\ud863\udfb6\uda9b\udda5", "\uafc0\ub195\ubfce\ucdda\u1fa3\u8764\u9f48", "\ud9cb\udf29",
        33, 12094, -1549970459, 3295023415031730413L, 72377L, false, false, (char) 44511, (char) 4867,
        Double.longBitsToDouble(0x3fe6ecbcc2bf98bfL), Double.longBitsToDouble(0x3fe558a3ddabd314L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|testAttr|org.w3c.dom.Attr|new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "C|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|<init>|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|equalStrings|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|getAttribute|org.w3c.dom.Element,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|getNodePointer||new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|getPosition||new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|setPosition|int|new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "C|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|<init>|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|getNodePointer||new:org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|getPosition||new:org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|setPosition|int|new:org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|testAttr|org.w3c.dom.Attr|new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "C|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|<init>|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
