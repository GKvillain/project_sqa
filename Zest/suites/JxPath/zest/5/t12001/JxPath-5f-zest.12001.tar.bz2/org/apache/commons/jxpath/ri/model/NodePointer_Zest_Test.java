package org.apache.commons.jxpath.ri.model;
import org.junit.Test;
import static org.junit.Assert.*;
public class NodePointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 1, 13, 6, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 1, 13, 6, 10, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\uba86\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\ud90b\udd6d\udaa6\udfca",
        10, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 12, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f\udbed\udf93\ud8b8\udd58\u82b5\ud9a2\udf10\ud892\udd4f\udbe4\udef2\uda8b\udfba\udb7d\udcc7\udb6f\udd77\ud9c9\udc62", "\u4b4b\u8d99\u1598\u3654\u387e\u009d\u0c19\u7483\u19c0\u0e5b\u12a9\u352d\u1b46\u5f7f\u8b26", "\ud878\udeab\u682f\udb3c\udf6a\ud9ca\udebf\ud9b2\udda3\uda58\ude14\udbcd\udfe3\ud982\udd72\ud902\udf70\ud9b1\udf39\ud981\udc1e\ud87c\udecf\udac0\udfba\udbc5\udf6e\udb06\udf39\ud989\ude47",
        18, 60319, -45282103, -7870290240255899739L, 34186L, false, false, (char) 389, (char) 53431,
        Double.longBitsToDouble(0x3feeb06eb7bc9799L), Double.longBitsToDouble(0x3fe68fe098ddd698L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\ube86\000\udbe3\udc10\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\ube86\000\udbe3\udc10\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 1, 13, 6, 9, "\ud899\udd47\ube86\000\udbe3\udc10\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\025\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\u4f67\000\000",
        -5, -1000, 0, 2134629991653270062L, -100000L, false, false, (char) 60726, (char) 34775,
        Double.longBitsToDouble(0x3fc6510b7fe6daf0L), Double.longBitsToDouble(0x3fd46ff83b37def2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 13, 6, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\ud809\udca4\udb15\udc82\uda2e\udca6 |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud809\udca4\udb15\udc82\uda2e\udca6'\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 7, "\ud809\udca4\udb15\udc82\uda2e\udca6", "\u1800\u37df\u2408\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67\u119f\u4b4b\ua9a0", "\udbfe\udde6\ud9fe\ude3c\udbd9\udeae\udbad\udc69\udb8e\udee8\udb5e\udc57",
        57, 8025, -939946371, -6592002590001725406L, 4505L, false, false, (char) 21443, (char) 53852,
        Double.longBitsToDouble(0x3fe7cf94db58eaffL), Double.longBitsToDouble(0x3fe0a201287eae73L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f' |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 1, 4, 6, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u2705\uc30d\u2be3\ud345\u713b\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, false, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 6, 9, "\ud899\udd47\udbb4\udc68\udb88\udee3\ud837\udde6\uda01\udce1\u0de5", "\u3c7e\u521d\u1b49\u1316\u52e1\u869a\u1162\u5096\u8733", "\ud93a\udc5a\udad3\udf59\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b690987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.jxpath.JXPathException\012",
        Z.run(T, 1, 7, 9, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\udbf3\ude91\udb30\udfa4\udbd9\udcf9", "\u3c7e\u521d\ube30\u3c17\u2a4a\ub2da\u42e3\u69e6\u85ce", "\ud93a\udc27\udbfc\udfed\ud8bd\ude35\udaee\udeed\ud9fe\ude6b\udb2f\udf49\udbad\udc69\ua8f7\udb5e\udc43\ud864\udd83\udb42\udc86\ud9b5\ude8f\udbcf\udc1e\udafe\udd13\udafb\udfa1\ud8b5\udf4b\udb19\udf93\udb15\udc14\udb38\udcd4\udb6a\udc0e\ud8eb\udd45\uda7c\udc1d\ud8a5\udc8e\ud95d\udcf0\ud910\udc9f",
        29, 1954, -1781705660, 3194672554149696067L, -90761L, true, true, (char) 24067, (char) 1462,
        Double.longBitsToDouble(0x3fda335ccce39660L), Double.longBitsToDouble(0x3fd863fd4594b4b0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.jxpath.JXPathException\012",
        Z.run(T, 1, 9, 5, 9, "\ud899\udd47\udab5\udf09\ud854\ude47\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u7a69\u257c\u3c17", "\udbe4\udcf1\ud9c9\udc62\udb3e\udc56\ud843\udf38\udbe9\udd75\ud93a\udc5a",
        21, 73248, -1373618200, -8839639902244547332L, -47993L, false, false, (char) 14360, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\uda99\udd6b\udad7\udcf6\uda01\udce1\uda10\uddaa' |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\uda99\udd6b\udad7\udcf6\uda01\udce1\uda10\uddaa'\012",
        Z.run(T, 1, 10, 6, 5, "\ud899\udd47\udb0a\udc73\uda99\udd6b\udad7\udcf6\uda01\udce1\uda10\uddaa", "\u3c7e", "\ufc78\ud8ed\udc3e\udb7d\udcc7\udbe4\udcf1\ud9c9\udc62\udb3e\udc56\ud843\udf38\udbe9\udd75\ud927\udf5e\ud929\udf64\udaa6\udfca\u9300",
        22, 53972, 497007275, -1485235504044056816L, 88871L, false, true, (char) 27157, (char) 9741,
        Double.longBitsToDouble(0x3fd77ca350c62528L), Double.longBitsToDouble(0x3fbf39d6e9bb7340L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\udbaa\udd5a\udb0a\udc73\udb88\udee3\ud867\udfe6\uda01\udce1\udbd9\udd2f\ud872\udcd4'\012",
        Z.run(T, 1, 14, 2, 9, "\udbaa\udd5a\udb0a\udc73\udb88\udee3\ud867\udfe6\uda01\udce1\udbd9\udd2f\ud872\udcd4", "\u5d25\u407d\u3c17\u2a4a\u24d7\u713b\u6008\u8d67\u5fbc", "\ud929\udf64\udaa6\udfca\udbfe\udde6\ud9fe\ude3c\udb2f\udf49\udbad\udc69\ua8f7\udb5e\udc43\ud864\udd83\udb42\udc86\ud940\udf15\ud80f\udc1e",
        53, 11980, 1584648639, 1806474865054086000L, -93722L, false, false, (char) 15113, (char) 27955,
        Double.longBitsToDouble(0x3fe1d9e732b96b2bL), Double.longBitsToDouble(0x3fe5c8c5ee4fa982L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 12, 6, 3, "\ud8b5\udc2e\udbd1\udc16\ud830\udffc\udac3\udde6\udbef\udd6f\ud9ab\udca6\udb73\udf96", "\u521d", "\uda8b\udfba\udb7d\udcc7\udbe4\udcf1\ud9c9\udc62\udb3e\udc56\ud843\udf38\udbe9\udd75\ud93a\udc5a\ud929\udf64\udaa6\udfca\udbfe\udde6\ud9fe\ude3c\udb2f\udf49\udafa\udef0\ud83c\ude55\ud9b1\udebc\ud864\udd83\udb42\udc86",
        27, 78761, 981687713, 8968699081586864319L, -68118L, false, false, (char) 715, (char) 52106,
        Double.longBitsToDouble(0x3fe3aa9e2210a890L), Double.longBitsToDouble(0x3fbb44ecc1daf508L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 1, 15, 6, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.apache.commons.jxpath.JXPathException\012",
        Z.run(T, 1, 8, 6, 9, "\ud88f\udd34\udb0a\udc73\udb91\udee3\ud837\udde6\uda01\udce1\udbb4\udff1", "\u1eff\u521d", "\uda8b\udfba\udb7d\udcc7\udbe4\udcf1\ud9c9\udc62\udb3e\udc56\ud843\udf38\udbe9\udd75\ud93a\udc5a\ud935\udc64\udaa6\udfe1\udbfe\udde6\ud9fe\ude3c\udb1e\udfa0\udbad\udc82\ua8f7\udb5e\udc43\ud864\udd83\ud915\udc6e",
        27, 78761, 981687713, 8968699081586864319L, -80526L, false, true, (char) 39910, (char) 54709,
        Double.longBitsToDouble(0x3fe804a5f038ac71L), Double.longBitsToDouble(0x3fe0f3769258e635L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.PropertyIterator:@? |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 1, 3, 6, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\ubdb3\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, 1800633297, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f' |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\0121=!org.apache.commons.jxpath.JXPathException\012",
        Z.run(T, 2, 4, 7, 8, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, 257882876, 2134514117730591278L, -92706L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.PropertyIterator:@? |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f\udbed\udf93\ud8b8\udd58\u82b5\ud9a2\udf10\udbfc\uddc5\udbcb\udf92\uda8b\udfba\udb7d\udcc7\udbe4\udcf1\ud9c9\udc62\ud880\udc57\ud843\udf38\udbe9\udd75\ud93a\udc5a\ud929\udf64\udaa6\udfca\udbfe\udde6\ud9fe\ude3c\udb2f\udf49\udbad\udc69\ua8f7\udb5e\udc43\ud864\udd83\udb42\udc86\ud9b5\ude8f\udb8f\udc1e'\012",
        Z.run(T, 1, 3, 6, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f\udbed\udf93\ud8b8\udd58\u82b5\ud9a2\udf10\udbfc\uddc5\udbcb\udf92\uda8b\udfba\udb7d\udcc7\udbe4\udcf1\ud9c9\udc62\ud880\udc57\ud843\udf38\udbe9\udd75\ud93a\udc5a\ud929\udf64\udaa6\udfca\udbfe\udde6\ud9fe\ude3c\udb2f\udf49\udbad\udc69\ua8f7\udb5e\udc43\ud864\udd83\udb42\udc86\ud9b5\ude8f\udb8f\udc1e", "\u0b8a\uc786\uc74c\u96f5\u8904\u282a\u4540\u87b0\u1fe4\uafa0", "\ud990\udefa",
        12, 65984, 586053504, -450523453735261961L, -67622L, true, false, (char) 42770, (char) 52392,
        Double.longBitsToDouble(0x3f958698de19cb20L), Double.longBitsToDouble(0x3fc2651c2ab2f564L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 9, "\udae9\ude3e\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\ubbda", "\u3c7e\u67ce\u3f8e\u3c17\u2a4a\u5dd1\u3213\002\u8cd7", "\000\ud9e8\udf94\udaa6\udfca",
        12, 39128, 21756, 46L, -47993L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fda14b000000106L), Double.longBitsToDouble(0x3fc7ef8001f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 12, 6, 9, "\ud8a3\udc2f\udb0a\udc73\udb88\udee3", "\u1dd3\u8f1f\u2408\u3c7e", "\ud979\udcf1\uda8b\udfba\udb7d\udcc7\uda83\udfee",
        39, 51224, -588148407, -138611503025533081L, 23797L, false, false, (char) 23043, (char) 32717,
        Double.longBitsToDouble(0x3fea72cd34d98ca7L), Double.longBitsToDouble(0x3fd844f27af556aeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\0121=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 2, 14, 15, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u2c99\ub423\u2a4a\ub2da\ucc23\u0ba9\u57b7", "\ud939\udff7\ud929\udf64\udaa6\udfca\udbfe\udde6\ud9fe\ude3c\udb2f\udf49\udbad\udc69\ua8f7\udb5e\udc43",
        57, 63124, -952706950, -3287059618789630559L, 72505L, false, true, (char) 50088, (char) 17987,
        Double.longBitsToDouble(0x3fe1248d614a6deaL), Double.longBitsToDouble(0x3fe86464d79b8447L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\uda34\ude87\uda81\udd3e\ud951\udc6c\uda01\udce1\udbd9\udd2f\udbed\udf93\ud8b8\udd58\udb56\udd4d |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\uda34\ude87\uda81\udd3e\ud951\udc6c\uda01\udce1\udbd9\udd2f\udbed\udf93\ud8b8\udd58\udb56\udd4d'\0121=org.apache.commons.jxpath.ri.model.beans.PropertyIterator:@? |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\uda34\ude87\uda81\udd3e\ud951\udc6c\uda01\udce1\udbd9\udd2f\udbed\udf93\ud8b8\udd58\udb56\udd4d'\012",
        Z.run(T, 2, 13, 3, 11, "\ud899\udd47\uda34\ude87\uda81\udd3e\ud951\udc6c\uda01\udce1\udbd9\udd2f\udbed\udf93\ud8b8\udd58\udb56\udd4d", "\u3c17\u2a4a\ubad9\u28f4\u6008\u8d67\u5fbc\u4b4b", "\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud989\uddef\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud989\uddef\uda01\udce1\udbd9\udd2f'\0121=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud989\uddef\uda01\udce1\udbd9\udd2f' |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud989\uddef\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 2, 13, 10, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud989\uddef\uda01\udce1\udbd9\udd2f", "\u3c7e\u9268\u18e7\u1224\u2a4a\ub2da\uaaa7\u4f18\u8d67", "\uda4e\udc03\ud929\udf59\udaa6\udfca",
        52, 39128, -1621601028, 4734132767500231266L, -88249L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud82b\udce6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud82b\udce6\uda01\udce1\udbd9\udd2f'\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 0, 0, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud82b\udce6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\uabc5\000",
        -5, -1000, -1621601280, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3f32ca0260041800L), Double.longBitsToDouble(0x3f3f1dc3e73ad800L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 6, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u9939\uabd0\u3c44\u2a4a\ub2da\u713b\u6008\u103e", "\ud947\udcf0\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\000\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\000\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 0, 9, "\ud899\udd47\000\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991999078446L, 96608L, false, true, (char) 9559, (char) 51043,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud86f\udd3f\ud994\udc61\udbd6\udca5' |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud86f\udd3f\ud994\udc61\udbd6\udca5'\0121=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud86f\udd3f\ud994\udc61\udbd6\udca5' |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud86f\udd3f\ud994\udc61\udbd6\udca5'\012",
        Z.run(T, 2, 4, 10, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud86f\udd3f\ud994\udc61\udbd6\udca5", "\u3c7e\u521d\u407d\ua2ec\u90cd\u2958\u71f6\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 29612,
        Double.longBitsToDouble(0x3fda12bc50987506L), Double.longBitsToDouble(0x3fedfbe3b87ce75bL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\0121=!org.apache.commons.jxpath.JXPathException\012",
        Z.run(T, 2, 13, 8, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\uda71\ude67\ud9b3\udc93",
        22, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.PropertyIterator:@? |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47'\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 1, "\ud899\udd47", "\u73d8\uc7b4\u1dd3", "\u82b5\ud9a2\udf10\ud817\ude92\udbab\uddea\ud969\ude65\udb7d\udc61\udbe4\udcf1\ud9c9\udc62\udb3e\udc56",
        30, 45995, -2006888601, -5352620770858923896L, -8208L, false, false, (char) 23043, (char) 32717,
        Double.longBitsToDouble(0x3fe8875b1cd98ca7L), Double.longBitsToDouble(0x3fd844f27f67ca98L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:\udb45\udf1c |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\udb45\udf1c'\0121=java.lang.String:\udb45\udf1c |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\udb45\udf1c'\012",
        Z.run(T, 2, 13, 13, 14, "\udb45\udf1c", "\u73c7\uc7b4\u1dd3", "\u82b5\ud896\udc2a\udbfc\uddc5\udbcb\udf92\u411d\ud87d\udfc9\udbe4\udd5c\ud9c9\udc62\udb3e\udc56",
        58, 49987, 509693828, -8178000660229879805L, -2761L, false, false, (char) 23043, (char) 32717,
        Double.longBitsToDouble(0x3fe8875b1cd98ca7L), Double.longBitsToDouble(0x3fd844f27af556aeL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47 |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47'\0121=!org.apache.commons.jxpath.JXPathException\012",
        Z.run(T, 2, 13, 8, 3, "\ud899\udd47", "\u73d8\uc7b4\u1dd3", "\u82b5\ud9a2\udf10\udabc\udd04\udbcb\udf92\uda8b\udfba\udb7d\udcc7\udbe4\udcf1\ud9c9\udc62\udb3e\udc56",
        58, 45995, 291589991, -5352620767570589560L, -8208L, false, false, (char) 23043, (char) 32717,
        Double.longBitsToDouble(0x3fe8875b1cd98ca7L), Double.longBitsToDouble(0x3fd844f27af556aeL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 11, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u6008\u8d67", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.PropertyIterator:@? |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\udbdf\udf1e'\0121=org.apache.commons.jxpath.ri.model.beans.PropertyIterator:@? |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\udbdf\udf1e'\012",
        Z.run(T, 2, 3, 3, 9, "\udbdf\udf1e", "\u8c22\uc7b4\u57e7", "\u82b5\uda62\udd4f\u8c6b\udbcb\udf92",
        53, 13936, 838467072, 5351710129859181968L, -82109L, true, true, (char) 13350, (char) 15935,
        Double.longBitsToDouble(0x3fcd15f264db341cL), Double.longBitsToDouble(0x3fb24c90155cfac0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\udbe9\udf0d\udae1\udec3\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\0121=null |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\udbe9\udf0d\udae1\udec3\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 2, 14, 14, 11, "\udbe9\udf0d\udae1\udec3\udb88\udee3\ud837\udde6\uda01\udce1\udbd9\udd2f", "\ud208\u343f\u0d9c\u3c17\u2a4a\u1114\u71b3\u6008\ub2c7", "\ud93a\udc5a\ud929\udf64\udaa5\udfca",
        12, 40744, 461518834, 3045282411251458792L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280487a60L), Double.longBitsToDouble(0x3fc7ef8ef93b9d6cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\ud80a\uddc0\udb15\udc82\uda2e\udca6\ud867\udf52\uda01\udd15\uda7d\udc81\ud8a7\udcd6\ud8b8\udd58\u82b5\ud9a2\udf10\uda04\udec9\udbcb\udf92\uda8b\udfba |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud80a\uddc0\udb15\udc82\uda2e\udca6\ud867\udf52\uda01\udd15\uda7d\udc81\ud8a7\udcd6\ud8b8\udd58\u82b5\ud9a2\udf10\uda04\udec9\udbcb\udf92\uda8b\udfba'\0121=!org.apache.commons.jxpath.JXPathException\012",
        Z.run(T, 2, 13, 9, 7, "\ud80a\uddc0\udb15\udc82\uda2e\udca6\ud867\udf52\uda01\udd15\uda7d\udc81\ud8a7\udcd6\ud8b8\udd58\u82b5\ud9a2\udf10\uda04\udec9\udbcb\udf92\uda8b\udfba", "\u1be5", "\udbe9\udd75\uda2d\uddf3\ud924\udec9\udaa6\udff1\udbba\udf44\ud85b\udd3d\ud81f\udf23\udba5\udee4\uda11\udef9\udb5e\udcc0\ud864\udd83\ud927\ude66\udb08\udef1\udb56\udf2d\ud886\udc57\udb2a\udeb1\ud8b5\udf4b\ud8e6\udfba\uda1a\ude8a\ud93c\udc89\udb43\udeeb\udbd9\udf67\ud959\ude54\udb6a\udf9a\ud8a7\udf6f\ud97f\udc09\uda9b\udda1\ud9c6\udee3\udbce\ude9f\uda72\udd3b\ud891\ude94\uda70\udf6a\uda01\udd70\uda62\uddf9\ud9b0\udc9f\udabd\uddcd\uda87\uddce\uda16\udee8\ud943\udd81\ud8a5\udd4d",
        22, 20361, -2083144577, 3861103125538139303L, 26359L, false, true, (char) 48297, (char) 29176,
        Double.longBitsToDouble(0x3feb02b55e655e54L), Double.longBitsToDouble(0x3fd6632bbfd9948eL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud88f\udd03\udb13\ude32\ud899\udef9\udad7\udc70\ud836\udf9e\ud9b4\udfef' |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud88f\udd03\udb13\ude32\ud899\udef9\udad7\udc70\ud836\udf9e\ud9b4\udfef'\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 5, "\ud88f\udd03\udb13\ude32\ud899\udef9\udad7\udc70\ud836\udf9e\ud9b4\udfef", "\u3c7e\ub1c2\u407d\u964d\u8179\ub2da\u713b\u3598", "\ud8b7\udf05\udaf1\uddf5\uda3d\ude6b\udab9\ude04\ud8ff\ude51\ud9e6\udccf\udb44\udf1b\udbad\udc69\ud95b\udff9\ud85f\ude63\ud8c7\ude47\ud8c7\udf86\ud9b5\ude8f\ud9c0\uddc5\ud9a9\udf96",
        2, 21611, 24092796, 8465634897378360821L, 30235L, false, true, (char) 8717, (char) 49816,
        Double.longBitsToDouble(0x3fec7a72b93556dcL), Double.longBitsToDouble(0x3f8730f1310cb980L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\ud885\ude47\ud87b\ude2b\uda31\udc38\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud885\ude47\ud87b\ude2b\uda31\udc38\ud837\udde6\uda01\udce1\udbd9\udd2f'\0121=java.lang.String:\ud885\ude47\ud87b\ude2b\uda31\udc38\ud837\udde6\uda01\udce1\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud885\ude47\ud87b\ude2b\uda31\udc38\ud837\udde6\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 2, 15, 15, 9, "\ud885\ude47\ud87b\ude2b\uda31\udc38\ud837\udde6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2abd\ua3e1\u713b\u2e2a\ubee6", "\ud94c\ude29",
        10, 73248, -855127984, -1592502357598516456L, 58802L, true, false, (char) 47931, (char) 58739,
        Double.longBitsToDouble(0x3fd83c79b0987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.beans.PropertyIterator:@? |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud82b\udce6\uda01\udce1\udbd9\udd2f'\0121=org.apache.commons.jxpath.ri.model.beans.PropertyIterator:@? |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud82b\udce6\uda01\udce1\udbd9\udd2f'\012",
        Z.run(T, 2, 3, 3, 0, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud82b\udce6\uda01\udce1\udbd9\udd2f", "\u3c7e\u521d\u407d\u0463\u2baf\ub2da\u713b\u45e1\u8d67", "\udb23\udfa2\uabc5\000",
        54, -1000, -1621601280, 8759706518491980334L, -47993L, false, false, (char) 60925, (char) 13248,
        Double.longBitsToDouble(0x3f32ca0260041800L), Double.longBitsToDouble(0x3f3f1df9df3ad800L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda99\udfe5\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda99\udfe5\udbd9\udd2f'\012",
        Z.run(T, 1, 13, 6, 9, "\ud899\udd47\udb0a\udc73\udb88\udee3\ud837\udde6\uda99\udfe5\udbd9\udd2f", "\u3c7e\u521d\u407d\u3c17\u2a4a\ub2da\u713b\u3fb2\u4b1a", "\ud93a\udc5a\ud929\udf64\udaa6\udfca",
        12, 39128, -1621601028, 2134629991653270062L, -47993L, false, true, (char) 53457, (char) 55828,
        Double.longBitsToDouble(0x3fda14b280987506L), Double.longBitsToDouble(0x3fc7ef8ee1f39d6cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 12, 3, "\ud899\udd47\u2db4", "\u5f68\ub13a\u23b9\u954e", "\udabc\udd04\udbcb\udf92\uda8b\udfba\udb7d\udcc7\udbe4\udcf1\uda9e\udc6d",
        21, 82217, 2036616576, 1252369473939680197L, -46039L, false, true, (char) 51892, (char) 23043,
        Double.longBitsToDouble(0x3feb542a07102b3aL), Double.longBitsToDouble(0x3fcb21f4e0d39c9cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 12, 12, 0, "", "", "\uda31\ude1a\ud8ad\uddae\udad9\udc7b",
        37, 27446, 105026226, 6217285184408003474L, -100000L, false, false, (char) 13925, (char) 18546,
        Double.longBitsToDouble(0x3feb3bcb23c51161L), Double.longBitsToDouble(0x3fc116b6f4de678cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 5, 0, "", "", "\ud95c\udfd4\ud8ad\uddae\udad9\udc7b",
        37, 23030, 104995944, 6217285184408003474L, -100000L, false, false, (char) 13925, (char) 18546,
        Double.longBitsToDouble(0x3feb3bcb23c51161L), Double.longBitsToDouble(0x3fc116b6f4de678cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:\ud899\udd47\ua60e\u5253\uda7a\udcb4\ud9fc\udce2\udbd9\udd2f |this=org.apache.commons.jxpath.ri.model.beans.BeanPointer:'\ud899\udd47\ua60e\u5253\uda7a\udcb4\ud9fc\udce2\udbd9\udd2f'\012",
        Z.run(T, 1, 13, 6, 9, "\ud899\udd47\ua60e\u5253\uda7a\udcb4\ud9fc\udce2\udbd9\udd2f", "\u3c7e\u2079\u07ea", "\udb7d\udcc7\udbe6\ude74\ud8a0\ude6e\udb3e\udc56\u92c9\ucdfe\ud93a\udc5a\ud929\udf64",
        38, 88992, -2047433001, 786264047910892794L, 95049L, false, true, (char) 55828, (char) 43209,
        Double.longBitsToDouble(0x3fb30ea0c5fbe3b8L), Double.longBitsToDouble(0x3fd5be75ba332dbaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.NodePointer|compareNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,int,org.apache.commons.jxpath.ri.model.NodePointer,int|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|asPath||fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|attributeIterator|org.apache.commons.jxpath.ri.QName|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|childIterator|org.apache.commons.jxpath.ri.compiler.NodeTest,boolean,org.apache.commons.jxpath.ri.model.NodePointer|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|clone||fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|compareChildNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.model.NodePointer|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|compareTo|java.lang.Object|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|createAttribute|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int,java.lang.Object|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|createPath|org.apache.commons.jxpath.JXPathContext|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|createPath|org.apache.commons.jxpath.JXPathContext,java.lang.Object|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|equalStrings|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|getBaseValue||fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|getDefaultNamespaceURI||fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|getImmediateNode||fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.NodePointer|compareNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,int,org.apache.commons.jxpath.ri.model.NodePointer,int|fac:org.apache.commons.jxpath.ri.model.NodePointer:newNodePointer:org.apache.commons.jxpath.ri.QName,java.lang.Object,java.util.Locale",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
