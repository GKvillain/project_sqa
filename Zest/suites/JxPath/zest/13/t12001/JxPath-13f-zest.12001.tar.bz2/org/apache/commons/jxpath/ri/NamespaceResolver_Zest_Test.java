package org.apache.commons.jxpath.ri;
import org.junit.Test;
import static org.junit.Assert.*;
public class NamespaceResolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 19, 14, "\ud803\udd6f", "\u6ede\u2022\u2318\u12c4\u2349\u9094\u3282\u4d49", "\ud865\udfe3\uda45\udeb6\ud813\udf96\ud86f\uddda\udbc6\udfc4\ud9a3\udf58",
        13, 78635, -764390024, 8718821946812180620L, -56193L, true, true, (char) 479, (char) 50005,
        Double.longBitsToDouble(0x3fe8047ac92b11beL), Double.longBitsToDouble(0x3f9c044ee60323c0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 21, 19, "\ud83c\udca2", "\u6ede\u2022\u2318\u12c4\u2349\u5828\uc161\ua035", "\ud8a1\uddf7\ud841\udeb4\ud813\udf96",
        25, 91414, 613240113, 2920539741882842443L, 31777L, true, true, (char) 30451, (char) 14712,
        Double.longBitsToDouble(0x3fde122be038089cL), Double.longBitsToDouble(0x3fe980c8f0c337deL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.NamespaceResolver:@? |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 7, 8, 10, "\udb88\udc45", "\u138d\u92c1\uc7f8\ua6f1\ua2ea\u2b5d\u0893\u949c", "\ud865\udfe3\uda45\udeb6\ud813\udf96\ud86f\uddda\udbc6\udfc4\ud9a3\udf58",
        13, 12267, -1387410312, 7710057081010248890L, -56193L, true, true, (char) 479, (char) 50005,
        Double.longBitsToDouble(0x3fe8047ac92b11beL), Double.longBitsToDouble(0x3fd588fc95a6ced2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 19, 0, "\000", "\u6ede", "\uda96\udc42",
        3, 17337, 69850515, -2303807615658811629L, 75207L, true, true, (char) 37250, (char) 60223,
        Double.longBitsToDouble(0x3e44c4d400000000L), Double.longBitsToDouble(0x3feb61246d4b2887L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 9, 9, 14, "\ud803\udd6f", "\u6ede\u2022\u2318\u12c4\u2349\u9094\u3282\u4d49", "\ud865\udfe3\uda45\udeb6\ud813\udf96\ud860\uddda\udbc6\udfc4\uda62\ude53",
        13, 78635, -767834760, 8718821946812180620L, -56193L, true, true, (char) 479, (char) 50005,
        Double.longBitsToDouble(0x3fe8047acd2b57beL), Double.longBitsToDouble(0x3f9c044ee60323c0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 0, 0, 14, "\ud803\udd6f", "\u6ede\u26f3\u2318\u12c4\u2349\u9094\u3282\u7b36", "\ud865\udfe3\u3d3b\ud92c\udf76\ud86f\uddda\udbc6\udf26\ud9a3\udf58",
        23, 78560, -764390024, 8718821946812180620L, -56193L, true, true, (char) 479, (char) 50005,
        Double.longBitsToDouble(0x3fe8047ac92b11beL), Double.longBitsToDouble(0x3f9c044ee60323c0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 11, 11, 20, "\ud803\udd6f\udbec\ude8e\udb66\udfce\uda6d\udcb9\udb25\ude1a", "\u2349\u9094\u3282\u2abd\u847c\u9efd\u627d\uc228\ua95d\u26b1\uc002\u4883\u1746\ub4cd\u1f78\u49c6\u6db9\u25d9\u7751\uc5bd\uc237\u3add\ua09a\u4645\uc5e1\u64d9\u469f\u967c\u0cdc\u3a61", "\ud9b9\udeed\ud89c\udf8a\ud887\udeaf\udafc\udc63\udb82\udcdc\ud96f\udeab\ud951\udf60\udaf5\uddda\ud8d8\ude31\uda3f\udcce\ud85c\udd62",
        3, 63187, -790418796, -5886352171933221898L, -20977L, true, true, (char) 47670, (char) 15127,
        Double.longBitsToDouble(0x3feb1d6e8c17ff3aL), Double.longBitsToDouble(0x3fb2d9a485e4ed38L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 17, 11, 14, "\ud803\udd6f", "\u6ede\u2022\u2318\u12c4\uc604\u0917\u8482\u8d82", "\ud874\uded5\uda45\udeb6\ud813\udf96\ud86f\uddda\udbc6\udfc4\ud9a3\udf58\ud9be\uddcf\ud8f1\udc13",
        26, 8926, -945903476, -2630875007145909023L, 1632L, true, true, (char) 64617, (char) 16488,
        Double.longBitsToDouble(0x3fe6ed5a6c45f67bL), Double.longBitsToDouble(0x3fd6776a73f57f04L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.NamespaceResolver:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 19, 14, "\ud803\udd6f", "\u6ede\u9e6b\u2318\u12c4\u4a65\u2702\u3282\u4d49", "\ud865\udfe3\udb3e\ude11\uda8f\udf0b\ud86f\uddda\udbc6\udfc4",
        13, 47604, -346653365, -3283030154719954421L, 79937L, true, false, (char) 3151, (char) 63309,
        Double.longBitsToDouble(0x3fc59c552c023d64L), Double.longBitsToDouble(0x3fd2b11be038089cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 16, 11, 14, "\ud82d\ude24\ud85c\udcf3\udb67\udc20", "\u2318\u12c4\u2349\u9094\u3282", "\ud965\udf5b",
        13, 95979, -1284348903, -6600048069337770451L, -86820L, false, false, (char) 38461, (char) 19693,
        Double.longBitsToDouble(0x3fbbde3fd1232040L), Double.longBitsToDouble(0x3fcc3b6facfec43cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 21, 19, 14, "\ud803\udd6f", "\u6ede\u2022\u3a9f\u12c4\u5ab3\u9094\u3282\u4d49", "\ud865\udfe3\uda45\udeb6\ud813\udf96\ud86f\uddda\udbc6\udfc4\ud9a3\udf58\ud9be\uddcf\ud8de\udcfd\ud826\udf16\udb79\ude4c\uda87\udc62\udb21\udda0\ud818\udf73\ud8ed\udfca\ud95a\udec8\ud9f0\ude08\udac7\ude0b\uda5c\udd72\udbee\udd96\ud83b\udd6c\uda7d\udd08\ud84c\ude92\u65c1\ud997\udd76\ud8d3\uddf4\uda27\ude72\uda3a\udc4f\uda72\udfdb\udbe2\udcf9\udbde\udf0b\ud8c8\udcf8\udb0e\udc65",
        -5, 95820, -57394376, 1998092545117213840L, 21286L, false, false, (char) 675, (char) 24717,
        Double.longBitsToDouble(0x3fdb1396359ac672L), Double.longBitsToDouble(0x3fe058603440c8e9L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 14, 18, "\ud803\udd6f", "\u6ede\u8854\u8c59\u1302\u5477\uc386\u87f6\u46c2", "\ud865\udfa6\uda45\udeb6",
        2, 20560, 897359160, 7763451781052880696L, 74220L, true, true, (char) 47966, (char) 11044,
        Double.longBitsToDouble(0x3fe47466d8ace2a9L), Double.longBitsToDouble(0x3fe8047ace4e46beL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 20, 15, 8, "\udaf6\udf3d", "\uc122\u7b7d\u2318\u65ac\u18a3\u95a8\ua4a2\u6b7d\u847c", "\uda45\udeb6\ud813\udf96",
        46, 95295, -1546649901, 2920539956631207243L, -65790L, false, true, (char) 57614, (char) 12383,
        Double.longBitsToDouble(0x3fea5e613131bd66L), Double.longBitsToDouble(0x3fc58e97fc023d64L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 10, 19, 14, "\000", "", "\000\ud826\udc93\u3f26\ud802\udee1\udb33\uddd1",
        15, 35331, 947907591, 4261157753972145467L, -94688L, false, false, (char) 33453, (char) 64504,
        Double.longBitsToDouble(0x3fd4b0087af1d6acL), Double.longBitsToDouble(0x3fe00693808c78ffL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 14, 19, 14, "\ud803\udd6f", "\u6ede\u2022\u2318\u12c4\u2349\u9094\u3282\u4d49", "\ud865\udfe3\uda45\udeb6\ud813\udf96\ud86f\uddda\udbc6\udfc4\ud9a3\udf58",
        13, 78635, -764390024, 8718821946812180620L, -56193L, true, true, (char) 479, (char) 50005,
        Double.longBitsToDouble(0x3fe8047ac92b11beL), Double.longBitsToDouble(0x3f9c044ee60323c0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 8, 19, 14, "\ud803\udd6f", "\u6ede\u2022\u2318\u12c4\u2349\u6eb4\u3282\u262d\u4d01\u9efd\u627d\uc228\u7140\u26b1\uc002\u4883\u6f75\ub4cd\u318b\u605f\ucba6\u06a9\u7751\uc5bd\u29bd\ubb28\u65a8\u4645\uc5e1\u812d\ub314\u5a57\u7f3e\u05b6\u5448\u1029\u3c8f\u2303", "\ud95e\udcc8\udaad\udf8a\udafd\udc8f\udb77\udf3b\uda9d\ude34\udabe\ude5c\ud913\udcca\ud9c3\uddb7\ud8d0\ude63\ud89d\udf03\udb88\udd03\u0a93\ud8e1\udddc\ud8a9\udd86\uda06\udcb3\ud990\udce1\ud890\udd74\ud8b5\udc70\ud8fc\udf07\uda17\udc89\uda75\udf3d\ud900\udcc1\uda7d\udcff\uda0f\udfed\udb03\ude94\ud8c5\udf1f\udb45\udc22\uda6f\ude30\udad6\udf80\ud8be\ude8c\udaec\uddf9\ua5cf\ud869\ude9f\udb2b\ude1b\ud822\udd54\ud952\udf3c\ud802\udd1f\ud9d6\udc44",
        49, 18294, -562845439, 8220702974187675327L, -24858L, true, true, (char) 30952, (char) 16177,
        Double.longBitsToDouble(0x3fbe5c33d3d01c88L), Double.longBitsToDouble(0x3fdb887787075a5cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 2, 19, 14, "\u78fc", "\u6ede\u2022\u385e\u12c4\u7ff9\u640c\u3282\u4e07", "\ud865\udfe3\uda45\udeb6\ud813\udf96\ud86f\uddda\udbc6\udfc4\ud9a3\udf58",
        13, 78635, -764390024, 8718821946812180620L, -56193L, true, true, (char) 479, (char) 50005,
        Double.longBitsToDouble(0x3fe8047ac92b11beL), Double.longBitsToDouble(0x3f9c044ee60323c0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=null\012",
        Z.run(T, 2, 16, 19, 0, "\ud803\udd6f\uda6a\udfad\udb59\udfd4\uda6d\udcb9", "\u12c4", "\udb33\uddd1\uda8a\udd4b\ud807\udef2\udbe1\udf59\ud865\udfe3\uda45\udeb6\ud813\udf96\ud86f\uddda\udb92\udfc4\ud9a3\udf58\ud9be\uddcf\ud8f1\udc13\uda76\udec8\ud9a4\udd7f\ud985\udd39\ud883\udef8",
        45, 72391, -1238839421, -8117209824921596465L, 88444L, false, true, (char) 42755, (char) 31425,
        Double.longBitsToDouble(0x3fbefccccd9db8c0L), Double.longBitsToDouble(0x3fe5e04a1c8985f3L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 1, 13, 21, 14, "\udb0f\uddeb\ud90d\udda1\udb7d\udf32\ud81d\uddda\ud9f3\udde5\ud973\udd65\uda96\udc42\ud9d3\udc67\ud822\ude72\udb33\uddd1\uda8a\udd4b", "\u627d\uc228\ua95d\u26b1\uc002\u4883", "\uda76\udec8\ud9a4\udd7f\ud985\udd39\ud883\udef8\ud854\uddae\ud913\udf22\ud95a\udec8",
        -3, 45952, 72233259, 1810130511873378096L, -55194L, true, false, (char) 22674, (char) 26819,
        Double.longBitsToDouble(0x3fe2e4cba05a1ac8L), Double.longBitsToDouble(0x3fd75a91aea4f186L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 4, "\ud820\udf6f", "\u6ede\u2022\u2318\u3448\u9226\u43da\uaf81\u4d49", "\ud865\udfe3\uda45\udeb6\ud813\udf96\udba6\udf5b\udb6d\ude9a\ud9a3\udf58",
        38, 99907, -2062898817, -6925540864870212980L, -56193L, true, true, (char) 479, (char) 50005,
        Double.longBitsToDouble(0x3fa683b0da5be5b0L), Double.longBitsToDouble(0x3fdfe77e0e131206L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 13, 2, "\ud803\udd6f", "\u6ede\u2022\u2318\u12c4\u2349\u9094\u3282\u4d49", "\ud865\udfe3\uda45\udeb6\ud813\udf96\ud86f\uddda\udbc6\udfc4\ud9a3\udf58",
        37, 78635, 275797368, -6664067005401880449L, -56193L, true, true, (char) 479, (char) 50005,
        Double.longBitsToDouble(0x3fe8047ac92b11beL), Double.longBitsToDouble(0x3f9c044ee60323c0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 1, 17, 19, "\ud83c\udca2", "\u6ede\u2022\u2318\u57c4\ud163\u0592\u624b\u70c7", "\ud8a1\uddf7\ud841\udeb4\ud813\udf96",
        25, 80814, -1686225015, -7824734346318756694L, 31777L, true, true, (char) 30451, (char) 17290,
        Double.longBitsToDouble(0x3fd07c50b038089cL), Double.longBitsToDouble(0x3fe980c8f54137deL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 15, 10, "\ud83c\udca2\ud97b\udd33\ud99c\udfcc", "\u1b5f\u1233\u2349\u5828", "\ud4ff\u4f52\udbb0\udc64\ud841\udeef\ud813\udf96\ud86f\uddce\udbc6\udfc4\ud9a3\udf58\ud9be\ude1c\ud8f1\udc13\uda76\udec8\uda3c\udd56\udade\udd93",
        49, 43547, 2090466623, 647872403767913974L, 43841L, false, false, (char) 8270, (char) 28833,
        Double.longBitsToDouble(0x3f89c97773e2ef80L), Double.longBitsToDouble(0x3feadfc5a445ef13L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 21, 15, "\udaba\udfc1", "\u6f31\u2022\u2318\u12c4\u2349\u5828\ubbe3\u851d\ua1fd\u0950\u1d6c\u19f7\ua95d\u26b1\uc002\u4883\u6f75\ub4cd\u1f78\u35fb\ub051\u9cfa\u7691\u530a\u762c\ua9a6\ua447\u46fb\uc5e1\ub966\u87bc\u19fd\u6cf5\ub14e\u21a5", "\udaa8\udf58\ud973\udfee\u6963\ud832\udfea\ud81d\udcbf\ud8a2\udd2d",
        19, 45101, 729560373, 2944504579743329955L, -53205L, false, false, (char) 36870, (char) 2382,
        Double.longBitsToDouble(0x3fd71b9319af03f6L), Double.longBitsToDouble(0x3fe15fd2dd0f3aacL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 9, 9, 15, "\ud83c\udc81\ud80f\uddf4\udb6e\udc5c\uda6d\udcb9\udb3a\ude07\ud973\udd65\udad0\udee7", "\uc161\ud7e9\u78d6\u0856\u1d6c\u19f7\ua95d\u26b1\u3890\u4883\u6f75\ub4cd\u1f78\u841f\u3552\u9cfa", "\uda64\udfc6\ud9d0\ude90\uda87\udd4f",
        58, 80852, 937297712, -2112125814849872591L, 34764L, true, false, (char) 50708, (char) 13023,
        Double.longBitsToDouble(0x3fcac5631979f81cL), Double.longBitsToDouble(0x3fc33758e042ed44L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 0, 0, 16, "\000", "", "\ud973\udd65\uda96\udc42\ud9d3\udc86\ud949\udfe3\ud991\udd9a",
        30, 70944, 1802633216, 1500543910735183931L, -94688L, false, false, (char) 19761, (char) 64504,
        Double.longBitsToDouble(0x3fb2ca21ebc75ab0L), Double.longBitsToDouble(0x3fe2f69384de7200L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=new org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 11, 14, 19, "\ud83c\udca2", "\u6ede\u2022\u2318\u1228\u2349\u5828\uc161\ua035", "\ud8a1\uddf7\uda09\udeb8\ud813\udf96",
        44, 47714, 606930794, 2920539741882842443L, 68231L, true, false, (char) 79, (char) 6431,
        Double.longBitsToDouble(0x3fdf608fd4258cbaL), Double.longBitsToDouble(0x3fe7b02210197015L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=new org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 13, 14, 19, "\ud83c\udca2", "\u6ede\u2022\u2318\u12c4\u2349\u3c42\uc161\ua035", "\ud8a1\uddf7\ud841\udeb4\ud813\udf96",
        25, 91414, -1331042767, 7099905837037419851L, 31777L, true, true, (char) 30451, (char) 14712,
        Double.longBitsToDouble(0x3fde122be038089cL), Double.longBitsToDouble(0x3fe980c8f4c337deL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.NamespaceResolver:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 21, 19, "\ud83c\udca2", "\u6ede\u2022\u2318\u27ce\u89fe\u57f9\uc161\ua035", "\ud8a1\uddf7\udac3\udff4\ud814\udc0b",
        25, 91414, 613240113, 2920539741882820257L, 30421L, true, true, (char) 52158, (char) 14712,
        Double.longBitsToDouble(0x3fde122bee38089cL), Double.longBitsToDouble(0x3fec7a8d1bacc086L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 19, 13, "\udb13\udf7b", "\u6ede\u2022\u2318\u5149\u23d4\u5828\uc161\ua035", "\ud8a1\uddf7\ud841\udeb4\ud93f\udf6b",
        3, 32662, 613240113, 2920539741882842443L, 31777L, true, true, (char) 30451, (char) 14712,
        Double.longBitsToDouble(0x3fde122be038089cL), Double.longBitsToDouble(0x3fe980c8f0c337deL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=java.lang.String:\u6ede\u2022\u2318\u181a\u2349\u5828\uc161\ua035 |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 10, 16, 8, "\ud83c\udca2", "\u6ede\u2022\u2318\u181a\u2349\u5828\uc161\ua035", "\ud8a1\uddf7\ud93b\udfb9\ud814\udc43",
        25, 91414, 613240113, 2920539741882842443L, 34849L, true, true, (char) 952, (char) 14860,
        Double.longBitsToDouble(0x3fde122be038089cL), Double.longBitsToDouble(0x3fe980c8f0c337deL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.NamespaceResolver:@? |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=org.apache.commons.jxpath.ri.NamespaceResolver:@? |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 7, 7, 1, "\uda4a\udce6\udbd0\uddb5", "\u10e3\uc7f8\uc6f0\uc245\u9358\u0893", "\ud8db\udde9\ud865\udfa4\uda45\udeb6\uda00\udf4c",
        -3, 85782, 1619897346, -4222788498458822940L, -93747L, true, true, (char) 4281, (char) 22310,
        Double.longBitsToDouble(0x3fd5cdf53cae8634L), Double.longBitsToDouble(0x3fea3b7a8b655c28L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 11, 11, 20, "\ud803\udd6f\udbec\ude8e\udb66\udfce\uda6d\udcb9\udb25\ude1a", "\u2349\u9094\u3282\u2abd\u847c\u6fda\u627d\uce4f\u12b4\u12a4\u09c4\u4883\u1746\ub4cd\u1f78\u49c6\u6db9\u25d9\u7751\uc5bd\uc237\u3add\ua09a\u4645\u3ec5\u64db\u469f\u967c\u0cdc\u3a61", "\ud9b9\udeed\ud89c\udf8a\ud887\udeaf\udafc\udc63\udb82\udcdc\ud96f\udeab\ud951\udf60\udaf5\uddda\ud8d8\ude31\uda3f\udcce\ud85c\udd62",
        46, 63187, -790418796, -6202281444393743643L, -37562L, true, false, (char) 42077, (char) 22865,
        Double.longBitsToDouble(0x3fd1c611a44dd1e0L), Double.longBitsToDouble(0x3feb1d6e8c17ff3aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 4, 20, 2, "\uda33\ude6b\udbec\ude8e\ud891\udce2\uda6d\udcb9\ud9de\udc0b\u6d59\uda96\udc54\ud92a\uddb2\ud808\udce0\udb33\uddd1\uda8a\udd4b\ud83b\udeec\udbe6\ude3c\ud84a\udc89\ud92c\uddfc", "\uc002\u4883\u6e45\ub4cd\u1f78\u0235\u908c\u25c4\uaa51\uc975\u29bd\ua07e\ua007\u4645", "\udbc2\udcbd\udb3e\udd00\u246d\uda2b\udc42",
        39, 43325, -980361600, 1692512161321032679L, -27390L, true, true, (char) 11128, (char) 34875,
        Double.longBitsToDouble(0x3fd930cc7ddfa674L), Double.longBitsToDouble(0x3fd50ad54727d5c4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 10, 1, 0, "\udb8d\udda5\ud8d0\udcb1\u199f\uda6d\udcb9\ud967\uddbc\ud973\ude22\uda96\udc42\ud9d3\udc86\u1b64\udb2c\udd94\uda8a\udd4b\ud81f\ude60\ud965\udf5b\u79cb\uda45\udf5e\ud813\udf96\ud86f\uddda\ud87d\ude18\udbc7\udfbc\ud968\udee9\udbc5\ude71\ud8ee\udefb\udaa5\ude34\ud87b\ude54", "\ub9d8\u7a04\u02f9\u9a57\u5457\u5cb2\ua9c0\u908e\u327a\ucd14\u2df0\u40a2\uc060\ud74d\u94ff\u0341\u6077\ub562\ud2a2\u34ff", "\udb7f\ude66\udad8\udfca\ud8aa\udefa\ud8dc\udf14\ud878\udd10\udbe5\udd4d\ud885\udce3\ud86c\udd92\ud963\udeff\udb15\udec7\ud87c\udcd6\u5117\uda3b\udf8e\uda34\udff5\uda4a\udd8b\ub5b8\ud8fe\udf0c",
        53, 15716, 1014595188, 911162411074292066L, 81270L, false, true, (char) 33545, (char) 14472,
        Double.longBitsToDouble(0x3fee9de84e758ba6L), Double.longBitsToDouble(0x3fe6ec933fae301aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 18, 2, 14, "\ud82d\ude24\ud85c\udcf3\udb67\udc20", "\u4024\u12d6\u74e0\u281c\u3282", "\ud965\udf5b",
        13, 16291, -1284348903, -862025291363130483L, -86820L, false, false, (char) 33113, (char) 42732,
        Double.longBitsToDouble(0x3fdd01add19390e2L), Double.longBitsToDouble(0x3fcc3be90cfec43cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=null |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 8, 8, 19, "\ud933\udc5c\u4a16\udb66\udfce\uda6d\udcb9\udb3a\ude07\ud973\udd65\udaa7\udd42\ud9bb\uddc7\udbdc\ude37\ud979\ude84\ud96c\udfd6\ud4ff\u4f52\ud8a1\uddf7\udb5d\udf2f\ud824\udf96\ud86f\uddda\ud8fd\udde0\udab6\udd9c\udaef\udf2b\u3088\ue8c5", "\u02cf\u7691\u2008\u762c\ua9a6\u374c\u4621\uc8bb\ub966", "\ud8de\udf0d\udbe9\udc8b\ud8cd\udc4a\ud985\udfe6\udb90\udd0b\udb43\udd9b\udbd4\udf21\ud85d\ude90\u36d6\udaca\udf49\u1efb",
        49, 59048, -2011566301, -6014897216922273888L, -81576L, false, true, (char) 572, (char) 29590,
        Double.longBitsToDouble(0x3fefbc58c146cea6L), Double.longBitsToDouble(0x3fea79d2cd10d58dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 10, 21, "\ud83c\udca2", "\u6ede\u2022\u2318\u1228\u2349\u5828\uc161\ua035", "\ud8a1\uddf7\uda09\udeb8\ud813\udf96\ud985\udfe7\ud89d\udf0d\udb06\udd8b\ud9be\uddcf\ud8f1\udc13\uda76\udec8\ud8d9\udd50\udb9b\uddde\ud8f3\udda4\ud807\udfdc\udbb0\udfcd\uda65\udc0c\ud9d0\ude90\ud8e4\ude52\udb4f\udfdc\ud835\udfda\ud9ef\udf16\udb4d\udee5\ud80f\udfc9\udb69\ude34\ud8c0\udc34\udb5a\uddf2\uda07\udd1e\udacf\udcc3\ud8b9\udebc\ud9be\udebb\udbf1\udc41\ud9c1\udea7\ud983\udff2\ud884\udfff",
        12, 34866, -312870963, 5573939002780449482L, -72132L, true, true, (char) 6354, (char) 16499,
        Double.longBitsToDouble(0x3fd403698867b478L), Double.longBitsToDouble(0x3fd4ad7a5bfcfddcL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 19, 13, "\udb13\udf7b\udbec\udf03\udb66\udfce\uda6d\udcb9\uda16\udfe9\ud973\uddcb\ud921\ude27\udbf2\ude22", "\ua035\u78d6\u0856", "\ud871\udd7e\ud838\uddd5\uda6c\udfbd",
        59, 58148, 1565949259, -3283845158983391906L, -96013L, true, false, (char) 30030, (char) 31518,
        Double.longBitsToDouble(0x3fdf60892abf73e4L), Double.longBitsToDouble(0x3fde122be038089cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=java.lang.String:\u2022\u2318\u181a |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 10, 2, 20, "\udafd\udc8c\u1d9b", "\u2022\u2318\u181a", "\ud991\udd9a\ud85e\udfcf\ud4ff\u4f52\ud8a1\uddea\ud93b\udfb9\ud814\udc43\ud86f\uddda\udbc6\udfc4\ud9a3\udf58\ud9be\uddcf\ud8f1\udc13\uda62\ude7f\ud8c9\udd1c\udbd1\udfb7\ue727",
        48, 33023, 1090343813, -4111290875814972646L, 88444L, false, true, (char) 28833, (char) 12407,
        Double.longBitsToDouble(0x3febae0b5c0bcfcbL), Double.longBitsToDouble(0x3fc4b5773a610748L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 10, 10, 8, "\ud83c\udca2", "\u6f46\u2022\u2318\u181a\u2349\u5828\u8861\ua035\u78d6\u0856\u1d6c\u0928\uaa0a\u26b1\uc002", "\ud8f1\udc13\uda62\ude7f",
        50, 65790, 86798041, -5688235304614760129L, 15387L, false, true, (char) 20910, (char) 33037,
        Double.longBitsToDouble(0x3fe980c8f0c337deL), Double.longBitsToDouble(0x3fd61005c39b687aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\0121=java.lang.String:\ud83c\udca2 |this=org.apache.commons.jxpath.ri.NamespaceResolver:@?\012",
        Z.run(T, 2, 10, 20, 8, "\ud83c\udca2", "\u6ede\u4422\u2318\u7419\u4a7f\u5828\uc1be\ua32b", "\udaa1\ude01\uda84\udfaf\ud8d7\udf65\ud972\udf08\udbc6\udfc4\ud9a3\udf58\ud9be\uddcf\ud8f1\udc13\uda62\ude7f\ud8c9\udd1c\udbd1\udfb7",
        26, 30749, 597266992, -377791745289502021L, 32912L, false, true, (char) 20331, (char) 22031,
        Double.longBitsToDouble(0x3fde99ba69285ec2L), Double.longBitsToDouble(0x3fd19b6e3e3a152aL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 19, 6, "\ud81f\udf09", "\u6ede\u2022\u6cb3\u7b7a\u2349\u9094\u3282\u9a3a", "\uda2e\udf68\uda45\ude87\udbb7\udf99\ud86f\uddda\udbc6\udfc4",
        13, 58148, -346653365, -3283030152438646178L, 79937L, true, false, (char) 19022, (char) 16193,
        Double.longBitsToDouble(0x3fc59c552c023d64L), Double.longBitsToDouble(0x3fd2b11be038089cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.NamespaceResolver:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=org.apache.commons.jxpath.ri.NamespaceResolver:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 6, "\udafd\udc8c\u1d9b", "\u6427\u6cea\uaea4", "\ud991\udd9a\udae3\udf72\ud4ff\udb86\udeec\uf54c\ud93b\udfb9\ud814\udc43\ud86f\uddda\udbc7\udc25\udabb\ude17\ud9be\uddcf\ud8f1\udc13\ud9e4\ude80\ud8c9\udd1c\udbd1\udfb7\ue727\ud807\udf7a",
        53, 47813, -957234501, 2503564998443151841L, 32912L, true, false, (char) 60794, (char) 36706,
        Double.longBitsToDouble(0x3fcfd2fa8296acc4L), Double.longBitsToDouble(0x3fe4c20e9442bd65L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getExternallyRegisteredNamespaceURI|java.lang.String|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getExternallyRegisteredPrefix|java.lang.String|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getNamespaceURI|java.lang.String|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getPrefix|org.apache.commons.jxpath.ri.model.NodePointer,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getPrefix|java.lang.String|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createAttribute|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getNamespaceResolver||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|clone||new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getNamespaceContextPointer||new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|isSealed||new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|registerNamespace|java.lang.String,java.lang.String|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|seal||new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|setNamespaceContextPointer|org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "C|org.apache.commons.jxpath.ri.NamespaceResolver|<init>|org.apache.commons.jxpath.ri.NamespaceResolver",
    "C|org.apache.commons.jxpath.ri.NamespaceResolver|<init>|",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|asPath||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getExternallyRegisteredNamespaceURI|java.lang.String|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getExternallyRegisteredPrefix|java.lang.String|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getNamespaceURI|java.lang.String|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getPrefix|org.apache.commons.jxpath.ri.model.NodePointer,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.NamespaceResolver|getPrefix|java.lang.String|new:org.apache.commons.jxpath.ri.NamespaceResolver:",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createAttribute|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getNamespaceResolver||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
