package org.apache.commons.jxpath.ri.model.dom;
import org.junit.Test;
import static org.junit.Assert.*;
public class DOMNodePointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 15, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u93bf\ub595\u55bb\u6de9\ua036\u85cb\u4758\ud3cc\u687b\u5574\ub685\u31ea", "\ud848\udf20\ud9e0\ude9f\uda09\udc98\ud9d1\udfd2\uda51\ude9e\ud9cb\udc14",
        58, 81316, -192158192, -8236986850789815042L, 59595L, true, false, (char) 52451, (char) 17491,
        Double.longBitsToDouble(0x3fe79c05418bb058L), Double.longBitsToDouble(0x3fd89fd3b4878b38L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 5, "U", "", "\udb33\uddba\ud9c8\udf2f\ud87a\uddfd\ud8d7\udc36\000\uda38\ude08\ud919\ude2c\ud8c2\uddbe\ud87f\udc20\udafb\udea3\ud982\udfba\000\ud98c\udd25\ud931\udf1d\udb22\ude4c\ud8ca\udd57\udb71\udf87\udbe1\udee4\ud848\udf20\ud9e0\ude9f\uda09\udc98\ud9d1\udfd2\uda51\ude9e\ud9cb\udc14\uda6d\ude5d\uda98\udfd0",
        3, 65050, 0, 8718968877789900651L, -26283L, true, false, (char) 32297, (char) 23984,
        Double.longBitsToDouble(0x3fa2702f1b3ecce0L), Double.longBitsToDouble(0x3fd2d1158d2b67a4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 15, "\ud968\udc1a\ud823\udcca\u43ca\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u93bf\ub595\u55bb\u6de9\u879b\u85c8\u4758\ud3cc\u687b\u2c35\ud159\uca88", "\ud8fe\udeba\ud9e0\udde3\ud8de\udfc7\ud9d7\udca1\uda51\ude9e\uda00\ude39",
        8, 69820, -259267056, -8236986849301492482L, -58677L, true, true, (char) 24633, (char) 22591,
        Double.longBitsToDouble(0x3fe79c07b18bb058L), Double.longBitsToDouble(0x3fdcb0fab4878b38L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 15, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u93bf\ub595\u4949\ub87d\u73f9", "\uda73\udce2\ud95d\udc96\ud931\udf1d\udb22\ude4c\ud8ca\udd49\ud813\udd89\udbe1\udee4",
        47, 29975, -1556291056, -6082651381619619017L, 78430L, false, false, (char) 30603, (char) 29878,
        Double.longBitsToDouble(0x3fcfc6d0881f0c14L), Double.longBitsToDouble(0x3feb5bcaa74fd05aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 7, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udb33\ude0a\udb65\udcbe", "\u93bf\u54f9\u7d07", "\udb42\ude15\uda40\uddf9\ud8a0\udd8a\ud98c\ude22\ud9ce\udc8a\ud948\udd51\udb7e\udee9\udb57\udc9b",
        17, 96682, 756758519, -6684219189993532212L, -58780L, false, false, (char) 21954, (char) 30603,
        Double.longBitsToDouble(0x3f9af48b1e91b600L), Double.longBitsToDouble(0x3fa96a7c76b79540L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 15, 0, "\ud967\udfea\ud950\udf98\uf7b6\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u93bf\u3acb\u562d\u6de9\ua036\u85cb\u4758", "\udb23\udc67\ud9c8\udcf9\udba1\ude10\udb43\udfe0\udbe1\udee4\ud848\udf20\ud934\uddaa\ud9e5\ude11\ud9d1\udf48\uda51\ude9e\udadd\udfff\uda6d\ude5d\uda98\udfd0\ud8a1\udd63\ud869\udce3\ud97a\ude59\udb2e\udd87\ud8f5\udcb9\udbd9\udcc6\uda42\udc99\udb4f\udf40\ud8ef\ude41\ud8ea\udd61",
        5, 50147, 1203017028, -5518981819615388333L, 76846L, true, true, (char) 9244, (char) 61396,
        Double.longBitsToDouble(0x3fef2eba3adb0c4bL), Double.longBitsToDouble(0x3fe18d33925b8909L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 15, "\uff07\udb23\udfd4\ud9a6\udd04\udb61\udd29\udb29\udea8\udb33\uddba\ud9c8\udf2f", "\u93bf\ub595\u55bb\u6de9\ua036\uc244\ua395\u752e\u8c18\u55a5\ub685\u31ea", "\ud848\udf20\ud9e0\ude9f\uda09\udc98\ud9d1\udfd2\uda51\ude9e\ud9cb\udc14",
        58, 81316, -192158192, -8236986850786523906L, 59595L, true, false, (char) 52451, (char) 17491,
        Double.longBitsToDouble(0x3fe5ec054144cd58L), Double.longBitsToDouble(0x3fd9ab7b6cb3dc5aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 10, 4, 15, "\ud968\udc1a\udb85\udc22\u43ca\ud82c\udee2\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u9401\ub595\u55bb\u6de9\ua036\u6876\u4836\ud3cc\u687b\u5574\ub685\u31ea", "\ud848\udf20\ud9e0\ude9f\uda09\udc98\ud9d1\udfd2\uda51\ude9e\ud9cb\udc14",
        58, 81316, -192158192, -8236986850789815042L, 59595L, true, false, (char) 52451, (char) 17491,
        Double.longBitsToDouble(0x3fe79c05418bb058L), Double.longBitsToDouble(0x3fd89fd3b4878b38L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 15, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u93bf\ub595\u55bb\uaa05\ua036\u85cb\u4758\ud3cc\u687b\u5574\ub685\u31ea", "\ud848\udf20\ud9e0\ude9f\uda09\udc98\ud9d1\udfd2\uda51\ude9e\ud9cb\udc14",
        58, 81316, -192158192, -8236986850789815042L, 59595L, true, false, (char) 64789, (char) 17491,
        Double.longBitsToDouble(0x3fe79c05418bb058L), Double.longBitsToDouble(0x3fd89fd3b4e5531eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 4, 15, "\ud968\udc1a\udb85\udc22\u43ca\ud86d\udf02\uda41\ude8f\udb33\uddba\ud9c8\udf2f", "\u93bf\ub595\u55bb\u6de9\ua036\u85cb\u476d\ud3cc\u687b\u58c8", "\udba8\ude98\udbe1\udee4\ud848\udf20\ud8ea\udfa4\uda09\udc98\ud9d1\udfd2\uda96\udc72",
        41, 5638, -1848278453, -825313152216311782L, 98137L, true, true, (char) 22341, (char) 51171,
        Double.longBitsToDouble(0x3fe125b5305180a8L), Double.longBitsToDouble(0x3fec5d82c189fd3bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 4, 13, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30", "\uca53\u2edd\u496c", "\udbd0\udc5f\udb18\udd47",
        16, 70684, 768895239, 7323006211670607357L, 6159L, false, true, (char) 34414, (char) 4418,
        Double.longBitsToDouble(0x3fc8470adfdf9134L), Double.longBitsToDouble(0x3fe08168dccca33cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 0, 15, "\ud967\udfc5\udb85\udc22\u43ca\udb4a\ude30\ud9c4\udf45\udb33\udd7d\ud9c8\udf2f", "\000\000\000", "\000\ud9f4\udd0c",
        -5, -747, 1879048192, -5359953508108530412L, 93427L, false, false, (char) 7237, (char) 3883,
        Double.longBitsToDouble(0x3fc9946780000000L), Double.longBitsToDouble(0x3fe0000000fe5677L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 4, 15, "\ud968\udc1a\udb85\udc22\uda6f\udd97\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u947b\ub595\u55bb\u6de9\ua036\u85cb", "\ud98c\ude22\ud931\udf1d\udb22\ude4c\ud8ca\udd57\udb71\udf87\udbe1\udee4",
        47, 65519, -1556291056, -6082651381619619017L, 78430L, false, false, (char) 30603, (char) 19622,
        Double.longBitsToDouble(0x3fc351b6081f0c70L), Double.longBitsToDouble(0x3feb5bcaa6ebd05aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 1, 15, "\ud968\udc1a\ud95e\udcec\u4414\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u9430\uc946\u55bb\u6de9\u9f97\u85cb\u2a03\u025c\u67d6\u5574\ub685\u31ea", "\ud848\udf20\ud9e0\ude9f\uda09\udc98\ud9d1\udfd2\uda85\uddf8\ud9bd\ude93",
        58, 81316, -751442416, -8236986850789815042L, 59595L, true, false, (char) 52451, (char) 17491,
        Double.longBitsToDouble(0x3fe79c05458bb058L), Double.longBitsToDouble(0x3fd89fd3b4878b38L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 0, "\ud842\uddf9\udb5f\ude81\u43ca\udb5c\udf30\ud8f1\udfbc\udbce\udd2c\udb89\udf00", "\u0387\u16c8\ud40a\u5baf\u2b12\ubd8d\u4758\ud3cc\u3372\u1abc\ub685\u31ea", "\ud848\udf20\ud9e0\ude9f",
        39, 94364, -1308226761, 1693739370982472414L, -93360L, false, false, (char) 39598, (char) 48460,
        Double.longBitsToDouble(0x3feb5bcaa6ebd05aL), Double.longBitsToDouble(0x3fd37dbacd85eb20L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 4, 5, "\ud94f\udc68\udb77\udc22\u43ca\ud86e\udeca\udacf\ude4f\ud97d\udcc3\ud9c8\udf28\ud9be\udcd3\udbbd\ude09\ud82f\udfa8\udb01\udf76\udbd0\udc5f\ud8c2\uddbe\ud87f\udc20\udafb\udea3\ud982\udfba\ud8a0\udd57\ud98c\ude22\ud931\udf1d\udb22\ude4c\ud8ca\udd57\udb71\udf87\udbe1\udee4\ud848\udf20\ud9e0\ude9f\uda09\udc98\ud9d1\udfd2\uda51\ude9e\ud9cb\udc14\uda6d\ude5d\uda98\udfd0\ud8a1\udd63\ud99c\udd5d", "\u44bb\u180c\u8d03\u87d4\ucba6\uae43\u1455\u29ff\u972c\u3dc9\u14ce\u42a8\u8c90\u14f3\uad01", "\udaa0\udeb2\udb02\udfc5\udb77\ude78\uda0d\udc18\uda2c\udfd0\udbc5\ude9e",
        52, 56554, -1276667153, 5122183296067590002L, 25336L, false, true, (char) 11899, (char) 56530,
        Double.longBitsToDouble(0x3fd62a4536c61d68L), Double.longBitsToDouble(0x3fc8ed975258e798L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 12, 2, 15, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u7146\ub595\u55bb\u6de9\ube0e\u2c36\u2c34\ud471\u687b\u5574\ub685\u31ea", "\ud848\udf20\ud9e0\ude9f\uda09\udc98\ud9d1\udfd2\uda51\ude9e\ud9cb\udc14",
        58, 81316, -192158192, -8236986849378530562L, 51394L, false, true, (char) 55407, (char) 17491,
        Double.longBitsToDouble(0x3fb3a02a0c5cad80L), Double.longBitsToDouble(0x3fd89fd3b4878b38L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 15, "\udb49\udc8a", "\u9d75\u594e\ubf70\uca2f\u2edd\u816b\u93bf\ub595\u55bb\u6de9\ua036\u58f9\u47a1\u0766\u3daa\u9755\u8c29\u31ea\ua0ee", "\ud9e0\ude9f\ud98a\ude9f\ud945\udfcc\uda51\ude9e\udbf8\udc2c\udaef\udffc\uda98\udfd0\ud8a1\udd63\ud99c\udd5d\ud956\udd67\uda54\udf12",
        16, 65504, -175050441, -9175997646973154573L, -8053L, false, true, (char) 16932, (char) 62670,
        Double.longBitsToDouble(0x3fc0407e62e04110L), Double.longBitsToDouble(0x3fd427b37a24d43cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 4, 15, "\ud973\udd4b\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udb33\uddba\udaff\udeec", "\u93bf\ub595\u55bb\u6de9\ua036\u85cb\u4758\u3302\u687b\u5574\u9b8c\u35f4", "\ud848\udf20\ud97c\udced\uda1d\udce8",
        29, 25239, 1450663676, -3217055584595770697L, -62435L, true, true, (char) 22341, (char) 52451,
        Double.longBitsToDouble(0x3fe617ac82f380a8L), Double.longBitsToDouble(0x3fd8bb058313fa76L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 15, "\ud968\udc1a\ud823\udcca\u43ca\udb4a\ude30", "\uca53\u2edd\u816b\u93bf\u5df1\u7926\u86e3\ud769\u85c8\u4758\ud3cc\u687b", "\udbb5\udf3f\udb2e\udcde\udbe1\udee4\ud8fe\udeba\ud9e0\udde3\uda67\udeea\ud9d7\udca1\uda51\ude9e\uda00\ude39\ud84d\udd92\ud9c9\ude68\udb67\udd26\ud914\udc99\udb9d\udc2e\ud9ba\uddd1\udbbc\udf15\udac8\ude63\ud81f\ude42\udadb\udcf9\ud9e1\udfd9\ud996\ude57\ud83d\ude5a\udb8e\udcce\uda5a\udea3\ud9db\udea1\ud8ac\ude83\ud819\ude1e\ud982\udeec\udba5\ude76\udb55\udd42\udbb2\udf83\ud8ae\uddaa\ud9f8\udcdd\udab9\udd2c\ud80a\udcb8\ud963\uded9\udbe8\udf01\ud975\udcd8\ud858\udfd6\ud8a9\udf3f",
        27, 18945, 681944714, 8411897157255863141L, -8850L, false, false, (char) 12262, (char) 29385,
        Double.longBitsToDouble(0x3fef0673967c0337L), Double.longBitsToDouble(0x3fb2462d2bf713c0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null\012",
        Z.run(T, 2, 5, 12, 6, "\uda68\udeb8\udb66\udd84\uda82\ude83\udb4a\ude12\udb29\ude37\uda52\udcb9\udb0a\udeb0\ud9b6\udccf\udbbd\ude09", "\uc6ed\u6de9", "\ud982\udfba\ud8a0\udd57\ud98c\ude22\udabe\udf6d\udae3\udc90\ud92f\uddde\ud806\udf0f\uda27\udc57\ud8fe\ude42\ud9b5\udceb\ud853\udec9\ud937\udce8\u072c\ud9ed\udfef",
        8, 69820, -1762361661, -8277528876540392689L, 55559L, false, false, (char) 52202, (char) 41443,
        Double.longBitsToDouble(0x3fdcb0fab4878b38L), Double.longBitsToDouble(0x3fdb806eb6680392L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 15, "\udaa6\udeb6\udbb4\udfd4\udb7c\udfc5\udb05\udf0a\udb29\ude37\udb33\uddba\ud8f4\ude84\ud9be\udcd3\udbbd\ude09\udb3d\udc41\uda8e\udd17\udb1c\udf46", "\ud7db\uc121", "\udabe\udf6d\udb53\ude92\ud8b7\udffe\ud9f5\ude8e\ud8c3\udf9a\uda9e\udc2b\ud9e0\udde3\ud8de\udfc7\ud8a9\udf2a\udb4f\uddcd\ud849\uded9\udbee\udcb6\ud95d\ude43\u9bec\ud99c\udd5d\udb6a\uded0\uda55\udc1f\udb43\udcfa\uda60\udf83\uda28\uddb8\ud9a4\udc75\udad0\ude72\ud8f9\udeb9\uda1c\udf8c\ucde1\uda56\udeb2\u301f",
        25, 80396, 1929768932, -1904063051825828227L, 97188L, false, false, (char) 18995, (char) 4700,
        Double.longBitsToDouble(0x3fe2518b49398e2eL), Double.longBitsToDouble(0x3f95a23987627200L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 15, 10, "\udaf4\udc20\ud96d\udccf\ue2ca\udb4a\ude30\udb29\ude37\uda8f\udc58\ud86d\ude7b", "\u70ca\ub5ba", "\ud965\udc91\udafb\udea0\ud982\udfba\ud8a0\udd57",
        18, 6290, 904435939, 317249275940554182L, -23006L, false, true, (char) 60714, (char) 57576,
        Double.longBitsToDouble(0x3fe9bd5cb5b1b206L), Double.longBitsToDouble(0x3fecf2676254d380L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 13, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u93bf\ub595\u4949\ub87d\u73f9", "\uda73\udce2\ud95d\udc96\ud98b\udd29\udb22\ude4c\ud8ca\udd49\ud813\udd89\udbe1\udee4",
        55, 35526, -1556291056, -6082651381619619017L, 78430L, false, false, (char) 30495, (char) 29878,
        Double.longBitsToDouble(0x3fcfc6d0881f0c14L), Double.longBitsToDouble(0x3feb5bcaa74fd05aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 0, 15, "\ud968\udc1a\udb85\udc22\u43ca", "\ud63a\uca53\uba1a\u2026\u93bf\ub595\u4949\ub87d\u73f9\u85cb\u1834\u5330\u8d74\u5574\ub685\u31dc\u770f\u2659\uc3ed\u6b49\ua41e\ua8bf\ucecb\ud576\u8c2b\u7757", "\u4966\ud9ce\udd2d",
        10, 49935, -567284300, 9153386291970123637L, 32331L, true, true, (char) 11074, (char) 15135,
        Double.longBitsToDouble(0x3fe21cfb751c9e67L), Double.longBitsToDouble(0x3fd1031666a065d8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 15, "\uda5d\uddc9\udac1\udde3", "\u2de7\u6012\uca53\uba1a\u2026\u93bf\ub595\u9e07\ub87d\u9447\u85cb\ub67a", "\ud931\udf1d\udb22\ude4c\ud8ca\udd49\ud813\udd89\udbe1\udee4\ud848\udf20\ud8b1\udc43\uda09\udc98\ud9d1\udfd2",
        24, -324, -747718402, -7963628217797175929L, 43664L, true, false, (char) 59583, (char) 26537,
        Double.longBitsToDouble(0x3fdc1cd798da5960L), Double.longBitsToDouble(0x3feb36e58d813412L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 7, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udb33\ude0a\udb65\udcbe", "\u93bf\u54f9\ubd41\u010f\u6346\u84b8\u9039\ud43d\u687b\u09b1\u6dce\ud5fd\uae0a\u2659\uc3ed\ub56c\ua41e\ua8bf\u8ffb\u45ee\ua0a4\u7757\ub87c\u9fda\u90b5\u130d\u361a\ua83b\uc4be\u5366\u0aca\u00f6\u9d8a\ud03b\u45f8\u66a2\u4c45\u9be5\u6067\ua98d\u4f49\u8f88\ub307\ub5b2\u72a4\u0b9a\u20a1\ud1ec", "\u277a\uda28\udd5e\udbc0\udfc2\u3861\ud9dc\udcca\udb20\udf88\ud82c\udf52\udb67\udc73\uc74e\ud818\udfd9\u47d7\ud9d0\uddaf\ud825\udd5d\ud89e\udce3\udb25\udd19\ud8cc\udc31\uda9b\ude28\udaec\ude66\udac8\udcb2\udab6\udd16\ud8f2\udcc5\ud81c\udf64\udb78\ude3b\uda9e\udf5c\uda82\udcd5\ud9c3\udcc1\udba2\ude0f\udb24\udd11\uda0c\udf9b\uda06\udfe5\udba7\udd8c\udb29\udf0d\ud887\ude87\udb6a\udd68\ud95b\uddf6\udbc6\udf08\ud9ac\udde4\udafc\udcbe\udbf0\udd22\ud9ce\udc9b\uda48\udf51",
        35, 43581, 1973136057, -7386689752727722392L, -6344L, false, false, (char) 54049, (char) 31761,
        Double.longBitsToDouble(0x3fe37d7e84855b6cL), Double.longBitsToDouble(0x3feae6876a103c3cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 1, 7, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udb33\ude0a\udb65\udcbe", "\u93bf\u54f9\u7d07", "\udb42\ude15\uda40\uddf9\ud9bd\uddb1\ud98c\udd7f\ud9ce\udc8a\ud948\udd51\udb7e\udee9\udb57\udc9b",
        17, 96682, 756758519, -6684243379249343284L, -58780L, false, false, (char) 21954, (char) 30603,
        Double.longBitsToDouble(0x3f9ef48b1e91a900L), Double.longBitsToDouble(0x3fa96a7c76bfb450L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 7, "\ud968\udc1a\udb85\udc22\u43ca\u5a12\udb0b\uddd5\udb33\ude0a\udb65\udcbe", "\u93bf\u54f9\u7d07\u010f", "\uda40\uddf9\ud8a0\udd8a\udb2a\udc70\ud9b1\udd90\ud948\udd51\udb7e\udee9\udb57\udc9b\udbe1\udee4\ud9d3\udf74\ud93b\udeda\uda09\udc98\ud9c5\udfea\uda51\udf1c\ud9cb\udc14\uda6d\ude5d\uda98\udfd0\ud8a1\udd63\ud99c\udd5d\udb59\ude6a\ud9a1\udf58\udb1e\udc4c\udafb\udd0f\udb02\uddb7\ud9aa\udcd3\uda48\udd7b\udb32\udd76",
        0, 10095, -754097630, 7947289785621311013L, -1301L, false, false, (char) 55645, (char) 12333,
        Double.longBitsToDouble(0x3fe569a1e87c62f7L), Double.longBitsToDouble(0x3facea8d9602da20L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 1, "\udab9\udfe4\ud8b9\uddb7\uda9d\ude3c\ud89e\udee9\ud95c\udd48\udb33\ude0a", "\u9c41\ud1c1", "\udbc0\udf3b\ud893\udc08\ud979\udff0\uda40\ude66\ud890\udd8a\ud98c\ude22\ud866\udf35\uaec2\udb7e\udee9\udb1b\ude7e\ud8be\udfaf\ud94e\udf23\ud9e0\ude9f\uda09\udc98",
        29, 92759, -2141217414, -3211426085061557676L, 21939L, false, true, (char) 41492, (char) 62252,
        Double.longBitsToDouble(0x3fead16427962ab4L), Double.longBitsToDouble(0x3feb0a8e1c1a6aacL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 7, 16, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30\udb29\ude37\udaa4\udc11\udb65\udc63", "\u62ab\u4fb4\u670e", "\udb42\uddee\uda40\uddf9\ud899\udd8a\ud98c\ude22\ud9ce\udc8a\ud948\udd51",
        21, -676, 945222547, -1995889847363225609L, 25748L, true, true, (char) 4355, (char) 39385,
        Double.longBitsToDouble(0x3fd6b54a2332df84L), Double.longBitsToDouble(0x3f9a2ef71e91b600L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 1, "\ud968\udc1a\udb85\udc22\u43ca\udb4a\ude30", "\u586d\u8530\u8387\u043f\u54f9\u7d07\u010f\u6346\u9bee\u89d4\u6cc6", "\ud92d\ude7d\u8857\udb55\udd81\udbe1\udee4\ud848\udf20\ud9e0\ude9f",
        39, 94364, -2130310345, 6230552216238733566L, -93360L, false, false, (char) 9438, (char) 7219,
        Double.longBitsToDouble(0x3feb5bcaa64ac6bbL), Double.longBitsToDouble(0x3fdfc9695e7d9048L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 13, "\uda02\udf08\udb85\udc22\u43ca\ud86d\udf02\uda41\ude8f\udb33\uddba\ud9c8\udf2f", "\u93bf\ub595\u55bb\u6de9\ua036\u85cb\u476d\ud3cc\u8c80\u990f", "\uda07\udf07\udbe1\udecc\ud848\udf20\ud8ea\udfa4\udb93\udde7\ud96b\ude00\uda96\udc72",
        41, 5638, -1848278453, -825313152216311782L, 98137L, true, true, (char) 22341, (char) 51171,
        Double.longBitsToDouble(0x3fe125b5305180a8L), Double.longBitsToDouble(0x3fec5d82c189fd3bL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 0, 0, "", "", "\ud9c4\udf45",
        51, 90000, 44746, 0L, -100000L, false, false, (char) 47693, (char) 44,
        Double.longBitsToDouble(0x3fd00000000001a8L), Double.longBitsToDouble(0x3fcfa00000000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 2, "\ud968\udc1a\udb85\udc22\uda6f\udd97\udb4a\ude30\udb29\ude37\udb33\uddba\udb6b\udfa1", "\u4e97\u0ea8\u49f9\ube0b\u6663\ua39d\u2ab7\u803e\u401d", "\udab4\udce7",
        -3, 99970, -464704492, 7810965751165875781L, -92375L, false, false, (char) 3957, (char) 21954,
        Double.longBitsToDouble(0x3fe0848bdbc9518bL), Double.longBitsToDouble(0x3fc819fcdc1f0c70L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 16, 0, "", "\u8f7c\u2b73\u5763\ud63a\uca53\u039b\uac2d", "\uda78\ude33\000",
        -5, 70701, 768895239, 7323006211670607357L, 6159L, false, true, (char) 34397, (char) 4418,
        Double.longBitsToDouble(0x3fc8470adfdf9134L), Double.longBitsToDouble(0x3fe08168dccca33cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 14, "\ud968\udc1a\udb85\udc22\uda6f\udd97\udb4a\ude30\udb29\ude37\udb33\uddba\ud9c8\udf2f", "\u947b\ub595\u55bb\u6de9\ua036\u85cb", "\ud98c\ude22\ud931\udf1d\udb22\ude4c\ud8ca\udd57\udb71\udf87\udbe1\udee4",
        54, 65519, -1556291056, -6082651381502702793L, 78430L, false, false, (char) 30603, (char) 19622,
        Double.longBitsToDouble(0x3fc351b6081f0c70L), Double.longBitsToDouble(0x3feb5bcaa6ebd05aL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 12, "\ud85b\udcb3\uda17\udd0e\uda6f\udd97\udb4a\ude30\udb29\ude37\udb33\uddba\ud8ae\udf02\ud866\udea7\udb56\udcba\ud830\udc64\udb01\udf76\udbd0\udc5f\ud826\udfb0\ud8f0\udd05\uda3a\udff9\ud9d5\udc9f\ud8a0\udd57\ud98c\ude22\ud8eb\udcde\udb47\ude55\ud8ca\udde6\uda95\udd46\ud804\uddd6\udab3\udc07\uda11\uded2\uda09\udc98\ud8d4\ude52\ud911\udcbb\ud892\udc18\udb36\udc5f\ud8aa\udce7\uda1f\udd48\udbd2\udca1\ud8cd\udc7d\uda42\udf02\ud87f\udc9c\ud8c9\udf9e\udaa7\ude83", "\u713b\u3309\u12ad\u6564\u59b1\ua658\u0128\uaa9f", "\ud857\udf26\ud97a\udc5e",
        1, 165, -1005989649, -6310081788355766712L, -89194L, false, false, (char) 17672, (char) 15600,
        Double.longBitsToDouble(0x3feb8a69bae77f55L), Double.longBitsToDouble(0x3fd34916ba054c6eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 6, "\uda68\udeb8\udb66\udd84\uda82\ude83\uda3c\udd9f\udb29\ude37\uda52\udcb9\udb0a\udeb0\ud9b6\udccf\udbbd\ude09", "\u2cf4\u391d", "\uda08\udec1\ud864\udfa3\ud9c5\udcb7\udabe\udf6d\udae3\udc90\ud92f\uddde\ud806\udf0f\uda27\udc57\ud8fe\ude42\ud9b5\udceb\ud853\udec9\uda59\udd54\u072c\ud9ed\udfef",
        20, 69820, 1592164035, 6880537822131227407L, 6557L, false, false, (char) 52202, (char) 41443,
        Double.longBitsToDouble(0x3fdcb0fab4878b38L), Double.longBitsToDouble(0x3fdb806eb6680392L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 9, "\ud8df\udf36", "\ua4a6\ua976\ud3fb\ub88b\u165a\u7765\u70ca\u8f45\u8834\u51d3\u6739\u3fb5\ub8e6\uba00\u7bfb\u0505\u12a7\uc720\u388c\u9f05\u24d2\ua096\u1d86", "\uda00\ude39\udaa4\udcfe\udb43\udd50\uda94\uddb7\ud8ff\ude1e\udb58\udc73\udb7f\udf1a\ud823\udff8\ud87c\udde4\udb9c\udd40\ud8bc\udc87\ud94d\udf62\ud9b0\uddc3\udb02\udf86\ud97d\udd39\uda7b\udf7c\udacf\udc04\uda93\udc5e\u80f0\udb7b\udf05\ud97a\udf04\ud8b4\udcab\udb81\udc4a\udb34\udfec\uda77\ude80\ud885\ude2b\ud802\udc0b",
        34, 28392, 957822303, -986718428555298866L, 30716L, true, true, (char) 63774, (char) 10929,
        Double.longBitsToDouble(0x3fec97921ad53c3cL), Double.longBitsToDouble(0x3fe30b69b166483aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 10, "\ud992\udd05\u33e2\ud9d1\udffa\ud86d\udddf\udb29\ude37\udb33\uddba\ud9dc\udc79", "\u93bf\ud086\u4949\ub87d\u73f9", "\uda73\udce2\ud95d\udc96\ud97b\ude00\ud959\ude44",
        13, 62136, 945222499, 7948058130045024566L, 25748L, true, true, (char) 4526, (char) 3957,
        Double.longBitsToDouble(0x3fa00037610910f0L), Double.longBitsToDouble(0x3f7872c27f1b4200L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 1, 7, "\ud968\udc1a\udb85\udc22\u43ca", "\000", "",
        -5, -1000, 0, 16023253317575680L, 82925L, false, true, (char) 44060, (char) 44152,
        Double.longBitsToDouble(0x3fd1400005b83e4aL), Double.longBitsToDouble(0x3ec5e00000000000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 0, "\udab9\udfe4\ud8b9\uddb7\ud892\udd76\ud89e\udee9\ud92e\udd48\udb33\ude0a", "\u9c41\ud1c1", "\udbc0\udf3b\ud893\udc08\ud979\udff0\uda40\ude66\ud890\udd8a\ud98c\ude22\ud866\udf35\uaec2\ud8fe\ude5e\udb60\udfc5\ud8be\udfaf\ud94e\udf23\ud9e0\ude9f\uda09\udc98",
        29, 92759, -2141217414, -3211426085061557676L, -97869L, false, true, (char) 41492, (char) 36601,
        Double.longBitsToDouble(0x3fd5a2c84d361b10L), Double.longBitsToDouble(0x3feb0a8e1c1a6aacL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 17, 0, "", "\u7132\u2b73", "\udb46\udf98\ud850\udd90\000",
        -5, -1000, -1677721600, -4851783220075889246L, -73120L, false, false, (char) 30402, (char) 32858,
        Double.longBitsToDouble(0x3feae944376ae863L), Double.longBitsToDouble(0x3fd2ce189a49390aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 15, "\ud968\udc1a\udb85\udc22\ud8bc\udebe\u2fb0\uda43\udd64\ud889\ude44\ud9c8\udf17", "\u93bf\ub595\u55bb\u6de9\u1d36\u85cb\u4758\ud3cc\u687b\u5574\ub685\u2058", "\uda36\udd2f\ud9e0\ude9f\uda09\udc98\ud9d1\udfd2\uda51\ude9e",
        41, 84598, -1854176684, 5619900867237507263L, 98137L, true, true, (char) 22341, (char) 52451,
        Double.longBitsToDouble(0x3fe617ac82f380a8L), Double.longBitsToDouble(0x3fd8bb058313fa76L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getNamespaceURI||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getNamespaceURI|java.lang.String|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getNamespaceURI|org.w3c.dom.Node|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|asPath||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|attributeIterator|org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|childIterator|org.apache.commons.jxpath.ri.compiler.NodeTest,boolean,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|compareChildNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createAttribute|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int,java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equalStrings|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equals|java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|findEnclosingAttribute|org.w3c.dom.Node,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getBaseValue||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getDefaultNamespaceURI||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getImmediateNode||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getNamespaceURI||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getNamespaceURI|java.lang.String|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getNamespaceURI|org.w3c.dom.Node|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
