package org.apache.commons.jxpath.ri.model.dom;
import org.junit.Test;
import static org.junit.Assert.*;
public class DOMNodePointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 8, 9, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udcea", "\ub15f\ud623\u85e9\u391c\u76f7\u5806\u1454\u1cc6\u25b6\u0e03\ua25f\u9f42\u3815\ub3e6\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\uaf45\u5bad\u8f3e\u2f31\u6c1f\u7fec\uc024\u8254\u0a92\u20d8\u1824\ua828\ud3aa\u7f6c\u9d95\u98c0\u26f4\ua1c0\ub686\u97b4", "\ud8c0\ude07\ud9b2\udc76\udb5e\ude85\udbbf\uddaf\udb6b\udda9\ud9bc\udc49",
        38, 67033, 73202250, -253135920770577277L, 21526L, true, false, (char) 44477, (char) 23865,
        Double.longBitsToDouble(0x3feec470d40a81ecL), Double.longBitsToDouble(0x3fee3dac2d9242dbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 8, 9, "\udafd\udcae\ud9fe\udecd\ud9c3\udf73", "\u4640\u3456\ub15f\ud623", "\ud815\uddf5\uda39\udfd7\udba9\udfbd\udbab\udfda\ud887\ude49\udbc3\udfb9\ud872\udfcc\ud8eb\uddf7\ud963\uddf4",
        14, 44386, -825925625, -2229315190052079213L, -2550L, true, true, (char) 63302, (char) 8422,
        Double.longBitsToDouble(0x3fa3f128271f5ae0L), Double.longBitsToDouble(0x3fd2570cf6ae23c0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 8, 9, "\udb25\udcf9\udaf4\udeae\ud870\udd59\udbc7\udc18\ud85a\udcea", "\u0c25\u8c71\u377d\u2a71\ua094\ud055\u1454\u1cc6\u25b6\u0e03\ua25f\u9f42\u986e\u012a\u1169\u3dae\uba20\uae40\uc60e\u0b05\u8815\ub6e7\u61a1\u22bf\u2786\uab06\uc8be\u8254\u0a92\u20d8\u1824\ua828\ud3aa\u7f6c\u11d5\ubc4f\u043f\uba8a\uc9ca\u979b", "\u7cfe\ud9b2\udc76\udb5e\ude85\udbbf\uddaf\udb6b\udda9\ud9bc\udc49",
        38, 67033, 73202250, -253135920770577277L, 21526L, true, false, (char) 44260, (char) 11694,
        Double.longBitsToDouble(0x3feec470d4f65fecL), Double.longBitsToDouble(0x3fee3dac2d9242dbL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 9, "\udacb\udd62\udbff\udfd8\ud9c3\udf73\udbc6\udff0\ud85a\udcea\uda72\udf5e\udaae\ude8e\u9c17\uda15\udcb4\ud953\udf41\ud9af\udcf8\uda32\udea3\uda39\udfb0\udba9\udfbd\udac9\udd28", "\ua25f\u9f42\u3815", "\ud90b\udd20\ud8d3\udfd2\ud977\udcd0",
        22, 35477, 1341888634, -4898372411745338931L, -40786L, true, false, (char) 14368, (char) 34292,
        Double.longBitsToDouble(0x3feab88f02995059L), Double.longBitsToDouble(0x3fe981a42bbce26eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 1, 21, 8, 9, "\udb25\udcf9\ud9fe\udecd\udb0f\udf95\udaf0\udfe7\udaa2\udfc4", "\ub15f\ud623\u85e9\u391c\u76f7", "\udb92\udc95\udb56\udfd1",
        51, 17722, 1449322720, -3446633850853027924L, -9881L, true, true, (char) 43742, (char) 15515,
        Double.longBitsToDouble(0x3fe2a88ccb3edcd2L), Double.longBitsToDouble(0x3fef6a6e71cdbc70L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 1, 6, 8, 9, "\udb25\udcf9\ud9fe\udee1\ud9c3\udf73\udbc6\udff0\ud85a\udcea", "\ub15f\ud623\u85e9\u886c\u76f7\u5806\u1454\u1cf3\u25b6\u0e03\ua25f\u9f42\u8062\ub3e6\u10eb\u8e46\u410c\ub752\u618b\ubcb3\uaf45\u5bad\u8f3e\u2f31\u6c1f\u7fec\uc024\u8254\u0a92\u20d8\u1824\ua828\ud3aa\u0809\u9d95\u98c0\u26f4\ua1c0\ub686\u97b4", "\ud8c0\ude07\udb20\ude0d\udb30\udf69\udbbf\uddaf\udb6b\udda9\ud9bc\udc49",
        38, 67033, 73202250, -253135920770577277L, 21526L, false, true, (char) 57945, (char) 23865,
        Double.longBitsToDouble(0x3feec470d00a81ecL), Double.longBitsToDouble(0x3fee3dacb05e25dbL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 15, 6, 1, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udcea\uda72\udf5e\udbd5\udddb\ud9f7\udcb8", "\u391c\u76f7\u5806\u1454\u1cc6\u25b6\u0e03\ua25f\u161e\u0e8f\uc5e2\ud2f3\u1eb2\u8747\u464d\uc60e\ubcb3\uaf45\u5bad\u8f3e", "\ud93a\udf8b\udb9e\udd16\udaa1\ude32\udbca\ude90\ud935\uddd9",
        40, 28284, 1724484056, 6438974853953128953L, -11931L, false, true, (char) 12491, (char) 27415,
        Double.longBitsToDouble(0x3fed59c4032f69afL), Double.longBitsToDouble(0x3fd91fe86b57002cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 9, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udd42", "\ub15f\ud623\u85e9\u391c\u76f7\ub8ce\uc690\u1cc6\u25b6\u0e03\ua25f\u9f42\u9ee6\ube16\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\uaf45\u5bad\u8f3e\u2f31\u9045\u7a20\u7b12\ud681\u3fb7\u20d8\u1824\ua828\ud3aa\u7f6c\u9d95\u98c0\u26f4\ua1c0\ub686\u97b4", "\ud8ae\udfe9\ud9b2\udc76\udb5e\ude85\udbbf\uddaf\ud89f\udd62\ud989\udda4",
        38, 67033, 73202250, -253135920770577277L, 21526L, true, false, (char) 44477, (char) 23865,
        Double.longBitsToDouble(0x3feec470d40a81ecL), Double.longBitsToDouble(0x3fee3dac2d9242dbL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 9, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udcea", "\ub15f", "\ud9af\udcf8\ud815\uddf5\uda39\udfb0\udaf7\ude44\udbab\udfbe\ud887\ude49\u5542\ud872\udfcc\ud8eb\uddf7\ud963\uddf4\ud9e8\udcad\udbe9\udfc5\ud90b\udd20\ud8d3\udfd2\ud977\udcd0\ud8e9\uddf7\udbb1\udef1\uda95\udd30\ud921\udc3f\000",
        -5, 15614, -173095897, 8128788905825670437L, -31751L, false, true, (char) 19498, (char) 62162,
        Double.longBitsToDouble(0x3fd8466c93f2b2b6L), Double.longBitsToDouble(0x3fed05fc67fba5d4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 14, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udcea", "\ub15f\ud623\u85e9\u391c\u76f7\u5806\u1454\u1cc6\u25b6\u0e03\ua25f\u9f42\u3815\ub3e6\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\uaf45\u5bad\u8f3e\u2f31\u6c1f\u7fec\uc024\u8254\u0a92\u20d8\u1824\ua828\ud3aa\u7f6c\u9d95\u98c0\u26f4\ua1c0\ub686\u97b4", "\ud8c0\ude07\ud9b2\udc76\udb5e\ude85\udbbf\uddaf\udb6b\udda9\ud9bc\udc49",
        38, 67033, 73202250, -253135920770577277L, 21526L, true, false, (char) 44477, (char) 23865,
        Double.longBitsToDouble(0x3feec470d40a8100L), Double.longBitsToDouble(0x3fee3dac2d9242dbL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 6, 11, "\udb25\udcf9", "\uadb3\u75ce\u4640\u5162\u2910\ud623\u85e9\u391c\u76f7\u5806\u1454\u1cc6\u25b6\u0e03\ua25f\u9f42\u3815\ub3e6\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\uaf45", "\udba7\ude52",
        9, 17103, 1892631153, 1288052743433974615L, 38032L, false, true, (char) 62162, (char) 15437,
        Double.longBitsToDouble(0x3fdf9595b7417f18L), Double.longBitsToDouble(0x3fefdd2ea128a762L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 11, 0, "\udb25\udcf9\ud842\udc50\ud991\ude4a\udbc6\udff0\ud85a\udcea", "\ub0ed\ud623\u85e9", "\uda39\udfb0\udba9\udfbd\udbab\udfda\ud887\ude49\udbc3\udfb9\u0db2\uda54\udcd1\ud963\uddf4\ud9e8\udcad\udbe9\udfc5\ud90b\udd20\ud8d3\udfd2\ud977\udcd0\ud8e9\uddf7\udbb1\udef1\uda28\udf3a\ud9b6\udedb\ud9ca\ude83\udba7\ude52\ud87b\udd8e\ud93a\udf8b\udb9e\udd16\udaa1\ude32\ud898\udc13",
        13, 10440, 1761299388, 3391327550178060241L, 95375L, true, true, (char) 58817, (char) 23371,
        Double.longBitsToDouble(0x3fc937024b343d38L), Double.longBitsToDouble(0x3fef0d4698244accL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 21, 13, 19, "\ud91b\udfd6\uda00\udf88\ud9c3\udf73\udbc6\udff0\udad5\udde8\udada\ude46\ud915\udd2a\u9c17", "\u391c\u76f7\u5806\u1454\u1cc6\u25b6\u7eda\u2a7e\u1a35\u3797\ub3e6\u10eb\u3dae\u04fa\uae40\u4e0f\u1585\u11f9\u4331\u0b43", "\udb61\udd9b\ud8c9\udcdb\u3629\ud898\udc13\ud935\uddb1",
        40, 60388, 1724484056, 6438974854087346681L, -11931L, false, true, (char) 12821, (char) 27398,
        Double.longBitsToDouble(0x3fed59c4032f69afL), Double.longBitsToDouble(0x3fd91fe86b57002cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 10, 14, "\udb25\udcf9", "\uadb3\u75ce\u4640\u3456\u00f4\000\000\000\000\000\000\000\ucb8d\u0e03\000\000\u374f\ub3e6\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\uaf45", "\udba7\ude52",
        9, 17103, 1892631153, 63073644789199703L, 38032L, false, true, (char) 62162, (char) 15437,
        Double.longBitsToDouble(0x3fdf9595b1417f18L), Double.longBitsToDouble(0x3fefdd280128a762L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null\012",
        Z.run(T, 2, 1, 4, 9, "\udad1\udc5d\ud981\udd73\ud8ca\ude52\udac9\udf0c\uda17\ude1f", "\ub15f\ud623\u85e9\u391c\u76f7\u5806\u1454\u1cc6\u25b6\u0e03\ua25f\u9f42\u3815\ub3e6\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\u3145\u1491\u8ecd\u9eff\u6c1f\u7fec\uc024\u8254\u0a92\u20d8\u6d7b\uadd3\ua839\u8bd2\ub2b5\u07d7\u2615\ua1c0\ucc74\u7889", "\udba3\uddf8\ud9b2\udc8f\udb5e\ude85\udbbf\uddaf\udb6b\udda9\ud9bc\udc49",
        38, 67033, -14353846, -253135920619733623L, 21526L, true, false, (char) 44477, (char) 23865,
        Double.longBitsToDouble(0x3feec4723c0a81ecL), Double.longBitsToDouble(0x3fee3dac2d9242dbL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 14, 1, 17, "\ud82a\udf34\udbfd\udcd1\ud9c3\udf73\udbc6\udff0", "\u3456\ub15f\ud623\u85e9\u391c\u76f7\u5806\u1454\u1cc6\uc1cc\u62f3\ua25f\u9f42\u3815\ub3e6\u10eb\u3dae\u04fa", "\udbb1\udef1\uda95\udd30\ud99c\udc3d\ud9ca\ude83\udba7\ude52\ud87b\udd8e\ud93a\udf8b\udb9e\udd16\udaa1\ude32\ud898\udc13\ud935\uddb1\udb8a\udd71\udb34\uddeb\udac1\udfe6",
        40, 97321, -1512832096, -6385356625959419608L, 95375L, true, true, (char) 58817, (char) 38447,
        Double.longBitsToDouble(0x3fc937024b343d38L), Double.longBitsToDouble(0x3fef0d4698244accL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 9, "\udafd\udcae\ud9fe\udecd\ud943\ude12", "\u4a43\u3456\ub15f\ud623\u85e9\u391c", "\udba9\udfbd\udbab\udfda\ud887\ude49",
        57, 39322, 292018055, -3446633850229911636L, -9881L, true, false, (char) 31369, (char) 36720,
        Double.longBitsToDouble(0x3fdfaba6ebfe17c0L), Double.longBitsToDouble(0x3fc549e64736f014L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=null\012",
        Z.run(T, 2, 21, 4, 9, "\udb25\udcf9\udaf4\udeae\ud870\udd59\udbc7\udc18\ud85a\udcea", "\u0c25\u8c71\u377d\u2a71\ua094\ud055\u1454\u1cc6\u25b6\u0e03\ua25f\u9f42\u986e\u012a\u1169\u3dae\uba20\uae40\uc60e\u472a\u2608\ub737\u61a1\u1a05\u2786\uab06\uc8be\u8254\u0a92\u20d8\u1824\ua828\ud3aa\u7f6c\u11d5\ubc4f\u043f\uba8a\uc9ca\u2c27", "\u7cfe\ud9b2\udc76\udb5e\ude85\udbbf\uddaf\udb6b\udda9\ud9c1\udf1a",
        38, 67033, 73202250, -253135920770577277L, 21526L, true, false, (char) 44260, (char) 11694,
        Double.longBitsToDouble(0x3feec470d4f65fecL), Double.longBitsToDouble(0x3fee3dac2d9242dbL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 14, 13, 11, "\udacb\udd62\ud8ce\udf12\u0248\udb01\udf9d\ud97f\udd45\udb5c\udd71\ud8ff\udf77\udb2a\udc05\udb88\udf1e\ud8ca\udd20\uda5d\udefe\udb0e\udeb8\uda39\udfb0\udba9\udfbd\ud8db\udf99", "\u71be\ube2a\u384c\ub3e6\u10eb\u3dae\u04fa\uae40\uc60e\ub6e9\u8883\u6ea5\uc413\u2f31\u6c1f\u7fec\u48bb\ubf35\u0a92\u20d8\u0282\u257a\u2f3c\u5b66", "\ucd9b\ud955\udfed\ud986\udf7a\ud9c0\uddd4\udb5b\udc2d\ud897\ude86\ud98f\udfd0\ud9ae\ude2f\uda2c\udecc\udba6\udf50",
        22, 20404, 955549553, -433388827549849756L, 4656L, true, false, (char) 53781, (char) 63344,
        Double.longBitsToDouble(0x3fec4dbf24f89398L), Double.longBitsToDouble(0x3fdb529a2b34c84eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 19, "\ud965\udfbf\ue050\ud802\ude5d", "\u4640\u35cd\u0887\u5ca0\u7e17\u391c", "\udba9\udfbd\ud8e2\udd6f",
        42, 91627, -1332070367, 6224793682947283142L, 61837L, true, false, (char) 14187, (char) 7644,
        Double.longBitsToDouble(0x3fe539859b8dd576L), Double.longBitsToDouble(0x3fe076c66c3fe17eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 9, 13, "\udacb\udd62\udbff\udfd8\udabf\udc61\udbc0\udcd5\ud85a\udcea\uda72\udf5e\udaae\ude8e\u9c17\uda15\udcb4\ud953\udf41\ud9af\udcf8\uda32\udea3\uda39\udfb0\udba9\udfbd\udac9\udd28", "\ua25f\u9f42\u399d", "\ud90b\udd20\ud8d3\udfd2\ud977\udcd0",
        22, 40005, 1341888573, -4898372411745338931L, -40786L, true, false, (char) 14368, (char) 34292,
        Double.longBitsToDouble(0x3fe6708f02995059L), Double.longBitsToDouble(0x3feff1a42bbce26eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null\012",
        Z.run(T, 2, 1, 0, 21, "\udb25\udcf9\ud9fe\udecd\udb0f\udf95\udaf1\udc58\udaa2\udfc4", "\ub114\u666b\ud13d\ua78c\uc46c", "\udb92\udc95\ud801\udc32\udbc3\udff4\ud92b\uddc8\u564e\udb90\udfca\ud8da\ude8d\udbe9\udfed\ud90b\udd20",
        33, 52143, 295242140, -7126250048780838082L, -109L, true, true, (char) 61201, (char) 31902,
        Double.longBitsToDouble(0x3fdeb4613ea3b338L), Double.longBitsToDouble(0x3fc7a69b514d5b3cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 5, 6, 9, "\ud930\udebe\ud867\ude2e\udb1a\udda9\udbc6\udf82", "\ub664\u3f5f\ubc88\ubc2a\u886c\u76f7\u6052\u4aeb\ube6e\uac05\u0e03\ua25f\u9f42\u8062\ub3e6\u489f\u2d9e\ud615", "\udbb1\udef1",
        11, 80773, -1228839138, -8112866530249653796L, -51473L, true, true, (char) 34103, (char) 23282,
        Double.longBitsToDouble(0x3fda83485e8638eaL), Double.longBitsToDouble(0x3fe0be87f4a24f9bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 14, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udd42", "\ub15f\ud623\u85e9\u391c\u76f7\ub8ce\uc690\u1cc6\u25b6\u0e03\ua25f\u9f42\u9ee6\u2eae\u11cb\u3dae\u04fa\u8e40\u80e9\ubcf2\uaf45\u5bad\u8f3e\u2f31\u9045\u7a20\u7b12\ud681\u3fb7\u20d8\u28d8\uc3f0\u882a\u3f3c\u9d32\u15ca\uc1cc\ua1c0\ub686\u97b4", "\ud8ae\udfe9\ud9b2\udc76\ud9d3\udcc8\udbbf\uddaf\ud89f\udd62\ud989\udda4",
        38, 67033, 73202250, -253135917255619453L, 21526L, true, false, (char) 44314, (char) 23865,
        Double.longBitsToDouble(0x3feec470d40a81ecL), Double.longBitsToDouble(0x3fee3dac2d92e1f4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 9, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udd42", "\ub15f\ud623\u85e9\u391c\u76f7\ub8ce\uc690\u1cc6\u25b6\u8013\u93d2\u2217\u9ee6\ube16\u10eb\u87ae\u04fa\uae40\uc60e\ubcb3\uae5a\uba7d\u8f34\u2e92\u0092\u7a20\u7b12\ud681\u3fb7\u20d8\u1824\ua828\ud3aa\u7f6c\u9d95\u98c0\u26f4\ua1c0\ub686\u97b4", "\ud8ae\udfe9\ud9b2\udc76\udb5e\ude85\udbbf\uddaf\ud89f\udd62\ud989\udda4",
        38, 67033, 805370442, -253135920770577277L, 21526L, true, false, (char) 44477, (char) 23865,
        Double.longBitsToDouble(0x3feec470d40a81ecL), Double.longBitsToDouble(0x3fee3dac2d9242dbL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null\012",
        Z.run(T, 2, 9, 0, 0, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73", "\u4640\u3456\ub15f\ud623", "\ud815\uddf5\ud8c5\udc97\udba0\uddfa\udbab\udfda\ud887\ude49\udbc3\udfb9\ud872\udfcc\ud8eb\uddf7\ud91f\udf71",
        22, 44386, -825925625, -2229315190883628593L, -2657L, true, true, (char) 63302, (char) 8422,
        Double.longBitsToDouble(0x3fc2c1ca1578eab0L), Double.longBitsToDouble(0x3fd2570cffb4a44cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 6, 6, 9, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udd42", "\ub15f\ud623\u85e9\u391c\u76f7\ub8ce\uc690\u1cc6\u25b6\u0e03\ua25f\u9f42\u9ee6\ube16\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\uaf45\u5bad\u8f3e\u2f31\u6bbd\u5822\u7b12\ud681\u3fb7\u20d8\u2ffb\ua828\ud3aa\u7f6c\u9d95\u0199\u26f4\ua1c0\ub686\u97b4", "\ud8ae\udfe9\ud9b2\udc76\udb5e\ude85\udacd\udc16\ud975\udd1c\udbe4\udf93",
        38, 67033, 73202250, -253135920770577277L, 21526L, true, false, (char) 44477, (char) 23865,
        Double.longBitsToDouble(0x3feec470d490be45L), Double.longBitsToDouble(0x3fee3dac2d92b1dbL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 9, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udd42", "\ub15f\ud623\u85e9\u391c\u76f7\ub8ce\uc690\u1cc6\u25b6\u0e03\ua25f\u9f42\u9ee6\ube16\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\uaf45\u5bad\u8f3e\ub6e7\u9099\u7a20\u7b12\ud681\u4305\u780c\u1824\ua828\ud3aa\u7f6c\u9d95\u98c0\u26f4\ua1c0\ub686\u97b4", "\ud8ae\udfe9\ud9b2\udc76\udb5e\ude85\udbbf\uddaf\ud89f\udd62\ud989\udda4",
        38, 67033, 73202250, -253135920770577277L, -24918L, true, false, (char) 46512, (char) 23865,
        Double.longBitsToDouble(0x3feec470d40a81ecL), Double.longBitsToDouble(0x3fee3dac2d9242dbL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 21, 21, 18, "\uda50\udfee\ud946\udefd\udab2\udc9c\udb0e\udcf6\ud85a\udcea\uda72\udf5e\udab4\udd2a", "\u865b\u391c\u76f7\u5806\u7e5d\u1cc6\u25b6", "\ud8e5\udcc8\ud963\uddf4\ud9e8\udcad\udbe9\udfc5\ud90b\udd20\ud8d3\udfd2\ud977\udcd0\ud9d7\udce9",
        29, 23842, -1140517710, -8910237940963084309L, -19143L, true, false, (char) 11662, (char) 34103,
        Double.longBitsToDouble(0x3fe4ca82cdf99631L), Double.longBitsToDouble(0x3fec200d9a1179a5L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 17, 6, 11, "\udb25\udcf9", "\uadb3\u15ce\u45c4\u5162\u2910\ud623\u85e9\u391c\u76f7\u5806\u1454\u1cc6\u25b6\u0e03\ua25f\u9f42\u3815\ub3e6\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\u8bb5", "\udba7\ude52\ud87b\udd8e\ud93a\udf8b",
        18, 28149, -2104069289, -5186413425505445081L, 824L, false, true, (char) 58195, (char) 49964,
        Double.longBitsToDouble(0x3fefdd2ea128a762L), Double.longBitsToDouble(0x3fd7c73107088ed6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 13, "\udb25\udcf9\ud842\udc50\ud991\ude4a\udbc6\udff0\ud85a\udcea", "\ub0ed\ud623\u85e9", "\uda39\udfb0\udba9\udfbd\udbab\udfda\ud887\ude49\udbc3\udfb9\u0db2\uda54\udcd1\ud963\uddf4\ud9e8\udcad\udbe9\udfc5\ud90b\udd20\ud8d3\udfd2\ud977\udcd0\ud8e9\uddf7\udbb1\udef1\uda28\udf3a\ud9b6\udedb\ud9ca\ude83\udba7\ude52\ud87b\udd8e\ud93a\udf66\udb9e\udd16\udaa1\ude32\ud898\udc13",
        13, 10440, 1761299388, 3391327550178060241L, 95375L, true, true, (char) 58817, (char) 23371,
        Double.longBitsToDouble(0x3fc937024b343d38L), Double.longBitsToDouble(0x3fef0d4698244accL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 0, "\udb25\udcf9\ud842\udc50\ud991\ude4a\udbc6\udff0\ud85a\udcea", "\ub0ed\ud623\u85e9", "\uda39\udfb0\udba9\udfbd\udbab\udfda\ud887\ude49\udbc3\udfb9\u0db2\uda54\udcd1\ud963\uddf4\ud9e8\udcad\udbe9\udfc5\ud90b\udd20\ud8d3\udfd2\ud977\udcd0\ud8e9\uddf7\udbb1\udef1\uda28\udf3a\ud9b6\udedb\ud9ca\ude83\udba7\ude52\ud87b\udd8e\ud93a\udf8b\udb9e\udd16\udaa1\ude32\ud898\udc13",
        13, 10440, 1761299388, 3391327550178060241L, 95375L, true, true, (char) 58817, (char) 23371,
        Double.longBitsToDouble(0x3fc937024b343d38L), Double.longBitsToDouble(0x3fef0d4698244accL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 0, "\udb25\udcf9\ud842\udc50\ud991\ude4a\udbc6\udff0\ud85a\udcea", "\ub0ed\ud623\ubf45", "\uda39\udfb0\udba9\udfbd\udbab\udfda\ud887\ude49\udbe6\udfb9\u0db2\uda54\udcd1\ud963\uddf4\ud9e8\udcad\udbe9\udfc5\ud8d6\udd25\ud8d3\udfa2\ud977\udcd0\ud8e9\uddf7\udbb1\udef1\uda28\udf3a\ud9b6\udedb\ud9ca\ude83\udba7\ude52\ud87b\udd8e\ud93a\udf8b\udb9e\udd16\udaa1\ude32\ud898\udc13",
        13, 10440, 1761299388, 3391327550178060241L, 95375L, true, true, (char) 58817, (char) 23371,
        Double.longBitsToDouble(0x3fc937024b343d38L), Double.longBitsToDouble(0x3fef0d4698244accL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 8, 9, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udcea", "\ub15f\ud623\u85e9\u391c\u76f7\u5806\u1454\u1cc6\u25b6\u0e03\ua25f\u9f42\u3815\ub3e6\u10eb\u3dae\u04fa\uae40\uc60e\ubcb3\uaf45\u5bad\u8f3e\u2f31\u6c1f\u7fec\uc024\u8254\u0a92\u20d8\u1824\ua828\ud3aa\u7f6c\u9d95\u98c0\u26f4\ua1c0\ub686\u97b4", "\ud8c0\ude07\ud9b2\udc76\udb5e\ude85\udbbf\uddaf\udb6b\udda9\ud9bc\udc49",
        38, 67033, -475006390, -253136049619596157L, 21526L, true, false, (char) 44477, (char) 23865,
        Double.longBitsToDouble(0x3feec470d40a81ecL), Double.longBitsToDouble(0x3fee3dac2d9242dbL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 9, "\udb25\udcf9\ud9fe\udecd\ud9c3\udf73\udbc6\udff0\ud85a\udd42", "\ub15f\ud623\u85e9\u391c\u76f7\u424a\u782f\u1da9\u25b6\u0e03\u92f7\u2653\u9ee6\ube16\u10eb\u1654\u5c75\uae40\u752b\u884f\uaf70\u4d36\ubfcc\u5e28\u2599\u19e6\ub19e", "\ud94b\udce5\udb8a\udd71\udb34\uddeb\udac1\udfe6\ud840\udec8\uda89\ude2c\uda5f\ude4f\ud838\udec2",
        23, 85691, 947961021, 7615344712228469551L, -91574L, true, false, (char) 51983, (char) 51950,
        Double.longBitsToDouble(0x3feb4bcd1a4aa861L), Double.longBitsToDouble(0x3fe1c822e483fc7cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|findEnclosingAttribute|org.w3c.dom.Node,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getLanguage||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getValue||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|stringValue|org.w3c.dom.Node|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|findEnclosingAttribute|java.lang.Object,java.lang.String,org.jdom.Namespace|static",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|getLanguage||new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|getValue||new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|asPath||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|attributeIterator|org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|childIterator|org.apache.commons.jxpath.ri.compiler.NodeTest,boolean,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|compareChildNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createAttribute|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int,java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equalStrings|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equals|java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|findEnclosingAttribute|org.w3c.dom.Node,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getLanguage||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getValue||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|stringValue|org.w3c.dom.Node|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|findEnclosingAttribute|java.lang.Object,java.lang.String,org.jdom.Namespace|static",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|getLanguage||new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|getValue||new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
