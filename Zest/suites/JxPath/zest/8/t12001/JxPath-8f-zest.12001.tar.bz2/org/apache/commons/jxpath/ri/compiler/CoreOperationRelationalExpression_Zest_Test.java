package org.apache.commons.jxpath.ri.compiler;
import org.junit.Test;
import static org.junit.Assert.*;
public class CoreOperationRelationalExpression_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 7, 0, "\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u88fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub61a\u6f1c\u9c98\u1603\u7905\ubda7\u0b66\u5f45\u368a\u263c\u65b7\u1c74\u3be1\u1af7\ud4d2\ucd69\u0999\u2ece\ud358\u8581\u4268\u737f\u5b79\u4d38\u79c3\u8ae9\u3579", "\ud8cf\udfbf\ud82e\udcaa\u9b0e",
        -5, 30835, 1891071883, -8597874123974701245L, -12594L, false, false, (char) 48117, (char) 468,
        Double.longBitsToDouble(0x3fe6c3d44029425cL), Double.longBitsToDouble(0x3fe6ffbacaf9b028L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 7, 0, "\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\udaec\udd88", "\u53c8\ub48d\u88fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub61a\u6f1c\u9c98\u1603\u7905\ubda7\u0b66\u5f45\u368a\u263c\uc00d\u8bfe\u9fb8\u1a79\ud4d2\ucd69\u0999\u2ece\ud358\u8581\u4268\u737f\u5b79\u4d38\u79c3\u8ae9\u3579", "\ud8cf\udfbf\ud82e\udcaa\u9b0e",
        -5, 30835, 1891071883, -8597874123974701245L, -12594L, false, false, (char) 48117, (char) 468,
        Double.longBitsToDouble(0x3fe6c3d44029425cL), Double.longBitsToDouble(0x3fe03f42caf9b028L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 7, 0, "\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u26fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub61a\u6f1c\u9c98\u1603\u7905\ubda7\u0b66\u5f45\u368a\u263c\u65b7\u1c74\u90eb\u1af7\u0090\ucd69\u0999\u2ece\ud358\u8581\u4268\u737f\u5b79\u4d38\u79c3\u8ae9\u3579", "\ud8cf\udfbf",
        45, 141, -1097309395, -6224340326585763957L, -38371L, true, true, (char) 23695, (char) 30658,
        Double.longBitsToDouble(0x3fc9f164d3483408L), Double.longBitsToDouble(0x3fe6c3d44029425cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 0, "\000\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1G", "\u53c8", "\ud96f\udfb9\uda0d\udf22\udaa5\udc82\ud98b\udc51\u00bd\000\ud938\udc4e",
        -5, -745, 0, 0L, -100000L, false, false, (char) 11860, (char) 38075,
        Double.longBitsToDouble(0x3e49697c00000000L), Double.longBitsToDouble(0x3fe0416d28000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 6, 0, "\ud9d7\ude04\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f\uda8d\uded7\ud8f9\udfae\udaf1\udccb\ud822\udf09\udb03\udf0c\ud96f\udfb9\uda43\udc1a", "\u155b\u3a38\u505f\ub7e2\u57ce\ua825\u1603\u7905", "\udbdd\udd06\udaa5\udf5a\udba4\udd57\udb02\ude74\uda98\udd0a\u8351\udb4b\udc2d\ud80d\uddf2\udba5\udcce\ud811\ude6d\udbaa\udd5b\uda4b\udfb0\udb27\udc41\ud8a7\ude10\ud915\uddb1\ud990\udcb0\udbb7\udcf0\ud91d\udf17\ud975\udc3c\uda1d\udcf7",
        24, 64303, -1417603910, 5521848714936863781L, -14867L, false, false, (char) 39053, (char) 38897,
        Double.longBitsToDouble(0x3febbd47bc2eb1fdL), Double.longBitsToDouble(0x3fe6274808cf8b26L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 3, 0, "\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u88fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub61a\u6f1c\u9c98\u1603\u7905\ubda7\u0b66\u5f45\u368a\u263c\u65b7\u1c74\u3be1\u1af7\ud4d2\uc2aa\ub498\u2ece\ud358\u8581\u4268\u737f\u5b79\u4d38\u79c3\u8ae9\u3579", "\ud8cf\udfbf\ud82e\udcaa\u9b0e",
        -5, 30835, 1891071883, -8597874123974701245L, -12594L, false, false, (char) 24197, (char) 468,
        Double.longBitsToDouble(0x3fe6c3d44029425cL), Double.longBitsToDouble(0x3fe6ffbaca81ef28L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\uda25\udfd4\ud881\udc59\udabe\udca1\ud9f8\udd0f |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 0, "\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\uda25\udfd4\ud881\udc59\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u88fd\uc940\ub26a\u918f\u9fe7\u155b\u3a38\u7033\ub61a\u6f1c\u9c98\u1603\u7905\u309f\ubb56\u2791\u35ed\u5b3c\u65b7\u1c74\u3be1\u1af7\ud4d2\ucd69\u4b14\u2eb2\ub167\ub5e6\u8072\ub2ad\u57fa\u1a78\u79c3\u8ae9\u3579", "\ud8d1\udd47\ud82e\udcaa\u9b0e",
        -5, 30835, 1891071883, -8597874123974701245L, -12594L, true, false, (char) 48117, (char) 468,
        Double.longBitsToDouble(0x3fe6c3d446fc425cL), Double.longBitsToDouble(0x3fe6ffbacb636661L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 0, "\udb18\uddbf\ud831\udd9d\udb29\udc2d\ud94a\ude56\ud98d\udf8c\udbef\uddbf\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u88fd\uc940\ub26a\u7166\u00d5\uc6ae\u3a38\u7033\ub61a\u6f1c\u9c98\u1603\u7905\ubda7\u0b66\u5f45\u2e6b\u263c\u65b7\uaaac\ua507\u1af7\ud4d2\ucd69\u0999\u2ece\ud358\u8581\u4268\u973a\u037f\u4d38\ube57\u8ae9\u3579", "\ud8cf\udfbf\ud82e\udcaa\u9b0e",
        -5, 30835, 1891071883, -8597874123974701245L, -12594L, false, true, (char) 24929, (char) 468,
        Double.longBitsToDouble(0x3fdd8db8805285ccL), Double.longBitsToDouble(0x3fe6fdfb82f9b028L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 6, 0, "\ud87a\udef5\udb6a\udc82", "\u9743\u7187", "\udab6\udf9e\ud8ca\udd7d\udaf1\udccb",
        11, 11624, -1526422250, 1697918926300180587L, 82339L, false, false, (char) 49224, (char) 57202,
        Double.longBitsToDouble(0x3feffe651404b501L), Double.longBitsToDouble(0x3fce0fa0c1b7ebecL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 0, "\uda44\udced\ud910\ude4e", "\u9743\u9982", "\ud85b\udd16\ud968\udef5\ud9e6\ude20",
        2, 67760, -750202043, 8421539349124159828L, 82293L, false, false, (char) 9737, (char) 55990,
        Double.longBitsToDouble(0x3feffe651438b501L), Double.longBitsToDouble(0x3fda9575568efa56L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 7, 0, "\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u88fd\ua15f\ub26a\u918f\u83c9\u3180\u7287\u59a0\uc59d\u6f1c\u9c98\u1603\u7905\ubda7\u0b66\u5f45\u368a\u263c\u65b7\u1c74\u3be1\u1af7\ud4d2\ucd69\u0999\u2ece\u7c12\u34be\u7e88\u737f\u9a49\u4d38\u79c3\u8ae9\u3579", "\ud8cf\udfbf\uda85\uddf7\ud83c\udeb8",
        31, 16339, 1682930395, -8597874123378847933L, -12594L, false, false, (char) 42910, (char) 468,
        Double.longBitsToDouble(0x3fe6c3d44029425cL), Double.longBitsToDouble(0x3fe6ffbacaf9b028L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 0, "\ud8e7\ude8c\udb00\udf9b\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u26fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub21a\u6f1c\u9c98\u1603\ud1f4\ubda7\u3c34\u5f45\u368f\u48e7\u8e05\ua0e7\u90eb\u1af7\u0090\ucd69\u5315\u2e8c\ub833\u103a\u7a4a\u737f\u5b79\u4d38\u79c3\u8ae9\u3579", "\ud8c2\udeae",
        32, 141, -1097309395, -6224340326585763957L, -38371L, true, true, (char) 23695, (char) 30658,
        Double.longBitsToDouble(0x3fe3f31936670d17L), Double.longBitsToDouble(0x3fd2e9200407fc84L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 0, "\ud860\udd65\u2806\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u26fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub61a\u6f1c\u9c98\u1603\u7905\ubda7\u0b66\u5f45\u368a\u263c\u65b7\u1c74\u90eb\u1af7\u0090\ucd69\u0999\u2ece\ud358\u8581\u4268\u737f\u5b79\u4d38\u79c3\u8ae9\u3579", "\ud8cf\udfbf",
        45, 141, -1097309395, -6224340326585763957L, -38371L, true, true, (char) 23695, (char) 30658,
        Double.longBitsToDouble(0x3fc9f164d3483408L), Double.longBitsToDouble(0x3fe6c3b43829425cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 7, 5, "\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u26fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub61a\u6f1c\u9c98\uce4d\ucc5b\ubda7\u0b66\u5f45\u368a\u263c\u65b7\u1c74\u90eb\u1af7\u0090\ucd69\u34b8\u2f21\ud358\u8581\u4268\u737f\u5b79\u4d38\u79c3\u8ae9\u55ed", "\ud8cf\udfbf",
        45, 141, -1097309395, -6224340326585763957L, -38371L, true, true, (char) 23695, (char) 30658,
        Double.longBitsToDouble(0x3fc9f164d3483408L), Double.longBitsToDouble(0x3fe6c3d44029425cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 7, 0, "\ud97b\udc52\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1G", "\u53c8", "\uda83\ude23\uda0d\udf22\udaa5\udc82\ud98b\udc51\u00bd\000\ud938\udc4e",
        -5, -745, 0, 0L, -100000L, false, false, (char) 11860, (char) 38075,
        Double.longBitsToDouble(0x3e49697c00000000L), Double.longBitsToDouble(0x3fe0416d28000000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 7, "\udab3\udd5b\ud9fc\udfb0\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\u084b\ub000\ud8ca\udceb\udaf1\udccb\ud822\udf09\udb03\udf0c\ud96f\udfb9\udae3\udd0e\ud801\udfcb\ud84b\ude14\uda7b\udd18\ud93d\ude09\u32ef\udb13\udece\ud891\ude0f\u008c\000\000\uda9f\udc5a\000\udb54\udc09\u85b8,\ud8b5\udd99\uda98\udd0a\u3627\udbf4\udda4\udb25\ude7b\udba2\ude1d\ud960\udc63\ufa1d", "\u850d\u72b1\ubea5\uccab\u70c0\ua3bd", "\ud9fc\udd4a\ud86e\udf7f\ud8dd\udc04",
        21, 48038, 1083644257, -2259130237132555166L, 71756L, true, true, (char) 34656, (char) 33081,
        Double.longBitsToDouble(0x3feaaf5e2f4ef6edL), Double.longBitsToDouble(0x3fed5565f5693c4aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 0, "", "\ud2e2", "\ud875\udf85\udabe\udca1G\000\ud8ca\udceb\udaf1\udccb\ud822\udf09\udb03\udf0c\ud96f\udfb9\uda0d\udf22\udaa5\udc82\ud98b\udc51\u00bd",
        -5, 98428, 0, 0L, -100000L, false, true, (char) 36666, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e49697c00000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 0, "\000\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud92a\uddaf\udabe\udc93G", "\u53c8", "\ud972\udfb9\uda0d\udf22\udaa5\udc82\ud98b\udc51\u00bd\000\ud938\udc4e",
        -5, -745, 0, -6382726572582463747L, -100000L, false, false, (char) 11860, (char) 38075,
        Double.longBitsToDouble(0x3fedc000028035cfL), Double.longBitsToDouble(0x3fe0416da0000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 4, "\000\ud822\udc17\ud86a\udf79\uda03\udf04\udad7\udd30\ud8ee\udd74\ud93f\udd30\u559e", "\u53c8\u2485\u88fd\uc940", "\ud98b\udc51\udbfa\udc38",
        50, 98428, 0, 1095223869440L, -100000L, false, true, (char) 22415, (char) 59148,
        Double.longBitsToDouble(0x3fb5d205709ef770L), Double.longBitsToDouble(0x3fe6a40308376ce4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 0, "\udaa3\ude2d\ud80a\udd43\udb5d\udda1\udacd\udc2d\ud9ca\ude82\ud9cd\udd2c", "a\ub196\u53c8\ub48d\u4313", "\ud806\udf24\ud900\udd4e\ud929\udc08\ud869\udefe\ud8b4\udc34\ud974\udf0e\ud8a8\ude9c\udb98\udfbf\uda7d\udcf5\uda6c\uddfc\uda9f\udc5a\u00a2\udb33\uddf9\udb2f\udeb8\ud8b3\udddc\ud8b5\uddd3",
        29, 26024, -1567186791, 411918209515158414L, -72261L, true, false, (char) 20795, (char) 9427,
        Double.longBitsToDouble(0x3fdabad857809b16L), Double.longBitsToDouble(0x3fe314be16a62934L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\000\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud850\udc8b\ud875\udf85\udabe\udca1\ud816\udf11\uda93\udf86\udb7f\udc68\ud82b\udd08\ud822\udee0\udb03\udf0c\ud96f\udfb9\ud93a\udf99", "\u45eb\u9257\uc294\000\u00ff\u0c08\uc430", "\udb64\udeed\ud81c\udc8f\udb14\udd2c\udaf7\udf0e\ud8b5\udd99\uda98\udd0a\u3a08\udbc6\ude22\ud937\udcaf\uda10\udc2e\ud987\ude2e\ud86a\udc94\ud83a\udec4\ud1ea\uda68\ude63\ud92a\udf7e\udb1f\udc91",
        1, 6860, 1491142835, -7171364378123349265L, -22689L, true, true, (char) 15276, (char) 65397,
        Double.longBitsToDouble(0x3fbc70cf42bdc3f8L), Double.longBitsToDouble(0x3fab5bd558043fa0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 0, "\ud9d7\ude04\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f\uda8d\uded7\ud8f9\udfae\udaf1\udccb\ud9e2\udda8\ud821\uddbb\ud92e\udd77\uda43\udc02", "\u155b\u3a38\u505f\ub7e2\u57ce\ua825\u1603\u7905", "\udbdd\udd06\udaa5\udf5a\udbf7\udebc\udb51\udc92\uda98\udd0a\u8351\udb68\udc1c\ud822\udd04\udba5\udcce\ud811\ude6d\udbaa\udd5b\uda4b\udfb0\ud80b\ude73\udbe1\udd43\ud915\uddb1\ud990\udcb0\udbb7\udcf0\ud91d\udf17\ud975\udc3c\uda1d\udcf7",
        24, 64303, -1417603910, 5521848714936863781L, -14867L, false, false, (char) 39053, (char) 15089,
        Double.longBitsToDouble(0x3fed227d1abcb1b8L), Double.longBitsToDouble(0x3feace6850317c20L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 0, "\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ucf73\u88fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub61a\u6f1c\u9c98\u1603\u7cca\ubda7\u0b66\u5f45\u368a\u263c\u65b7\u1c74\u3be1\u1af7\ud4d2\uc2aa\ub498\u2ece\ud358\u8581\u4268\u737f\u5b79\u4d38\u79c3\u8ae9\u3579", "\ud8cf\udfbf\ud82e\udcaa\u9b0e",
        -5, 30835, 1891071883, -8597735044343722173L, -12594L, false, false, (char) 24197, (char) 468,
        Double.longBitsToDouble(0x3fe6c3d44029425cL), Double.longBitsToDouble(0x3fe6ffbaca81ef28L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "\ud2e2", "\ud875\udf85\udabe\udca1\ud9f8\udd0f\udab6\udf9e\ud8ca\udd7d\003\ud822\udf09\udb03\udf0c\026\ud9c8\udd63\udacd\udfb2\udb2d\uddb0\ud8fc\ude3d",
        54, -956, -872415232, -5403967711321121788L, 14579L, false, true, (char) 9410, (char) 64822,
        Double.longBitsToDouble(0x3fd7ef8f88c1e14eL), Double.longBitsToDouble(0x3feb9a0dbac5ef43L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "", "", "\ud969\udfb6",
        13, 43940, -346383801, 4676646553578706885L, -100000L, false, false, (char) 7968, (char) 54088,
        Double.longBitsToDouble(0x3fd000000a726d0aL), Double.longBitsToDouble(0x3fef5f853200007dL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "\uda44\udced\ud910\ude4e", "\ua207\u3ebc", "\ud85b\udd16\ud968\udef5\udb85\udcf0",
        15, 39269, 1950770406, -772599370787519404L, -50847L, false, false, (char) 39534, (char) 2007,
        Double.longBitsToDouble(0x3fcd7de9dd7f70b8L), Double.longBitsToDouble(0x3fe85dced87a991fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 5, "\ud906\udd95\ud910\ude4e\ud95b\ude18\uda16\udee6", "\u967a\u4de3", "\ud9e6\ude20\ud925\uddff\ud98b\uded0\ud970\udca2\ud8e2\udd51\u331d\ud9b0\udf69\ud801\udc39\u3098\ud920\udde2",
        25, 47719, 2134522331, 9019427279521449376L, 24365L, false, true, (char) 11482, (char) 35829,
        Double.longBitsToDouble(0x3fc34f11d4696f18L), Double.longBitsToDouble(0x3feec47e6435818bL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 0, "\ud8e7\ude8c\udb00\udf9b\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u26fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub21a\u6f1c\u9c98\u1603\ud1f4\ubda7\u3c34\u5f45\u368f\u48e7\u8e05\u8b25\u9155\u1af7\u0090\u2f80\u0d04\u2e8c\ub833\u103a\u7a4a\u737f\u5b79\u4d38\u79c3\u8ae9\u3579", "\ud8c2\udeae",
        32, 141, -1097309395, -6224340326585763957L, -38371L, true, true, (char) 23695, (char) 30658,
        Double.longBitsToDouble(0x3fe3f31936670d17L), Double.longBitsToDouble(0x3fd2e9200407fc84L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "", "\ud2e2\u7146\u9743\u7187\u46dc\u99ce\ua06a\ub228\u53c8\ub48d\u26fd\uc940\ub26a\u918f", "\ud9cc\udddc\ud936\ude47",
        8, 47719, -1279928572, 9019427651181366087L, -46162L, false, true, (char) 24708, (char) 55057,
        Double.longBitsToDouble(0x3f809ee200054000L), Double.longBitsToDouble(0x3e35780000000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "", "\000", "\177\udabe\udc93\000\000\ud8ca\udceb\003\ud822\ude38",
        24, -978, 0, 360777252864L, -100000L, false, false, (char) 40054, (char) 255,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe7ed3b6300d6c6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 7, 0, "\ud8e7\ude8c\ud9ef\udc9e\ud95b\ude18\ud909\udf7f\ud969\udfb6\ud875\udf85\udabe\udca1\ud9f8\udd0f", "\u53c8\ub48d\u88fd\uc940\ub26a\u918f\u8307\u155b\u3a38\u7033\ub61a\u6f1c\u9c98\u1603\u7905\ubda7\u0b66\u5f45\u368a\u443a\u65b7\u1c74\u3be1\u1af7\ud4d2\ucd69\u0999\u2ece\ud358\u8581\u4268\u737f\u5b79\u4d38\u79c3\u8ae9\u3579", "\ud8cf\udfbf\ud82e\udcaa\u9b0e",
        -5, 30835, 1891071883, -8597874123974701245L, -12594L, false, false, (char) 48117, (char) 468,
        Double.longBitsToDouble(0x3fe6c3d44029425cL), Double.longBitsToDouble(0x3fe6ffbacaf9b028L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 0, "7", "\u7146\u9743\u7187\u46dcG\000\ub196\u53c8\ub48d\u88fd\u8224\ub26a\u5954\u8307\ud3be\u9db5\u114f\000", "\udaa6\udd74",
        15, 51456, 0, 0L, -100000L, false, false, (char) 38254, (char) 20038,
        Double.longBitsToDouble(0x3fc3147f89e68658L), Double.longBitsToDouble(0x3fe96c9a0d4739d4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 0, "7", "\u7146\u9743\u7187\u46dcG\000\ub196\u53c8\ub48d\u88fd\u8224\ub26a\u5954\u8307\ud3be\u9db5\u114f\000", "\udaa6\udd74",
        27, 51565, 0, 0L, -100000L, false, false, (char) 38254, (char) 20038,
        Double.longBitsToDouble(0x3fc3147f898a8658L), Double.longBitsToDouble(0x3fce526837898f5cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "9", "\ud875\udf85\udabe\udca1",
        24, 22694, -2015899502, 11239147729L, -99978L, false, false, (char) 2043, (char) 57647,
        Double.longBitsToDouble(0x3ec4cab898000000L), Double.longBitsToDouble(0x3fa6790e00000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "", "9", "\ud875\udf85\udabe\udca1",
        24, 22694, -2015899502, 11239147729L, -99978L, false, false, (char) 2043, (char) 57647,
        Double.longBitsToDouble(0x3ec4cab898000000L), Double.longBitsToDouble(0x3fa6790e00000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 7, "7", "\u012f\u96e5\u7187\u46dcG\000\ub196\u53c8\ub48d\u88fd\u8224\ub26a\u5954\uc142\u6419\u9db5\u114f\u2c93", "\ud863\udfd3\ud925\udd81\udacf\udf7a\ud89b\uddc7\000\000\000\ud8b5\udd99\uda6e\udd95\udb34\udc60\udb02\udee4\uda88\udf07\ud991\udc10\ud9c0\ude95\udbfc\udff0\uda59\udca3\udb4d\udf58\ud901\udde0",
        57, 96400, -1087029921, -7606756303849653353L, 93855L, true, false, (char) 64723, (char) 23533,
        Double.longBitsToDouble(0x3fed786002ae1f92L), Double.longBitsToDouble(0x3fe08beb464421acL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 0, "7", "\u3b9a\u9743\u7187\u46dc\u2322\u382f\ub21f\u27cb\ud041\u88fd\u8224\ub26a\u5954\u8307\ud3be\u9db5\u114f\000", "\udaa6\udd74",
        15, 51456, 0, 0L, -100000L, false, false, (char) 38254, (char) 20038,
        Double.longBitsToDouble(0x3fc3147f89e68658L), Double.longBitsToDouble(0x3fe96c9a0d4739d4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "7", "\u3b9a\u9743\u7187\u46dc\u2322\u382f\ub21f\u27cb\ud041\u88fd\u8224\ub26a\u5954\u8307\ud3be\u9db5\u114f\000", "\ud971\ude70",
        -1, 23113, 0, 0L, -100000L, false, false, (char) 38254, (char) 20038,
        Double.longBitsToDouble(0x3fc3147f8bcec258L), Double.longBitsToDouble(0x3fe96c9a0d4739d4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 7, "\udbc3\udd82\uda07\udca7\udbc6\udef5\udb6d\udce7\ud96e\udd40\ud875\udf85\ud84e\ude6a\u084b\ub000\ud8ca\udceb\udaf1\udccb\ud822\udf09\udb03\udf0c\ud93e\udd7e\u32bc\udbae\udcb0\ud864\udee7\uda7b\udd18\ud93d\ude09\u32ef\udb13\udece\ud891\ude62\u008c\000\000\uda9f\udc5a\000\udb54\udc09\u85b8,\ud8b5\udd99\uda98\udd0a\u3627\ud824\udd99\uda2e\ude21\udba2\ude1d\ud960\udc63\ufa1d", "\uaa57\u72b1\ubea5\uccab\u70c0\ua3bd", "\ud9fc\udd4a\ud86e\udf7f\ud8dd\udc04",
        8, 48038, 1083644257, -2285715328780551070L, 71756L, true, true, (char) 23666, (char) 25767,
        Double.longBitsToDouble(0x3fd1382c57b6d644L), Double.longBitsToDouble(0x3fed52e415693c4aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|compute|java.lang.Object,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|computeValue|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|containsMatch|java.util.Iterator,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|evaluateCompare|int|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|findMatch|java.util.Iterator,java.util.Iterator|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|getPrecedence||new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|isSymmetric||new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|reduce|java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression|compute|java.lang.Object,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationGreaterThan:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
