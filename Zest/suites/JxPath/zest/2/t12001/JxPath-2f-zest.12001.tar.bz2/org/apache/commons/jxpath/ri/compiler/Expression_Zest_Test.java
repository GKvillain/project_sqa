package org.apache.commons.jxpath.ri.compiler;
import org.junit.Test;
import static org.junit.Assert.*;
public class Expression_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:11 |this=org.apache.commons.jxpath.ri.compiler.Constant:11\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:11\012",
        Z.run(T, 2, 4, 3, 6, "\uda6f\ude16\udb5e\udff0\ud8b2\udd87\ud80d\udfa4\ud886\udfc2\uda3d\udfd8\udbb5\udf38\udb7e\udf21\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\uda80\udee2\udb11\udc69\udbb6\ude07\ud8b8\udf81\udb5d\udcab\udb2c\udf53\ud8d4\udca7\ud95c\udf93", "\u4705\u0cff\u98be\u4847", "\ud9dc\udccf\ud924\udc4d\ud830\ude38\ud851\udfee\uda8d\udfbd\uda9f\ude99\ufde8",
        11, 569, 664966749, -3411250197125888363L, -66688L, true, true, (char) 13721, (char) 42819,
        Double.longBitsToDouble(0x3fe6e150b7566ec7L), Double.longBitsToDouble(0x3feaafaad29df3e8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.apache.commons.jxpath.ri.compiler.Constant:40\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:40\012",
        Z.run(T, 2, 4, 3, 6, "\uda9e\ude5c\udb5e\udff0\ud8b2\udd87\ud80d\udfa4\ud886\udfc2\uda3d\udfd8\udbb5\udf38\udb7e\udf21\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\ud8ad\uddc2\uda80\udee2\udb11\udc69\udaa1\udc69\ud8b8\udf81\udb5d\udcab\udb2c\udf53\ud8d4\udca7\ud95c\udf93", "\ub162\u3238\u98be\u4847", "\ud9dc\udccf\ud924\udc4d\ud830\ude38\ud851\udfee\uda8d\udfbd\uda9f\ude99\ud90d\udfb0",
        40, 569, -1700620707, -3446679055933077867L, -66688L, true, true, (char) 15769, (char) 42819,
        Double.longBitsToDouble(0x3fe6e150b7566ec7L), Double.longBitsToDouble(0x3feaafaad1276c05L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:0.5050340119473917 |this=org.apache.commons.jxpath.ri.compiler.Constant:0.5050340119473917\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:0.5050340119473917\012",
        Z.run(T, 2, 4, 3, 6, "\000\udb5e\udf89\ud971\uddb7\ud80d\udfa4\ud886\udfc2\uda3d\udfd8\udbb5\udf38\udb7e\udf21\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\u9571\uda51\udc87\udb11\udc69\udbb6\ude07\ud8b8\udf81\udb5d\udcab\udb2c\udf53\ud8d4\udca7\ud95c\udf93", "\u4705", "\udbc5\ude79",
        56, 51371, 239, -4383062489664408360L, 74443L, false, false, (char) 27186, (char) 38566,
        Double.longBitsToDouble(0x3fe0293d1695d0a8L), Double.longBitsToDouble(0x3fd3ff05444090c6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 2, "\udb6c\udf77\udb5e\udff0\ud8b2\udd87", "\ubeb4\u083f", "\ud8e4\udfa6\ud87e\udf9f\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\uda80\udee2\udb11\udc69\udbb6\ude07",
        -5, 47316, 1920316565, 3363702829314043507L, -13603L, false, false, (char) 36368, (char) 808,
        Double.longBitsToDouble(0x3fb289b341b128e8L), Double.longBitsToDouble(0x3fe21f1062ef884fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:11\0121=java.util.Collections$1:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:11\012",
        Z.run(T, 2, 3, 6, 6, "\uda6f\ude16\udb5e\udff0\ud8b2\udd87\ud80d\udfa4\ud886\udfc2\uda3d\udfd8\udbb5\udf38\udb7e\udf21\udbbc\udf95\udb36\udc90\uda7e\udeed\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\uda80\udee2\udaeb\udd69\udbb6\ude07\ud8b8\udf81\udb5d\udcab\udb2c\udf53\ud900\udfa7\ud95c\udf93", "\u4705\u0cff\u98be\u4847", "\ud9dc\udccf\ud924\udc4d\ud830\ude38\ud851\udfee\uda8d\udfbd\uda9f\ude99\ufde8",
        11, 569, 664966749, -3394080223546538347L, -66688L, true, true, (char) 13721, (char) 42819,
        Double.longBitsToDouble(0x3fe6e150b7566ec7L), Double.longBitsToDouble(0x3feaafaad29df3e8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:0.4532577808820364\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:0.4532577808820364\012",
        Z.run(T, 2, 5, 5, 6, "\ud89a\udf15\ud855\udc6a\uda7c\uddde\ud9d1\udfa5\ud805\udd51\ud99f\udc2d\ud84a\ude21\udbcf\udc36\ud909\udec7\udbcd\udd18\uda62\udcf3\ud9d7\udf5f\ud86a\udd10\ud91e\udd83\udbdc\udd17\udbfd\udf7a\uda41\udd75\ud909\udeb1\uda97\udd74\uda4e\udc21\ud951\ude06\udb5d\udcab\udb2c\udf53\udabc\udd5c\ud95c\udf93", "\u124d\u90b0\u504a\u882e\ub498\u9d32\u4770\u33cb\u58f3\u7c4c\u8780\u2139\u616c\u9afa\u4d53\u04bf\ucc7e\u4dfc\u92b3\ub8fa\u99bf\u8f31\ua768\u29fd\u1d62\u1c08\u4644\u5ebf\u2f97\u0812\uc3b0\u6d05\uc4d4\u6f70\u4cee", "\ud81b\udf2b",
        20, 7520, 377669946, 260061969457125716L, 49519L, false, false, (char) 7349, (char) 52984,
        Double.longBitsToDouble(0x3fdd022cec62efb4L), Double.longBitsToDouble(0x3fc59702facf5534L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:44 |this=org.apache.commons.jxpath.ri.compiler.Constant:44\0121=java.lang.Integer:44 |this=org.apache.commons.jxpath.ri.compiler.Constant:44\012",
        Z.run(T, 2, 4, 2, 2, "\uda6f\ude16\udb5e\udff0\ud8b2\udd87\ud80d\udfa4\ud886\udfc2\uda3d\udfd8\udbb5\udf38\udb7e\udf21\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud82d\ude14\udaa0\udd59\ud8ee\udf12\u3227\ud6cb\ud896\ude9c\uda80\udee2\udb11\udc69\udba0\udf85\ud8b7\udc81\udb5d\udcab\udb2c\udf53\ud8d4\udca7\ud95c\udf93", "\u8537\u723b\u98be\u4847", "\ud9dc\udccf",
        44, 59896, -1157510145, 1249756285973772977L, 16850L, true, true, (char) 26023, (char) 62886,
        Double.longBitsToDouble(0x3fe4ae85453ff054L), Double.longBitsToDouble(0x3fe102431dc320c8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.Collections$1:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:0.3068274783226478\0121=java.util.Collections$1:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:0.3068274783226478\012",
        Z.run(T, 2, 0, 0, 1, "\uda6f\ude16\udb5e\udff0\ud8b2\udd87\ud80d\udfa4\ud886\udfc2\uda53\uddd8\udbb5\udf38\ud907\udd1b\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\ud9eb\udf38\udb10\udfe3\udbb6\ude07\ud8b8\udf81\udb5d\udcab\udb3f\ude82\ud8d4\udca7", "\u71d3\u4705\u0cff\u98be\u4847\u54b6\u2068\u483c\u33cb\ud3e8\u90c6\u1a55\ua869\u19e3\u4057\u3c0e", "\uda49\udda8\ud812\udd83\uda3f\udc0e\ud809\udd45\ud8c7\udcfd\udbc3\ude75\ud903\udd63\ud947\udf4a\uda29\ude9e\uda2f\udc7a\uda3f\udf82\uda4f\udc95\udb61\udf96\ud860\ude83\ud8f5\udc38\ud98d\udd0f\udb78\ude50\uda7d\udeda\ud983\ude14\udb20\ude45\udbaf\udfd1\ud856\udfc9\uda15\udc25",
        21, 29176, 1454481969, 7854359908032615722L, 73241L, false, false, (char) 64698, (char) 57346,
        Double.longBitsToDouble(0x3fd3a30fb83a3c26L), Double.longBitsToDouble(0x3fe80d92cb343fffL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:0.6536738340700613 |this=org.apache.commons.jxpath.ri.compiler.Constant:0.6536738340700613\012",
        Z.run(T, 1, 4, 3, 2, "\udb7c\udd7d\ud982\udd41\ud8b2\udd87\ud80d\udfa4\ud886\udf87\uda7e\udff8\ud807\udddb\udb7e\udf21\udbbc\udf95\udabf\uddb5\uf1ac\ud99b\udcd2\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\uda80\udee2\udb11\udc69\udbb6\ude07\ud8b8\udf81\udb5d\udcab\udb2c\udf53\ud8d4\udca7\ud95c\udf93", "\u680d\u0d25\u98be\u4847\u54b6\ucf57\u6098\u5676\u919b\u8a39", "\ufde8\ud93b\udc76\ud86e\udeea\udb3f\udf8a",
        22, 27669, -834988453, 9101965026020306824L, 44379L, false, false, (char) 36381, (char) 19632,
        Double.longBitsToDouble(0x3fe4eae563729e77L), Double.longBitsToDouble(0x3fda063aab09cae8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\012",
        Z.run(T, 2, 4, 3, 6, "\uda6f\ude16\udb5e\udff0\ud80a\udd93\ud80d\udfa4\ud886\udfc2\udae9\ude8f\u4e10\udb7e\udf21\ud801\udc3f\ucdcb\ud9d5\udfcd\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\uda80\udee2\ud824\udc1a\udbb6\ude07\ud8b8\udf81\udb5d\udcab\udb2c\udf53\ud8d4\udca7\ud95c\udf93", "\u4705\ubcdf\ud7d3\u4880", "\ud9dc\udccf\ud924\udc4d\ud830\ude38\ud851\udfee\uf9c4\uda9f\ude99\ufde8\ud93b\udc76\udab6\ude2f\ud866\udcb2\ud912\ude4a\udac9\udf1f\ud812\udd82\uda3f\udc0e\ud809\udd45\ud8c7\udcfd\udb30\udf2b\udb15\uddc4\udb09\udfb0\uda29\ude9e\ud8db\udef0\udb51\udc3f\ud80c\udeeb\u0411\udb7f\udf7e\ud9f4\udc55\uda51\udf4d\ud86a\udf57\ud89d\udd5f\udb97\udd23\udb3f\udf2c\ud89a\udd41",
        50, 73206, -264656896, -453083680154306959L, 3325L, true, false, (char) 65255, (char) 57302,
        Double.longBitsToDouble(0x3fe9930989144a1aL), Double.longBitsToDouble(0x3fe2476087ca0ee0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:0.7363016410910295\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 2, "\uda6f\ude16\udb5e\udff0\ud8b2\udd87\ud8e7\udd51\ud886\udfc2\uda3d\udfd8\udbb5\udf38\udb7e\udf21\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\uda80\udee2\ud81d\uddd0\udbb6\ude61\ud8b8\udf81\udb5d\udcab\udb2c\udf53\ud8d4\udca7\ud95c\udf93", "\u42ad\u0c84\u98be\u73c4", "\ud9dc\udc06\ud924\udc4d\ud830\ude38\ud851\udfee\ud9e4\udfc4\uda9f\ude5f\ufde8\ud93b\udc76\ud86e\udeea\udbd2\udcb2\udb1e\udf3a\uda49\udda8\ud812\udd83\uda51\uddf7\ud812\uddda",
        31, 51459, 1858586332, 7972538222727681862L, 9872L, false, true, (char) 5729, (char) 32864,
        Double.longBitsToDouble(0x3fe78fc8758f446aL), Double.longBitsToDouble(0x3fe7aeb9ce61cc0bL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:11\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 5, "\uda6f\ude16\udb5e\udff0\ud8b2\udd87\ud80d\udfa4\ud886\udfc2\uda3d\udfd8\udbb5\udf38\udb7e\udf21\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud9b1\udfeb\uda89\udc9e\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\uda80\udee2\udb11\udc69\udbb6\ude07\ud888\udd6a\udb5d\udd6b\udb2c\udf53\ud8d4\udca7\ud95c\udf93", "\u4705\u0cff\u98be\u4847", "\ud9dc\udccf\ud8bf\udf7f\ud830\ude38\ud851\udfee\uda8d\udfbd\uda9f\ude99\ufde8",
        11, 569, 664966749, -3411250197125888363L, -66688L, true, true, (char) 13721, (char) 42819,
        Double.longBitsToDouble(0x3fe6e150b7566ec7L), Double.longBitsToDouble(0x3feaafaad29df3e8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\0121=null |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\012",
        Z.run(T, 2, 4, 4, 5, "\ud9a2\udd80\udb5e\udfd7\u018f\ud80d\udfa4\ud886\udfc2", "\u7a30", "\ud9f7\udc6a\ud9b1\udfeb\udaa0\udd48\ud86a\ude6f\u3227\uda4d\udcab\ud896\ude69\ud95d\udc10\ud807\udc48\udbb6\ude07",
        3, 15186, 1926267175, 7746572784185038045L, 53269L, true, false, (char) 47894, (char) 756,
        Double.longBitsToDouble(0x3fe21f1642ef884fL), Double.longBitsToDouble(0x3fcc7b7f33630f80L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.Collections$1:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:33\012",
        Z.run(T, 1, 6, 6, 6, "\ud8fc\uddbe", "\u11aa\u295c\u1dda", "\udbbc\udf95\udb82\udc32\udb7c\ude48\udbb9\udd86",
        33, 31909, -293571793, 4283108900153812883L, 37129L, true, true, (char) 48808, (char) 2119,
        Double.longBitsToDouble(0x3fd5183c18f994d6L), Double.longBitsToDouble(0x3fe39976d5773beaL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\0121=java.util.Collections$EmptyIterator:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\012",
        Z.run(T, 2, 2, 0, 6, "\uda6f\ude16\udb5e\udff0\ud8b2\udd87\ud80d\udfa4\ud886\udfc2\uda3d\udfd8\udbb5\udf38\udb7e\udf21\udbbc\udf95\ud872\udc8e\ud912\udf6c\udab2\udfc1\ud9e1\uded2\uda80\udf1b\u3227\uda4d\udcab\ud896\ude69\uda70\udef2\udb11\udc69\udbb6\ude07\uda6b\uddee\udb5d\udd98\udb2c\udf53\ud8d4\udca7\ud95c\udf93", "\u3d05\u0c85\u98be\u4847", "\ud9dc\udccf\ud924\udc4d\udbff\udf41\ud861\udea7\uda8d\udfbd\uda9f\ude99\ud89a\udff6",
        14, 11225, 664968843, -4420056514567060063L, -66688L, true, true, (char) 13721, (char) 12100,
        Double.longBitsToDouble(0x3fe6e150b7566ec7L), Double.longBitsToDouble(0x3feaafaad466e6e8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\012",
        Z.run(T, 2, 1, 3, 1, "\uda6f\ude16\udb5e\udff0", "\u6644\u3f32\u7dea\ud12a", "\ud9f7\udc6a\ud9b1\udfeb\ud9ec\udd4e\ud8ee\udf12\u3227\uda4d\udcab\u896f",
        38, 79633, 426956936, 6749961237265153036L, 48967L, true, false, (char) 10388, (char) 45729,
        Double.longBitsToDouble(0x3fb82f3275aba7d0L), Double.longBitsToDouble(0x3fe60902744a26cdL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\0121=java.util.Collections$EmptyIterator:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\012",
        Z.run(T, 2, 0, 6, 1, "\uda62\udfd0\uda27\ude1a\udb30\ude53\ud98b\udf18\ud8ad\udfb8\uda3d\udfd8\u922f\udb7e\udf6f\udbbc\udf95\ud932\udd0e\udbbf\udde8\ud855\udfa1\uda2a\udd03\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\ud9e1\udc6c\udb0b\uddc9\udb8e\ude07\ud8a0\udc81\ud98e\udca2\udb17\udf2e\ud8d4\udca7\ud9e8\ude78", "\u276f\u8eff", "\ud988\udeb0\ud91d\udf35\ud8bc\udf2b\ud93e\udcaa",
        56, 49855, 296870840, -5002308752132974955L, -78953L, false, false, (char) 62886, (char) 22333,
        Double.longBitsToDouble(0x3fd3ff05444090c6L), Double.longBitsToDouble(0x3fdf620c8f647e90L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\012",
        Z.run(T, 2, 3, 3, 3, "\uda3f\udc16\udb5e\udff0\ud8b2\udd87\ud80d\udfa4\ud886\udfc2\uda3d\udfd8\ud98d\udd45\udb7e\udef2\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12", "\u607e\u2975\ub259\ub274\u0d02\ub215\u51f0\u73bf\u7c67\u1c78", "\uda34\udec4\ud987\udc73\udbfc\ude8f",
        52, 51371, -1598482193, -2410185428496363514L, -7005L, true, false, (char) 59093, (char) 36144,
        Double.longBitsToDouble(0x3fe639fbeabb95baL), Double.longBitsToDouble(0x3fe02bd6afefeab4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:-5\012",
        Z.run(T, 1, 3, 2, 4, "\ud89c\udfec\udb87\udc66", "\u6644\u3f32\u7dea\ud12a\u57c5", "\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab",
        -5, 31603, 445692633, 1833634137096629756L, 50379L, true, true, (char) 18616, (char) 43270,
        Double.longBitsToDouble(0x3fd7d616d8c17992L), Double.longBitsToDouble(0x3fe5aba7d2c1204eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\012",
        Z.run(T, 1, 0, 0, 0, "", "\ub6fc\u242c", "\ud801\uddfd",
        -5, 81144, 0, -3971374794631056830L, 75616L, true, true, (char) 43353, (char) 20093,
        Double.longBitsToDouble(0x3fe2de6498d94cddL), Double.longBitsToDouble(0x3fc10352000065c8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\0121=java.util.Collections$EmptyIterator:@? |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\012",
        Z.run(T, 2, 1, 1, 3, "\000\udb5e\udf89\ud959\ude2f\ud828\udc74\ud886\udfc2\uda3d\udfd8\udbb5\udf38\udb7e\udf21\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\ud850\ude28\uda4d\udcab\u9571\uda51\udc87\udb11\udc69\udbb6\ude07\ud8b8\udf0a\udb5d\udcab\udb65\uddd0\udb2f\udeaf\ud95c\udf93", "\u4705\u0cff\u98be", "\ud91d\udf35\u00ef\ud924\udc4d\ud830\ude38",
        35, -440, -1728081999, 8955953138350278770L, 69565L, true, false, (char) 22333, (char) 3476,
        Double.longBitsToDouble(0x3fe102431e43bec1L), Double.longBitsToDouble(0x3fe41e259b9b9113L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.compiler.Constant:'null'\012",
        Z.run(T, 1, 4, 0, 0, "", "\ub6fc\u11aa\ud5f7\u18a7\000\000\uaf79\u6fb3\u94a4\u9420\u56ac\u3c2a\uae71", "\uda51\udc87",
        43, 28936, 252, 1920270336L, -6189L, false, true, (char) 45729, (char) 45353,
        Double.longBitsToDouble(0x3fe0b4dfd0000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:8 |this=org.apache.commons.jxpath.ri.compiler.Constant:8\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.Constant:8\012",
        Z.run(T, 2, 4, 3, 6, "\uda6f\uddfa\udb5e\udff0\ud8b2\udd87\ud80d\udfa4\ud8a0\udd90\uda4b\udf56\udbb5\udf38\udb7e\udf21\udbbc\udf95\udb36\udc90\ud9f7\udc6a\ud9b1\udfeb\udaa0\udd48\ud8ee\udf12\u3227\uda4d\udcab\ud896\ude69\uda80\udee2\udb11\udc69\udbb6\ude07\ud8b8\udf81\udb5d\udcab\udb2c\udf53\ud8d4\udca7\uda38\udd32\udbc7\udccb\udbe7\udd3c\udb48\udf44\ud966\udc9c\udb18\ude90\udbc5\udeb0\ud857\ude72\ud91d\udf35\ud9dc\udc48", "\u8a39\u4b46\ua869\u19e3\u4057\u3c0e\uad56\u35e9\u7c02\u2b0a\ub8fa\u74c2\u8ed4\u8ddc\u2a28", "\ud925\udef5\uda46\udc03\uc9f0\ud893\udfe3",
        8, 73144, 2145555911, -5761559973743330757L, 14853L, true, true, (char) 29146, (char) 53587,
        Double.longBitsToDouble(0x3fe10f8d43fee00bL), Double.longBitsToDouble(0x3fe8157c55933617L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.compiler.Expression|iterate|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.Constant:java.lang.Number",
    "M|org.apache.commons.jxpath.ri.compiler.Expression|iteratePointers|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.Constant:java.lang.Number",
    "M|org.apache.commons.jxpath.ri.compiler.Expression|compute|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.Constant:java.lang.Number",
    "M|org.apache.commons.jxpath.ri.compiler.Expression|computeContextDependent||new:org.apache.commons.jxpath.ri.compiler.Constant:java.lang.Number",
    "M|org.apache.commons.jxpath.ri.compiler.Expression|computeValue|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.Constant:java.lang.Number",
    "M|org.apache.commons.jxpath.ri.compiler.Expression|isContextDependent||new:org.apache.commons.jxpath.ri.compiler.Constant:java.lang.Number",
    "M|org.apache.commons.jxpath.ri.compiler.Expression|iterate|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.Constant:java.lang.Number",
    "M|org.apache.commons.jxpath.ri.compiler.Expression|iteratePointers|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.Constant:java.lang.Number",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
