package org.apache.commons.jxpath.ri.compiler;
import org.junit.Test;
import static org.junit.Assert.*;
public class CoreOperationCompare_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 11, "\ud8cf\udf75\ud9ae\udc03\ud983\udc52\uda98\udfbe\ud9b4\udfbf\ud984\udcac\udbe1\udd35\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\ud8dc\udc64\uda3d\udc3a\udafb\uddc6\ud920\udda6", "\u2072\u8080\ua392\ua759\u554e\u54a9\u88cf\ub5ae\u0a76\u8f34", "\ud860\udd78",
        22, 2395, 994481364, -7735010742883424752L, 32464L, false, true, (char) 20921, (char) 55949,
        Double.longBitsToDouble(0x3fecf42411be30d3L), Double.longBitsToDouble(0x3feb05a6701478c6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 11, "\ud8cf\udf75\udb7a\udda9\udbc2\udeec\uda98\udfbe\ud9b4\udfbf\ud984\udcac\udbe1\udd35\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\ud8dc\udc64\uda3d\udc3a\ud85c\udec7\ud920\udda6", "\u2072\u8080\ua392\ua759\ua4b6\uc720\u88cf\ub5ae\u0a76\u8f34", "\ud860\udd78",
        22, 2395, 994467028, -7735010742883424752L, 32464L, false, true, (char) 20921, (char) 55949,
        Double.longBitsToDouble(0x3fecf42411be30d3L), Double.longBitsToDouble(0x3fb82d3380a2a990L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 7, 11, "\ud8cf\udf75\ud9ae\udc03\ud983\udc52\ud8d9\udede\ud8c5\udf31\uda46\ude76\udae3\uddf8\ud84d\udf84\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\ud8dc\udc64\uda3d\udc3a\u720b\ud8ef\udefb", "\u2072\u60fc\u9b07\u50b4\u4e36\u50ce\uc336\ub5a0\u0a76\u8f34\ucb8b\u9abb", "\ud90c\udd9a\ud8e4\udc52\uda06\ude62\ud9cf\udf0a\udaa5\udd19\ud9ef\udc86\ud833\ude3e\uda32\udfaf\udbcb\udf53\uda4a\ude7e\uda5f\udd4f\udbe1\udf03\udba2\udce9\udb37\ude4f\ud853\udd7c\ud8dd\udd04\u46dc\uda36\udce2\uda42\ude0d\uda35\ude0a\udb39\udced\ud96d\udee5\ud8a7\udd7c\u22a0\ud801\udc31\uda19\udf36\uda69\udedd\udafb\udc8d\udacd\ude66",
        27, 59261, 720389054, 5004358059657320379L, 14580L, true, false, (char) 25027, (char) 26965,
        Double.longBitsToDouble(0x3fe3c8fb3b7a7486L), Double.longBitsToDouble(0x3fcf5dd91b14fb5cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 2, "\ud8cf\udf75\u47b3\ud982\udfc9\uda98\udfbe\ud9b4\udfbf\ud984\udcac\udbe1\udd35\udb4a\udd01\ud831\udd36\ud99f\uddbb\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\udaa1\udf54\udae8\udc30\ud961\udf58\ud8e4\udccf\uda3d\udc3a\ud8d7\udccc\ud90c\udf0e", "\u2072\u8080\ua392\ua759\ubd8a\u9e23\u88cf\ub5ae\u545e\u95a0", "\ud9ea\udf2f",
        48, 2395, 994481364, -7735010742883424752L, 32464L, false, true, (char) 61550, (char) 55949,
        Double.longBitsToDouble(0x3fecf42411be30d3L), Double.longBitsToDouble(0x3fd8b044b028f134L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 12, 11, "\ud8cf\udf75", "\u6dfa\u31a9\u6394\u1875\u05ff", "\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\uda33\ude59\udbeb\udc31\udafb\uddc6\ud920\udda6\ud809\uddf7\000\ud944\udef3\u3523\uda46\udd44\ud84e\udeb8",
        48, 93613, 247701328, 7079783118457575683L, -73729L, false, true, (char) 32277, (char) 28799,
        Double.longBitsToDouble(0x3fc377f0735043b0L), Double.longBitsToDouble(0x3fc6c768d842529cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 12, 11, "\udb1d\udc54\uda72\udfb3\ud983\udc52\uda98\udfbe\ud9b4\udf49\udbc6\udcad\udbe1\udd35\ud8f6\udce1\ud92e\udd1e\u9952\udbbd\udecc\udbe0\udd46\udb16\udcea\uda5f\ude5b\udb7b\udeb8\ud94f\udedc\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\ud8dc\udc64", "\000\ua506\u6f54\u201a\u8080\ua392", "\ud9d2\ude81\udb3c\udc82",
        23, 57523, -471704616, -7482618052745485842L, -17690L, true, false, (char) 42431, (char) 62459,
        Double.longBitsToDouble(0x3fe32062ba6a10c9L), Double.longBitsToDouble(0x3fd702d95ec5e10cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 11, "\ud8cf\udf75\ud9ae\udc03\ud983\udc52\uda98\udfbe\ud9b4\udfbf\ud846\udc4e\udbe1\udd35\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8a2\udf2e\ud85c\udf1e\ud9eb\udc52\ud878\udf5b\ud94f\udf27\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\ud96e\udf10\udb5a\ude88\ud9cd\udc97\udbac\udff7", "\u2072", "\ud958\udc51\ud2c1\ud9d2\ude81\udae6\udc2e\udb39\udce9\udbc9\udf78\u2e62\ud95c\udc80\ud8ca\udecf\uda85\udd89\udbcd\udd63\ud9a3\udd66\ud8e4\udc52\uda06\ude62\ud9eb\udc8e\udaa5\udd19\ud9ef\udc86\ud833\ude3e\uda32\udfaf\udbcb\udf53",
        8, 83886, 2026267488, 4618239194818413067L, 64291L, true, true, (char) 4152, (char) 54421,
        Double.longBitsToDouble(0x3fc4acfa6e436c6cL), Double.longBitsToDouble(0x3fea77f6ca995258L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:!= |this=org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 11, "\ud8cf\udf75\ud9ae\udc03\ud983\udc52\uda98\udfbe\ud9b4\udfbf\ud984\udcac\udbe1\udd35\udbac\ude7c\ud930\udc52\ud93c\ude22\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\ud8dc\udc64\uda3d\udc3a\udafb\uddc6\ud920\udda6", "\u2072\u8080\u0d84\ubdd2\ubfa0\u54a9\u88cf\ub5ae\u0a76\u6c5a", "\ud860\udd78",
        22, 2395, 994481364, -7735010742883424752L, 32464L, false, true, (char) 20921, (char) 55949,
        Double.longBitsToDouble(0x3fecf42411be30d3L), Double.longBitsToDouble(0x3feb05a6701478c6L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 8, "\ud97d\udf45\uda28\udf5b\ud8a8\udf48\uda99\udc09\ud9b4\udfbf\ud829\udc5f\udb0e\udd9f\udbac\ude7c\udb5e\udc28\ud852\udf70\udbbd\ude52\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud923\udde8\uda54\udce6\ud918\udf09\ud89b\udc31\ud8dc\udc64\udbfb\udcac\udb1e\udce6\ud920\udda6", "\u7285\u9a90\ua392\ub4f7\ua645\u79af\u0209\ub5ae\u21fd", "\ud8ca\udecf\ud860\udd78\udbba\ude53\ud9cb\udcd5",
        14, 83470, 278554128, -1187522680526076436L, 87731L, false, false, (char) 42016, (char) 8849,
        Double.longBitsToDouble(0x3feb05a673ff78c6L), Double.longBitsToDouble(0x3fe45a9c6a04594fL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 4, 11, "\ud8cf\udf75\ud9ae\udc03\ud983\udc52\uda98\udfbe\ud9b4\udfbf\ud984\udcac\udbde\udf34\ud917\udc9f\u0edf\ud807\udc87\udbf7\ude63\ud8a7\udc4e\ud9f0\udf0d\ud9bd\udc34\udb7b\uded9\ua5db\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\uda28\udd73\uda3d\udc3a\udafb\uddc6\ud920\udda6", "\u2072\u7817\ua392\ua759\u67a9\u54a9\u88cf\ub5ae\u0a76", "\ud8ca\udecf\ud860\udd78\ud85a\udce4\udbb8\udd90",
        14, 83470, 278554128, 3284551749452827248L, 87731L, true, false, (char) 42016, (char) 8849,
        Double.longBitsToDouble(0x3fb82d338d36d498L), Double.longBitsToDouble(0x3f9fb7b5181eca80L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 12, 11, "\ud8cf\udf75\ud9ae\udc03\ud94c\udd16\udb8a\udc35\udadb\udcbf\ud972\udc99\ub53c\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\ud8dc\udc64\uda3d\udc3a\udafb\uddc6\ud920\udda6", "\u2072\u8080\ua392\ua759\u554e\u54a9\u88cf\ub5ae\u0a76\u8f34", "\ud860\udd78",
        22, 2395, 994481364, -7735010742883424752L, 32464L, false, true, (char) 20921, (char) 55949,
        Double.longBitsToDouble(0x3fecf42411be30d3L), Double.longBitsToDouble(0x3feb05a6701478c6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=new org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 11, "\ud8cf\udf75\ud9ae\udc03", "\ucb23", "\ud8b2\udf5f\udb45\udf19\ud93c\ude22\udbb8\udf03\ud8af\udd2e\ud82f\udce1\ud93f\udc35\u98de\ud872\udd6b\ud944\udf67\udaa1\udf54\uda6d\udf0e\ud946\uddf7\ud8dc\udc64\uda3d\udc3a\udafb\uddc6\ud920\udda6\uda5e\udc61\uda5e\ude5b\ud8ac\udf82\udb96\udce1\uda0c\udc4e\ud84e\udeb8\ud98c\ude27\udba5\udd08\ud881\udeff\ud8f3\udf69\ud96d\udd26\ud8c1\udec0\ud95c\udc80\ud8ca\udecf\ud9a8\udc7b\ud85a\udcc7\ud90c\udd9a\ud945\udc23",
        11, 96128, 764744298, -1115197877180244126L, 59387L, false, true, (char) 8849, (char) 6191,
        Double.longBitsToDouble(0x3f9478c615b53d20L), Double.longBitsToDouble(0x3fe7aaa95dcb05a8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 11, "\ud886\udd1d", "\u80fa", "\udbe1\udd35\udbac\ude7c\udb5e\udc28\udaca\udf65\ud9e8\udd0b\ud8af\udd2e",
        44, 32654, -2026314248, -7840893094200915338L, -77702L, true, true, (char) 41147, (char) 62457,
        Double.longBitsToDouble(0x3fe5785c5f71785bL), Double.longBitsToDouble(0x3fe0692bc6abfe8bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 0, "\ud814\udc7d\udb7a\udda9\udbc2\udeec\ud8af\ude29\u9808\uda3d\ude75\udbe1\udd35\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\ud9f2\udc1d\udbe4\udfbe\ud88c\udd5d\ud8dc\udc64\uc40a\ud8de\udf5a\ud8d5\udcc9", "\u2072\u6a42\ua392\ua759\ua4b6\u7262\u4fc4\ub5ae\u0a76\u8f34", "\ue072",
        22, 36771, 994481385, -7735010742883424752L, 32464L, false, true, (char) 8853, (char) 38582,
        Double.longBitsToDouble(0x3fc6c56b1256e814L), Double.longBitsToDouble(0x3fd92310d0286ee8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:!= |this=org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 11, "\ud8cf\udf75", "\u6dfa\u31a9\u6394\u1875\u05ff", "\udbbd\ude03\ud8af\udd2e\ud840\ude8b\udbbc\udff5\udb6b\udec0\ud94f\udedc\ud944\udf4e\udaa1\udf54\ud918\ude36\ud8fd\ude21\uda33\ude6e\udbeb\udc31\udafb\uddc6\ud920\udda6\ud809\uddf7\000\ud944\udef3\u3523\uda46\udd44\ud84e\udeb8",
        48, 93613, 247701328, 7079783118457575683L, -73729L, false, true, (char) 32277, (char) 28799,
        Double.longBitsToDouble(0x3fc377f07cf7ade4L), Double.longBitsToDouble(0x3fe118427e06cd8dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:!= |this=org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 7, "\ud8d0\udc13", "\u50e5\u58b5\u8823\u96dd\u05ff", "\udbbd\ude03\udb0d\udeb1\uda7e\udf6a\ud867\udf48\uda01\udc3a\ud8dd\udf16\udb3a\udf49\uda4c\udc2a\ud918\ude84\ud867\udd77\uda33\ude84\udbeb\udc31\udafb\uddc6\ud920\udda6\ud8e6\udc25>\ud944\udef3\ud9b7\udee6\uda31\ude34\ud81a\udf5e",
        9, 8837, -992011642, -9102721425918020349L, -73729L, false, true, (char) 32277, (char) 28799,
        Double.longBitsToDouble(0x3fc377f0731db2c8L), Double.longBitsToDouble(0x3fc6c7637842529cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 12, 11, "\udb1d\udc54\udb38\udfb6\uda57\udcfa\uda98\udfbe\ud9b4\udf49\udbc6\udcad\udbe1\udd35\ud8f6\udce1\ud92e\udd1e\uda48\udf02\udbcf\ude31\udbe0\udd46\udb16\udcea\uda5f\ude5b\udb7b\udeb8\ud94f\udedc\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\ud8dc\udc64", "\u02ab\u7705\u6f54\u201a\u8080\ua392", "\ud878\udf1a\udb3c\udcff",
        23, 57523, -471704616, -7482618052745485842L, -17799L, true, false, (char) 42431, (char) 62459,
        Double.longBitsToDouble(0x3faa062ba6a10020L), Double.longBitsToDouble(0x3fd702d1aec5e10cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 1, "\udb38\udc20\uda72\udf8b\ud982\udfa0\ud8fb\udebf\udb3d\udee2\udb48\ude9f\ud808\udc10\ud8f6\udce1\uda55\udc67", "\ud3d0\u7fd0\u722a\u66b1\u0883\u6aa0\u6217\ucc00", "\ud8ae\udeb8\udb72\uddb4\u38f3\ud89d\udfc0\ud8e6\udcf4\udb7f\uddac\ud815\udf5b\uda46\udd44\ud84e\udeb8\ud805\udd4e\ud9d2\ude81\udb3c\udc82\u7fbb\udb26\udd82\udb54\udf60\uda49\udd7d\ud87b\udd1a\ud97c\udfb7",
        -4, 3960, -1003773143, 889382114037419620L, -28781L, false, true, (char) 44498, (char) 2614,
        Double.longBitsToDouble(0x3fde39a771f05e84L), Double.longBitsToDouble(0x3fc9fc3d48c9ee58L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 12, 11, "\ud887\ude00\ud962\udd93\udb22\udd53\ud898\udf4c\uda02\udc71\udb65\ude72\udbc1\uddf5\ud8a0\udd95\udac7\udd35\udbf8\udf91\udbbd\udecc\udbdc\udcf2\udb16\udca1\uda5f\ude5b\ud9bd\udeb9\ud94f\udedc\ud944\udf4e\udaa1\udf54\uda81\udc7c\ud9e8\uded6\uda6f\ude57", "\uc0f1\u6f43\ub730\u43d4\u1a5d\u1196", "\ud9d2\ude81\udb3c\udc82\ud8a9\udf6d\udb67\udda2\udb52\udc15\ud95c\udc68\u6357\udb6a\udf7c\ud8c6\udc91\ud8a0\udefb\ud977\udc07\u2f9b\ud81c\udea4\ud81a\udf2b\uda0d\udf44\udaea\udcd0\udaaf\udcf0\ud87b\ude0c\uba76\udb63\udc76\u19d5\uda22\udf45\uda08\uddaa\uefa9",
        9, 41353, -1509544029, -1913632451614279429L, -87658L, true, true, (char) 36234, (char) 22010,
        Double.longBitsToDouble(0x3fa79feaf714a740L), Double.longBitsToDouble(0x3fe2a964302677d0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:= |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Integer:2 |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 11, "\ud8cf\udf75\ud9ae\udc03\ud983\udc52\uda98\udfbe\ud9b4\udfbf\ud846\udc4e\udbe1\udd35\udbac\ude7c\udb5e\udc28\uda84\udd25\ud814\udf64\udbe5\ude4a\ud85c\udf42\ud9eb\udc52\ud878\udf5b\ud94f\udf27\ud944\udf4e\udaa1\udf54\ud918\udf09\ud89b\udc31\ud96e\udf10\udb5a\ude88\ud9cd\udc97\udbac\udff7", "\u2072", "\ud958\udc51\ud2c1\ud9d2\ude81\udae6\udc2e\udb39\udce9\udbc9\udf78\u2e62\ud95c\udc80\ud816\uddc3\uda85\udd89\udbcd\udd63\ud9a3\udd66\ud8e4\udc52\uda06\ude62\ud9eb\udc8e\udaa5\udd19\ud9ef\udc86\ud833\ude3e\uda32\udfaf\udbcb\udf53",
        8, 83886, 2026267488, 4618239194818413067L, 64291L, true, true, (char) 4152, (char) 54421,
        Double.longBitsToDouble(0x3fc4acfa6e436c6cL), Double.longBitsToDouble(0x3fea77f6ca995258L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 11, "", "", "\ud9b4\udfbf",
        50, 52561, 1482294600, 6881898836795215406L, -27648L, false, true, (char) 58172, (char) 50271,
        Double.longBitsToDouble(0x3fd91f8634ed265eL), Double.longBitsToDouble(0x3feb9872b8f141ddL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 0, "\ud814\udc7d\udb7a\udda9\udbc2\udeec\ud8af\ude29\u9808\uda3d\ude75\udbe1\udd35\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\u053b\ud947\udcd3\ud944\udf4e\ud9f2\udc1d\uda1e\ude9c\ud88c\udd5d\ud8dc\udc64\uda2a\ude85\uda4f\udd91\ud8d5\udc89", "\u0535\ua8a0\ua392\u1d92\ua4b6", "\ud8f3\udf06\udbbb\udf0c\udaeb\uddb0\ud95c\udc80\ud8ca\udecf\ue072\ud85a\udce4",
        -4, 23561, -1800947530, 1196380870690542186L, -26114L, true, false, (char) 51003, (char) 52180,
        Double.longBitsToDouble(0x3fc2b740a648c434L), Double.longBitsToDouble(0x3f943752203de3e0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 0, "", "\u406b\u5e92\u916d", "\000\000\000\000\000\ud824\udee1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\000\ud809\udca4\udbe4\udfbe\000\000\ud600\ud8de\udeba\ud8d5\udcc9\ud809\uddf7",
        49, -1000, 0, 1618149376L, -100000L, false, false, (char) 0, (char) 39170,
        Double.longBitsToDouble(0x3fdd86600d3e828aL), Double.longBitsToDouble(0x3fdee9828bcf0e5cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:!= |this=org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual:!toString:java.lang.NullPointerException\0121=new org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 0, "\ud81f\udd7d\udb7a\udda9\udbe7\udfec\ud924\udda3\u87fc\uda3d\ude75\udbe1\udd35\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\ud9f2\udc1d\udbe4\udfbe\ud88c\udd5d\ud8dc\udc64\ud93b\udc0e\ud8de\udf5a\ud8d5\udcc9", "\u2072\u6a42\ua3fc\ua759\ua4b6\u7262\u4fc4\ub5ae\u0a76\u8f34", "\ue072",
        53, 23780, -1600310817, 3938206189158143667L, 33917L, false, true, (char) 52885, (char) 40514,
        Double.longBitsToDouble(0x3fc6c56b1256e814L), Double.longBitsToDouble(0x3fd92310d4326ee8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 5, "", "", "\ud9b4\udfbf\ud846\udc4e\udbe1\udd35\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbb0\udd3d\ud9c1\udc08\udbc3\ude12\udb58\udcd9\ud878\ude99\uda56\udd94\udb6e\udf91\udad5\udf0e\udae5\ude4f\ud873\udde4\uda95\udde0\ud843\udedd\ud866\udc53\udb24\udea5\ud934\uddf4\udadc\udd6d\ud83b\ude6b\ud877\udcb0\ud90e\ude1f\ud993\udf39\ud8fe\udfe7\ud800\uddb2\ud812\udd89\ud909\udf14\uda31\uded0\udb1a\ude6c\ud8ad\udef8\udb35\udd27\ufd24\ud8f0\udc87\uda15\udf10",
        45, 32849, 597037383, 4132517493037113525L, -48056L, false, false, (char) 41673, (char) 32710,
        Double.longBitsToDouble(0x3fb800338f74e228L), Double.longBitsToDouble(0x3fdf7399b6de48eaL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 7, 11, "", "", "\ud9b4\udfbf",
        50, 52561, 1482294600, 6881898836795215406L, -27648L, false, true, (char) 58172, (char) 50271,
        Double.longBitsToDouble(0x3fd91f8634ed265eL), Double.longBitsToDouble(0x3feb9872b8f141ddL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=new org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 1, "\udb80\udd8f\u0e44\ud8bf\udc50\uda67\udc84\u358c", "\u4009\u16dc\uab87\u8807\u2908\u2383\u6bb0\u6756\u83f9\u3375\uaa63\u331e\ubeb8\u4c66\u734f\u7d9a\u26f7", "\ud866\udf4e\udb83\udd0c\ud867\udca1\udb93\udfde\udada\udd25\uda5b\udcee\ud9b2\uddf6\ud979\udf80\uda54\udffa",
        28, 54766, -995477284, -6615310883237436488L, -84005L, true, true, (char) 39370, (char) 51491,
        Double.longBitsToDouble(0x3fe7029cab721b04L), Double.longBitsToDouble(0x3fdad08ba8167756L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 2, "", "\u6271\u7777\u1f01", "\uda8b\udcc1\000\000\000\000\ud824\udee1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\000\u7477\u1d47\000\000\ud600\ud8de\udeba\ub45d\udaff\udc84\ud80b\udf39\000\000",
        -5, 27376, 0, 0L, 56279L, false, true, (char) 42980, (char) 47638,
        Double.longBitsToDouble(0x3fc090e5da6d3698L), Double.longBitsToDouble(0x3fee4d8c6dfe1952L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 11, "", "", "\uda14\udf3d",
        50, 52561, 1482294600, 6881898836795215406L, -9494L, false, true, (char) 58172, (char) 50271,
        Double.longBitsToDouble(0x3fd91f8634ed265eL), Double.longBitsToDouble(0x3feb9872b8f141ddL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 11, "", "\u6b76", "\ud833\udf18\udbe1\udd35\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8a2\udf2e\ud8aa\udc46\ud9eb\udc52\ud878\udf5b",
        5, 87372, 1105032080, 6788202205571977574L, -40408L, true, false, (char) 28713, (char) 46970,
        Double.longBitsToDouble(0x3fcf13d307b4e920L), Double.longBitsToDouble(0x3fe5a6668501daa8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 15, 11, "\ud8cf\udf75\ud9ae\udc03\ud983\udc52\uda98\udfbe\ud9b4\udfbf\ud93f\udced\udbe1\udd0a\udbac\ude7c\udb5e\udc28\ud93c\ude22\udbbd\ude03\ud8af\udd2e\ud82f\udce1\ud9bd\udc34\udb7b\uded9\ud94f\udedc\ud944\udf4e\udaa1\udf54\udbba\ude9b\ud89b\udc31\ud8dc\udc64\uda3d\udc3a\udad3\udf74\ud920\udd50", "\u2072\u8080\ua392\ua759\u554e\u54a9\u88cf\ub5ae\u0a76\uc6e8", "\ud860\udc96",
        22, 51612, -1325813099, -7774337048288532976L, 32464L, false, true, (char) 20921, (char) 55949,
        Double.longBitsToDouble(0x3fecf42411be30d3L), Double.longBitsToDouble(0x3feb05a6701478c6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|computeValue|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|equal|java.lang.Object,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|equal|org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationEqual|getSymbol||new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual|getSymbol||new:org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "C|org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual|<init>|org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|contains|java.util.Iterator,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|findMatch|java.util.Iterator,java.util.Iterator|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|getPrecedence||new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|isSymmetric||new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "C|org.apache.commons.jxpath.ri.compiler.CoreOperationEqual|<init>|org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|computeValue|org.apache.commons.jxpath.ri.EvalContext|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|equal|java.lang.Object,java.lang.Object|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationCompare|equal|org.apache.commons.jxpath.ri.EvalContext,org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression|new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationEqual|getSymbol||new:org.apache.commons.jxpath.ri.compiler.CoreOperationEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "M|org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual|getSymbol||new:org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual:org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
    "C|org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual|<init>|org.apache.commons.jxpath.ri.compiler.Expression,org.apache.commons.jxpath.ri.compiler.Expression",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
