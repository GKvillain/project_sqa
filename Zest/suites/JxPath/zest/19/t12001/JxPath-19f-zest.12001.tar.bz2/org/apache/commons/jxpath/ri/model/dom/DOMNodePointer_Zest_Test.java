package org.apache.commons.jxpath.ri.model.dom;
import org.junit.Test;
import static org.junit.Assert.*;
public class DOMNodePointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 3, "\ud971\udcd3\ud825\udccb\udb41\udd92\ud842\udd95\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud80f\udf4f\uda87\uddd4\udad5\ude75\ud953\udf9a\u12a1", "\u6c1e\ubb26\u4377\u3683\u2992\u55b7\u1bd5", "\uda72\udfca\uc870",
        1, 75994, -1626347789, -4976886496585309412L, 870L, true, false, (char) 10977, (char) 8912,
        Double.longBitsToDouble(0x3fd2a40f05c36aa8L), Double.longBitsToDouble(0x3fdfed30b2bc0ad4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 3, "\ud971\udcd3\ud825\udccb\udb41\udd92\ud842\udd95\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud80f\udf4f\uda87\uddd4\udad5\ude75\ud953\udf9a\u12a1", "\u6c1e\ubb26\u4377\u3683\u2992\u55b7\u1bd5", "\uda72\udfca\uc870",
        1, 75994, -1626347789, -4976886496585309412L, 870L, true, false, (char) 10977, (char) 44252,
        Double.longBitsToDouble(0x3fd2a40f05c36aa8L), Double.longBitsToDouble(0x3fdfed30b2bc0ad4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 12, "\ud9c6\udf17\ud825\udccb\udb41\udd92\ud842\udd95\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6", "\ub3a1\ud095\u16d3\ud634\u01d5\uac46\ub693\u6c1e\ubb26\u4377\u3683\u2992\u55b7\u1bd5\u6dd3\u17f9\u7d66\u4875\ua637\uba8f\uac0e\ub23d\u841b\u7507\u1860\u9917\u56b6\u847e\u40aa\ub598\u1069\uc876", "\ud8c5\ude21\ud9ad\udc46\udac3\ude8c\udbf8\udcd2\udaf9\ude1e\ud910\udcce\ud83a\udd8f\ud86f\udc07\u1c5d\u701c\ud9e9\ude16\ud925\udebc\u8572\ud96e\udcf9\ud9c9\ude74\ud8b0\udfba\ud823\udc4e\udb5d\udfd1\ud8fd\udeb7\uda3c\udd14\ud9a1\udeb0",
        9, 63358, -849248575, -7941736311350307124L, -9237L, false, false, (char) 63085, (char) 13193,
        Double.longBitsToDouble(0x3f85df75fac9afc0L), Double.longBitsToDouble(0x3fb29ed2300e0678L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 13, 1, 12, "\ud971\udc64\ud825\udccb\udb41\udd92\uda04\ude9f", "\u0a4d\u705e\u1606\u0342\u900a\uc5ff\ud010", "\udac6\udea1\udb32\udc49\udb3a\ude1f\ud82b\udfca",
        -5, 31628, 1107884390, -6064504464921050295L, 46696L, true, true, (char) 34887, (char) 20804,
        Double.longBitsToDouble(0x3fb035cc3116e198L), Double.longBitsToDouble(0x3fe7981de41a9f0fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 17, "\ud971\udcd3\udb59\udcc5\udb41\udd92\ud842\udd95\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud833\udf41\uda87\uddd4\udad5\ude75\ud953\udf9a\u12a1\ud8a3\ude01", "\ubb26\u4377\u3683", "\udb06\udf39\ud806\udddc",
        4, 8247, 1311173589, -2579673468060783070L, -4794L, false, true, (char) 48148, (char) 27714,
        Double.longBitsToDouble(0x3feff492ca86c05aL), Double.longBitsToDouble(0x3fec3c1a492a40f0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "\000", "\000\000",
        -5, -1000, 0, 0L, -100000L, false, false, (char) 50306, (char) 0,
        Double.longBitsToDouble(0x3fd46e20000001b4L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 9, 3, "\ud971\udcd3\ud825\udccb\udb41\udd92\ud842\udd95\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud80f\udf4f\uda87\uddd4\udad5\ude75\ud953\udf9a\u12a1", "\u6c1e\ubb26\ud261\u3683\u2992\u55b7\u1bd5", "\uda72\udfca\uc870",
        1, 42346, -1626347789, -4977040539882347748L, 870L, true, false, (char) 10977, (char) 73,
        Double.longBitsToDouble(0x3fd2a40f05c36aa8L), Double.longBitsToDouble(0x3fdfed30b2bc0ad4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 1, 18, 9, 9, "\ud971\udcd3\ud825\udccb\udb41\udd92\ud842\udd95\ud9cb\udd74\ud972\udd08\ud964\udfa9\uda0a\udd8c\ud946\udfd6\uda50\ude43\ud84f\udcae\ud80f\udf4f\uda87\uddd4\ud8f9\udda6\ud955\udcd2\u12a1", "\ua46f\ua165\u955e\ub489\u5a2a\ubc7b\u3329", "\uda72\udfca\uc870\udb91\ude89\ud95d\ude5a\uda0c\udd3c\udbfe\udc07\ud8b3\udd31\u8b8a\udbe2\udf18\uda42\udfa1\ud930\udec0\udad0\udf5a\ud9d9\udcc3\udb08\udc3a\udab8\ude4f\ud850\udf91\uda3b\udfc7\udb9d\udef8\udb87\ude5e\ud85c\udf1a\udb53\uddee\uda45\udcde\uda09\udcc8\udaba\udfc7\uda10\udd36\udb9b\udef7\uda5c\udd39",
        50, 36002, 1612625361, -2190838820333892526L, 21890L, true, true, (char) 6323, (char) 54876,
        Double.longBitsToDouble(0x3febeb8a60ecc0d8L), Double.longBitsToDouble(0x3fdf94368a6eaf74L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 8, 6, "\ud971\udcd3\ud825\udccb\udb41\udd92\ud842\udd95", "\u3b79\u47a8\u1606", "\ud80f\udf4f\uda87\uddd4\udad5\ude75\ud953\udf9a\u12a1\ud8a3\ude01\udb13\uddc7\ud826\udf46\udae5\ude91\udabe\ude09\ud851\udf84\ud8f8\udc5c\udbcc\udf7a\udb39\uddbf\ud806\udddc\ud98e\ude2c\uda72\udfca\uc870\udb91\ude89\ud95d\ude5a\ud868\udd4a\udbfe\udc07\u13da\ud987\udf75\ud8a6\ude1e\udb18\udcc6\ud9e6\udf2c\udad0\udf5a\ud9d9\udcc3\udb08\udc3a\udab8\ude4f\ud8ef\udc20",
        49, 11238, 556776200, 85246651335736254L, 3746L, false, true, (char) 47445, (char) 54104,
        Double.longBitsToDouble(0x3fe35578a9e6e0fcL), Double.longBitsToDouble(0x3fd473895aefbd20L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 15, 3, "\ud971\udcd3", "\u3ba1\u0ea7\u4bca\u3b79\u47a8\u1606", "\ud80f\udf4f\uda87\uddd4\udad5\ude75\ud94d\udf16\ud9b4\ude14\ud8a3\ude01\udb13\uddc7\uda0c\udf39\udae5\ude91\udabe\ude09\ud917\udf87\uda88\ude23\udbcc\udf7a\ud8c7\uddc6\ud922\udd6e\ud98e\ude2c\udac7\uddf4\ud9c6\udf7f\ud89b\udff1\u9fa4\uda0c\udea5\ue1e3\ud8b3\udf31\u8b8a\ud8a2\udfcf\udb18\udcc6\ud924\ude8a\udad0\udf5a\ud9d9\udcc3\udb08\udc3a\udab8\ude4f\u4e33",
        -4, 15515, -1115039646, 3620974355315701822L, 30915L, true, false, (char) 15308, (char) 24743,
        Double.longBitsToDouble(0x3fe667507a5d62d3L), Double.longBitsToDouble(0x3fe047a40280302dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 3, "\ud971\udcd3\ud825\udccb\ud89b\uddc0\ud842\udd27\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud80f\udf4f\ud846\ude1f\udad5\udda2\ud953\udf9a\u12a1", "\u6c1e\u6d32\u4e93\u1383\u4e9a\u49b0\u1c84", "\uda72\udfca\uc870",
        1, 75994, -1626347789, -7940943345674083469L, 69338L, true, true, (char) 55833, (char) 2102,
        Double.longBitsToDouble(0x3fdfed30b2bc0ad4L), Double.longBitsToDouble(0x3fecde453fd250fbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 9, 3, "\ud971\udcd3\ud825\udccb\ud8cc\udd18\ud842\udde5\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud80f\udf4f\uda87\uddd4\udad5\ude75\ud953\udf9a\u12a1", "\u6c1e\ubb26\u4377\u3683\u2992\u55b7\u1bd5", "\uda72\udfca\uc870",
        1, 86538, 177148189, -4976886496585309412L, 870L, true, false, (char) 10977, (char) 8912,
        Double.longBitsToDouble(0x3fd2a40f05c36aa8L), Double.longBitsToDouble(0x3fea96985aba397bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 1, 3, "\ud998\ude7c\udb13\ude70\ud903\ude93\ud874\udd89\uda34\udc68\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud96b\udc87\ud834\udd18\ud94a\udf16\ud84e\udc53\ud9ad\udd04\udb3f\ude00\ud953\udf9a\u12a1\ud8a3\ude01\udb13\uddc7\ud826\udf46\udae5\ude91\udabe\ude09\ud975\udd8e\udba0\udecc\uda82\udf1b\ud8c7\uddc6\ud95b\udfd5\ud98e\ude2c\uda72\udfca\uc870", "\u1189", "\udaf3\ude36",
        36, 96095, 1112107654, -1568576371568749753L, -54198L, false, false, (char) 30472, (char) 65162,
        Double.longBitsToDouble(0x3fcda989ede02960L), Double.longBitsToDouble(0x3fe797f8da16f217L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 3, "\ud971\udcd3\ud825\udccb", "\u95a0", "\ud8df\udda0\ud9c2\uddd5\ud99b\ude31\ud925\udfac\ud80f\udf4f\ud9c1\udf11\ud9d5\udf8a\udbcc\udcec\udbff\ude59\ud8a3\ude01\ud99f\uddec\udbdc\udeaf\udae5\udf67\udabe\ude09\ud851\udf84\ud8f8\udc5c\udbcc\udf7a\ud8c7\uddc6\udbfe\uddd8\ud98e\ude2c\uda72\udfca\uc808\udb91\ude89\ud95d\ude5a\uda0c\udd3c\udbfe\udc07\ud8b3\udd31\u8b8a\ud8a6\ude1e\udb18\udcc6\ud9c8\udcd2\uda6d\ude21\ud9db\udc1b\udb08\udc3a\udab8\ude4f\ud94f\udd4f\ud879\uddd1",
        55, 90793, -1348605948, 7026609835387488512L, -13299L, true, true, (char) 9820, (char) 40835,
        Double.longBitsToDouble(0x3fbabd863d2bbe18L), Double.longBitsToDouble(0x3fe826f2c3d14104L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 3, "\ud971\udcd3\ud825\udccb\udb41\udd92\ud842\udd95\uda34\udcdc\udb2d\uddb9\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud973\udf8f\ud925\udfac\ud80f\udf4f\uda87\uddd4\ud8e8\udebf\udba4\udd48\u12a1", "\u6bb5\ubb26\u4377\u3683\u2992\u33da\uc708", "\uda72\udfca\uc870",
        1, 75994, -1626347789, -4976886496585309412L, -6802L, true, false, (char) 10936, (char) 35412,
        Double.longBitsToDouble(0x3fc7fa0deb867df0L), Double.longBitsToDouble(0x3fdfed30b2bc0ad4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 9, 11, "\ud971\udcd3\ud825\udccb\udb41\udd92\ud842\udd95\uda34\udcdc\udb95\udc6d\ud970\udcf8\uda0a\udda7\udaad\udecd\ud974\udc15\ud925\udfac\ud80f\udf4f\uda87\uddd4\udad5\ude75\ud802\udd98\u12a1", "\u6c1e\ubb26\u4377\u3683\u2992\u55b7\u1bd5", "\uda72\udfca\uc870",
        1, 75994, -1626347789, -4976886496585309412L, 870L, true, false, (char) 10977, (char) 8912,
        Double.longBitsToDouble(0x3fd2a40f05c36aa8L), Double.longBitsToDouble(0x3fdfed30b2bc0ad4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 13, 9, 3, "\ud971\udcd3\ud825\udccb\ud9f0\udc1a\udb8c\udea5\uda34\udcdc\ud8f5\udda8\ud965\udc93\ud8a4\udc74\uda4d\udc89\ud98a\udf56", "\u2db3\u1971\u0c31\u3b56", "\ud826\udf46\ud9b0\ude00\udbec\udeb0\ud851\udf84\ud855\udeb5\udbcd\ude7a\ud8c7\uddc6\ud94a\ude0b\ud98e\ude2c\ud8cc\ude2d\udaff\udeb8\udaf0\udceb\ud9c8\ude50",
        40, 14922, -1680567441, -6046609733848762886L, 69338L, false, false, (char) 2581, (char) 44380,
        Double.longBitsToDouble(0x3fdfd860b3f3dab8L), Double.longBitsToDouble(0x3fd549f5bb06898aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 1, 15, "\ud9c6\udf17\ud825\udccb\udb41\udd92\ud892\udc00\uda36\udfac\ud94a\udca8\ud860\udf0a\uda0a\udda7\ud946\udfd6", "\ub3a1\ud095\u16d3\ud634\u01d5\uac46\ub693\u6c1e\ubb26\u4377\u8a24\u2992\u55b7\u1bd5\u8f99\u4ffa\u5a63\u4880\u267a\uba8f\uac0e\ub23d\u841b\u392d\u1860\u9917\u56b6\u847e\ub012\u2976\u0f90\uc876", "\ud8c5\ude21\ud9ad\udc46\udac3\ude8c\udbf8\udcd2\udaf9\ude1e\ud910\udcce\udacf\uddff\ud874\ude69\u1c5d\u701c\ud9e9\ude16\ud925\udebc\u8572\ud8bf\udda1\ud952\udc21\ud8b0\udf42\ud823\udc4e\udb5d\udfd1\ud8fd\udeb7\uda3c\udd14\ud9a1\udeb0",
        9, 63358, -849248575, -7941736311350307124L, -9237L, false, false, (char) 63085, (char) 13193,
        Double.longBitsToDouble(0x3f85df75eab66fc0L), Double.longBitsToDouble(0x3fb29ed2300e0678L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 6, 12, "\ud971\udc64\ud825\udccb\ud82d\udcdd\ud834\udde0", "\u0a4d\u705e\u1606\u0342\u900a\ud0f6\ud04d\u16d3\u6e4b\u31e3\ua14f\uaa68\uc9f6", "\ud940\udf27\ud8dc\udfca\udbc8\udf24\ud92e\udcde\uda3c\udd3e\ud967\udf8a\udba5\uddbd\ud90b\uddbb\udb91\ude23\ud95d\ude5a\ud9d2\udd5e\ud86d\udcc8\ud9c4\udcc8\ud809\ude09\ud96b\udd5c\udb79\udd03\udab6\udf4c\ud86b\udedc\uda92\uded8\u1061\udaa8\udd76\ud98e\udd55\ucace\ue0a8",
        26, 11756, -212259271, -7860159039393271145L, 62464L, false, true, (char) 33274, (char) 24953,
        Double.longBitsToDouble(0x3febe9f288785480L), Double.longBitsToDouble(0x3fac5f7399f05170L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null\012",
        Z.run(T, 2, 15, 13, 12, "\ud971\udc64\ud835\uddd3\udac3\ude59\uad8c", "\u84e2\u705e\u1606\u9998\u4e12\uc5e8\u0dff\u16d3\u6e4b\u317d\ua14f\uaa68\ub467\u50ee", "\ud8f8\udc5c\udbc8\udf24\ud92e\udcde\uda3c\udd3e\ud98f\udc22\udba5\uddbd\ud90b\uddbb\udb91\ude23",
        4, 54211, 1285524506, -4979060687284104191L, -65980L, false, true, (char) 57520, (char) 59602,
        Double.longBitsToDouble(0x3fd15eb7239f4d60L), Double.longBitsToDouble(0x3fee744a0dc8128cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 0, 1, "\ud990\udf4d\ud825\udccb\udb41\udd92\uda04\ude9f\uda48\udcb9\ud96a\ude00\u8070\udb8a\ude5e\ud962\udf74\uda66\udc0e\ud925\udfac\udba2\udebe\uda87\uddec\udad5\ude75\ud925\uddf6\udb9b\udd3b\ud9a4\ude1e\udb3d\udf1f\ud82b\udfca\u4771\ud9d6\udc8e\ud8c9\udd4a\ud8f8\udc5c\ud9d2\udf29\ud92e\udcde\uda3c\udd3e\udbcf\udc22", "\ua5d1\uba8f\uac0e\u4eb7", "\uda9e\udf5a\ud9dc\udda5",
        46, 37524, 11607624, 7510834742199738199L, 97074L, true, true, (char) 36334, (char) 64397,
        Double.longBitsToDouble(0x3fe664b0b5fa44cdL), Double.longBitsToDouble(0x3fd5ff892afd9bacL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 12, "\ud971\udc64\ud8a0\udd12\ud9f0\udc7f", "\ud24f\u81f8\ud23a\u0835\u02fa\u900a\uc9da\ud010\u16d3", "\udb7c\udd8e\u1444\ud815\udeca\udb2e\udc95\ud852\udea7",
        10, 77522, -40090807, 3970685714906889480L, 52089L, true, true, (char) 49520, (char) 59888,
        Double.longBitsToDouble(0x3fe9f80b64f06d2fL), Double.longBitsToDouble(0x3fcf9888e6868214L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 8, "\ud8fe\ude3b\ud97b\udfd7", "\u91a3\u4b56\u0a4d\u705e\u4425\u0342\u900a\uc5ff\ud010\u50eb\u3faa\ua8b4\ua15a\u8a68", "\udab1\udee2\ud8c9\udcfb\ud8f8\udc5c\udbc8\udf24\udb08\udceb\udb87\udc39\udbb2\udd3a\ud820\ude1b\udb8e\udcbf\ud924\udc47\udaea\udc0c\udbd6\udd6f\ud846\udf98\ud892\udef0\ud8b5\udd50\ud8e0\ude9f\udaab\udeab\uc9fa\uda7e\udc0f\u51af",
        6, 38801, -1477771657, -6885776036618343047L, 95620L, false, true, (char) 9235, (char) 65254,
        Double.longBitsToDouble(0x3fd0a74559510d7eL), Double.longBitsToDouble(0x3fee138e0b0afb9eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 10, 17, "\udad8\udd67\udb59\udc66\udb30\udd4a\ud842\udd95", "\ud397\u47a8\u1606", "\ud833\udf41\uda87\uddd4\udb05\udfae\udb2a\uddb9\u1302\ud8ab\ude6d\udb13\uddc7\ud826\udf46\ud94d\udcc4\ud83e\uddd2\ud851\udf84\uda97\udd23\ud99b\ude42\udb06\udf39\uda0d\udf20\ud96a\udf5d\uda72\udfca\ud8cd\udce1\ud823\ude2f\ud95d\ude5a\ub038\udb95\udda3\uea73\u8b8a\ud873\udf6d\udb2b\udf91\ud9cd\udd5e\ud9d9\ude61\udb8d\udf1d\ud970\uddd1\uc114\ud915\udfbc",
        26, 5204, -949528893, -7776395911012288990L, -45596L, false, true, (char) 55697, (char) 15131,
        Double.longBitsToDouble(0x3fef25f032fc1347L), Double.longBitsToDouble(0x3fec00950f1a94e7L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 8, "\ud971\udcd3\udb59\udcac\uda17\udd9d\ud842\udd95\uda34\udcdc\udbbd\udd0f\ud963\udc46\uda62\uddb3\ud946\udfd6\ud95c\udc09\ud908\udfbd\ud9b1\udd8f\uda8e\ude54\udad5\ude75\ud953\udf9a\u12a1\ud8a3\ude01", "\ubb26\u4377\u3972", "\udb06\udf39\ud806\udddc",
        4, 8247, 1311173589, -2579673467557466590L, 74813L, true, true, (char) 9153, (char) 27714,
        Double.longBitsToDouble(0x3feff492cb7c1cd1L), Double.longBitsToDouble(0x3fec3c1a4dfe7391L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 8, 6, "\ud971\udcd3\udb59\udcc5\udb41\udd92\ud842\udd95\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud833\udf41\uda87\uddd4\udae9\udc85\ud953\udf9a\u12a1\ud8a3\ude01", "\ub7b9\u4377\u3683", "\udb06\udf39",
        20, 19719, -938987753, 2511665903091001595L, 94829L, false, true, (char) 10977, (char) 8912,
        Double.longBitsToDouble(0x3fd2a40f05bce470L), Double.longBitsToDouble(0x3fd133a51b9226e2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 3, "\ud971\udcd3\udb59\udcc5\udb41\udd92\ud842\udd95\udabc\udece\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud833\udf41\uda87\uddd4\udad5\ude75\ud959\udf9d\u12a1\ud8a3\ude01", "\u6c91\ub8c5\u3609", "\udb06\udf39\ud806\udddc",
        4, 8247, 1311173589, -2579673466105446622L, -91927L, false, true, (char) 7442, (char) 27714,
        Double.longBitsToDouble(0x3feff492ca86c05aL), Double.longBitsToDouble(0x3fc0f06924a903c0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 15, 9, "\ud981\ude1c\udb59\udcc5\udb41\udd92\ud842\udd95\uda34\udd4b\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud833\udf41\uda87\uddd4\udad5\ude75\ud953\udf9a\u12a1\ud8a3\ude01", "\ubb26", "\ud8e3\uddd2\uda12\udd57\udb06\udf39\uda66\udc12\udab2\udd9d\uda72\udfca\uc870\udb91\ude89\ud95d\ude5a\uda0c\udd3c\udbfe\udc07\ud8b3\udd31\u8b8a",
        0, 74494, -2092340602, 4679415416655288618L, -18344L, true, false, (char) 9606, (char) 61777,
        Double.longBitsToDouble(0x3fda4b7c86fd7c08L), Double.longBitsToDouble(0x3f851930641634c0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 17, "\ud971\udcd3\ua22e\uc50b\uda37\ude0c\ud882\udc46\udb99\ude91\udb3e\udddb\uda0a\udda7\ud946\udfd6\ud974\udc15\ud925\udfac\ud833\udf41\uda87\uddd4\udad5\ude75\ud97e\udc4f\u12a1\ud8a3\ude01", "\ubb26\u4377\u3683", "\udb06\udf39\ud806\udddc",
        4, 8247, 1311173589, -2579673467339362782L, -4794L, false, false, (char) 48148, (char) 27714,
        Double.longBitsToDouble(0x3feff492ce86c05aL), Double.longBitsToDouble(0x3fec3b55d12a40f0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 17, "\ud971\udcd3\udb59\udcc5\udb41\udd92\ud842\udd95\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6\ud9dc\udd55\ud8fa\udc7e\ud833\udf41\uda87\uddd4\udad5\ude75\ud953\udf9a\u12a1\ud8a3\ude01", "\ubb26\u4377\u3683", "\udb06\udf39\ud806\udddc",
        4, 8247, 1311173589, -2579673468060783070L, -4794L, false, true, (char) 48148, (char) 27714,
        Double.longBitsToDouble(0x3feff492cb25e713L), Double.longBitsToDouble(0x3fec3c1a492a40f0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 12, 18, 9, "\ud971\udcd3\udb59\udcc5\udb41\udd92\ud94f\udfa1\ud89e\udd8b\ud94a\udc54\ud8d9\udc20\ud9d0\udf3d\ud950\udcd4\ud974\udc15\ud925\udfac\ud833\udf94\ud96a\udce1\udad5\ude75\ud953\udf9a\u12a1\ud80b\ude14", "\ud757\u4377\u3683", "\udb06\udf39\ud806\udddc",
        4, 75663, 1311173589, -2579673468062019232L, -4794L, false, true, (char) 44132, (char) 45634,
        Double.longBitsToDouble(0x3fc208b4ea192ff4L), Double.longBitsToDouble(0x3fec3c1a492a40f0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 15, 17, "\ud971\udcd3\u75a9\ud9dc\udd48\udb00\udc03\uda34\udd56\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud946\udfd6", "\uca88\ud095\u16d3\ud634\u01d5\u1040\ub693\u5bc4\ubb26\u43e9\u3683\u4e81\u430e\u154a\u6dd3\ua090\ucec1\u4875\ua637\ubfd6\uabdd\ub23d\u84e8\u7507\uce36\u108f\u56b6\u847e\u31d1\ub255\u3515\u3130", "\udac1\udf08",
        32, 70941, -1266010597, -346286567257816936L, -35833L, true, false, (char) 29471, (char) 11595,
        Double.longBitsToDouble(0x3fdbdea2251876daL), Double.longBitsToDouble(0x3fea258ecb4958c8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 13, "\ud9b2\udcf3\ud898\udd21\udb41\udd92\ud842\udd95\uda34\udcdc\udbd1\uddf2\uda56\udf98\udb4e\ude99\ud946\udfd6\ud974\udc15\ud925\udfac\ud833\udf41\uda87\uddd4\udad5\ude75\udb9e\udf5f\ud95f\udcb2\uda90\udd37", "\ubbef\u4377\u3683\u4e81\u430e\u154a\u24f2\u0177\u9bf7\u2419\ua637\uba8f", "\ud8b3\udd31\ud949\ude7c\uda58\udc94\udb2c\udc3d\ud9e6\udf2c\udad0\udf5a\uda41\udf56\udbcc\udf65\ud8e7\ude5c\ud8e1\udca8\ud853\udca2\ud9ba\udd3e\udae2\udc6a\uda09\udf62",
        30, 19852, -305412583, -4450390930189972191L, 27294L, false, true, (char) 45005, (char) 32363,
        Double.longBitsToDouble(0x3fc476bd19e43a78L), Double.longBitsToDouble(0x3fed7643b299aa8aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 17, "\ud971\udcd3\udb59\udcc5\uda10\uddfa\ud8bc\udd49\uda34\udcdc\ud94a\udca8\ud970\udd0c\uda0a\udda7\ud9ce\ude5a\ud974\udc15\ud908\udd93\ud833\udf41\ud8b8\uddcb\ud95e\udd93\ud953\udfbe\u12a1\ud8a3\ude01", "\ubb26\u4377\u3683", "\udb06\udf39\ud806\udddc",
        4, 8247, 1311173589, 7662590705486573090L, -4794L, false, true, (char) 59156, (char) 27714,
        Double.longBitsToDouble(0x3feff492ca86c05aL), Double.longBitsToDouble(0x3feb141a492a40f0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 16, "\ud966\udcf2", "\u5db1\u2af7", "",
        -5, -1000, 0, -7138127344056613201L, -100000L, false, false, (char) 50306, (char) 0,
        Double.longBitsToDouble(0x3fd46e20029525b4L), Double.longBitsToDouble(0x3fc5255acd179748L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 13, 13, 15, "\ud971\udc64\ud8a0\udd12\ud9f0\udc7f", "\ud24f\u81f8\ud23a\ubbc3\u954c\u900a\u786f\u9163\u063b", "\udaff\ude69\u1444\ud815\udeca\udb7e\ude6c\udb05\udf0f",
        10, 77522, -40071852, 3970685714906889480L, 52089L, true, true, (char) 49520, (char) 59888,
        Double.longBitsToDouble(0x3fe9f80cc4f06d2fL), Double.longBitsToDouble(0x3fcf9888e6868214L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 12, "\ud971\udc64\ud8a0\udd12\ud9f0\udc7f\ud906\udc9c\uda29\udd53\udbee\ude7b\ud99b\udcc3\uda20\udcd6\udbd7\udecb\uda65\udfc6\ud925\udfac\ud9a8\udd9b\uda87\udd4f\udad5\ude75\ud83d\udd4f\ud999\udc1f\udb3a\udc0f\u167a\ud815\udeca\udb2e\udc95\ud852\udea7\ud8c9\udd4a\ud8f8\udc5c\udbfb\ude5d\ud8d8\udda2\udb0f\udd90\ud841\udf95\ud8d2\udf8c\udb67\udd52\uda56\udeba\u60f9\ud8b6\ude0d\uda0c\ude67\ud8b5\ude8d\u316b\uda23\uddd0", "\u307c\u2e38\u1524\u8b55\ua69a\u80c2\u699e", "\udac3\udd9f\uda9c\udf9f\udacc\udc07\ud9f1\udf84\uda85\udd1a\ud94b\udd28",
        27, 19731, -657967926, -6409286179589357361L, -22792L, false, true, (char) 28162, (char) 41896,
        Double.longBitsToDouble(0x3fedcd4c3c1fd7cfL), Double.longBitsToDouble(0x3fdf3daaf135792cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 6, "\ud971\udc64\ud8a0\udd12\ud9f0\udc7f", "\u4882\u90a9\u053d\u70fc\ub6be\u9b8c\ua8c4\u25e5\u4e51", "\udb7c\udd8e\ud834\udd9a\ud815\udefa\udb2e\udc95\ud852\udefb",
        10, 77522, -40090807, 3970685714906889480L, 52089L, true, true, (char) 11078, (char) 22768,
        Double.longBitsToDouble(0x3fe9f80b64f06d2fL), Double.longBitsToDouble(0x3fcf9888e6868214L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 13, "\ud95a\udd6a\udaa8\udf3c", "\u91a3\u4b56\u0a4d\u705e\u4425\u0342\u3fc8\uc5ff\ud010\u50eb\u3faa\ua8b4\ua15a\u7668", "\udab1\udee2\ud8c9\udcfb\uda34\udc5e\ud83e\udf66\udb08\udceb\udb87\udc39\udbcf\udda0\ud820\ude1b\udb8e\udcbf\ud924\udc47\udaea\udc0c\udbd6\udd6f\ud847\udd51\uda33\udf71\uda3c\udcf2\uda68\udfb0\udaab\udf13\uc9fa\udbec\udcae\uda75\udd1a\udb4e\udda7\ud88e\udc48\ud82d\udd0d\udbb6\udccc",
        45, 33697, -2017181365, 1079424264734006157L, 71370L, false, false, (char) 26028, (char) 42630,
        Double.longBitsToDouble(0x3fe26ece0fb7945bL), Double.longBitsToDouble(0x3fd98686b4fb6e0eL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 18, 18, 2, "\uda74\ude36\ud97b\udfd7", "\u91a3\u4b56\u4e2b\uccc3\u4425\u0342\u7d75\uc5ff\ud010\u50eb\u3faa\ua8b4\ua15a\u8a68", "\ud83a\udebf\uda8c\uded8\ud86d\udd5d\udb4e\udc82\udb08\udceb\udb87\udc39",
        16, 52407, 1927088635, 3617196794347041358L, -38963L, false, true, (char) 33178, (char) 11277,
        Double.longBitsToDouble(0x3fd798822e5b4fd4L), Double.longBitsToDouble(0x3fd79a070d42aceeL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 8, "\ud971\udcd3\udb59\udcac\uda17\udd9d\ud842\udd95\uda34\udcdc\udbbd\udd0f\ud963\udc46\uda62\uddb3\ud946\udfd6\ud95c\udc09\ud908\udfbd\ud9b1\udd8f\uda8e\ude54\udad5\ude75\ud953\udf9a\u12a1\ud8a3\ude01", "\ubb26\u4377\u0a1b", "\udb06\udf39\ud806\udddc\ud98e\ude2c",
        32, 91589, -600627034, 2431009358332725702L, -27851L, false, false, (char) 27714, (char) 21079,
        Double.longBitsToDouble(0x3febe0e68f878349L), Double.longBitsToDouble(0x3fdfe7391019c0c0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 3, "\ud971\udcd3\uda9d\udca7\udacd\ude97\ud842\udd95\uda34\udcdc\uda09\udfca\udbe5\uddf2", "\u43ca\u0d00\u4496\u6a16\u86d9\u9fcb\u84d5\uac46\u5794\u6c1e\ub7b9\u358a\uc570\ub7e5\u38e1", "\ud98e\ude2c",
        32, 62643, -1323685637, 269281537836902131L, 37485L, false, true, (char) 10977, (char) 8912,
        Double.longBitsToDouble(0x3fd2a40f0bbce470L), Double.longBitsToDouble(0x3fe74337bdc91371L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 15, "\u2371\udacc\ude1c\ud877\uddfd\ud80f\udfd2\udb54\udd8d\udbd1\uddc7\uda56\udf98\u1c97\udb8c\udcfe\uda20\udf9a\udbae\udc32\udb8a\udcbf\ud9ec\ude29\udb4e\uddbe", "\uae71\u22ba\u9191\u7d07h", "\udad2\ude97\uda8a\udeda\ud9e1\udcae\ud91b\udd44\ud904\udff9",
        29, 18854, 364686882, 8220914243467447322L, -45144L, true, true, (char) 54321, (char) 19998,
        Double.longBitsToDouble(0x3fec4e90f52a4080L), Double.longBitsToDouble(0x3fda339eb1665612L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 17, "\ud971\udcd3\udb59\udcc5\uda10\uddfa\ud8bc\udd49\ud91f\udef2\u376e\ud97b\udce0\uda0a\udda7\ud9ce\ude5a\ud998\udf15\ud9e4\udd60\ud825\udce3\ud8b8\uddcb\ud95e\udd93\ud953\udfbe\u12a1\ud8a3\ude01", "\ubb26\u4377\u3683", "\udb06\udf39\ud806\udddc",
        30, 8247, 1311173589, 7662590705486573090L, -4794L, false, false, (char) 32684, (char) 27724,
        Double.longBitsToDouble(0x3feff492ca86c05aL), Double.longBitsToDouble(0x3feb141a492a40f0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 3, "\ud971\udcd3\ud825\udccb\udb41\udd92\ud842\udd95\uda8e\udeca\ud949\udfcc\ud970\udd0c\ud803\udca3\udb0c\udf53\ud973\udf8f\ud925\udfac\ud905\uded7\uda87\udd6b\udad5\ude75\ud953\udf9a\u12a1", "\ua66e\u312b\u0c56\u1300\u70d6\u9425\u1bd5", "\uda72\udfca\ud9b9\uddd4",
        1, 75994, -1626347789, -4976886494897259737L, 870L, true, false, (char) 10977, (char) 8912,
        Double.longBitsToDouble(0x3fd2a40f05c36aa8L), Double.longBitsToDouble(0x3fdfed30b2bc0ad4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getRelativePositionByQName||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|matchesQName|org.w3c.dom.Node|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|getRelativePositionByQName||new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|matchesQName|org.jdom.Element|new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|asPath||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|attributeIterator|org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|childIterator|org.apache.commons.jxpath.ri.compiler.NodeTest,boolean,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|compareChildNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createAttribute|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int,java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equalStrings|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equals|java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|findEnclosingAttribute|org.w3c.dom.Node,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getBaseValue||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getDefaultNamespaceURI||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getRelativePositionByQName||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|matchesQName|org.w3c.dom.Node|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|getRelativePositionByQName||new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|matchesQName|org.jdom.Element|new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
