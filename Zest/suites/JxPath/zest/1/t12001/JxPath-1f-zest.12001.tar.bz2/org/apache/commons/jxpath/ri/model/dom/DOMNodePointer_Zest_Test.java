package org.apache.commons.jxpath.ri.model.dom;
import org.junit.Test;
import static org.junit.Assert.*;
public class DOMNodePointer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 3, 3, 3, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ub90d", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 42445, -12412063, 2206257257139936520L, 36095L, false, false, (char) 38491, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 3, 3, 3, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ub90d", "\u5b44\udba4\udc36\ud818\udc8f\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 42445, -12412063, 2206257257139936520L, 36095L, false, false, (char) 33627, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 3, "\uda9d\udc45\ud833\udc68\udbf3\udfee\ud9cb\ude65\ud97a\udc0e\ud975\udefe\ud996\udd9f\uda82\udcd2", "\uc8b9\ucbd3", "\udb58\udedc\udae2\ude12\udb22\ude97\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 42445, -12412063, -6211814872416297756L, 36095L, false, false, (char) 38491, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 15, 3, "\udaf1\uddaf\ud8cb\ude95\ud947\udeda\ud9cb\ude33\ud98d\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2\ud83f\ude36", "\ub90d", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 42445, -12412063, 2206257257139936520L, 16639L, true, false, (char) 33378, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 11, 3, 3, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ub90d", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 42445, -12412063, 2206257257139936520L, 36095L, false, false, (char) 38491, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 11, 1, "\uda9d\udc45\uda12\udf58\udacb\udc77\ud9cb\ude77\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ub90d", "\ud8a0\udfa1\udba4\udce1\ud870\udc1a",
        11, 73164, 667619953, -7794451139532118051L, 17943L, false, true, (char) 51198, (char) 8055,
        Double.longBitsToDouble(0x3f9018768d453e20L), Double.longBitsToDouble(0x3fbee84d4517da80L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 4, 3, "\ud8c4\udd46\ud833\udc29\uda57\udfcc\ud9cb\ude50\ud97a\udc0e\uda1d\ude91\ud996\ude11\udb58\udd7c", "\u09ff\u852c", "\udbf7\udc43\udba4\udc36\uda65\ude0b\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        49, 42378, -12412063, 2206257258164575240L, -75934L, false, true, (char) 13909, (char) 24027,
        Double.longBitsToDouble(0x3fc45f6a108f1b14L), Double.longBitsToDouble(0x3feb0454451cbd34L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 18, 18, 11, "\udaeb\ude8b\ud868\udce1\u4d7a\ud98a\ude45\ud820\udf08\u2d89\udb51\udf2f\ud89d\udcc1", "\u7064\ub902", "\u5afe\ud819\udf5d\udbe6\udefa\ud83e\udc69\ud922\udcfa\udaa0\ude62",
        57, 40473, 959421281, 2181296977389821192L, 68854L, true, false, (char) 3059, (char) 56927,
        Double.longBitsToDouble(0x3fe9eb54711cbd34L), Double.longBitsToDouble(0x3fec64dd53db4631L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\uda9d\udc45\ud833\udc68\udbf4\udc39\uda54\uddaa\ud979\udfd4\uda2b\ude98\ud996\ude11\uda27\udee4 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 14, 2, "\uda9d\udc45\ud833\udc68\udbf4\udc39\uda54\uddaa\ud979\udfd4\uda2b\ude98\ud996\ude11\uda27\udee4", "\u01fe\ub90d", "\u5b44",
        19, 47261, 1581952048, -8467573635639170210L, 44201L, false, true, (char) 51198, (char) 8055,
        Double.longBitsToDouble(0x3f8230ed1a8a6740L), Double.longBitsToDouble(0x3fbee84d4517da80L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 7, "\ud9b3\udee1\ud640\udbf4\udc39\ud9cb\ude65\ud97a\udc0e", "\u0299\u73e6", "\udbb8\udec4",
        8, 81733, 262470232, 5081715397917298501L, -64311L, true, false, (char) 29708, (char) 53206,
        Double.longBitsToDouble(0x3fa2bb5090b3e390L), Double.longBitsToDouble(0x3fb502f620fcf9c8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=java.lang.String:\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud825\ude17\uda6f\udff5 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 3, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud825\ude17\uda6f\udff5", "\u01fe\ub90d", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 42445, -12412063, 2206257257139936520L, 36095L, false, false, (char) 38491, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 17, "\uda9d\udc1f\ud833\udc68\udbf4\udc39\ud9cb\ude65\udab6\udf2c\udb3a\udd86\uda4c\udd75\uda91\udd6b", "\u7b32\ua029\u415c\u0bfd\u4390\ubfa3\u8792\u440d\u7f5d\ub488\uc334\ub492", "\udaf4\udcbd\udac8\uddbd\u9d10\udb25\ude88\u71ca\udb26\udc02\uda3f\udf6f\uda71\uded1\udb4d\ude56\ud874\udf88\udbd2\udcc4\udb01\udc55\u525f\udbca\udc61\ud8b3\udf89\ud8f9\udc74\udac9\ude5d",
        58, 55208, 33773058, -8361472568665099902L, 55321L, false, false, (char) 5699, (char) 51275,
        Double.longBitsToDouble(0x3fc350726aea3c20L), Double.longBitsToDouble(0x3fee76b7ca28d485L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 15, "\udaa1\udc24\udaac\udd45\udb39\udcb3\ud83d\udc52\udb93\udca1\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\uc876", "\u5b44\udba4\udc36\uda40\ude44\udab9\ude6a",
        20, 67046, -1814787223, 4687305878489308001L, -59658L, true, true, (char) 13533, (char) 58501,
        Double.longBitsToDouble(0x3fba8a7c64c6b9a8L), Double.longBitsToDouble(0x3fd9814845e98f8aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 3, 0, 7, "\000", "\u05c1\u63b8\ub79b\u0a7e\u8996\u738b\u9908\u1887\ub90d\u8410\u2407\u4c20\ud4ac\u0a45\000\000\000\u38fb\u0d18a\000\u8183\000\ub89c\ucc10\000", "\ud93b\udc0d",
        45, 16400, 1164620647, 8876849950455746046L, -52657L, false, false, (char) 49108, (char) 47982,
        Double.longBitsToDouble(0x3febe9b1486ab91eL), Double.longBitsToDouble(0x3fe0754218b4cd72L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 13, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ua50e", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6\ud823\udd09\ud956\udfb2\udb50\udf55\udba9\udd16\udaf4\udcbd\uda98\udc84\ua318\udb25\ude88\udbad\uded3\u6430\udaa3\udd51\ud93b\udc0d\ud917\udf70\udb70\udd2a\udba2\udf56\udb04\udd05\uda86\uddc7\uda03\udf4a\ud806\udfef\udbe6\ude08\ud8fa\uddf7\udb5c\udc89\ud898\ude6d\ud873\udf23\ud844\udc04\ud9d4\udcce\udb07\udc33\udaf0\udc83\udb4c\udd4f",
        47, 67298, -449571626, -7381868629857126149L, -90767L, false, false, (char) 37293, (char) 49830,
        Double.longBitsToDouble(0x3fede83f22b634e8L), Double.longBitsToDouble(0x3fde32ec2422e842L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 11, "\ud9d6\udd82\u63db\udb34\udf77\u683b\uda7f\ude43\udae5\ude96\ud996\ude11\uda82\udcd2\ud83f\ude36\uda12\udc3b\ud8d7\ude0f\udb6f\ude8e\uda89\uddfe\udb0a\uddd9\u5b44\udba4\udc36", "\ubb6c\u31a6", "\ud830\udc8f\ud978\udf29\ud92f\udcf5\ud854\udc6d\u9d10\udb25\ude88\ud8a0\ude6c\ud810\udeb4\udaa3\udd51\ud93b\udc0d\ub01a\ud8be\udf58\uda72\udd28\udbfe\udea2\udb9e\udf34\udab3\udf9a\ud8e0\ude17\udaff\udc33\ud8e7\uddb9\ud94d\uddb9\ud8c2\ude70\udbb6\ude6a\udad6\udcad\udb6a\udd16\uda82\ude68\uda54\ude94\ud8ad\ude2a\ud942\udfd9\ud82f\ude9a\udb3f\udf6a",
        -3, 69563, 1857902797, -8439698957809140893L, 12275L, false, false, (char) 8133, (char) 36590,
        Double.longBitsToDouble(0x3fcf68ac89c774e8L), Double.longBitsToDouble(0x3fe95f53c390c0bbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 4, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ub90d", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 42445, -12412063, 2206257257139936520L, 36095L, false, false, (char) 16038, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 8, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ub90d", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 42445, -12412063, 2206257257139936520L, 36095L, false, false, (char) 38491, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 16, 3, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\000\000\000\000", "\u01fe", "\udb03\udeb4\u5b44\udba4\udc36\000\ud9df\uddda\ud86e\udfb7\000\uda26\udd93",
        3, -1000, 10367817, 31885837205504L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe7a63e2b608ae6L), Double.longBitsToDouble(0x3f9cbd3460dc35a0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 3, "\uda9d\udc45\ud9aa\ude03\ud97d\udfd1\ud880\udfc2\ud8ff\udc10\udb7c\udcfb\ud996\uddc6\uda82\udcd2", "\u01fe\ub90d", "\ud99b\ude95\ud9cc\ude0b\uda6c\udc27\udbda\udf05\ud86f\udc09\ud96f\udfb6\ud823\udd09\ud87a\uddc4\uda7c\udd58\uda42\udd2f",
        34, 72312, 410391455, 3022421192443522154L, 92350L, false, false, (char) 35367, (char) 33029,
        Double.longBitsToDouble(0x3fabba59e222dcb0L), Double.longBitsToDouble(0x3fdc87da2204ddbeL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 10, 13, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ub90d", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 64821, 531420880, 7622056480177659266L, 36095L, false, false, (char) 38491, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3feb04573090615cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 0, "\uda9d\udc45\ud833\udc68\udaa6\udcb2\ud9cc\udfe3\ud979\udfc6\udb9e\udf29\uda47\ude10\udb8e\udfc2", "\uc8ee\u6077", "\udbce\udc1f\ud8d7\udc72\udb9e\udf92\ud9a1\udd20\ud86e\udfb7\ud96f\udfb6",
        27, 71493, -12412063, 2206257257139936520L, 36095L, false, false, (char) 38491, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0bd31f14L), Double.longBitsToDouble(0x3fe8763f362e6d2eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 5, "\ud9fd\udf58\udb9c\udca5\uda3e\udc6a\udacb\udfa9\ud980\udd21\ud91d\uddb2\ud996\ude1d\ud86a\udc46", "\u6965", "\udb03\udef9\ud919\ude05\udba4\udd7e\ud870\udc1a\ud817\udd11\uda96\ude40\udbe1\udf4a\ud91b\ude03",
        24, 1621, 513684752, -6384136113285065777L, 71100L, false, true, (char) 61849, (char) 64320,
        Double.longBitsToDouble(0x3fdcc7d25fccdf56L), Double.longBitsToDouble(0x3fe551e80cc17e71L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 3, 11, 18, "\uda9d\udc45", "\ucaac\u285e\u2e90\u0a21", "\u403b\uda11\udccc\udb4c\udca5\ud971\udf79\udb71\ude31\ud887\ude9c\udba4\udc36\ud870\udc1a\uda0a\uddda\ud9b5\udf25\ud8f2\udd13\ud884\ude8d\udb45\udc52\udb1c\udcdd\uda66\udfc3\udb65\udc66\uda47\uddeb\udba1\udc7e\ud9c0\udf96\udac1\udcda\ud923\udc34\uda16\udd36\ud949\udd34\uda95\udf21\udaf2\udde4\uda82\udf9a\ud9b1\udd2e\udbfe\udeb5\udbbe\udce2\ud92b\udc1d\udb85\udd9c\udb26\uddf6",
        15, 59643, -684899677, 2516353243233785281L, 25994L, false, true, (char) 22245, (char) 28915,
        Double.longBitsToDouble(0x3fe689b0747d371bL), Double.longBitsToDouble(0x3fcfeb4d9b171898L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 16, "\uda9c\udf80\ud833\udc68\udbf3\udfee\ud9cb\ude65\ud97a\udc0e\ud975\udefe\ud996\udd9f\uda82\udcd2\ud83f\ude36\u403b\ud909\udd96\uda23\udebc\ud8db\udc61\udb03\udef9\udb58\udedc\udae2\uddfc\udb22\ude97\uda0a\uddda\ud86e\udfb7\ud96f\udfb6\udab1\udc6f\ud90a\ude3f\ud822\ude07\udb6a\ude39\u310c\udac8\udde9\udbf3\udcce\udb02\udf36\udbad\udf55\ud923\udc34\ud8b3\udcb8", "\u9d6b\u1113\uc1c8\u2b52\u7637\uac9a\u6844\u739e\u6c18\u93a1\u4ec2\u94ed\u7be8", "\udacc\udfab\ud9f0\udd69\udb4c\udde4\ud829\udf5a\udb55\uddfb\uda5e\udfc5\udbb0\udc5f\ud9f2\udf8c\ud9dd\udd57\udb91\udf9f\ud8f5\ude4f\udb83\udf3b\uda68\udd35\uda5d\ude39\ud95b\ude19\ud96e\udd57\uda74\ude8c\ud98b\udc00\udb27\udc1d\udbec\udfea",
        42, 40571, -1055270685, -174109850694004973L, 57036L, true, false, (char) 16965, (char) 24810,
        Double.longBitsToDouble(0x3fd87c7916671452L), Double.longBitsToDouble(0x3fdfaa9d99260ffcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\uda9d\udc45\ud833\udc68\udbf3\udfee\ud9cb\ude65\ud97a\udc0e\ud975\udefe\ud996\udd9f\uda82\udcd2 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.String:\uda9d\udc45\ud833\udc68\udbf3\udfee\ud9cb\ude65\ud97a\udc0e\ud975\udefe\ud996\udd9f\uda82\udcd2 |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 3, "\uda9d\udc45\ud833\udc68\udbf3\udfee\ud9cb\ude65\ud97a\udc0e\ud975\udefe\ud996\udd9f\uda82\udcd2", "\uc8b9\ucbd3", "\udb58\udedc\udae2\ude12\udb22\ude97\uda0a\uddda\udb0f\udeb2\ud96f\udfb6",
        32, 42445, -12412063, -6211814872416297756L, 36095L, false, false, (char) 4290, (char) 19498,
        Double.longBitsToDouble(0x3fc45f704bd31f14L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\012",
        Z.run(T, 2, 16, 2, 12, "\uda9d\udc45\ud833\udc68\udbf3\udfee\ud9cb\ude65\ud97a\udc0e\ud975\udefe\ud996\udd9f\uda82\udcd2", "\u5dc2\u1b71\u3a3d\u2417\u721c\u1c86\u4342\u440d\u47ef\ub488\ucf8e", "\ud9a3\ude34\udbfd\udcd6\udac8\udde9\u9d10\udb25\ude88\udbad\uded3\udb69\uddd5\udaa3\udd51\ud93b\udc0d\ud917\udf70\ud925\udf54\udad9\udc00\ud9d3\udd2b\ud91f\udc0e\ud80b\udc59",
        8, 8064, 1009388597, -209103248739965772L, -85721L, true, true, (char) 5551, (char) 46223,
        Double.longBitsToDouble(0x3fbe17322d400668L), Double.longBitsToDouble(0x3fe6c708f71334d3L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 3, "\udaf1\udcd1", "\uca7a", "\ud992\ude29",
        44, 40504, 1680343636, 4952860656725600333L, -59365L, false, false, (char) 4004, (char) 0,
        Double.longBitsToDouble(0x3fb3188010000000L), Double.longBitsToDouble(0x3fd5e8a7d6d24f96L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 7, 5, "\uda9d\udc45\ud833\udc68\udbf4\udc39\udaa4\udcf3\ud979\udf92\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u38c3\u27e0", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 55940, 1014042386, -710641019289314781L, 36031L, false, false, (char) 38491, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a0b85e314L), Double.longBitsToDouble(0x3fcb115cc072f750L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator:@? |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 0, "", "", "\000",
        -5, 89400, -807796736, 0L, -99923L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e32280428000000L), Double.longBitsToDouble(0x3e3522f000000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 3, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ub90d", "\u5b44\udba4\udc36\ud870\udc1a\uda0a\uddda\ud86e\udfb7\ud96f\udfb6",
        32, 42445, -12412063, 2206257255546101000L, 36095L, false, false, (char) 38491, (char) 23984,
        Double.longBitsToDouble(0x3fc45f6a096d9314L), Double.longBitsToDouble(0x3feb0457301cbd34L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 16, "\ud836\udc85\u1793\udbf4\udc39\ud9b6\udffb\uda56\udd4f", "\u0299\u744f\u9908\u01fe\u4c61\u8410\uc0fd\u9ce2\ubfa3", "\ud86e\udfb7\ud93e\uddb6\udb2d\udf0d\udbbe\udda2\udb50\udf55\udba9\udd16\udaf4\udcbd\udac8\uddbd\u9d10\udb25\ude88\ud911\udd9a\udb93\udf61\ud89f\ude89",
        51, 85560, -1333964772, -7763036418090209042L, -82890L, false, false, (char) 56496, (char) 16779,
        Double.longBitsToDouble(0x3fc25abf8a84f410L), Double.longBitsToDouble(0x3fc008df4d5aed34L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=null |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 1, "\uda9d\udc45\uda12\udf58\ud81f\ude40\ud9cb\ude77\ud97a\udc0e\uda2b\ude98\ud996\ude11\uda82\udcd2", "\u01fe\ub90d", "\ud8a0\udfa1\uda40\ude2f\ud890\udd8e",
        51, 73255, 667619953, -2822477150915063701L, 17943L, false, true, (char) 51198, (char) 8055,
        Double.longBitsToDouble(0x3f9018768d453e20L), Double.longBitsToDouble(0x3fbee84d4517da80L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 15, "\udab3\ude45\uda12\udf58\uda17\udefd\udbe5\udf95\udb25\udf29\ud9a4\udc0f\uda73\udd74\uda82\udcd2", "\u01fe\ub90d", "\ud8a0\udfa1\udba4\udce1\ud870\udc1a\uda0a\uddda\uda2b\ude34\ud937\udd3b\ud823\udd9c\ud956\udfb2\udb42\udf55\udba9\udd16\udaf4\udcbd\udac8\uddbd\u9d10\udb25\ude88\u3d04\udb79\udc5f\ud8c5\udfa8\udaa8\udc3c\ud9cd\udfb8\uda89\ude43\udb62\udedd\ud882\ude54\uda69\udf64\uda5b\ude99\uebfa\ud849\udf2f\ud91f\udd5f\ud93f\ude94",
        35, 27291, -841628907, -1548219024659385468L, -65979L, true, false, (char) 58860, (char) 29981,
        Double.longBitsToDouble(0x3fdb52721eb56132L), Double.longBitsToDouble(0x3f80886426fb0180L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 12, 11, 1, "", "", "\ud97a\udc0e",
        49, 3072, 0, -6289800954146979244L, -14822L, true, false, (char) 3909, (char) 33006,
        Double.longBitsToDouble(0x3fe388532bfc27cbL), Double.longBitsToDouble(0x3f427a8d85043000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 18, "\ud9b3\udee1\u1027\000\u05c1\ud97a\udc0e", "\u0299", "\udbe1\udc93\u284d",
        4, -1000, 262470232, 247643519320064L, -100000L, true, false, (char) 45875, (char) 31269,
        Double.longBitsToDouble(0x3feb0ec55894c042L), Double.longBitsToDouble(0x3fa2bb5090b3e390L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 18, "", "", "\ud845\udc86",
        38, 89400, -807796736, 0L, -84307L, false, false, (char) 67, (char) 0,
        Double.longBitsToDouble(0x3ebd122804280000L), Double.longBitsToDouble(0x3febbcf18f7828caL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 11, 11, 10, "", "", "\ud97a\udc0e",
        49, 3072, 0, -6289800954146979244L, -14822L, true, false, (char) 3909, (char) 33006,
        Double.longBitsToDouble(0x3fe388532bfc27cbL), Double.longBitsToDouble(0x3f427a8d85043000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 11, 11, 10, "", "", "\ud97a\udc0e",
        49, 3072, -905969664, -4888867074135057518L, -14822L, true, false, (char) 3772, (char) 33006,
        Double.longBitsToDouble(0x3fe388532bfc27cbL), Double.longBitsToDouble(0x3f427a8d85043000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 3, 3, 3, "\uda9d\udc45\ud833\udc68\udbf4\udc39\ud9cb\ude65\ud97a\udc0e\uda2b\uddfd\ud996\ude11\000", "\u01fe\ub90d", "\u5b44",
        19, 47261, 1581952076, -8467573635962372096L, 17943L, false, true, (char) 51198, (char) 8055,
        Double.longBitsToDouble(0x3f9018768d453e20L), Double.longBitsToDouble(0x3fbee84d4517da80L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.w3c.dom.Node,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|testNode|org.apache.commons.jxpath.ri.model.NodePointer,java.lang.Object,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|asPath||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|attributeIterator|org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|childIterator|org.apache.commons.jxpath.ri.compiler.NodeTest,boolean,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|compareChildNodePointers|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.model.NodePointer|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createAttribute|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|createChild|org.apache.commons.jxpath.JXPathContext,org.apache.commons.jxpath.ri.QName,int,java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equalStrings|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|equals|java.lang.Object|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|escape|java.lang.String|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getAbstractFactory|org.apache.commons.jxpath.JXPathContext|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|getBaseValue||new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.dom.DOMNodePointer:org.w3c.dom.Node,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMNodePointer|testNode|org.w3c.dom.Node,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|testNode|org.apache.commons.jxpath.ri.compiler.NodeTest|new:org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer:java.lang.Object,java.util.Locale",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer|testNode|org.apache.commons.jxpath.ri.model.NodePointer,java.lang.Object,org.apache.commons.jxpath.ri.compiler.NodeTest|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
