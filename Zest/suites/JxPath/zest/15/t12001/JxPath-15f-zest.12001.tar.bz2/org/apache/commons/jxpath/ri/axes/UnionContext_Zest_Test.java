package org.apache.commons.jxpath.ri.axes;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnionContext_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[]]\0121=new org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[]]\012",
        Z.run(T, 2, 2, 2, 2, "\ud944\udfb2\ud8d8\udde5\ud9af\udd35\ud88b\udec3\udbda\ude3b\udb6f\ude54\udb64\udc69\udbf9\udf8a\udb1b\udf34\udaee\uddae\ud895\udcc0\ud937\udda8\ud818\udd75\ud806\udfe2\uda24\udc1a\udafa\udf27\ud868\udfac\uda5b\udf36\uda07\uded0\uceca\udbd3\udfdb\udae6\ude47\ud939\udf20\u99d1\udb91\udc93\udab2\udcae\uda20\ude56\ud8f0\udcc7\uda27\udf4f", "\u891d\u135d\u9bc2", "\uda55\udefa\u5f74\u3ad1\uda7e\uddc5\udb76\udd6d\ud9ac\udd31",
        4, 50988, 1156843944, -3882731492885251311L, -52146L, true, true, (char) 34551, (char) 60555,
        Double.longBitsToDouble(0x3fdc1bb943724fd6L), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[null, null]]\0121=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[null, null]]\012",
        Z.run(T, 2, 2, 2, 2, "\ud944\udfb2\ud8d8\udde5\udb42\uddab\ud88b\udf3a\udb7b\udd0b\ud80e\ude64\udb64\udcaa\udbf9\udf8a\udb1b\udf34\udaee\uddae\udbcf\ude5c\ud951\udfc5\ud818\udd75\ud9fb\udebc\uda13\udfde\udafa\udf27\ud868\udfac\uda5b\udf36\uda07\uded0\uceca\udbd3\udfdb\udae6\ude47\ud939\udf20\u99d1\udb91\udc93\ud91d\udcb7\uda7c\uddc7\ud8e3\udd2b\ud98c\udd41", "\u891d\u135d\u9bc2\uc73d\u9f95\ua790\u9dee\u477a\u172e\u77ab", "\ud84d\udc07",
        2, 31127, 1616526097, -779676920897059566L, -11099L, true, true, (char) 16145, (char) 37154,
        Double.longBitsToDouble(0x3fe9cd312c73d443L), Double.longBitsToDouble(0x3fef3bfd99b7aa07L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[null, null, null]]\0121=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[null, null, null]]\012",
        Z.run(T, 2, 2, 2, 2, "\ud944\udfb2\ud8d8\ude19\ud9af\udd35\ud88b\udec3\udbda\ude3b\udb6f\ude54\udb64\udc69\udbf9\udf8a\udb1b\udf34\udaee\uddae\ud895\udcc0\ud937\udda8\ud818\udd75\ud806\udfe2\uda24\udc1a\udafa\udf27\ud868\udfac\uda5b\udf36\udbae\udfe4\uceb9\udbd3\udfdb\uda0d\ude3a\ud956\ude81\u4870\udb91\udc93\udab2\udcae\uda20\ude56\ud8f0\udcc7\uda27\udf4f", "\u891d\u135d\u9bc2", "\uda55\udefa\u5f74\u3ad1\uda7e\uddc5\udb76\udd6d\ud8cb\ude01",
        31, 50988, 1156843944, -3882731492885251311L, -52146L, true, true, (char) 34551, (char) 21211,
        Double.longBitsToDouble(0x3fdc186053724fd6L), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 2, "\ud944\udfb2\ud8a5\udcaf\ud9af\udd35\ud88b\udec3\udbda\ude3b\udb6f\ude54\udb64\udc69\udbf9\udf8a\udab4\udcfb\ud9fe\udd86\ud895\udcc0\ud937\udda8\uda86\uddad\udaa5\ude1b\uda24\udc1a\udafa\udf27\ud868\udfac\uda5b\udf36\uda07\uded0\uceca\udbc3\udcdb\udae6\ude47\ud939\udf20\u99d1\udb41\udf8a\udab2\udcae\uda20\ude56\ud8f0\udcc7\uda27\udf4f", "\u891d\ube9f\uabf6", "\uda55\udefa\u5f74\u3ad1\uda7e\uddc5\udb76\udd6d\ud9ac\udd31",
        4, 50988, 1156843944, 2956645984291503146L, -52146L, true, true, (char) 34551, (char) 60555,
        Double.longBitsToDouble(0x3fdc1bb943724fd6L), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context\0121=java.lang.Integer:0 |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 2, "\ud944\udfb2\ud8d8\udde5\ud9af\udd35\ud88b\udec3\udbda\ude3b\udb6f\ude54\udb64\udc69\udbf9\udf8a\udb1b\udf34\udaee\uddae\ud895\udcc0\ud937\udda8\ud818\udd75\ud806\udfe2\uda24\udc1a\udafa\udf27\ud868\udfac\uda5b\udf36\ud844\udfcf\uceca\udbd3\udfdb\udae6\ude47\ud939\udf20\u99d1\udb91\udc93\udab2\udcae\uda20\ude56\ud8f0\udcc7\uda27\udf4f", "\u47ed\u139f\u9bc2", "\uda55\udefa\u5f74\ud8d3\udf93\uda98\udee2\udb76\udd6d\ud9ac\udd31",
        4, 50988, 1156843944, -3882731492885251311L, -76951L, false, false, (char) 52565, (char) 31140,
        Double.longBitsToDouble(0x3fd18c33e6321f78L), Double.longBitsToDouble(0x3fc5b5b0f070b798L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[null]]\0121=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[null]]\012",
        Z.run(T, 2, 2, 2, 2, "\ud944\udfb2\udbf2\udc92\ud9c3\ude9b\ud88b\udec3\udbda\ude3b\udb6f\ude54\udb64\udc69\udbe1\ude8a\udb1b\udf34\udae4\udf09\ud895\udcc0\ud937\udda8\ud818\udd75\ud806\udfe2\uda24\udc1a\udafa\udf27\ud868\udfac\uda51\udc07\udad1\udeec\uf8ff\udbd3\udfdb\ud98d\udf70\ud939\udf12\u99d1\udb91\udc93\udab2\udcae\uda20\ude56\ud8f0\udcc7\uda27\udf4f", "\u891d\u135d\u9bc2", "\uda55\udefa\u5f74\u3ad1\uda7e\uddc5\udb76\udd6d\ud8ec\udef2",
        25, 50988, -1007416920, 8252909480562014993L, -52146L, true, true, (char) 34551, (char) 12526,
        Double.longBitsToDouble(0x3fc92da766e518ccL), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 2, "\udb55\uddae\ud91f\ude89\ud044\uda4f\udf59\udbda\ude25\udb6f\ude54", "\u6356\u272e\u0299\u214c\ub863\u54f3\u1761\uc39a\u74a5\ube3e\u2cce\u683a\u3eed\u1a42\u7133\u1d6a\u93ca\ud3cb\u1b6c", "\udbd1\udfb6\u1820\ud9dc\udcf6\udac7\udd79\udaf7\udc0e\udb4d\udeaa\uda2b\uddff\uda55\udefa",
        14, 90128, 1903457046, -8841488931555989999L, 33030L, false, true, (char) 45846, (char) 34551,
        Double.longBitsToDouble(0x3fb200110e0ddca0L), Double.longBitsToDouble(0x3fdb927eba31867cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException\0121=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 2, "\ud944\udfb2\ud8d8\udde5\ud9af\udd35\ud88b\udec3\udbda\ude3b\udb6f\ude54\udb7c\udddc\udbf9\udf8a\udb1b\udf34\udaee\uddae\ud895\udcc0\ud937\udda8\ud818\udd75\ud8d1\ude47\uda24\udcd2\udafa\udf27\ud868\udfac\uda5b\udf36\uda07\uded0\uceca\udbd3\udfdb\udae6\ude47\ud939\udf20\u99d1\udb91\udc93\udab2\udcae\uda20\ude56\ud8f0\udcc7\uda27\udf4f", "\u891d\u1dcc\u45b1", "\uda55\udefa\u5f74\u3ad1\uda7e\uddc5\udb76\udd6d\ud9ac\udd31",
        5, 6323, 1156862217, -3882731492885251311L, 59726L, true, false, (char) 34395, (char) 60555,
        Double.longBitsToDouble(0x3fdc1bb943724fd6L), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[]]\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 0, 2, "\ud944\udfb2\ud8d8\udde5\ud9af\udd35\ud808\udce2\udbda\ude3b\udb6f\ude54\udb64\udc69\udbf9\udf8a\udb1b\udf34\udaee\uddae\ud895\udcc0\ud937\udda8\ud818\udd75\ud806\udfe2\uda24\udc1a\udafa\udf27\ud868\udfac\uda5b\udf36\uda07\uded0\uceca\udbd3\udfdb\u87c5\udacf\udcc4\u9a6c\udb91\udc93\udab2\udcae\uda20\ude56\ud8f0\udcc7\uda27\udf4f", "\u891d\u135d\u9bc2", "\udbd7\udefb\u5f74\u3ad1\uda7e\uddc5\udb76\udd6d\ud9ac\udd31",
        4, 50988, 1156843944, -3882731492885251311L, -52146L, true, true, (char) 34551, (char) 60555,
        Double.longBitsToDouble(0x3fdc1bb943724fd6L), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[]]\012",
        Z.run(T, 1, 2, 0, 2, "\ud944\udfb2\ud8d8\udde5\ud9af\udd35\ud88b\udec3\udbda\ude3b\udb6f\ude54\udb64\udc69\udbf9\udf8a\udb1b\udf34\udaee\uddae\ud895\udcc0\ud937\udda8\ud818\udd75\ud806\udfe2\uda24\udc1a\udafa\udf27\ud868\udfac\uda5b\udf36\uda07\uded0\uceca\udbd3\udfdb\udae6\ude47\ud939\udf20\u99d1\udb91\udc93\udab2\udcae\uda20\ude56\ud8f0\udcc7\uda27\udf4f", "\u891d\u135d\u9bc2", "\uda55\udefa\u5f74\u3ad1\uda7e\uddc5\uda35\ude14\ud9ac\udd31",
        4, 50988, 1156843944, -3882731492885251311L, -52146L, true, true, (char) 34551, (char) 60555,
        Double.longBitsToDouble(0x3fdc1bb943724fd6L), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[null, null]]\0121=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud944\udfb2\ud8d8\udde5\ud9af\udd35\udb89\udc01\ud90c\udea5\udb6f\ude1e\udb64\udc69\udbf9\udf8a\udb1b\udf34\udaee\udce0\ud895\udcc0\ud908\udfb0\ud80f\ude65\ud806\udfe2\uda24\udc1a\udafa\udf27\ud868\udfac\ud930\udf0c\uda07\uded0\ud982\udca1\udbd3\udfdb\udae6\ude47\ud939\udf20\u99d1\udb91\udc93\udab2\udc32\uda20\ude56\ud8f0\udcc7\uda9b\udd4b", "\u891d\u135d\u9bc2", "\uda55\udefa\u5f74\udb7a\ude14\ud888\udf17\ud9e2\udc85\ud849\ude2b",
        50, 50988, 1156843944, -3882731496391689455L, -76951L, false, false, (char) 52565, (char) 31140,
        Double.longBitsToDouble(0x3fd18c33e6321f78L), Double.longBitsToDouble(0x3fdd43578f835d88L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\ud944\udfb2\udbdb\udfa7\udb97\udf31\udba1\udedf\udb0d\ude48\udb6f\ude45\udb64\udc69\udbf9\udf8a\udb1b\udf34\udaee\uddae\ud895\udcc0\ud937\udda8", "\u1761\uc39a\u33da\u6448\u2cce\u683a\u3eed\u1a42\u7133\u1d6a\u93ca\u8b97\u1b6c\u45e8\u8a97\u2530\ub7eb\u891d\u135d\u9bc2\uc73d\u8135", "\u3ad1\uda7e\uddc5\udb76\udd6d\ud9ac\udd31\u4f5e\ud84d\udc07\ud8e5\uddb8\ud818\udd1a\uda6c\udcbe\udafb\udf55\udb89\udc6d\udb7c\udc9c",
        17, 96912, 669716929, -4377971932482728680L, 89494L, false, false, (char) 34692, (char) 60253,
        Double.longBitsToDouble(0x3febe2e7ab78ef4cL), Double.longBitsToDouble(0x3fef0af3ef41a60dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 2, "\uda92\udc58\ud8d8\uddcd\ud9a2\udc6f\ud83c\udf71\udbfc\udeec\ud9cb\udce1\udafc\udcdd\udbf9\udf8a\ud948\ude5d\ud905\udd91\ud96e\udf5b\ud8b2\udcba\ud818\udd75\ud806\udfe2\udbd3\uddd1\udb5b\udd99\ud99f\udc3a\ud865\udd80\uda07\uded0\ud8be\udd5e\u74e2\udae6\ude19\ud885\udfaa\udb7e\udd4c\udb28\udde0\udba0\udcc1\udb00\udd21\u3f10\uda27\udf4f", "\u891d\u135d\u9bc2\u2f44\u59bb\u8f87\u5e3b\u096e\u6af1\u1ea3\u34f3\uaddf\u2ba4\u189b\u8a60\u7d64\ua175", "\ud871\uddd4\udb1e\uddf0\ud8f0\udd72\ud964\udddb",
        37, 35583, 1754114008, -4958424373087050305L, 51607L, false, true, (char) 17965, (char) 2121,
        Double.longBitsToDouble(0x3fb22fcd0c904940L), Double.longBitsToDouble(0x3fbcc1110e822848L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.IndexOutOfBoundsException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 0, "\ud944\udfb2\ud959\udf06\ud9af\udcb6", "\u4d5f\u38e1\u83c0\u6356\u272e\u0299\u214c\u0198\u3a6f\u474e\u3287\u74a5\u6395\u2cce\u683a\u3eed\u1a42\u7133\u1d6a\u93ca\u8b97\ua9a0\u9c8e\u4ef9\u2530\ub83a\u891d\uc6e9\u6ab1", "\uda55\udefa\uda77\udc4e\u1a0d\uda7e\uddc5\udb76\udd6d\ud9ac\udd31",
        4, 61924, 1156893877, -3882731492885251311L, 90531L, false, true, (char) 34551, (char) 60555,
        Double.longBitsToDouble(0x3fdc1bb943724fd6L), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 2, "\ud944\udfb2\ud8d8\udde5", "\u337e\ubb20\u38e1\u83c0\u6356\u272e\u0299\u214c\u0198\u2d53", "\ud982\ude18\uda4b\udf77\udb9d\udefd\ud803\ude3f\uda09\udf37\udac1\udfb0",
        4, 76660, -1918422191, -3908460505316842293L, -40108L, true, false, (char) 52603, (char) 44529,
        Double.longBitsToDouble(0x3fd9640109ebfc3eL), Double.longBitsToDouble(0x3fd15787dd9603a4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.IndexOutOfBoundsException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 2, "\udb44\udda6\udbd9\udfea\udad9\udff5\u40e2\ud904\udd3b", "\ua06a\u41ca\u26bf\u16c1\u93e7\u8460\u56b7\ub3ad\u3e6e", "\ud94d\uddba\ud966\udd05\udbd3\udfeb\ud8f5\udd6b\ud809\udc87\ud907\udc6d",
        24, -375, -2014239541, -7324147942683460923L, 70054L, true, false, (char) 15782, (char) 42712,
        Double.longBitsToDouble(0x3fe0abc3eecb01ecL), Double.longBitsToDouble(0x3fe05fc89eb542c9L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.NullPointerException\0121=java.lang.Integer:1 |this=org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context\012",
        Z.run(T, 2, 1, 1, 2, "\ud944\udfb2\ud8d8\udde5\udb42\uddab\udb6e\udeec\udb7b\udc8c\ud80e\ude64\udbb1\ude5c\udb2b\udff5\udbac\udc59\udaee\uddae\udbcf\ude5c\ud951\udfc5\ud818\udd75\ud9fb\udebc\uda13\udfde\udafa\udf27\ud868\udfac\uda5b\udf36\uda07\uded0\uceca\udbd3\udfdb\udae6\ude47\ud939\udf20\u99d1\udb91\udc93\ud91d\udcb7\uda7c\uddc7\ud8e3\udd2b\ud98c\udd41", "\u891d\uafdc\uc0f8\u8425\ud1aa\ua75b\u9dee\u477a\u172e\u77ab", "\ud84d\udc07",
        11, 31127, 1616526097, -779676917586770670L, 78185L, false, true, (char) 1878, (char) 31078,
        Double.longBitsToDouble(0x3fee9619f6cd6255L), Double.longBitsToDouble(0x3fe9cd312c73d443L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context\012",
        Z.run(T, 2, 1, 0, 2, "\ud944\udfb2\ud8a5\udcaf\ud9af\udd35\ud88b\udec3\udbda\ude3b\udb6f\ude54\udb64\udc69\udbf9\udf8a\udab4\udcfb\ud996\uded2\ud8a2\udd97\ud937\udda8\uda86\uddad\udaa5\ude1b\uda24\udc1a\udafa\udf27\ud868\udfac\uda5b\udf36\uda07\uded0\uceca\udbc3\udcdb\udae6\ude47\ud939\udf20\u99d1\udb41\udf8a\udab2\udcae\uda20\ude56\ud8f0\udcc7\uda27\udf4f", "\u891d\ube9f\uabf6", "\uda55\udefa\u5f74\u3ad1\uda7e\uddc5\udb76\udd6d\udaa0\udf9b",
        0, 50988, 1156843944, 2956645984291503146L, -52146L, true, true, (char) 64503, (char) 60555,
        Double.longBitsToDouble(0x3fdc1bb943724fd6L), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.UnionContext:!toString:java.lang.IndexOutOfBoundsException\0121=java.lang.Boolean:false |this=org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context\012",
        Z.run(T, 2, 0, 0, 2, "\udb44\udda6\udbd9\udfea\udad9\udff5\u40e2\ud904\udd3b", "\ua06a\u41ca\u26bf\u16c1\u93e7\u8460\u56b7\ub3ad\u3e6e", "\ud94d\uddba\ud966\udd05\udbd3\udfeb\ud8f5\udd6b\ud809\udc87\ud907\udc6d",
        0, -375, -2014239541, -7324147942683460923L, 70054L, true, false, (char) 15782, (char) 42712,
        Double.longBitsToDouble(0x3fe0abc3eecb01ecL), Double.longBitsToDouble(0x3fe05fc89eb542c9L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[]]\0121=new org.apache.commons.jxpath.ri.axes.UnionContext:Empty expression context |a1=[Lorg.apache.commons.jxpath.ri.EvalContext;:[[]]\012",
        Z.run(T, 2, 2, 2, 2, "\ud944\udfb2\ud8d8\udde5\ud9af\udd35\ud88b\udec3\udbda\ude3b\udb6f\ude54\udb64\udc69\udbf9\udf8a\u8b39\000\ud895\udcc0\ud937\udda8\ud818\udd75\ud806\udfe2\uda24\udc1a\udafa\udf27\ud868\udfac\uda5b\udf36\uda07\uded0\uceca\udbd3\udfdb\udae6\ude47\ud939\udf20\u99d1\udb91\udc93\udab2\udcae\uda20\ude56\000\uda27\udf4f", "\u891d\u135d\u9bc2", "\uda55\udefa\u5f74\u3ad1\uda7e\uddc5\udb76\udd6d\ud9ac\udd31",
        4, 50988, 1156843944, -3882731492885251311L, -34464L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e2b927000000000L), Double.longBitsToDouble(0x3fd18c33e6321f78L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.axes.UnionContext|setPosition|int|new:org.apache.commons.jxpath.ri.axes.UnionContext:org.apache.commons.jxpath.ri.EvalContext,[Lorg.apache.commons.jxpath.ri.EvalContext;",
    "M|org.apache.commons.jxpath.ri.axes.UnionContext|getDocumentOrder||new:org.apache.commons.jxpath.ri.axes.UnionContext:org.apache.commons.jxpath.ri.EvalContext,[Lorg.apache.commons.jxpath.ri.EvalContext;",
    "C|org.apache.commons.jxpath.ri.axes.UnionContext|<init>|org.apache.commons.jxpath.ri.EvalContext,[Lorg.apache.commons.jxpath.ri.EvalContext;",
    "M|org.apache.commons.jxpath.ri.axes.UnionContext|setPosition|int|new:org.apache.commons.jxpath.ri.axes.UnionContext:org.apache.commons.jxpath.ri.EvalContext,[Lorg.apache.commons.jxpath.ri.EvalContext;",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
