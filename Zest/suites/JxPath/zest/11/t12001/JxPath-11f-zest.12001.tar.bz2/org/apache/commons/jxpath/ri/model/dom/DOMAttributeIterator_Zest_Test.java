package org.apache.commons.jxpath.ri.model.dom;
import org.junit.Test;
import static org.junit.Assert.*;
public class DOMAttributeIterator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 4, "\uda8d\uddf8\ud87d\udc9e\ud953\udda5", "\uab3d\u38ee\u4c7e\u3afb\u9757\u92b8\u7d8b\u3d26\u7f84\u55c0", "\ud80d\udc53\ud9c5\udd73\ued90\udb75\udf2f",
        42, 17493, -196480647, 6981822356645425939L, -67897L, false, false, (char) 12239, (char) 35365,
        Double.longBitsToDouble(0x3fe224a3e841232dL), Double.longBitsToDouble(0x3fefec4d0b11926cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 4, "\uda60\udfef\ud908\udf83\ud953\udda5", "\uab3d\u38ee\u4c7e\u3afb\u9757\u92b8\u266f", "",
        58, 94752, 23552, 0L, -34464L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fbc7d00189b0720L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 11, "\uda8d\uddf8\ud87d\udc9e\ud953\udda5\udbc0\udcca\uda41\udc73\uda6d\udcbb\uda98\udefd\udae5\uddfc\uda31\udef6", "\u2bcd", "\ud8d3\udd0e\udab6\ude6a\udb54\ude60\ud80d\udc53\ud8d8\udfa4\ued90\udb75\udf2f\ud948\udccb\uda22\udfdc\ud91c\udcc8\ub6f5\udb49\uddac\udb6c\udee0\ud808\udcfb\uda8b\udef2\udbf1\udfe4\u739a\udad6\udc56\ud88f\udf47\udb62\udd87\ud86c\udd74\ud912\uddde\ud82c\udc93\udbf0\udef6\udbe6\udd35\udbdb\udda1\ud873\udf93",
        18, 49432, 800575671, -6653797638132861611L, -90964L, true, true, (char) 7040, (char) 13213,
        Double.longBitsToDouble(0x3fd6da81a797409eL), Double.longBitsToDouble(0x3fe7c31fe6634c8aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 1, "\uda8d\uddf8\ud982\ude95\uda23\uddfb", "\u6f6b\uab77\u78ee\u2756\ube6e\u36fe\u6915\u3d26\u7f84", "\udb4a\udf7a\udb20\udc1c\ud9c5\udd73\ud891\udf9b",
        41, 68995, -1086324433, -843878333788415887L, -10114L, true, false, (char) 15141, (char) 57825,
        Double.longBitsToDouble(0x3fb048cb7fec4d08L), Double.longBitsToDouble(0x3fe5f1d365c52906L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 6, 4, "\uda8d\uddf8\ud87d\udc9e", "\u212d\uab3d\u38ee\u0283", "\udbf5\uddb5\udb9d\uddfc",
        21, 29987, -1122024118, 2394618028827106337L, -78192L, true, false, (char) 10279, (char) 50698,
        Double.longBitsToDouble(0x3fa2c41f9793f120L), Double.longBitsToDouble(0x3fe38fa24b1360e4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 2, 6, 4, "\uda8d\uddf8\ud87d\udc9e\ud953\udda5", "\uab3d\u38ee\u4c7e\u3afb", "\udb9d\uddfc",
        24, 24114, -1122024188, 2394618028827106337L, 23150L, false, true, (char) 10115, (char) 7877,
        Double.longBitsToDouble(0x3fe9be19f8cea426L), Double.longBitsToDouble(0x3fe91a365b13cdeaL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 0, "\uda8d\uddf8\ud87d\udc9e\ud953\udda5\udbbd\udfce\uda41\udc73\uda6d\udcbb\uda98\udefd\udbb3\ude03\ud952\udcfa\uda15\udd9f\udbf5\uddb5\udb9d\uddfc\udb11\ude34\uda69\udfce\ud931\udc08\ud945\ude1b", "\u428a\u6ca2\u1b36", "\ud8fe\udf1c",
        48, 34811, 1613452598, -5406433469759781570L, -41756L, false, true, (char) 8936, (char) 49477,
        Double.longBitsToDouble(0x3fd11926c8bc1fccL), Double.longBitsToDouble(0x3fc93072b49153dcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 11, "\udb08\uddf6\udb4a\udd91\udabc\ude10\uda8c\udf8a\u8364\uda6d\udc58\uda98\udefd\udae5\uddfc\uda31\udef6\uda15\udd9f\udb37\uddff\ud981\udf1c\ud801\udd74\ud965\udd1b\uda3e\udc84\udab6\ude6a", "\u8f0c\u7406\u1b36\ub1eb\u3ae6\u9397\u6a97", "\ud9b4\ude7b\ud899\ude3c\udbf1\udfe4\u739a",
        3, 84020, -1838358513, 7809957607304617889L, -49894L, true, true, (char) 41191, (char) 7091,
        Double.longBitsToDouble(0x3feb080712e07296L), Double.longBitsToDouble(0x3fc6e5643934bedcL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 11, "\uda8d\uddf8\ud87d\udc9e\ud953\udda5\udae2\ude42\udb44\udf59\uda6d\udcbb\uda98\udefd\udae5\uddfc\uda31\udef6", "\u2bcd", "\ud8d3\udd0e\udab6\ude6a\udb54\ude60\ud80d\udc53\ud8d8\udfa4\ued90\udb75\udf2f\ud948\udccb\uda22\udfdc\ud91c\udcc8\ub6f5\udb49\uddac\udb6c\udee0\ud808\udcfb\uda8b\udef2\udbf1\udfe4\u739a\udad6\udc56\ud88f\udf47\udb62\udd87\ud86c\udd74\ud912\uddde\ud82c\udc93\udbf0\udef6\udbe6\udd35\udbdb\udda1\ud873\udf93",
        25, 26588, 800575671, -6653797638132861611L, -90964L, true, true, (char) 7040, (char) 13213,
        Double.longBitsToDouble(0x3fd6da81aca1409eL), Double.longBitsToDouble(0x3fe7c50056634c8aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 11, "\uda8d\uddf8\ud87d\udc9e\ud953\udda5\udbc0\udcca\uda41\udc73\uda6d\udcbb\uda98\udefd\udb25\udd3b\ua6f3", "\u2bcd", "\ud8d3\udd0e\udab6\ude6a\udb54\ude60\ud80d\udc53\ud8d8\udfa4\ued90\udb6c\udc8a\udb50\udcef\uda08\ude6f\udabc\udc38\ub6f5\udb49\uddac\udb6c\udee0\ud808\udcfb\uda8b\udef2\udbf1\udfe4\u739a\udad6\udc56\ud88f\udf47\udb62\udd87\ud86c\udd74\ud912\uddde\ud82c\udc93\ud86e\udf15\udbe6\udd35\udbdb\udda1\ud873\udf93",
        18, 49432, 800575671, -2834745154122681003L, -90964L, true, true, (char) 7040, (char) 13213,
        Double.longBitsToDouble(0x3fd6da81a797409eL), Double.longBitsToDouble(0x3fe7c31fe6634c8aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 2, 0, "\uda83\uddc1\ud9b7\udd1a\ud949\udc61", "\u3ce6\ub47c\u8b6d\ud1d4", "\udb60\udd4d",
        24, 94298, -1122024188, 7173781659687247368L, 38937L, false, true, (char) 10115, (char) 7877,
        Double.longBitsToDouble(0x3fe9be19f8cea426L), Double.longBitsToDouble(0x3fe91a365b13cdeaL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "", "", "\uda41\udc73",
        -3, 89639, -1682629651, -6890403401805879606L, 97010L, false, false, (char) 16192, (char) 45726,
        Double.longBitsToDouble(0x3fa30ff3c21213b0L), Double.longBitsToDouble(0x3fcade9f80000000L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 2, 11, "\udb08\uddf6\udb4a\udd91\udabc\ude10\uda8c\udf8a\u8364\uda6d\udc58\uda98\udefd\udae5\uddfc\uda31\udef6\uda15\udd9f\udb37\uddff\ud981\udf1c\ud801\udd74\ud965\udd1b\uda3e\udc84\ud8dc\udffe", "\u8f0c\u7406\u6152", "\ud91c\udcc8",
        7, 93466, 1088203207, -7635069518483533492L, -23728L, false, true, (char) 57887, (char) 30918,
        Double.longBitsToDouble(0x3fe88c9367a16c62L), Double.longBitsToDouble(0x3fee9cf2044684fbL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 2, 0, "", "", "\uda41\udc73",
        -3, 89639, -1682629651, -6890403401805879606L, 97010L, false, true, (char) 16192, (char) 45726,
        Double.longBitsToDouble(0x3fdb719e77473624L), Double.longBitsToDouble(0x3fe6bd9a1000000bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 4, 0, "\ud8bf\udf41\ud915\udd40\ud953\udd80\uda9c\udccd\uda60\uddbc\ud904\udfbd\udae7\udf0f\udae5\uddfc\uda31\udef6\uda15\udd9f\ud828\udf0f\udb9d\ude36\udb11\udde2\ud965\udd1b\ub913\udb6e\udf8d\ud978\udd50\ud99c\udf1a\ud9c5\udd73\ued90\udb75\udf2f\ud948\udccb\uda23\udc0e\ud91c\udcc8\udb08\udc26\udb53\uddb5\udb6c\udee0\ud917\udec5\u3919\ud9be\udd8c\u739a\udb00\udd0b\ud8ba\udd47\udb62\udd87\ud83f\udf3f\ud8ea\udc7b\ud9b7\udd8f\u4a19\ud863\udefb\ud93a\udde4\udb3b\ude30\udbfd\udeef\ud8da\ude16\ud8a5\ude81\u6018\udb33\udfe9\udb9e\udf92\udb06\udf66", "\u0115\ub115\uba34\u2f31\u3437\ua6bb", "\udb1a\udd00\udb4f\udf65\udbf4\udfc3\ud845\udcd5\ud8e9\udf25\ud921\udc7f\uda35\udffd\uda44\udc70\udb29\udcd5\ud95b\udc12\u1350\uda64\udecd\ud95b\ude94\ud9ea\udf98\udbaa\udcba\uaec0\udab2\udea0\ud9c5\udc6d\udbc2\udf81\uda17\ude1d\ud883\udf68\ud96a\udc16\ud955\uddea\ud922\udecc\ud9f2\udd93\ud805\udd63\ud9be\udefc\ud9a6\udef9\ud9ff\udf61\ud99a\udf62\ud948\udc0c\ud8b7\udd98\uda66\uddbf\ud982\udd3b\ud819\uddd8",
        59, 93641, 313314856, -2926740838024952798L, -86271L, false, true, (char) 38164, (char) 46123,
        Double.longBitsToDouble(0x3fd6fe2c8fae4384L), Double.longBitsToDouble(0x3feeeec53fcb2ff9L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|getAttribute|org.w3c.dom.Element,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "C|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|<init>|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|equalStrings|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|getNodePointer||new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|getPosition||new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|setPosition|int|new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|testAttr|org.w3c.dom.Attr,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "C|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|<init>|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|getNodePointer||new:org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|getPosition||new:org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|setPosition|int|new:org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "M|org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator|getAttribute|org.w3c.dom.Element,org.apache.commons.jxpath.ri.QName|new:org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator:org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
    "C|org.apache.commons.jxpath.ri.model.jdom.JDOMAttributeIterator|<init>|org.apache.commons.jxpath.ri.model.NodePointer,org.apache.commons.jxpath.ri.QName",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
