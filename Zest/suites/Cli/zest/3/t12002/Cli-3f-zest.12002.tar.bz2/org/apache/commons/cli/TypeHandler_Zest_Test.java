package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\ud807\udfd7\ud8ed\udd4b\udb1b\udf4e\012",
        Z.run(T, 1, 7, 2, 3, "\ud807\udfd7\ud8ed\udd4b\udb1b\udf4e", "\u6138", "\ud8cd\ude9b",
        42, -819, -251090918, 8116664662432130994L, -63253L, true, true, (char) 38310, (char) 62102,
        Double.longBitsToDouble(0x3fe1d3b00ab93a78L), Double.longBitsToDouble(0x3fe6630ebf06c85fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 2, 3, "\ud807\udfd7\udae3\udfa6\udb1b\udf4e", "\u6169\u66ed", "\ud949\uddad\uda50\uddbd",
        47, 97258, -1388599374, 5204710908253390405L, -63253L, true, false, (char) 3295, (char) 21526,
        Double.longBitsToDouble(0x3fe2e75042b93a78L), Double.longBitsToDouble(0x3fe6630ebaf8865fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.io.File:\ud8ec\udfd6\ud9a2\udead\ud8d7\ude72\u15b0\ud94b\udc93\ud92d\udfab\uda52\udcf2\u08a0\ud8cd\ude9b\ud923\ude3c\ud97e\udc47\ud8a4\udfdf\ud955\ude25\ud928\uded1\udabb\udd40\ud8d0\udf44\udb24\udc49\udad7\udcb2\udb56\udddf\ud99a\ude33\ud8f6\udf2e\ud837\uddac\ud816\udc7d\udb29\udf84\udb79\udf77\ud8f3\udc55\ud9e9\udd0f\ud9d2\udd25\u40c8\udae6\udf6d\ud807\udd7d\udbf9\udea2\u3f74\uda7e\udfa1\udab4\udedd\ud8f1\udfce\012",
        Z.run(T, 1, 3, 2, 9, "\ud8ec\udfd6\ud9a2\udead\ud8d7\ude72\u15b0\ud94b\udc93\ud92d\udfab\uda52\udcf2\u08a0\ud8cd\ude9b\ud923\ude3c\ud97e\udc47\ud8a4\udfdf\ud955\ude25\ud928\uded1\udabb\udd40\ud8d0\udf44\udb24\udc49\udad7\udcb2\udb56\udddf\ud99a\ude33\ud8f6\udf2e\ud837\uddac\ud816\udc7d\udb29\udf84\udb79\udf77\ud8f3\udc55\ud9e9\udd0f\ud9d2\udd25\u40c8\udae6\udf6d\ud807\udd7d\udbf9\udea2\u3f74\uda7e\udfa1\udab4\udedd\ud8f1\udfce", "\u16ba\u907e\u6c48\u0440\u1826\ub5a2\u5ad3\u1393\u8ac7", "\ud99a\ude1f\udace\udfad\u90ea",
        26, 22978, 1907733756, -4570953948429658347L, 23882L, true, false, (char) 1349, (char) 35625,
        Double.longBitsToDouble(0x3fa2d48d6b206540L), Double.longBitsToDouble(0x3fe2068439625561L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 3, 3, "\ud807\udfd7\ud8ed\udd4b\udb1b\udf4e", "\u242e", "\ud8cd\ude9b\ud949\uddad\uda50\uddbd\ud8a7\udf38\ud955\ude25\ud928\uded1\udabb\udd40\ud8d0\udf44\ud964\udea1\udad7\udcb2\udb56\udddf\ud99a\ude33\ud8f6\udf2e\ud837\uddac\ud816\udc7d\udb29\udf1c\ud9d1\udca3\udb28\udfc3\ud95e\ude5d\udb76\udfcb\udaad\udf44\udae7\udcb9\ud848\uddab\udb2e\ude19\udb17\udd98",
        13, 50098, 1105749855, 422163700034329808L, 58093L, false, true, (char) 50867, (char) 52991,
        Double.longBitsToDouble(0x3fe0a8689b8e5ebeL), Double.longBitsToDouble(0x3fdef0cf888f1b8cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 9, 4, 2, "\ud931\udc7c\ud8ed\udd4b\udb1b\udf4e\udb22\udd1d\ud888\udcde\udbed\udda1\ud9f0\udc13", "\u4c66\uca95\u48ce\u6d92\u7ce1\u14dd\ua61f\u01dd\u08b2", "\udae1\ude4a",
        30, 38129, -933240116, 1081241068937792559L, -33372L, true, true, (char) 32848, (char) 17338,
        Double.longBitsToDouble(0x3fe901effe225e01L), Double.longBitsToDouble(0x3fe8570fa6a57247L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 1, 6, "\ud807\udfd7\ud8ed\udd4b\udb1b\udf4e\uae43\ud965\uded6\udb49\ude10\uda52\udc38\ud88d\udf45\ud8cd\ude9b\ud949\uddad\uda50\uddbd\ud8a7\udf38\udb1f\udf4b\ud928\ude56\udabb\udd40\ud905\ude3e\ua9c8\ud98e\ude88\udb72\udd6e\ud99a\ude33\ud9f6\udf2e\udbad\udcad\ud816\udc7d\udb29\udf84\udb38\udd56\uda2d\udfd2\ud923\udc8c\ud9f9\udf6e\uda06\udeb6\ud813\udfda\ud803\udc4c\ud97b\udd7e\ud93c\ude21\ud802\udf14\ud99e\udebc\uda32\udd63\ub23b\uda74\udcd8\udb1b\udc98\ud873\ude8a\u7262\udb89\uddb1\ud8f8\udf32\udafb\udd33", "\u1329", "\ud84a\udf2f\udbe3\udc90\ud8c7\udc29\ud945\uddda\ud85f\udf8a\ud882\udd60\uda93\udcc1\ud896\udd0a\ud960\udd77\udb11\udf07\udaf6\udd35\uda9a\udfe0\uda80\udeb3\udb9a\udd87\u3499\u4e84\ud96a\udda3\ud8d9\udf6e\u5c46\udaf1\udf44\ud998\uddab\udbbc\udfb7\ud8ee\udf1e\udb14\udcfd",
        41, 94496, 342093209, 1198119659197961574L, 50966L, true, true, (char) 48404, (char) 51209,
        Double.longBitsToDouble(0x3fe2d9a08f38d17cL), Double.longBitsToDouble(0x3f7136c5d5b20180L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 9, 2, 3, "\ud807\udfd7\ud8ed\udd4b\uda2f\uddf7", "\u6138", "\ud8cd\ude9b\ud949\uddad\uda50\uddbd\ud8a7\udf38",
        8, 48626, 1211816191, -3671763809528267673L, -8078L, true, true, (char) 62102, (char) 47163,
        Double.longBitsToDouble(0x3fe5c9d3c2cc61d7L), Double.longBitsToDouble(0x3fe83642fb18e2b3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\ud807\udfd7\ud8ed\udd4b\ud918\udcb0\012",
        Z.run(T, 1, 7, 4, 8, "\ud807\udfd7\ud8ed\udd4b\ud918\udcb0", "\u6138", "\ud8cd\ude9b",
        42, -819, -251090918, 8116664662432130994L, 60938L, false, false, (char) 47163, (char) 25905,
        Double.longBitsToDouble(0x3fe6630ebf06c85fL), Double.longBitsToDouble(0x3fdb20d7182f726eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 2, 3, "\u4bbe\000\udb94\udf2a", "\u6138", "\ud8cd\ude9b",
        42, 29085, 0, 8116664662432130994L, -63253L, true, true, (char) 38310, (char) 62102,
        Double.longBitsToDouble(0x3f3d8055c9d3c000L), Double.longBitsToDouble(0x3fe6630eb800c85fL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 7, "\ud8eb\ude8f", "\uc97b\u7c37\ub2bd\u66ed\u7636*\u1ddf\u5941\ub778\u4d2c\u94c4\ua4e5\u41ef", "\ud8db\udced\ud931\uddd0\uda85\udf22\udac3\udfe5\ud97c\udc00\ud8bb\udec9\ud960\udc8b",
        37, 62239, -945846062, 5904808454238772210L, -93817L, true, false, (char) 5800, (char) 47322,
        Double.longBitsToDouble(0x3fe81f06e2d0a20cL), Double.longBitsToDouble(0x3fd80465b5056b2eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 2, 0, 1, "\ud807\udfd7\ud8ed\udd4b\uda21\uddf0", "\u0b96\ua899\u9f58\u8c7c\ubf62\u6a69\u0e5d\ub502", "\ud8d0\udf29\udbd2\udd4f\ud9a9\udf30\udbb7\udd9b",
        23, 32616, -176668102, 4780571713768402636L, 28380L, false, false, (char) 64432, (char) 14420,
        Double.longBitsToDouble(0x3f9cf72af4ae54c0L), Double.longBitsToDouble(0x3fd174304110da76L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 6, 3, "\ud9cb\udd37\udb51\udd31\udb08\udfff", "\u7a54", "\ud8cd\ude39\udbaf\udc14",
        52, 91132, 1889808244, -5970085689340274433L, 15311L, false, true, (char) 36954, (char) 32921,
        Double.longBitsToDouble(0x3fe1eb9d239c25bcL), Double.longBitsToDouble(0x3fe5c9d3c26454d5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 6, 2, 7, "\ud807\udfd7\ud8ed\udd4b\udb1b\udf4e", "\uba01\u9c41", "\ud8c7\udd6d\uda50\udd3b",
        59, 28811, -1388599374, 9169874193943840325L, -63253L, false, true, (char) 15923, (char) 43230,
        Double.longBitsToDouble(0x3fe05bb00870ea90L), Double.longBitsToDouble(0x3fea4a3dda5346efL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 6, 3, "\ud807\udfd7\ud8ed\udd4b\ue41c", "", "\u08a0",
        45, 89177, 1191182469, 2436629436301312L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e30000008000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 2, 2, 3, "\ud807\udfd7\ud8db\udc4b\udb87\udc23", "\u6138", "",
        26, 99496, 10515845, 2251801703493376L, 86623L, true, false, (char) 35186, (char) 355,
        Double.longBitsToDouble(0x3e132001c0000000L), Double.longBitsToDouble(0x3fad630023a76010L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 0, 0, "", "\uab8a", "\udb49\ude10",
        9, 73387, 528504000, 5866986217289053573L, -87968L, false, true, (char) 34362, (char) 36479,
        Double.longBitsToDouble(0x3fb9f342c3af0f70L), Double.longBitsToDouble(0x3fddfc037b32001cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 8, 6, 4, "\ud807\udfd7\ud8ed\udd4b\udb1b\udf4e", "\u330d", "\ud8cd\ude9b\ud949\uddad",
        16, 96386, 1881579007, -5963988897364256513L, 55545L, true, false, (char) 4631, (char) 38310,
        Double.longBitsToDouble(0x3fc838cb88e9d804L), Double.longBitsToDouble(0x3fe5c9d3c0996158L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 7, "\ud8c9\udfd8\udbfa\uddb2\ud8c4\udca7", "\u4f80\u213c\u834c\u606a\u8e6a\u38da\u0e68\u9a0f\u4044\u408d\u8d71\ubbe3", "\udb9e\udd54",
        25, 56268, 827730617, -1197989609725859015L, -76943L, true, false, (char) 59642, (char) 63973,
        Double.longBitsToDouble(0x3fd68a6b904747fcL), Double.longBitsToDouble(0x3fc13ae91d296460L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 9, 1, 9, "\ud807\udfd7\ud91d\ude84\udb1b\udf67", "\u6138", "\uda68\udf49",
        59, 19931, -329753130, 7396088722052851698L, -65109L, false, true, (char) 13406, (char) 48951,
        Double.longBitsToDouble(0x3fd99000e8758cb8L), Double.longBitsToDouble(0x3fe5a6f9ea865f21L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\000\012",
        Z.run(T, 1, 7, 0, 3, "\000", "\000", "",
        14, 6619, 528504000, 5866986216097871237L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fddfc0000000000L), Double.longBitsToDouble(0x3e31d00000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 2, 3, "\ud807\udfd7", "\u6e44\u56d2\u5aee\ud7a4\u16df\uc215\u11ca\u56e7\u7b15\uadbe\u5d99\u669a\u41e0\u20c4\u3cdc\ud1ef\ua948\u1816\u6786\u1f49\u70de\u281f\u68ae\u11e4\u76cf\u2e7b\u328a\u654d\u8bb4\u8afb\u3156\u7288\u5ca0\ubcbe\u1ba2\u1b84\u7b20\u2f3f\ubabd\u21d6\ub7a1\u525d\u457d\u2bc7\ub8ae", "\uda68\udf3a\udbc4\udc90\ud91c\ude50\udab4\udeb1\ud982\udc70\udb87\udcda\udaf4\udfdb\uda94\udfc9\ud95c\ude1f\ud87c\udde6\udb63\uddd6\ud9a0\udfc0\ud9d9\udd6a\udbb7\ude10\udb37\udd82\udbce\ude7a\uda15\udecb\ud9c2\udee1\ud959\udd08\uda08\udf8b\udb14\ude88\ud971\ude49\udb98\udfec\udba3\udf80\ud8b5\udc8a\udb07\udcb6",
        35, 66300, -2141046472, -265499339465309011L, -92407L, false, true, (char) 29823, (char) 42407,
        Double.longBitsToDouble(0x3fba6522cbe0f4f0L), Double.longBitsToDouble(0x3fecb9394b21810cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 6, 9, "\ud807\udfd7\ud8ed\udd4b\udb1b\udf4e\uae43\ud9d9\udf52\udb49\ude65\uda52\udc38\u08a0\ud8cd\ude9b", "\u0e5d\ub502\u5d99\u669a\u41e0", "\udb56\udddf\ud99a\ude33\ud8f6\udf2e\ud96a\udfaa\ud816\udc7d\udb29\udf84\ud8c0\udc7b",
        52, 24218, -387212755, -9185565243148896402L, -45973L, false, true, (char) 52972, (char) 38688,
        Double.longBitsToDouble(0x3fe404e78a57de62L), Double.longBitsToDouble(0x3fba61e0797fa718L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 0, "\000\udb0f\udc3d\udb1b\udf4e", "\u3734", "",
        45, 89177, 133, 12032L, -100000L, false, false, (char) 35186, (char) 21092,
        Double.longBitsToDouble(0x3eab899000000000L), Double.longBitsToDouble(0x3fad000023a76010L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 2, 3, "\ud807\udfd7\ud9b3\udc0e\udb1b\udfe1\uae43\uda58\udeb1\udb49\ude10\uda52\udc38\u08a0\ud8cd\ude9b\ud949\uddad\uda50\uddbd\ud8a7\udf38\ud955\ude25\ud928\uded1\udabb\udd40\ud8d0\udf44\ud964\udea1\udad7\udcb2\udb56\udddf\ud99a\ude33\ud8f6\udf2e\ud837\uddac\ud816\udc7d\udb29\udf84\udbb2\udcf3\ud9ce\udf8d\ud8b5\uddea\uda78\udef0\ud8cd\udf8b\ud85a\uddd6\ud902\uddb9\u26a5\ud980\udda3\udbd5\udfdc", "\u1b20\u5ae6", "\ud90b\udf49\ud93c\uddb7\ud9dd\udc40\udb88\udc6e\udb48\udf3d\udb25\udff6\ud96d\udd64\udafa\udcf4\udb44\udf1f\ud993\udd60\ud88b\uddd6\ud8a2\udc36\uda4a\ude09\uda68\udf36\ud990\udedf\uda39\udf12\uda51\ude09\ud9b8\udc1f\udaca\ude46\ud961\udf30\ud881\udf9b\ud8de\udc89\ud958\udd7c\udbb1\udd51\ud81d\udc03\udb00\udde5\udba6\ude9c\uda9a\udcc2\u6651\ud9de\udeed\ud938\udd50\ud906\udca5\ud86a\udf30\ud852\udc1a\ud9dc\ude40\ud9f8\udeb8\udb09\udd6a\udbc9\udf9a\ud9df\udc75\ud9d2\udf1d\ud8ed\udcad\ud8a3\udd28\udbce\uddbc\u11e6\udb0d\udd66\u8478",
        25, 22028, 273529090, 2299561270754931382L, -70209L, true, true, (char) 29624, (char) 1579,
        Double.longBitsToDouble(0x3fd7b9220c08e17aL), Double.longBitsToDouble(0x3fc58b1a3cecbe0cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 4, "\ud807\udf48\ud8ed\udd4b\udb1b\udf4e\uae43\uda58\udeb1\u5ae5\ud876\udca1", "\u1961\u6a69", "\ud891\ude7c\udabb\udd40\ud8d0\udf44\ud964\udea1\udad7\udcb2\udb56\udddf\udb13\ude4f\ud8bb\ude76\ud88c\uddf6\uda17\ude2f\ud9f2\udf4f\ud936\udf15",
        3, 50705, -2082034040, -2945689204077149721L, 18386L, false, true, (char) 7499, (char) 44257,
        Double.longBitsToDouble(0x3fcf0df3d5b65b54L), Double.longBitsToDouble(0x3fe9caa5d313f5a8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 2, 3, "\ud807\udfd7\udad7\udfa0\udb1b\udfa7", "\u6138", "\ud8cd\ude9b",
        42, -819, -251088614, 8116664662432130994L, -52453L, true, false, (char) 21092, (char) 13570,
        Double.longBitsToDouble(0x3fd99000e8758cb8L), Double.longBitsToDouble(0x3fe1d3b00ab93a78L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 6, 9, "\000", "", "",
        -5, 59936, 815144387, 2269907397171150848L, -100000L, false, false, (char) 164, (char) 55295,
        Double.longBitsToDouble(0x3ead467cd0000000L), Double.longBitsToDouble(0x3fbd787b8efe01b8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 2, 3, "\ud807\udfd7\udae3\udfa6\udb1b\udf4e", "\u1ebe\ud6dd", "\ud8f2\udf0d\uda50\uddd9\ud926\udd57\uda56\udf4e\ud819\udf73\uda8e\uddfc\ud8d0\udf44\ud96b\udca1\ud99b\udc33",
        52, 50900, 1419699130, 4243748691650226873L, 5746L, false, false, (char) 27202, (char) 29691,
        Double.longBitsToDouble(0x3fee1b208b9befabL), Double.longBitsToDouble(0x3fd04e1c7e2b2c26L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 7, "\ud834\ude79\udae3\udfa6\udb1b\udf4e", "\u9272\u66ed", "\ud893\ude13\ud9ad\ude87",
        47, 97258, -1388599374, 5204710302663001669L, -63253L, true, false, (char) 3295, (char) 21526,
        Double.longBitsToDouble(0x3fe2e75042b93a78L), Double.longBitsToDouble(0x3fe6630ebaf8865fL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\ud807\udfd7\udbf4\ude1d\udb03\udf6c\uae43\uda58\udeb1\ud893\udd76\ud8bd\udef2\udad4\udcab\uda11\udfe3\ud957\udce2\udb89\udc3a\uda0f\ude1b\ud8ac\udf5b\uda45\uddd1\udabb\udd40\ud8d0\udf44\ud964\udea1\udad7\udcb2\udb56\udddf\ud8b5\udc94\ud881\udc4f\ud837\uddac\ud816\udc7d\udb29\udf1c\0121=java.io.File:\ud807\udfd7\udbf4\ude1d\udb03\udf6c\uae43\uda58\udeb1\ud893\udd76\ud8bd\udef2\udad4\udcab\uda11\udfe3\ud957\udce2\udb89\udc3a\uda0f\ude1b\ud8ac\udf5b\uda45\uddd1\udabb\udd40\ud8d0\udf44\ud964\udea1\udad7\udcb2\udb56\udddf\ud8b5\udc94\ud881\udc4f\ud837\uddac\ud816\udc7d\udb29\udf1c\012",
        Z.run(T, 2, 7, 3, 7, "\ud807\udfd7\udbf4\ude1d\udb03\udf6c\uae43\uda58\udeb1\ud893\udd76\ud8bd\udef2\udad4\udcab\uda11\udfe3\ud957\udce2\udb89\udc3a\uda0f\ude1b\ud8ac\udf5b\uda45\uddd1\udabb\udd40\ud8d0\udf44\ud964\udea1\udad7\udcb2\udb56\udddf\ud8b5\udc94\ud881\udc4f\ud837\uddac\ud816\udc7d\udb29\udf1c", "\ub39a\u6c68\u7de0\u9e7b\ucf91\u9d7d\u0906\uac08\u6552\u3d7c\u8297\u9eb8\ub555\u4d66\u6393\u47df\u04c3\ub65f\u0aee\u428e\u07dc", "\udb19\udefc",
        0, 88553, 242262959, -7045210085939571659L, -60589L, true, true, (char) 14212, (char) 20423,
        Double.longBitsToDouble(0x3fd8e6c6104c5194L), Double.longBitsToDouble(0x3fc1477bdd6d6e50L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 9, 9, 3, "\ud807\udfd7\ud8ed\udd4b\udb1b\udf4e", "\u242e", "\ud8cd\ude9b\ud949\uddad\uda50\uddbd\ud860\ude94\udb50\udc9b\ud907\ude11\udabb\udd40\ud8d0\udf44\ud964\udea1\udad7\udcb2\udb56\udd8b\ud99a\ude33\ud8f6\udf2e\ud837\uddac\ud816\udc7d\udb29\udf1c\ud9d1\udca3\udb28\udfc3\ud95e\ude5d\udb76\udfcb\udaad\udf44\udae7\udcb9\ud848\uddab\udb2e\ude19\udb17\udd98",
        13, 50098, 1105749855, 422163700034329808L, 58093L, false, false, (char) 28077, (char) 52991,
        Double.longBitsToDouble(0x3fe0a8689b8e5ebeL), Double.longBitsToDouble(0x3fdef0cf888f1b8cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 0, 8, "\ud8eb\ude8f", "\uc97b", "\u9b44\udbce\udcff\ud87d\ude62\udb45\udc8e\udbf6\udd26\uda53\udd85",
        21, -1000, 3817291, -3671764105881011097L, 28223L, true, true, (char) 23629, (char) 9383,
        Double.longBitsToDouble(0x3fb38716448db7d8L), Double.longBitsToDouble(0x3ec147ca483c0000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 7, "\uda15\udde5", "\uc97b", "\uda52\udc38\udbce\udd53\udbab\udcd9\udb45\udc8e\uda17\udc36\uda53\udd85",
        21, 37454, 1211776843, -3671763745103758233L, 58656L, false, true, (char) 23629, (char) 9383,
        Double.longBitsToDouble(0x3fb38716448db7d8L), Double.longBitsToDouble(0x3fe8334c51f2920fL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 0, "\ud8eb\ude8f\ud837\uddb1\udb2e\udcc0\ud87a\ude6b\ud99f\udcef\uda88\udfed\uda52\udc38\udbce\udd53\ud87d\ude62\udb45\udc8e\udbf6\udd26", "\u94c4\ua4e5\u41ef\u20c4\u8d74\ua5fd\u7686\u2484\ub7d3\u4dc3\u0da7\ua4b8\u2f8a\u353a", "\uda23\udcbf\ud8fc\udd0f\ud8f5\udcb4\ud9e0\udf36\udbd3\udd6d\ud99d\ude23\ud97d\ude31\ud899\ude06\uda39\udd79\ud99d\udef5\ud97d\udd1d\uda8e\udf54\udb68\udf0a\uda70\udf19\udbc6\udeab\ud802\udd1f\udb94\ude16\udb18\uddf7\uda9d\ude29\ud868\udcff\udbef\udd3c\uda91\udd5a\uda55\ude2e",
        24, 73005, 960070670, -2990059015858381360L, 63252L, false, false, (char) 33993, (char) 20452,
        Double.longBitsToDouble(0x3fcf743769470614L), Double.longBitsToDouble(0x3fcf7354c316dfbcL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 0, "\000\udb0f\udc3d\udb1b\udf4e\ud806\ude43\uda3f\udefe\u3734\ud8e9\udff3\ud86a\uded4\ud8cd\ude9b\ud949\uddad\u0085", "\u8de6\000\u41fe\u9f4e\u8c4d\032\u0099\u1816\u13fb\u380c\u6e41\uc962\u0bd4\uc64d\u3dea\u4b14\u1b8d\u1d40\u5158\u9343\ub8b8\u736b\u6723\ubc11\u37dd\u133c\u3ee2\u1c77\uce62\u0c6d\u966b\u9d37\u9e0b\uc07d", "\ue5bb\udad9\udcd4\ud8c4\udd3d\udbea\udd04\udaf3\uddcc\uda21\udedf\ud95d\uddca\u8c65\u97d8\udad4\uddcb\ud858\ude1d",
        13, 53840, -1543158533, -7441729737027484185L, -49803L, true, true, (char) 25746, (char) 29992,
        Double.longBitsToDouble(0x3fb46ce6f9313958L), Double.longBitsToDouble(0x3feccd0694bf8438L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\ud807\udf48\ud9b5\udf70\udb47\udfea\uae43\uda4e\uddab\u5ae5\uda53\ude6b\0121=java.lang.String:\ud807\udf48\ud9b5\udf70\udb47\udfea\uae43\uda4e\uddab\u5ae5\uda53\ude6b\012",
        Z.run(T, 2, 7, 7, 4, "\ud807\udf48\ud9b5\udf70\udb47\udfea\uae43\uda4e\uddab\u5ae5\uda53\ude6b", "\u1961", "\uda4d\udc6e\ud891\ude7c\udabb\udd40\ud8d0\udf44\ud9d1\udc76\ud96e\udf44\udb56\udddf\udb13\ude4f\ud8bb\ude76\ud88c\uddf6\uda17\ude2f\ud9f2\udf4f\ud936\udf15\ud9f1\ude1d\udba6\udcc5\ud8af\udef4\ud8e3\udcde\uda0f\udc06\ud804\udf08\udb32\udf30\ud8f8\udd2d\uda5b\udfd8\udbbd\udd4a",
        28, 55477, -173512903, -9105034816799692133L, 96695L, true, false, (char) 31900, (char) 46652,
        Double.longBitsToDouble(0x3fe707c25d3922a2L), Double.longBitsToDouble(0x3fe2555b26c7f1f0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 2, 3, "\ud807\udfd7\ud8da\udf4c\udb1b\udf4e", "\u3734", "\ud8cd\ude9b",
        42, -867, 0, 52235392253952L, -63253L, true, true, (char) 38310, (char) 62102,
        Double.longBitsToDouble(0x3fe003b00ab93a78L), Double.longBitsToDouble(0x3fe6630ebf06c85fL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 8, 8, 0, "\ud8eb\ude8f", "\u8a4b\u9c0b\ub2bd\u66ed\u7636*\u1ddf\u5941\ub778\u4d2c\u94c4\ua4e5\u41ef", "\ud8db\udced\ud89c\udc46\ud8d6\udfea\udac4\udc1f\ud97c\udc00\ud8bb\udec9\ud960\udc8b",
        37, 62239, -945846062, 5904808454238772210L, 42175L, false, true, (char) 14879, (char) 34492,
        Double.longBitsToDouble(0x3fa152687dca8fe0L), Double.longBitsToDouble(0x3fe81f06e228850cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 1, 0, "\ud8eb\ude8f\ud837\uddb1\udb2e\udcc0\udbf2\udf39\ud943\udc2a\ud9d3\udf72\ud8c3\udfd5\udbce\udd29\ud87d\ude62\udb45\udc8e\udbf6\udd26\ud81f\udd2b\ud8b3\ude68\udb43\udd95\uda94\udf8c\ud8d0\udf53\ud964\udea1\ud8fa\udfe3\ud8db\udced\ud931\uddd0\uda85\udf22\udac3\udfe5\ud97c\udc00\ud8bb\udec9\ud960\udc8b\ud984\ude9f\udb47\ude37\ud9bd\udd7f\ud8f1\udcd5\uda23\udcbf\ud8fc\udd0f\uda16\udd23\ud9f5\ude36\udbd3\udd6d\ud99d\ude23\udbbe\udf51\ud913\udd0b\ud8c6\udee9\uda6e\ude7e\ud99c\ude90\udad3\uddd6\u1637\udb4d\uded2\ud9c4\udeac\ud9cd\uddd9\ud932\udfd6\ud8c0\udc20\udbe7\udc9d\ud890\udc66\ud86b\udceb\udae1\udc9f\ud9d4\ude79\ud935\ude89\udb96\udfe6\uda34\udd82\ud96d\udf3c\ud883\udcb8\ud825\udf3b\ud8d7\udf86\ud9a9\udd1d\ud8e4\udf83\udaf1\udd1d\udbee\udeca\uda1d\udf3a\ud89e\udc9d\ueb04\uda3c\udcac\ud9c9\udd72\ud83a\udd0f\udb61\ude4e\ud82a\udee4\ud8b4\udf4f\udaea\udd56\ud804\udd1c\udbb6\udc1e\ud8b2\udffd\uda70\ude04\ud85d\udc44\uceed\udb97\udc31\u4620\ud839\ude90\udaee\udf0c\ud961\udc92\udaa3\udd31\ud877\ude52\ud939\uded5\ud84f\udf26\uda89\udcb8\ud912\udf3e\ud955\udcbb\udbbc\udc08\udb2c\udf46\ud9a6\uddc4\udb72\uddd8\uda58\udc50\udbdf\udc0f\udaa9\ude7f\uda24\udca7\udbde\udf9f\ud940\udd94\uda8e\udd39\ud9cf\udc48\uda85\udc8f\uda11\udd2b", "\u2db8\u4ef6\u1aa6\u4629\u1a47\u5b8a\u5947\u95d3\ub19a\u7ec7\u5be5\u1be7\ud40d\ud416\u1d49\u632a\u3bcd\u29ea\u2b60\u62f1\u7ee3\u88c4\u13eb\u71c5\u305d\u9606\u5f9e\u8924", "\ud995\udd3f\ud8a8\udf4a\ud993\udde5\ud9ba\udf13\ud9f0\udeb9\udb99\udebc\ud871\ude7e\ud9cd\udf5e\u686c\uda4c\udccc\ud857\udd00\udb31\udfd4\uf895\uda63\udff8\ud98c\udde2",
        50, 42070, -644605839, -3317428411209175612L, -55261L, false, true, (char) 920, (char) 16238,
        Double.longBitsToDouble(0x3fd79bde23f11f38L), Double.longBitsToDouble(0x3fe297b0b42f0bcfL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 1, 0, "\ud8eb\ude8f\ud837\uddb1\udb2e\udcc0\udbf2\udf39\ud943\udc2a\ud9d3\udf72\ud8c3\udfd5\ud85f\ude92\udbcd\udf55\ud81f\udfc7\u3372\ud922\udf6a\ud8b7\udf36\udb43\udd95\uda94\udf8c\ud8d0\udf53\ud964\udea1\ud8fa\udfe3\ud8db\udced\ud931\uddd0\uda85\udf22\udac3\udfe5\ud97c\udc00\ud8bb\udec9\ud960\udc8b\ud984\ude9f\udb47\ude37\ud9bd\udd7f\ud8f1\udcd5\uda22\udfd1\ud8fc\udd0f\uda16\udd23\ud9f5\ude36\udbd3\udd6d\ud99d\ude23\udbbe\udf51\ud913\udd0b\ud8c6\udee9\uda6e\ude7e\ud99c\ude90\udad3\uddd6\u1637\udb4d\uded2\ud9c4\udeac\ud9cd\uddd9\ud932\udfd6\udaa2\uded2\u0818\ud890\udc66\ud86b\udceb\udae1\udc9f\ud9d4\ude79\ud935\ude89\udb96\udfe6\ud834\udc82\ud8dc\udd19\ud883\udcb8\ud825\udf3b\ud8d7\udf86\ud9a9\udd1d\ud8e4\udf83\udaf1\udd1d\udbee\udeca\uda1d\udf3a\ud89e\udc9d\ueb04\uda3c\udcac\ud9c9\udd72\ud83a\udd0f\udb61\ude4e\ud82a\udee4\ud8b4\udf4f\udaea\udd56\ud804\udd1c\udbb6\udc1e\ud8b2\udffd\uda70\ude04\ud85d\udc44\uceed\udb97\udc31\u4620\ud839\ude90\udaee\udf0c\ud961\udc92\ud86b\udfff\ud892\udf2b\udbf4\udfa4\ud939\ude9a\uda89\udcb8\ud912\udf3e\ud955\udcbb\udbbc\udc08\udb2c\udf46\ud97c\uddcf\udb72\uddd8\uda58\udc50\udbdf\udc0f\udaa9\ude7f\uda24\udca7\udbde\udf9f\ud940\udd94\udb16\uddfd\ud9cf\udc48\uda85\udc8f\uda11\udd2b", "\u2db8\u4ef6\u1aa6\u4629\u1a47\u5b8a\u5947\u95d3\ub19a\u7ec7\u5be5\u1be7\ud40d\ud416\u1d49\uc252\u3bcd\u29ea\u2f7a\u6287\u7ee3\u88c4\u13eb\u163e\u0a8d\u9606\u5f9e\u8924", "\ud995\udd3f\ud8a8\udf4a\udb71\udcd3\ud9d2\udd34\ud9f0\udeb9\udb99\udebc\ud871\ude7e\ud9cd\udf5e\u686c\uda4c\udccc\ud857\udd00\udb31\udfd4\uf895\uda63\udff8\ud98c\udde2\ud9fd\udfc1\udb17\udfab\ud93f\ude2d\ud99b\uddb9\uda66\udde1\ud88d\udc0a\ud9a0\udd5d\ud939\udc01\uda09\udf3f\udbcd\udcf6\ud9ac\ude9f\ud9c4\udd62\ud899\udf04\uda94\udd48\udbe8\ude60\ud9be\ude14",
        8, 59255, 1405544836, 1961218521689077025L, -79148L, false, false, (char) 33846, (char) 23644,
        Double.longBitsToDouble(0x3fb1399d330ad948L), Double.longBitsToDouble(0x3fdc22a392e58f42L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 9, 9, 9, "\ud9ae\udceb\ud99c\udce0\udafb\udcf4\udb07\udff1\ud9d9\udf52\u1e05\ud9c4\ude30\u08a0\u9597", "\u0e5d\ub502\u5d99\ud5da\u4246", "\udb56\udddf\ud99a\ude33\ud8f6\udf2e\ud96a\udfaa\ud816\udc7d\udb29\udf84\ud8c0\udc7b",
        52, 24218, -387212755, -9185565243148896402L, -1312L, true, false, (char) 48106, (char) 17427,
        Double.longBitsToDouble(0x3fb6e89ae60abc28L), Double.longBitsToDouble(0x3fe290890e1a6782L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.TypeHandler|createNumber|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createClass|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createDate|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFile|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFiles|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createObject|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createURL|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
    "C|org.apache.commons.cli.TypeHandler|<init>|",
    "M|org.apache.commons.cli.TypeHandler|createNumber|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
