package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 3, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3\u71e2\u1374\u9bc6\ua617\u88db\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\u949e\ucf83\ub0d5\u067e\u4835\ucf1f\u221c\u179f\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        13, 43023, 1229162084, 8224975238497588711L, 99362L, true, true, (char) 52682, (char) 30982,
        Double.longBitsToDouble(0x3fe4df5f12dd99b8L), Double.longBitsToDouble(0x3fed5675fdddf8beL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 3, 1, "\ud9ba\udd3f\uda8f\udedd\uda15\ude2e\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\uda1d\udd68\ud9c2\udcd4\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\udbd1\uddbc\udb26\udfdc\udabb\ude13", "\ua76c\u378f\u71e2\u1374\u9bc6\ua617\u4961\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\u949e\ucf83\u41f4\u93f1\u4835\ucf1f\ub247\u179f\u091a", "\uda2d\udd5a\udb1a\udc24\udb1c\udd55",
        35, 43023, 1229162084, 8224975238497588711L, 99362L, true, true, (char) 52682, (char) 30982,
        Double.longBitsToDouble(0x3fe4df5f12dd99b8L), Double.longBitsToDouble(0x3fed5675fdddf8beL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 3, 1, "\uda64\ude83", "\u297e\u48be\u798d\u43e3\u3db6\u5357", "\ud8e9\udcdd\udac0\udeba\udb6a\udef4\ud9c7\udc31",
        21, 23864, -1614977976, 6977794483833211836L, -98145L, true, true, (char) 34662, (char) 8817,
        Double.longBitsToDouble(0x3fc9ba0c4dabbf70L), Double.longBitsToDouble(0x3fd848a9b2bf8778L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 4, 1, "\ud9ba\udd3f\udab7\udcdc\ud924\ude52\ud86f\udfcd\uda42\ude08\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\udb90\udd72\u0bdf\ud898\udebe\ud9a5\udc32\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\udb40\udf5a\udacb\udd4b\udabb\ude5f", "\u091d\ud0b5\u71e2\u1374\u9bc6\ua617\u88db\u65f7\u4617\u1dd1\ua68e\ud343\ua6ca\u3d44\u5691\ucf83\ub0d5\u067e\u4835\ucf1f\u221c\u179f\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        13, 43023, 1229162084, 8224975238497588711L, 99362L, true, true, (char) 52682, (char) 30982,
        Double.longBitsToDouble(0x3fe4df5f12dd99b8L), Double.longBitsToDouble(0x3fdd355b6bbbf036L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 0, 0, "\udbd2\udd35", "\u297e\u48be\u798d", "\ud9f3\udfaa\uf4d1",
        -5, 77952, 5, 1495928519262208L, -32576L, false, false, (char) 47834, (char) 24790,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e1835f3a0000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=null\012",
        Z.run(T, 2, 9, 1, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\ud8b7\uddbb\ud9d2\udeda\ud8e5\udf6f\ud9e3\udddd\ud9fb\udc17\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\uda33\ude98\ud9c7\udc15\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3\u71e2\u1374\ud57b\u46ad\u43c5\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\uc0a5\u5066\ub0d5\u067e\u4835\u2803\u6efc\u179f\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        13, 43023, 1229162084, 8224975238497588711L, 99362L, true, true, (char) 52682, (char) 31186,
        Double.longBitsToDouble(0x3fe4df5f12dd99b8L), Double.longBitsToDouble(0x3fed5675fdddf8beL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 7, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udaf1\udd2c\ud875\ude6a\uda9b\udcae\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\udaff\ude9b\ud8ec\ude8e\ud96a\udf0f\udb75\udcdf\udabb\ude13\ud8e6\udf99\ud940\udc01\uda34\udc51\ud820\udd84\uda6d\udf83\udb5d\udcbb\ud9d8\udc79", "\u65f7\ua792\u3406\u1cb0\ud343\ua6ca\u3d44\u949e\ucf83\ub0d5\u067e\u4835\ucf1f\u221c\u179f\u091a\u3e1d\u4b5d\u7a8e\u6502\uc5c8\u7916\ua12a\u2539\uc2af\u663c", "\uda61\udd9e\ud8af\udd28\uda18\udddc\udbd3\udc93\udbb1\udff5\ud9ed\udf3c\udbb8\udfbf\ud8cc\udf04",
        35, 75666, -1571260218, 6011405055625028955L, 83134L, false, false, (char) 14026, (char) 32903,
        Double.longBitsToDouble(0x3fd14eb004e16bc6L), Double.longBitsToDouble(0x3fe5da2b6f616be4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 3, 8, "\ud9ba\udd3f\udab7\udcdc\udaff\udf28\ud861\udfd2\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ud849\udd20\ud844\ude60\udb22\udcf2\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3\u71e2\u1374\u9bc6\ua5b6\u88db\u65f7\u4617\u3406\u39d7\u36d8\ua6ca\u3d44\u949e\ucf83\u5d76\ub96b\u4835\u1868\u28be\u48e8\ua1d9", "\ud9fc\udc6d\udb1a\udc24\ud80d\ude79\ud9a0\udfe9\uda84\udde6\ud906\udeb5\ud221\ud98c\udf22\udaaf\ude91\ud842\udcc7\uda61\udd9e\ud8af\udd28\uda18\udddc\udbd3\udc93",
        29, 47218, 1339409885, 6278666699697862101L, -26765L, false, false, (char) 12365, (char) 12797,
        Double.longBitsToDouble(0x3fbd1243c65b9fe0L), Double.longBitsToDouble(0x3fd04ed079443d26L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 3, 1, "\ud97e\udd08\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\ud902\udf40\ud805\udc66\ud995\udec6\ud815\udf0f\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\uda8f\udc23\ud9e5\udd46", "\u9154\u7e18\u71e2\u1374\u9bc6\ua617", "\ud9d5\udf98",
        23, 17734, -401423821, -6274228873055246484L, -19767L, false, true, (char) 41804, (char) 39685,
        Double.longBitsToDouble(0x3fedc2dc020dc68bL), Double.longBitsToDouble(0x3fe80a81951b4cdfL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\udb59\ude08\udb5e\uddfc\ud96a\udf23\udb75\udcdf\udabb\ude13", "\u0910\u68a3\u71e2\u1374\u9bc6\ua617\u88db\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\u949e\ucf83\ub0d5\u067e\u4835\ucf1f\u221c\u179f\u091a", "\uda2d\udd5a\udb1a\udc24\uda2f\udcc1",
        13, 43023, 709068388, 8224926417604335079L, 99362L, true, true, (char) 52682, (char) 30982,
        Double.longBitsToDouble(0x3fe4df5f12dd99b8L), Double.longBitsToDouble(0x3fed5675fdddf8beL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 3, 1, "\ud9ba\uddba\ud8b5\udcdb\ud8cb\udde6", "\u798d", "\ud9e9\udfab\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\udaff\ude9b",
        56, 48060, -865327126, 4445284213639184470L, 79391L, true, true, (char) 8817, (char) 52527,
        Double.longBitsToDouble(0x3feb5ff6e5848a2dL), Double.longBitsToDouble(0x3fd5fc3bcb857822L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.io.File:\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\ud839\udc9b\ud9c6\udfe4\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13\012",
        Z.run(T, 1, 3, 9, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\ud839\udc9b\ud9c6\udfe4\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3\u71e2\u1374\u9bc6\u4321\u88db\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\u949e\ucf83\ub0d5\u067e\u4835\ucf1f\u221c\u179f\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        13, 43023, 1229162084, 8224975238497588711L, 99362L, true, true, (char) 52682, (char) 30982,
        Double.longBitsToDouble(0x3fe4df5f12dd99b8L), Double.longBitsToDouble(0x3fed5675fdddf8beL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=java.io.File:\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udb4e\udd9c\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\ud8df\udc7a\udb6a\udef4\udb42\ude8e\ud849\udd4b\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udac1\udc57\012",
        Z.run(T, 2, 9, 3, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udb4e\udd9c\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\ud8df\udc7a\udb6a\udef4\udb42\ude8e\ud849\udd4b\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udac1\udc57", "\u091d\u567a\u71e2\u1374\u9bc6\ua617\u88db\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\uac52\ub62c\u7323\u0669\u4835\ucf1f\u221c\u179f\u091a", "\uda29\udd90\ud84c\udc04\ud8a0\ude92\ud86a\uded6\uda84\udde6\ud906\udeb5",
        44, 18127, -1908747963, -5310600214563059761L, -25004L, true, false, (char) 40085, (char) 61033,
        Double.longBitsToDouble(0x3fdddf8bed716336L), Double.longBitsToDouble(0x3fdaa1ba9972a7a2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 2, 1, "\ud9ba\udd3f", "\u297e\u48be\u798d\u43e3\u3db6\u5357", "\ud8a8\udcbd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31",
        21, 23864, -1614977976, 6977794483833211836L, -98145L, true, true, (char) 34796, (char) 8817,
        Double.longBitsToDouble(0x3fc9ba0c5c000000L), Double.longBitsToDouble(0x3fd848a2d2bf8778L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 3, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udad6\udcfe\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ufa5b\ud9b0\udefe\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\ud99f\ude85", "\u99bd\u6886\u0ac6\u1374\u9bc6\ua617\u88db\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\u949e\ucf83\u6a57\ucc9c\u305e\ucf1f\u221c\u179f\u091a\u3e1d\u4b5d\u7a8e", "\ud9a0\udd9f\ud85e\udc5f\ud996\ude84\ud828\ude89\udb49\udf8f\ud882\udf4b\ud996\uddf2\udb14\udef4\ud994\udeb3\uda18\ude5f\udbd3\udc93\ud968\udd7d\ud9ed\ude9e\ud91c\udf71\ud867\udee5\udae3\udf1f\u7e9f\ud9a8\uddaf",
        43, 46053, -529609333, -5403857192399712019L, -42570L, true, true, (char) 8997, (char) 48448,
        Double.longBitsToDouble(0x3fc057916be52274L), Double.longBitsToDouble(0x3fe912a6e07746deL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 8, 4, 1, "\ud9ba\udd3f\udab7\udcdc\ud867\udcdc\u00c4\000\udbb7\udc7a\ud84e\udc6d\000\ud9f3\udf8a\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396H\udbb2\udcb4\ud96a\udf0f\udb75\udcdf\ud98a\ude7b", "\u091d\u68a3\u516e\u1374\u9bc6\uce63\u0f7c\u65f7\000\u00f4\000\ud343\ua6ca\u3d44\u949e\u00de\000\u067e\u4835\ucf1f\u221c\u00b8\u3f0c", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        -5, 48, 0, 8224975238497588711L, 99362L, false, false, (char) 56027, (char) 30732,
        Double.longBitsToDouble(0x3f4d7c4b76640000L), Double.longBitsToDouble(0x3fed5675fdddf8beL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=null\012",
        Z.run(T, 2, 9, 7, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud9c0\udf2d\udaee\udd70\udb85\udc0f\udb31\udf6c\ud8e9\udc25\uda9b\udc0f\udb6a\udef4\udb35\uddc8\ud855\uddec\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3\u71e2\u8b28\uc46e\ua617\u88db\u65f7\u4617\u3406\u1cb0\u0351\ua6ca\u3d44\uae50\ud08a\ub0d5\u067e\u4835\u9fb7\uab61\u15a2\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        13, 43023, 1229162084, 8224975238497588711L, -31119L, false, true, (char) 30333, (char) 40085,
        Double.longBitsToDouble(0x3fedac7f55ddf8beL), Double.longBitsToDouble(0x3fe46d7ba77946fdL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 8, 8, 2, "\udbb3\udc3b\udab7\udcdc\ud8cb\udde6", "\u798d", "\ud9f3\udfaa\udb84\udff4",
        38, 47059, 581243397, 2955857282444552683L, -32576L, false, false, (char) 48052, (char) 27794,
        Double.longBitsToDouble(0x3fef57a47a71cc6cL), Double.longBitsToDouble(0x3fb58f6c0c257ce8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 4, 9, 9, "\udbf6\udd85\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\ud88b\udc42\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u09dd\u8f9e\u71e2\u1374\u9bc6\ua617\u88db\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\u949e\ucf83\ub0d5\u067e\u81af\u5468\u221c\u179f\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        13, 43023, 1229162221, 8224975238497588711L, 33826L, true, true, (char) 50433, (char) 30982,
        Double.longBitsToDouble(0x3fe4df5f12dd74b8L), Double.longBitsToDouble(0x3fed5675fdddf8beL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 6, "\uda6f\udc92\ud9bb\udcea\ud8cb\udde6\uda28\uddf1", "\u43e3\u3db6\u5357\u646a\ud58e\u26f2\u934b\u3128\u26c9\u0218\u0540\ub898\u55e2\u7e2c\u9ac8\ua38e", "\ud962\udc2b\uda0b\udd53\uda90\udc7c\udb5d\udcbb\ud9d8\udc79\udb62\uddf6\ud85d\udd5e\ud860\udfbc\udaa9\udda0\udb92\ude3c\ud942\ude68\uda1b\uddff\udae7\udc2d\ud85b\udebf\ud811\udf7c\udafa\ude69\udbc6\ude09\udbaa\udc92\udbe8\ude97\ud97d\udd23\u45d0\udb65\uddb9\udb9d\udeba",
        -4, 2643, -756680701, 5429612392855546665L, -22501L, false, true, (char) 48667, (char) 257,
        Double.longBitsToDouble(0x3fea04e1da9b5973L), Double.longBitsToDouble(0x3fe6eccdc1ad02bfL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbbf\udcec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udfb7\udb31\udf6c\ud84d\udf70\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\udaf9\ude17\udbb2\udcf6\ud93f\ude3a\udb75\udcdf\udabb\ude13", "\u091d\ub2b5\u050d\u1374\uc4ab\ua617\u896a\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u6ab8\ua7db\ucf02\ub0d5\u067e\u4835\u7472\u221c\u179f\u2a55", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79\ud810\udc1c\uda84\udd73\ud906\udeb5\ud221\ud98c\udf22\uda4a\ude90\ud84e\udce6\uda61\udd9e\ud8af\udd28\uda18\udddc\ud98e\udf3e\ud881\udf9b\ud9ed\udf3d\uda2a\udff9\uda2e\udd6f\ud993\uddae\udab5\udd38\udb58\udce4\uda18\udd07\uda9c\udd31\udb19\udc43\uda64\udfbe\udaff\udf0d\ud943\udef3\ud90e\udcce\ud9cf\udd4f\uda47\udf11\ud94e\ude87\udb2f\ude8e\ud86d\udf80\u986c\ud9c7\udcbb\udb05\udc0e\ud86c\udef5\uda62\udfab\ud928\udfa1\ud801\udf54\ud9eb\udf0f\uda44\ude29\ub4ca\ud805\udc33\udbf0\udf4c\ud8ce\udcf8\u908c\ud8cb\udfd7\ud978\udee7\udbdd\udd94\uda8b\ude06\uda8d\udd04\udb2e\udf14\ud822\udcbd\uda44\udcf4\ud9bf\udf4c",
        56, 97697, 1055363141, -2510986348657546560L, 83136L, true, false, (char) 32752, (char) 61404,
        Double.longBitsToDouble(0x3fcaa72694ab2cccL), Double.longBitsToDouble(0x3feaa5e81364b450L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 4, 3, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\ud968\ude28", "\u9e99\u63db\u409a\u53de\ubbab", "\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13\ud991\udecb\udbdb\udda8\uda34\udc69\ud820\udd84\uda6d\udf83\udb5d\udcbb\ud9d8\udc79\udb62\uddf6\ud85d\udd5e\ud860\udfbc\udad2\udfd6\udb87\udff1\udb08\udc17\uda98\udf96\udb59\udc74\ud94d\udef0\ud82b\ude7a\udafa\ude69\udbc6\ude09\uda6f\ude55\ud832\ude06\ud8d7\ude8c\ud9ba\udf0d\ud88c\udc55\ud925\udc2b",
        57, 2701, -756680701, 5429612391041313577L, -35641L, true, true, (char) 62402, (char) 33604,
        Double.longBitsToDouble(0x3fee7db265efdadbL), Double.longBitsToDouble(0x3fec5aaf2a9bebe2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 9, 9, 1, "\ud9ba\udd3f\uda4f\udd41\ud9b7\udd45\ud83f\udc63\udb0d\udf0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud88f\udf66\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\u9ec7\ud8c2\ude9e\udaf8\ude65\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3\u71e2\u1374\u9bc6\ua617\u88db\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\u949e\ucf83\ub0d5\u067e\u4835\ucf1f\u221c\u179f\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        13, 43023, 1229162084, 8224975238497588711L, -31119L, false, true, (char) 30333, (char) 40085,
        Double.longBitsToDouble(0x3fed5675fdddf8beL), Double.longBitsToDouble(0x3fdee635c7cd72aaL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 5, "\ud9ba\uddbc\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\ud8e9\udcdd\uda9b\udc0f\udb6a\udef4\ud9c7\udc31\ud849\udd20\ud80e\udd96\udba1\udfab\udbd0\udebb\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3\u71e2\u1374\u9bc6\u7abb\u93b4\u65f7\u4617\u3406\u1cb0\ud343\ua6ca\u3d44\u949e\ucf83\ub0d5\u067e\u4835\u4da7\u221c\u179f\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        13, 43023, 1229162084, 8224975238497588711L, -35264L, false, true, (char) 5409, (char) 28484,
        Double.longBitsToDouble(0x3fe4df5f12dd99b8L), Double.longBitsToDouble(0x3fed5675fdddf8beL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\uda2f\uddd8\ud93f\udc2a\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\udb86\ude96\uda13\udcf0\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13\0121=java.io.File:\uda2f\uddd8\ud93f\udc2a\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\udb86\ude96\uda13\udcf0\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13\012",
        Z.run(T, 2, 7, 3, 1, "\uda2f\uddd8\ud93f\udc2a\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\udb86\ude96\uda13\udcf0\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3", "\ud9a1\udc79",
        14, 78495, 1701619138, -1629991903925115909L, 46893L, true, false, (char) 26466, (char) 29995,
        Double.longBitsToDouble(0x3fe92ceb1306c1e4L), Double.longBitsToDouble(0x3fe4bd4f95b221aaL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 1, "\uda64\ude83", "\u488e\u48be\u798d\u43e3\u3db6\u5357", "\u88bb",
        29, -846, 0, 8507139351010150240L, 24131L, false, true, (char) 7290, (char) 52445,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e27555000000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 8, 1, 1, "\000", "", "",
        26, -1000, 1777252393, 4329775774583811281L, 61605L, false, false, (char) 29487, (char) 4848,
        Double.longBitsToDouble(0x3fe15cf6df60760fL), Double.longBitsToDouble(0x3fb22fed58e80000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 1, "\uda64\ude83", "\u297e\u48be\u798d\u43e3\u3db6\u5357\u646a\u409a\u53de\u51c0\u3128\u26c9\u0218\u9b2c\u5a31\u55e2\u7e2c\u9ac8\u24be\u96e6\u91b2\u091d", "\uda18\udfd9",
        58, 83444, -1220642465, 3273479423305304187L, 57537L, true, false, (char) 26948, (char) 59260,
        Double.longBitsToDouble(0x3fe5a64696f90802L), Double.longBitsToDouble(0x3feb49f0ac23adbcL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 7, 3, "\uda64\ude83\udab7\udcdc", "\u48be\u798d", "\ud9f3\udfaa\udb84\udff4",
        38, 11836, 581281968, 2955857282444552683L, -32576L, false, false, (char) 52883, (char) 27794,
        Double.longBitsToDouble(0x3fef57a47dacff6cL), Double.longBitsToDouble(0x3fe60e930a3f9093L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 1, "", "\000", "\000",
        -5, -1000, 0, 8730488259352551904L, -100000L, false, false, (char) 4843, (char) 3335,
        Double.longBitsToDouble(0x3fb81d83c0000000L), Double.longBitsToDouble(0x3f9d9fbd778c1ac0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 6, 7, 1, "\uda64\ude83", "\u297e\u48be\u798d\ud6ba\u3db6\u5357", "\ud8e9\udcdd\udac0\udeba\udb6a\udef4\ud9c7\udc31",
        21, 23864, -1614977976, 6977794483833211836L, 98267L, false, false, (char) 35156, (char) 39820,
        Double.longBitsToDouble(0x3fefbaca3a52f811L), Double.longBitsToDouble(0x3fc9ba0c4dabbf70L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 2, 2, 2, "\uda64\ude83", "\u31c6\ua343\u3177\u46aa\uc6c0\ua0d0", "\ud8e9\udcdd\uda53\udee4\udb6a\udef4\ud9c7\udc31",
        56, 23864, 615539784, -4372082940070393066L, -88337L, false, false, (char) 27325, (char) 18515,
        Double.longBitsToDouble(0x3fd7555f14a5f03cL), Double.longBitsToDouble(0x3fc9ba0c5d00a370L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 1, "\ud9ba\udd3f\udab7\udcdc\ud9f7\udddb\uda3b\udfeb\uda12\udd45\udbf0\udfec\uda7d\uddc8\ud835\udc44\ud9f3\udfaa\udb84\udff4\udb31\udf6c\udb90\udcde\u0bdf\ud898\udebe\ud9a5\udc32\ud849\udd20\ub396\udb0b\ude9b\udbb2\udcd1\udb40\udf5a\udacb\udd4b\udabb\ude5f\ud8e6\udf99\udac8\udc05\uda34\udc51\udb40\udd13", "\u9c11\ua617\u6b3b\uce1e\u6d8a\ucbf9", "\udae7\udc2d\ud85b\udebf\ub37f\ud97f\udd55\udadb\udc8a\u20a2\uda95\udfc5\ud997\udc45",
        6, 92146, 1345495565, 5539290105510389019L, 40454L, true, false, (char) 44480, (char) 19244,
        Double.longBitsToDouble(0x3fdd91cf76cfdd58L), Double.longBitsToDouble(0x3fde7722428ba210L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 9, 4, 1, "\ud9ba\udd3f\udab7\udcdc\ud924\ude52\ud86f\udfcd\uda42\ude08\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\udb90\udd72\u0bdf\uda4a\uded8\ud99a\uddd5\ud82d\udf53\ud8dd\udd95\ud8e3\udcb3\ud82f\ude47\ud8fb\ude6d\ud9bf\udeeb\ue93f", "\u0f40\ud1a0\u7246\u1374\u9bc6\ua617\u88db\u65f7\u4617\u1dd1\ua68e\ud343\ua6ca\u3d44\u5691\ucf83\ub0d5\u067e\u4835\ucf1f\u221c\u179f\ubc2b\u3f03\u4b5d\u7a8e\u6502\uc5c8\u7916\ua12a\u2539\uc2af\u663c\u8a6d", "\ud8af\udd28\ud9ba\udfd6\udbd3\udc93\ud81d\udfea\udbce\udd5b\uda06\udfe6\ud9b5\udcfe\udac7\udf14\uda8e\udcdb",
        -1, 44470, -1977043774, 7331695250957754885L, 62897L, false, false, (char) 64415, (char) 34288,
        Double.longBitsToDouble(0x3fe11befecca54faL), Double.longBitsToDouble(0x3fe76bfe353193c7L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 1, "\ud9dd\udd76\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udaf1\udd2c\ud875\ude6a\uda9b\udcae\udb6a\udef4\ud992\udd31\udae9\udfb1\uda6d\ude37\udbed\udc2f\ud822\udeb0\udb2e\udf03\udb75\udcdf\udabb\ude13\ud8e6\udf99\ud938\udf01\uda34\udc51\ud820\udd84\uda6d\udf83\udb5d\udcbb\uda87\udf76", "\u1898\ua792\u3406\u1cb0\ud343\ua6ca\u522a\u8587\ucf83\ub0d5\u067e\u4835\ucf1f\u221c\u179f\u091a\u3e1d\u4b5d\u7a8e\u6502\uc5c8\u7916\ua12a\u2539\uc2af\u663c\u8a6d\u8de4\uc3c8\u76c2\u2b35\u2962", "\udbb8\udfbf\ud8cc\udf04\ud816\udf2d\udb23\udd56\ud814\udf41\uda4a\uddf6\udb60\udedd\uda99\udf7c\ud996\udc45\udaba\ude61\ud81b\ude97\ud8ad\udc2a",
        38, 55336, 1810145979, 4307173393204460987L, 38684L, true, true, (char) 21407, (char) 33147,
        Double.longBitsToDouble(0x3fcaad0bcdbe9930L), Double.longBitsToDouble(0x3fe361f6f8881956L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 7, 9, "\ud876\udf7d\uda6c\ude17\ud8c1\udfc4", "\u5dfe", "\udbc8\udf86",
        31, 30236, 11492176, 2496421381819158666L, -8792L, false, true, (char) 27830, (char) 62607,
        Double.longBitsToDouble(0x3fe38e6005e03db0L), Double.longBitsToDouble(0x3fec91c759128bdeL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 9, 9, 1, "\ud9ba\udd3f\udab7\udcdc\udb01\udde1\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud9c0\udf2d\udaee\udd70\udb85\udc0f\udb31\udf6c\ud8e9\udc25\ud8d7\udd8d\udb03\udea3\udb1a\udfde\ud855\uddec\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udb88\udc2d", "\u091d\u7be6\u71e2\u8b28\uc46e\ua617\u88db\u65f7\uc90e\u3406\u1cb0\u0340\ua6ca\uce8c\uae44\ud08a\ub0d5\u067e\u5340\u9fb7\uab61\u15a2\u091a\u3e1d\u7eeb\u60d2", "\ud96d\udf77\udb96\udd1a\ud94a\udf77\udbf7\udf43\ud98c\udf22\udb27\udcbe\udb80\udca2\uda9d\udee9\ud8af\udd28\uda18\udddc\u2fb0\ud93c\udffa\ud9f5\uddfc\udbba\udfbd\ud932\ude21\uda86\udedc\udbe5\udf5f\udab3\udc09",
        44, 63911, 1811615652, 8531296349260798698L, 13031L, false, true, (char) 65234, (char) 13450,
        Double.longBitsToDouble(0x3fa5ffe8535680b0L), Double.longBitsToDouble(0x3fd78cbc752cb5c2L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=null\012",
        Z.run(T, 2, 9, 7, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud9c0\udf2d\udaee\udd70\udb85\udc0f\udb31\udf6c\ud8e9\udc25\uda9b\udc0f\udb6a\udef4\udb35\uddc8\ud855\uddec\ub396\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3\u71e2\u8b28\uc46e\ua617\ucee6\u5b63\u3e33\u3406\u1cb0\u0351\ua6ca\u3d44\uae50\ud08a\ub0d5\u067e\u4835", "\ud9f3\udec4\udb9d\udec6\udaf1\udf88\u4fd9\uda2d\udd5a\udb1a\udc24\ud80d\ude79\ud9a0\udfe9\uda84\udde6\ud906\udeb5\ud221\ud98c\udf22\udb27\udcbe\udb80\udca2\uda9d\udee9\ud8af\udd28\uda18\udddc\udbd3\udc93",
        4, 47229, -1351301667, 5115287137434606457L, -72118L, false, false, (char) 64843, (char) 38290,
        Double.longBitsToDouble(0x3fc4b1729d453548L), Double.longBitsToDouble(0x3fe1fcb10be2d8b8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 1, "\ud9ba\udd3f\ud8ad\udd37\uda9d\udd80\ud9a4\ude8b\uda62\udec4\udbf0\udfec\ud886\udf6d\ud9c0\udf2d\udaee\udd70\udb84\udff5\udb31\udf6c\ud8e9\udc25\uda9b\udc0f\ud853\udfe8\udb35\uddc8\ud855\uddec\udb46\udf13\udb59\udf84\udbb2\udcd1\ud96a\udf0f\udb75\udc4b\uda03\udf57", "\u0569\u2527\u71e2\u8b28\uc46e\u5f64\u9958\u03b2\u15b5\u95c9\ub83c", "\ud85b\udebf\ud866\udf26\ud8fd\udd2a\udbc6\ude09\udbaa\udc92\ud940\udf81\ud9a9\udcd8\ud9cd\udef4\ud9f3\udf4f",
        45, 99352, -1496816147, -3249918863045211214L, 7309L, false, false, (char) 35323, (char) 17638,
        Double.longBitsToDouble(0x3fde7722428ba210L), Double.longBitsToDouble(0x3fed0599d1def948L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb8c\udd01\ud807\uddd3\ud886\udf6d\ud9c0\udf2d\udaee\udd70\udb85\udc0f\udb31\udf6c\ud8e9\udc25\uda9b\udc0f\ud897\ude6b\udb35\uddc8\ud855\uddec\ub396\udaff\ude9b\ud905\udedc\ud96a\udeec\udb75\udcdf\udabb\ude13\0121=java.lang.String:\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb8c\udd01\ud807\uddd3\ud886\udf6d\ud9c0\udf2d\udaee\udd70\udb85\udc0f\udb31\udf6c\ud8e9\udc25\uda9b\udc0f\ud897\ude6b\udb35\uddc8\ud855\uddec\ub396\udaff\ude9b\ud905\udedc\ud96a\udeec\udb75\udcdf\udabb\ude13\012",
        Z.run(T, 2, 7, 7, 1, "\ud9ba\udd3f\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb8c\udd01\ud807\uddd3\ud886\udf6d\ud9c0\udf2d\udaee\udd70\udb85\udc0f\udb31\udf6c\ud8e9\udc25\uda9b\udc0f\ud897\ude6b\udb35\uddc8\ud855\uddec\ub396\udaff\ude9b\ud905\udedc\ud96a\udeec\udb75\udcdf\udabb\ude13", "\u091d\u68a3\u71e2\u8b28\uc46e\ua617\u88db\u65f7\u0674\u7eee\u1cb0\u0351\ua6ca\u3d44\uae50\ud08a\ub0d5\u067e\u4835\u16cf\uab29\u15a2\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79\ud9a0\udfe9\uda84\udde6\ud906\udeb5\ud221\ud98c\udf22\udb27\udcbe\udb80\udca2\uda9d\udee9",
        56, 51291, -1715959141, -8076639833646293067L, 86739L, true, true, (char) 42704, (char) 23002,
        Double.longBitsToDouble(0x3fc8d27e3540ba7cL), Double.longBitsToDouble(0x3fe357296733e309L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 1, "\uda2f\uddd8\ud93f\udc2a\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\udbf0\udfec\ud886\udf6d\ud86d\ude67\ud9f3\udfaa\udb84\udff4\udb31\udf6c\udb86\ude96\uda13\udcf0\udb6a\udef4\ud9c7\udc31\ud849\udd20\ub37a\udaff\ude9b\udbb2\udcd1\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\u68a3", "\ud9a1\udc79",
        35, 87219, 1701619077, -1629991903925115909L, 46893L, true, false, (char) 26466, (char) 29995,
        Double.longBitsToDouble(0x3fe92ceb1543c1e4L), Double.longBitsToDouble(0x3fe2e5cbb5b221aaL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 3, 1, "\ud99c\udfe8\udab7\udcdc\ud8cb\udde6\ud83f\udc5c\udb03\udd0f\ud863\ude06\uda72\ude67\ud86d\ude67\ud93e\udc10\udb84\udf79\udb31\udf6c\ud902\udeab\uda9b\udc89\udb6a\udef4\ud9c7\udc31\ud849\udd20\ud8ca\udf84\uda7d\udda7\udbd2\udeec\ud96a\udf0f\udb75\udcdf\udabb\ude13", "\u091d\uc4d9\u724e\u1374\u9bc6\ua617\u88db\u65f7\u4617\u3406\u348b\u7d43\ua6ca\u3d44\u949e\ucf83\ub0d5\u067e\u7d2a\u436f\u5aa7\ud7fe\u091a", "\uda2d\udd5a\udb1a\udc24\ud80d\ude79",
        13, 43023, 1228373604, 8224975238497588711L, 99362L, true, true, (char) 52682, (char) 19462,
        Double.longBitsToDouble(0x3fd9beb7bf38a3c0L), Double.longBitsToDouble(0x3feb7dbbc5ddf8beL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.TypeHandler|createNumber|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createClass|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createDate|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFile|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFiles|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createObject|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createURL|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
    "C|org.apache.commons.cli.TypeHandler|<init>|",
    "M|org.apache.commons.cli.TypeHandler|createNumber|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
