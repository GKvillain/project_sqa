package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Parser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 3, "\udaee\udf42\udb4c\udc3c", "\u62f6\u57ee\uae46\u8bac", "\ud8c9\udf1a\udacf\ude2e\ud800\udf37",
        16, 53930, 603372740, -3334256884703081257L, -62306L, false, false, (char) 8755, (char) 63061,
        Double.longBitsToDouble(0x3fb02816e8b1d698L), Double.longBitsToDouble(0x3fc0a391b4da2af4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 5, "\udae2\udd9c\udb4c\udc3c\udb39\udcc5\udb04\udea9\udafa\udce6\udacd\udea1\udba2\uddff\ud926\udf41", "\u386b", "\udade\uddb1\u4d5e\uda2d\udee2\udbb6\udd4c\ud831\udde7\udbd9\udeae\u45d5\ud97c\udd77",
        3, 29856, 973511111, 2057306194858304645L, 99426L, true, false, (char) 5644, (char) 26806,
        Double.longBitsToDouble(0x3fc107045d7abc70L), Double.longBitsToDouble(0x3fec3f48e33b075cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 3, "\udaee\udf42\udb4c\udc3c", "\u62f6\u57ee\uae46\u36a3", "\ud8c9\udef2\udacf\ude2e\ud9aa\udfd0\udade\uddb1\u4d5e\uda2d\udee2\udba1\udc4c\ueb49\ud84d\udfa3\u463d\ud97c\udd77\udb7a\udee5\ud814\udcdc\ud9c0\udfb7\udadf\udec4\udbc5\udd9b\udaaa\udc44\ucd63\ud825\udf37\udb74\udea2\udaa3\udebc\u36e5\ud9dc\udec8\uda5c\udcb6\ud869\udeb9\u18dd\udbc3\ude9f\ud8fb\ude70\uda73\udf2e",
        4, 6297, -1927184391, 1853282383825909275L, -41143L, false, false, (char) 10332, (char) 38034,
        Double.longBitsToDouble(0x3fcc9889a5fb7308L), Double.longBitsToDouble(0x3fc31c2debd83b34L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 4, 11, "\udb1b\udc42\ud80d\udede", "\u62f6\u57ee\uae46\u8bac", "\u4df0\ud919\udc36\ud801\udc05\udade\uddb1\u4e03\ud916\udebd\ud8d7\udc78\ud8eb\udda3\uad28\u5be5\ud97c\udd77\udb7a\udee5\ud814\udcdc\ud9c0\udfb7\udadf\udec4\udbc5\udd9b\uda4e\udc72\udb2f\uddce\ud85f\ude7d\ud9ef\udd3e\uaa6c\ud95c\udf8e\ud971\udc9e\udb50\udfcb\u2d95\ud800\udc73\udab2\udc2b\ud8a8\udc42\uda5c\udd6c\udb26\uddb6\udb87\udc9a\ud97a\uddad\ud9c6\udfcd\ud97d\udf0d\ud8d5\ude2f\udb1c\ude37\ud9f1\udec9\udb12\udd05\ud931\udf04\udb06\udf6a\udbf6\udc21\udb41\ude0a\ud811\udf62\ud889\udedc\udae8\ude26\ud8f3\udfd3\udbc2\udde7\u69aa\ud8f7\udfab\ud93e\udcbc\ud9f7\udd1c\ud825\uded4\ud89a\ude00\u1d0d\ud8fa\udcdc\ud84b\udcce\ud895\udcf7",
        13, 36371, -365159186, -3721450810299991457L, -91491L, false, false, (char) 9997, (char) 49415,
        Double.longBitsToDouble(0x3fec1cfb2ae07fcbL), Double.longBitsToDouble(0x3fc1b39f499af8d8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 4, "\udaee\udf42\udb4c\udc3c", "\u62f6\u57ee\uae46\u8bac", "\000\000\ud800\udf2e",
        16, 53930, 603372740, -3334352542214697769L, 84706L, true, false, (char) 57499, (char) 16361,
        Double.longBitsToDouble(0x3f1c8d000017a000L), Double.longBitsToDouble(0x3f97cb1c0e900c60L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 11, "\udaee\udf42\udb4c\udc3c\udb39\udcc5", "\u69a2\uae46\u8bac\u7672", "\udacf\ude2e\ud800\udf37\udaec\udccb\u4d5e\uda2d\udee2\udba1\udc4c",
        40, 83817, 421489858, 5814671266272432514L, -8831L, false, true, (char) 58070, (char) 60621,
        Double.longBitsToDouble(0x3fd2a0f9e8875b26L), Double.longBitsToDouble(0x3fe9dfb5c8c16bf9L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 7, "\ud8bf\udf1a\u38df\udb4b\ude54\ud907\udfca", "\uae46\ub39c\u6c15\u98ac\u322b", "\udade\uddb1\u4d5e\uda2d\udee2\udba1\udc4c\ueb49\ud84d\udfa3\u463d\udac9\udcbf",
        18, 64279, 986923072, 2057306194858304645L, 43215L, true, false, (char) 60425, (char) 6736,
        Double.longBitsToDouble(0x3fe8e88ffaaca537L), Double.longBitsToDouble(0x3fd4a0504199f562L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 3, "\udb03\udc97\uda94\uddbb", "\ua068\u57ee\uae46\u8bac", "\ud8c9\udf1a\udacf\ude2e\ud800\udf37",
        16, 53930, 603372740, -3334256884703081257L, -62306L, false, false, (char) 8755, (char) 18517,
        Double.longBitsToDouble(0x3fddae02332b0dceL), Double.longBitsToDouble(0x3fb1930429b455e8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 11, 4, 1, "\udb54\ude34\udb9b\udc86", "\u1c94\u587d\u8202\ua212\u962e\u5994\u447c\u9864\ub1c3\u03a3\u3a8e\u1a72\u808c\uce24", "\ud97c\udd77\udb7a\udee5\ud814\udcdc",
        52, 85782, 584647568, -8382356308243726390L, 41822L, true, true, (char) 55507, (char) 9890,
        Double.longBitsToDouble(0x3fdcaaff2afa776cL), Double.longBitsToDouble(0x3fc277c976abaca8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 3, "\udaee\udf42\udb4c\udc3c", "\u663f\u57ee\uae46\u6f32", "\ud8c9\udf1a\udacf\ude2e\ud800\udf37\udade\uddb1\u4d5e\uda2d\udee2\udba1\udc4c\ueb49\ud84d\udfa3\u463d\ud97c\udd77\udb7a\udee5\ud814\udcdc\ud9c0\udfb7",
        6, 78549, 241904950, -1780563998780991556L, -46510L, true, false, (char) 36634, (char) 62224,
        Double.longBitsToDouble(0x3fb83b393b24e400L), Double.longBitsToDouble(0x3fd00ed73fa2244aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 3, "\udb28\udc06\udb4c\udc3c", "\ubaf5\u4139\uae46\u8bac", "\ud8c9\udf1a\udacf\ude2e\ud800\udf37",
        16, 53930, -906576700, -3696242853033325559L, -9812L, true, false, (char) 57499, (char) 26089,
        Double.longBitsToDouble(0x3fba835a3a1f9b00L), Double.longBitsToDouble(0x3fd7931072f6653aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 3, "\udaee\udf42\udb4c\udc3c", "\000\u1e8c\000\000", "\000",
        22, 81337, -939524096, -1203586613264335872L, -54135L, true, false, (char) 25299, (char) 62932,
        Double.longBitsToDouble(0x3fd8250b1cff1facL), Double.longBitsToDouble(0x3fb02816c0b1d698L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 4, 4, 3, "\udaee\udf42\udb4c\udc3c", "\u62f6\u57ee\uae46\u8bac", "\ud8c9\udf1a\udacf\ude2e\ud800\udf37\udade\uddb1\u4d5e\ud9a3\udebe\udba1\udc4c\ueb49",
        52, 15858, 72008118, -8082042349936744833L, 93053L, false, true, (char) 8681, (char) 62437,
        Double.longBitsToDouble(0x3fc3877c11586308L), Double.longBitsToDouble(0x3fef6129154b1985L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 11, 4, 10, "\udaee\udf42", "\u7802\u397a\u7d5c\u4e6d\u3d66\uad96", "\ud8c6\udcd5\ud80e\ude01\udaea\udfb1\u4d5e\uda2d\udee2\udba1\udc4c\udb56\udd63\ud84d\udfa3\u463d\ud97c\udd77\udb48\uded7\ud814\udcdc\ud9c0\udfb7",
        6, 61860, 1915057206, 6129428430764747785L, 95856L, false, true, (char) 13842, (char) 16585,
        Double.longBitsToDouble(0x3feaa24a8470e90eL), Double.longBitsToDouble(0x3fc2bf264daf093cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 3, "\udb36\udc03\ud8ca\ude92\ud8a8\udec2\ud8fb\ude73\ud936\udec8\ud889\udc7e\ud95d\udf2c\ud926\udf41\ud8ec\udede\ud870\ude3c\ud8c9\udf1a\udacf\ude2e\ud800\udf37\udbda\udcda\u4d73", "\u670e\ubc72\u1a88\ub405\u3f61\u9523\u45f8\u75bc\ua187\u073b\u2a3c\u1430\ubc95\u53be\uc6fa\u07df\ub55d\ua910\u9cb9\ua2a7\ubbb4\ud5df\u0e6c\uc6f1\u2b16\u33cb\u84cc\u17e3\ud036\u46fb\u4ca0\u97dc\u0e2f\u2772\u4477\uce55\ud26f\u1c81\ud01b\u3571\uaf76\u01ef\u88f4\u4d75\u5db0", "\udafd\udda5\ud83b\udc94\uda21\udf14\ud9e5\ude5e\ud82a\udf72\uda1e\udcff\uda13\ude6c\ud978\ude0a\udb86\udd48\uda3e\ude17\ud846\ude8b\udb59\ude60\uda69\ude86\ud870\ude74",
        20, 84, -137543674, 1516791325314127513L, -44010L, false, true, (char) 25931, (char) 43182,
        Double.longBitsToDouble(0x3fa524e17c813c50L), Double.longBitsToDouble(0x3feaad21cd4b9b0fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\u0aec\ud90b\uddcc]] |a1=[Ljava.lang.String;:[[\u0aec\ud90b\uddcc]] |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 4, 3, "\u0aec\ud90b\uddcc", "\u2c55\u3c08\uae46\u38ad", "\ud8c9\udf1a\udacf\ude2e",
        1, 95652, -280199756, 2591466184821593863L, -58320L, false, false, (char) 51131, (char) 32976,
        Double.longBitsToDouble(0x3fd368abdf710a66L), Double.longBitsToDouble(0x3fcc69b924ad1ab4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 3, "\ud900\udd4c\uda78\udee7\udb39\udcc5\ud907\udfca\ud812\udff6\uda59\udd0f", "\u7672", "\udbfa\udd31\ud800\udff1\ud808\udec5\udb87\udc86\uda2d\udee2\udbbe\uddba",
        42, 29281, 421489858, 5814671266272432514L, 70907L, false, true, (char) 29682, (char) 919,
        Double.longBitsToDouble(0x3fe2ce192e73105eL), Double.longBitsToDouble(0x3fe632e8ca3d410bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 7, "\udaee\udf42\udb4c\udc3c", "\u62f6\u57ee\uae46\u8bac", "\ud8c9\udf1a\udacf\ude2e\ud800\udf37",
        0, 53930, 603372740, -3334256884703081257L, -62306L, false, false, (char) 8755, (char) 63061,
        Double.longBitsToDouble(0x3fb02816e8b1d698L), Double.longBitsToDouble(0x3fc0a391b4da2af4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 0, "\ud97d\udfe4\udb4c\udc3c", "\u02f6\u2d09\u24fb\u3e62", "\ud8b9\udc33\uda05\udf47\ud8a6\ude96\udaca\udddf\u4d5e\udb65\udede",
        56, 5154, 2145149410, -5971924158539244362L, -60703L, false, true, (char) 16250, (char) 38418,
        Double.longBitsToDouble(0x3fd36350ceb5a26aL), Double.longBitsToDouble(0x3fb965a8781379c0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 8, "\udaee\udf42\udbd0\udedf", "\u1369\u57ee\u8f85\u8bac\u7672\ud1d0\uc1d8\u9864\ub1c3\u03a3\u3a8e", "\ueb49\ud83a\ude59\udbfa\udebc\ud841\udf3a\ua636\ud814\udcdc\ud9eb\udc6c\udadf\udf81\ud9a4\ude86\ud993\ude41\uda7a\udda4\ud9ea\udf8b\uda68\udd22\ud850\udf70\uda94\ude6c\udb10\udd68\ud99f\udd53\udaad\udf4f\udb0d\udebb\udb01\udd26\ud8f9\udfd1\ud8d5\ude1c\udada\ude42\u4892\ud868\udc91\uda30\ude23\ud9dc\udfe7\ud9f4\ude54\udad3\udc0e\uda52\udd5b\ud8ec\ude89\ud9b7\ude17\udaf3\ude2f\udbba\udc45\ud91e\udc25\udbe4\ude8b\ud860\udd69\ud8bd\udcae\udb0b\udcb3\udb7d\udc82\ud8cb\udf86\ud87e\udd84\udb3e\uddcd\udbbd\udd52\ud842\udf1d",
        57, 23709, 823787426, 3844894142643831881L, 8727L, true, false, (char) 18788, (char) 24926,
        Double.longBitsToDouble(0x3fdb56ca2895d49cL), Double.longBitsToDouble(0x3fe0c21b098151c4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udae4\uded0\udbb3\udd90\udb39\udcc5\ud8d7\ude91\udbec\ude12]] |a1=[Ljava.lang.String;:[[\udae4\uded0\udbb3\udd90\udb39\udcc5\ud8d7\ude91\udbec\ude12]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 5, "\udae4\uded0\udbb3\udd90\udb39\udcc5\ud8d7\ude91\udbec\ude12", "\u8cc2\u8709\ud1d0\u1e5d", "\ud8f9\udc21\ud84d\udccd\udae2\uddd4\udba9\udda3\udabc\ude0a\udbff\ude1a\uda6e\udffa\udb09\udd0d\udb7a\ude75",
        47, 51072, 479003926, -8449486802102964938L, 16101L, true, false, (char) 4262, (char) 6206,
        Double.longBitsToDouble(0x3fd66e6ee4298b0cL), Double.longBitsToDouble(0x3fe1939ddadd8ed9L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\ud994\ude2e\ud9a9\udfcd]] |a1=[Ljava.lang.String;:[[\ud994\ude2e\ud9a9\udfcd]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 11, 2, 3, "\ud994\ude2e\ud9a9\udfcd", "\u221e\u57ee\uae46", "\ud8af\udc8c\ud8dc\udec7\udacf\ude2e\ud800\udf37\udade\uddb1\u4d5e\uda2d\udee2\udade\udfaa\ueb49\ud84d\udfa3\u463d\ud97c\udd77\udb7a\udee5\ud814\udcb9\ud9c0\udfb7\udadf\udec4\udbc5\udd9b\udb0f\ude17\udafb\udce8\udb51\udf66\ud99d\ude98",
        7, 9278, 528370917, -5848504466846645994L, -9503L, true, false, (char) 23661, (char) 56544,
        Double.longBitsToDouble(0x3fabcbc0127a70d0L), Double.longBitsToDouble(0x3fcce8559ffccbb4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 3, "", "\u551a\u6f15\u62f6\u57ee\uae46\u8bac\u7672\ud1d0", "\ud800\udf37",
        16, 53930, 603372740, 95689411349719L, -62306L, false, false, (char) 8755, (char) 63061,
        Double.longBitsToDouble(0x3fb02816c0b1d698L), Double.longBitsToDouble(0x3f1c8d0000000000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 4, 0, 4, "\000", "\u7802", "\ud95d\udf2c",
        58, 99776, 1304628647, 932007903232L, 1376L, false, false, (char) 44048, (char) 31485,
        Double.longBitsToDouble(0x3f4a3740e5b57c00L), Double.longBitsToDouble(0x3fc85ec212d8647cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 11, 11, 3, "\ud8f6\uddeb\u56c5\udb39\udcc5\ud907\udfca\ud93f\udfc8\ud8f8\udeea\ud8c8\udf52\u2073\ud8f5\udd04\ud870\ude3c\ud8c9\udf1a\udacf\ude2e\ud9f3\udc25\udb2c\uddaf\u4d5e\uda2d\udee2\udba1\udc4c\udbee\udc83\ud8c8\ude0e\u463d\ud9a6\ude9f\ud96a\udebc\udaaa\udea7\ud8a5\udc9b\udb59\udda5\udb4e\udeff\ud908\ude5d\ud8f8\udf17", "\uc309\u3924\u9694\u6b75\ubf71\u4a76\u6633\u87d5\uae01\u6719\ua3a9\ua040\ud53e\u55ef\u587a\ucb98\u2541\u5bc9\u9cdf\ub2c9\u30eb\u0d89\u1666\u3037\u9229\u3da5\u668a\uc7c8\u56ae\u8f6f\u2277\ud30c\uc35f\u1836\u48d6\u0ceb\u40fa\u97c6\ub816\u1276\u7056\u1868\u0832\u7837\u51bd\uc28b\uac8d\u5732\u1280\u6b01\u0bbd\u8982\uc0f2\u6716\uc1d4\u1a1e\u3eb8\u3b32\u0d20\u70b4\u6fc0\u7cf9\u5892\uac27\uc5d7\u42ba\u7f0e\u8783\uc313\u36e7\u34c4\u3fa0\ub99f\ud1ba\u17b2", "\ud897\udd83\uda53\ude51\u3ed6\ua9e4",
        17, 10272, -613629729, -3028710909157722508L, 45654L, true, true, (char) 2282, (char) 57838,
        Double.longBitsToDouble(0x3fc44c435eba2aa0L), Double.longBitsToDouble(0x3fc5a6ace2039e7cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 3, "\udad1\udcc7\udac1\udd44", "\u6284", "\ud926\udf41\ud8f5\udcfe\uda15\udff0",
        0, 92602, 335907337, -3970357443324793254L, 53351L, true, false, (char) 19864, (char) 64393,
        Double.longBitsToDouble(0x3fc6c323e60942c4L), Double.longBitsToDouble(0x3fe3fc7eb040a05bL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udaee\udf42\udb4c\udc3c]] |a1=[Ljava.lang.String;:[[\udaee\udf42\udb4c\udc3c]] |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\udaee\udf42\udb4c\udc3c]] |a1=[Ljava.lang.String;:[[\udaee\udf42\udb4c\udc3c]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 2, 3, "\udaee\udf42\udb4c\udc3c", "\u62f6\u57ee\uae46\u8bac", "\ud8c9\udf1a\udacf\ude2e\udb13\ude49",
        16, 53930, 603372740, -3334256885676159785L, -62306L, false, false, (char) 8755, (char) 63061,
        Double.longBitsToDouble(0x3fb02816e8b1d698L), Double.longBitsToDouble(0x3fc0a391b4da2af4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udaee\udf42\ud9b2\udd67]] |a1=[Ljava.lang.String;:[[\udaee\udf42\ud9b2\udd67]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 8, "\udaee\udf42\ud9b2\udd67", "\uad09\ua20e\u3a77", "\udb88\udf88\udb71\ude6e\ud9f0\udd5a\udb15\ude67\udab8\udc8e\uda04\udfb4\udbab\udf7c\ud9e3\udde1\udbc2\udf41\ud8e9\ude69",
        12, 54040, 1957872109, -6891911480139890624L, -71856L, true, true, (char) 2888, (char) 43606,
        Double.longBitsToDouble(0x3fdfe2381c5dcbe4L), Double.longBitsToDouble(0x3fe8963b06dc0b90L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 3, "\udaee\udf42\udb4c\udc3c", "\u62f6\u57ee\uae46\u1658", "\ud8f1\udfbe\udacf\udf5b\ud9aa\udfd0\udade\uddb1\u4d5e\uda2d\udee2\udba1\udc4c\ud980\udf4c\ud998\udd09\ud891\udfe8\ud81f\udf0e\uda51\ude05\ud814\udcec\udb7f\uddba\uda6f\udcbf\udbc5\udd9b\udaaa\udc44\ucd63\ud825\udf37\udb7e\udd46\udaa3\udebc\u36e5\ud9dc\udec8\uda5c\udcb6\uda89\udf7e\ud8ea\udf50\uda54\udfb0\ud8dd\udedb\uda73\udf2e\uda88\udce2\udbc8\uded5\uda17\udfd4\udbf2\uddf1\udb06\ude28\ud8ed\udc40\ud925\udf0f\ud977\udf20\ud87f\uded2\ud847\udebf\udb4e\udd4a\ud964\udc38\ud824\udece\udb81\udd28\ud922\udd77\ud970\uddc8\ud955\udd07\udbbd\udc4c\uda38\udce7\ud9ff\uddd7\uda6f\udd16\udaed\uded8\udbc9\udc30\ud835\udfc5\uda1e\udd1e\uda5c\udee9\udb7e\udf24\uda0d\udcb4\ud89b\uddc9\udae2\udfa2\ud9cb\udce6\udb19\udfd9\ud8a3\udd1d\ud82a\ude4e\udb5e\udd1e\ud8dd\udf87\uda75\udf60\udac0\udea8\udac2\ude12\ud9b4\udec2\udbec\udecf\uda6a\udf36\udaf1\udf21\udb2e\udcaa\ud9d7\uddc1\udbe9\udd25\ud1f1\ud966\udc9f",
        21, 29650, 1846196085, 2517501136979603955L, -25036L, true, false, (char) 5559, (char) 35567,
        Double.longBitsToDouble(0x3fe2c14c225257ecL), Double.longBitsToDouble(0x3fc1f349da9ef18cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 3, 3, "\udaee\udf42\udb4c\udc3c", "\u62d8\ub2ba\u0cf1\u73f8", "\ud8c9\udef2\udacf\ude2e\ud9aa\udfd0\udade\uddb1\u4d5e\uda2d\udee2\udba1\udc4c\ud95a\udf6e\ud972\udd87\uda90\ude80\ud86e\udc58\udafb\udd34\uda8c\udec4\ud875\udf7b",
        56, 78546, 870395190, 7522875316977654913L, -83684L, false, true, (char) 19568, (char) 18276,
        Double.longBitsToDouble(0x3f9efc10fe948f00L), Double.longBitsToDouble(0x3fe2cc3d88ea2badL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 3, "\udaee\udf42\udb4c\udc3c\udb39\udcc5\ud90a\ude2c", "\uae46\u36a3\u05da\u2a77\u7712\u9864\u7452\u03a3\ud3bd\ubf0d\u602f\uce77\u8f63\u03a2\u8d88\u337e\u9523\u45f8", "\udb3e\udce6\ucdb1",
        21, -135, 1840758852, 2412078836275555040L, 66899L, false, false, (char) 61317, (char) 34954,
        Double.longBitsToDouble(0x3fdf143b8ff39698L), Double.longBitsToDouble(0x3fe414690e1b19b8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 4, 11, "\udb1b\udc51\ud80d\udede\udb38\udfe7\ud907\udfca\ud936\udec8\ud889\udc7e\ud95d\udf2c\udb8f\udf01", "\u62c4\u528d\ub291\u03a3\u3b33\u723d\u7887\ud3fe\u90d5\u9030\ub459\ucc92\u9236\u45f8\u96ec\ua18a\ucfa3\u6695", "\uaa6c\ud95c\udf8e",
        30, 16583, 578284429, -6581432696650543347L, -64419L, false, false, (char) 9914, (char) 34397,
        Double.longBitsToDouble(0x3fe13e4c8e1d58c2L), Double.longBitsToDouble(0x3feb5065626f2e72L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 11, "", "", "\ud936\udec8",
        30, 76384, -848898155, -2000023768373403707L, 31072L, false, false, (char) 44048, (char) 31485,
        Double.longBitsToDouble(0x3fcafa3740e5b57cL), Double.longBitsToDouble(0x3fc85ec20238647cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 3, "\udaee\udf42\udb4c\udc3c", "\u663f\u57ee\uae46\u6f32", "\ud8c9\udf1a\udacf\ude2e\ud800\udf37\udade\uddb1\u4d5e\uda2d\udee2\udba1\udc4c\ueb49\udbab\udc71\udaa4\udc59\ud97c\udd77\udb7a\udee5\ud814\udcdc\ud9c0\udfb7",
        6, 78549, 241904950, -1780563998780991556L, -88808L, true, false, (char) 36634, (char) 62224,
        Double.longBitsToDouble(0x3fb83b393b24e400L), Double.longBitsToDouble(0x3fd00ed73fa2244aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 2, 3, "\udaee\udf42\udb4c\udc3c", "\u663f\u57ee\uae46\u6f32", "\ud8c9\udf1a\udacf\ude2e\ud800\udf37\udade\uddb1\u4d5e\uda2d\udee2\udba1\udc4c\ueb49\ud84d\udfa3\u463d\ud97c\udd77\udb7a\udee5\ud814\udcdc\ud9c0\udfb7",
        6, 78549, 241904950, 225660889272899516L, -46510L, true, false, (char) 36634, (char) 62224,
        Double.longBitsToDouble(0x3fb83b393b24e400L), Double.longBitsToDouble(0x3fd00ed73fa2244aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 3, "\000", "", "",
        -5, 76384, -947078251, 2636702357412389031L, -100000L, true, false, (char) 54988, (char) 0,
        Double.longBitsToDouble(0x3fc8800000008fd8L), Double.longBitsToDouble(0x3e2c300000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 3, "\udaee\udf42\udb4c\udc3c", "\u596d\u585e\uae46\u8bac", "\ud8c9\udf1a\udacf\ude2e\ud800\udf37",
        16, 53930, 603372740, -3334256884703081257L, -62306L, false, false, (char) 8755, (char) 63061,
        Double.longBitsToDouble(0x3fb02816e8b1d698L), Double.longBitsToDouble(0x3fc0a391b4da2af4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 11, 11, 3, "\ud8f6\uddeb\u56c5\udb39\udcc5\ud907\udfca\ud93f\udfc8\ud92b\ude64\ud8d5\udcf9\u2073\ud8f5\udd04\ud870\ude3c\ud8c9\udf1a\uda20\uded6\ud9d3\udfaa\udb2c\uddaf\u4d5e\udb73\udfc5\ud8d5\uded5\udba6\ude7b\ud8c8\ude0e\u463d\ud9a6\ude9f\ud96a\udebc\udaaa\udea7\ud8a5\udc9b\udb59\udda5\udb4e\udeff\uda47\udc7c\ud9c2\udc6a", "\uc309\u3924\u9694\u6b75\ubf71\u4a76\u6633\u87d5\uae01\u6719\ua3a9\ua040\ud53e\u55ef\u587a\ucb98\u2541\u5bc9\u9cdf\ub2c9\u30eb\u0d89\u1666\u3037\u9229\u3da5\u668a\uc7c8\u56ae\u8f6f\u2277\ud30c\uc35f\u1836\u48d6\u0ceb\u40fa\u97c6\ub816\u1276\u7056\u1868\u0832\u7837\u51bd\uc28b\uac8d\u5732\u1280\u6b01\u0bbd\u9fbb\uc0a3\u6716\uc1d4\u1a1e\u3eb8\u3b32\u0d20\u70b4\u6fc0\u7cf9\u5892\uac27\uc5d7\u42ba\u7f0e\u8783\uc313\u36e7\u34c4\u3fa0\ub99f\ud1ba\u17b2\u7992\u6073\u7cae\u8738\u53e2\u09a7\ua093\u2307", "\ud8bc\udc1b\udae0\udd81\udb56\ude3b\ud90a\udf8a\ud936\udcad\ufb65\udacf\uddb7\udaa8\uded3\ud8a1\udf3d\uda47\udd50\udb6b\udc82\ue753\uda01\udfe0\ud82a\udded\uda05\udf7d\ud8c7\udf36\udb58\udc01\udbc1\udced\uda67\udfc6",
        0, 15819, 924535761, 2448948830410266972L, 93010L, true, true, (char) 44466, (char) 61955,
        Double.longBitsToDouble(0x3fcfc505ea0dfd14L), Double.longBitsToDouble(0x3fef3d21c52bbe17L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 3, "\udb03\udc97\uda94\uddbb", "\ud01f\u1d48\u3ea1\u8bac\u7672\ud1d0\u386b\u9864\ub1c3\u03a3\u81aa\u033d\u6366\u7446\u3e72\u257f\ub3b2\ucc92", "\uda19\ude10",
        20, 75804, 314151496, -7167702398161092808L, -23197L, false, true, (char) 64977, (char) 19859,
        Double.longBitsToDouble(0x3fcc392059710ab8L), Double.longBitsToDouble(0x3fd7d1fa3a1c58daL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Parser|setOptions|org.apache.commons.cli.Options|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processArgs|org.apache.commons.cli.Option,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processOption|java.lang.String,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|setOptions|org.apache.commons.cli.Options|new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
