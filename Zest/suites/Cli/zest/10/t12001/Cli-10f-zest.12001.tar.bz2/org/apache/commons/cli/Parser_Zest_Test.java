package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Parser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5\u0b5c\u9c26\ud599\uc505\ucc9e\u8d41\uaf04\u4b06\u8d00\u9556\u5719\u6042\u3372\ucac3\u97d0\ubc7d", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\ude39\ud8ff\udc79\uda53\uddf3\ud871\udc0b\ud9fa\udf85\u72fb\udba8\uddad\ud902\udcad\udb34\udf01",
        -4, 65368, -796719504, 1781192458734494534L, 28788L, true, true, (char) 15493, (char) 39720,
        Double.longBitsToDouble(0x3f8bbd47b81d6680L), Double.longBitsToDouble(0x3fea407368b53cf3L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5\u0b5c\u9c26e\uc505\000\u8d41\uaf04\u4b06\u8d00\u9556\u5719\u6042\u3372\ucac3\u97d0\ubc7d", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\udd5f\ud8ff\udc79\uda53\uddf3\uc06b\000\udbb8\udf5b\udba8\udd04\ud902\udcad\udb34\udf01",
        -4, 65368, -796719504, 1781173651072705350L, 28788L, true, true, (char) 15493, (char) 39720,
        Double.longBitsToDouble(0x3f8bbd47b81d6680L), Double.longBitsToDouble(0x3fea407368b53cf3L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5\u6503\u5c39\ud599\uc505\u2eef", "\ud998\udf85\uda54\udedb\udb39\udcb4\uda95\udd96\uda3f\udc06\ud85b\udd37\udb9d\udd99\ud994\udeca\udb94\udc43\uda69\udd21\udad4\udd4f\uda87\udd58",
        31, 53772, -1135816954, 9016425094549817636L, 47349L, true, true, (char) 7615, (char) 46352,
        Double.longBitsToDouble(0x3fe78ef3196b1d73L), Double.longBitsToDouble(0x3fcf3266e54218dcL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u72fd\uabac\u46f8\u28c2", "\uda13\ude5d\udb2d\udf23\ud8e6\ude44\udaa7\udc36\udbac\udca5\uda13\udf83\uda9e\udc1f\uda4c\udd1a\uda95\udd7a\ud994\udd51\ud889\udc0d\ud8e6\udfbf\ufee3\uda9f\udf3a\ud826\ude13\udae1\udc4f\ud99f\udd64\ud9cf\uddf6\udacc\uddce\uda78\udf43\udaf3\ude39",
        3, 55802, -1245331349, -4745114611755753575L, -74928L, true, true, (char) 44080, (char) 63111,
        Double.longBitsToDouble(0x3feea1acb91bd05bL), Double.longBitsToDouble(0x3fea30c5c467e60dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9b6\udca4\ud88d\udd32\udaa0\udf3e\udb92\udd3a\ud9a0\ude86\udb38\uddd1\uda85\udd19\ud897\udf3e\ud905\uddc8\udb98\udfc3\ud9f2\udf37\ud9de\udd2c\ud8e6\ude44\udaa7\udc36\udba5\udef4\uda13\udf83\uda9e\udc1f\uda4c\udd1a", "\u3372\ucac3\u97d0\ubc7d\ud449", "\ud9b6\udc28\udb2c\udeb1\ud9a0\ude76",
        43, 613, 62100301, -5463990121860568113L, 15204L, true, false, (char) 770, (char) 64475,
        Double.longBitsToDouble(0x3fd1bd08368c3170L), Double.longBitsToDouble(0x3fe62d1bc8eca1aaL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5", "\ud9f2\udf37\udb2d\udf23\ud8e6\ude44\udaa7\udc36\udbac\udca5",
        56, 35176, -771105840, 3174627491785948464L, 9001L, true, true, (char) 62175, (char) 50992,
        Double.longBitsToDouble(0x3feed5174a5418c5L), Double.longBitsToDouble(0x3fd1f33368986710L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 4, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5\u1b6e\u9b85\ud599\uc505\ucc9e\u8d41\uaf04\u4b06\u8d00\u9556\u5719\u6042\u3372\ucac3\u97d0\ubc7d", "\uda90\udffd\ud945\udc74\udb2c\udf0f\uda78\udf08\udaf3\ude39\ud8ff\udc79\uda53\uddf3\ud871\udc59\udade\uddf6\udaf3\udfb8\udba8\uddad\ud902\udcad\udb34\udf01",
        -4, 65368, -796719504, 1781192458734494534L, 94324L, true, true, (char) 15493, (char) 39720,
        Double.longBitsToDouble(0x3f8bbd47b81d6680L), Double.longBitsToDouble(0x3fea407368b53cf3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9f9\ude44\ud88d\udca8\ud964\ude16\ud848\udef6\uda2e\uddfd\udb38\uddd1\ud902\udcb8\udb8c\udcb7\ud8e6\udda8\u636a\ud974\udd18\uda8b\udd69\ud98a\ude4a\udaa6\udfb7\udbac\udca5\uda13\udf83\udabb\uddd3\uda10\udcf4\ud847\udeb2\ud994\ude19\ud85b\udd37\udb9d\udd99\udb7c\udc1e\udb94\udc43\uda69\udd21\ud84c\udc4c\uda81\ude11\ud9c9\udd72\udb5a\ude97\uda78\udfc3\udaf3\ude39\ud9ce\udde1\ud9bd\udf8f\ud99d\udf5d\ud9fa\udf85\u72fb\udba8\uddad\udab3\udf6b\udb34\udf01\udaaa\uddcb\ud96e\udcb0\uda28\udfa3\udbae\ude8f\ud831\uddd2\ud804\uddfc\ud9dd\uddb3\udaed\udeea\uda22\uddd0", "\u17fa\ua385", "\ud909\udcce",
        -3, 45925, -1587025658, -3749885866130114873L, -44489L, false, true, (char) 30479, (char) 64280,
        Double.longBitsToDouble(0x3fd10c7710064f5aL), Double.longBitsToDouble(0x3fa3f0e62d2004f0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u0ebd\u4236\u0b5c\u9c26\ud599\uc505\ucc9e\u8d41\uaf04\u4b06\u5d55\u9556", "\u00ba",
        1, 32369, 1016315058, -6707677758366572582L, -65921L, false, false, (char) 46037, (char) 33574,
        Double.longBitsToDouble(0x3fd247d20424711eL), Double.longBitsToDouble(0x3fbaee873b3dae28L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 8, "\ud8d2\ude81\ud88d\udd25", "\u3550\u94ac\u46f8\u1ad5\u0b5c\u9c26\ud599\uc505\u12ec\u91e9\uaed0\u4b06\u8d00\u9556\u5719\u3e3d\u3372\ucac3\u97d0\ubc7d", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08",
        58, 18468, -1172553198, -5348657417743370393L, -79856L, false, false, (char) 57758, (char) 31742,
        Double.longBitsToDouble(0x3fe62d1bc8eca1aaL), Double.longBitsToDouble(0x3fec0ab0d3051980L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5\u0b5c\u9c26\ud599\uc505\ucc9e\u8d41\u6f3e\u4b2a\u8d00\u9556\u5719\u6042\ucba9\ucac3\u97d0\ubc7d", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\ude39\ud8ff\udc79\uda53\uddf3\ud871\udc0b\ud9fa\udf85\u72fb\udba8\uddad\ud902\udcad\udb34\udf01",
        -4, 65368, -796719504, 1781192458734494534L, 28788L, true, true, (char) 15493, (char) 39720,
        Double.longBitsToDouble(0x3f8bbd47b81d6680L), Double.longBitsToDouble(0x3fea407368b53cf3L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 10, 0, "\ud9b5\udfd8\ud88d\udd32\ud964\ude16\udb92\udd3a\ud9a0\ude86\udb38\uddd1\ud902\udcb8\udb8c\udcb7\ud906\udfb8\udb98\udfc3\ud9f2\udf37\udb2d\udf23\ud8e6\ude44", "\u4b06", "\ud8ac\udfad\uda79\udeaa\ud85b\udd37\udb9d\udd99\ud994\udeca\udb94\udc43\uda69\udd21\udad4\udd4f\uda87\udd58\ud9b6\udc28",
        32, 28046, 2099300058, 4075556605588685330L, 33273L, true, true, (char) 46352, (char) 64852,
        Double.longBitsToDouble(0x3fd6b1d731f3266eL), Double.longBitsToDouble(0x3fd508637ce1ead6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 10, 1, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5\u0b5c\u239c\ud599\uc505\ucc9e\u8d41\uaf04\u4b06\u8d00\u9556\u5719\u6042\u3372\ucac3\u97d0\ubc7d", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\ude39\ud8ff\udc79\uda53\uddf3\ud871\udc0b\ud9fa\udf85\u7282\udba8\uddad\ud902\udcad\udb34\udf01\udaaa\uddcb\ud96e\udcb0",
        51, 9187, -1552325818, -6797529680055760660L, 40037L, false, true, (char) 22193, (char) 27770,
        Double.longBitsToDouble(0x3fea407368b53cf3L), Double.longBitsToDouble(0x3fa15dc9c9b6c0d0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\uda0c\udfa5\udb15\ude06", "\u34d9", "\udb8c\udcb7",
        43, 17569, -1344983963, 376400868479050503L, -74845L, false, false, (char) 42198, (char) 61016,
        Double.longBitsToDouble(0x3fe716904d302c0eL), Double.longBitsToDouble(0x3fdba4617c6feea6L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9b5\udfd8\u6bf9", "\u3550\u94ac\u46f8\u1ad5\u00cf\000\ua934\uc505\ucc9e\u8d41\uaf04\u426f\ub708\000\ua436\u6042\u3372\ucac3\u97d0\ubc7d", "",
        -5, -1000, 0, 0L, -99982L, true, false, (char) 44332, (char) 48830,
        Double.longBitsToDouble(0x3fed48000000de63L), Double.longBitsToDouble(0x3fd6b1d001f3266eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 4, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5\u0b5c\u9c26\ud599\uc505\ucc9e\u8d41\uaf04\u4b06\u8d00\u9556\u5719\u6042\u3372\ucac3\u97d0\ubc7d", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\ude39\ud8ff\udc79\uda53\uddf3\ud871\udc0b\ud9fa\udf85\u72fb\udba8\uddad\ud902\udcad\udb34\udf01",
        -4, 65368, -796719504, 1781192458734494534L, 40037L, false, true, (char) 22193, (char) 27770,
        Double.longBitsToDouble(0x3fea407368b53cf3L), Double.longBitsToDouble(0x3fcab5e9758797f4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud87b\ude03\ud88a\udc1f\ud964\ude16\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udb98\udfc3]] |a1=[Ljava.lang.String;:[[\ud87b\ude03\ud88a\udc1f\ud964\ude16\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udb98\udfc3]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 2, 6, 9, "\ud87b\ude03\ud88a\udc1f\ud964\ude16\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udb98\udfc3", "\ucc9b\u8d41\uaf04\u4510\u0df6\u52f5\u90b5\u6042\u3372\ucac3\u97d0\ubc7d\ud449\u9d81\ud44d\u0803\u5412\ucec8\u6327\u0326\u6bf2\u2e5e\ubaee\u9af5\ua085\u2299\u487c", "\udb13\ude07\udbae\ude8f\ud8b9\ude96\udb35\udd35\udb8d\uddac\udaec\udc19\ud92f\udc37\uda9b\udde2",
        29, 34048, 1016701453, -7721159357638559950L, -92799L, false, true, (char) 57970, (char) 18678,
        Double.longBitsToDouble(0x3fc190e702b6342cL), Double.longBitsToDouble(0x3feace2bdba08793L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\ub69b\uc072\uc830\u775b\u9c26\ud599\uc505\ucc9e\u8d41\uaf04\u4b06\u8d00\u9556\u5719\u6042\u8a5b\ucac3\u9f9d\ubc7d", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\ude39\ud8ff\udc79\uda53\uddf3\ud871\udc0b\ud9fa\udf85\u72fb\udba8\uddad\ud902\udcad\udb34\udf01",
        -4, 65368, -796719504, 1781192458734494534L, 28788L, true, true, (char) 15493, (char) 39720,
        Double.longBitsToDouble(0x3f8bbd47b81d6680L), Double.longBitsToDouble(0x3fea407369b53cf3L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 2, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u2a52\ucb04\uac97\u969f\u0b5c\uc4ae\u5c0f\u60ad\u2b0f\ua781\u7f54\u4b06\u269a\u1c40\ub5e7\u6042\u3372\ucac3\u2926\ua46b", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\ude39\ud8ff\udc79\uda53\uddf3\ud871\udc0b\ud9fa\udf85\u72fb\udba8\uddad\ud902\udcad\udb34\udf01",
        -4, 65368, -796719504, 1781192458734494534L, 28788L, true, true, (char) 15493, (char) 39720,
        Double.longBitsToDouble(0x3f8bbd47b81d6680L), Double.longBitsToDouble(0x3fea407368b53cf3L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 6, "\ud9b5\udfd8\ud88d\udd32", "\u5806\u94ac\u46f8\u1ad5\u0b5c\u9c26\uabd2\u579e\uccfb\u8d41\u7fd6\u6354\u883e\u9556\u5719\u8cff\u3368\ucac3\u22c7\u0c74", "\uda87\udd58\ud9b6\udc28\ud850\udfa3",
        23, 18853, 948914468, 5508819413035735699L, 6599L, true, false, (char) 64852, (char) 16094,
        Double.longBitsToDouble(0x3fb0490ddc7deb78L), Double.longBitsToDouble(0x3fe32fab591bd083L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud834\uddc7\ud88d\udc3c\ud964\ude16\udb92\udd3a\ud9a0\ude86\udb38\uddd1\ud902\udcb8\udb8c\udcb7\ud906\udfb8\udb98\udfc3\ud9f2\udf37\udb2d\udf23\ud8e6\ude44\udaa7\udc36\udbac\udca5\uda13\udf83\uda9e\udc1f\uda4c\udd1a\uda95\udd7a\ud994\udd51\ud85b\udd37", "\ubfd9\ud449\u1d36\u4406\uba32\u5412\ucec8\u6327\ucc2c\u8018\ub9a1\u7be3\uc9fc\ubbd2\u59d8\u487c\uc8a1\u14c6\u6627\u0e67\u3213\u64e4\u4ef8\u3dba\u13ae\u484f\u536f\u17fa\ua385\u36e7\u8112\u449c\u91f2\ud6f3\ub42c\u9251\uc479\u2ece\u5489\uc2b2\u585c\u5b32\ud043\ub9df\u2412\u6e97\u6040\uc130\u5118", "\ud842\udc61",
        -5, 44123, 948184246, 135643552990558716L, 71275L, false, true, (char) 38796, (char) 15119,
        Double.longBitsToDouble(0x3fda8269558bbb10L), Double.longBitsToDouble(0x3fea1ceaf399422cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u1822\ud23f\u46f8\u1ad5\u0b5c\u9c26\ud599\u2cf6\u1a0f\u29ea\u745a\u9aff\u8d00\u9556\u5719\u6042\u3372\ucac3\u97d0\ubc7d", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\ude39\ud8ff\udc79\uda53\uddf3\ud871\udc0b\ud9fa\udf85\u72fb\udba8\uddad\ud902\udcad\udb34\udf01",
        -4, 65368, -796719504, 1781192458734494534L, 28788L, true, true, (char) 15493, (char) 39720,
        Double.longBitsToDouble(0x3f8bbd47b81d6680L), Double.longBitsToDouble(0x3fea407368b53cf3L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 4, "\ud9b5\udfd8", "\000\000\000", "",
        -5, 17569, 1942236261, 16113160282415872L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd000000c6feea6L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u5092", "",
        -5, -1000, 0, 0L, -18379L, true, true, (char) 31577, (char) 18072,
        Double.longBitsToDouble(0x3fc2d3639c23b738L), Double.longBitsToDouble(0x3fee80944ae2d209L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 0, "\000", "", "",
        18, 16138, 1938207209, 3559753348898374817L, -99787L, false, false, (char) 63231, (char) 3762,
        Double.longBitsToDouble(0x3fc2d3639c23b738L), Double.longBitsToDouble(0x3fee80944ae2d209L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 0, "*\ud88d\udd32", "", "\ud902\udcb8",
        24, 77679, 2042289139, 8341841222187957973L, -59107L, true, true, (char) 59686, (char) 39213,
        Double.longBitsToDouble(0x3fdfc3b2a5fc5c60L), Double.longBitsToDouble(0x3fd302c0e174e812L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 7, 0, "\ud80f\uddb8\ud8ff\udd0b\uda98\udf43\uda14\udf2c\ud417\uda6a\udfe7\ud8cb\uddf5\ud990\udff9\uda16\udc74\ud88b\udd43\udb15\udf12\udaa1\udded\udb91\uddbb\udaa7\udc36\udbac\udca5\ud9a8\udeae", "\u2f18\ua4b3\u1cee\u8b95\u51ba\u4afc\uc84b\u5036\u7fa7\u5d28", "\ud9b6\udd3c\ud8ff\udc79",
        12, 70846, -1104831965, -4915573883692848576L, -43019L, true, true, (char) 63111, (char) 62826,
        Double.longBitsToDouble(0x3fd1bd00968c3170L), Double.longBitsToDouble(0x3fcffa46319e751cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9b6\udca4\ud88d\udd32\udaa0\udf3e\udb92\udd3a\ud9a0\ude86\udb38\uddd1\uda9e\ude80\ud897\udf3e\ud905\uddc8\udb98\udfc3\ud9f2\udf37\uda1b\udf26\ud8e6\ude44\uda74\udffc\u7169\uda13\udf83\uda9e\udc1f\uda4c\udd1a", "\u3372\ucac3\u97d0\ubc7d\ud449", "\ud9b6\udc28\udb2c\udeb1\ud9a0\ude76",
        43, 613, 62100301, -5463990121860568113L, 9883L, false, false, (char) 59578, (char) 28234,
        Double.longBitsToDouble(0x3fecee215dfb5a2aL), Double.longBitsToDouble(0x3fd9ad1642544016L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 2, 0, "\ud9b6\udca4\ud88d\udd32\udaa0\udf3e\udb92\udd3a\ud9a0\ude86\udb38\uddd1\uda85\udd19\ud897\udf3e\ud905\uddc8\udb98\udfc3\ud9f2\udf37\ud9de\udd2c\ud91d\udcc1\udaa7\udc36\udba5\udef4\uda13\udf83\uda9e\udc1f\uda4c\udd1a\u7418\ud994\udd51\ud85b\udd37\udb9d\udd99\ud994\udeca\udb94\udc43\uda69\udd21\udad4\udd4f\uda87\udd58\ud9b6\udc28\udb2c\udeb1\ud8db\udde1", "\u0fb0\ua80f\uce7b", "\udb67\ude79\uda50\udffc\udb37\udd48\ud96e\udd22\uda28\udfa3\udbae\ude8f\ud831\uddd2\udb35\udd35\ud9cb\udc4f\ud999\ude5f\udadf\udd74\uda23\udff6\ud928\udcd8\uda29\udd34\udb0d\ude92\ud9a9\udeb5\ud8a3\udc98\ud8b7\udfd4\ud911\udc48\udbf4\udf48\uda18\udd2b\ud8b1\uddec\udaa3\uddc9\udad2\udfc6\ud97b\ude85\udb7f\udd58\udb2d\ude03\ud97a\udc29\uda6e\udee4\udb6a\udfff\ud884\udd50\ud962\udfa1\ud8e6\udf69\ud8a1\udfcf\udbe9\udc4e",
        34, 34554, 2002896899, -2947968762480877146L, -17964L, true, false, (char) 38876, (char) 18472,
        Double.longBitsToDouble(0x3fb800bf09e2d180L), Double.longBitsToDouble(0x3fd6b5ebc57105b0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 4, 2, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5\u1b6e\u9b85\ud599\uc505\ucc9e\ubdf5\u9039\ud693\ud71e\u9556\u5719\u6042\u3372\ucac3\u8fd0\ubc7d", "\uda90\udffd\ud945\udc74\ud906\udd7c\uda78\udfb1\udaf3\ude39\ud8ff\udc79\uda53\uddf3\ud871\udc59\udade\uddf6\udaf3\udfb8\udba8\uddad\ud902\udcad\ud935\udfa1",
        51, 65433, -796719504, 1781192458734494534L, 94324L, true, true, (char) 15493, (char) 39720,
        Double.longBitsToDouble(0x3f8bbd47b81d6680L), Double.longBitsToDouble(0x3fea407368b53cf3L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 8, "\ud9f9\ude44\ud88d\udca8\ud964\ude16\ud848\udef6\uda2e\uddfd\udb38\uddd1\ud85d\udf00\udba0\ude6f\ud8f5\ude86\udacf\udd82\udb19\udd4b\ud9d6\udd83\ud98a\ude4a\ud9db\udc70\ud98b\udc59\uda13\udf83\udba7\udf2a\udbc1\ude78\ud84e\udeec\udab1\udee8\ud92c\udfe0\ud968\udd77\ud992\udc17\udb94\udc43\uda69\udce9\ud93f\udde5\ud88b\udc17\uda14\udd0d\udb5a\ude97\ud9ea\ude7b\udae6\udf58\udac3\udcde\ud9bd\udf8f", "\u3c68\ubb3a\u8f0b\uc3b3\u98a5", "\udbae\ude8f\ud84a\udc48\ud881\udfbd\udb3c\uddca\udacb\udee2",
        28, 89411, 1644372240, 1039758530967163723L, -47468L, true, false, (char) 48828, (char) 37480,
        Double.longBitsToDouble(0x3fec57c60baeeb53L), Double.longBitsToDouble(0x3fd83900e517211aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\ud9b5\udfd8\ud88d\udd32]] |a1=[Ljava.lang.String;:[[\ud9b5\udfd8\ud88d\udd32]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 4, 2, 6, "\ud9b5\udfd8\ud88d\udd32", "\u0eab\u94ac\u46f8\u1ad5\u0b5c\u4893\ud599\uc505\u2152\u8d05\u6f3e\u4b2a\u8d00\u9556\u5719\u6042\ucba9\ucac3\u97d0\u9956", "\ud965\udd18\ud9b6\udc28\ud8ae\udd09\ud894\udd7b\ud91c\udf99\ud988\udc4d\udbe7\udddb\ud871\udc19",
        50, 98249, 644053929, 181886157321116598L, -62009L, true, false, (char) 57758, (char) 31742,
        Double.longBitsToDouble(0x3fe62d1bc8eca1aaL), Double.longBitsToDouble(0x3fec0ab0d38c57acL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud87b\ude03\ud9c4\ude5c\udbef\udf7c\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udb98\udfc3]] |a1=[Ljava.lang.String;:[[\ud87b\ude03\ud9c4\ude5c\udbef\udf7c\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udb98\udfc3]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 9, "\ud87b\ude03\ud9c4\ude5c\udbef\udf7c\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udb98\udfc3", "\ucc9b\u8d41\uaf04\u4510\u0df6\u52f5\u90b5\u6042\u3372\ucac3\u97d0\ubc7d\ud449\u9d81\ud44d\u0803\u5412\ucec8\u6327\u41af\u781e\u2e03\u5ad2\u9af5\ua085\u2299\u487c", "\udb13\ude07\udbae\ude8f\ud8b9\ude96\udb35\udd35\udb8d\uddac\udaec\udc19\ud92f\udc37\uda9b\udde2",
        29, 34048, 1016701453, -7721159357638559950L, -92799L, false, true, (char) 45765, (char) 34776,
        Double.longBitsToDouble(0x3fc190eda2b6342cL), Double.longBitsToDouble(0x3feace2bdba08793L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udb95\udc1e\ud88a\udc1f\ud964\ude16\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udba3\udc74]] |a1=[Ljava.lang.String;:[[\udb95\udc1e\ud88a\udc1f\ud964\ude16\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udba3\udc74]] |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\udb95\udc1e\ud88a\udc1f\ud964\ude16\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udba3\udc74]] |a1=[Ljava.lang.String;:[[\udb95\udc1e\ud88a\udc1f\ud964\ude16\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udba3\udc74]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 2, 9, "\udb95\udc1e\ud88a\udc1f\ud964\ude16\udb92\udd3a\uda90\udefc\udb38\uddd1\ud825\udcaa\udb8c\udcb7\ud906\udfb8\udba3\udc74", "\ucc9b\u8d41\uaf04\u4510\u0df6\u52f5\u90b5\u6121\u50c7\u6895\ud33a\ubc7d\u1dc5\u42cc\uc63e\u29d1\u7d29\u21c0\u6327\u0326\u6bf2\u2e5e\ubaee\u9af5\u84ab\uc104\u4811", "\u99f2\udbae\udf3f\ud9a0\ude89\udacb\udc5c\ud884\udec5\udaec\udc2e\ud92f\udc37\uda9b\udde2",
        29, 12120, 1016691810, -7769956783190886600L, 10552L, true, true, (char) 8132, (char) 59320,
        Double.longBitsToDouble(0x3fe70e2bdf6f9ee7L), Double.longBitsToDouble(0x3fb2a927b37bcac8L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 11, 11, 8, "\ud9b5\udfd8\ud88d\udd32", "\u849e\u988f\uc072\uc830\u9461", "\udb2d\ude96\ud8e6\ude44\uda55\udcce\udbac\udc54",
        56, 79473, 1475734580, 3174557032344141104L, 9001L, false, true, (char) 62132, (char) 50992,
        Double.longBitsToDouble(0x3fe6d5174b9216e7L), Double.longBitsToDouble(0x3fd1de46a8981ab8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 0, "\udae1\udd3f\uda86\udf31\ud92f\uddc3\udb92\udd3a\ud9a0\ude86", "\u809a\u56e0\u14ea\u1606\u1507\u8b66\u8da4\u9953\u631a\u4ce5\uc3b0\u56bb\u4187\u8a5b\ucac3\u02b9\ubc7d\ud449\u736f\u999e", "\uda64\udd13\udae7\ude10\ud8ff\udc79\uda53\uddf3\ud871\udc0b\ud9fa\udf85\ud9b4\udf46\udbc6\udee2\ud902\udcad\udb65\udd28\udaaa\uddcb\ud96e\udcb0\uda28\udfa3\udbae\ude8f\ud831\uddd2\ud865\udecd\udb0d\udf11\ud8d3\udee6\ud907\ude60\uda9b\udde2\udaeb\uddd9",
        25, 1660, 1404230325, -2775385278785910552L, -30883L, false, false, (char) 30630, (char) 53847,
        Double.longBitsToDouble(0x3fe1f7ea4b4e0821L), Double.longBitsToDouble(0x3fc1b8c292eaed9cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 11, "\ud9b5\udfd8\ud88d\udd32", "\u3550\ub69b\uc072\uc830\u775b\u9c26\ud599\uc505\ucc9e\u8d41\uaf04\u4b06\u8d00\u9556\u5719\u6042\u8a5b\ucac3\u9f9d\ud4ab", "\uda88\udc32\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\ude39\ud8ff\udc79",
        -3, 98651, -1104808089, 4166406666430151593L, -79856L, false, false, (char) 57758, (char) 31742,
        Double.longBitsToDouble(0x3fe62d1bc8eca1aaL), Double.longBitsToDouble(0x3fd81561a60a32baL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud80f\uddf3\ud855\uddec\uda72\udfa2\uda14\udf2c\ud417\uda6a\udfe7\ud8ca\udcf5\ud990\udff9\uda16\udc74\ud8cc\udd63\ud9b3\udf74\udaa1\udded\udb91\uddbb\udaa7\udc36\udbac\udca5\ud9a8\udeae]] |a1=[Ljava.lang.String;:[[\ud80f\uddf3\ud855\uddec\uda72\udfa2\uda14\udf2c\ud417\uda6a\udfe7\ud8ca\udcf5\ud990\udff9\uda16\udc74\ud8cc\udd63\ud9b3\udf74\udaa1\udded\udb91\uddbb\udaa7\udc36\udbac\udca5\ud9a8\udeae]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 0, "\ud80f\uddf3\ud855\uddec\uda72\udfa2\uda14\udf2c\ud417\uda6a\udfe7\ud8ca\udcf5\ud990\udff9\uda16\udc74\ud8cc\udd63\ud9b3\udf74\udaa1\udded\udb91\uddbb\udaa7\udc36\udbac\udca5\ud9a8\udeae", "\025\ub427\u1cee\u9f23\u5fec\u4afc\uc84b\u5036\u7fa7\u5d46", "\ud9a7\udfdf\ud8ff\udc79",
        12, 70846, -1104831965, -4915573883692860608L, -43019L, true, true, (char) 63111, (char) 62826,
        Double.longBitsToDouble(0x3fd1bd00968c3170L), Double.longBitsToDouble(0x3fcffa46319e751cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 8, "\ud80f\uddb8\uda0c\udd90\udb63\udde1\uda14\udf2c\udbac\ude63\ud983\ude05\ud8cb\uddf5\ud990\udff9\uda16\udc74\ud88b\udd43\udb15\udf12\udaa1\udded\udb91\uddbb\udaa6\udfc3\udbac\udca5\ud9a8\udeae", "\u5712\uc43e\u1cee\u8b95\u3fb7\u65b7\uc7ee\u5036\u7fa7\u5d28\u4d1a\ucf03\ud5ea\ucc2c", "\ud9e3\ude41\udbc9\udff1\udae5\udd37\uda09\udf25\udb34\udf01\udade\udecb\udbec\udcf8\udb2c\udd32\ud944\udc66\uffdd\uda54\ude77\uda2e\udfbd\ud80d\udddc\uda8e\udc7b\ud946\udf18",
        23, 57707, -1034776421, 495858213159096396L, 87246L, true, false, (char) 11762, (char) 5695,
        Double.longBitsToDouble(0x3fef91e4f7595dfdL), Double.longBitsToDouble(0x3fd87a6ddad2fef8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 2, 5, "\ud9f9\ude44\ud88d\udca8\ud964\ude16\ud848\udef6\uda2e\uddfd\udb38\uddd1\ud85d\udf00\udba0\ude6f\ud8f5\ude86\ud830\udc53\udaed\udd0e\ud9d6\udd83\ud98a\ude4a\ud9db\udc70\uda67\ude87\uda13\udf83\udba7\udf2a\udbc1\ude78\ud84e\udeec\udab1\udee8\ud92c\udfe0\ud968\udd77\ud992\udc17\ud8df\udd2a\ud87f\udc4f\uda75\udf90\ud8aa\udec2\uda14\udd0d\udb5a\ude97\ud9ea\ude7b\udae6\udefd\udac3\udcde\ud9bd\udf8f", "\u3c68\ubb3a\u8f0b\uc3b3\u98a5", "\udbae\ude8f\ud91e\udc7b\ud881\udfbd\udb3c\uddca\udacb\udee2",
        28, 89411, 1644372240, 1039758530967163723L, -47279L, true, false, (char) 48828, (char) 37480,
        Double.longBitsToDouble(0x3fec57c60baeeb53L), Double.longBitsToDouble(0x3fd83900e517211aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3550\u94ac\u46f8\u1ad5\u0b5c\u9c26\ud599\uc505\ucc9e\u8d41\uaf04\u4b06\u8d00\u9556\u5719\u6042\u2b9b\ucac3\u97d0\ubc7d", "\uda87\udd58\ud9b6\udc28\udb2c\udeb1\uda78\udf08\udaf3\ude39\ud8ff\udc79\udbcf\udecf\ud95d\udf16\ud9fa\udf2e\u72fb\udba8\uddad\ud902\udcad\udb34\udf01",
        -4, 65368, -796719504, 1781192458734494534L, 28788L, true, true, (char) 15493, (char) 39720,
        Double.longBitsToDouble(0x3f8bbd47b81d6680L), Double.longBitsToDouble(0x3fea407368b53cf3L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud9b5\udfd8\udb7d\udc09]] |a1=[Ljava.lang.String;:[[\ud9b5\udfd8\udb7d\udc09]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 2, 10, 4, "\ud9b5\udfd8\udb7d\udc09", "\u2a52\ucb04\uac97\u969f\u0b5c\uc4ae\u5c0f\u60ad\u2b0f\ua781\u7f54\u4a9c\u269a\ua8e4\ub5e7\u6042\u3372\ucac3\u2926\ubcd7\ud7c8\u1d36\u6efc\uba32\u5412\ucec8\u6327\ucc2c\u7f3c\u5871\ua15a\u0ba2\ubbd2\u59d8\u487c\uc8a1\u14c6\u6627\u0e67\u659c\ub256\u4127\u3dba\u13ae\u484f\u536f\u17fa\u8bbb\u866f\u97fe\u6d40\ubad5\u5cfc\u1767\uccdd\u7151\uc067\u9478\ub2af\ucf29\u9485\u7023\u9583\u2c40\u1bcd\u7e66\ud405\u0e07\ucbb1\u748a\u8fa7\u72a9\u7b77\u8058\u518c\u88a7\u3157\u659a\ub9d2\ud495\u791e\u98d8\u8766\u25b3\u532e\ud6b2\u983f\u5d9a\u9644\u2d41\u38fa\u6dfd\u2c12\u57b9\u8981\u87ee\u2d67\u2d5c\u2538\u3606\u8d42\u10ef\u80ec\u1825\u699e\u4192\ub8c5\ubde0\u3398\u03d6\u64bb", "\ud8f9\ude5c\udbfb\udc71\ud8a3\udfeb\uaa0f\u7400\ud9d1\udce5\uda3b\udf5e\udb78\udd55\udbd9\udf2b\ud8af\udce6\udb57\udfab\ud8c3\udce5\ud846\udffb\u49a1\udac5\udd2a\ud81e\ude08\udae7\udf05\ud8ef\ude95\ud9e5\ude30\udbf4\udf43\ud838\udcf0\uc5a1\ud868\udd60",
        -5, 80120, 917692479, -2289365693864153149L, 43142L, false, true, (char) 7832, (char) 33538,
        Double.longBitsToDouble(0x3fd83ac39aaee6eeL), Double.longBitsToDouble(0x3fed6717282ba90eL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 4, 2, 0, "\ud9b5\udfd8\ud88d\udd32", "\u3531\u94ac\u2062\u797e\u69d2\u5c39\ud599\uac68\uac3a", "\ud8da\udef2\udb6e\udf08\uda58\udd68\udb81\udde9\uda3f\udc06",
        25, 90167, 909033369, -2241177766377649651L, -47183L, true, false, (char) 41649, (char) 44228,
        Double.longBitsToDouble(0x3fd488c855523d72L), Double.longBitsToDouble(0x3feb984bc5cc6f40L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Parser|setOptions|org.apache.commons.cli.Options|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processArgs|org.apache.commons.cli.Option,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processOption|java.lang.String,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|setOptions|org.apache.commons.cli.Options|new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
