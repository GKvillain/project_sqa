package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Util_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 1, 1, "\uda00\udf34\udb18\udfdd\udac0\uddb6\udb39\udeba\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udbb4\udc5c\u16f7\ud858\udc8e\ud8ab\udc38\udb00\udc87", "\u63be\ua432\u83e8\u2a35", "\ud97b\udf80\uda1b\udc1e\udb71\uddee\ud880\uddce",
        6, 51398, 1824356669, -1762711176585328046L, 45626L, false, true, (char) 21968, (char) 46027,
        Double.longBitsToDouble(0x3fe1d54f6e8bda2fL), Double.longBitsToDouble(0x3fcb1c6ad6a901acL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\udb69\udee7\012",
        Z.run(T, 1, 1, 1, 1, "\udb69\udee7", "\u0877\u8d74\u8353\ub58d\u9993\u633d\ub32f\u1b11\u0b2a\u1532", "\u60c8\ud88c\udc8f\ud824\udd9a\ud8b7\udf2b\uf3ae\ud97b\udf80\uda27\udfb0\ud9c5\ude58\ud880\uddce\uda70\udf30\ud850\uddbc\ud9f1\udfa5\ud86d\udddf\ud91f\udcd5\ud9e0\udf13\uda0a\ude92\ud8e6\udeab\udb43\udfc5\ud9bb\udc33\ud9f0\udfff\udad4\udc54\udb6f\udc4c\udabc\udeba\udbd6\udf54\udb6f\udfe0",
        33, 55942, -1412157633, -4049597451251610683L, 57237L, false, false, (char) 11723, (char) 46952,
        Double.longBitsToDouble(0x3fd1cbc9d255b096L), Double.longBitsToDouble(0x3feb1cb14187c77fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 1, 1, "\udac6\ude67\udb2b\udcb5\udac0\uddb6\udb39\udeba", "\u575f", "\ud858\udc8e\uda21\udc38\udb00\udc87\ud84f\udccf\ud97a\udfbd\udbd2\udc1a\u60c8\ud88c\udc8f\udbda\udcd5\ud8b7\udf2b\uf3ae",
        26, 26735, -328204522, -4555727988398285839L, 65571L, false, true, (char) 12764, (char) 52643,
        Double.longBitsToDouble(0x3fc8e29c556acbe8L), Double.longBitsToDouble(0x3fed9070f1463286L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 0, 1, "\uda10\ude18\u671b\udac0\uddb6\udb39\udeba\ud806\udefc\udb29\ude41", "\u8bfa\u5071\u5a1e", "\ud9de\udcca\udbd2\udcc8\u60c8",
        48, 89195, -409133893, 7892677942621521573L, -99766L, true, true, (char) 26295, (char) 53941,
        Double.longBitsToDouble(0x3fd3d77fff0cd868L), Double.longBitsToDouble(0x3fecaf3c4bb82e91L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 1, "\uda00\udfed\udb18\udfdd\udac0\uddb6\udb39\udeba\uda87\udf2b\uda23\ude3e\ud8fd\udfdc\udbb1\udd09\udbb1\udd99\udb50\udd05\ud887\udd29\udaf5\ude87\ud9f7\udcc3\ud9de\udcca\udbe1\udfe0\ud813\ude25\ud88c\udc71\udbda\udcd5\ud8b7\udf2b\uf3ae\ud97b\udf80\uda1b\udc1e\udb71\uddee\ud880\udd92", "\uabc1\u5c58\u7698\u6452\u2b1e\u0e16Q\u7b42\u9968\u1c93\u8d31\u4a3b\u4198\ub2c0\u76a3\u66ae", "\udac1\udfb6",
        54, 44639, -396717426, 1035077100609098325L, 88957L, false, false, (char) 50589, (char) 55484,
        Double.longBitsToDouble(0x3fe51a30af895e74L), Double.longBitsToDouble(0x3fc1de2c40b5de10L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 0, 0, "", "\ube3c\u0877\u0814\000\000\000\000\000\uc2f6\u0b2a\u1532\u909c\u63be\ua432\u83e8", "\udbb2\udee9\ud96a\udcf5\ud81e\udd3f\000\000\uda02\ude40\ud850\uddbc\ud9f1\udfa5\udbc3\ude14\ud901\udd08\000",
        -5, 1104, 847660978, -6202158974171611078L, -30541L, true, true, (char) 46750, (char) 19416,
        Double.longBitsToDouble(0x3fc94f0f5e5da374L), Double.longBitsToDouble(0x3fef10312ca75938L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\uda00\udf34\ud97a\udd0d\uda4e\udfca\udb39\udeba\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udb33\udd51\u16f7\ud858\udc8e\ud8ab\udc38\udb00\udc87\012",
        Z.run(T, 1, 0, 1, 1, "\uda00\udf34\ud97a\udd0d\uda4e\udfca\udb39\udeba\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udb33\udd51\u16f7\ud858\udc8e\ud8ab\udc38\udb00\udc87", "\u3701\u3708\ub3bc\ubf47", "\ud863\udfa4\ud855\udeba\uda09\udd46\ud893\udc84\ud9dd\udd45\ud850\uddbc\ud912\udebd\udbc3\ude14",
        37, 95608, -1302739162, 1017423576552589234L, -77274L, true, false, (char) 15407, (char) 44565,
        Double.longBitsToDouble(0x3fe22f2d000cc1b4L), Double.longBitsToDouble(0x3feaaf2d37cbc836L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\uda00\udf01\udb39\udded\ud89b\udc0d\012",
        Z.run(T, 1, 1, 0, 0, "\uda00\udf01\udb39\udded\ud89b\udc0d", "\ud7bd", "\u16f7\ud858\udc8e\ud8ab\udc38",
        13, 95856, 2142386500, 1212972205755468478L, -94101L, true, true, (char) 52220, (char) 21521,
        Double.longBitsToDouble(0x3fd3f8884e015202L), Double.longBitsToDouble(0x3fd88ec6f6000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=java.lang.String:\uda00\udf34\ud9f1\udfca\ud92a\ude63\udb39\udeb6\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udbb4\udc5c\u16f7\ud858\udc8e\ud8ab\udc38\udb00\udc87\012",
        Z.run(T, 2, 2, 1, 1, "\uda00\udf34\ud9f1\udfca\ud92a\ude63\udb39\udeb6\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udbb4\udc5c\u16f7\ud858\udc8e\ud8ab\udc38\udb00\udc87", "\uaf00\u8f62\u83e8\u2a35", "\ud97b\udf80\uda3a\udc7d\udb71\uddee\ud880\uddce",
        6, 51398, 1758492989, -1762711176585328046L, 45626L, false, true, (char) 21968, (char) 24871,
        Double.longBitsToDouble(0x3fe1d5cc768bda2fL), Double.longBitsToDouble(0x3fcb1c6ad6a901acL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 1, 0, "\uda00\udf34\udb18\udfdd\udac0\uddb6\udb4f\udf58\uda6d\udd24\udb94\udf16\udacb\udf47\udbb4\udc5c\u16f7\ud858\udc8e\ud8ab\udc38\uc420", "\uc5dc\u96c9\u83b3\u0dab", "\ud99d\udf87\uda1b\udc1e\ud8ec\udeee\ud880\uddce\uda09\ude31\ud850\uddbc\ud9f1\udfa5\udbc3\ude14\ud901\udd08\ud821\udd1e\uda0a\ude92\u462f\ud8c8\udeac\ud9bb\udc33\udb3d\udea7\uda5f\udcae\udba4\udfdf\udb71\udd43\ud933\udd8f\udb71\udcca\udbda\ude28\ud85b\udf06\ud88a\udc90\uea86\uda31\udc6c\udac2\udfcc\ud901\udd8a\ud97d\udf94\ud9e3\udee7\ud818\udd31\udbff\udc93\udb33\udf82\udb2b\udcac\uda56\ude41",
        5, 93210, -1413049027, 7755154092225209535L, 59249L, false, false, (char) 53101, (char) 53084,
        Double.longBitsToDouble(0x3febd67679e07aa0L), Double.longBitsToDouble(0x3fd3b1f36ba2a4d2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 1, 0, 1, "\uda00\udf34\udb18\udfdd\udac0\uddb6\udb39\udeba", "\u56fd\uce66\u8bfa\u5071\u1b25\u0b2a\u1532\u909c\u63be\ua432\u83e8\u2a35\u7834", "\udbff\udf64\udb71\ude42\ud880\uddce\ud964\udd50\ud850\uddbc",
        7, 49908, 772098642, -3180579586440575194L, 49426L, false, true, (char) 16423, (char) 55482,
        Double.longBitsToDouble(0x3fcb1c6ad6a901acL), Double.longBitsToDouble(0x3fecee3dda91462aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 1, 2, 1, "\uda00\udf34\udb18\udfdd\udac0\uddb6\udb39\udeba\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udbb4\udc5c\ud976\udd29\ud834\udd71\ud8ab\udc38\udb00\udc87", "\u63be\ua432\u83e8\u2a35", "\udab7\udd68",
        17, 44478, -1060713080, -849179283566584472L, 57818L, false, false, (char) 32189, (char) 39682,
        Double.longBitsToDouble(0x3fda4b259f641c3cL), Double.longBitsToDouble(0x3fb18ca1a0a0b360L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 2, 0, "", "\000\u5085\u0814\ud7bd\u575f\uce66\u8bfa\u5071\u1b25\u0b2a\u1532\000\000\000\u83e8", "\uf3ae\ud97b\udf80",
        55, 44478, -1060713080, 2753700419068021838L, 4326L, false, false, (char) 32189, (char) 39682,
        Double.longBitsToDouble(0x3fd5ab259f641c3cL), Double.longBitsToDouble(0x3fd46328607553daL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\uda3b\udfa3\udb18\udfdd\ud9ad\udfef\udb39\ude8f\uda6d\udd2b\udb29\ude41\ud900\udddd\udbb4\udc5c\ud978\ude04\ud857\udfc5\ud8ab\udc38\ud84a\udc8c\0121=java.lang.String:\uda3b\udfa3\udb18\udfdd\ud9ad\udfef\udb39\ude8f\uda6d\udd2b\udb29\ude41\ud900\udddd\udbb4\udc5c\ud978\ude04\ud857\udfc5\ud8ab\udc38\ud84a\udc8c\012",
        Z.run(T, 2, 0, 0, 0, "\uda3b\udfa3\udb18\udfdd\ud9ad\udfef\udb39\ude8f\uda6d\udd2b\udb29\ude41\ud900\udddd\udbb4\udc5c\ud978\ude04\ud857\udfc5\ud8ab\udc38\ud84a\udc8c", "\u63be\ua432\u83e8\u2a35", "\ud97b\udf80\uda1b\udc1e\udb71\uddee\ud9e4\udf7f",
        6, 51398, 1824356669, 3677187829171538557L, -61198L, false, true, (char) 43541, (char) 45936,
        Double.longBitsToDouble(0x3fe1d54f698bda2fL), Double.longBitsToDouble(0x3fcb1c6696a901acL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\uda00\udf34\udb18\udfdd\udac0\uddb6\ud97a\udff0\ud8dd\ude95\ud853\udc3c\uda2a\udc73\ud93e\udfdb\udbab\udf86\ud8f0\udc02\ud8b8\uddf9\uda88\udfcb\0121=java.lang.String:\uda00\udf34\udb18\udfdd\udac0\uddb6\ud97a\udff0\ud8dd\ude95\ud853\udc3c\uda2a\udc73\ud93e\udfdb\udbab\udf86\ud8f0\udc02\ud8b8\uddf9\uda88\udfcb\012",
        Z.run(T, 2, 1, 1, 0, "\uda00\udf34\udb18\udfdd\udac0\uddb6\ud97a\udff0\ud8dd\ude95\ud853\udc3c\uda2a\udc73\ud93e\udfdb\udbab\udf86\ud8f0\udc02\ud8b8\uddf9\uda88\udfcb", "\u1a20\u6870\u45dd\u4c39", "\ud90e\udedd\uda1b\udcd8\udb71\uddee\uda6c\udecb\ud974\udc36\ud8f1\udf65\udbe4\ude2e\udbc3\ude14\ud901\udd08\udbff\uddad\uda0a\udf41\u462f\udac3\udda8\ud918\udfef\udb2c\ude53",
        10, 75920, 141847852, -3456475740323485493L, 75789L, false, false, (char) 6552, (char) 14919,
        Double.longBitsToDouble(0x3fe35cab3fe02549L), Double.longBitsToDouble(0x3feb4f2ed3e7b49cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=java.lang.String:\ud8ec\udced\udb1a\udcf4\udac0\uddb6\udb39\udeba\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udbb4\udc5c\ud8f5\udda5\ud846\udc6f\ud80e\uddab\uda18\udf13\ud9ef\ude7c\udb63\uddce\udbd2\udcc8\u1a2b\udb7b\udeba\ud9d3\ude43\ud8db\udc68\udaf4\udfca\udbff\udd18\udaf7\uddde\uda93\ude23\ud880\uddce\ud945\udd37\ud850\uddbc\ud9f1\udfa5\udbc3\ude14\ud901\udd08\012",
        Z.run(T, 2, 2, 1, 0, "\ud8ec\udced\udb1a\udcf4\udac0\uddb6\udb39\udeba\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udbb4\udc5c\ud8f5\udda5\ud846\udc6f\ud80e\uddab\uda18\udf13\ud9ef\ude7c\udb63\uddce\udbd2\udcc8\u1a2b\udb7b\udeba\ud9d3\ude43\ud8db\udc68\udaf4\udfca\udbff\udd18\udaf7\uddde\uda93\ude23\ud880\uddce\ud945\udd37\ud850\uddbc\ud9f1\udfa5\udbc3\ude14\ud901\udd08", "\u3899\u24d2\u7bbb\u9968\u1c93\u8d31\u3f05\u5581\ua072\ub9ae\ud185\u0cc6\u7719\u7dbc\u0beb\ub36f\ub1c8\u0a09\u3f41\u9da4\u7009\ucb62\u5773\u0c16\u2626\u8ceb\u3372\u9d53\u155a\u37e1\ua0fa\uc80f", "\udb63\udcdd\udb2f\udf58\udb6c\udca9\udb09\udca9\ud864\udd35\ud884\udd77\uda85\udfe7\ud825\udc2f\ud8b5\udfcc\uda77\udc0c\ud9dd\uddfc\udb8c\ude40\ud89e\udf5d\uda08\uddef\ud89d\ude55\udada\udecb",
        44, 64175, 1433576601, -2808312118903434771L, 2710L, true, true, (char) 29093, (char) 1016,
        Double.longBitsToDouble(0x3fc4ba1c8ec72e8cL), Double.longBitsToDouble(0x3fb060018edcafb8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 1, 2, "\000", "\u8ff1\000\u441e\u1167\u8b70", "\ud8ab\udc38",
        55, 43136, 2142386500, 1152922376485208254L, 66626L, true, false, (char) 63939, (char) 43031,
        Double.longBitsToDouble(0x3fd88ec6f1e3818cL), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 1, "\uda00\udfec\udb18\udfdd\udac0\uddb6\udb39\udeba\ud97d\udd33\udb29\ude41\udb11\ude26\udbb7\uded1\u16f7\ud858\udc8e\ud8ab\udc38\udb00\udc87", "\u63be\ua432\u83c6\u2a35", "\udbdc\udcad\uda1b\udc1e\udb71\uddee",
        10, 97841, -731591602, 7835552229184083846L, -79592L, false, true, (char) 20403, (char) 21968,
        Double.longBitsToDouble(0x3fd463286c7553daL), Double.longBitsToDouble(0x3fe45ed178d8e356L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 1, 2, "\uda00\udf34\ud934\ude0a\uda25\ude72\ud91b\udd25\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udbb4\udc5c\u16f7\ud858\udc8e\ud8ab\udc38\udb00\udc87", "\u6326\ua432\u83e8\u2a35", "\ud97b\udf80\ud960\udc23\udb6a\udc27\ud880\uddce\u2732\uda72\uddd9\udb80\udecf\udbc3\uddde\ud901\udd08\ud821\udd1e\uda0a\ude92\u462f\ud8c8\udeac\ud9bb\udc33\ud9f0\udfff\uda5f\udcda\udb6f\udca3\u019c\ud98a\ude0f\ud9d1\udd9a\udb7e\uded7\ud8c7\udebf\udaee\udc50\ud9a4\udf96\udbc1\udc77\u2eae\udaf2\udd68\ud80b\udeab\udb37\udec6\u3043\ud890\udce5\ud804\udec7\udad9\udd63\ud83a\udc61\udba8\udd43\udbcb\udcea\udb62\udf6e\uda08\udfdf\u575b\udb07\udd6f\ud865\udeb4\ud992\udedf\ud90d\udf44\ud97d\udce3\ud8b7\udf25\ud935\udce8\ud922\ude92\ud98e\udfb7\udab5\udcbf\ud9ab\udc30\ud930\udfaf\ud983\udc63\udaa3\udd54\udbcd\ude80\uda60\udd9a\udbf9\udce0\ud991\udc34\ud964\udc56\ud998\udc36\udb8b\udd49\uda88\udc2d\ud947\udc64\ud92c\udc9a\ud934\udc6f\uda2e\udef2\udbee\udf72\ud949\udf1b\udb5c\ude44",
        10, 78122, -777836105, 321734850706636423L, 36565L, false, true, (char) 65106, (char) 64180,
        Double.longBitsToDouble(0x3fe201656c1183c3L), Double.longBitsToDouble(0x3fda63880626a47aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\udb69\udee7\012",
        Z.run(T, 1, 1, 1, 1, "\udb69\udee7", "\u0877\u8d74\u8353\ub58d\000\000\ub32f\u1b11\u0b2a\u00a0", "",
        32, 77308, -1549002997, 4691382285042617058L, 84862L, false, true, (char) 49399, (char) 33207,
        Double.longBitsToDouble(0x3fb38989c9eea320L), Double.longBitsToDouble(0x3fec3365ea1f6bb8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 1, 1, 1, "\000", "", "\000",
        -2, 39660, -1846329940, 5619453031357847555L, 77568L, false, true, (char) 55165, (char) 7059,
        Double.longBitsToDouble(0x3fec6333d70b112eL), Double.longBitsToDouble(0x3feaad1d62e2411bL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\u6fe1\012",
        Z.run(T, 1, 1, 1, 1, "\u6fe1", "", "",
        42, 63312, -2101668340, -7929926708617261374L, 20611L, false, true, (char) 45838, (char) 54987,
        Double.longBitsToDouble(0x3fe5f086af000000L), Double.longBitsToDouble(0x3fe85889700000acL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\u1290\u90a3\udb9d\uddb2\ud8a9\udd13\udb90\udcfa\u9c67\udbca\udd64\ud841\udeaa\udad5\udf2f\uda06\udf5a\012",
        Z.run(T, 1, 1, 1, 0, "\u1290\u90a3\udb9d\uddb2\ud8a9\udd13\udb90\udcfa\u9c67\udbca\udd64\ud841\udeaa\udad5\udf2f\uda06\udf5a", "\u1532\u0d1e\u372b\ua432\u83e8\u799d\177", "\uda27\udfb0\ud942\udd37\ud946\udd40\uda70\udf30\ud850\uddbc",
        39, 83958, 772129311, -3231150524248504538L, 6982L, false, true, (char) 39483, (char) 40039,
        Double.longBitsToDouble(0x3fee2e3e65c6e2d2L), Double.longBitsToDouble(0x3fc840da94359300L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\u0334\012",
        Z.run(T, 1, 0, 1, 1, "\u0334", "\u93f4\u8d2e\u8353\ub11c\u4cde\u6338\u7bc6\u836f\u5a96\ua5db\u9144\u63be\ua432\u83e8\u45c4\ud2f5\u3b5d\u241a\u8154\u5032\u2a99\u3d46\ucaf6\u221e", "\ud9e0\udf13\uda02\ude34\ud8a2\udea9\udb52\udfff\ud9bb\udc33\ud9f0\udfff\udad4\udc54\ud987\udf18\ud98f\udeba\ud87c\ude5d\udb6f\udf3a\ud953\udd9b\ud997\udca3\ud903\udce3\ud85d\udcc3\udbc8\udda6\udaeb\ude0f\udb71\udc01\u338a\uda6e\udd5e\udaa2\udd03\ud8ef\udf8f\ud989\udf73\ud9d6\udc0e\ud943\udc7b\udaf6\udfe9",
        43, 97551, 1946237425, -1598222072689371422L, -39784L, false, false, (char) 46046, (char) 17828,
        Double.longBitsToDouble(0x3f944a73d39eee60L), Double.longBitsToDouble(0x3fc60bbbe7f02424L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 1, "\udb69\udee7", "\uabab\u8d74\u8fc5\ud37f\u53e3\uc755\u9299\u1b11\u0bce\ub802", "\u60c8\ud8ab\udd8f\u5472\ud8b7\udeff\uf3ae\udb7f\udc3e\ud98c\udf1a\ud9c5\ude58",
        10, 68889, -731591602, 7835552231401774982L, -57597L, false, true, (char) 47027, (char) 54478,
        Double.longBitsToDouble(0x3fd46d076c7553daL), Double.longBitsToDouble(0x3fe45ed178815a56L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud831\udf64\ud91e\udcaa", "\u215a\u360b\u3a9c\u920c", "\udad6\udd88\u8376\ud9f7\udc40\ud9de\udcca",
        24, 50454, 288231246, -7589665936423183173L, -10235L, false, true, (char) 14303, (char) 28944,
        Double.longBitsToDouble(0x3fdf1c0c6325527eL), Double.longBitsToDouble(0x3fdfaffc1f0cd868L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 2, 2, 1, "\udae9\ude67\u663b\udac0\uddb6\udb39\udeba\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udbb4\udc5c\ud976\udd29\ud834\udd71\ud8ab\udc38\udb00\udc87", "\u63be\ua432\u83e8\u2a35", "\udab7\udd68",
        17, 44478, -1060713080, -849179283112158104L, 57818L, false, false, (char) 62976, (char) 39652,
        Double.longBitsToDouble(0x3fda4b259f641c3cL), Double.longBitsToDouble(0x3fb18ca1a0a0b360L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 0, 0, 0, "", "\uce2e\u084c\u0814\ud7bd\u7f60\uce66\ua95e\u4fa8\u1b25\ua381\u1532\u909c\u63be\ua432\u04b2\u2a35\177\u5fd3\u30ee?\u67e6\u0088\u9509\000", "\uda89\udc07",
        36, 40814, 236887386, 3615154613905097030L, -71926L, false, true, (char) 56845, (char) 50474,
        Double.longBitsToDouble(0x3fdf0dd5ae21c0c8L), Double.longBitsToDouble(0x3fe9787bfc6af361L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 1, 1, "\uda00\udf34\udb18\udfdd\udadf\udcac\udb39\udeba\uda6d\udd2b\udb29\ude41\ud8c0\udddd\udbb4\udc5c\udb48\udc19\uda94\ude32\ud9fc\uddc1\udad0\udddd", "\u63be\ua432\ua245\u15a1", "\ud97b\udf80\uda1b\udc1e\udb71\uddee\ud880\uddce",
        6, 51490, 1207597373, -1355606357754242090L, 45626L, false, true, (char) 21968, (char) 46027,
        Double.longBitsToDouble(0x3fe1d54f6e8bda2fL), Double.longBitsToDouble(0x3fcb1c6ad6a901acL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\u0334\012",
        Z.run(T, 1, 0, 1, 1, "\u0334", "\u93f4\u8d2e\u8353\ub11c\u4cde\u6338\u7bc6\u836f\u5a96\ua5db\u9144\u63be\ua432\u905a\ud1b7\ud2f5\u3b5d\u2382\u8154\u5032\u2a99\u3d46\ucaf6\u221e\u3f32\ub0aa\u8092\ua666\uaca1\u46c2\u7b42\u2972\u6a80\u5d11\u4afb\u4b14\u8258\ucb96\u7080\u374e\u4d77\ub213\u6df9\u2526\u97fb\ubb8d\u718c\u14fa\u138f\u7944\u18ac\u0ad5\ubb75\u4c0a\u4b6e\u4f34\ud171\u67df\uc617\u90d2\u1569\u9af8\u9df2\uaddd\u7f65\u3a7f\ud04c\u29b9\u8e68\u71a2\u4b3a\u1b24\u2ac5\ud65c\ubb2b\u971d\u17ee\uaa74", "\ud8ca\udf19\ud920\udc54\uda12\uddfe\ud868\ude34\ud8b8\udd68\ud9bb\ude44\udaa0\udee4\udbca\udc41\ud829\udf70\uda3f\udc8c\ud9a1\udf0f\uda04\ude49\udaac\udc19\ud86c\udf9f\uda19\udce1\udaab\udeee\udaf6\ude58\udac2\udce6\ud962\udcd7\ud8a8\udda7\ud94a\ude86\ud997\udd3e\ud9ab\ude69\uda65\udcf0\uda93\ude74\udac9\udd3e\ud826\ude26\uf0de\udbf7\udebe\ud9b5\udc27\ud96c\uddf4\ud914\ude3a\ud9af\ude88\ud99d\udfe8\ud8f1\udf53\ud8d6\udd71\ud91a\udebb\ud82b\udcb5\ud9e1\udd1c\u96d9\ud8f3\udc45\udba0\udf4f\ud9f7\uded6\uda03\ude9a\udbe9\udd0e\udaba\udfcd\ud92c\udf76\udb39\udf43\ud80a\ude6c\udbdb\udd80\ud938\udda0",
        30, 99875, 1304643497, -1707440380595720086L, 45754L, true, true, (char) 11913, (char) 40345,
        Double.longBitsToDouble(0x3fec8419900f99efL), Double.longBitsToDouble(0x3fe512c3705eec5eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Util|stripLeadingAndTrailingQuotes|java.lang.String|static",
    "M|org.apache.commons.cli.Util|stripLeadingHyphens|java.lang.String|static",
    "C|org.apache.commons.cli.Util|<init>|",
    "M|org.apache.commons.cli.Util|stripLeadingAndTrailingQuotes|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
