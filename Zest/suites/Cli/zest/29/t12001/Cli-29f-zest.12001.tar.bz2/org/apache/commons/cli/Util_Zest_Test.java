package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Util_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\udb12\udd26\uda62\uddb8\uda4a\udf54\uda96\udf5b\012",
        Z.run(T, 1, 0, 2, 2, "\udb12\udd26\uda62\uddb8\uda4a\udf54\uda96\udf5b", "\u0ca6\u0822\u46ab\ua9b2\u70ac\u92d9\ubd41\u87da\u46a5\u756e", "\ud905\udf2d\udbaa\udcfd\ud9db\ude17\udb44\udc05\ud9dd\udf02\ud980\ude76\udbe6\udd9c\ud881\udc7b\ud9e3\udda7\uda27\ude27\udbc6\udd27",
        35, 19394, -1111701355, -5677611886005290112L, -35043L, true, true, (char) 45172, (char) 8079,
        Double.longBitsToDouble(0x3fdfdeb921a1cd6eL), Double.longBitsToDouble(0x3faf6ef2144b2ff0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\udb12\udd26\uda62\uddb8\uda4a\udf54\uda96\udf5b\012",
        Z.run(T, 1, 0, 2, 2, "\udb12\udd26\uda62\uddb8\uda4a\udf54\uda96\udf5b", "\u0ca6\u0822\u46ab\ua9b2\u70ac\u92d9\ubd41\u87da\u46a5\u756e", "\ud905\udf2d\udbaa\udcfd\ud9db\ude17\udb44\udc05\ud9dd\udf02\ud980\ude76\udbe6\udd9c\ud881\udc7b\ud9e3\udda7\uda27\ude27\udbc6\udd27",
        35, 19394, -1111701355, -5677611886908142909L, -35043L, true, true, (char) 45172, (char) 8079,
        Double.longBitsToDouble(0x3fdfdeb921a1cd6eL), Double.longBitsToDouble(0x3faf6ef2144b2ff0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 1, "\udb12\udd26\uda62\uddb8\uda4a\udf54", "\ua9db\u995d\u892c\u1de1\ub2e3\ua342\ua47d\ubd41", "\uda8f\udf86",
        26, 85479, -1278276692, 8033316089855762422L, -86694L, false, true, (char) 60293, (char) 6175,
        Double.longBitsToDouble(0x3fe34d866af4af4cL), Double.longBitsToDouble(0x3fd3c365209b7596L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\udb12\udd26\uda62\uddb8\uda4a\udf54\uda96\udf5b\012",
        Z.run(T, 1, 0, 2, 2, "\udb12\udd26\uda62\uddb8\uda4a\udf54\uda96\udf5b", "\u0ca6\u0822\u46ab\ua9b2\u70ac\u92d9\ubd41\u87da\u46a5\u369e", "\ud905\udf2d\udbaa\udcfd\ud9db\ude17\udb44\udc05\ud9dd\udf02\ud980\ude76\udbf6\udc9c",
        17, 70769, 911407860, -4986684097938831283L, -544L, false, true, (char) 64085, (char) 2380,
        Double.longBitsToDouble(0x3fd5be319b81a39cL), Double.longBitsToDouble(0x3fdfdeb921a1cd6eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\udb12\udd26\ud918\uddbb\ud884\udf51\udbb6\uddf7\uda82\ude6b\ud89a\udffc\ud829\udd82\ud87b\udf05\012",
        Z.run(T, 1, 1, 2, 0, "\udb12\udd26\ud918\uddbb\ud884\udf51\udbb6\uddf7\uda82\ude6b\ud89a\udffc\ud829\udd82\ud87b\udf05", "\u70ac\u92d9\ubd41\u87da", "\ud8dc\uddc1\ud9ec\udf0e\ud905\udf2d\udbaa\udcfd",
        6, 70118, -1413991430, 1587687273211471230L, 29888L, false, true, (char) 19919, (char) 38974,
        Double.longBitsToDouble(0x3fc15fdae255b0e8L), Double.longBitsToDouble(0x3fe095ede380b135L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 0, 1, "\udb12\udd26", "\ub720\u2f86\u4bc5\u0ca6\u0822\u468b\ua9b2\u70ac\u92d9\ubd41\u87da\u46a5\u756e\u4dc3\u1e1d", "\udb3d\udc68\udb5a\udcf8\ud9dd\udf02\udb02\udd57\udb0d\udecc\udbb8\udc58\ud967\udedb\uda27\ude27\udbc6\udd27\ud823\udcf5\udaae\ude33\ud923\udcad\ud8fb\udd6d\ud997\uddfb\ud90b\uddc4\ud990\udeed\udb2f\udea1\ud842\ude75\udb2b\udc8b\ud9a3\udfb6\ud974\udeb9\ud923\udfb4\udb43\ude73\ud906\udca0\ud9a0\udf88\ud853\udec4",
        52, 3573, -2077760272, -748510529687456990L, -79795L, true, false, (char) 53688, (char) 42902,
        Double.longBitsToDouble(0x3fc78b79517560acL), Double.longBitsToDouble(0x3fc22c0785c975d0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\udaee\udea6\ud94b\uddab\ud8e2\uddb3\udbd8\udd25\uda2e\udfc5\ud86f\udd3f\ud829\udd82\ud87b\udf05\uda36\ude5f\udb2e\udc2d\ud82a\udeff\ud911\udf7b\udab7\udd44\udb59\ude32\udbe6\udc09\udb1b\udf8c\ud8ea\ude4d\ud9ec\udf0e\ud905\udf2d\udbaa\udcfd\ud9db\ude17\udb44\udc05\ud9dd\udf02\ud980\ude76\udbe6\udd9c\ud881\udc7b\ud9e3\udda7\uda27\ude27\udbc6\udd27\ud823\udcf5\udaae\ude33\ud923\udcad\ud8fb\udd6d\ud997\uddfb\ud9ee\ude95\ud8dc\udf90\ubfa4\ud95d\udeca\udb2b\udc8b\uda36\udc7f\ud983\udecd\012",
        Z.run(T, 1, 0, 2, 2, "\udaee\udea6\ud94b\uddab\ud8e2\uddb3\udbd8\udd25\uda2e\udfc5\ud86f\udd3f\ud829\udd82\ud87b\udf05\uda36\ude5f\udb2e\udc2d\ud82a\udeff\ud911\udf7b\udab7\udd44\udb59\ude32\udbe6\udc09\udb1b\udf8c\ud8ea\ude4d\ud9ec\udf0e\ud905\udf2d\udbaa\udcfd\ud9db\ude17\udb44\udc05\ud9dd\udf02\ud980\ude76\udbe6\udd9c\ud881\udc7b\ud9e3\udda7\uda27\ude27\udbc6\udd27\ud823\udcf5\udaae\ude33\ud923\udcad\ud8fb\udd6d\ud997\uddfb\ud9ee\ude95\ud8dc\udf90\ubfa4\ud95d\udeca\udb2b\udc8b\uda36\udc7f\ud983\udecd", "\ua403\u6fbb\u7e67\u3c77\u5918\u47b4\u62bd\ubcfd\u49c9\u39e5\u166e\u3bc2\ube0c\u58e0", "\ud84e\udf0b\uda0a\udd95\ud97e\udf01\udb5c\ude2d\ud9ca\uded9\ud854\udc9f\ud8fe\udd7e\udb4f\udc68\ud891\ude60\ud80e\udddf\udb6d\udd3d\udb05\udf14\udbf5\udc6c\udb09\udd7a\ud834\ude3a\ud8d6\ude27\uda9d\udebf",
        31, 60361, 1614194564, 2994880449833783619L, 98596L, true, false, (char) 40268, (char) 23956,
        Double.longBitsToDouble(0x3fe419dd7388e0d0L), Double.longBitsToDouble(0x3fded6c8cd026d82L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\udb12\udd26\uda4f\udc83\ud9dc\udc3b\udb2d\udc42\0121=java.lang.String:\udb12\udd26\uda4f\udc83\ud9dc\udc3b\udb2d\udc42\012",
        Z.run(T, 2, 0, 1, 2, "\udb12\udd26\uda4f\udc83\ud9dc\udc3b\udb2d\udc42", "\u45d5\u5c98\ud4f5\ua9ad\u70ac\u92d9\ucd40\u87da\u38a0\u756e", "\ud905\udf2d\udba8\udfae\ud9db\uddcb\udb44\udc05\ud9dd\udf02\ud958\udc22\ue3fb\ud881\udc7b\ud9e3\udda7\ud8ca\udc18\udbf3\ude0c\ud823\udcf5\uda85\ude05\ud8db\udf9c\ud8fb\udd6d\ud997\uddfb\ud980\udd3e\ud98f\udd09",
        13, 96835, -641839680, 864223307160101072L, 59420L, true, true, (char) 26861, (char) 20132,
        Double.longBitsToDouble(0x3fc8abc09eb2b544L), Double.longBitsToDouble(0x3fedc4052a9c4c28L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 1, 2, 2, "\udb12\udd26\udb29\udcbb\uda4a\udfc2\uda96\udf5b", "\u0ca6\u0822\u46ab\u26d9\u70ac\u212f\ubd41\u87da\u46a5\u756e", "\ud905\udf2d\udbaa\udcfd\ud94a\ude36\udb60\ude2b\udbd4\uddfa\ud980\ude76\udbe6\udd9c\ud881\udc7b\ud9e3\udda7\uda27\ude27\udbc6\udd27",
        15, 32781, -702933056, -4141150918557140096L, -35137L, true, true, (char) 45172, (char) 8079,
        Double.longBitsToDouble(0x3fdfdeb921a1cd6eL), Double.longBitsToDouble(0x3faf6ef2144b2ff0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 1, 2, 2, "\u00b1", "", "\000",
        14, -1000, 0, 1595510774L, -100000L, false, false, (char) 43149, (char) 61470,
        Double.longBitsToDouble(0x3fec862a8357a6bbL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\udb12\udcc4\uda8f\udf2f\ud828\udfe0\ud9c2\udf1c\ud92a\udd5d\ud89b\udc21\udad4\udfb9\012",
        Z.run(T, 1, 0, 2, 2, "\udb12\udcc4\uda8f\udf2f\ud828\udfe0\ud9c2\udf1c\ud92a\udd5d\ud89b\udc21\udad4\udfb9", "\uceef\u3404\ub258\ubd41\u6284\u2187\u756e\u4dc3\u0726\u8cd1\uc52f\u96f4\ucfa9\u3016\u4263", "\ud9e3\udda7\uda27\ude27\udb72\ude50\udb9b\udc62\udaae\ude5e\ud923\udcad\ud8fb\udd6d\ud997\uddfb",
        42, 36659, -484838603, -3328497284197233216L, -65409L, true, true, (char) 37372, (char) 19440,
        Double.longBitsToDouble(0x3fdc96f45a02e5feL), Double.longBitsToDouble(0x3fe7f78a12868b6bL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\udb12\udd26\uda62\uddb8\udac9\udd73\ud88c\udfb6\uda9c\ude4d\ud89a\udffc\ud829\udd82\ud885\udd82\uda36\ude5f\ud9f6\ude72\udadb\udd90\ud99c\udd1a\udbac\udec8\ud8f4\udf5c\uda06\udcdb\u42a6\ud8ea\ude4d\ud846\udffc\udbe2\ude71\ud84a\ude2d\ud9db\ude0d\ud8b8\udc20\ud871\udefb\ud980\ude76\uda0f\udcf9\ud9c8\udc8a\udaae\udeca\udab8\udfcb\uda4c\ude41\ud8e2\udf8c\udbb3\udd97\u4fdb\ud8fb\ude01\udb15\udfa3\uda15\udc36\ud8dc\udfa3\u5181\ud842\udea2\udb2b\udc8b\uda36\udc7f\ud93f\udc2b\012",
        Z.run(T, 1, 0, 2, 2, "\udb12\udd26\uda62\uddb8\udac9\udd73\ud88c\udfb6\uda9c\ude4d\ud89a\udffc\ud829\udd82\ud885\udd82\uda36\ude5f\ud9f6\ude72\udadb\udd90\ud99c\udd1a\udbac\udec8\ud8f4\udf5c\uda06\udcdb\u42a6\ud8ea\ude4d\ud846\udffc\udbe2\ude71\ud84a\ude2d\ud9db\ude0d\ud8b8\udc20\ud871\udefb\ud980\ude76\uda0f\udcf9\ud9c8\udc8a\udaae\udeca\udab8\udfcb\uda4c\ude41\ud8e2\udf8c\udbb3\udd97\u4fdb\ud8fb\ude01\udb15\udfa3\uda15\udc36\ud8dc\udfa3\u5181\ud842\udea2\udb2b\udc8b\uda36\udc7f\ud93f\udc2b", "\u4f58\ud529\uad4b\u19e1\u164e\u7cd9\ub301\u1239\ucda2\u772f\u72f6\u0fd0\u28f8\ua017", "\uda45\uddc6\ud8b3\udd75\ud857\ude9e\ud992\udfec\udaba\udf60\ud83e\udfee\ud8f1\udcd1\udad2\udf55\uda0f\ude3b\udb86\udc7d\udb71\udf96\uda29\udc63\uda1f\udf96\udae3\udf46\ud9cc\udcb4\ud9cd\ude2f\ud8e8\udec7\ud972\ude05\ud884\udec6\ud8b9\ude10\ud84b\udd3f\ud879\udcc7\ud9ac\ude40\ud8c5\udd93\uda88\udef7\udae0\udd21\ud842\udc8b\ud992\udcc2\ud810\udd76\ud9c3\udff8\ud985\udd93\ud8ed\udc8c\uda8a\ude6a\ud881\udc85\udbb6\ude63",
        58, 61518, -311625852, 3370332498132351534L, -59872L, true, false, (char) 57775, (char) 56698,
        Double.longBitsToDouble(0x3fd842fbb235bc26L), Double.longBitsToDouble(0x3fec06be1521f94bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\udada\udfab\012",
        Z.run(T, 1, 0, 2, 2, "\udada\udfab", "\ubdcd\uc973", "\ud86d\ude21\uda36\ude5f",
        6, 85618, -697808250, 9143458989849468303L, -39844L, true, true, (char) 24821, (char) 47261,
        Double.longBitsToDouble(0x3fe530e767f66f7cL), Double.longBitsToDouble(0x3fe87700b3fa106dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\000\012",
        Z.run(T, 1, 0, 1, 2, "\000", "\000", "\ud829\udd82",
        57, 19761, -1083683263, 6852666594745699206L, -76017L, false, false, (char) 61470, (char) 34016,
        Double.longBitsToDouble(0x3feabd35dbacfb31L), Double.longBitsToDouble(0x3fbb2ceebfb37800L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e2\ude84\uaa5e\ud88e\udc04\ud990\udff3\uda9c\ude4d\udb59\udf1a\udbc5\udfa1\ud9ef\udc66\0121=java.lang.String:\ud8e2\ude84\uaa5e\ud88e\udc04\ud990\udff3\uda9c\ude4d\udb59\udf1a\udbc5\udfa1\ud9ef\udc66\012",
        Z.run(T, 2, 0, 0, 2, "\ud8e2\ude84\uaa5e\ud88e\udc04\ud990\udff3\uda9c\ude4d\udb59\udf1a\udbc5\udfa1\ud9ef\udc66", "\u7f94\u9953\u614d", "\uda8f\uded8\ud862\ude69\ud9ec\udf0e\ud943\udd2c\udb4e\udcf6\ud91e\udebd",
        33, 84619, 369662250, -4685250500119996122L, 61136L, true, false, (char) 41599, (char) 22782,
        Double.longBitsToDouble(0x3fe1248c9ccac0e6L), Double.longBitsToDouble(0x3fe35fb21b3894b2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 2, "", "\u2246\ubdb6\uc332", "\ud87b\udef1",
        1, 19033, 0, 620756992L, -83504L, true, true, (char) 1758, (char) 50726,
        Double.longBitsToDouble(0x3fefb37be70ee000L), Double.longBitsToDouble(0x3fefd083692aabb8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udb12\udd26\uda62\uddb8\uda4a\udf54\uda96\udf5b\ud885\udde2", "\u5cca\u46ab\u9cf5\u0504\u5873", "\uda06\udcdb\uda8f\udf86\ud8ea\ude4d\ud9ec\udf0e\ud905\udf2d\udbaa\udcfd",
        6, 62590, -1517862776, 1655183934103594366L, 91982L, true, false, (char) 17713, (char) 64085,
        Double.longBitsToDouble(0x3fe9a8b0bd5be319L), Double.longBitsToDouble(0x3fc81a39c57fe1f0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\udb4a\ude44",
        44, 19638, 26132, 0L, -100000L, false, false, (char) 33636, (char) 24660,
        Double.longBitsToDouble(0x3fe7e02800000000L), Double.longBitsToDouble(0x3e3d600000000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:\ud817\udd33\uda62\udda9\uda4a\udf54\ud81a\udfc6\uda4e\udc1a\0121=java.lang.String:\ud817\udd33\uda62\udda9\uda4a\udf54\ud81a\udfc6\uda4e\udc1a\012",
        Z.run(T, 2, 1, 1, 0, "\ud817\udd33\uda62\udda9\uda4a\udf54\ud81a\udfc6\uda4e\udc1a", "\u0471\u0c66\u1dec\ua36f\ua47d", "\u38e0\udb95\udfa9\ud952\udc99\ud9ec\udf0e\uda07\udf2e\udbcd\udffd",
        13, 14654, 1268631466, 4462067954179672300L, -94595L, false, true, (char) 38510, (char) 37947,
        Double.longBitsToDouble(0x3fe124980d4aaa77L), Double.longBitsToDouble(0x3f8ce458ace6ac40L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 2, 2, 1, "\udb04\udc63\uda44\udf53\uda4a\udf54", "\ua9e4\u995d\u3295\u0595\u8c7f\u9f0e\uba33\ub613", "\uda8f\udf86",
        26, 85479, -1278276692, 8033316089855762422L, -86694L, false, true, (char) 60293, (char) 6175,
        Double.longBitsToDouble(0x3fee15866af4af4cL), Double.longBitsToDouble(0x3fd3c365209b7596L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\udb28\udd26\ud918\uddbb\ud884\udf51\udbb6\uddf7\uda82\ude6b\ud89a\udffc\ud829\udd82\ud87b\udf05\uda36\ude5f\uda70\ude9e\ud9ec\ude84\ud97d\udc31\udbac\udec8\ud8f4\udf5c\uda06\udcdb\ud893\udca7\u5cff\udaed\ude91\ud8ee\udd7a\ud89a\udc80\ud9db\ude17\udb44\udc05\ud9dd\udf02\ud980\ude76\udbe6\uddb6\udab9\udda2\ud922\udc6f\udb24\udd83\uda74\udd38\ud93b\udd99\udb05\uddbf\ud923\udcad\ud8fb\udd6d\ud85e\udc3f\ud8ab\udcf0\uda54\udd9d\ud865\udef3\udaae\udebe\udb55\udc5a\ud9ee\udcbd\udb58\udfad\udbff\udef5\ud91f\udee4\u7fa2\udad8\udc00\ud871\udff1\ud974\ude83\uda9e\ude34\ud82c\udd08\ud95a\udf34\ud941\uddc3\ud881\udebc\ud9d1\udf33\ud95a\ude4c\udac0\udc99\ud9ef\udc26\udbb3\uddd7\udbec\uddd0\udabd\udf4f\ud88c\udc59\udb55\udd31\udb7a\udd12\012",
        Z.run(T, 1, 0, 1, 1, "\udb28\udd26\ud918\uddbb\ud884\udf51\udbb6\uddf7\uda82\ude6b\ud89a\udffc\ud829\udd82\ud87b\udf05\uda36\ude5f\uda70\ude9e\ud9ec\ude84\ud97d\udc31\udbac\udec8\ud8f4\udf5c\uda06\udcdb\ud893\udca7\u5cff\udaed\ude91\ud8ee\udd7a\ud89a\udc80\ud9db\ude17\udb44\udc05\ud9dd\udf02\ud980\ude76\udbe6\uddb6\udab9\udda2\ud922\udc6f\udb24\udd83\uda74\udd38\ud93b\udd99\udb05\uddbf\ud923\udcad\ud8fb\udd6d\ud85e\udc3f\ud8ab\udcf0\uda54\udd9d\ud865\udef3\udaae\udebe\udb55\udc5a\ud9ee\udcbd\udb58\udfad\udbff\udef5\ud91f\udee4\u7fa2\udad8\udc00\ud871\udff1\ud974\ude83\uda9e\ude34\ud82c\udd08\ud95a\udf34\ud941\uddc3\ud881\udebc\ud9d1\udf33\ud95a\ude4c\udac0\udc99\ud9ef\udc26\udbb3\uddd7\udbec\uddd0\udabd\udf4f\ud88c\udc59\udb55\udd31\udb7a\udd12", "\u8d3c\u3a0e\uc0d7\u7a4e\u710d\uaa78\u55ab\u61de\ub2c0\u6048\u515a\u6b66\u6d4a\u5a06\u4674\u1bc7\u2b0c\ua212\u13bc\u8bf4\uc8b9\ub21c\u682b\u698d\uadce\u481b\u80c9\u26f3\ub1f2\u1c3b\u6a42\u5550\ua122\u0593\u5b6c\uaf55\u0308\u3db1\u93ac\ub2b8\ub9ea\uc508\u29d3\ub244", "\udb31\udf93\udb1e\udf3e\ud9cf\udd89\ud817\uddeb\ud8a1\udd6f\uacd0\udbb8\ude88\ud91d\ude09\ud924\udf3a\udac6\ude87\ud80a\udc8c\uda03\udc62\udb59\udf37\ud895\udce3\ud8cd\udca2\ud90e\udfc8\ud9b4\ude43\udb32\ude46\ud822\udc6a\ud8d8\ude89\ud819\udce9\ue499\ud93c\udfcb\ud947\ude36\u8f11\ud90c\udf1f\udb44\udddd\ud94d\udfba\ud936\udffe\ud80a\ude28",
        10, 6591, -1903875964, 1537566066582205170L, 55780L, false, true, (char) 17239, (char) 57981,
        Double.longBitsToDouble(0x3fe3100cb0a133dbL), Double.longBitsToDouble(0x3f97f6d400a71480L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 1, "\udb12\udd26", "\ua217", "\ud829\udd82\ud87b\udf05\u745e\uda88\udddb\uda93\udeef\ud995\udfa5\udbac\udec8\ud8f4\udf5c\uda06\udcdb\uda8f\udf86",
        2, 85599, -1279652948, 3969245135304487256L, -86694L, false, true, (char) 40160, (char) 49668,
        Double.longBitsToDouble(0x3fee9162b11a5567L), Double.longBitsToDouble(0x3fd3c36f509b7596L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 1, 0, 0, "", "\u2246\u6bde\u97b4", "\024",
        -5, 45737, 1595510774, -2959204128117102448L, -100000L, false, false, (char) 34016, (char) 39562,
        Double.longBitsToDouble(0x3fed67d98f6cb3baL), Double.longBitsToDouble(0x3fd583715003588aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 1, "\udb12\udccd", "\ub720\u2f86\u4bc5\u0ca6\u57ad\u46b0\ua9b2\u70ac\u461c\ucbb1\u87da\u46a5\u2fcd\ubee6\u1e1d", "\udb3d\udc68\udb5a\udcf8\ud9dd\udf02\udb02\udd57\udb0d\udecc\udbb8\udc58\ud967\udedb\uda27\ude27\udbc6\udd27\ud823\udcf5\udb2b\ude21\ud923\udca6\ud8fb\udd6d\ud997\uddfb\ud90b\uddc4\ud990\udf14\udb2f\udea1\udb01\udf6b\udb2b\udc8b\ud9a3\udfb6\ud974\udeb9\ud923\udfb4\udb43\ude73\ud906\udca0\ud9a0\udf88\ud853\udec4",
        52, 3573, -2077760272, -748510529687456990L, -79795L, true, false, (char) 53688, (char) 42902,
        Double.longBitsToDouble(0x3fc78b79517560acL), Double.longBitsToDouble(0x3fc22c0785c975d0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 0, "\ud817\udd33\uda62\udda9\uda4a\udf54\ud81a\udfc6\uda32\udc1a", "\u816a\000\000\u91cc\ua47d", "\000\000",
        -5, -1000, 0, 0L, 45494L, false, false, (char) 50667, (char) 43827,
        Double.longBitsToDouble(0x3fe7bec2e2f4af4cL), Double.longBitsToDouble(0x3fd3c365209b7596L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\u97b1\0121=java.lang.String:\u97b1\012",
        Z.run(T, 2, 0, 0, 0, "\u97b1", "\u82c5", "\ud829\udd82",
        7, 44233, -1258291200, 3265369505956540945L, -76017L, false, false, (char) 61470, (char) 34016,
        Double.longBitsToDouble(0x3fee7d35dbacfb31L), Double.longBitsToDouble(0x3feb659dd0000015L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\udb12\udd26\uda62\uddb8\uda4a\udf54\uda96\udf5b\012",
        Z.run(T, 1, 0, 2, 2, "\udb12\udd26\uda62\uddb8\uda4a\udf54\uda96\udf5b", "\u0ca6\u0822\u46ab\ua9b2\u7894\u92d9\ubd41\u87da\u46a5\u756e", "\udb78\ude2d\udbaa\udcfd\ud9db\ude17\udb44\udc05\ud9dd\udf02\ud980\ude76\udbe6\udd9c\ud881\udc7b\ud9e3\udda7\uda27\ude27\udbc6\udd27",
        35, 19394, -1111701355, -5677611886005290112L, -35043L, true, true, (char) 45172, (char) 8079,
        Double.longBitsToDouble(0x3fdfdeb921a1cd6eL), Double.longBitsToDouble(0x3faf6ef2144b2ff0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=java.lang.String:\udb12\udd26\ud462\ue18e\udac5\udeb6\udaab\uddb7\uda0c\udff5\ud829\udd82\ud87b\udf05\u745e\uda88\udddb\uda93\udeef\ud995\udfa5\udbac\udec8\ud8f4\udf5c\uda06\udcdb\uda8f\udf86\012",
        Z.run(T, 2, 2, 0, 1, "\udb12\udd26\ud462\ue18e\udac5\udeb6\udaab\uddb7\uda0c\udff5\ud829\udd82\ud87b\udf05\u745e\uda88\udddb\uda93\udeef\ud995\udfa5\udbac\udec8\ud8f4\udf5c\uda06\udcdb\uda8f\udf86", "\u8068\ua944\u861b\u7b79\u3016\u5cc2", "\ud9a5\udcda",
        7, 42132, -623556531, 5711767262322833819L, 85799L, false, true, (char) 32350, (char) 7356,
        Double.longBitsToDouble(0x3fecd9a10ed68f31L), Double.longBitsToDouble(0x3fe9cef509cd2c9bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Util|stripLeadingAndTrailingQuotes|java.lang.String|static",
    "M|org.apache.commons.cli.Util|stripLeadingHyphens|java.lang.String|static",
    "C|org.apache.commons.cli.Util|<init>|",
    "M|org.apache.commons.cli.Util|stripLeadingAndTrailingQuotes|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
