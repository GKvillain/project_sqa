package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Util_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e4\udc4b", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u25c4", "\udbe8\udcf5\uda54\udc2f\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2\ud96c\udf16\u56b9\ud94e\udf45\udb13\ude82\uda93\udf92\uc98a\udbda\udd1b",
        28, 27477, 436045010, 8806025928658935160L, 97130L, false, false, (char) 6772, (char) 10840,
        Double.longBitsToDouble(0x3fee7d7fabdb9e1aL), Double.longBitsToDouble(0x3fef31a8fdd4b88aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\ud90b\udc47\0121=java.lang.String:\ud90b\udc47\012",
        Z.run(T, 2, 0, 1, 1, "\ud90b\udc47", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u25c4", "\udbe8\udcf5\uda54\udc2f\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2\ud96c\udf16\u56b9\ud94e\udf45\udb13\ude82\udb83\udf0a\uca37\udbda\udd1b",
        28, 27477, 436045010, 8806025928658935160L, -33942L, true, false, (char) 28743, (char) 15892,
        Double.longBitsToDouble(0x3fee7d7fabdb9e1aL), Double.longBitsToDouble(0x3fef31a8fdd4b88aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 0, 0, 1, "\ud8e4\udc4b", "\u684e\u9d7f\u27a8\u60f5\uc5a6\u9cab\u7dfe\u25c4", "\uda28\udcf9\uda54\udc2f\ud804\ude00\uda33\udfb7\u8cd0\ud81a\udd4b\ud969\udcc0\udaa9\udd4e\ud9b2\ude0a\ud940\udf82\udb13\ude82\uda93\udf92\uc98a\udbda\udd1b",
        28, 27477, 436045010, 8806025929447464312L, 97275L, false, false, (char) 34470, (char) 10840,
        Double.longBitsToDouble(0x3fdcfaff57b66594L), Double.longBitsToDouble(0x3fef31a8fdd4b88aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 2, 0, 0, "\ud8e4\udc4b", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u958b", "\udbe8\udcf5\uda54\udc2f\uda26\ude91\ud9ed\udfec\udab8\udcfe\ud989\udd05\ud831\udee2\ud96c\udf16\u56b9\udb6e\udcd5\uda08\udcc9\udacb\udeda\uda8c\udd64\udbda\udd1b",
        28, 27477, 436045010, -6606261788291907377L, -82201L, false, false, (char) 51394, (char) 10840,
        Double.longBitsToDouble(0x3fee7d7fabdb9e1aL), Double.longBitsToDouble(0x3fef31a8fdd4f68aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 0, 1, 0, "\ud8e4\udc4b", "\u1475\u00d5\u279d\u6298\uc58d\u9cab\u7dfe\u25c4", "\udbc4\udda1",
        59, 61691, -1324938145, -3418423535645375989L, 10871L, true, true, (char) 55257, (char) 54062,
        Double.longBitsToDouble(0x3fd0046d7a725202L), Double.longBitsToDouble(0x3fa6249ff6653c70L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\udb22\udf1a\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 0, 2, 0, "\ud8e4\udc4b\udb22\udf1a", "\u9d7f", "\udbd3\udf01\udae9\udcfb\uda6e\udde2\ud844\ude7f\udbdb\udf84\udb54\uded6\u8a0f\uda54\udc2f\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\udb7a\udc66\ud96c\udf16\u56b9\ud94e\udf45\udb13\ude82\ud9aa\udcfa",
        9, 3767, 264678976, 8856413591459759314L, -76073L, false, true, (char) 10549, (char) 12684,
        Double.longBitsToDouble(0x3fdaca0c74806030L), Double.longBitsToDouble(0x3fee7d7fabdb9e1aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e4\udc4b", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u25c4", "\udbe8\udcf5\uda54\udc2f\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2\ud96c\udf16\u56b9\ud94e\udf45\udb13\ude82\uda93\udf92\uc98a\udbda\udd1b",
        28, 27477, 436045010, 8806025928658935160L, -18456L, false, false, (char) 52164, (char) 27125,
        Double.longBitsToDouble(0x3fef31a8fdd4b88aL), Double.longBitsToDouble(0x3feb752c5f180dafL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 1, 2, 1, "\ud8e4\udc4b", "\uc650", "\ud838\udcd0\udbd3\udf01\udae9\udcfb",
        39, 3013, -1022627530, -4919747550905069824L, -55432L, true, false, (char) 46409, (char) 61048,
        Double.longBitsToDouble(0x3feb790f2c2a7bafL), Double.longBitsToDouble(0x3fe2b786c52846d7L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 1, 1, 1, "\ud8e4\udc4b", "\ud4ec", "\ud838\udcd0\udbd3\udf01\udae9\udcfb",
        39, 3013, -1022627530, 2835290431484628820L, -86581L, true, false, (char) 21210, (char) 22135,
        Double.longBitsToDouble(0x3fe2275029173dc7L), Double.longBitsToDouble(0x3feb790f2c2a7bafL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\udb00\udc3f\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 1, 2, 1, "\udb00\udc3f", "\u48c5\u9d7f\u27a8\u6298\uc58d\u9c66\u7dfe\u25c4\ud0f7", "\uda54\udc2f\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2\ud96c\udf16\udb5d\udd8b\udb58\uddd4\udae9\ude0a\uda93\udf92\uc98a\udbda\udd1b\ud98e\udc54\ud8c4\ude7b\ud833\ude5a\udabc\udd20\udbe9\udd80\udbfb\uddd6\ud821\uddda\ud9a4\udefb\uda4b\udc81\ud9cf\udd88\ud9c9\udfb0\ud985\udddc\udb9e\udfaf",
        32, 20041, 1947823061, 3796708706066714445L, -47534L, true, true, (char) 25301, (char) 41760,
        Double.longBitsToDouble(0x3fa36bb1ec480fe0L), Double.longBitsToDouble(0x3fec4d8a2b6883ddL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 1, 1, 1, "\ud8e4\udc4b", "\u1475\u9d7f\u27a8\u6298\uc58d\ub953\u7db6\u25c4", "\udbe8\udcf5\uda54\udc2f\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2\ud96c\udf16\u56b9\ud94e\udf45\udb13\ude82\uda93\udf92\uc98a\udbda\udd1b",
        28, 27477, 436045010, 8806025928658935160L, 23953L, true, true, (char) 25861, (char) 44638,
        Double.longBitsToDouble(0x3fda26f6854b732cL), Double.longBitsToDouble(0x3fe671b9b67d5155L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e4\udc4b", "\u1475\000\u27a8\u6298\u85c8\u9cab\u7dfe\u25c4", "\udbe8\udcf5\uda54\udc2f\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2\ud96c\udf16\u56b9\ud94e\udf45\udb13\ude82\uda93\udf92\uc98a\udbda\udd1b",
        28, 18773, 0, 0L, 97130L, false, false, (char) 6772, (char) 64087,
        Double.longBitsToDouble(0x3fee7d7fabdb9e1aL), Double.longBitsToDouble(0x3fef31a8fdd4b88aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e4\udc4b", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u25c4", "\udbf8\udfc5\ud853\ude4a\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2\ud96c\udf16\u56b9\ud94e\udf45\udb13\ude82\uda93\udf92\uc98a\udbda\udd1b\ud98e\udc54\ud8d3\udc7b\ud833\ude5a\udabc\udd20\udbe9\udd80\udbfb\uddd6\ud821\uddda\ud9a4\udefb\uda4b\udc81\ud9cf\udd88\uf60a\ud9b7\udefc\udb9e\udfaf\ud84c\udd9b\udb86\udccc\ud854\udfc8\uda7e\ude4a\uda15\udcfb\udb15\udda6\udb67\udefd\udbef\udd7b\ud979\udcff\ud908\ude10\ud83d\udd46\udbe6\ude29",
        38, 8887, -371111637, 2524312678906541835L, -72024L, false, false, (char) 19096, (char) 29374,
        Double.longBitsToDouble(0x3fe149fae31bc2dfL), Double.longBitsToDouble(0x3fd5cf9995c44fb8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 0, "\ud8fa\udd4b\ud9d6\udf14", "\u417f", "\udab3\ude50\udafc\udd1b\udbfc\ude3e\ud812\udfa1\ud897\udd5e\udac8\udfb3\ud92c\udc58\ud95b\udd47\ud80f\uddbb\ud8f7\udfc9\udae3\ude85\ud99a\udcbf\ud831\udee2\ud973\udf3d\u3b27\ud94e\udf45\udb13\ude82\uda1f\udf98",
        58, 78133, 261603174, 8856413909876049106L, -76072L, false, true, (char) 4654, (char) 12684,
        Double.longBitsToDouble(0x3fdaca0c748061bcL), Double.longBitsToDouble(0x3fee7c6fabdb9e1aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\000\012",
        Z.run(T, 1, 0, 1, 1, "\000", "\u1475", "\ud838\udcd0\udbd3\udf01\udae9\udcfb",
        39, 3013, -1023410176, -4919747550905069740L, -20964L, true, true, (char) 8532, (char) 55257,
        Double.longBitsToDouble(0x3fe2b786c52846d7L), Double.longBitsToDouble(0x3fac9480c2c00000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 0, 2, 2, "\ud8e4\udc4b\ud9d6\udf14\ud96b\udce0", "\u6ae9\u0b1b\uc58d\u9cab\u7dfe\u25c4\ud0f7\u405e\u202a\uaa1d\u2c2f\u9ec5\u2f11\u9ffe\u3c05\ub943\u5207", "\ud9e5\udeb5\ud9d4\udc7a\ud854\udfff",
        28, 60021, 436044861, -3515822652454010879L, 97130L, false, false, (char) 6772, (char) 10840,
        Double.longBitsToDouble(0x3fee7d7fabdb9e1aL), Double.longBitsToDouble(0x3fef31a8fdd4b88aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 2, 1, "\ud8e4\udc4b", "\u1475\u1808\u27a8\u6298\uc58d\u9cab\u7dfe\u25c4", "\udbe8\udcf5\uda54\udc2f\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2\ud96c\udf16\u56b9\ud94e\udf45\udb13\ude82\uda93\udf92\uc98a\udaea\udeca",
        51, 27477, 436045010, 8806025928658935160L, 97130L, false, false, (char) 6772, (char) 10840,
        Double.longBitsToDouble(0x3fee7d7fabdb9e1aL), Double.longBitsToDouble(0x3fef31a8fdd4b88aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 1, "\ud905\udd26", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u242a", "\udbe8\udcf5\uda54\udc2f\uda73\udef4\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2",
        26, 85759, -254256086, 5104797562330805544L, -80227L, false, false, (char) 25578, (char) 55213,
        Double.longBitsToDouble(0x3fd48009812b8ba0L), Double.longBitsToDouble(0x3fc3170f86b2831cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud8e4\udc4b", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u25c4", "\udbe8\udcf5\uda54\udc2f\ud804\ude00\uda33\udfb7\ud905\udf20\udb08\ude56\ud831\udec2\ud89d\udcce\u56b9\ud94e\udf45\udb13\ude82\uda93\udf92\uc98a\udbda\udd1b",
        28, 27477, 426666194, -7496469118525612712L, -99478L, false, false, (char) 6772, (char) 10840,
        Double.longBitsToDouble(0x3fee7d7fabdb9e1aL), Double.longBitsToDouble(0x3fef31a8fdd4b88aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e4\udc4b", "\u1475\u9d7f\u4b0b\u2cbd\uc58d\u091d\u7d0b\u25c4", "\000",
        -5, -1000, -1325400064, -3418423535645375989L, -100000L, false, true, (char) 55257, (char) 54062,
        Double.longBitsToDouble(0x3fd2846d7a005202L), Double.longBitsToDouble(0x3fa6249ff6653c70L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=java.lang.String:\ud8e4\udc6d\ud9d6\udf14\ud96b\udce0\ud840\udda2\ud914\udef1\uff40\ud838\udcd0\udbd3\udf01\udae9\udcfb\ud859\udd96\ud988\udf70\udabe\udd36\012",
        Z.run(T, 2, 2, 1, 1, "\ud8e4\udc6d\ud9d6\udf14\ud96b\udce0\ud840\udda2\ud914\udef1\uff40\ud838\udcd0\udbd3\udf01\udae9\udcfb\ud859\udd96\ud988\udf70\udabe\udd36", "\uaa1d\u2c2f\u9ec5\u09ae\u9ffe\u3c05\ub943\uafc4\u4906\ua64c\u35c2\u1409\u2778\u0a21\u96e8\uab9f\u72c4\u7e2c\u0b2f\u4012\ua7bc\ub2ac\u1363\u67c7\u7ad1\u0b34\u5113\ua688\uab17\u9e8f\u1e88\u3789\u6127\u7e45\ud300\u2583\u3487\u0530\u620e\u3c8a", "\udbb1\ude48\ud924\udf75\ud8a6\ude8f\uda8f\udf87\ud9bd\udf5b\uda64\udfc0\ud9e8\udf0e\ud8ce\udcde\ud9a7\udd08\ud901\ude72\ud9b8\udc2e\udbec\udcdc\uda80\uddcc\ud9f0\udccb\ud974\uddcc\udbdf\udcbd\uda93\udd03\ud9a9\udd5a\ud998\uddb0\ud918\udd81\ud86b\udd52\ufbe1\uda7f\udedb\ud852\udfcc\ud9bb\udc52\udb60\udcfe\ud88b\udcde\u11e7\ud95d\udf6d\udb6d\ude01\ud969\udf15\ud91f\udcbb",
        53, 34409, 1997696499, -3512351777652283613L, -2736L, true, true, (char) 52238, (char) 43150,
        Double.longBitsToDouble(0x3fce50ace48dad6cL), Double.longBitsToDouble(0x3fe963bbcc285038L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 1, 1, 1, "\ud8e4\udc4b", "", "\udb9e\udf10",
        52, -1000, 1425379322, -7414543523315451523L, 60853L, false, true, (char) 33190, (char) 65040,
        Double.longBitsToDouble(0x3fb7c95d08000000L), Double.longBitsToDouble(0x3fe05e847b44ea05L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e4\udc4b", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u25c4", "",
        9, 13914, 628383691, -5690566002793819672L, -20964L, true, true, (char) 8532, (char) 55257,
        Double.longBitsToDouble(0x3fe2b786c52846d7L), Double.longBitsToDouble(0x3fd392901858927eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 2, 2, 0, "\udad8\udc5e", "\ua8c0\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u25c4\u0f31\u7754\uaa9c\u3254\u2c2f\u9ec5\u09ae\uc8ff\u3c05\ub943\u5207\ub233\ua64c\u35c2\u1409\u2f8e\ud60d\u96e8\u92bb\u72c4\u2308\u0be6\u7343\u49e0\ub2ac", "\ud9b7\udefc\uda8c\udf84\uda02\udc4b\udace\udff3\ud81a\udf47\ud8b8\udd40\udbc7\udf5c\ud933\udc2e\uda7d\udfdb\ud838\udc9d\ud8b9\ude1d\udb5a\udc1d\ud870\udf38\ud918\uddd9\uda00\udea2\ud945\ude1f\udb63\udf6e\uda36\udd07\ud8a0\udc95\udbb0\udda8\udb5d\udfc4\udb06\udd08\ud908\udc08\ud9bb\ude39\ud8c2\udcc1\ud8e9\uded0\udad0\udd59\ud823\ude04\udaa2\udc08\udbe4\udca1\u03f1\ud8c2\udcc7\ud8e4\udf80\udbe1\udefc\uda68\udf6e\uda93\udcfa\udab8\uddd8\uda5b\ude24\uda36\udfc5\udb26\udd81\ud9b3\udd3e\udba3\udf15\udb5d\udc15\ud8ac\udcba",
        41, 84534, -1161789657, -513339546000857422L, -51524L, false, false, (char) 9703, (char) 22084,
        Double.longBitsToDouble(0x3fc29d6273fc340cL), Double.longBitsToDouble(0x3feeb45b71462731L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\ud90b\udc47\0121=java.lang.String:\ud90b\udc47\012",
        Z.run(T, 2, 0, 1, 1, "\ud90b\udc47", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u25c4", "\udbe8\udcf5\uda54\udc2f\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud986\udd45\u4c71\ud80a\udff5\ud94e\udf45\udb13\ude82\udb83\udf0a\uca37\udbda\udd1b\ud98e\udc54\ud8d3\udc7b\ud833\ude5a\udabc\udd20\ud805\udf6f\udbf3\udcf0\ud8ed\udfd7\uda05\ude88\ud924\udcad\ud9cf\udd88\uf60a\ud9b7\udefc\udb9e\udfaf\uda97\udc3f\ud9ad\udcc1\ud866\udf6f\ud9c9\ude3f\ud9ba\udc3e\udb40\udfb2\ud9dd\ude7b\ud90b\udc72\udac0\udde1\udb12\udce2\uda11\udf16\u3f8b\udb9e\udc4b\udb6f\udfb1\ud56a\udbd7\udc9a\udb33\udef4\uda78\udd20\ud9ea\udc50\uda83\uddf4\udae1\udce2\ud9b6\udde9\ud91c\udc73\udb1d\ude1f\ud8c2\udea3\ud8ae\udd76\ud9d1\udf18\ud9db\udfdd\ud8ea\udcd7\udaba\udc88\uda2b\udc06\udb02\udede\udba4\udd55\udbc9\ude6d\udaff\udf14\ud9b1\udf25\ud9bb\uddf7\ud9e7\udf05\udab8\ude46",
        49, 42731, -1358522570, 8421108929994413879L, -92792L, false, true, (char) 47113, (char) 62756,
        Double.longBitsToDouble(0x3fe00dfed02f09fdL), Double.longBitsToDouble(0x3fdfa79854ac4ed6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 2, 0, 0, "\ud8e4\udc4b", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u1695\u7af2", "\uda84\udc21\uda45\ude70\uda26\ude91\udba3\udefa\udab8\udcfe\ud989\udd05\ud831\udee2\ud96c\udf16\u56b9\udb6e\udcd5\udbce\uddeb\ud8c2\uddcc\uda8c\udd64\udbda\udd1b\ud98e\udc54\ud8d3\udc7b\ud833\ude5a\udb66\ude80\ud977\udc12\udbe6\udeef\ud84f\ude49\u45fc\udb14\udf42\ud9cf\udd88\uf60a\ud9b7\udefc\ud8ef\udf57\ud81d\udcc2\ud8a6\udfa2",
        -4, 5498, 1900828987, 194921133421266695L, 27047L, true, false, (char) 49871, (char) 45389,
        Double.longBitsToDouble(0x3fe88ee8a2e4e36fL), Double.longBitsToDouble(0x3fd9a096bfa0b89aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=java.lang.String:\000\012",
        Z.run(T, 2, 2, 0, 0, "\000", "", "",
        1, 3275, -1928362552, 6121957570658320371L, -38250L, false, false, (char) 0, (char) 25856,
        Double.longBitsToDouble(0x3fee5cf22bea2f19L), Double.longBitsToDouble(0x3fe8c22056510000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud94e\udc40\ud931\ude1b\udbac\ude00\udbb9\udc1b\ud914\udef1\uff40\udaae\udc8a\udbd3\udecc\udae9\udcfb\udb84\udcde\ud948\udd39\ud990\udf9e\udbd5\udfa4\udbe8\udcf5\udbcd\udd63\uda26\uddde\ud9ed\udfec\udab8\udcfe\ud989\udd05\ud831\udee2\ud819\udeed\uda3c\udc79\udb6e\udd1b", "\u39cc\ubf42\u5c68\u92e9\ua83d\u033f\u6436\u6d91\u1dcb\u4600\u036b\u1307\u3cec\u7ad1\u8caf\ub291", "\udbfb\udf12\udb66\udef5\ud9ac\udf4e\udb9c\ude9f\udb31\udfdd\ud84b\udc6b\ud946\udf6b\ud9cc\udec4\ud8f1\udcb0\u605a\udb91\ude8a\uda9b\ude71\ud921\uddd8\udb92\ude0c\ud988\udd35\ud99d\udffd\uda74\udfc3\uda52\udf18\udae2\udf00\ud81e\ude77\ud9e2\udd4d\udb38\uddf9\ud938\ude72\ud859\udffc\u20a2\udbcb\ude4f\udad6\udef0\udab1\udfe5\ud9e8\udc12\ud88f\udd7a\uda45\ude2f\ud977\ude11\ud801\ude00\ue62e\ud926\udf58\ud8b1\uddd9\uda3f\udd63\ud8c3\udd38\ud894\udc57\uda84\udf28\ud9c6\ude00\ud93e\udf95\ud8a4\udc45\ud97b\udccb\ud9c1\udca5\ud8c5\udd7c\udbf9\ude7c",
        40, 48004, 1197523778, -5342792418965826385L, -43403L, false, false, (char) 29195, (char) 21861,
        Double.longBitsToDouble(0x3f80b8b973e14800L), Double.longBitsToDouble(0x3fe67b8f41484b5fL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\0121=java.lang.String:\ud8e4\udc4b\012",
        Z.run(T, 2, 0, 0, 1, "\ud8e4\udc4b", "\u1475\u9d7f\u27a8\u6298\uc58d\u9cab\u7dfe\u7e52", "\udb56\udd8c\uda0c\udf2b\ud804\ude00\uda33\udfb7\ud8fd\udf1c\ud99a\udcbf\ud831\udee2\ud96c\udf16\u56b9\ud94e\udf45\udb13\ude82\uda93\udf92\uc98a\udbda\udd1b\ud98e\udc54\ud8d3\udc7b\ud833\ude5a\udabc\udd20\udbe9\udd80\udbfb\uddd6\ud821\uddda\ud9a4\udefb\uda4b\udc81\ud9cf\udd88\uf60a\ud9b7\udefc\udb9e\udfaf\ub24b\ud8e3\uddeb\ud852\udcdd\udbf6\udcf3\ud836\udf48\ud8e7\udd5b\ud90a\udccf\udb5c\udddd\ud858\udcfa\udb8a\udce5\ud816\udde7\ud9ad\udc48\udbfd\udeff\udb34\udd8e\ud81d\udfd4\ud8ba\udc25\ud921\ude8f\ud8c1\udf2a\uda5a\udd9b\uda37\udd3d\udbc6\udc30\ud905\udd1b\ud993\udccd\ud854\udd53\udafb\udd7f\ud8e2\udc2e\udbfe\udfa3\udb0f\udd98",
        -1, 73603, -615064305, 7406090086653962325L, 10056L, true, true, (char) 59628, (char) 50707,
        Double.longBitsToDouble(0x3fef255cbf8178c4L), Double.longBitsToDouble(0x3fed9ecfa91d89fcL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e4\udc4b\udb33\udf1a\uda55\udcd5\ud840\udda2\ud914\udef1\uff40\ud838\udcd0\udbd3\udf01\udae9\udcfb\uda6e\udde2\ud99a\udd4b\udb27\uddd3\udb54\uded6\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 0, 2, 1, "\ud8e4\udc4b\udb33\udf1a\uda55\udcd5\ud840\udda2\ud914\udef1\uff40\ud838\udcd0\udbd3\udf01\udae9\udcfb\uda6e\udde2\ud99a\udd4b\udb27\uddd3\udb54\uded6", "\u2c2f\u9ec5\u09ae\u9ffe\u9d85\ub943\u5207\ub233\ua64c\ub75a\ubd32\u2d70\ub9ac\uaa91\u1209\u5c48\u7e2b\u7c56\u510c\ua7bc\u6099\u3ce7\u5297\u0d82\u189d\ub8ef\u6756\u8e55\u7f6c\u2f5d\u3c22\uc48e\u1aad\u52a7\u6c00\u4fa1\u4c98\u8b4a\u7594\u5d5d\u1e5a\uc9a3\u1ef0\u8c23\ucb22\ubf0e\u5776\u5d61", "\ud888\udd0f\ud8e3\ude36\ud96c\ude1a\udb6b\ude90\uda88\udec4\udbe6\udeb8\udb92\udd4f\ud8e5\udfc0\udb21\uddec\ud83a\ude36\udb9b\udcc5\uda1c\udf49\ud899\udf4c\ud864\udc41\ud99b\uddbc\ud923\ude94\ud90a\udf08\udad5\udfbb\ud959\udc76\uda97\udd7d\ud932\udd7e\udb01\ude69\ud849\udc46\uc7b1\udba4\udd8e\u2f95\udb56\udc92\ud8a5\udccd\udaa6\udc55\uda76\udf8c\ud862\udf87\ud993\udf41\ud916\udcf4\uda93\udebb\ud9a9\udecd\ud97b\udd82\udbba\udf88\ud883\udd6e\ud9ea\udfe0\ud833\udc22\udbfc\udff1\ud85e\udf76\uda26\udf51\u36e1\u6a3f\ud8de\ude96\uda0c\ude97\udbef\uded8\uda38\ude9f\udacd\udc63\ud825\udde4\uda91\udfda\udaaa\ude38\uda0a\udc75\udb59\udda1\uda73\uddd5\uda34\uddd8\uda59\udc49\uda85\udd01\ud8a4\udfb5\udafe\ude16\ud863\udceb\ud964\ude04\ud84b\ude50\udabe\udfa2\udb87\udd95\ud92f\udf02\udbce\udf58\udacd\udf46\ud926\udf24\ud807\udea2\ud84b\udd3f\uda0a\udd81\u0248\uda9f\udf09\ud8b4\uddce\ud55c\ud8bd\udda7\ud8f7\udce9\ud9e2\udf9b\uda79\udf30\u50b4\udb3a\ude2a\udbec\udf10\ud9c9\udffa\udaab\udde8\uda31\ude9b\udb47\ude2f\udb93\udfdc\ud9ff\ude9b\ud934\udc93\ud8e2\udf13\uda2f\uddd9\ud82c\udc14\ube53\udb4f\ude2e",
        28, 25048, 1242081620, 8340954956285030466L, -93426L, false, true, (char) 36935, (char) 33419,
        Double.longBitsToDouble(0x3fcb55c2d912405cL), Double.longBitsToDouble(0x3fe679091e7559c3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Util|stripLeadingHyphens|java.lang.String|static",
    "M|org.apache.commons.cli.Util|stripLeadingAndTrailingQuotes|java.lang.String|static",
    "C|org.apache.commons.cli.Util|<init>|",
    "M|org.apache.commons.cli.Util|stripLeadingHyphens|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
