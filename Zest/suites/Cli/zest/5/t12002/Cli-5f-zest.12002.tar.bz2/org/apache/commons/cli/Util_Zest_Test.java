package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Util_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46\012",
        Z.run(T, 1, 1, 1, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46", "\u15dd\u8340\ua581\ub7b5\u71c7\u5781\ub9e6\u16a9\u4a6c\u942f\ud44d\u1bf7\uc165\u6c35\ud7e4\uc13e\u16be\u1969\ua75e\u03da\u8748\u9a25\u4e92\ua6cd\ucc61", "\ud8f8\uddd2\ud8d7\udf07\ud94b\udf63\ud800\udc97",
        56, 30209, -290941864, 5573086981389932059L, 24971L, false, true, (char) 13981, (char) 36577,
        Double.longBitsToDouble(0x3fa007e2e2574970L), Double.longBitsToDouble(0x3fdaed98115bd8beL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\ud8c1\udcb5\ud929\ude46\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\uef24\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46\012",
        Z.run(T, 1, 1, 1, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\ud8c1\udcb5\ud929\ude46\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\uef24\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46", "\u15dd\u8340\ua581\ub7b5\u71c7\u5781\ub9e6\u16a9\u4a6c\u942f\ud44d\u1bf7\uc165\u6c35\ud7e4\uc13e\u16be\u1969\ua75e\u03da\u8748\u9a25\u4e92\ua6cd\ucc61", "\ud8f8\uddd2\ud8d7\udf07\ud93b\ude32\ud800\udc55",
        56, 30209, -290941864, 5573086981389932059L, 24971L, false, true, (char) 13981, (char) 36577,
        Double.longBitsToDouble(0x3fa007e2e2574970L), Double.longBitsToDouble(0x3fdaed98115bd8beL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udafa\ude69\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46", "\u15dd\u8340\ua581\ub7b5\u71c7\u5781\ub9e6\u16a9\u4a6c\u942f\ud44d\u1bf7\uc165\u6c35\ud7e4\uc13e\u16be\u1969\ua75e\u03da\u8748\u9a25\u4e92\ua6cd\ucc61", "\ud8f8\uddd2\ud8d7\udf07\ud94b\udf63\ud800\udc97\udbe8\udcb7\udb81\ude06\ud95a\udf52\udb44\udda3",
        25, 35246, -1115809835, 4405226148367300987L, -96334L, true, false, (char) 5330, (char) 58457,
        Double.longBitsToDouble(0x3fed1a4698fcc143L), Double.longBitsToDouble(0x3fd8a109b238232aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 2, "\udb3e\udfde\udb0c\udd9b\udbfe\ude90\udb46\udc30\ud8c8\udf0d\ud826\udebc\uda27\ude72\ud80c\udf95\ud82e\udc0c\ufa54\ud931\udfbd\ud80d\ude9a\ud942\udd30\ud9f5\udd08\ud9da\udda5\ud93b\udd4d\ud860\udd39\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud875\udea9\ud8f4\udc13\ud970\udd5b\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb1\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46", "\u4030\u8340\uba3f\uc2f0\u728b\u5781\ub9e6\u16a9\u4a6c", "\ud83b\udcb2",
        24, 74551, 1526978012, -458406739561903918L, 74660L, false, true, (char) 60060, (char) 58015,
        Double.longBitsToDouble(0x3fd7e2d5ede7c868L), Double.longBitsToDouble(0x3fc0151f94fe8c9cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udbef\udf9c\012",
        Z.run(T, 1, 1, 1, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udbef\udf9c", "\u5e29\ubc49\u8aac\u8275\u2107\u67ce\u4f72\u0988\uc1d0\ub67d\u632a\u8114\u19f4\uc83a", "\ud9cb\udc2a",
        40, 71025, -1301406377, 9056087376800636601L, -95897L, false, true, (char) 5421, (char) 3231,
        Double.longBitsToDouble(0x3f87da79b9e86680L), Double.longBitsToDouble(0x3fd9f7596f2651a8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\uda77\udd1f\udb17\ude12\udbeb\udd79\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\uda9c\udc3a\udb7f\udc4f\ud875\udf53\012",
        Z.run(T, 1, 1, 1, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\uda77\udd1f\udb17\ude12\udbeb\udd79\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\uda9c\udc3a\udb7f\udc4f\ud875\udf53", "\u9991\u15dd\u8340\ua581\ub7b5\u71c7\u5781\ub9e6\u16a9\u88ef\ucbe3\ub182\u1bf7\uc165\u6c35\ud7e4\uc13e\u16be\u1969\ua75e\u03da\u8748\u9a25\u64cb\uc0aa\uad2f\u137a\u908c\u57d2\ud674\u5053\u3c05\u706d\u8ee8\u4fca\u80bf\u3af7\u6c3f\ua901\u124d\u1ecc", "\ud8dc\udfe0\udbac\udc85\ud8de\udfd3\udb80\udcaa\udb80\udda1\udaac\udefc\udaf8\udc42\ud987\uddff\u23b1\u1cc3\ud8eb\udcb6\ud894\ude91\udaaa\udd02\ud86c\udc09\ud8da\udfa2\udab2\udd92\ud80d\udd86\udb8a\udebb\uda33\udd4e\udac0\ude82\ud96a\udefe\ud966\udeab\uda32\udff6\ud8a4\udf18\uda3c\ude17\udbae\udd48\udad8\ude60\udae2\uddd8",
        22, 45810, 1553198065, 1434812111850171621L, 67611L, true, true, (char) 24384, (char) 45560,
        Double.longBitsToDouble(0x3fec58b83fb7456eL), Double.longBitsToDouble(0x3fe98e72e1ce498fL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\u4971\ud8e2\udf02\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda4e\udc53\012",
        Z.run(T, 1, 1, 1, 2, "\u4971\ud8e2\udf02\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda4e\udc53", "\u632a\u8114\u19f4\uc83a\u963a\u0b0c\u40d6\u0f32\u522b", "\udb7d\udd9b\udbca\udfd7\ud8f4\udd8a\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06",
        14, 65434, -44469209, 3390409749546281919L, 22872L, false, true, (char) 4367, (char) 59976,
        Double.longBitsToDouble(0x3fe142bd88da9a6fL), Double.longBitsToDouble(0x3fccd9f3beef1064L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\ud931\ude18\ud95c\udfa7\ud9c4\udd68\ud868\udf99\udb3f\udf31\udb39\uddef\ud9dc\udf40\ud806\udd88\ud82e\udc0c\udbdb\udde2\udacb\udc12\ud93b\udc11\udb06\uddfa\ud8ff\udc12\ud81a\ude99\udb92\udd95\uda84\udeb6\uda7b\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud894\ude2f\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\ud9c3\ude73\udb4a\udcc1\udb7d\udcfd\udb92\udcb7\ud901\uddc4\udbfc\udc29\uda04\udc1e\ud8d8\udfc5\udb89\ude7a\udbf5\uddd4\ud84b\udf08\ud871\udf4e\ud9f2\uddc0\ud9e2\udcab\udb56\ude79\ud875\udf53\udbd7\udd46\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 1, 2, 2, "\ud931\ude18\ud95c\udfa7\ud9c4\udd68\ud868\udf99\udb3f\udf31\udb39\uddef\ud9dc\udf40\ud806\udd88\ud82e\udc0c\udbdb\udde2\udacb\udc12\ud93b\udc11\udb06\uddfa\ud8ff\udc12\ud81a\ude99\udb92\udd95\uda84\udeb6\uda7b\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud894\ude2f\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\ud9c3\ude73\udb4a\udcc1\udb7d\udcfd\udb92\udcb7\ud901\uddc4\udbfc\udc29\uda04\udc1e\ud8d8\udfc5\udb89\ude7a\udbf5\uddd4\ud84b\udf08\ud871\udf4e\ud9f2\uddc0\ud9e2\udcab\udb56\ude79\ud875\udf53\udbd7\udd46", "\u5a00\u8340\ua581\ub7b5\u71c7\u86ef\u2c35\u16a9\u4a6c\u942f\ud44d\u8480\uc1a7\u6c35\u704d\u8585\u16be\u1969\ua75e\u03da\u0c9e\u3d26\u62a2\u6848\ucc61", "\ud8e6\uddc9\ud884\udc1c\udba9\udd5b\uda29\udec4",
        15, 98075, -290941864, 5573086981775808027L, 24971L, false, true, (char) 9423, (char) 65268,
        Double.longBitsToDouble(0x3fedf91dbcd3d489L), Double.longBitsToDouble(0x3fd2425d115adbbaL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 2, "", "\u69f0", "\ud840\uddbc",
        -5, -1000, 0, -3819052482908861638L, -89491L, false, false, (char) 110, (char) 0,
        Double.longBitsToDouble(0x3e4fac8c00000000L), Double.longBitsToDouble(0x3fdd0b6bb0e479bcL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\u0207\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46\012",
        Z.run(T, 1, 0, 1, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\u0207\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46", "\u15dd\u8340\u7573\ub7b5\u71c7\u5781\ub9e6\u16a9\u4a6c\u942f\ud44d\u1bf7\uc165\u6c35\ud7e4\uc13e\u16be\u1969\ua75e\u03da\u8748\u9a25\u4e92\ua6cd\ucc61", "\ud8f8\uddd2\ud8d7\udf07\ud94b\udf63\ud800\udc97",
        56, 30209, 454595672, 8938802807814325508L, -79742L, false, false, (char) 13981, (char) 36577,
        Double.longBitsToDouble(0x3fa007e2e2574970L), Double.longBitsToDouble(0x3fdaed98115bd8beL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\012",
        Z.run(T, 1, 1, 1, 1, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5", "\ubc49\u8aac\u8275\u2107\u67ce\u4f72", "\udad2\udf79\ud8ea\udfa7",
        39, 83704, 11110258, 3773647228242478206L, -5995L, true, false, (char) 48850, (char) 25067,
        Double.longBitsToDouble(0x3fe5c8f8d660ed19L), Double.longBitsToDouble(0x3f7c9f0cf230b200L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 1, 2, "\ud876\udcd5\ud8e2\udea2\ud9c4\udd68\udb4e\udf14\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf63\ud81a\udf16\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\ud993\udde5\udb8f\udf9d\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46", "\u15dd\u8340\ua581\ub7b5\ub236\u2852\ub9a0\u16a9\u4a6c\u942f\ud44d\u1bf7\uc165\u6c35\ud7e4\uc13e\u16be\u1969\ua75e\u03da\u8748\u9a25\u4e92\ua6cd\ucc61", "\ud8f8\uddd2\ud8d7\udf07\ud94b\udf63\ud800\udc97",
        56, 30209, -290941864, 5573086981389932059L, 24971L, false, true, (char) 13981, (char) 36577,
        Double.longBitsToDouble(0x3fa007e2e2574970L), Double.longBitsToDouble(0x3fdaed98115bd8beL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud263\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\udbdf\ude6e\uda44\ude31\ud82d\udfd5\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\ud96f\ude94\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\udac1\ude40\ud891\udc3d\udad6\ude70\ud920\udfb9\udaf7\udd4b\ud8d8\udd52\ud857\udf48\udb92\udcb7\udbcc\uddbb\ud83c\ude26\ud9f5\udf7f\udac5\udf41\ubb06\udbf5\udd61\udb9b\udcc1\ud86d\udc27\u118f\uda33\udd7e\udb56\ude79\ud875\udf53\udbd7\udd46\0121=java.lang.String:\udb3e\udfde\ud263\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\udbdf\ude6e\uda44\ude31\ud82d\udfd5\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\ud96f\ude94\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\udac1\ude40\ud891\udc3d\udad6\ude70\ud920\udfb9\udaf7\udd4b\ud8d8\udd52\ud857\udf48\udb92\udcb7\udbcc\uddbb\ud83c\ude26\ud9f5\udf7f\udac5\udf41\ubb06\udbf5\udd61\udb9b\udcc1\ud86d\udc27\u118f\uda33\udd7e\udb56\ude79\ud875\udf53\udbd7\udd46\012",
        Z.run(T, 2, 1, 1, 2, "\udb3e\udfde\ud263\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\udbdf\ude6e\uda44\ude31\ud82d\udfd5\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\ud96f\ude94\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\udac1\ude40\ud891\udc3d\udad6\ude70\ud920\udfb9\udaf7\udd4b\ud8d8\udd52\ud857\udf48\udb92\udcb7\udbcc\uddbb\ud83c\ude26\ud9f5\udf7f\udac5\udf41\ubb06\udbf5\udd61\udb9b\udcc1\ud86d\udc27\u118f\uda33\udd7e\udb56\ude79\ud875\udf53\udbd7\udd46", "\u15dd\u8386\ua581\ub7b5\u1f61\u5781\ub9e6\u16a9\u5259\u82f3\ucc40\ud19b\uc165\u6f0d\ud7e4\uc13e\u16be\u1969\ua75e\u03da\u9eab\ua770\u4e92\ua6cd\u72fe", "\ud8f8\uddd2\ud8d7\udf07\ud94b\udf63\ud800\udc97\udbe8\udcb7\udb81\ude06\ud95a\udf52\udb44\udda3\udb71\ude58\uda3a\udcc6",
        50, 15640, -1867384453, 1136593965048874016L, -96334L, true, false, (char) 3885, (char) 39432,
        Double.longBitsToDouble(0x3fdb9780031f8db4L), Double.longBitsToDouble(0x3fe39136fa9212f9L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\012",
        Z.run(T, 1, 1, 2, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68", "\u8fd4\u5e29\ubc49\u8aac\u8275\u2107", "\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a",
        40, 71025, -41476777, -5925139815894229385L, -95897L, false, true, (char) 5421, (char) 3231,
        Double.longBitsToDouble(0x3f87da79b9e86680L), Double.longBitsToDouble(0x3fd9f7596f2651a8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 0, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\u04df\udbe7\udca5\u3e55\ud887\udf81\ud931\udf18\ud93b\udc11\ud9ae\udd0e\udb09\ude96\ud9da\uddbc\udad2\udf79\udb58\udd7e\ud9dc\udc18", "\u3f62\u0afb", "\ud9c0\ude3c\ud921\udf4e\ud8d8\udd53\udb7d\udd9b\ud90e\udcb5\uda36\uddf7\ud94f\udf13\uda04\udcaa\ud8f4\udf4d\ud963\udec2\ud83d\udc21\udbe5\udc09\ud8c2\ude97\uda11\uddb4\udb2e\udec7\udb56\ude79\ud875\udf53\udbd7\udd46\ud9a2\uddaa\ud910\udc38\ud8b0\udcb4\ud9ab\udf8f\udbb1\udf13\udbdf\udcf1\udacb\udc2b\ua600\ud8f1\udd5e\udb81\ude7b\udb9c\udc2f",
        50, 28179, 841154699, 7889400144619033295L, 61864L, true, false, (char) 188, (char) 49432,
        Double.longBitsToDouble(0x3fdc795a7b791c6eL), Double.longBitsToDouble(0x3fdf49b75a52cbaeL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 0, "\udb3e\udfde", "\000", "\uda27\ude72\\\ud824\udeb2\000",
        -5, 16429, -1351887117, 4363655720129525870L, -34314L, true, true, (char) 59531, (char) 50255,
        Double.longBitsToDouble(0x3fa48054c7e345e0L), Double.longBitsToDouble(0x3fd5d13071974f9cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 1, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\ud8c8\udf6c\ud8c8\udee3\udb21\udffa\ud936\udf84\ud818\udc7d\ud82e\udc0c\ud815\udd5c\udbb5\udf22\ud9f6\udff0\ud81c\ude06", "\ub67d\u632a", "\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\ud9a8\udfe2\ud901\ude6d",
        36, 70369, -314813142, -6801935121972306201L, 66873L, false, true, (char) 23244, (char) 60810,
        Double.longBitsToDouble(0x3fdb1c3f1b017760L), Double.longBitsToDouble(0x3fefc201735e84b9L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\uda38\uddeb\ud82e\udc3e\uda19\ude72\ue891\ud95f\udef8\ud936\ude33\ud82c\udcb3\ud9ac\udcda\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\ud8f2\ude1b\ud81a\udf5d\ud8e2\uddf5\u4718\ud9d5\udd29\ud809\udc9f\udae2\udcc4\uda4c\udf6d\uda72\udf87\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udae7\uddcd\udbe5\udc06\ud871\udf4e\u118f\udb75\udfd6\udb56\ude79\ud875\udf53\012",
        Z.run(T, 1, 1, 1, 1, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\uda38\uddeb\ud82e\udc3e\uda19\ude72\ue891\ud95f\udef8\ud936\ude33\ud82c\udcb3\ud9ac\udcda\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\ud8f2\ude1b\ud81a\udf5d\ud8e2\uddf5\u4718\ud9d5\udd29\ud809\udc9f\udae2\udcc4\uda4c\udf6d\uda72\udf87\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udae7\uddcd\udbe5\udc06\ud871\udf4e\u118f\udb75\udfd6\udb56\ude79\ud875\udf53", "\u9991\u15dd\u071b\ua4e4\ub7b5\u71c7\u5781\ub9e6\u35e2\u4a6c\u942f\ud44d\u1bf7\uc165\u6c35\ud7a8\uc72a\u0ff5\ub880\ua75e\u03da\ua02c\u9abe\u4e92\ua6cd\ucc61\u6d99\u908c\ubda8\ud674\u5053\u3c05\ua280\u8f98\u83aa\u80b3\u3af7\u6c3f\ua901\u734c\u958f", "\ud8dc\udfe0\udaef\udea7\ud8ff\udfea\ud869\udc0e\ud993\udf8a\ud8dc\udefc\udafa\udf84\ud828\ude75\udb28\ude1e\uda30\udc71\u41ea\ud962\ude7c\udbc7\udf79\uda1f\udf0d\ud83f\udd38\udbd3\udff7\udb24\udfa6\ud8bd\udcc4\ud8ca\udd8b\ud924\udc11\ud824\udeee\udbcd\udc60\udbb9\udd6b\ud944\udc0c\udbee\ude91\uda3f\uddbf\udaa1\udf11\udb13\ude40\ud8a1\udcf0\udae3\udf94\ud9c3\udf0c\uda51\udefd\udbeb\udec9\udb42\udf81\u9911\udadd\udd6f\uda79\udfe8\u8b97\ud8a0\udeb1\ud989\udebc\uda39\udfe3\udaab\udf20\ud815\udf3e\udbae\udc37\u206b\ud933\udc18\udb31\udfdb\uda8c\udf94\udad6\udd21\ud9d5\udc8e\u700c",
        41, 16085, 1377407560, 3629124552200243829L, 39216L, false, false, (char) 34237, (char) 58322,
        Double.longBitsToDouble(0x3fdf42cc23d16f0eL), Double.longBitsToDouble(0x3fd773e13a9a2f14L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33", "\ub67d\u632a", "\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb7\ud901\uddc4",
        22, 33057, -314813142, -6801935121972306201L, -2829L, false, false, (char) 63, (char) 9486,
        Double.longBitsToDouble(0x3fedf97868d13cbaL), Double.longBitsToDouble(0x3fdb1c3f1b017760L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\udd4e\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udafa\ude69\udb92\udcb7\ud901\uddc4\ud94f\udf13\ud9f2\udfb9\udb9f\udc0e\udb89\ude7a\u00e7\ud9b8\ude5b\ud871\udf4e\u118f\u33d8\udb56\ude79\ud875\udf53\udbd7\udd46", "\u15dd\u4b8c\ua581\ub7b5\u71c7\u5781\ub9e6\u16a9\u4a6c\u942f\ud44d\u1bf7\uc165\u6c35\ud7e4\uc13e\u16be\ucfed\000\u037a\u8748\u9a25\u4e92\ua6cd\ucc61", "\ud8f8\uddd2\ud8d7\udf07\ud94a\ude63\ud800\udc97\udbe8\udcb7\uda7a\udefe\ud95a\udf52\udb44\udda3",
        25, 35246, -1115809835, 4405226148367300987L, -20758L, false, true, (char) 3167, (char) 13783,
        Double.longBitsToDouble(0x3fe6980525c4da2bL), Double.longBitsToDouble(0x3fe7fa3e3c87367eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\012",
        Z.run(T, 1, 1, 0, 0, "\udb3e\udfde", "\u871e\u58dd\u13c4\u5e29\ubc49\u8aac\u6946\000\u66d1", "\ud9da\uddbc",
        42, 57366, -1229230101, 4385997856539510642L, -5995L, true, false, (char) 48850, (char) 25067,
        Double.longBitsToDouble(0x3fec30f8d660ed28L), Double.longBitsToDouble(0x3f7c9c00f230b200L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 0, "\u90dd\ud8e2\udf02\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda22\udfd7\ud80c\udf95", "\u2107\u67ce\u4856\ucf0c\uc1d0\ub67d\u632a", "\ud90f\udd3a\ud81a\udf3f\ud834\udcb7\ud908\udc67\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udbca\udfd7\ud8f4\udd8a",
        22, 33057, -314813142, -6801935121972306201L, 66873L, false, true, (char) 23244, (char) 60810,
        Double.longBitsToDouble(0x3fe1714f8efbce95L), Double.longBitsToDouble(0x3feb71babb5e84b9L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 1, 2, 0, 0, "\u4971", "\000", "",
        -5, -1000, -1510070950, -3802074928159339718L, -98062L, true, false, (char) 4472, (char) 28416,
        Double.longBitsToDouble(0x3f46d77dc8000000L), Double.longBitsToDouble(0x3fa48054c7e345e0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud931\ude18\ud95c\udfa7\ud9c4\udd68\ud868\udf99\udb3f\udf31\udb39\uddef\ud9dc\udf40\ud806\udd88\ud82e\udc0c\udbdb\udde2\udacb\udc12\ud93b\udc11\udb06\uddfa\ud8ff\udc12\ud81a\ude99\udb92\udd95\uda84\udeb6\uda7b\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud894\ude2f\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\ud9c3\ude73\udb4a\udcc1\udb7d\udcfd\udb92\udcb7\ud901\uddc4\udbfc\udc29\uda04\udc1e\ud8d8\udfc5\udb89\ude7a\udbf5\uddd4\ud84b\udf08\ud871\udf4e\ud9f2\uddc0\ud9e2\udcab\udb56\ude79\ud875\udf53\udbd7\udd46", "\u5a00\u8340\ua581\ub7b5\u71c7\u86ef\u2c35\u16a9\u5f51\u4e12\ud44d\u8480\uc1a7\u6c35\u704d\u8585\u16be\u1969\ua75e\u03da\u0c9e\u3d26\u62a2\u6848\ucc61", "\ud8e6\uddc9\ud884\udc1c\udba9\udd5b\uda29\udec4",
        15, 98075, -290941864, 5573086981775808027L, 24971L, false, true, (char) 9423, (char) 65268,
        Double.longBitsToDouble(0x3fedf91dbcd3d489L), Double.longBitsToDouble(0x3fd2425d115adbbaL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=new org.apache.commons.cli.Util:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud931\ude18\udadb\udf19\ud9c4\uddaa\ud8e8\udf7b\udb3f\udf4f\udb56\udcee\ud9dc\udf40\ud806\udd88\ud82e\udc0c\udbdb\udde2\udacb\udc12\ud93b\udc11\udb06\uddfa\ud90a\udfb7\ud814\udc59\udb92\udd95\uda84\udeb6\uda7b\udf99\ud946\udfba\udac5\ude73\ud81a\udf3f\ud894\ude2f\ud8c0\udd70\uda57\udf54\ud944\udf3d\ud9c3\ude73\uc28d\udb7d\udd7e", "\u8f2a\u0cc0\ud23e\u142a\u7244\u451a\u6f33\u0186\u100c\u4e39\u5b8f\u39a3\ud4ba\u84d3\u5a00\u8340\ua581\ub7b5\u71c7\u86ef\u2c35\u16a9\u4a6c\u618c\ud44d\u8480\u5192", "\udb84\udfdd\ud8fe\udcdd\ua69c\udbb2\udfd0\udbed\udf98\ud886\udc1e\ud9d3\udd54",
        5, 62916, 1451567082, -4152758725977538178L, 21728L, false, true, (char) 21489, (char) 45025,
        Double.longBitsToDouble(0x3fd9310888b15716L), Double.longBitsToDouble(0x3fd8346a8f822f0aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\ud931\ude18\ud95c\udfa7\ud9c4\udd68\udb8c\udf6b\ud9b4\udd0b\udb39\uddef\ud9dc\udf40\ud806\udd88\ud82e\udc0c\ud995\udddf\udacb\udc12\ud93b\udc11\udb06\uddfa\ud8ff\udc12\ud81a\ude99\udb92\udd95\uda84\udeb6\uda7b\udf99\ud8fb\udd66\udbf5\udf09\ud81a\udf3f\ud894\ude2f\ud88a\udd69\000\000\ud9c3\ude73\u1840\udb7d\udcfd\udb92\udcb7\ud901\uddc4\000\udb5f\udc06\ud8d8\udfc5\udb0c\ude71\udbf5\uddd4\ud84b\udf08\ud871\udf4e\udb43\udf68\ud9e2\udcab\udb56\ude79\ud875\udf53\udbd7\udd46\0121=java.lang.String:\ud931\ude18\ud95c\udfa7\ud9c4\udd68\udb8c\udf6b\ud9b4\udd0b\udb39\uddef\ud9dc\udf40\ud806\udd88\ud82e\udc0c\ud995\udddf\udacb\udc12\ud93b\udc11\udb06\uddfa\ud8ff\udc12\ud81a\ude99\udb92\udd95\uda84\udeb6\uda7b\udf99\ud8fb\udd66\udbf5\udf09\ud81a\udf3f\ud894\ude2f\ud88a\udd69\000\000\ud9c3\ude73\u1840\udb7d\udcfd\udb92\udcb7\ud901\uddc4\000\udb5f\udc06\ud8d8\udfc5\udb0c\ude71\udbf5\uddd4\ud84b\udf08\ud871\udf4e\udb43\udf68\ud9e2\udcab\udb56\ude79\ud875\udf53\udbd7\udd46\012",
        Z.run(T, 2, 0, 0, 2, "\ud931\ude18\ud95c\udfa7\ud9c4\udd68\udb8c\udf6b\ud9b4\udd0b\udb39\uddef\ud9dc\udf40\ud806\udd88\ud82e\udc0c\ud995\udddf\udacb\udc12\ud93b\udc11\udb06\uddfa\ud8ff\udc12\ud81a\ude99\udb92\udd95\uda84\udeb6\uda7b\udf99\ud8fb\udd66\udbf5\udf09\ud81a\udf3f\ud894\ude2f\ud88a\udd69\000\000\ud9c3\ude73\u1840\udb7d\udcfd\udb92\udcb7\ud901\uddc4\000\udb5f\udc06\ud8d8\udfc5\udb0c\ude71\udbf5\uddd4\ud84b\udf08\ud871\udf4e\udb43\udf68\ud9e2\udcab\udb56\ude79\ud875\udf53\udbd7\udd46", "\u5a00\u8340\ua581\ub7b5\u71c7\u86ef\u2c35\u28bc\u0af7\u942f\ud44d\u8480\uc077\u604b\u4471\u5b68\u16be\u1969\ua75e\u03da\u279d\u3d26\u62a2\u6848\ucc61", "\ud8e6\uddc9\udb91\udc83\udb70\uddd7\uda29\udec4",
        15, -853, -290941864, 5573086981775808027L, 24971L, false, true, (char) 9423, (char) 65268,
        Double.longBitsToDouble(0x3fedf91dbcd3d489L), Double.longBitsToDouble(0x3fd2425d115adbbaL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.Util:@?\0121=java.lang.String:\012",
        Z.run(T, 2, 2, 1, 0, "", "\000", "",
        34, 89550, 92, -6485705345774890753L, -15267L, false, false, (char) 107, (char) 0,
        Double.longBitsToDouble(0x3e20000000000000L), Double.longBitsToDouble(0x3fef5918a90000bbL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46\012",
        Z.run(T, 1, 1, 1, 2, "\udb3e\udfde\ud8e2\udef9\ud9c4\udd68\udb45\udec7\ud8c8\udfd5\ud840\uddbc\uda27\ude72\ud80c\udf95\ud82e\udc0c\udbdb\udde2\ud931\udf18\ud93b\udc11\ud936\ude33\uda59\udd53\ud9da\uddbc\udad2\udf79\ud8ea\udfa7\uda78\udf99\ud8fb\udd66\udbf5\udf7b\ud81a\udf3f\ud831\udd9d\ud9cb\udc2a\ud9d5\udde2\ud809\udc9f\udae2\udcc4\ud8d8\udd52\udb7d\udd9b\udb92\udcb7\ud901\uddc4\ud94f\udf13\uda04\udcaa\udb9f\udc0e\udb89\ude7a\udbf5\uddd4\udbe5\udc06\ud871\udf4e\u118f\u33ff\udb56\ude79\ud875\udf53\udbd7\udd46", "\u15dd\u8340\ua581\ub7b5\u71c7\u5781\ub9e6\u16a9\u4a6c\u942f\ud44d\u1bf7\uc165\u6c35\ud7e4\uc13e\u16be\u1969\ua75e\u03da\u8748\u9a25\u4e92\ua6cd\ucc61", "\ud8f8\uddd2\ud8d7\udf07\ud94b\udf63\ud800\udc97",
        56, 30209, -290941864, 5573086981389932059L, 24971L, false, true, (char) 13981, (char) 18913,
        Double.longBitsToDouble(0x3fc074d6d894ff30L), Double.longBitsToDouble(0x3fdaed98115bd8beL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Util|stripLeadingHyphens|java.lang.String|static",
    "M|org.apache.commons.cli.Util|stripLeadingAndTrailingQuotes|java.lang.String|static",
    "C|org.apache.commons.cli.Util|<init>|",
    "M|org.apache.commons.cli.Util|stripLeadingHyphens|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
