package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda2e\udcc8\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u7330\u4830\u7ab9\uc7f8\u7f7a\u72df\u7f32\u4f0b\u648f\u9d88\u647f", "\u6a9e\udab0\ude64\ud917\udd41\uda4a\udf20",
        59, 65038, 1069554226, 3261603487213614186L, 28660L, true, true, (char) 56777, (char) 28122,
        Double.longBitsToDouble(0x3fd6a6e800640432L), Double.longBitsToDouble(0x3fe77e4340dc02a3L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \u0e01\udb93\udc4e\ud9d0\udf40\ud83d\udc70\ud8da\ude5e\ud9ed\udf20\udb87\udc80\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\uda05\udfd2\ud942\udecf\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94]] |a1=[Ljava.lang.String;:[[\u0e01\udb93\udc4e\ud9d0\udf40\ud83d\udc70\ud8da\ude5e\ud9ed\udf20\udb87\udc80\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\uda05\udfd2\ud942\udecf\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 0, 1, "\u0e01\udb93\udc4e\ud9d0\udf40\ud83d\udc70\ud8da\ude5e\ud9ed\udf20\udb87\udc80\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\uda05\udfd2\ud942\udecf\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94", "\u98d1\u5392\u7ab9\u3e31\uc55b\u1ed2\u6f21\u8d2f\u46da\u9c62\u0fab", "\u6a9e\udab0\ude64\ud917\udd41\uda4a\udf20",
        59, 65038, 1069554226, 3261603484462150762L, 28660L, true, false, (char) 44844, (char) 1206,
        Double.longBitsToDouble(0x3fd6a89ba435a52eL), Double.longBitsToDouble(0x3fe77e4778dc02a3L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 2, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda2e\udcc8\uda07\udef5\udb22\udebe\udb59\ude92\ud88f\udf55\ud946\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u7330\u4830\u7ab9\uc7f8\u7f7a\u72df\u7f32\u4f0b\u648f\u9d88\u3338", "\u6a9e\udbf1\uded5\ud917\udd41\uda4a\udf20\ud850\ude72\udb54\udfba\udb0b\uddf3\udb79\uddc1\ud872\udc83",
        42, 9590, 248630219, 1360314654789753594L, -79470L, true, false, (char) 17279, (char) 38054,
        Double.longBitsToDouble(0x3fd6d7386ab289c0L), Double.longBitsToDouble(0x3f9950e19ac82f20L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\udbc1\udf2f\udbb6\udecb\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud935\uddbd\ud9d4\ude4d\ud993\udeb4\ud9dc\udf0e\ub6e8\udad7\udc3a\uda55\udf31\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\ud985\udd11\ud9c8\ude97\ud939\udfba\ud8c1\udc5b\ud995\udd61\uda58\ude3f\udba1\udf7f\udb94\udfd0", "\u72df\u7f32\u4f0b\u648f\u9d88\u647f\u83f8\u8eb4", "\ud917\udd41\ud81f\udc5b\ud850\ude72\ud923\uddc2\udb0b\uddf3\udabe\udebc\udbc9\udfaf\udaa9\udeac",
        16, 68188, -136261895, 3205537064604485928L, 39806L, false, false, (char) 12220, (char) 62872,
        Double.longBitsToDouble(0x3fcb2dca7d07e6e0L), Double.longBitsToDouble(0x3fe0f6742171266eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda2e\udcc8\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\ud8e7\ude32\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\uda95\udcb3\udbe0\ude5a\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u7330\u4830\u7ab9\uc7f8\u7f7a\u72df\u7f32\uc8a5", "\uda66\uddfe\ud926\udd0a",
        27, 38212, -872200843, -7927114084188322771L, 69826L, false, false, (char) 51926, (char) 8621,
        Double.longBitsToDouble(0x3fdab458ad28b6c4L), Double.longBitsToDouble(0x3fee5afc4ef90ed1L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda2e\udcc8\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud923\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8", "\u40e1\u065c\u697b\u77c4\u05f3\u0ad9\u6055\u171b\u7a96", "\udb96\udd60\udb94\udfd0",
        17, 22294, -555906523, -5474484621944327164L, 1865L, true, false, (char) 16036, (char) 59323,
        Double.longBitsToDouble(0x3fedee601c2d91fdL), Double.longBitsToDouble(0x3fd0775f513d20a2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda2e\udcc8\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u7330\u4830\u7ab9\uc7f8\u7f7a\u72df\u13a5\u18f1\u648f\u9d88\u647f", "\u6a9e\udab0\ude64\ud917\udd41\uda4a\udf20",
        59, 65038, 1069554226, 3261603487213614186L, 28660L, true, true, (char) 56777, (char) 28122,
        Double.longBitsToDouble(0x3fd6a6e800640432L), Double.longBitsToDouble(0x3fe77e4340dc02a3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 3, 3, 4, "\ud857\udea9\udb7f\udf04\ud842\udfa2\ud885\udeea\uda2e\udc3c\udbee\udde9\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda29\udf26\ud99f\udd33\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\ua713\ub2cf\u34a2\u238d\u7f7a\u72df\u7f32\u4f0b\u648f\u9d88\u647f\u83f8\u9bef\uc1d1\uac9d\u4121\u3ffb\ub4a9\uadaf\u9018\u4455\u26d6\u4dfa\u9fcf\u5d5b\ubd58\u75f1\uabe6\u9db6\u720f\u8f05", "\ud97c\udd50\uda0c\udd2b\udb69\udf38\udbe9\uddd1\udbc5\udd83\udacc\udd1e\ud95d\udfe1\ucb11\ud909\udc08\ud9ec\udcf6\udb00\udf2e\udae4\udedc\ud9e7\udd65",
        12, 65672, -1117330924, 6902989382937827084L, -20564L, false, true, (char) 61719, (char) 15021,
        Double.longBitsToDouble(0x3feb00ff08a38a91L), Double.longBitsToDouble(0x3fe7c15556427187L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda2e\udcc8\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\udad0\udcdb\ud8e7\udc8c\ud993\udeb4\ud867\udfe6\uda00\udd16\udacb\udd20\ud958\udd46\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u7330\u4830\u2ccc\uc8a0\u7f7a\u72df\u7f32\u4f0b\u648f\u9d88\u647f", "\u6a9e\udab0\ude64\ud917\udd41\uda4a\udf20",
        59, 65038, 1069554226, 3261603487213614186L, 28660L, true, true, (char) 56777, (char) 28122,
        Double.longBitsToDouble(0x3fd6a6e800640432L), Double.longBitsToDouble(0x3fe77e4340dc02a3L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 4, "\ud857\udea9\udb7f\udf04\ud8a7\udc35\udad0\uded3\uda2e\udcc8\ud869\udc25\uda68\udd5f\uda21\udfa8\udae9\udc05\ud945\udfbd\ud9d4\ude4d\udaf7\udea6\ud867\udfe6\ud92d\udc58\uda68\udf33\ud8f1\udf80\udac0\udc90\udb29\udc3f\uda47\udf63\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u7330\u4830\ua793\u821d\u8068\uc252\u6b1a\u90e0\u2e05\u9d88\u647f", "\u6a9e\udab0\ude64\ud917\udd41\uda4a\udf20",
        59, 65038, 1069554226, 3261603487213614186L, 28660L, true, true, (char) 56777, (char) 44877,
        Double.longBitsToDouble(0x3fd6a6e800640432L), Double.longBitsToDouble(0x3fe77e4340dc02a3L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud9a0\udd24\ud93b\uddb1\uda43\udd2b\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4", "\u0bd6\ua290\ua0c3\ub005\u596f\u3689\u40e1\u065c\u887a\u77c4\u9821\u0ad9\u6055\u171b\u7a96\u81c1\u7330\u4830\u7ab9\uc7f8\u7f7a\u72df\u7f32\u4f0b\u648f\u9d88\u647f\u83f8\u8eb4\uc10e", "\uda4a\udf20",
        59, 65038, 1069554226, 3261603487213614186L, 28660L, true, true, (char) 56777, (char) 32474,
        Double.longBitsToDouble(0x3fd6a6e800640432L), Double.longBitsToDouble(0x3fe77e4340dc02a3L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda2e\udcc8\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9cb\udd4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u7330\u4830\u7ab9\uc7f8\u7f7a\u72df\u7f32\u4f0b\u648f\u9d88\u647f", "\u6a9e\udab0\ude64\udb8f\udfdc\udb11\udd72",
        59, 65038, 1069554226, 4185453838801237098L, 28660L, true, true, (char) 56777, (char) 28122,
        Double.longBitsToDouble(0x3fd6a6e800640432L), Double.longBitsToDouble(0x3fe77e4340dc02a3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda98\udee3\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\udada\udc96\ud8f5\udc5d\uda68\udefe\uda56\udefc\udaeb\udd90\ud9e1\uded8\ud95b\uddcd\uda8b\udd2e\udbea\udd27\udb4b\udd85\udadb\uddc4\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u72b9\u4830\u1c0f\u84e9\u7f71\u72df\u7f32\uc544\u9df4\u9a94\u647f\u78b6\u8eb4\uc10e\u57d7\u415a\u5bd5\ub6fc\uc678\u2cca\u3928\u938d\u4535\u9fcf\u5d5b\ubd58\u75f1\uabe6\ubd31\u720f\ubf81\uc57a\u073d\u0ca4\ud4ad", "\ud9ac\udcd0\ued1a\ud9f7\ude66\ud8ed\udc0a\ud9d7\uddb1\uda1e\udd9e",
        29, 69189, -1054827431, 184228582223519739L, -68969L, true, true, (char) 63702, (char) 17493,
        Double.longBitsToDouble(0x3fe9236cdf81fb2dL), Double.longBitsToDouble(0x3fe6a751d22ebd04L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 4, 4, "\ud857\udea9\udb7f\udef7", "\u4a42\u22c2\uc467\u981e\u7b95\ud3c0\u8083\uce9e\ua141\u1ea1\u0bd6\u66b6\u2362\ub005\u596f\u3689", "\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\u3927",
        43, 19165, 208586380, 2690415821957050844L, 61243L, false, true, (char) 10251, (char) 22712,
        Double.longBitsToDouble(0x3fe7a86eac6ca04dL), Double.longBitsToDouble(0x3fde95e8f4875abaL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud857\udea9]] |a1=[Ljava.lang.String;:[[\ud857\udea9]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud857\udea9", "\u4dbf", "\udb22\udebe\uda08\udd85\ud88f\udf55",
        23, 26529, -1073776006, 3157847222948185372L, 5766L, true, true, (char) 58682, (char) 10946,
        Double.longBitsToDouble(0x3fd87ca66405f432L), Double.longBitsToDouble(0x3fc91e319796e9d4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda2e\udcc8\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud876\ude55\ud9a3\udc46\ud8e1\uddb7\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud8fc\udeda\ud8b2\udee2\u253e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u73b0\u4830\u7ab9\uc7f8\u7f7a\u72df\u7f32\u4f0b\u648f\u9d88\ua280", "\ud98d\udd8b\uda2d\udc71\ud917\udd41\uda4a\udf20\ud850\ude72\udb54\udfba\udb0b\uddf3\udb79\uddc1\ud872\udc83\udbc4\udc15\ud943\udc35\udb14\udc9e\udb2e\udc15\ud820\udd7d\uda92\udd89\ud907\udceb\udb2b\udf16\udad0\udf27\ud941\udda0\udb67\udc86\ud993\udf1d\uda32\udfe0\udb76\udefc\uda24\uddd5\ud84e\uddc3\udb7f\udef5\ud9f5\udc78\uda96\udd06\ud91f\udc0c\ud958\udd4d\ud8b2\udc2e\ud9d9\udc35\ud93e\uddcb\uda21\ude6d\uda55\udf5b\ud8e1\uddbe\udbc1\ude6a",
        35, 90971, 1401689193, -3600695523785259428L, 85859L, false, false, (char) 38113, (char) 39217,
        Double.longBitsToDouble(0x3fc22d8c8dbf10ecL), Double.longBitsToDouble(0x3fd2187b53d612feL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 0, "", "\u426d", "\uda07\udef5",
        14, 87108, 498414997, -7420623976477038943L, -29681L, false, true, (char) 25348, (char) 12910,
        Double.longBitsToDouble(0x3fe88b188fabd58fL), Double.longBitsToDouble(0x3fcecf39961c0198L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68", "\u996d\u67fe\u4d25", "\ud993\udeb4\udba2\udf23\ud8ad\udf1f",
        43, 94384, 925751564, -4207479463774517995L, -30155L, true, false, (char) 27569, (char) 20123,
        Double.longBitsToDouble(0x3fe4ab6ac899125aL), Double.longBitsToDouble(0x3fef4789eb06eaa3L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 3, 3, "\ud857\ude3a", "\u044a", "\ud86f\udfdc\ud9ea\udf3d\uda40\udf2d\uda48\udc98",
        43, 76461, -1415915809, -6556124932046526403L, 97393L, true, true, (char) 10946, (char) 47085,
        Double.longBitsToDouble(0x3fa37d0c8a099a40L), Double.longBitsToDouble(0x3fde5ba7532411dcL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 2, 0, "\ud9f2\udd2f\udb95\udde2\ud8a1\uddd8", "\uaf6c\u4d89\uadb4\ua0ca", "\ud993\udeb4",
        -4, 16476, 843638845, 7138659670332211985L, -8145L, true, true, (char) 28197, (char) 19421,
        Double.longBitsToDouble(0x3fe76e32419208a4L), Double.longBitsToDouble(0x3fe6020fd13ffbf3L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud857\udea9\udb7f\udf04\ud8e4\ude34\uda99\udea6\uda3c\udd42\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud933\udc75]] |a1=[Ljava.lang.String;:[[\ud857\udea9\udb7f\udf04\ud8e4\ude34\uda99\udea6\uda3c\udd42\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud933\udc75]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 0, 3, 4, "\ud857\udea9\udb7f\udf04\ud8e4\ude34\uda99\udea6\uda3c\udd42\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud933\udc75", "\ub8aa\u7ed3\ubeb1\u27c2\u7f7a\u72df\u7f32\u7fa3\u6913\u9d88\u0989", "\udbc9\udf7c\udab0\ude82\ud917\udd41",
        39, 70879, 886139038, 4593700422727994135L, 66315L, false, false, (char) 11092, (char) 56777,
        Double.longBitsToDouble(0x3fe7d4b7016a6e80L), Double.longBitsToDouble(0x3fa6536361c25cd0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 6, "\u0e01\udb93\udc4e\ud9d0\udf40\ud83d\udc70\ud8da\ude5e\ud9ed\udf20\udb87\udc80\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud8c8\udfbd\uda5f\ude27\ud86e\udf08\uda05\udfd2\ud942\udecf\ud95b\uddcd\u252e\uda8d\udd52\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94", "\ua32d\u213e\u7ab9\u3e31\uc605\u1ed2\u2b56\u8dfb\u46da\u9c62\u0fab", "\udbaf\udedc\udab0\ude64\ud917\udd41\uda4a\udf48",
        59, 4902, -1748980279, 3261603484462150762L, 22260L, true, false, (char) 44844, (char) 1206,
        Double.longBitsToDouble(0x3fd6a89ba435a52eL), Double.longBitsToDouble(0x3fe77e4778dc02a3L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 1, "\ud90f\udca3\udaa6\udd2c", "\u4221\ua9df\u86ee\u3c07\u67ad\u5d34\u8083\u48b2\ub0cd\u2808\ubec9\u0b79\u7028\ubb4d\u596f\u3689", "\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94\udad4\udea5\uda07\udc7b\ud83e\udd05\u44e7\udb94\udfd0\udac0\udc6b\udb3c\uddd0\udb76\udd01\ud8d1\udc84\ud976\udee1\ud96a\udd7d\ud954\udf22\uda51\udd2a\ud926\udd0a\ud819\udc84",
        27, 34157, 301964733, 8499845198666393863L, -93294L, true, true, (char) 8621, (char) 10999,
        Double.longBitsToDouble(0x3fe4a2db129539ddL), Double.longBitsToDouble(0x3fd570dd6e259b46L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 6, "\udaff\udc7a\udb93\udc4e\ud9d0\udf40\ud83d\udc70\ud8da\ude5e\ud9ed\udf20\udb87\udc80\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud875\udd3a\uda3f\udfb2\ud86e\udf08\uda05\udfd2\udb4a\udcce\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\ud9de\udc07\ud9c5\uddb7\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94", "\u98d1\u5392\u7ab9\u3e31\u576e\u1ed2\u6f21\u8d2f\u46da\u9c62\u0fab\u83f8\u8eb4\uc10e\u57d7\u415a\u3ffb\ub4a9\uaa91\u9637\u88bc\u6476", "\udb1e\udf65\ud921\udd13\udac8\ude8d\ud916\ude2b\ud8e7\udedb\udb2b\udf16\ud811\ude7b\ud982\ude92\udae5\udf8d\ud822\udebb\ud8c8\udc2f\uda3e\udd54\ud92a\udfb0\ud882\udda1\udacf\udeec\ud852\uddac\ud857\udfb4\udbbd\udf58",
        22, 48265, 1733123870, -3140205763184214981L, -28043L, true, true, (char) 61330, (char) 43945,
        Double.longBitsToDouble(0x3fecf6bbec68f2b7L), Double.longBitsToDouble(0x3fec75593f99ffddL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \u0e01\udb93\udc4e\ud9d0\udf40\ud9d2\udc9b\ud8da\udebd\ud886\ude8a\udba7\udd0a\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\ud9ef\udc67\uda13\udd68\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94]] |a1=[Ljava.lang.String;:[[\u0e01\udb93\udc4e\ud9d0\udf40\ud9d2\udc9b\ud8da\udebd\ud886\ude8a\udba7\udd0a\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\ud9ef\udc67\uda13\udd68\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \u0e01\udb93\udc4e\ud9d0\udf40\ud9d2\udc9b\ud8da\udebd\ud886\ude8a\udba7\udd0a\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\ud9ef\udc67\uda13\udd68\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94]] |a1=[Ljava.lang.String;:[[\u0e01\udb93\udc4e\ud9d0\udf40\ud9d2\udc9b\ud8da\udebd\ud886\ude8a\udba7\udd0a\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\ud9ef\udc67\uda13\udd68\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 1, "\u0e01\udb93\udc4e\ud9d0\udf40\ud9d2\udc9b\ud8da\udebd\ud886\ude8a\udba7\udd0a\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\ud9ef\udc67\uda13\udd68\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94", "\u98d1\u5392\u7ab9\u7731\uc55b\u1ed2\u6f21\u8d2f\u46da\u9c62\u0fab", "\u6a9e\udab0\ude64\ud917\udd41\uda4a\udf20",
        59, 99246, 1892200959, -7237697890292140812L, 28660L, true, false, (char) 44844, (char) 1206,
        Double.longBitsToDouble(0x3fd6a89bac35a52eL), Double.longBitsToDouble(0x3fc461fc237008a4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 1, "\u0e01\ud914\udd2f\ud876\udda8\ud83d\udc70\ud8da\ude5e\ud8d8\udf67\udaf0\uddb7\udbec\udd15\ud92b\udc73\udb7b\udcd6\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\udacd\udc17\uda09\udd33\ud942\udecf\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94", "\u56fc\u45c5\u6f21\u3e31\uc55b\u1ed2\u6f21\u2aaf\u40ad\u4652\u0fab", "\u6a9e\udab0\ude64\ud917\udd41\uda4a\udf20\ud850\ude72\udb54\udfba\udb0b\uddf3\udb5b\udddd\udbd9\uded8\udaa9\udecf\ud808\uddf8\udb1e\udf65\ud8b9\ude5f\ud91d\udf2d\udbb7\udebc\ud8e7\udedb\udb2b\udf16\uda12\ude3c",
        0, 69379, -1844947040, -1060844973039174896L, -8527L, true, true, (char) 16254, (char) 55318,
        Double.longBitsToDouble(0x3fd7df78af919ebeL), Double.longBitsToDouble(0x3fd8ddd86c7a1766L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 1, "\u0e01\udac7\ude08\ud9e5\udce0\ud83d\udc70\ud8da\ude5e\ud9ed\udf20\udb87\udc80\udbec\udd0f\ud93b\udf5a\ud9cb\udc72\ud9d4\ude7d\u4693\u353f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\uda13\udc98\ud821\udfd9\ud949\udc12\u252e\uda89\udc56\udb6c\udf47\uda7f\udce8\ud98f\ude31\uda7b\udea1\udab0\ude28\udb7c\udfa9\ud939\udf94", "\u98d1\u2f6c\ua7ee\u3ec0\uc55b\u1ed2\u6f21\u36b0\u5c8a\ub2e6\u4487", "\udab7\udca8\udab0\udebd\ud91b\udf41\ud9c8\udf1f",
        59, 64958, 1069554226, 3261603486711527035L, -53258L, false, false, (char) 14303, (char) 32200,
        Double.longBitsToDouble(0x3fd49c247ec96548L), Double.longBitsToDouble(0x3fe3deb611d3d792L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udb67\ude76\udb21\udc90\uda19\ude63]] |a1=[Ljava.lang.String;:[[\udb67\ude76\udb21\udc90\uda19\ude63]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 2, 2, "\udb67\ude76\udb21\udc90\uda19\ude63", "\ua9df\u86ee\ub2fa\u68c0\u6790", "\ue43f\ud92f\uddbf\udb5f\udcc8\ud86e\udf08\uda05\udfd2\ud942\udecf",
        21, 7558, 663517698, -6812476307774513002L, -41120L, true, true, (char) 65484, (char) 130,
        Double.longBitsToDouble(0x3fd22f121781a4f0L), Double.longBitsToDouble(0x3fe7806375642356L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\000\udb93\udc4e\ud9d0\udf40]] |a1=[Ljava.lang.String;:[[\000\udb93\udc4e\ud9d0\udf40]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 0, 1, "\000\udb93\udc4e\ud9d0\udf40", "\ua9df\u86ee\u2323\000\000", "\ue43f",
        16, -1000, 1674943744, -3049488552641373269L, 35801L, false, false, (char) 24688, (char) 33291,
        Double.longBitsToDouble(0x3fea2b12aa00c207L), Double.longBitsToDouble(0x3fd3ffbf352adab2L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 4, 5, "\ud995\udc2f\udb93\udd07\ud9d0\udf40\ud83d\udc70\ud8da\ude5e\udb22\udcd9\uda65\udcd5", "\u2a8f\u8add\u5c05\uc1b0", "\ud991\udc3e\uda05\udfd2\ud84e\uded5\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94\udaf3\udef7",
        33, 86816, -138990236, -1605298930552662962L, 69804L, false, false, (char) 41012, (char) 31158,
        Double.longBitsToDouble(0x3fe717e6af984843L), Double.longBitsToDouble(0x3fde96c8f4875abaL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\uda2e\udcc8\uda07\udef5\udb22\udebe\udb59\ude92\ud8b4\udd55\ud946\udfbd\ud9d4\uddbc\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\ud8e8\udf7c\udbd2\udcb9\udb5b\udcae\udadb\ude6b\ud95f\udd75\udb8a\ude82\udac1\udf67\udb7c\udfa9\udbd4\udf38", "\u7330\u4830\u7ab9\uc7f8\u7f7a\u72df\u7f32\ua96a\u5441", "\ud83e\udde4",
        27, 38212, 1078686476, -7927114084188322771L, 69826L, false, false, (char) 51926, (char) 16543,
        Double.longBitsToDouble(0x3fdab458a79cb6c4L), Double.longBitsToDouble(0x3fee5afb8ef90ed1L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 4, "\ud857\udea9", "\u4720", "\udb22\udebe",
        3, 79997, -1727765553, 4492031256438995578L, -13318L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fed5eac78f679ccL), Double.longBitsToDouble(0x3fd87ca664040032L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 0, "", "", "\udbb6\udecb",
        28, 83920, 419844108, 2140676110223172559L, -13318L, true, true, (char) 32072, (char) 20037,
        Double.longBitsToDouble(0x3fed5eac78f679ccL), Double.longBitsToDouble(0x3fd87ca66405f432L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 4, "\uda28\udc95\udb55\udd81\ud9e7\udef6\ud967\udf4a\uda2e\udcc8\uda07\udef5\udb22\udebe\uda08\udd85\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud923\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8", "\u40e1\u065c\u697b\u77c4\u05f3\u0ad3\u6055\u171b\u0dd9", "\udb9c\ude77\udb94\udfd0\u4614\uda8a\udc17\ud83c\udc31\udb39\udcc3\uda50\udcfd\udac5\udcfa\udab8\udc25\uda66\ude28\ud926\udd0a\ud819\udc84\u6a9e\udab0\ude64\ud917\udd41",
        39, 70879, 1514848127, -5631524344512209719L, 54435L, false, false, (char) 58372, (char) 18122,
        Double.longBitsToDouble(0x3fe3c9b5c356fdf7L), Double.longBitsToDouble(0x3fef58c96d67cf11L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 3, 3, "\u2d15", "\u044a", "",
        -3, 564, 1593128341, 962872909836075457L, 86079L, false, true, (char) 36160, (char) 53101,
        Double.longBitsToDouble(0x3fe88b188fabd58fL), Double.longBitsToDouble(0x3f3e732c3e533000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud857\ude3a]] |a1=[Ljava.lang.String;:[[\ud857\ude3a]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud857\ude3a]] |a1=[Ljava.lang.String;:[[\ud857\ude3a]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 4, "\ud857\ude3a", "\u54b9\ub078\u41dd\u7a37\u5801\u5e20\u4fa5\u152a", "\ud944\uddbf\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\ud956\udeb4\ud82b\ude36\udb36\uddc1\udaee\udcba\ud981\udd46\ud9e0\udf53\ud9c6\uddbc\ud9ae\udf7b\ud9e3\udcc5\ud92e\uddfd",
        12, 42675, 845388690, 4898227299339595177L, -14069L, false, false, (char) 25526, (char) 32018,
        Double.longBitsToDouble(0x3faf3a87f74c1340L), Double.longBitsToDouble(0x3fe4007c1083dc6cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 1, 0, 0, "\ud251", "\u0092", "",
        28, 87108, 149, -5764607521988352351L, -29681L, false, true, (char) 25348, (char) 12910,
        Double.longBitsToDouble(0x3fe888000511de8fL), Double.longBitsToDouble(0x3fe678751da72a7dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 4, "\ud857\udea9\udb7f\udf04\ud9e7\udef6\ud96d\udc68\udb9d\udce0\udbe0\udec1\uda45\udc72\uda20\udd33\ud88f\udf55\ud945\udfbd\ud9d4\ude4d\ud993\udeb4\ud867\udfe6\ud92d\udc58\uda68\udf33\uda56\udefc\udac0\udc90\ud9e1\uded8\ud95b\uddcd\u252e\udbea\udd27\ud991\udec1\ud982\udea8\ud95f\udcea\udb8a\ude82\udac3\udfb0\udb7c\udfa9\ud939\udfba", "\u7330\u4830\u7ab9\uc7f8\u7f7a\u72df\u7f32\u4f0b\u648f\u9d88\u647f", "\u6a9e\udab0\ude64\ud917\udd41\ud966\udd19",
        59, 65038, 1069554226, 3261603487213614186L, 28660L, true, true, (char) 56777, (char) 28122,
        Double.longBitsToDouble(0x3fd6a6e800640432L), Double.longBitsToDouble(0x3fe77e4344ec94a3L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 1, "\u0e01\udb93\udc4e\ud9d0\udf40\ud83d\udc70\ud8da\ude5e\ud9ed\udf20\udb87\udc80\udbec\udd0f\ud92b\udc73\u888b\ud9d4\ude4d\u232f\ue43f\ud92f\uddbf\uda5f\ude27\ud86e\udf08\uda05\udfd2\ud942\udecf\ud95b\uddcd\u252e\uda89\udc56\udaa8\udf51\uda11\ude61\ud830\udf9e\udb8c\uddc2\udac3\udfb0\udb7c\udfa9\ud939\udf94", "\u98d1\u5392\u7ab9\u3e31\uc55b\u1ed2\u6f21\u8d2f\u46da\u9c62\u0fab\u83f8\u8eb4\uc10e\u57d7\u415a\u3ffb\ub4a9\u8f37\u95c0\u88bc\u6476\u4dbc\u0ac6\u1afc\ubda6\u7ae4\u4398\ub0d6\u720f\u4e81\u6760\uce12\u9133\u246e\u9ec1\u0f1e\u7e64\u25fc\ub038\u54e9\uc315\u9dc5\u5b86\ubbe3\ua5e1\ua3e2\u40aa\u9340\ua34b\ud454\u9bed\u6f82\u9042\u866d\u927c\uc140\u478a\u8b8a\uc5b1\u17c5\ub61e\ubf25\u6bd6\ubc2f\u1b88\ud5f1\u39fb\u8b8e\uce6f\u74da", "\ud84d\udf42\ud81d\ude1d\ud94e\udcf0\ud928\udf8c\ud3ae\udafc\udfb6\u0351\uda67\udcf7\uda85\uddae\uda7a\udcdc\ud8fa\udee6\ud9a1\udf72\udac8\udf85\ud939\udee0\ud900\udde1\ud827\udd99\uda1c\udc20\udbba\ude3f\ud832\ude2e\ufbcc\udbaa\udfe3\udb79\udd98\udb3d\udc52\uda63\ude79\udb1d\udfe6\udbeb\udcf0\udb84\ude39\ud8b0\ude21\uda67\udd64\ub115\ud89e\udc3c\uaca3\ud97d\udd1a\ud96d\ude21",
        20, 45971, 1549888676, -3765550836676261972L, -61655L, false, false, (char) 31993, (char) 37691,
        Double.longBitsToDouble(0x3fa032e1586fd5f0L), Double.longBitsToDouble(0x3fe2bc1a41594887L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 5, "\000", "\u4dbf", "\udb22\udebe\014\ud882\uddc0",
        7, 57896, -1073807360, 3157847222948185372L, 5766L, false, false, (char) 58682, (char) 10946,
        Double.longBitsToDouble(0x3fd87ca66326ca32L), Double.longBitsToDouble(0x3fc91e33b40001d4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
