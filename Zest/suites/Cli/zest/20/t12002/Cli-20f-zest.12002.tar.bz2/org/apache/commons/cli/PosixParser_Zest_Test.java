package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55", "\ub161\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u7c5b\u2e98\u8634\u9dae\u5f8a\ubb6a\u51e8\u8a7a\u1a3a\uac18", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\ud9ca\udc3e\uda63\udf8e\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udbca\udd8a\ud91a\udd89\ud83c\udc47\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\uda73\ude26\uda40\udcce",
        51, 54536, -826278009, -8444790185079748632L, 42154L, true, true, (char) 18750, (char) 6795,
        Double.longBitsToDouble(0x3fee17cfe85d3e59L), Double.longBitsToDouble(0x3fe24c5a120e24deL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 0, "\udb19\udf64\ud88b\udeca\uda25\udcc9\ud837\udd61", "\ub7d2\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u618a\u22c4\u3bd5\u809c\u1dc4\u2df8\u426f\u9460\u5197\u7c5b\u2e98\u8634\u9dae\u5f8a\ubb6a\u4b24\u8a7a\ub7da\u945e", "\uda3a\ude1f\udafe\udd2e\u89d2\ud828\udfec\udab5\udf92\udaa7\udd68\ud96f\udc81\ud87a\udf6e\uda93\ude62\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udbca\udd8a\ud91a\udd89\ud83c\udc47\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\uda69\udf81\uda21\udf2c",
        51, 54536, -826278009, -8444790185079748632L, 19894L, true, true, (char) 18750, (char) 6795,
        Double.longBitsToDouble(0x3fee17cfe85d3e59L), Double.longBitsToDouble(0x3fe3a3fa120e24deL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55", "\ub161\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u2dcd\u1a90\ucc87\u9dae\u5f8a\ubb6a\u7a29\u8a7a\u1a3a\uac18", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\u3be2\ud9dc\udcff\ud80b\udc56\ud9c4\ude7c\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udbca\udd8a\u6980\ud93c\udc47\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udab6\udf20\ufc94\uda40\udcce",
        51, 54536, -826278009, -8444790185076013080L, 42248L, true, true, (char) 18750, (char) 6795,
        Double.longBitsToDouble(0x3fee17cfe85d3e59L), Double.longBitsToDouble(0x3fe24c5a120e24deL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 3, "\ud992\udf2b\ud89c\ude65\udb61\udd56\u286e", "\ub161\u0117\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u7c5b\u2e98\u8634\u9dae\u5f8a\ubb6a\u51e8\u8a7a\u1a3a\uac18", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\uda2f\udefa\udb4a\udfc7\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udb7f\udec5\udb23\udcd7\ud83c\udc67\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\udad5\udc56\uda40\udcce",
        51, 54032, -836174340, -8444790185079748632L, 42154L, true, true, (char) 18750, (char) 6795,
        Double.longBitsToDouble(0x3fee17cfe85d3e59L), Double.longBitsToDouble(0x3fe24c5a160e24deL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55]] |a1=[Ljava.lang.String;:[[\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 0, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55", "\ub161\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u7c5b\u2e98\u8634\u9dae\u5f8a\ubb6a\u51e8\u8a7a\u1a3a\uac18", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\ud9ca\udc3e\uda63\udf8e\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udbca\udd8a\ud91a\udd89\ud83c\udc47\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\uda73\ude26\uda40\udcce",
        51, 54536, -826278009, -8444790185079748632L, 42154L, true, true, (char) 18750, (char) 6795,
        Double.longBitsToDouble(0x3fee17cfe85d3e59L), Double.longBitsToDouble(0x3fe24c5a120e24deL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\ud992\udf2b\ud89c\ude65\ud804\udf65\ud874\udd55", "\ub161\u6b0e\u5ad8\u87f1\u52cc\u0181\u3e83\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\u0978\u3ddb\u9460\u5197\u7c5b\u2e98\u8634\u8fdb\u5f8a\ubb6a\u51e8\u8a7a\u1a3a\uac18", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\ud9bd\ude74\ud953\ude98\udb2b\udc92\uda63\udf8e\uda14\udffb\udafc\ude7b\uda17\udc35\ud918\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udbca\udd8a\ud91a\udd89\ud83c\udc47\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\uda73\ude26\uda40\udcce",
        51, 87256, -822400971, -8444790185079748632L, 78913L, true, true, (char) 39656, (char) 13891,
        Double.longBitsToDouble(0x3fe72992ccc09dcaL), Double.longBitsToDouble(0x3fee17cfe85d3e59L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 4, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55", "\u3cf6\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u7c7a\u2e98\u8634\u9dae\u5f8a\ubb6a\u594f\u363f\u1a3a\uac83", "\uda3a\ude1f\udafe\udd2e\ud906\udc23\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\ud9c2\uddfb\udafe\udd97\ud80b\udc56\udafc\ude7b\uda17\udc35\ud827\udce3\ud8d6\ude01\ub1d0\udace\udced\ud9bd\udcd1\udb34\udff1\ud850\udc06\udbca\udd8a\ud91a\udd89\ud81c\udc56\ud8ac\ude4c\ud964\uddd2\udb15\udffd\uda0f\udee1\ud99f\udfe5\udb82\udc97\uda49\udd71\uda40\udca0",
        51, 54536, 428082823, -8444790103475370008L, 42154L, true, true, (char) 18750, (char) 6795,
        Double.longBitsToDouble(0x3fee17cfe85d3e59L), Double.longBitsToDouble(0x3fe24c5a120e24deL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 0, "\ud97f\udedd\udb29\udde9\uda8c\udebc\ud874\udd55\ud950\ude32\ud96c\uddfd\udb41\udffb\udbee\udf88\ud945\udc52\uda8a\udc20\ueb00\ud82d\udc39\ud9af\udd68\udaf7\udcb0\udbdd\udec2\uda62\udc9a\ud92b\udf3d\ud93e\udcf7\ud922\ude3e\udab9\ude08\ud873\udf52\udb40\udd95\u16f6\ud886\ude93\udb60\ude99\ud864\udd99\ud821\udfa0\ud98e\udee7\ud9db\udf07", "\u09e5\u5db2\uac18\u715c\u2c66\u76c8\u8625\ud096\u6368\u87c6\u6ca3\u142b\u675d\u9653\u3393", "\ud92b\udcc9\ud8d6\ude01\udb89\udcc4\ud907\uddb5\udaf0\udfb2\ud96b\udd41\ud87c\udf82\udbca\udd8a\ud91a\udd89\udbd8\udc48\ud8cf\ude70\udb03\udc0b\udbeb\udde9\uda07\udd89\udb59\udc41\udb82\udc97\uda73\ude26\udb3c\udcbe\uda21\udea5",
        46, 1991, -1966205934, -5792253746489747172L, 20799L, false, true, (char) 27591, (char) 18750,
        Double.longBitsToDouble(0x3fc813b94f083674L), Double.longBitsToDouble(0x3fb74f96724c5a10L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud840\uddfb\ud950\uddb9\ud8c5\udec8\ud9c6\udfef", "\u455f\u0639\u836f\u3e23\ub708\u851e\u61ed\u68c4\u3bd5\u809c\u1dc4", "\u16f6\ud886\ude93\udb60\ude99\udbd9\udcb4\ud817\udccb\ud823\uddea\ud9db\udf07\udbf3\udc58\ud914\udf25\ud840\uddf8\ud9aa\uddba",
        51, 21775, -1805971718, 809972238129813514L, -46043L, false, false, (char) 30428, (char) 25217,
        Double.longBitsToDouble(0x3fbee974782213e0L), Double.longBitsToDouble(0x3fe439d6c691a00fL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55", "\ub161\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u7c5b\u2e98\u8634\u9dae\u5f8a\ubb6a\u51e8\u8a7a\u1a3a\uac18", "\uda1f\udf03\ud89f\udd3f\ufca6\ud921\udcc8\u7494\udaa7\udd68\ud96f\udc81\ud9ca\udc3e\uda63\udf8e\udafd\udc4f\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24",
        31, 57194, 592674678, 7361753183892376796L, -47646L, false, false, (char) 62180, (char) 50103,
        Double.longBitsToDouble(0x3fd48ebcef0f2ba6L), Double.longBitsToDouble(0x3f92cebffd1159c0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\ud992\udf2b", "\ubad7\u4017", "\uda33\ude00",
        14, 48364, -1753845217, 9004348585934921269L, -41957L, true, true, (char) 34733, (char) 31052,
        Double.longBitsToDouble(0x3fe8324c42b37776L), Double.longBitsToDouble(0x3fd843896a5a3d44L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 4, 2, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud858\udf08", "\ud26b\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u229e\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u7c5b\u2e98\u8634\ubbce\u5ff2\ubb6a\u51e8\u8a7a\u1a3a\uac18", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\ud9ca\udc3e\uda63\udf8e\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud98f\uddf8\udabf\udf4c\ud860\ude40\udbca\udd8a\ud91a\udd89\ud83c\udc47\ud8ac\ude4c\udb0d\udf0b\uda43\udc74\uda0f\udf70\udb59\udc41\uda85\udc59\uda46\udd27\uda40\udcce",
        51, 54536, -826278009, -4889280983396876528L, 23361L, false, false, (char) 40716, (char) 13891,
        Double.longBitsToDouble(0x3fe72992ccc092f5L), Double.longBitsToDouble(0x3fee17cfe85d3e59L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\u46ab", "\u1c3c\ub38e", "\uda33\ude00",
        14, 48364, -1753845217, 9004348585927507968L, -100000L, false, false, (char) 52229, (char) 43561,
        Double.longBitsToDouble(0x3fd843896a5a3d44L), Double.longBitsToDouble(0x3fe74a56944d44bcL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\ud992\udeef\ud89c\ude65\ud804\udfd8\ud874\udd55", "\ub161\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\ua9d2\u3ddb\ud6af\u20c9\u7bde\u2e98\u8634\u9dae\u5f8a\u8130\u51dd\u8a7a\u1a3a\uac18", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\ud9ca\udc3e\uda63\udf8e\ud80b\udc56\udafc\ude7b",
        16, 41161, -854893310, 153036282828054451L, -38633L, false, false, (char) 30970, (char) 22231,
        Double.longBitsToDouble(0x3fcb8cc55f80e804L), Double.longBitsToDouble(0x3fd8ca15c5ebab20L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 3, "\uda80\udf33\ud915\uddc1\ud805\udc4b\ud874\udd55\ud94e\udf1d\ud8c5\udec8\ud9c6\udfef\uda33\ude00\ud8fe\udc59\uda39\udd1a\uda70\udc90\ud886\ude60\ud9af\udd68\udaf0\udf0f\udbca\udcc5\udb4a\udf38\ud818\ude35\ud960\udd03\uda37\ude71\ud947\ude8f\uda8d\udf10\udb40\udd95\ud858\ude49", "\u972e\u8cb8", "\udbf3\udc58\uda5d\udd28\ud840\uddf8\udb08\udc6a\udaa9\udce1\u0cc3\u48a2\udb95\ude6c\udaa8\udf2a\ud943\udccc\ud921\udcc8\ud957\udd5b\udb9d\udeaf\ubff3\ud82d\udc7d\uda63\udf8e",
        52, 71340, 478798495, 7605417109241945346L, 55571L, false, false, (char) 64869, (char) 38345,
        Double.longBitsToDouble(0x3fe8935443842353L), Double.longBitsToDouble(0x3fcb8cc55f80e804L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\uda50\ude24", "\u4ff4\u6a7d\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\u7982\u3ddb\u9460\u5197\u7c5b\u2e98", "\ud9db\udf07",
        18, 55373, 960951960, 5662033093288936550L, -46043L, false, false, (char) 30428, (char) 26311,
        Double.longBitsToDouble(0x3fbace97f82213e0L), Double.longBitsToDouble(0x3fe439d6c6911c89L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 2, 4, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55\ud950\ude32", "\u5d21", "\udb88\udff5\ud8b5\udeb2\ud9af\udd68\udaf7\udcb0\ud980\udfa0",
        4, 50695, 1233702062, 8608211800507691699L, 77453L, true, false, (char) 10505, (char) 62562,
        Double.longBitsToDouble(0x3fd9170ab89be6f0L), Double.longBitsToDouble(0x3f74216eaa6e2380L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55]] |a1=[Ljava.lang.String;:[[\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 0, 6, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55", "\ub161\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u1334\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u5294\000\u85e7\u9dae\u5f8a\ubb6a\u51e8\u8a7a\000\u67b2", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\ud9ca\udc3e\uda63\udf8e\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udbca\udd8a\ud91a\udd89\ud83c\udc47\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\uda73\ude26\uda40\udcce",
        -2, 54536, -826278009, -8444790185079748632L, -100000L, false, false, (char) 18661, (char) 6795,
        Double.longBitsToDouble(0x3fee17cfe85d3e59L), Double.longBitsToDouble(0x3fe24c5a120e24deL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 1, "\ud980\uddfe\ud89c\ude65\ud804\udfd8\ud874\udd55", "\u7361\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u4ea3\u8b72\u7883\ua086\u1dc0\u7157\u06ed\u9460\u6bf6\u2b16\u769a\ub5d2\u9dae\u5f8a\ubb6a\u51e8\u8a7a\u1a3a\uac18", "\uda3a\ude54\udb0b\uddf4\uda79\udd0c\ud8b1\udc04\udac5\udc87\udaa7\udd68\ud96f\udc81\ud9ca\udc3e\uda94\udfa7\ud80b\udc56\ud9a0\udd2e\uda31\udfc5\udb3e\ude9f\ud8d6\ude01\ub1d0\udb62\udf37\udba0\udd22\udb34\udfb2\udb88\udc33\udbca\udd8a\ud91a\udd89\ud83c\udc47\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\uda73\ude26\uda40\udcce",
        53, 54536, 1854275463, -8444789656798771224L, -59259L, false, false, (char) 35813, (char) 37860,
        Double.longBitsToDouble(0x3fe72ec934c09dcaL), Double.longBitsToDouble(0x3fee17cfee9c7fdbL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55]] |a1=[Ljava.lang.String;:[[\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 4, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55", "\ub945\u5d21\u9c6f\u44b0\u0639\u836f\ub446\u3a9d\u851e\u61ed\u22c4\u3bd5\u809c\u2a81\uc20a\u3ddb\u9460\u5197\u7c5b\u2bed\u7b4d\u9dae\u5f8a\ubb6a\u51e8\u538f\u1620\uac18", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udb88\udd74\ud935\udc81\uda75\udf64\udb7b\udd68\uda8e\udc8d\ud879\ude97\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\ud921\udf9a\ud877\uded1\u8355\udb78\ude2d\u9470\ud963\ude39\udb0d\udf28\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\uda73\ude26\uda40\udcce",
        51, 75079, -826278009, -8444790185079748632L, 48413L, true, true, (char) 30474, (char) 58393,
        Double.longBitsToDouble(0x3fee1544785d3e59L), Double.longBitsToDouble(0x3fe24c5a120e24deL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\ud992\udf2b\ud89c\ude65\ud83a\ude35\udb86\ude38", "\ub161\u5d21\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u7c5b\u2e98\u8634\u9dae\u5f8a\ubb6a\u51e8\u8a7a\u1a3a", "\u48a2\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\ud9ca\udc3e\uda63\udf8e\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udbca\udd8a\ud91a\udd89\ud83c\udc47\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\uda73\ude26\uda40\udcce\ud92b\udeaa\ud8af\udf06\udbf1\udc9f\udbb3\udd29\ud8f8\udf2b\ud8da\udd15\ud90d\udf01\ud851\ude6b\udbdd\udd92\uda34\ude74\ud932\udd1b\ud92b\udc65\uda85\udf6e\udb1c\udd7b\ud8cc\udc75\ud82d\udde5\ud9af\udcd9\ud83b\ude68\udaa5\udf56\udb1f\udfe6\ud826\udf18\uda5e\uddfd\uda9e\udeb5\ud8a7\udd27\u7680\uda68\udd87\udacc\uddf4\ufd74\ud8d3\udcb8\ud808\uddaa",
        46, 91019, 1176673007, 4933764522920975033L, -39104L, false, false, (char) 20630, (char) 56937,
        Double.longBitsToDouble(0x3fdc4813198213c2L), Double.longBitsToDouble(0x3fb53b49544da198L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud904\uddb3\ud87e\udc7e\ud804\udfd8\ud874\udd55\ud950\ude32\ud8c5\udec8]] |a1=[Ljava.lang.String;:[[\ud904\uddb3\ud87e\udc7e\ud804\udfd8\ud874\udd55\ud950\ude32\ud8c5\udec8]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \ud904\uddb3\ud87e\udc7e\ud804\udfd8\ud874\udd55\ud950\ude32\ud8c5\udec8]] |a1=[Ljava.lang.String;:[[\ud904\uddb3\ud87e\udc7e\ud804\udfd8\ud874\udd55\ud950\ude32\ud8c5\udec8]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 5, "\ud904\uddb3\ud87e\udc7e\ud804\udfd8\ud874\udd55\ud950\ude32\ud8c5\udec8", "\u999c\u44b0\u0639\u836f\u3e23\u9209\u395b\u61bd\u22c4\uc8ab\u4ba4\u43b1\ua9d2\u7117\u3348\u97ce\ubf85\u2463\u6981\u53c7\u0bc4", "\ud840\uddf8\udaaf\udd6f\u1e7a\ud99e\udc7a\u48a2",
        33, 34514, -1734796508, -4989042078929529129L, 97662L, true, false, (char) 29056, (char) 17672,
        Double.longBitsToDouble(0x3fe488e44d02698bL), Double.longBitsToDouble(0x3fa2e68599adaf60L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 0, "\ud992\udf2b\ud89c\ude65\udb61\udd56\ud921\udc37\udbd8\ude39\ud8d5\uded9\ud9c6\udfef\uda52\uddf5\ud858\ude11\uda89\udf68\udb88\udff5\ud8b5\udeb2\ud9af\udd68\udaf7\udcb0\ud8da\udfa2\ud87f\ude91\ud80c\udcad\ud960\udd03\ud8f8\ude10\udab9\ude08\ud873\udf52\udb40\udd95\u16f6\ua4e5\udb60\ude99\udbd9\udcb4\ud817\udccb\ud823\uddea", "\u367f\u8a7a\u1a3a", "\u48a2\uda3a\ude1f\udbea\udfe2\u8a7c\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\uda2f\udefa\udb4a\udfc7\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udb7f\udec5\udb23\udcd7\ud83c\udc67\ud8ac\ude4c\udb0d\udf0b\udb15\udffd\uda0f\udee1\udb59\udc41\udb82\udc97\udaba\udc56\uda40\udcce\ud92b\udeaa\ud8bc\udfcc\ud820\udf0c\udbb3\udd29\ud8f8\udf2b\ud8c6\ude15\ud90d\udf01\ud8a7\udc36\udb83\udcd3\uda34\ude74\ud932\udd1b\udb00\udda8\ud8d6\udc7e\udb1c\udd7b\ud8cc\udc75\ud98d\udff4\udad3\ude92\udbcf\udc1e\ud838\ude63\ud884\udeb3\udab4\uded2\uda1d\uddcd\uda33\udc78\ud8af\udeb7\ud955\udd73\udb3b\udd83\ud8af\udcd3\udbb7\ude9e\uda6f\udc7b\ud8aa\udec7",
        9, 12209, 1261844252, 6775527039446097253L, 66128L, false, false, (char) 38929, (char) 63106,
        Double.longBitsToDouble(0x3fca58d5899f8660L), Double.longBitsToDouble(0x3fdb2affdbc51bf2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 1, 3, "\u00ab", "\u8a4a", "\udbc7\udcef",
        -3, 4474, 1508686364, -7532707847164534955L, -52446L, true, true, (char) 41432, (char) 34733,
        Double.longBitsToDouble(0x3fc5d593cc192620L), Double.longBitsToDouble(0x3fe59bbbb5843896L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 3, "\ud992\udf2b\ud89c\ude65\udb61\udd56\u286e", "\ub161\u0117\u999c\u44b0\u0639\u836f\u3e23\ub708\u851e\u61ed\u22c4\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197\u7c5b\u0dc2\u8475\u9dae\u771c\u9c8a\u51e8\u8a7a\u1a3a\uac18", "\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud95e\udf81\uda2f\udefa\udb4a\udfc7\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\udbe0\ude06\ub1d0\udb62\udf37\ud84a\udf24\udb34\udfb2\ud860\ude40\udb7f\udec5\udb23\udcd7\ud83c\udc67\ud8ac\ude4c\ud950\ude4c\ud99a\udf67\ud8b9\udf60\udb59\udc07\udb82\udc97\udad5\udc56\uda40\udcce",
        51, 54032, -836174340, -8444790185079748665L, 42154L, true, true, (char) 18750, (char) 6795,
        Double.longBitsToDouble(0x3fee17cfe85d3e59L), Double.longBitsToDouble(0x3fe24c5a160e24deL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud992\udf2b]] |a1=[Ljava.lang.String;:[[\ud992\udf2b]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud992\udf2b]] |a1=[Ljava.lang.String;:[[\ud992\udf2b]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud992\udf2b", "\ubad7\u4017", "\uda33\ude00",
        14, 48364, -1753845217, 9004348585934921269L, -100000L, false, false, (char) 0, (char) 30894,
        Double.longBitsToDouble(0x3fe8324c42b37776L), Double.longBitsToDouble(0x3fd843896a5a3d44L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 2, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55", "\u3cd6\u5d21\u999c\u44b0\u71a8\u4043\u3e2a\ub708\u851e\u152d\u22c4\u3bd5\u2c7a\u1d18", "\u16f6\ud886\ude93\ud894\udd97\udbd9\udd32\ud817\udccb\ud836\uddf1\uf03a\udbf3\udc58\ud975\udd97\udb31\udde8\ud9aa\uddba",
        28, 21775, 2053246714, 809972238129813514L, 23527L, true, false, (char) 33891, (char) 32443,
        Double.longBitsToDouble(0x3fed9810fd8914dcL), Double.longBitsToDouble(0x3feaabc621a24398L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud992\udf2b\ud89c\ude65\ud804\udfd8]] |a1=[Ljava.lang.String;:[[\ud992\udf2b\ud89c\ude65\ud804\udfd8]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 2, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8", "\u5da8\u3cf6\ud0fa\000\000\000\u7c19\u3e23\ub708\u851e", "\uccae\ud8d7\udf0a\udab9\ude08\ud873\udf52\udb40\udd95\u16f6\ud886\ude93",
        31, 61338, 140207181, -2573983086943548076L, -755L, true, false, (char) 52791, (char) 37732,
        Double.longBitsToDouble(0x3fafbfff6fa47d00L), Double.longBitsToDouble(0x3fd767a62014167aL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 5, 6, "\ud97f\udedd\udb29\udde9\uda8c\udebc\ud874\udd55\ud950\ude32\ud96c\uddfd\udb41\udffb\udbee\udf88\ud945\udc52\uda8a\udc20\ueb00\ud82d\udc39\ud9af\udd68\udaf7\udcb0\udbdd\udec2\uda62\udc9a\ud92b\udf3d\uda43\ude39\ud922\udecc\udab9\ude08\ud873\udf52\udb40\udd95\u16f6\ud886\ude93\udb60\ude99\ud96d\udcc5\ud821\udfa0\ud98e\udee7\ud9db\udf07", "\u09e5\u5db2\uac18\u715c\ua3bf\u8841\uc2f6\ud096\u6368\u87c6\u6ca3\u142b\u3609\u67ad\u3393", "\ud92b\udcc9\ud8d6\ude01\udb89\udcc4\ud907\uddb5\udaf0\udfb2\ud96b\udd41\ud87c\udf82\udbca\udd8a\ud91a\udd89\udbd8\udc48\ud8cf\ude70\udb03\udc0b\udbeb\udde9\uda07\udd89\udb59\udc41\udbbe\udc6c\udb7a\udd09\udb3c\udcbe\uda21\udea5",
        6, 1991, -1966205934, -5792253746489747172L, 20799L, false, true, (char) 27591, (char) 18750,
        Double.longBitsToDouble(0x3fc813b94f083674L), Double.longBitsToDouble(0x3fb74f96720c5a10L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 3, "\ud83e\udf71\ud915\uddc1\ud805\udc4b\ud9ec\udd91\udbc8\udec4\uda0e\udc4b\uda0a\udcea\udbc5\uddc6\uda99\udd48\udaf6\udf77\uda46\udf25\ud886\ude60\ud9af\udd68\udaf0\udf0f\udbca\udcc5\uda0f\udf4d\ud941\udf37\ud892\udcec\udb81\udd97\ud947\ude8f\uda1c\uddb7\ud940\uddfd\ud858\ude49\udaee\udc6a\u7dcd\ud9e2\ude58\ud841\udf92\ud8f3\udca6\ud9db\udf2a\udbf3\udc58\ud8e9\udf8f\ud840\uddb2\udb08\udc6a\ud97e\uddcd\u0c7b\udaee\uddcf\udb95\ude6c\udaa8\udf2a\ud8ca\uddd1\udbec\udcf3\ud884\ude26\ud86c\udc7e\uc032\ud82d\udc7d\uda63\udf8e\ud80b\udc56\udafc\ude7b\udb79\udeff\ud80f\udf15\u2588\ub14f\u4690\ud89b\ude29\udbeb\ude30\ud8ba\udc32\udb92\udeaa\ud91a\udd89\ud83c\udc47\udb4f\udf1d\ud989\udfb7\u7bd0\ud9f7\ude82", "\u27c1\u08c9\uad84\ud62a\u7510\u0e38\ud7cf\u4d19\u0191\u60cc\u3735\ua32d\u5c70\u0ae4\ubda1\ud77b\u7e91\u8f18\u85f5\u695f\u2780\u9217\ubc97\ua93e\u7f83\uc21e\u27a9\ucbff\u1933\ub635\u825d\u19fc\u8987\u58cd\u6dc4\uac10\u8cfc\u86e9\ua35a\u65c7\u9a16\u3a8e\u325b\u37c9\u547c\u4a63\u55d9\u8617\u9d52\ud508\uc898\u2ba1\u6ff3\u73e0\u3d9c\uc201\uc35a\u54c8\u0e2f\u1504\u5769\u7043\u67a5\u05e6\u1641\u1690\ud6e5\ubbf3\u8b34\uaee2\u8058\u3aaa\ud3e7\ubc8e\u4142\u1bf9\u06d2\u26be\u1a4e\u1622\u734e", "\udb52\udf88\udbbc\udd2f\ud8e6\udecc\ud990\udf0d\udb49\uddfe\ud914\uddfa\uda83\ude65\udb4a\ude42\ud9b4\udce5\ud82d\udcf8\udaa9\uddf4",
        15, 40600, -1197819714, 5077330906973909236L, 73421L, false, true, (char) 41247, (char) 5369,
        Double.longBitsToDouble(0x3fd2cd8a296c79faL), Double.longBitsToDouble(0x3fea2dc708bb9a28L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \ud992\udf2b]] |a1=[Ljava.lang.String;:[[\ud992\udf2b]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 0, 0, "\ud992\udf2b", ";\000", "",
        21, 4474, 1508686364, -7532707847164534955L, -52446L, true, true, (char) 41432, (char) 34733,
        Double.longBitsToDouble(0x3fc5d593cc192400L), Double.longBitsToDouble(0x3fe59bbbb5843896L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 1, 3, "\u00ab", "\000", "",
        24, 30952, 178, 6413125867621741087L, -26731L, false, false, (char) 753, (char) 41432,
        Double.longBitsToDouble(0x3fd97000095d593cL), Double.longBitsToDouble(0x3f32620000000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 3, ">", "\u8a4a", "\udbc7\udcef",
        -3, 99874, -1216066009, -7502212548570783915L, -93769L, true, true, (char) 41432, (char) 18093,
        Double.longBitsToDouble(0x3fc5d58856a52620L), Double.longBitsToDouble(0x3fd2ecd7670ff14eL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 3, 0, "\u00ab", "", "",
        -5, 50144, 48128, -5659335880235763172L, -52446L, true, true, (char) 41432, (char) 34733,
        Double.longBitsToDouble(0x3f4593cc00000000L), Double.longBitsToDouble(0x3fe59bbbb5843896L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 6, 1, "\ud992\udf2b\ud89c\ude65\ud804\udfd8\ud874\udd55\ud950\ude32\ud8c5\udec8\ud9c6\udfef\uda33\ude00\ud858\ude11\uda89\udf68\udb88\udff5\ud8b5\udeb2\ud9af\udd68\udaf7\udcb0\ud980\udfa0", "\u3bd5\u809c\u1dc4\ua9d2\u3ddb\u9460\u5197", "\ud9bf\ude40\udb68\udec3\ud886\udebe\udb5b\udea5\ud8c4\ude06\ud840\uddf8\ud9aa\uddba\udbe8\udff0\ud99e\udc7a\u48a2\uda3a\ude1f\udafe\udd2e\u89d2\ud921\udcc8\udac5\udc87\udaa7\udd68\ud96f\udc81\ud9ca\udc3e\uda63\udf8e\ud80b\udc56\udafc\ude7b\uda17\udc35\ud92b\udcc9\ud8d6\ude01\ub1d0\udbe4\udeeb\ud9be\udeeb",
        55, 57194, 592674678, -3230713139683026164L, -47646L, false, true, (char) 14476, (char) 50103,
        Double.longBitsToDouble(0x3fd48ebcef0f2ba6L), Double.longBitsToDouble(0x3f92cebf3d1159c0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
