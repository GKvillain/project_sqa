package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\ucbb7\u249a\u7d4a\u00e7\u1ada\uac58\u2d2a\u1113\uaa5a\u3ff1\u688f\uc1a7", "\udb58\ude95\ud980\udc7f\ud90e\udcee\udab0\udfb4\udbae\udc2e\ud9fc\udf12",
        52, 32602, 465883375, 3175815683787672064L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\ud84b\udc29\ud8c9\ude19\udb19\udf3c\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\ud511\u249a\u7d4a\u00e7\u64a1\uac58\u8904\u9890\uaa5a\u9c16\u693c\uc1a7", "\uda7d\udfc9\ud980\udc7f\ud90e\udcee\udb6a\udd48\udbad\udfc5\udad9\udd40",
        50, 32602, 465883375, 3175815682973059584L, -26060L, false, true, (char) 25254, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\ud83b\udd00\udb78\ude71\ud81b\udd89\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\u311d\u249a\u7d4a\u00e7\u43fc\u7a45\u8d75\u1113\uaa5a\u3ff1\ub9af\uc1a7", "\udb58\ude95\ud980\udc7f\ud90e\udcee\udab0\udfb4",
        30, 28490, -1635391558, 8163236472145891567L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67cb6ac4dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\ud83b\udd00\ud92d\udeac", "\uc1ab\u0bbc\u3623", "\udaec\udfa1\ud811\udd8d",
        -3, 31056, -1537377896, 3880594006176217541L, -99602L, false, true, (char) 51410, (char) 21132,
        Double.longBitsToDouble(0x3fe774f5ea703583L), Double.longBitsToDouble(0x3fd482d24fea4248L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 11, "\ud83b\udd00\ud92d\udeac\ud98c\udd48\udbb9\udc6c\ud857\udcdc", "\uca4b", "\ud811\udd8d\uda0f\udd66\uda07\udf22\uda11\udc31\udba3\uddcc\ud9bf\udd0c\udb88\ude1f\ud9be\udf55\ud8bc\udd7f\udbb5\udcac\udb80\ude50\ueb3c",
        11, 23358, 757391984, 2388079090405951477L, -75427L, false, true, (char) 53682, (char) 25479,
        Double.longBitsToDouble(0x3fe2736c2c799006L), Double.longBitsToDouble(0x3fc7649bfee80e5cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 11, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\uda30\udddd\ud9a6\udc6a\ud980\ude72\ud89b\ude81\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\ucbb7\u249a\u7d4a\u00e7\u1ada\uac58\u2d2a\u1113\uaa5a\u3ff1\u688f\uc1a7", "\udb58\ude95\ud980\udc7f\ud90e\udcee\udab0\udfb4\udbae\udc2e\ud9fc\udf12",
        52, 1026, 1969555899, 3359225669438884366L, 54598L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 13, "\ud989\udc58\ud960\uddd2\ud81f\ude8c\uda74\ude14\ud864\ude3a\uda0d\udc12\ud804\udd56\ud8c0\udcfe\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\u3efa\u0fe8\ub1b1\u00e7\u1ada\ub1f9\u2d2a\ub60e\u7ea3\u3ff1\u688f\uc1a7\u953f", "\ud980\udc7f\uda94\udd6b\udbe1\udee7\ud9fd\udd8b\ud9fc\udf12\udaca\udd82\ud8c6\uddbc\udbba\ude91\udba3\ude22\ud941\udeb7\ud953\udd1c\udbfd\udeae",
        58, 8713, -452703800, 1022017067736321491L, -156L, false, true, (char) 5398, (char) 56060,
        Double.longBitsToDouble(0x3fc81bfc66c2c308L), Double.longBitsToDouble(0x3fed3aab4c9b5b03L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud9dd\uddb3\ud89b\uded0\udaec\udfa1\ud811\udd8d\uda0f\udd66\uda0d\udc22\uda11\udc31\ud9c3\udedc\ud9bf\udd0c\ud877\udf97\ud9a1\udc4b\ud89f\udd90\udbb5\udcac\udb80\ude50\ueb3c\udaa5\ude9d", "\u688f\uc1a7\ud164", "\ud980\udc7f\ud90e\udcee\udb29\udc6f\ud95f\ude1d\ud9e7\udce0\ud97c\uddfb\ud846\udeff\udbba\ude91\udb8c\udcb5\ud941\udeb7\udb1d\udd21\udbfd\udeae",
        58, 19201, 242735747, 1022017853715336659L, 5728L, true, true, (char) 23638, (char) 24627,
        Double.longBitsToDouble(0x3fe69f2d63241df6L), Double.longBitsToDouble(0x3fe8c2a36a7cb68aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\ud83a\ude9c", "\u6b6b\u1b4d\ub9e2\u3684\u24c5\u99f6\u7bba\u7bf2\u5c2d\u6573", "\ud9bf\udd0c",
        30, 65149, -604705889, -2163981330556593396L, 66823L, false, false, (char) 6131, (char) 22124,
        Double.longBitsToDouble(0x3fefa909214cb72fL), Double.longBitsToDouble(0x3fefeb0eab94fedcL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\udb31\udcfb\000\u140d\000\ud864\ude53\ud850\udc07\u0091", "", "\uda0f\udd66",
        11, -1000, 0, 0L, -100000L, false, false, (char) 56063, (char) 62360,
        Double.longBitsToDouble(0x3fb640001774f5e8L), Double.longBitsToDouble(0x3fe381ac19482d24L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 11, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\ucbb7\u8eac\u7cb0\u00e7\u1ada\uac58\u2d2a\u1113\uaa5a\u3ff1\u688f\uc1a7", "\udb58\ude95\ud980\udc7f\uda8c\udfec\udab0\udfb4\udbae\udc2e\ud9fc\udf12",
        52, 32602, 465883375, 3175815683787672064L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f59cfL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 1, 0, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u2789\ucafc\u249a\u91bc\u0223\u1ada\uac58\u3e85\u1113\ub120\u8322\u688f\u7c06", "\udb58\ude95\ud9b9\udcb0\ud90e\udcee\udab0\udfb4\udbae\udc2e\ud9fc\udf12",
        32, 32602, -551041403, -5366554985326050681L, 90143L, false, true, (char) 35698, (char) 22981,
        Double.longBitsToDouble(0x3fee98774d6b252eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\udead\ud83e\udfaa\ud811\udd8d", "\uacfc\u0384\ucbb7\u249a\u7d4a\u00e7\u1ada\uac58\u2d2a\u1113\uaa5a\u3ff1\u688f\uc687", "\udb58\ude95\uda87\udd19\ud90e\udd5e\udab0\udfb4\udbae\udc2e\ud9fc\udf12\ud97c\uddfb",
        52, 70375, 739427210, -4015159180777122907L, -21014L, true, true, (char) 64833, (char) 65097,
        Double.longBitsToDouble(0x3fdd30e2e4b3699eL), Double.longBitsToDouble(0x3fbfc023f96ce5f0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\udac3\udec4\ud92d\udeac", "\u3461\u4574\u361c", "\udaec\udfa1\ud811\udd8d\uda0f\udd66\ud9bd\uddba\uda10\udfdf\ud9c3\udedc\ud9bf\udd0c\ud877\udf97\ud9a1\udc4b\ud8bc\udd7f\udbb5\udcac\udb80\ude50\ueb3c\udbe6\udc41\udab9\uddcf\udb48\udca9\udbf2\udf3b\ud9bc\udfaa\udbd3\udf0f\udb35\udfeb\udb58\ude95\ud980\udc7f\ud90e\udcee\udab0\udfb4\udbae\udc2e\udb4e\udcba\ud97c\uddfb\ud9fc\udd3a\udb51\ude8c\udba3\ude22\ud941\udeb7\ud953\udd1c\udaee\udec6\udaae\udfe7\ud8ca\udf55\ud8ec\udf5d\udbe8\udca8\uda76\udd48\ud864\udfbb\uda3c\udf7d\u9142\ud8a5\udf2c\udadd\udddc\ud9b3\udcd9\ud8cb\udfbf\udbff\udddb\ud827\udeba\ud964\ude04\uda56\udf7e\ud9ad\udc96\udbf0\ude22\udbfd\ude49\udbba\ude3c\ud90d\ude26\ud869\udd96\udad8\udd46\uda78\udeeb\u6eae\uda48\udcfe\ud837\udd5a\ud853\udec1\uda49\udda2\udbf7\udcfd\udb0f\udf69\udb2a\udf59\ud9ca\udc17\uda52\uddb1\udbce\udf24\ud94c\udc89\uda2b\udc2c",
        15, 91885, 1450606138, 2061189876283933818L, -9495L, false, false, (char) 52905, (char) 20594,
        Double.longBitsToDouble(0x3fc150cc842dc9dcL), Double.longBitsToDouble(0x3fedf440b9b32119L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\ucbb7\u249a\u7d4a\u00e7\u1ada\uac58\u2d2a\u1113\uaa5a\u3ff1\u688f\uc1a7", "\udb58\ude95\ud980\udc7f\ud8fa\ude03\udab0\udfb4\udbae\udc2e\ud9fc\udf12",
        52, 32602, 465883375, 3175815683787672064L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 13, "\uda77\udf04\udb78\udd88\ud8cd\udfa8\ud9a8\udf21\udb0a\udc06\ud911\udf8a\ud981\udf6d\ud91a\udd80\udb92\udcea\udaf3\ude96\uda7a\ude21", "\u2abd\ua348\ucb01\u249a\u7d4a\u00e7\u1ada\u8d26\ud126\u4607\ub085\uce59\u8f5b\u5be6", "\udaab\udde8\ud960\udd92",
        40, 85814, -1548809102, -809967706505383655L, -39584L, true, true, (char) 28749, (char) 49964,
        Double.longBitsToDouble(0x3fc15b51ffaddf20L), Double.longBitsToDouble(0x3feb749d75980e2eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\ucbb7\u249a\u7d4a\u00e7\u1ada\u88a3\u2d2a\u1113\uaa5a\u3ff1\u688f\u2970", "\udb58\ude95\ud980\udc7f\udb72\ude81\uda8c\udd66\udbae\udc2e\ud9fc\udf12",
        52, 32602, 12898543, 3175815091082185216L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 13, "\ud83b\udd00\ud92d\udeac\ud85c\uddf9\ud918\udfde\ud864\ude53\ud894\udfd6\udb8c\udeec\udaca\udcf2\ud8f6\udeaf\udb73\ude46\udbbd\udfc2", "\u616f\u03be\ub313\u8ffa\u629c\u2168\ud3e4\uac58\u2d2a\u745a\uaa5e\u3ff1\u688f\uc123", "\udb58\ude95\ud980\udc7f\ud90e\udcee\udac0\udcfb\ud83d\ude56\u626b",
        1, 92844, 465883375, 3175815683787672064L, -3671L, true, false, (char) 65097, (char) 23553,
        Double.longBitsToDouble(0x3fe2cda67c7f594dL), Double.longBitsToDouble(0x3fe983c9052728d7L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0", "\u3d65", "\ud9c3\udedc\ud9bf\udd0c\ud877\udf97\ud9a1\udc4b\ud8bc\udd7f\udbb5\udcac\udb80\ude50\ueb3c\udaa5\ude9d\ud933\ude15\u7019\udbf2\udf3b",
        50, 7692, -19111939, 8567899914469464779L, 68526L, true, false, (char) 8730, (char) 60144,
        Double.longBitsToDouble(0x3fb4a7a1477b8a48L), Double.longBitsToDouble(0x3fec50de22002c12L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 13, "\ud878\ude76\ud92d\ude48\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud88e\udddd\ud89b\uded0\udad9\udda1\ud81a\udf8d", "\uacfc\u0384\ucbb7\u2436\u7d4a\u00e7\u1ada\uac58\u2eac\u1113\uaa5a\u3ff1\u688f\uc1a7", "\udb58\ude95\ud980\udc7f\ud90e\udcee\udab0\udfb4\udbae\udc2e\ud9fc\udf12",
        52, 32602, 465883315, -8659644136940533561L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 13, "", "\u00b7", "",
        -5, -1000, 0, 201560986619183068L, -3336L, false, true, (char) 13786, (char) 0,
        Double.longBitsToDouble(0x3fe66ec8039f5d39L), Double.longBitsToDouble(0x3ece800000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 11, 13, "\ud83b\udd00\ud92d\udeac\udb15\udd4b\ud9a8\udf20\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udb48\udfaf\ud811\udd8d", "\uacfc\u0384\ucbb7\u1e9a\u7d4a\u940b\u1ada\uac58\u4de2\u093b\uaa16\u3ff1\u688f\uc1a7", "\udb58\ude95\ud980\udc7f\ud90e\udcee\udab0\udfb4\udbae\udc2e\ud9fc\udf12",
        52, 32602, 465883375, 3175815683418749024L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bd8efa8fL), Double.longBitsToDouble(0x3fe2cda67f173f12L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\ud83b\udd00\udad8\udfe2\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud9ac\udd6d\ud8a7\udd9b\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\ua0e6\u8de6\ucbb7\u638f\ubb83\u00e7\u4d68\u2ffc\u9e55\uac4a\uaa5a\u3ff1\uaa0a\u1950", "\udb5c\udf2e\ud980\udc7f\u6b04\udab0\udfb4\ud8c4\udff8\ud9fc\udf12\udbca\udfe1\udba7\udc08\udbba\ude91\udbb0\udc22\ud925\udde0\ud953\udd1c\uda44\ude52\udbcf\ude6a\ud8ca\udf55\uda2d\ude1e\udae1\udcfb\ud811\ude33\udb29\udd38\udbe6\udd30\ud931\udc35\uda1f\udc8b\ud82c\ude02\ud9c7\udd28\ud8b6\udd88\udac2\ude26\u251a\ud848\udc77\udaeb\udf45\ud951\udd21\ud9b7\uddd1",
        25, 59063, -1893692093, -2391196942486579326L, 497L, true, true, (char) 54351, (char) 5928,
        Double.longBitsToDouble(0x3fdd8a073098814eL), Double.longBitsToDouble(0x3fe22cd2c6dc9eb6L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 1, 9, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud85d\udc53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\ucbb7\u249a\u7d4a\u00e7\u1ada\uac58\u2d2a\u1113\uaa5a\u3ff1\u688f\uc1a7", "\udb58\ude95\ud980\udc7f\ud90e\udcee\udab0\udfb4\udbae\udc2e\ud9fc\udf12",
        52, 32602, 465883375, 3175815683787672064L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 15, 5, "\udb01\udc82", "\u0142\u1b4d\u47a0\u0376\u24c5\u60f7\u7bba\u902c\u0d18\u73cf\u9991\u40e0\u394a\u92df\u7d25", "\udb80\ude50\ueb3c\udbe6\udcbc\udbae\udedb\udb39\udd2f\udbb9\udd5e\ud9bc\udfaa\ud979\udde3\uda93\udeea\udb58\ude95\ud9c9\udede\ud8c1\ude28\udb3c\udfd5\uda25\ude8c\ud966\udc7a\uda90\udc88\ud82a\udce7\ud9aa\uddea\udba3\ude22\ud941\udeb7\ud953\udd1c\udbfd\udeae\udbcf\ude43\uda59\udefc\ud8ec\udfc5\udbe8\udca8\uda76\udd64\udb9a\uded0\udab6\udd9a\udac6\udd21\udb01\udd3c\ud9e0\udd4a\udb1a\udef1\ud859\udff7\ud98d\udc98\udae5\udf32\udb31\ude88\ud9aa\ude49\ud925\udedf\udac4\uddb7\u6cb4\ud974\udc37\ud826\udd96",
        6, 69907, 2120129643, 5882991016906176928L, -88825L, false, true, (char) 61268, (char) 32553,
        Double.longBitsToDouble(0x3fdf1f0f3b30646cL), Double.longBitsToDouble(0x3fa9d934a87b3a00L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 13, "\ud83b\udd00\ud92d\udeac\ud804\udec4\udb4f\ude0b\ua405\ud8a6\uddac\ud81e\ude63\ud89b\ude11\ud89b\uded0\uda54\udc95\uda19\udc45", "\u3a0f\u0384\ucbb7\u249a\u7d4a\u00fa\u1ada\u8add\u69a2\u8a09\uaa5a\u3ff1\u688f\uc1a7\u9616\u4ea3\ub880\u9ca1\u3c48\ubf71\u1635\uc6b1\u3432\uca96\u59d8\u57c6\u4ff5\ud03d\u055a", "\ud8ec\udf5d\udbe8\udca8\uda76\udd64\ud8d5\udf9c\ud8d8\ude6c\uda83\ude8c\uda1b\udffb\ud9bd\ude02\ud962\udd1e\ufc67\udbca\udccd\uda1d\udf2b\ud883\ude43\udb7d\udff8\uda90\udf29\udb96\udd5d\ud83a\udf6b\udacd\udd30\ud9a8\udfad\ud8fe\udc89\ud92a\udf6a\uda96\udce7",
        0, 10909, -267980155, 2452630553409581601L, -3138L, false, false, (char) 42535, (char) 14292,
        Double.longBitsToDouble(0x3f74c0acdf899c80L), Double.longBitsToDouble(0x3fe6b33beeb23173L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 14, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud8f2\udd9b", "\u7bf2\u3d65\u6573\uacfc\u0384\ucbb7\u249a\u7d4a\u00e7\u1ada\uac58\u2d2a", "\ud80d\udd19\udbf2\udf3b\ud9bc\udfaa\udbd3\udf0f",
        6, 18044, -698212592, 7871443074680263246L, -61826L, false, true, (char) 17111, (char) 16952,
        Double.longBitsToDouble(0x3fec50de22002c12L), Double.longBitsToDouble(0x3fed2e423f2c9121L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 0, 13, "\ud83b\udc9c", "\u6b6b\u1b4d\ub9e2\u3684\u24c5\u99f6\u1fe0\u7bf2\u3d65\u6573", "\uda94\udc09",
        30, 65149, -604705889, -2163981330556593396L, 66823L, false, false, (char) 6131, (char) 22088,
        Double.longBitsToDouble(0x3fcea4248532dcbcL), Double.longBitsToDouble(0x3fefeb0eab94fedcL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 0, "\udb31\udc97", "\u5eff", "\ud81e\ude63",
        36, 64574, 1073971164, -4709057225098348233L, -3336L, false, true, (char) 218, (char) 0,
        Double.longBitsToDouble(0x3fe66ec8039f5d39L), Double.longBitsToDouble(0x3ece800000000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 0, "\ud83a\ude9c\u00f1", "\u2fbf\032\000", "",
        -5, 66744, 1191622967, 6546054384094902680L, -36726L, true, true, (char) 24737, (char) 0,
        Double.longBitsToDouble(0x3fbcb6c0000709e0L), Double.longBitsToDouble(0x3fe7ce14c4598bf9L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 15, "\ud83b\udd00\udb78\ude71\ud81b\udd89\ud9a8\udf21\ud864\ude53\ud861\udc65\ud81e\ude63\uda60\udf75\udb68\udd63\udaec\udfa1\ud811\udd8d", "\ub7f3\u6ad1\u212a\u23e0\u796f\u3217\u4395\u7a45\u8d75\u1113\uaa5a\u3ff1\ub9af\uc1a7", "\udb62\udf1a\ud9b1\ude60\ud90e\udd11\udab0\udfb4",
        18, 28490, -247142470, 3764282237373977494L, 2992L, true, false, (char) 28749, (char) 49964,
        Double.longBitsToDouble(0x3fd492f96506457eL), Double.longBitsToDouble(0x3fee9873be6ee99dL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 0, "", "\u6189", "\000",
        25, 5648, 46929574, 4612671026227052544L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f2b806cdd900000L), Double.longBitsToDouble(0x3e0cb6c000000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 6, "\ud9c9\udf30\ud92d\udeac\uda08\udd04\udbb9\udc6c\ud85d\udfdc\ud884\udc94\ud81e\ude63\udb90\udf64\uda41\udc44\udaec\udfa1\ud811\udd8d\uda0f\udd66", "\u7e2e\ucbb7\u91d1\u6771\u6ab2\u6ba9\uac58\u08a0\u1113\ua1d4\u3ff1\u688f", "\udb35\udfd8\udb58\ude95\udbf1\uded8\ud985\udd00\uda73\udc6e\ud8e7\udea5\ud890\udcf1\ud8af\udc73\uda9b\udc96\ud86d\udea8\ud916\udfc1\ud97b\udfe0\udadb\udd92\ud81a\udcb9\ud978\udeb6\ud84b\ude47",
        5, 41321, -478707082, 1984907436400944331L, -48237L, true, false, (char) 42809, (char) 38305,
        Double.longBitsToDouble(0x3fe61df2a28dc45bL), Double.longBitsToDouble(0x3faffa1217b83d60L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 11, "\ud83b\udd51\ud92d\udeac\ud98c\udd48\uda2b\udd66\ud8cd\udc81", "\uca4b\u3008\u7bba", "\uda1b\udc8a\ud8d0\udd30\uda8e\ude0c\ud891\udc15\ud8cb\ude8d\ud860\ude52\ud8bc\uddac\udbb5\udcac\ud920\udcff\u7cea\udaa5\ude73",
        -2, 4280, 556017981, -5246896510039938740L, -53812L, true, false, (char) 25479, (char) 65490,
        Double.longBitsToDouble(0x3fef75a638ed4e7dL), Double.longBitsToDouble(0x3fedd01cb9b1e90aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 9, 8, "\ud83b\udd76\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\uda30\udddd\ud9a6\udc6a\ud980\ude72\ud89b\ude81\udaec\udfa1\ud811\udd8d", "\u854d\u59f6\ucbb7\u249a\u7d4a\u00e7\u1ada\uad32\u2d2a\u1113\u2c97\u3ff7\u688f\uc1a7", "\udb4e\udf4b\ud980\udc7f\udb95\udfd3\uc754\udbae\udc2e\ud9fc\udf12",
        52, 1026, 1969555899, 3359225669438884366L, 54598L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 15, 13, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\uda30\udddd\ud9a6\udc6a\ud980\ude72\ud89b\ude81\udaec\udfa1\ud808\ude09", "\uacfc\u0384\u3829\u279a\u7c9c\u00e7", "\ueb3c\udaa5\ude9d\ud933\ude15\ud80d\udd19\udbf1\udfda\ud986\udf52\udbd3\udf0f",
        6, 17652, -653436213, 7891866176748687950L, -61826L, false, true, (char) 17111, (char) 33851,
        Double.longBitsToDouble(0x3fdf3756541c5d3cL), Double.longBitsToDouble(0x3fe3ee5a3be65fe5L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 1, 3, 13, "\ud83a\ude9c", "\u6b6b\u1b4d\ub9e2\u3684\u24c5\u99f6\u7bba\u7bf2\u5c2d\u6573", "\ud9bf\udd0c",
        30, 65149, -604705889, -2163981330556593396L, 66823L, false, false, (char) 6131, (char) 22124,
        Double.longBitsToDouble(0x3fefa909214cb72fL), Double.longBitsToDouble(0x3fefeb0eab94fedcL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 0, "\000", "\u6b6b", "\ud811\udd9d\ud885\udea1\ud89b\uded0\udaec\udfa1\ud811\udd8d\uda0f\udd66\uda07\udf22\uda11\udc31\ud9c3\ude2c\ud9bf\udd0c\ue1d7\ud9a1\udc4b\ud8bc\udd7f\udbb5\udcac\udb80\ude50\udbfb\udd3c\000\ud933\udd27\ud80d\udd19\udbf2\udf3b\ud9bc\udfaa\udbd3\udf0f\udb35\udfeb",
        17, 66211, 1828716544, -8068600819903689607L, -100000L, false, false, (char) 0, (char) 50057,
        Double.longBitsToDouble(0x3fe0016093a5c847L), Double.longBitsToDouble(0x3fe964890b76f7b6L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 13, 13, 13, "\ud82e\udc3a\ud929\udde6\ud81d\udc95\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\ud811\udd8d", "\uacfc\u0384\ucbb7\u249a\u085f\u00e7\u1ada\uac58\u2d2a\u1113\uaa5a\u3ff1\u688f\uc1a7", "\ud8c0\udc9a\ud980\udc7f\ud8fa\ude03\udab0\udfb4\udbae\udc2e\ud9fc\udf12",
        52, 32602, 465883375, 3175815683787672064L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 5, "\ub9fa", "\u8ded\u1b4dE\u0376\u24c5\u60f7\u7bba\u902c\u4117\u73cf\u9991\000\u5784\u92df\u00a8", "\udb80\ude50\ueb3c\udbe6\udcbc\udbae\udedb\udb39\udd2f\u2948\000\udbe9\udc94\uda93\udeea\udb58\ude95\ud9c9\udede\ud8c1\ude28\uda9d\udfa6\uda25\ude8c\ud966\udc7a\000\ud940\udcc0\ud9aa\uddea\000\000\ud953\udc77\udbfd\udeae\ucb76\ud913\udda8\000\000\uda76\udc91\udb9a\uded0\udab6\udd9a\udac6\udd21\udad7\udc3c\ud9e0\udd4a\udb52\udc6c\ud81f\udf6e\ud98d\udc98\ud9d8\udfcb\000\000\000\udaab\udeb4\u6cb4\ud974\udc37\ud826\udd96",
        6, 29640, 2120129643, 5882991016906176928L, -88825L, false, true, (char) 0, (char) 32529,
        Double.longBitsToDouble(0x3fdf1f0f3b30646cL), Double.longBitsToDouble(0x3fa9d934a87b3a00L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 13, "\u7d2f", "\u6b6b\u7cdf\u56c5\u3684\u24c5\u99f6\u7bba\u7bf2\u5c2d\u6573", "\ud89e\udfa2",
        4, 65116, -604705889, -2163981330556593396L, 66823L, false, false, (char) 5142, (char) 60736,
        Double.longBitsToDouble(0x3fefa90924a8b72fL), Double.longBitsToDouble(0x3fd4ed70e729fdb8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 3, 3, 13, "\ud83a\ude9c", "\ub539\u1b4d\ub9e2\u3684\u24c5\u99f6\u7bba\u7bf2\u5c2d\u6573", "\ud9bf\udd0c",
        30, 65149, -604705889, -2163981330556593396L, 66823L, false, false, (char) 6990, (char) 22124,
        Double.longBitsToDouble(0x3feeb8712052dab4L), Double.longBitsToDouble(0x3fea9eb0e3acb693L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 4, 4, 0, "\000", "\u6b6b", "\ud811\udd9d\ud885\udea1",
        24, 37164, -1096412825, 5117981673951609288L, -10656L, true, true, (char) 4475, (char) 34508,
        Double.longBitsToDouble(0x3fecfae9ce72dbf4L), Double.longBitsToDouble(0x3fe8670fbd86bb98L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 13, "\ud83b\udd00\ud92d\udeac\ud81b\ude2e\ud9a8\udf21\ud864\ude53\ud894\udfd6\ud81e\ude63\ud89b\ude11\ud89b\uded0\udaec\udfa1\uda49\udc08", "\uacfc\u0384\u9410\u249a\u7d4a\u00e7\u1ada\uac58\u2d2a\u1113\uaa5a\u3ff1\u688f\uc1a7", "\udb58\ude95\ud980\udc7f\ud90e\udcee\uda92\udeb4\udbae\udc2e\ud9fc\udf12",
        52, 32602, 465883375, 3175815683787672064L, -26060L, false, true, (char) 61662, (char) 64833,
        Double.longBitsToDouble(0x3fee9873bdd30e2eL), Double.longBitsToDouble(0x3fe2cda67c7f594dL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 13, "\ud83a\ude9c\ud92d\udeac\udae2\udf2d\ud895\udfed\ud929\udf9f\ud894\udfd6\ud81e\ude63\ud8a7\ude17\ud957\udece\udaec\udfa1\ud811\udf8d\ud9e1\udc2f\uda07\udf22\ud8fc\uddf9\u39f4\udaf6\udd28\udb9f\udd8a\udac1\udf90", "\uad4b\u2d2a\u1113\uaa5a\u3ff1\u688f\uc1a7\u953f\u3405\ub8c3\u9fed\u6ea1\uc863\u6f61\u182d\ud1f7\u7f67\uc7b1\ubec8\ua21d\ubaa9\u7152\u0193\u5b74\u7ac3\u962c\u0df9\u20fc\ub71f\u7c8a\u94e8\u714f\u690d\u985f\u2e2c\u0a5d\u58b6\u9cbb\u4f21\uae4d\ubdee\u565f\ua77c\u8700\ubcbe\u82f2\u6251\uca87\u379c\u4922\u715e\u5516\u06f1\u9f27\u6caf\u29ec\u914c\u7c85\ua54c\u7e65\u9d7b\u9deb", "\ud841\ude49\uda41\udd88\udbe2\udf3f\ud866\ude49\ud873\udc06\udba4\udf2f\ud8b3\udece\udaf7\udf12\ud9c0\udc5f\ud879\udcc9\udb05\udf30\uda7d\udc14\udb57\udd01\ud89d\udc56\ud961\udd4a\u6d87\udb05\udf25\ud9e9\udcf8\udb99\udd40\uead9\udb78\udc78\u316e\ud815\ude33\udb66\udeef\u29cf\udaad\udc9a\udbd4\udd10\udba4\udfb7\udb3c\udfeb\ud801\udeff\udb37\udde7\ud805\ude4c\ud969\ude3f\udb64\uddf1\ud833\udd71\uda8e\udc51\uda43\ude73\ud962\udf50\udb96\udd64\udb01\udddc\uda22\udc61\ud99b\ude9b\udb53\ude53\ud9d5\udc9e\uda8b\udc47\ud8af\udca4\ud921\udf2a\ud82e\udc9d\udb42\ude69\ud864\ude70",
        58, 2712, 2097803684, 2969994535162391068L, -68608L, false, false, (char) 8563, (char) 37984,
        Double.longBitsToDouble(0x3fcd581b3cd5bf24L), Double.longBitsToDouble(0x3fe74e21d8772cd4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.DefaultParser|isShortOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredArgs||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredOptions||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|getLongPrefix|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleConcatenatedOptions|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithoutEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleProperties|java.util.Properties|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleShortAndLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleUnknownToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isArgument|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isJavaProperty|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isShortOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
