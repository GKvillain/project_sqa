package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\udace\udc8b\udb00\udf83\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f0b\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\u4f49", "\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\udbc1\udffd\ud8fb\uddb5\udbc9\udc62\uda4b\ude2e\uda01\udd88\ud997\udf0e\ud909\udc94\ud995\udc1b\ud8d2\udebf\ud971\udd36\udaea\udf01\uda67\udd02\ud81f\udf1a\ud904\udc48\ud8fc\udc1a\udb8c\ude25\ud920\udf7d\udae4\ude83\uda43\udf3d\uda4d\udc88\uda05\udd16\ud8ed\udd6e\ud814\udc0c\uda00\udeb5\udba0\ude30\ud905\uddce\udbef\udec7\udb35\uddc1\udba2\udd48",
        19, 97114, 1364687878, 3334505223052085655L, 99069L, true, false, (char) 45890, (char) 59887,
        Double.longBitsToDouble(0x3fe635b08efc00dfL), Double.longBitsToDouble(0x3faa06a7fb7b6050L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\uda16\udd43\udb48\uddb3\uda4b\udc47\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f0b\u4e4c\u5c97\u69d7\u74e5\ub078\u4c5c\u0305\u46ba\ucf3c\u4f49", "\udb85\udc6a\ud95a\udd60\ud8ef\udc0d\udb0a\udc9d\udbc1\udffd\ud8fb\uddb5\udbc9\udc62\uda4b\ude2e\uda01\udd88\ud997\udf0e\ud909\udc94\ud995\udc1b\ud897\udc35\ud80f\ude25\udaea\udeca\ud939\uddd5\ud81f\udf1a\ud904\udc48\ud8fc\udc1a\udb8c\ude25\ud920\udf7d\udae4\ude83\uda43\udf3d\uda4d\udc88\uda05\udd16\udb7b\udfb6\ud81b\udc97\uda00\udeb5\udba0\ude30\ud905\uddce\udbe6\udf60\udbc4\udfb7\udba2\udd48",
        19, 69885, 1367426125, 668374241547317215L, 99069L, true, false, (char) 45890, (char) 59887,
        Double.longBitsToDouble(0x3fe635b08efc00dfL), Double.longBitsToDouble(0x3fe9a06a7fb7b605L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 14, 14, "\ud9a4\udc70\udb9f\udf22\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51\ud824\udf1f\ud80c\udcba\ud8b7\udd1b\udafb\udf6f\uda5e\udd04\ud868\udf3a\udb2d\udef1\u3f22", "\u46ba\ucf3c", "\uda2c\ude6a\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\udbc1\udffd\ud8fb\uddb5",
        14, 26049, 561068944, -1187226236943578310L, 99316L, true, false, (char) 37494, (char) 14492,
        Double.longBitsToDouble(0x3fceabab222eb680L), Double.longBitsToDouble(0x3fe0349be63918e0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 14, "\udace\udc8b\udb00\udf83\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f0b\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\u4f49", "\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\udbc1\udffd\ud8fb\uddb5\udbc9\udc62\ud8c0\ude26\uda01\udd88\ud997\udf0e\ud909\udc94",
        35, 24069, -1484162451, 1213708466800555132L, -33752L, true, false, (char) 3628, (char) 21890,
        Double.longBitsToDouble(0x3fdb918e0f2ea2a0L), Double.longBitsToDouble(0x3fdf5322576edf30L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 1, 14, "\udb26\udc16\udb12\udeb9\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f0b\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\u9e17", "\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\udbc1\udffd",
        37, 49379, 1340701049, 2409772765004832775L, -63453L, true, true, (char) 38573, (char) 40181,
        Double.longBitsToDouble(0x3f8abd88fba221c0L), Double.longBitsToDouble(0x3fe641aea4f55d59L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 14, "\udace\udd39\udb00\udf83\ud9d2\udf23\uda99\udf64\ud839\udf1f\ud835\udf60\u7dc8\udb50\udc51\ud824\udf1f\ud80c\udcba\ud8b7\udd1b", "\u2b07\ub884\u3359\u8054\u0305\u29b9\ucf3c\u4f49\u29df\u0203\ud74e\u1650\u6364\u1d19", "\udbc9\udc62",
        59, 12944, -1165615097, 1654029673852866243L, 65267L, false, true, (char) 21201, (char) 40053,
        Double.longBitsToDouble(0x3fe641aea3f55d59L), Double.longBitsToDouble(0x3fe1e8db3dabb17cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 1, 0, 5, "\udace\udc8b\udb00\udf83\uda00\udddf\udb2d\udff3\ud839\udf13\ud835\udf60\udbaf\uddcf\udb50\udc51\ud824\udf1f\ud80c\udcba", "\u5c97\ud4fe\u6d05\ub0da\u4c5c\u0305\uc88b\uc4df\u4f49\u29df\u9410\ud74e\u1650\u6364\u7e19\u2e25\u35ea\u4e01\uaae7\ub332\u11b9\u6bce\u0b1c\u7037\u23de\u35be\u7e74", "\ud8fc\udc1a\udaad\udd94\ud901\udce1\udae4\ude83\uda43\udf3d\uda4d\udc88",
        3, 36438, 1290077060, -4243580321632835888L, 10470L, true, true, (char) 3794, (char) 24190,
        Double.longBitsToDouble(0x3fe1136d5406af43L), Double.longBitsToDouble(0x3fe6aa8ab9972e46L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 13, 1, 14, "\udace\udc8b\udb00\udf83\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\udbbb\udc87\udb50\udc51", "\u4f0b\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\u9802", "\udb85\udc6a\ud95a\udd9f\ud80d\udf29\ud801\ude48\udbcf\udd44\uda8a\udfcf\udbc9\udc62\uda4b\ude2e\uda01\udd88\ud997\udf0e\ud909\udc94\ud995\udc1b\ud8a1\udc4f\ud971\udd36\udaea\udf01\uda67\udd02\ud81f\udf1a\ud904\udc48\ud8fc\udc1a\udb8c\ude25\ud920\udf7d\uda3c\udd59\uda43\udf3d\uda4d\udc88\uda05\udd16\ud8ed\udd6e\ud814\udc0c\uda00\udeb5\udba0\ude30\ud905\uddce\udbef\udec7\udb35\uddc1\ub4ab",
        8, 97114, 1364669260, 3334505223052085655L, 99069L, true, false, (char) 45890, (char) 59887,
        Double.longBitsToDouble(0x3fec65b08efc00e8L), Double.longBitsToDouble(0x3faa06a7fb7b6050L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\udace\udc8b\udb06\udc4d\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f26\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\u4f49\u29df\u9410\ud74e\u1650\u6364\u1d19\u2e25\u35ea\u4e01\u482f\ub332\u979c", "\ud8d2\udebf\ud971\udd36\udaea\udf01\uda67\udd02\ud81f\udf1a\ud904\udc48\ud8fc\udc1a\udb8c\ude25\ud920\udf7d\udae4\ude83\uda43\udf3d\uda4d\udc88\uda05\udd16",
        58, 3060, -988035538, 5860068660798030678L, 75311L, true, false, (char) 24144, (char) 12236,
        Double.longBitsToDouble(0x3f7abd0e391c1100L), Double.longBitsToDouble(0x3fce2388c58566d0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\udace\udc8b\udb00\udf83\uda74\udffa\udb3d\udcd3\ud96e\udc2c\ud835\udf60\udb3d\uddd0\udb50\udc51", "\u4f0b\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\u4f49", "\udaa4\ude32\ud976\udd01\ud861\udd33\ud801\ude48",
        3, 81852, -2001769621, 5758267159728962448L, 99316L, true, false, (char) 40053, (char) 40876,
        Double.longBitsToDouble(0x3fe904c4d88bb7a4L), Double.longBitsToDouble(0x3fe0349be5b918e0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 3, 1, 14, "", "", "",
        2, 66356, 274711761, -1586496743563031937L, -99969L, false, false, (char) 57008, (char) 40929,
        Double.longBitsToDouble(0x3fca0685a26c90b4L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 11, "\udab2\uddf7\udb00\udf83", "\u6812\u6100", "\udaec\udf63",
        17, 41750, -17010790, -6936987423344885721L, 69883L, false, true, (char) 59180, (char) 60727,
        Double.longBitsToDouble(0x3fedb3413afdbf7aL), Double.longBitsToDouble(0x3fd474de0226dfbeL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 14, "\udace\udc8b\udb00\udf83\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\udba3\udf49\udb11\udfe7", "\u4f0b\u4e4c\u5c97", "\u3ecf",
        33, 93008, 1747450696, -4649355603316043011L, 27251L, true, true, (char) 29933, (char) 3787,
        Double.longBitsToDouble(0x3fee4f0fd8eda29cL), Double.longBitsToDouble(0x3fe7a7813b6beadfL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\ud992\udf56\udaf1\udc9d\uda75\udc39\ud91c\udfa9\ud928\ude49\ud9b8\udfae\u7dc8\ud935\udf24\udaa0\udc1d\ud486\ud9e7\udeda\udabd\udf64\uda5e\udd04\ud851\udfcf\udb94\udcd9\ud998\udfc8\ud869\udd96\udb4a\udedb\ud948\udd6b\uda2f\udfe8\ud82e\udf48\ud914\udd57\udbe4\udd1e\ud803\udf7e\ud95a\udd60\ud861\udd33\ud801\ude48\udbd6\udd74\ud9c1\udc41\ud813\udc70", "\ucc7f\u3426\u9d66\u7291\u2994\u35be\u7e74\u33ba\u2ead\u3b54\u57ee\u3f82\u6e18\uc792\u791c\u7a75\ub093\uaea6\u7861\ud5c8\ub57b\u842b\u2de6\ub1c3\u5b24\u81c2\u1c6e\u81ad\u5be8\u358a\uca25\ubda2\u8bdd\u957c\ua7ce\ua6c2\ub885\uc9c2\ub049\u29a6\u7076\u078a\u880e\u2821\u3283\u19a6", "\uda35\ude05\ud822\udd9b",
        30, 39859, -1176197602, -3039355639629090860L, -35440L, false, true, (char) 20084, (char) 5549,
        Double.longBitsToDouble(0x3fe0daba4d4ba4a3L), Double.longBitsToDouble(0x3fe1ed81fda97ceeL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\udace\udc8b\udb00\udf83\uda75\udc39\udb2d\udf51", "\u8a83\u9f27\u4b02\u849d\u4fba\u4e4c\u5c97\uadfd\ucfb0\ub078\u7623\u0305", "\udb73\udf93",
        34, 88059, 162235353, -3757321220230999350L, -67469L, false, true, (char) 22091, (char) 553,
        Double.longBitsToDouble(0x3fec827f49072171L), Double.longBitsToDouble(0x3fe8bcf5bec3b37eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 1, 1, 14, "\udace\udc8b\udb00\udf83\uda75\udc39\udb2d\udf51\ud839\udf13\ud91d\udc25\ud8a6\udce9\udb66\udee8", "\u4f0b\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\u4f49", "\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\ud841\udffd\ud8fb\uddb5\udbc9\udc62\uda4b\ude2e\uda01\udd88\ud997\udf0e\ud946\ude93\udb3a\udf2d\uda42\ude80\ud971\udd1f\ud92d\udcc3\uda67\udd08\ud81f\udf1a\ud904\udc48\ud8ec\udc12\ud8ec\ude2c\ud920\udf7d\udae4\ude83\uda43\udf3d\uda4d\udc88\uda05\udd16\ud8ed\udd6e\ud814\udc0c\uda00\udeb5\udba0\ude30\ud905\uddce\udbef\udec7\udb35\uddc1\udba2\udd48",
        19, 97114, 1364687878, 3334505223052085655L, 99069L, true, false, (char) 45890, (char) 59887,
        Double.longBitsToDouble(0x3fee35b08efc58d3L), Double.longBitsToDouble(0x3faa06a7fb7b6050L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 3, 1, 14, "\udace\udc8b", "\u233f\u1aaa\u6100\u00d1\000\u1bda\ucf6f\u61c6\u4e4c\ucdb9\uadfd\ucfb0\u009b\u2000\ucbb0\000\000\000\u29df\u9410", "\ua6f8",
        31, 52685, -354427148, -8597535054980613767L, -100000L, false, false, (char) 36546, (char) 54025,
        Double.longBitsToDouble(0x3fbb400000000000L), Double.longBitsToDouble(0x3e3f700000000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 15, "\udace\udc8b\udb00\udf83\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f0b\u4e4c\u707c\uaaa6\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\uca42", "\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\udbc1\udffd\ud8fb\uddb5\udbc9\udc62\uda4b\ude2e\uda01\udd88\ud997\udf0e\ud909\udc94\ud995\udc1b\ud8d2\udebf\ud971\udd36\udaea\udf01\uda67\udd02\ud81f\udf1a\ud904\udc48\ud8fc\udc1a\udb8c\ude25\ud89e\udf7c\udae4\ude83\uda43\udf3d\uda14\udfb9\udaf4\ude07\ud8ed\udd6e\ud814\udc0c\ud9a4\udfc6\udba0\ude30\ud905\uddce\udbef\udec7\ud8ea\ude3a\udb3c\udd39",
        30, 54189, 1168306959, 3334357626500975312L, 16506L, false, false, (char) 11782, (char) 59887,
        Double.longBitsToDouble(0x3fe635b08efc00dfL), Double.longBitsToDouble(0x3faa06a7fb7b6050L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 0, 14, "\udace\udc8b\udb00\udf83\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f0b\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\u54ea", "\udbc3\udcdf\ud95c\udc9c\ud861\udd33",
        19, 85453, -354427148, -8597535054980613767L, 39271L, false, true, (char) 42422, (char) 50185,
        Double.longBitsToDouble(0x3fe368e2056ca789L), Double.longBitsToDouble(0x3f8abd88fba221c0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 10, "\ud92e\ude9e", "\u1447\u6812\u6100\u1839\u16e8\ud64a\u13c8\u290b\u4e4c\u5c97\u01c4\u1048\u7e6a\u4c5c\u0305\u46ba\ud219\u4f49\u29df\uaa94\ud74e\u1650\u6364\u1d19\u2e25\u35ea\u4e01\u482f\ub332", "\ud995\udc1b\ud8aa\udcbf\udaf0\ude8b\udb63\uddea\uda40\udcfb\ud81f\udf1a\udba6\udd30\udb46\udd51\udb59\udc7f\ud920\udf7d\udae4\ude83\uda43\udf3d\uda4d\udc88\uda05\udd16\ud937\udd73\ud814\udc0c\ud961\udebe\udb3e\udca7\ud905\uddce\udbef\udec7\udb35\uddc1",
        7, 59244, -1354513886, 5861289806034012885L, 72385L, true, true, (char) 33012, (char) 45890,
        Double.longBitsToDouble(0x3fd1cfcd3d8d6c22L), Double.longBitsToDouble(0x3fe7e006f8340d4fL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 3, 1, 14, "", "\u8311\u1447\u6812\u6100\u1839\u9f85\u8f12", "\udabd\udf70\uda5e\udd04\ud868\udf3a\udb2d\udef1\u3ecf\udac1\udd66\udb4a\udedb",
        51, 4542, 1306530557, 8061413951503986963L, -91540L, true, true, (char) 553, (char) 35705,
        Double.longBitsToDouble(0x3f7c85c59d77c300L), Double.longBitsToDouble(0x3fe618b7a115d2f4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 0, 14, "\ud9a4\udc70\udb9f\udf22\uda75\udc39\udb2d\udf51\ud839\udf13\udac1\udf59\u7dc8\udb50\udc51\ud824\udf1f\ud80c\udcba\ud8b7\udd1b\udafb\udf6f\uda5e\udd04\ud868\udf3a\udb2d\udef1\ud835\udfb5", "\u46ba\ucf3c\u4f49\u29df\u9410\ud74e\u1650\u6364\u1d19\u2e25\u35ea\u4e01\u482f\ub332\ucc7f\u1149\u680c", "\udaea\udf01\udbe8\udf81\ud81f\udf1a\ud904\udc48\ud8fc\udc1a\udb8c\ude25\ud920\udf7d\uda61\udd54\ud81e\udd23\udb2d\udf96\ud973\udcf2",
        55, 81524, 1212119299, -1636469882449744127L, -73451L, true, true, (char) 50196, (char) 3235,
        Double.longBitsToDouble(0x3fc9980b7be0b258L), Double.longBitsToDouble(0x3fdf40b4eacfb808L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 14, 14, "\ud9a4\udc70\udb9f\udf22\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\ud973\udf82\udbc3\uded5\ud85f\udc4a\ud8b7\udd1b\udafb\udf6f\uda5e\udd04\ud868\udf3a\udb2d\udef1\u3f22", "\u46ba", "\udb2a\udfde\uda2c\ude6a\udb85\udc6a\ud95a\udd60\u7532\ud801\ude48\udbc1\udffd\ud8fb\uddb5\udbc9\udc62\uda4b\ude2e\uda01\udd88\ud997\udf0e\ud909\udc94\ud864\udd40\udb29\udef7\ud996\ude04\ud960\udcdd\udbc8\uddb9\ud81f\udf1a\ud904\udc48",
        -4, 94954, 417382918, -2944054290655152298L, -98130L, false, false, (char) 30941, (char) 15298,
        Double.longBitsToDouble(0x3fedcb463e023b2eL), Double.longBitsToDouble(0x3fdd57674215e722L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 14, "\ud9a4\udc70\ud8b6\udd8e\uda74\udff3\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51\ud826\uddd2\ud80c\udcba\ud8b7\udd1b\udafb\udf6f\uda5e\udd04\ud868\udf3a\udb2d\udef1\u3f22", "\u8644\u48e9", "\uda2c\ude6a\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48",
        3, 81852, -2001769621, 5758267159728962448L, 99316L, true, false, (char) 37494, (char) 14492,
        Double.longBitsToDouble(0x3fceabab222eb680L), Double.longBitsToDouble(0x3fe0349be63918e0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 12, "\uda15\ude7d\ud8ba\ude53\udabc\ude6e\ud8b2\ude53\ud944\udff3\ud83e\udccd", "\u8f12", "\udafb\udf6f\uda5e\udd04\ud9e7\uddb7\uda8c\udfd5\u3f22\uda7b\udf44\udb4a\udf20",
        7, 29531, -1580301947, 4769049146384667947L, -61885L, false, false, (char) 33698, (char) 60954,
        Double.longBitsToDouble(0x3fef1befabd8ba81L), Double.longBitsToDouble(0x3fd7988af7209fd2L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 14, "\ud9a4\udc70\udb9f\udfb7\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51\ud824\udf1f\ud82c\udf4d\ud8b7\udd1b\udafb\udf6f\udad5\udfdf\udbf1\udcb5\udb2d\udef1\u8ff7\ud8d7\udf29\udb4a\udf20\ud948\udd6b\uda2f\udfe8\udb73\udf93\ud85d\udfd9\uda00\uddd5\u8279\ud9ea\udd2c\ud861\udd33\udb34\udf0c\uda3a\ude9b\u888a\ud8a8\udf45", "\ucc7f\u561b\uafd9\u3d28\u2994\u35be\u4a05\u990f\u17e0\u3b49\u57ee\u3f82\u2634\u3cdf\ubd38\u6dae\uc6b6\u0e4e\u6dad\u114b\u0635\u5595\uc58f\u86a6\ua7f9\u4139\u9e66\uaeda\u98d3\ub43f\uae1a\u963c\u6529\ub69c\u6c6f\ub1f2\u864d", "\uda39\udd88\ud8b6\udf4d\uda5e\ude88\ud8e7\udc1f\uda5b\udc05\ud845\udd15\uda07\udeed\ud9ac\udf2f\ud817\udf18\udaea\udc29\uda5e\udec8\ud96a\udc83\uda1a\ude55\udac6\udd86\ud9c4\udcad\ue464\ud938\ude72\udb13\udec7\ud80f\udc5a\ud998\ude7e\ud717\udaff\udcdd\ud93a\ude02\ud93d\udd34\udb5a\ude89\ud966\udc2f\ud112\ud9c4\udc53\ud9ba\udd1d\udb99\udff3\udbea\udea0\u19cb\udbf9\udfbc\udb00\udef0\uda8f\udfe0\udbfd\udc66",
        29, 38911, -1234386235, 5889080422085323810L, 62949L, false, true, (char) 9422, (char) 12887,
        Double.longBitsToDouble(0x3fdb3ae84f33642eL), Double.longBitsToDouble(0x3fdab9375f7a8db0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 15, 13, 14, "\uda41\udee1\udb9f\udfc3\udb14\udc68\uda32\udf6a\ud839\udf13\udb29\uddf9\ud918\udde4\udb50\udc76\ud824\udf1f\ud80c\udcba\udb86\udd0d\udafb\udf6f\ud983\udd53\uda52\udcd7\udb2d\udef1\u3f22", "\u46ba\ucf3c", "\uda6a\ude51\udb85\udc6a\ud95a\udd60\ud861\udd33\ud8aa\udd1c\ud883\udfc0\uda31\udcd2",
        1, 56583, 561068944, -1187226236943578310L, 99316L, true, false, (char) 37494, (char) 14492,
        Double.longBitsToDouble(0x3fceabab222eb680L), Double.longBitsToDouble(0x3fe0349be63918e0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 10, "\ud9a4\udc70\udb9f\udf22\uda75\udc39\udb52\udc09\ud9d6\udd1a\uda9d\udd68\ua7c8\udb50\udc51\ud824\udf1f\udbc5\udf6b\udae3\udd30\ud912\uddda\ud89e\ude89\uda93\udc50\udbff\udd46\ud9cc\udfe9", "\u2746\ucf3c", "\uda2c\ude6a\udb85\udc6a\ud95a\udd60\ud861\udd33\udb9d\udfb5\udbc1\udfb4\udba0\udeb1",
        14, 26049, 561068944, -1187225639943124020L, 60980L, false, false, (char) 16329, (char) 39588,
        Double.longBitsToDouble(0x3fcb0dc4622fe5acL), Double.longBitsToDouble(0x3fe1049be63918e0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 14, "\ud97a\udd9f", "\ud74a\u92d8\u3c87", "\ud824\udf1f",
        57, 58015, -18059392, -6936987423344885721L, -74289L, false, true, (char) 62559, (char) 60727,
        Double.longBitsToDouble(0x3fe400d13a55db0dL), Double.longBitsToDouble(0x3fd474de0226dfbeL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 14, "", "\000", "\ud835\udf60",
        46, 40374, 178031231, -2013265920L, -100000L, false, false, (char) 0, (char) 48154,
        Double.longBitsToDouble(0x3fee43d1d3f5286bL), Double.longBitsToDouble(0x3fea478f7bb66827L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 4, 14, "\udb0c\udc8a\udb00\udf83\uda75\udc39\udbb0\udff1\udb89\ude03\ud850\udc22\u47f4\udb50\udc51", "\u21e5\u4ddf\u5c97\uadfd\ucfb0\ub078\u4c5c\uc804\u46ba\ucf3c\u4f49\uc9586\ua5ed\u1650\u352c\u1860\u2e25\u5b3b\u5466\u9839\ub332\ucc7f\ucc5a\ucb0e\u72ef\u2994\u7962\u7ee3\u33ba\uc16a\u3b54\u57ee\u3f82\u6e18\u4b06\u8a38\u1e80\u0833\ucef5\u42a5\ub07e\u8648", "\udad9\ude5f\ud928\udebf\udbfc\udc91\udbe3\udd3a\ud9ef\udcdb\udbb1\udf52\udb80\udf8b",
        58, 19043, 1474385798, 8005218263218937742L, 60501L, true, false, (char) 52657, (char) 11176,
        Double.longBitsToDouble(0x3fe3af19de2dbe3eL), Double.longBitsToDouble(0x3fdfb129fd0298e2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 0, "<", "?\u1aaa\u6100\u6fc8\u9f85\u8f12\u3971\u4f0b\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\ucbb0\u302e\ucf3c\u4f49\uc958\u2beb", "\u00f8\ud801\ude48\u80ed\000\000\ud913\udda8",
        9, -1000, 385108736, -3245812463253262059L, -100000L, false, false, (char) 89, (char) 3468,
        Double.longBitsToDouble(0x3fe0349be00018e0L), Double.longBitsToDouble(0x3fecba8800000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 11, "\udace\udc8b\ud904\udca4\uda75\udc39\udb2d\udf51\ud839\udf13\udad1\udf00\uda27\udc29\uda66\ude5a\ud8ca\uddcf\ud970\udc03\ud858\udc32", "\uc127\ucfc7\ub8ea\u4c5c\u0305\u46ba\ucf3c\u9e4b\uce53\u4af3\ud74e\u870f\u391d\u13ca", "\udbc9\udc62",
        5, -392, 1977211453, 1654029674315026115L, -8339L, false, true, (char) 1363, (char) 40053,
        Double.longBitsToDouble(0x3fe641aea5335d59L), Double.longBitsToDouble(0x3fc17b0e881a4df0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 8, "\uda47\ude92\ud8a1\udd30\uda75\udc39\udb2d\udf51\ud839\udf13\udb2f\udd1c\ud9c1\udd59\udb8c\udc44\udbb6\udc3e\ud80c\udcba", "\u5c97\uadfd", "\udac1\udd66",
        51, 4914, 2060567689, 2725029673940795660L, 8280L, false, true, (char) 9097, (char) 42794,
        Double.longBitsToDouble(0x3fe1301228538a36L), Double.longBitsToDouble(0x3fec827968072171L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 6, "\udb26\udc16\udb12\udeb9\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u62d6\u566c", "\udb2d\udef1\u3ecf\udac1\udd66\udb4a\udedb\ud948\udd6b\uda2f\udfe8\u111c\udb48\udc07\uda2c\ude6a\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\udbc1\udffd\ud8fb\uddb5\udbdc\udd62\uda4b\ude2e\uda01\udd88\ud997\udf0e\ud909\udc94\ud995\udc1b\ud8d2\udebf\ud971\udd36\udaea\udf01\uda67\udd02\ud81f\udf1a",
        14, 71117, -1610272020, -2758708080384459886L, -47727L, true, false, (char) 10061, (char) 14033,
        Double.longBitsToDouble(0x3fee06de524f2230L), Double.longBitsToDouble(0x3fe9808d1ffa0fe9L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 9, 14, "\udb26\udc16\udb12\udeb9\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f0b\u4e4c\u5c97\uadfd\ucfb0\ub078\u4c5c\u0305\u46ba\ucf3c\u9e17", "\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\udbc1\udffd",
        37, 49379, 1340701049, 2409772765004832775L, -63453L, true, true, (char) 38573, (char) 40181,
        Double.longBitsToDouble(0x3f8abd88fba221c0L), Double.longBitsToDouble(0x3fe641aea4f55d59L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 1, 14, "", "", "\ud822\ude31",
        2, 91761, -369426274, 764638315179790191L, -100000L, true, false, (char) 186, (char) 55503,
        Double.longBitsToDouble(0x3fecd9216bc87a3aL), Double.longBitsToDouble(0x3fed80dbeb48f1efL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 14, "\udace\udd39\udb00\udf83\ud9d2\udf23\uda99\udf64\ud839\udf1f\ud835\udf60\u7dc8\udb50\udc51\ud824\udf1f\ud80c\udcba\ud8b7\udd1b", "\u2b07\ub884\u3359\u8054\u0305\u29b9\ucf3c\u4f49\u29df\u0203\ud74e\u1650\u6364\u1d19", "\udbc9\udc62\uda4b\ude2e\uda1b\udd5f\udb56\udfee\ud909\udc94\ud864\udc83\uda88\udc9d\ud971\udd36\udaea\udf01\uda67\udd02\ud81f\udf1a\ud904\udc48\ud99d\udd92\ud9e2\udd9c\udb44\udf60\ud865\udc02\u91b1\ud80a\udf38\ud8df\uddc0\ud839\udcae\ud8c3\udd27\u024c\ud93f\udc43\udba4\udd83\udad4\udd85\udbd6\uddcc\ud869\udc74\udb0d\udc25\ud956\udead\udbe1\udd7a\ud9b2\udc4b\ud8f1\udf52\uda48\udc14\ud9f9\udf4a\udaf5\ude8c\uda34\ude07\udaa8\udd8e\ud8db\udc68\ud918\ude01\ud97c\udf8a\udbd0\udf8e\ud927\udf19\ud86d\udda1\udbfa\udec5\ua757\ud81d\udc8e\udbd7\udce2\udbe9\udfa6\ud9ce\ude56\uda0f\udc19\ud912\udd39\udb32\udf66\ud879\udfa3\uda9f\udf75\ud89f\udf74\ud8a2\ude86\udbc3\udcd2\udb89\udfe9",
        36, 33436, 1765514942, 7525842946719852830L, -18055L, false, true, (char) 62075, (char) 56835,
        Double.longBitsToDouble(0x3fea395033428d59L), Double.longBitsToDouble(0x3fd770d4f4d08234L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 13, 13, 14, "\udace\udc8b\udb00\udf83\uda37\udd9a\ud9a3\udd47\uda55\udda5\ud931\udd7c\udbbb\udc87\udb50\udc51", "\u220b\u1d67\u5cdb\uadfd\ucfb0\ub078\u4c5c\u97fe\u3b22\u1103\u85aa", "\uda58\ude06",
        23, 89221, -1566831671, -4470806775033784303L, 65511L, false, true, (char) 16760, (char) 15041,
        Double.longBitsToDouble(0x3fe618b7a2a5d2f4L), Double.longBitsToDouble(0x3fe368e2056ca789L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 3, 3, 10, "\ud8a3\uddda", "\000\u649a", "\ud8e2\udc19\ud824\udf1f\ud80c\udcba",
        19, -1000, -1917133135, -2835015797319073705L, -54213L, false, false, (char) 15590, (char) 20330,
        Double.longBitsToDouble(0x3fe651f11bda077bL), Double.longBitsToDouble(0x3fca04d75c0f9360L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 3, 4, 14, "", "", "",
        2, 66391, -1033911087, -1020052353203697090L, -99969L, false, false, (char) 57008, (char) 24896,
        Double.longBitsToDouble(0x3fead6ea42b6cdafL), Double.longBitsToDouble(0x3f91d0e154012bc0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 14, "\ud841\udf1a\ue46a=", "\u8025", "\ud824\udf1f",
        -1, 16117, 764971302, -5576589587616937721L, -100000L, true, false, (char) 108, (char) 19649,
        Double.longBitsToDouble(0x3fefe826bb33c8adL), Double.longBitsToDouble(0x3feba6bbecf866d6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 10, 14, "", "\uc965\000\u6812\u8d9c\ua701\u64db\ubb5b", "\u574a",
        18, 97391, -402449465, -5916292157177593856L, -60114L, true, true, (char) 17203, (char) 33912,
        Double.longBitsToDouble(0x3fe09db4cc623f9bL), Double.longBitsToDouble(0x3fe9d669c12eff51L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 14, "<", "\u1447", "\u7dc8\udb46\uddac\000\u594b\ud8b7\udd1b",
        8, 47753, 875364391, 2606920974628198382L, -52917L, false, true, (char) 17826, (char) 0,
        Double.longBitsToDouble(0x3feec8b0034209abL), Double.longBitsToDouble(0x3fe7c33e980000fbL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 4, 4, 14, "\000", "", "\uda14\udf5c\ud8ee\udc87\ud998\udef4\udb4e\udedf\ud80f\udedb\037\000\uda30\udecc\ud8b3\ude07\udbb6\udc62\ud837\udfef\ud931\udc9e\ufd0b\ud912\udd16\ud9dc\udcee\udae4\udd7e",
        56, 93456, -368127772, -1669609605618903849L, 13000L, true, false, (char) 64231, (char) 943,
        Double.longBitsToDouble(0x3fe717c4a13af7d7L), Double.longBitsToDouble(0x3fbcd50c735d8580L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 14, "\udb68\udc4e\ue46a=", "\uceee", "\ud824\udf1f",
        -1, 52213, 748194086, -1509616477291734520L, 96408L, true, true, (char) 49492, (char) 39221,
        Double.longBitsToDouble(0x3fe135521d7cd976L), Double.longBitsToDouble(0x3fefe826bb33c8adL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\udace\udc8b\udb00\udf83\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f0b\u4e4c\u5c97\uadfd\ucfb0\u4078\u4c5c\u0305\u46ba\ucf3c\u4f49", "\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\udbc1\udffd\ud8fb\uddb5\udbaf\udcac\ud8fb\ude3b\uda28\ude7f\ud997\udf0e\ud909\udc94\ud995\udc1b\ud8d2\udebf\ud971\udd36\udaea\udf01\uda10\ude52\ud81f\udf1a\ud904\udc48\ud8fc\udc1a\ud9ea\udd34\ud8fb\udc60\udae4\ude83\uda43\udf3d\uda4d\udc88\uda05\udd16\ud8ed\udd6e\ud814\udc0c\ud9d5\uddbe\udba0\ude30\ud905\uddce\udbef\udec7\ud899\udeb3\ud90c\ude29",
        36, 97114, 1364687878, 3334505223052085655L, 99069L, true, false, (char) 45890, (char) 59887,
        Double.longBitsToDouble(0x3fe635b08efc00dfL), Double.longBitsToDouble(0x3faa06a7ff1e8050L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 14, "\ud9a4\udc70\udb9f\udfb7\uda75\udc39\udb2d\udf51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51\ud824\udf1f\ud82c\udf4d\ud8b7\udd1b\udafb\udf6f\udad5\udfdf\udbf1\udcb5\udb2d\udef1\u8ff7\ud8d7\udf29\udb4a\udf20\ud948\udd6b\uda2f\udfe8\udb73\udf93\ud85d\udfd9\uda00\uddd5\u8279\ud9ea\udd2c\ud861\udd33\udb34\udf0c\uda3a\ude9b\u888a\ud8a8\udf45", "\ucc7f\u561b\uafd9\u4217\u2994\u35be\u4a05\u990f\u17e0\u3b49\u57ee\u3f82\u2634\u3cdf\ubd38\u6dae\uc6b6\u0e4e\u6dad\u114b\u0635\u7f5c\uc58f\u86a6\ua7f9\u4139\u9e66\uaeda\u98d3\ub43f\uae1a\u963c\u6529\ub69c\u6c6f\u7bae\u2465", "\uda39\udd88\ud8b6\udf4d\uda5e\ude88\ud8e7\udc1f\uda5b\udc05\ud845\udd15\uda07\udeed\ud9ac\udf2f\ud817\udf18\uaaeb\ud86f\udd96\ud96c\udea1\uda1a\ude55\udac6\udd86\ud9c4\udcad\ue464\ud938\ude6c\udb13\udec7\ud80f\udc5a\ud998\ude7e\ud717\udaff\udcdd\ud93a\ude02\ud93d\udd34\udb5a\ude89\ud966\udc2f\udb3d\udd15\ud9c4\udc53\ud9ba\udd1d\udb99\udff3\udbea\udea0\u19cb\udbf9\udfbc\udb00\udef0\uda8f\udfe0\udbfd\udc66\ud99e\udf6c\ud98a\udfad\ud8ff\udd12\udbf1\udc41\ud801\udf34\udb08\udf81\uda1e\uddc4\ud8e4\uddd6\uda4a\udda5\udab1\udee3\uda7b\udd1b\ud9d0\udd33\udb27\uddd7\u68df\ud9c8\udec1\ud8db\udda7\ud856\udfa9\ud98d\udef1\ud976\udeeb\udb2f\udc5a\ud83d\ude22\ud861\udd31\ud80b\ude60\uda35\udf74\ud885\udc29\udb85\udfc5\udaf0\udc3f\udb59\udf97",
        -4, 79727, 136406322, 8623709372366332394L, -19641L, false, true, (char) 17198, (char) 44361,
        Double.longBitsToDouble(0x3fe841c5efebd35eL), Double.longBitsToDouble(0x3fd8ba3bc4efc80aL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 14, "\ud841\udf1a\ue46a=\000\ud994\udf2f\udb44\udd45\u71d1\udb50\udc51\ud824\udf1f\uda00\udebb\udbef\udea1\udb82\udfd5\ud99f\udcc1\ud9f5\udfd8\udabd\udd95\u00c8\u00c2\ud92a\udf55\uda86\udd97\ud93e\udc79\u6d94\ud964\udcba\udb64\udccf\ud9b4\udd83\u83c5\ud882\udc05\udb38\udf5c\ud9b4\udf0e\ud8c7\udff3\uaebe", "\u8ad8\u96a2\u5e1c\u988d\u9ef1\u210c\u78cb\ub8bb\u4745\u9c9d\u4920\u79b2\u31dc\u1337\u09ca\u68b3\u0683\u6e08\ua367\u126b\uae61\u79f5\u6c65\ud302\u0bee\u63ac\u20e7\u8ebc\ub1a3\u9775\u4ab7\u6bbe\u6296\u35a9\u37f2\uc1e7\u351b", "\ud953\udf32\udb2a\udeef\ud97f\udca3",
        17, 79225, 2118490257, -2483676436520660457L, 72294L, true, true, (char) 33957, (char) 35,
        Double.longBitsToDouble(0x3fed615cac000d2fL), Double.longBitsToDouble(0x3fb1c07b5de68d30L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\udabb\udc20\udb00\udf83\uda75\udc39\udb34\udc51\ud839\udf13\ud835\udf60\u7dc8\udb50\udc51", "\u4f0b\u4e4c\u5c97\uc0cf\u56ab\ub00c\u4c5c\u8997\u25a3\ucf3c\u4f49", "\udb85\udc6a\ud95a\udd60\ud861\udd33\ud801\ude48\udbc1\udffd\ud8fb\uddb5\udbc9\udc62\uda4b\ude2e\uda01\udd88\ud997\udf0e\ud909\udc94\ud995\udc1b\ud8d2\udebf\ud971\udd36\ud92e\udc84\uda67\uddc2\ud81f\udf1a\ud904\udc48\ud8fc\udc1a\udb8c\ude25\udabb\ude2a\ud8c7\udf9b\ud8f9\udc75\uda4d\udc88\uda05\udd16\ud8ed\udd6e\ud814\udc0c\uda00\udeb5\udba0\ude30\ud905\uddce\udbef\udec7\udb35\uddc1\udba2\udd48",
        19, 96890, -1319883894, -7417804609160984169L, 99069L, true, true, (char) 45890, (char) 59887,
        Double.longBitsToDouble(0x3fe635b08efc00dfL), Double.longBitsToDouble(0x3faa06a7fc7b6050L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 14, "\ud841\udf1a\ue46a=\000\ud994\udf2f\udb44\udd45\u71d1\udb50\udc51\ud824\udf1f\uda00\udebb\udbef\udea1\udb82\udfd5\ud99f\udcc1\ud9f5\udfd8\udabd\udd95\u00c8\u00c2\ud92a\udf55\uda86\udd97\ud93e\udc79\u6d94\ud964\udcba\udb64\udccf\ud9b4\udd83\u83c5\ud882\udc05\udb38\udf5c\ud9b4\udf0e\ud8c7\udff3\uaebe\ud82c\udf8a\udb1e\ude47\udbfd\udeec\uda65\uddd4\uda51\uddca\ud9f5\ude83\uda06\udeb7\ud9a8\uddc6\ud85d\ude52\uda12\ude90\uda4c\udea6\ud9d5\udc50\ud970\uddef\ud8ae\udf9c\ud83c\ude7b\ud844\udc2d\ud9d7\udf5f\udb52\udcf0\ud986\udcbe\ud944\udf3e\udad1\udd5f\udb56\udd61\udafc\udc07\udabd\ude4d\ud807\udc40\udad3\udf94\ud9ae\udc35\ud8d7\udcab\ud9cd\udcfb\ud87d\ude88\ud911\udd7b\ud9cb\udf79\uda77\udc97\ud846\udcc4\ud9c4\udfae\ud8ae\udd86\ud81c\udf17\ud935\udd67\ud889\udd2c\uda6a\udc02\udb20\udfe1\ud953\udf32\udb2a\udeef\ud97f\udca3\udaf0\ude8e\udbe2\udd3d\u2802\udbfc\udf68\ud80b\udcea\uda8e\udcfd\ud975\udc4c\ud882\uddf6\udb2d\ude29\uda15\udc8b\udb95\udc72\ud807\udc1d\udad9\udd8b\uda67\udf5f\ud823\udc54\uda0c\udc58\udb82\udd18\udab1\udf0a\ud860\ude6b\ud8bc\udda5", "\u414a\u8425f", "\ud90e\udcd5\udbdb\udf21\ud946\udc92\ud920\udc5e\udb20\udc29\ud9ee\udece\udb86\udc1d\u2c03\udb5c\udfb8\ud987\ude09\ud9a7\udc87\ud95f\udf97\udbe9\udfb9\ud916\udf67\ud878\udffb\uda0d\udfde\uda51\udf4f\udbed\udd13\ud954\udc02\ue12d\ud8a4\udd3d\udb9a\udf96\ud8bd\udfde\ud979\udcd4\uf676\ud836\udef0\u0bfa\udbae\udd9c\ud8da\ude70\ud84d\udce9\ud997\udcd5\ud98a\udf5a\ud8bd\ude84\ud8a8\udda9\udb5a\udf7d\uc564\udbb2\udd41\udba4\uddbc\ud85b\udd70",
        55, 22170, -1738137272, 1009757130211143444L, -55674L, false, true, (char) 26560, (char) 17496,
        Double.longBitsToDouble(0x3fd4eeebf317be90L), Double.longBitsToDouble(0x3fca23c7f0052528L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 14, "\ud841\udf1a\ue46a=\000\ud994\udf2f\udb44\udd45\u71d1\udb50\udc51\ud824\udf1f\uda00\udebb\udbef\udea1\udb82\udfd5\ud99f\udcc1\ud9f5\udfd8\udabd\udd95\u00c8\ud922\udcb2\ud942\ude56\uda86\udd97\ud93e\udc79\u6d94\ud964\udcba\udb64\udccf\ud9b4\udd83\u83c5\ud882\udc05\udb38\udf5c\ud9b4\udf0e\ud8c7\udff3\uaebe\ud82c\udf8a\udb1e\ude47\udbfd\udeec\uda65\uddd4\uda51\uddca\ud9f5\ude83\uda06\udeb7\ud9a8\uddc6\ud85d\ude52\uda12\ude90\uda4c\udea6\ud9d5\udc50\ud970\uddef\ud8ae\udf9c\ud83c\ude7b\ud844\udc2d\ud9d7\udf5f\udb52\udcf0\ud986\udcbe\ud944\udf3e\udad1\udd5f\udb56\udd61\udafc\udc07\udabd\ude4d\ud807\udc40\udad3\udf94\ud9ae\udc35\ud8d7\udcab\ud9cd\udcfb\ud87d\ude88\ud911\udd7b\ud9cb\udf79\uda77\udc97\ud846\udcc4\ud9c4\udfae\ud8ae\udd86\ud81c\udf17\ud935\udd67\ud889\udd2c\uda6a\udc02\udb20\udfe1\ud97d\udfe7\ud91e\udde0\ud97f\udca3\udaf0\ude8e\udbe2\udd3d\u2802\udbfc\udf68\ud80b\udcea\uda8e\udcfd\ud975\udc4c\ud882\uddf6\udb2d\ude29\uda15\udc8b\udb95\udc72\ud807\udc1d\udad9\udd8b\uda67\udf5f\ud823\udc54\uda0c\udc58\udb82\udd18\udab1\udf0a\ud860\ude6b\ud8bc\udda5", "\u414a\u8425f", "\ud90e\udcd5\udbdb\udf21\ud946\udc92\ud920\udc5e\udb20\udc29\ud9ee\udece\ud9b6\udfd6\ud8e2\ude56\udb5c\udfb8\ud987\ude09\ud9a7\udc87\ud95f\udf97\udbe9\udfb9\ud916\udf67\ud878\udffb\uda0d\udfde\uda51\udf4f\udbed\udd13\ud954\udc02\ue12d\ud8a4\udd3d\udb9a\udf96\ud8bd\udfde\ud979\udcd4\uf676\ud836\udef0\u0bfa\udbae\udd9c\ud8da\ude70\ud84d\udce9\ud997\udcd5\ud98a\udf5a\ud8bd\ude84\ud8a8\udda9\udb5a\udf7d\uc564\udbb2\udd41\udba4\uddbc\ud85b\udd70",
        55, 22170, -1738137272, 1009757130211143444L, -55674L, false, true, (char) 26560, (char) 17496,
        Double.longBitsToDouble(0x3fd4eeebf317be90L), Double.longBitsToDouble(0x3fca23c7f0052528L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 14, "\ud841\udf1a\ue46a=\000\ud994\udf2f\udb44\udd45\u71d1\udb50\udc51\ud824\udf1f\uda00\udebb\udbef\udea1\udb82\udfd5\ud99f\udcc1\ud9f5\udfd8\udabd\udd95\u00c8\u00c2\ud92a\udf55\uda86\udd97\ud93e\udc79\u6d94\ud964\udcba\udb64\udccf\ud9b4\udd83\u83c5\ud882\udc05\udb38\udf5c\ud9b4\udf0e\ud8c7\udff3\uaebe\ud82c\udf8a\udb1e\ude47\udbfd\udeec\uda65\uddd4\uda51\uddca\ud9f5\ude83\uda06\udeb7\ud9a8\uddc6\ud85d\ude52\uda12\ude90\uda4c\udea6\ud9d5\udc50\ud970\uddef\ud8ae\udf9c\ud83c\ude7b\ud844\udc2d\ud9d7\udf5f\udb52\udcf0\ud986\udcbe\ud944\udf3e\udad1\udd5f\udb56\udd61\udafc\udc07\udabd\ude4d\ud807\udc40\udad3\udf94\ud9ae\udc35\ud8d7\udcab\ud9cd\udcfb\ud87d\ude88\ud911\udd7b\ud9cb\udf79\uda77\udc97\ud846\udcc4\ud9c4\udfae\ud8ae\udd86\ud81c\udf17\ud935\udd67\ud889\udd2c\uda6a\udc02\udb20\udfe1\ud953\udf32\udb2a\udeef\ud97f\udca3\udaf0\ude8e\udbe2\udd3d\u2802\udbfc\udf68\ud80b\udcea\uda8e\udcfd\ud975\udc4c\ud882\uddf6\udb2d\ude29\uda15\udc8b\udb95\udc72\ud807\udc1d\udad9\udd8b\uda67\udf5f\ud823\udc54\uda0c\udc58\udb82\udd18\udab1\udf0a\ud860\ude6b\ud8bc\udda5", "\u414a\u8425f", "\ud90e\udcd5\udbdb\udf21\ud946\udc92\ud920\udc5e\udb20\udc29\ud9ee\udece\udb86\udc1d\u2c03\udb5c\udfb8\ud987\ude09\ud9a7\udc87\ud95f\udf97\udbe9\udfb9\ud916\udf67\ud878\udffb\uda0d\udfde\uda51\udf4f\udbed\udd13\ud954\udc02\ue12d\ud8a4\udd3d\udb9a\udf96\ud8bd\udfde\ud979\udcd4\uf676\ud836\udef0\u0bfa\udbae\udd9c\ud8da\ude70\ud84d\udce9\ud997\udcd5\ud98a\udf5a\ud8bd\ude84\ud8a8\udda9\udb5a\udf7d\uc564\udbb2\udd41\udba4\uddbc\ud85b\udd70\udb74\ude8e\ud828\udee2\u432d\ud980\udd96\ud80e\udc75\uda26\udf79\ud9f8\udfcb\udb97\udcad\u679d\udad8\udd80",
        5, 24739, 1229612241, -8836058067388465104L, -33873L, true, false, (char) 34099, (char) 45895,
        Double.longBitsToDouble(0x3fd9c75808108c14L), Double.longBitsToDouble(0x3fe8261627ccd7fcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.DefaultParser|isShortOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredArgs||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredOptions||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|getLongPrefix|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleConcatenatedOptions|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithoutEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleProperties|java.util.Properties|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleShortAndLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleUnknownToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isArgument|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isJavaProperty|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isShortOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
