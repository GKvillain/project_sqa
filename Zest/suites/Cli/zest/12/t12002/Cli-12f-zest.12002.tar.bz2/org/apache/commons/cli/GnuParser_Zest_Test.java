package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class GnuParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |a1=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud843\udde1\ud806\udf9b", "\u07f9\u5ed1\u317f\u4de4", "\ud984\udc69\ud902\ude72\ud8bf\udf6c\uda40\udf0d\uda68\udfed\udade\udcf0\uda2f\udcaa",
        32, 28192, 355024487, -4084540293604903614L, -37734L, false, true, (char) 28302, (char) 47916,
        Double.longBitsToDouble(0x3fdad84234c72776L), Double.longBitsToDouble(0x3fe916d211d88489L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |a1=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud843\udde1\ud806\udf9b", "\u07f9\u5ed1\u317f\u75a9", "\ud984\udc69\ud902\ude72\ud8bf\udf6c\uda40\udf0d\uda68\udfed\udade\udcf0\uda2f\udcaa",
        32, 28192, 355024487, -4084540293604903614L, -37734L, false, true, (char) 28302, (char) 47916,
        Double.longBitsToDouble(0x3fdad84234c72776L), Double.longBitsToDouble(0x3fe916d211d88489L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud841\ude61\ud893\uddae]] |a1=[Ljava.lang.String;:[[\ud841\ude61\ud893\uddae]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud841\ude61\ud893\uddae", "\u07f9\u5ed1\uad59\u9518\u2aa0", "\ud902\ude71\ud8bf\udf6c\uda40\udf0d\u169c\udadd\ude55\uda2f\udcaa",
        32, 28192, -1970906314, 6195145444661138048L, -37734L, false, true, (char) 28302, (char) 47916,
        Double.longBitsToDouble(0x3fdad84234c72776L), Double.longBitsToDouble(0x3fe916d215d88489L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud843\udde1\u74c8]] |a1=[Ljava.lang.String;:[[\ud843\udde1\u74c8]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud843\udde1\u74c8", "\u07f9", "\ud8bf\udf1a\udb70\udc39",
        43, 24332, 66, 0L, -100000L, false, false, (char) 36090, (char) 15352,
        Double.longBitsToDouble(0x3fe33f2b843e1529L), Double.longBitsToDouble(0x3fd42c75000001d0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 1, 0, 1, "\udbfc\ude90\ud96b\udc16\ud91d\udce7\uda06\udd71\ud4d6\udb8b\ude9d\ud9d7\udfeb\udadd\ude65\udb70\udc39\udbe1\udee1\udba6\udf89\ud986\udc08\ud9ef\udef4", "\uaf78\u575b\uc61f\u5002\uc9a4", "\ud8ba\udfc3\udbc8\uddad\udbba\udd63\uda2a\uddd9\uda48\udeda\ud931\ude59\udbd3\udfcc\ud813\udf62\ud8ab\udd0c\ud952\udccb\udb5d\udddd\ud9a7\udedf\udab4\udd51\udaea\udc0b\ud87e\udf94\ud933\udca2\udb78\udc7a",
        56, 24208, 1801014286, 4865582145882716172L, 24677L, false, false, (char) 63485, (char) 9151,
        Double.longBitsToDouble(0x3fe9d3ddba4592b6L), Double.longBitsToDouble(0x3fc3593dd19f00dcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud843\udde1\ud806\udf9b", "\u07f9\u5ed1\u317f\u539c\ucd59\u32fd\ua7d7\ub14d\u886e\u3708\ua9c6\u4b00\u3d92\u4477\u9aad\u777b", "\ud964\ude32\ud9f8\udec4\udab8\udd67\ud8a4\ude7c\udbad\udee7\ud96d\uddc4\ud931\udcaa\uda64\udf4b\uda52\udc29\uda4f\ude51\ue040\udb19\uddc2\u9ed7\udb4f\ude78\udbda\udced\uda32\udf4a\ud865\ude03",
        14, 24603, -940518387, -5472158183550851887L, -72958L, false, true, (char) 55007, (char) 56521,
        Double.longBitsToDouble(0x3fe8ec9e1a243acbL), Double.longBitsToDouble(0x3fe723ba23d28ddbL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud845\udcbb\ud8fd\udfbb\uda04\udfc9\ud899\udc81\ud855\uddac\udb8b\ude9d\udab5\udcaf\ud858\udee3\udb70\udc39\udbe1\udee1\ud992\uddc8\ud858\udc1d\ud936\uded8]] |a1=[Ljava.lang.String;:[[\ud845\udcbb\ud8fd\udfbb\uda04\udfc9\ud899\udc81\ud855\uddac\udb8b\ude9d\udab5\udcaf\ud858\udee3\udb70\udc39\udbe1\udee1\ud992\uddc8\ud858\udc1d\ud936\uded8]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud845\udcbb\ud8fd\udfbb\uda04\udfc9\ud899\udc81\ud855\uddac\udb8b\ude9d\udab5\udcaf\ud858\udee3\udb70\udc39\udbe1\udee1\ud992\uddc8\ud858\udc1d\ud936\uded8", "\u4b00\u3d92\u4477\u250d\u777b\u310f", "\ud9d2\udd21\udab8\udd67\udaf2\udd74",
        11, 41474, -2078069769, -7801464165721042333L, 12168L, true, true, (char) 44115, (char) 15398,
        Double.longBitsToDouble(0x3fd1d152b515b3b4L), Double.longBitsToDouble(0x3fe80794c7d590ddL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |a1=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud843\udde1\ud806\udf9b", "\u07f9\u5ed1\u317f\u5366", "\ud984\udc69",
        58, 68776, 1012631423, 4468802584022361575L, -100000L, false, false, (char) 9176, (char) 57702,
        Double.longBitsToDouble(0x3fd42c750802d1d0L), Double.longBitsToDouble(0x3fe9d00003dd9730L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud8a7\ude74\uda0d\udf43", "\u0748\ucbbc\u5df1\ub800\u8fa9\u32fd\ua7d7\u1c39\u768d\u0ed7\u81bc\u4ad0\u3d92\u6615\u1bf1\ua375\u6664\u69e0\u49c1\u7700\u1351\u6f9e\u8cfa\uc702", "\ud984\udfd8",
        -1, 56, -82030515, 5088685585845368417L, -31526L, true, true, (char) 24148, (char) 33368,
        Double.longBitsToDouble(0x3fe61070bc2ffb94L), Double.longBitsToDouble(0x3feb789a07e84f14L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |a1=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud843\udde1\ud806\udf9b", "\u9581\u98c2\u317f\u9c1c\u74d9\ua9af\ua7d7\u6cf6", "\uda87\udd9b",
        45, 56562, 1238404347, -1819732255555751648L, -37734L, false, false, (char) 28317, (char) 34720,
        Double.longBitsToDouble(0x3fd1be5a8a9ead76L), Double.longBitsToDouble(0x3fa44e809d884890L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 0, "\udb7c\udea1\ud80f\udea9\ud896\ude32\uda2e\udcef\ud855\uddac\udab9\ude94", "\u8fa9\u8b79\u99f4\u860b\u0481\u3708\u9a13\u67c9\u6a0e\u4477\u32f9\u4018\u310f\u0999\u4998\u7700\u1351\u6f9e\u3fa4\u0cf3\ucb26", "\ud970\udfdb\ud9cd\udc54\udad1\uddb8\ud8a4\ude72\uda44\udc9c\udb1f\ude2c\ud8ce\udd9a\ud946\udc98\uda57\udef9\ud94e\udd54\ud8e2\ude7d\udb73\udec0\uda94\ude72\ud924\udcf6\ud9bb\udde3\uda7a\ude63\uda94\udfbe\uda3a\udeef\ud956\udd14\udb88\uded7\uda8b\udef2\udb5a\uddfb\udb66\ude7e\udbbd\uddf4\ud9a3\udd79\ud919\udde0",
        28, 94084, -767746140, -1274020840396212129L, -30968L, false, false, (char) 65459, (char) 38718,
        Double.longBitsToDouble(0x3f51d029dfa55e00L), Double.longBitsToDouble(0x3fd47dd6ecbc06aeL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |a1=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |this=org.apache.commons.cli.GnuParser:@?\0121=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |a1=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud843\udde1\ud806\udf9b", "\u07f9\u5ed1\u5720\u38c1", "\ud984\udc69\ud902\ude72\ud8bf\udf6c\uda40\udf0d\uda68\udfed\ufe65\uda2f\udcaa\uda58\udd54\ud91c\udc97\ud8cf\udfa6",
        9, 70602, -1278211071, -7552533025873430636L, 61318L, false, false, (char) 47916, (char) 56492,
        Double.longBitsToDouble(0x3fe28c9dd822da42L), Double.longBitsToDouble(0x3fd626443e2bf258L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud843\udde1", "\u9f61\u07f9\u5ed1\u317f\u9bd1\u8ba3\u3340\ua7d7\ucbd3\ua21e\u4c63\uaeff\u2700\u3d92\u4477\u9aad\u777b\u310f\u0999\u4998\u7700\u488b\u7060\u422a\u2ebc\u6929\u3a5b\u85a7\u48ce", "\ud92a\udde0\ucc1d\ud957\udf6f\uda59\udcc9\ud841\uddb9\uda19\udcf2\ud939\ude1a\ud8a2\uddf5\udac7\udee1\ud85f\udfd7\ud836\udd11\uda5e\udcbc\ud8d0\udcee\udb7f\udccc\ud913\udd9b\ud9a3\udf75\ud95e\udff3",
        31, 53211, 1986085990, 8425143737513138377L, 4351L, true, false, (char) 35534, (char) 48769,
        Double.longBitsToDouble(0x3fec758a4ff52622L), Double.longBitsToDouble(0x3fc1ce7c679ed21cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |a1=[Ljava.lang.String;:[[\ud843\udde1\ud806\udf9b]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud843\udde1\ud806\udf9b", "\uad9b\u5ed1\ub079\u4cca", "\ud984\udc69\ud902\ude72\ud8bf\udf6c\uda40\udf0d\uda68\udfed\udade\udcf0\uda2f\udcaa\uda58\udd54\ud91c\udc97\ud8cf\udfa6\udb44\udce6\udadc\udf70\ud885\udf82\udae5\udd0c\uda97\udf57\udac4\udfd7\udbad\udee7\ud96d\uddc4\ud931\udcaa\uda64\udf4b\uda52\udc29\ud941\udca3\ud8ac\udf45\uda42\ude82\ud951\udf2f\udb18\udeaf\udacb\udf92\ud93e\udd58\udbab\udd6c\u7ccf\ud984\ude87\udbb3\udef7\ud8df\udfa0\ud8ed\udf90\ud982\ude7e\ud8f0\udfe5\ud8dc\ude11\ud980\udc93\ud9e7\ude0b\ud8c5\udedc\uda6c\udd04\ud9e2\udcca\ud84f\udc4c\uda91\ude3d\ud99b\ude79\ud841\udcd8\ud9cb\uddc1\u9692\ud920\udf12\ud8f9\udc97\uda9a\udf97\ud92a\ude85\uda93\ude21\udb08\udc1b\udbbe\udec3\udb2c\udc89\udbe9\ude0f\udaa3\udc50\uda3b\udd39\uda84\udcc7\ud902\udc58\u2be1\udb68\udcb3\u9195\ud983\ude97\ud8f6\udf43\ud8a3\ude46\ud93d\udd6a\udadf\udea1\u086f\ud8df\udcd1\uda6d\udc8f",
        -2, 5885, -1411924341, -7679451467307268904L, -69463L, false, true, (char) 60828, (char) 13829,
        Double.longBitsToDouble(0x3fd2b342b66aef78L), Double.longBitsToDouble(0x3fea84c42baf1a2bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud843\udde1\u74c8]] |a1=[Ljava.lang.String;:[[\ud843\udde1\u74c8]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud843\udde1\u74c8", "\ua4b7\000\ud3d9\u4de4", "\000",
        58, 68776, 5998463, 4468802284239529447L, -63909L, false, false, (char) 9176, (char) 57702,
        Double.longBitsToDouble(0x3fd42c750000d1d0L), Double.longBitsToDouble(0x3fe9d00000009730L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud843\udde1]] |a1=[Ljava.lang.String;:[[\ud843\udde1]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud843\udde1", "\u9f61", "\udbf9\udc02",
        0, 37402, 776188968, -3107374942435704510L, -69151L, false, false, (char) 25579, (char) 25703,
        Double.longBitsToDouble(0x3fcf681768a12740L), Double.longBitsToDouble(0x3fe33f2b843e1529L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.GnuParser:@?\0121=[Ljava.lang.String;:[[]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\u8e1d", "\udb8b\ude9d",
        41, 54590, 1779153402, 3333706232352498420L, 31072L, true, true, (char) 91, (char) 15872,
        Double.longBitsToDouble(0x3f29c68000000000L), Double.longBitsToDouble(0x3fe142480067e570L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 1, 1, 0, "\ud9b6\udca5\ud818\udcfc", "\u07f9\u5ed1\u317f\u4de4", "\udbd2\udf9d\ud820\udf76\ud8bf\udf6c\uda40\udf0d\uda68\udfed\udade\udcf0\uda2f\udcaa",
        32, 28192, 1982750567, -2066584122371262996L, 38134L, true, true, (char) 9680, (char) 26852,
        Double.longBitsToDouble(0x3fe916d43eb36a54L), Double.longBitsToDouble(0x3fb2641fa56c0d08L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\000]] |a1=[Ljava.lang.String;:[[\000]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\000", "", "",
        -2, 31211, 1054495590, 7641405676933329960L, -67554L, false, false, (char) 20369, (char) 40097,
        Double.longBitsToDouble(0x3fde73e041b4671aL), Double.longBitsToDouble(0x3fcf681768a12740L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\uda91\udf72\udba1\ude38", "\u07f9", "\uda80\udfd0\uda9e\udfb1\udb68\udf59\uda4f\udf77\ud902\ude71\ud8bf\udf6c\ud917\udd9a\ud817\uddd7\uda70\ude59\uda32\udefb\uda58\udd54\uda19\udcd5\udabd\udc49\ud80a\udd06\udacf\udcae\ud91f\udd2e\udafd\udcb8\udab8\udd67\udaf2\udd74\udbad\udee7\ud96d\uddc4\ud931\udcaa\uda64\udf4b\udac4\udd61\ud94b\udc7b\ud866\udcb4\udac9\udd3b\udad8\udd68\udb02\ude4d\ud872\udebf\udbdd\udfd5\ud819\ude09",
        44, 65238, 739017006, 6847237264873765025L, 43112L, true, false, (char) 11432, (char) 50760,
        Double.longBitsToDouble(0x3fd12b16d32f00b0L), Double.longBitsToDouble(0x3fa44f9a727bbbd0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud966\ude17\udbb3\udd12\ud94a\udd80\uda8f\udca1\ud855\udcfb\uda9e\udedf\udbdc\ude2b\ud90c\ude5c\ud8ef\ude11\udbe1\uded2\ud984\udc69\ud862\udf77\ud9b1\ude93\ud899\ude0b\ud95f\udfd1\udade\udcc0\uda2f\udcaa\udb30\ude78\u5b70]] |a1=[Ljava.lang.String;:[[\ud966\ude17\udbb3\udd12\ud94a\udd80\uda8f\udca1\ud855\udcfb\uda9e\udedf\udbdc\ude2b\ud90c\ude5c\ud8ef\ude11\udbe1\uded2\ud984\udc69\ud862\udf77\ud9b1\ude93\ud899\ude0b\ud95f\udfd1\udade\udcc0\uda2f\udcaa\udb30\ude78\u5b70]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 1, "\ud966\ude17\udbb3\udd12\ud94a\udd80\uda8f\udca1\ud855\udcfb\uda9e\udedf\udbdc\ude2b\ud90c\ude5c\ud8ef\ude11\udbe1\uded2\ud984\udc69\ud862\udf77\ud9b1\ude93\ud899\ude0b\ud95f\udfd1\udade\udcc0\uda2f\udcaa\udb30\ude78\u5b70", "\u69e0\u49c1\u7700\u96db\u7044\u8cfa\uc702\u6929\u1240", "\ud96b\udf44\uda2c\ude15\udb84\udfb3\ud8a0\udec6\ud841\udd48\udbad\uddef\ud971\udd10\ud88d\udccb\uda69\ude95\ud93a\ude7f\ud9bb\udd51\ud80c\udc18\ud813\udec3\u731e",
        25, 29017, -1120532572, -4436663336502833470L, 51340L, false, true, (char) 41719, (char) 26006,
        Double.longBitsToDouble(0x3fe824cca6b9b32aL), Double.longBitsToDouble(0x3fe5adcae11b6a7aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud9b6\uddee\ud806\udfd2", "\u07f9\u5ed1\u9720\u4de4", "\udb83\udc12\ud902\ude72\ud8bf\udf6c\uda40\udf0d\uda68\udfed\ud979\uddfe\ud929\udd12",
        32, 28192, 1842076263, 8632090251821059489L, -37734L, false, true, (char) 28302, (char) 47916,
        Double.longBitsToDouble(0x3fdad84234c72776L), Double.longBitsToDouble(0x3fe916d214d88489L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud843\udde1\ud806\udf9b", "\u29ba\u5ed1\u317f\u4de4", "\ud984\udc69\ud902\ude72\ud8bf\udf6c\u37b5\uda68\udfed\udade\udcf0\uda2f\udcaa",
        32, 28192, 355024487, -4084540293604903614L, 7632L, true, false, (char) 21518, (char) 47524,
        Double.longBitsToDouble(0x3fe098e49ccbff9dL), Double.longBitsToDouble(0x3fecb9ee5ae6a661L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 1, "\ud966\ude17\udbd3\udf12\ud94a\udd80\uda8f\udca1\ud941\ude52\udab5\ude7f\udbdc\ude2b\ud90c\ude5c\udbbc\udd4e\udbe1\uded2\udab7\udd62\udb1a\udf73\ud9b1\ude93\ud899\uddfb\ud95f\udfd1\ua4a6\uda09\udf49\udb30\uddb9\u5b70", "\u69e0\u49c1\u7700\u96db\u7044\u8cfa\uc702\u6929\u1240\u9a42\u3344\u4606\u8a19\u8e09\u2a95\u1872\u5c12\u3e99\u31cd\u2e75\u6d85\u9300\u4929\u82f8\uc632\u8020\ube6b\u507b\u753a\ubfa4\ub04a\u0f6c\u0257\u0efc\u78c1\u0b3d\u1b7f\u0783\ub440\uaa59\u8d34\u48da\u6db1\u67f3\u8b00\ua901\u12b6\u88fe\u40fb\u4e8c\u4582\u5261\u9810\u7c32\u05b4\u2e12\u64c0\u0bed\u650f\u4a42\u6b63\ucea0\u7479\u2af7\u11b4\u7cb8\u43f1\u33ba\u2357\u3a56\u7c10\ud0f4\u57f4\u7d5f\u6f49\u30e4\u7469\u70cf\u6e0f\u1d69\ucaad\u6c3f\u04ad\ud6ba\u6331\u8cb5\u7deb\u8af0\u7073\u0c15\u85f4\u8df4\u0742\u4910\u57e2\u3e64\u5e16\u613b\u4181\u0fff\u06bd\ud059\u7918\uc117\ud74a\uafff\u6f97\ud113\u35a8\uc0ba", "\uda33\udf2c",
        25, 88558, 1509028150, -2746270418056542765L, 43277L, true, true, (char) 36555, (char) 27291,
        Double.longBitsToDouble(0x3feab978b4cd8c89L), Double.longBitsToDouble(0x3fef3f9f01171348L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.GnuParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.GnuParser:",
    "C|org.apache.commons.cli.GnuParser|<init>|",
    "M|org.apache.commons.cli.GnuParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.GnuParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
