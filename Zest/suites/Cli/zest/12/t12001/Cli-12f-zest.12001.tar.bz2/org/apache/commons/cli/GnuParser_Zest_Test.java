package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class GnuParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46]] |a1=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46", "\u2c31\u5e4a\u1c03\u16ce\uc6ec\u309c\u59ed", "\udb9f\udc03\uda60\udd6f\udbe9\udf61\udab7\ude13\ud8fa\udead\ud88a\udca9\uda6a\ude0e\udac8\udc67\ud873\udd74\u41be\uda30\udfbb\uda52\udda0\ud8ca\udcdc\ud87f\udf81\uda0e\udde0\ud9b8\udded\udad2\udeeb",
        52, 83926, 1244089006, -2565197175115420672L, -61401L, true, true, (char) 36669, (char) 54998,
        Double.longBitsToDouble(0x3fe16185cdad017bL), Double.longBitsToDouble(0x3fe420e18d3ac962L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46]] |a1=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46", "\u2c31\u5e4a\u1c03\u16ce\uc6ec\u309c\u59ed", "\udb9f\udc03\uda60\udd6f\udbe9\udf61\udab7\ude13\uda0b\udc35\udb6b\udf4b\ud98c\udec8\ud9a2\udea6\udbbb\udf5c\u4198\uda30\udfbb\uda52\udda0\ud8ca\udcdc\ud87f\udf81\uda0e\udde0\ud9b8\udded\udad2\udeeb",
        52, 83926, -1759032658, -2565197175115420672L, -61401L, true, true, (char) 29501, (char) 54998,
        Double.longBitsToDouble(0x3fe16185cdad017bL), Double.longBitsToDouble(0x3fe420e18d3ac962L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\000]] |a1=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\000]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\000", "\u2c31\u5e4a\u1c03", "\udac9\udc18",
        31, 60663, -329106, 575829897216L, 96608L, true, false, (char) 48388, (char) 64850,
        Double.longBitsToDouble(0x3fe0c933584f9f67L), Double.longBitsToDouble(0x3fed62ba71612321L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\u513a\udb64\udf0e\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3]] |a1=[Ljava.lang.String;:[[\u513a\udb64\udf0e\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\u513a\udb64\udf0e\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3", "\u9cfe\ua8a6", "\ud8f3\udc34\udb54\udcb4\udad6\udd20\udab7\udecc\uda75\udc77\uda8d\udc31\udac9\udc18\ud842\ude32\udbbd\udd58\udabe\ude6d",
        35, 9614, 612724027, -2738249798010695165L, -7919L, false, true, (char) 5250, (char) 981,
        Double.longBitsToDouble(0x3fcedbbac147f928L), Double.longBitsToDouble(0x3fd6779f9fd897dcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 0, "\ud929\udfa5\uda16\udf8b\uda64\uddf2\ud8ed\udf78\udb6b\ude2a\udace\udcb3\udb5c\udef6\ud881\udf63\ud820\udf2b\udb17\udf45\ud8ba\udecf", "\u2c31", "\uda75\udc77\uda8d\udc31\udac9\udc18\udafa\ude2e\udbbd\udd58\udabe\ude6d\udb9f\udc03\uda60\udd6f\udbe9\udf61\udab7\ude13\ud8fa\udead\udaed\udf73\uda6a\ude0e\udac8\udc67\ud873\udd74\uda74\udd50",
        17, 43972, -26101054, 8789179638940661275L, -46633L, false, false, (char) 40520, (char) 9150,
        Double.longBitsToDouble(0x3fe61a513c00dc66L), Double.longBitsToDouble(0x3f9d9e68d8eaec20L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda5a\udd1c\ud97b\udfc5\udbed\udd18\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\ud9ee\udccd\ud828\ude10\uee41]] |a1=[Ljava.lang.String;:[[\uda5a\udd1c\ud97b\udfc5\udbed\udd18\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\ud9ee\udccd\ud828\ude10\uee41]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\uda5a\udd1c\ud97b\udfc5\udbed\udd18\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\ud9ee\udccd\ud828\ude10\uee41", "\u3cc9\u1dc1\u0379\u16ce\uc6ec\u309c\u59ed", "\uda60\ude7a\ud869\udc63\udbe9\udf61\udab7\ude13\ud8fa\udead\ud88a\udca9\uda6a\ude0e\udac8\udc67\uda03\udcd0\u41ba\uda30\udfbb\uda52\udda0\ud8ca\udcdc\ud87f\udf81\uda0e\udde0\ud9b8\udded\udb9b\udfc7\uda98\udd36\uda14\udeca\udad1\udf0c\udbb3\udca9\udab9\ude3f\ud8f0\udd43\udaea\udc09\uda8a\ude69",
        20, 55423, 24878636, 2031675029382664836L, -66102L, true, false, (char) 38363, (char) 17120,
        Double.longBitsToDouble(0x3fd7440fb3146a52L), Double.longBitsToDouble(0x3faf5bfb172fff50L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud929\udfa5]] |a1=[Ljava.lang.String;:[[\ud929\udfa5]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud929\udfa5", "\000\ua8d5\u7e89", "\uda82\udd97",
        24, 68219, -1645380418, -4270173974954382507L, -91435L, false, true, (char) 0, (char) 769,
        Double.longBitsToDouble(0x3fd8f007319f8ddeL), Double.longBitsToDouble(0x3e421bffe8000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud929\udfa5\ud998\udd60\uda64\uddee\ud8ed\udf78\udbba\udc27\uda29\udc00\udb5c\udef6\ud881\udf63\uda82\udd97\ud91a\udcf9\ud890\ude46]] |a1=[Ljava.lang.String;:[[\ud929\udfa5\ud998\udd60\uda64\uddee\ud8ed\udf78\udbba\udc27\uda29\udc00\udb5c\udef6\ud881\udf63\uda82\udd97\ud91a\udcf9\ud890\ude46]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud929\udfa5\ud998\udd60\uda64\uddee\ud8ed\udf78\udbba\udc27\uda29\udc00\udb5c\udef6\ud881\udf63\uda82\udd97\ud91a\udcf9\ud890\ude46", "\ua3e9\u5e21\uc200\ua203\ub586\u309c\u59ed\u94c6\u5946", "\udb20\ude7c\uda4c\ude0a\udb84\udecf\ud892\ude7f\uda6a\ude0e\udac8\udc67\ud835\udf75\ua02f\uda30\udfbb\uda52\udda0\ud91c\udce5\ud87f\udf81\uda0e\udde0\ud9b8\udded\udad2\udeeb",
        52, 83926, 1244089006, -2565197173267168512L, 73700L, false, true, (char) 29656, (char) 46724,
        Double.longBitsToDouble(0x3fd25c159bd8fbf4L), Double.longBitsToDouble(0x3fdadc5b4e4b7104L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udb34\udc64\udb5f\udc40\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46\ud98f\udef6\udbd5\udfe6]] |a1=[Ljava.lang.String;:[[\udb34\udc64\udb5f\udc40\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46\ud98f\udef6\udbd5\udfe6]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\udb34\udc64\udb5f\udc40\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46\ud98f\udef6\udbd5\udfe6", "\u1c03\u16ce\uc6ec\u309c\u59ed\uccf9", "\uda60\udd6f\udbe9\udf61\udab7\ude13\ud8fa\udead\ud88a\udca9\uda6a\ude0e\udac8\udc67\ud873\udd74\u41be\uda30\udfbb\uda52\udda0\ud8ca\udcdc\ud87f\udf81\uda0e\udde0\ud9b8\udded\udad2\udeeb\uda98\udd36\uda14\udeca\udad1\udf0c\udbb3\udca9\udab9\ude3f\ud8f0\udd43\udb3e\udd73\uda70\udccc\ud9b9\udcc1\ud813\udcae\ud955\ude42\ud951\udf56\ud807\udf4c\udaf9\udf90\ud9dd\udfbb\udacf\udf4a\udbbb\udf4a\u9e6a\udb2e\udf2b\udb22\udcbb\udb03\udfd7\udbc4\udcf4\ud821\udc1b\uda92\udd10\udabf\udfd9\ud99d\udda6\ubd0b\uda7e\ude51\ud9f4\udecf\ud8d8\udd26\ud83e\udeb6\udaad\udf85\u9ccd\udb3b\udc7d\udbb4\udf87",
        53, 41112, 1633991178, -7944923737297364699L, -73112L, false, true, (char) 60014, (char) 6892,
        Double.longBitsToDouble(0x3f97818669e15b80L), Double.longBitsToDouble(0x3fda21ca876af8c6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 1, 1, 0, "\ud929\udfa5\udb5e\udfe1\uda89\udeee\ud8ed\udf78\udbba\udc27\ud954\udcb6\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46", "\u0e18\uae2a\u1c03\u16ce\uc6ec\u309c\ua52f", "\udb9f\udc03\uda60\udd6f\udbe9\udf61\udab7\ude13\ud8fa\udead\ud88a\udca9\uda6a\ude0e\udac8\udc67\ud873\udd74\ud850\udfdd\uda46\udc74\ud9fd\udc9f\ud9a3\uddfa\ud87f\udf5b\uda0d\udee0\ud9b8\udded\udad2\udeeb",
        52, 51414, 1244088906, -2565197172884050944L, 41434L, true, true, (char) 2365, (char) 47574,
        Double.longBitsToDouble(0x3fe16185cdad017bL), Double.longBitsToDouble(0x3fda45a31a74039aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 0, "", "", "\000\000\udb5c\udef6",
        23, -1000, 0, 0L, -100000L, false, false, (char) 17580, (char) 54122,
        Double.longBitsToDouble(0x3e48000000000000L), Double.longBitsToDouble(0x3f39dcc67e300000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\000]] |a1=[Ljava.lang.String;:[[\000]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 0, 0, "\000", "\u6016\u4ad9*\u80d0\000\u9c8e\ua8a6#\u1aaa\u7d28\u2c31\u5e4a\u1c03\u16ce\uc6ec\u309c\u59ed\uccf9\u0a68\ud331\ub5dc\u0084\u0b47\u9f63\u00bc\u1d54\ub39c\u984f", "\uda52\udda0",
        8, 28353, 1273914727, -7329370983969378423L, 69667L, false, false, (char) 8837, (char) 60967,
        Double.longBitsToDouble(0x3fdfba5a4710e76aL), Double.longBitsToDouble(0x3fdcf8d07c586172L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\0121=[Ljava.lang.String;:[[\ud929\udfe9\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udb98\udcb8\ud9a4\udefa]] |a1=[Ljava.lang.String;:[[\ud929\udfe9\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udb98\udcb8\ud9a4\udefa]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 1, 0, 1, "\ud929\udfe9\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udb98\udcb8\ud9a4\udefa", "\ua8a6\u8074", "\uda62\uddc8\udbab\udf8d\udab7\udecc\uda75\udc77\uda8d\udc31\udbb8\udc20\uda7e\ude8d",
        25, 73894, 2132837510, 1306871129021181243L, 59229L, false, true, (char) 64850, (char) 54403,
        Double.longBitsToDouble(0x3fb3e7d9e98bba70L), Double.longBitsToDouble(0x3fd95ba5c748be96L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udaf1\udf7e\ud8ba\uddf5\ud92d\uddcb", "\u8135\u8081\u7d28\u2c31\uc633\u6f3c\u16ce\uc6ec\u309c\u59ed\uccf9", "\uda60\udd6f\udbe9\udf61\udab7\ude13\ud8fa\udead\ud88a\udca9\uda6a\ude0e\udac8\udc67\ud873\udd74\u41be\uda31\udc25\uda52\udda0\udb0a\udd1c\ud897\udc95\uda0e\udde0\ud9b8\udded\udad2\udeeb\uda98\udd36\uda14\udeca\udad1\udf0c\udbb3\udca9\udab9\ude3f\ud8f0\udd43\udb3e\udd73\uda70\udccc\udbea\udeb8\ud813\udc1c\ud937\udc7e\ud951\udf56\ud807\udf4c\ud831\udc6a\udae8\ude3c\ud981\udddb\udaf8\udf21\udbd3\ude15\udb7a\udc43\udb4b\ude09\udb2f\udc02\ud90d\udc60\ud8d5\udda9\ud93a\ude1b\ud944\uddf6\u31bb\uda77\udcdd\ud890\udc2a\ud9a2\ude24\udb20\udf5e\udbbb\udcec\ud9aa\udd5a\uda0a\udd99\ud96e\ude79\udac0\udeb1",
        -4, 85776, -436157475, -2909533050180901511L, 80525L, false, true, (char) 14328, (char) 11414,
        Double.longBitsToDouble(0x3fe45fd263d71582L), Double.longBitsToDouble(0x3fe54e5590784bb3L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud80d\udf33]] |a1=[Ljava.lang.String;:[[\ud80d\udf33]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud80d\udf33", "\u6016\ua99c\u7e89\u3347\uca5f\u9cfe\ua8a6\u8074\u8081\u7d28\u2c31\u5e4a\u2ae8\u603c", "\ud842\ude32\udbbd\udd58\udabe\ude6d\udb9f\udc03",
        16, 57216, -637548463, 813341751271535036L, 51636L, true, true, (char) 981, (char) 52940,
        Double.longBitsToDouble(0x3fb47f92ab3bcfc8L), Double.longBitsToDouble(0x3fef625f77899a48L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udad9\udd5c\ud867\udcfc\ud95e\udf2e\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud87f\ude63\uda82\udd97\ud828\ude10\ud890\ude46", "\u17a5\u6fb3\u1c03\u16ce\uc6ecU\u59fd", "\udabe\udfb4\uda5a\ude98\udbe9\udf61\udab7\ude13\ud8fa\udead\ud88a\udca9\uda5e\udc0e\udac8\udc67\ud873\udd74\udbf5\uddbd\uda30\udfbb\uda52\udda0\ud8ca\udcdc\ud87f\udf81\uda0e\udde0\ud8a1\udfe1\ud91f\udeaa",
        10, 94558, 2049990047, -2583935507542512640L, -61401L, true, true, (char) 36669, (char) 5334,
        Double.longBitsToDouble(0x3fe1608045ad017bL), Double.longBitsToDouble(0x3fe420e18d3ac962L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 1, "\uda2a\uded9\udafd\udd1e\udbf9\ude5c\ud8ed\udf78\udbba\udc27\udace\udcb3\ud922\ude5a\ud8cb\uddea\udb96\uddbf\udab4\udc69\ud890\ude9f\ud8e1\udfad\udb2a\udec1\ub516\udb27\uddc8\udab7\udee5\udb9d\udebd\uda3c\udc19\udbdc\udecf\ud81c\udcd8\udbbd\udd58\ud878\udeba\udb9f\udc03\uda60\udd6f\ud976\uddc1\ud862\ude9e\ud8fa\udead\u3e96\uda6a\ude0e\udac8\udc82\ud873\udd74\u41be\udb0d\udeaa\ud829\uded3\udbe1\udd56\ud87f\udf81\uda0e\udde0\ud9b8\udded\udad2\udeeb\uda98\udd36\uda14\udeca\ud97b\udd9e\uc1e6\udbf0\udf97\ud8fd\uddd3\udb3e\udd73\uda70\udccc\ud9b9\udcc1\ud813\udcae", "\u6165\ud6a0\u7f5c\u50c3\u9f51", "\udb70\udd9b\ud81e\udf64\udb67\udd1c\u9ca9\ud872\udc00\udab7\udf28\ud829\udc2f\ud86d\udcea\ud8f7\udfb2\udadc\udeb0\udaf7\udf9b\udad4\udcd0\uda51\uddc9\ud86c\udedc\uda86\udf11\u8893\udad4\udd95\uda59\udd7d\ud861\udcf7\uda7e\udeaf\ud8ff\ude89\ud823\ude83\ud993\udc4a\udabd\udd3c\ud902\udf94\ud9a0\udfec\udaa1\ude33\ud863\udfa6\ud9b7\udd87\uda96\udef6\udb8d\udf15\ud8f3\udce1\ud86a\udd42\ud9cc\udfc6\uda62\udcd3\uda19\udd48\ud9d4\ude94\udbf6\udd27\ud90b\udcf8\uda0e\ude38\ud97a\udfbf\ud9c9\udfc2",
        6, 19100, 760008732, 8901574252023057554L, -87776L, false, false, (char) 5680, (char) 40277,
        Double.longBitsToDouble(0x3fe26c172953a084L), Double.longBitsToDouble(0x3fec00596d985ffbL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 0, "\u3497", "\000", "",
        23, 25320, -1379348992, -90298342718495197L, -100000L, true, true, (char) 37446, (char) 17580,
        Double.longBitsToDouble(0x3fec169741131048L), Double.longBitsToDouble(0x3fe00000058f6773L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\u513a\udb64\udf0e\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3]] |a1=[Ljava.lang.String;:[[\u513a\udb64\udf0e\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3]] |this=org.apache.commons.cli.GnuParser:@?\0121=[Ljava.lang.String;:[[\u513a\udb64\udf0e\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3]] |a1=[Ljava.lang.String;:[[\u513a\udb64\udf0e\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "\u513a\udb64\udf0e\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3", "\u9cfe\u6c1c", "\ud8f3\udc34\udb54\udcb4\udad6\udd20\udab7\udecc\uda75\udc77\uda8d\udc31\udac9\udc18\ud842\ude32\udbbd\udd58\udabe\ude6d",
        35, 9614, 612724027, -2738249798010695165L, -7919L, false, true, (char) 5250, (char) 981,
        Double.longBitsToDouble(0x3fcedbbac147f928L), Double.longBitsToDouble(0x3fd6779f9fd897dcL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\ud929\udfa5\uda16\udf8b\uda64\uddf2\ud81a\udfef\udb7d\ude07\udace\udcb3\udb5c\udef6\ud881\udf63\ud820\udf2b\udb17\udf45\ud8ba\udecf", "\u2c31", "\uda1b\udda5\udba6\ude67\udac9\udc18\udafa\ude2e\udbbd\udd58\udabe\ude6d\udb9f\udc03\uda60\udd6f\udbe9\udf61\udab7\ude13\ud8fa\udead\udaed\udf73\uda6a\ude0e\udac8\udc67\udbe4\ude6e\udb7f\ude77",
        17, 43972, -26101054, 1655477830292437206L, 42199L, false, false, (char) 8551, (char) 9150,
        Double.longBitsToDouble(0x3fe61a513c00dc66L), Double.longBitsToDouble(0x3f9d9e68d8eaec20L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "", "", "\udb6b\ude2a",
        58, 90102, 163669712, -8596876689773913939L, 50228L, false, true, (char) 45074, (char) 37446,
        Double.longBitsToDouble(0x3fd752337705a5d0L), Double.longBitsToDouble(0x3eb2000000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud929\udfa5\uda16\udf8b\uda64\uddf2\ud8ec\udcf3\udb6b\ude2a\ud8df\udc42\udb5c\udef6\ud881\udf63\ud820\udf2b\udb17\udf45\ud966\udfc4]] |a1=[Ljava.lang.String;:[[\ud929\udfa5\uda16\udf8b\uda64\uddf2\ud8ec\udcf3\udb6b\ude2a\ud8df\udc42\udb5c\udef6\ud881\udf63\ud820\udf2b\udb17\udf45\ud966\udfc4]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud929\udfa5\uda16\udf8b\uda64\uddf2\ud8ec\udcf3\udb6b\ude2a\ud8df\udc42\udb5c\udef6\ud881\udf63\ud820\udf2b\udb17\udf45\ud966\udfc4", "\u6061\u5e84\u1c03", "\udac9\udc18",
        29, 60663, -329106, 9160467353436352606L, 37930L, false, false, (char) 28355, (char) 61460,
        Double.longBitsToDouble(0x3fd878627f133490L), Double.longBitsToDouble(0x3fe0b1cb9d16f132L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46]] |a1=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udbba\udc27\udace\udcb3\udb5c\udef6\ud881\udf63\uda82\udd97\ud828\ude10\ud890\ude46", "\u2c31\u5e4a\u1c03\u3dec\uc7c8\u309c\u59ed", "\udb9f\udc03\uda60\udd6f\udbe9\udf61\udab7\ude13\ud8fa\udead\ud88a\udca9\uda6a\ude0e\udac8\udc67\ud873\udd74\u41be\uda30\udfbb\uda52\udda0\ud8ca\udcdc\ud87f\udf81\uda0e\udde0\ud9b8\udded\udad2\udeeb",
        52, 83926, 1244089006, -2565197175115420672L, -61401L, true, true, (char) 36669, (char) 54998,
        Double.longBitsToDouble(0x3fe16185cdad017bL), Double.longBitsToDouble(0x3fe420e18d3ac962L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\ud8e1\uddda\udace\udcd7\udb5c\udef6\ud881\udf63\uda82\udd97\ud927\udd0f\ud9e2\udcab]] |a1=[Ljava.lang.String;:[[\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\ud8e1\uddda\udace\udcd7\udb5c\udef6\ud881\udf63\uda82\udd97\ud927\udd0f\ud9e2\udcab]] |this=org.apache.commons.cli.GnuParser:@?\0121=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud929\udfa5\udb5e\udfe1\uda64\uddee\ud8ed\udf78\ud8e1\uddda\udace\udcd7\udb5c\udef6\ud881\udf63\uda82\udd97\ud927\udd0f\ud9e2\udcab", "\u021f\u5e4a\u1c03\u9bf7\u2967\u309c\u59ed", "\udb9f\udc03\uda60\udd6f\udbe9\udf61\udab7\ude13\ud8fa\udead\ud88a\udca9\uda6a\ude0e\udac8\udc67\ud873\udd74\u41be\uda30\udfbb\uda52\udda0\ud8ca\udcdc\ud87f\udf81\uda0e\udde0\ud9b8\udded\udbba\udfec",
        52, 84056, 1244089006, -2565197175115420672L, -79021L, true, false, (char) 63106, (char) 27587,
        Double.longBitsToDouble(0x3fad4d22923eb900L), Double.longBitsToDouble(0x3fc4528ded1cbf10L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb45\uddab\udb5e\udfe1\uda64\uddee\ud8ed\udf78\udaa3\ude1b\udace\udfa8\ud874\udef1\ud881\udf63\uda82\udd97\uda6d\udfd3\udb27\udfe3", "\u2c31\u5e4a\u1c03\u16ce\uc6ec\u309c\u0fca", "\u333c\uda60\udd5f\ud99b\udf5a\udab7\ude13\ud8e2\udcad\ud88a\udca9\u7a09\udac8\udc67\ud873\udd74\u41be\uda30\udfbb\uda52\udda0\ud8ca\udcdc\ud87f\udf81\ud8a0\udc49\ud915\udde5\udbc0\udeb4",
        19, 81705, -653585336, -2565264456284814848L, -61401L, true, true, (char) 36669, (char) 12502,
        Double.longBitsToDouble(0x3fc5c7fa41c615f8L), Double.longBitsToDouble(0x3fe3416ded3ac962L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda1b\udc43\uda16\udf8b\uda64\uddf2\udac7\udde4\udab5\udc5e\udace\udcb3\udb5c\udef6\ud881\udf63\ud820\udf2b\udaaa\udc0d\ud8ba\udedd\ud90d\udc7b\udbd4\udfc5\uda62\uddc8\ud913\udea0\udab7\udecc\uda75\udc77\uda8d\udc31\udac9\udc18\udafa\ude2e\udbbd\udd58\udabe\ude6d\udb9f\udc03\uda40\udd38\ud946\udef0\uda99\udeef\ud8fa\udead\udaed\udf73\udb98\udf26\udad1\udc3c\ud973\udc20\uda74\udcd0\uda30\udfd1\ud92e\udece\uda00\udeaa\ud87f\udf81\udaff\udeec\ud9b9\udf88\udad2\udeeb\uda98\udd36\uda1c\uddca\udad1\udf0c\udbb3\udca9\ud800\udf42\ud8f0\udd43\udbf9\uddd0\ud888\udf5e\ud8e5\udd60\udb1f\udd2e\u5197\ud934\udf65\ud929\udfb6\udb6c\udc87\ud903\ude19\ud909\udf5b\uda5d\udc10\ud9ba\udde5\ud9f2\udd3f\ud83e\udc17\uda1b\udecf\udbba\udfb2\ud95f\udc58\ud934\udeb8\udb22\udd36\ud811\ude5e\ud8cd\udd3c\u3415\ua089\udb57\udfa7\udaff\ude98\uda15\udd49\ud961\udc01\udb73\ude2c\ud8c1\udfdf\ud842\uddc0\uda24\ude54\ud91e\udd7e\udb8d\udcb8\uda4a\uddea\ube21\ud8f6\udeea\ud915\udcc9\udb61\ude85\ud856\ude39\ud94f\udcfb\ud966\udc22\uda54\udebb\udaba\ude15\ud869\udf01\uda60\udded\ud9ab\ude0e\ud8e2\udc5e]] |a1=[Ljava.lang.String;:[[\uda1b\udc43\uda16\udf8b\uda64\uddf2\udac7\udde4\udab5\udc5e\udace\udcb3\udb5c\udef6\ud881\udf63\ud820\udf2b\udaaa\udc0d\ud8ba\udedd\ud90d\udc7b\udbd4\udfc5\uda62\uddc8\ud913\udea0\udab7\udecc\uda75\udc77\uda8d\udc31\udac9\udc18\udafa\ude2e\udbbd\udd58\udabe\ude6d\udb9f\udc03\uda40\udd38\ud946\udef0\uda99\udeef\ud8fa\udead\udaed\udf73\udb98\udf26\udad1\udc3c\ud973\udc20\uda74\udcd0\uda30\udfd1\ud92e\udece\uda00\udeaa\ud87f\udf81\udaff\udeec\ud9b9\udf88\udad2\udeeb\uda98\udd36\uda1c\uddca\udad1\udf0c\udbb3\udca9\ud800\udf42\ud8f0\udd43\udbf9\uddd0\ud888\udf5e\ud8e5\udd60\udb1f\udd2e\u5197\ud934\udf65\ud929\udfb6\udb6c\udc87\ud903\ude19\ud909\udf5b\uda5d\udc10\ud9ba\udde5\ud9f2\udd3f\ud83e\udc17\uda1b\udecf\udbba\udfb2\ud95f\udc58\ud934\udeb8\udb22\udd36\ud811\ude5e\ud8cd\udd3c\u3415\ua089\udb57\udfa7\udaff\ude98\uda15\udd49\ud961\udc01\udb73\ude2c\ud8c1\udfdf\ud842\uddc0\uda24\ude54\ud91e\udd7e\udb8d\udcb8\uda4a\uddea\ube21\ud8f6\udeea\ud915\udcc9\udb61\ude85\ud856\ude39\ud94f\udcfb\ud966\udc22\uda54\udebb\udaba\ude15\ud869\udf01\uda60\udded\ud9ab\ude0e\ud8e2\udc5e]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\uda1b\udc43\uda16\udf8b\uda64\uddf2\udac7\udde4\udab5\udc5e\udace\udcb3\udb5c\udef6\ud881\udf63\ud820\udf2b\udaaa\udc0d\ud8ba\udedd\ud90d\udc7b\udbd4\udfc5\uda62\uddc8\ud913\udea0\udab7\udecc\uda75\udc77\uda8d\udc31\udac9\udc18\udafa\ude2e\udbbd\udd58\udabe\ude6d\udb9f\udc03\uda40\udd38\ud946\udef0\uda99\udeef\ud8fa\udead\udaed\udf73\udb98\udf26\udad1\udc3c\ud973\udc20\uda74\udcd0\uda30\udfd1\ud92e\udece\uda00\udeaa\ud87f\udf81\udaff\udeec\ud9b9\udf88\udad2\udeeb\uda98\udd36\uda1c\uddca\udad1\udf0c\udbb3\udca9\ud800\udf42\ud8f0\udd43\udbf9\uddd0\ud888\udf5e\ud8e5\udd60\udb1f\udd2e\u5197\ud934\udf65\ud929\udfb6\udb6c\udc87\ud903\ude19\ud909\udf5b\uda5d\udc10\ud9ba\udde5\ud9f2\udd3f\ud83e\udc17\uda1b\udecf\udbba\udfb2\ud95f\udc58\ud934\udeb8\udb22\udd36\ud811\ude5e\ud8cd\udd3c\u3415\ua089\udb57\udfa7\udaff\ude98\uda15\udd49\ud961\udc01\udb73\ude2c\ud8c1\udfdf\ud842\uddc0\uda24\ude54\ud91e\udd7e\udb8d\udcb8\uda4a\uddea\ube21\ud8f6\udeea\ud915\udcc9\udb61\ude85\ud856\ude39\ud94f\udcfb\ud966\udc22\uda54\udebb\udaba\ude15\ud869\udf01\uda60\udded\ud9ab\ude0e\ud8e2\udc5e", "\u685b\u0726\u21d7\u716f\u8496\ubab9\u0e8c\u4083\u86c4\u7a37", "\uda5c\udd68\ud930\udf32\ud909\ude22\udbef\udde0\ud994\udfab\ud9e2\udd0e\uda5b\udea3\udb22\udc44\ud8dc\udf08\udb98\ude3c\udacd\ude13\ud9fa\ude3d\ud87c\ude08\uda4a\udea6\udba0\udccf\ud9b6\udd2f\ud96c\udde8\ud988\udfe1\ud9ff\udde2\udb36\udf87\uda6b\udfab\ud91e\udc96\uda41\udcef\ud83f\ude73\uda2b\udc9f\ud913\udd79\uda31\udc7c\ud880\ude54\ud864\udd1a\ud9a1\udf00",
        2, 63189, -190937529, -2095759968467699571L, -61796L, true, false, (char) 43789, (char) 3666,
        Double.longBitsToDouble(0x3faf4f0a164667f0L), Double.longBitsToDouble(0x3fd57f3e449deb60L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda1b\udc43\uda16\udf8b\uda64\uddf2\udac7\udde4\udab5\udc5e\udace\udcb3\udb5c\udef6\uda97\uddf9\ud99d\udd93\ud992\udd1c\udbad\udf6f\ud90d\udc7b\udbd4\udfc5\uda62\uddc8\ud913\udea0\udab7\udecc\uda75\udc77\uda8d\udc31\udac9\udc18\udafa\ude2e\udbbd\udd58\udabe\ude6d\udb9f\udc03\uda40\udd38\ud946\udef0\uda99\udeef\ud8fa\udead\udaed\udf73\udb98\udf26\udad1\udc3c\ud973\udc20\uda74\udcd0\uda30\udfd1\uda24\udec9\uda00\udeaa\ud880\ude81\udaff\udeec\ud9b9\udf88\udad2\udeeb\uda98\udd36\uda1c\uddca\udad1\udf0c\udbb3\udca9\ud800\udf42\ud8f0\udd43\udbf9\uddd0\ud888\udf5e\ud8e5\udd60\udb1f\udd2e\u5197\ud934\udf65\ud929\udfb6\udb6c\udc87\ud903\ude19\ud909\udf5b\uda5d\udc10\ud9ba\udde5\ud9f2\udd3f\ud83e\udc17\uda1b\udecf\udbba\udfb2\ud95f\udc58\ud934\udeb8\udb22\udd36\ud811\ude5e\ud8cd\udd3c\u3415\ua089\udb57\udfa7\udaff\ude98\uda15\udd49\ud81b\ude4e\udb73\udd61\ud8c1\udfdf\ud842\uddc0\uda24\ude54\ud91e\udd7e\udb8d\udcb8\uda4a\uddea\ube21\ud8f6\udeea\udb59\udc4c\udb61\udf0c\ud856\ude39\ud94f\udcfb\ud966\udc22\uda54\udebb\udaba\ude15\ud869\udf01\uda60\udded\ud9ab\ude0e\ud8e2\udc5e]] |a1=[Ljava.lang.String;:[[\uda1b\udc43\uda16\udf8b\uda64\uddf2\udac7\udde4\udab5\udc5e\udace\udcb3\udb5c\udef6\uda97\uddf9\ud99d\udd93\ud992\udd1c\udbad\udf6f\ud90d\udc7b\udbd4\udfc5\uda62\uddc8\ud913\udea0\udab7\udecc\uda75\udc77\uda8d\udc31\udac9\udc18\udafa\ude2e\udbbd\udd58\udabe\ude6d\udb9f\udc03\uda40\udd38\ud946\udef0\uda99\udeef\ud8fa\udead\udaed\udf73\udb98\udf26\udad1\udc3c\ud973\udc20\uda74\udcd0\uda30\udfd1\uda24\udec9\uda00\udeaa\ud880\ude81\udaff\udeec\ud9b9\udf88\udad2\udeeb\uda98\udd36\uda1c\uddca\udad1\udf0c\udbb3\udca9\ud800\udf42\ud8f0\udd43\udbf9\uddd0\ud888\udf5e\ud8e5\udd60\udb1f\udd2e\u5197\ud934\udf65\ud929\udfb6\udb6c\udc87\ud903\ude19\ud909\udf5b\uda5d\udc10\ud9ba\udde5\ud9f2\udd3f\ud83e\udc17\uda1b\udecf\udbba\udfb2\ud95f\udc58\ud934\udeb8\udb22\udd36\ud811\ude5e\ud8cd\udd3c\u3415\ua089\udb57\udfa7\udaff\ude98\uda15\udd49\ud81b\ude4e\udb73\udd61\ud8c1\udfdf\ud842\uddc0\uda24\ude54\ud91e\udd7e\udb8d\udcb8\uda4a\uddea\ube21\ud8f6\udeea\udb59\udc4c\udb61\udf0c\ud856\ude39\ud94f\udcfb\ud966\udc22\uda54\udebb\udaba\ude15\ud869\udf01\uda60\udded\ud9ab\ude0e\ud8e2\udc5e]] |this=org.apache.commons.cli.GnuParser:@?\012",
        Z.run(T, 1, 0, 1, 0, "\uda1b\udc43\uda16\udf8b\uda64\uddf2\udac7\udde4\udab5\udc5e\udace\udcb3\udb5c\udef6\uda97\uddf9\ud99d\udd93\ud992\udd1c\udbad\udf6f\ud90d\udc7b\udbd4\udfc5\uda62\uddc8\ud913\udea0\udab7\udecc\uda75\udc77\uda8d\udc31\udac9\udc18\udafa\ude2e\udbbd\udd58\udabe\ude6d\udb9f\udc03\uda40\udd38\ud946\udef0\uda99\udeef\ud8fa\udead\udaed\udf73\udb98\udf26\udad1\udc3c\ud973\udc20\uda74\udcd0\uda30\udfd1\uda24\udec9\uda00\udeaa\ud880\ude81\udaff\udeec\ud9b9\udf88\udad2\udeeb\uda98\udd36\uda1c\uddca\udad1\udf0c\udbb3\udca9\ud800\udf42\ud8f0\udd43\udbf9\uddd0\ud888\udf5e\ud8e5\udd60\udb1f\udd2e\u5197\ud934\udf65\ud929\udfb6\udb6c\udc87\ud903\ude19\ud909\udf5b\uda5d\udc10\ud9ba\udde5\ud9f2\udd3f\ud83e\udc17\uda1b\udecf\udbba\udfb2\ud95f\udc58\ud934\udeb8\udb22\udd36\ud811\ude5e\ud8cd\udd3c\u3415\ua089\udb57\udfa7\udaff\ude98\uda15\udd49\ud81b\ude4e\udb73\udd61\ud8c1\udfdf\ud842\uddc0\uda24\ude54\ud91e\udd7e\udb8d\udcb8\uda4a\uddea\ube21\ud8f6\udeea\udb59\udc4c\udb61\udf0c\ud856\ude39\ud94f\udcfb\ud966\udc22\uda54\udebb\udaba\ude15\ud869\udf01\uda60\udded\ud9ab\ude0e\ud8e2\udc5e", "\u685b\u555c\u21d7\u716f\u8496\ubab9\u0e8c\u4083\u86c4\u7a37", "\uda5c\udd68\ud930\udf32\ud909\ude22\udbef\udde0\ud994\udfab\ud9e2\udd0e\uda5b\udea3\udb22\udc44\ud8dc\udf08\udb98\ude3c\udacd\ude13\ud9fa\ude3d\ud87c\ude08\uda4a\udea6\udba0\udccf\ud9b6\udd2f\ud96c\udde8\ud988\udfe1\ud9ff\udde2\udab0\udde4\uda6b\udfab\ud91e\udc96\uda41\udcef\ud83f\ude73\uda2b\udc9f\ud913\udd79\uda31\udc7c\ud880\ude54\ud864\udd1a\ud9a1\udf00\ud9e4\udc4c\ud9e3\udd1c\ud90b\udd9b\ud8aa\udfb3\ud80a\ude7b\uda1b\udc08\ud863\udfdb\uda4c\udd23\ud819\udd03\udacb\udc6f\ud93e\ude48\ud920\udcad",
        8, 20822, -184842040, -5851710431183970633L, 66235L, false, true, (char) 31516, (char) 31322,
        Double.longBitsToDouble(0x3fd15f68cabdcceeL), Double.longBitsToDouble(0x3fda3226bc3c7d7eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.GnuParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.GnuParser:",
    "C|org.apache.commons.cli.GnuParser|<init>|",
    "M|org.apache.commons.cli.GnuParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.GnuParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
