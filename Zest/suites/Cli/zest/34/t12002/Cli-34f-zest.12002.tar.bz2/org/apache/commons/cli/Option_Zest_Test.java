package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Option_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\ud869\udebb\ud87b\udd6d", "\u35a5\u9d2a\u3440\ua9eb\u26cd\u443b", "\udb23\udd35\ud927\udef5\ud9bf\udd00",
        1, 7024, 965343831, -9076845475779394868L, 3750L, true, false, (char) 17075, (char) 24730,
        Double.longBitsToDouble(0x3fdc8176e6f3b772L), Double.longBitsToDouble(0x3fec4e1474f6c01dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 11, 1, "\ud869\udebb", "\u2a60\u35a5\u9d2a\u3440\ua9eb\u26cd\u8947\u0e5f\u0d61\u952a\u9e50\u9aee\u7590", "\uda4a\uddb5\ud96e\udfab\uda3a\udd93\ud923\udeb6\udad8\uddd4\uda54\udfd1",
        55, 37680, -1030866055, -8278192768238092340L, -96592L, false, false, (char) 39550, (char) 54031,
        Double.longBitsToDouble(0x3fe58e1f4dc98ffaL), Double.longBitsToDouble(0x3fa5e7af4209a070L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\ud869\udebb\ud87b\udd6d", "\u35a5\u9d2a\u7f92\u794f\u42ca\u443b\u0e90\u0d61\u30b9\u1963\uce25", "\ud809\uddbb",
        36, 68188, 868360372, 2074353233365767893L, 125L, false, true, (char) 5939, (char) 46615,
        Double.longBitsToDouble(0x3fced803baa075e4L), Double.longBitsToDouble(0x3fd7c8c18452d9eeL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 11, "\udbde\udd99\udbd5\udc99\ud8f6\udc94\ud964\uded6\udbf9\udda1\ud8ba\udd96\uadf5\ud9ad\udf1b\ud8db\udc72\udbda\udf70\udbc8\udeb9\ud8fa\udca3\ud95b\udddc", "\u98a5", "\ud89d\udfe0\ud8e5\udf80\ud9e4\udd5b\udb6a\udf38",
        5, -504, 391739619, -2657435182170552377L, 30199L, false, false, (char) 25586, (char) 45827,
        Double.longBitsToDouble(0x3fc33eead13420bcL), Double.longBitsToDouble(0x3fdce7516e5580acL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\ud869\udebb\ud87b\udd6d", "\u35a5\u9d2a\u3440\ua9eb\u10cd\u443b", "\udb23\udd35\ud927\udef5\ud9bf\udd00\udb35\udffd",
        -1, 85775, -2113367774, -8714814046617045370L, 125L, false, false, (char) 5804, (char) 46615,
        Double.longBitsToDouble(0x3fced803bd23191cL), Double.longBitsToDouble(0x3fe61ba6f9abfefdL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\ud869\udebb\ud87b\udd6d", "\u35a5\u9d2a\u3440\u53f7", "\ud898\uddc9\ud8e1\udecd\udaa5\udd36\ud9b9\udefe\ud9bf\udd00\udb35\udffd\uda3c\udfb6\ud809\uddbb\uda4a\uddb5\ud96e\udfab\uda3a\udd93\ud90b\udef8\uda51\ude39\uda54\udfd1\udbf9\udf50\u735f\ua335\ud8b5\udfc5\ud957\ude8b\ud832\udddb\ud8bb\udd55\ud81b\udff7\uda6c\udfb1\uda26\uddbd\ufdf0\udbee\udfad\uda91\udede\uda17\ude84\ud805\udc2f",
        30, 84827, 1690091870, 4663708852165800987L, 86201L, false, false, (char) 27949, (char) 43188,
        Double.longBitsToDouble(0x3fe24d93c339654eL), Double.longBitsToDouble(0x3fc9900ed037ed84L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\ud861\udd6f\ud87b\udd6d\udb6c\udf90\ud86e\udeda", "\u34bd\ua9eb\u84bf\u443b\u0e90\u0d61\u30b9\u2694\u6439\u7590\ud137\u0e89\u1bd6\u0b0a", "\ud8f8\udcce\udbf7\udf23\u6fee\udaf6\udc8b\ud990\udfb0\ud8b5\udce9",
        24, 52685, 1364006556, 5804508789230810125L, -1633L, false, false, (char) 26453, (char) 55798,
        Double.longBitsToDouble(0x3f60f4eb2ed09900L), Double.longBitsToDouble(0x3fd9bb38960f66dcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 10, "\ud86b\udc2b\ud87b\udd6d", "\u26c0\u9d2a\u8c3f\u9cb7\u63d9\u445e", "\udb23\udcf3",
        31, 16535, -398115839, -159600883503612329L, 79860L, true, true, (char) 46615, (char) 27923,
        Double.longBitsToDouble(0x3fec4c229c7ae4edL), Double.longBitsToDouble(0x3fdb2175357bb68cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 4, 12, "\udb35\udf02\ud87b\udd6d\udb6c\udf90\ud964\uded6\ud8ca\udddd\ud881\udc65\ud940\ude8d\ud9ad\udef8\udbcb\udf3a\udbff\ude05\uda41\udf21\ud819\udda5\ud9ad\udfc2", "\u7590\ud137\u0e89\u1bd6\u7374\ua3ec\u6764\u0384", "\udae5\udfa4\u3fda\ud8b5\udfc5\udaf7\udd7b\ud9d6\udc7d\ud897\udf49\udab8\udd62\udbc9\udfc7\ud8eb\udf90\udb98\udd13\udbdc\udcfd\ud955\udc17\uda0c\udf36\ud943\udc76\ud938\udd4b\udbcb\udd48\udaf4\uddf6\ud94a\udff1\ud923\udd9d\udbb0\udf92\ufd4e\udb81\udcfa\ud93f\ude57\uda27\uddc9\ud915\udc31\udb7b\udd5a",
        9, 17592, -1858223625, -8401043804860793038L, 59292L, true, true, (char) 30029, (char) 64040,
        Double.longBitsToDouble(0x3fdbf57fffbada8eL), Double.longBitsToDouble(0x3fe97eed906e4a2aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 0, 11, 5, "\ud869\udebb\ud87b\udd6d", "\u35a5\u9d2a\u3440\ua9eb\u26cd\u23b0", "\udb23\udd35\ud927\udef5\ud9bf\udd00",
        1, 7024, 965343831, -9077005050994310452L, -99930L, true, false, (char) 32115, (char) 24548,
        Double.longBitsToDouble(0x3fdc8176e6f3b772L), Double.longBitsToDouble(0x3fec4e1474f6c01dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\u3d86\ud870\uddd5\udb6c\udf90\u4ace\udbe8\uded8\ud881\udc65\uadf5\ud9a8\udef8\udbcb\udf90\udb26\udce1\ud8f6\udfbc\ud8e1\udecd\udb23\udd35\udb7f\udd43", "\ua3c3\ud6eb", "\ud840\uded3\ud88d\udf7b\udb9c\udfd2\uda55\udc78\ud9e2\ude44\ud932\udff0\u3fda",
        40, 65694, -696159881, 6508638448549458291L, -59031L, false, true, (char) 44630, (char) 24335,
        Double.longBitsToDouble(0x3feaba274744828dL), Double.longBitsToDouble(0x3fe8c5ffdbda1f38L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\ud869\udebb\ud87b\udd74", "\u35a5", "\ud9ad\udef8\udbcb\udf90",
        37, 43983, 217146890, 7628849182135386291L, 76694L, false, false, (char) 819, (char) 51882,
        Double.longBitsToDouble(0x3fe664104686870eL), Double.longBitsToDouble(0x3fdaa4bced543992L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\u2f0d\ud89a\uddcf\udb6c\udf90\ud964\uded6\udbe8\uded9\ud881\udc65\uadf5\ud9ad\udef8\udbcb\udf90\udaec\ude78\ud8f6\udfbc\ud8e1\udecd\ua63a", "\u7590\ud137\u1e03\u1bd6\u7374\ua3ec\u6764\u0384\u4077\u5ca8\uaec9\ud2a5\u0fd2\u5010\u598d\u8393\u15f6\u4501\u8a71\uace1\u359b\u0e23\u3305\u7b5b\u766c\u58c2\u10f8\u7cf9\uaebc\ucdd1\u7db8\u2a9d\u512e\uaa52\u3735\u4231\u1a59\uc661\ud751\u7940\ua037\u3aab\u284f\u8e3e\uc45b\u3ef3\ub7c3\u09dd\u95d0\uc9e8\u24b0\u66c6\u29a0\u074c\ub318\u537d\u1dff", "\uda10\ude4e\udb98\uddcf\udba0\udd24\udb7c\udd6d\udaf4\ude5f\ud8f5\udc40\udb53\uddec\ud811\udffe\ud878\udda4\udb71\udde6\ud90a\udcb3\udbd2\udcf4\ud894\udf6c\udb0f\udf3a\ud951\udce4\ud992\udff7\udb00\udc75\udbaf\udc42\udb00\udfa3\ud848\udfbf\uda7e\udf39\ud82c\uddbd\udade\ude32\udb1c\ude8f\ud967\ude11\u1bed\ud970\udf52\ud8ca\udf01\ud89c\udf29\ud83f\udde0",
        15, 80945, 522350293, 4779321922878980974L, -64577L, false, true, (char) 15052, (char) 21381,
        Double.longBitsToDouble(0x3fe50c036183d1b0L), Double.longBitsToDouble(0x3fea5c2b1df3f67eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 11, 5, "\ud869\udebb\ud87b\udd6d", "\u35a5\u9d2a\u3440\ua9eb\u26cd\u443b", "\udb23\udd35\ud927\udef5\ud9bf\udd00",
        1, 7024, 965343831, -9076845475779394868L, 3750L, false, true, (char) 11686, (char) 58237,
        Double.longBitsToDouble(0x3fdc8176e2048772L), Double.longBitsToDouble(0x3feeae60b4f6c01dL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 0, 0, 0, "\ud869\udebb\ud87b\udd6d", "", "\ud84c\udc88",
        -5, -1000, 0, 7854277750134145034L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e20000000000000L), Double.longBitsToDouble(0x3e81a1a1c0000000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30ee  :: null :: class java.lang.String ]\012",
        Z.run(T, 1, 1, 0, 0, "\u30ee", "", "",
        -5, -1000, 203, 0L, -100000L, false, false, (char) 64434, (char) 60670,
        Double.longBitsToDouble(0x3e98000000000000L), Double.longBitsToDouble(0x3f4fa00000000000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option:   :: \u4970\u171d\u35a5\u9d2a\u3440\ubace\u26cd :: class java.lang.String ]\012",
        Z.run(T, 1, 1, 11, 0, "", "\u4970\u171d\u35a5\u9d2a\u3440\ubace\u26cd", "\ud8e1\udecd",
        26, 48251, 1633535, 868393493306342360L, -100000L, false, false, (char) 64916, (char) 51475,
        Double.longBitsToDouble(0x3fe6a8e64d407d73L), Double.longBitsToDouble(0x3fcc7cf6c7205c00L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 3, 7, "\uda98\udf15", "\u4b1b\u392a\u462b\u3440\u0f35\u47d6\ub56f\u2231", "\ud927\udf1b\udaf1\udf4f\udbd0\udcc0\uda08\udcbf\ud809\udde7\udbe8\udf4a\uda11\udfd6\ud99f\udc6b\ud8ae\udcec\udb87\udf56\uda54\udffb\ud9e2\ude44\udb97\udddc",
        16, 85420, -1767777034, -2727758131574056307L, 77558L, false, false, (char) 26828, (char) 37794,
        Double.longBitsToDouble(0x3fecdad4ada5b1afL), Double.longBitsToDouble(0x3fe3391dc511d0e5L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\ud869\udebb\ud87b\udd6d\ud938\udee8\ud964\udf52\udbe8\uded9\ud881\udc65\uadf5\ud9ad\udef8\udbcb\udf90\ud939\udd2b\ud8f6\udfae\ud8e1\udecd\udb23\udd35\ud927\udef5\ud9bf\udd00\udb35\udffd\uda3c\udfb6\ud809\uddbb\ud888\ude14\ud96e\udfab\uda3a\udd93\ud90b\udef8\uda51\ude39\uda54\udfd1\ud9e2\ude44\udae5\udfa4\u3fda\ud8b5\udfc5\uda64\ude71\ud944\udcc7\udaf7\udf67\ud914\udfe5\ud94b\udee9\udad3\udf74\ud854\udc71\udb1a\udc4b\uda9a\udf61\ud898\udf99\uca92\u405a\udae3\udf2f\udafd\udcd6\ud960\udd0f", "\u9cc5\u973a\uc4dd\u81f6\ua9a5\ub159", "\ud8ac\udfa7\ud81d\udc26",
        40, 311, 1009234202, -2804356588989605970L, -83875L, false, false, (char) 56023, (char) 63502,
        Double.longBitsToDouble(0x3fe17a62f6057093L), Double.longBitsToDouble(0x3fe9067147995199L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \000\000  :: \u35a5\u9d2a\u3440 :: class java.lang.String ]\012",
        Z.run(T, 1, 1, 11, 5, "\000\000", "\u35a5\u9d2a\u3440", "\udb26\udce1\ud8f6\udfbc\ud8e1\udecd\udb23\udd35\ud927\udef5\ud9bf\udd00\udb35\udffd\uda3c\udfb6\ud809\uddbb\uda4a\uddb5\ud96e\udfab\u7686\ud90b\udef8\uda51\ude39\uda54\udfd1\ud9e2\ude44\udae5\udfa4\u3fda\ud8b5\udfc5\ud9ca\udd64\ud914\udcf8\uda4d\udc86\ud880\udc16\udbad\udd8a\ud8c7\ude3d\uda69\udc90\udb82\udeef\udb00\udefa\ud8b1\udc0b\udb86\udd24\ud992\uded8\udb25\udf39",
        14, 69225, -1536420218, 3802675422813965319L, 54449L, false, false, (char) 40398, (char) 9767,
        Double.longBitsToDouble(0x3fd0fb63ced26fbaL), Double.longBitsToDouble(0x3fd6ac34f387b506L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 5, "\ud869\udebb\udb53\udf39\udaef\ude51\ud8bc\ude3f", "\u3440\ua9eb\u26cd\u23b0\u1e77\u6d01\u30a5\u2694\u89da\ua9bb", "\ud91c\udf4d\ud96e\udfab\uda3a\udd93\uda30\udf43\udb5f\udd7b\udb4d\ude89",
        30, 37680, 587479929, -4546295192106717962L, 52534L, false, true, (char) 16299, (char) 50413,
        Double.longBitsToDouble(0x3fe601e663adbb1bL), Double.longBitsToDouble(0x3fe085613f09c303L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 0, 11, 14, "\ud95d\udfc0\ud87b\udd6d\ud85c\udfc5\ud8f4\udc33\udbe8\uded9\ud881\udc65\uadf5\ud9ad\udef8\udbcb\udf90\ud800\udfaf\ud8f6\udfbc\ud8e1\udecd\udb23\udd35\ud927\udef5\ud9bf\udd00\udb35\udffd\uda3c\udfb6\ud809\uddbb\uda26\udc93\ud96e\udfab\uda3a\udd93\ud98e\uddec\uda51\ude39\udb4d\ude86\ud9e2\ude44\udae5\udfa4\u17ce\ud8b5\udfc5\ud8dc\udd0d\udad0\udd34\ud9aa\ude25\uda97\udc52\udad6\udcff\udaa9\udc16\udaff\udf2a\ud8bf\udf02\uda2a\udec2\ud80b\ude3e\udbe1\ude12\udad2\ude63\udaf0\udd43\ud94a\udeef\ud915\udf34\udaac\udc88", "\u018e\u9ffa", "\ud8d3\udf88\ud8f3\udc82\uda29\ude51\ud881\udc24\ud9a5\udd64\uda2f\udef6\uda4e\udf3b\udac5\udeb1\ud975\udf61\uda62\udc2c\udbf2\udcd9\udaf4\udfea\ud8c9\uddeb\udafe\udebc\udb61\udd66\ud935\udcf9\udb44\ude91\ud8cc\uddd5\u67dc\u0b60\uda8a\udd56\ud9e2\ude67\ud845\udd5a\ud9be\ude53\udb9f\ude68",
        27, 56455, -1147986758, -4180728325602909144L, 7438L, true, true, (char) 44577, (char) 33574,
        Double.longBitsToDouble(0x3fe974c293fa238fL), Double.longBitsToDouble(0x3fd45180e2b3e5d0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\u3d86 |this=org.apache.commons.cli.Option:[ option: \u3d86  :: \uae74\u35a4\u9d2a\u3440\u95eb\u26cd\u443b\u0e90\u0d61\u30b9\u0eac\u3fc5\u6ba8 :: class java.lang.String ]\012",
        Z.run(T, 1, 12, 15, 10, "\u3d86", "\uae74\u35a4\u9d2a\u3440\u95eb\u26cd\u443b\u0e90\u0d61\u30b9\u0eac\u3fc5\u6ba8", "\udb95\ude66\ud95e\ude77\ud840\ude30\ud88d\udf7b\udb9c\udfd2\uda55\udc78\ud9e2\ude44\ud9c5\ude55\u3fda\u4513\udb84\udd61\udbf7\udf04\udabc\udd81\udbbf\uddc3\ud963\udfc3",
        42, 99692, -340624107, 4965345426045503319L, -38367L, false, true, (char) 56408, (char) 22754,
        Double.longBitsToDouble(0x3fb5e68513302968L), Double.longBitsToDouble(0x3fe9918db1b16617L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 0, "\ub4d5\000\000\ud884\udca2\udbe8\uded8\ud96e\udc5c\u9772\uda03\uddeb\ud86a\uddbf\000\000\u6600\ud85c\udcf6\000", "\u63c3", "\ud902\udf87",
        54, 92644, -1129971712, 217595928117248L, 46297L, false, false, (char) 0, (char) 29047,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3dd2ebc000000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.RuntimeException\012",
        Z.run(T, 2, 4, 7, 8, "\u3d86", "\uae74\u35a4\u9d2a\u3440\u95eb\u26cd\u443b\u0e90\u0d61\u30b9\u0eac\u3fc5\u6ba8", "\uda4a\ude67\ud917\udd87\ud840\uded3\ud88d\udf7b\udb9c\udfd2\uda55\udc78\ud802\udf54\ud932\udff0",
        10, 31505, 1258728694, -2989983920166841297L, -38351L, true, true, (char) 29783, (char) 44586,
        Double.longBitsToDouble(0x3feae75d975744e8L), Double.longBitsToDouble(0x3fea24146b18bffbL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 0, "\u00d5\000\000\u38a8\000\ud880\udf9f\uadf5\ud9a8\udef8\udbcb\udf90\udb26\udce1\ud8f6\udf6d\000\000\000", "\000", "'\ud840\ude2b\ud88d\udf7b",
        31, 72032, 393115875, -8366409617180312711L, 75350L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3dd2ebc000000000L), Double.longBitsToDouble(0x3fdc64c1ca2a6282L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud869\udebb\ud87b\udd6d", "\u24c7\u17b4\u2bfe\u7b14\u79d3\u0095\u0130\012\000\u9b2f\u3569\u5aaa\ubfb0\u4d42\u2a43\u309a\u437e\ub7a2\ud762\u7d8d\u698a\ub650\u80c5\u5e66\u2f4f\u08e2\u6925\u804c\u5f57\u9849\u4ffd", "\ud861\udde9\uda41\udd34\udb67\udd5f\ud830\udc4a\ud8b1\udd8a",
        10, 6795, 1350884950, -1697218323606140451L, -98377L, false, false, (char) 30997, (char) 55479,
        Double.longBitsToDouble(0x3fe4fc40df00de1dL), Double.longBitsToDouble(0x3fedd4b3f0f03ea9L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud869\udebb\ud87b\udd6d", "", "\ud84c\udc88",
        -5, -1000, 0, 7854277750134145034L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e20000000000000L), Double.longBitsToDouble(0x3e80699b40000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 4, "\u30ee\000\000\000\000\000\000\ud8fb\udf87\ud85a\udd90\udb76\udf5e\ud8dd\udf03\000", "\u40a1S\ua471\u8000\u7549\ub35f\ubd33\u3f74\ub7dd\u92a1\u2b9f\uc9ff\u91d1\u453e\u6781\u61a4\u7ab8\u5a89\u83dd\uacb9\u3540\u3dba\u86a3\u7a9d\uc137\ucc99\uacab\u8f09\u542c\u2b14\u6004\uc018\u7ec1\u2f38\u2d5c\ua275\uc9c5\uc150\ua6d6\ubb41\u680c\u2a89\uc6e4\u5294\ua569\ud04b\u8cca", "\udb92\ude9a\udaf4\udfcc\uda8d\udd58\udb9d\udd1c\ud89f\udf74\uda70\udd71",
        48, 31325, 667393924, -7326440540130178188L, -66781L, true, false, (char) 2918, (char) 13181,
        Double.longBitsToDouble(0x3fe10904e2687b23L), Double.longBitsToDouble(0x3fe1d93f6ac56907L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30ee\000\000\000\000\000\000  :: \u9dd5\u81c6\000 :: class java.lang.String ]\012",
        Z.run(T, 1, 7, 0, 0, "\u30ee\000\000\000\000\000\000", "\u9dd5\u81c6\000", "\ud9bf\udd00\ud821\udc8f\udae5\udfd2\000\udacf\udf68\udbba\udd09\udb33\udc12\ud889\udc21\ud876\uddda\udb7a\udefe\udb1a\ude7a\ud904\udf83\u3d9e\uda86\ude37",
        28, 30504, -1664948113, -946288954442167239L, -6592L, false, false, (char) 7767, (char) 18339,
        Double.longBitsToDouble(0x3fcc1d8fcba2984cL), Double.longBitsToDouble(0x3fd66df80e507b80L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 3, 0, 0, "\u59d9", "", "\ud91e\udc90\ud9c3\udc0c",
        44, 81130, 1291845632, 7858418437909905408L, -67053L, true, false, (char) 24, (char) 0,
        Double.longBitsToDouble(0x3f4fa00000000000L), Double.longBitsToDouble(0x3fe81e7f141cf7e7L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.Option:[ option: \u30ee\000\000  :: null :: class java.lang.String ]\012",
        Z.run(T, 1, 5, 0, 0, "\u30ee\000\000", "\000", "\000",
        -5, 18048, 0, 8863084066665169075L, -100000L, false, false, (char) 64768, (char) 0,
        Double.longBitsToDouble(0x3fa0ad041de28ae0L), Double.longBitsToDouble(0x3fe94e90e59fbb05L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 0, "\u3000", "", "",
        -5, -1000, 203, 0L, -100000L, false, false, (char) 64434, (char) 60670,
        Double.longBitsToDouble(0x3e98000000000000L), Double.longBitsToDouble(0x3f4fa00000000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:12526 |this=org.apache.commons.cli.Option:[ option: \u30ee  :: \000\000\000 :: class java.lang.String ]\012",
        Z.run(T, 1, 11, 3, 3, "\u30ee", "\000\000\000", "\ud810\udf14",
        44, 50181, -1696956923, 7368734093913129211L, 96608L, false, false, (char) 40902, (char) 2701,
        Double.longBitsToDouble(0x3fec7a1dad3f1ea4L), Double.longBitsToDouble(0x3fe52e99f9f67a77L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.RuntimeException\012",
        Z.run(T, 1, 2, 0, 0, "\u30ee", "", "\ud87b\udeb8\udb7c\udd2b\ud86f\udd89\ud97a\udef0\udaac\ude8b\ud9ca\udc7d\udbc7\uddc3\uda81\udf3f\u80b3\ud9bf\udd00\000\udae5\udfd2\000\udade\udc8f",
        -5, 27167, -181922721, -1015201526781984413L, 22863L, false, true, (char) 49187, (char) 34282,
        Double.longBitsToDouble(0x3fdb4ad2ebfdaa38L), Double.longBitsToDouble(0x3fedb49de1ddf372L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Option:[ option: \u30ee  ::  :: class java.lang.String ]\012",
        Z.run(T, 1, 13, 0, 0, "\u30ee", "", "",
        34, -982, 2097152203, 0L, -100000L, false, false, (char) 64434, (char) 60670,
        Double.longBitsToDouble(0x3e98000000000000L), Double.longBitsToDouble(0x3f4fa00000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30ee  :: null :: class java.lang.String ]\012",
        Z.run(T, 1, 7, 0, 0, "\u30ee", "\u4b46", "\000",
        3, 18704, 0, 7858218399808094208L, -67053L, true, false, (char) 28156, (char) 521,
        Double.longBitsToDouble(0x3f4fa00000000000L), Double.longBitsToDouble(0x3fe0199efe816882L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=org.apache.commons.cli.Option:[ option: \u30ee  ::  :: class java.lang.String ]\012",
        Z.run(T, 1, 15, 15, 0, "\u30ee", "", "",
        -5, -1000, 233, -3242591731706757098L, -100000L, false, false, (char) 42992, (char) 46691,
        Double.longBitsToDouble(0x3fa2a1df80077000L), Double.longBitsToDouble(0x3f4fa00000000000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 0, "\u30ee\000\000\000\000\000\000\u00cb\000\000\ud8dd\ude6d\000\udbc3\udf40\u80b3\ud9bf\udd00\000\ud8b3\udcb9\u31c6\uda82\udec0", "\u2ef1\u5733\ubb36\ud611\u619a\uafce\u0a51\u311a\u4426\u0a38\u2091\u96cf\uc94f\ua965\u8738\u6e54\ua3e8\u742d\u888b\u9b74", "\ud8b2\udccd\udbaf\udfa5\udbac\udc42\udb31\udd2a\uda45\udd3d\ud981\ude4a\udb52\udf68\uda7e\ude42\ud990\udf2b\ud8e8\udc85\udaed\udc15\ud962\ude57\ud909\udefe",
        1, 35755, -1678459580, 4864633711179503114L, 53992L, false, true, (char) 31815, (char) 21555,
        Double.longBitsToDouble(0x3fe0da99a001678eL), Double.longBitsToDouble(0x3fe5a9ec9a41ff66L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30fc  ::  :: class java.lang.String ]\0121=void |this=org.apache.commons.cli.Option:[ option: \u30fc  ::  :: class java.lang.String ]\012",
        Z.run(T, 2, 7, 5, 8, "\u30fc", "", "\uadf9\udb3a\udd3c\u00cb",
        8, 8188, -1497096164, 53603205120L, 20525L, true, false, (char) 54209, (char) 64768,
        Double.longBitsToDouble(0x3fe2c00007a55ce6L), Double.longBitsToDouble(0x3fed150078eb73b2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=org.apache.commons.cli.Option:[ option: \u30ee  ::  :: class java.lang.String ]\0121=java.lang.String:\u30ee |this=org.apache.commons.cli.Option:[ option: \u30ee  ::  :: class java.lang.String ]\012",
        Z.run(T, 2, 15, 12, 0, "\u30ee", "", "\000\000\u00cb\000\000\ud8dd\ude6d\000\uda81\udf3f\u80b3\ud9bf\udd00\000\udae5\udfd2\000\ud9b4\uddf9\ud94f\udd5d\u9d87\u1803\ud97b\udeb8\udb9c\udfc9\ud8b9\uddf1\udb47\udddb\ud83f\uddbc\udaf9\udc2b\udbd9\udf37\udafa\udf42\ud9bc\udffe\udb2b\uddb0\udb0d\udff6",
        19, 39346, -251056577, 1548770936039973734L, -44432L, false, false, (char) 39096, (char) 52199,
        Double.longBitsToDouble(0x3fea4bf0c4ade95bL), Double.longBitsToDouble(0x3feae57b0444baafL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u30ee  :: null :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u30ee  :: null :: class java.lang.String ]\0121=!java.lang.RuntimeException\012",
        Z.run(T, 2, 6, 2, 12, "\u30ee", "\u9112", "",
        -5, -797, 0, 9223372036067590234L, -100000L, true, false, (char) 6691, (char) 16864,
        Double.longBitsToDouble(0x3fc3b428b2890014L), Double.longBitsToDouble(0x3f45dd2760b17000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 3, 7, "\uf818", "\u4b1b\u392a\u462b\u3440\uab02\u1ec1\u7095\u8ed7", "\ud927\udf1b\udaf1\udf4f\udbd0\udcc0\uda08\udcbf\ud9cc\udcc9\udbe8\udf8a\uda11\udfd6\udb17\uddc8\uda09\ude84\udbd5\uddae\ud9ff\udefc\ud9e2\ude38\uda12\udc66\ud90a\udc6e\ud887\udda8\u093b\u3df2\udb6b\udff6\udb11\udde7\u90e8\ud862\ude13\ud9a9\udf74\udbdb\udd66\ud84f\udfd8",
        3, 22715, 599264677, -3394220541214100207L, -45661L, false, true, (char) 43978, (char) 24878,
        Double.longBitsToDouble(0x3feb5ce59d2be4b4L), Double.longBitsToDouble(0x3fd421e5b18b1374L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \000\000  :: \u35a5\u9d2a\u3440 :: class java.lang.String ]\0121=java.lang.Integer:0 |this=org.apache.commons.cli.Option:[ option: \000\000  :: \u35a5\u9d2a\u3440 :: class java.lang.String ]\012",
        Z.run(T, 2, 1, 11, 5, "\000\000", "\u35a5\u9d2a\u3440", "\udb26\udce1\ud8f6\udfbc\ud8e1\udecd\udb23\udd35\ud927\udef5\ud9bf\udd00\udb35\udffd\uda3c\udfb6\ud809\uddbb\uda4a\uddb5\ud96e\udfab\u7686\ud90b\udef8\uda51\ude39\uda54\udfd1\ud9e2\ude44\udae5\udfa4\u3fda\ud8b5\udfc5\udbd2\uddf8\uda8b\udf6e\uda6a\udcdb\ud8ac\ude16\udbad\udd8a\ud8c7\ude3d\uda69\udc90\udb82\udeef\udb00\udfdb\ud8b1\udc0b\udb86\udd24\ud992\uded8\udb25\udf39",
        14, 69225, -1536420218, 3802675422813965319L, -14769L, false, false, (char) 40398, (char) 9767,
        Double.longBitsToDouble(0x3fd0fb63ced26fbaL), Double.longBitsToDouble(0x3fd6ac34f387b506L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:\000\000 |this=org.apache.commons.cli.Option:[ option: \000\000  :: \u35a5\u9d2a\u3440 :: class java.lang.String ]\0121=java.lang.Integer:0 |this=org.apache.commons.cli.Option:[ option: \000\000  :: \u35a5\u9d2a\u3440 :: class java.lang.String ]\012",
        Z.run(T, 2, 12, 11, 5, "\000\000", "\u35a5\u9d2a\u3440", "\udb26\udce1\ud8f6\udfbc\ud8e1\udecd\udb23\udd35\ud927\udef5\ud9bf\udd00\udb35\udffd\uda3c\udfb6\ud809\uddbb\uda4a\uddb5\ud96e\udf1e\u7686\ud90b\udef8\uda51\ude39\uda54\udfd1\ud9e2\ude44\udae5\udfa4\u3fda\ud8b5\udfc5\ud9e3\udf32\ud914\udc4c\uda4d\udc86\ud880\udc16\udbad\udd8a\ud8c7\ude3d\uda69\udc90\udb82\udeef\udb00\udefa\ud8b1\udc0b\ud839\udefd\ud992\uded8\udb25\udf39",
        14, 74369, -1536380736, 3802675422813965319L, 54449L, false, false, (char) 40398, (char) 9767,
        Double.longBitsToDouble(0x3fd0fb63ced26fbaL), Double.longBitsToDouble(0x3fd6ac34f387b506L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u3d86  :: \ud600\u35a4\u9d2a\u3440\u95eb\u26cd\u443b\u5705\u0d61\u30b9\u0eac\u3fc5\u6ba8 :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option: \u3d86  :: \ud600\u35a4\u9d2a\u3440\u95eb\u26cd\u443b\u5705\u0d61\u30b9\u0eac\u3fc5\u6ba8 :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u3d86  :: \ud600\u35a4\u9d2a\u3440\u95eb\u26cd\u443b\u5705\u0d61\u30b9\u0eac\u3fc5\u6ba8 :: class java.lang.String ]\012",
        Z.run(T, 2, 7, 6, 12, "\u3d86", "\ud600\u35a4\u9d2a\u3440\u95eb\u26cd\u443b\u5705\u0d61\u30b9\u0eac\u3fc5\u6ba8", "\ud892\udca4\ud95e\udedd\ud840\ude30\ud88d\udf7b\udb9c\udfd2\uda55\udc78\ud9e2\ude44\ud9c5\ude55\u3fda\uda8c\udc10\udb84\udcad\udbf7\udf04\udabc\udd81\udbbf\uddc3\ud963\udfc3",
        42, 99692, -340624107, 4965345426045503398L, -38367L, false, true, (char) 56408, (char) 40674,
        Double.longBitsToDouble(0x3fb5e6be77577168L), Double.longBitsToDouble(0x3fe9914831b16617L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Option:[ option: \u3d86  :: \uae74\u35a4\u9d2a\u3440\u95eb\u26cd\u443b\u0e90\u4ab6\u30b9\u96f8\u7d83\u6ba8 :: class java.lang.String ]\0121=!java.lang.RuntimeException\012",
        Z.run(T, 2, 13, 4, 8, "\u3d86", "\uae74\u35a4\u9d2a\u3440\u95eb\u26cd\u443b\u0e90\u4ab6\u30b9\u96f8\u7d83\u6ba8", "\uda4a\ude67\ud917\udd87\ud840\uded3\ud88d\udf7b\udb9c\udfd2\uda55\udc78\ud802\udf54\ud932\udff0",
        10, 31505, 1263312374, -2990010883971525585L, -38351L, true, true, (char) 29783, (char) 44586,
        Double.longBitsToDouble(0x3feae75d97acf7e8L), Double.longBitsToDouble(0x3fea24146b18bffbL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Option:[ option: \u30ee  :: \u8b00\000\000 :: class java.lang.String ]\0121=null |this=org.apache.commons.cli.Option:[ option: \u30ee  :: \u8b00\000\000 :: class java.lang.String ]\012",
        Z.run(T, 2, 13, 8, 3, "\u30ee", "\u8b00\000\000", "\ud82e\udc03",
        44, 50192, -1393918459, 7368734094150303995L, 133L, false, false, (char) 40902, (char) 2701,
        Double.longBitsToDouble(0x3fec7e22953f1ea4L), Double.longBitsToDouble(0x3fee5f89fae95ec3L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=org.apache.commons.cli.Option:[ option: \u30ee  ::  :: class java.lang.String ]\0121=java.lang.Class:java.lang.String |this=org.apache.commons.cli.Option:[ option: \u30ee  ::  :: class java.lang.String ]\012",
        Z.run(T, 2, 15, 15, 10, "\u30ee", "", "",
        -5, 80480, 198, -3242591733161590762L, -100000L, false, false, (char) 42992, (char) 46691,
        Double.longBitsToDouble(0x3fba0aefc003b800L), Double.longBitsToDouble(0x3f4fa00000000000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30fc  :: \u2b42 :: class java.lang.String ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30fc  :: \u2b42 :: class java.lang.String ]\012",
        Z.run(T, 2, 7, 7, 8, "\u30fc", "\u2b42", "\udb3a\udd3c\u00cb\ud83c\udcc3\ud9d9\uddc6\ud948\udedc\udb3d\udf69\uda64\udf7a\ud9f8\udd90\udac0\udcbf\ud8f3\udc69\ud810\ude14\000\uda1d\udfd1\uda34\uddfd\ud9d4\ude73\ud862\uded8",
        59, 34152, 1549862176, -5796617987933928570L, -3483L, false, false, (char) 59329, (char) 8243,
        Double.longBitsToDouble(0x3fdbf843cafb676eL), Double.longBitsToDouble(0x3fd32479cad443aeL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u30fc  ::  :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u30fc  ::  :: class java.lang.String ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30fc  ::  :: class java.lang.String ]\012",
        Z.run(T, 2, 6, 1, 1, "\u30fc", "", "\ud8d2\udfac\udad3\udce9\ud955\udece",
        3, 8188, -1497096164, 53392246784L, 20525L, true, false, (char) 39044, (char) 64815,
        Double.longBitsToDouble(0x3fe2c00007a55ce6L), Double.longBitsToDouble(0x3fed150078eb73b2L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u30ee  :: \u9112\000 :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u30ee  :: \u9112\000 :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option: \u30ee  :: \u9112\000 :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u30ee  :: \u9112\000 :: class java.lang.String ]\012",
        Z.run(T, 2, 6, 6, 12, "\u30ee", "\u9112\000", "",
        3, -1000, Integer.MIN_VALUE, -3333367025148874093L, -67053L, true, true, (char) 16864, (char) 38370,
        Double.longBitsToDouble(0x3fc44800a002bba4L), Double.longBitsToDouble(0x3fdd82c5cb2e2430L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30ee  :: \u9162\u9576\u7426\000\u00cb\ub892\u97b3\uc875\u73cb\u7752\uaef4\u83d0\u6e8d\u5e4e :: class java.lang.String ]\0121=!java.lang.RuntimeException\012",
        Z.run(T, 2, 1, 2, 12, "\u30ee", "\u9162\u9576\u7426\000\u00cb\ub892\u97b3\uc875\u73cb\u7752\uaef4\u83d0\u6e8d\u5e4e", "\ud92b\udc6b\udaf1\udcf4\udaea\udc85\ud89b\udd40\ud902\udd3a\udba5\ude7e",
        -2, 88659, -530910981, -3611197247523138547L, 80520L, true, true, (char) 57980, (char) 55870,
        Double.longBitsToDouble(0x3fd76c73741d2ac8L), Double.longBitsToDouble(0x3fe53d361f2fd6e7L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30fc  :: null :: class java.lang.String ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u30fc  :: null :: class java.lang.String ]\012",
        Z.run(T, 2, 7, 7, 2, "\u30fc", "\u2b42\u587f", "\u00cb",
        8, 8188, -1494212580, 9007199307681377935L, 20507L, false, true, (char) 44022, (char) 8349,
        Double.longBitsToDouble(0x3fe2c00007a55ce6L), Double.longBitsToDouble(0x3fed15007feb73b2L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 5, "\ud869\udebb\ud87b\udd6d", "\u35a5\u9d2a\u3440\ua9eb", "\ud8f6\udfbc\ud8e1\udecd\udb23\udd35\ud927\udef5\ud9bf\udd00\udb35\udffd\uda3c\udfb6\ud809\uddbb\uda4a\uddb5\ud96e\udfab\uda3a\udd93\ud90b\udef8\uda51\ude39\uda54\udfd1\ud9e2\ude44\udae5\udfa4\u3fda\ud8b5\udfc5\udbbc\ude5d\u0f0f\udac1\udd17\ud92b\udc13\ud867\ude6b\udb57\udce4\ud8b0\udc73\uda3a\udc1c\uda5b\udd8c\ud81e\udf23\ud83b\udf1f",
        7, 75099, -1058123996, -4794492554110367710L, 45571L, true, true, (char) 63080, (char) 22159,
        Double.longBitsToDouble(0x3fe4eb230aeefd35L), Double.longBitsToDouble(0x3fe15043d10c963bL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 0, 3, 0, "@", "\u4b1b\u392a\u462b\u3440\u0f35\u47d6\ub56f\u2231", "\ud927\udf1b\u3bff\000\udb06\udde2\ud850\ude8b\udbe8\udf28\uda11\udfd6\ud99f\udc6b\u8c47\000\udb07\udd0a\000\udbb4\udd03",
        -5, -1000, -1767833600, 0L, 77558L, false, false, (char) 26828, (char) 37794,
        Double.longBitsToDouble(0x3fecdad4ada50000L), Double.longBitsToDouble(0x3fe3391dc511d0e5L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 0, 3, 0, "?", "\u4b1b\u392a\u462b\u3440\u0f35\u47d6\ub56f\u2231", "\ud927\udf1b\u3bff\000\udb06\ude10\ud850\ude8b\udbe8\udf28\uda90\uddf5\ud99f\udc27\u9547\000\udb07\udd0a\000\udbb4\udd03",
        -5, -1000, -1767833600, 8192000L, 77558L, false, false, (char) 26828, (char) 37794,
        Double.longBitsToDouble(0x3fecdad4ada50000L), Double.longBitsToDouble(0x3fe3391dc511d0e5L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Integer:20718 |this=org.apache.commons.cli.Option:[ option: \u50ee  :: \u73a2 :: class java.lang.String ]\0121=java.lang.Integer:20718 |this=org.apache.commons.cli.Option:[ option: \u50ee  :: \u73a2 :: class java.lang.String ]\012",
        Z.run(T, 2, 11, 11, 10, "\u50ee", "\u73a2", "\udb9c\udc28\u00c6\ud833\udd59\udb06\udef9\ud91d\ude57\000\ud950\udfa7\udb5d\udc91\udbed\udc0c\ud90c\udf6b\udae5\udfd2\000\uda0c\udd25\ud894\uddc3\udbef\udca8\ud9dc\udc27\ud965\udf7e\udb25\udcf0\ud911\udfed",
        11, 24322, -757336666, -5392811526407323103L, -59151L, false, false, (char) 25187, (char) 35456,
        Double.longBitsToDouble(0x3fde2c65c8e33404L), Double.longBitsToDouble(0x3fe58e4d24f34960L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 0, 0, "\udbd3\uddd3\uf34d\000\udb55\udc89\u00cd\000\000\u00cb\ud88d\udc0d\000\ud8dd\ude6d\000\uda81\udf3f\u80b3\uda2e\udf77/\udae6\udddb\000\uda1e\udf0e\udab5\udc2b\uda8c\udd6a\ud996\udecb\ud8fc\udc46\u51c2\ud934\udd00\udb25\ude84\udb88\udfbf\u1f9b\udab5\udebf\ud8d2\udd95\udbcd\udfc5\uda4c\udc34\ud883\udded\udb08\udfc0\ud8ce\udfbb\ud90f\uddb3\ud9dc\ude01\udb69\udfb7\udacc\udc5b\u8900\ud96f\udc3f\udb0b\udf9d\ud81a\udffc\udb98\uded8\udb36\ude75\uda93\udd24\uda73\udfb1\uda17\udc7a\uda25\ude47\u4cbc\udbe7\udcec\ud82d\udd47\ud975\udd00\udb4c\udfb3\ud968\udc4e\ud928\udd1e\ud9a8\ude2b\udb56\udf70\udb08\uddec\uda6b\udf08\ud8db\ude07\udafd\uddfb\udb1d\udfec\udb3d\udc12\ud840\udfbc\uda75\udc40\ud8e8\ude9f\udbe4\udf9c\ud857\ude78\ud944\udd76\uda09\udc8a\ud864\udd18\ud831\udcde\uda8b\udec3\ud8ef\udd6b\udaf5\udc85\ud9cc\udf08\uda0b\udc6f\ud970\udc38\u3173\udb8c\udeb7\uda82\uddac\udb78\udd67\ub7b3\ud812\udf95\ud8fa\udd91\uda86\udeff\udb7c\udd7f\ud997\udc3d\u3cfd\udbcb\uddf1", "\u8209", "\udb2e\udfac\udb79\udeea\ud8e2\ude01\ud9ea\udc15\ud93b\udcdb\udacb\udc29\udbc6\uddfe\udbe0\ude44\ud903\ude1f\ud867\udd93\udb6d\ude77\udaa0\udc9f\ud916\udd2b\udbfe\udfb4\ud89c\udcb4\udbdd\udf2f\ud869\uddaf\udb53\udd36\uda1f\ude7e\udbc1\udf24\udbf3\udc3d\udaa7\udd3e\udb8a\udeee\udb2d\udf8d\udbe1\udd38\ud87c\ude97\ud8cc\udc39\udb3d\udc39\ud867\udcba\u7d05\udbea\udcf3\uda70\udc64\ud862\udd3f\ud8d8\udc0b\ud8cf\udfcf\udba3\ude73\ud9b4\udde2",
        -5, 23423, -263613287, -1627745654148973673L, -53874L, false, false, (char) 56560, (char) 61487,
        Double.longBitsToDouble(0x3fd87dcf2733c500L), Double.longBitsToDouble(0x3fc24e4c7912c208L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
    "M|org.apache.commons.cli.Option|acceptsArg||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|add|java.lang.String|new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|addValue|java.lang.String|new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|addValueForProcessing|java.lang.String|new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|clearValues||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|clone||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|equals|java.lang.Object|new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getArgName||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getArgs||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getDescription||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getId||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getKey||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getLongOpt||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getOpt||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getType||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
