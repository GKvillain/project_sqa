package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Option_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4\uda13\udda4", "\u8533\u5080\u3ca8\ua53b\u06c7\u3a2a\u9586\u2db2\u37b5\u4835\u4231\u6884\u4e83\u6d88\u533e\u2b60\ud3d2\u451d\u94f7\u8e96\u77a9\u500b\u488a\u08a6\u5f23\ucb31\u6897", "\u1ded\ud98c\udfcc\ud89b\udc88\ud8a3\udefe\udabb\udfe5\ud9c1\udfe1\udb09\udf31\uda93\ude88\udb16\ude2c\udb5e\udf54\ud95d\udf0c",
        49, 58532, 1298344980, -5507450377751002703L, 4924L, true, false, (char) 6576, (char) 46638,
        Double.longBitsToDouble(0x3fe4220d7a940e30L), Double.longBitsToDouble(0x3fc125ea6ac21494L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4\uda13\udda4", "\u8533\u5080\u3ca8\ua9b9\u06c7\u3a2a\u9586\u2db2\u37b5\u4835\u4231\u6884\ub483\u6d88\u533e\u2b60\ud3d2\u451d\u7b46\u9efa\u77a9\uccab\u8104\uc6d6\u5f23\u7467\u1e66\u3158\u4989\u4795\u5b94\u8355\ud0fc\u8808\u63c7\ua398", "\udb5e\udf54\ud917\udf09\ud929\udd93\uda94\uddbb\ud9ec\udca3\udba3\ude8e\ud903\udc82\ud8a8\udd6d\ud89b\udf44\udafa\ude7c\ud86a\udc49\udbcb\udcbb\uf75a\uda2f\udf65\uda0a\udf36\udac1\udc31",
        31, 20937, -1680565472, 1508654299574330910L, -18625L, true, false, (char) 34731, (char) 54391,
        Double.longBitsToDouble(0x3fde47370c6dfc98L), Double.longBitsToDouble(0x3fee6bee88c78ff6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud8d6\udec5\udbe5\udcfe\uda67\udde4\uda13\udda4", "\u8533\u5080", "\ud91e\udd56\ud67a\ud8ab\udcaa\uda59\udc19",
        -5, 64110, 1105861650, -4139814540060773015L, -33867L, false, false, (char) 30156, (char) 61955,
        Double.longBitsToDouble(0x3fe2289023e2e086L), Double.longBitsToDouble(0x3fe589f8473efd71L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 3, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4\uda13\udda4", "\000\000\u3ca8", "\ud67a",
        58, 36023, 654311424, 1105861632L, 17399L, true, false, (char) 204, (char) 0,
        Double.longBitsToDouble(0x3fe0000007c3d240L), Double.longBitsToDouble(0x3fb144811f170000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4", "\u4161\u8533\u5080\u3ca8", "\ud67a",
        58, 52983, 666263716, -6228101537455042030L, -15864L, true, false, (char) 26657, (char) 64295,
        Double.longBitsToDouble(0x3fe05c1e0fc3d240L), Double.longBitsToDouble(0x3fe228902557e086L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4\ud876\udd8e", "\ube7a\u5050\u3ca8\u85d2\u6b68\u3a2a\u9586\u2db2\u37b5\u4835\u4231\u6884\u838c\u7c8f\u5324\u7d8d\ud431\u451d\ub9f6\u8e96\u77a9\u500b", "\ue1f8\ud852\udddb",
        40, 73250, -896534505, -1586204133674079749L, -57598L, true, false, (char) 15532, (char) 62380,
        Double.longBitsToDouble(0x3fe9d13b65d77bfeL), Double.longBitsToDouble(0x3fea79667b2e4443L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\uda83\udcc5\udbfa\udf6c\uda67\udde4\uda13\udda4\ud882\udc1a\ud8bd\uddf3\ud9ae\udc35\ud9ed\udf38\udbed\udf69\ud9fb\udfd6", "\u1fca\u65b7", "\ud98d\udff4\ud8d6\udd39\udb47\udf06\ud9f2\ude87\ud907\udd89\uda1d\udeb6\udb57\udf58\udb28\udcd2\ud886\udc6a\udbb7\udf98\ud9a2\ude8a\ud89d\udc0e\ud892\udf88\uda29\udd14\ue1f8\ud852\udddb\ud9e0\udec0\ud93f\udc6f\udb31\udcf0\u1ded\udb3d\udfd5\ud8c4\ude7b\ud8a3\udefe\udabb\udfe5\ud9c1\udfe1",
        -5, 99762, -1043354153, 4918853623845927595L, 51020L, false, false, (char) 59506, (char) 13634,
        Double.longBitsToDouble(0x3fd6fa80fc496f7aL), Double.longBitsToDouble(0x3fbf44c6bc24d158L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\uda28\udc6d\ud902\udfd1\ud814\udd4f\ud9fc\udd84", "\u8533\u5080\u3ca8\ua53b\u06c7\u3a2a\u9586\u2db2\u37b5\u4835\u4231\u6884\u4e83\u6d88\u533e\u2b60\ud3d2\u451d\u94f7\u8e96\u77a9\u500b\u0af3\u08a6\ua738\ucb31\u9115", "\u1ded\ud98c\udfcc",
        8, 95076, -832154926, 7415029250705362143L, 78902L, true, true, (char) 39807, (char) 60614,
        Double.longBitsToDouble(0x3fd104d63a083d38L), Double.longBitsToDouble(0x3fd6fa89dc496f7aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 3, "\ud8d6\udec5\udbfa\udf6c\uda81\udff1\uda13\udda4", "\u8533\u5080\u3ca8\ua53b\u2c8b\u3a2a", "\uda73\udd70\u5211\ud98e\udc86\ud8d6\udd39\udb75\udddc\udb38\udee0\ud836\udd2f\uda1d\udf4f\udb57\udf58\udb28\udcd2",
        5, 27082, -42878287, 1561877425206823187L, 82427L, true, true, (char) 4421, (char) 2473,
        Double.longBitsToDouble(0x3f977aa677f951e0L), Double.longBitsToDouble(0x3fdfb24fc5cd2e32L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4\uda13\udda4", "\u8533", "\ud9fb\udfd6\udb86\udd4a",
        55, 21973, -1287090017, 2861580869281339046L, -72196L, true, true, (char) 58510, (char) 26657,
        Double.longBitsToDouble(0x3fe517642a0b83c1L), Double.longBitsToDouble(0x3fee180202451204L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 15, "\ud8d6\udec5\udb79\udd1a\ud970\ude01\uda2d\udd2c", "\u8533\u5080\u3ca8\ua53b\u06c7\u3a2a\u9586\u2db2\u37b5\u6290\u42c9\u6884\u4e83\u6d88\u533e\u3585\ud3d2\u451d\u94f7\u8e96", "\ud892\udf88\u2405\ue1f8\ud852\udddb\udb0e\udc37",
        -5, 8303, 522130056, -8669091057843547418L, 52274L, true, true, (char) 62405, (char) 63141,
        Double.longBitsToDouble(0x3fdd77bfee9f839eL), Double.longBitsToDouble(0x3fe6b2221901477aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\u1e96\udbfa\udf6c\udba8\udca5\uda83\udebd", "\u49a4\ud6cf\u86dc\u5799\u6dce\u3a44\u2b86\ud3da\u37b5\u4835\u4231\u4444\u161b\u6d88\u121a\u2b60\ud3d2\u8abe\u0d14\u8e96\u77a9\u500b\u488a\u08a6\u5f23\ucb31\u6897", "\ud887\udf8c\u7f2a\ud8c2\ude1d\udbef\udf1b\udb57\udc3b\uda62\udd3e\udac3\udf01\ud910\udc31\uda32\ude36\ud997\ude81\ud88d\udf2b",
        53, 29062, -1537004524, -5484447272167702095L, -1726L, false, true, (char) 877, (char) 39603,
        Double.longBitsToDouble(0x3feea498fab08525L), Double.longBitsToDouble(0x3fb6528d8a41b508L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 6, 3, "\udbb9\udd3e\ud99d\udfa2\uda67\udde4\uda13\udda4\ud882\udc1a\ud8bd\uddf3\ud9ae\udc35\ud9ed\udf38\udbed\udf69\uda0b\udeff\ud91e\udd6a\ud67a", "\u37b5\u4835\u4a7d\u86e7\u4e83\u6d88\u533e\u2b60\ud3d2\u451d", "\ud9a2\ude8a\ud8a0\udd0e",
        55, 13274, 672853915, -2473474683811974248L, -57598L, false, false, (char) 18488, (char) 62405,
        Double.longBitsToDouble(0x3fe9d13b65d77bfeL), Double.longBitsToDouble(0x3fea7e0e7ad64443L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud8d6\ude03", "\000\u80d9\u4161\u8533\u5080\u3ca8\ua53b\u06c7\u3a2a", "\ud848\udefb\u918e",
        5, 67316, 128857449, 7335480751678620245L, -28832L, false, true, (char) 63928, (char) 59310,
        Double.longBitsToDouble(0x3fe6728d604a8497L), Double.longBitsToDouble(0x3fecda8a6be1281aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 3, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4\uda13\udda4", "\u8533\u5080\u3ca8\ua53b\u06c7\ub95a\u9586\u009f\u3711\u4835\u4231\u6884\u4e83\u6d88U\000\000\000\uaa12\u8e96\u77a9\u500b\u488a\u08a6\u5f23\ucb31\u6897", "\u1ded\ud98c\udfcc\ud89b\udc88\ud8a3\udefe\udabb\udfe5\ud9c1\udfe1\ud971\udce5\000\uda13\udc49\udb5e\udf54\ud95d\udf0c",
        49, 58532, 1298344980, -5507450377751002703L, 4924L, true, false, (char) 6576, (char) 46638,
        Double.longBitsToDouble(0x3fe4220d7a940e30L), Double.longBitsToDouble(0x3fc125ea6ac21494L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud951\udcf9\ud93e\ude1e\uda67\udde4\uda13\udda4\ud882\udc1a\ud9fb\ude41\ud9ae\udc35\ud9ed\udf38\udbed\udf69\ud9fb\udfd6\ud91e\udd56\ud983\udc00\uf54a\ud888\udc0c\ud8e4\ude43\u9145\ud98d\udff4\ud8d6\udd39", "\u9c06\u03ef\uc1bd\u45fa\u5e73\ua5bf\u77a9\ucedb\u621f\u7054\ucc62\ua9b6\uae38\u07eb\u9569\u3312\u9dbc\u83c0\ud0fc\u8808\u2bcc\ua398\uaa2f\u6b8a\u6ddd\u4444\u5c2b\uc243\u47cc", "\udb58\udf2c\ud89b\udf44\udafa\ude7c\ud86a\udc49\udbcb\udcbb\uf75a\ud8c3\udd79\uda27\udd1b\ud8d2\udd2f\ud977\udfc7\ud9fc\udd7b\ud8b7\udeac\udbfd\udf75\udb10\udefc\ud810\udf7a\ud891\udc62\udba9\udd12\uda6e\udde4\udb12\ude9f\udb17\udfb8\u06b2\ud8db\udf30",
        44, 1568, -1873754278, 8412032653045919053L, 10042L, false, false, (char) 7835, (char) 5373,
        Double.longBitsToDouble(0x3fec4766d55d10cbL), Double.longBitsToDouble(0x3fc2a305e3e3f934L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 4, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4\uda13\udda4\ud882\udc1a\ud8bd\uddf3\ud9ae\udc35\udb82\udf63\udbee\udc14\ud9fb\udfd6\ud91e\udd56\ud67a\ud8ab\udcaa\uda59\udc19\ud848\udefb\u918e\ud98d\udff4\ud8d6\udd39\udb75\udddc\udb38\udee0\ud836\udd2f\uda1d\udf4f\udb57\udf58\udb28\udcd2\ud84f\ude6a\udbb7\udf98\ud9a2\ude8a\ud89d\udc0e\ud8ad\ude88\uda29\udd14\udaa6\udd30\ud9f9\udddc\udb0e\udc37\ud966\ude6c\udb31\udcf0\u1ded\ud98c\udfcc\ud89b\udc88\ud8a3\udefe\udabb\udfe5\ud9c1\udfe1\udb09\udf31\uda93\ude88\udb16\ude2c\udb5e\udf54\udb91\ude77\udab1\uddd2\uda0a\ude4e\udbc9\ude55\udba3\udf2f\ud8e7\udf82\udb72\udd2c\ud89b\udf44\udafa\ude7c\ud86a\udc49\udbcb\udcbb\uf75a\u2d5e\uda43\udd4b", "\uc356", "\ud962\udef0\udb65\udd62\udb5d\uddd8\udb4b\udffb\udab7\udf0e\ud870\udea3\u6539\udb70\udd09\ud9f9\udf98",
        35, 17488, -1560448892, 870785001318434044L, 17345L, true, true, (char) 31251, (char) 20454,
        Double.longBitsToDouble(0x3fe2664a9626a1bbL), Double.longBitsToDouble(0x3fcaad1310d15e24L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\012",
        Z.run(T, 2, 9, 6, 8, "\u1a0f", "\u2fab\u80d9\u4161\u8533\u5080\u3ca8\ua53b\u06c7\u3359", "\ud863\udc78\u918e",
        5, 67316, 128857449, 7335480751678620245L, 91045L, false, true, (char) 63928, (char) 58543,
        Double.longBitsToDouble(0x3fe6728d604a8497L), Double.longBitsToDouble(0x3fe5fa8a6d5b1eefL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 3, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4\uda13\udda4", "\000\ub0d1\ua94e\u7248\uc2b5", "\u909f\ud95a\ude4c\000\ud98d\udfe2\ud937\udf69\uda97\uddae\ud811\udced\000\udb6a\ude84\udb57\udf4d\udb28\udcd2\ud8bb\ude62\uda1e\ude4c\ud8c4\udc42\uda85\udeb3\ud874\udc58\ud8cd\ude35",
        8, 28111, -1598345098, -6781796646514196910L, -91509L, true, true, (char) 25985, (char) 54020,
        Double.longBitsToDouble(0x3fe31de9bb547d79L), Double.longBitsToDouble(0x3fedfe5356425861L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 0, 6, 3, "\ud8d6\udec5\udbfa\udf6c\uda67\udde4\uda13\udda4", "\000\000\ub7c7\ub4f5\u06c7\u7edf\u82cb\u909f\u1639\000\u421f\u4992\u6627\ua116\ub4f5\uc14c", "\ud8bb\ude62\u48e7\udb5a\udc33",
        9, 40576, -896678423, 1842395786998494322L, 64950L, true, false, (char) 28243, (char) 25009,
        Double.longBitsToDouble(0x3fe427479b284e6cL), Double.longBitsToDouble(0x3feafd247913d165L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 3, "\000\u53fb\000\uda13\udda4", "\000\000\u3ca8", "\ud67a",
        58, 36023, 654311424, 1105861632L, 44640L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4f0c0000000000L), Double.longBitsToDouble(0x3fb144811f170000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\u00c2", "\u00f9\u97e8\000\000\000\u3ca8\uc1b2\u06c7\u398e", "\000\000",
        -5, -1000, 0, 57663754174726144L, -38048L, false, false, (char) 4681, (char) 0,
        Double.longBitsToDouble(0x3fe70cf6a42d0100L), Double.longBitsToDouble(0x3fda231971aad856L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 3, "\ufdff", "", "\000\000\000\ud8a3\udd03",
        34, 44025, 0, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fcc200000000330L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 3, "\ud8d6\udec5", "\u18ac", "",
        -5, -1000, -1590268672, 7494202750192844873L, 95957L, false, false, (char) 0, (char) 9984,
        Double.longBitsToDouble(0x3e13883d40000000L), Double.longBitsToDouble(0x3ec1800000000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void\0121=org.apache.commons.cli.Option:[ option: \u00c2  :: \u18ac\u988d\000\000\000\000\ub443\u0549\u656c :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u00c2  :: \u18ac\u988d\000\000\000\000\ub443\u0549\u656c :: class java.lang.String ]\012",
        Z.run(T, 2, 0, 6, 0, "\u00c2", "\u18ac\u988d\000\000\000\000\ub443\u0549\u656c", "\000\000\u1c00\ud8d6\udd39\ud8e3\udd73\u600c\000",
        -5, 89064, 302252227, 296913347328L, -7113L, false, true, (char) 24111, (char) 28104,
        Double.longBitsToDouble(0x3fd0e9140c98ad9cL), Double.longBitsToDouble(0x3fd69787559826b8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 0, "\uda83\udcc5", "\u18ac\u80d9\u4161\u4b1f\u5080\u3ca8\ua53b\u06c7\u3a2a", "\ud848\udefb",
        40, 61589, -963875684, -7805242381006378693L, -81494L, false, true, (char) 55956, (char) 4421,
        Double.longBitsToDouble(0x3fd357977086a144L), Double.longBitsToDouble(0x3fda4487e1db466cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.Option:[ option:   :: \u1866\u948b\u80d9\u4161\u8533\u5080\u3ca8\ua53b :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option:   :: \u1866\u948b\u80d9\u4161\u8533\u5080\u3ca8\ua53b :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option:   :: \u1866\u948b\u80d9\u4161\u8533\u5080\u3ca8\ua53b :: class java.lang.String ]\012",
        Z.run(T, 2, 9, 6, 3, "", "\u1866\u948b\u80d9\u4161\u8533\u5080\u3ca8\ua53b", "\ud8ab\udcaa",
        3, 66716, -1450092890, 4749639619686722716L, -43455L, true, false, (char) 64295, (char) 30156,
        Double.longBitsToDouble(0x3fee1e9202451204L), Double.longBitsToDouble(0x3fef170432b13f08L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud81c\udffd\ud94d\ude81\udba7\udfc3\ud9fc\udd5f\ud882\udc1a\ud8bd\uddf3\ud9ae\udc35\ud9ed\udf38\udbfe\ude50\ud9fb\udfd6\ud8b7\udc9f\ud979\udd5b\ud8ab\udc92\uda59\udc19\ud848\udefb\ud80c\udd89\ud98d\udff4\uda34\udfc7\ud96d\udf9c\ud93e\udf41\ud836\udd6f\uda1d\udf4f\udbc2\udc01\uda07\udf7c\ud886\udcc2\udbb7\udf98\ud9a2\ude8a\ud89d\udc0e\ud973\udd8d\uda29\udd14\ud9f0\udf55\ud872\udf9e\uda9b\ude6f\ud9db\udd97\ud8b9\udc4e\ud88d\udec5\udafd\uddc3\ud8c8\udef1\udbf3\udd67\udabb\udfe5\ud9c1\udfe1\ud940\udc67\uda82\udea7\udb16\ude2c\udb5e\udf47\ud95d\udf0c\uda53\udce9\udbd5\udce0\ud9ec\udca3\udb27\ude93\udaa5\udfdd\ud873\udd88\udb01\ude78\ud939\udf69\uda02\uddda\udb91\udc22\ud92a\udcd7\udbd7\uddf6\udb2c\udf2e\udb0c\udf33\ud8ed\ude6c\udb0e\uddad\udada\udfcb\uda44\udd43\udb90\udfa1\udbe7\udf05\udbc2\ude44\ud962\udc0b\ud83e\udc37\udbf5\udd54\u496f\uda96\ude28\udb58\udf1b\ud838\udf9b\ud84f\ude80", "\u12ff\u9bbe\ua705\ua7c1", "\uda22\udcca\ud9b9\udf2c\ud946\udf03\uda2e\udd02",
        -2, 96700, -332662604, 6720443505664338502L, 16897L, true, false, (char) 35616, (char) 54190,
        Double.longBitsToDouble(0x3fc596c31d47388cL), Double.longBitsToDouble(0x3fd4e057f3c98f34L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.Option:[ option: \000\000\000\000  ::  :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option: \000\000\000\000  ::  :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \000\000\000\000  ::  :: class java.lang.String ]\012",
        Z.run(T, 2, 9, 6, 15, "\000\000\000\000", "", "",
        33, 77210, 1153564672, 2283294894540651893L, 6332L, false, false, (char) 44202, (char) 44678,
        Double.longBitsToDouble(0x3fd69c68c8000f5cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.Option:[ option: \000  :: \u9949\u550c\000\uc118\u5ed0\000\000 :: class java.lang.String ]\0121=void\012",
        Z.run(T, 2, 9, 0, 0, "\000", "\u9949\u550c\000\uc118\u5ed0\000\000", "\ud8ab\udcaa",
        15, 33128, -1869719898, -963903332L, -43455L, true, false, (char) 60733, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f4c10cac4000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u1e96  :: \u35dd\ucc55\u6f4c\u76e2\ud6cf\u86dc\u5799\u6dce\u3a44 :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u1e96  :: \u35dd\ucc55\u6f4c\u76e2\ud6cf\u86dc\u5799\u6dce\u3a44 :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option: \u1e96  :: \u35dd\ucc55\u6f4c\u76e2\ud6cf\u86dc\u5799\u6dce\u3a44 :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u1e96  :: \u35dd\ucc55\u6f4c\u76e2\ud6cf\u86dc\u5799\u6dce\u3a44 :: class java.lang.String ]\012",
        Z.run(T, 2, 6, 6, 15, "\u1e96", "\u35dd\ucc55\u6f4c\u76e2\ud6cf\u86dc\u5799\u6dce\u3a44", "\ud8ea\udcec\ud9cc\udf74\udad3\udf59\udb39\udf6b\udb9d\udd73\ud954\udeae\u7752\uda54\udd4b\uda4c\udf5f\udbda\ude4b",
        33, 27082, 1601288881, -5993980189468097717L, 83854L, true, false, (char) 32391, (char) 12004,
        Double.longBitsToDouble(0x3f977aa677f951e0L), Double.longBitsToDouble(0x3fdbf3aff609f68cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 3, "\u1e96", "\000", "",
        -5, 76840, -1590249676, -7909515349046506135L, 68821L, false, false, (char) 24738, (char) 32348,
        Double.longBitsToDouble(0x3f92a99193883d40L), Double.longBitsToDouble(0x3fd00a7f6000015cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.cli.Option:[ option:   ::  :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option:   ::  :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option:   ::  :: class java.lang.String ]\012",
        Z.run(T, 2, 12, 6, 3, "", "", "\ud86c\udc75\ud8bd\uddf3\ud9ae\udc35\ud9ed\ude64\udbed\udf69\uda0b\udeff\ud91e\udd6a\ud67a\ud8ab\udcaa\uda59\udc19\ud972\udef0\u918e\ud950\uddf5\ud8dd\udf9c",
        14, 13705, -326827435, -8952858496055840245L, 91045L, false, true, (char) 16313, (char) 62463,
        Double.longBitsToDouble(0x3fc9ca35812a125cL), Double.longBitsToDouble(0x3fecda8a6be1281aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u68bc\uabe0\u41e8\u8533\u5080\u3ca8\ua53b\u06c7\u3359 :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u68bc\uabe0\u41e8\u8533\u5080\u3ca8\ua53b\u06c7\u3359 :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u68bc\uabe0\u41e8\u8533\u5080\u3ca8\ua53b\u06c7\u3359 :: class java.lang.String ]\012",
        Z.run(T, 2, 7, 6, 8, "\u1a0f", "\u68bc\uabe0\u41e8\u8533\u5080\u3ca8\ua53b\u06c7\u3359", "\ud863\udc78\uda86\udee2",
        16, 20874, 128857478, 7335480751675735125L, 91045L, false, true, (char) 1105, (char) 61203,
        Double.longBitsToDouble(0x3fe6728d630e8397L), Double.longBitsToDouble(0x3fe5fab86d5b6ae4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\0121=null |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\012",
        Z.run(T, 2, 15, 10, 7, "\u1a0f", "\u2fab\u80d9\u4161\u8533\u5080\u1c12\ua53b\u06c7\u3359", "\ud983\udd29\u9133",
        5, 67316, 128857449, 7335480751678620245L, 91045L, false, true, (char) 63928, (char) 58543,
        Double.longBitsToDouble(0x3fe6728d604a8497L), Double.longBitsToDouble(0x3fe5fa8a6d5b1eefL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.RuntimeException\012",
        Z.run(T, 2, 2, 6, 8, "\u018b", "\u2fab\u80d9\u4161\u8533\u9cf2\uc0d1\u7cff\u074e\u3359", "\ud839\ude44\u4271",
        5, 67316, 128857449, 7335480751678620245L, -28901L, false, true, (char) 63928, (char) 58543,
        Double.longBitsToDouble(0x3faccd50426c8420L), Double.longBitsToDouble(0x3fe82b6ee875972dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:6671 |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\0121=null |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\012",
        Z.run(T, 2, 11, 8, 3, "\u1a0f", "\u2fab\u80d9\u4161\u8533\u5080\u3ca8\ua53b\u06c7\u3359", "\ud863\udc78\ud816\udd86",
        5, 67316, 128857449, 7335480751686663060L, 91045L, false, true, (char) 63928, (char) 58543,
        Double.longBitsToDouble(0x3fc9ca35812a1160L), Double.longBitsToDouble(0x3fe5fa8a6d5b1eefL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u57d1\u80d3\u4161\u8533\u5080\u3ca8\u3a77\uc6fd\u3359 :: class java.lang.String ]\0121=!java.lang.RuntimeException\012",
        Z.run(T, 2, 9, 4, 8, "\u1a0f", "\u57d1\u80d3\u4161\u8533\u5080\u3ca8\u3a77\uc6fd\u3359", "\udbf0\udde7\ue2bc\ud98d\udff4\u6e5c\ud86e\udfc7\udb38\udee0\ud836\udd2f\udb8b\udc25\ud90b\udf28\ud8c9\ude42\ud85e\udca6\ud907\udfa0\ud9a2\ude8a\ud89d\udc0e\ud892\udf88\uda29\udd14\udac9\udc91\ud9ce\udf1b\udaa4\ude98\uda46\udccb\udb99\udd82\ud814\udced\ud992\ude32\ud863\udc61\udbaf\udc2d\ud8c5\udd10\udbfc\udde3\uda68\udf6f\ud8ab\udf74\udacc\uddb6\ud8ff\udf35\uda7f\udc85\ud898\ude46\uda6d\ude3a\ud8ba\udfa4",
        32, 61250, -787546120, -1016767144853119419L, -65403L, true, true, (char) 27723, (char) 20257,
        Double.longBitsToDouble(0x3fe3cb2d4df0266fL), Double.longBitsToDouble(0x3febf7180e06ab55L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u04b4\u803e\u4161\u8533\u5a2e\u3d6b\ua53b\u06c7\u3359 :: class java.lang.String ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u04b4\u803e\u4161\u8533\u5a2e\u3d6b\ua53b\u06c7\u3359 :: class java.lang.String ]\012",
        Z.run(T, 2, 9, 1, 8, "\u1a0f", "\u04b4\u803e\u4161\u8533\u5a2e\u3d6b\ua53b\u06c7\u3359", "\ud863\udd14\u918e\ud98d\udff4\ud8d6\udd39\udb75\udddc\udaa6\ude41\ud836\udd2f\uda1d\udf4f\udaa5\udf5f\udb28\udcd2",
        5, 27082, -42878287, 5885333064469936846L, 12722L, false, false, (char) 43499, (char) 54995,
        Double.longBitsToDouble(0x3fd888b1f427f91aL), Double.longBitsToDouble(0x3fec6d8ee801e283L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u847f\u80d9\u4161\uc8d2\u9a47\u3d14\ucca5\u0bdd\u3359 :: class java.lang.String ]\0121=!java.lang.RuntimeException\012",
        Z.run(T, 2, 9, 2, 8, "\u1a0f", "\u847f\u80d9\u4161\uc8d2\u9a47\u3d14\ucca5\u0bdd\u3359", "\uda46\udd49\udb10\uded4\ud99e\udf93",
        45, 81449, 1707924705, -1403713144679006019L, 906L, false, true, (char) 37675, (char) 63273,
        Double.longBitsToDouble(0x3fe3285ba61d760dL), Double.longBitsToDouble(0x3fec13dc6a159f78L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void\0121=java.lang.Class:java.lang.String |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\012",
        Z.run(T, 2, 0, 15, 8, "\u1a0f", "\u2fab\u80d9\u4161\u8533\u69af\u68c4\u4b9c\ua769\ud36d", "\udb49\ude4b\udb69\udece",
        29, 99243, 128857449, 7335440069748421461L, 91045L, false, true, (char) 63928, (char) 58543,
        Double.longBitsToDouble(0x3fe6728d604a8497L), Double.longBitsToDouble(0x3fe5fa8a6d5b1eefL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.Option:[ option: \u1a0f  ::  :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option: \u1a0f  ::  :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u1a0f  ::  :: class java.lang.String ]\012",
        Z.run(T, 2, 9, 6, 8, "\u1a0f", "", "",
        12, 73064, -457600812, 0L, 31072L, false, false, (char) 32166, (char) 50595,
        Double.longBitsToDouble(0x3fc3883d54000230L), Double.longBitsToDouble(0x3fcc20f5c9559400L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\0121=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ] |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\012",
        Z.run(T, 2, 7, 6, 8, "\u1a0f", "\u2fab\u80d9\u4161\u8533\u5080\u3a1f\ua53b\u06c7\u3359", "\ud863\udc78\u918e",
        5, 67316, 128857449, 7335480751678620245L, 91045L, false, true, (char) 63928, (char) 58543,
        Double.longBitsToDouble(0x3fe6728d604a8497L), Double.longBitsToDouble(0x3fe5fa8a6d5b1eefL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:11456 |this=org.apache.commons.cli.Option:[ option: \u2cc0  :: null :: class java.lang.String ]\0121=java.lang.String:\u2cc0 |this=org.apache.commons.cli.Option:[ option: \u2cc0  :: null :: class java.lang.String ]\012",
        Z.run(T, 2, 11, 12, 8, "\u2cc0", "\ub440\u80d9\u4161\u8533\u5080\u3ca8\ua53b\u06c7\u3359", "\ud863\udc78\u918e",
        52, 25377, 128857449, 7335480751678620245L, -49323L, true, true, (char) 64584, (char) 1129,
        Double.longBitsToDouble(0x3feeb5a45ada611bL), Double.longBitsToDouble(0x3fd890034e208294L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u2fab\u80d9\u4161\u8533\u5080\u3ca8\ua53b\u06c7\u3359 :: class java.lang.String ]\0121=!java.lang.RuntimeException\012",
        Z.run(T, 2, 8, 4, 8, "\u1a0f", "\u2fab\u80d9\u4161\u8533\u5080\u3ca8\ua53b\u06c7\u3359", "\ud98c\udfce\ud88d\ude7d",
        5, 67316, 125318505, 7335480751678620245L, 91045L, false, true, (char) 57528, (char) 58534,
        Double.longBitsToDouble(0x3fe6728d604a8497L), Double.longBitsToDouble(0x3fe5fa8a6d5b1eefL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Option:[ option: \ufeb0  :: \u05c3\u9dce\u21ac\u119c\u38c8\u58cf\u44bb :: class java.lang.String ]\0121=null |this=org.apache.commons.cli.Option:[ option: \ufeb0  :: \u05c3\u9dce\u21ac\u119c\u38c8\u58cf\u44bb :: class java.lang.String ]\012",
        Z.run(T, 2, 13, 13, 0, "\ufeb0", "\u05c3\u9dce\u21ac\u119c\u38c8\u58cf\u44bb", "\ud9a2\udf0d\u2500\000\ud8d7\uddcb\ud8ce\ude45\u9168\ud888\udc03\ud811\udced\u0660\udb4d\ude1d",
        51, 69655, 659485765, 2607412911279804134L, 39849L, true, true, (char) 65468, (char) 53671,
        Double.longBitsToDouble(0x3fd6b4e589c52724L), Double.longBitsToDouble(0x3f6089ddd1599d00L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 15, "\000\000\000\000\000\000\000\000\ud8a3\udd03\udb6c\udfbb", "\u9562\u2db2\u37b5\u21e8\u42c9\u6884\u4e83\u0401\000\u4a4b\u9063\u8aaa\u0165\u5be6\u7883\u74e9\u1c95\uc599\u010e\u60cd\u3d64\ucc8e\u6594\u8379\uaaeb\u20fe\ua901", "\ucffa\ud9a5\udc3c\u1cef\udac3\udf8c\uda96\udf67\udb45\udd31",
        40, 74951, -1124397098, 5370685072811019680L, 92849L, true, true, (char) 20773, (char) 16488,
        Double.longBitsToDouble(0x3fca4a00ed3b1820L), Double.longBitsToDouble(0x3feffeddb5b00eb2L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u1a24  :: \ud1c7\uabe0\u41e8\u8533\u5080\u9411\uc334\u8137\u3317\ub24f\u8573\ucac2\u85e0\ud288\u9397\u4ea0\u6d88\u2d0a :: class java.lang.String ]\0121=!java.lang.RuntimeException\012",
        Z.run(T, 2, 7, 2, 8, "\u1a24", "\ud1c7\uabe0\u41e8\u8533\u5080\u9411\uc334\u8137\u3317\ub24f\u8573\ucac2\u85e0\ud288\u9397\u4ea0\u6d88\u2d0a", "\udb28\udcd2\ud886\udc6a\udaf8\udc38\u7b29\ud89d\udc61\udac7\udf67\udaf6\udd66\ud91b\udff6\uda0d\udeb0\ud952\udfe0\ud826\udf54\ud979\udf5b\uda7f\udd75\uda73\uddfd\udbc8\ude1f\ud82e\udcd3\udb32\udf70\uda80\udee9\ud9e1\udd4c\udb3c\udd6c\udb27\uddf9\ud83a\udec2\ud9ce\ude9c\ud997\udfdf\udbd8\ude03\udaa8\ude02\ud863\udef1",
        25, 63138, 1095462066, -2240754880584951729L, 53923L, false, true, (char) 28142, (char) 1499,
        Double.longBitsToDouble(0x3fd1efa8db4e3b12L), Double.longBitsToDouble(0x3fd266de28e821b2L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u68bc\uabe0\u412c\u8533\ud4ed\u9c5b\ua53b\u1f3e\u3359 :: class java.lang.String ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u68bc\uabe0\u412c\u8533\ud4ed\u9c5b\ua53b\u1f3e\u3359 :: class java.lang.String ]\012",
        Z.run(T, 2, 7, 7, 11, "\u1a0f", "\u68bc\uabe0\u412c\u8533\ud4ed\u9c5b\ua53b\u1f3e\u3359", "\ud863\udc78\ud8a1\uddcd",
        16, 20874, 128857478, 7335480752336665685L, -96427L, true, false, (char) 30882, (char) 1098,
        Double.longBitsToDouble(0x3fe58a4d07910783L), Double.longBitsToDouble(0x3fe6728d630e8397L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u2fab\u80d9\u4161\u3a30\u5080\u1c12\ua53b\ubaf0\u67ff :: class java.lang.String ]\0121=java.lang.Class:java.lang.String |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u2fab\u80d9\u4161\u3a30\u5080\u1c12\ua53b\ubaf0\u67ff :: class java.lang.String ]\012",
        Z.run(T, 2, 15, 15, 7, "\u1a0f", "\u2fab\u80d9\u4161\u3a30\u5080\u1c12\ua53b\ubaf0\u67ff", "\ud983\udd29\u9133\ud98d\udff4\ud962\udc1e\udbb4\udc67\udb10\udc3c\ud836\udd2f\uda1d\udf4f",
        16, 67163, -528029115, 4541919678739278257L, -65752L, false, false, (char) 56331, (char) 64585,
        Double.longBitsToDouble(0x3fe0019120071abdL), Double.longBitsToDouble(0x3fc50c8e7791bb80L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:6671 |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\0121=java.lang.Integer:6671 |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: null :: class java.lang.String ]\012",
        Z.run(T, 2, 11, 11, 3, "\u1a0f", "\u2fab\u80d9\u4161\u8533\u5080\u3ca8\ua53b\u06c7\u3359", "\ud863\udc78\ud816\udd86",
        5, 67932, 128857449, 7335480751686663060L, 91045L, false, true, (char) 63928, (char) 58543,
        Double.longBitsToDouble(0x3fc9ca35812a1160L), Double.longBitsToDouble(0x3fe5fa8a6d5b1eefL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u03e5\u803e\u4161\u8533\u5a2e\u3d6b\ua53b\ud254\u3359 :: class java.lang.String ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u1a0f  :: \u03e5\u803e\u4161\u8533\u5a2e\u3d6b\ua53b\ud254\u3359 :: class java.lang.String ]\012",
        Z.run(T, 2, 1, 1, 8, "\u1a0f", "\u03e5\u803e\u4161\u8533\u5a2e\u3d6b\ua53b\ud254\u3359", "\ud863\udd14\u918e\ud98d\udff4\ud8d6\udd39\udb75\udddc\udaa6\ude41\ud836\udd2f\ud97a\uddbd",
        38, 60695, -539067898, 4541919677729847985L, -23425L, false, false, (char) 56331, (char) 19018,
        Double.longBitsToDouble(0x3fed76fc7afa5902L), Double.longBitsToDouble(0x3fe7fd9760f48ddfL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 2, 8, "\ud9cc\udd30\ud920\udf38\udbbd\udef6\ud8e5\ude24\ud9ea\uddc2\udacc\udf2c\ud843\ude1b\uda76\udd38\uda42\udd09\udae2\ude00\udbe4\ude32\ud848\udd89\ud8bc\udcf6\udbd8\udc0c\udb6a\udc1b", "\ud167\u4e83\u6d88\u709e\ucb9e\ud440\u9699\u94f7\ud264\u77a9\uc137\u830c\uaf00\u0f99\u3aa1\uc88b\u0cb4\u48a1\u081f\u081d\u3774\ua4b1\u39a0\ub520\u7e72\u4359\u25c2\u5981\u8155\u1cd4\u6f89", "\ud84e\udc07\ud818\udd49\ud9a8\udd3d\uda52\ude52\ud823\ude58\ud85f\udd25\ud8f9\udf54\ud85a\udfa7\ud8eb\udddf\ud8e9\uddae\ud99b\udefe\udada\ude79\uda91\udc24\udb91\ude6a\ud8fe\udddf\ud950\udfd6\udb9e\udf06\udaed\udede\udbaa\uddd9\uc3db\ud897\ude92\uda0e\udd4e\udbe9\udd16\ud9ee\ude09\u2b19\ud813\udc8f\ud8b0\udce6\udba9\udc67\udabd\udc44\u223d\ud932\udcfe\u9782\ud9e8\udff9\ud967\udd7d\udadc\udef8\u55d4\ud829\udcff\udafb\uddfe\ud8d2\udc07\uda16\ude32\ud94a\udff1\uda9d\ude1d\udb74\ude30\ud916\ude4b\ud9c6\udd1c\udb1c\uddd7\udac8\udcef\udbc1\udcbd\uda1e\udd05\udaf0\udf19\udabe\udcf5\udb1b\udd87\ud987\udc3e\uda1d\ude9a\ucd04\ud833\udc1c\ud90e\udcf0\ud871\udf44\uda7f\udfd7\ud8b9\uddeb\ud96c\udcb8\udb00\udeb5\ud88f\udeac\udb50\udc36\ud8fb\udec2\uda03\udc85\udaac\ude2e\ud8a6\udc15\ud8bf\udce4\ud93c\udd9c\uda8b\udf4a\ud9dd\udd22\udaeb\udd68\udbdb\udc33\udafa\udcfe\ud837\udf17\uda41\uded2\udba7\udf34\ud8fa\udfcd\ud885\udd29\uda6e\udd95\udb81\udd12\ud944\uddfb",
        43, 38601, 1567084795, 6145782324242731104L, -18341L, false, false, (char) 22661, (char) 2917,
        Double.longBitsToDouble(0x3fb2eb16f1568db0L), Double.longBitsToDouble(0x3fdde5b10595549cL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u18d6  :: null :: class java.lang.String ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Option:[ option: \u18d6  :: null :: class java.lang.String ]\012",
        Z.run(T, 2, 7, 7, 3, "\u18d6", "\u2fab\u80d9\u5520\u2fd3\u4ff0\u3a1f\u6519\u0ec6\u3359", "\ud863\udc78\u918e",
        8, 67316, 128857449, -5854100206424620459L, 91207L, false, true, (char) 63928, (char) 30502,
        Double.longBitsToDouble(0x3febed6f694a8497L), Double.longBitsToDouble(0x3fe5fa8a6d5b1eefL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 3, "\ud8d6\udec5\udbfa\udf6c\udaba\udffe\ud9f7\ude14", "\u8533\u4fac\u3ca8\ua53b\u06c7\u43f1\u7327\ubd2c\u37b5\u4835\u4231\u6884\u4e83\u6d88\u533e\u2b60\ud3d2\u451d\u94f7\u8e96\u77a9\u500b\u488a\u08a6\u5f23\ucb31\u6897", "\u1ded\ud98c\udfcc\ud89b\udc88\ud8a3\udefe\udabb\udfe5\ud9c1\udfe1\udb09\udf31\uda20\udd6f\ud81f\udec2\udb5e\udf54\ud95d\udf0c",
        49, 58532, 1298344980, -5507450377872297310L, -31073L, true, false, (char) 6576, (char) 46638,
        Double.longBitsToDouble(0x3fe4220d7a940e30L), Double.longBitsToDouble(0x3fc125ea6ac21494L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
    "M|org.apache.commons.cli.Option|acceptsArg||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|add|java.lang.String|new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|addValue|java.lang.String|new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|addValueForProcessing|java.lang.String|new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|clearValues||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|clone||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|equals|java.lang.Object|new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getArgName||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getArgs||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getDescription||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getId||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getKey||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getLongOpt||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getOpt||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.Option|getType||new:org.apache.commons.cli.Option:java.lang.String,java.lang.String",
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
