package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Parser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61", "\u531c", "\udbf2\udc1a\udaa9\ude11\udbdb\udea3\ud942\udcb2",
        12, 28860, 204892006, 5333775666554162504L, 51806L, true, true, (char) 33585, (char) 62552,
        Double.longBitsToDouble(0x3fecd22723a8abffL), Double.longBitsToDouble(0x3fee5ecb33197a0dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61", "\u531c", "\ud96d\udc77\udaaa\udd04\ud998\ude1b\ud942\udcad",
        12, 28860, 204892006, 5333775666554162504L, 51806L, true, true, (char) 33585, (char) 62552,
        Double.longBitsToDouble(0x3fecd22723a8abffL), Double.longBitsToDouble(0x3fee5ecb33197a0dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 5, "\ud9d5\udf9a\udb60\ude4f\udb65\ude89\udb99\ude0e\ud937\udf0f\ud8a6\udfe3\ud8ad\udf35\ud8b8\ude34\ud954\udcdc", "\ud1ed\u7281\u8cf3\ud0fb", "\ud8ec\udf96\udad3\udd12\udaf7\ude7a\udb10\udf28\ud9f3\udd8d\udada\udf94\u7212\ud817\udf40\uda4a\udc49\uda7e\uddfe",
        58, 63609, 1911270449, -6687864722037915435L, 8085L, false, false, (char) 30543, (char) 54094,
        Double.longBitsToDouble(0x3fe4ab7c3fcbadffL), Double.longBitsToDouble(0x3fd6d14d8656dcf4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\udbda\udea2\udb60\ude4f\udb65\ude89\udb99\ude0e\udb33\udf8d\ud8a6\udf61\ud896\udfca\uda25\udf91\ud954\udcdc\udbed\udc66", "\u7281\u8cf3\ub134\u23ed\u224c\u5ddf\uc870\u6536\ua2ae\uc0a7", "\ud95a\udc02",
        10, 26144, 2047727563, 1954583235135546837L, -92990L, true, true, (char) 16206, (char) 49480,
        Double.longBitsToDouble(0x3fe96218836abbc3L), Double.longBitsToDouble(0x3fc42f31c32a205cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 7, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61\ud8ad\udf35\ud8b8\ude34\ud954\udcdc\udb1e\udc54\uda1d\udec1\udbf2\udc1a\udaa9\ude11\udbdb\udea3\uda54\udff5\u347f\udbe7\udc99\ud8cc\udc1e", "\ua302\uaaf1\u27b7\u9d3d\u4d9a\u780a\uc186\ua873\u2c06\uacd3\u9da9\u202f\u7e99\u2693\u4b56\ub93c\u5ae1\u48b5\u3eaf\u9459\u250b\uc346\ud4ac\u1858\u4d12\ubcfd\u8ab8\ucad8", "\ud9d8\ude80\ud971\udd04\udaca\ude5f\ud887\udfd9\ud8da\udfaf\ud990\udd55\ud80b\udf72\ud9b0\udd95\uc343",
        30, 79063, 791682352, 5379910746721905271L, -21222L, false, true, (char) 33527, (char) 46890,
        Double.longBitsToDouble(0x3fc0906ea7c95a44L), Double.longBitsToDouble(0x3fecbf3b509a54fdL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 5, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61", "\u531c", "\udbf2\udc1a\udaa9\ude11\udbdb\udea3\ud942\udcb2",
        12, 28860, 204892006, 5333775666554162504L, 51806L, true, true, (char) 33585, (char) 62552,
        Double.longBitsToDouble(0x3fecd22723a8abffL), Double.longBitsToDouble(0x3fee5ecb33197a0dL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 5, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61", "\u531c", "\udbf2\udc1a\udaa9\ude11\udbdb\udea3\ud942\udcb2",
        12, 28860, 680930150, 5333684956844870984L, 51806L, true, true, (char) 33585, (char) 62552,
        Double.longBitsToDouble(0x3fecd22723a8abffL), Double.longBitsToDouble(0x3fee5ecb33197a0dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 7, "\ud9ce\udd8f\udb60\ude4f\ud9f4\udcf1\udb99\ude8a\udbfa\udcb1\ud8a6\udf61\ud8ac\udf35\ud8b8\ude34\ud954\udcdc\udb1e\udc54\uda1d\udec1\udbf2\udc1a\ud8ac\udc10", "\u14ab\ub0bd\u5ddf\uc870\u213b\ua302\u81b2\u5060\u9d32\u8e22\u9d2e\uc301\ua822\u8ea4\ua0eb\u0da8\u9a9c\u03b4", "\udb2f\ude3a\uda46\ude45\ud893\udf03\ud809\udcbd\ud8d8\udd17\ud8b3\udf5d\udbe7\udfd9\ud905\udc00\ud865\udfae\ud90d\udd25\ud855\udde1",
        46, 18782, 1264918796, 6290608511844837597L, 38172L, false, false, (char) 56183, (char) 34640,
        Double.longBitsToDouble(0x3fc1535a73651eecL), Double.longBitsToDouble(0x3fea51cf7e2e5bfbL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\udb5c\udc0e\ud812\uddc8\udb49\ude03\ud801\udc02\000\ud8a6\udf09", "\u3559", "\udbf2\udc1a",
        23, 47098, 91582560, 2010869165040074752L, -100000L, false, false, (char) 806, (char) 40702,
        Double.longBitsToDouble(0x3fd55be72000a2a8L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61\ud8ad\udf35\uda8f\ude36\ud903\udd01\udb1d\udffb", "\u7281\u8cf3\u36d8", "\ufccc\udbfb\udf68\ud961\udc98\ud9c0\udc4b\u6521\ud88a\udca8\ud97c\uded4\ud95a\udc02\udaaf\udea6\uda9c\udd61\ud95b\udefc\udab4\uded0\uda9a\udc3f\udb7e\ude6c\udae6\udc6a\ud95a\udd1a\ud8ce\ude62\ud975\udd1c\udae6\ude44\ud96e\udf4d\ud98a\udc79\udae4\udf47\udbef\udc50\ue5fd\udbd3\udd6a\udb89\ude67\udbdf\udd07\udb06\ude9c\udb4e\udf62\udaf6\udeda\udaa2\udcff\ud86f\ude1c\uda95\uddc0\uda72\udcb9\ud93a\udcf9\ud9cf\udcf8",
        -2, 25323, 579349070, 6946677600062747063L, -71176L, false, false, (char) 12059, (char) 61287,
        Double.longBitsToDouble(0x3fdb2f82511070f8L), Double.longBitsToDouble(0x3fe52827fa387dc1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 2, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\uda8c\udf73\udbfa\udcb1\ud8b1\ude67\ud8ad\udf35", "\ucaec\u4258\ud1ed\u71c9\u57cb\uab4e\u3a10\ub3e4\uc2bf\u92c7", "\ud8ab\udf09\u51fe\ud97c\uded4\ud95a\udc02\uda3c\uddec\ud975\ude24\udaf8\udf8b\udbb0\udec7\ud962\udf02\ud948\udff5\ud911\uddba\uda01\udc57\uda19\udcfd\uda5c\udf66\ud947\udef1\udabc\udf3e\ud932\udc76\udbe1\udd9d\udac9\udda2",
        31, 377, 1490614163, -1997411413063157929L, -67479L, true, true, (char) 28965, (char) 42624,
        Double.longBitsToDouble(0x3fe1c8c00224d4c3L), Double.longBitsToDouble(0x3fc0a82492e5f338L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\ud9e0\ude9a\udb5c\udd4f\u7086", "\u8d80", "\ud954\udcdc",
        -4, -576, -1045353529, 7449481521669629186L, -97222L, false, true, (char) 24128, (char) 0,
        Double.longBitsToDouble(0x3fd484a05d21192aL), Double.longBitsToDouble(0x3fcfc9c01556f9c8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61]] |a1=[Ljava.lang.String;:[[\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 5, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61", "\u531c", "\udbf2\udc1a\udaa9\ude11\udbdb\udea3\ud942\udcb2",
        33, 79587, 204892006, 5333775666554162504L, 51806L, true, true, (char) 33585, (char) 62552,
        Double.longBitsToDouble(0x3fecd22723a8abffL), Double.longBitsToDouble(0x3fee5ecb33197a0dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61", "\000", "\udbf2\udc1a",
        33, 47098, 0, 2010868228583714084L, -9706L, false, true, (char) 806, (char) 40702,
        Double.longBitsToDouble(0x3fd55be721baa2a8L), Double.longBitsToDouble(0x3f106673489c8000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 5, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61", "\u531c", "\udbf2\udc1a\udaa9\ude11\udbdb\udea3\udb4d\uddb2\u347f\udbe7\udc99\ud8cc\udc1e\ud9e6\udf8d\udaf7\ude7a\udb10\udf28\ud964\udc44\udbf8\ude1f\ud97c\uded4\ud95a\udc02\udaaf\udea6",
        -1, 52563, -1472785639, 135607892705804166L, 26792L, false, false, (char) 63273, (char) 14431,
        Double.longBitsToDouble(0x3fe3060ce9fda83dL), Double.longBitsToDouble(0x3fa8c85bbf68bf70L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 6, "\ua940\udb60\udc4d\uda10\udec0\ud8bf\ude48\udbfa\udcb1\ud8a6\udf61\ud8ad\udf35\ud8b8\ude34\ud954\udcdc\udb1e\udc54\uda1d\udec1\udbf2\udc1a\udaa9\ude11\ud8be\udf13\ud865\ude80\ud9a0\udd7b\ud988\udc3b\ud8cc\udc46\udad3\udd12\udaf7\ude7a\udb10\udf28\u6521\udb20\udd6b\ud8c4\udc81\u70cc\udb03\udee4\u46bb\ud95b\udefc", "\u6099\ub249\u3f00\u640a\u2c23\u1269\u949f\u06e8\u2e4a\u72f1\u2a2f\ua4d8\u5d11\u7a69\u9666\u09fe\u29fe\ud149\u5678\ubbb0\u854f", "\ud9cb\udd40\udaa9\udc36\ud801\udeb8\ud9d9\udd97\uda2f\udfc2",
        12, 27182, -853644547, 8121638412435493796L, 80824L, true, true, (char) 59766, (char) 46752,
        Double.longBitsToDouble(0x3feed3d2e3d6becfL), Double.longBitsToDouble(0x3fee85e737fe68ffL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 5, "\ud969\udcbd\ud9d1\udf0b", "\u37f8\u6282\u881b\u89fa\u6eab\u6a67\u42e7\ub9ad\u38e2\u8cf3\u368c\u23ed\u224c", "\ud870\udfcb",
        49, 95587, 294446654, 1181686267543562501L, -10824L, true, true, (char) 36320, (char) 2808,
        Double.longBitsToDouble(0x3fd22836c4fc0818L), Double.longBitsToDouble(0x3fda1254854eeda8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\ud9b9\udd84\udb42\udd9e\ue09a]] |a1=[Ljava.lang.String;:[[\ud9b9\udd84\udb42\udd9e\ue09a]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 8, 1, 7, "\ud9b9\udd84\udb42\udd9e\ue09a", "\ub60f\u13e6", "\udb08\ude73\ud8e6\udfac\u6db4\udaa9\udd1d\udbdb\udea3\ud942\udcb2\u347f\ud857\udf5d\ud824\udc27",
        57, 74342, 1971927107, -8610213619301055050L, -10737L, true, false, (char) 10839, (char) 21971,
        Double.longBitsToDouble(0x3fed144c75417058L), Double.longBitsToDouble(0x3fe171cc751c0b16L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 3, "\ud9e0\ude9a\udb60\ude03\udb65\ude89\ud9b6\udcfd\uccfe\ud89f\ude61\ud8ad\udf35\ud8b8\ude34\ud9c0\udcd2\udb1e\udc54\uda80\udf5d\udbd6\uddf8\udb80\uddf7\ucfc9\uda51\ude97\udb36\udcf2\ud803\ude40", "\ub1a2\u2154\u22e7\ubce8\u66b6\uaf95", "\udbc3\ude78\ud979\udec8\ud822\udf23\u8c5d\uda3d\uddd7\uda5b\udf2a\udbc6\udfdb\udbda\uddd9\ud80d\udd39\ud96a\udc85\ud82e\udf5c\udaf8\uddf0\ud819\udf3a\udaff\ude07\ud8e8\ude5e\udb91\udf69\ud918\udda9\ud81f\udd78\u85d5\u8649\udbb4\udc2a\ud976\udc46\ud944\udd28\udb34\ude09\uda62\udee9\ud967\uddc8\ud9ba\udfa8\uf1b6\ud95c\udd22\ud9a7\ude35\ud9ae\uddd3\ud89e\udfb2\udbd2\udfe5\ud9f3\udc46\udad7\ude84\ud9b7\udf88\uda5f\ude36\ud9fc\ude84\ud84a\udc05\udb78\udd77\ud953\udcf1\uda61\ude47\u4d5a\ud921\udd75\ud897\udc4f\udb9d\ude86\ud84d\uddc7\ud9c8\udca6\uda5f\udc7f\udb73\udd44\udbe4\udf3b\ud9c4\udfea\uda9b\udce5\ud9d7\udd4c\udbe9\udcaa\uda12\udf63\ud8d1\udcbd\uda7a\ude7f\ud8d1\udce5\ud8cf\udfd4\ud949\ude49\udb35\udf32\ud8e9\udd9e\udb12\udfb5\uda44\udf61\u934a\ud91a\udff8\udb00\udddd\udaae\udd9d\u3128\udab0\udec5\ud8c9\udd2c\ud9f5\udceb\ud804\uddcc\udb62\udfad\udbbb\udd1a\udbe3\udf8a\udac3\udce3\ud976\ude1e\udb2a\udd2d\ud85f\udfc9\udb3a\udd05\ud813\udead\udbfa\udde4\ud86c\ude94\ud9df\udfa8\ud91e\udc91",
        28, 2309, -1933725060, -9051161509327543602L, -29825L, true, true, (char) 59088, (char) 52778,
        Double.longBitsToDouble(0x3fb3440e05c8c8d8L), Double.longBitsToDouble(0x3fdbe1f84b9ebe14L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 6, "\ud9e0\ude9a\udb60\ude4f\u0086", "", "",
        -5, -1000, 0, 0L, -100000L, false, false, (char) 0, (char) 60671,
        Double.longBitsToDouble(0x3feb37b6c8b60c36L), Double.longBitsToDouble(0x3fd484a05d21192aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 5, "\ud9e0\ude9a\udad5\udd39\udb65\ude5a\udb99\ude0e\udb19\udcd1\ud8be\udfc0", "\u531c\u9214\u4258\u58be\u9129\u8cf3\u36d8\u23ed\u224c\u5ddf\uc870\u0c7d", "\u2d20\udb24\ude88\ud810\udc96\uda93\udd3d\uda9c\udd61\ud95b\udefc\ud85b\udde3",
        10, 9630, 883875223, 8121914282911887532L, -13976L, false, true, (char) 43303, (char) 52936,
        Double.longBitsToDouble(0x3fd23613c2fbc510L), Double.longBitsToDouble(0x3fdad34a9f1b5076L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 5, "\ud9e0\ude9a\udb60\ude24\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61\ud8ad\udf35\ud8aa\udf09\ud954\udcdc\udb1e\udc54\uda1d\udec1\udbf2\udc1a\udaa9\ude11\udbdb\udea3\ud942\udcc5\u347f\udbe7\udc99\ud8cc\udc1e\udad3\udd12\udaf7\ude7a\udb10\udf28\u6521\ud884\udc79\ud97c\uded4\ud95a\udc02\ud877\udf9f\uda9c\udd61\ud95b\udefc\ud84f\udfbd", "\ub4db\u5cdb\u7380\ud726\u0c3f\u4d10\uc53a\u49f0\u5b5f\u2c5a\uc20a\u0a82\ua0f1\ubb48\u5942\ua14c\u23d5\u1d2f\u4667\u7b01\u9337\u6560\u8f14", "\udbfe\ude7c\udb2b\udc6f",
        12, 39656, -585487514, -270357632168214402L, -5138L, false, false, (char) 44165, (char) 42180,
        Double.longBitsToDouble(0x3fe42248345bfe6aL), Double.longBitsToDouble(0x3fd5d94a751309b0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud9e0\ude9a\udb60\ude4f\ud8d9\udea4\udb86\uddf1\udbfa\udcb1\uda38\udd6b]] |a1=[Ljava.lang.String;:[[\ud9e0\ude9a\udb60\ude4f\ud8d9\udea4\udb86\uddf1\udbfa\udcb1\uda38\udd6b]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 5, "\ud9e0\ude9a\udb60\ude4f\ud8d9\udea4\udb86\uddf1\udbfa\udcb1\uda38\udd6b", "\ucdb7\u5278\u1c92\u82ee\u5074\u32b0\u5e24\ud437\u337c\u4747\u2240\u6d55\ud390\u3284", "\ud87d\uded1\udbeb\uddff\ud98a\uddeb\uda50\udd73",
        31, 54891, 1621137347, -1627864253266183754L, -88230L, false, false, (char) 42137, (char) 26498,
        Double.longBitsToDouble(0x3fd226536a1b3aceL), Double.longBitsToDouble(0x3fdef1150396e7a8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 1, "\udb04\udeba\udb60\ude4f\ud9c9\ude1c\udb92\ude42\uda29\uddb1\ud8a6\udf61\ud8ad\udf35\ud8b8\ude34\ud952\udcdc\udb1e\udc54\ud91b\udee9\udbf1\udf73\udaa9\ude11", "\ud0aa\u70cf\u5ddf\uc870\u0c7d\ua302\u334c\u85b9\u58e5\u4d9a\u780a\u75e8\ua873\u2b4c\uafc2\u35b1\u96d8\u097a\u427a\u72b8\u0e40\u3f15\u599c\u86e1\u6b45\u072c\u1efd\ubad1\u8022\ua5ec\u8995\ud1ab\u1ed3\u7009\u57be\u3bc1\u9761\ub0cd\u31c6\u8b0d\u076e\u1cf2\ua93a", "\udb3b\udce7\uda46\udc03\udab0\udd40\ud9b2\udd75\ud901\udf8c\udb67\ude1a\uda58\udd6c\ud82a\udcb4\uda27\udf6f",
        56, 43088, -839920683, -1320128310983495818L, -47162L, false, false, (char) 5645, (char) 63716,
        Double.longBitsToDouble(0x3fd37acdae1207d0L), Double.longBitsToDouble(0x3fd376a5ebde53a0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 4, "\ud9e0\ude9a\udb60\ude4f\udae5\udcc5\uda42\udce0", "\u2c01\u067e\ubd97\u4ede", "\udabc\udf5b\ud929\udca2",
        58, 69969, 876736804, 880004465394409654L, -59803L, false, false, (char) 23960, (char) 64748,
        Double.longBitsToDouble(0x3fef9883339a44e4L), Double.longBitsToDouble(0x3fed455fffcbd966L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 5, "\u00e9\udb60\ude4f\u0086", "\u7076", "\u9d66",
        -5, -1000, -1045353529, 7449481523482354946L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e48000000000000L), Double.longBitsToDouble(0x3fcfc9c01556f9c8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud9e0\ude9a\udb60\ude4f\ud927\udf8a\ud847\ude77\udbfa\udcb1\ud8a6\udf61]] |a1=[Ljava.lang.String;:[[\ud9e0\ude9a\udb60\ude4f\ud927\udf8a\ud847\ude77\udbfa\udcb1\ud8a6\udf61]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 0, "\ud9e0\ude9a\udb60\ude4f\ud927\udf8a\ud847\ude77\udbfa\udcb1\ud8a6\udf61", "\u531c", "\udbf2\udc1a\udaa9\ude11\udbdb\udea3\ud942\udcb2",
        38, 28860, 204892006, 5333775666554162504L, 51806L, true, true, (char) 33585, (char) 62552,
        Double.longBitsToDouble(0x3fecd22723a8abffL), Double.longBitsToDouble(0x3fee5ecb33197a0dL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 0, "\ud9e0\ude9a", "\u084c\u37f8\000", "\000",
        -5, -576, -1045353529, 246263022118144L, -97222L, false, true, (char) 24128, (char) 27884,
        Double.longBitsToDouble(0x3fd484a05d21192aL), Double.longBitsToDouble(0x3fcfc9c01556f9c8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbc3\udfab\ud889\udcd6\udb65\ude89\ud96c\udfc2\ud97b\udd9e\ud868\udf7e]] |a1=[Ljava.lang.String;:[[\udbc3\udfab\ud889\udcd6\udb65\ude89\ud96c\udfc2\ud97b\udd9e\ud868\udf7e]] |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\udbc3\udfab\ud889\udcd6\udb65\ude89\ud96c\udfc2\ud97b\udd9e\ud868\udf7e]] |a1=[Ljava.lang.String;:[[\udbc3\udfab\ud889\udcd6\udb65\ude89\ud96c\udfc2\ud97b\udd9e\ud868\udf7e]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 7, "\udbc3\udfab\ud889\udcd6\udb65\ude89\ud96c\udfc2\ud97b\udd9e\ud868\udf7e", "\u3e67\u9214\u4258\ub4c0\u6df7\u8d4f\u070e\u7ca3\u22ac\u0bf4", "\udafe\udca1\udb68\udce1\ud952\udd49\uda33\udf6b\udbd1\udf1f\udac0\udfc7\ud940\udf7d",
        58, 27425, -232992181, -3618315221791593763L, -52269L, false, true, (char) 29396, (char) 40396,
        Double.longBitsToDouble(0x3fe800245352da0dL), Double.longBitsToDouble(0x3fe5cd18dee26379L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 8, "", "", "\u0415",
        -5, -1000, 0, -5486228771067396096L, -23257L, true, true, (char) 36345, (char) 64645,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e16c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 5, "\udae3\ude66\u63cd\udb65\ude89\udb99\ude0e\uda7a\udcb0\ud931\udcee\u4688\uda25\udf1e\ud9f4\udf76\udb26\uddd4", "\u7281\u61b1\u8d26\ub703\u224c\u5ddf\uc870\u6536\ua2ae\ud55b", "\uda5b\uddc9",
        10, 26144, 2047727563, 1954583235135546837L, -81965L, true, false, (char) 59188, (char) 4781,
        Double.longBitsToDouble(0x3fe11c8dd0960cb6L), Double.longBitsToDouble(0x3fdab32e3b0501f0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udbda\udea2\udb60\ude4f\udb65\ude89\udb99\ude0e\udb36\udcbf\ud8a6\udf61\ud896\udfca\uda25\udf91\ud954\udcdc\udbed\udc66", "\ub500\u8cf3\ub134\u23ed\u224c\u5ddf\uc870\u6536\ua2ae\uc0a7", "\ud95a\udc02",
        10, 26144, 2047727563, 1954583235135546837L, -92990L, true, true, (char) 16206, (char) 49480,
        Double.longBitsToDouble(0x3fe96218836abbc3L), Double.longBitsToDouble(0x3fc42f31c32a205cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\udbda\udea2\udb60\ude4f\udb65\ude89\udb99\ude0e\udb33\udf8d\ud8a6\udf61\ud896\udfca\uda25\udf91\ud954\udcdc\udbed\udc66", "\u7281\u8cf3\ub134\u23ed\u224c\u5ddf\uc870\u6536\ua2ae\uc0a7", "\ud95a\udc02",
        10, 26144, 2047727563, 1954583235135546837L, 22030L, false, true, (char) 60513, (char) 60636,
        Double.longBitsToDouble(0x3fecd4b0129d2fe8L), Double.longBitsToDouble(0x3fe701c8da68fbafL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 2, "\udbab\ude9b\udb6a\udcc0\ud9e7\udc5f\udb75\udfde\udbfa\udcb1\ud8a6\udf61\ud8d0\udd5b\udab8\udf49\ud954\udca5\udb22\ude62\uda1d\udec1\udbf2\udc1a", "\ub842\ub735\u17b1\u5ddf\uc7c4\u0c7d\ua302\u334c\u77cc\u1c76\u533b\ud7e3\ua2be\ua873\u0afe\u5f4e\u6020\u558b", "\ud9f6\udcd7\ud949\udea2\udaa4\uddb0",
        48, 34748, -1723064798, -8430194240189936356L, 95853L, false, false, (char) 46718, (char) 39464,
        Double.longBitsToDouble(0x3fc9d4b750782168L), Double.longBitsToDouble(0x3fe05a7aa173df44L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\ud9e0\ude9a\udb60\ude4f\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61", "\u52c3", "\udbf2\udc1a",
        3, 89456, 91582560, 2010869164886584612L, -9706L, false, true, (char) 806, (char) 40702,
        Double.longBitsToDouble(0x3fd55be723baa2a8L), Double.longBitsToDouble(0x3fef9883339a44e4L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 2, "\uda73\ude18\udb60\ude4f\udbdc\udc90\udb99\ude0e\u6fd7", "\uc349\ucca7\uad5b\u429f\ud1ed\u1481\u8cf3\u36d8\u23ed\u224c\u842b\u75f0\u0c7d\ua302\u334c\u5d68\u9d4c\u6aef", "\ud95b\udefc\ud8db\udcc4\udb98\udf0b\udbb6\udec1\ud8d6\udd56\udb9e\ude70\ud955\udf87\uda45\udd5e\ud9ef\udcec\uda4e\udc70\udb66\udfa6\ud942\udee9\udaab\ude27\uabe0\ud93f\udde4\udaf6\udc3e\uda5b\udd84\uda2d\udcd0\udb69\udcdc\ud8da\udc65\u1d2c\ud8a0\udefe\ud89f\udc86\udadf\udd00\ud939\ude8c\udafe\udc12\udb6b\udc9b\ud81b\udee3\ud876\udc54\ud876\udca7\ud807\udd03\uda2b\udff5\ud848\udd68\ud86e\udfaa\udab2\udd1e\ud886\udc5e\ud836\udf0d\udb0d\udff2\ud85c\udd3a\ud816\udf85\ud94e\udcb4\ud9fa\udec9\ud8cb\uddbc\ud85d\udcdd\udbd9\udd52\udb12\uddc9\udadc\udf5c\ud801\udffc\ud916\udc7b\ud8b6\udff6\ud8a5\ude66\uda57\udf58\u7a1d\ud842\udde3\ud9d0\ude0e\udacf\ude6e\udac5\udc69\udbe6\udf22\udb91\udd72\uda3b\uddc3\udb7f\udc36\udbc3\ude80\ud822\udfaf\ud9f0\udce1\ud950\udd09\ud9e8\uddf6\udbb1\uddb2\ud8e7\uddfe\ud8da\udcac\ud863\udd83\ud815\udf4b\udbd1\udc87\ud876\udda0\ud826\udc56\ud829\udfe4\ud8d4\udc47\ud82d\udf7e\ud924\udd84\ud9ae\udebd\udb18\udf8a\uda25\uddd7\udb1f\udc35\udb7b\udc8b\ud8ba\ude33\udb90\udf7a\udb2b\udd2c\udb8b\udde8\udbf7\udd35\udaec\udee3\udbd0\udef6\ud8c4\udc08\uae7c\udb37\udc92\ud8e6\udf23\ud9f8\udeed\u0d80\udb32\udc4f\ud8d2\udd4b\uda2d\udfaf\udb73\uddf1\udae1\udf99\uda29\udf13\uda54\udca9\ud838\udf6e\ud997\ude26\ud99a\ude5d\udbf5\udfb0\ud8d2\udcef\ud9f8\udc68\uda00\udd15\ua5a1",
        26, 8060, 445892631, 8632820644197955953L, 11890L, false, true, (char) 7992, (char) 52442,
        Double.longBitsToDouble(0x3fefef97f8171089L), Double.longBitsToDouble(0x3feca07001bd3ea6L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 5, "\ud9e0\ude9a\udb60\ude24\udb65\ude89\udb99\ude0e\udbfa\udcb1\ud8a6\udf61\ud8ad\udf35\ud8aa\udf09\ud954\udcdc\udb1e\udc54\uda1d\udec1\udbf2\udc1a\udaa9\ude11\udbdb\udea3\ud942\udcc5\u347f\udbe7\udc99\ud8cc\udc1e\udad3\udd12\udaf7\ude7a\udb10\udf28\u6521\ud884\udc79\ud97c\uded4\ud95a\udc02\ud877\udf9f\uda9c\udd61\ud95b\udefc\ud84f\udfbd", "\ub4db\u5cdb\u7380\ud726\u0c3f\u4d10\uc53a\u49f0\u5b5f\u2c5a\uc20a\u0a82\ua0f1\ubb48\u5942\ua14c\u23d5\u1d2f\u4667\u7b01\u9337\u6560\u8f14", "\udbfe\ude7c\udb2b\udc6f",
        12, 39656, -585487514, -270357633611054978L, -5138L, false, false, (char) 44165, (char) 42180,
        Double.longBitsToDouble(0x3fe42248345bfe6aL), Double.longBitsToDouble(0x3fd5d94a751309b0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processArgs|org.apache.commons.cli.Option,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processOption|java.lang.String,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
