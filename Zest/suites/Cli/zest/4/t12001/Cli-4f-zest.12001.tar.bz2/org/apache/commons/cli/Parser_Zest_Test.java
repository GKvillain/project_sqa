package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Parser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 8, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a", "\u6719\ub5a4\u29ae\u3728\u64ab\u415d\uc74b\u9724", "\uda3e\uded4\uda73\udf80\uda39\udd1c\ud94e\udc50\uda7a\udf74",
        16, 91410, 1047932995, -6004901312640633081L, 87596L, false, true, (char) 49248, (char) 18924,
        Double.longBitsToDouble(0x3fe1a4b8b62fad58L), Double.longBitsToDouble(0x3fc1878142156068L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 8, 8, 4, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a", "\u6735\ub5a4\u29ae\u3728\u28d1\u0c47\u46da\u9e5a", "\uda3e\uded4\uda73\udf80\uda39\udd1c\ud94e\udc50\uda7a\udf74",
        16, 91410, 443821379, -7794126976678676588L, 87596L, false, true, (char) 49248, (char) 18924,
        Double.longBitsToDouble(0x3fe1a4b8b60ad358L), Double.longBitsToDouble(0x3fc1879da21442b0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 7, "\udaf6\udd3e\ud81c\udebe\ud95e\udc62\udb62\udfb3\ud890\udfb0\udac6\udecf\udab4\uded9\uda2b\udcbc\udae6\uddc5\udbb5\udd05\udb26\udd86\ud875\udc2a\udb17\ude98\ud8bb\udc1b\ud90f\udf7f\ud823\ude77\uda69\ude48\udb56\udd9c\uda48\udfee\ud87f\udf99\ud8f7\udd0f\ud814\udf95\uda04\uddb4\ud9fd\udf0a\uda3e\uded4\udb73\ude21\udb70\udd38\ud94e\udc50\uda7a\udf74\udb3d\ude90\udbf1\uddc3\ud92a\udff1", "\u56db\ua00c", "\udb78\udcba\ud917\udc1b\ud858\udc22\udb5c\udcf5\ud8cd\uddc9\ue555\udb24\uddb8\ud86c\uddbd\ud8f2\udfe3\udaf1\udffb\uda2f\ude01\ud97b\udd8a\udab8\udc19\ud8d0\udf86\ud97a\udd74\u7fa1\udba0\udc5b",
        44, 55025, 1258188724, 7093039033416563133L, -22926L, true, false, (char) 3002, (char) 48260,
        Double.longBitsToDouble(0x3feb216ba8389960L), Double.longBitsToDouble(0x3fe28534b1689654L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 7, "\udaf6\udd3e\ud801\uddfc\uda66\udd85", "\u687c", "\ud9c8\ude95\uda8f\ude94\udb26\udd86\udbd6\udfdb\uda54\uddd8\udb89\udc22\ud8c7\udd3d\ud823\udee9\uda58\udc48",
        43, 63086, -331200317, 1166771070522939106L, 32650L, true, false, (char) 1123, (char) 10417,
        Double.longBitsToDouble(0x3fe3a8ab0c6c6362L), Double.longBitsToDouble(0x3fe3bd451c42b844L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 8, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a", "\u6719\ub5a4\u29ae\u3728\u64ab\u415d\uc74b\u9724", "\ud87e\udccf\uda73\udf80\uda39\udd1c\ud94e\udc50\uda7a\udf74",
        16, 13010, 0, 0L, 87596L, false, true, (char) 49248, (char) 18924,
        Double.longBitsToDouble(0x3fe1a4b8b62fad58L), Double.longBitsToDouble(0x3fc1878142156068L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 2, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\ud96a\ude01\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a", "\u483e\u2852\ucf95\uccf8\u4b13\u4588\ubc2d\u1f48\u00ba\u33cf\u957c", "\ud95b\udfd7\u1b29\udb3d\ude79",
        -5, 56995, -1398125038, 5532451169035883242L, 72406L, false, true, (char) 36525, (char) 49248,
        Double.longBitsToDouble(0x3fefc4efa2349716L), Double.longBitsToDouble(0x3fe17d6ac48c3c0aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 8, 5, 8, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud8bb\udda1", "\u6719\u1633\u44a6\u3735\u64ab\u415d\uc74b\u9724", "\uda3e\uded4\uda73\udf80\uda39\udd1c\ud94e\udc50\uda7a\udf74",
        16, 91410, 1047932995, -6004901312640633081L, 87596L, false, true, (char) 49248, (char) 18924,
        Double.longBitsToDouble(0x3fe1a4b8b62fad58L), Double.longBitsToDouble(0x3fc1878142156068L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 8, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a", "\u6719\ub5a4\u29ae\u3728\u64ab\u415d\uc74b\u9724", "\uda3e\uded4\uda73\udf80\uc57a\ud94e\udc50\uda7a\udf74",
        16, 91410, 1047932995, -6004901312640633081L, 38380L, true, false, (char) 43051, (char) 60865,
        Double.longBitsToDouble(0x3fe9f062afb6f4ddL), Double.longBitsToDouble(0x3fedf05eb66b0f1fL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 8, "\ud97f\udd21\ud837\ude6e\ud937\udeed\udaaf\udf40\udaf9\udd22\udac6\udecf\ud869\udff0\udadc\udec1\ud922\udfd6", "\u8ae4\ubd56k\uc5c2\ub5a4\u29ae\u36b6\ud7aa\u415d\uc74b\u7f1d\u05a9\u8ea9\u0c4a\ubaa1", "\ud9bc\ude0c\udb62\ude1d\ud3e5\udbf4\udd41\ud823\uddae\ud945\udcc3",
        46, 94556, -1724957192, 3515209862902706217L, 54572L, false, false, (char) 36265, (char) 33723,
        Double.longBitsToDouble(0x3fb1c7068f40ac98L), Double.longBitsToDouble(0x3fe6710bb9b89e7bL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 8, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udada\udeef\000\udac8\udfe3\udbdd\udcec\ud998\udddf\ud9c8\ude95\001\udb04\udd21\ud875\udc2a", "\u6719\u5111\u29ae\u9bda\u64ab\u415d\uc74b\u9724", "\uda3e\uded4\uda73\udf80\uda39\udd1c\ud94e\udc50\022",
        53, 91410, 1047932995, 47936585257189376L, 87596L, false, true, (char) 49248, (char) 18924,
        Double.longBitsToDouble(0x3fe1a4b8b62fad58L), Double.longBitsToDouble(0x3fc1878142156068L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udaf6\udd3e\uda75\udef2\ud8bb\udc14\udb16\udd00\ud9ac\uddb8\udaf2\ude85\udad9\udf7b\ud816\udd38\udb9a\ude9e\ud93b\udc62\udb26\udd35\ud875\udc2a]] |a1=[Ljava.lang.String;:[[\udaf6\udd3e\uda75\udef2\ud8bb\udc14\udb16\udd00\ud9ac\uddb8\udaf2\ude85\udad9\udf7b\ud816\udd38\udb9a\ude9e\ud93b\udc62\udb26\udd35\ud875\udc2a]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 7, "\udaf6\udd3e\uda75\udef2\ud8bb\udc14\udb16\udd00\ud9ac\uddb8\udaf2\ude85\udad9\udf7b\ud816\udd38\udb9a\ude9e\ud93b\udc62\udb26\udd35\ud875\udc2a", "\u6719\ub5a4\u29ae\u01e5\ub28c\u8b57\ub4b2\u1418", "\uda3e\uded4\ud8fa\udc9a\ud8a1\udc44\ud85f\udd2a\uda96\udc98",
        16, 24698, 1047933011, -6004901312640633081L, -80914L, true, true, (char) 61934, (char) 19011,
        Double.longBitsToDouble(0x3fe9a4eb6b648795L), Double.longBitsToDouble(0x3fe5e88b23f89df4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 4, "\ud9f1\ude8c\udae9\udecc\uda8c\udfb1\ud803\udce9\ud998\udd01\ud929\udd39\ud9d9\udc2a\ud819\udd7d\udbb3\udd6b\uda8f\ude94\ue30f\ud875\udc2a\udb17\ude98\ud8bb\udc1b\ud98d\uddce\u1c5f\uda69\ude48\udb1b\ude00\uda4c\udc90\ud8fb\ude97\ud8f7\udd0f\ud929\udfbc\ud95d\ude49\ud909\udf0f\uda3e\uded4\uda73\udf80\udb4f\udea8", "\u48f4\ua2c8", "\ud91c\udf8d\ud951\uddf0\ud934\udd54\udb6f\udf79\udb6f\udf8b\udb78\udcba\ud8fa\udc2c\ud867\ude5a\udb5c\udcf5\ud828\udd16",
        23, 41653, 1478106252, -4184459207692132772L, -39235L, false, false, (char) 37431, (char) 50405,
        Double.longBitsToDouble(0x3fe0b465b5c7b643L), Double.longBitsToDouble(0x3fef6bab7b10c083L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 3, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\udbdd\udcec\ud998\udddf\udabe\ude10\udba1\udec2\ud9d9\udc27\ud9ac\udc49", "\ub25b\u249a\u9df2\u3728\u64ab\u415d\uc74b\u9724\u397c\ub0bb\u957c\ub010\u7d31\u583f\u3fb5\uadc6\ua294", "\ud91c\udf8d\ud951\uddf0\ud934\udd54\udb6f\udf79\uda11\ude44\udb78\udcba\ud917\udc1b\ud93a\uded4\udb5c\udcf5\ud8cd\uddc9",
        45, 30239, 1485249676, 4497917920616524909L, 56754L, true, true, (char) 21772, (char) 23593,
        Double.longBitsToDouble(0x3feec6332e0f46c8L), Double.longBitsToDouble(0x3fdb13f5c8668472L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 8, "\ud8d5\ude2e\uda63\udf2a", "\u76ef\u5d4b\u16bc\u4c0b\u5aa5\ub6ee\u3f29\u679f\ubcde\u7f86\u6719\ub5a4\u5801\u3728\u64ab\u415d", "\ud95d\ude49",
        38, 82193, 1557614600, 1540736686368117365L, -62794L, true, true, (char) 35009, (char) 20130,
        Double.longBitsToDouble(0x3fe83d6552ea4cc7L), Double.longBitsToDouble(0x3fd72ab9451283d0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\000\000\000\ud894\udf89=\uda8c\udfe5\u00b7", "\u66ef", "\000",
        14, 15638, 1536971025, 3800126785614512288L, 12445L, true, false, (char) 59154, (char) 34671,
        Double.longBitsToDouble(0x3e358fb010000000L), Double.longBitsToDouble(0x3fe04012dbda5cd7L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 8, "\ua5b0\ud814\udcfc\uda78\uddae\ud855\udee1\ud980\ude5b\udac6\udecf\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a\ud8af\udee4\ud838\udd0c\ud8a1\uddec\ud823\ude77\uda69\ude48\udb56\udd9c\uda48\udfee\ud87f\udf99\ud8f7\udd0f\ud929\udfbc\ud88c\udda0\ud909\udf0f\uda3e\uded4\uda73\udf80\uda39\udd1c", "\uadcf\ua294\u924a\u234d\u6a06\u0dba\u4dc2\u63b2\u189e\ua1b5\uac7b\u5c00\u1a89\u6fa0\u6122\uc560\u3cf7\u6959", "\udbbb\udd70\uda6f\uddf2\ud82f\uded2\udb39\udc0d\udbf3\udc90\ud816\udd96\udac8\udcf6\ud91f\udfd5\udba5\udfb1\ud985\udec2\ud9af\udd81\ud956\udf13\ud859\udd6e\ud88b\udd26\ud820\ude25\ud914\udc4a\udb10\udd7b\udb6e\udfaa\ud9b0\udcbc\ud888\udcfb\udb9f\udfb4\ud844\udc21\ud994\udea4\ud80b\ude88\ud813\udf5e\ud8b4\udefe\ud954\udcb2\ud99e\udeb5\udb66\ude9c\uda37\udee1\ud8a5\udd0f\uda6c\udc5b\ud9ef\uddd7\ud9c4\udebe\ud888\udd7b\udaf6\uddb5\udb96\udef4\udaa0\udf85\udab4\ude78\udb95\udea0\udb5e\ude46\ud98d\uddcb\ud9c6\udf8b\udbcc\udd85\ud9e8\udfb1\ud8b4\udffe\ud82f\uddb9\u6458\ud949\udeaf\ud803\udf08\uda78\ude00\ud939\udd83\u7b1c",
        10, 57526, 2068360800, -1748154783123999036L, 39052L, true, true, (char) 50479, (char) 55152,
        Double.longBitsToDouble(0x3fe9a858951b3a70L), Double.longBitsToDouble(0x3fe138001d3ec4a1L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a]] |a1=[Ljava.lang.String;:[[\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 8, 1, 5, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a", "\u6719\ub5a4\u29ae\u3728\u64ab\u415d\uc74b\u9724", "\uda3e\uded4\uda73\udf80\uda39\udd1c\ud94e\udc50\ud9fe\udfe0",
        58, 78346, 1047932995, -6004901312640633081L, 58545L, true, true, (char) 49248, (char) 18924,
        Double.longBitsToDouble(0x3fe1a4b8b62fad58L), Double.longBitsToDouble(0x3fc1878142156068L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 8, "\udaf6\udd3e\ud801\uddfc", "\u0338\u59d0\u3ae9\ud3e4\ub5f0\u346d", "\udb77\udf85\uca01\ud8ff\udc03\ud823\udeb7",
        45, 10040, -942366914, -1422494529668172773L, -90199L, false, true, (char) 53427, (char) 1123,
        Double.longBitsToDouble(0x3feed6749a751561L), Double.longBitsToDouble(0x3f926362597eb220L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 6, "\uda11\udfce\ud801\uddfc\ud937\udeed\uda79\udcbf\ud9ba\ude87\udac6\udecf\ud9af\ude5b\ud9ad\udf9c\ud9c8\ude95\uda8f\ude94\ud959\udfe5\udb53\ude95\udbdd\udd02\ud8bb\udc1b\ud8c7\udd3d\ud823\ude77\uda69\ude48\udb56\udd9c\uda48\udfee\ud87f\udf99\udbc3\udd56\udadb\udf0f\ud920\udd32\ud8fb\udeaa\ud826\udfa9\ud849\udf1b\uda39\udd1c\ud94e\udc50\uda7a\udf74\udada\udcf8", "\u2fab\u4d8d\u8f4c\u8b8f\u63ad", "\ud917\udc1b\ud858\udc22\udb5c\udcf5\ud8cd\uddc9\udbda\udd4f\ud90c\ude23\ud87e\udfbf\ud897\udff5\ud9c0\udd59\ud977\udcff\ud89a\udd32\ud8a0\udf45\ud8f8\udc72\udb67\udf3e\uda2c\udf3c\ud86d\ude0b\ud810\udf08\udb0f\udf3d\ud8ed\udc36\ud9d9\udc7f\uda2a\udf5b\u5935\ud8a9\ude70",
        0, 89958, 475444742, 4676398167226573290L, 73897L, true, true, (char) 26109, (char) 64754,
        Double.longBitsToDouble(0x3fe092173134d99eL), Double.longBitsToDouble(0x3feb91b8e8d69d33L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udaf6\udd3e\udb20\udc26\ud91e\udeec\udbad\ude78\udaf3\udcf1]] |a1=[Ljava.lang.String;:[[\udaf6\udd3e\udb20\udc26\ud91e\udeec\udbad\ude78\udaf3\udcf1]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 2, "\udaf6\udd3e\udb20\udc26\ud91e\udeec\udbad\ude78\udaf3\udcf1", "\ucb30\u5aa5\uabb6\u714d\u344a\ud1c7\ubf81\u2127\u6dcc\ua47a\u7ce3\u64ab\u68fb\uc529", "\ud8df\udf44\ud9e5\udc67\ud93a\udc57\udbec\ude2c\ud83d\ude0c\ud846\udf5e\udbc5\udf2b\uda33\udc27\ud80b\udd08\ud8ba\udf68\ud967\udfd3\udac6\udc9f\ud8f5\udfd9\uda5f\udd8a\ud92c\udc5c\udb78\udcba\ud8b3\udf28\uda23\udf88\udb7e\udc55\ud899\uddcf",
        2, 30239, 1477123212, -3598146832820895461L, -10732L, false, true, (char) 52427, (char) 26205,
        Double.longBitsToDouble(0x3fdb94a506afccb0L), Double.longBitsToDouble(0x3fd8fde9163a670cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 0, "", "", "\ud98f\uddc9\udbfd\udeeb\000\ud969\udd73\ud9c8\ude95\uda8f\ude94",
        29, 2466, -1574919135, -7970506436845527986L, -50035L, false, false, (char) 5584, (char) 4248,
        Double.longBitsToDouble(0x3f9bec42dc420620L), Double.longBitsToDouble(0x3fdb786b8f4c9b26L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 1, 8, 4, "\uda51\udcdf\u3709\ud880\udec2\ud92a\udc36\ud95c\udfb3\udbff\ude25\ud9f4\ude11\udbff\ude51\udbc1\udc1a\uda35\uddcf\u1bd7\ud875\udc2a", "\u6a2b\ub5a4\u29ae\uaecb\u608c\u7b38\u6ea7\ub8ba", "\ud886\uddec\uda8c\udc65\udb5b\udc17\ud875\udcfb\uda76\udd7c",
        16, 25427, 1131687235, 922571590400890533L, 88248L, true, true, (char) 30070, (char) 47382,
        Double.longBitsToDouble(0x3fe8da3ef716f989L), Double.longBitsToDouble(0x3fcde22c63e3a75cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 2, "\ud82c\udf5a\ud801\uddfc\ud835\udeec\udbad\ude78\ud836\udcfc\u2bb2\ud818\udd1b\udaae\udd13\ud9c8\ude95\uda8f\ude94\udb15\udfa6\uda34\udc8a\uda38\ude49\udae4\udc30\ud8c7\udd59\ud881\uddb4\ud83f\uddfd\ud86f\udddb\ud97b\udfb6", "\u24e0\u05bb\u44ef\ucf2b\u285f\u7d31\u583f", "\udbf1\uddc3\udb97\udcc9\ud9dd\udd3d\udbe7\udeff\udae0\udfa7",
        52, 20697, -1084779073, -7071072242300017868L, -55267L, false, true, (char) 29002, (char) 34111,
        Double.longBitsToDouble(0x3fce72ba81e5b900L), Double.longBitsToDouble(0x3fe7af3834dd0810L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\ude57\udbc2\udd52\ud9df\udc70\udba9\udfdf\uda8f\ude94\udb26\udd86\ud875\udc2a]] |a1=[Ljava.lang.String;:[[\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\ude57\udbc2\udd52\ud9df\udc70\udba9\udfdf\uda8f\ude94\udb26\udd86\ud875\udc2a]] |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\ude57\udbc2\udd52\ud9df\udc70\udba9\udfdf\uda8f\ude94\udb26\udd86\ud875\udc2a]] |a1=[Ljava.lang.String;:[[\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\ude57\udbc2\udd52\ud9df\udc70\udba9\udfdf\uda8f\ude94\udb26\udd86\ud875\udc2a]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 8, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\ude57\udbc2\udd52\ud9df\udc70\udba9\udfdf\uda8f\ude94\udb26\udd86\ud875\udc2a", "\uc261\u576c\uc0fa\u108d\u1d5c\u0c47\u46da\ud607\u76fc", "\udbea\ude30\uda39\udd1c\ud8d5\ude14\uda7a\udf74\udb3d\ude90\udbf1\uddc3\ud82b\uded2",
        59, 70308, -862711062, 1839074968305876385L, -10188L, false, true, (char) 36502, (char) 3623,
        Double.longBitsToDouble(0x3fec8c363a34976cL), Double.longBitsToDouble(0x3fe0569ac08c3cedL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 7, "\u00ab", "", "\udac9\ude00",
        25, 44644, 477606120, -6631088652120913819L, 41908L, false, false, (char) 11827, (char) 24926,
        Double.longBitsToDouble(0x3fd2d5b9cb406978L), Double.longBitsToDouble(0x3fe9f3b428c3c7d4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "", "\u7803", "\udac9\ude00",
        9, -1000, 477560832, 4617207808L, 41908L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e14069780000000L), Double.longBitsToDouble(0x3faf00000c300000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 2, "\uda84\udcff\ud801\udde9\ufe0c\udbb1\udeb4\ud84b\udce7\udac9\ude00\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\udbd6\udfdb\uda54\uddd8\udb89\udc22\ud8c7\udd3d\ud823\udee9\uda58\udc48\ud805\udc9c\uda48\udfee\ud90b\ude7e\ud934\udd03\ud9ed\udc1c\ud86b\udc8e\ud8b0\udc41\uda3e\uded4\uda73\udf80\uda39\udd1c\ud94e\udc50\u1f46\udb2f\ude3c\ud865\udcdd\ud973\udffe\uda35\ude73\ud91a\udcc6\udbf4\uddc4\udba2\udc5f\udbfa\udc15\ud990\udfb0\uda01\udc0c\udb55\udef3\udbdb\uddce\ud852\udc34\udb31\udeed\u1528\ud84a\udd77\uda8b\udce0\udba4\udf5e\udb17\uddbf\udbef\udda4\ud95e\ude76\ud867\udd2c\ud881\ude13\ud816\udfec\ud9b4\uddb4\udb1b\udfaf\udaf5\udce4\udaf5\udfa8\udb00\udf5e\udb45\udd9d\ud82d\uddf6\ud97d\udfef", "\u3190\u5339\ud28d\u9892\u6c33\uc8d9\u084b", "\uda31\udc8c\ud984\udeba\udb40\udeb0\ud89c\udf99\ud9df\ude13\uda26\udff0\udb44\udce5\ud86a\udec2\udb34\udd04\ud818\udc33\uda9e\uddb2\ud854\udda8\ud872\udd72\ud977\udefb\udb40\udeef\ucad2\ud8ac\udf55\ud941\uddea\ud81f\ude93\ud843\udf0c\ud838\udfec\ud948\udcaf\ud94d\udfc3\ud9b9\udf6a\uda7c\udf16\ud8cc\udcc0\ud871\udc05\ud970\udf19\uda60\udd29\ud8d5\udcb5\ud92b\udef9\uda55\udd6a\udaeb\udf4c\uda14\udc91\udb7d\udc65\udbe6\udffc\uda6d\udc36\ud94e\udf23\ud9c5\udfb8\uda09\udf86\ud889\ude90\ud8de\ude65\ud90b\udcda\ud9a5\udfeb\udb9c\ude83\ud929\ude31\uda10\udc73\ud8a2\udc70\udb4e\udecc\udb80\udc42\uda7f\udf03\udb0d\ude26\udaac\udd34\uda9b\udedb\ud8c2\uddf0\udad8\ude95\uda0c\udcf6\ud92f\uddf6\ud9f1\udc83\ua680\ud968\udd78\ud93f\udc95\ud890\udd44\ud848\udeda\ud94b\udcf2\ud95e\udc16\udb84\udc07\ud83b\udc92\ud8e9\ude02\ud8cb\udd5d\ua756",
        9, 92295, 108789694, -8372939097816349603L, -25447L, true, true, (char) 19235, (char) 52794,
        Double.longBitsToDouble(0x3fd66b2f9e15db86L), Double.longBitsToDouble(0x3fdf928c071704c2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 7, "", "\ubb4a", "\000",
        13, 47236, 0, 3508224L, -100000L, false, false, (char) 11598, (char) 4190,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "", "", "\ud84b\udcaa",
        38, 59311, 8305772, 2017612631518061569L, -100000L, false, false, (char) 0, (char) 11598,
        Double.longBitsToDouble(0x3fc061fb74b40000L), Double.longBitsToDouble(0x3fda034bc07ced0aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 5, "\udb02\udcab", "\u6fde\u3767\u5d4b", "\ud9c8\ude95\udb8d\ude93\udb96\udcd9\ud891\udc57\udb17\ude98\ud8bb\udc1b\ud8c7\udd3d\ud823\ude77\uda69\ude48",
        40, 63086, -331200317, 1166771066999723746L, 86278L, true, false, (char) 27312, (char) 6192,
        Double.longBitsToDouble(0x3fef47f494126362L), Double.longBitsToDouble(0x3fe65fac8c42b844L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 2, "\uda84\udcff\ud801\udde9\ufe0c\udbb1\udeb4\ud84b\udce7\udac9\ude00\udbdd\udcec\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\udbd6\udfdb\uda54\uddd8\udb89\udc22\ud8c7\udd3d\ud823\udee9\uda58\udc48\ud805\udc9c\uda48\udfee\ud90b\ude7e\ud934\udd03\ud9ed\udc1c\ud86b\udc8e\ud8b0\udc41\uda3e\uded4\uda73\udf80\uda39\udd1c\ud94e\udc50\u1f46\udb2f\ude3c\ud865\udcdd\ud973\udffe\uda35\ude73\ud91a\udcc6\udbf4\uddc4\udba2\udc5f\udbfa\udc15\ud990\udfb0\uda01\udc0c\udb55\udef3\udbdb\uddce\ud852\udc34\udb31\udeed\udbd4\udc26\ud84a\udd77\uda8b\udce0\udba4\udf5e\udb17\uddbf\udbef\udda4\ud95e\ude76\ud867\udd2c\ud881\ude13\ud816\udfec\ud9b4\uddb4\udb1b\udfaf\udaf5\udce4\udaf5\udfa8\udb00\udf5e\udb45\udd9d\ud82d\uddf6\ud97d\udfef", "\u3190\u5339\ud28d\u9892\u6c33\uc8d9\u084b", "\uda31\udc8c\ud984\udeba\udb40\udeb0\ud89c\udf99\ud9df\ude13\uda26\udff0\udb44\udce5\ud86a\udec2\udb34\udd04\ud818\udc33\uda9e\uddb2\ud854\udda8\ud872\udd72\ud977\udefb\udb40\udeef\ucad2\ud8ac\udf55\uda31\udd29\ud81f\ude09\ud843\udf0c\ud838\udfec\ud948\udcaf\ud94d\udfc3\ud9b9\udf6a\uda7c\udf16\ud8cc\udcc0\ud871\udc05\ud970\udf19\uda60\udd29\ud8d5\udcb5\udb6f\ude7c\uc5b0\udaeb\udf4c\uda14\udc91\udb7d\udc65\udbe6\udffc\uda6d\udc36\ud94e\udf23\ud9c5\udfb8\uda09\udf86\ud889\ude90\ud8de\ude65\ud90b\udcda\ud9a5\udfeb\udb9c\ude83\ud929\ude31\uda10\udc73\ud8a2\udc70\udb4e\udecc\udb80\udc42\uda7f\udf03\udb0d\ude26\udaac\udd34\uda9b\udedb\ud8c2\uddf0\udad8\ude95\uda0c\udcf6\ud92f\uddf6\ud9f1\udc83\ua680\ud968\udd78\ud93f\udc95\ud890\udd44\ud848\udeda\ud94b\udcf2\udb1d\udcf6\udaae\uddf0\ud837\udd15\uda7d\udda7\udb0f\udf8f\udb45\udd40",
        4, 92295, 108789694, -8372939097816349603L, -25447L, true, true, (char) 19235, (char) 52794,
        Double.longBitsToDouble(0x3fd66b2f9e15db86L), Double.longBitsToDouble(0x3fdf928c071704c2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 8, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udbad\ude78\ud98f\uddc9\udac6\udecf\uda2f\udcf5\ud998\udddf\ud9c8\ude95\uda8f\ude94\udb26\udd86\ud875\udc2a", "\u6719\ub5a4\u29ae\u3728\u64ab\u415d\uc74b\u9724", "\uda3e\uded4\uda73\udf80\uda39\udd1c\ud94e\udc50\uda7a\udf74",
        16, 36449, 1047932995, -6004901291165796601L, 87596L, false, true, (char) 49248, (char) 18924,
        Double.longBitsToDouble(0x3fe1a4b8b62fad58L), Double.longBitsToDouble(0x3fec61e05676c7d9L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 8, "\udaf6\udd3e\ud801\uddfc\ud937\udeed\udada\udeef\000\udac8\udfe3\udbdd\udcec\ud998\udddf\ud9c8\ude95\001\udb04\udd21\ud875\udc2a", "\u6719\u6a52\u29ae\u9bda\u64ab\u415d\uc74b\u9724", "\ud860\udf2f\uda98\udcd0\uda39\udd1c\ucffc\ue853",
        53, 66793, 1056190531, 47936726991110144L, -7929L, true, false, (char) 39588, (char) 13051,
        Double.longBitsToDouble(0x3fbf9e2f22240b20L), Double.longBitsToDouble(0x3fef9d03f201765cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processArgs|org.apache.commons.cli.Option,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processOption|java.lang.String,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
