package org.apache.commons.cli2;
import org.junit.Test;
import static org.junit.Assert.*;
public class Option_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 15, 6, "\uda71\uddca\ud833\udde2\ud851\udf6b\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07", "\u5aa1\u9151", "\ud922\udf00\u0c88\ud8a6\uddc3",
        32, 42328, 1700481396, -648564796668075045L, 68546L, false, false, (char) 23792, (char) 1764,
        Double.longBitsToDouble(0x3fc5cec867144e30L), Double.longBitsToDouble(0x3fc82c6ad777fb28L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 8, 13, "\udaad\udfde\uda64\ude98\ud9fa\ude50\ud9db\udd42\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07\udb51\udfa5\uda2a\udf4c\ud80d\udf82\udb9f\udd50\ud806\udc03\uda7f\udcb1\udae8\udccc\ud951\udcbe\ud8a6\uddc3\uda5f\udcaa\ud8e0\udcfe\ud847\udf6d\ud9f8\udca1\ud902\uddab\udac3\uddbd\udac5\udf72\udb7d\ude89\udbac\udfec\ud8af\uddce\udb8e\uddd4", "\u6aa0\uc47a\ub78c\u48b3\u9792\u1362\ubf33\u4d5d\u6491\u11e7\u28c8\u7f62\u3ca2\u25b3\u8b64\u9c00\ub4ff\ub4dc", "\ud942\uddc9\ud96f\udf4b",
        51, 86124, -52042859, 6748521585399818273L, -13129L, false, true, (char) 31632, (char) 56765,
        Double.longBitsToDouble(0x3fd4422fcc8f52daL), Double.longBitsToDouble(0x3fcb06a389bafc18L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 15, 6, "\uda71\uddca\ud833\udde2\ud851\udf6b\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07", "\u70c4\u4cc3", "\ud922\udf00\u0c88\ud8a6\uddc3\uda5f\udc57",
        8, 44396, -151005759, -1097009298668345519L, 47909L, true, false, (char) 31912, (char) 5070,
        Double.longBitsToDouble(0x3fb9d29a4bdaa1d0L), Double.longBitsToDouble(0x3fe05b6ab1c40b18L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:Passes properties and values to the application |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 9, 15, 6, "\uda71\uddca\ud833\udde2\ud851\udf6b\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07", "\u74fc\u207b", "\ud922\udf00\u0c88\ud9ae\udc72",
        55, 42328, 1700481396, -648564796668075045L, 68546L, false, false, (char) 23792, (char) 1764,
        Double.longBitsToDouble(0x3fc5cec87b144e30L), Double.longBitsToDouble(0x3fc82c745777fb28L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 15, 6, "\ud947\udc63\ud833\uddaa\ud851\udf6b\ud869\udf43\ud874\udfd5\udadd\ude25\ud93e\ude7d\ud8e0\udc07\udb51\udfa5", "\u9151\u66bb\u6620\u86b1\ubd80\u2bd8", "\ud847\udf6d\ud8a7\udd39\ud91e\udef5\ud90d\uddc2\ud87e\uddce",
        42, 22473, 1984163542, 1408501532451029445L, -1149L, true, true, (char) 30694, (char) 57947,
        Double.longBitsToDouble(0x3fc21654748749dcL), Double.longBitsToDouble(0x3fe30ef96fe0801fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 8, 15, 14, "\uda71\uddca\ud9df\udd78\ud851\udf6b\uda7a\udf2a", "\u90d7\u5f54\u0912\uc9af\uac8b\u8149\u9d0d\u6620\u2c74\uc4d8\u2bd8\ud302\u7060\uc194\u1316\u421c", "\uda5e\udfb7\ud8c8\udebd\ud8af\uddce\ud8ca\uddd2\uda87\udf9f\udae0\udc2a\ud9e6\udc57\ud842\udfdb\ud906\udc59\udb8c\udf90\udbd1\udd35",
        22, 91915, 838512631, -4343339410024773653L, -37552L, true, true, (char) 19986, (char) 26848,
        Double.longBitsToDouble(0x3fe0ec74822e3548L), Double.longBitsToDouble(0x3fe43a47b8230f29L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 15, 6, "\uda71\uddca\ud833\udde2\ud851\udf6b\ud869\udf43\ud99e\udf2b\udadd\udebc", "\u7a11\u676d", "\udbeb\udda3",
        14, 69852, 1315573737, 1156863053684481581L, -53268L, true, true, (char) 39642, (char) 38935,
        Double.longBitsToDouble(0x3fd9ee592d800822L), Double.longBitsToDouble(0x3fe48cf2fed6180eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 9, 5, "\uda71\uddd2\ud8ce\udd10\uda4f\ude6a\ud89b\udd0c\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07", "\u5aa1\u9151", "\ud922\udf00\u0c88\ud9c6\ude74\ud861\ude91\ud8c7\udef2\uda9f\udc3a\ud8a7\udd09\ud91e\udef5",
        27, 75038, -1637882176, 1733532438547918550L, 47909L, true, false, (char) 31912, (char) 46251,
        Double.longBitsToDouble(0x3fe5b3862db4a6a6L), Double.longBitsToDouble(0x3fe165fb5e40524fL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 15, 1, "\udb90\udfec\ud93b\udce6", "\u3554\u1e33\u1c7a\u5589\u7a11\u676d\u5aa1", "\ud90c\udc5f",
        52, 47737, 2046820561, -8808903063182718213L, 11088L, true, true, (char) 58770, (char) 23949,
        Double.longBitsToDouble(0x3fe6b0c074ae7643L), Double.longBitsToDouble(0x3fdc5138c08f9cacL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 5, 15, 6, "\udb68\udcf8\udb08\uddbf\uda03\ude03\ud869\udf43\ud99e\udf2b\uda7d\ude4a\ud92f\udc6b\ud8f9\udc7f", "\u46ff\u68b5\u4c36\u6620\u60a8\u81d9\u2bd8\u3a31\u7060\uc194\u1316\ub1cf\u8ffe\u4270\ud581\ub0e8\u3301\ua7d8\u1781\u0f52\u87df\u55e7", "\uce05\udb08\ude1c\udba9\udcc0\ud8c9\udcec\uda02\uddff\ud930\udcef\uf0f8\u33cc",
        7, 37848, 1340762701, -5642309527823588201L, 57832L, true, true, (char) 21432, (char) 45373,
        Double.longBitsToDouble(0x3f86faf8cb998180L), Double.longBitsToDouble(0x3fed5f6a435addbdL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 15, 6, "\ud891\udcd9\ud9b9\udd83\ud851\udf6b\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07", "\u5aa1\u9151", "\ud922\udf00\u0c88\ud8a6\uddc3",
        32, 59155, 1700506254, -648564796668075045L, 68546L, false, false, (char) 23792, (char) 20708,
        Double.longBitsToDouble(0x3fc5ced647144e30L), Double.longBitsToDouble(0x3fc82c6ad777fb28L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 15, 6, "\uda71\uddca\ud833\udde2\udac6\udfe5\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude72\ud8e0\udc07", "\u5aa1\ucd2b", "\u5684\uda23\uddb8\ud8a6\uddc1\uda5f\udc57\ud8e0\udcfe\ud847\udf6d\ud8a7\udd39\ud91e\udef5\ud90d\uddc2\ud957\udddb\ud878\udcff\udbc5\udffb\ud8af\uddce\udb8e\uddd4\uda87\udf9f\udaf6\udcae\uda1c\udf3b\udafd\udc83\ud879\udef7\ud881\ude80\ud829\udf57\ud982\udc61\udaee\ude3c\ud9bb\udf84\uda44\udc0c\uda82\udc60\ud8af\udd0f\udba7\ude52\udb56\udf27\udbe1\udc74\udad2\udc69\udb35\udef6\udb82\udf0b\uda5e\udf7b\ud900\udc45\udb22\udf68\udaa5\ude5d\ud99a\ude6e\udb44\udce6\udbea\udc8e\udb54\udd7b\udb41\udd24\udafa\udfeb\ud9c0\udd0f\udb85\udf42\ud810\udd86\ud8df\udcfc\udb58\udfe6\u79d2\ud941\udc3d\ud9fc\udff5\ud9c4\udeea\uda85\udcde\udb16\udc27\ud8b5\udc1c",
        31, 5168, 100252178, 8117359167509989564L, -3481L, false, false, (char) 1704, (char) 49497,
        Double.longBitsToDouble(0x3fc165589fce46b8L), Double.longBitsToDouble(0x3fe026a7fc50c0deL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 4, 18, 6, "\uda71\uddca\ud833\udde2\ud851\udf6b\ud869\udf43\uda64\udd6e\ud89d\udfe0\ud8f3\udffa\ud8dd\udf5f", "\u5aa1\u9151", "\ud922\udee9\u0c88\ud8a6\uddc3",
        32, 19616, 1700481442, -648564796672597029L, 68546L, false, false, (char) 23792, (char) 1764,
        Double.longBitsToDouble(0x3fc5cec867144e30L), Double.longBitsToDouble(0x3fc82c6ad777fb28L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 4, 0, "\000", "\u2d70\u6497\u8bc8\ubdae\u92ea\u7a11\000\000\000\ubfea", "",
        14, 86169, 1755520557, -1574911557385893516L, -10875L, true, true, (char) 28062, (char) 60112,
        Double.longBitsToDouble(0x3fe48cf2fed6180eL), Double.longBitsToDouble(0x3fc5cec867144e30L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 15, 6, "\uda71\uddca\ud833\udde2\ud851\udf6b\ud869\udf43\ud99e\udf2b\ud8ee\udca3\ud9d1\udfa5\ud8e0\udc07\udb51\udfa5\uda4e\udf7d\udbac\udf26\udbf5\udd89\udbd3\udf68\uda9c\udf66\ud922\udf00\u0c88", "\u7060", "\ud91e\udef5\ud90d\uddc2\ud957\udddb\ud92d\udc21",
        11, 17542, 327942318, 7191894355937487041L, -51342L, true, true, (char) 27211, (char) 49366,
        Double.longBitsToDouble(0x3fd8c1d2f1145b3aL), Double.longBitsToDouble(0x3fe1451c0e436e94L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 6, 6, "\uda9b\ude7f\ud833\udde2\ud851\udf6b\ud869\udf43\ud99e\udf2b\uda8b\udeb3\ud93e\ude7d\ud8e0\udc07", "\u5aa1\u4e10", "\ud871\ude54\u0c55\ud8a6\uddc3",
        32, 42328, 1700481396, -648564796668075045L, 68546L, false, false, (char) 23792, (char) 1764,
        Double.longBitsToDouble(0x3fdae76433242328L), Double.longBitsToDouble(0x3fc82c761777fb28L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 15, 13, "\ud823\udfa2\ud937\udde4\udb2b\udc78\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc47", "\u5aa1\u9151", "\ud922\udf00\u0c88\ud8a6\uddc3",
        32, 63552, -2056697362, 7461495274795817320L, -95951L, false, false, (char) 23792, (char) 1764,
        Double.longBitsToDouble(0x3fc5cec867144e30L), Double.longBitsToDouble(0x3fc82c6ad777fb28L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 17, 11, 5, "\ud9f3\udcb0\udbee\udecb\ud851\udf80\ud869\udf43", "\u48fa", "\uda2a\udf4c",
        56, 87601, -319183165, 686220741475399932L, 30863L, true, false, (char) 7060, (char) 13209,
        Double.longBitsToDouble(0x3fee0b2adbdb4b23L), Double.longBitsToDouble(0x3fe45ba60d89485aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 15, 6, "\udb66\udd81\udbde\udfe2\udbd9\udc66\ud869\udf43\ud99e\udf2b\udadd\udebc\uda8c\ude84\u05ba", "\u77f6\u73a9", "\ud846\udee1\u0c88\ud8a6\uddc3\ud8c1\udf58\ud8e0\udcfe\ud84c\ude6d\ud8a7\udd39\ud91e\udef5\udafd\udf1a",
        12, 22635, -2147361391, -8045684161353351135L, 89659L, true, true, (char) 746, (char) 33570,
        Double.longBitsToDouble(0x3fdf6492455117f4L), Double.longBitsToDouble(0x3fcc6ab6e8df68f8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:-D |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 12, 15, 6, "\uda71\uddca\ud833\udde2\ud851\udf6b\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud809\ude5d", "\u1c56\u3a52\u8836\u6620\u64a1\uc4d8\u2bd8\u3a31\ubba2\uc194\u330a", "\ud957\udddb\ud878\udcff\udbc5\udffb",
        57, 95318, 1666597317, -87142062597767715L, -33370L, false, false, (char) 10821, (char) 41419,
        Double.longBitsToDouble(0x3fec3499654e20cfL), Double.longBitsToDouble(0x3fe68cb3430c67bfL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 16, 0, "\uda71\uddca\ud833\udde2\ud80a\udfd0\ud869\udf43\ud944\udd3d\ud9ec\udca5\ud8d0\uddab\ud8e0\udc07", "\u5aa1\u9151", "\u24d4\uda76\ude8d\ud8c3\udf1b",
        32, 42328, 1700481396, -648564796668075045L, 68546L, false, false, (char) 55223, (char) 42269,
        Double.longBitsToDouble(0x3fec3bb94a24adadL), Double.longBitsToDouble(0x3fc82fcb7774b728L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.util.Collections$SingletonSet:[-D] |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 7, 14, 0, "\ud921\udc32\ud8df\udf1f\ud851\udf6b\udbdc\udda6\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07\udb73\udeb7\uda2a\udf4c\udba5\udeec\ud822\udea0\uda7d\udc0c\udace\udff7\udb89\udefb\u0c88\ud87f\udeef\ud822\ude17\udbb1\udcd8\ud847\udf6d\ud8d1\udd2e\ud804\udc03\ud833\udcd6\ud974\udf75\ud878\udcff\udbc5\udffb\ud8af\uddce\udb8e\uddd4\uda87\udf9f\udaf6\udcae\udb17\udd58\ud988\uddb4\udbf4\udeed\udbb0\udc71\ud8ca\udc12\ud8d7\udfb8\udb51\udfba\uda01\udd47\udbf2\ude3a", "\u3ac4\u828e\u4b08\ud7b8\ua6cd\uc0a8\u939e\u164f\ud503\u4819\ua067\u6fae\u6d87\u422c\ubbb4\uc432\uac63\u66f1\u5533\u7ec0\u364a\u7022", "\uda44\udd1d\uda4c\udc00\ud946\udf8a\uda23\udf73\ud811\udc61\udbaf\udfcf\udb0f\uddcb\ud9f3\uddfb\ud8b8\udddd\ud95b\uddbb\u4222\udaef\udd9d\ud8e3\ude36\ud98f\udc0b\udb10\udd15\ue717\uda71\udde7\ud8c3\udc6c\ud9d2\uded8\ud891\udecc\uda98\udf36\ud9f3\udc1e",
        49, 58396, 658452723, -275702430123364174L, -50713L, true, true, (char) 37776, (char) 521,
        Double.longBitsToDouble(0x3febd4b218746415L), Double.longBitsToDouble(0x3fe3c53fa7a2fb15L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 5, 2, 6, "\uda71\uddca\ud839\udc46\ud884\udd89\ud869\udf43\ud99e\udf2b\udadd\udee6\ud93e\ude7d\ud8e1\udfab", "\u5aa1\u02cb", "\ud922\udf00\udb14\udff1\ud8b9\ude36",
        56, 22849, -529991112, -648564795636976755L, 93516L, false, false, (char) 23792, (char) 49892,
        Double.longBitsToDouble(0x3fc5cec8672f3630L), Double.longBitsToDouble(0x3fe6472d8a007068L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 11, 2, 6, "\uda71\uddca\ud833\udde2\ud851\udf6b\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07", "\u5aa1\u04c8", "\ud922\udf00\u0c88\ud8a6\uddc3\uda5f\udc57\ud8e0\udcfe\ud847\udf6d\ud8a7\udd39\ud91e\udef5\ud90d\uddc2\ud957\udddb\udb93\udd38\udbc6\udc14\ud8af\uddce\udb8e\uddd4",
        42, 10657, -1703379491, -8960465602965056631L, 94734L, true, true, (char) 6226, (char) 26375,
        Double.longBitsToDouble(0x3fedfef31eeb5c27L), Double.longBitsToDouble(0x3fed5dfa8ba5c0f3L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 15, 6, "\udbd8\udc19\ud833\ude52\ud851\udf6b\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07", "\u5aa1\ub23a", "\ud922\udf00\u4288\ud8a6\uddc3\ud912\udf50\ud8e0\udcfe\ud847\udefb\ud8a7\udd39\ud91e\udef5\udac2\udffd\udb56\uddb1\uda35\udf9a\udbc5\udffb\ud8af\uddce\udb8e\uddd4\udbd2\udd05\ud913\udee4\ud882\udd8e\ud972\udf87\udb26\udd5c\ud96e\udf25\ud801\ude6e\ud81b\udfab\ud9c4\udca8\udbc4\udc5d\udbe2\uddc4\udbe9\udcf7\udb49\udd29\ud81f\udfbb\udbb7\ude3f\udb85\udf41\udbb9\udfcf\ud992\udd64\udbb4\udd12\ud80a\udf94\udbe1\udc3d\ud86d\udf24\ud9ef\ude1f\ud9d0\uddbe\ud8f5\udd40\udabb\uddab\ud934\udddf\ud95c\uddb6\uda97\udd82\uda87\udd5e\uda7d\ude39\udabd\uded4\uda6b\udcab\ud8d2\udcbf\udb70\ude49\udb39\udd86\udb3d\udf2b\ud996\ude7f\ud999\udeb8\ud9cd\udeca\udaee\udd68\udb2a\udc57",
        46, 13991, -1172385742, 5628076978686435769L, 60554L, false, false, (char) 9783, (char) 60547,
        Double.longBitsToDouble(0x3fbe365dd01f2af8L), Double.longBitsToDouble(0x3fd357dab4df769aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:Passes properties and values to the application |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 9, 0, 6, "\uda71\uddca", "\u00a3\000\000\000\000\000\000\000\000\u8773", "\000",
        9, 30832, -366687672, 7303511983125364736L, 73905L, false, true, (char) 60112, (char) 23792,
        Double.longBitsToDouble(0x3fe6b0c070ae7643L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.util.Collections$SingletonSet:[-D] |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.lang.Integer:68 |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 14, 10, 5, "\udbe8\udce0\ud9d2\udcd2\ud97c\udcea\ud8a1\uddb2\udac4\ude01\udb96\udf7a\ud93e\ude7d\ud864\udccd\ud80c\ude48", "\u8b9c\u819d\u1cd5\ua7c1\uc449\u1e84\u5515", "\uda66\udd68\udb69\uddd6\ud93d\udf51\uda12\udf22\udbfe\ude87",
        -3, 14720, -2076343056, 2786929309699982900L, -99998L, true, true, (char) 52610, (char) 21325,
        Double.longBitsToDouble(0x3fb334188e41ecf0L), Double.longBitsToDouble(0x3fb92d3d50dcafa0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.Collections$SingletonSet:[-D] |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 14, 14, 11, "\udb59\ude89\ud87e\udc86", "\u3df0", "\ud9c8\udf3d\udb2a\udc61\uda2a\udf4c\ua2bb\ud88a\ude62\ud8b4\udc83\ud95f\ude64\ud9e0\uddb1\ud95c\uddae\udbb7\udc60",
        52, 74504, -569522316, 4341613191790276035L, -39058L, true, false, (char) 53744, (char) 34987,
        Double.longBitsToDouble(0x3feb7c90fe586adcL), Double.longBitsToDouble(0x3fe5fd8ffd150e02L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:68 |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 10, 17, 4, "\ud945\udef3\udabd\udde7\uda1a\uddde\u4c97\ud8fd\udddf\ud841\uddd9\ud93e\ude57\ud89f\ude6b", "\u9c61\u2e1b\u8836\uc6cd", "\ud8a6\uddc3\udbcd\udd51\ud92f\udec6\udbd3\udf60\ud90d\udf61\uda4f\uddfa\ud919\udef9\ud957\udddb\ud878\udcff\udbc5\udffb\ud8af\uddce\ud960\uddfe\ud8a9\udd9a\udb20\udc03\udaad\udc43\ud91d\udca5\ua72d\ud8b5\udf77\udb5f\ude0a\ud932\udf64",
        29, 47659, 188634799, 2059286142809240241L, -38144L, false, false, (char) 9948, (char) 22044,
        Double.longBitsToDouble(0x3fcc56e9b74bb13cL), Double.longBitsToDouble(0x3faef19c0f94ee10L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:Passes properties and values to the application |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 9, 0, 1, "\uda71\uddca", "\u5fcc", "\ud93e\ude7d",
        34, 49726, -1964441600, 4331683706886115577L, -34464L, false, false, (char) 4073, (char) 20074,
        Double.longBitsToDouble(0x3e30000000000000L), Double.longBitsToDouble(0x3fd740000000cab6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 5, 8, 13, "\udaad\udfde\uda64\ude98\ud9fa\ude50\ud9db\udd42\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07\udb51\udfa5\uda2a\udf4c\ud80d\udf82\udb9f\udd50\ud806\udc03\uda7f\udcb1\udae8\udccc\ud951\udcbe\ud8a6\uddc3\uda5f\udcaa\ud8e0\udcfe\ud847\udf6d\ud9f8\udca1\ud902\uddab\udac3\uddbd\udac5\udf72\udb7d\ude89\udbac\udfec\ud832\udc55\udb8e\uddd4", "\u6aa0\uc47a\ub78c\u48b3\u9792\u1362\ubf33\u4d5d\u6491\u11e7\u28c8\u7f62\u3ca2\u25b3\u8b64\u9c00\ub4ff\ub4dc", "\ud942\uddc9\ud96f\udf4b",
        51, 86124, -52042859, 6748521585399818273L, -44287L, false, true, (char) 23940, (char) 56765,
        Double.longBitsToDouble(0x3fb5b3bab23d4e80L), Double.longBitsToDouble(0x3fcb06a389bafc18L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 4, 13, "\udaad\udfde\uda64\ude98\ud9fa\ude50\ud9db\udd42\u8139\udb0a\udcbe\ud93e\ude9b\ud8e0\udc07\udb51\udfa5\uda2a\udf4c\ud80d\udf82\udb9f\udd50\ud806\udc03\uda7f\udcb1\udae8\udccc\ud951\udcbe\ud8a6\uddc3\uda5f\udcaa\ud8e0\udcfe\ud847\udf6d\ud9f8\udca1\ud902\uddab\udac3\uddbd\udac5\udf72\udb7d\ude89\udbac\udfec\ud8af\uddce\udb8e\uddd4", "\u6aa0\uc47a\ub78c\u48b3\u9792\u1362\ubf33\u4d5d\u6491\u11e7\u28c8\u7f62\u3ca2\u25b3\u8b64\u9c00\ub4ff\ub4dc", "\ud942\uddc9\ud96f\udf4b",
        51, 86124, -52042859, 6748521585399818273L, -13129L, false, true, (char) 31632, (char) 56765,
        Double.longBitsToDouble(0x3fd4422fcc8f52daL), Double.longBitsToDouble(0x3fcb06a389bafe28L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 8, 13, "\udaad\udfde\uda64\ude98\ud9fa\ude50\ud9db\udd42\ud99e\udf2b\ud800\uddcd\uda2a\udf5b\udbc1\udc6f\udb51\udfa5\uda2a\udf4c\ud80d\udf82\udb9f\udd50\ud806\udc03\uda7f\udcb1\udae8\udccc\ud951\udcbe\ud8a6\uddc3\uda5f\udcaa\ud8e0\udcfe\ud847\udf6d\ud9f8\udca1\ud902\uddab\udac3\uddbd\udac5\udf72\udb7d\ude89\udbac\udfec\ud8af\uddce\ud97b\udf0b", "\u6aa0\uc47a\ub78c\u48b3\u9792\u1362\ubf33\u4d5d\u6491\u11e7\u28c8\u7f62\u3ca2\u25b3\u8b64\u9c00\ub4ff\ub4dc\u76c9\u934b\u7ce7\ubbf8\ub3c8", "\udbaf\ude24\udbc7\udec6\udace\udd04\ud8e7\ude27\ud8b5\udc56\ud913\ude96\udb3d\udcee\udbb1\udc29\ud904\udd68\udaec\udd03\uda05\udc15\uda78\uddec\ud880\udd4c\uda04\udf57\ud873\udc9b\udba5\udc01\udb4d\udd0d\u4bf4\udb63\ude40\udbbd\udeea\uda7f\uddf9\udbaf\ude03\udb45\udf1d\ud966\ude16\ud859\udfc5\ud825\udc2f\ud870\ude54\ud98e\udd3a\ud94d\udfa8\udabb\udf6b\u5b7b\ud9e7\udd85\ud917\udfe6\ud8e3\udc71\ud9b0\udf83\ud971\ude01\ud833\udd6f\udb42\uddbb",
        40, 26831, -2112274321, 6177187230473135920L, 13328L, true, true, (char) 35011, (char) 8694,
        Double.longBitsToDouble(0x3fe060a65d633d39L), Double.longBitsToDouble(0x3fe69c416cdfec81L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:68 |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 10, 17, 13, "\udaad\udfde\uda64\ude98\ud9fa\ude50\ud9db\udd42\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07\udb51\udfa5\uda2a\udf4c\ud80d\udf82\udb9f\udd50", "\u5b31\u0dc7\u51d1\ua507\u3732\uc194\u2880\u4085\u2fa2\u6270", "\ud8af\uddce\udb8e\uddd4\uda87\udf9f",
        12, 94801, -744165107, 3672988013698153159L, -68533L, true, false, (char) 1669, (char) 64360,
        Double.longBitsToDouble(0x3fe1b8e7e4513c7cL), Double.longBitsToDouble(0x3fcd5ec898f9e154L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 8, 8, 13, "\uda8e\udede\uda64\ude98\ud9fa\ude50\ud85d\udd18\ud99e\udf2b\udadd\udebc\udabe\ude7d\ud8e0\udc07\udb51\udfa5\uda2a\udf4c\ud80d\udf82\udb9f\udd50\ud806\udc03\uda7f\udcb1\uf9c0\ud834\ude14\ud8a6\udcf4", "\uc194\u2880", "\udac5\udf72\udb7d\ude89\udbac\udfec",
        12, 33646, -1477471263, -87194326532094455L, 91709L, true, false, (char) 261, (char) 64852,
        Double.longBitsToDouble(0x3fce17997948c344L), Double.longBitsToDouble(0x3fe1be498a371cfcL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 8, 13, "", "\uc3d8", "",
        17, 34448, 1949739310, 7832324065785930291L, -75411L, false, true, (char) 59575, (char) 41294,
        Double.longBitsToDouble(0x3fde933381a3d868L), Double.longBitsToDouble(0x3fe40080724868a3L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 5, 5, 13, "\uda6d\udfde\uda64\ude98\ud9fa\ude50\ud977\udcaf\ud8b8\ude58\udabb\udc64\ud970\ude76\ud8e0\udc07\udb51\udfa5\uda2a\udf4c\ud80d\udf82\udb9f\udd50\ud806\udc03\uda7f\udcb1\ud982\udf39\ud840\udf6a\ud8ab\udc26\uda5f\udcaa\ud8e0\udcfe\ud9ca\udc61\udaf5\ude9b\udbd8\udf71\udac3\uddbd\udac5\udf72\udb8f\udc89\ud8db\ude03\uda22\udc3a\ud846\udc6f", "\u2cc8\u5264\ube06\u381b\u946d\u1362\u16ab\u517d\u6481\u11e7\u28c8\u7f62\u3ca2\u402d\u6b15\u9c9d\ub4ff\u8d43\uc89c\u2748\u7c03\uad9f\u8c1b\u1ff3", "\udbc7\udec6\uda76\ude58\ud884\udcbc\udace\udec1\ud8f9\udc00\udb3d\udcee\udbb1\udc29\ud904\udd68\udaec\udd03\ud95c\udc1d\udacb\udd87\ud95a\udd60\ud84b\ude87\ud948\udfa0\uda3f\udfe5\ud98e\ude9c\ud885\udd55\ud9e7\udf4b\ud86a\udd6f\uda87\ude20\uda38\udc1a\ud9a5\udc4c\udba6\ude57\udace\ude67\ud8d4\udd3a\ud8c0\udfa4\ud864\udea3\ud970\udcb3\uda56\uddea\ud8a2\ude7d\udb86\uddaa",
        -1, 6957, 1225070795, 5146456057576171604L, -30124L, true, true, (char) 30620, (char) 26647,
        Double.longBitsToDouble(0x3fce5e1873a50390L), Double.longBitsToDouble(0x3fd5ad26e46d5a9aL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.lang.String:Passes properties and values to the application |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 11, 9, 5, "\uda71\uddd2\ud8ce\udd10\uda4f\ude6a\ud89b\udd0c\ud99e\udf2b\udadd\udebc\uda01\ude77\ud8e0\udc07", "\u5aa1\u9151", "\ud889\uddf4\u0c2d\ud9c6\ude74\udaea\udc55\ud8c7\udef2\uda9f\udc3a\ud8a7\udd09\ud91e\udef5",
        27, 75038, -1637882176, 1733532438547918550L, 47909L, true, false, (char) 31912, (char) 46251,
        Double.longBitsToDouble(0x3fdfce8a5ba81a5eL), Double.longBitsToDouble(0x3fe165f95e40524fL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 7, 7, 9, "\uda71\uddd2\ud8ce\udd10\uda4f\ude6a\ud89b\udd0c\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc07", "\u5ed2\u9151", "\ud922\udf00\u0c88\ud9c6\ude74\ud861\ude91\u851f\udaa7\udc19\u6f64\u5068",
        49, 75038, -1637882176, 1733532438547918550L, -83163L, true, false, (char) 31912, (char) 46251,
        Double.longBitsToDouble(0x3fe5b3862db4a6a6L), Double.longBitsToDouble(0x3fe165fb5e40524fL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 17, 13, "\ud823\udfa2\ud937\udde4\udb2b\udc78\ud869\udf43\ud99e\udf2b\udadd\udebc\ud93e\ude7d\ud8e0\udc47", "\u5aa1\u3d78", "\uda29\udddb\u33b6\ud8a6\uddc3\uda5f\udc57\ueb6b\uda1e\udeb4\ud89b\udc85\udb94\udc35",
        53, 67703, -1637882176, 5120239355042197206L, 47748L, true, false, (char) 31912, (char) 47149,
        Double.longBitsToDouble(0x3fe09df97b6fd7b1L), Double.longBitsToDouble(0x3fc305867eb00580L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.util.Collections$SingletonSet:[-D] |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 7, 14, 0, "\ud921\udc32\ud8df\udf1f\ud851\udf6b\ud9e8\udc01\ud838\uddb7\uda5c\udcce\ud93e\ude7d\ud821\udc0a\ud3b7\uda2a\udf4c\udabb\udceb\ud822\udea0\uda7d\udc0c\ud9be\ude6f\uda81\udc00\u0c88\ud87f\udeef\ud817\udc17\udbb1\udcd8\ud847\udf6d\ud8d1\udd2e\ud804\udc03\ud833\udcd6\ud974\udf75\ud878\udcff\udbc5\udffb\ud8af\uddf1\udb8e\uddd4\udbce\udde3\udae0\udc90\udb17\udd58\ud988\uddb4\udbf4\udeed\udbb0\udc71\ud8ef\udea3\ud9fe\udf3d\udb51\udfba\ud979\udc83\udbf7\ude15", "\u4b5c\uc2a0\u44cd\u1247\ua8b0\uc0a8\u63d0\u164f\ud503\u4819\ubdec\u2be7\u5247\u91d1\u90bf\u6a09\uac63\u66f1\u1cb0\u5d1f\u6b37\u784c", "\ud953\udf46\uda51\udf76\ud946\udf8a\uda23\udf73\u77a7\ud8e4\udcda\udb0f\ude30\ud813\udf0b\udb0e\udc2f\ud95b\uddbb\u4222\udb00\udc9d\uf563\udadc\udd48\uda55\udf53\u2298\udafb\udeec\ud8c6\udffc\udbdc\ude7d\uda4f\udd37\ud919\uddad\ud9df\udc40\uda64\udfd7\udb96\udd17\ud824\udd43\ud8ee\udde0\udbcf\udcbb\udaf1\udd7d\udbbd\ude53\ud91b\udf9e\ud953\udca0\udb2a\udcf0\udbcd\udd5f\udacc\udf43\udb70\udf37\ud908\udf7f\ud84b\udc38\ud8ef\udc96\ud873\udcb5\udb94\udfbe\uda24\udf73\ud979\ude60\ud9b5\udc46\udb6d\udde5\ud9ab\udcfc\ud892\udd6b\ud8ad\ude6f\u2c33\udb4e\udf6d\uda97\udf2d\ud8f9\udde5\ud8c2\udc04\ud80d\udd07\ud9bd\udf70\ud866\udd86\ud873\udece\udb97\udf1f\ud8b9\udda3\ud8a0\udd74\ud848\udfdc\udb36\udc25\ud807\udff2\udbc6\udc75\udadd\ude14\ud9ee\udfa8\ud8db\udc93\udbf3\udf6e\udaa0\udc62\uda32\udc84\ud9df\udd1f\uda2d\udc85\uda75\udd55\ud8a6\udf8e\uda7b\udfc5\ud81b\udddb\udb8a\ude33\udb06\udd65\udb2e\udcc7\ud96c\udcf8",
        4, 77413, -672362031, -7911163258452571717L, 88006L, true, false, (char) 43880, (char) 42719,
        Double.longBitsToDouble(0x3fcdd061bf4216d4L), Double.longBitsToDouble(0x3fc4ab0d797b6514L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 5, 5, 13, "\uda6d\udfde\uda64\ude98\ud9fa\ude50\ud977\udcaf\ud8b8\ude58\udabb\udc64\ud970\ude76\ud8e0\udc07\ud86b\ude92\ud9d3\udc86\ud80d\udf82\udb9f\udd50\ud806\udc03\uda7f\udcb1", "\u9fab", "\ud9ca\udc61\udaf5\ude9b\udbd8\udf71\udac3\uddbd\udac5\udf72",
        17, 34146, -1237103469, 1385700543429231301L, -17378L, true, false, (char) 50745, (char) 45062,
        Double.longBitsToDouble(0x3fded0064159bdc0L), Double.longBitsToDouble(0x3fe13c6f8a371cfcL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 7, 15, 0, "\udad0\udd05\ud84d\udc4a\ud987\udf66\uda46\udfd0\udb28\udd7a", "\u92ea\u7a11\ua634\u727e\ud335\uaf55\u65e4\u7ca8\u7a90\uc43c\u3a31\u7060", "\ud91e\udef5\ud90d\uddc2\uda76\udf8b\udb50\udd06",
        22, 87669, 828218775, -4136714948211742527L, 17498L, false, true, (char) 63556, (char) 33542,
        Double.longBitsToDouble(0x3fdcea0d5a4fb23aL), Double.longBitsToDouble(0x3fe7ef176052b1d1L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:Passes properties and values to the application |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 1, 9, 15, 6, "\udbca\udd95\udbc4\udd84\ud851\udf6b\ud869\udf43\ud861\ude8b\u5a11\ud93e\ude7d\ud8e0\udc07", "\u74fc\u207b\u87d5\u6b7f\u8ebd", "\ud9a5\udf41\ud8e0\udcfe\ud847\udf6d\ud8a7\udd39\udae3\ude17\udbcc\udfbc\ud957\udddb\ud878\udcff\udbc5\udf95\ud8af\uddce\udb8e\uddd4\ud85f\udca4\udbe7\ude00\uda3b\udec6\udbed\udeea",
        1, 428, 2014171477, -9042771207809159121L, -836L, true, true, (char) 38413, (char) 35005,
        Double.longBitsToDouble(0x3fcef2d9d915afa4L), Double.longBitsToDouble(0x3fd2428838b6d566L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "C|org.apache.commons.cli2.option.GroupImpl|<init>|java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.OptionImpl|getParent||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.option.OptionImpl|setParent|org.apache.commons.cli2.Option|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|appendUsage|java.lang.StringBuffer,java.util.Set,java.util.Comparator|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|canProcess|org.apache.commons.cli2.WriteableCommandLine,java.lang.String|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|canProcess|org.apache.commons.cli2.WriteableCommandLine,java.util.ListIterator|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|defaults|org.apache.commons.cli2.WriteableCommandLine|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|findOption|java.lang.String|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getDescription||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getId||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getParent||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getPreferredName||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getPrefixes||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getTriggers||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|helpLines|int,java.util.Set,java.util.Comparator|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "C|org.apache.commons.cli2.option.GroupImpl|<init>|java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.OptionImpl|getParent||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.option.OptionImpl|setParent|org.apache.commons.cli2.Option|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
