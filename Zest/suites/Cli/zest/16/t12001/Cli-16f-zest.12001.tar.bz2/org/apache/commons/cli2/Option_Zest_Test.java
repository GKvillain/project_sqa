package org.apache.commons.cli2;
import org.junit.Test;
import static org.junit.Assert.*;
public class Option_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 11, 11, 2, "\ud8cd\udd40", "\u3313\u6ec4\u57a6\u4ea9", "\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud986\udc1c\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69",
        49, 14594, 285513807, -1311471878062785742L, -97952L, false, false, (char) 47834, (char) 63768,
        Double.longBitsToDouble(0x3fd4c4420d12ae32L), Double.longBitsToDouble(0x3fe0473e1f9581a8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.util.Collections$SingletonSet:[-D] |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 5, 13, 2, "\ud8cd\udd40", "\u87a4\u6ec4\u57a6", "\u1ac6",
        42, 27583, 785764557, -9037214370699498065L, -24554L, false, true, (char) 28934, (char) 47860,
        Double.longBitsToDouble(0x3fd66bd77b7928beL), Double.longBitsToDouble(0x3fe10229ac9569deL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 2, "\ud8cd\udd40", "\u3313\u6ec4\u57a6\u3278", "\udb1a\udcec\udb2e\udf14\udbc5\udd01\ud956\udf47\ud986\udc37\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\uceaf\udaa2\ude7a",
        50, 50450, 285513807, -1311471878062785742L, -97952L, false, false, (char) 18559, (char) 40170,
        Double.longBitsToDouble(0x3fd4c44d6312ae32L), Double.longBitsToDouble(0x3fe0453faf9581a8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:68 |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.lang.String:-D |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 10, 12, 0, "\ud8cd\udd40", "\u9da8\u2fa8\u57a6\ub97b", "\uda97\udd54\ud83e\ude83\udbc5\udd01\ud956\udf47\ud985\udfe1\uda68\uded9\ud839\uddce\ud95f\udd55\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udaca\udd69\ud9cf\udfe1\ud83f\udd03",
        2, 72158, 2133277490, 1309098268828370944L, 29831L, true, false, (char) 14700, (char) 42402,
        Double.longBitsToDouble(0x3fe0473e1f9581a8L), Double.longBitsToDouble(0x3fe846c9120bdec7L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 11, 11, 2, "\u8a97\udb7e\ude17\ud90d\udc65\u801b\ud9d4\udd3f\ud86d\ude42\uda9d\udd99\ud9fe\udfd0\u1ac6\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud987\udf0e\uda68\uded9\ud90b\udea0\udb74\udce8\ud887\udce2\udb43\udf09\udbce\udcb3\uda17\ude60\udac1\udd69", "\u9f24\uc211\uc9e5\u2b76\u8049\u9b68\u6778\u84e1\u9487\u21cf\u365e", "\ud841\udea7\udbb0\uddaf\udadf\ude9b\udbc4\udd68\ud96e\ude95\ud9c0\udc7c\udbf0\uddbf\uda50\udc23\udb9e\udc36\udb3f\udeb9\uda06\udf4e\ud829\udd60\ud94b\udd0d\ud816\udff6\ud9cb\udf08\uda7b\udc8b\ud90f\udca8\udb6c\udec3\uda60\uddac\ud91a\udfc0\udb10\udcfa",
        0, 49077, 1017612056, -3028274007162540191L, 67023L, false, false, (char) 57527, (char) 27925,
        Double.longBitsToDouble(0x3fe8b4f03ae9c7d5L), Double.longBitsToDouble(0x3fbcec4bf5376068L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 4, 11, 2, "\ud8cd\udd40", "\u3313\u6ec4\u57a6\u4ea9", "\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud986\udc1c\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69",
        49, 14594, 285513807, -1311471878062785742L, -97952L, false, false, (char) 47834, (char) 63768,
        Double.longBitsToDouble(0x3fd4c4420b12ae32L), Double.longBitsToDouble(0x3f800857e5606940L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 11, 11, 2, "\ud92b\udd4f", "\u3313\u6ec4\u57a6\u4ea9", "\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud8b4\udcf7\ud985\udfd7\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab",
        58, 48860, -2036490256, -132635295866455665L, -49618L, true, true, (char) 6698, (char) 33816,
        Double.longBitsToDouble(0x3fcb36c0308d27d8L), Double.longBitsToDouble(0x3fd118520d5f6e3eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 11, 2, "\ud8cd\udd40", "\u3313\u6ec4\u57a6\u4ea9", "\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud986\udc1c\ud964\ude96\uda85\udca0\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69",
        49, 14594, 285513807, -1311471878062785742L, -97952L, false, false, (char) 47834, (char) 63768,
        Double.longBitsToDouble(0x3fd4c4403d12ae32L), Double.longBitsToDouble(0x3fe0473e1f9581a8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.Collections$SingletonSet:[-D] |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 14, 11, 2, "\udb8e\udd37", "\u3313\u6ec4\u57a6\u4ea9\u61b5", "\uda52\udcb1\udbc5\udd01",
        1, 55975, 926991966, -3419362076730716491L, 21584L, false, false, (char) 56859, (char) 15627,
        Double.longBitsToDouble(0x3fb3f985ea308820L), Double.longBitsToDouble(0x3fe02101572a70ddL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 0, 0, "\ud8cd\udd40", "\000\u6e0a\u57a6\u4ea9", "\u3963\000\000\000\u00af\uda37\udcd9\000",
        30, -1000, 0, 55808L, -99760L, false, false, (char) 0, (char) 46847,
        Double.longBitsToDouble(0x3ec98001fc9c0000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 2, "\ud8cd\udd40", "\u3313\u6ec4\u57a6\u4ea9", "\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud986\udc1c\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69",
        49, 14594, 285513807, -1311471878062785742L, -97952L, false, false, (char) 47834, (char) 63768,
        Double.longBitsToDouble(0x3fd4c4420d12ae32L), Double.longBitsToDouble(0x3fe0473e1f9581a8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 11, 11, 4, "\ud8cd\udd40", "\u9676\uc7a8\u046a\uac1b", "\uda61\udc26\ud92e\ude07\udbc5\udd01\ud971\udc0e\ud986\udc1c\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac4\udd69\udb25\udfcc\udaca\udc31\uda28\udf10\ud989\ude33",
        34, 7722, 1069680640, 3982168420387259399L, 85683L, false, false, (char) 33222, (char) 2298,
        Double.longBitsToDouble(0x3fd2c0e46ded7d34L), Double.longBitsToDouble(0x3fe7b70d0d020a68L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 18, 3, 2, "\udaaa\udcd5", "\u3313\u6ec4\u57a6\u4ea9\u61b5\u40a0\ub9f7", "\ud956\udf47\ud986\udc1c\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69",
        49, 14594, 1535547471, -1311589384073037006L, -97952L, false, false, (char) 47834, (char) 47836,
        Double.longBitsToDouble(0x3fdbe9dded12ae32L), Double.longBitsToDouble(0x3fe0473e1f9581a8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 11, 11, 2, "\ud8cd\udd40", "\u3313\u6ec4\u57a6\u4ea9", "\uda2b\udc51\uda52\udcb1\udbc5\udd01",
        1, 55975, -1001273762, -4196013871662694046L, 21584L, false, false, (char) 56859, (char) 29707,
        Double.longBitsToDouble(0x3fb3f985fc9df820L), Double.longBitsToDouble(0x3fe9976e63f3bb27L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 16, 13, "\ud8cd\udd40\ud9cb\ude3f\ud90d\udca4\u801b\ud9d4\udd3f\ud86d\ude4e\ud939\udc18\u9056\u9cd6\ud95d\udc5d\udaa3\udd89\udba4\udf02\uda41\uddcc\ud931\udfec\ud8d5\udc8f\udadd\ude97\ud95f\udd2d", "\ua96f\u010a\u628b", "\udad4\udf08\ud989\ude33\ud90e\udeb0\ud81c\udf03\uda8c\udd05",
        40, 51153, 1142981667, 6276317262077185673L, 39371L, false, true, (char) 62748, (char) 59274,
        Double.longBitsToDouble(0x3fd3e3868c6d0b0eL), Double.longBitsToDouble(0x3fd1dd65f6d3c6ccL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 11, 17, 2, "\ud8cd\udd40", "\u3313\u21fe\u57bf\u4ea9", "\udbc3\ude89\udb00\udf70",
        -3, 91161, -1586451025, -4300438063590059012L, 29626L, true, false, (char) 12032, (char) 3407,
        Double.longBitsToDouble(0x3fe51434eef02f2cL), Double.longBitsToDouble(0x3feb50750851e617L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 11, 11, 0, "\ud83b\udfa7", "\u2955", "\ud90c\ude48",
        37, 16304, -1436153507, 599122241791060603L, -55537L, false, false, (char) 25677, (char) 41367,
        Double.longBitsToDouble(0x3fc03e0855faf180L), Double.longBitsToDouble(0x3fdbcb9435e064beL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 4, 6, 13, "\ud8cd\udd40\udb7e\ude17\ud90d\udc65\u8012\u2fbb\ud86d\ude42\ud91b\udc92\ud9fe\udfd0\u1ac6", "\uc9ee\u0d71\ua0f0\u356e\u450b\u84a8\u2591\u2afb\u4c49", "\ud988\uddc1\u1567\udae8\udd4f\ud989\ude33\ud90e\udeb0\udb12\udfff",
        48, 25887, -1393829193, 2593319216339350860L, -59414L, true, true, (char) 6980, (char) 40000,
        Double.longBitsToDouble(0x3fe8738cd043bd45L), Double.longBitsToDouble(0x3fed339c534a66b2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 11, 2, "\ud8cd\udd40\udb7e\ude17\ud90d\udc65\u801b\ud9d4\udd3f\ud86d\ude42\ud91b\udc92\ud972\udec3\ud925\udfa0\uda2b\udc45\uda52\udcb1\udbc5\udd01\ud956\udf47\ud986\udc1c\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab\u2283\udac3\udf3b\uda80\udd07\udac1\udd69\udae5\udfcc\ud83f\udce3\ud99d\udf73\ud989\ude0f\ud90e\udeb0\ud81c\udf03\uda8c\udd05\udaca\udc48\uda43\udf6c\udb2a\udc26\udb0d\udf7a\ud939\udd1b\ud853\udd74\ud805\ude5b\udb89\ude86\udaa4\udee2\uda73\udd4e\ud898\udd89\ud353\ud96f\udfc6\udb10\udff5\ud8e4\ude9e\udbcd\udc8a\udb0f\udf5b\ud8cf\udd34\ud825\udd30\ud80d\ude89\udab2\udd47\ua61d\udb11\udd05\udb26\udd24\ud8e2\udff9\ud953\udffd\udbd5\uddcd\udae6\udd32\udb57\udcfb\udb57\ude80\udbe1\ude8f\udb8f\uddda\uda0a\udfeb\ud94a\ude74\uda93\udfe7\udb90\uddb3\ud9e4\udf8c\ud989\udcd2\udb76\udd19\uc705\uda4c\udf9e\uda80\udfbb\udaba\udf6a\udb99\udd13\ud90f\udc9f\ud830\uddde", "\u23c7\u3137", "\udaa4\udd3b",
        17, 45838, 562566984, 4409141136194888977L, -24911L, false, false, (char) 51508, (char) 50594,
        Double.longBitsToDouble(0x3fe0662ffeb3d5d8L), Double.longBitsToDouble(0x3fda3f364baa26d6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:Passes properties and values to the application |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 9, 8, 2, "\ud8cd\udd40", "\u2c42\u6ec4\ub921\ua3fd", "\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud8de\ude64\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69",
        49, 14594, 285513807, -1311471878062758606L, -97952L, false, false, (char) 47834, (char) 63768,
        Double.longBitsToDouble(0x3fd4c4420d12ae32L), Double.longBitsToDouble(0x3fe0473e1f9581a8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 16, 0, "\ud8cd\udd40", "\u3313\u6ec4\u57a6\u4ea9", "\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud986\udc1c\uda68\uded9\uda97\udedd\ud95f\udd23\udba4\uddab\udb64\udea5\udb59\udd39\ud921\udca7\u64cd",
        44, 14594, 285513807, -1311471878062785742L, -97952L, false, false, (char) 47834, (char) 63768,
        Double.longBitsToDouble(0x3fd4c4420d12ae8eL), Double.longBitsToDouble(0x3fe0473e1f9581a8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:-D |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 4, 2, "\ud8cd\udd40", "\u3313\u6ec4\u57a6\u4ea9", "\uda2b\udc51\uda52\udcb1\udbc1\udf19\ud956\udf47\ud986\udc1c\uda68\uded9\uda97\udedd\ud95f\udd23\uda04\udf1d\ud821\udc6f\udb19\udc46\udac4\udc1a\uda54\udcc9",
        38, 94661, 2061069297, -4168727815511393335L, -97952L, false, false, (char) 47834, (char) 63768,
        Double.longBitsToDouble(0x3fd4c4420d12ae32L), Double.longBitsToDouble(0x3fe0473e1f9581a8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 18, 2, "", "\u6782", "\ud86d\ude42",
        6, 67663, 1278879304, -6168232344593840511L, -10551L, true, true, (char) 26574, (char) 6222,
        Double.longBitsToDouble(0x3fe89549285a2316L), Double.longBitsToDouble(0x3fe000000500b943L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 5, 8, 12, "\u8fd3", "\u3313\u0d13\u9cdc\u4ea9", "\ud96a\udcd2\ud876\udee1\udbc5\udd01\ud956\udeed\udb31\udc50\udb45\udd20\uda97\ude53\ud95f\udd23\udba4\uddab\udb64\udea5\ud942\udcce\udb61\udd90\udaa4\udce0",
        49, 14594, 285513807, -1311471878062785742L, -33311L, false, false, (char) 1783, (char) 42402,
        Double.longBitsToDouble(0x3fd08e7c3f388c42L), Double.longBitsToDouble(0x3f9b52ba2bb5cac0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 17, 13, 2, "\uda38\ude7d\udb7e\ude17\ud90d\udc65\u801b\udb0c\udd3b\ud86d\ude42\ud91b\udc92\ud9fe\udfd0\ud90a\ude07\udb94\ude84\uda52\udc38\udbc5\udd01\ud956\udf47\ud986\udc1c\uda68\uded9", "\u2591\u2afb\ua96f\u9b12", "\ud83f\udce3\udae8\udd4f\ud989\ude33\ud90e\udeb0\ud820\udd24\uda1e\udc80\udb4c\ude3d\u75cf\udb4a\ude36\ud804\udec9\ud939\udd1b\udbba\ude95\ud8a4\udccb\uda9b\uddb9\uda15\udd15",
        46, 7530, -358293922, 3107129355335551210L, 65810L, true, false, (char) 11446, (char) 52029,
        Double.longBitsToDouble(0x3fe34a0ae735da87L), Double.longBitsToDouble(0x3fecf089e58a03d8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:Passes properties and values to the application |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 0, "\000", "\u3313", "",
        22, 57175, 1278879232, -6168232344600656255L, -100000L, true, false, (char) 0, (char) 21329,
        Double.longBitsToDouble(0x3fe895492a5a2316L), Double.longBitsToDouble(0x3fe68be1adbcb943L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 17, 17, "\ud88d\udf6d\udaa6\uddc6\ud9bc\udd77\ud997\udc4b\ud9d4\udd4c\ud976\udc68\ud92e\udcdf\uda79\udc53\ud88f\udd93\ud9ac\udf72\udbf1\udc4e", "\u976a\u976e\u5ec8\ua165\uc0b1\u81b8\u75d6\ubfc2\u739a\u6b2c\u11c4\u6a1b", "\ud9bc\udf61\ud88c\udd3a\ud82c\udc23\uda16\udc6e",
        38, 16414, -1599465175, 1360134525317003044L, -11575L, true, false, (char) 4480, (char) 20287,
        Double.longBitsToDouble(0x3fe1cc278c28d36bL), Double.longBitsToDouble(0x3feba56a2348cb80L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.util.Collections$SingletonSet:[-D] |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 5, 13, 11, "\000", "\u87a4\u3de1\u3035", "\u1ac6",
        42, -873, 0, -9037214370699498065L, -24554L, false, true, (char) 28934, (char) 47860,
        Double.longBitsToDouble(0x3fd66bd77b7928beL), Double.longBitsToDouble(0x3fe10229ac9569deL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 5, 5, 2, "\ud8cd\udd40", "\u87a4\u6ec4\u57a6", "\u1ac6",
        14, 27465, 785764557, -9037214370699498065L, 55963L, false, true, (char) 28934, (char) 47860,
        Double.longBitsToDouble(0x3fd66bd77b7928beL), Double.longBitsToDouble(0x3fe10229ab48d2beL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 5, 4, 13, "\ud94b\udefd\ud924\udedd", "\ubbd8", "\ud9fe\udfd0",
        9, 38421, 1201878250, -6655803283324183231L, -97306L, true, true, (char) 51778, (char) 52356,
        Double.longBitsToDouble(0x3fed564e45f77219L), Double.longBitsToDouble(0x3fda4945fc408a02L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 7, 3, 2, "\ud8cd\udd40", "\u08e6\ub03c\u57a6", "\u1ac6",
        42, 27583, 785764557, -9037214371186102865L, -24554L, false, true, (char) 46158, (char) 5282,
        Double.longBitsToDouble(0x3fd02f505b30e340L), Double.longBitsToDouble(0x3fe10229ac9569deL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 8, 8, 18, "\udbbd\udf67\udb05\uddd3", "\u9465\u2650\u9d9e\u9e38\u86cf\ub034\uce4b\ub4bd\ucb32\ud112\u1f66\u450b\uaf29\u238f\u2afb\ub1ae\u5262\ua5ea\u79fd\u1261\uc4c5\ua540\u86c2\u12a9\ucee6\u780d\u5112\uc1b8\u8ee6\u99c0\u7ced", "\ud9bd\udd0f\udac9\udebf\udabc\udffc\ud8ad\udd35\udada\udc03\ud839\udd52\u4e03\udbb7\ude2a\ud8e6\udec2\ud859\udf73\ud9ee\udcae",
        41, 14744, -895115455, 2718886885566995197L, 68083L, false, true, (char) 50391, (char) 1146,
        Double.longBitsToDouble(0x3fe29fd88863f2bdL), Double.longBitsToDouble(0x3fef05efe1a3c57bL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 4, 11, 0, "\ud891\udf40", "", "",
        -5, -1000, 0, 5476377146882523136L, 36643L, true, true, (char) 4271, (char) 41422,
        Double.longBitsToDouble(0x3e38954800000000L), Double.longBitsToDouble(0x3e96000000000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 14, 18, "\ud8cd\udd40\udb7e\ude17\udb3d\udc7e\u80ae\ud9d4\udd3f\ud86d\ude42\ud91b\udc92\uda83\udfb4\u1ac6\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud986\udc1c\ud964\ude96\ud919\udd0a\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69\udae5\udfcc\ud83f\udce3\udb41\uddbb\ud989\ude33\ud90e\udeb0\ud81c\udf03\ud81f\udde8\ud825\udc3c\uda40\udc1c\udac6\ude52\u6dc9\ud924\ude31\udbba\ude95\ud8b8\udc54\uda6b\udea7\ud8d5\ude58\ud97f\ude23\uda5d\udd3e\udb8c\ude29\udbc4\udc86\u0d54\uda82\udc24\uda55\udc3e\u974b\udbc4\udee5\ud829\ude24\uda4b\udff3\uda5b\ude9e\uda0d\udf5a\uda30\ude68\udb0e\udf81\udaba\udd06\udaa6\udd54\uda95\udff2\uda93\udd37\ud8d1\udf7a\ud919\udea7\ud9d8\udc78\ud848\udd12\udb87\udc14\ud8fa\udffb\udb36\udf36\uda09\ude3e\udbd2\ude6b\ud9e8\udcea\udafc\udddf\ud857\udeda\ud996\udfdc\ud814\ude3c\uda79\udd77\ud818\udec3\ud865\uddcd\u6b0a\ud959\udc0b\uda51\udee2\ud83d\udc00\udbc3\udf71\ud811\udc94\ud982\udd3c\udae3\udf71\udadb\uddc2\ud8aa\udf4e\ud83e\udd9e\udae1\udef7\ud955\udec5\ud9f5\udea6\uda5a\ude57\ud898\udcdc\ud888\udf0a\udb26\udcd3", "\u8641\u43e3\u55fd\u6d9e\u1c5a\u6744\u97b0\u4aba\u0a77\u7403\u84bd\u6388\ua32a\uc517\u838c\u269f\u93a1\u83ba\u5b8b\ubc85\u2bf2\u87fa\u3a67\u6d2a\u10a3\u099f\uc9bb\u9a09\u8dbb\u6314\u739f\ud3a9\u3d6b\u9192\u5dae", "\udb0f\udf91\ud969\udc48\ud811\ude2c\udb28\udc48\udb70\udd44\udbfb\udde5\ud85d\ude10\ud943\udf60\ue891\udae3\udffa\udb0c\ude65\uda67\uddd5",
        45, 84204, -1273864555, -4250198430080741883L, 7695L, false, false, (char) 39227, (char) 59342,
        Double.longBitsToDouble(0x3fa64fd9d1c99040L), Double.longBitsToDouble(0x3fe7319366bb7f3dL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=java.lang.Boolean:false |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 5, 5, 2, "\ud8cd\udd40\udb7e\ude17\udbcc\udd84\u801b\udbbf\udede\uda57\ude25\ud907\ude3d\ud9fe\udfd0\u1ac6\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\udb17\ude05\ud964\ude96", "\u6b6b\u2afb\ua96f\u9a3b", "\ud83f\udce3\udae8\udd4f\ud989\ude33\ud90e\udeb0\ud81c\udf03\udbf0\udc2b\udac5\uddc5\uda0d\udebd\ud828\udc25\uda21\udd73\udaba\udf1e\ud93d\udceb\ud8fb\ude96\uda9b\udeb5\ud9aa\udf86",
        15, 823, 1987887405, -8420826378487905560L, 60888L, false, false, (char) 63771, (char) 41902,
        Double.longBitsToDouble(0x3fb2e85619d5bc90L), Double.longBitsToDouble(0x3fdde442d2859794L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=null |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\012",
        Z.run(T, 2, 11, 11, 2, "\udabf\ude88", "\u3313\u6ec4\u57a6\u4e89", "\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud986\udc1c\ud9cc\udc9f\uda97\udedd\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69",
        49, 14594, 285513807, -1311471878062785742L, -97952L, false, false, (char) 47834, (char) 63768,
        Double.longBitsToDouble(0x3fd4c4420d12ae32L), Double.longBitsToDouble(0x3fe0473e1f9581a8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 14, 18, "\ud8cd\udd40\udb7e\ude17\udb3d\udc7e\u80ae\ud9d4\udd3f\ud86d\ude42\ud91b\udc92\uda83\udfb4\u1ac6\uda2b\udc51\uda52\udcb1\udbc5\udd01\ud956\udf47\ud986\udc1c\ud964\ude96\ud919\udd0a\ud95f\udd23\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69\udae5\udfcc\ud83f\udce3\udb41\uddbb\ud989\ude33\ud90e\udeb0\ud81c\udf03\ud81f\udde8\ud825\udc3c\uda40\udc1c\udac6\ude52\u6dc9\ud924\ude31\udbba\ude95\ud8b8\udc54\uda6b\udea7\ud8d5\ude58\ud97f\ude23\uda5d\udd3e\udb8c\ude29\udbc4\udc86\u0d54\uda82\udc24\uda55\udc3e\u974b\udbc4\udee5\ud829\ude24\uda4b\udff3\uda5b\ude9e\uda0d\udf5a\uda30\ude68\udb0e\udf81\udaba\udd06\udaa6\udd54\uda95\udff2\uda93\udd37\ud8d1\udf7a\ud919\udea7\ud9d8\udc78\ud848\udd12\udb87\udc14\ud8fa\udffb\udb36\udf36\uda09\ude3e\udbd2\ude6b\ud9e8\udcea\udafc\udddf\ud857\udeda\ud996\udfdc\ud814\ude3c\uda79\udd77\ud818\udec3\ud865\uddcd\u6b0a\ud959\udc0b\uda51\udee2\ud83d\udc00\udbc3\udf71\ud811\udc94\ud982\udd3c\udae3\udf71\udadb\uddc2\ud8aa\udf4e\ud83e\udd9e\udae1\udef7\ud955\udec5\ud9f5\udea6\uda5a\ude57\ud898\udcdc\ud888\udf0a\udb26\udcd3", "\u8641\u43e3\u55fd\u6d9e\u1c5a\u6744\u97b0\u4aba\u0a77\u7403\u84bd\u6388\ua32a\uc517\u838c\u269f\u93a1\u83ba", "\ud975\udd3c\uda92\udf94\ud86a\udd40\udb7e\udfaf\uda73\uddbb\udb97\udee3\udbee\udd2e\uda13\udd1d\udbf1\ude32\ud8d9\udd07\ud889\udee3\uda5c\udcc3\uda01\uddaa\udb8b\udd4d\ud92d\udf9d\ud8bf\udc51\ud822\udcf8\udb0f\udf91\ud969\udc48\ud811\ude2c\udb28\udc48\udb70\udd44\udbfb\udde5\ud85d\ude10\ud943\udf60\ue891\udae3\udffa\udb0c\ude65\uda67\uddd5\ud958\udd3d\ud9db\udc66\ud9e4\ude1b\ud85d\udf92\udb15\udc05\udb2c\uddc5\ud98a\udef8\ud87b\udd26\uda3c\udde1\udb99\udcd0\ud891\udec2",
        22, 34819, -1615613720, -7420678552826403556L, -41493L, true, false, (char) 61937, (char) 26279,
        Double.longBitsToDouble(0x3feead20873dfb99L), Double.longBitsToDouble(0x3fd85680d31ce098L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 14, 10, "\ud8cd\udd40\udb7e\ude17\udbce\udfe7\ud9f7\udfe0\ud83f\udffc\ud9e6\udca1\u5eed\ud9fd\udd21\ud9d8\udf30\uda2b\udcb8\uda52\udcb1\udb97\ude2b\ud87a\udd19\ud8c0\ude5d\ud8a5\udc8f\udb12\uddc7\ud963\udef0\udba4\uddab\udb64\udea5\udbce\udcb3\udae6\udfc8\udac1\udd69\udae5\udfcc\udb63\udcb5\udb41\ude45\ud989\ude33\ud90e\udeb0\uda0d\uddbd\ud81f\udde8\ud825\udc3c\uda40\udc1c\udac6\ude52\udacd\ude41\ud924\ude31\udbba\ude95\ud9fe\uded7\udbc2\uddef\ud8cb\udca6\ud885\udf3b\ud91a\udd2d\ud838\udc7e\udbc4\udc86\u0d54\ud8e6\udf75\uda55\udc08\u974b\udbc4\udee5\ud829\ude24\ud9af\ude45\ud9d4\udc1a\uda90\uddeb\uda4a\udd68\udb0e\udf81\udaba\udd06\udaa6\udd54\udb91\udf03\uda93\udd37\ud8d1\udf7a\ud919\udea7\ud9d8\udc78\ud848\udd12\udb87\udc14\ud8fa\udffb\udb36\udf36\uda09\ude3e\udbd2\ude6b\ud9e8\udcea\udafc\udddf\ud857\udeda\ud996\udfdc\udb43\udfec\ud981\ude39\ud818\udec3\ud865\uddcd\u6b0a\ud959\udc0b\uda51\udee2\ud83d\udc00\udb0b\udd74\udbbf\uddef\ud982\udd3c\udae3\udf71\udadb\uddc2\ud8aa\udf4e\ud83e\udd9e\udae1\udef7\ud955\udec5\ud9f5\udea6\udb33\ude83\ud898\udcd2\ud888\udf0a\udb26\udcd3", "\u8641\u43e3\u55fd\u6d9e\u1c5a\u6744\u97b0\u4aba\u0a77\u7403\u84bd\u6388\ua32a\uc517\u838c\u269f\u533f\u83ba", "\ud9ae\uddbb\uda93\udc0a\ud86a\udd40\udb7e\udfaf\uda73\uddbb\udb13\udc40\ud82d\ude84\udaa1\udd24\udbf1\ude32\ud8d9\udd07\ud889\udee3\uda5c\udcc3\uda01\uddaa\udb8b\udd4d\ud92d\udf9d\ud8bf\udc51\ud94b\udd6d\udb0f\udf49\ud969\udc48\ud811\ude2c\udb28\udc48\udb70\udd44\udbfb\udde5\ud85d\ude10\ud943\udf60\ue891\udaf9\udffa\udb0c\ude65\uda67\uddd5\ud958\udd3d\ud9db\udc66\ud9e4\ude84\ud85d\udf92\udb15\udc05\udb2c\uddc5\ud98a\udef8\ud87b\udd26\uda3c\udde1\udb99\udcd0\ud891\udec2",
        22, 79795, -1615613807, -7420678552490859236L, -93497L, false, true, (char) 56913, (char) 50915,
        Double.longBitsToDouble(0x3fee805d900246a5L), Double.longBitsToDouble(0x3feead20873dfb99L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.option.PropertyOption:-D<property>=<value>\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 17, 2, "\ud8cd\udd40", "\u3313\u21fe\u57bf\u4ea9", "\udbc3\ude89\udb00\udf70",
        -3, 88601, -1586451025, -4300438062121004036L, 75029L, true, false, (char) 28802, (char) 46964,
        Double.longBitsToDouble(0x3fe2b4165ad4a82fL), Double.longBitsToDouble(0x3fed4b586e4387c9L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "C|org.apache.commons.cli2.option.GroupImpl|<init>|java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.OptionImpl|getParent||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.option.OptionImpl|setParent|org.apache.commons.cli2.Option|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|appendUsage|java.lang.StringBuffer,java.util.Set,java.util.Comparator|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|canProcess|org.apache.commons.cli2.WriteableCommandLine,java.lang.String|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|canProcess|org.apache.commons.cli2.WriteableCommandLine,java.util.ListIterator|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|defaults|org.apache.commons.cli2.WriteableCommandLine|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|findOption|java.lang.String|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getDescription||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getId||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getParent||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getPreferredName||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getPrefixes||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|getTriggers||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.Option|helpLines|int,java.util.Set,java.util.Comparator|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "C|org.apache.commons.cli2.option.GroupImpl|<init>|java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.OptionImpl|getParent||fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
    "M|org.apache.commons.cli2.option.OptionImpl|setParent|org.apache.commons.cli2.Option|fld:org.apache.commons.cli2.option.PropertyOption:INSTANCE",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
