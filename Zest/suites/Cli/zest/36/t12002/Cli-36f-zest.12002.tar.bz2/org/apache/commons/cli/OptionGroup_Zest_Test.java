package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class OptionGroup_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u8241\u41b5\u94fd\u3de0\ucca1\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 9, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uda30\udc2b\udb3f\udc2f\uda27\udd7e", "\u8241\u41b5\u94fd\u3de0\ucca1\u8571\ucd14\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 1, 14, "\ud927\uddbb\ud9a0\ude85\ud9d3\udda3\udb05\udcda\ud9be\udc52\ud881\uddb4\uda8f\udd45\ud88b\ude45\udade\udc5d", "\u1f1f\u38ae\ud5bc\u76ea\u81b8\u642f\u86b8\u9441\u34ae\u6c36\ua82d\u39e2\u9000\u17e6\u1b49", "\ud8ec\udc95\uda03\uded5\uda15\udece\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 53641, (char) 54606,
        Double.longBitsToDouble(0x3fec5fce404a2e21L), Double.longBitsToDouble(0x3fec8d1d0c754a60L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\ud927\uddbb\ud9a0\ude85\uda92\udd2e\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u8241\u41b5\u94fd\u3de0\ucca1\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde\ud86b\udc9e\uda04\uddcf\ud9d2\uddd6\ud8bd\udd00\ud8a9\udee1\udbf9\udd74\udae0\udc24\udb1b\udc66",
        7, 24935, -1138660469, 598860175125623437L, 152L, false, true, (char) 50055, (char) 48776,
        Double.longBitsToDouble(0x3fe4894274687b8eL), Double.longBitsToDouble(0x3fd219f2d6fa1ff0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\ud927\udd08\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4", "\u1ade\u8bec\ud48e\uc0ea\u1f1f", "\ucac9\udacb\ude4e\udb6a\udd73\ud9c7\udf0d\uda93\udf4e\udab5\udc05",
        -5, 66450, 1147941021, -6788256539798884839L, 82942L, false, true, (char) 8654, (char) 59097,
        Double.longBitsToDouble(0x3fdb05c6bf02f3beL), Double.longBitsToDouble(0x3f84ad8c56587bc0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udbd1\udeb2\ud8c8\udfda", "\u8241\u41b5\u94fd\u3de0\ucca1\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde\ud86b\udc9e\uda04\uddcf\ud9d2\uddd6\ud8bd\udd00\ud8a9\udee1\udbf9\udd74\udae0\udc24\udb1b\udc66\ud96b\udde6\ud8aa\udc49\ud81b\udf8b\udaa1\udca5\ud82e\udf0d\ud844\udc5f\ud8b0\udf9e\uda53\udf58\udad6\ude34\udbef\uddda\ud846\udd87",
        47, 10871, -1169135439, 6880726566904933194L, 93942L, true, true, (char) 60721, (char) 36995,
        Double.longBitsToDouble(0x3fd6c928e5686a94L), Double.longBitsToDouble(0x3fe6a062d3471808L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 14, 8, "\ud927\uddbb\ud9a0\udec7\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\ud9ac\udf49\ud8e6\udcc8\ud876\udfa3\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\udba1\udff3\udb4f\ude11\uda27\udd7e", "\u8241\u40c5\u8875\u092d\u8873\u55ad\uc461\ud2c4", "\ud909\ude67",
        46, 48681, 1643109386, 599358466058014333L, -62969L, true, true, (char) 65009, (char) 35891,
        Double.longBitsToDouble(0x3fd75087de5eb108L), Double.longBitsToDouble(0x3fad67c149cd3940L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\uda24\udf0f\ud8e9\udd10\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud96f\udf69\ud93d\ude3e\uda2a\ude73\udaea\udcde\uda77\uddda\ud9e3\ude8c\uc93d\ud916\udc3a\ud9de\udfb9", "\u073a\u420b\u94fd\u3de0\uccf4\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139535193, 7963154127307884778L, -49906L, true, true, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 1, 0, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\ud95c\udd56\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u8241\u41b5\u94fd\u3de0\ucca1\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 14, 8, 13, "\uda78\udeab\ud99c\udcd1\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udcab\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud938\udfd8\udad2\ude4c\ud8e9\uddbd\uda0b\udd25", "\u10c1\u41b5\u94fd\u89c3\u35c5\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 97362, -653362548, 7963154377674466002L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 8, 6, "\ud927\uddbb\ud9a0\ude85\udb38\udf22\ud8f8\udc3d\ud986\udcf8\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u8241\u41b5\u54fd\u3de0\ucca1\u8571\uc8c5\ucce7", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 6, 4, 5, "\uda6a\udd2f\ud9a0\ude85\udb3b\udc22\ud80f\udeea\ud850\udcc9\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\udb47\udc80\uda39\udfa3\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\ud887\udd6d\uda27\udd7e", "\u8241\u41b5\u4a97\u887d\ucc44\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154127576507090L, 60114L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fe869169496bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 14, 2, "\udb95\udccc\ud9a0\ude1b\ud9f2\ude26\udb09\udf4b\ud9be\udcf4\udbac\udd93\udb44\udeb7\u24e6\ud8ce\udc8f\udb90\udc7f\ud8c5\udc27\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u734d\u41b5\u7923\u69a6\u0264\u8571\u6a25\u8f2f", "\ud80b\udd6b\ud84c\ude76",
        27, 88760, 139548947, 4127776095906964119L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a1f1087dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 3, 3, "\ud927\uddbb\ud938\udc10\udbb7\udf63\ud842\udf33\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud881\udfa0\udade\udc98\ud8f9\ude6f\udb8b\udff6\uda80\udd2e\ud9ba\uddfe\ud801\udd04\udab3\udef1\ud9d8\udf35\uc93d\udb4f\ude11\uda27\udd7e", "\u824d\u41b5\u1e24\u2bd3\ucca1", "\ud9c2\udc01\ud88e\ude4a\uda3e\udece\ud909\ude67\uda83\udcde\ud86b\udc9e\uda04\uddcf\udb20\udd5d\ud8bd\udd00\ud8a9\udee1\udb4d\udc7f\uda2b\udd78\udab9\ude4b\udbef\ude93\ud88b\ude52\ud81b\udf8b\udaa1\udca5\udac6\udfba",
        32, 78898, 410537387, 7202444222447030086L, 29560L, true, true, (char) 48361, (char) 9585,
        Double.longBitsToDouble(0x3f8375e1a3cbe800L), Double.longBitsToDouble(0x3fd923bd0b118deaL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 14, 2, "\udb20\ude41\ud9a0\ude85\udb3b\udc22\ud900\udddc\udaf2\uddad\ud93a\udeff\udb8f\udc0d\udaa6\udcd1\udb90\udc9c\udba5\udeac", "\u38ae\u7abd\u76ea\uce63\u7c88\u5773\u17e8\u5931\u8a37\u6739\u83a7\u8a7e\u1aaf\u35c0\uc867", "\ud851\ude61\uda15\udece\ud909\ude67\uda83\udcde\ud86b\udc9e",
        39, 67017, 1854066301, 4963568026151014451L, -89336L, false, false, (char) 61335, (char) 25940,
        Double.longBitsToDouble(0x3fe145e10a8d0854L), Double.longBitsToDouble(0x3fbd421f49f45578L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\ud927\uddbb\ud9a0\ude85", "\u630f\u6930\u6601\ucde0\u8bec\ud48e\ub6db\u1f1f\u38ae\ud5bc\u76ea\u5e08\u7c88\u6040\u17e8\u7a81\uaeec\u8241\u41b5\u94fd\u3de0", "\udae9\udf6f\ud8ec\udcb1\ud851\uddfc",
        16, 99285, 2044693936, 6252886898972285962L, 83933L, false, false, (char) 5397, (char) 7397,
        Double.longBitsToDouble(0x3fe0aa5df04e6b3bL), Double.longBitsToDouble(0x3fc4ebde2e2fe720L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 5, 14, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\udb2e\udf96\udade\udc5d\ud9ee\udfc9\uda23\ude9e\ud93d\udec1\uda2a\ude73\ud9db\ude4f\uda58\udf9a\udaa5\ude6d\uc90d\udb4f\ude11\uda27\udd7e", "\u8135\u41b5\u94fd\u3de0\ucca1\u8571\u230b\u8f0d", "\ud909\ude67\ud8b3\udf44",
        14, 40386, 139549017, 7963154128566362834L, 81166L, false, true, (char) 19337, (char) 64255,
        Double.longBitsToDouble(0x3feba1f76428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\uda78\udf63", "\u0400\u630f", "\ud88b\ude45",
        50, 28404, 868786556, -7621264323016353998L, 28642L, true, false, (char) 63608, (char) 15462,
        Double.longBitsToDouble(0x3fe9c8f0e77a9720L), Double.longBitsToDouble(0x3fc3bceb129511b0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\udae9\udeff", "\u8241\u41b5\u94fd\u3de0\ucca1\u8571\u230b\u8f0d\uc19d\ub88e\u5e7e\uc621\u065a\u481d\u9b34\u6177\u1476\uc1f0", "\ud96b\udde6\ud8aa\udc49\ud81b\udf8b\udaa1\udca5\ud82e\udf0d\udbd0\udf24\uda5d\uddd6\udabe\udea0\udb15\udcd3\u6fdd\ud81c\udc70\ud99c\ude6e\udbbf\ude2d\ufd69\u99fa\ud9a3\udfc3\u6fe4\ud9d2\udef2\udb9f\udf22\ud9c2\udeba\udb64\udca0\udbd7\udc41\uda5c\udcb7\ud9a4\ude8a\ud8a9\udcc1\ud81e\ude99\udbd9\udfe3",
        59, 72529, 1723124186, -8564182186781668615L, -44899L, true, false, (char) 31533, (char) 12774,
        Double.longBitsToDouble(0x3fee12ec057da8bcL), Double.longBitsToDouble(0x3fd3efc5ee49028cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 14, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u8241\u41b5\u94fd\u3de0\u0577\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, -49999L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 5, "\ud927\uddbb", "\uc3dc\u630f", "\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e",
        7, 51708, -891822613, 7644438479913744002L, 10466L, true, false, (char) 20821, (char) 7834,
        Double.longBitsToDouble(0x3fc3bceb129511b0L), Double.longBitsToDouble(0x3fe0cd0e586c8d10L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 9, 7, "\ud927\udd20\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\uda0d\udde6\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e\ud904\udc97\udb2f\udd0a\uee06\ud8df\udca5\udaf5\udf17\u7753\uda3b\udfca\ud8d7\uddd9\udae9\udf6f\ud8ec\udcb1\ud851\uddfc\uda15\udece\ud909\ude67\uda83\udcde\ud86b\udc9e\uda04\uddcf\ud9d2\uddd6\ud8bd\udd00\ud8a9\udee1\udbf9\udd74\udae0\udc24\udb1b\udc66\ud96b\udde6\ud8aa\udc49\ud81b\udf8b\udaa1\udca5\ud842\udc0a\uda97\udddf", "\u3485\u9e6f\u6f57\u5b32\uc81e\u7b58\u41dd", "\ud87e\udc75\ud944\udda2\uc5db\udbba\ude31\udbdc\udfeb\udb81\udfe8\ud9f7\udd57\ud80a\udefe\udb08\udfda\ud94a\udfd7\ud88d\ude0a\ud93f\udd53\udbc5\udcad\ud9d5\udf77\uda38\ude52\udaa9\udda7\ud838\udd17\ud9ba\udc43\u5fc0\ud91a\udf62\ud947\uded2\udb19\udd54\ud900\udd49\udb97\udcbf",
        39, 3668, -834108957, -8493149668051367190L, 38372L, true, false, (char) 1925, (char) 29073,
        Double.longBitsToDouble(0x3fd407bd7e865556L), Double.longBitsToDouble(0x3fd8bfc90f225c16L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 14, 11, "\ud927\uddbb\ud9a0\ude85\ud9a2\uddd6\ud9c0\udc51\udaac\udc0a\udbac\udd41\uda7a\udc51\ud88b\ude45\ud8a1\uddcc\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\udacc\udd85\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\ud98e\uddd3", "\u0609\u4388", "\ud8b3\udca7\ud8d7\ude09\ud827\uddcd\uda16\uddb9\ud851\udd99\uda15\udece",
        48, 21679, 1455863570, 7057101076760189273L, 39986L, true, false, (char) 45541, (char) 30946,
        Double.longBitsToDouble(0x3fb8e5a8ed3af788L), Double.longBitsToDouble(0x3fcfcebdd0a3bfb0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 14, 2, 2, "\ud93b\uddee\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\udb6b\udfc4\ud9d9\ude1e\ud9db\ude4f\ud847\udcc4\ud9e3\ude8c\uc93d\udb4f\ude11\ud95a\uddb6", "\u8241\u552a\u94fd\u3de0\ucca1\u8571\u230b\u8f0d\uc19d\ud042\u51ca", "\udaa6\udc61\ud9d2\udd88\ud8bd\udd00\ud8a9\udee1\ud954\udf43\uda7f\udd49",
        16, 37902, 684232871, -4890468544424930264L, -51755L, true, false, (char) 54183, (char) 40821,
        Double.longBitsToDouble(0x3fe3b97f715ccbceL), Double.longBitsToDouble(0x3fe04abec5333ed4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 4, "\udbfc\udff7\ud9a0\ude6a\udb3b\udc22\ud8f8\udc3d", "\ud269\u8728\u1ca0\ud48e\u4123\u480c\u38ae\ud5bc", "\udabf\udfc9\udb4f\ude20\uda27\udd7e\ud904\udcae\ud987\udd90\ud93f\udc23\ud9de\udf46\ud9b8\udd95\uda6e\udf21\udbd2\ude6e\ud943\udd0f\ud8e2\udd6a",
        51, 34250, 1575291206, 6659567061890469296L, -17725L, true, true, (char) 54989, (char) 37109,
        Double.longBitsToDouble(0x3fa9a2713ae59370L), Double.longBitsToDouble(0x3fe0d4ec204e6baaL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 9, 2, "\ud927\uddbb\ud9fb\udd11\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\ud84d\ude42\udad8\udcaa\ueb56\ud9e3\udefb\uc93d\ud9a3\ude7b", "\uaeec\u8241\u41b5\u94fd\u3de0", "\udae9\udf6f\ud8ec\udcb1\ud851\uddfc",
        16, 99285, 2044693936, 6252886897327070218L, 83933L, false, true, (char) 26135, (char) 7397,
        Double.longBitsToDouble(0x3fe0aa5df04e6b3bL), Double.longBitsToDouble(0x3fc4ebde2e2fe720L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 1, 14, "\ud927\uddbb", "\u219e\u626d\u682a\u6280\ucddd\u8bec", "\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\uda85\udcb8\ud95b\udd59\ud915\udf5f\u0292\udbd8\ude46\udb61\udd5f\ucf6c\ud8bf\udd1f\ud953\ude7b\udbfc\udd0c\ud95b\ude3c",
        17, 64226, -1335282362, 2806213753109285190L, -72578L, true, true, (char) 40555, (char) 42802,
        Double.longBitsToDouble(0x3fbd52983ccaeed8L), Double.longBitsToDouble(0x3fee87c2d61725f4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 1, 6, "", "", "\ud9be\udc52\ud881\uddb4",
        16, 5786, -1377030860, -4388110515712777860L, 44666L, true, true, (char) 57601, (char) 61846,
        Double.longBitsToDouble(0x3fe94282266f6983L), Double.longBitsToDouble(0x3fd1b0838cce884eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 7, 7, 14, "\ud927\udd25\ud9a0\ude85\uda6e\udfb1\uda91\udf62\ud9be\udc52\ud881\uddb4\uda57\udd49\uda60\udfb6\ud9a6\udd9f", "\uaaf1\u38ae\ud5bc\u76ea\u81b8\u642f", "\udbaa\udef9\udba6\udf7d\uceeb",
        8, 27519, -1923872817, 9024183251697082837L, 82970L, false, false, (char) 47464, (char) 48439,
        Double.longBitsToDouble(0x3fdb05ce0b02f374L), Double.longBitsToDouble(0x3fee2fa96a0c1ae6L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\ud905\udfbb", "\u219eT", "",
        -5, 24016, 0, 0L, -100000L, false, false, (char) 44287, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 8, 14, "\ud8a6\uddca", "\u219e\u626d", "\ud8a9\udd27\udade\udc5d\uccc8\ud8a7\udc34",
        42, 890, 110644716, -3830348956314525108L, 11083L, false, false, (char) 61846, (char) 3948,
        Double.longBitsToDouble(0x3fe37b4c19b252e3L), Double.longBitsToDouble(0x3fdbe4462a0a9734L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 11, 10, "\ud927\uddbb\ud9a0\ude85\udb3c\udc19\ud827\udfab\ud93e\ude73\ud881\uddb4\uda8f\udd45\ud88b\ude45\ud980\uddad", "\u4628\u393b\ud5bc\u76ea\u874f\u63ce\u86b8\u9441\u34ae\u6c36\ua82d\u39e2\u9000\uada9\u1b49", "\ud8ec\udc95\uda03\uded5\ud887\udec7\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 53641, (char) 54606,
        Double.longBitsToDouble(0x3fec5fce404a2e21L), Double.longBitsToDouble(0x3fd82a3a181d4f6cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 4, 14, 2, "\ud927\udd08\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\uda9a\udf22", "\u1ade\u8bec\ud48e\uc0ea\ua4c0", "\ucac9\udacb\ude4e\udb6a\udd73\ud9c7\udf0d\uda93\udf4e\udab5\udc05",
        -5, 32914, -1517431286, -6788256539798884839L, 44718L, false, true, (char) 8654, (char) 59097,
        Double.longBitsToDouble(0x3fdb05c6bf02f3beL), Double.longBitsToDouble(0x3f84ad8c56587bc0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 5, 14, 2, "\ud927\udd08\ud9a0\ude85\udbd1\udf55\ud8f7\udf8c\ud9be\udcf4", "\u1ade\u2ab2\ud4aa\uc0ea\u1f1f", "\ucac9\udacb\ude4e\udb6a\udd73\ud9c7\udf0d\ud94e\udd0d\udab5\udc05",
        54, 4397, 1147941081, -6788256539798884839L, -20798L, false, true, (char) 8654, (char) 59097,
        Double.longBitsToDouble(0x3fe582e35a0f1825L), Double.longBitsToDouble(0x3fcac576256587bcL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 14, 14, 0, "\ud927\udd08\uda2b\udf5b\udb3e\ude2d\ud959\udeab\uda3c\udfc2", "\u1963\u8bcf\ud48e\u0bc8\u680f", "\ucaa7\udacb\udede\udb6a\udd73\ud9c7\udf0d\udb55\ude05\ud952\ude36\ud9bb\udfc3\udb47\udd62\ud8a4\ude9a\udaf5\udf17\ud817\udcce\ud85a\udcfe\ud8d7\uddd9\ud916\ude74\ud8ec\udcb1\ud85e\udd42\uda15\udece\ud909\ude67\ud88c\ude83\udb23\udd00\uda04\uddcf\udac4\udd8f\ud859\udc36\udabf\ude1a\uda09\ude0f\uda57\udd12\ud828\ude32\udb65\uded3",
        41, 51213, 875914272, -7824783623945898337L, -45329L, true, true, (char) 27188, (char) 59746,
        Double.longBitsToDouble(0x3fddba8c882a10e0L), Double.longBitsToDouble(0x3fed9ad118ce76e9L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 0, 2, "", "", "\u00f6",
        -5, 2272, -1793551214, 223338299392L, -100000L, false, false, (char) 0, (char) 61439,
        Double.longBitsToDouble(0x3fb332b4341350b0L), Double.longBitsToDouble(0x3fdc5a695bf0db2cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 9, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\uda24\udf0f\ud8e9\udd10\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud96f\udf69\ud93d\ude3e\uda2a\ude73\udaea\udcde\uda77\uddda\ud9e3\ude8c\uc93d\ud916\udc3a\ud9de\udfb9", "\uad64\u420b\u94fd\u3de0\uccf4\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139535193, 7963154126200588522L, -49934L, true, true, (char) 19337, (char) 33944,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 8, 6, "\u00d9\ud9a0\ude85\udb38\udf22\ud8f8\udc3d\ud986\udcf8\udbac\udd93\uda7a\udc51\ud88b\ude45\udb36\udf1b\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\uc9de\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u8241\u41b5\u54fd\u3de0\ucca1\u8571\uc8c5\ucce7", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u2012\ucd08\ubb5e  [ARG] :: \ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ] [ long {\u2012\ucd08\ubb5e=[ option:  \u2012\ucd08\ubb5e  [ARG] :: \ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u2012\ucd08\ubb5e  [ARG] :: \ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ] [ long {\u2012\ucd08\ubb5e=[ option:  \u2012\ucd08\ubb5e  [ARG] :: \ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ]\012",
        Z.run(T, 1, 11, 3, 0, "", "\u2012\ucd08\ubb5e", "\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e",
        0, 48716, -891822613, 7644297417517823618L, 10466L, true, false, (char) 20821, (char) 7834,
        Double.longBitsToDouble(0x3fc3bceb129511b0L), Double.longBitsToDouble(0x3fe0cd0e586c8d10L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 8, 6, "\u86d9\000\udb38\udf22\ud8f8\udc3d\ud986\udcf8\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\u4cbc\ud8c5\udc89\ud908\ude3e\uda2a\ude73\ud9db\ude4f\udad1\uddf7\000\000\000\000", "\u8241\u41b5\u54fd\u3de0\ucca1\u8571\uc8c5\ucce7", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3ec910a2f0000000L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 0, 1, "\u86d9\000\000\uda50\ude48\ud984\uddf8\udbac\udd93\uda7a\udc51\000\000\ud8e6\udc69\udb40\udd87\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u8241\u311d\u5058\u3de0\ucca1\u8571\000\000", "",
        -5, 48936, 13023105, 7056859141118187865L, 39776L, true, false, (char) 7397, (char) 19411,
        Double.longBitsToDouble(0x3d1e200000000000L), Double.longBitsToDouble(0x3fec5fc80400bc21L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u86d9=[ option: \u86d9   [ARG] :: \udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e :: class java.lang.String ]} ] [ long {=[ option: \u86d9   [ARG] :: \udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u86d9=[ option: \u86d9   [ARG] :: \udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e :: class java.lang.String ]} ] [ long {=[ option: \u86d9   [ARG] :: \udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e :: class java.lang.String ]} ]\012",
        Z.run(T, 1, 11, 8, 6, "\u86d9", "", "\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e",
        21, 22585, -413628550, 4930369141351318693L, -17554L, true, false, (char) 44318, (char) 8654,
        Double.longBitsToDouble(0x3e46c171ac000000L), Double.longBitsToDouble(0x3fec0bcefc0a56c6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 6, 5, 11, "\uda6a\udd2f\ud9a0\ude85\udb3b\udc22\ud80f\udeea\ud850\udcc9\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\udb47\udc80\uda39\udfa3\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\ud887\udd6d\uda27\udd7e", "\u8241\u41b5\u4a97\u887d\u1810\000\u2219\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154127576507090L, 60114L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fe869169496bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 10, 2, "\udaa5\udc52\ud9a0\ude85\udb3b\udc22", "\u6930\u0d8c\ucddd\u8bec\ud48e\ub6db\u2ef0\ub74f\ud502\u76ea\u5e08\u7c88\ud350\u17e8\u7a81\uaeec\u8241\u41b5", "\uda3b\udf6d\ud892\udf09\ud9fe\udfad\ud8f8\udd64\ud851\uddfc",
        16, 99285, 2044693936, 6252886898972285962L, 83933L, true, false, (char) 43905, (char) 40245,
        Double.longBitsToDouble(0x3fe64c19304e6b3bL), Double.longBitsToDouble(0x3fc4ebde2c348b48L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 12, 0, "\uda6a\udd2f\udbc4\udfb6\udb3b\udc22\u987f\ud84d\ude66\udb96\udc57\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud970\udd5f\udb47\udc67\uda94\udd91\ud9c1\udc14\ucac9\ud9e3\ude8c\uc93d\ud887\udd6d\ud8e3\udc9c", "\u8241\u41b5\u4a97\u359f\u3ab02\u77c9\u75db", "\udb03\udc81\ud935\ude69\ud86b\udc9e\uda04\uddcf",
        57, 92645, 165814994, 3153384189427347826L, 88494L, true, false, (char) 40432, (char) 29905,
        Double.longBitsToDouble(0x3fcf1d2cd4d2a954L), Double.longBitsToDouble(0x3fe40c80cdbe991dL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 6, 6, 5, "\uda6a\udd2f\ud97c\udf11\udb3b\udc22\ud80f\udeea\ud850\udcc9\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\udbb9\uddae\ud8c5\udc89\udb47\udc80\uda39\udfa3\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\ud887\udd6d\uda27\udd7e", "\u8241\u41b5\u4a97\u887d\ucc44\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 71458, 139549017, 7963154127576507090L, 60114L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fe869169496bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 9, 5, "\u9614\ud9a0\udeb6\udb3b\udc22\udb0b\udee8\ud850\udcc9\udac2\ude95\ud855\udef5\udb9b\udee9\udade\udc3a\ud8e6\udd25\ud8c5\udc89\udb47\udc80\uda39\udfa3\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\ud868\udf42\uda27\udd7e", "\u8241\u41b5\u4a97\u887d\ucc44\u8571\u230b\u8f0d", "\ud909\ude67\ud8b4\udf70",
        46, 40386, 139549017, 7963154127576507090L, 60114L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fe014b6949681f1L), Double.longBitsToDouble(0x3fefc842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 3, 3, 3, "\ud927\uddbb\ud938\udc10\udbb7\udf63\ud842\udf33\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud881\udfa0\udade\udc98\ud8f9\ude6f\udb8b\udff6\uda80\udd2e\ud9ba\uddfe\ud801\udd04\udab3\udef1\ud9d8\udf35\uc93d\udb4f\ude11\uda27\udd7e", "\u824d\u41b5\u1e24\u2bd3\ucca1", "\ud9c2\udc01\ud88e\ude4a\uda3e\udece\ud909\ude67\uda83\udcde\ud86b\udc9e\uda04\uddcf\udb20\udd5d\ud8bd\udd00\ud8a9\udee1\udb4d\udc7f\uda2b\udd78\udab9\ude4b\udbef\ude93\ud88b\ude52\ud81b\udf8b\udaa1\udca5\udac6\udfba",
        32, 78898, 410537387, 7202444222447030086L, 29560L, true, true, (char) 48361, (char) 9585,
        Double.longBitsToDouble(0x3f8375e1a3cbe800L), Double.longBitsToDouble(0x3fd923bd0b118deaL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: null :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 1, 9, 4, 0, "", "", "\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e\ud904\udc97\udb2f\udd0a\uee06\ud8df\udca5\udaf5\udf17\u7753",
        19, 49261, -1852981774, -5734993955456548864L, 78049L, false, false, (char) 47944, (char) 54989,
        Double.longBitsToDouble(0x3fe69374103344e2L), Double.longBitsToDouble(0x3fea8ac9be156cb4L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: \u2912 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: \u2912 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 1, 9, 14, 5, "", "\u2912", "\udbac\udd93\ud9e6\udc47\ud88b\ude45\udade\udc5d\u4cbc\000\udb40\uddc0\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\udb15\udd75\ud904\udc97\udb2f\udd0a\uee06\ud8df\udca5\udaf5\udf17\u7753\uda0a\udca0\ud8d7\uddd9\ud941\uddfa\ud8ec\udc4f\uac8a\ud951\udd87\ud909\ude67\uda83\udcde",
        46, 40376, 139549017, 7926335882198655698L, -49999L, true, false, (char) 78, (char) 0,
        Double.longBitsToDouble(0x3e40a2f000000000L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 14, 14, 11, "\ud927\uddbb\ud9a0\ude85\ud9a2\uddd6\ud9c0\udc51\udaac\udc0a\udbac\udd41\uda7a\udc51\ud88b\ude45\ud8a1\uddcc\ud8e6\udd25\ud8c5\udc89\ud9c9\udd23\udacc\udd68\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\udd74\ud98e\uddd3", "\u0609\u4388", "\ud8b3\udca7\ud8d7\ude09\ud827\uddcd\uda16\uddb9\ud851\udd99\uda15\udece",
        48, 21679, 516339474, 7057078322023455065L, -7156L, true, false, (char) 45541, (char) 30946,
        Double.longBitsToDouble(0x3fb8e5a8ed3af788L), Double.longBitsToDouble(0x3fcfcebdd0a3bfb0L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 2, 2, "\000\000\000\000\ud9be\udcf4\udbac\udd93\uda7a\udc51\u9492\udade\udc5d\ud8e6\udd25\udb40\udd0b\udb6b\udefd\ud9ca\udf44\ud9db\ude4f\ud847\udcc4\ud9e3\ude8c\uc93d\udb4f\ude11\ud95a\uddb6", "\u877a", "",
        -5, 66432, 7288501, 1039388980578L, -32090L, false, true, (char) 49664, (char) 12640,
        Double.longBitsToDouble(0x3f35b18000000000L), Double.longBitsToDouble(0x3e30000000000000L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\0121=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 8, 8, 4, "\udbfc\udff7\ud9a0\ude6a\udb3b\udc22\ud8f8\udc3d", "\ud269\u8728\u1ca0\ud48e\u4123\u226b\u38d0\u12c1", "\udabf\udfc9\udb4f\ude20\uda27\udd7e\ud904\udcae\ud987\udd90\ud93f\udc23\ud9de\udf46\ud996\udf97\uda6e\udf21\udb66\ude78",
        9, 37827, -1335230783, -4320169707251103277L, -17725L, true, true, (char) 54989, (char) 41360,
        Double.longBitsToDouble(0x3fa9a2713ae59370L), Double.longBitsToDouble(0x3fe0d4ec204e6baaL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 9, 1, "\udbfc\udff7", "\uc309\u5d6e", "\uda6b\ude55",
        8, 58252, 868756420, 7695237216636606258L, 10466L, false, false, (char) 10059, (char) 36834,
        Double.longBitsToDouble(0x3fc3bd00f284853cL), Double.longBitsToDouble(0x3fe6825fb3190149L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 11, 6, "\ud982\udcef\ud9a0\ude6a\udb3b\udc22\ud8f8\udc3d\udbe8\udea9\udaf2\udf9e\udaab\udd2e\uda6b\ude55\udaf8\udd10\ud8e6\udd25\ud8a7\uded1\ud857\udfc5", "\u76ea\ucd40\u36d7\u604f\u17e8\u7a98\u4948\u9923\u8d42\u88b9\ub5ab\u7d05\u4446\u4c04\u8f0d\uc19d", "\uda83\udcde\uda7e\udd8f\ud88b\udf1f\ud9d2\uddd6\ud8bd\udd00\ud8a9\ude82\udbf9\udd74",
        37, 33458, 868633438, 8087770943999279043L, 83921L, false, true, (char) 5378, (char) 43296,
        Double.longBitsToDouble(0x3fbca7eadb832d00L), Double.longBitsToDouble(0x3fdab92073f4a486L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u00d9=[ option: \u00d9 \uc3dc\ubb5e\u6930\u0d8c\ucddd\u217b\ud481\ub6db\u1f1f\u38ae\ud5bc  :: \u98d6\udb4f\ude11\uda27\udd7e\ud904\udc97\ud9d7\udede\ud93d\udd6d\udb9e\udfb6\ud9de\udce3\u7753 :: class java.lang.String ]} ] [ long {\uc3dc\ubb5e\u6930\u0d8c\ucddd\u217b\ud481\ub6db\u1f1f\u38ae\ud5bc=[ option: \u00d9 \uc3dc\ubb5e\u6930\u0d8c\ucddd\u217b\ud481\ub6db\u1f1f\u38ae\ud5bc  :: \u98d6\udb4f\ude11\uda27\udd7e\ud904\udc97\ud9d7\udede\ud93d\udd6d\udb9e\udfb6\ud9de\udce3\u7753 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u00d9=[ option: \u00d9 \uc3dc\ubb5e\u6930\u0d8c\ucddd\u217b\ud481\ub6db\u1f1f\u38ae\ud5bc  :: \u98d6\udb4f\ude11\uda27\udd7e\ud904\udc97\ud9d7\udede\ud93d\udd6d\udb9e\udfb6\ud9de\udce3\u7753 :: class java.lang.String ]} ] [ long {\uc3dc\ubb5e\u6930\u0d8c\ucddd\u217b\ud481\ub6db\u1f1f\u38ae\ud5bc=[ option: \u00d9 \uc3dc\ubb5e\u6930\u0d8c\ucddd\u217b\ud481\ub6db\u1f1f\u38ae\ud5bc  :: \u98d6\udb4f\ude11\uda27\udd7e\ud904\udc97\ud9d7\udede\ud93d\udd6d\udb9e\udfb6\ud9de\udce3\u7753 :: class java.lang.String ]} ]\012",
        Z.run(T, 1, 11, 8, 14, "\u00d9", "\uc3dc\ubb5e\u6930\u0d8c\ucddd\u217b\ud481\ub6db\u1f1f\u38ae\ud5bc", "\u98d6\udb4f\ude11\uda27\udd7e\ud904\udc97\ud9d7\udede\ud93d\udd6d\udb9e\udfb6\ud9de\udce3\u7753",
        45, 49261, 266518002, 5014118746462661770L, 78049L, false, false, (char) 47944, (char) 54989,
        Double.longBitsToDouble(0x3fe69374103344e2L), Double.longBitsToDouble(0x3fed72c9be154bbeL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u2012\ucd08\u75ed  [ARG] :: \ud88f\udd8c\ud90c\udf7a\ud8f3\udd19\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9c3\ude40\udb4f\ude8a\udbca\udca5\udbbd\udeca\ud904\udc97\udb2f\udd0a\uee06\ud8df\udca5\udae5\udf17\u7753\ud9b0\ude46\udb68\ude98\ud81f\udc59\ud863\ude0d\uda27\udcd2\ud8c7\udca2\ud8a4\udf37\ud84c\udd42\ud9dd\udd25\uda35\udf03\ud9f5\udd00\uda68\udea4\ud818\udfa5\udafa\ude5c\ud982\udc12\uda7a\udf03\ud9cf\udffc\udb40\udd0e\ud815\ude9e\ud85c\udc7e\u70ae\udae2\udf84\ud85c\udcd5 :: class java.lang.String ]} ] [ long {\u2012\ucd08\u75ed=[ option:  \u2012\ucd08\u75ed  [ARG] :: \ud88f\udd8c\ud90c\udf7a\ud8f3\udd19\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9c3\ude40\udb4f\ude8a\udbca\udca5\udbbd\udeca\ud904\udc97\udb2f\udd0a\uee06\ud8df\udca5\udae5\udf17\u7753\ud9b0\ude46\udb68\ude98\ud81f\udc59\ud863\ude0d\uda27\udcd2\ud8c7\udca2\ud8a4\udf37\ud84c\udd42\ud9dd\udd25\uda35\udf03\ud9f5\udd00\uda68\udea4\ud818\udfa5\udafa\ude5c\ud982\udc12\uda7a\udf03\ud9cf\udffc\udb40\udd0e\ud815\ude9e\ud85c\udc7e\u70ae\udae2\udf84\ud85c\udcd5 :: class java.lang.String ]}... |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u2012\ucd08\u75ed  [ARG] :: \ud88f\udd8c\ud90c\udf7a\ud8f3\udd19\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9c3\ude40\udb4f\ude8a\udbca\udca5\udbbd\udeca\ud904\udc97\udb2f\udd0a\uee06\ud8df\udca5\udae5\udf17\u7753\ud9b0\ude46\udb68\ude98\ud81f\udc59\ud863\ude0d\uda27\udcd2\ud8c7\udca2\ud8a4\udf37\ud84c\udd42\ud9dd\udd25\uda35\udf03\ud9f5\udd00\uda68\udea4\ud818\udfa5\udafa\ude5c\ud982\udc12\uda7a\udf03\ud9cf\udffc\udb40\udd0e\ud815\ude9e\ud85c\udc7e\u70ae\udae2\udf84\ud85c\udcd5 :: class java.lang.String ]} ] [ long {\u2012\ucd08\u75ed=[ option:  \u2012\ucd08\u75ed  [ARG] :: \ud88f\udd8c\ud90c\udf7a\ud8f3\udd19\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9c3\ude40\udb4f\ude8a\udbca\udca5\udbbd\udeca\ud904\udc97\udb2f\udd0a\uee06\ud8df\udca5\udae5\udf17\u7753\ud9b0\ude46\udb68\ude98\ud81f\udc59\ud863\ude0d\uda27\udcd2\ud8c7\udca2\ud8a4\udf37\ud84c\udd42\ud9dd\udd25\uda35\udf03\ud9f5\udd00\uda68\udea4\ud818\udfa5\udafa\ude5c\ud982\udc12\uda7a\udf03\ud9cf\udffc\udb40\udd0e\ud815\ude9e\ud85c\udc7e\u70ae\udae2\udf84\ud85c\udcd5 :: class java.lang.String ]}...\012",
        Z.run(T, 1, 11, 3, 0, "", "\u2012\ucd08\u75ed", "\ud88f\udd8c\ud90c\udf7a\ud8f3\udd19\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9c3\ude40\udb4f\ude8a\udbca\udca5\udbbd\udeca\ud904\udc97\udb2f\udd0a\uee06\ud8df\udca5\udae5\udf17\u7753\ud9b0\ude46\udb68\ude98\ud81f\udc59\ud863\ude0d\uda27\udcd2\ud8c7\udca2\ud8a4\udf37\ud84c\udd42\ud9dd\udd25\uda35\udf03\ud9f5\udd00\uda68\udea4\ud818\udfa5\udafa\ude5c\ud982\udc12\uda7a\udf03\ud9cf\udffc\udb40\udd0e\ud815\ude9e\ud85c\udc7e\u70ae\udae2\udf84\ud85c\udcd5",
        5, 25081, 465001911, 4450452610753808281L, 37178L, true, true, (char) 8601, (char) 65068,
        Double.longBitsToDouble(0x3fde61ad912f73baL), Double.longBitsToDouble(0x3fe1014fd23e69a4L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\ucd08\ubb5e  :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ] [ long {\u6b2b\ucd08\ubb5e=[ option:  \u6b2b\ucd08\ubb5e  :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\ucd08\ubb5e  :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ] [ long {\u6b2b\ucd08\ubb5e=[ option:  \u6b2b\ucd08\ubb5e  :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: \u6b2b\ucd08\ubb5e :: class java.lang.String ]} ] [ long {\u6b2b\ucd08\ubb5e=[ option:  \u6b2b\ucd08\ubb5e  :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: \u6b2b\ucd08\ubb5e :: class java.lang.String ]} ] [ long {\u6b2b\ucd08\ubb5e=[ option:  \u6b2b\ucd08\ubb5e  :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 10, 14, "", "\u6b2b\ucd08\ubb5e", "\udb3a\uddbd\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e",
        0, 73780, -904953685, 3004745376390102358L, -86887L, false, true, (char) 6134, (char) 18705,
        Double.longBitsToDouble(0x3fe0cd0e586c8d10L), Double.longBitsToDouble(0x3fecf71f79e21f06L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 3, 0, "\ued39", "\u5d72\u70b7\ud12b\u1139\ucd7d\u8bec\ud48e\ua3a2\u202a\u38ae\ud5bc\u76ea", "\udb40\uddf4\ud8db\udd78\ud904\udc97\udbeb\udc5a\ud954\udc9f\uda14\udef4\udae5\udf17",
        32, 21516, -1759093860, 6105997343651973877L, -51033L, false, true, (char) 34627, (char) 64168,
        Double.longBitsToDouble(0x3fe99df8099a2b74L), Double.longBitsToDouble(0x3fdd059488269086L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: \u6b2b\ucd08\ubb5e :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: \u6b2b\ucd08\ubb5e :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: \u6b2b\ucd08\ubb5e :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: \u6b2b\ucd08\ubb5e :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 9, 10, 14, "", "\u6b2b\ucd08\ubb5e", "\udb3a\uddbd\udade\udc5d\ud8e6\udd25\ud8c5\udc89\udb9f\udf4e",
        0, 73780, -904953685, 3004745376390102358L, -86887L, false, true, (char) 6134, (char) 18705,
        Double.longBitsToDouble(0x3fe0cd0e586c8d10L), Double.longBitsToDouble(0x3fecf71f7c350606L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud811\ude48\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u8241\u41b5\u94fd\u3de0\ucca1\u7ea0\u236a\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 10, 10, "\037", "\u05a1\u333d", "\000\udade\udc5d\uda17\udcbd\ud89c\udf0d\000",
        -5, -1000, 0, 7644438481413865472L, -100000L, true, false, (char) 20821, (char) 38810,
        Double.longBitsToDouble(0x3fc3a000129511b0L), Double.longBitsToDouble(0x3fef616c200ff9baL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e :: class java.lang.String ]} ] [ long {\u6b2b\u345d\ubb5e=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e :: class java.lang.String ]} ] [ long {\u6b2b\u345d\ubb5e=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e :: class java.lang.String ]} ] [ long {\u6b2b\u345d\ubb5e=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e :: class java.lang.String ]} ] [ long {\u6b2b\u345d\ubb5e=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 11, 14, "", "\u6b2b\u345d\ubb5e", "\udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e",
        0, 1964, -904953688, 3004745376390102358L, 10466L, true, false, (char) 40279, (char) 25393,
        Double.longBitsToDouble(0x3fc3bceb129511b0L), Double.longBitsToDouble(0x3fe0cd0f286c8d10L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u6609=[ option: \u6609  [ARG] :: \ucd08\ubb5e\u6930 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u6609=[ option: \u6609  [ARG] :: \ucd08\ubb5e\u6930 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u6609=[ option: \u6609  :: \ucd08\ubb5e\u6930 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u6609=[ option: \u6609  :: \ucd08\ubb5e\u6930 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 9, 10, 2, "\u6609", "\ucd08\ubb5e\u6930", "\ud9e4\udc51\uda72\udf2b\ud8c5\udc89",
        29, 890, -770409148, -3886746987576229888L, -45007L, true, true, (char) 7834, (char) 62429,
        Double.longBitsToDouble(0x3fdc1446cc33155eL), Double.longBitsToDouble(0x3fbb23443bf1cac8L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u6609=[ option: \u6609  :: \ucd08\ubb5e\u6930 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u6609=[ option: \u6609  :: \ucd08\ubb5e\u6930 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u6609=[ option: \u6609  :: \ucd08\ubb5e\u6930 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u6609=[ option: \u6609  :: \ucd08\ubb5e\u6930 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 10, 10, 2, "\u6609", "\ucd08\ubb5e\u6930", "\ud9e4\udc51\uda72\udf2b\ud8c5\udc89",
        29, 890, -1189118652, -1319929980067315469L, -45007L, true, true, (char) 7834, (char) 62429,
        Double.longBitsToDouble(0x3fdc1446cc33155eL), Double.longBitsToDouble(0x3fc4eec8de4bf0b0L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 5, 5, 5, "\uda6a\udd2f\ud9a0\ude85\udb3b\udc22\ud80f\udeea\ud850\udcc9\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\udb47\udc80\uda39\udfa3\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\ud887\udd6d\uda27\udd7e", "\uc7e2\u1118\u4a97\u887d\ucc44\u8571\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 63434, 0, 7963154127576507090L, 60114L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fe869169496bc21L), Double.longBitsToDouble(0x3fe46842a000087dL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 8, 6, "\000\000\000\000\000\000\000\ud866\uddb3\udb36\udf1b\ud8e6\udd25|\000\udafc\udf6f\ud9f6\udd46\uc9de\ud9e3\ude8c\uc93d\udb4f\ude11\000", "\u8241\u41b5\u54fd\u3de0\ucca1\u8571\uc8c5\ucce7", "\000\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 8, 6, "\000\000\000\000\000\000\000\000\000\ud8d3\udc69|\000\udafc\udf6f\ud9f6\udd46\uc9de\ud9e3\ude8c\uc93d\udb4f\ude11\000", "\u8241\u41b5\u54fd\u3de0\ucca1\u8571\uc8c5\ucce7", "\000\uda83\udcde",
        46, 55330, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fe807ce4000bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: null :: class java.lang.String ]} ] [ long {\u6b2b\u345d\ubb5e=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: null :: class java.lang.String ]} ] [ long {\u6b2b\u345d\ubb5e=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: null :: class java.lang.String ]} ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 11, "", "\u6b2b\u345d\ubb5e", "\udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e",
        45, 1964, -2045804376, 3004745376390102358L, 10466L, true, false, (char) 40279, (char) 25393,
        Double.longBitsToDouble(0x3fc3bceb104511b0L), Double.longBitsToDouble(0x3fe0cd0f286c8d10L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\ud9cc\udef1\ud93d\ude2f :: class java.lang.String ]} ] [ long {\u6b2b\u345d\ubb5e=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\ud9cc\udef1\ud93d\ude2f :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\ud9cc\udef1\ud93d\ude2f :: class java.lang.String ]} ] [ long {\u6b2b\u345d\ubb5e=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\ud9cc\udef1\ud93d\ude2f :: class java.lang.String ]} ]\0121=java.util.ArrayList:[\u6b2b\u345d\ubb5e] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\ud9cc\udef1\ud93d\ude2f :: class java.lang.String ]} ] [ long {\u6b2b\u345d\ubb5e=[ option:  \u6b2b\u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\ud9cc\udef1\ud93d\ude2f :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 14, 11, "", "\u6b2b\u345d\ubb5e", "\udb3a\uddbd\udade\udc5d\udb6f\uddb2\ud9cc\udef1\ud93d\ude2f",
        59, -476, -2045777544, 3004745376390102358L, 10466L, true, false, (char) 40279, (char) 25393,
        Double.longBitsToDouble(0x3fc3bceb104511b0L), Double.longBitsToDouble(0x3fe0cd0f286c8d10L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    ::  :: class java.lang.String ]} ] [ long {=[ option:    ::  :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    ::  :: class java.lang.String ]} ] [ long {=[ option:    ::  :: class java.lang.String ]} ]\0121=java.util.Collections$SingletonList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    ::  :: class java.lang.String ]} ] [ long {=[ option:    ::  :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 14, 11, "", "", "",
        6, 99323, 1137039836, -7638131370561360588L, 97326L, false, false, (char) 32935, (char) 34319,
        Double.longBitsToDouble(0x3fb58a6cc0000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: null :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: null :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 9, 9, 11, "", "\u6b2b\u345d\ubb5e", "\udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud93d\ude3e",
        25, 61580, -2045804376, 3004745376390102358L, 10466L, true, false, (char) 40279, (char) 25393,
        Double.longBitsToDouble(0x3fc3bceb104511b0L), Double.longBitsToDouble(0x3fe0cd0f286c8d10L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u1d83=[ option: \u1d83 \u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\udab1\udd02\ud93d\ude2f :: class java.lang.String ]} ] [ long {\u345d\ubb5e=[ option: \u1d83 \u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\udab1\udd02\ud93d\ude2f :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u1d83=[ option: \u1d83 \u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\udab1\udd02\ud93d\ude2f :: class java.lang.String ]} ] [ long {\u345d\ubb5e=[ option: \u1d83 \u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\udab1\udd02\ud93d\ude2f :: class java.lang.String ]} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {\u1d83=[ option: \u1d83 \u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\udab1\udd02\ud93d\ude2f :: class java.lang.String ]} ] [ long {\u345d\ubb5e=[ option: \u1d83 \u345d\ubb5e  [ARG] :: \udb3a\uddbd\udade\udc5d\udb6f\uddb2\udab1\udd02\ud93d\ude2f :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 14, 11, "\u1d83", "\u345d\ubb5e", "\udb3a\uddbd\udade\udc5d\udb6f\uddb2\udab1\udd02\ud93d\ude2f",
        59, -476, -2045777544, 3004745376390102358L, 10466L, true, false, (char) 40279, (char) 25393,
        Double.longBitsToDouble(0x3fc3bceb104511b0L), Double.longBitsToDouble(0x3fe0cd0f286c8d10L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?   [ARG] :: null :: class java.lang.String ]} ] [ long {=[ option: ?   [ARG] :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?   [ARG] :: null :: class java.lang.String ]} ] [ long {=[ option: ?   [ARG] :: null :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: null :: class java.lang.String ]} ] [ long {=[ option: ?   [ARG] :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: null :: class java.lang.String ]} ] [ long {=[ option: ?   [ARG] :: null :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 10, 11, "?", "", "\udbac\udd93\ud9b5\uddda\udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud96e\uddf4\udb4c\udd5f",
        49, 50624, 699596800, -7545008184625201152L, 13750L, true, true, (char) 54374, (char) 51847,
        Double.longBitsToDouble(0x3fe0c22ea816e4f0L), Double.longBitsToDouble(0x3fd75342dfc7d0f0L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: null :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 7, 10, 10, "?", "", "\udbac\uddc4\ud9b5\uddda\udb3a\uddbd\udade\udc5d\ud8e6\udd25\udbc2\udf09\ud96e\uddf4\udb4c\udd5f",
        49, 60328, 699596800, -7545008184625201152L, 13750L, true, true, (char) 54374, (char) 51847,
        Double.longBitsToDouble(0x3fe0c22ea816e4f0L), Double.longBitsToDouble(0x3fd75342dfc7d0f0L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 14, 2, "\ud927\uddbb\ud9a0\ude85\udb3b\udc22\ud8f8\udc3d\ud9be\udcf4\udbac\udd93\uda7a\udc51\ud88b\ude45\udade\udc5d\ud8e6\udd25\ud8c5\udc89\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\ud9e3\ude8c\uc93d\udb4f\ude11\uda27\udd7e", "\u8241\u41b5\u94fd\u3de0\u5eb4\ucc90\u230b\u8f0d", "\ud909\ude67\uda83\udcde",
        46, 40386, 139549017, 7963154128566362834L, 81166L, true, false, (char) 19337, (char) 61335,
        Double.longBitsToDouble(0x3fec5fce4428bc21L), Double.longBitsToDouble(0x3fe46842a475087dL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 5, 14, 14, "\ud927\uddbb\u2b1e\udb3b\udc22\ud8f8\udc3d\ud90f\udcf0\udb4a\udd95\uda9f\udd51\udb2e\udf96\udade\udc5d\ud855\udfbe\u59b9\ud915\udcfd\ud9ed\udc74\ud9f8\udfe0\uda58\udf9a\udaa5\ude6d\uc90d\udb4f\ude11\uda92\udfb5", "\ucfdd\u48fb\ub9fb\u7561\u9d84\u3051\u98f7\u2344\u547b\u4a30\u5d93\u9549\u063a\u0998\u9589\ub19c\u5231\uc1f0\ube57\u013a\u3200\u5d05\u02a6\uc505\u3c9d\uc49c\u9019\u9d64\u2929\u8f04\u840a\u7428\u791e\uc045\u6880\u8c0d\ud26b\u9488\u55f5\u2dd2\ud2c1\ucc46\u8e81\u1091\ubedd\uc903\u100d\u322e\ub45b\u9d4e\u99ae\u9cb6\ucff3\u7441\ud348\ud765\ub869\u8813\uae31\u8b02\u3d13\u98ee\u3aa5\u743d\u59bf\u7cf1\ua571\u0734\u926a\u2bcc\u8022\u2c3e\u982c\uc067\u41f0\u1c6e\u96c6\u040b\ub4c4\u641f\u1340\u6d22\u9d65\u06c5\u8713\ua232\u1360\u639b\uac0b\u9032\u01d6\ubf64\u6e63\u0ef8\u419f\u74fc\ua22a\ua022\ub11b\u3d4b\u660a\u8a7c\u753f\u24d8\u98ca\uc1b3", "\ud83e\udd3d\udb00\udd6c\uda48\udd88\udb5b\ude91\ud896\udcd3\ud9cb\udd1c\udb59\ude1e\ud84f\udd92\udb4c\udd7f\ud950\udcf6",
        8, 8781, 1829130650, -6769035244611975736L, -9213L, false, false, (char) 10968, (char) 61367,
        Double.longBitsToDouble(0x3fd2772644608786L), Double.longBitsToDouble(0x3fe4f7c60e7ad0d7L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ? \u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a  [ARG] :: \ud94f\uded9\uda9c\udd5d\uda6b\ude6b\ud9e0\uddca\udb1e\udff6\udbc1\udfe8\udb79\udfe1\ud878\udd78\udab6\udc51\ud93b\udf28\ud900\udc67\ud90f\udfdc\ud8f8\udc14 :: class java.lang.String ]} ] [ long {\u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a=[ option: ? \u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354... |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ? \u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a  [ARG] :: \ud94f\uded9\uda9c\udd5d\uda6b\ude6b\ud9e0\uddca\udb1e\udff6\udbc1\udfe8\udb79\udfe1\ud878\udd78\udab6\udc51\ud93b\udf28\ud900\udc67\ud90f\udfdc\ud8f8\udc14 :: class java.lang.String ]} ] [ long {\u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a=[ option: ? \u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354...\0121=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a :: class java.lang.String ]} ] [ long {\u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a=[ option: ? \u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a  [ARG] :: \ud94f\uded9\uda9c\udd5d\uda6b\ude6b\ud9e0\uddca\udb1e\udff6\udbc1\udfe8\udb79\udfe1\ud878\udd78\udab6\udc51\ud93b\udf28\ud900... |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a :: class java.lang.String ]} ] [ long {\u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a=[ option: ? \u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a  [ARG] :: \ud94f\uded9\uda9c\udd5d\uda6b\ude6b\ud9e0\uddca\udb1e\udff6\udbc1\udfe8\udb79\udfe1\ud878\udd78\udab6\udc51\ud93b\udf28\ud900...\012",
        Z.run(T, 2, 11, 10, 11, "?", "\u97ea\u0a8d\ubc67\u07d4\u8d18\u2710\ua9ce\ucfda\ud7fa\u08b2\u8946\u684a\u116c\u32ee\000\u99ce\u2341\ud6b6\u6cf9\u6822\u2cd9\u0e0d\u8a05\ucdec\u4d91\u81d6\u2e56\uabc5\u458f\u35df\u1b53\u4540\u5fec\u5d04\u4a63\u27cf\u4a81\u5bb6\uab72\u137a\uad5a\ud02b\u4f99\u3e90\u852e\u0ad0\u82b1\uce92\ubc3b\u3d9f\u1848\u0eae\uaca1\u85ad\ua0d5\u427a\u1e26\u3354\u133a", "\ud94f\uded9\uda9c\udd5d\uda6b\ude6b\ud9e0\uddca\udb1e\udff6\udbc1\udfe8\udb79\udfe1\ud878\udd78\udab6\udc51\ud93b\udf28\ud900\udc67\ud90f\udfdc\ud8f8\udc14",
        16, 94623, 1104027317, -7286552615679152108L, 29809L, true, false, (char) 50281, (char) 34525,
        Double.longBitsToDouble(0x3feb6f451f56a92cL), Double.longBitsToDouble(0x3fdabb8cfb168ab2L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedValues:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 2, 1, 14, "\ud927\uddbb", "\u2fb2\ua949\u682a\u4380\u1fd6\ua171", "\ud93d\ude3e\uda2a\ude73\ud9db\ude4f\ucac9\uda85\udcb8\ud95b\udd59\udabb\udd5c\u0292\udbd8\ude46\udb61\udd5f\ucf6c\ud8bf\udd1f\u717a\udbfc\udd0c\ud994\udf42",
        17, 64226, 2003383622, 2806213753109285190L, -68737L, false, true, (char) 16178, (char) 64857,
        Double.longBitsToDouble(0x3fd14371ef86931aL), Double.longBitsToDouble(0x3fd3ead07bb4a1f4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.OptionGroup|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getNames||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getOptions||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getSelected||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|isRequired||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|setRequired|boolean|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|setSelected|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|toString||new:org.apache.commons.cli.OptionGroup:",
    "C|org.apache.commons.cli.OptionGroup|<init>|",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,boolean,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,java.lang.String,boolean,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOptionGroup|org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getMatchingOptions|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOption|java.lang.String|new:org.apache.commons.cli.Options:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
