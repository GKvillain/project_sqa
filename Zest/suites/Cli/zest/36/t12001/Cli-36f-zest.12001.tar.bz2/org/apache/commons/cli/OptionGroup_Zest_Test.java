package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class OptionGroup_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\u5997\uda11\ude10", "\ub12c\u5817\u7a64\ubea6\u1fdf\u75a3\u2ecc\u5b86\u5328\u565b\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        16, 90990, -1676786907, -6533368063640072778L, 84099L, false, false, (char) 49092, (char) 55400,
        Double.longBitsToDouble(0x3f9997d3e6ca6380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\udb30\udcc3\uda11\udd95", "\ub12c\u5817\u7a64\ubea6\u1fdf\u75a3\u2ecc\u5b86\u5328\u565b\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50\udb93\udf5f\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        16, 90990, -1676786907, -6533460419798320714L, 6671L, true, false, (char) 53948, (char) 39789,
        Double.longBitsToDouble(0x3fe91a3dd0d28fb2L), Double.longBitsToDouble(0x3fe738a6f2c9d59fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 5, "\u5997\uda11\ude10\udb25\udc7a\uda37\udf6d\uda2f\udfa0\udbed\udf12\udb41\udeeb\udbed\udcdc\ud860\udcee\udab6\udf8a", "\u447e\u565b\u8a47\u6222", "\ud84f\udc49\udae3\ude17\udb20\ude2a\udaf3\uddeb\udb31\udc65\udb93\udf0c\ud91e\udf1a\ud8dd\udd94\ud927\udc2b\udb77\udde4\udb9f\ude3d\uda5a\udcb0",
        4, 46340, -1868618615, -1804257806193929981L, 61507L, false, true, (char) 64049, (char) 27755,
        Double.longBitsToDouble(0x3fdb6b254c2d07b4L), Double.longBitsToDouble(0x3fc6a54e9a733b9cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 5, 14, 8, "\u5997\uda11\ude10", "\ub12c\u88af\ub65d\u4577\u1fdf\u8007\u2e07\u5b86\u5328\u565b\u8a47\u43da\u1b24\ud1c7\u0d04", "\udb4b\udd76",
        48, 49381, 558045499, 8734644439442867627L, 4289L, true, false, (char) 27441, (char) 17353,
        Double.longBitsToDouble(0x3fe0a37aa1169053L), Double.longBitsToDouble(0x3fd03e6ab853552aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\u5997\uda11\ude10", "\ub12c\u5817\u7a64\ubea6\u1fdf\u75a3\u2ecc\u5b86\000\000\u8425\ub305\u1bb0\u7aeb\u09ae", "\udae0\udca1\u01b9\000\000\000\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\000\udb46\udd08\000",
        35, 90990, -1676786907, -6533368063640072778L, 84099L, false, false, (char) 49092, (char) 55400,
        Double.longBitsToDouble(0x3f9997d3e6ca6380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 6, 5, "\u5997\udbd2\udd91", "\ub12c\u5817\u7a64\ubea6\u1fdf\u75a3\u2ecc\uab00\u5328\u565b\u8a47\ub305\u1bb0\u7aeb\u09ae", "\ud99f\uddac\udb14\udd59\udb93\udfa1\ud9ad\udfa1\ud894\udf9b\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        16, 90990, -1676786907, -6533368063640072778L, 44203L, false, false, (char) 42963, (char) 39789,
        Double.longBitsToDouble(0x3fe91a3dd0d28fb2L), Double.longBitsToDouble(0x3fe738a6f2c9d59fL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\u5997\ud827\udff4", "\ub12c\u9f78\u38b0\u29de\u1fcb\u75a3\u2ecc\u5b86\u5328\u565b\u8a47\ucbe9\u1bb0\u7aeb", "\ud90e\udd1c\ud818\udffe\udb40\udeeb\udb93\udf0c\ud91e\udf1a\ud9e0\udecc",
        -5, 56270, -540413283, 3031079210156638497L, 43101L, false, false, (char) 7259, (char) 17072,
        Double.longBitsToDouble(0x3fe92db8605d9c0eL), Double.longBitsToDouble(0x3fdb6a554c2d07b4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\u5997", "\ud28b\ub12c\u5817\u7a64\ubea6\u1fdf\u75a3\u2ecc", "\udb55\uddc6\ud938\udec1\ud9c6\ude71\ud9fd\ude4b",
        12, 83328, 1327610495, -3141327062333428128L, -62539L, true, true, (char) 34102, (char) 48866,
        Double.longBitsToDouble(0x3fa3f62a80000000L), Double.longBitsToDouble(0x3e2212a000000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\u5997\uda11\ude10", "\ub12c\u5817\u7a64\ubea6\u1fdf\u75a3\u2ecc\u5b86\u5328\u565b\u8a47\ub305\u1bb0\u7aeb\ubadc", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf8\udc0e\ud901\udc82\ud91c\udef6\uda5c\ude3c\uda5a\udd07\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b\ud981\udfac\u26d8\ud889\udd41\ud8c7\udf26\ud867\udceb\ud8c7\udd0b\ud8b7\udeba\ud94e\ude91\udb7f\ude2d\ud869\udef0\udaf6\udc84\udb74\ude0c\udaac\udc67\ud939\udca5\udb82\udcfe\udb48\uddf6\udafb\udd55\ud811\udf4b\ud90a\udfd1\ud9d1\udc1f\ud9fd\udcb9\udb8c\udced\udaf9\udd9c\ud9ee\udd9b\ud97e\udd00\uda3f\udf51\udab0\uddc5\uda9e\udedd\udb62\ude4e\ud960\udecf\uda0c\udd34\udb84\udd06\udb10\udcdc\uda94\udc7b\uda6f\ude1c\ud971\udd54\ud86e\ude74\uda60\udd0b",
        0, 25156, -1546258295, -1354628986283843057L, 52902L, false, true, (char) 45389, (char) 13307,
        Double.longBitsToDouble(0x3fe97a469c566fcbL), Double.longBitsToDouble(0x3fe1dc966736bf92L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 1, 1, 6, "\udbf1\udc96\uda11\ude10", "\ub12c\u5817\u7a64\ubea6\u1fdfs\u5af2\u5b86\ub74e\u4a00\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50U\000\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\udbbf\ude18\000\ud92e\udef7\ud8cf\udc4b",
        16, 90960, -1676786907, -6533368063640072778L, -46973L, false, false, (char) 49092, (char) 55400,
        Double.longBitsToDouble(0x3f9997d3e6ca6380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 8, 1, 2, "\u5997\uda11\ude10", "\ub12c\u4c87\u57b0\u1110\u1fed\u75a3\u2ecc\u5b86\u5328\u565b\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        16, 90990, -1676786907, -6533368063640072778L, 84099L, false, false, (char) 49092, (char) 55400,
        Double.longBitsToDouble(0x3f9997d3e6ca6380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\uda66\udc19", "\ud28b\ub12c\u5817\u7a64\ubea6\u86fb\u75cb\u6d2b\u9557\u5328\u565b\u44a6\u5004\u330d\ub31f\u0332\u8048\ub002\u13c3\u0c46\u8494\u93a5\ud046\uae5b\u78a9\ud05d\u0d17\u16b6", "\udb81\udf97\ud962\udffa\ud8cf\udc4b\ud981\udfac\ud967\ude19\ud889\udd7b\uda5c\udc91\u7e65\ud9ca\udc96\ud92a\uddd0\ud8ff\udebf\uda96\udeb4\ud869\udef0\udaf6\udc84\udb74\ude0c\udaac\udc67\ud9e5\udd9a",
        28, -522, -1062780684, 539509042243473252L, -69203L, false, false, (char) 6686, (char) 9059,
        Double.longBitsToDouble(0x3fd8a6cac67c2f3aL), Double.longBitsToDouble(0x3fe9f3dec0306480L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 14, 4, 5, "\u5997\uda11\ude10", "\ub12c\u4a2a\u7ca2\u125a\u1fdf\u75a3\u2ecc\u5b86\u5328\u565b\u8aa1\ub305\u1bb0\u358e\u6bd5", "\udae0\udca1\udb31\udc50\ud812\udd11\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb92\ude99\udbd6\ude6d\ud8cf\udc4b",
        16, 90990, 588137253, -6533368063640072778L, 84099L, false, false, (char) 39125, (char) 55400,
        Double.longBitsToDouble(0x3f9997d3e6ca6380L), Double.longBitsToDouble(0x3fe86d37c01a4e65L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 5, "\ud966\udf15\ud8f1\udd60", "\ub12c\u5817\u7a64\u8678\u34df\u152d\uade4\u7f83\u5383\u70eb\u8a47\ud7ba\u1bb0\u7aeb\u09ae", "\udb33\udf38\udbb1\udd9d\udbac\udef8\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\ud9b4\udcee\ud955\udc3e\udb81\udf97\ud83e\udcfe\ud8ce\udffc",
        16, 90990, -1676786907, -3408203072481196374L, 84099L, false, false, (char) 7621, (char) 55400,
        Double.longBitsToDouble(0x3f9997d34959c380L), Double.longBitsToDouble(0x3fee75b2357bc78dL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\u5997\uda11\ude10", "\ub12c", "\udadf\udf9d\ud9ce\udcfe",
        30, 35425, 824748355, -7054555455220659515L, -3709L, false, true, (char) 32932, (char) 4815,
        Double.longBitsToDouble(0x3fe306a339ae264bL), Double.longBitsToDouble(0x3fe2a965d5a9c850L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 5, "\u5997\uda11\ude10", "\ub12c\u7992\u5308\u36c7\ub4e8\u727c\u12cf\u19ee\u3f09\u565b\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae0\udd04\udb31\udc50\ud8ec\udd08\ud91e\udf1a\udaf7\udfc0\ud968\udf36\ud91c\udfc5\ud985\udd70\udb13\ude8f\udbf3\udeb2\uda94\udc33\ud95f\ude1f\ud94c\uddcd\uda1f\udc8c\ud8cf\udc4b",
        16, 90990, -1676786907, -6533368063640072778L, 17941L, false, false, (char) 42963, (char) 39789,
        Double.longBitsToDouble(0x3fe91a3dd0d28fb2L), Double.longBitsToDouble(0x3fe738a6f2c9d59fL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] :: \udbed\udf12 :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] :: \udbed\udf12 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] :: \udbed\udf12 :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] :: \udbed\udf12 :: class java.lang.String ]} ]\012",
        Z.run(T, 1, 11, 1, 5, "", "\000", "\udbed\udf12",
        7, 1240, -374228401, 1592263757206170585L, -22383L, true, false, (char) 35176, (char) 50880,
        Double.longBitsToDouble(0x3fe5563800233d9cL), Double.longBitsToDouble(0x3fc6198b29fd4754L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 3, 5, "\u5997\uda11\ude10", "\ub12c\u5817\u7a64\ubea6\u1fdf\u6f07\u2e72\u0732\u5d42\u565b\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae6\udd25\udb80\udda3\udb93\udf5e\ud91e\udf1a\ud9ff\udf32\ud84c\ude25\udb1c\udff6\ud985\udda4\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b\udb71\udfa4\ud97d\uded1\ud889\udd41\ud844\udf05\u7e65\ud8f4\udc8b\ud992\udea9\ud8ff\udebf\uda96\udeb4\ud869\udef0\udaf6\udc84\udb74\ude0c\ud995\ude5b\ud939\udca5\udb82\udcfe\udb48\uddf6\udafb\udd55\u492c\ud8a0\udc69\ud846\udfbe\ue381",
        5, 25524, 854321512, 4795042339118424384L, -26827L, true, true, (char) 28010, (char) 60094,
        Double.longBitsToDouble(0x3fef00788a7039b9L), Double.longBitsToDouble(0x3fcf0334faaff7a4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 5, "\ud8fb\udc28\uda11\ude10", "\u1e36\u5817\u7a64\ubea6\u2578\u863b\u1dae\uc885\u5328\u565b\uaf46\ub305\u1bb0\u7aeb\u0a2d", "\ud981\udc22\ud88f\udf5f\udb91\udc98\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud99e\udc27\uda3c\udd43\ud885\udf9b\udb44\udd80\ud962\udffa\ud8cf\udc4b",
        16, 90990, -1676786689, -6533368063640072778L, -23559L, true, false, (char) 21973, (char) 34948,
        Double.longBitsToDouble(0x3fe738a6f2c9d59fL), Double.longBitsToDouble(0x3f9997d3eeea6380L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 10, 5, "\u5997\uda11\ude10", "\u9274\uc4d4\u0443\ubea6\u1fdf\u75a3\ub4f4\u710d\u43b7\u565b\u8a47\u1505\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50\ud99b\udf10\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\udbad\udfdf\udbf7\udd97\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        16, 90990, -1676786907, 5572307734699898566L, 84099L, false, false, (char) 49092, (char) 55400,
        Double.longBitsToDouble(0x3f9997d3e6ca6380L), Double.longBitsToDouble(0x3fc6f4df1eb3885cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 9, 13, "\uda0f\ude4e", "\ud28b\ub12c\u5817\u7a64\ubea6\u1fdf\u0dcf\u9ab7", "\ud8fa\udedd",
        9, 28459, 1033691818, -3721811523952838480L, 74510L, true, false, (char) 46585, (char) 34102,
        Double.longBitsToDouble(0x3fdab793704fd8aaL), Double.longBitsToDouble(0x3fd98cf87cf7be2aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\u5997\uda11\ude10", "\ub12c\u5817\u7a64\ubea6\u1fdf\u75a3\u2ecc\u5b86\u5328\u565b\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\uda18\udf2e\ud902\udd64\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        16, 90990, -1676786907, -6533368063640072778L, 34985L, false, false, (char) 20782, (char) 22882,
        Double.longBitsToDouble(0x3fc9b2f54494ca24L), Double.longBitsToDouble(0x3fd421c032f6957aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 1, 14, 3, "\udac1\udc6e\ud808\udd3d\udb25\udc6c\udb92\udfba\udaa3\udd4a\udbed\udf12\udb41\udeeb\udb81\udd0f\ud8be\uddb6\ud953\udcc0\udabe\udec1\uda77\udc28\u016c\udb55\uddc6", "\u1bb0\u7aeb\u09ae\u8048\ub002\u13c3\u56b1\u5055\u623a\ud046\uae5b\u78a9", "\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud9be\udfc3\ud82e\udd6f\ud998\udfde\ud889\udd41\ud844\udf05\u7e65\ud9ca\udc96\udaf3\udd55\ud8ff\udec6",
        1, 7926, -1884106973, 711279371550029454L, 34985L, false, false, (char) 62656, (char) 5892,
        Double.longBitsToDouble(0x3fdb4fca815dd478L), Double.longBitsToDouble(0x3fd53743881aa8e6L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 3, 3, 11, "\u9c97\uda49\udeea\udb37\udeff\uda37\udf6d\uda2f\udfa0\udbed\udf12\ud8ba\ude81\udbec\ude8f", "\u2ecc\u5b86\u592c\u565b\u8a47\u5f90\u7c18\u268a", "\ud90e\udc78\ud8eb\ude07\ud9a4\udd73\udabe\udd58\uda35\udf7b\udaf7\udfba",
        -5, 7359, 1458542366, 3031079244516376865L, 43101L, true, false, (char) 7259, (char) 17072,
        Double.longBitsToDouble(0x3fe92db8605d9c0eL), Double.longBitsToDouble(0x3fd664554c2d07b4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 5, "\u5997\uda11\ude10", "\u692d\u5817\u7a64\ubea6\u1fdf\u75a3\u2f6c\u5b86\u76cc\u5648\u8a47\u1258\u059e\ud0a8\u09ae", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ub57f\uda8a\udffb\uda5a\udcf5\ud8a8\udc2b\ud9eb\ude19\ud851\udc98\ud953\udc2d\uda07\udd3b\ud8cf\udc4b\ud981\udfac\ud97d\uded1\ud889\udd41\udb9c\ude31\u7e65\ud9ca\udc96",
        16, 58516, -793270914, 5168666403509817123L, 34985L, false, false, (char) 58768, (char) 50919,
        Double.longBitsToDouble(0x3fe2815c0e6dd55aL), Double.longBitsToDouble(0x3fe81bc245b2fed5L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ]\0121=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 11, 8, 0, "\u5997\u6db6", "\ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        41, 22326, 0, -6533368463072031306L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f999700e6ca6380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 7, 7, 5, "\u5997\uda11\ude10\udb25\udc7a\uda37\udf6d", "\u79d1\ubea6\u1fdf\ub5cb\u2ecc\u5b86\u5328\u565b", "\ud9fd\ude4b\udb07\udd5d\uda65\udd82",
        50, 43798, 642477664, -8578428531500929887L, -79676L, true, true, (char) 56444, (char) 34037,
        Double.longBitsToDouble(0x3fe7e5cee138fa0aL), Double.longBitsToDouble(0x3feaa3bbab149d54L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 5, "\u5997\ud9ee\udf3e", "\ub12c\u5817", "\uda93\udd69\ud953\udcc0\udabe\udec1\uda60\udc7a",
        31, 66892, 1489034785, -4057560976225148246L, 47321L, true, false, (char) 4815, (char) 17096,
        Double.longBitsToDouble(0x3fdae264b4aa5974L), Double.longBitsToDouble(0x3fda9c850b39a934L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 5, "\u5997\uda11\ude10\udb25\udc7a\uda37\udf6d\uda2f\udfa0\udbed\udf12\udb41\udeeb\udbed\udcdc\ud860\udcee\udab6\udf8a", "\u447e\u565b\u8a47\u6222", "\ud84f\udc49\udae3\ude17\udb20\ude2a\ud9cc\udcf8\udb40\udde9\udb93\udf0c\ud91e\udf1a\ud8dd\udd94\ud927\udc2b\udb77\udde4\udb9f\ude3d\uda5a\udcb0",
        4, 46340, -1868618615, -1804257806193929981L, 61507L, false, true, (char) 64049, (char) 27755,
        Double.longBitsToDouble(0x3fdb6b254c2d07b4L), Double.longBitsToDouble(0x3fc6a54e9a733b9cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedValues:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 2, 5, 9, "\u58e1\uda11\ude10\ua13d", "\u5817\u7a64\u60cb\uaa9f\u6119\u6d81\u2aeb\u16be\u5679\u8a47\u6222\u377a\u699a\u6d39\u4528\u0d7c\u1232", "\ud91e\udf1a\ud8dd\udd94",
        55, 6842, -1084937476, 3034374944721289505L, -51548L, true, true, (char) 40100, (char) 17072,
        Double.longBitsToDouble(0x3fe92db8605d9c0eL), Double.longBitsToDouble(0x3fdb6b254c2d07b4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  :: null :: class java.lang.String ]} ] [ long {} ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 5, "\u5997", "\u9535\u6ff7\000\u0927\ua662\u289b\u9d64\u2ecc", "\udb55\uddc6\ud938\udec1\udbab\udf58\ud86e\udf5f\udb6e\udfa8\ud84f\udc49B\000\udaf3\uddeb\u00c3\000\ud891\udd68\ud8dd\udd94\ud927\udc2b\udb77\udde4\udb9f\ude3d\000\ud897\udf0a",
        14, 73032, 0, -6155013315731914752L, -100000L, false, false, (char) 7898, (char) 63272,
        Double.longBitsToDouble(0x3fe4e6773e28b86dL), Double.longBitsToDouble(0x3fad2b9f88ff9160L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 5, "\u5997\uda11\ude10\ud817\ude7b\uda37\udf6d\udb29\udefe\ud9c0\udfbb\udb41\udedf\udbed\udcdc\ud860\udcee\udab6\udf8a", "\u447e\u565b\u8a47\u439d", "\ud84f\udc49\udae3\ude17\udb20\ude2a\udaf3\uddeb\udb31\udc65\udb93\udf0c\ud91e\udf1a\ud8dd\udd94\ud927\udc2b\udb77\udde4\udb9f\ude3d\udafb\udf42\ud8f9\udc22\uda60\uddb2\udaa7\uddf8\ud8cc\udf9c\ud962\udffa\ud8cf\udc4b\ud981\udfac\ud97d\uded1\ud9af\ude14\ud899\udc60\u7e65\ud9ca\udc96\ud92a\uddd0\udbc6\udc03\udbd8\udf5a\ud9a6\udde4\udb39\udf93\ud9f6\udcce\udb7b\udec7\ud982\udff2\u4509\uda6b\ude79\ud931\udcb7\udbce\udf67\udbac\udd44\udbd6\udf74\u773b\ud8b6\udebe\ud890\udec0\uda85\udcd7\ud804\ude7e\ua5e0\udb04\ude11\udabd\udefd\uda27\udc35\udafb\ude2e\udaae\udec6\ud868\udd33\ud8f5\udd5b\udac6\udc14\ud818\uddaf\ud8bf\udc9d\udaf3\ude03\ud82e\ude5b\udb49\uddfc",
        34, 70133, 2075696269, -2185661249451692425L, 15496L, false, true, (char) 23232, (char) 30204,
        Double.longBitsToDouble(0x3fd57552db7bae24L), Double.longBitsToDouble(0x3fe9647321b805edL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 6, 6, 5, "\u5c97\uda11\ude10\udb25\udc7a\uda37\udf6d\uda69\udf9d\udbed\udf12\udb41\udeeb\udbed\udcdc\ud860\udcee\udab6\udfdd", "\u5ec7\uc0c0\u29c9\u6222", "\ud84f\udc49\udae3\ude17\udb20\ude2a\udaf3\uddeb\udb31\udc65\udad1\udf0b\ud91e\udf1a\ud8dd\udd94\ud9b2\udf10\udb77\udde4\udb9f\ude3d\uda5a\udcb0",
        4, 46416, -1868618615, -1844216614252850941L, 61507L, false, true, (char) 64049, (char) 27755,
        Double.longBitsToDouble(0x3fdb6b254c2d4bb4L), Double.longBitsToDouble(0x3fdb52a74e658930L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  [ARG] :: \u7966\ub628\u88af\u0bba\u4577\u1d5b\u09e3\u027a\u5b86\u5328\u565b\u8a47\u2eb3\u1b21\uce52\u061c :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  [ARG] :: \u7966\ub628\u88af\u0bba\u4577\u1d5b\u09e3\u027a\u5b86\u5328\u565b\u8a47\u2eb3\u1b21\uce52\u061c :: class java.lang.String ]} ] [ long {} ]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 9, 5, 14, "\u5997", "\u7966\ub628\u88af\u0bba\u4577\u1d5b\u09e3\u027a\u5b86\u5328\u565b\u8a47\u2eb3\u1b21\uce52\u061c", "\udb4b\udd76",
        48, 42741, 558045499, 8734644439442867611L, 4289L, true, false, (char) 27441, (char) 17353,
        Double.longBitsToDouble(0x3fe0a37aa2169053L), Double.longBitsToDouble(0x3fd03e6aa853552aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 14, 14, 8, "\u5997\uda11\ude10", "\ub12c\u88af\ub65d\u4577\u1fdf\u8007\u2e07\u5b86\u5328\u565b\u8a47\u43da\u1b24\ud1c7\u0d04", "\udb4b\udd76",
        48, 49381, 558045499, 8734644439442867627L, 4289L, true, false, (char) 27441, (char) 17353,
        Double.longBitsToDouble(0x3fe0a37aa1169053L), Double.longBitsToDouble(0x3fd03e6ab853552aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 11, 8, "\u5997\ud968\ude5c", "\ub12c\u88af\u23ff\uce86\u1fdf\u8007\u6781\u51e6\u5328\u46a8\u8a80\u43da\u1b24\u6b2a\u0d04", "\udb4b\udd76",
        48, 49381, 558045499, 8734644439442867627L, 4289L, true, false, (char) 27441, (char) 17353,
        Double.longBitsToDouble(0x3fe0a37aa2169053L), Double.longBitsToDouble(0x3fd03e6ab853552aL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 6, 5, "\ud90f\udf83", "\ud28b\u646f\u60b4", "\udb7e\udf37\udabb\udd96\udabe\udec1\ud916\udf10\u016c\udb55\uddc6\ud938\udec1\ud9c6\ude71\ud9fd\ude4b\ud8bf\udf73\uda65\udd82\udb43\udf28\ud90e\udd1c\ud99f\uddac\udb14\udd59\udb93\udfa1\ud9d1\udc73\ud92b\udfe9\udb69\udcc6\udb81\udc89\ud97a\udd68\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud925\udc7d\ud981\udfac\ud97d\uded1\ud889\udd41\ud844\udf05\u7e65\uda58\uddde\udbcc\udfa1\ud8f3\udcaf\uda96\udeb4\ud98a\uddb9\udaf6\udc84\udb74\ude0c\udb54\udf3b\udb8a\udc39\ud873\udff7\ud827\uddf2\udbb4\udee5\udabe\udf32\udbd0\udf5c\ud815\udf90\ud9a8\uded4\udb46\udd9d\uda3c\udf25\udb99\uddfc\udb58\udf70\ud8ac\udf1e\udbbf\udeb8\udb96\udd64\udbfe\udf1f\ud835\udd80\udbf2\udc11\uda2b\udfe8\udb19\udfc5\ud88f\udfc3\uda92\udf15\ud923\udc61\udb52\udc90\ucb42\udaad\udd53",
        29, -505, 586262481, 2070860586993450352L, -40181L, false, true, (char) 56356, (char) 50941,
        Double.longBitsToDouble(0x3fa0b29094702170L), Double.longBitsToDouble(0x3fd339a3279eef08L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 1, 2, "\ud9e5\udf01\uda11\ude10", "\u0d4f\u4c87\u57b0\u1110\u1fed\u75a3\u2ecc\u5b86\u5328\u565b\u8a47\ub305\uac1a\u7aeb\u3aad", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\ud901\udc82\uda6c\udea9\udbbe\udd73\ud876\udc2a\ud946\udd00\uda60\ude6f\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b\ud981\udfac\ud97d\uded1\ud889\udd41\ud844\udf05\u7e65\ud9ca\udc96\udbbc\ude39\ud8ea\udcc7\uda96\udeb4",
        11, 47022, 350157010, -3053534114967518519L, -92010L, true, false, (char) 1663, (char) 48923,
        Double.longBitsToDouble(0x3fe6d736ecc1d009L), Double.longBitsToDouble(0x3fe277ed83b23f39L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 13, 7, "\u5997\ud8ed\ude16", "\u71c3\u4c87\u3fc9", "\udbe2\udca9\ud9b5\udfd0\udb33\ude7f",
        45, 60689, 1726917166, -4057561006289919318L, 32944L, true, false, (char) 4815, (char) 17096,
        Double.longBitsToDouble(0x3fdae264b4aa5974L), Double.longBitsToDouble(0x3fc1590a014c0de8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 11, 13, "\u5997\uda11\ude10", "\u9f56\u80b7\u57b0\u1110\u1fed\u75a3\u2ecc\u5b86\u5328\u565b\u23be\u90ae\u1bb0\u7aeb\u09ae", "\udae0\udca1\ud8af\udc4f\ud904\udd3a\ud91e\udf16\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        16, 90990, -1676786907, -6533368063640072778L, 84099L, false, false, (char) 49092, (char) 55400,
        Double.longBitsToDouble(0x3f9997d3e6ca6380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\0121=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 8, 8, 4, "\ud9f4\ude65\udaa7\udd24\uda60\udd93\udb01\udc51\udbfe\ude6a\ud8f5\ude25", "\u1fed\uc7b6\u2edb\u5b86", "\ud95d\ude2e\udae0\udd3a\udb2e\uddd5",
        49, 60185, 1327610495, 6145095369304534624L, -62539L, true, true, (char) 34102, (char) 19760,
        Double.longBitsToDouble(0x3fa3f6092072fad0L), Double.longBitsToDouble(0x3fb77c455dd007e8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \026\000\000\000\udad8\udf00\000\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] [ long {\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \026\000\000\000\udad8\udf00\000\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \026\000\000\000\udad8\udf00\000\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] [ long {\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \026\000\000\000\udad8\udf00\000\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ]\0121=java.util.ArrayList:[\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \026\000\000\000\udad8\udf00\000\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] [ long {\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \026\000\000\000\udad8\udf00\000\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 14, 4, "", "\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u00c5\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b", "\026\000\000\000\udad8\udf00\000\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9",
        3, 67226, -947059762, -431231231445627469L, 96009L, true, false, (char) 47579, (char) 38552,
        Double.longBitsToDouble(0x3fe71672d5a6d2b5L), Double.longBitsToDouble(0x3fe3eb6d2fec6ef4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 1, 8, "\u00e1\u6d03\000\000\udaa1\udd21\udbed\udf56\udb41\udeeb\udb81\udccd\ud9ce\udcfe\ud953\udcc0\ud878\udebe\uda77\udc28\u016c\ud9d9\udec6\ud938\udec1\ud809\udca4\ud9fd\uddf7\udb07\udd17", "\u3efe\u7c5a\u3b44\u2336\u4e8b\u17dd", "\ud9ac\udda0\udb61\ude8e\udba7\udc02",
        26, 24368, -1890225876, 5176021664470257915L, -89982L, true, true, (char) 44928, (char) 514,
        Double.longBitsToDouble(0x3fb93fa51456d4a0L), Double.longBitsToDouble(0x3fe6c633c0ec50b0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] ::  :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] ::  :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] ::  :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] ::  :: class java.lang.String ]} ]\012",
        Z.run(T, 1, 11, 1, 5, "", "\000", "",
        6, 24800, -1763861760, -1607298743158645901L, -56669L, true, true, (char) 59614, (char) 35176,
        Double.longBitsToDouble(0x3f48d80aab1c0000L), Double.longBitsToDouble(0x3fa19ece0b0cc590L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] :: \u4275 :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] :: \u4275 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] :: \u4275 :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] :: \u4275 :: class java.lang.String ]} ]\012",
        Z.run(T, 1, 11, 1, 5, "", "\000", "\u4275",
        7, 4448, -374216879, 1592263757206170585L, -22383L, true, false, (char) 35176, (char) 50880,
        Double.longBitsToDouble(0x3fe5563800233d9cL), Double.longBitsToDouble(0x3fc6198b29fd4754L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u3ad0=[ option: \u3ad0 \u0600\u5934\u5817\u7a64\ube64\u7593\u72ac\ud4b8\u5b86\u5328\u565b\u1075\u7d38\u1bb0\u7aeb\u09ae\u70ed\u7097\u48ad\uc392\u7b89\u1120\u0643\u4803\uafa7\u9b26\u6dc6\u9019\u0754\ua20f\u805e\ud6a1\u98bc\uae54\u8307\u822a  :: \ud9ea\udd43\udb75\udcf4\ud9b1\udd81\udb23\ude9e\udb65\udd09\udb9c\udec1\udbc1\udd4d\ud9de\udd5f\ud899\udcfe\uda87\udf5f\ud92b\udccf\udad3\udd78\ud89f\udf98\uda50\ude61\ud8c2\udd4f\ud871\ude89\ud8e7\udc36\ud93b\udfe0\udb41\udfd8\udb77\udc8f\uca6d\ud976\udc1e\ud982\udf22\ud884\udf32\uda9c\udeeb\ud89b\udfa3\ud99a\udc72 :: class java.lang.String ]} ] [ long {\u0600\u5934\u5817\u7a64\ube64\u7593\u72ac\ud4b8\u5b86\u5328\u565b\u1075\u7d38\u1bb0\u7aeb\u09ae\u70ed\u7097\u48ad\uc392\u7b89\u1120\u0643\u4803\uafa7\u9b26\u6dc6\u9019\u0754\ua20f\u805e\ud6a1\u98bc\uae54\u8307\u822a=[ option: \u3ad0 \u0600\u5934\u5817\u7a64\ube64\u7593\u72ac\ud4b8\u5b86\u5328\u565b\u1075\u7d38\u1bb0\u7aeb\u09ae\u70ed\u7097\u48ad\uc392\u7b89\u1120\u0643\u4803\uafa7\u9b26\u6dc6\u9019\u0754\ua20f\u805e\ud6a1\u98bc\uae54\u8307\u822a  :: \ud9ea\udd43\udb75\udcf4\ud9b1\udd81\udb23\ude9e\udb65\udd09\udb9c\udec1\udbc1\udd4d\ud9de\udd5f\ud899\udcfe\uda87\udf5f\ud92b\udccf\udad3\udd78\ud89f\udf98\uda50\ude61\ud8c2\udd4f\ud871\ude89\ud8e7\udc36\ud93b\udfe0\udb41\udfd8\udb77\udc8f\uca6d\ud976... |this=org.apache.commons.cli.Options:[ Options: [ short {\u3ad0=[ option: \u3ad0 \u0600\u5934\u5817\u7a64\ube64\u7593\u72ac\ud4b8\u5b86\u5328\u565b\u1075\u7d38\u1bb0\u7aeb\u09ae\u70ed\u7097\u48ad\uc392\u7b89\u1120\u0643\u4803\uafa7\u9b26\u6dc6\u9019\u0754\ua20f\u805e\ud6a1\u98bc\uae54\u8307\u822a  :: \ud9ea\udd43\udb75\udcf4\ud9b1\udd81\udb23\ude9e\udb65\udd09\udb9c\udec1\udbc1\udd4d\ud9de\udd5f\ud899\udcfe\uda87\udf5f\ud92b\udccf\udad3\udd78\ud89f\udf98\uda50\ude61\ud8c2\udd4f\ud871\ude89\ud8e7\udc36\ud93b\udfe0\udb41\udfd8\udb77\udc8f\uca6d\ud976\udc1e\ud982\udf22\ud884\udf32\uda9c\udeeb\ud89b\udfa3\ud99a\udc72 :: class java.lang.String ]} ] [ long {\u0600\u5934\u5817\u7a64\ube64\u7593\u72ac\ud4b8\u5b86\u5328\u565b\u1075\u7d38\u1bb0\u7aeb\u09ae\u70ed\u7097\u48ad\uc392\u7b89\u1120\u0643\u4803\uafa7\u9b26\u6dc6\u9019\u0754\ua20f\u805e\ud6a1\u98bc\uae54\u8307\u822a=[ option: \u3ad0 \u0600\u5934\u5817\u7a64\ube64\u7593\u72ac\ud4b8\u5b86\u5328\u565b\u1075\u7d38\u1bb0\u7aeb\u09ae\u70ed\u7097\u48ad\uc392\u7b89\u1120\u0643\u4803\uafa7\u9b26\u6dc6\u9019\u0754\ua20f\u805e\ud6a1\u98bc\uae54\u8307\u822a  :: \ud9ea\udd43\udb75\udcf4\ud9b1\udd81\udb23\ude9e\udb65\udd09\udb9c\udec1\udbc1\udd4d\ud9de\udd5f\ud899\udcfe\uda87\udf5f\ud92b\udccf\udad3\udd78\ud89f\udf98\uda50\ude61\ud8c2\udd4f\ud871\ude89\ud8e7\udc36\ud93b\udfe0\udb41\udfd8\udb77\udc8f\uca6d\ud976...\012",
        Z.run(T, 1, 11, 1, 11, "\u3ad0", "\u0600\u5934\u5817\u7a64\ube64\u7593\u72ac\ud4b8\u5b86\u5328\u565b\u1075\u7d38\u1bb0\u7aeb\u09ae\u70ed\u7097\u48ad\uc392\u7b89\u1120\u0643\u4803\uafa7\u9b26\u6dc6\u9019\u0754\ua20f\u805e\ud6a1\u98bc\uae54\u8307\u822a", "\ud9ea\udd43\udb75\udcf4\ud9b1\udd81\udb23\ude9e\udb65\udd09\udb9c\udec1\udbc1\udd4d\ud9de\udd5f\ud899\udcfe\uda87\udf5f\ud92b\udccf\udad3\udd78\ud89f\udf98\uda50\ude61\ud8c2\udd4f\ud871\ude89\ud8e7\udc36\ud93b\udfe0\udb41\udfd8\udb77\udc8f\uca6d\ud976\udc1e\ud982\udf22\ud884\udf32\uda9c\udeeb\ud89b\udfa3\ud99a\udc72",
        33, 19169, -745825236, 6657454033191792270L, -25635L, false, true, (char) 13390, (char) 31602,
        Double.longBitsToDouble(0x3fc90cb3e995eb50L), Double.longBitsToDouble(0x3fc3241aabfe9824L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 1, 12, "\uf1e1", "\000", "\udb41\udeeb\udb81\udccd\udbfc\udcd4\ud953\udcc0\ud878\udebe\uda77\udc28\u016c\udb55\uddc6",
        41, 66881, 1033691818, -3721811523952838480L, 90181L, true, true, (char) 25585, (char) 5852,
        Double.longBitsToDouble(0x3fec61e7951bca54L), Double.longBitsToDouble(0x3fc2ea063848c36cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 9, 13, "\ue95c", "\ud28b\ub12c\ua5e0\u87d8\ubea6\u1fdf\u0dcf\u34b7\u4398\ub199\u03ed\u8a47\ub305\u1cb2\u7b84\ua9b7\u8048\u70d4\uaab5\u28e4\u5055\u623a", "\ud911\uddb1\ud97c\udfa7\udaac\udfdf\uda37\udfd3\udb33\udf1a\ud9b2\udc53\udb67\ude38\udaa2\udd48",
        46, 31229, 15390040, 4461272101365221720L, 7809L, true, true, (char) 32124, (char) 61348,
        Double.longBitsToDouble(0x3fdef4bfad68f2a6L), Double.longBitsToDouble(0x3fd075e5f2aae82cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u9c97=[ option: \u9c97  :: \u3e02\u23b4\ub6bc\u7d93 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u9c97=[ option: \u9c97  :: \u3e02\u23b4\ub6bc\u7d93 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u9c97=[ option: \u9c97  :: \u3e02\u23b4\ub6bc\u7d93 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u9c97=[ option: \u9c97  :: \u3e02\u23b4\ub6bc\u7d93 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 10, 10, 9, "\u9c97", "\u3e02\u23b4\ub6bc\u7d93", "\ud869\udfb1\udacd\ude27\ud834\udead\udb90\udd23\ud843\udf8b\uda5f\udfd6",
        6, 88203, 1481610854, 5896639821024442906L, 74525L, true, true, (char) 5328, (char) 53484,
        Double.longBitsToDouble(0x3feeecaf8172c538L), Double.longBitsToDouble(0x3fa3f62af1e2fad0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 9, 11, "\u5997\u6db6", "\ub12c\u5817\u7a64\u32a0\ucf92\u75a3\u2ecc\u5b861\u0b96\u365f\u45a9\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\uda0b\udece\ud8b2\udf6d",
        41, 22326, 0, -6533368462837150282L, -14207L, false, false, (char) 0, (char) 61183,
        Double.longBitsToDouble(0x3fefd375bf365385L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997\u6db6=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ] [ long {\ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae=[ option: \u5997\u6db6 \ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae  :: null :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 11, 11, "\u5997\u6db6", "\ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u5b861\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        41, 22326, 0, -6533368463072031306L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f999700e6ca6380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 14, 14, 0, "\ud9b2\udc1e\u67fb", "\ub12c\ube19\u5184\u32a0\u6af7\u717b\u67d2\u5b86\u00c6\u0b96\u03bc\uc524\u1bd4\u7aeb\u09ae", "\udae0\udca5\udb31\udc50\udb93\udf0c\ud91e\udf1a\udb7d\udfef\ud901\udc82\ud91c\udef6\ud985\udd70\ud94e\uddf6\ud8a8\udc2b\uda60\udde3\ud8aa\ude7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        41, 22326, 0, -6533368460124670794L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f99970030512380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997 \ud405  :: \udb41\udeeb\udb40\ude02\udb79\ude14\uda6f\udce6\ud927\ude04\uda6f\udc181\udb58\uddd1\udb73\udebe\ud90a\udc35\ud9fd\ude4b\udb07\udd17\uda65\udd5f\udb43\udf28\ud90e\udd1c\uda2a\udcfe\uda2e\udd8d\udb93\udf0c\ud91e\udf1a :: class java.lang.String ]} ] [ long {\ud405=[ option: \u5997 \ud405  :: \udb41\udeeb\udb40\ude02\udb79\ude14\uda6f\udce6\ud927\ude04\uda6f\udc181\udb58\uddd1\udb73\udebe\ud90a\udc35\ud9fd\ude4b\udb07\udd17\uda65\udd5f\udb43\udf28\ud90e\udd1c\uda2a\udcfe\uda2e\udd8d\udb93\udf0c\ud91e\udf1a :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997 \ud405  :: \udb41\udeeb\udb40\ude02\udb79\ude14\uda6f\udce6\ud927\ude04\uda6f\udc181\udb58\uddd1\udb73\udebe\ud90a\udc35\ud9fd\ude4b\udb07\udd17\uda65\udd5f\udb43\udf28\ud90e\udd1c\uda2a\udcfe\uda2e\udd8d\udb93\udf0c\ud91e\udf1a :: class java.lang.String ]} ] [ long {\ud405=[ option: \u5997 \ud405  :: \udb41\udeeb\udb40\ude02\udb79\ude14\uda6f\udce6\ud927\ude04\uda6f\udc181\udb58\uddd1\udb73\udebe\ud90a\udc35\ud9fd\ude4b\udb07\udd17\uda65\udd5f\udb43\udf28\ud90e\udd1c\uda2a\udcfe\uda2e\udd8d\udb93\udf0c\ud91e\udf1a :: class java.lang.String ]} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997 \ud405  :: \udb41\udeeb\udb40\ude02\udb79\ude14\uda6f\udce6\ud927\ude04\uda6f\udc181\udb58\uddd1\udb73\udebe\ud90a\udc35\ud9fd\ude4b\udb07\udd17\uda65\udd5f\udb43\udf28\ud90e\udd1c\uda2a\udcfe\uda2e\udd8d\udb93\udf0c\ud91e\udf1a :: class java.lang.String ]} ] [ long {\ud405=[ option: \u5997 \ud405  :: \udb41\udeeb\udb40\ude02\udb79\ude14\uda6f\udce6\ud927\ude04\uda6f\udc181\udb58\uddd1\udb73\udebe\ud90a\udc35\ud9fd\ude4b\udb07\udd17\uda65\udd5f\udb43\udf28\ud90e\udd1c\uda2a\udcfe\uda2e\udd8d\udb93\udf0c\ud91e\udf1a :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 14, 3, "\u5997", "\ud405", "\udb41\udeeb\udb40\ude02\udb79\ude14\uda6f\udce6\ud927\ude04\uda6f\udc181\udb58\uddd1\udb73\udebe\ud90a\udc35\ud9fd\ude4b\udb07\udd17\uda65\udd5f\udb43\udf28\ud90e\udd1c\uda2a\udcfe\uda2e\udd8d\udb93\udf0c\ud91e\udf1a",
        17, 10115, 799928359, -2371823185167348101L, -35660L, false, false, (char) 35177, (char) 47022,
        Double.longBitsToDouble(0x3fe5a554a91d933eL), Double.longBitsToDouble(0x3fe8f00488000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 5, 5, 0, "\udaac\udcb8\u9fd9", "\ub12c\u5817\u7a64\u32a0\u1fdf\u75a3\u2ecc\u99db1\u0b96\u8a47\ub305\u1bb0\u7aeb\u09ae", "\udae0\udca1\udb31\udc50\udb84\ude24\ud8ee\udf62\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud9c7\udf79\uda80\udf6c\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        41, 22326, 0, -6533368463072031306L, -100000L, false, false, (char) 14156, (char) 0,
        Double.longBitsToDouble(0x3f999700e6ca6380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  [ARG] :: \u7906\u6ff7 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  [ARG] :: \u7906\u6ff7 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997 \u7906\u6ff7  [ARG] :: \udbed\udcdc\ud8f2\udfe7\u9d64\udabe\udec1 :: class java.lang.String ]} ] [ long {\u7906\u6ff7=[ option: \u5997 \u7906\u6ff7  [ARG] :: \udbed\udcdc\ud8f2\udfe7\u9d64\udabe\udec1 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997 \u7906\u6ff7  [ARG] :: \udbed\udcdc\ud8f2\udfe7\u9d64\udabe\udec1 :: class java.lang.String ]} ] [ long {\u7906\u6ff7=[ option: \u5997 \u7906\u6ff7  [ARG] :: \udbed\udcdc\ud8f2\udfe7\u9d64\udabe\udec1 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 9, 11, 2, "\u5997", "\u7906\u6ff7", "\udbed\udcdc\ud8f2\udfe7\u9d64\udabe\udec1",
        17, 41559, -1421391163, -4125053025758740285L, -3744L, true, false, (char) 49449, (char) 53503,
        Double.longBitsToDouble(0x3fe3000000c3f84bL), Double.longBitsToDouble(0x3fe7d80000000000L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  :: \u9535\u7615\ua493\u44aa\uc7a1\u289b\u9d7f\u2ecc :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  :: \u9535\u7615\ua493\u44aa\uc7a1\u289b\u9d7f\u2ecc :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  :: \u9535\u7615\ua493\u44aa\uc7a1\u289b\u9d7f\u2ecc :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997  :: \u9535\u7615\ua493\u44aa\uc7a1\u289b\u9d7f\u2ecc :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 9, 9, 5, "\u5997", "\u9535\u7615\ua493\u44aa\uc7a1\u289b\u9d7f\u2ecc", "\udb55\uddc0\ud938\udec1\udbab\udf58\ud86e\udf5f\udb6e\udfa8\ud84f\udc49B\000\udaf3\uddeb\u00c3\000\ud891\udd68\ud82f\uddfd\ud999\uded3\udb77\udde4\udb9c\udca0\uda1c\udd4d\udaee\uded0",
        1, 73032, 478470838, -3820428707495935910L, -100000L, false, false, (char) 7898, (char) 20995,
        Double.longBitsToDouble(0x3fda321af16db6daL), Double.longBitsToDouble(0x3fad2b9fb7df9160L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \ud82d\ude32\u2610\000\000\ud829\udea8z\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] [ long {\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \ud82d\ude32\u2610\000\000\ud829\udea8z\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \ud82d\ude32\u2610\000\000\ud829\udea8z\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] [ long {\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \ud82d\ude32\u2610\000\000\ud829\udea8z\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \ud82d\ude32\u2610\000\000\ud829\udea8z\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] [ long {\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \ud82d\ude32\u2610\000\000\ud829\udea8z\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \ud82d\ude32\u2610\000\000\ud829\udea8z\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ] [ long {\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b=[ option:  \000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b  [ARG] :: \ud82d\ude32\u2610\000\000\ud829\udea8z\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 11, 4, "", "\000\000\000\000\u7a64\u8678\u34df\u152d\u9d29\000\000\u569e\000\ud7ba\u1bb0\u7aeb\u09ae\u8048\uc392\u910b\ubd61D\000\000\ua04b\u78a9\ud05d\ud055\u5e2b", "\ud82d\ude32\u2610\000\000\ud829\udea8z\000\ud9a1\udef0\udb0c\udcfb\ud971\ude74\000\000\ucab6\udac2\udd61\udb74\udd3a\uda83\udd80\u00c9",
        3, 67226, -947059762, -431231231445627469L, 96009L, true, false, (char) 47579, (char) 51096,
        Double.longBitsToDouble(0x3fe716747da6d2b5L), Double.longBitsToDouble(0x3fe3eb6d2fec6ef4L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \ud28b :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \ud28b :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 1, 9, 2, "?", "\ud28b", "\udb45\udc5fB\000\ud934\ude74\udaae\ude94\udb4a\udf7f\000\ud8d0\udf08",
        9, 28459, 1033636781, -3721810866836293203L, 17781L, false, false, (char) 62073, (char) 48815,
        Double.longBitsToDouble(0x3fda90000139a934L), Double.longBitsToDouble(0x3fed4a31b88705a7L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997 \ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a  [ARG] :: \ud8cd\udee0\udbc5\udf29\udbdd\udf81\udadc\udc03\udbb6\udedf\udae2\ude0f\uda2c\udd00\ud84f\udef6\ud575\ud8cc\udf73\ud809\ude1b\u3e55\ud8c3\uddff\udb65\udc92\udbd1\udfaf :: class java.lang.String ]} ] [ long {\ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a=[ option: \u5997 \ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a  [ARG] :: \ud8cd\udee0\udbc5\udf29\udbdd\udf81\udadc\udc03\udbb6\udedf\udae2\ude0f\uda2c\udd00\ud84f\udef6\ud575\ud8cc\udf73\ud809\ude1b\u3e55\ud8c3\uddff\udb65\udc92\udbd1\udfaf :: class java.... |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997 \ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a  [ARG] :: \ud8cd\udee0\udbc5\udf29\udbdd\udf81\udadc\udc03\udbb6\udedf\udae2\ude0f\uda2c\udd00\ud84f\udef6\ud575\ud8cc\udf73\ud809\ude1b\u3e55\ud8c3\uddff\udb65\udc92\udbd1\udfaf :: class java.lang.String ]} ] [ long {\ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a=[ option: \u5997 \ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a  [ARG] :: \ud8cd\udee0\udbc5\udf29\udbdd\udf81\udadc\udc03\udbb6\udedf\udae2\ude0f\uda2c\udd00\ud84f\udef6\ud575\ud8cc\udf73\ud809\ude1b\u3e55\ud8c3\uddff\udb65\udc92\udbd1\udfaf :: class java....\0121=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997 \ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a  [ARG] :: \ud8cd\udee0\udbc5\udf29\udbdd\udf81\udadc\udc03\udbb6\udedf\udae2\ude0f\uda2c\udd00\ud84f\udef6\ud575\ud8cc\udf73\ud809\ude1b\u3e55\ud8c3\uddff\udb65\udc92\udbd1\udfaf :: class java.lang.String ]} ] [ long {\ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a=[ option: \u5997 \ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a  [ARG] :: \ud8cd\udee0\udbc5\udf29\udbdd\udf81\udadc\udc03\udbb6\udedf\udae2\ude0f\uda2c\udd00\ud84f\udef6\ud575\ud8cc\udf73\ud809\ude1b\u3e55\ud8c3\uddff\udb65\udc92\udbd1\udfaf :: class java.... |this=org.apache.commons.cli.Options:[ Options: [ short {\u5997=[ option: \u5997 \ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a  [ARG] :: \ud8cd\udee0\udbc5\udf29\udbdd\udf81\udadc\udc03\udbb6\udedf\udae2\ude0f\uda2c\udd00\ud84f\udef6\ud575\ud8cc\udf73\ud809\ude1b\u3e55\ud8c3\uddff\udb65\udc92\udbd1\udfaf :: class java.lang.String ]} ] [ long {\ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a=[ option: \u5997 \ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a  [ARG] :: \ud8cd\udee0\udbc5\udf29\udbdd\udf81\udadc\udc03\udbb6\udedf\udae2\ude0f\uda2c\udd00\ud84f\udef6\ud575\ud8cc\udf73\ud809\ude1b\u3e55\ud8c3\uddff\udb65\udc92\udbd1\udfaf :: class java....\012",
        Z.run(T, 2, 11, 11, 3, "\u5997", "\ud405\u3df8\u40aa\u8fa1\ub89e\uc54b\u33fa\uc719\u732a\u5409\uad6e\u880a\u3007\u1bb0\u7aeb\u098b\u8048\u9fd0\u349b\u43f3\u86a1\u623a\u2aa5\u379b\u6ab6\u84d0\uac1c\u16d9\u7747\u350b\ua272\u0c5a\u11ce\u69c9\u5b1e\u99e7\uc436\u404c\u71c3\u0f7a", "\ud8cd\udee0\udbc5\udf29\udbdd\udf81\udadc\udc03\udbb6\udedf\udae2\ude0f\uda2c\udd00\ud84f\udef6\ud575\ud8cc\udf73\ud809\ude1b\u3e55\ud8c3\uddff\udb65\udc92\udbd1\udfaf",
        6, 72743, -258260619, -7006308755702639513L, -30721L, true, true, (char) 36066, (char) 26027,
        Double.longBitsToDouble(0x3fe4bbb9529108a0L), Double.longBitsToDouble(0x3fee0737fa3af389L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ? \ud28b  :: \uf35b\000\000\ud934\ude74\udaae\ude94C\000\ud8d0\udf08 :: class java.lang.String ]} ] [ long {\ud28b=[ option: ? \ud28b  :: \uf35b\000\000\ud934\ude74\udaae\ude94C\000\ud8d0\udf08 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ? \ud28b  :: \uf35b\000\000\ud934\ude74\udaae\ude94C\000\ud8d0\udf08 :: class java.lang.String ]} ] [ long {\ud28b=[ option: ? \ud28b  :: \uf35b\000\000\ud934\ude74\udaae\ude94C\000\ud8d0\udf08 :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \ud28b :: class java.lang.String ]} ] [ long {\ud28b=[ option: ? \ud28b  :: \uf35b\000\000\ud934\ude74\udaae\ude94C\000\ud8d0\udf08 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \ud28b :: class java.lang.String ]} ] [ long {\ud28b=[ option: ? \ud28b  :: \uf35b\000\000\ud934\ude74\udaae\ude94C\000\ud8d0\udf08 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 9, 2, "?", "\ud28b", "\uf35b\000\000\ud934\ude74\udaae\ude94C\000\ud8d0\udf08",
        9, 28459, 1033636781, -3721810866836293203L, 17781L, false, false, (char) 62033, (char) 48724,
        Double.longBitsToDouble(0x3fda900001380134L), Double.longBitsToDouble(0x3fed4a31b88705a7L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\u5997\uda11\ude10", "\ub12c\u5817\u7a64\ubea6\u1fdf\u75a3\u2ecc\u5b86\u5328\u3610\u1517\ud187\u8f8f\uc4f8\ud053", "\udae0\udca1\udb31\udc50\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5",
        4, 46340, -1873553900, -1825091352517029629L, 61507L, false, true, (char) 64049, (char) 27755,
        Double.longBitsToDouble(0x3fdb6a554c2d07b4L), Double.longBitsToDouble(0x3fc6a54e9a733b9cL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    ::  :: class java.lang.String ]} ] [ long {=[ option:    ::  :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    ::  :: class java.lang.String ]} ] [ long {=[ option:    ::  :: class java.lang.String ]} ]\0121=java.util.Collections$SingletonList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    ::  :: class java.lang.String ]} ] [ long {=[ option:    ::  :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 14, 4, "", "", "",
        -5, -1000, 290053607, 4638569270923082319L, -100000L, false, false, (char) 0, (char) 197,
        Double.longBitsToDouble(0x3e4be00000000000L), Double.longBitsToDouble(0x3fe554a528233d9cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @   [ARG] :: \uf622 :: class java.lang.String ]} ] [ long {=[ option: @   [ARG] :: \uf622 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @   [ARG] :: \uf622 :: class java.lang.String ]} ] [ long {=[ option: @   [ARG] :: \uf622 :: class java.lang.String ]} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @   [ARG] :: \uf622 :: class java.lang.String ]} ] [ long {=[ option: @   [ARG] :: \uf622 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 14, 4, "@", "", "\uf622",
        7, 7069, -76957105, 55960537648857088L, -100000L, true, false, (char) 0, (char) 1784,
        Double.longBitsToDouble(0x3fe554a528233d9cL), Double.longBitsToDouble(0x3fc5f53b72d2b078L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @ \uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0  :: \ud909\ude23\ud871\ude1f\ud959\uded0\ud8a0\udf4c\udb31\udd1c\ueb96 :: class java.lang.String ]} ] [ long {\uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0=[ option: @ \uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0  :: \ud909\ude23\ud871\ude1f\ud959\uded0\ud8a0\udf4c\udb31\udd1c\ueb96 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @ \uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0  :: \ud909\ude23\ud871\ude1f\ud959\uded0\ud8a0\udf4c\udb31\udd1c\ueb96 :: class java.lang.String ]} ] [ long {\uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0=[ option: @ \uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0  :: \ud909\ude23\ud871\ude1f\ud959\uded0\ud8a0\udf4c\udb31\udd1c\ueb96 :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  :: \uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0 :: class java.lang.String ]} ] [ long {\uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0=[ option: @ \uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0  :: \ud909\ude23\ud871\ude1f\ud959\uded0\ud8a0\udf4c\udb31\udd1c\ueb96 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  :: \uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0 :: class java.lang.String ]} ] [ long {\uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0=[ option: @ \uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0  :: \ud909\ude23\ud871\ude1f\ud959\uded0\ud8a0\udf4c\udb31\udd1c\ueb96 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 11, 10, 0, "@", "\uc2ee\uba53\u608f\u7a64\u8678\u34dfV\000\000\u4734\u00d1\000\ud7ba\u1bb0", "\ud909\ude23\ud871\ude1f\ud959\uded0\ud8a0\udf4c\udb31\udd1c\ueb96",
        10, 49137, -931484514, -5362730478661318690L, -36202L, false, false, (char) 26928, (char) 7814,
        Double.longBitsToDouble(0x3fecf72d7d5c07a0L), Double.longBitsToDouble(0x3fde8391d65de7acL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.LinkedHashMap$LinkedKeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 1, 1, 5, "\u5997\uda11\ude10", "\ub12c\u5817\u7a64\ubea6\u1fdf\u75a3\u2ecc\u5b86\u5328\u565b\u8a47\ub305\u1bb0\u7aeb\u09ae", "\ud9a5\ude64\000\udb93\udf0c\ud91e\udf1a\udaf7\udfc0\ud901\udc82\ud91c\udef6\ud985\udd70\uda5a\udcf5\ud8a8\udc2b\uda60\udde3\ud8cb\udf7f\udb81\udf97\ud962\udffa\ud8cf\udc4b",
        16, 90990, -1676786907, -6533368063640072778L, 84099L, false, false, (char) 49092, (char) 55400,
        Double.longBitsToDouble(0x3f9997d3e6ca6380L), Double.longBitsToDouble(0x3fc6f4df00693994L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 5, "\u5997\uf7c6\udb25\udc7a\uda37\udf6d\uda2f\udfa0\udbed\udf12\udb41\udeeb\udbed\udcdc\ud860\udcee\udab6\udf8a\udabe\udec1\udaf2\ude86\udbfc\udec1\udb55\uddc6\ud938\udec1\ud92b\udc63\ud86e\udf5f\udb6f\udc8d\ud84f\udc49\ud849\ude30\ud867\udf65\ud91d\udd82\udb31\udc65\udb93\udf0c\udb8e\uddee\ud85c\ude3e\ud838\udcdd\udb77\udde4\udb9f\ude3d\ud987\udd27\udbd1\udd31\uda60\udde3\udaa7\uddf8\udb38\udd71\ud963\udc8b\ud8cf\udc4b\ud981\udfac\ud97d\uded1\ud889\udd41\ud8cc\udfc9\u7e65\ud9ca\udc96\ud92a\uddd0\udaac\udf76\udb10\udfb1\uda7d\udc1f\u8ece\ud95e\ude6d\udb75\udfad", "\u3657\uc3f0\u73e0\u2a50\ud43a\uc968\u5492\ud5e2\u01ae\ucbe2\u7b89\uac7f\u081a\u64ad\u9311\u2e3c\u75e8\u3461\u3065\ua066\u8b04\ub86d\u1bad", "\ud910\udcc0\udbcc\udc9c\ud98b\udff9\uda21\ude41\uda96\udf6d\ud873\udf3e\uda27\udedd\udb78\udfa3\uda6d\udebb\udbc2\udf2d\ud8aa\ude36\uda3d\udda1\ud8e1\udf2c\udaf9\udfd2\udada\udc8b\ud92c\udc55\ud8f9\uddc3\udbf8\ude91\ud85d\udeb9\ud85d\udc1f\udaa4\ude7d\ud866\uddf2\ud806\udc5e\ud9e9\udf85\uda2f\udccb\ud8c1\udc6a\ud8fd\udda2\uda21\udc97\udb24\udd77\udb21\ude97\udb80\udcc5\udb0e\uddb2\ud91a\udd56\ud8e4\udcdd\ud9a3\udcc2\ud85a\udd92\ud952\udcfe\ud837\uddfb\ud8bc\udc33\ud8bd\ude6b\udbd1\udcb8\uda0d\udc89\uda41\uddee\ud9ca\udd0e\udae1\udc01\uda49\ude85\ud85f\udf24\ud8dc\udfaf\ud8af\udfad\ud99d\ude14\ud8ea\ude2c\udbf5\udda9\udaf7\udfe0\uda63\uddd6\udb22\udc1e\ud99a\udfa8\ud95d\uddcb\ud9f1\udd0c",
        18, 80233, 1536884864, 2244135982957773991L, 95929L, true, false, (char) 38530, (char) 35509,
        Double.longBitsToDouble(0x3fe3221a9d7d3c8eL), Double.longBitsToDouble(0x3fa5c7e262798860L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.OptionGroup|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getNames||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getOptions||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getSelected||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|isRequired||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|setRequired|boolean|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|setSelected|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|toString||new:org.apache.commons.cli.OptionGroup:",
    "C|org.apache.commons.cli.OptionGroup|<init>|",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,boolean,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,java.lang.String,boolean,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOptionGroup|org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getMatchingOptions|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOption|java.lang.String|new:org.apache.commons.cli.Options:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
