package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 3, 5, "\ud8a0\udde1\udb40\ude2f\udb95\uddc0\ud8ac\udd78\ud914\uddc6\ud809\udf3d\ud8b9\udf83\uda6c\udd77\uda54\udeb8\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\ud990\udd2c\uda96\uddd7", "\u54fa\u39b8\u9301\u2aac\u7f4c\u37bb\u34aa\u0931\u7077\u7e57\u553a\u89f3", "\udb5e\udda9\ud8e9\ude21\udad0\udc4f\udadb\uddad\ud863\udeb2\ud965\uddea\ud920\udf78\udac7\uddec\uda69\udfcf\ud8fd\udf35\udbb5\udc2d\uda7c\udd2e\uf4da\ud8a5\ude1e\udb06\udc33\ud8d7\udede\ud8c9\udd65",
        20, 73014, 69440224, 7470122402141192255L, 81454L, false, false, (char) 9543, (char) 21190,
        Double.longBitsToDouble(0x3fdd3644d74da44cL), Double.longBitsToDouble(0x3fee5665d4e46d95L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 3, 5, "\ud8a0\udde1\udb40\ude2f\udb95\uddc0\ud8ac\udd78\ud914\uddc6\ud809\udf3d\ud8b9\udf83\uda6c\udd77\uda54\udeb8\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\ud990\udd2c\uda96\uddd7", "\u54fa\u39b8\u9301\u2aac\u7f4c\u37bb\u34aa\u0931\u7077\u7e57\u553a\u89f3", "\udb5e\udda9\ud8e9\ude21\udad0\udc4f\udadb\uddad\ud863\udeb2\ud965\uddea\ud920\udf78\udac7\uddec\uda69\udfcf\ud8fd\udf35\udbb5\udc2d\uda7c\udd2e\uf4da\ud8a5\ude1e\udb06\udc33\ud8d7\udede\ud8c9\udd65",
        20, 73014, 69413856, 7470122402141192255L, 81454L, false, false, (char) 9543, (char) 21190,
        Double.longBitsToDouble(0x3fdd3644d74da44cL), Double.longBitsToDouble(0x3fee5665d4e46d95L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 3, 5, "\ud8a0\udde1\udb40\ude2f\udb95\uddc0\ud8ac\udd78\ud914\uddc6\ud809\udf3d\ud8b9\udf83\uda6c\udd77\uda54\udeb8\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\ud990\udd2c\uda96\uddd7\ud9c7\ude81\ud907\ude81\ud825\udd45\ud849\udf74\uda73\udc33\udb3a\ude5e", "\u34aa\u0931", "\ud9a2\udf69\ud93f\udc88\ud8cb\udc71\ud826\udff9\udb5e\udda9\ud8e9\ude21\udad0\udc4f\udadb\uddad\ud863\udeb2\ud965\uddea\ud920\udf78\udac7\uddec\uda69\udfcf\ud8fd\udf35\udbb5\udc2d\uda7c\udd2e\uf4da\ud8a5\ude1e\udb06\udc33\ud8d7\udede\ud8c9\udd65\uda14\udd74\ud973\udf4e\ud9a2\udf1e\u1adb\ud83e\udd35\ud904\udf4f\udb32\udee3\ud899\ude54\udb24\udd19\ud896\udf8b\ud90d\udf1f\ud9f2\udca0\ud8c8\ude3f\udaa7\udfe4\udb3e\udd4a\ud8e2\udf6d\udabd\udeac\ud8ef\udd2f\uda6f\uddc1",
        54, 17408, -700547916, -6206154301684774902L, 58100L, true, true, (char) 22659, (char) 45470,
        Double.longBitsToDouble(0x3fe4835d93c4dd75L), Double.longBitsToDouble(0x3fc0805dc36266dcL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 3, 5, "\ud8a0\udde1\udb40\ude2f\udb95\uddc0\ud8ac\udd78\ud914\uddc6\ud809\udf3d\ud8b9\udf83\uda6c\udd77\uda54\ude29\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\udb66\udd77\ud914\udd10", "\u54fa", "\udb3a\ude5e",
        58, 35942, -1535086308, 6678709979466176119L, 75263L, true, true, (char) 52422, (char) 41423,
        Double.longBitsToDouble(0x3fd275cef4621158L), Double.longBitsToDouble(0x3fec55d8acfc0d1bL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 13, 7, "\u2e58\ucafa\ud993\udc72\ud85a\udf35\ud914\udd42\ud809\udf3d\ud8b9\udf83\ud84d\udc78\udb57\udc44\ud988\udedc\ud8cf\udce3\udac3\udf5c\udbf0\uddb4\udbeb\udef1\ud8d8\udcd9\ud9d4\udf84\ud907\ude81\ud825\udd45\ud849\udf74\uda73\udc33\udb3a\ude5e\udb59\ude87\ud893\udcc0\uda52\udfb7\ud912\udccd\uda7a\udef0\uda9c\udffc\ufa27\ud9de\udd4d\ud8bb\udd06\ud826\udff9\udb64\ude2d\ud8e6\udcaf\udad0\udc4f", "\u63a7\u5940\ua9f7\u1f3a\uc693\ub774\u08da\u33a6\ub7f7\u17c1\u19c7\ub721\ua10e\u0333\uafc7\u5f9d\u9b94\ua6fc\u6d0d\u9e21\u15fc\u7c82\u037c\u16e2\u15ab\uad83\u6a44\ub0e2", "\ud8ad\udcbf\udaa6\udd26\udb51\udc6f\uda9a\udf13\uda9b\udde1",
        49, 47820, -492093666, 7963513629593956029L, -56702L, false, true, (char) 16231, (char) 59410,
        Double.longBitsToDouble(0x3fe9a3bb9cec9713L), Double.longBitsToDouble(0x3fd350240950bb3eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 3, 5, "\ud8a0\udde1\ua725\ud946\udf59\udb3a\uddc0", "\u3952\u8cdf\ub40c\u4718\u9f0a\ubae5\u8207\u73ef\u14e7\u7639\u8d57\u54fa\u39b8\u9301\u2aac\u7f4c", "\ud912\udccd\uda7a\udef0\uda9c\udffc\ud960\ude38\ud8c2\ude41\udbc5\udcc8\ud826\udff9",
        1, 4105, 219877258, 7804203772519544276L, 14370L, false, false, (char) 14562, (char) 43498,
        Double.longBitsToDouble(0x3fda11050665b14aL), Double.longBitsToDouble(0x3fe617d68c8ef8b8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 3, 5, "\ud8a0\udde1\udb40\ude2f\udb95\uddc0\ud8ac\udd78\ud914\uddc6\ud809\udf3d\ud8b9\udf83\uda6c\udd77\uda54\udeb8\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\ud990\udd2c\uda96\uddd7", "\u54fa\u39b8\u9301\u2aac\u7f4c\u37bb\u34aa\u0931\u7077\u7e57\u8668\u86e9\u8c22\u1ca5\u836e\u7882\u5f12\u5af2\u4051\u63a7\ub040\ua9f7\u1f3a\uc693\ub774\u08da\uabe5\ub7f7\u17c1\uc8f8\ub7b4\ua10e", "\u1adb\ud83e\udd35\ud904\udf4f\udb32\udee3\ud899\ude54\udb24\udd19\ud896\udf8b\ud90d\udf1f\ud9f2\udca0\ud8cd\udd3f\uda7c\udc6e\ud895\udc16\uda0b\udff4",
        8, 77225, -783379680, -4724052337519299120L, -76883L, true, true, (char) 38096, (char) 42081,
        Double.longBitsToDouble(0x3fe7395b768382f9L), Double.longBitsToDouble(0x3fefe60014621c9aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "", "\000\u0eeb\u2130", "\uda6c\udd77",
        -4, 16696, -757832556, -3870280319886163968L, -100000L, false, false, (char) 2304, (char) 52543,
        Double.longBitsToDouble(0x3fe5d80000975025L), Double.longBitsToDouble(0x3fc8036000013800L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 3, 0, "\ud8a0\udde1", "\u0eeb\u29c7\u99c3\u3952\u8cdf\ub40c", "\udac3\udf63",
        57, 1674, -1595068558, 3952255318976563583L, 75429L, true, false, (char) 2329, (char) 34984,
        Double.longBitsToDouble(0x3fedb606091c89e4L), Double.longBitsToDouble(0x3feabd2406775cafL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 8, "\ud8a0\udde1\udb40\ude2f\udb95\uddc0\ud8ac\udd78\ud914\uddc6\ud809\udf3d\ud8b9\udf83\uda6c\udd77\uda54\udeb8\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\ud990\udd2c\uda96\uddd7", "\u54fa\u39b8\u9301\u2aac\u7f4c\u37bb\u34aa\u0931\u7077\u7e57\u553a\u89f3", "\udb5e\udda9\ud8e9\ude21\udad0\udc4f\udadb\uddad\ud863\udeb2\ud965\uddea\ud920\udf78\udac7\uddec\uda69\udfcf\ud8fd\udf35\udbb5\udc2d\uda7c\udd2e\uf4da\ud8a5\ude1e\udb06\udc33\ud8d7\udede\ud8c9\udd65",
        20, 73014, 69440224, 7470122402141192255L, 81454L, false, false, (char) 9543, (char) 21190,
        Double.longBitsToDouble(0x3fdd3644d74da44cL), Double.longBitsToDouble(0x3fee5665d4e46d95L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 5, "\udbd1\ude79\udb40\udda3\ud91f\udc24\u0d4e\ud914\uddc6\ud809\udf3d\ud8b9\udf83\uda6c\udd77\ud91d\ude9c\ud9bd\ude9e\uda06\udd5b\udad1\udf6a\u7a69\ud990\udd2c\uda1f\uddca", "\ua1eb\u61d7", "\udb59\ude87\ud893\udcc0\uda52\udfb7\udb33\udfcd\uda7a\udef0\uda9c\udffc\ud960\ude38\ud943\udf6f\ud8cb\udc71\ud826\udff9\udb7a\udc6c\ud8e9\ude21\udad0\udc4f\udadb\uddad\ud863\udeb2\ud965\uddea\ud920\udf78\udac7\uddec",
        14, 27600, 139103877, -6163098879328185217L, 14370L, false, false, (char) 14565, (char) 42986,
        Double.longBitsToDouble(0x3fda11050665b14aL), Double.longBitsToDouble(0x3fe617d68c8ef8b8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 10, 6, 5, "\ud8a0\ude53\udb40\ude2f\udb95\uddc0\ud8ac\udd78\ud914\uddc6", "\u8cdf", "\uda06\uddea\udac3\udf63\u7a69",
        49, 23442, 920206150, -3657193931340403383L, -52745L, true, true, (char) 12789, (char) 48247,
        Double.longBitsToDouble(0x3fd1c89e46af4900L), Double.longBitsToDouble(0x3fe3bae578ef4bf0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:usage:  |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                                       |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 11, 3, 5, "\ud8a0\udde1\uda90\udc61\udb55\udd04\udade\udd7c\ud914\uddc6\ud809\udf3d\ud8b9\udf83\uda6c\udd77\uda54\udeb8\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\ud990\udd2c\uda80\uddcc", "\u5542\u39b8\u9301\u2aac\u7f4c\u0da9", "\uda7a\udef0",
        38, 27783, 514168225, -2066960766351720833L, -25711L, false, true, (char) 59926, (char) 33046,
        Double.longBitsToDouble(0x3f968fcacd6ba100L), Double.longBitsToDouble(0x3fd8067d38278752L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 5, "\uda3b\udc4e\udaa4\udf0a\udb9d\ude91\ud8ac\udd78", "\u3952\u8cdf\ub40c\u4718\u9f0a\ubae5\u0e79\u2a6e", "\ud907\ude17\ud825\udd45\uda9a\udfbd\ud80b\udc2e\ud9f9\udef5\u307d\ud893\udcc0\uda52\udfb7\ud912\udccd\ud876\udfcf\uda9c\udf9f\ud960\ude38\ud943\udf6f\ud8e7\udc2a\udbaa\uddae\udb5e\uddc7\ud8e9\ude21\udafe\udf4f\udadb\uddad\ud863\udeb2\ud965\uddea\udabf\udce8\udba8\udcf8\ud913\udd6d\ud8ff\udea9",
        28, 74570, -507063784, -8070902988568506977L, 14370L, false, false, (char) 14590, (char) 25322,
        Double.longBitsToDouble(0x3fd56742847fd794L), Double.longBitsToDouble(0x3fc44eaeb65d1eb4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 1, 3, 3, 5, "\ud812\udf00\udbd0\udf13\ud9fc\udcd6", "\u99c3\u3952\u8cdf\ub40c\u4718\u9f0a\ubae5\u8207\u7f49\u7bae\u470f", "\ud849\udf74\uda73\udc33\ud897\udf0e\udb59\udece\ud85c\udfc0\uda52\udfb7\ud912\udccd\ud8c5\udcb5\ud96e\udca2\uf4c1\ud943\udf6f",
        -1, 43242, -1585795694, -4965801119665418358L, 61103L, true, false, (char) 33944, (char) 45409,
        Double.longBitsToDouble(0x3fe09e1c09abeb53L), Double.longBitsToDouble(0x3fef80404e6a981aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                     |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 12, 3, 5, "\ud8a0\udde1\udb40\ude2f\udb95\uddc0\ud8ac\udd78\udb21\udf8c\ud809\udf3d\ud8b9\udf83\uda6c\udd79\uda54\udeb8\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\ud990\udd2c\uda96\uddd7", "\u54fa\u39b8\u9301\ub099\u7f4c\ua55d\u6956\u8cfc\u7077\u7e57\u553a\u89f3", "\udb5e\udda9\ud8e9\ude21\udad0\udc4f\udadb\uddad\ud863\udeb2\ud965\uddea\udae6\udee5\udae3\udc26\uda69\udfcf\ud8fd\udf35\udbb5\udc2d\udb32\udd29\u4ce6\ud8a5\ude1e\udb06\udc33\ud8d7\udede\ud8c9\udd65",
        20, 73014, 69440224, 7470122402141192255L, 81454L, false, false, (char) 9543, (char) 21190,
        Double.longBitsToDouble(0x3fdd3644d74da44cL), Double.longBitsToDouble(0x3fee54cdd4e46d95L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 3, 5, "\ud8a0\udde1\udb40\ude2f\udb95\uddc0\ud8ac\udd78\ud914\uddc6\ud809\udf3d\ud8b9\udf83\uda6c\udd77\uda54\udeb8\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\ud990\udd2c\uda96\uddd7", "\u54fa\u39b8\u9301\u2aac\u7f4c\u37bb\u34aa\u0931\u7077\u7e57\u553a\u470c\u8c22\u1ca5\u836e\u7882\u5f12\u5af2\u4051\u63a7\ub040\ua9f7\u1f3a\uc693\ub774\u08da\u33a6", "\ud8d7\uded1\ud87e\udd5f\ud9ee\udf08\ud973\udf4e\ud9a2\udf1e\u1adb\ud83e\udd35\ud904\udf4f\udb32\udee3\ud899\ude54\udb24\udd19\ud896\udf8b\ud90d\udf1f\ud9f2\udca0\ud8c8\ude3f\udb2f\udf09\ud9ad\udf7a\ud8ef\udd05\uda8f\udd6f\ud8a5\udc09\udb00\udc18\udbdf\udcc3\udae1\udf8b\uda53\ude44\udbd9\ude64\ud834\ude3b\uec69\udb90\udc3a\ud8e9\udd6b\udbed\ude32\udb3c\udfac\uda04\udddd\uda50\uddc3\ud87c\udc15\ud924\uddf0\ud8d8\udc02\ud90b\udc2b\ud8d1\udf12\udae4\ude33\uda3a\udfd7\ud97b\udcf2\ud8a7\ude55\ud8e3\udfa6\uda16\udc9b\udb17\udf44\ud981\udd33\udb6b\uddc4\udadb\udd12\uda8e\udf14\uda46\udd2d\ud98f\udcb2\ud8c7\udece\udb91\udc6e\ud8be\udf57\ud83e\udcf3\uda88\udf40\ud854\udc7b\ud8cc\udc46\udb1b\ude4b\ud814\uddb0\udb7e\udf28\ud979\uddf2",
        44, 60225, 1705032751, 1272339252063689316L, 48980L, false, true, (char) 19423, (char) 2450,
        Double.longBitsToDouble(0x3fea2e415fe498d4L), Double.longBitsToDouble(0x3fe1650707620102L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 5, "\udb96\udedd\ud876\udd4f\udb95\uddc0\ud8ac\udd78\ud914\uddc6\ud809\udf3d\ud882\ude08\udbce\udefe\uda54\ude40\udae7\udcac\uda06\uddea\udac3\udf63\u7a69\ud990\udd2c\ud9fa\udfc9", "\u54fa\u39b8\u9301\u5bba\u7f4c\u6007\ud0fe\u33ba\u1cb5\u7e57\u553a\u89f3", "\uda44\udf7d\ud8e9\ude21\ud89d\udc50\uda0a\ude99\ud863\ude65\ud965\uddea\ud920\udf78\udac7\uddec\uda69\udfcf\ud8fd\udf35\udbb5\udc2d\udb75\udcd6\uf4da\ud8a5\ude1e\udb06\udc33\ud8d7\udede\ud8c9\udd65",
        55, 54367, 69440224, 7470122402141192255L, 81454L, false, false, (char) 9543, (char) 21190,
        Double.longBitsToDouble(0x3fdd3644db256a44L), Double.longBitsToDouble(0x3fc9598d9afe80e0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|static",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|java.io.PrintWriter,int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
