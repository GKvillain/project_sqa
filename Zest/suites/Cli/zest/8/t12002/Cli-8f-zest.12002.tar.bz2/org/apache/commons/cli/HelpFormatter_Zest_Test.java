package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 0, "\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud9dd\ude60\uda31\udc1c", "\u00a1\uc0b4\ucdf7\u8984\u07ed\u554a\u9560\u4faf\u6a26\u8e18\u8902\u9fcf\u0a2b\u8d1b\u4325\u1789\u955f\u3d88", "\ud9af\udc6a\ud8a7\udcde\ud932\ude29\udb85\udd3c\ud953\ude55\udbe0\uddbc\ud9fe\udd31\ud95d\udf0a\udb9d\udce1\ud9bb\uddb6\u67da",
        56, 77042, 1231983101, 5763887978248852868L, 59256L, false, false, (char) 26310, (char) 19348,
        Double.longBitsToDouble(0x3fb8cdeb1386d588L), Double.longBitsToDouble(0x3fe5cfef61fa86b7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 0, "\ud99a\udef7\ud90b\uddda\ud855\udc3f\ud9dd\ude60\uda31\udc1c", "\u00a1", "\ud879\udec8\ud868\udf8e\ud8be\udc94\udaf3\ude35\ud931\udc51\ud8e6\udc6f\ud8ab\udc83\udaf7\uddb0",
        -1, 82136, 146954938, 3795404979814769929L, 73355L, false, true, (char) 18095, (char) 7226,
        Double.longBitsToDouble(0x3fed027415541517L), Double.longBitsToDouble(0x3fc0f94886d53fb8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 0, "\ud99a\udef7\ud87d\udfb3\ud83c\udd1d\ud9dd\ude60\uda31\udc1c\uda32\udd87\ud811\udea3\u79fe\udbd5\udcd5\ud943\udc36\ud879\udec8", "\u9541\u4faf\u6a26\u8e18\u8902\u9fcf\u0a2b\u8d1b\u4325\u1789\ub68f\u5d72\u865b", "\ud8a7\udcde\u00a6",
        0, 19144, 1174159369, 4726634794410214505L, 44416L, true, false, (char) 57249, (char) 62997,
        Double.longBitsToDouble(0x3fdfd3e0932892dcL), Double.longBitsToDouble(0x3fecc7d3a4f7ecf0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 0, "\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud9dd\ude60\uda31\udc1c", "\u00a1\uc0b4\ucdf7\u8984\u07ed\u554a\u94d2\u4faf\u6a26\u8e18\u8902\u9fcf\u0a2b\u8d1b\u4325\u1789\u955f\u3d88", "\ud9af\udc6a\u00a0\ud932\ude29\udb85\udd3c\u41b5\udbe0\udd4a\ud9fe\udd31\ud95d\udf0a\udb9d\udce1\ud9bb\uddb6\u67da",
        56, 77042, 1231983101, 5692674809141056900L, 95557L, false, false, (char) 22627, (char) 0,
        Double.longBitsToDouble(0x3fe5cfef61fa86b7L), Double.longBitsToDouble(0x3fea3eb6035643a9L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud9dd\ude60\uda31\udc1c!\u1509\u00c0\u889f\u07ed\u554a\u9560\u4faf\u6a26\u6a17\u8902\u9fcf\u0a2b\u8d1b\u4325\u1789\u955f\u3d88 |a0=java.lang.StringBuffer:\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud9dd\ude60\uda31\udc1c!\u1509\u00c0\u889f\u07ed\u554a\u9560\u4faf\u6a26\u6a17\u8902\u9fcf\u0a2b\u8d1b\u4325\u1789\u955f\u3d88 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud9dd\ude60\uda31\udc1c", "!\u1509\u00c0\u889f\u07ed\u554a\u9560\u4faf\u6a26\u6a17\u8902\u9fcf\u0a2b\u8d1b\u4325\u1789\u955f\u3d88", "\ud9af\udc6a\ud8a7\udcde\ud932\ude29\udb85\udd3c\ud953\ude55\udbe0\uddbc\ud9fe\udd31\ud95d\udf0a\udb9d\udce1\ud9bb\uddb6\udbee\uded9",
        56, 77042, 1231983101, 5763887978248852868L, 95557L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe5cfe800fa86b7L), Double.longBitsToDouble(0x3fdc04244f674afeL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 3, 15, "\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud9dd\ude60\uda31\udc1c", "\u00a1\uc0b4\u6a13\u8984\u5200\u554a\u9560\u4faf\u6a26\u8e18\u8902\u9fcf\u0a2b\u8d1b\u4325\u1789\u955f\u3d88", "\ud9af\udc6a\ud8a7\udcde\ud932\ude29\udb85\udd3c\ud953\ude55\udbe0\uddbc\ud9fe\udd31\ud95d\udf0a\udb9d\udce1\ud9bb\uddb6\u67da",
        56, 77042, 1231983101, 5763887978248852868L, 59256L, false, false, (char) 26310, (char) 28820,
        Double.longBitsToDouble(0x3fe9302fca794f57L), Double.longBitsToDouble(0x3fe5cfef61facfb7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 0, "\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud9dd\ude60\ud92b\uddb9\uda32\udd87\udb19\udc26\ud9a8\udff4\ud8ef\udc4c\ud927\udd46\ud879\udec8\ud9ab\udfd1\ud9d1\udc1c\u0da8\ud935\udcf3\ud8e6\udc6f\ud8ab\udc83\udaf7\uddb0\udbd3\udee1\ud923\uddee\ud860\udf3e", "\u1514\u69df", "\ud8ab\udd03\ud8a7\udcde\uda40\udd16\ud880\uddfe\ud86c\udfee\udbfa\udd2a\ud9fe\udd31\ud9e6\udda4\ud9d0\udd8d\udacf\udcbb\ud9fb\udd89",
        22, 11370, -1001090563, 5763887978248852868L, 2680L, false, false, (char) 16502, (char) 31217,
        Double.longBitsToDouble(0x3fb8cdeb1386d588L), Double.longBitsToDouble(0x3fe5cfef66fa86b7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 0, "\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud9dd\ude60\uda31\udc1c", "\u9f22\uc0b4\ucdf7\u8984\u07ed\u554a\u9560\u4faf\u6a26\u8e18\u8902\u9fcf\u0a2b\u8d1b\u4325\u1789\u955f\u3d88", "\ud9af\udc6a\udb7f\ude2a\ud932\ude10\udb85\udd3c\ud953\ude55\udbe0\uddbc\ud9fe\udd31\ud95d\udf0a\udb9d\udce1\ud9bb\uddb6\u67da",
        56, 77042, 1231983101, 5763887978248852868L, 59256L, false, false, (char) 26310, (char) 19348,
        Double.longBitsToDouble(0x3fb8cdeb1386d588L), Double.longBitsToDouble(0x3fdb9fdec3f50d6eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 0, "\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud94e\udd33\uda31\udc1c", "\u00a1\uc0b4\ucdf7\u8984\u07ed\u554a\u9560\u718c\u6a26\u8e18\u8902\u0929\u09fa\u8d1b\u8842\u1796\u54c2\u861f", "\ud9af\udc6a\ud8a7\udcde\ud8eb\udd85\udb29\ude8e\udaac\udf3a\ufea6\ud8d9\udc13\uda14\udfed\udb9d\udcf0\ud9bb\uddb6\u67da\uda87\udfde\udb95\ude81\udb4d\ude50",
        14, 31115, -1778244361, 4350919142428237912L, -98458L, false, true, (char) 6394, (char) 61909,
        Double.longBitsToDouble(0x3fee54269a04e045L), Double.longBitsToDouble(0x3fe96544193658ffL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 9, 12, 0, "\ucefe\uda7b\udd93\ud855\udc3f\ud8cc\ude8a\ud80d\udf3d", "\u00a1\uc0b4\u8def\u1f72\u08bc\u554a\u9560\u6cd3\u6a26\u8e18\u8902\u9fcf\u0a2b\u8d1b\u56b3\u6b46\u5579", "\udbf9\udf39",
        30, 89996, -901505708, 5759647107707388341L, -54102L, true, false, (char) 16576, (char) 11277,
        Double.longBitsToDouble(0x3feb181a90f3a7f3L), Double.longBitsToDouble(0x3fe28a9601fdf911L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 0, "\ud99a\udef7\ud97a\udc64\ud855\udc3f\ud9dd\ude60\uda5b\udcd1", "\u00a1\uc0b4\ucdf7\u8984\u6167\u551c\u663a\u4faf\u6a26\u8e18\u3b7a\ua032\u0a49\u8d1b\u36b3\u331b\u1be3\u7532", "\ud9af\udc6a\ud8a7\udcde\ud932\ude29\udb85\udd3c\ud953\ude55",
        40, 70226, 2144479106, 4689866844712023072L, 10993L, false, false, (char) 53253, (char) 47874,
        Double.longBitsToDouble(0x3fd844ffd9efd954L), Double.longBitsToDouble(0x3fde896020b078c2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 7, 9, 0, "\ud928\udc5d\uda7b\udd24\ud855\udc3f\udb6b\udc91\uda01\udd27\uda1f\udc0f\udb19\udc26\ud9a8\udff4\ud8dd\udf4c\ud927\udd46\uda32\udd15\ud868\udf8e\ud9fb\udc0b\ud9e7\ude5a\uda04\ude5b\uda51\ude8c\ud88b\udf82\udaf7\uddb0\udbd3\udee1\uda91\ude11\ud919\udf88\uda75\udfd2\ud9ce\udeba", "\uc67d\u8c99\u14d7\u949f\u5da4\u1f43\u8d44\u8272\u0df3\u3b6a\u1c3c", "\uda87\udfde\udb95\ude81\ud89f\udef4\uda09\uddba\ud906\udfa8\udaed\ude79\udbc3\udd76\ud9d3\udea4\ud8b7\udee1\udbbf\udd4d\ud871\ude30",
        39, 89217, 1293023738, -6323976115663994494L, -26490L, false, false, (char) 55683, (char) 19556,
        Double.longBitsToDouble(0x3fe77ebc7a664fe5L), Double.longBitsToDouble(0x3fe3ea09e2ab7945L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 0, "\ud99a\udef7\ud86e\udfbc\ud859\udf80\ud81e\udc8e\uda31\udc04", "\ua267\u1050\u41ed\u88e8\u18d0\u7811\u9560\u4faf\u2027\u7c05\uaa3c\u27d0\u0e54\u6369\u4325\u49e7\ua7d7\u3d88", "\ud9af\udc6a\ud8a7\udcde\udaca\udff4\udb85\udd3c\ud958\udf55\udbe0\uddbc\ud9fe\udd3c\ud95d\udf0a",
        55, 20119, -1687319770, -2025602095825480998L, -67596L, false, true, (char) 4415, (char) 47677,
        Double.longBitsToDouble(0x3fb60f0fdf2b5708L), Double.longBitsToDouble(0x3fd029192ceb5a8eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                                                         |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 9, 3, 0, "\u032c\udab3\udc81\ud855\udc3f\ud9dd\ude60\uda31\udc1c", "\u00a1\uc0b4\ucdf7\u8984\u07ed\u3ecd\u1ef5\u4faf\u6a26\u8e18\u8902\u5f84\u0a2b\u012f\u4325\u1789\u955f\u3d88", "\udb18\udefd\ud8a7\udcde\ud932\ude29\udb85\udd3c\ud953\ude55\uda9e\udf95\uda05\udfc8\ud95d\udf0a\udb9d\udce1\ud863\udeaa\u67da",
        56, 77042, 1231983101, 5763887978248852868L, 59256L, false, false, (char) 26310, (char) 19348,
        Double.longBitsToDouble(0x3fb8cdeb0e194588L), Double.longBitsToDouble(0x3fe5cfef61fa86b7L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 0, "\ud99a\udef7\udb8b\udf1b\uda7c\udf0e\ud9dd\ude08\uda31\udc1c", "\u00a1\uc0b4\uca39\ud4de\u07ed\u554a\u9560\u4faf\u6a26\u8e18\u8902\u9fcf\u0a2b\u8d1b\u4325\u1789\u955f\u3d88", "\ud9af\udc6a\ud8a7\udcde\ud932\ude29\udb85\udd3c\ud953\ude55\udbe0\uddbc\ud9fe\udd31\ud95d\udf0a\udb9d\udce1\ud9bb\uddb6\u67da",
        56, 77042, 1231983101, 5763887978248852868L, 59256L, false, false, (char) 26310, (char) 19348,
        Double.longBitsToDouble(0x3fb8cdeb1386d588L), Double.longBitsToDouble(0x3fe5cfef61fa86b7L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 1, 0, "\u00de", "\ud58c\u22f6\uc6b7\uaf64\000\000\ucd37\u8984\u07ed\u554a\u9560\u4faf\u0cff\000", "\000\ud9ae\ude0b\000\ud9ce\udeba\ud86a\udfdf\ud8bf\udf35\ud910\udcb7\udbda\ude77\000\ud8a7\udcde\u1d54\000\000\ud85e\udc0e",
        -5, -1000, 1091895296, 1941390227189902627L, -100000L, false, false, (char) 28928, (char) 20609,
        Double.longBitsToDouble(0x3fcee00007a25808L), Double.longBitsToDouble(0x3f2e308000000000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 0, "\ud99a\udef7\ud93a\ude52\ud855\udc3f\ud9dd\ude60\ud8c0\udff6", "\u00a1\ub6a2\u0811\u53f2\u7250\ua367\u955e\u4faf\u6a26\u8e18\u8902\u9fcf\u4d30\u3ce6\u1d7a\uac41\u9547\u3d88\u56f3\u9832\u3641\ua493\u5da4", "\u52bd\ud90e\uddb9\uda54\udf3a\udb55\udf33\ud9bb\udde4\u67da\ud918\udcf2\ud84e\udde3\udb4d\uddfa\udb0b\ude4a\ud92f\udc60\ud895\udfbc\ud879\uddd1\ud9d3\udea4\uda68\udcee\udb6b\udd4a\ud871\ude30\uda8e\ude50\u364d\udaa6\udd5c\udb72\udd09\udadd\udc22\ud803\udd20\ud852\udc0f\ud839\udf4e\ud873\udc9e\uda93\udd4e\uda6e\udfd7\uda24\udd9d\uda8e\udded\uda40\udfba\ue868\u0627\ud89b\udd6a\ud844\ude0d\udb06\udd91\ud8b1\ude99\uda3d\udcb2\ud9a0\udf8d",
        22, -185, 1855071098, -4837198911899568069L, -85697L, false, true, (char) 31375, (char) 34417,
        Double.longBitsToDouble(0x3fe08383c0f9f1c2L), Double.longBitsToDouble(0x3fe13815e89105b2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 1, 0, "\ud99a\udef7\uda7b\udd93\ud855\udc3f\ud9dd\ude60\uda31\udc1c", "\u00a1\uc0b4\u9707\ua8f1\u07ed\u554a\u9560\u4faf\u6a26\u8e18\u8902\u6286\u7f7d\u8cce\u4325\u1789\u955f\u3d88", "\ud9af\udc6a\ud8a7\udcde\ud932\ude29\udb85\udd3c\ud953\ude55\ud951\udf74\ud9fe\udd31\ud95d\udf0a\udb9d\udce1\ud9bb\uddb6\u67da",
        56, 77042, 1231983101, 5763887978248852868L, 59256L, false, false, (char) 26310, (char) 19348,
        Double.longBitsToDouble(0x3fb8cdeb1386d588L), Double.longBitsToDouble(0x3fe5cfef61fa86b7L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 12, "\ud99a\udef7\udbb9\uddf1\uda27\udf74", "\u9a50", "\ud986\udfe3\ud927\udd46\ud879\ude1d",
        24, 80934, 226613646, -4035240984725353217L, -88693L, false, false, (char) 4322, (char) 36126,
        Double.longBitsToDouble(0x3fc701185548d2acL), Double.longBitsToDouble(0x3fefbb43a694ca6bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|static",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|java.io.PrintWriter,int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
