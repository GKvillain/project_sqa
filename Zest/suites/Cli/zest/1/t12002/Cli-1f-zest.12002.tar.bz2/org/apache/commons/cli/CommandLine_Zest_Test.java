package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class CommandLine_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 13, 20, "\ud850\ude31", "\u3279\u6020", "\uda2d\udcbf",
        23, 2805, -518740873, -3436125570029861005L, -19439L, false, false, (char) 39376, (char) 36796,
        Double.longBitsToDouble(0x3fe960ff67c90d9eL), Double.longBitsToDouble(0x3f90ddc96c7875a0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 12, 13, 20, "\ud850\ude31", "\000", "",
        34, -1000, -1536294912, -4956487586901875593L, -100000L, false, true, (char) 0, (char) 50164,
        Double.longBitsToDouble(0x3eb5a95a14880000L), Double.longBitsToDouble(0x3fe960ff67c90d9eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.HashMap$KeyIterator:@? |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 24, 4, 20, "\ud850\ude31", "\u3279\u6020", "\uda2d\udcbf\uda1b\udeb2\ud8e6\udcbf\ud942\ude82\uda72\udda2\udb0d\udd0a\udaab\ude18\ud8dd\udd24\ud8a5\udd83",
        48, 76947, 228502316, -2465272432476470256L, -36868L, true, true, (char) 62648, (char) 63686,
        Double.longBitsToDouble(0x3fd22d10c8c73d7aL), Double.longBitsToDouble(0x3fe88554818317a9L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 13, 20, "\ud850\ude31", "\u3279\u7969\u58ca\ucca6\uc22e\u1791\u9b46\u8fd1\u6d7b\ubb47\u4fc0\u61f3\ua51d\uc65f\ubb00\u5b50\u673c\u2491\u36cf\u7bd0\uceaf\uabc7\u5c08\ua3da\u3209\uccf8\u03dd\u344d\u1648\u213f\ubbb9\ud4f4\u11da\u37d9\u0c60\ub7f8\u905f\u19c4\u3494\u3105\u47b9\u04b8\uc945\u7b4e\u38d3\ub465\u624d\ud387\u8563\ubf86\uca49\ub5cb\ud1ff\u27c9\ud4f0\ua646\u599e", "\udabe\udd31",
        3, 16642, -1498192335, 7564512221832374517L, -62835L, false, false, (char) 39627, (char) 41089,
        Double.longBitsToDouble(0x3feafb0441001a20L), Double.longBitsToDouble(0x3fd51d1df5bacf4eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 13, 22, "\ud869\udd31\ud9b3\udf8c\u0255\udb08\uddaf\udb1c\uddd3\udb99\ude72\ud8d0\udec9\uda2d\udcbf", "\u8fd1\u6d7b\ubb47\u4fc0\u61f3\ua51d\uc65f\ubb00\u5b50", "\ud82c\udc00\ud833\udcc0\udabb\udc83\ud9cf\udc5c\ud8f7\udd17\ud883\udf78",
        39, 61133, 1278176994, -7912255146983549251L, 88364L, false, false, (char) 46894, (char) 8170,
        Double.longBitsToDouble(0x3feb79643539f7a6L), Double.longBitsToDouble(0x3fefd6e011ccc1f7L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.String:\ud913\ude91 |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 19, 14, 20, "\ud913\ude91", "\u3279\ucf88\ucc47\ucbcb\uc22e\u1791\u5847\u8fd1", "\udad9\udd5f",
        -3, 86234, 1116843898, -3387218007777432788L, 79184L, true, true, (char) 22826, (char) 65260,
        Double.longBitsToDouble(0x3fdddc8f2208f6eeL), Double.longBitsToDouble(0x3fd61f84b0774608L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.cli.Option;:[[]] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 5, 13, 5, "\ud813\ude54\ud9b3\udf3b\u0255\udb08\uddaf\udaac\udf9b\udaa1\udecc\ud8d0\udec9", "\u9b46\u8fd1\u6d7b\ubb47\u4fc0\u449e\u8bf5\u3989\u8998\u6a48\u0f63\u2491\u4b88", "\ud81f\ude30\udacb\udff4\ud907\udf80\uda36\ude9b\ud9bf\udd7e\ud82c\udd2f\uda86\udcfe\ud8a2\ude7a\ud9fa\udeea\uda9c\udd94\ub4ad\ud9ed\udc13\ud8c2\udc4d\uda40\udfae\ud927\udfd7\ud878\ude74\udaf4\udcc7",
        39, 80347, -155852957, 4637940116934553703L, -31231L, false, true, (char) 23089, (char) 38638,
        Double.longBitsToDouble(0x3fd429b2d10202eaL), Double.longBitsToDouble(0x3fdec625820baf5cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=[Lorg.apache.commons.cli.Option;:[[]] |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 5, 20, "\ud850\ude31", "\u3279\u6020\ucc47\ucbcb\u20ee\u1791\u9b46", "\udb0d\udd40\udaab\udd8c\ud8dd\udd24",
        21, 41514, 2131083051, 885761334087238206L, 48343L, true, true, (char) 38776, (char) 1369,
        Double.longBitsToDouble(0x3fd68cdf26079c1aL), Double.longBitsToDouble(0x3fb98bbe492cad50L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 1, 23, "\ud850\ude31\ud9b3\udf8c", "\u6020\ucc47\ucbcb\uc22e\u1791\u9b46\u8fd1\u6d7b\ubb47", "\uda45\uddd2",
        26, 84530, 228502316, -2465272432476470256L, 97836L, true, false, (char) 2232, (char) 42315,
        Double.longBitsToDouble(0x3fd41c1ba83d22a6L), Double.longBitsToDouble(0x3fe3ec3a7539c09aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 13, 20, "\ud850\ude31", "\uc0ae\u6020\ucc47\ucbcb\uc22e\u1791\u9b46\u8fd1\u6d7b\ubb47\u4fc0", "\ud906\udf66\uda57\udf0c\ud9c6\udff9\udb5d\uddc4",
        41, 98275, 1587103525, 2483115000983264967L, -44960L, false, true, (char) 61862, (char) 52562,
        Double.longBitsToDouble(0x3fd6e64434b3260aL), Double.longBitsToDouble(0x3fd60c4447f25080L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 13, 20, "\ud821\udf13", "\u3279\u6020", "\uda2d\udcbf",
        23, 2805, -518740873, -3436125570029861005L, 51686L, true, true, (char) 51991, (char) 42342,
        Double.longBitsToDouble(0x3f90ddc96c7875a0L), Double.longBitsToDouble(0x3fc1fd6903a5754cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 1, 11, 2, 11, "\ud850\ude31", "\u3279\u6020", "\uda2d\udcbf",
        40, 67468, -740188816, -8488408910196563866L, -19439L, false, false, (char) 39376, (char) 36796,
        Double.longBitsToDouble(0x3fe960ff67c90d9eL), Double.longBitsToDouble(0x3f90ddc96c7875a0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=void |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 16, 17, "\udaf0\udcaa", "\u6fb3\u8ea1\u9cf1\ua490\uc190", "\ub27c\ud9c4\udd4e\ud9bb\udccb\ud899\udcf8\udaf0\udcb9\udb37\udf43",
        27, 84550, 228502316, 6758099603722568976L, -48993L, false, true, (char) 48955, (char) 18942,
        Double.longBitsToDouble(0x3fec0a6c27c60e98L), Double.longBitsToDouble(0x3fe923c69ea362c8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 15, 4, 19, "\ud9b6\udfa6\ud840\udc89\u0255\udb08\uddaf", "\ucbcb\uc22e\u1791\u9b46\u8fd1\u6d7b\ubb47\u4fc0\u61f3\ua51d\uc65f\ubb00\u5b50\u673c\u2491", "\uda44\udf6f\uda95\udf52\ud83b\udd92\ud8f5\udfee\udbd3\udd43\udb6a\udfce\ud81a\udcfb\uda24\uddba\uda13\uddb2\ud96d\udf1e\udb42\ude01\udbb5\ude76\uda1f\udc2a\ud8df\udda8\udbc5\udc68\ud9c6\udd26\ud96b\udcb6\ud87c\udd45\udb2f\udf8b\ud9f0\udc4b\uda2e\udc81\udb90\udc94\ud99d\udf27\udafb\uddb5\ud898\ude8d\ud85e\udc93\ud857\udf50\udb7d\ude7e\ud817\udc92\udbe4\udcf4",
        18, 14263, -113009005, 2763475856237305904L, -26779L, false, false, (char) 1919, (char) 42863,
        Double.longBitsToDouble(0x3fde7d6d20735752L), Double.longBitsToDouble(0x3fc9730571ff9cf0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 14, 13, 20, "\ud850\udf10", "\u3279\u6020", "\uda2d\udcbf",
        23, 2805, -518740873, -3436125569207777421L, 3444L, true, false, (char) 39414, (char) 36796,
        Double.longBitsToDouble(0x3fe078ff66c9da22L), Double.longBitsToDouble(0x3fe24ca63680fc61L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 6, 20, "\ud850\ude31", "\u1fb6\u68e9", "\uda2d\udcbf",
        23, 2805, 981534327, -3455374123096881293L, -19439L, true, false, (char) 39494, (char) 36840,
        Double.longBitsToDouble(0x3fe960ff67c90d9eL), Double.longBitsToDouble(0x3f90ddc96ac63380L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 3, 1, 0, "\udbc8\ude75", "\u94e9\u43f0\u34ba\u0a05\u5a6b\u17bd\u9b46", "\udb0d\udd40\udaab\ude18\ud8dd\udd24",
        44, 85898, 535579947, 981409973706266569L, 41802L, true, true, (char) 56510, (char) 17744,
        Double.longBitsToDouble(0x3fda34c0e85b7f9eL), Double.longBitsToDouble(0x3fcb1223018d5eb0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 13, 13, 20, "\udb10\udd70", "\uc8aa\u2033\u7b3b\u0b14\u3a69\u1791\u9b46\u8fd1\u6d7b\ubb47\u4fc0", "\ud906\udf66\uda57\udf0c\ud9ba\udc59\udb5d\uddc4",
        41, 94115, -756225283, -8842898154178376720L, 39033L, false, false, (char) 23249, (char) 1933,
        Double.longBitsToDouble(0x3fedff0c3540adffL), Double.longBitsToDouble(0x3fe466c6b28b5c9cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 20, "\ud850\ude31", "\u3279\u6020", "\uda2d\udcbf",
        23, 2805, -518740873, 8149384472518699730L, -19439L, false, false, (char) 15734, (char) 65270,
        Double.longBitsToDouble(0x3fe960ff67c90d9eL), Double.longBitsToDouble(0x3f90ddc96c7875a0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 17, 1, 21, "\ud850\ude31", "\u3279\u6020", "\uda2d\udcbf",
        23, 2805, -518740873, -3436125570029861005L, -19439L, false, false, (char) 39376, (char) 36796,
        Double.longBitsToDouble(0x3fe960ff67c90d9eL), Double.longBitsToDouble(0x3fdb3ddc98c6b9c2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 12, 9, "\ud850\ude31\ud862\udde4", "\u6020\ucc47\u48d5\u448b\u1791\u9b46\u8fd1\u6d7b\u043b", "\ud88a\udda1\ud97e\udfd2\uda57\udf56\ud903\udff7\ud9e4\uddcf\ud831\udf7e\udba5\ude36\ud9eb\ude48\ud8a3\udf2b\ud87b\udffe\ud9d1\udd37\ud93b\udd15\udaf3\udd1e\udb79\udf2b\u699a\uda20\udece\udb54\udf0f\ud822\udce1\ud9b0\udd45\ud82a\udf34\udb0e\udcf1\ud84f\uded9\udb85\ude1c\uda52\ude88\ud824\udd43\ud816\udf5b\udae4\ude45\uda30\udd56\udb5e\ude92\ud9ed\udef1\uda54\udec3\udab2\ude00\udacf\udf90\udb4d\udd40",
        0, 59901, -1454198221, -4394671551807698756L, 56272L, false, false, (char) 41490, (char) 11587,
        Double.longBitsToDouble(0x3feae03fe47cd829L), Double.longBitsToDouble(0x3fe11b61d6d16c7aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 13, 20, "\ud850\ude31", "\u3279", "\u9e15\uda09\udce3\000\000\uda04\ude2d\uda3c\udf30\udb0d\udd40\udaab\ude18\ud8dd\udd24\ud8a5\udd83\ud906\udf66\uda57\udf0c\ud9c6\udff9\udb5d\uddc4\udbb4\udc81",
        25, 42863, 1088935996, -8398446289674254470L, 36806L, false, true, (char) 17975, (char) 48347,
        Double.longBitsToDouble(0x3fed56866de72333L), Double.longBitsToDouble(0x3fe46b0dd7c28c2fL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 13, 20, "\ud850\ude31", "\u3279\u6020", "\uda2d\udcbf",
        59, 2805, -1911249801, -3455324745921476749L, -19439L, false, false, (char) 39376, (char) 36796,
        Double.longBitsToDouble(0x3fe960ff67c90d9eL), Double.longBitsToDouble(0x3f90ddc96c7875a0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.cli.Option;:[[]] |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 1, 21, 13, 1, "\ud87a\udd52\ud9b3\udf8c\u0255\udbe8\uddfe\udb83\udd0e\udb47\ude84\ud933\udf76\ud94a\udfcf\udbfd\udd69\ud881\udeb5\ud8e8\udcf9\ud9a7\udf61\udb0d\udd40\udaab\ude18\udb79\udc36\ud8a5\udd21\ud8ab\udced\u6a60\ud80e\udd09\udb5a\ude7d\udbb4\udc81", "\u8f60\u9780\u39f1\u73e1\u853e\ud76c\u4b32\ucaf0\u7310\uad4d\u5ddb\u1176\u582d\uaa3d\ud46c\uc0da\u5499\u0d7e\u9d77\u243f\u49e6\u8b95\u553c\u285f\u2e11\u64ab\u67da\u49d8\ud0a5\ud613\u407a\u45f5\u922a\u633f\u5283\u05b7\u7f2f\u0764", "\udb70\udee2\uda2f\uddf3\ud941\udd93\udbdc\udf54\uda0e\udd9b\uda6b\udee9\udb68\udc49\udbd1\ude06\ud868\udca6\udbb1\udf97\ud8c3\udf09\udb42\udcbc\ud964\udd21\udb19\udec4\udabb\udc14\ud8ce\udd05\ud96f\uddb9\ud8a3\udcee\udaef\udd84\udb94\udf3d",
        13, 64611, 107653726, -3956945451012014743L, 27856L, false, true, (char) 14870, (char) 24514,
        Double.longBitsToDouble(0x3f8df5fccbef2840L), Double.longBitsToDouble(0x3fd9780116cc4e80L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.CommandLine:@?\0121=[Lorg.apache.commons.cli.Option;:[[]] |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 12, 21, 2, "\udabe\udf28\ud9b3\udf49\udb0d\udfb0", "\u4870\u44e3\u490f\uc9bd\u39c7\ub4f6\uc284\ubae2\u4fc0\ucab3\ua4ad\uc65f\u4fbe\uc9ae\u1659\u24e1\uca79\u3dc4\u0b5c", "\uda4d\uddf9\udbc9\udd56\ud98f\udcae\uda4b\udf98\ud80f\uddd1\ud839\udfae\ud8d9\udf29\ud92c\udd75\ud973\udd04\udbce\ude66\uda75\ude5f\ud910\udcd7\ud984\ude62\ud9ed\udcbd\ud8b1\udcb6",
        25, 61301, 1745577424, 6320528975718780887L, -40890L, true, false, (char) 59765, (char) 62727,
        Double.longBitsToDouble(0x3fd6288aaf306c48L), Double.longBitsToDouble(0x3fcc03de97d40e28L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=void |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 0, 0, 21, "\ud850\ude1e", "\u3279\uc316", "\uda2d\udcbf",
        23, 2805, 0, -3436125570029861005L, -19439L, false, false, (char) 39376, (char) 36753,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e3b1e1d68000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 22, 22, 6, "\ud850\ude31", "\u3279\u6020", "\uda2d\udcbf",
        19, -1000, 0, 0L, -99921L, false, false, (char) 44799, (char) 17041,
        Double.longBitsToDouble(0x3fe8000000c90d9eL), Double.longBitsToDouble(0x3f4bb92d8f0eb400L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.HashMap$KeyIterator:@? |this=org.apache.commons.cli.CommandLine:@?\0121=java.util.HashMap$KeyIterator:@? |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 24, 8, 18, "\udbf2\udc6c\ud8b1\udc31\ud90a\udd48\udaa6\uddaf\uda01\udc02\udb84\udd99\uda64\uddd5\ud918\udd1d\ud8cc\udebc\uda40\udfd5\uda16\uddc8\ufa9a\ud998\ude53\uda25\udd50\ud9dc\ude04\uda74\ude3d\ud906\udf6e\udae2\uddcf\uda2b\udf3b\ud8df\udc39\udaeb\uddfa\ud900\udddc\ud8ab\ude6b\udafc\ude1f\uda2b\udd6f\ud841\udec3\udbcf\udd87\ud973\ude3d\u24ef\uda3e\udd65", "\ua5e5\uabec\uaa23\u994e\uae96\u1f9d\u27b7\u4f43\u7c75\u9909", "\udb0d\udcb9\ud89f\udd23\ud838\udf7d\ud998\udfb6\ud83c\ude3d\ud883\udd7f\udb35\udc19\ud8ad\udc33\uda92\udc81\udbf6\udd76\ud876\udf90\ud87a\udcc0\udbf7\udcdc\uda7f\ude5d\ud95a\ude9c\ud8a3\ude3e\udb3e\udcb1\udb91\udcac\udbba\udfb1",
        19, 88347, -127600568, -2279662120477842702L, 59678L, false, true, (char) 2793, (char) 57499,
        Double.longBitsToDouble(0x3fb31db8a92fe318L), Double.longBitsToDouble(0x3fce8ec428540fb8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 13, 6, "\000", "", "",
        -5, 86000, 1391824860, -6598164778312071987L, -100000L, false, false, (char) 50889, (char) 44799,
        Double.longBitsToDouble(0x3e3960ff60000000L), Double.longBitsToDouble(0x3fee486cf010ddc9L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 11, 13, 23, "\ud850\ude31\ud9b3\udf8c\u0255\udb08\uddaf\uda9d\udd9b\udaa1\udecc\ud8d0\udec9\uda2d\udcbf\uda1b\udeb2\ud8e6\udcbf\uda04\udea4\uda3c\udf30\uda7a\ude38\udaab\ude18\ud882\udf36\ud8a5\udd83\ud906\udf66\uda57\udf0c\ud9c6\udff9\udb5d\uddc4\udbb4\udc81\ud861\udd85\uda0d\udff8\ud992\udef5\ud97e\ude22\udaeb\udde9", "\u3049\u289e\u81f0\u4162\u0d1d", "\udad9\udf6f\udb59\ude3f\uda78\ude0d\ud8da\udd6a\ud9bb\udccb\udb88\udcf1\ud86b\udddc\uda7f\udf6e\ud951\udd8b\udafe\udf11\udac4\udd66\udaff\udc37\uda62\ude6f\udb85\udff4\ud870\udfa2\uc240\uda0e\udcc1\ud940\udfad\ud8d2\udec5\ud817\udcfb\ud811\udcef\uda33\ude6a\ud8c4\udfa9\ud95e\udc9a\uda82\ude9a\ud97a\udd12\ud9f2\udc91\ud85e\udfd8\udb99\ude85\udb8c\udcf3\ud9b8\udd46\udbf6\udee3\ud863\udf75\ud9a2\ude01\udb83\udeb4\udb21\udf66\ud87a\udc5a\ub5fd\u6a51\ud9b1\udd40\udb17\ude81\ud9a5\udf43\ud913\udf46\udad8\ude9b\ud9fd\udde5\udaf6\ude7d\u989a\udba2\udf36\udab9\udf60\udb20\ude74\ud97b\udce6",
        -3, 89648, 1965776725, 5254645420061517438L, 88297L, false, false, (char) 46537, (char) 56485,
        Double.longBitsToDouble(0x3fecee38d19c1c66L), Double.longBitsToDouble(0x3fc1c0343fdcc050L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 19, 3, 24, "\ud913\ude91", "\u3279\ucf88\ucc47\uca56\u1a49\ub027\u728a\u7597", "\udabe\udd66\ud8c5\ude17\ud8a5\udd83",
        14, 89288, -1323071852, -3010184050542672598L, 51515L, false, true, (char) 5840, (char) 54395,
        Double.longBitsToDouble(0x3fb87e12eeaa0560L), Double.longBitsToDouble(0x3fea95a109dc866fL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:\ud95a\udc64 |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.String:\ud95a\udc64 |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 14, 14, 6, "\ud95a\udc64", "\u91c1\ub15c\ucc47\ucbcb\uc22e\u1791\u5847\u402f", "\udae5\udc5f",
        18, 73290, 1381175125, -4026738111345825804L, -41358L, false, true, (char) 19327, (char) 55307,
        Double.longBitsToDouble(0x3fdddc8d5208f6eeL), Double.longBitsToDouble(0x3fe35331cbb8b661L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 2, 13, 20, "\ud850\ude31", "\u3279\u6020", "\uda2d\udcbf",
        23, 45325, 534061481, 8060838437767200426L, 29852L, true, false, (char) 39376, (char) 36796,
        Double.longBitsToDouble(0x3fe960ff67c90d9eL), Double.longBitsToDouble(0x3f90ddc96c7875a0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=java.util.LinkedList:[] |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 0, 11, 20, "\ud971\ude10\ud906\udcab\ud91d\udca5\u7279", "\u6fd4\uc22e\u1791\u5847\u8fd1\u6dad", "\udb96\udef8\udb16\udf9d\ud90a\uddf0\udb41\udc65\udb40\ude90\udb1f\udf80\uda3c\ude2f\ud9ca\udfef\ud815\udfbb\ud99a\udde3\udaea\uddc7",
        31, 9449, -1167024953, -6745460432982698907L, 74658L, true, false, (char) 28795, (char) 25612,
        Double.longBitsToDouble(0x3feebbe577b3c994L), Double.longBitsToDouble(0x3fe1adbd7eea6c0bL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 9, 19, 7, "\udb46\ude82\ud8f3\udecc\uda24\ude9f\ua8ab\udb35\udf38\ud8d4\udd8b\ud980\udeb1\ud812\udd58\uda04\udde5\ud8fc\udf5f\uda04\udea4\udae5\ude04\udb98\udd4b\ub86b\ud8e2\udfd5\ud83d\udecf\ud95a\udeab\ud859\uded6\udb66\ude73\ud839\udfd6\udb63\ude1b\ud85a\udee6\udba8\ude5a\ud888\udd8b\ud867\udfcf\ud846\udf64\ud8c2\udc40\udb0d\udeee\udb4c\udcdf\ud978\udecb\udb21\udc90\udb89\udfdb\ud98e\udefe\uda58\udc25\ud20e\udb3d\ude9f\uf1d0\udb46\udcf8\udbd4\ude44\ud849\udd13\ud93e\udf6a\udbe6\ude9b\uda4f\udd14\ud8ed\udec7\ud977\udc74\ud8a5\udd18\uda4e\udeae\udba3\udd6d\uda9c\udc63\u3832\ud950\udfe9\udbde\udc58\udb43\ude89\ud927\udd15\ud84e\udc7d\udb0f\udd8d\udbd3\udd11\uda6e\udfbd\ud953\udc09\uda8a\udf61\udbd5\udff1\ud87a\udfa1\udbbc\udf80\ud986\udd9b\ud8de\udd88\udb17\udd1f\ud899\udf04\ud8e5\udd4b\uc299\ud9fe\udf6e\udb53\udd6a\ud929\udff1\ud801\udcd9\udb48\udde3\ud9bb\udc4c\ud24a\udb8b\udd70\ud89e\udf67\udb4d\udc24\ud9fb\udc1e\udafb\udc57\udba0\udd03\uda2b\udd89\uda92\udf0c", "\u932b\ua910\ubc1a\u1bbd\u67e6\u0eba\u02bd\u2f7f\u65da\u80d3\uce7b\u3771\u303c\ubf62\u0421\uc1eb\u140f", "\ud8f8\udde7\ud813\udd74\ud93a\udd17\udb79\udd71\udbb4\ude90\uda14\udfbe\uda71\udf7e\udaf8\udf45\udae5\udf54\ud93e\udeac\ud815\udc71\ud836\udecf\udab9\udeb3\ud933\udcbf\u5ccd\udb33\udca0\ud97a\udc92\udbcb\uddbe\ud99a\ude9a\ud876\udc98\uda15\udf7e\udbf9\udd4a\ud9a2\udda1\ud9b3\udecb\u714d\uc266\udb94\udf1f",
        54, 90033, 399659732, -8776617807345744412L, -56576L, true, true, (char) 269, (char) 53037,
        Double.longBitsToDouble(0x3facbea620c51810L), Double.longBitsToDouble(0x3fe28d3ef2d9350bL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 9, 22, 7, "\udb46\ude82\ud8f3\udecc\uda24\ude9f\ua8ab\udb35\udf38\ud8d4\udd8b\ud980\udeb1\ud812\udd58\uda04\udde5\ud8fc\udf5f\uda04\udea4\udae5\ude04\udb98\udd4b\ub86b\ud8e2\udfd5\ud83d\udecf\ud95a\udeab\ud859\uded6\udb66\ude73\ud839\udfd6\udb63\ude1b\ud85a\udee6\udba8\ude5a\ud888\udd8b\ud863\udccd\ud827\udedf\ud8c2\udc40\udb0d\udeee\udb4c\udcdf\ud978\udecb\udb21\udc90\udb89\udfdb\ud98e\udefe\uda58\udc25\ud20e\udb3d\ude9f\uf1d0\udb46\udcf8\udbd4\ude44\ud849\udd13\ud93e\udf6a\udbe6\ude9b\uda4f\udd14\ud8ed\udec7\ud977\udc74\ud8a5\udd18\uda4e\udeae\udbeb\udc69\uda9c\udc63\u3832\ud950\udfe9\udbde\udc58\udb43\ude89\ud927\udd15\ud84e\udc7d\udb0f\udd8d\udbd3\udd11\uda6e\udfbd\ud953\udc09\uda8a\udf61\udbd5\udff1\ud87a\udfa1\udbbc\udf80\ud986\udd9b\ud8de\udd88\udb17\udd1f\ud899\udf04\ud8e5\udd4b\uc299\ud9fe\udf6e\udb53\udd6a\ud929\udff1\ud801\udcd9\udb48\udde3\ud9bb\udc4c\ud24a\udb8b\udd70\ud89e\udf67\udb4d\udc24\ud965\udc94\udafb\udc57\udba0\udd03\uda2b\udd89\uda92\udf0c", "\u932b\u228e\ubc4f\u1bbd\u67e6\u0eba\u02bd\u2f7f\u65da\u4ee7\ucedd\u3771\u303c\ubf62\u0421\uc1eb\ucdd4", "\ud9c2\udfee\ud81b\udd74\ud93a\udd17\udb79\udd71\udbb4\ude90\uda14\udfbe\uda71\udf7e\udaf8\udf45\udae5\udf54\ud93e\udeac\ud969\udc7c\uda49\udf39\udab9\udde1\ud933\udcbf\u5ccd\udb33\udca0\ud97a\udc92\udbcb\uddbe\ud99a\ude9a\ud876\udc98\uda15\udf7e\udbf9\udd4a\ud9a2\udda1\ud9b3\udecb\u714d\uc266\udb94\udf1f\udba6\udd0c\udbfc\ude36\ud965\udc3b\ud9b0\udd6d\uda92\udf0c\uda20\udd9f\uda11\udd72\uda65\udd13\ud813\udd55\ud92e\udf85\uda7b\udd06\ud95f\udcda\ud8d7\udd71\udb64\udfca\ud963\udf99\ud84f\udfdb\u03c8",
        8, 97830, 1978728672, -2802311408299550671L, -4877L, true, false, (char) 63400, (char) 44975,
        Double.longBitsToDouble(0x3fd49eefdf044c24L), Double.longBitsToDouble(0x3fd7ccbbaaa603caL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 12, 13, 20, "\ud850\ude31", "o", "\u9e15\000",
        -4, 29658, 1151284956, 65984299190504704L, 31072L, true, false, (char) 45, (char) 36796,
        Double.longBitsToDouble(0x3fe960ff67c90d9eL), Double.longBitsToDouble(0x3fd6b9b2aa4e0c74L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 3, 13, 20, "\ud850\ude31", "o", "\u9e15\000",
        -4, 29658, 1151284956, 65984299190504704L, 31072L, true, false, (char) 45, (char) 36796,
        Double.longBitsToDouble(0x3fe960ff67c90d9eL), Double.longBitsToDouble(0x3fd6b9b2a84e0c74L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.CommandLine|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionObject|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionObject|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValues|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValues|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptions||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|hasOption|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|hasOption|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|iterator||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|resolveOption|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|addArg|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getArgList||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getArgs||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValue|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValue|char,java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValue|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionObject|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionObject|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValues|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValues|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptions||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|hasOption|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|hasOption|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|iterator||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|resolveOption|java.lang.String|new:org.apache.commons.cli.CommandLine:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
