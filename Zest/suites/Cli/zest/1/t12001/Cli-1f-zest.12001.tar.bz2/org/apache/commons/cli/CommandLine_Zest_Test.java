package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class CommandLine_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u2f12\u6330\u8a61", "\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        -4, 24751, 1672988388, 7820981753886348698L, 26550L, false, false, (char) 34245, (char) 7122,
        Double.longBitsToDouble(0x3fe431321ed59041L), Double.longBitsToDouble(0x3feee6fa777ec75eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\0121=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 7, 12, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u2f12\u6330\u8a61", "\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        -4, 24751, 1672988322, 7820981753886348698L, 26550L, false, false, (char) 34245, (char) 7122,
        Double.longBitsToDouble(0x3fe431321ed59041L), Double.longBitsToDouble(0x3feee6fa777ec75eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 1, 22, 5, "\ud9a7\udca5\uda7f\udfaf\udb79\ude7e\ud837\ude68\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\u7eb0\ud90d\udf97\uda1a\udd38", "\u8921\u695b\u5b35", "\udacb\udd0d\ud890\udf87\ud96f\udde3\uda4d\udebb\ud8e7\udd67\udba8\ude1c",
        -4, 24751, 1672988388, -7022882617926806150L, -45841L, true, true, (char) 38066, (char) 62775,
        Double.longBitsToDouble(0x3fe057846a6b7167L), Double.longBitsToDouble(0x3fe431321ed59041L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=java.util.HashMap$KeyIterator:@? |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 0, 8, 22, "\udb4d\udc57\ud988\udc46\udafa\udc86\udaf1\udde2\ud800\udfc6\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\udadc\ude4e", "\ua370\uc37b\u7f97", "\udacb\udd0d\udb01\udffc\ud8f1\udf2f\uda4d\udebb\ud8e7\udc9b\ud9d1\udfd0",
        -4, 24751, 1672988388, 7820981753886348698L, 98513L, true, true, (char) 38066, (char) 41434,
        Double.longBitsToDouble(0x3fe67793f2e76c67L), Double.longBitsToDouble(0x3fbe3a10c8c127f0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 6, 2, 22, "\udafa\ude75\uda7f\udf05\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda5f\udcdd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u9225\uc867\u0d23", "\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\udb59\udd60\ud9d1\udfd0",
        -4, 24751, 1672988388, 7820981753886348698L, 26550L, false, false, (char) 34245, (char) 7122,
        Double.longBitsToDouble(0x3fe431321ed59041L), Double.longBitsToDouble(0x3feee6fa777ec75eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 19, 2, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\ud844\udd29\ud979\udde3\udb1b\udd61\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u2f12\u6330\u8a54", "\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        1, 22385, 1672988388, 7820981753886348698L, 26550L, false, false, (char) 34245, (char) 7122,
        Double.longBitsToDouble(0x3fe431321ed59041L), Double.longBitsToDouble(0x3feee6fa777ec75eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 15, 2, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u2f12\u6330\u8a61", "\udacb\udd1e\udae5\uddf1\ud8f1\udf48\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        -4, 24751, 1672988388, 7820805831618472602L, 26550L, false, false, (char) 34245, (char) 45522,
        Double.longBitsToDouble(0x3fe431321ed59041L), Double.longBitsToDouble(0x3feee6fa777ec75eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 13, 7, "\uda14\udfdd\ud8e4\udec5", "\u7be2\u0bf4\u78f7\u2440\u8c74\u34e5", "\ud956\udfed\uda08\uddb0",
        48, 50218, -1433824926, 196338631611565048L, 66146L, false, false, (char) 32931, (char) 44878,
        Double.longBitsToDouble(0x3feb87565f7ff004L), Double.longBitsToDouble(0x3fe7f402051baf13L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 3, "\ud914\udd2e\uda7f\udf19\ud69d\ud850\udc23\ud88c\udcef\udb28\udfe9\uda5c\udf3c\udb1f\udd1e\udaeb\udcf6\ud96e\udccc\uda35\udfb8", "\u2f12\u6330\u8a61", "\udaa6\udd03\ud84d\udd04\ud8f1\udf2f",
        -4, 45124, 1271628633, -1092747950890922113L, 11992L, false, true, (char) 62202, (char) 41045,
        Double.longBitsToDouble(0x3fe879aaf9aa8308L), Double.longBitsToDouble(0x3fe883ae52cef2f7L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.cli.Option;:[[]] |this=org.apache.commons.cli.CommandLine:@?\0121=[Lorg.apache.commons.cli.Option;:[[]] |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 21, 5, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u2f12\u5839\u8a61", "\udacb\udd7e\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        -4, 24751, 1672988388, 7820981753886348698L, 26550L, false, false, (char) 34245, (char) 7122,
        Double.longBitsToDouble(0x3fe431321ed59041L), Double.longBitsToDouble(0x3feee6fa777ec75eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=void |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 0, 0, 8, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\udbc9\udfdb\ud941\udd9f", "\u2f12\u6330\u8a61", "\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        -4, 24751, 1672988388, 7820981753886348698L, -100000L, false, false, (char) 0, (char) 12054,
        Double.longBitsToDouble(0x3feee6fa777ec75eL), Double.longBitsToDouble(0x3fecf761eb76f4d4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 2, 15, 14, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda4b\ude65\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e", "\u570c\u0792\u5dbb\u82a0\u6330\u8a61\ud11f\u558a\u3181\u54b8\uc677\u512c\u46eb\u252e\ua58d\u211c\u4c5e\u56e3\u9d8c\u2f24\u93b2\ucaf2\u7549", "\ud8ef\udcac\ud866\udff0\udb0d\udce7\uda6f\udc85\uda7d\uddc5\udbfb\udc6e\ud98b\udc19\u330c\udb58\udc37\ud805\udf9a\ub7f7\ud833\udd38\ud993\ude28",
        -1, 24718, 1387446524, -4119011621440985443L, -72715L, true, true, (char) 40736, (char) 55374,
        Double.longBitsToDouble(0x3fe66e8ce16c53aeL), Double.longBitsToDouble(0x3fd1feaf1d88baacL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u2f12\u6330\u8a61", "\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        -4, 36359, 0, 7820981753886348698L, 26550L, false, false, (char) 34245, (char) 7122,
        Double.longBitsToDouble(0x3fe431321ed59041L), Double.longBitsToDouble(0x3feee6fa707ec75eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude99\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8e3\udc8d\ud933\udd98\ud97c\ude78\ud956\udfed\ud825\ude1d\ud8cb\udc22\udbbf\udce0\uda74\udd8c\udab8\udd0c\ud842\udf49\ud84d\udd04", "\u46eb\u252e\ua58d\u211c\u9513\uae1b", "\uda99\udf97\udabd\udfb1\ue7c4\ud977\udc7c\udb84\udd7c\ud8ef\udcac\ud866\udff0\uda47\ude24\uda6f\udc85\udb29\udeda\ud9c7\ude3c\udb9f\udcbd\udb13\udd69\ud8e0\udec9\ud805\ude8f\ud80b\ude43",
        57, 9771, -553933721, 2810949585156899312L, -42190L, true, false, (char) 27935, (char) 45931,
        Double.longBitsToDouble(0x3fc9683d23cfac54L), Double.longBitsToDouble(0x3fe5ce1b95cd59e3L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\ud87e\udfd2\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\u00d8\ud941\udcef |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 14, 2, 22, "\ud87e\udfd2\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\u00d8\ud941\udcef", "\u2f12\u6330\u8a61", "\uda9b\ude0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\uda14\udede\000",
        56, 24751, 1672988388, 7820981754906280090L, 26550L, false, false, (char) 33998, (char) 7122,
        Double.longBitsToDouble(0x3fe431321ed59041L), Double.longBitsToDouble(0x3feee6fa777e0000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 1, 6, 6, 11, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\ud9d2\ude74", "\u34e4\u78b7\u07a6\u5995\u7235\u5446\u8a61", "\udacb\udda5",
        38, 7207, -1512850420, -943825022100400472L, 11992L, false, true, (char) 38990, (char) 41010,
        Double.longBitsToDouble(0x3fe879aaf9aa8308L), Double.longBitsToDouble(0x3f9075ca831d9ee0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.HashMap$KeyIterator:@? |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 24, 22, 22, "\uda14\udf80\uda81\udc65\udb79\ude7e\uf684", "\u607d\u7f5a\u41df\u3553\u570c\uc6bc\u5dbb", "\udbbf\udd94",
        6, 71829, 1615511393, 4120159887259108093L, 85558L, true, false, (char) 4946, (char) 16469,
        Double.longBitsToDouble(0x3fb8564643a9bbf8L), Double.longBitsToDouble(0x3fd9a6c894cb866aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 22, "\udbfd\udd71\ud8bf\udfcf\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\udb2a\udca0\ud886\uddf0\uda9b\udeef\udb5d\udf49\ud947\udcc6\ud97c\ude78", "\u6330\u35e5\u78e5\u69f9\u768c\u8d7b\uc72e\u512c", "\ud109\u9b28\ud975\udcc4\ud9ba\udfdd\udb5a\ude04\ud95d\udcc4\ud897\udf96\udabd\udfb1\ua09b\ud942\udf4b\udb84\udd7c\ud8ef\udcac\udb1e\udfec\udb0d\udce7\uda6f\udc85\udac1\udc47\ud804\udd82\ud90f\udecc\u794d\ud99b\udd30\ud982\udcd6\udbcc\udca3\ud801\udd28\ud902\uddbb\ud8cb\udc48\ud8e7\udfa8\uda73\udcc8\udb7d\ude89\udaa2\udc30\udaaf\udfdc\u8899\udb70\uddc6\uf424\ud973\udd58\ud9b3\ude5b\udab3\udc1c\udb8c\udca1\ud97f\udc37\uda66\udee6\udb84\udde3\udb3a\ude80\udb61\ude1d\udb76\udc5a\uda30\udf90\uda3c\udedd",
        50, 17147, -42928912, -3493777073053272815L, 25432L, false, true, (char) 59216, (char) 22902,
        Double.longBitsToDouble(0x3fec55ff0f61c96cL), Double.longBitsToDouble(0x3fe5e75cd7bc98b6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 12, "\u11d5", "", "",
        -5, 64759, -235987469, -4638979463927625768L, 46627L, true, true, (char) 64324, (char) 50367,
        Double.longBitsToDouble(0x3fd327f041796d80L), Double.longBitsToDouble(0x3fd7d0dd4ec3695cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 1, 3, 2, 22, "\uda14\udfdd\uda4c\uddb0!\uda0f\uddf0\ud834\udd90\ud8ee\udf0b\uda64\udddd\000\000\ud8ab\udfb5\ud941\udd9f", "\000\000\000", "\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        -4, -1000, 0, 7820782226885645722L, 35594L, false, false, (char) 247, (char) 0,
        Double.longBitsToDouble(0x3e4b564000000000L), Double.longBitsToDouble(0x3feee6fa7000c75eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 15, 22, "\uda35\udd8c", "\ubb5d\u7be2\u0bf4\u0ba3\u2fb0", "\ud941\udd9f\udb52\udcb7\ud956\udfed\ud910\ude52\ud8cb\udc22\udbbf\udce0\ud82a\udd29\udab8\udd0c\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0\ud8a9\udea2\u9b28\ud975\udcc4\ud9ba\udfdd\udb5a\ude04\ud95d\udcc4\ud897\udf96\udabe\udc4b\ua06f",
        3, 75198, 641968747, -8052072719924158763L, 78175L, false, false, (char) 48766, (char) 65060,
        Double.longBitsToDouble(0x3fbaedad4c1aeda0L), Double.longBitsToDouble(0x3fdd17beb47b896eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\0121=void |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 22, 0, 12, "", "\u7ed6\u009d\000\000\u0f18\u00f3\u83b2", "\ud96d\uddb5",
        15, 96950, 15526, 231997440L, -17921L, true, true, (char) 56889, (char) 35248,
        Double.longBitsToDouble(0x3fe6852e9b592bf6L), Double.longBitsToDouble(0x3e4dfc0000000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 1, 2, 22, "\uda46\udc22\ud80c\udfec\udb79\udea0", "\u0bf4\uc8f3\u2d47\u8c74\u3530\u589e", "\ud85c\udd6d\ud8cb\udc22\udbbf\udce0\uda74\udd8c\udab8\udd0c\udacb\udd0d\udba3\udfd0\udaf9\udcd3",
        5, 68152, 1271621977, -1092747950890922113L, 11992L, false, true, (char) 39207, (char) 279,
        Double.longBitsToDouble(0x3fe879aaf9aa8308L), Double.longBitsToDouble(0x3f9075ca59de5ee0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 7, 23, 14, "\uda35\udf0d\ud87b\udd55\udabf\udf5d\uda0f\ude8d\ud93b\udc73\udb35\udc1a\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f\ud97c\ude4d\ud964\udcd3\ud850\udc17\ud8cb\udc22\udbbf\udce0", "\u9676\u54ed\uc677\u8a5b\u1855\u252e", "\ud885\udc79\uda40\udd63\udb62\udf70",
        53, 7369, -2096568512, 3809624340374762043L, -9589L, false, true, (char) 32476, (char) 28025,
        Double.longBitsToDouble(0x3fdb6184b46259aeL), Double.longBitsToDouble(0x3f65b8f86eda4d00L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 13, 13, 22, "\uda46\udff0\uda7f\udf5c\udb79\ude7e\ud8e8\udd9a\udb4a\udf5d\ud832\udfee\ud93d\udc49\udb38\udea8\ud884\udf22\ud8ac\udc87\ud941\udd9f", "\u2425\u567d\u6d98", "\udacb\udd0d\ud8e1\uddaf\ud968\udcd6\udb47\udef4\ud8e9\udd26",
        10, 79258, 1042037406, 7185430412469319032L, -45230L, false, false, (char) 19591, (char) 38144,
        Double.longBitsToDouble(0x3f9075ca59de5ee0L), Double.longBitsToDouble(0x3fe35b8b3a862643L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 12, "", "\000", "\007",
        23, -1000, 0, -8935141660703064064L, -100000L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fc796d815f43750L), Double.longBitsToDouble(0x3feb0da570006000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\uda36\udd91\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f\ud97c\ude78\ud956\udfed\ue46f\ud8cb\udc22\ud95d\ude65\uda74\udd41\ud851\udc0a\udacb\udd0d\ud84d\udd04\ud923\udf07\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0\ud8a9\udea2\u9b28\ud975\udcc4\ud9ba\udfdd\udb5a\ude04\ud95d\udcc4\uda5b\ude19\ud9e3\udf88\ua09b\ud942\udf4b\udb84\udd7c\ud8ef\udcac", "\u54bd", "\ud8f8\udc05\udaa4\ude91\ud9ed\udff0\ud994\udee6\ud927\uddfb\ud893\ude99\udbdb\udfa0\ud881\ude92\ud9a1\udccd\uda45\udce4\ue325\uda49\udd79\ud8e8\udd4b\udbde\udd79\udade\udcac\ud878\uded9\ud976\udd58\udb22\udf3f\udbb8\udf72\udb23\udfc7\uda65\udcf1\ud82f\udf76\ud9a0\udf03\udb99\udd8b\ud90a\udf06\udb0a\udee0\uda1d\uddde\udb31\udd7b\uda29\udeb2\uda1e\udec7\uda65\udf9e\ud9e0\udc39\ud819\udce9\uda91\udcc4\udbcb\udc5c\ud8ff\udce0\uda76\ude50\uda14\udfe1\udb78\udcba\ud8bd\uddcb\ud876\uddef\ud895\udd5d",
        26, 27527, 462638952, 9023853229459562517L, -20908L, true, true, (char) 5398, (char) 32594,
        Double.longBitsToDouble(0x3fa2febf0d6606e0L), Double.longBitsToDouble(0x3fd8df11239d881cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 0, "", "", "\ud834\udd90\udb28\udfe9\ud9ab\udfe0\ud825\udd0e",
        37, 72136, 1689616304, 6980083280118175213L, -84640L, false, true, (char) 65404, (char) 29521,
        Double.longBitsToDouble(0x3feb0da57797604aL), Double.longBitsToDouble(0x3fe13ae09c0ccda4L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 1, 22, 0, 15, "\uda14\udfdd\u51c0", "\u6cec\uc0f3\u6055\u2d47\u8c74", "\ud9a3\udddc",
        2, 27191, 2130984102, 8917278110266967431L, -66681L, false, false, (char) 32931, (char) 44878,
        Double.longBitsToDouble(0x3fec3a5e5f1a9cceL), Double.longBitsToDouble(0x3fd835d2c9e957a0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 17, 1, 22, "\ud855\udefd\uda7f\udf9d\udb79\ude7e\uda0f\ude8d\uda60\udc4c\udb28\udfe9\uda64\udddd\ud99d\ude3d\ud915\udd3f\ud8ac\udc61\ud941\udd9f", "\u2f12\u6330\u8a61", "\uda08\udcb6\ud84d\udcd7\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        4, 24816, 1672988399, 7820981753886348698L, 52626L, false, false, (char) 34245, (char) 7122,
        Double.longBitsToDouble(0x3fe431321ad59041L), Double.longBitsToDouble(0x3feee6fa777ec75eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 13, 22, 14, "", "\000\000\000\u50ec\u0f18\000\000\u0700\uaf5b\u0792\u55ed\u2ee4", "\uda74\udd8c\udab8\udd0c\udacb\udd0d\udbd9\ude02\udab4\ude30\uda1e\udeaf\ud8e7\udd67\ud9d1\udfd0\ud8a9\udea2\000\udb47\ude0a\ud93d\ude5d\udb5a\ude04\ud95d\udcc4",
        10, -1000, 0, 0L, -15386L, true, false, (char) 78, (char) 32382,
        Double.longBitsToDouble(0x3fd436b2fff32ce2L), Double.longBitsToDouble(0x3fe180aa0eaaacacL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=null |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 3, 19, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u2f12\u6330\u8a61", "\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0",
        -4, 24751, 1672988322, 7820981753886348698L, 26550L, false, false, (char) 34245, (char) 7122,
        Double.longBitsToDouble(0x3fe431321ed59041L), Double.longBitsToDouble(0x3feee6fa777ec75eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 22, 22, 5, "\ud9a7\udca5\uda7f\udfaf\ud807\uddc6\uda01\udf3d\udafd\udce9\ud815\udefe\ud96c\udf21\udb1f\udd1e\u7eb0\uda6c\udf07\uda1a\udd9c", "\u8921\u695b\u5b35", "\udacb\udd0d\ud890\udfb8\ud96f\udde3\uda4d\udebb\ud80e\udd5a\udba8\ude1c",
        -4, 45487, 1672988388, -7022882618228796038L, -156L, true, true, (char) 27761, (char) 62626,
        Double.longBitsToDouble(0x3fe057846a6b7167L), Double.longBitsToDouble(0x3fe431321ed59041L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 1, 22, 5, "\ud9a7\udca5\uda7f\udfaf\uda0a\ude5e\ud837\ude68\udbd5\udeb7\udb28\udfe9\uda64\udddd\udb1f\udd1e\udbf6\uddbc\ud919\udfea\uda1a\udd38", "\u8921\u695b\u5b35\ud11f\u4438\u3181\uc5e6\u957a\u512c\u46eb\u2284", "\udb9a\udcd8\uda53\udde7\udb5a\udde4",
        16, 63745, -2096568561, -2248965642335218579L, -45912L, true, true, (char) 22673, (char) 43241,
        Double.longBitsToDouble(0x3fe2fcc692e25b29L), Double.longBitsToDouble(0x3fe44b3bc7716420L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.HashMap$KeyIterator:@? |this=org.apache.commons.cli.CommandLine:@?\0121=java.util.HashMap$KeyIterator:@? |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 8, 8, 22, "\udb4d\udc57\ud988\udc46\udafa\udc86\udaf1\udde2\ud800\udfc6\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\udadc\ude4e", "\ua370\uc37b\u7f97", "\udacb\udd0d\udb01\udffc\ud8f1\udf2f\uda4d\udebb\ud8e7\udc9b\ud9d1\udfd0",
        -4, 24751, 1672988388, 7820981753886348698L, 96608L, true, true, (char) 38066, (char) 41434,
        Double.longBitsToDouble(0x3fe67793f2e76c67L), Double.longBitsToDouble(0x3fbe3a10c8c127f0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\uda14\udfdd\ud8e4\udec5 |this=org.apache.commons.cli.CommandLine:@?\0121=java.lang.String:\uda14\udfdd\ud8e4\udec5 |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 14, 14, 7, "\uda14\udfdd\ud8e4\udec5", "\u13f9\u0cad\u636f\ub7c0\u8c36\u34e5", "\ud87f\udd40\ud95f\udfe8",
        31, 69945, -685517101, 196338629598299128L, 66326L, false, false, (char) 32931, (char) 60238,
        Double.longBitsToDouble(0x3feb8752af7ff004L), Double.longBitsToDouble(0x3fe7f402051baf13L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u2f12\u6330\u8a61", "\udacb\udd0d\ud84d\udd04\ud8f1\udf2f\uda4d\udebb\ud8e7\udd67\ud9d1\udfd0\ud8a9\udea2\u9b28\ud975\udcc4\ud9ba\udfdd\udb5a\ude04\ud95d\udcc4",
        10, 89439, 1976177066, -939233548149746994L, -15386L, true, false, (char) 20267, (char) 32476,
        Double.longBitsToDouble(0x3fdea2ed1f9d6176L), Double.longBitsToDouble(0x3fe4c29d5eba7bafL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.CommandLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 13, 7, "\ud983\udc74\uda1c\udcf9", "\ua41c\u965d\u78f7\u2440\ucc1c\u34e5", "\ud956\udfed\uda08\uddb0\ud9f0\udce8",
        28, 71074, 45713650, -512068985585226186L, 33289L, true, true, (char) 39877, (char) 39101,
        Double.longBitsToDouble(0x3feb9d3801ec67afL), Double.longBitsToDouble(0x3fdb2914851aad38L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.CommandLine:@?\0121=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.CommandLine:@?\012",
        Z.run(T, 2, 7, 12, 22, "\uda14\udfdd\uda7f\udfb0\udb79\ude7e\uda0f\ude8d\ud834\udd90\udb28\udfe9\uda64\udddd\udb1f\udd1e\udaeb\udcf6\ud8ac\udc8d\ud941\udd9f", "\u2f12\u6330\u8a61\ud11f\u4438\u3181\u54b8\uc677\u512c\u46eb\u252e\ua58d\u211c\u94d1\uae1b\u9d8c\u2f24\u93b2\ucaf2\uad44\u249d\u5936\ubfc4\u1e15\u7815\u54bd\ud532\ub6b3\u8857\u043d\u4afa\ub0f5\u1e48\u8896\ud05e\u3a36\u6a89\u2ad9\u4d23\u4ef3\uc076\uc6b8\uacc3\uc364\u0dd5\u3c3b\u915c\uaad2\uc543\u5c3c\u6bb9\u0cf8\u130f\u4f66\u0a0d\u5468\ub97a\u605a\u0ec4\u56de\ua368", "\u6890\udaf0\uddbe\ud9e2\udda7\ud8c8\udd6d\ud9f3\udcd0\udb91\ude4b\uda2d\uddde\ud8bb\udc31\ud905\udc06\udbd4\udd01\udb9f\udd75\uda10\uddb3\udb39\ude83\uda7e\ude15\u9ff4\udb5b\udd0d\ud8a6\uddbe\udae4\udc17\uda62\ude4a\ud9a0\udc24\ud711\udb1a\ude06\ud913\uddcc\udbff\udc1b\uda44\udf52\ud8d5\uddce\u301d\udb35\udd9a\uda22\udfbc\uffc8\udba9\udc58\udbb6\udd9f\ud8b7\ude99\ud8de\udc53\ud813\udf34\udb69\ude6a\uc721\udbc3\ude18\udb6e\udcd6\ud832\udf48\udb81\udd5e\uda7d\udd45\ud924\udf7a\uda3d\udc85\ud893\udea6\ud914\ude87\ud8b4\ude29\udaee\ude01\udbd1\udfcc\udb31\udd2f\u2369\ud928\ude9f\ud867\ude68\ud9ef\udc15\udaf7\udf5f\ud93a\udcfa",
        55, 33407, -1833554980, -4808302687029191139L, -14813L, true, true, (char) 37168, (char) 38680,
        Double.longBitsToDouble(0x3fc221dea94ec78cL), Double.longBitsToDouble(0x3fc5ed743513a2a4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.CommandLine|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionObject|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionObject|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValues|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValues|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptions||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|hasOption|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|hasOption|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|iterator||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|resolveOption|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|addArg|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getArgList||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getArgs||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValue|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValue|char,java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValue|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionObject|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionObject|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValues|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptionValues|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|getOptions||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|hasOption|char|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|hasOption|java.lang.String|new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|iterator||new:org.apache.commons.cli.CommandLine:",
    "M|org.apache.commons.cli.CommandLine|resolveOption|java.lang.String|new:org.apache.commons.cli.CommandLine:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
