package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u025a", "\uda38\udff1\ud964\udde3",
        52, 30032, 1838854625, -1661418613430676049L, -55671L, false, true, (char) 40114, (char) 65165,
        Double.longBitsToDouble(0x3fd83572c81776a4L), Double.longBitsToDouble(0x3fe560c81824d6e4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\ud90d\udc8b\uda59\udd46\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u025a", "\uda38\udff1\uda14\udcda",
        52, 30032, 1838854625, -1661418613430676049L, -55671L, false, true, (char) 40114, (char) 65165,
        Double.longBitsToDouble(0x3fd83572c81776a4L), Double.longBitsToDouble(0x3fee38c81824d623L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\udae3\udfd0\000\uda53\ude49\ud8da\udf74\ud8ed\udc70\u5960\000\uda0c\udea6\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u025a", "\uda38\udff1\ud964\udde3",
        52, 30032, 1838854625, -1661418612809919057L, -100000L, false, false, (char) 21207, (char) 11891,
        Double.longBitsToDouble(0x3fb99b1331e44288L), Double.longBitsToDouble(0x3f35cb0000000000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 4, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u025a", "\uda38\udff1\ud964\udde3",
        52, 30032, 1838854625, -1661418613430676049L, -22074L, false, false, (char) 21679, (char) 503,
        Double.longBitsToDouble(0x3fe560c81824d6e4L), Double.longBitsToDouble(0x3fec144130a138a1L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 4, "\u37d8\ud95f\udcf1\udbe8\udd9d\udb7a\udc1e\udbf1\udcff\ud96e\udd75", "\ucdd6\u4e16", "\ud9d1\ude61\ud96f\uddac\ud8f2\udc1c\udb80\udc66\ud966\udcb4\udae1\udc35\ud9d3\ude56\udb23\udc53\uda3d\ude3d\udac5\udd6a\ud8cb\uded4\udb4d\ude67\udb4b\udce6\ud935\udf48\udb6f\ude6c\uda2b\udecd\ud964\udde3\ud8ac\udebe\ud890\udfba\ud898\udf8f\udb83\udd37\ud8d0\udfeb\ud916\udf40\ud943\udd4e\ud961\udc22\uda59\udd58\udb46\ude4d\ud970\udd58\ud866\udf4e",
        32, 89427, 1826905772, 3331999299551183564L, -5790L, true, false, (char) 25136, (char) 46648,
        Double.longBitsToDouble(0x3fc551dada8448a0L), Double.longBitsToDouble(0x3fe8440829be79b0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud89f\udcc3\ud937\udc9b\udbc8\ude84\ud9e6\udf92\u00af\uda68\udc49\uda91\ude68\ud8ed\udc70\ud823\udc65\000\000\udaf3\udc98\uda35\udefa\ud965\udff2", "\u502f\uab37\000\u8ebdP\000\000\u50e3\u025a", "\000\ud8e2\udcb1",
        52, 85776, 0, -1661418613430676049L, -55671L, false, true, (char) 40114, (char) 65165,
        Double.longBitsToDouble(0x3f35cb205dda9000L), Double.longBitsToDouble(0x3fe560c81824d6e4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 2, "\ud89f\udcc3\ud937\udc9b\ud945\udffc\ud9e6\udf92\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\u48e4\u8f88\u6088\u1ac0\u99bd\u716f\ubffa", "\uda38\udff1\ud964\udde3",
        52, 30032, 1838854625, -1661418612042717521L, -55671L, false, true, (char) 40114, (char) 60710,
        Double.longBitsToDouble(0x3fd83572c81776a4L), Double.longBitsToDouble(0x3fe560cea024d6e4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 6, "\ud83d\udfa9", "\u3e27\u2ac5\ua1af\u55b4\ua817\uce1b\u50c1\ub1e8", "\uda1a\udce1\udb35\udcaf\udba1\uddda\uda0c\udd5f\uda37\udf20\udab6\uddaf\udb41\udeac\udb5b\udf18\udb30\udefb",
        23, 23372, 15427907, 4080573464537315400L, -73668L, false, false, (char) 62606, (char) 3377,
        Double.longBitsToDouble(0x3fc26db516bfa3c4L), Double.longBitsToDouble(0x3fbcb6cf9aac5cd8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 2, "\udb03\ude56", "\u1d9e\u18d4\u7771\u556d\ub8d2\u0534", "\ud857\udde1",
        10, 30386, 1593034125, 8735274919964274733L, -2978L, true, true, (char) 44178, (char) 50420,
        Double.longBitsToDouble(0x3fee3feaa05384c8L), Double.longBitsToDouble(0x3fd43df717e401d6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud89f\udcc3", "\u62c2\u2ac5\u87c5\u5622\u14f4\uad67\u336d\u4f45\u6e21\ua51a\u54a8\u4a70", "\udb8f\udd1e\udab6\uddaf\ud8a1\udcdc\ud8c6\ude0d",
        12, 66766, -546205613, 8055675871469575110L, -90310L, false, true, (char) 12077, (char) 62606,
        Double.longBitsToDouble(0x3fde1c54f926db34L), Double.longBitsToDouble(0x3fdafe8f1e6db67cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 5, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\udb29\udfde\uda67\ude4b\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u025a", "\uda38\udff1\udb95\udfda",
        16, 30032, -1934962659, -1661418329962834513L, -55671L, false, true, (char) 40114, (char) 65165,
        Double.longBitsToDouble(0x3fd83572c81776a4L), Double.longBitsToDouble(0x3fe560c81824d6e4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 2, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u1788\u6088\u1ac0\u99bd\ud1bc\uc12a", "\uda38\udff1\ud964\udde3\ud8ac\udebe\uda50\udc9a\uda1a\udc56\ud866\udf37\ud9b0\udf84\ud8a5\udd9a\ud943\udd9a\ud961\udc22\uda4d\uded5\udb46\ude4d\ud970\udd58\ud866\udf5f\udba6\udd76\ud9ca\udc27\udb48\udd2c\uf263\udb5f\udd7e\ud854\udd97\ud858\ude99\ud91b\udfbd",
        47, 25199, 415773686, 6028837536629756405L, 29557L, false, true, (char) 38690, (char) 13704,
        Double.longBitsToDouble(0x3fb8e829ab1f8510L), Double.longBitsToDouble(0x3fd54dbd90a7e9f0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud896\udd8e\ud833\udfd9\ud88e\udf8e", "\u5f79\u3237\ua834\uce1b\u76b5\u234e\u6e21\ua508\u54a8\u4a70\u85ef\u502f\uc9bc\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u025a\u016e\u31f6\u6e5f\u9f19\u8452\ud12c\u179a\u0553\ub5e5\u33e6", "\uda59\udd58\udb46\ude4d\ud970\udd58\ud866\udf5f\udba6\udd76\ud945\udd84",
        17, 40826, 243098741, 9218941328903639293L, 66702L, true, true, (char) 29318, (char) 8213,
        Double.longBitsToDouble(0x3fd9beecd96e5d8cL), Double.longBitsToDouble(0x3fe34622ee162786L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 2, "\ud904\udffc", "\u62c2\u2ac5\u59ca\u95a2\ua8f8\u8584\u27b6\ua7ea\u2959\u0510\u54a8\u4a70\u85ef\u502f", "\udb41\udeac\uda27\udf3d\udac5\udd6a\ud829\udc84",
        42, 74907, 950082546, 4152802950246311386L, 73668L, true, false, (char) 65184, (char) 44151,
        Double.longBitsToDouble(0x3feaac5f10be9ec8L), Double.longBitsToDouble(0x3fe6bd8e7bec2a87L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud89f\udcc3\ud923\udf51\000\ud9ca\udfc5\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac]] |a1=[Ljava.lang.String;:[[\ud89f\udcc3\ud923\udf51\000\ud9ca\udfc5\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 4, "\ud89f\udcc3\ud923\udf51\000\ud9ca\udfc5\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u025a", "\ud85d\ude0e",
        -1, 72320, 60432, 7897819509718873235L, 9454L, true, true, (char) 65414, (char) 1191,
        Double.longBitsToDouble(0x3fef615438666c4cL), Double.longBitsToDouble(0x3fe1e4428d00002cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 8, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\udafa\udc41\ud877\ude1d\ud8da\udf74", "\u837b", "\ud9d3\udd11\ud9a3\udd06\ud8f2\udc67\udb23\udf66\ud882\udcd1\udbae\ude28\udab6\uddaf\udb41\udeac\uda27\udf3d\udac5\udd6a\ud865\udfc2\ud956\ude32\ud84a\udc7c\ud935\udf48\ud8bd\udc0f\u8a5f",
        14, 72382, -984617968, 7897820476086514835L, 9454L, true, true, (char) 65414, (char) 1191,
        Double.longBitsToDouble(0x3fef615438666c4cL), Double.longBitsToDouble(0x3fe7dbda8d83572cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 4, 8, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\uda8c\udd84\uda57\udccc\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\ud919\udd94\ud857\ude1b\ud9d1\ude67\ud96f\uddac", "\u4fda\u4230\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u79dd", "\uda38\udff1\ud964\udde3",
        52, 30032, 1838854625, -1661418566185997246L, -37495L, false, false, (char) 39934, (char) 23705,
        Double.longBitsToDouble(0x3fdcb1003204cb00L), Double.longBitsToDouble(0x3fdc680685426624L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \uda01\udfd8\udabe\udfe9\ud88e\udf96\ud9e6\udf92\udafa\udc41\ud826\udf1e\ud879\uddd1\ud8ec\udfec\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac]] |a1=[Ljava.lang.String;:[[\uda01\udfd8\udabe\udfe9\ud88e\udf96\ud9e6\udf92\udafa\udc41\ud826\udf1e\ud879\uddd1\ud8ec\udfec\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 1, 4, "\uda01\udfd8\udabe\udfe9\ud88e\udf96\ud9e6\udf92\udafa\udc41\ud826\udf1e\ud879\uddd1\ud8ec\udfec\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u0c03\u227d\ucfa8\u8f88\u6088\u1ac0\u992a\ud1bc\u025a", "\udb5c\udec3\udbb4\ude73",
        -1, 30032, 1838854625, -1661418613430676049L, -27125L, true, true, (char) 1095, (char) 15741,
        Double.longBitsToDouble(0x3fb99b1331e44288L), Double.longBitsToDouble(0x3fd83572c81776a4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 6, "\ud990\udd01\udbaf\udc70\ud026\ud83c\udd77\ud93f\udf4e\uda68\udc7f\ud8da\udf74\udabc\udef2\ud823\udc65\udb0d\udc6e\ud946\udeed\ud857\ude6c\ud9d1\ude67\ud96f\uddac\uda79\udf01\udb87\udd66", "\ucfa8\u8f88\u90f6\u1ac0\u84c5\u14f5\u02c1\u0efc\u2c96\u277b\ua748\u8450\u4e81\u4bc8\u393f\u1cfd\ucad2\uae51\u2412\u9d3e\u9446\u928c\u858d\ubc1d\u29b0\u95f2\uc0a2\u23fa\u8f97\u8b3c\uc79b\uc366", "\ud8ae\udcb8\udbd1\uddc8\ud837\ude28\ud935\udd45\ud8ef\udca2\uda4e\udfb7\ud999\udc95\ud95e\udf44\u4f91\ud96e\ude11\ud9b7\udcf4\uda09\udf2b\udb99\udfe6\udb68\udcad\ud88b\udd44\udb51\udfe1\udb3c\udde7\ud99b\udd6b\udaf4\ude8c\udb89\udf3c\udaf5\udebc\udb1c\udf8f\udaf2\udfff\ud84d\udc02\uda4c\ude12",
        48, 91782, 1091197029, -1676146179804996133L, 41938L, true, true, (char) 6017, (char) 3475,
        Double.longBitsToDouble(0x3fe304eb8d4a2750L), Double.longBitsToDouble(0x3fea21af16f34e03L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 6, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96", "\u87c5\u5622", "\udb0d\udc6e",
        8, 95692, 2125692656, 6204031444064463491L, 22669L, false, false, (char) 21391, (char) 38884,
        Double.longBitsToDouble(0x3fe01077bcc7b4eeL), Double.longBitsToDouble(0x3fe9645fd85384c8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda28\udf17\ud9e1\udde6\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\u9c00\u5b87\ucd63\u1ac0\u99bd\uad5e\u025a", "\uda90\udf7c\udb80\udfe0",
        52, 30032, 1838854625, 8834589754063206567L, -55671L, false, true, (char) 43769, (char) 65241,
        Double.longBitsToDouble(0x3fd83572c81776a4L), Double.longBitsToDouble(0x3fe560c81824d6e4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud934\udefa\ud916\udce1\ud833\udec8\uda02\udf44\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud81a\ude65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac]] |a1=[Ljava.lang.String;:[[\ud934\udefa\ud916\udce1\ud833\udec8\uda02\udf44\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud81a\ude65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 2, "\ud934\udefa\ud916\udce1\ud833\udec8\uda02\udf44\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud81a\ude65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u025a", "\uda38\udff1\ud964\udde3",
        17, 30109, 1838854625, -1661418613430676049L, -55671L, false, true, (char) 40114, (char) 65165,
        Double.longBitsToDouble(0x3fd83572c81776a4L), Double.longBitsToDouble(0x3fcac7e0695d4fc4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud89f\udcc3\ud937\udc9b\ud88e\udf96\uda73\udf1e\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac]] |a1=[Ljava.lang.String;:[[\ud89f\udcc3\ud937\udc9b\ud88e\udf96\uda73\udf1e\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 1, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\uda73\udf1e\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\uc3c9\u1b08\u99bd\ud188\u025a", "\uda38\udff1\ud964\udde3",
        29, 6641, 1838843312, -1661304204087296081L, -99317L, false, false, (char) 45339, (char) 27172,
        Double.longBitsToDouble(0x3fee37faee3c88d5L), Double.longBitsToDouble(0x3fd83572c81776a4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 8, "", "\u093c\000\u2ac5\u87c5\u5622\ua8f8\uce1b\u50c1\u234e\u6e21\ua51a\u54a8\u3a8c", "\uda37\udf20\u0a36\000",
        41, -935, 0, -2377900603236193981L, 12712L, false, true, (char) 160, (char) 62,
        Double.longBitsToDouble(0x3e2e100000000000L), Double.longBitsToDouble(0x3fc26db356bfa3c4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\u8b02\000\u2a16", "\ud8ed\udc70`\000\000C\udb9b\udf6c\ud966\udcac\ud8f2\udc1c\udb87\udd66\ud882\udcd1\uda37\udf20\u0a36\000",
        -5, 38553, -2067219513, 31965358540390400L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f90087f00000000L), Double.longBitsToDouble(0x3fc260134003a3c4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud898\udde3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\ud869\udf9c\uda42\udccc\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u8768\uc9bc\ucfa8\u8f88\u6088", "\udb4d\ude67\udb76\udd50\ud97d\udf4c\ud9ba\udfad\uda38\udff1\ud964\udde3\ud8ac\udebe\ud8e0\udca2\uda1a\udc56\ud866\udf37\ud9b0\udf84\ud8a5\udd9a\ud943\udd9a\ud961\udc22\uda59\udd58\udb46\ude4d\ud970\udd58\ud866\udf5f\udba6\udd76\udbec\udcc3\udb3e\udfc4\ud934\udfbf\u2d15\ud955\udd0c\ud9ca\udc72\ud86b\udd3a\udb10\ude47\udaca\udf48\ud859\udc78\udb8d\udd2f\u55be\ud944\uded8\udb9c\udc43\ud9d1\uddd4\udbdf\udc5d\ud9ff\udd4d\ud8d1\udf48\udbdf\udf80\uda44\udf3a\uda50\udf6b\udb0f\udf6a\ud931\udebf\ud907\udea0\ud80a\udc7d\udb7d\uddb0\udb9c\udc3d\ud809\udf8c\uda5c\uddd2\udbcd\ude42\udac0\uddd7\uda25\udf27\uda7b\udf13\ud879\ude95",
        32, 27241, -318842330, 3927867083366710744L, 79173L, true, false, (char) 62527, (char) 27372,
        Double.longBitsToDouble(0x3fe5bd1be15645b3L), Double.longBitsToDouble(0x3fe9949f8f7143f8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 2, "\ud89f\udcc3\udb57\udfab\u048b\uda31\udd2b\udafa\udc41\ud934\udc2e\ud8fb\udd84\udb71\uded3\ud823\udc65\udb0d\udc6e\uda42\udd89\ud846\udefa\udbe8\udd1d\ud8ed\udf88", "\u502f\uc9bc\ucfa8\u29e7\u5785\u0546\u3355\ub3b8\u0309", "\uda38\udff1\ud964\udf32",
        30, 49693, -506670579, -1661418377207474769L, 25514L, true, false, (char) 23632, (char) 65165,
        Double.longBitsToDouble(0x3fd83572c81776a4L), Double.longBitsToDouble(0x3fc5832060935b90L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud89f\udcc3\ud9b8\udf15\udaef\udf3f\ud8be\udea5]] |a1=[Ljava.lang.String;:[[\ud89f\udcc3\ud9b8\udf15\udaef\udf3f\ud8be\udea5]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \ud89f\udcc3\ud9b8\udf15\udaef\udf3f\ud8be\udea5]] |a1=[Ljava.lang.String;:[[\ud89f\udcc3\ud9b8\udf15\udaef\udf3f\ud8be\udea5]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 5, "\ud89f\udcc3\ud9b8\udf15\udaef\udf3f\ud8be\udea5", "\ubbc3\u8058\uafc6\uc0e2\ud6b6\u6e21\ua51a\u54a8\u5e70\u85ef", "\udab6\uddaf\udb41\udeac\uda27\udf3d\uda91\ude8f\ud829\udc84\udb4d\ude67\udb76\udd50\ud935\udf48\ud9c4\udfad\uda38\udff1\ud932\udeb7\ud9d8\udeb7\uda50\udc9a\uda1a\udc56\ud866\udf37\ud9b0\udf84\ud917\udfb2\udb2e\udd88\ud961\udc22\uda59\udd58\udab1\udcc3\ud9a1\udd00\ud866\udf5f\udba6\udd76\udb75\udfbd\udb3f\udc3f\ud9c8\udd88\udb9c\udd38\ud998\udf4a\ud83d\ude3b\ud87f\udf2a\ud90c\udea9",
        51, 27651, -473964698, 4130199938597541995L, 50134L, true, false, (char) 57689, (char) 53645,
        Double.longBitsToDouble(0x3fe2ea0e58bd9315L), Double.longBitsToDouble(0x3fbc15e0090330d8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud89f\udcc3\ud937\udd20\udb9e\udebd\udb96\ude5e\udb07\udc53\uda8a\udef1\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\udaa9\uddbc\udb2c\uddf7\ud810\udc76\ud96f\uddac]] |a1=[Ljava.lang.String;:[[\ud89f\udcc3\ud937\udd20\udb9e\udebd\udb96\ude5e\udb07\udc53\uda8a\udef1\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\udaa9\uddbc\udb2c\uddf7\ud810\udc76\ud96f\uddac]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 4, 2, "\ud89f\udcc3\ud937\udd20\udb9e\udebd\udb96\ude5e\udb07\udc53\uda8a\udef1\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\udaa9\uddbc\udb2c\uddf7\ud810\udc76\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6088\u31b6\u36fd\ud1d8\u025a", "\uda38\udff1\ud964\udde3",
        52, 30032, 1838854625, -1661418613430676049L, -22074L, false, false, (char) 21679, (char) 46377,
        Double.longBitsToDouble(0x3fe5f3f68024d6e4L), Double.longBitsToDouble(0x3fe7a83b25acd441L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\000", "\uda68\udc7f",
        2, 51336, 96, 0L, 22669L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e41040000000000L), Double.longBitsToDouble(0x3fee3c5fd85384c8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud9e6\udf92\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6088\u1ac0\u99bd\ud1bc\u025a\u0f10\u2c96\u277b\ua748\u8450\u4e81\u4bc8\u393f\u421e\ucad2", "\uda59\udd58\udb46\ude4d\ud970\udd58\ud866\udf5f\udba6\udd76\ud945\udd84\udb3f\udc3f\udbff\udea4\ud8d1\udc79\uda0c\udc47\u9919\uda71\ude10",
        7, 14305, 876462127, -4856771433253165328L, -11765L, true, true, (char) 18, (char) 42230,
        Double.longBitsToDouble(0x3fdf805226622e2eL), Double.longBitsToDouble(0x3fd7431e296c3f44L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 0, "", "\u8b02", "\u5236",
        -5, -1000, 0, -1522925568L, 22669L, false, false, (char) 2703, (char) 60644,
        Double.longBitsToDouble(0x3fd500ef7882c92eL), Double.longBitsToDouble(0x3fee3c5fd85384c8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 8, 4, "", "\u89f3\u62c2\u2ac56\000\ua8f8\uce1b\u50c1\u234e\u6e21\ua51a\u54a8\u4a70", "\uda37\udf20\udab6\uddaf\udb04\udce1\uda27\udf3d",
        23, 47487, -546205613, 66262356960812018L, -90310L, false, true, (char) 12077, (char) 2175,
        Double.longBitsToDouble(0x3fd00c500926db34L), Double.longBitsToDouble(0x3fd0000f18e5b67cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 4, "\ud89f\udcc3\uda6b\udc77\ud9b0\udddf\ud9e6\udf92\udaf9\udc41\ud02c\ud8da\udf74\ud8ed\udc70\udb22\udc64\udb40\udfc8\udac2\udd9e\ud844\udc4b\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u8f88\u6c13\u8214\u99bd\uc550\u025a", "\ud84a\udf59\ud964\udde3",
        52, 30032, 1838854625, -1661418613430676049L, 79326L, true, false, (char) 36104, (char) 3830,
        Double.longBitsToDouble(0x3fdb7bb0e70ca2f2L), Double.longBitsToDouble(0x3fe8c31049f940daL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 0, 0, "\ud8f2\ude37\udbd5\uddfb\ud88e\udf96\ud9e6\udf92\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\udb6d\uddba\udacf\udca8\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\u04af\u8f88\u6088\uc774\u9736\ud1bc\u025a", "\uda38\udff1\ud964\udde3",
        52, 30032, 1838854625, -1661418613430676049L, -22074L, false, false, (char) 21679, (char) 503,
        Double.longBitsToDouble(0x3fe560c81824d6e4L), Double.longBitsToDouble(0x3fec144130a8b7abL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 9, 4, 4, "\ud89f\udcc3\ud937\udc9b", "\u3cd8\ucfcd\u6132\u210f\u5c7c\u6d72\ud0d3\u30bc", "\udbff\udde8\udac1\udf5a",
        -5, 1574, 165033270, 7379524089093262634L, 98064L, true, false, (char) 4450, (char) 24443,
        Double.longBitsToDouble(0x3fd24dfa047d08f4L), Double.longBitsToDouble(0x3fe38043f9e1c5b2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud89f\udc35\ud937\udc9b\ud88e\udf96\ud9e6\udf92\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65", "\u57e8\ua508\u54a8\u4a70\u85ef\u502f\uc9bc\ucfa8", "\udac5\udd6a\ud829\udc84\udb4d\ude67\udb76\udd50\ud88a\uddde\ud9a0\ude7d\uda38\udff1\ud964\udde3\ud8ac\udebe\uda50\udc9a\uda1a\udc56\ud806\udc53\ud9c0\udc0d",
        29, 59457, 991951802, -1867178470223480533L, -52036L, false, false, (char) 53000, (char) 52136,
        Double.longBitsToDouble(0x3fc4271427452328L), Double.longBitsToDouble(0x3fe79c0647c42258L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 2, "\000", "", "",
        30, -1000, 0, 3674937295934324736L, -100000L, false, false, (char) 179, (char) 14758,
        Double.longBitsToDouble(0x3fb0979a396bc9c8L), Double.longBitsToDouble(0x3fe670dec8000059L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 5, 2, "\ud89f\udcc3\ud937\udc9b\ud88e\udf96\ud8d0\udd86\uda06\udc98\udba1\ude77\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\u502f\uc9bc\ucfa8\u3d31\u60b3\ud392\u99bd\u7b41\u025a", "\uda38\udff1\udb95\udfda",
        16, 91840, -1934962659, -1661418329962834513L, 58836L, false, true, (char) 63707, (char) 11891,
        Double.longBitsToDouble(0x3fb99b1339e44288L), Double.longBitsToDouble(0x3fd83005881776a4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 5, 8, "\udbcc\udd00\ud9f3\udf27\ud88e\udf96\ud96f\udc92\udb2a\udc51\uda34\udcca\uda0e\uddd6\ud8ed\udc2e\ud823\udc65\udb4e\udc8e\ud95d\udf3a\uda62\ude3b", "\ua23a\u85ef\ub424\uc9bc\u30d8\u91d1", "\ud829\udc84\udb4d\ude67\udb76\udd50\ud935\udf48\u559c\udb43\udcf5\udb95\udff3\ud9c5\udc8f\uda50\udc9a\u6951\ud866\udf79",
        53, 80082, -1631001771, -5634178238943636777L, 52270L, true, false, (char) 21679, (char) 65373,
        Double.longBitsToDouble(0x3fe560c81824d6e4L), Double.longBitsToDouble(0x3fe691724b5f2e08L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 0, "\udb89\udcb8\ud944\udf9b\ud88e\udf96\ud9e6\udf92\udafa\udc41\uda68\udc7f\udb08\udf4a\ud89d\ude92\ud823\udc65\udada\udc6e\uda42\udd89\ud857\udde1\ud9d1\ude67\ud96f\uddac", "\ua871\uc954\ucfa8\u8f88", "\ud829\udc84\udb4d\ude67",
        33, 75546, 966899904, 2134747839542040868L, 66162L, true, true, (char) 57901, (char) 65184,
        Double.longBitsToDouble(0x3fbcb6cf9aac5f10L), Double.longBitsToDouble(0x3fc7d3d90b5ec73cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 4, "\udb00\udfb4\ud937\udc9b\uda1d\udf34\uda58\udf25\udafa\udc41\uda68\udc7f\ud8da\udf74\ud8ed\udc70\ud823\udc65\udb0d\udc6e\uda42\udd89\ud84a\udcdd\ud9d1\ude67\udac6\udc0d", "\u502f\u8d77\ucfa8\u2d56\u6088\u1ac0\u99bd\ud1bc\u025a\u0f10\u64e5\u277b\ua748\u8450\u4e81\u4bc8\u3963\u421e\u8ead\u908c\u161d\u4ab3\u7197\u928c\u858d\u967c\u2a49\u45f3\u8a18\u4e9f\u26d1\ua9d6\uc1a9\u0b28\u8a92\uc3ba\u9673\u3679\u5af1\ua0d7\uc70d\u807e\u4849\uc28a\ubc45\u49bd\u5e88\uaa73\u42ad\u9723\u3706\u93fc\u0862\u3e62\uaae3\u18b2\u3c74\u602e\ua39b\u3e55\u9727\u4859\u32c8\u2b35\u617a\u842b\u3f8a\u526c\u8331\ubd91\u3ffc\u4465\u3ac3\u32c9\u2752\u8f54\u6824\u0719\ub06c\ua241\ua094", "\udb4e\udfed\udb61\udcbb\ud902\udc8f\udbf4\udfb1\ud91a\uded9\uda0c\udd51\ud9c3\udeeb\uda8e\uddc4\ud839\udd93\udba5\udea7\udb95\udc9b\udb88\udfb4\ud9e0\udcfd\udb4a\udf36\uda91\udff2\ud995\udcbd\ud98c\udc16\ud8af\udf89\udb25\udd33\uda6a\udf69\udb8e\udc10\udb1c\udc22\udb85\udd3b\ud94d\udfee\uda8d\udfa5\udab8\udef2\udb0f\udc38\uda8b\udc57\uf687\uda1f\udfb9\ua82b\ud8bb\udee1\uea41",
        47, 1719, 2082258208, -3016448913175090370L, -66292L, false, false, (char) 42217, (char) 30701,
        Double.longBitsToDouble(0x3fde6743468d1166L), Double.longBitsToDouble(0x3fec8e0fd999b8d6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processNonOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processNonOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
