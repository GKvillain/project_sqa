package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud86e\udf1a\uda97\udca7\udbe3\udecc\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb5f\ude3a\ud99b\udf26\ud953\udd48",
        -5, 47449, -1032957498, -9174423548475140622L, -87543L, true, true, (char) 26962, (char) 32804,
        Double.longBitsToDouble(0x3fec0fcb2bd4157eL), Double.longBitsToDouble(0x3fc0b8e228954cfcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265\u146d]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265\u146d]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 1, 6, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265\u146d", "\u62fb\ucddd\u34d5\u3271\u1733\u141d\u8a6e\uccdb\u7dc1", "\udb8a\udc3c\ud8d5\uddbb\ud816\udd8b\udb5f\ude3a\ud99b\udf26\ud953\udd48\ud85c\ude74\udbe6\udd88",
        7, 62060, 237573618, -395111408638111913L, 71144L, false, true, (char) 34022, (char) 338,
        Double.longBitsToDouble(0x3fc0b8e22c954cfcL), Double.longBitsToDouble(0x3fd7b9f97b87083eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 2, "\ud90a\udc29\udb51\udcda\uda7f\udfa6\ud976\uddcf\ue265", "\ua8ad\u62ea\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\udaa8\udda8\ud805\udd36\ud9a2\udcf5\uda5b\ude58\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb5f\ude3a\ud99b\udf26\ud97c\udf48\ud85c\ude74\udbe6\udd88\uda04\udebe\ud877\udee3\ud92c\udfd2\ud8ed\udff1\ud8d0\ude04\ud98e\udc1e\udb6e\udf4a\ud93d\udd73\ud8ed\udcc5\ud846\udc79\udbbc\udd6c\u3e06\uc9b4\udb77\udc06\udaa8\udd47",
        52, 31853, 1642645606, 1759509342936774214L, -30392L, true, false, (char) 7820, (char) 2797,
        Double.longBitsToDouble(0x3fe8826d4ec036ecL), Double.longBitsToDouble(0x3fe78a8c632d0d6eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265\u146d\ud88c\udd7c\udbed\udfa7\ud9f3\ude10\udbf2\udc2d\uda96\udd2d\ud849\udfcb\u51c4\ud8ae\udecd\ud808\udf30]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265\u146d\ud88c\udd7c\udbed\udfa7\ud9f3\ude10\udbf2\udc2d\uda96\udd2d\ud849\udfcb\u51c4\ud8ae\udecd\ud808\udf30]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 9, 1, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265\u146d\ud88c\udd7c\udbed\udfa7\ud9f3\ude10\udbf2\udc2d\uda96\udd2d\ud849\udfcb\u51c4\ud8ae\udecd\ud808\udf30", "\u0e18\u8d16\u1275\u0fb8\u760a\u83dc\u9b4e\ud115\uace9\u9f19\u20cd\u377d\u66ba", "\ud97b\udc92\udb6e\udf4a\ud93d\udd06\ud8ed\udcc5\ud846\udc79\udbbc\udd6c\ud830\udeb7\ud980\ude92\ud935\udcb1\ud8e6\udf0e",
        38, 57654, 29991503, -8369013895519829813L, 51089L, false, true, (char) 11093, (char) 4868,
        Double.longBitsToDouble(0x3fe71f9391197de0L), Double.longBitsToDouble(0x3fd3e42b60e77192L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51", "\u94ff\u8948\uc40d\u62fb\ucddd", "\u51c4\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud86e\udf1a\uda97\udca7\udbe3\udecc\u7dc7\ud9e5\udd00",
        8, 7736, -1606445877, -6009833571191201295L, 10273L, false, false, (char) 59329, (char) 22125,
        Double.longBitsToDouble(0x3feabfd42797696bL), Double.longBitsToDouble(0x3fc1199955a9cae8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud86b\udd9b\uc6c5\uda00\udef1\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\ud86b\udd9b\uc6c5\uda00\udef1\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud86b\udd9b\uc6c5\uda00\udef1\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\ud86b\udd9b\uc6c5\uda00\udef1\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud86b\udd9b\uc6c5\uda00\udef1\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud86e\udf1a\uda97\udca7\udbe3\udecc\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb5f\ude3a\ud99b\udf26\uda9e\ude6c",
        29, 82135, -1038986810, 8628652124282832180L, 71144L, false, true, (char) 34023, (char) 338,
        Double.longBitsToDouble(0x3fc0b8e228954cfcL), Double.longBitsToDouble(0x3fe27c41a1f89073L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud86e\udf1a\uda97\udca7\udbe3\udecc",
        35, 50079, -1835929667, 8037763871013835979L, -43787L, true, true, (char) 58640, (char) 43218,
        Double.longBitsToDouble(0x3fdf280ad0881c52L), Double.longBitsToDouble(0x3feabfd42797696bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 9, 9, 0, "\udb23\udd9f\udaae\udc71\udb29\udf51\ud976\uddcf", "\ua6b9\uc40d", "\uda96\udd2d\ud80c\uddcc\uda7c\udf41",
        2, 39947, 1319398426, 9219707372017204183L, -26196L, true, false, (char) 32794, (char) 29241,
        Double.longBitsToDouble(0x3fc96df16ba280fcL), Double.longBitsToDouble(0x3fbad8e6df8ef558L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u335a", "\uda8a\udeaf\uda47\udfe1\uda11\ude46\ud86e\udf1a\uda97\udca7\udbe3\udecc\udb8a\udc3c\udb51\udd72\uc64a\udae4\udd7d\ud809\udec6\udafc\udf3e\ud85c\ude74\udbe6\udd88\ud853\ude25\ud877\udee3\uda71\udec7\ud8ed\udff1\ud9a3\udd8d",
        16, 74392, -110817942, 1548828707073944532L, 42897L, false, false, (char) 24969, (char) 30106,
        Double.longBitsToDouble(0x3fd002c6f0da0404L), Double.longBitsToDouble(0x3fee51e583700a57L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 1, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud86e\udf1a\uda97\udca7\udbe3\udecc\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb5f\ude3a\ud99b\udf26\ud953\udd48",
        -5, 47449, -1032957498, -9174423548475140622L, -87543L, true, true, (char) 26962, (char) 32804,
        Double.longBitsToDouble(0x3fec0fcb2bd4157eL), Double.longBitsToDouble(0x3fc0b8e228954cfcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda91\udfc5\udad1\udd7a\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udad1\udd7a\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 0, "\uda91\udfc5\udad1\udd7a\udb29\udf51\ud976\uddcf\ue265", "\ua1c6\u81cb\ucdd3\u34d5", "\ud8ae\udecd\udafb\udca9\udae1\udfd9\uda0f\udd79\ud820\udcd6\udbde\uddc1\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb2e\udd43\ud99b\udf26\ud953\udd48",
        47, 50562, -1032957498, -9174423548475140622L, -87543L, true, true, (char) 26962, (char) 58660,
        Double.longBitsToDouble(0x3fe2dbfee3d4157eL), Double.longBitsToDouble(0x3fc0b8e228954cfcL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 8, "\uda99\udd36\udabf\udd71\ud8f0\ude17\ud97a\udf94\ud990\udc14\u146d\ud88c\udd7c\udbed\udfa7\ud9f3\ude10\udbf2\udc2d", "\u1e16\u141d\u8a6e\uccdb\u7dc1\u3f38\ubf91\u1275\u91a0", "\ud99b\udf26\udae8\udf66\ud947\uddb8\udbe6\udd88\ud853\ude25\ud877\udee3\ud923\udc20\ud8ed\udff1\uda7c\udd9a\ud97b\udc92",
        29, 51530, -858520447, -4102368741868721019L, -75096L, false, true, (char) 51109, (char) 37146,
        Double.longBitsToDouble(0x3f9981c57fe29440L), Double.longBitsToDouble(0x3fe39ecf54fea0b1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud86e\udf1a\uda97\udca7\udbe3\udecc\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb5f\ude3a",
        -2, 55120, -559209365, -7833202376710401594L, 90990L, false, false, (char) 51675, (char) 63000,
        Double.longBitsToDouble(0x3fde3d573ad4e574L), Double.longBitsToDouble(0x3fec0fcb2bd4157eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 4, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d", "\000",
        -5, 98352, 496222479, 33825319882326016L, -51044L, true, false, (char) 41687, (char) 62726,
        Double.longBitsToDouble(0x3fedec82efa89291L), Double.longBitsToDouble(0x3fc96df1600000fcL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 5, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u34d5", "\ud8ae\udf4b\udb5f\udddc\uda8e\udc1c\ud86e\udf1a\uda97\udca7\udbe3\udecc",
        35, 50079, -1835929667, 8037763871013835979L, 90990L, true, false, (char) 51675, (char) 30978,
        Double.longBitsToDouble(0x3fc1199955a9cae8L), Double.longBitsToDouble(0x3fec0fcb2bd4157eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 0, "\uda91\udfc5", "\ud270\u900d\u9ff3\ub00d", "\ud9b8\udf25\u9c56\ud822\uddd0\udbda\udfc3\udac2\udd17\udb54\udde9\uda8e\udc1c\ud86e\udf1a\udbcf\udca3\000\udb10\udc87",
        44, 47333, 9166760, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4d5c0000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 2, "\ud960\uded0", "\u930f\u9cca\u9ff3\u850d", "\000\uda6f\udcd7",
        38, 56254, 0, 2339668327736700131L, -26196L, true, false, (char) 0, (char) 57255,
        Double.longBitsToDouble(0x3fc96df16f2280fcL), Double.longBitsToDouble(0x3fbae46ebf8ef558L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 9, 6, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u34d5", "\000",
        -5, 37936, 199, -5026228291952716715L, -34464L, true, false, (char) 29241, (char) 1110,
        Double.longBitsToDouble(0x3fee4501fc000000L), Double.longBitsToDouble(0x3f4bd56400000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 9, 5, 0, "\ud87b\udc0f\udabf\udd43\udb29\udf51\udbf5\udcee\ud88c\udea9", "\uc40d\u62fb\uc591\u774e\u9471\u1733", "\uda8e\udc1c\ud9b2\udd3c\uda97\udc6f\udbe3\udecc\u84ca",
        0, 44179, 1871437736, -6899632506359100472L, -26257L, false, true, (char) 43218, (char) 33114,
        Double.longBitsToDouble(0x3fe59bd1e7fd9b94L), Double.longBitsToDouble(0x3fd933a1a91198f0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 9, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud86e\udf1a\uda97\udca7\udbe3\udecc\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb5f\ude3a\ud99b\udf26\ud953\udd48",
        -5, 68593, -1087901600, -9177884119589644814L, 13150L, true, true, (char) 26962, (char) 32804,
        Double.longBitsToDouble(0x3fec0fcb2bd4157eL), Double.longBitsToDouble(0x3fc0b8e228960cfcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 4, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265\udbf6\udf01\uda5c\udd84\ud924\udcd4\ud889\udf50", "\u5165\u17d6\u141d\u8a6e\u93ee\ud24d\uc3a0\u254d\u1275\u1c2a\u5561\u0614", "\ud85c\ude74\ud8ba\udc33",
        9, 62060, 237573618, -395111409258868905L, -26664L, false, true, (char) 34022, (char) 338,
        Double.longBitsToDouble(0x3fc0b8e228954cfcL), Double.longBitsToDouble(0x3fb0df11434943c0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 2, "\uda91\udfc5", "\000\000\ub84f\ub00d", "\udbf2\udc2d\uda96\udd2d\ud849\udfcb\uee16\ud8ae\udecd\ud81a\udffa\000\000\000\udb6a\ude75\000",
        13, 47333, 1871437736, -6899632506371309368L, -26257L, false, true, (char) 43218, (char) 38559,
        Double.longBitsToDouble(0x3fb1038a78000000L), Double.longBitsToDouble(0x3fecbb4b5c88cccaL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda64\udf6b\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda64\udf6b\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 4, 0, "\uda64\udf6b\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\ucddd\u0dd5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\udbf8\udf0a\udaa1\ude82\udbe3\udecc\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb5f\ude3a\ud99b\udf26",
        30, 26635, -1823809551, -4436518674204072348L, 74148L, true, true, (char) 30978, (char) 26962,
        Double.longBitsToDouble(0x3fd6a72ba703f2caL), Double.longBitsToDouble(0x3feea33ccc85c711L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 1, 2, "\uda91\udeed\ud99f\udc4b\ud9e5\udc73\udb43\udc39\udb26\udc8b\udb93\udf11\ud88c\udd7c\udbed\udfa7\ud9f3\ude10\uda10\ude1d\udbfa\udd39\ud849\udf2d\ud9d1\uddc0\ud8ae\udecd\ud937\ude68", "\u2459\u692b\u7d64\u4410\u760a\u74a2\u25b9\u50ad\u4e00\u9f19\u5997", "\ud8ed\udff1",
        31, 10655, 1924832392, -475959435645971327L, -78629L, true, false, (char) 50979, (char) 12023,
        Double.longBitsToDouble(0x3fe3eb0cce2d1ba0L), Double.longBitsToDouble(0x3fe56e0144657696L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 4, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\u53b7\u62fb\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud879\ude1a\uda97\udca7\udbe3\udecc\udb8a\udc3c\ud900\udd29\udbe9\udc40\ud864\udf6e\ud99b\udf26\ud953\udd48",
        -5, 47449, -1032957498, -5332461429486167095L, 92814L, true, true, (char) 29539, (char) 55222,
        Double.longBitsToDouble(0x3fc0d7c569a1ac40L), Double.longBitsToDouble(0x3fabcaeee2a86040L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 5, 0, "\uda91\udfc5", "\000", "",
        30, 89403, 549934114, 867583393792L, -88749L, true, false, (char) 50625, (char) 18787,
        Double.longBitsToDouble(0x3fb56e803da51118L), Double.longBitsToDouble(0x3e92f7b20ba00000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 0, "\uda91\udfc5\udaab\udf5a\u1799\udb89\udde7\ud9b9\udeed\u1473\ud88c\udd7c\udbed\udfa7\ud9f3\ude10\ud992\ude5b\ud96b\udca0\ud849\udfcb\u51c4\ud940\ude36\udb89\ude77\ud9cf\udd0a\ud86e\udf1a\ud928\udecf\udbe3\udefe\udb8a\udc3c\udb51\udd72\ud816\udd14\udb5f\ude3a\ud8fd\udd42\ud953\udd48\ud85c\ude74\ud83c\udd93\ud853\ude25\ud877\udee3\uda71\udec7\ud8ed\udff1\ud9a3\udd8d\ud97b\udc92\udb6e\udf4a\ud93d\udd06\ud9d4\udddb\ud846\udc1d\udbb4\udd6c\ud9a3\ude2f\udaf7\udf0e\udbd9\udc15\ud9c6\udf3c\ud8ae\udcda\ud97c\udf74\ud9b9\udd77\udaa0\udf9f\ud8ca\udff6\udba5\ude00\ud9c4\udfb6\udbe8\ude60\ud8ab\udcb3\ud98e\udd9a\ud953\udf3b\ud814\ude74\udbbb\udf6e\udbe1\udd47\ud93e\udfd1\ud92c\udc9e\ud86c\uddba\ua4a1\ud8c1\uddc8\udb7b\udd03\udae8\udf84\udac5\udc93\ud951\udf75\udbec\udec8", "\u0749\u3a9d\u94d2\u8504\u7376\u16f2\u2266\uc15c\u74d0\uc924\u764f\u53ef\u81ff", "\ud859\udc4f\uda07\udc59\udb7c\udf12\ud816\udefd\ud9d2\udc87\udb28\ude01\udb4f\ude63\ud8c1\udc49\ud93a\udf27\udb48\udcbd\ud8bf\udebd\ud83d\uddbd\ud9d0\udc09\udb9d\udf15\ud972\ude95\ud9ce\udccc\ud941\udc27\ud945\uddc2\ud8ad\uddb0",
        4, 485, -219196467, 5500008644824348338L, 87276L, true, true, (char) 5520, (char) 11264,
        Double.longBitsToDouble(0x3fdcee94dfa7c1c8L), Double.longBitsToDouble(0x3fd4a49ed0070facL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 1, 0, "", "\u6700", "",
        27, 21936, 11211891, 92505686189312L, -100000L, false, false, (char) 0, (char) 50375,
        Double.longBitsToDouble(0x3f3258e2add1f800L), Double.longBitsToDouble(0x3feda5111c070912L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 5, 3, "\uda2a\udd11\udaa2\udd82\udb29\udf51\u413e\ud8e4\udee9\ud9ff\ude2b", "\u62fb\ucddd\u34d5\u3271\u1733\u24b5\u5f64\uccdb\u7dc1", "\udb8a\udc3c\ud984\udd13\ud89d\udef0\uda1c\udc4e\udad9\ude4f\ud9c5\udd6d\udad3\udf3b\udbe6\udcc5",
        28, 62060, 237573618, -395111408638111913L, 85592L, false, true, (char) 34022, (char) 338,
        Double.longBitsToDouble(0x3fc0b8e22c94e918L), Double.longBitsToDouble(0x3fd7b9f97b87083eL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 9, 0, 0, "", "\u88fe", "\u146d\ud88c\udd7c\ud81b\udc7d\ud9de\uddee\udbf2\udc2d",
        10, 25443, -1229920746, 2131259319389793267L, -100000L, false, false, (char) 36500, (char) 33239,
        Double.longBitsToDouble(0x3fe2f84897fe7ce5L), Double.longBitsToDouble(0x3fed44948ccb6f8bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 4, 2, "\ud90a\udc29\udb51\udcda\uda7f\udfa6\ud976\uddcf\ue265", "\ua5b7\u30c5\ub743\u34f2", "\ud8ae\udecd\udb5f\udddc\udaa8\udda8\ud805\udd36\ud9a2\udcf5\uda5b\ude58\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb5f\ude3a\ud99b\udf26\ud97c\udf48\ud85c\ude74\udbe6\udd88\uda04\udebe\ud877\udee3\ud92c\udfd2\ud8ed\udff1\ud8d0\ude04\ud98e\udc1e\uda13\ude8f\udb3a\udec2\ud8a0\udeca\ud8a6\udda1\udbc7\udea4\u3e06\uc9b4\udb77\udc06\udaa8\udd47",
        52, 31853, 1642645606, 1759509342941296198L, -30392L, true, true, (char) 8549, (char) 49809,
        Double.longBitsToDouble(0x3fe8826d4ec036ecL), Double.longBitsToDouble(0x3fe78a8c632d0d6eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 0, "\ud86b\udcdc\uc6c5\udb11\udc79\udb12\udfdc\ue229\u146d\ud830\udd2d\ud962\udfeb\ud84f\udcbe\udb89\udc28\uda55\uddec\ud963\udff8\ud942\ude69", "\u9ba0\u7dd3\u0e18\u8d16\u8e4f\u277f\ua87f\u83dc\uc0c2\u18d5\u4776\u36ab\u1860\u8f50\u39b4\u834d\u066c", "\ud93d\udd06",
        46, 29172, 1396681861, -8632219449775483313L, 67647L, false, false, (char) 11123, (char) 46603,
        Double.longBitsToDouble(0x3fec14cd3d255280L), Double.longBitsToDouble(0x3fe4a57877f9774dL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, ]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 0, 8, "", "\000", "\u146d",
        44, 90179, 549934114, 2923018445038263382L, -59552L, true, true, (char) 7001, (char) 63805,
        Double.longBitsToDouble(0x3fe0000000000063L), Double.longBitsToDouble(0x3fb540003da51118L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 4, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\uc40d\u62fb\u829b\u332f", "\ud8ae\udecd\udb5f\udddc\udb88\udddf\ud8a0\udcfc\uda97\udca7\udbe3\udecc\udb8a\udc3c\udb51\udd72\ud816\udd4a\udb5f\ude3a\ud99b\udf26",
        30, 26635, -1823809551, -4436518674204072348L, -81500L, true, true, (char) 30978, (char) 26962,
        Double.longBitsToDouble(0x3fd6a72ba703f2caL), Double.longBitsToDouble(0x3feea0abf485c711L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\u13f5", "\ubfa3\000\ud816\udc0a\000\000",
        28, 25443, -1241513984, 544746483L, -40295L, false, false, (char) 54419, (char) 33239,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud8ab\udca3\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |a1=[Ljava.lang.String;:[[\ud8ab\udca3\udabf\udd71\udb29\udf51\ud976\uddcf\ue265]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 9, 4, "\ud8ab\udca3\udabf\udd71\udb29\udf51\ud976\uddcf\ue265", "\u53b7\u62fb\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud879\ude1a\uda97\udca7\udbe3\udecc\ud958\udc43\ud900\udd29\udbe9\udc40\ud864\udf6e\ud8cf\udfdf\ud950\udfb1",
        11, 78309, -1032957498, -653285188308828977L, 89515L, true, false, (char) 2377, (char) 49136,
        Double.longBitsToDouble(0x3fe34ca77f22db31L), Double.longBitsToDouble(0x3fd9791e978ee130L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\udb7e\ude68]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\udb7e\ude68]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\udb7e\ude68]] |a1=[Ljava.lang.String;:[[\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\udb7e\ude68]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda91\udfc5\udabf\udd71\udb29\udf51\ud976\uddcf\udb7e\ude68", "\uc40d\u62fb\ucddd\u34d5", "\ud8ae\udecd\udb5f\udddc\uda8e\udc1c\ud86e\udf1a\uda97\udca7\udbe3\udecc\udb8a\udc3c\udb51\udd72\ud816\udd4a\ud817\ude37\ud99b\udede\ud953\udd48",
        58, 47449, -1032957498, -9174423547183294990L, -87543L, true, false, (char) 26874, (char) 24581,
        Double.longBitsToDouble(0x3fdfd583301f4960L), Double.longBitsToDouble(0x3fc0bc3f88954cfcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processNonOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processNonOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
