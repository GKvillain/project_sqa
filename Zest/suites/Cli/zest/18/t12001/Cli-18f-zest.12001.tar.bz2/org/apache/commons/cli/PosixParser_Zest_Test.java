package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\ucb03\u5738\u786b", "\ud9d5\udd88\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb22\udcad\ud901\udc28\u8cfb\uda28\ude0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, 677900967, 7231082740212344405L, -42697L, true, true, (char) 26440, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6a91917acb0efL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79", "\u7409\u7ee4\ucab3\u5738\u786b", "\ud9d5\udd88\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud8ae\udcd0\udb22\udc87\ud901\udc28\u8cfb\uda28\ude0d\udbf7\ude5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, 677900967, 7231082740212344405L, -42697L, true, true, (char) 26440, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe43921160e5212L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\ucb03\u5738\u786b", "\ud9d5\udd94\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\ud96f\udebc\ud946\udd3b\udb22\udcad\ud901\udc28\ud842\udeeb\udbed\ude8a\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, 677900967, -6175658024265397668L, -96446L, false, false, (char) 39922, (char) 21798,
        Double.longBitsToDouble(0x3fe6a91917acb0efL), Double.longBitsToDouble(0x3fe2ce8c66670437L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \u65c0\ud806\uddf7\udafb\udd79\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9d2\udf2e\udb6a\udd83\ud925\uddfe\ud8dc\udcf6\udbb1\udcf4\uda68\udceb]] |a1=[Ljava.lang.String;:[[\u65c0\ud806\uddf7\udafb\udd79\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9d2\udf2e\udb6a\udd83\ud925\uddfe\ud8dc\udcf6\udbb1\udcf4\uda68\udceb]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 1, "\u65c0\ud806\uddf7\udafb\udd79\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9d2\udf2e\udb6a\udd83\ud925\uddfe\ud8dc\udcf6\udbb1\udcf4\uda68\udceb", "\u634c", "\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb83\udedd\ud900\udff8\u8cfb\uda92\ude02\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, -1371737433, 4907586663792813653L, -42697L, true, true, (char) 26440, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6a91917acb0efL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\udb1f\udc3a\ud806\uddd2\udafb\udd79]] |a1=[Ljava.lang.String;:[[\udb1f\udc3a\ud806\uddd2\udafb\udd79]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 0, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\ucb03\u00ff\u9e2b", "\ud9d5\udd88\ua164\ud9be\udedf\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb22\udcad\ud901\udc28\u8cfb\uda28\ude0d\ud87a\udc5e\u8382\000\udaa7\udf13\u00be",
        -5, 31021, 62119, 7231082741423449685L, -100000L, false, false, (char) 26440, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6a91917acb0efL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 8, 3, "\ud853\udef2\ud806\uddd2\udafb\udd79\ud86b\ude17\ud8be\ude3e", "\ucb03\u5738\u5107\uc113\u1a01\uaa6e\u3ec8\u634c\u85f2\u2a33\u4c67\ubf20\u2252\ub503\ua0cb\ucc7a", "\udaab\udf46\ud852\ude93\udaa7\udf74\uda9f\udd3f\ud9be\udd4d\ud8c3\udeb4\udbe9\ude7d\udba9\udcba\udbe6\ude13\ud9d1\udc17\ud902\udf7c\uda8c\ude5e\ud869\uddb4\ud8a6\udfc3\udbf5\udc6f\ud816\udd7a\ud851\udd0f\uda8a\udda7\ud87c\udffd\ud9ba\udfa4\uda8a\udfac\udbd4\udfed\uda66\udd47\udbac\udc9b\ud8a2\udc25\ud900\udf58\udb01\udc55\ud969\uddbf\ud9fc\udc0e\udb20\ude50\udb0a\udfd1",
        51, 94304, 1077544871, -9181641598920199285L, 89629L, false, false, (char) 22211, (char) 62476,
        Double.longBitsToDouble(0x3feee3680a9c264aL), Double.longBitsToDouble(0x3fd03cce82c74956L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb1e\udfa8\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\ucb03\u8138\u786b\uc086\u1a01\ud3ea\u3f1d", "\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb22\udcad",
        53, 45436, -1747533775, 5536511461328061314L, 20830L, true, false, (char) 52332, (char) 23755,
        Double.longBitsToDouble(0x3fe538ed2f712867L), Double.longBitsToDouble(0x3fe2cb22ce3c951cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 8, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79", "\000\u4d3f", "\ud8dc\udcf6\udbb1\udcf4\uda68\udceb\ud88d\udd84\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb22\udcad",
        53, 45436, -1747533775, 180144870260736L, 31999L, false, true, (char) 52217, (char) 23755,
        Double.longBitsToDouble(0x3fe538ed28712867L), Double.longBitsToDouble(0x3fe2ab22cb82b7d0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 8, 1, "\uda01\ude47\udb31\udc16\udb91\ude51", "\u7409\u4d3f\ucb03\u5738\u786b", "\ud9d5\udd88\uda05\uddb2\ud8cd\udcdd\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\ud8ed\udf92\udbdd\udf75\u8c97\uda28\ude0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, 677900967, 7231082740212344405L, -31059L, false, true, (char) 55798, (char) 32923,
        Double.longBitsToDouble(0x3fc2b85b82ef3924L), Double.longBitsToDouble(0x3fdea660b4c8c62cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 3, "\udb1f\udc3a\ud806\uddd2\ub512", "\u7409\u4d3f\ucb03\u5738\u92ca\u5582\u1a01\u6634", "\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46",
        31, 33509, 188265343, 8669092710123487281L, 64738L, true, false, (char) 55074, (char) 39411,
        Double.longBitsToDouble(0x3fc32fe613d53f58L), Double.longBitsToDouble(0x3fe538ed2f712867L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb1f\udc3a", "\uc159\ua82f\u1889\uad75\ucb03\u5738", "\ud82a\udcec\ud9d5\udd88\uda05\uddb2\ue4d3\ud850\ude07\udb83\udc98\uda1c\udeb4\udaa4\udd46",
        31, 82237, 963554662, -3480852877931896546L, 64738L, true, false, (char) 55074, (char) 39411,
        Double.longBitsToDouble(0x3fc32fec13d53f58L), Double.longBitsToDouble(0x3fe538ed2f712867L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 0, "\udb1f\udc3a\uf08c\000", "\u7409\u4d3f\u11d4", "\000",
        -5, 4000, -1056964608, -6240896223087940570L, -100000L, false, false, (char) 658, (char) 53989,
        Double.longBitsToDouble(0x3febfe5835e40b38L), Double.longBitsToDouble(0x3fa8bc2730097d60L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 8, 2, "\udb1e\udfc5\ud8f4\uddc9\udafb\udd79", "\u7409\u4d3f\ucb03\u5738\u786b", "\ud9d5\udd3a\uda05\uddb2\ud943\udcd8\ud96a\ude34\udad8\udc5c\ud8a3\udc91\udbdb\udf02\ud946\udd2b\udb22\udcad\udac9\udc2c\u8cfb\uda28\ude0d\ud87a\udc5e\uda19\udf3d\udbf8\uddcf\ud9ed\ude63\uda8e\udfe0",
        32, 31021, 677900967, 7231082740212344405L, -31059L, false, true, (char) 54147, (char) 32765,
        Double.longBitsToDouble(0x3fed33b4bda197beL), Double.longBitsToDouble(0x3fed769f8761352cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \udb12\udcf4\ud806\uddd2\udafb\udd79]] |a1=[Ljava.lang.String;:[[\udb12\udcf4\ud806\uddd2\udafb\udd79]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 0, 1, "\udb12\udcf4\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\uaf0e\uc5ff\u016b", "\u5b2a\uda03\udfdc\ud943\udcd8\ud87c\udd3b\uda93\udfd0\uda95\udd99\udaca\udd3a\ud946\udd3b\udb22\udcad\udafd\udf5e\udae4\udfda\uda28\ude0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 76837, 677849938, 7231082740212344405L, -42697L, true, true, (char) 26440, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6a91917b489bdL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda44\udc2d\ud9e9\udf42\udb0b\ude57]] |a1=[Ljava.lang.String;:[[\uda44\udc2d\ud9e9\udf42\udb0b\ude57]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\uda44\udc2d\ud9e9\udf42\udb0b\ude57]] |a1=[Ljava.lang.String;:[[\uda44\udc2d\ud9e9\udf42\udb0b\ude57]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 4, "\uda44\udc2d\ud9e9\udf42\udb0b\ude57", "\u87fe\uba41\u52a0", "\udbb1\udd54\udb34\udd30\udb0e\ude20\ud96e\ude03\udad0\udd97\ud8b1\udea0\udb6b\udd6f\uda1c\udeb4\ud90a\udf79\ud946\udd1b\udb8d\udd82\ud901\udc28\udabe\ude08\uda28\ude0d\ud822\udc52\udaff\udc71\ud81f\udedc\udaa7\udf74\uda9f\udd3f\ud9be\udd4d\ud8c3\udeb4\uda41\udd08\udbd3\udd5a\udbe6\ude13\udb35\udf09\ud9c4\udf27\ud891\udd62\ud8b9\udf7b\udb49\udce7\uda14\udfe0\udbea\ude0b\ud89c\ude2c\ud8ed\ude47\u3677\ud829\udd14\ud899\udd49\udbdb\ude10\udac1\udebf\udad6\uddb7\udb24\udea1\ud9ed\udf2c\uda07\udf25\ud878\udc4b\ud9fb\udd21\ud97c\udeea\ud8a9\udef2\ua86f",
        57, 95602, 1188196589, -9206966539854470333L, 81667L, false, false, (char) 5596, (char) 60372,
        Double.longBitsToDouble(0x3fe21e7a3239332eL), Double.longBitsToDouble(0x3fbbdab923707208L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 4, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\u048d\u334e\u7898", "\ud9d5\udd88\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb22\udcad\ud901\udc28\u8cfb\uda28\ude0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, 677900967, 7231082740212344405L, -42697L, true, true, (char) 26440, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6a91917acb0efL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 8, 1, "\ud84f\uddd2\ud806\udd7e\udafb\udd79", "\u7409\u4d3f\ucb03\u5738\u786b", "\ud9d5\udd88\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\ud93c\udcc4\ud926\udcc7\ud92a\uddf1\udb22\udcad\ud901\udc28\u8cfb\uda23\udc0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 56237, 677901049, 7231082740212344405L, -42697L, true, true, (char) 26440, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6ad6117acb0efL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\ucb03\u5738\u786b", "\ud95c\udfed\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb22\udcad\ud901\udc28\u8cfb\uda28\ude0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, 677900967, 7231082740212344405L, -42741L, true, true, (char) 26440, (char) 13997,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6aac117acb0efL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 4, "\udb85\ude94\ud806\udd75\udafb\udd79", "\u7409\u4d3f\ucb03\u5738\u786b", "\ud8d5\udd88\uda05\uddb2\uda9a\udf04\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud918\udc5f\udb22\udcad\ud40e\u8cfd\u028f\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, -1083706713, 7231082740212344405L, -95149L, true, true, (char) 26440, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6a91917acb0efL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 8, 1, "\uda4c\udcb1\ud93b\udc23\ud8df\udd85", "\u5400\u937c\u9781\u98f9\u786b\uc086\u1a01\ud3ea\u3f1d\u6341\u85f2", "\udaa4\udd46\ud946\udd3b\uda7f\uddfb\ud87f\ude91\ud872\udef5\uda02\udc99\ud884\udd5e\uda19\udf3d",
        54, 80249, 2137023934, 5752869420861295861L, 28881L, true, false, (char) 9305, (char) 59838,
        Double.longBitsToDouble(0x3fd77b61c4278152L), Double.longBitsToDouble(0x3fcc16a36acea4fcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udb1f\udc3a\ud806\uddd2\udafb\udd79]] |a1=[Ljava.lang.String;:[[\udb1f\udc3a\ud806\uddd2\udafb\udd79]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \udb1f\udc3a\ud806\uddd2\udafb\udd79]] |a1=[Ljava.lang.String;:[[\udb1f\udc3a\ud806\uddd2\udafb\udd79]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\ucb03\u5738\u786b", "\ud9d5\udd88\uda05\uddb2\ud943\udcd8\u2c26\000\ud9de\ude2e\udaa4\udd46\udb51\udca7\ud9a2\udcad\177\u8c17\uda28\ude0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udc81",
        32, 31021, 677900967, 7231082740212344405L, -42697L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fe6a91917acb0efL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 1, 1, "\udabc\udf03\ud806\uddd2\udafb\udd79\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9bd\uded8\udb13\uddb6\udbe0\udfc0\ud951\udc70\udbb1\udd68\uda68\udceb\ud9d5\udd88\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\uda65\udfae\ud946\udd3b\ud9e5\udc4f\ud901\udc57\u8cfb\uda28\ude0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f", "\u9a2b\uc660\u4387\u6236\u9044\u2655\u2efd\u4a0e\u1cc4\u890c\u1120\u4c56\u10a1\ua8f9\u03fb\uba18\u7530\u91ae\u12fb\uc31d\ua372\ubdbd\u06fe\u41e7\u4080\uc0e1\u48b5\ub349\ud233\u5ce1\u9827", "\udb45\uddc2\ud908\ude83\ud8ff\ude37\ud804\udd73\uda07\udf60\ud84a\udffd\uda9a\udc64\uda51\udd4d\ud907\ude6a\ud94b\udee0\udaa1\udcde\udb27\ude43\ud904\udc2d\ud886\udda2\udb20\udeb3\ud9be\udd0a\ud98f\udd46\ud934\uddf3\ud8b3\udd0f\udb7e\udde5\udb87\udd50\ud9b4\udd45",
        6, 58923, 1635297150, -6768383607397967902L, 48348L, true, false, (char) 31955, (char) 5972,
        Double.longBitsToDouble(0x3fddd814df2359deL), Double.longBitsToDouble(0x3feef74a9c2e20d5L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 1, "\ud9d0\udf32\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\u8df9\u608c\u48b1", "\ud9d5\udd88\udaa9\udde4\ud943\udcd8\ud96a\ude34\ud89c\udd7b\uda1c\udeb4\udae7\udfc9\uda9f\udf6e\udb2b\udeb8\ud901\udc28\ud86f\udd00\uda28\ude0d\ud9e6\uddf4\ud973\udf47\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, 677900967, -760953921286047142L, -42697L, true, true, (char) 42182, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6a91917acb0efL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udb1f\udc3a\ud806\uddd2\udafb\udd79]] |a1=[Ljava.lang.String;:[[\udb1f\udc3a\ud806\uddd2\udafb\udd79]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 7, 8, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79", "\u7409\u11dc\ub92f\u5738\000", "",
        55, 91732, -1453071885, 7405092228859604224L, -14593L, false, false, (char) 25, (char) 0,
        Double.longBitsToDouble(0x3fcc816700c5e000L), Double.longBitsToDouble(0x3feeb80003824cd5L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 8, 1, "\udb1f\udc3a\ud806\uddd2\udafb\udd79\ud988\udfc7\ud8d5\udf43\ud9ee\udf48\ud9bd\uded8\udb13\uddb2\ud8a4\udfc2\udbd1\udf90\udba0\udd58\uda78\uddeb\ud9d5\udd88\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa1\udd46\ud946\udd3b\udb22\udcad\ud901\udc28\ud935\udee5\ud9a7\ude68\ud87a\udc5e\uda19\udf3d\ud852\ude93\udb3e\udfe0\uda9f\udd3f", "\u9689\uc660\u9bc6\u4f40\u631f\u2655\u215b\u9af5\u07ef\u890c\u1120\ucfd8\u72da\u746a\u9436\ub168\u8bfd\ub7b0\ub777\ub47c\u25a9\u14cc\ua0b5\u850f\u2e98\u6de7\u5d4c\u26e8\u2654\u7047\u5518", "\ud971\uddbb\ud901\udd4c",
        10, 64325, 777134374, 6330350738138571737L, 16265L, true, false, (char) 19087, (char) 38013,
        Double.longBitsToDouble(0x3fe44ebe03d298bdL), Double.longBitsToDouble(0x3fe71c4828fbcb30L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb1e\udf65\ud806\uddd2\000", "", "",
        43, 28695, 0, -8984518196004685722L, -100000L, false, false, (char) 0, (char) 5078,
        Double.longBitsToDouble(0x3fc0dec5d67c9414L), Double.longBitsToDouble(0x3fc247c0a3353c64L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 4, 1, "\udb5b\udf36\ud806\uddd2\udafb\udd79", "\u7409\u4d3f\ucb03\u5738\u786b", "\ud0f8\uda05\uddb2\ud943\udcd8\ud96a\ude34\ud8f4\udef9\ud9f3\uddf1\udaa4\udd46\ud946\udd3b\udb0a\udd60\ud885\uddf1\u8cae\uda28\ude0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaf5\udefb\ud997\uddd7",
        59, 31021, 677900967, 7231082740212344405L, -42697L, true, true, (char) 556, (char) 26415,
        Double.longBitsToDouble(0x3fe59d4ccf6895beL), Double.longBitsToDouble(0x3fdad23221a75574L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 1, "\udb1f\udc3a\u5099\000", "\u7409", "\000\000\000",
        56, 34516, -1051459584, -6240896223087940570L, 32986L, true, true, (char) 692, (char) 53989,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3f49b20f5e5f7400L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\u65c0]] |a1=[Ljava.lang.String;:[[\u65c0]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 3, "\u65c0", "\u616d\u2a58\u7409\ua195\u65ad\u3117", "\uda68\udceb",
        57, 91732, -1453071885, 7405092228859604438L, -14593L, false, false, (char) 53989, (char) 59220,
        Double.longBitsToDouble(0x3fde40b38062f09cL), Double.longBitsToDouble(0x3fcaf2e3ae093354L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 7, "\u65c0", "\u7b6d\u2a58\u7409\ua195\u65ad\u3117", "\ud94c\udcbc\ud96c\uddb1\uda05\udda1\ud943\udcd8\ud96a\ude34\udb83\udc90\uda1c\udeb4\udaa4\udd46",
        31, -811, 188265295, 8669092710113950807L, 64738L, true, false, (char) 55074, (char) 39516,
        Double.longBitsToDouble(0x3fc32fec13d53f58L), Double.longBitsToDouble(0x3fed38ed2bbcae3cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \u65c0\ud806\uddf7\udafb\udd79\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9d2\udf2e\udb6a\udd83\ud925\uddfe\ud8dc\udcf6\udbb1\udcf4\udac0\udf71]] |a1=[Ljava.lang.String;:[[\u65c0\ud806\uddf7\udafb\udd79\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9d2\udf2e\udb6a\udd83\ud925\uddfe\ud8dc\udcf6\udbb1\udcf4\udac0\udf71]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 1, "\u65c0\ud806\uddf7\udafb\udd79\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9d2\udf2e\udb6a\udd83\ud925\uddfe\ud8dc\udcf6\udbb1\udcf4\udac0\udf71", "\u62fa\u85f2\u2a33\u5a9f\u7827", "\ud900\udff8\u8cfb\uda92\ude02\ud87a\udc5e\uda19\udf3d\ud922\udc9b\udb36\udd07\uda9f\udd3f\ud9be\udd4d\ud8c3\udeb4\ud9d9\uddd5\ud9d9\udc15\udbe6\ude13\ud9d1\udc17\ud902\udf7c",
        28, 80254, -1455456032, -7656415465280716952L, 12881L, true, true, (char) 22398, (char) 59347,
        Double.longBitsToDouble(0x3f949faba2c64e40L), Double.longBitsToDouble(0x3fe5fa579c255436L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, ]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 0, 0, "", "\u4dc3\u7b6d\u2a58\u00f7\000\u2cd8\u3f04\u786b", "\000",
        41, 80907, 11264, -707437875317835642L, 15858L, true, true, (char) 13397, (char) 55523,
        Double.longBitsToDouble(0x3f3e138000000000L), Double.longBitsToDouble(0x3fe8000000000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 8, 5, "\udbe6\udf0e\ud806\uddf7\udafb\udd79\udb88\ude11\ud8ea\ude81\ud9a1\udfaa\ud9d2\udf2e\uda53\udf77\ud842\udd69\uda9b\uddf5\ud8e7\udd1d\uda24\uddae\ud902\ude8d\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda15\udf20\udb6b\udccd\ud96a\udcc3\ud85e\ude1b\ud900\udff8\u8cfb\uda92\ude02\ud87a\udc5e\uda19\udf3d\udab7\ude26\ud9d6\udd92\udac5\udd88", "\u51bf\u50ca\u587b\u9edb\u366f\u2635\u255a\u4a0e\u8839\u890c\u1120\uc71a\u5c74\u9b38\u0a45\u2e7d\u8cb6\u5ebd\u4c91\u3d0f\u0228\uac9d\u29f3\u8af2\uc5b1\uca9d\u8413\u5204\u8cf8\u6d19\u5d39", "\uda71\udc3f\ua2f6\uda40\udd65\ud9cb\udcc7\ud9a6\udf18\ud839\udcdb\udb23\udfd2\uda41\udd3a\ud939\udf74\uda75\udd01\udae7\uddc2\uda15\ude9a\ud97a\udf7d\ud8db\udf0e\ud99f\udcad\ud820\udff5\uda10\udc48\udbec\udeaf\udb6e\uddb0\ud8c5\udeda\ud979\udd8d\ud802\udcd1\udaf3\udca5\udbf0\udda1\ud8e8\udcd2\ud84a\udd86\ud891\udeae\ud975\udd57\udaf4\udf26\uda4a\udec5\uda98\ude85\uda2b\udc02\udbc6\uddfb\udbc3\ude14\ud909\udc64",
        31, 4177, -1418536877, 2469228829806455582L, 62027L, true, false, (char) 59093, (char) 62041,
        Double.longBitsToDouble(0x3fea5625bee92f20L), Double.longBitsToDouble(0x3fcd3bb94ba6ede8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \u65c0\ud806\uddf7\udafb\udd79\ud985\ude44\udb94\udd2f\ud9ee\udf48\ud9d2\udf2e\udb6a\udd83\ud925\uddfe\udbab\udf5e\ud891\ude64\uda68\udca1\ud9d5\udd88\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb83\udedd\ud900\udff8\u8cfb\uda92\ude02\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f\ud9be\udd4d\ud8c3\udeb4\ud9d9\uddd5\ud9d9\udc15\udbe6\ude13\ud9d1\udc17\ud902\udf7c\uda8c\ude5e\ud869\uddb4\ud8a6\udfc3\udbf5\udc6f]] |a1=[Ljava.lang.String;:[[\u65c0\ud806\uddf7\udafb\udd79\ud985\ude44\udb94\udd2f\ud9ee\udf48\ud9d2\udf2e\udb6a\udd83\ud925\uddfe\udbab\udf5e\ud891\ude64\uda68\udca1\ud9d5\udd88\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb83\udedd\ud900\udff8\u8cfb\uda92\ude02\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f\ud9be\udd4d\ud8c3\udeb4\ud9d9\uddd5\ud9d9\udc15\udbe6\ude13\ud9d1\udc17\ud902\udf7c\uda8c\ude5e\ud869\uddb4\ud8a6\udfc3\udbf5\udc6f]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 1, "\u65c0\ud806\uddf7\udafb\udd79\ud985\ude44\udb94\udd2f\ud9ee\udf48\ud9d2\udf2e\udb6a\udd83\ud925\uddfe\udbab\udf5e\ud891\ude64\uda68\udca1\ud9d5\udd88\uda05\uddb2\ud943\udcd8\ud96a\ude34\udb83\udd41\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb83\udedd\ud900\udff8\u8cfb\uda92\ude02\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f\ud9be\udd4d\ud8c3\udeb4\ud9d9\uddd5\ud9d9\udc15\udbe6\ude13\ud9d1\udc17\ud902\udf7c\uda8c\ude5e\ud869\uddb4\ud8a6\udfc3\udbf5\udc6f", "\u00af\u98c8\u0fa2\u57ea\u6bdb\ud752\u06b8\u924b\ua833\u7109\u57d7\u0189\u3d00\u013f\u3c0b", "\ud8ea\udd16\uda31\udc33\uda16\udfe0\ud962\udcb4\ud87d\udc60\uda3a\udf56\udbae\udde1\udaca\udfbc\udaae\ude03\udaf8\udc2b\udaba\udd4c\udaac\udc1c\ud9b2\udcb1\u4b40\udad0\udce1\ud9e6\udf08\u68b5\ud817\udcf7\u76ed\ud866\udd4d\ud91d\ude0a\ud8f4\udcd7\udbe5\udd7e\udbd3\ude29\ud8da\uddf7\ud821\udd0a\ud820\udda2\ud836\ude02\uda1f\udcdb\ud8c6\ude28\udbfc\udfe3\uda9c\ude94\ud892\uddc5\ud9ae\ude23\uda8a\uddd7\uda9a\udf76",
        8, 90688, 1642712284, 1266017294501036701L, -17353L, true, false, (char) 50171, (char) 20802,
        Double.longBitsToDouble(0x3fef4622bc93f571L), Double.longBitsToDouble(0x3fc558be2e4b5e88L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 3, 1, "", "", "",
        15, 66055, -857992740, 62487411585792L, -89430L, false, false, (char) 30228, (char) 53676,
        Double.longBitsToDouble(0x3fe1ee0aa426a963L), Double.longBitsToDouble(0x3fdd666c410dec5cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 8, 1, "\ud809\udc2f", "", "",
        -5, 72176, 1389836501, -290354637277121985L, -65286L, false, false, (char) 53676, (char) 41799,
        Double.longBitsToDouble(0x3fa3548002d63c40L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 8, 6, "\udb1f\udc3a\ud8b2\udfe7\udafb\udd79\ud988\udfc7\ud8d5\udf43\ud9ee\udf48\ud9bd\uded8\udb45\udf93\ud933\udc88\ud972\udcd3\udba0\udd58\uda78\uddeb\ud9d5\udd88\uda05\uddb2\udba6\udd29\ud8aa\udf80\ud83d\udf09\uda1c\udeb4\udaa1\udd46\u96cd\ud8e7\uddb0\ud907\ude8e\ud89a\udcd7\ud9a7\ude68\udad4\udf0b\uda19\udf4f\ud9a4\uddd7\uda1a\udd2c\ud812\udd32", "\u3eb9\uc660\u9bc6\u4f40\u631f\uba32\u215b\u17b4\u07ef\u890c\uab41", "\uda26\udc41\udab2\udfc2\ud977\udd24\ud848\udcb4\ud9af\ude3f\ud892\udd95",
        44, 46696, -490516621, -5818096118205523516L, -43961L, false, false, (char) 29340, (char) 18738,
        Double.longBitsToDouble(0x3fc62da6bd97ad9cL), Double.longBitsToDouble(0x3fd164f0ed90815cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud926\udf6b\udb41\udfce\udafb\udd53\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9bd\uded8\udb13\uddb6\ud8a4\udfc2\ud8dc\udcf6\udbb1\udcf4\uda68\udceb]] |a1=[Ljava.lang.String;:[[\ud926\udf6b\udb41\udfce\udafb\udd53\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9bd\uded8\udb13\uddb6\ud8a4\udfc2\ud8dc\udcf6\udbb1\udcf4\uda68\udceb]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 8, 1, "\ud926\udf6b\udb41\udfce\udafb\udd53\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9bd\uded8\udb13\uddb6\ud8a4\udfc2\ud8dc\udcf6\udbb1\udcf4\uda68\udceb", "\u634c", "\uda1c\udeb4\udaa4\udd46\ud946\udd3b\udb22\udcad\ud901\udc28\u8cfb\uda28\ude0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f",
        32, 31021, 677900967, 7231082740212344405L, -42697L, true, true, (char) 26440, (char) 13819,
        Double.longBitsToDouble(0x3fe59d49ff6895beL), Double.longBitsToDouble(0x3fe6a91917acb0efL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 1, "\udb1e\udfd4\ud952\udc17\udafb\udd79\ud985\ude44\ud8be\udecb\ud9ee\udf48\ud9bd\uded8\udb13\uddb6\ud8a4\udfc2\ud8dc\udcf6\udbb1\udcf4\ud90d\udf1e\ud8ea\uded8\ud98d\ude39\ud943\udcd3\ud96a\ude34\udb83\udd41\uda1c\udeb4\ud96f\udebc\ud91e\udf4c\udb22\udcad\ud901\udc28\ud842\udeeb\udbed\ude8a\ud87a\udc5e\uda19\udf3d\ud852\ude93\udaa7\udf74\uda9f\udd3f", "\u9a8a\u2256\ube5a\u4f40\uad86\u3583\u3ca1\u47b5\u1cd5\u890c\u1120\uce3f\uc78f\u7939\u1e8c\ud2f0\u11c8\u9445\u9e5d\u9272\ub10c\ua4ff\u081e\u5a61\u5f89\u8482\ud241\u57a7\u4af7\u4325\uca4d", "\udb8f\udd25\udbf0\ude46\ud8a5\ude5c\udbda\udd3e\uda9b\ude54\udbed\udfa7\udb65\udfcd\ud891\ude38\ud935\ude5d\uda33\udcda\u96d2\udbd7\udd25\ud9cf\udfd6\ud925\udddd\uda4e\udecf\uda0f\udedd\udbc8\udcbf\ud8a4\uddd4\udbe3\udfbe\udb85\udc83\uda9e\udd7d\ud82e\udcaa\udb06\udec0\udb93\ude94\ud8a4\udee7\uda48\udee8\uda46\udead\udb9c\udfc4\udb35\uddf4\udb10\udde2\ud833\udc6b\udbde\ude00\uda73\udf44\udb9d\udc89\udac7\ude39\ud8c6\udcb4\udb32\udd5f\uda41\udfb1\udb50\udc98\ud824\udea7\ud8ed\udef4\uda40\udfc3\uda4b\udc9c\ud849\udd3c\ud8b4\uddb9\ud902\udfc7\ud954\udd73\uda7d\udcc8\udb2a\udf38\ud917\udc5c\udb22\ude57\ud9c9\ude16\ud864\udd0d\ud808\udf68\ud90a\udcc8\udb5d\udff8\uda4f\udc1f\ud9bc\udd82\udbfd\udf08\udae8\udef5\udabc\udd1e\uda00\udea8\uda63\ude15\ud984\udc67\u9758\udb87\udc9f\ud930\udcb3\uda25\udee7\ud97d\udee3\ud869\ude27\ud939\udc29\ud945\ude72\ud90e\udd85\ud9ea\udf33\ud826\udd2d",
        28, 43625, -783352473, 6216676098595447874L, -54429L, true, true, (char) 22730, (char) 41544,
        Double.longBitsToDouble(0x3febf0577055966fL), Double.longBitsToDouble(0x3fdb65fbd3e95df2L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 1, "\udb12\udcf4\ud806\uddd2\udafb\udd79\ud835\udc48\ud8ec\udd41\ud9ee\ude82\ud9bd\uded8\ud975\udfe7\ud90e\udcbc\ud8be\uddc7\udbb1\udcf4\udbf6\udef1\uccd4\udbd1\udfe3\ud924\udc21\ud87c\udd3b\uda93\udfd0\udba5\uddf9\ud9c2\udcef\ud946\udd3b\udb22\udcad\udafd\udf5e\udae4\udfda\uda0d\udc0d\ud87a\udc5e\uda19\udf3d\ud852\ude93\ud8b1\udd19\udaf6\udc40", "\uab34\uc660\uaa6b\u4588\u9044\u2655\u215b\u4a0e\u1cc4\u890c\u9aab\u8d0d\u416b\u5b8c\u2d20\uc091\uc513\u5bcd\ud0ca\u0911\u1269\ubd05\u78eb\u3294\ucfd7\u716c\u1b67\uc659\u23c6\ud181\uba92", "\uda73\udf52\ud9d5\ude10\ud8db\udd41\u77ca\uda2d\ude8a\udb68\udc73\uda82\udee1\ud9ba\udc96\u4764\uda30\udde7\uda9d\uded2\uda45\udfdf\ud96a\udc00\ud989\uddc5\udb51\udfc2\ud9ab\uddfa\ud8e4\udf34\ud990\udc15\ud8ee\udeda\ud84b\udd83\udba3\udd63\ue8dc\ud908\udf4d\uda3c\udf83\uda03\udf36\u46d8\udb4d\udee7\udb07\udf99\ud952\ude43\udb5a\ude27\ud820\uddca\ud9b4\ude9c\ud9cc\ude5b\udb16\udc31\udb6e\udc58\uda28\udf5b\ud9c0\udef6\ud99d\udd9e\udb56\udd5a\ucaed\ud879\udc7c\udb40\udfe4\udb0b\udf33\udb60\udd4f\udb4d\udc3f\ud93b\udd04\uda69\udf6f\udbde\udedd\ud91e\udf3c\udb89\udd7d\ud8fd\udc18\ud9b9\ude2d\ud89a\ude39\udb63\udd47\uda98\udebf\udb37\udf08\udac0\udc79\ud81e\uded9\uda99\udcbe\udb4e\udcb3\uc204\uda41\udc97\uda3f\udfea\ud9b0\ude36\udba8\udc9f\ud82d\udf68\ud9f4\udd97\uda6a\udea8\ud82e\udde1\ud860\ude0e\ud8aa\udd77\ud948\udfa8\udaa2\udea9\ud923\udef0\ud99d\udf34\u7134\udbde\uddaf\ud95e\udcac\ud892\udd29\uda15\udd2d\ud958\udfc0\udb45\ude64\ud978\udc18\udbbe\udccf\uda80\udfe6\ud93d\udcac\ud9ce\udd19\ud9ef\udc8a\ud86a\udded\udb01\udc78\ud88f\udeb4\uda22\udec1\uda25\udc8e\u2fc8\ud9a0\udf84\uda89\udc4a\ud8b3\udff4\ud880\udf5f\ud910\uddf8\udadc\udd67\uda76\udc03\ud89c\udd24\udbb2\uddaa\uda87\udc42\ud9bf\udd0d\uda1c\udfdf\uda6b\uddca\ud903\uded0\uda10\udc8d\ud87f\udc66\uda21\udd95\ud9c3\ude74\udaf0\udde2\udbde\udf50\udaf0\udcc3\ud8a7\udf39\udbe5\uddfc",
        21, 90592, 354204746, -7978512279030687349L, -6465L, true, true, (char) 40214, (char) 50792,
        Double.longBitsToDouble(0x3fe9bc4866060fffL), Double.longBitsToDouble(0x3fcf96032ddeac9cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
