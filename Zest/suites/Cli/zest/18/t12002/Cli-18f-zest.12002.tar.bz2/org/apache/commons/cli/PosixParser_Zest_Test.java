package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 1, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94", "\u1810\u076c\u0878\ubab3\ube21\u7d3a", "\uda7c\udee7\uda5a\udcc2",
        50, 56255, 1623805738, -5367864562505023968L, 13726L, true, false, (char) 28397, (char) 10772,
        Double.longBitsToDouble(0x3fd8973b2907720aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 1, "\udaab\udfbb\ud96a\udf62\ud91f\ude37\ud8c3\udde0\ud86a\udc94", "\u1810\u076c\u0878\ubab3\ube21\u7d3a", "\uda7c\udee7\uda5a\udcc2",
        50, 56255, 1623805738, -5367864562505023968L, 13726L, true, false, (char) 28397, (char) 10772,
        Double.longBitsToDouble(0x3fd8973b2907720aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 5, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud830\udcb6", "\u0d97\u8e65\u0878", "\udbc3\udd49\ud9fe\udfa6\udb82\ude0b\u1357",
        52, 40465, -2122255745, 6974192538517341087L, 4767L, true, true, (char) 32136, (char) 19273,
        Double.longBitsToDouble(0x3fae9bb4e4a465c0L), Double.longBitsToDouble(0x3fe42678d97610c0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 7, "\ud9e6\udcd7\ud9b0\udc8b\ud916\udeed\uda15\udd89\ud86a\udc94\ud994\udf70\ud8e0\udd51\ud9af\ude4d\uda93\udf5e\ud9b6\udf9c\ud864\udfb8\uda15\udcf7\udbc3\udd49\udb97\uddf2\ud94d\udead\uda7c\udee7\uda5a\udcc2\uae50\uda52\udf0a\uda81\udcff\udace\udc05\ud9b6\ude67\udb77\udf19\udbe1\udf7a\udbd7\udc27\udb6c\udfd5\ud8d4\ude9e\u982e\uda49\udcbd", "\u1e07\u112b\u2983\u5919\u84b4\u8ce2\u4398\u4717\u7270\u7715\u133c\u4713\ua4fb\u0f0b\ubd97\u91ee\ua28a\ud0c8\u4f27", "\uda1d\udee8\ud95d\udcc5\ud9d6\udee8\uda07\udda2\ud80f\udc11\udb1e\udea1\uda63\udc3a\udbd4\udd71\uda29\udc2c\ud805\udcad\ud9ae\udc1f\uda9f\udeb0\uda03\udd60\udb09\udcf7\ud9cd\uddea\udbaa\ude4a\ud9cc\udf83\ubbd8\ud911\udfcc\udb99\ude19\uda70\udd46\ud9e3\ude68\udb88\udf9d\ud8ac\udf08\uda02\udf03\ud864\udca0",
        36, 86821, -178326439, 7781241570996563296L, 4787L, true, false, (char) 35680, (char) 20416,
        Double.longBitsToDouble(0x3fe80e5db3078fafL), Double.longBitsToDouble(0x3fe94b01092fe2c8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 1, "\ud868\udc38\ud9ce\udc97\ud91f\ude0b\ud8c3\udde0\ud86a\udc94", "\u1810\u076c\u0878\ubab3\ube21\u7d3a", "\uda7c\udee7\uda5a\udcc2",
        0, 38008, 1623805911, -5367864562505023968L, 13726L, true, false, (char) 28397, (char) 10772,
        Double.longBitsToDouble(0x3fd8973b2907720aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 1, "\ud9d4\udc53\ud9b6\udd8f\ud91f\ude0b\ud8c3\udde0", "\u8b36\u1810", "\ud868\udc89\ud996\udc21\ud9f5\udf0b\ud8fe\udca0\ud94d\udf2a\uda7c\udee7\uda5a\udcc2\uae50\uda52\udf0a\ud87f\udcde\ud86b\udc3b",
        18, 87123, 1183204290, 4102639402496439806L, 27369L, true, false, (char) 19273, (char) 30630,
        Double.longBitsToDouble(0x3fe0fefc8a965cb6L), Double.longBitsToDouble(0x3fcf5bae20320520L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 8, 1, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94", "\u1810\u076c\u0878\ubab3\ube21\u7d3a", "\uda7c\udee7\uda5a\udcc2",
        50, 56255, 1623805738, -5367864562505023968L, 13726L, true, false, (char) 28397, (char) 10772,
        Double.longBitsToDouble(0x3fd8973b2907720aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 1, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94\ud994\udf70\ud82c\udfff\ud9af\ude4d\uda93\udf5e\ud9b6\udf9c\ud864\udfb8\udab9\udef3\udbc3\udd49\ud9fe\udfa6\ud94d\udead\uda7c\udee7\uda5a\udcc2\uae50\uda52\udf0a\ud87f\udcde\ud859\udf3b", "\u0758\ud447\u2bdb\uc7e0\u9d69\u06b6\u2e5b\u9728", "\ud95a\udfc9\ud9bf\udd06\uda10\ude23\ud983\udca1\udbef\udec9\ud975\udd6c\ud84d\ude05\udbfc\udd84",
        43, 29009, -1920325668, -4324776613101110046L, -76557L, false, false, (char) 6704, (char) 43887,
        Double.longBitsToDouble(0x3fe774961aff913fL), Double.longBitsToDouble(0x3fed25d0b1674e59L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \udaab\udfbb\ud84d\udf6f\ud91f\ude36\ud8c3\udde0\uda89\ude0b]] |a1=[Ljava.lang.String;:[[\udaab\udfbb\ud84d\udf6f\ud91f\ude36\ud8c3\udde0\uda89\ude0b]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 0, 0, "\udaab\udfbb\ud84d\udf6f\ud91f\ude36\ud8c3\udde0\uda89\ude0b", "\uab4c\u069d\u0878\ubab3\ube21\u7d3a\u6a8e\uc6cb\u38de\u7fba\u0451\ub3d7\u8604\u7354\u4536\ua1dc\u7d19\u5192\u3613\uc7e0\u9d69\u06b6", "\udb1b\udebb\ud8c7\udf81\ud960\udea7\uda15\udc68\ud9a8\udc34\ud86d\udebf\uda7d\udf9f\udac0\udfca\uda65\udfd7\ud873\udf22\uda6d\udfbb",
        10, 64287, 1004601890, -7598771902419010064L, 59945L, true, false, (char) 19485, (char) 17915,
        Double.longBitsToDouble(0x3fe3000d302de78aL), Double.longBitsToDouble(0x3fe7ddb1be512540L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 1, "\udaab\udfbb\udbee\udc68\udb08\udfa0\ud8c3\uddfa\udaaa\udfd3", "\u339f\u9d35\u0878", "\udada\ude13\ud94c\udcfa\ud8ec\udde4\udb17\ude5c",
        26, 40465, 1535177343, 6974192537946915743L, -61554L, false, false, (char) 55890, (char) 25282,
        Double.longBitsToDouble(0x3fda82e55312e74aL), Double.longBitsToDouble(0x3fc07720b2bcfa68L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 8, 4, 1, "\udae4\udffd\uda7f\uded1\ud982\uddaa\ud8c3\uddc4\ud86a\udc94\ud994\udf70", "\u0ab4\u8478", "\udbc3\uddc6\uda0f\udcf9\ud94d\udead\ud89c\udff7\udb1e\udd2b",
        3, 56255, 1623805738, -5367864562505023968L, 13726L, true, false, (char) 28397, (char) 36627,
        Double.longBitsToDouble(0x3fd8967a49077a0aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94]] |a1=[Ljava.lang.String;:[[\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 2, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94", "\u40b1\u5848\uc45a\ucb0d\ube21\u7d3a", "\uda7c\udee7\uda5a\udcc2",
        50, 64687, 1506371831, 3354481981445045827L, 17314L, true, false, (char) 8887, (char) 17096,
        Double.longBitsToDouble(0x3fd8973b25b7720aL), Double.longBitsToDouble(0x3fc5e7da1cf4dda4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 1, "\udb2d\udcdf\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94", "\u1810\u076c\uc2d7\u01d7\uc45e\ub731", "\uda7c\udee7\uda5a\udcc2",
        9, 55982, 1623805738, -5367864562505023968L, 13726L, true, false, (char) 28397, (char) 10772,
        Double.longBitsToDouble(0x3fd8973b2907720aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 6, 0, "\udaab\udfbb", "\u89f0", "\ud82c\udfff\ud9af\ude4d",
        5, 47483, 1295720235, -8380653735121978610L, -769L, false, false, (char) 45781, (char) 9611,
        Double.longBitsToDouble(0x3fc9a8d0d7f8e3bcL), Double.longBitsToDouble(0x3fe60e1a948973b2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\udaab\udfbb\udbee\udc68\ud92e\udc0b\udae6\udf53\ud86a\udc94]] |a1=[Ljava.lang.String;:[[\udaab\udfbb\udbee\udc68\ud92e\udc0b\udae6\udf53\ud86a\udc94]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 7, 1, "\udaab\udfbb\udbee\udc68\ud92e\udc0b\udae6\udf53\ud86a\udc94", "\u2abc\ub2b5\u28ed\u3ec6\ubdc1\u7d3a", "\uda7c\ude65\ud833\udf8e",
        3, 90308, 1623798165, -5367864562505023968L, 13726L, false, true, (char) 28218, (char) 10772,
        Double.longBitsToDouble(0x3fd8973b24348998L), Double.longBitsToDouble(0x3fce1553f5788128L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 6, 0, "\udaab\udfdb\udbee\udc68\ud959\udde9\ud8c3\udd80\ud86a\udc94", "\u1810\u076c\u0878\ubab3\ube21\u7d3a", "\uda7c\udee7\uda5a\udcc2",
        50, 56255, 1623805738, -5367864562505023968L, 13726L, true, false, (char) 28397, (char) 54561,
        Double.longBitsToDouble(0x3fd8973b2907720aL), Double.longBitsToDouble(0x3fc5e6cba0f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 1, "\udadf\udc54\ud91a\udff7\udbab\ude22\udb03\udcb8\ud8d8\udc2f", "\u1810\u75a0\uc08a\ubab3\ube21\u7d3a\u6ab9\u308a\u9e80\u7fba\u3fe8\u03e7\u7728\u13b0\u4536\u318b\ub154\ub476\u35b2\uc7e0\u9d69\u2228\u2e5b\u1145\u8c93", "\udb04\ude87\ud8ca\udcd7\ud981\udc80\uda6b\udf18\ud910\udcf4\udad5\udf03\udbd7\udfb8\ud8bd\udc53\uda34\udf2b",
        57, 83089, -1676626569, -87800195628054728L, 23991L, false, true, (char) 6955, (char) 28726,
        Double.longBitsToDouble(0x3fecb5787e651af7L), Double.longBitsToDouble(0x3fd2abf5a4c11c8aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 4, 3, 1, "\udaab\udfbb\udbee\udc68\uda8b\udde4\ud8c3\udde0\u00e9", "", "\ud8dd\udf8f",
        -5, -1000, 0, 0L, 96608L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e3e100000000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udaab\udfbb\uda83\udfb4\udb08\udde0\ud9c6\udffd\udab2\ude18", "\u1810\u076c\u0878\ubab3\ube21\u7d3a", "\ud8c3\ude8b\uda51\udc4c",
        50, 21110, 1623805857, -5367864562505023968L, 13726L, true, false, (char) 28397, (char) 35265,
        Double.longBitsToDouble(0x3fd897338907720aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94]] |a1=[Ljava.lang.String;:[[\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94]] |a1=[Ljava.lang.String;:[[\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94", "\u1810\u076c\u0878\ubab3\ube21\u7d3a", "\uda7c\udee7\uda5a\udcc2",
        50, 56255, 1623805738, -5367864562505023968L, 13726L, true, false, (char) 28397, (char) 10615,
        Double.longBitsToDouble(0x3fd8973b2907720aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udaab\udfbb\uda06\udc05\udbb6\ude24\udab1\udc24\udb3c\uddd2]] |a1=[Ljava.lang.String;:[[\udaab\udfbb\uda06\udc05\udbb6\ude24\udab1\udc24\udb3c\uddd2]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\udaab\udfbb\uda06\udc05\udbb6\ude24\udab1\udc24\udb3c\uddd2]] |a1=[Ljava.lang.String;:[[\udaab\udfbb\uda06\udc05\udbb6\ude24\udab1\udc24\udb3c\uddd2]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 5, "\udaab\udfbb\uda06\udc05\udbb6\ude24\udab1\udc24\udb3c\uddd2", "\u1810\u6416\u1879\ud0e9\ube47\u7d3a", "\uda7c\udee7\ud994\uddff",
        28, 56255, 1623805738, -5367864562505023968L, 82902L, false, true, (char) 9579, (char) 45769,
        Double.longBitsToDouble(0x3fd8973b2907720aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 4, 1, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94", "\ud662\u076c\u0878\ubae2\u56d2\u79ab", "\ud859\udc26\uda5a\udcc2",
        26, 56163, 1623805738, -5367735919644574176L, 13726L, true, true, (char) 28372, (char) 10792,
        Double.longBitsToDouble(0x3fe7439d9483b905L), Double.longBitsToDouble(0x3fed79f4d619c62aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 1, "\000", "", "\ud994\udf70",
        13, 27964, 715795675, 598296166400L, 97849L, true, false, (char) 31927, (char) 45862,
        Double.longBitsToDouble(0x3fec1a18ff118d6fL), Double.longBitsToDouble(0x3fe3ff99af2a8180L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 4, 3, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udd6d\ud97e\udc3d", "\u1810\u35e4\u0878\ubab3\ube21\u0fd5", "\uda7c\udee7\udb3b\udf32",
        32, 25157, 1039889045, -4057066814151063108L, 13726L, true, false, (char) 28397, (char) 10772,
        Double.longBitsToDouble(0x3fd8973b290772d6L), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 0, 0, "", "\ua6cb\u3d33\u5f93\u28d1\u3337\u7eeb\u4aa2", "\uda7d\udf1e",
        58, 19861, 1815291981, 4836662532388122499L, -100000L, false, true, (char) 33895, (char) 45985,
        Double.longBitsToDouble(0x3fd5bdd7a785c390L), Double.longBitsToDouble(0x3fc9a8d0d7f8e3bcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 1, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud86a\udc94\ud994\udf70\ud82c\udfff\ud9af\ude4d\uda93\udf5e\ud9b6\udf9c\ud864\udfb8\udab9\udef3\udbc3\udd49\ud9fe\udfa6\ud94d\udead\uda7c\udee7\uda5a\udcc2\uaec3\uda52\udf0a\ud87f\udcde\ud859\udf3b\ud8af\udc17\ud866\udf93\udbe1\udfe9\udbd7\udc27\uda26\ude6a\ud9bf\udd92\ud89f\udd5a", "\ua32e\u984c\ua08e\u7971\ubef6\u2ad2\u52ea\ub4da\u5473\u481b", "\udba6\udc02\ud9ae\ude54\ud90d\ude68\ud983\udff5\ud87c\udf33\udac5\udcb0\ud836\udff2\udb26\udddc\udbd0\udd13\udad3\udc62\ud917\udf6d\u3600\ud81d\udc5a\udbcc\udfb4\u2a4b\ud9b8\udd46\udbff\udd90\udafb\udd87\ud9e5\udfe4\udb88\uddd3\ud8fc\udd24\uda7c\udde2\ud980\udf41\ud815\udc62\uda6a\ude5c\ud937\ude91\ud8f2\udf9d\ud983\udea8\ubfcd\udb73\udc63\udb09\udf1d\ue784\udb32\udfb6\uda3b\udf31\udb79\uddb1\udaa1\ude93\udb1f\ude46\ud804\udf88\ud9e8\ude11\ud95f\uddc7\uda29\uded0\uda7b\udde1\ud9bf\udc9e\udb09\udefd",
        -4, 22611, -1381385712, -8987459637826320279L, -6079L, true, true, (char) 25853, (char) 56916,
        Double.longBitsToDouble(0x3fe1d94c64840470L), Double.longBitsToDouble(0x3fd8d514a06c3242L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 5, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\ud830\udcb6", "\u0d97\u8e65\u0878", "\udb72\udf20\ud9fe\udfa6\udb82\ude0b\u1357",
        52, 40465, -2122255745, 6974192538517341087L, -83555L, false, false, (char) 9632, (char) 39477,
        Double.longBitsToDouble(0x3fe046551f00a5edL), Double.longBitsToDouble(0x3fc4dfa6e90c3f14L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 3, 7, "\000", "\ub663", "\ud8e0\udd51\ud9af\ude4d",
        5, 47483, 1295720235, 8461399533560068903L, -75189L, true, true, (char) 37632, (char) 45434,
        Double.longBitsToDouble(0x3fc9a8d0d530e3bcL), Double.longBitsToDouble(0x3fe60f399914b9d2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 0, "\000", "", "",
        -5, 88656, -807964380, 3074319014743244800L, -100000L, true, true, (char) 49965, (char) 21687,
        Double.longBitsToDouble(0x3fe000000783001fL), Double.longBitsToDouble(0x3fe88c6b7e000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 3, 0, "\ud868\udc38\ud9ce\udc97\udac7\udec0\ud8c3\udde0\ud86a\udc94", "\u1810\u076c\u0878\ubab3\ube21\u7d3a", "\uda7c\udee7\uda5a\udcc2",
        0, 38008, 1623805911, -5367864562505023968L, 13726L, true, false, (char) 50157, (char) 10772,
        Double.longBitsToDouble(0x3fd8973b2907720aL), Double.longBitsToDouble(0x3fc5e7d340f4dda4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 3, 8, "\000", "\ub663", "\ud8e0\udd51\ud9af\ude4d",
        5, 47483, 1295720235, 8461399533560068903L, -75189L, true, true, (char) 37632, (char) 45434,
        Double.longBitsToDouble(0x3faf07b3adbbc850L), Double.longBitsToDouble(0x3fe60f3a0914b9d2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 1, "\udaab\udfbb\udbee\udc68\ud91f\ude0b\ud8c3\udde0\udb7f\udf58", "\u1810\u076c\u0878\ubab3\ube21\u7d3a\u6ab9\u308a", "\uda18\udc79\uda52\udf0a\ud87f\udcde\ud859\udf3b\ud8af\udc17\ud866\udf93\udbe1\udfe9\udbd7\udc27\uda26\ude6a\uda60\udc8d\ud86d\udeb8\ud9d4\udc33\udbcb\udff2\uda57\ude5f\ud857\ude3e",
        31, 68100, -694131175, 9069906605310837164L, -90417L, false, false, (char) 49136, (char) 273,
        Double.longBitsToDouble(0x3fad0b0c06f90880L), Double.longBitsToDouble(0x3fdde9d577530422L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 7, "\ud9e6\udcd7\ud80e\udf27\ud916\udfbe\uda15\udd89\uf4c8\ud994\udf78\ud8e0\udd51\ud9af\ude4d\uda93\udf5e\ud9b6\udf9c\ud864\udfb8\uda15\udcf7\udbc3\udd49\uda47\udc70\ud811\udc6f\uec66\uda21\udcd6\uae50\uda52\udf0a\uda81\udcff\udace\udc05\udb01\udcab\udb77\udf19\udb0e\udff1\ud9ab\udcfb\ud866\udd04\ud8d4\ude9e\u982e\uda52\udf62", "\u1e07\u6f98\u2983\u5919\u84b4\u8ce2\u4398\u4717\u7270\u7715\u133c\u4713\ua4fb\u0f0b\ubd97\u91ee\ua28a\ud0c8\u4f27\u6e61\uc1b2\u250c\u658d\u2014\uc946\u0526\u2c07\u99cc\ub3bc\u8dfe\u9ab4\ud648\u32d3\u1d9a\u1d1f\uc6ff\u0f0b\ubbbd\u8ff4\u7fc6\u1368\u9733\uc06c\u5195\u6f1c\ua2b9\u449a\u1f3c\u46b0\ud7bf\u65f7\u6728\u39a7\u59e1\u3e37\u0438", "\ud886\udd9e\uda19\udc62\ud8d8\udcb1\ud8c9\uddd2\ud8ac\udcb1\uda7a\ude18\udb81\udf3f\ud96e\udcd8\ud8cc\udc6f\uda2c\udc98\ud8f0\udecd\ud9ea\udfb0\udbe8\udfb6\udb9d\udf34\udbca\uddfe\udbd3\ude9d\udbaa\ude6c\ud9d2\uddf8\ud804\udde2\ud8e3\udf7f\udafb\udf7e\ud936\udfd8\udb2b\ude10\ud98d\udfe5\udb9f\udebb\ud98b\udc15\uda0b\udd4b\uda5f\udf55\ud96f\udec2\uda16\udea2\uda57\ude59\ud954\ude9d\ud851\udc85\ud8d7\udd15\uda34\udc50\ud88c\udecf\udb4b\udcc1\udbbe\udf0f\udbd2\udf39\ud87d\udc5e\ud894\udc58\u4633\ud99e\ude57\ud9b2\udf8d\udbe3\ude7a\uda17\ude62\u98c2\ud9fa\udc47\udaf6\udde2\ud829\ude00\ud898\udf3c\uda03\udc39\ud99d\uddbc",
        7, 50424, -1872467934, -7298023403630006737L, 87179L, true, true, (char) 177, (char) 56671,
        Double.longBitsToDouble(0x3fe33881dc4eace7L), Double.longBitsToDouble(0x3fe1d28efb6ba6f7L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
