package org.apache.commons.cli2.builder;
import org.junit.Test;
import static org.junit.Assert.*;
public class PatternBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u4686\u559a\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 35417, -1954767512, -3415875843159260992L, 29749L, false, true, (char) 12239, (char) 13698,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u4686\u559a\ub999\ua93b\u10f9\u9a4c\u03a8\ub04b\u1890\ub162\ubcd7\ube92\u7774\u51a3\ua04d\u942b\ua0b8\ubb0d\ud1dc", "\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud8df\udd87\ud859\udc3d\udbe7\udd75\uda64\ude7c\ud986\udc20\udb6e\udf12\ud88e\udd66\ud99f\udfe1\ud97a\udfab",
        50, 35417, -1954767512, -3415875843159260992L, 29749L, false, true, (char) 12239, (char) 57654,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe59688e01e98b4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u964b", "\udb6f\ude0d\ud88b\udff3\uda06\ude53\ud884\udd47\ud862\udfb0\udafa\udc83\ud896\udd36\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7\ud9da\udc36",
        44, 24726, -823964946, 6523111954301301294L, 6855L, true, true, (char) 61575, (char) 46982,
        Double.longBitsToDouble(0x3fde805110c28524L), Double.longBitsToDouble(0x3f9db0f28bab57a0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\ud813\udd3f\ud957\udd42\uda36\udca4", "\u5f8a\u4686\u559a\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af", "\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud946\udd53\udab6\udf0e\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1",
        27, 17625, 1522389021, 7487388710806444745L, -56601L, false, false, (char) 23128, (char) 41520,
        Double.longBitsToDouble(0x3fe82c5be0c0d098L), Double.longBitsToDouble(0x3fbeb2e9cf3e7678L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 0, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda7f\ude9e\000\000\000", "\u293b", "\udb6f\ude0d\u00c2\000\ud884\udcf0\ud862\udfb0\udafa\udc83\ud896\udd36\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7\u00ff",
        20, 24726, 0, 6485183463182545454L, 6855L, true, true, (char) 61575, (char) 46982,
        Double.longBitsToDouble(0x3fde805110c28524L), Double.longBitsToDouble(0x3f9db0f28bab57a0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude25\uda26\udccc\ud81e\udeb1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\udbf8\ude3a\ud82a\udd46\ud80f\ude3f\ud949\udd42", "\u293b\u1a94\ub506\ub999\u2b9f\u08b2\u2ec3\ucb0d\u533a\u18a6\ub0c5\u4198\u3e4d\u2c37\ub9af\u9f69\u942b\ua0b8\u5c88\u2ed3", "\ud864\udee3\udb81\udd6e",
        6, 88568, -2025209253, 6506083952840182877L, 87905L, false, true, (char) 30724, (char) 43149,
        Double.longBitsToDouble(0x3fe6068379143cbfL), Double.longBitsToDouble(0x3fcb87b21c162e4cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 5, 5, "\udb39\ude86\uda26\udccc\u32bd\udaa6\udece\ud88a\udfc7\uda12\udf32\udb26\udf7a\udae7\udde1\uda21\udf8e\ud833\uded7\ud949\udd42", "\u293b\u4686\ub3a6\ub999\u4b7c\uc2db\u833d\u03a8\u533a\ud0b1\u3cf5\u2c91\ube92\u2c37\ub9af\ucb79\u969c\u2ec5\ubb0d\ud1dc", "\uda1a\udd8f\udb43\udcc7\ud9fe\udc1a\ud923\uddd4\udb53\udf46\udbe7\udd75\uda64\udebe\ud986\udc20\udab0\udc91\ud81f\udddd\ud99f\udfe1",
        5, 89864, 80331417, -8395662536118608123L, -92896L, true, true, (char) 30852, (char) 12239,
        Double.longBitsToDouble(0x3fdc063c2f8eab68L), Double.longBitsToDouble(0x3fe6de0c4ee0e0d6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 3, "\udb2f\udf3f\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\udddd\u9e55\ud80f\ude3f\ud949\udd42", "\u48f4\u3481\u1b45\ub9e7\u2b9f\u65ab\u2ec3\u03a8\u533a\u18a6", "\ud833\ude28\ud9af\uddf7\ud9da\udc36\ud9b9\udc91\ud957\udf52",
        9, 42355, -230968786, 775464319240741223L, 6415L, true, false, (char) 9977, (char) 22865,
        Double.longBitsToDouble(0x3f9db0f28bab57a0L), Double.longBitsToDouble(0x3fe64b3f42ffd2e3L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\ud93f\ude06\ud858\udff0\uda10\uddc0\uda9a\ude39\u9e55\ud80f\ude3f\ud8d5\udc10", "\u40cc\u4686\u559a\ub999", "\udb5e\udd17\udb31\uddc5\ud8f0\udcde\ud896\udd36\udbec\udece\ud823\udff7\ud833\ude28\ud9af\uddf7\udb56\uded1\udb1d\udd6f\ud979\udcac\ud80a\udc09\ud854\udf54\ud90e\udd6c\ud841\udd11\ud913\udc9c\ud8fd\udeb0",
        27, 17296, 1358885348, -7858199870895644887L, -56601L, false, false, (char) 51148, (char) 41520,
        Double.longBitsToDouble(0x3fe82c5be0c0d098L), Double.longBitsToDouble(0x3fea9ad6052bce6fL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 0, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud95b\udea8\uda15\udfb0\ud8da\udfcc\u3664\ud91f\udf00\uda77\udddd\ud867\udd74\ud963\ude7f", "\u7c5c\u80dd", "\ud847\udff1",
        -5, 71591, 2139745534, 7851043890885859872L, -33813L, true, true, (char) 61071, (char) 20506,
        Double.longBitsToDouble(0x3fe0c4eeef44abd6L), Double.longBitsToDouble(0x3fe771bda022cee3L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb2d\udc7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u4686\u559a\ub999\u2b1f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\ud94f\udf94\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75\ud806\udd6d\ud949\udf1e\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 35417, -1954767512, -3415875843159260992L, 29749L, false, true, (char) 12239, (char) 13698,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb36\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42\ud973\udd0e\ud9f9\udf2d\ud8a8\uddc9\udb21\ude5a\ud893\udd63\ud973\udfaa\ud882\uddc1\uda06\ude53\ud884\udd47\ud862\udfb0\udafa\udc83\uda54\udcf6\udbec\udece\udb68\ude4d\ud833\ude28", "\u9f69\u942b\ua0b8\ubb0d\ud1dc\u3572\uc1cb\ub8a9", "\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab\ud8b4\udc9b\ud8c2\udee1\ud8ab\ude8a\udb41\udc39\ud8f5\uddaa\udbac\udd93",
        -2, 12614, 1673720246, 6175791610547795911L, -56524L, true, false, (char) 5281, (char) 24531,
        Double.longBitsToDouble(0x3fb2992cb6da2480L), Double.longBitsToDouble(0x3fd3228cc7728b82L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=null\012",
        Z.run(T, 2, 2, 3, 5, "\udba4\udf94\ud8e2\udebd\udbff\udf75\ud9ab\ude0f\ud9c4\ude59\udb59\udeeb\ud963\udde6\uda9a\ude39", "\u8d4b\u8fa9\u4898\u293b\u4686", "\ud822\udf98",
        -5, 26895, 1906240766, 7851043092021942816L, 31011L, false, true, (char) 61071, (char) 20506,
        Double.longBitsToDouble(0x3fe0c4eeea26e61dL), Double.longBitsToDouble(0x3fe771bda071c4e3L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 0, 4, 0, "\udb39\ude86\uda26\udccc\ud80f\udfa7\udb03\udd0d\ud9ea\udd94\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u29bd\u4686\u559a\ub999\u6905\u483a\u64c3\u7a57\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\u13bb\u9f69\u05c7", "\u6614\ud831\udec1\udaab\udce8\ud9fe\udf8a\udbe8\udd7e",
        10, 81934, -1326253961, 6538611055096990813L, -39726L, true, true, (char) 50999, (char) 9734,
        Double.longBitsToDouble(0x3fe60681b29937bfL), Double.longBitsToDouble(0x3feb40264f05cd40L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude86\uda26\udccc", "\u1243\ud151", "\u9e55\ud80f\ude3f\ud949\udd42\ud87d\udd12\udb59\udd18",
        55, 38154, -1067558651, -1820395933867532350L, -66696L, false, false, (char) 64, (char) 65279,
        Double.longBitsToDouble(0x3feb25644b80eb0fL), Double.longBitsToDouble(0x3fdffa21bc313bbaL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 2, 2, 1, "\udb39\ude86\uda26\udccc\udb29\udc33\ud899\ude06\uda15\udfb0\ud8f5\udfcc\udb4d\ude0e\udb50\udca3\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u2186\u559a\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\u4eda\u8207\u944f\ua0b8\ubb0d\u1b18", "\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 35417, -1954767512, -3415875843159260992L, 29749L, false, true, (char) 12239, (char) 58001,
        Double.longBitsToDouble(0x3fee397692dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 3, "", "\u90fc", "\ud8c8\udfa3",
        56, 20763, 59903, -833646544L, -34464L, false, false, (char) 39813, (char) 17373,
        Double.longBitsToDouble(0x3f480bc000000000L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb02\udc3f\udbd9\ude3a\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42\ud87d\udd12\ud893\udd55\ud8a8\ude82\udb21\ude5a\u5545\udb6f\ude0d\ud88b\udff3\uda06\ude53\ud884\udd47\ud862\udfb0\udafa\udc83\ud896\udd36\ud908\udc3b\udb68\uded7", "\ub9af\u263a\u9db9\u2084\ubb0d\ud1dc\u3572\uc1cb\ub8a9\u3d83\u0267\u60ce\u09f0\u1ba9", "\udac6\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab\ud8b4\udc9b\ud8c2\udee1\ud8ab\ude8a\udb41\udc39\ud9c7\udc9e\udbac\udd93\udb6a\udf9e\ucbc2\u22dd\u3ecd\udaa1\udc18\uda05\udd52\ud868\ude35\ud93f\udf6f\ud935\udd7f\ud96d\udf83\ud8b3\uddd2\ud99f\udc70\ud8bd\uddf1\udb50\udcf0\udb79\udfb0\udaba\uddf3\uda48\udd43\ud92d\udcf5\ud807\udcf2\udb5f\uddbc\ud90e\udc9b\ud939\udfbd\ud81a\udf35\udb73\ude0d\ud98c\udda2\uda4c\udf6b",
        14, 15236, -1083252045, -9011580095669300402L, 33107L, true, true, (char) 37442, (char) 35290,
        Double.longBitsToDouble(0x3feed157e4677a1dL), Double.longBitsToDouble(0x3fd00ef709305106L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u4686\u559a\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\uda0d\ude90\ud9de\udd53\ud9c5\udcf2\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 35417, -1954767512, -3415875843159260992L, 29749L, false, true, (char) 12239, (char) 13698,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 4, 3, "\ud9ec\udc19\ud8d9\ude72", "\u2e56\ud151\u1270", "\ud80f\ude3f\udb02\udf29\ud87d\udd12",
        57, 53007, -354975846, -4585129493030721653L, -62941L, true, false, (char) 37385, (char) 62389,
        Double.longBitsToDouble(0x3fe10367a50e7840L), Double.longBitsToDouble(0x3fee1b0d13f66c89L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 5, "\ud83b\udf63\uda3c\udfdb\udb57\ude06\ud8b6\udcb3\uda15\udfb0\ud8da\udfcc\u1f80\udb80\udecd", "\u4097\ucf88\ud28a\u293b\u750f\u28b8\u1d2c\u4a7d\u1dfb\u363f\u03a8\u2f68\u8c33\ub0c5", "\ud9af\uddf7\udb53\udef9",
        17, 58430, -1855547049, 513008225904908506L, 52965L, true, true, (char) 22321, (char) 46982,
        Double.longBitsToDouble(0x3fde805110c28524L), Double.longBitsToDouble(0x3fb9fdfca2ead5e8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\ud8e9\udc61\ud8ea\udda2\uda01\udf28\ud949\udd42", "\u293b\u504d\u559a\ud13e\u3fcc\u0392\u2ec3\u28a7\u533a\u18a6\ub0c5\ucd6f\ud4a7\u2bd2\u0132\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\u7cd9\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\uda3a\udd3c\u9ad9\ud865\uddfd\ud986\udc20\udab0\udc91\udb31\uded9\uda65\udf43\udaa3\udf17",
        16, 67631, -1954767402, -3415875840240025408L, 29749L, true, true, (char) 12239, (char) 13570,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 0, 0, 1, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\udaa8\udce1\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u4686\u559a\ub999\u9a72\u6ac7\u370f\u628f\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af\u9f69\u942b\ua0b8\u21b5\u9867", "\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\uda9f\udd6a\udbea\udfd4\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd7\ud99f\udfe1\ud97a\udfab",
        9, 35417, -1954767512, -3450778740271382336L, 29749L, false, true, (char) 38842, (char) 39814,
        Double.longBitsToDouble(0x3fef158ceadbc189L), Double.longBitsToDouble(0x3fd2ca21c57f78d2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 1, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42\ud87d\udd12\udb59\udd18\ud8e8\uddc9\ud9d1\udd52\u52c2\udb6f\ude0d\ud88b\udff3\ud84e\ude24\ud884\udd03\ud862\udfb0\udafa\udc83\ud896\udd36\udbec\udece\udb68\uded7\ud833\ude28\ud9d4\ude06\ud9da\udc36\ud9b9\udc91\ud975\udd6e\ud80a\udc09\ud9a0\udea9\ud8e6\ude1b\ud946\udd53\udab6\udf0e\udb37\ude24\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda62\udf56\ud986\udc20\u828a\udb57\uddd9\ud99f\udfe1\uf2eb\ud8b4\udc9b\ud894\udde1\ud8ab\ude8a\udb3f\udd39", "\u82d1\u3d14", "\udaa1\udc18\uda05\udd52\ud868\ude35\ud84e\udeb6\ud938\uddef\ud8e9\ude2f\ud8a0\udf0a\ud80d\udc96\ud81b\udc78\udad4\uddd7\ud9f4\udeef\ud9af\ude2e\u0255\ud948\udc66\uda38\uddbe\uda73\udf24\ud976\udc62\ud80e\uddac\ud8c9\ude74\ud9a2\udfcb\uda46\ude30\ud93a\udc08\ud931\udfee\ud871\udc66\ud8c9\udc1d\udbd4\udc66\ud9a6\udc09",
        52, 2175, 1852868224, -4139506863186459930L, 96182L, true, true, (char) 27774, (char) 2265,
        Double.longBitsToDouble(0x3fe32ed6b1405809L), Double.longBitsToDouble(0x3fd4569243866e4eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\u9fdc\000\udbed\udc55\ud80f\ude3f\udaae\udc04", "\u293b\u4686\u559a\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\u4534\ube92\u2c37\ub9af\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 35417, -1954767512, -3415875843159260992L, 29749L, false, true, (char) 12239, (char) 13698,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 1, 5, "\udb39\ude86\uda26\udccc\ud967\udfa8\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\udad0\uddf8\ud949\udd42", "\u293b\u4686\u559a\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af\u2e83\u2215\ua0b8\ubb0d\ud1dc", "\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 35417, -1954767512, -3415875843159260992L, 29749L, false, true, (char) 12239, (char) 13698,
        Double.longBitsToDouble(0x3fee3aada2798e89L), Double.longBitsToDouble(0x3f89448973e15a00L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 3, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud876\udcfa\udb35\udf1f\uda9a\ude39", "\u8d4b\u3c1b\u1f5b\u293b\u4686", "\ud88b\udff3",
        -5, 71591, 1906240766, 7851043092021942816L, 31011L, false, true, (char) 61071, (char) 20506,
        Double.longBitsToDouble(0x3fe0c4eeea26e61dL), Double.longBitsToDouble(0x3fe771bda7c3cee3L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 5, "\udb39\ude86", "\u57e4\u1243\ud151\u40ab\u40bd\u6133\u01a4\u81b2", "\ud89e\udc37\udb21\ude5a\u5545\udaba\udd4a\ud8e4\udef2\uda06\ude53\ud884\udd47\ud862\udfb0\udafa\udc83\ud896\udd36\udbec\udece\udb68\uded7\ud833\ude28\ud9e5\uddf7\ud9e4\udc5f\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud946\udd53\udab6\udf0e\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\u22ae\udbe7\udd75\uda64\ude7c",
        42, 30111, -259283261, -8303838729493064071L, 3527L, true, true, (char) 60033, (char) 20824,
        Double.longBitsToDouble(0x3f88c72b4af3b3c0L), Double.longBitsToDouble(0x3fe8336bf1b63e19L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb39\ude86\uda26\udccc\udaf9\ude02\ud84a\ude8c\ud815\udcae\ud8d0\udce4\udb26\udf7a", "\ua869", "\udb59\udd18\ud8a8\uddc9\udb21\ude5a\u5545\udb6f\ude0d\ud88b\udff3\uda06\ude53\ud884\udd47\ud862\udfb0",
        1, 23680, 1638049038, -6013994614744176796L, 52065L, false, false, (char) 49607, (char) 26417,
        Double.longBitsToDouble(0x3fc12a26e8b94a18L), Double.longBitsToDouble(0x3fc63e47679002e4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\ud9fa\uddd5\ud8da\udfc7\udb26\udf7a\ud93f\uddec\udb72\udeea\ud804\udf92\ud949\udd42", "\u293b\u4686\u559a\ub999\u2b9f\u60ea\u2e76\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af\u9f69\u0cfc\u23e5\ubb0d\ud1dc", "\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75\ud8ab\ude20\ud986\udc20\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 35417, -1954767512, -3415875843159260992L, 29749L, false, true, (char) 12239, (char) 4738,
        Double.longBitsToDouble(0x3fd6275b95b2ede0L), Double.longBitsToDouble(0x3fe042f552bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 0, 5, "\udb39\ude86\udbcb\udcd6\ud9cc\udddb\u4525\uda0b\udd94\ud8eb\udfaa\ud8e3\udc7d\udb4e\udeb1\udbfa\udd36\ud80f\ude3f\uda14\udeaa", "\u9a5a\u4686\u559a\ub999\ua93b\u0cf7\u11e6\u86af\u340a\u1890\ub162\ubcd7\ube92\u7774\u423b\ua041\u5851\u4ba8\u9987\ud1dc", "\ud960\ude88\ud9fe\udf79\ud951\udf30\ud8df\udd87\ud859\udc3d\udbe7\udd75",
        14, 10992, -406431998, -1102420606770348524L, -97608L, true, true, (char) 6226, (char) 62740,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3fd2bcecf60cdafcL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u964b", "\udb6f\ude0d\uda7f\udc2d\ud848\ude53\udb13\uddeb\ud875\ude5e\udafa\udc83\ud8a8\udc69\udbec\udf50\udb68\uded7\ud833\ude28\ud9af\uddf7\ud9da\udc36",
        44, 24726, -823964946, 6523111954200637998L, 6855L, true, true, (char) 61575, (char) 46982,
        Double.longBitsToDouble(0x3fde805110c28524L), Double.longBitsToDouble(0x3f9db0f28bab57a0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 0, 0, "\udb39\ude86", "\000\000\u284c\u9fdc\uad21\u42ae\u409a\u9030", "\ud86f\udfd3",
        4, 10349, -423843957, 234925786594578627L, -29598L, false, false, (char) 1812, (char) 7502,
        Double.longBitsToDouble(0x3fee1b0d1764ac89L), Double.longBitsToDouble(0x3fec07587dffa21bL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 3, "\udb39\udefb\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude29\u9e55", "\u5c80\uc7af\u964b\u4686\u435b\u2b82\u2af1\u8414\u7e1c", "\ud896\udd36\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7",
        5, 98584, 934578726, -3538902670695284797L, -34641L, true, true, (char) 33148, (char) 61575,
        Double.longBitsToDouble(0x3fb942c88f402888L), Double.longBitsToDouble(0x3fb850a480ed8790L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb17|-\ude50|-\uda26|-\udccc|-\ue7b1|-\ud899|-\ude06|-\uda15|-\udfb0|-\ud8da|-\udfcc] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\udb17\ude50\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc", "\u6133\u4dfd\u523a\ucaea\uc7af", "\u5545\udb6f\ude0d\ud9dc\udedc\udb94\udedb\ud986\udca9\ud862\udfad\udafa\udc83\ud896\udd36\udbec\udece\ud8f3\udd7b\ud833\ude28\ud9af\uddf7\ud9da\udc36\uda96\udfbf",
        39, 93054, 1518780355, -992003382086270799L, -29639L, true, false, (char) 46982, (char) 9977,
        Double.longBitsToDouble(0x3fb850a480ed8790L), Double.longBitsToDouble(0x3fb756af668e7a00L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude86", "\u23e4\u1243\ud151\u40ab", "\ud80f\ude3f",
        31, 99673, 1868690285, 1949484946629820314L, -62941L, true, false, (char) 47369, (char) 22152,
        Double.longBitsToDouble(0x3fec64b0ed96bc73L), Double.longBitsToDouble(0x3fea5b0d1764d791L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 5, 4, "\udb39\ude86\uda26\udccc\ud891\udf9e\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u42ad\ud098\u686f\ub999", "\ud884\udd9b\udbdf\udd54",
        19, 23680, 1638049038, -6013994614744176796L, -13471L, true, false, (char) 18026, (char) 49596,
        Double.longBitsToDouble(0x3fee1ea9222e5a86L), Double.longBitsToDouble(0x3fa2fe3e96757930L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 3, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06", "\u40ab\uadeb\u6133\u415c\u8d4b\u5c80\uc7af\u964b\u4686\u559a\ub999", "\ud884\udd47\ud862\udfb0\udafa\udc83\ud896\udd36\udbec\udece\udb68\uded7\ud833\ude28\ud851\udf47\udbfa\udd3f\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud946\udd53\udab6\udf0e\uda65\ude1b",
        16, 1325, 1116873192, -5696472568349994979L, -90856L, true, false, (char) 14547, (char) 6055,
        Double.longBitsToDouble(0x3fbe905cf36fcc88L), Double.longBitsToDouble(0x3feffb0fa5f8cf90L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 5, 2, 5, "\udb39\ude86\uda40\ude58\udb9b\udeaa\ud9c5\udf91\uda16\udc22\ud8da\udfcc", "\u5449\u5e66\u0af2", "\udb6a\udc42\udb21\ude97\u5545\udb6f\ude0d",
        27, 8715, -1940000003, 5853480517759120510L, 75263L, true, true, (char) 52519, (char) 52731,
        Double.longBitsToDouble(0x3fdffa21bc313bbaL), Double.longBitsToDouble(0x3fe49f30eaeed3b4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 1, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\035\ud8f2\udf98\ud9ce\udce2\uda7f\ude9eF\000\000", "", "\u5905\ud841\udf0b\000\uda06\udd90\ud884\udd47\ud862\udfb0\ud97e\ude26\000\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7\000\ud9b9\udc91\udae9\udf89\ud80a\udc09\udadd\udd18",
        41, -1000, -1806327449, -8054990131559243695L, 39752L, true, false, (char) 33039, (char) 59161,
        Double.longBitsToDouble(0x3fe64b3f40ffd2e3L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\ud813\udd3f\ud957\udd42\uda36\udca4\ud9bf\ude82\ud81e\uddaf\udb7a\udcca\udb21\ude5a\u5545\udb6f\ude0d\ud88b\udff3\uda06\ude53\ud884\udd47\ud862\udfb0\udafa\udc83\ud896\udd36\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7\ud9da\udc36\ud9b9\udc91\udae9\udf89\uda67\uddf1\udbf1\udd06\ud90e\udd5e\ud946\udd53\udab6\udf0e\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab", "\u5350\ua6d5\u8ab5\ua22d\u7bf4\ubea4\uc63e\u6265\ua54b\u3d68\u70f3\u84ee\u750b\u815e\u1bc2\u7f2f\ub182\u4800\u6f12\ud755\uc22a\u2f40\u5219\u20df\u1d47\u8821\u110e", "\u745c\udb0f\udff7\udb09\udd78\ud94d\udcd7\udab8\udd63\udbe9\udef1\ud949\udfa2\uda92\udc78\udb38\udca5\ud8d9\udc31\uda8a\udf72\ud919\ude31\udb53\udf75\udb38\udd81",
        44, 98525, -394899662, 4976677024166113340L, 1799L, true, false, (char) 16044, (char) 54077,
        Double.longBitsToDouble(0x3fd03c1d1cf0e6ecL), Double.longBitsToDouble(0x3fe3dd77bf55828aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb39|-\ude86|-\uda26|-\udccc|-\ue7b1|-\ud899|-\ude06|-\uda15|-\udfb0|-\ud8da|-\udfcc|-\udb26|-\udf7a|-\uda9a|-\ude39|-\ud813|-\udd3f|-\ud957|-\udd42|-\uda36|-\udca4] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 1, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\ud813\udd3f\ud957\udd42\uda36\udca4", "\u760e\u45f0\u559a\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u5537\ub9af", "\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud946\udd53\udab6\udf0e\uda0d\ude90\ud92a\uddb0\ud9c5\udd04",
        27, 17625, 1522389021, 7487388710806444745L, -56601L, false, false, (char) 23128, (char) 41520,
        Double.longBitsToDouble(0x3fe82c5be2cbd098L), Double.longBitsToDouble(0x3fbea55ecf3e7678L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 4, "\udb39\udf00\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud99c\ude87\uda9a\udd8d\uda9a\ude39\udb5b\ude54\ud957\udd42\uda36\udca4\ud9bf\ude82\ud81e\uddaf\udb7a\udcca\udb21\ude5a\u5545\udb6f\ude0d\ud88b\udff3\uda06\ude53\ud884\udd47\ud862\udfb0\udafa\udc83\ud896\udd36\udbec\udece\udb68\uded7\ud93c\udca4\udbc0\uddab", "\u55a6\ua0b8\ubb0d\ud1dc\u3572\uc1cb", "\ud9c5\udcb1",
        27, 17625, 1522389021, 7487388710806444745L, 70375L, false, false, (char) 23128, (char) 41520,
        Double.longBitsToDouble(0x3fe82c5be0c0d098L), Double.longBitsToDouble(0x3fbeb2e9cf3e7678L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 5, "\udb39\ude86\uda26\udccc\uda3d\udf34\ud899\ude06\uda15\udfb0\ud8ef\udef1\udb26\udf7a\uda7f\ude9e\000\000\000", "\u293b", "\udb6f\ude0d\u00c2\000\ud884\udcf0\ud862\udfb0\udafa\udc83\ud896\udd36\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7\u00ff",
        20, 24726, -1400963072, 6485319884228768302L, 6855L, true, true, (char) 61575, (char) 46982,
        Double.longBitsToDouble(0x3fe9488960614292L), Double.longBitsToDouble(0x3f9db0f28bab57a0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud8d8|-\ude0c|-\uda02|-\udfe1|-\ue7b1|-\ud899|-\ude06|-\uda15|-\udfb0|-\ud8da|-\udfcc|-\udb26|-\udf7a] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\ud8d8\ude0c\uda02\udfe1\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a", "\000", "",
        -5, 76500, -354975846, -4585129493043042421L, -100000L, false, false, (char) 0, (char) 62231,
        Double.longBitsToDouble(0x3ece800000000000L), Double.longBitsToDouble(0x3fee18000764ac89L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb24|-\ude12] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\udb24\ude12", "\ua9d0\u1243\ud151\u40ab\uad21\000\000", "",
        7, 76500, -354975846, -4585129493030721653L, -100000L, false, false, (char) 47369, (char) 62389,
        Double.longBitsToDouble(0x3fe10367a50e7840L), Double.longBitsToDouble(0x3fee1b0d1764ac89L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 1, "\udb39\ude25\uda26\udccc\ud81e\udeb1", "\ud151", "\uda79\uded7\uda06\udf06\ud94b\udc36\ud866\udcc8\ud887\udefb",
        47, 13314, -1064808335, -1820395933867532350L, -66696L, false, false, (char) 7502, (char) 47082,
        Double.longBitsToDouble(0x3fe8f4146380eb0fL), Double.longBitsToDouble(0x3fdffa21bc313bbaL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb41|-\udc95|-\uda26|-\udccc|-\u32bd|-\udaa6|-\udece|-\ud88a|-\udfc7|-\uda12|-\udf32|-\udb26|-\udf7a|-\udae7|-\udde1|-\uda21|-\udf8e|-\uda7b|-\udc7b|-\ud87d|-\udcbb|-\udb8b|-\udd08|-\udaff|-\ude8b|-\ud9a9|-\uddbd|-\udba9|-\udebd|-\ud8cc|-\uddeb|-\udb90|-\udc1d] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\udb41\udc95\uda26\udccc\u32bd\udaa6\udece\ud88a\udfc7\uda12\udf32\udb26\udf7a\udae7\udde1\uda21\udf8e\uda7b\udc7b\ud87d\udcbb\udb8b\udd08\udaff\ude8b\ud9a9\uddbd\udba9\udebd\ud8cc\uddeb\udb90\udc1d", "\u833d\u03a8", "\udab9\ude7f\ud86e\uddc5\ud9ed\udec4",
        59, 21567, -145596053, -4056374207792179152L, 74893L, false, false, (char) 39081, (char) 42263,
        Double.longBitsToDouble(0x3fe23706e51a2215L), Double.longBitsToDouble(0x3fe381dff49f78f7L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 5, 5, "\udb39\ude86\uda26\udccc\u32bd\udaa6\udece\ud88a\udfc7\uda12\udf32\udb26\udf7a\udae7\udde1\uda21\udf8e\ud833\uded7\ud949\udd42\ud87d\udd12\udb59\udd18\ud8a8\uddc9\udb21\ude5a\ud8cc\uddeb\udb6f\ude0d\uda4b\udc1b\ud94d\udd30\uda47\udec7\ud862\udfb0\udafa\udc83\udb16\udd36\ud824\udf6a\udb44\ude91\ud833\ude28\ud9af\uddf7\ud9da\udc36\ud815\udd40\ud9c9\udd8d\uae16\udadd\udd18\ud90e\udd5e\udb3b\udf6e\uda3c\udf45\uda1a\udd8f\udb43\udcc7\ud9fe\udc1a\ud923\uddd4\udb53\udf46\udbe7\udd75\uda64\udebe\ud986\udc20\udab0\udc91\ud81f\udddd\ud99f\udfe1\ud97a\udfab\ud8b4\udc9b\ud8c2\udee1\ud8ab\ude8a\udb41\udc39\ud8f5\uddaa\udbac\udd59\udb6a\udf9e", "\u5754\u6dbf\ub5eb\u719c\u2dc7\u6711\u168d\u1903", "\u91d9\uda20\ude79\udbae\udd52\ud990\udd4a\udba9\udcb8\ud93c\udfdf",
        17, 78734, -1634037590, 4593462416222646512L, -42689L, true, true, (char) 45164, (char) 18890,
        Double.longBitsToDouble(0x3fcb637c4519de7cL), Double.longBitsToDouble(0x3fee198bc2035800L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\udb56\ude86\ud808\udfdd\ud8ee\udd5b\ud9f4\uddb8\u2eb3", "\u707e\uab94\u22f9\uc71e\u3c1b\u1f5b", "\ud8cc\uddeb\udb6f\ude0d\uda4b\udc1b\ud94d\udd30\uda47\udec7\ud862\udfb0\uda24\udda4\udbe3\udece\udaa1\udf96\udb42\udd11\ud833\ude28\ud9af\uddf7\ud9da\udc36\ud815\udd40\udb3a\udf46\udb45\udd42\udaac\udfc0\udb2c\udc18\ud874\udc81\uda3c\udf45\uda1a\udd8f\udb43\udcc7\ud9fe\udc1a\uda5f\udecf\ud946\ude5e\uda35\udcbc\uda64\udebe\ud983\udcd7\udab0\udc91\udae1\udf7f\udb44\udcc5\ud806\ude96\ud87b\ude29\ud8c2\udee1\ud920\ude04\udb52\udfce\ud8f5\uddaa\udb79\udcc0",
        -2, 68358, 1673720246, 6175791610648459207L, -56704L, false, true, (char) 41593, (char) 65102,
        Double.longBitsToDouble(0x3fe293069c32bec9L), Double.longBitsToDouble(0x3fed1526bfd73978L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 5, 5, "", "", "\ud88a\udfc7\ud8e1\udf9a\udafe\udf9e\udae7\udde1\uda21\udf8e",
        18, 6456, 1534838702, -7532917705189658588L, -70391L, true, true, (char) 7643, (char) 58187,
        Double.longBitsToDouble(0x3fceedf293fbf36cL), Double.longBitsToDouble(0x3fe0c38cf2206cf4L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 0, "\udb2f\udf3f\uda26\udccc\ud9b0\udc8d\ud822\udf91\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\udddd\u9e55\ud80f\ude3f\ud949\udd42", "\u48f4\u3481\u1b45\ub9e7\uc8a7\u6577\u2ec3\u03a8\u533a\uc3dc", "\ud833\uddc7\ud9af\uddf7\ud9da\udc36",
        0, 40969, -823964946, 6523111954301301294L, 6855L, true, true, (char) 61575, (char) 46982,
        Double.longBitsToDouble(0x3fde80511287a01cL), Double.longBitsToDouble(0x3f9db0f28bab57a0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=null\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 5, 4, "", "\000\u23e4\u1243\ud151\u40ab\u4061\u42ae\000\000\ud7c2\u5042\u48f4\u3481\000\u120e\u2b9f\u65ab\u2ec3\u03a8", "\udbec\udece\udb68\uded7d",
        -4, 84615, -434301416, 4013855200252218094L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fde80000287a01cL), Double.longBitsToDouble(0x3f9db0f200000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 1, "\udb2f\udf3f", "\u23e4", "\udb26\udf7a\udbe4\udf43\u9e55\ud80f\ude3f\ud949\udd42\ud875\ude6e\u4a00\000\udbb0\udc0d\ud885\ude2c\udb6f\ude5b",
        27, 96427, -871658409, 1827963416L, 73326L, false, false, (char) 0, (char) 768,
        Double.longBitsToDouble(0x3fdffa21bc313bbaL), Double.longBitsToDouble(0x3f85cc3abb8ded00L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=null\012",
        Z.run(T, 2, 4, 3, 5, "\udb39\ude4c\ud937\udfb5\ud80d\ude12\ud9b2\uded4\ud9f0\udd9e\udb23\udf0c\u4ff0\ud830\udea3", "\ud3c6\ub6b1\u0c16\uac5c\ube32\u4a26\ube17\ua339", "\ud902\uddae\udafa\udcd3\ud8c5\udd6c\udbda\udea5\uda20\udf1b\ud833\ude83\ud9af\uddf7\uda3e\udd7d",
        27, 88820, -967706597, -6187335688896950952L, -46928L, true, false, (char) 7701, (char) 40360,
        Double.longBitsToDouble(0x3fe2ea7015080931L), Double.longBitsToDouble(0x3fee82e3feefb7fbL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\uda43\ude8a\uda26\udc79\ud80f\udfa7\udb03\udd0d\ud9ea\udd94\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u29bd\u4686\u559a\ub999\u6905\u483a\u64c3\u7a57\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\u13bb\u9f69\u05c7", "\u6614\ud831\udec1\udaab\udce8\ud9fe\udf8a\udbe8\udd7e",
        10, 81934, -1326253961, 6538611055096990813L, 28235L, true, true, (char) 50999, (char) 30436,
        Double.longBitsToDouble(0x3fd9845364fbd6b0L), Double.longBitsToDouble(0x3feb40264f05cd40L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 0, 4, 0, "\udb39\ude86\uda26\udccc\uda57\udd4b\udb03\udd0d\001\ud8c8\udfa3\u9fdc\udab5\ude99\u9e55\ud80f\ude3f\ud949\udd42", "\u29bd\u4686\u559a\ub999\u6905\u483a\000\u7a57\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\u13bb\u9f69\000", "",
        45, -998, 217615397, -8055055028515086121L, 94558L, true, false, (char) 33039, (char) 0,
        Double.longBitsToDouble(0x3e3b908800000000L), Double.longBitsToDouble(0x3fec98a6a6acf08bL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb39\ude86\uda26\udccc\ud80f\udfa7\udb03\udd0d\ud9ea\udd94\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42\ud965\udc0f\ud747\ud8a8\ude4b\udb21\ude5a\u5545\udb6f\ude0d\uda0f\udc93\uda06\ude53\ud891\udf47\udb73\uddd7\udafa\udc83\ud896\udd36\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7\ud920\udf2a\ud9b9\udc91\udafb\udf9b\ud90f\udcad", "\u1421\u7384\u7da3\u3e09\u0267\u50db\ucac5\u1ba9\u6f06\u158e\u8422\u5941\u1dcb\uc7a0\u30d3\ua845\u1f42", "\ud9d5\udd2c\uda0c\udff5\ud812\uded3\ud8ba\udd16",
        52, 89489, 1697929400, 2003748739144712811L, 44314L, true, false, (char) 48012, (char) 58782,
        Double.longBitsToDouble(0x3fe47e355e422db7L), Double.longBitsToDouble(0x3fb3bb7d45a51998L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u4686\u559a\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\uda0d\ude90\ud9de\udd53\ud9c5\udcf2\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\u00c9\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 91553, -1954767512, -3415875843159260992L, 29749L, false, true, (char) 25, (char) 0,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 0, "", "\uaefc", "",
        -5, 39704, 0, 0L, -63172L, false, false, (char) 17373, (char) 26601,
        Double.longBitsToDouble(0x3fee1735e0c30342L), Double.longBitsToDouble(0x3ec18003302c0000L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 5, "\udb39\ude86\uda26\udccc\ue7b1", "\u5b18", "\ud8ea\udda2\udb90\udecf\ud9f6\udf87\ud87d\udc83\udb59\udd18",
        55, 4562, 207509765, 3021818144721347581L, -42497L, true, true, (char) 62389, (char) 1010,
        Double.longBitsToDouble(0x3fdf9ea1e81b30eeL), Double.longBitsToDouble(0x3fe23fe4031b3801L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud833|-\udd1d|-\u5c34] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\ud833\udd1d\u5c34", "\u1243\ud151\u9fdc\000\u1f35\uacc8\u0b04\u835e\u1f5b\u6b01\u766a\u559a\ub999\u2b9f\u483a\u2ec3\u5401\u533a\u044a\ub0c5\u4534\ube92", "\udb7b\udd0f\ud975\udd6e\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud946\udd53\udab6\udf0e\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4",
        42, 15165, 1802144861, -3250654684825181697L, -23919L, true, false, (char) 50991, (char) 24920,
        Double.longBitsToDouble(0x3fe4dcb6b74fad68L), Double.longBitsToDouble(0x3fc81a1311eb2e9cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 1, "\udb39\ude86\ud902\udeb9\ue797\ud899\ude06\uda15\udfb0\ud8da\udfcc\udacc\udf8e\034\udbed\udc55\ud80f\ude3f", "\u9456\u77b2\u4686\u559a\uaf99\ua6ed\u63ad\u2ec3\u5bb7\u533a\u18a6J\u4534\u96d1\u2c37\ub9af\u9f69", "\udadd\udd18\udba0\uddc7\udaf9\ude5e\udbad\uded6\udbe3\ude86\udafc\ude96\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab\ud8b4\udc9b\ud8c2\udee1\uda17\udc56\udaa6\udf02\ud8eb\udda1\udbac\udd93\udb6a\udf9e\udb55\udeae\ud801\udf97",
        41, 52255, -1575200037, 5817338092732775103L, -31726L, true, false, (char) 60207, (char) 24502,
        Double.longBitsToDouble(0x3fafc0485df9f1a0L), Double.longBitsToDouble(0x3feba0fb5dee2e95L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 5, "\000", "\u23e4\u1243\u2875\u9fdc\000\u4f33\uc999\u405e", "\ud8a8\uddc9\udb21\ude5a\u5545\udb6f\ude0d\ud88b\udff3\ud8f6\udccb\000\ud862\udfb0\udafa\udc83\ud896\udd36\udbec\udece\udad8\udfcf\ud8b1\ude27\udb6a\ude75\ud9da\udc36\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udadd\udd18\ud90e\udd5e",
        52, 56551, -1875448537, 802309584719031397L, 35265L, true, false, (char) 23322, (char) 23241,
        Double.longBitsToDouble(0x3fdffd2e3d860000L), Double.longBitsToDouble(0x3fe567845e798cc2L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\u72ab\ud83b\ude1d\u3688#\udbed\udc55\ud80f\ude3f\udaae\udc04", "\u293b\ud107\u55e4\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\u4534", "\ud9da\udc36\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud946\udd53\udab6\udf0e\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, -1113613128328663380L, -97632L, true, false, (char) 41520, (char) 60033,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3fd2bcecf60cdafcL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udade|-\udcb2|-\u442b|-\ue7b1|-\ud899|-\ude06|-\uda4c|-\udefe|-\uda42|-\udc9c|-\udb2a|-\udf7c|-\uda9a|-\ude39|-\uda8d|-\udd00|-\uda24|-\udf89|-\ud9f7|-\udcc8|-\udadf|-\udf1d|-\ud960|-\ude3d|-\ud86f|-\udfd3|-\udb21|-\ude5a|-\u5545|-\udb6f|-\ude0d|-\ud9dc|-\udedc|-\udb9e|-\udddb|-\ud986|-\udca9|-\ud862|-\udfad|-\udafa|-\udc83|-\ud896|-\udd36|-\udbec|-\udece|-\ud8f3|-\udd7b|-\ud833|-\ude28|-\ud9af|-\uddf7|-\ud9da|-\udc36|-\uda96|-\udfbf|-\udaa3|-\udd70|-\ud83c|-\udec1|-\ud851|-\udf35|-\ud83b|-\udcb8|-\ud946|-\udd53|-\udab6|-\udf0e|-\uda0d|-\ude90|-\udbe8|-\udcf8|-\ud940|-\udf70|-\uda81|-\udf6b|-\ud932|-\udf59] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 3, "\udade\udcb2\u442b\ue7b1\ud899\ude06\uda4c\udefe\uda42\udc9c\udb2a\udf7c\uda9a\ude39\uda8d\udd00\uda24\udf89\ud9f7\udcc8\udadf\udf1d\ud960\ude3d\ud86f\udfd3\udb21\ude5a\u5545\udb6f\ude0d\ud9dc\udedc\udb9e\udddb\ud986\udca9\ud862\udfad\udafa\udc83\ud896\udd36\udbec\udece\ud8f3\udd7b\ud833\ude28\ud9af\uddf7\ud9da\udc36\uda96\udfbf\udaa3\udd70\ud83c\udec1\ud851\udf35\ud83b\udcb8\ud946\udd53\udab6\udf0e\uda0d\ude90\udbe8\udcf8\ud940\udf70\uda81\udf6b\ud932\udf59", "\uc2c9\u30d5\u9c11\u3c97\ubf2a\u571c\u2dff\u5fc0\u5053\u9149\u3f94", "\uda95\ude40\uda4f\udd6b\uda81\udd37\udadd\udef7\ud8b1\uddb9\ud9d5\udd40\ud8c2\udd22\ud9d3\udf1e\ud94d\udfc2\ud829\udfd7\ud80d\udee1\udb47\udfea\u1243\ud957\udd4a\udba7\uddfb\ud8cc\udd7c\ud9a7\udeaf\ucf71\udbbb\udf85\ud87c\udea6\u7cda",
        50, 63315, 760537228, -6303043690139869448L, -94185L, false, false, (char) 31032, (char) 34200,
        Double.longBitsToDouble(0x3fe19be6700b3252L), Double.longBitsToDouble(0x3fcef74a8e418cf8L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb17|-\ude50|-\uda26|-\udccc|-\ue7b1|-\ud899|-\ude06] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\udb17\ude50\uda26\udccc\ue7b1\ud899\ude06", "\u80d3\u40bd\u53c2\u17d0\u6bd8\u52eb\u98d0\u70aa\u4678\ubdc3\ub999", "\ud986\udca9\ud862\udfad\udafa\udc83",
        35, 45782, 1628372931, -1508803303782546560L, 90952L, false, false, (char) 40047, (char) 36518,
        Double.longBitsToDouble(0x3fe172d43361f23bL), Double.longBitsToDouble(0x3fd673adfa4f28aaL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb14|-\udd8e|-\uda26|-\udccc|-\ue7b1|-\ud899|-\ude06|-\uda15|-\udfb0|-\ud8da|-\udfcc|-\udb2a|-\udf7c|-\uda9a|-\ude39|-\u9e55|-\uda24|-\udf89|-\ud9f7|-\udcc8|-\ud8e9|-\udf22|-\ud960|-\ude3d|-\ud86f|-\udfd3|-\udb21|-\ude5a|-\u5545|-\udb6f|-\ude0d|-\ud9dc|-\udedc|-\ud8a8|-\udc25|-\ud927|-\udebd|-\udba0|-\udc8e|-\udae9|-\ude3a|-\ud896|-\udd36|-\udbec|-\udece|-\ud8f3|-\udd7b] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\udb14\udd8e\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb2a\udf7c\uda9a\ude39\u9e55\uda24\udf89\ud9f7\udcc8\ud8e9\udf22\ud960\ude3d\ud86f\udfd3\udb21\ude5a\u5545\udb6f\ude0d\ud9dc\udedc\ud8a8\udc25\ud927\udebd\udba0\udc8e\udae9\ude3a\ud896\udd36\udbec\udece\ud8f3\udd7b", "\ub9af\u97d2\u154e\ua0b8\ubb0d\ud1dc\u3572\uc1cb\ub8a9\u3d83\u0267\u60ce\ubaae\u69f2", "\udbca\udd74\udadf\udfae\uda26\udd39\ud82a\udc68\udac0\udd4e\ud8a0\udd96\ud8c7\udded\udbbb\udcc3\ud90a\udd23\udbed\udd0f\ud9f7\udd0f\ud90a\uddf6\udaa4\ude10\udaab\uddf3\ud9e0\udea0\ud887\udc9e",
        40, 46265, -1580919421, 2553313485848159692L, -93212L, false, false, (char) 33020, (char) 50185,
        Double.longBitsToDouble(0x3fceb7fa209bb7d0L), Double.longBitsToDouble(0x3fd5520802df00a2L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb17|-\ude50|-\uda26|-\udccc] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\udb17\ude50\uda26\udccc", "\u225d\ud151", "\u9e55\uda2a\udd0c\ud9f7\udce5\ud8e9\udf22\ud960\ude3d",
        20, 38154, -1067558651, -1820395935837806654L, -66696L, false, true, (char) 7599, (char) 24933,
        Double.longBitsToDouble(0x3feb23087380eb0fL), Double.longBitsToDouble(0x3fe19510de189d17L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 1, "\udb39\udef9\uda26\udccc\ue7b1\ud899\ude06\035\ud8f2\udf98\ud9ce\udce2\uda7f\ude9eF\000\000\000\000\udb7a\udcca\udb21\ude5a\u5905\ud841\udf0b", "\u2ec3", "\000\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7",
        -5, 98584, -743142874, -3538902494601625661L, -100000L, true, true, (char) 33148, (char) 61575,
        Double.longBitsToDouble(0x3fb942c88f402888L), Double.longBitsToDouble(0x3fb850a480ed8790L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\035\ud8f2\udf98\ud9ce\udce2\uda7f\ude9eF\000\000", "", "\u5905\ud841\udf0b\000\uda06\udd90\ud884\udd47\ud862\udfb0\ud97e\ude26\000\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7\000\ud9b9\udc91\udae9\udf89\ud80a\udc09\udadd\udd18",
        41, -1000, -1806327449, -8054990131559243695L, 39752L, true, false, (char) 33039, (char) 59161,
        Double.longBitsToDouble(0x3fe64b3f40ffd2e3L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\udb83\udea9\u0094\000\000\000\udb7a\udcca\udbde\udf9e\u5905\ud9ad\udf01\000\uda06\udd90\ud884\udd47\ud862\udfb0\ud97e\ude26\uda9c\udd4d\udac8\udf59\udb04\ude12", "C\u9f69\u55a6\ua0b8\ubb0d.\000\uc1cb\ub8a9\u3d83\uad36\u2e9e\u6021\u0baf", "\ud978\uddb0\u37e4\ud973\ude99\u9eae",
        19, 31829, -509486251, 7455495189591994286L, 50005L, false, false, (char) 27092, (char) 17931,
        Double.longBitsToDouble(0x3fdf20a08945dc72L), Double.longBitsToDouble(0x3fe0c91e73efdcc4L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 1, "\udb39\ude86\uda26\udccc\ue7b1\udae7\udead\ud8dc\udcbc\ud8f2\udf98\ud9ce\udce2\udb9b\udd6c\uda4d\ude69\000\000\ud86f\udd56\023\udb7a\udcca\udb21\ude5a", "\000", "\ud862\udfb0\ud97e\ude26\000\udbec\udece\udb17\udda8\ud817\ude75\ud9af\uddf7\000\ud9b9\udc91\udae9\udf89",
        9, 42355, 46, -1384105920785060197L, 6415L, true, false, (char) 9977, (char) 21235,
        Double.longBitsToDouble(0x3fd6d98d28bab57aL), Double.longBitsToDouble(0x3fe64b3f40ffd2e3L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 3, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\035\udbcf\udec6\ud9ce\udce2\uda7f\ude9e\ud8f2\udf23\002\000", "", "\ud8c2\udedd\ud841\udf0b",
        -5, 8520, -871658409, 8187241747931455555L, 73368L, true, true, (char) 6790, (char) 61071,
        Double.longBitsToDouble(0x3f44437860000000L), Double.longBitsToDouble(0x3fd33e61d5dda768L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb39|-\ude86|-\ud8f5|-\uddff|-\uda4b|-\ude6e|-\udbdd|-\ude02|-\010|-\ud8f2|-\udf98|-\ud9ce|-\udce2|-\uda7f|-\ude9e|-\ud8fb|-\udc47|-\uda5f|-\udfea|-`|-\000] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 0, "\udb39\ude86\ud8f5\uddff\uda4b\ude6e\udbdd\ude02\010\ud8f2\udf98\ud9ce\udce2\uda7f\ude9e\ud8fb\udc47\uda5f\udfea`\000", "\u4686", "\000",
        -5, 71591, 1906240766, 68822933908226048L, 97329L, true, true, (char) 61071, (char) 41499,
        Double.longBitsToDouble(0x3fe0c0000226e61dL), Double.longBitsToDouble(0x3fe7769da7989595L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 1, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\035\ud8f2\udf98\ud9ce\udce2\uda7f\ude9eF\ua299\027", "", "\u5905\ud841\udf0b\000\uda06\udd90\ud884\udd47\ud862\udfb0\ud97e\ude26\000\udbec\udece\udb68\uded7\ud833\ude28\ud9af\uddf7\000\ud9b9\udc91\udae9\udf89\ud80a\udc09\udadd\udd18",
        41, -1000, -1806327449, -8054990131559243695L, 39752L, true, false, (char) 33039, (char) 59161,
        Double.longBitsToDouble(0x3fe64b3f40ffd2e3L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 5, "\000", "\uac1b", "",
        -5, -1000, 0, -4730222166701141968L, -100000L, false, false, (char) 0, (char) 44118,
        Double.longBitsToDouble(0x3fec5eb75fa709bcL), Double.longBitsToDouble(0x3fe4eaa57ef76f94L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 5, 3, "x", "\ubd7f", "\udb25\udd16\udbbf\uddad",
        19, 23634, -1211123259, 6592082030775728475L, -67130L, true, false, (char) 32374, (char) 7643,
        Double.longBitsToDouble(0x3fda4d5af1ee2156L), Double.longBitsToDouble(0x3feff7e6da18719eL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.DefaultOption:[-\000] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\000", "\u7bf4", "\uda42\udeb2\udb07\uddb7\uda21\udf8e\ud833\uded7\ud949\udd42\ud87d\udd12\udb5f\udd3b\udb97\udd40\uda94\udd02\ud8cc\uddeb\udb6f\ude0d\uda4b\udc1b\ud94d\udd30\ud9ee\udd6d",
        19, 64416, 1806670368, 1793580780984325295L, 24693L, true, false, (char) 22504, (char) 11092,
        Double.longBitsToDouble(0x3fbb3e636dab6420L), Double.longBitsToDouble(0x3fee56c873f7dacfL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 5, 0, "\udae1\udc2f\022\u1d44\udab2\udcce\udae0\ude51\uda20\uded9\uda87\udf4a\ud8b6\udfa8\ud8ee\udd38\ud8d0\udf44\ud949\udd42\ud87d\udd12\udb59\udd18\ud8a8\uddc9", "\ud71d\u4b7c\u9113\u7953\u03a8\u533a\uceb0\u576c\u5e45\u697d\u2f1a\uaa5c", "\ud9e7\udf85\ud9ea\udf72\ud98c\ude32\ud877\uddf6\udb43\uddd5\ud860\udd25\udacd\udca7",
        5, 99088, -70884808, -7988362776752370604L, 46857L, false, true, (char) 26331, (char) 62539,
        Double.longBitsToDouble(0x3fcf720a519745e0L), Double.longBitsToDouble(0x3fdd94b2b2acfbdcL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=null\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 5, 4, "", "\000\u23e4\ubca0\u9748\u43f9\u4061\u42ae\u06d1\ub8b2\u8004\u5042\ud053\ub627\u28f5\u20b5\u50bd\uc445\u2ec3\u03a8", "\uda5b\udc45\ud867\udda0\ud8bb\udcc8",
        48, 93913, -434301416, 4013855200252218094L, -44936L, true, true, (char) 16, (char) 0,
        Double.longBitsToDouble(0x3deaed0000000000L), Double.longBitsToDouble(0x3fde80000379a01cL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud9eb\udd71\uda26\udccc\uda57\udd4b\udb03\udd0d\001\ud8c8\udfa3\u9fdc\udab5\ude99\u9e55\ud80f\ude3f\ud949\udd42", "\u29bd\u4686\u559a\ub999\u6905\u483a\000\u4d27\u0aa2\u18a6\ub0c5\ubcd7\ube92\u2c37\u13bb", "\000\ud906\udc02\udbcf\udec6\002\udaab\udce8\ud9fe\udf8a\udbe8\udd7ee",
        19, 3567, 53387, 1081145385830842368L, 58562L, true, true, (char) 55079, (char) 27367,
        Double.longBitsToDouble(0x3fda040c7036af7cL), Double.longBitsToDouble(0x3fe63ae9eedff4ddL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\u22e4\ud8cd\udc40\udb4a\ude34\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u4686\u559a\ub573\u7edd\ua99c\ua7ea\u0348\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\u267f\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\uda0d\ude90\ud9de\udd53\ud9c5\udcf2\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\u00c9\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 91553, -1954767613, -3415875843159260992L, 29749L, false, true, (char) 25, (char) 0,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\u72ab\ud83b\ude1d\u3688#", "\u405e\u71b3\u515d\u293b\ud107", "\ud88b\udff3",
        -5, 71591, 1906240766, 7851043092021942816L, -35360L, true, true, (char) 46069, (char) 28739,
        Double.longBitsToDouble(0x3fe771bda777cee3L), Double.longBitsToDouble(0x3fe172d430b1f23bL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 4, "\udb39\ude86\uda26\udccc\ud801\udeb1\ud899\ude06\u72ab\ud83b\ude1d\u2388#\udb86\ude56\ud80f\ude3f\udaae\udc04", "\u293b\ud107\u55e4\ub999\u2b9f\u2127\u2ec3\u03a8\u533a\u18a6\ub0c5\u699c", "\ud9da\udc36\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud946\udd53\udab8\uddda\ud9f7\udf1e\udbd0\udf33\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, -1113613128328663380L, -97632L, true, false, (char) 41520, (char) 60033,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3fd2bcecf60cdafcL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\udb39\ude86\uda26\udccc\ue7b1\uda37\udd02\u72ab\ud83b\ude1d\u3688#\udbed\udc55\uef3f\udaae\udc04", "\u293b\ud107\u55e4\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u56a5\ub0c5\u4534", "\ud807\ude0c\000\000\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud9d8\udcbc\000\uda0d\ude90\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, -1113613128328663380L, -97632L, true, false, (char) 41520, (char) 60033,
        Double.longBitsToDouble(0x3fc81a1301eb2e9cL), Double.longBitsToDouble(0x3fd2bcecf60cdafcL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb39|-\ude86|-\uda26|-\udccc|-\ue7b1|-\u0088|-\000|-\ud83b|-\ude1d|-\ud968|-\udcd4 <arg>|-\udbed|-\udc55|-\ud80f|-\ude3f|-\udaae|-\udc04] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\udb39\ude86\uda26\udccc\ue7b1\u0088\000\ud83b\ude1d\ud968\udcd4#\udbed\udc55\ud80f\ude3f\udaae\udc04", "\u2917\u3907\000\u120e\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\u4534", "\ud994\ude2a\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udaad\ude18\ud90e\udd5e\ud946\udd53\udab6\udf0e\ud90c\udd66\udbe4\udcf6\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, 183354502676480L, -97632L, true, false, (char) 41520, (char) 35713,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3f49d9e000000000L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 3, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\u72ab\ud83b\ude1d\udaba\udfb0+\udbed\udc55\ud80f\ude3f\udaae\udc04", "\u293b\ud107\u55e4\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\u4534", "\ud91c\udc37\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud946\udd53\udab6\udf0e\uce4d\u69d6\udb79\uddba\udb8b\uddf9\u0170\udbe7\udd75",
        28, 40977, 1871258111, -1113613128328663380L, -97632L, true, false, (char) 41520, (char) 60033,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3fd2bcecf60cdafcL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\udb83\udea9\u0094\000\000\000/\udbde\udf9e\u5905\ud9ad\udf01\000\uda06\udd90\ud884\udd47\ud862\udfb0\ud97e\ude26\uda9c\udd4d\udac8\udf59\udb04\ude12", "C\u663a\u5580\ua0b8\ubb0d.\000\uc1cb\ub8a9\u3d83\uad36\u2e9e\u6021\u0baf", "\ud978\uddb0\u37e4\ud973\ude99\u9eae",
        19, 31829, -509486251, 7455495189591949486L, 50005L, false, false, (char) 27092, (char) 0,
        Double.longBitsToDouble(0x3fdf20a00945dc72L), Double.longBitsToDouble(0x3fe0c91e73efdcc4L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 3, "\ud915\udfa8\uda26\udccc\ue7b1\udbb7\udc15\uda55\udda2\uda32\udc5d\u8a16\udb49\udf4d\uda4d\ude3b\000\024\ud86f\udd56\udb74\udd2d\ud95a\udc7f\udb21\ude41", "\000", "\ud862\udfb0\ud97e\ude26\000\udbec\udece\udb17\udda8\ud817\ude75\ud9af\uddf7\000\ud9b9\udc91\udae9\udf89",
        9, 42355, 322816667, -3589647558007886318L, 6415L, true, false, (char) 9977, (char) 2130,
        Double.longBitsToDouble(0x3feafa065c5d5a18L), Double.longBitsToDouble(0x3fe64b3f40ffd2e3L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb39\ude86\udab1\udf72\uda3b\udd93\udaef\udf19\ud8dc\udcbc\ud8f2\udf98\ud9ce\udce2\udb9b\udd6c\uda4d\ude69\000\000\udb85\udfc2\023\ud9d7\udfd9\udb21\ude5a", "\u0d2f", "\ud852\udeb0\ud97e\ude26\000\udbec\udece",
        22, 9483, 1390705152, 65158518916584984L, -53646L, true, true, (char) 23220, (char) 1280,
        Double.longBitsToDouble(0x3fe4df6655279417L), Double.longBitsToDouble(0x3fb4640d83285910L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 4, "\udb39\ude86\uda26\udccc\udae3\udc65\ud855\udd38\ud8dc\udcbc\ud8f2\udf98\ud9ce\udce2\udbe8\ude94\ud902\ude9e\003\000\ud86f\udd56\023\udb7a\udcca\udb21\ude5a", "!", "\ud862\udfb0\uda1c\ude71\udafe\udcc8\udab2\udf0f\ud832\udf1f\ud817\ude75\ud9af\uddf7\000\ud9b9\udc91\udae9\udf89",
        9, 25971, 46, -1384105920785060197L, 6415L, true, false, (char) 50427, (char) 21235,
        Double.longBitsToDouble(0x3fd6d98d28bab57aL), Double.longBitsToDouble(0x3fe64b3f400c12e3L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\udacb\udc81\udbe2\udec9\ud825\udfd7\ud899\ude06\035\udbcf\udec6\ud9ce\udce2\uda7f\ude9e\ud8f2\udf23\002\u0086", "", "\u62d4\udb2d\udd30",
        -5, 8520, -871658409, -2366943978579321012L, -11256L, true, true, (char) 6790, (char) 61071,
        Double.longBitsToDouble(0x3f444365220c0000L), Double.longBitsToDouble(0x3fd33e61c5dda768L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\ud8f5\uddff\uda4b\ude6e\udbdd\ude02\010\ud901\udd56\ud9ce\udce2\udbe6\udc93\ud8fb\udc2f\uda5f\udfeav\000", "\u4686", "x",
        -5, 71591, 1906240766, 68822933908226048L, 97329L, true, true, (char) 61071, (char) 41499,
        Double.longBitsToDouble(0x3fe0c0000226e61dL), Double.longBitsToDouble(0x3fe7769da79895d6L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=null\012",
        Z.run(T, 2, 4, 3, 0, "\udb39\udecc\ud8f5\uddff\uda4b\ude6e\udbdd\ude02>\ud8f2\udf98\udac5\udcaf\uda9a\uded4\ud841\udfe4\udbcf\udd8e`\000", "\u4686", "\000",
        -5, 71591, 1906212946, 68822933908226048L, 97329L, false, true, (char) 26943, (char) 41499,
        Double.longBitsToDouble(0x3fe0c0000226e61dL), Double.longBitsToDouble(0x3fd34d3b423773ceL)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb39|-\ude86|-\uda45|-\udcb0|-\uda3b|-\ude22|-\udbdd|-\ude02|-\032|-\ud8f2|-\udf98|-\ud9ce|-\udce2|-\uda7f|-\ude9e|-\ud8fb|-\udc47|-\uda5f|-\udfea|-`|-\000] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 0, "\udb39\ude86\uda45\udcb0\uda3b\ude22\udbdd\ude02\032\ud8f2\udf98\ud9ce\udce2\uda7f\ude9e\ud8fb\udc47\uda5f\udfea`\000", "\u0636", "\000",
        -5, 71591, 1906240766, 68822933908226048L, 97329L, true, true, (char) 61071, (char) 41499,
        Double.longBitsToDouble(0x3fe0c0000226e61dL), Double.longBitsToDouble(0x3fe7769da7989595L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 1, "\udb39\ude86\ud921\udfc9\udad9\udfc9\uda33\udc21\017\ud8f2\udf98\ud9ce\udce2\uda7f\ude9e\uc146\ud9ea\udf99\ud8c2\udf2e", "\u5f8a\u4686", "\uda30\ude70\ud9ff\udf1d\ud948\ude37\ud84e\udd2e\ud968\ude4c\udbee\udee4\u98d6",
        43, 82356, -1575287936, 1034652816935L, -53646L, true, true, (char) 23220, (char) 0,
        Double.longBitsToDouble(0x3fd670000a4f2b1eL), Double.longBitsToDouble(0x3fb4640d8da05910L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\udb39\ude86\uda26\udccc\ue7b1\ud93b\udc98\udae4\udf42\ud8f2\udf98\ud9ce\udce2\ud970\udd97\ud97f\udc22\u8abb\027\000\000\udb7a\udcca", "\u9050\ub7cf\u2e67\u523e\u03a8\uab39\000\uc831\u6b99\u2c34\u3b18\u8b89", "\ud80a\udc09\udadd\udd18.\udaef\udc32\udbfc\udeee\uda68\udf14\udb33\udea0\udb77\ude52",
        27, 17625, 327444765, 7489158241627364041L, -100000L, false, false, (char) 17868, (char) 11266,
        Double.longBitsToDouble(0x3fcc9d6dd529b13cL), Double.longBitsToDouble(0x3fe6e6ac377f7962L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udad1|-\udffe|-\007|-\u1d44|-\ud9b1|-\udd24|-\u73b7|-\ud9fb|-\udff4|-\u0092|-\udb07|-\uddb7|-\uda21|-\udf8e|-\ud833|-\uded7|-\ud80e|-\udf24|-\ud930|-\udc28|-\udb5f|-\udd3b|-\udb97|-\udd40|-\uda94|-\udd02|-\ud8cc|-\uddeb|-\udb6f|-\ude0d|-\uda4b|-\udc1b|-\ud94d|-\udd30|-\ud9ee|-\udd6d|-\uda86|-\udf00|-\udafa|-\udc83] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\udad1\udffe\007\u1d44\ud9b1\udd24\u73b7\ud9fb\udff4\u0092\udb07\uddb7\uda21\udf8e\ud833\uded7\ud80e\udf24\ud930\udc28\udb5f\udd3b\udb97\udd40\uda94\udd02\ud8cc\uddeb\udb6f\ude0d\uda4b\udc1b\ud94d\udd30\ud9ee\udd6d\uda86\udf00\udafa\udc83", "\u6c22\ube20\u2517\u60e7\u2adb\uc472\u8d97\u4f00\u4909\u2f8d\ub7b5\u7888\u730e\u5450\u7d9d\u3e62\u6d5f\u19ba\u3640\u50d6\u4807\u91d3\uc3cd\ud498\u5597", "\ud9b8\udc50\u6730\udbc6\udd6a\udb82\udd5e\ud9c6\ude6d\udac1\udca9\ud978\udcfd\ud945\udc20\uf722\uda61\ude1a\ud992\udfd2\ud85b\udd2f",
        10, 48081, -1102736940, 4735259007673375019L, -84224L, false, false, (char) 33417, (char) 17344,
        Double.longBitsToDouble(0x3fa7070e110e87d0L), Double.longBitsToDouble(0x3feab09402808e2fL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 1, "", "\000\u23e4\ubca0\u9748\u43f9\u4061\u42ae\u06d1\ub8b2\u8004\u5042\ud053\ub627\u28f5\u1553\u11b4\uc445\u2ec3\u03a8", "\uda5b\udc45\ud867\udda0\ud8bb\udcc8",
        48, 93913, -434301416, 4013855200252218094L, -44936L, true, true, (char) 16, (char) 0,
        Double.longBitsToDouble(0x3deaed0000000000L), Double.longBitsToDouble(0x3fde80000379a01cL)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 5, 4, "", "\u8f73\u8d88\ubca0\u9748\ubfad\u4061\u42ae\u06d1\ub8b2\u8004\u5042\ud053\ub627\u207f\u20b5\ub6a4\uc445\u2ec3\u6344", "\ud865\udf6c\ud867\udd43\ud8bb\udcc8",
        48, 93913, -434301416, -8956511726574810386L, -44936L, true, false, (char) 1, (char) 0,
        Double.longBitsToDouble(0x3deaed0000000000L), Double.longBitsToDouble(0x3fde80000379a01cL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=null\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 5, 4, "", "\000\u23e4", "\ud855\udf1d\uda9a\udddd\udacc\ude07\udbaf\udcb6\uda56\ude46\ud863\udf01\ud93d\ude55\000\uda75\ude57\uda64\udc49\ud831\udd71\udbf1\uddc5\ud847\udd4f\ud884\udd47\ud862\udfb0\ud97e\ude26\ud896\udd16\uda5b\udc45\ud867\udda0\ud8bb\udcc8\ud9cb\udc41\ud85e\udf52\ud9b9\udc91",
        0, 93054, -552812605, -2503111990989288493L, -100000L, false, false, (char) 26, (char) 8680,
        Double.longBitsToDouble(0x3fdbcd00e7638cfcL), Double.longBitsToDouble(0x3febee674ea17e51L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud840\udf9a\uda18\udea9\u22e4\udbe4\udc44\udb4a\ude34\u9e55\ud80f\ude3f\udaef\udc54", "\u293b\u4686\u559a\ub573\u7edd\ua99c\ua7ea\u0348\u533a\u18a6\u1686\u4db1\u55e6\ua9c9\u267f\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\uda0d\ude90\ud9de\udd53\ud9c5\udcf2\ud923\uddd4\ud932\udfb8\udbe7\udd75\ud9e2\ude7b\u00c9\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 91553, -1954767613, -3415875843159260992L, -37067L, true, false, (char) 19, (char) 0,
        Double.longBitsToDouble(0x3fee3aada108c189L), Double.longBitsToDouble(0x3fca9c969310c704L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 5, "\udb39\ude86\uda25\udfef\ue7b1\ud899\ude06\uda27\udc91\ud83b\ude1d\udb9d\udc0e\026", "\ucd9a\u0d34\uab66\u293b\ud107", "\ud88b\udff3",
        -5, 71591, 1906240766, 7851043092021942816L, -35360L, true, true, (char) 46069, (char) 28739,
        Double.longBitsToDouble(0x3fe771bda777cee3L), Double.longBitsToDouble(0x3fe172d430b1f23bL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud88b|-\udcbe|-\uda26|-\udccc|-\ub7ac|-\u4dd2|-\udad0|-\ude53|-\uda08|-\ude04|-\ud81a|-\udd4d <arg>|-\udbed|-\udc55|-\ud80f|-\ude3f|-\udaae|-\udc04] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\ud88b\udcbe\uda26\udccc\ub7ac\u4dd2\udad0\ude53\uda08\ude04\ud81a\udd4d<\udbed\udc55\ud80f\ude3f\udaae\udc04", "\u2917\ub997\000\u120e\u2b9f\u483a\u2ec3\u03a8\u533a\u57c1\uabc4\u6519", "\ud994\ude2a\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udaad\ude18\ud90e\udd5e\ud966\udf53\udab6\udf0e\ud90c\udd66\udbe4\udcf6\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, 183354502676480L, -97632L, true, false, (char) 41520, (char) 2875,
        Double.longBitsToDouble(0x3fc81a0fb1eb2e9cL), Double.longBitsToDouble(0x3f49d9e000000000L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb39|-\ude86|-\uda26|-\udccc|-\ud91d|-\ude83|-\u0088|-\000 <arg1> [<arg2> ...]|-\ud968|-\udcd4 <arg>|-\uda92|-\udc08|-\ud80f|-\udd7d|-\udaae|-\udc04] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\udb39\ude86\uda26\udccc\ud91d\ude83\u0088\000*\ud968\udcd4#\uda92\udc08\ud80f\udd7d\udaae\udc04", "\u2917\u3907\000\u120e\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ua5ce\000", "\ud994\ude2a\ud9b9\udc91\u8a26\ud51b\udaad\ude18\ud90e\udd5e\ud946\udd53\udab6\udf0e\ud90c\udd66\udbe4\udcf6\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, 183354502676480L, -97632L, true, false, (char) 41520, (char) 35713,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3f49d9e000000000L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\u72ab\ud83b\ude1d\udaba\udfb0+\udbed\udc55\ud80f\ude3f\ud949\udd12", "\u293b\ud107\u55e4\ub9ec\u2b9f\u483a\u0ec3\ubd8b\u533a\u80cf\ub0c5\u4534", "\ud91c\udc37\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udadd\udd18\ud90e\udd5e\ud946\udd53\udab6\udf0e\uce4d\u69d6\udb79\uddba\udb8b\uddf9\u0170\udbd1\udcc8",
        28, 40977, 1871258111, -1113613128328663380L, -97632L, true, false, (char) 41520, (char) 60033,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3fd2bcecf60cdafcL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "", "\uaefc\u1ae4\035\u284c\ub919\uae34\u60af\u0094\000\000\000/\u3a18\u5905\000\000\u4777\u2ec3\u8eeb", "\udac8\udf59\uda3b\udd2e\ud833\ude0c",
        5, -933, 1906200, -3191774504118170898L, -99954L, false, false, (char) 41318, (char) 33148,
        Double.longBitsToDouble(0x3fb4640d83285910L), Double.longBitsToDouble(0x3fe3f0208ee046faL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 0, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\udb83\udea9\u0094\000\udb7e\udf0e\000/\udbde\udf9e\u5921\uda03\udf66\ucaf1\uda06\udd90\ud884\udd47\ud862\udfb0\ud97e\ude26\uda9c\udd4d\udac8\udf59\udb04\ude12", "\ua827\u6f7f\u5580\ua0b8\u6f0f\ubd55\u9666\uc1cb\ub8a9\u3d83\uad36\u2e9e\u2fca\u35c8", "\ud978\uddb0\ud86f\udc13\ud973\ude99\ud868\ude4d",
        -4, 31623, -509486251, 7455495189591949486L, 50005L, false, false, (char) 27092, (char) 0,
        Double.longBitsToDouble(0x3fdf20a00945dc72L), Double.longBitsToDouble(0x3fe0c91e73efdcc4L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\000\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud8b9\ude44w\000\000\000\000/\ud823\ude30\005\ud9ad\udf01\000\ud8f6\udc08\u8c57\000\000\000\000\udb04\ude12", "C\000\000\u9fca\ubb0d\000\000\uc1cb\ub882\u3d83\uad36\u2e9e\u0f3e\u604b", "\ud936\ude1b",
        3, 61440, -65571095, -2188470116593070347L, -50176L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3957b548000000L), Double.longBitsToDouble(0x3e2f20a000000000L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\udb83\udea9\u0094\000\000\000/\udbde\udf9e\u5905\ud9ad\udf01\000\uda06\udd90\ud884\udd47\ud862\udfb0\030\uda9c\udd4d\udac8\udf59\ud88b\udd07", "C\u663a\u5580\u53fb\ubb0d.\000\uc1cb\ub8a9\u3d83\uad36\u2e9e\u6021\u0baf", "\ud978\uddb0\u37e4\ud973\ude99\u9eae",
        19, 31829, -509486251, 7455495189591949486L, 50005L, false, false, (char) 27092, (char) 0,
        Double.longBitsToDouble(0x3fdf20a00945dc72L), Double.longBitsToDouble(0x3fe0c91e73efdcc4L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 4, "\udb39\ude18\ud972\udd52\ud81b\udc8b\ud897\udd06\udb32\ude22\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\ud983\udd49\023\ud971\uded8\036\000/\udbde\udf9e\u5905\ud9ad\udf01\udb3b\udd5c\ud9ec\ude59\ud884\udd47\ud862\udfb0\ud97e\ude26\uda9c\udd4d\udac8\udf59\udb04\ude12\ud833\ude0c\ud8a9\udfb3C\udac9\ude19\udae9\udf63\ud80a\udc09", "\000\uc1cb\u571a\u3d83\uad36\u456e\u6021\u6895\u3ba3\u89cb\u394a\u37e4\u03d4\u2247\u0207\ub855", "\ud97d\udcec\udb46\udf4c\uda12\udeb4\ud832\ude65\u732a\udb6e\udc96\udb5a\udce5\ud885\udebe\uda33\udf9f\udb64\ude32\udb9b\udd9b\uda5b\ude36\u095c\udaa6\uddc2\ud831\udf71\udbd9\udd46\uda65\udc33\udbd6\udf73\ud9f2\udd42\udb28\ude2a\ud977\ude20\uda4d\udea4\ud923\udc20\udb14\udf50\ud9f5\udf0c\uda2a\udfe9\ud8b6\udca0\udbeb\udda2\udb28\uddcd\ud8db\udf20\ud821\udea7\u293c\ud9e9\udcf8\ud991\udea7\ud984\udece\uda5d\uddd7\udbc8\udd7e\udacc\udc69\uda98\udfac\udb42\uddcd\ud91f\udd33\udb35\udff7\udb6e\udcae",
        -4, 25837, -1188850773, -8146991298218080694L, -60028L, true, false, (char) 49183, (char) 45129,
        Double.longBitsToDouble(0x3feb0efe1aaeb39cL), Double.longBitsToDouble(0x3feeabf5aa77d211L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb39|-\ude86|-\uda26|-\udccc|-\ue7b1|-\ud897|-\udd06|-\ud818|-\ude6f|-\ud8f2|-\udf98|-\udbf7|-\udd11|-\ud8b9|-\ude44|-\udb83|-\udea9|-\udb1d|-\udde1|-\ud071|-\015|-\000 <arg>|-\udbde|-\udf9e|-\u5905|-\ud9ad|-\udf01|-\uda06|-\udd90|-\ud884|-\udd47|-\ud862|-\udfb0|-\uda34|-\udd53|-\uda9c|-\udd4d|-\udac8|-\udf59|-\udb04|-\ude12] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 3, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\ud818\ude6f\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\udb83\udea9\udb1d\udde1\ud071\015\000/\udbde\udf9e\u5905\ud9ad\udf01\000\uda06\udd90\ud884\udd47\ud862\udfb0\uda34\udd53\uda9c\udd4d\udac8\udf59\udb04\ude12", "\uc8da\u0be2\u4ca2\u0609\u7de7.\000\uc1cb\u7ea9\u3e2e\uad36\u2e9e\u6021\u0baf", "\uda6c\udf69\udb64\udd1a\ud8f3\udef2\u9eae",
        19, 31829, -509486251, 7455495189591949486L, 17234L, false, false, (char) 46566, (char) 30899,
        Double.longBitsToDouble(0x3feb7521b8bef96aL), Double.longBitsToDouble(0x3fe023be91b9c507L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\u008e\uda25\udfe1\ue7b1\u6988\ud9d0\ude09\000\u8977\ud9cc\udc4d\uda4d\ude3b\000\024\ud86f\udd56\udb74\udd2d\u7541\udb21\uddc0", "\000", "\udb13\udfa6\ud97e\ude26\000\udbec\udece\udb17\udda8\ud817\ude75\ud9af\uddf7\000\000\udac7\udd63",
        59, 42160, 322816667, -3589647558009421806L, 6415L, true, false, (char) 9977, (char) 1876,
        Double.longBitsToDouble(0x3feafa065c5d5a18L), Double.longBitsToDouble(0x3fe64b3f400000e3L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\udb39\ude86\uda26\udccc\udae3\udc65\ud855\udd38\ud8dc\udcbc\ud8f2\udf98\ud9ce\udce2\udbe8\ude94\ud902\ude9e\003\000\ud86f\udd56\023\udb7a\udcca\udb21\ude5a", "!", "\ud862\udfb0\uda1c\ude71\udafe\udcc8\udab2\udf0f\ud832\udf1f\ud817\ude75\ud9af\uddf7\000\ud9b9\udc91\udae9\udf89",
        9, 25971, 46, -1384105920785060197L, 6415L, true, false, (char) 50427, (char) 21235,
        Double.longBitsToDouble(0x3fd6d98d28bab57aL), Double.longBitsToDouble(0x3fe64b3f400c12e3L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 1, "\udb39\ude86\uda26\udccc\udae3\udcd8\ud855\udd38\ud829\udccc\ud8f2\udfb3\ud9ce\udce2\ud8c4\udea2\uda4a\udda1\ud9ef\ude82\014\ud86f\udd56\023\udbad\udeca\udb21\ude5a\ud988\udc1a", "\u811b\u2a68\u03a8\uc7fc\ub86d\u493a", "\ud9af\uddf7\000\ud99b\udc15\udae9\udf89\u922e\ud932\udd6d.\ud8a8\uddde\u883f\uda0d\ude90\udbe8\udcf8\ud80c\udeeb\ud91c\udfb1",
        -1, 23333, -1283743008, 1358498055516782604L, 42153L, false, true, (char) 29630, (char) 40165,
        Double.longBitsToDouble(0x3fd00152c945bf28L), Double.longBitsToDouble(0x3fb4ee47a81caa98L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud801\udf0f\uda72\udf14\uda80\udc88\udbdd\ude02>\ud8f2\udf98\udac5\udcaf\uda9a\uded4\ud841\udfe4\udbcf\udd8e\uda01\udfdf\ud989\uddad", "\u7bdc", "\000\ud8ff\udead",
        35, 38946, 16024088, -648518345377663307L, 62886L, false, false, (char) 41499, (char) 6802,
        Double.longBitsToDouble(0x3fe13730e93421a0L), Double.longBitsToDouble(0x3fd2991e707539e8L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=null\012",
        Z.run(T, 2, 4, 3, 0, "\udb39\udecc\ud8f5\uddff\uda4b\ude6e\udbdd\ude02>\ud8f2\udf98\030\000\ud841\udf64\udbcf\udd8e`\000", "\u4686", "\000",
        -5, 71591, 1906212946, 68822933908226048L, 97329L, false, true, (char) 26943, (char) 41499,
        Double.longBitsToDouble(0x3fe0c0000226e61dL), Double.longBitsToDouble(0x3fd34d3b423773ceL)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=null\012",
        Z.run(T, 2, 4, 3, 0, "\udb24\udecc\ud8f5\uddff\uda4b\ude6e\udbdd\ude02>\ud8f2\udf98\udac5\udcaf\uda9a\uded4\ud841\udfe4\udbcf\udd8e`\000", "\uc5ec", "\000",
        -5, 71591, 1906212946, 68822933908226048L, 97329L, false, true, (char) 29, (char) 41499,
        Double.longBitsToDouble(0x3fe0c0000000e61dL), Double.longBitsToDouble(0x3e21bb9000000000L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 5, 3, "\udb39\udecc\ud8f5\uddff\ud954\udeb4\udb5d\udc02\udbd9\udecb\ud8f2\udf98\udac5\udcaf\uda9a\uded4\ud811\udeab\ud8d5\uddde\ud880\udd0e\012", "\u4686", "\ud9d5\udfe8",
        -5, 71591, 1906212946, 68822933908226048L, 97329L, false, true, (char) 26943, (char) 41499,
        Double.longBitsToDouble(0x3fe0c0000426e61dL), Double.longBitsToDouble(0x3fdc5c31804b0884L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\uda45\udcb0\uda3b\ude22\udbe7\udf02\032\ud8f2\udf98\ud9ce\udce2\uda7f\ude9e\udb28\udebd\udb4e\udcfa\ud8d1\ude48\udbe8\udfb3", "\ub92e", "\000",
        -5, 71591, 1897065726, 6057541713008793856L, 97329L, true, true, (char) 61071, (char) 41499,
        Double.longBitsToDouble(0x3fe0c0000226e61dL), Double.longBitsToDouble(0x3fe7769da7989595L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud984|-\udc4b|-\ud882|-\udf23|-\ud855|-\udd68|-\udb39|-\ude61|-$|-\ud8f2|-\udf98|-\ud9ce|-\udce2|-\uda7f|-\ude9e|-\ud8fb|-\udc47|-\uda5f|-\udfea|-\ud816|-\uddca|-\005] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 0, "\ud984\udc4b\ud882\udf23\ud855\udd68\udb39\ude61$\ud8f2\udf98\ud9ce\udce2\uda7f\ude9e\ud8fb\udc47\uda5f\udfea\ud816\uddca\005", "\u0636", "\000",
        -5, 71591, 1906240766, 56326984258551808L, 97329L, true, true, (char) 61071, (char) 55880,
        Double.longBitsToDouble(0x3fe0c6200226e61dL), Double.longBitsToDouble(0x3fe7769da7989595L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\udbb9\udf25\ud921\udfc9\udad9\udfc9\uda33\udc21\021\ud8f2\udf98\ud9ce\udce2\uda7f\ude9e\uc146\ud9ea\udf99\uda58\udca7", "\u5f8a\u4686", "\uda30\ude70\udbb6\udfd9\ud948\udec7\udbda\uddbd\uda16\udd6c\ud88f\ude79\uda00\udefd",
        56, 87701, -107019392, 5485804573893137237L, -53646L, true, true, (char) 23220, (char) 0,
        Double.longBitsToDouble(0x3fd67000011d9b1eL), Double.longBitsToDouble(0x3fb4640d82ed2910L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 5, "\udad1\udffe\007\u1d44\ud9b1\udd24\u73b7\ud9fb\udff4\u0092\udb07\uddb7\ud8cd\udf83\ud833\uded5\ud80e\udf24\ud930\udc28\udaee\uddcc\udaca\udddf\udb0a\udf9c\uda1a\uddec\ud9d9\udd85\uda6b\ude55\ud94d\udd30\ud9ee\udd6d\uda86\udf00\udafa\udc83", "\u6c22\ube20\u2517\u60e7\u2adb\uc472\u8d97\u4f00\u4909\u2f8d\ub7b5\u7888\ud07e\u5908\u7d9d\u3e62\u6d5f\u19ba\u3640\u53cc\u016e\u91d3\uc3cd\ud498\u5597", "\ud9b8\udc50\u6730\udb38\ude85\ue0c4\ud9c6\ude6d\udac1\udca9\ud978\udcfd\ud945\udc20\uf722\uda61\ude1a\ud992\udfd2\ud85b\udd2f",
        10, 46849, -569497591, 4735259007673375019L, -67536L, false, true, (char) 33451, (char) 17344,
        Double.longBitsToDouble(0x3fa7070e110e87d0L), Double.longBitsToDouble(0x3feab09402808e2fL)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud9db|-\udc44|-\004|-\u1d44|-\ud9b1|-\udd24|-\u73b7|-\ud9fb|-\udf97] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\ud9db\udc44\004\u1d44\ud9b1\udd24\u73b7\ud9fb\udf97", "\u7788\ud1f4\u5c6a\ud601", "\uda90\udc02\ud8cc\udda1\udb0f\udc1d\udae5\udc4a\ud9b9\udf04\ud89c\udc93",
        42, 64423, 1806670368, 1800899130378802351L, 85495L, true, true, (char) 4442, (char) 27017,
        Double.longBitsToDouble(0x3fedd51accaa277fL), Double.longBitsToDouble(0x3fb193a8edab6420L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udad1|-\udffe|-\007|-\u1d44|-\ud9b1|-\udd24|-\udb44|-\udcd1|-\ud81f|-\udf58|-\uda57|-\udd12|-\udae9|-\udc18|-\uda21|-\udf8e|-\ud833|-\uded7|-\ud80e|-\udf24|-\ud930|-\udc28|-\udb5f|-\udd3b|-\udba9|-\ude40|-\uda94|-\udd02|-\ud8cc|-\uddeb|-\udb6f|-\ude0d|-\uda4b|-\udc1b|-\ud94d|-\udd30|-\ud9ee|-\udd6d|-\uda86|-\udf00|-\udafa|-\udc83|-\uda4a|-\udd78|-\ud9f5|-\uddaf|-\u67e2|-\udb03|-\udfac|-\udab8|-\udc97|-\udb30|-\uda8c|-\udc2c|-\ud9b9|-\udfe5|-\udae4|-\udf79|-\udbe5|-\udd34|-\ud931|-\udd33|-\udcef|-\udba8|-\udd98|-\ud869|-\udc31|-\ud900|-\ude32|-\ud9ed|-\udb16|-\udfcb|-\udae3|-\udfb4|-\uda8f|-\ude69|-\ud8c5|-\udd69|-\udbb4|-\ude9d|-\uda77|-\udc72|-\udb4c|-\udc98|-\udf25|-\ud8f0|-\uddf2|-\uda06|-\uded6|-\udbda|-\udc6c|-\ud897|-\ude70|-\uda5f|-\udeee|-\ud9b8|-\udc50|-\u6730|-\udbb9|-\ude6a... |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 3, "\udad1\udffe\007\u1d44\ud9b1\udd24\udb44\udcd1\ud81f\udf58\uda57\udd12\udae9\udc18\uda21\udf8e\ud833\uded7\ud80e\udf24\ud930\udc28\udb5f\udd3b\udba9\ude40\uda94\udd02\ud8cc\uddeb\udb6f\ude0d\uda4b\udc1b\ud94d\udd30\ud9ee\udd6d\uda86\udf00\udafa\udc83\uda4a\udd78\ud9f5\uddaf\u67e2\udb03\udfac\udab8\udc97\udb30\udd6d\uda8c\udc2c\ud9b9\udfe5\udae4\udf79\udbe5\udd34\ud931\udd33\udae4\udcef\udba8\udd98\ud869\udc31\ud900\ude32\ud9ed\udd34\udb16\udfcb\udae3\udfb4\uda8f\ude69\ud8c5\udd69\udbb4\ude9d\uda77\udc72\udb4c\udc98\ud8cc\udf25\ud8f0\uddf2\uda06\uded6\udbda\udc6c\ud897\ude70\uda5f\udeee\ud9b8\udc50\u6730\udbb9\ude6a\udb82\udd5e\ud9c6\ude6d\udac1\udca9", "\u75a5\uc5d4\u1113\u4c80\u147d\u9700\u2bed\ua2dd\u8833\ua885\u51db\uca1f\u0a55\ubda8\u4850", "\udb65\udcd3\udbd4\udf16\uda3a\udfb7\ud8fe\uddd3\uda58\udea6\uda61\udf7b\ud92b\udf0a\ud983\udf53\udbb1\udf3f\ud90e\udda8",
        56, 47146, -774144951, -2498633186497924912L, 18730L, true, true, (char) 44498, (char) 54052,
        Double.longBitsToDouble(0x3fdd69bbb215db92L), Double.longBitsToDouble(0x3fcf6409851a1c58L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 5, 4, "", "\u8fe8\u8d88\u6c3e\ucf47\u9297\u39aa\u42ae\u06d1\u626d\u641d\u5042\ud053\ub627\u877e\u20b5\u2e02\uc445\u2ec3\u6344", "\uda1f\udee3\ud859\ude4c\ud8bb\udcc8",
        19, 93913, 470357528, -8956407552143045906L, -44936L, true, false, (char) 24, (char) 0,
        Double.longBitsToDouble(0x3deaed0000000000L), Double.longBitsToDouble(0x3fde80000779a01cL)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 1, 4, "", "\u8f73\u8d88\ubca0\u9748\ubfad\u4061\u42ae\u06d1\ub8b2\u8004\u5042\ud053\ub627\u207f\u20b5\ub6a4\uc445\u2ec3\u6344", "\ud865\udf6c\ud867\udd43\ud8bb\udcc8",
        48, 93913, -434301416, -8956511726574810386L, -44936L, false, true, (char) 2, (char) 0,
        Double.longBitsToDouble(0x3deaed0000000000L), Double.longBitsToDouble(0x3fde80000379a01cL)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 0, "", "\000\u23e4", "\ud855\udf1d\uda9a\udddd\udacc\ude07\udbaf\udcb6\uda56\ude46\ud863\udf01\ud8bc\udccd\000\uda75\ude57\uda64\udc49\udb6b\udd13\udbf1\uddc5\ud847\udd4f\ud884\udd47\ud862\udfb0\ud97e\ude26\ud896\udd16\uda5b\udc45\ud867\udda0\ud8bb\udcc8\ud9aa\ude31\udb8a\ude57\ud9b9\udc91",
        0, 93054, 1640274371, -5734989626128463065L, -100000L, false, false, (char) 26, (char) 8680,
        Double.longBitsToDouble(0x3fdbcd00e7638cfcL), Double.longBitsToDouble(0x3febee674ea17e51L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud840\udf9a\uda18\udea9\u22e4\udbe4\udc44\udb4a\ude34\u9e55\ud80f\ude3f\udaef\udc54", "\u293b\u4686\u559a\ub573\u7edd\ua99c\ua7ea\u0348\u2873\u18a6\u62ea\u8b52\u55e6\ua9c9\u267f\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\uda0d\ude90\ud9de\udd53\ud9c5\udcf2\ud923\uddd4\ud932\udfb8\udbe7\udd75\ud9e2\ude7b\u00c9\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 91553, -1954767613, -3415875843434512192L, 99341L, true, false, (char) 19, (char) 0,
        Double.longBitsToDouble(0x3fee3aada108c189L), Double.longBitsToDouble(0x3fca9c969310c704L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 5, "\udb39\ude86\uda25\udfef\ue7b1\ud899\ude06\ud9ff\udcda\ud83b\ude1d\udb9d\udc0e\026", "\ucd9a\u0d34\uab66\u293b\ud107", "\ud83b\udc22",
        0, 81799, 1906211359, 3599645042929094383L, -35360L, true, true, (char) 19445, (char) 27569,
        Double.longBitsToDouble(0x3fe401bda777cee3L), Double.longBitsToDouble(0x3fe172d190b1f23bL)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 5, "\udb39\ude86\016\ue7b1\ud899\ude06\ud9fc\udcde\ud83b\ude1d\udb9d\udc0e\026", "\ucd9a\u0d34\uab66\u293b\ud107", "\ud88b\udff3",
        -5, -1000, 1906240766, 7851043092021942816L, -100000L, false, false, (char) 5656, (char) 28739,
        Double.longBitsToDouble(0x3fe771bda777cee3L), Double.longBitsToDouble(0x3fe172d430b1f23bL)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud88b\udcbe\uda26\udccc\ub7ac\udb0c\udef4\udad0\ude53\uda08\ude04\ud81a\udd4d<\udbed\udc55\ud80f\ude3f\udaae\udc04", "\u2917\ub997\000\u120e\u2b9f\u483a\u2ec3\u93f2\u533a\u57c1\uabc4\u6519", "\ud9ad\udf19\ud9b9\udc91\ud975\udd6e\ud80a\udc09\udaad\ude18\ud90e\udd5e\ud966\udf53\udab6\udf0e\ud804\udfc1\ud907\udf58\ud8e1\udcbf\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, 183354502676480L, -97632L, true, false, (char) 41520, (char) 2875,
        Double.longBitsToDouble(0x3fc81a0fb1eb2e9cL), Double.longBitsToDouble(0x3f49d9f370000000L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udab7\uddb4\ud9cc\ude9a\ud91d\ude83\u0088\000*\ud8d8\udc0c\ud8a0\udcd6\ud9dc\udc31\ud89c\udc04\udb01\uddd5", "\u1197\u2080\uc18b\u120e\u4e3e\u483a\u2ec3\u03a8\u533a\u18a6\ua5ce\000", "\ud91d\ude43\ud9b9\udd44\u6859\ud51b\udaad\ude18\ud90e\udd5e\ud946\udd53\udab6\udf0e\udaad\udf20\udbe4\udd96\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, 1667359641559891968L, -97632L, true, false, (char) 41520, (char) 35713,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3f49d9e000000000L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb39\ude86\uda26\udccc\ud91d\ude83\u0088\000*\ud968\udcd4#\uda92\udc08\ud80f\udd7d\udaae\udc04", "\u2917\u3907\000\u120e\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\u2f95\000", "\ud994\ude2a\ud9b9\udc91\u8a26\ud51b\udaad\ude18\ud90e\udd5e\ud946\udd53\udab6\udf0e\ud90c\udd66\udbe4\udcf6\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, 183354502676480L, -97632L, true, false, (char) 41520, (char) 35713,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3f49d9e000000000L)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\uda26\udccc\ud91d\ude83\u0088\uda16\udf4b%\ud968\udcd4#\uda92\udc08\ud80f\udd7d\ud8a5\udca9", "\u2917\uc32d\u2397\u9aff\u6326\u9712\u8f95\ua181\uaa3d\u9825\u0510\000", "\ud994\ude2a\ud9b9\udc91\u8a73\ud51b\uda47\udca5\ud90e\udd5f\ud946\udd53\udab6\udf0e\ud90c\udd66\ud86a\udcf9\ud9c5\udcb1\ud863\uddd4\ud932\udfb8\udbe7\udd75",
        28, 40977, 1871258111, 183354502676480L, -97632L, true, false, (char) 41520, (char) 30526,
        Double.longBitsToDouble(0x3fc81a1311eb2e9cL), Double.longBitsToDouble(0x3f49d9e000000000L)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\ud9d4\udc9a\ud8ef\udc86\ud9ca\ude4d@\000\000\000/", "\000\000\u4777\u2ec3", "\uda9c\udd4d\udac8\udf59\uda3b\udd2e",
        8, 26960, 67, 8187065916492288L, -18019L, false, false, (char) 0, (char) 41318,
        Double.longBitsToDouble(0x3fd2794550a3206cL), Double.longBitsToDouble(0x3fb942c893f02088L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 1, "\ud9ce\udf11\ud8bf\udfb8\ud8e2\udd95\ud9ff\uddce\udb22\ude89\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\udb83\udea9\u0094\000\udb7e\udf0e\ud805\udc74\031\udbde\udf9e\u5921\uda03\udf66\ucaf1\udb17\udf78\ud8ac\uddf2\uf5e9\ud840\ude96\ud949\udee4\ud9a1\udc0f\ud9ad\udd0e", "\u15e9\ud2c6\u435f\ua0b8\u6f0f\ubd55\u9666\uc1cb\ub8a9\u83e4\uad36\uc655\u2fca", "\ud97f\udd66\uda42\ude95",
        9, 61440, 965441257, -8421087826301841881L, -87040L, false, false, (char) 64533, (char) 16804,
        Double.longBitsToDouble(0x3fe79065932af6a9L), Double.longBitsToDouble(0x3fce400005c2c524L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ued29\uda26\udccc\ue7b1\udbe8\udfd0\034\ud8f2\udf98\udbf7\udd11\ud8d2\udfb0w\000\000\000\000/\ud823\ude30\005\ud9ad\udf01\000\ud8f6\udc08\udb1e\ude31\u33b5\ud8e4\uddd5\000\000\udb04\ude12", "\u2008\000\000\u9fca\ubb0d", "",
        56, 19424, 186802257, 293015885738334846L, -100000L, false, true, (char) 35, (char) 0,
        Double.longBitsToDouble(0x3fef226800000000L), Double.longBitsToDouble(0x3fe74f41de06fc17L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\000\ud87d\udf31\ue826\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\udaac\ude7e\ub9b6\000\000\000\uda99\udceb\u00a9\u0e21\005\ud9ad\udf01\000\ud8f6\udc08\u8c57\035\uf641\udb49\ude4e\ud84c\udcc0\uda9d\udc35", "C\000\000\u3603\u880e\000\000\uc1cb\ub882\u3d83\uad36\u2e9e\ub4d0\u5db2", "\ud936\ude1b\u37e4\ud973\ude99\u9eae",
        19, 6548, -509486251, -3884847946857037189L, 38196L, false, false, (char) 54560, (char) 8089,
        Double.longBitsToDouble(0x3fe170a084babaf9L), Double.longBitsToDouble(0x3fd5cff105de66a8L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\000\u00eb\000\u6088\000\ud8f2\udf98\udbf7\udd11\ud8b9\ude44w\000\000\000\000\000\000\000\000\000\ud8f6\udc08W\000\000\000\000\u8d23", "", "",
        -5, 92816, 1518780355, 0L, -100000L, true, false, (char) 2951, (char) 56974,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe8d5b000000023L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\000\uda13\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud8b9\ude44w\000\000\000\000/\udaed\udd96\016\ud9ad\udf01\000\uda8e\ude54\ud940\udca4\ud86e\ude61\000\000\udb06\udde2\ud870\ude9e", "\u00e9\000\000\u9fca\ubb0d\000\000\uc1cb\ub882\u3d83\uad36\u6fe4\u0f3e\u604b", "\ud936\ude1b",
        3, 61440, -65571095, -2188470116593070347L, -50176L, false, false, (char) 0, (char) 512,
        Double.longBitsToDouble(0x3e3957b548000000L), Double.longBitsToDouble(0x3fe00000039fa828L)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udac2\udc00\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud8b9\ude44w\000\000\000\ud83c\udffe\033\udb7d\udd1e\u95fd\ud9ad\udf01\000\ud8f6\udc08\u8c57\000\000\ud826\udc93\u5000\udb04\ude12", "C\000\000\u9fca\ubb0d\000\000\uc1cb\ub882\u3d83\u6d36\u5e49\u0f53\u604b", "\ud936\ude1b",
        3, 61440, -65571095, -2188470116593070347L, -50176L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3957b548000000L), Double.longBitsToDouble(0x3e2f20a000000000L)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\000\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud8b9\ude44w\000\000\000\000/\ud823\ude30\005\udb45\udc35\000\ud8f6\udc08\u8c57\udb00\udc14\014\000\000\udb04\ude12", "C\uae12\017\uba49\u7a22", "",
        56, 19424, 186802257, 293015885738334846L, -100000L, false, true, (char) 35, (char) 0,
        Double.longBitsToDouble(0x3fef24e008000000L), Double.longBitsToDouble(0x3fe74f41de06fc17L)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\uda26\udccc\ue7b1\u6160\ud8a3\udcae\udbe9\ude79\udbf7\udd11\ud9c8\udd8b\udb83\udea9\u0094\000\000\uda35\udd5a\uda49\udea8\udbde\udf9e\u5905\uda17\udd5c\ud871\udd1a\uda06\udd90\ud884\udd47\ud862\udfb0\030\uda9c\udd4d\udac8\udf59\ud88b\udd07", "\uc7bb\u663a\u5580\u53fb\ubb0d\uaa40\u00b4\uc1cb\ub8a9\u3d83\u8788\u2ec7\u66a1\u17ad\ubb1e\u1e3a\u394a\u37e4\u03d4\u2247\u0207\ub855\u0757\ub800\u6b10\u1332\u406c\u724f\u732a\u9b19\u48bb\ube69\u1919\u090a\ud6f9\uaa1b\u4ae0\u821a\ua48d\uc48b\u3b19\uab9e\u0475\u8c17\ua4bf\u7cb2\u30da\uc55a\u89c6\u36b1a\uc484\ub9dc\u2136\u533e\ub83f\ub90a\u034d\u468b\ud748\u6f77\u6ef5\u7db9\u639f\ua46d\u2393\ub043\u8bf2\u6b71\u79d2\uc1a3\u5e9c\u8c09\ud1bb\u73c6\ud2ed\u0879\u5238\u8c8a\uabda\uca31\u3d1d\u1230\u65de\u55af\ud4e7\ub9df", "\udb5b\udede\ud823\udf90\udabb\udea2\udafa\ude03\uabd7\ud8e8\udc74\udad0\udf9e\ud8af\udc8b\u8555\udb31\udede\uda6e\udcea\ud8f9\udfa9\ud907\udf21\udbb5\udefd\udba5\udf6e\uda15\ude40\ubecf\uda74\udce2\ud8ee\udff6\udaee\udf23",
        16, 77100, -495587564, 504873592055957764L, 87665L, false, true, (char) 11148, (char) 1506,
        Double.longBitsToDouble(0x3fb77a76755b0250L), Double.longBitsToDouble(0x3fe7d9438b98c829L)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude86\uda26\udccc\udb5c\udfc3\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud98c\ude02\udb83\udea9\ud9b5\udcce\ud978\udcd0\udb0f\udf13\ud8c6\udd17\030\udb58\ude57\udb84\udfd4\ud9ad\udf01\000\udaef\ude9a\ud897\udfdb\ud862\udfb0\030\uda9c\udd4d\udac8\udf59\ud88b\udd07", "C\u663a\u9510\u7b17\u1b9d.\ub900\uc1cb\u68bb\ucae0\uad36\u9e74\u5364\u0b70", "\ud978\uddb0\u8db5\ud973\udf6e\u9eae",
        19, 31829, -509486251, 7455495189251031214L, -76527L, false, false, (char) 27092, (char) 0,
        Double.longBitsToDouble(0x3fdf20a00945dc72L), Double.longBitsToDouble(0x3fe0c91e73efdcc4L)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb39\ude18\ud972\udd52\ud81b\udc8b\ud897\udd06\udb32\ude22\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\ud983\udd49\023\ud971\uded8\036\000/\udbde\udf9e\u5905\ud9ad\udf01\udb3b\udd5c\ud9ec\ude59\ud884\udd47\ud862\udfb0\ud97e\ude26\uda9c\udd4d\udac8\udf59\udb04\ude12\ud833\ude0c\ud8a9\udfb3C\udac9\ude19\udae9\udf63\ud80a\udc09", "\000\uc1cb\u571a\u3d83\uad36\u456e\u6021\u6895\u3ba3\u89cb\u394a\u37e4\u03d4\u2247\u0207\ub855", "\ud97d\udcec\udb46\udf4c\uda12\udeb4\ud85a\ude65\u732a\udb6e\udc96\udb5a\udce5\ud885\udebe\uda33\udf9f\udb64\ude32\udb9b\udd9b\uda5b\ude36\u095c\udaa6\uddc2\ud831\udf71\udbd9\udd46\uda65\udc33\udbd6\udf73\ud9f2\udd42\udb28\ude2a\ud977\ude20\uda4d\udea4\ud923\udc20\udb14\udf50\ud9f5\udf0c\uda2a\udfe9\ud8b6\udca0\udbeb\udda2\udb28\uddcd\ud8db\udf20\ud821\udea7\u293c\ud9e9\udcf8\ud991\udea7\ud984\udece\uda5d\uddd7\udbc8\udd7e\udacc\udc69\uda98\udfac\udb42\uddcd\ud91f\udd33\udb35\udff7\udb6e\udcae",
        -4, 25837, -1188850773, -8146991298218080694L, -60028L, true, false, (char) 49183, (char) 45129,
        Double.longBitsToDouble(0x3feb0efe1aaeb39cL), Double.longBitsToDouble(0x3feeabf5aa77d211L)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 4, "\006\000\000\ud87f\udc7e\udb32\ude22\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\ud983\udd49\023\000\036\000\000\udbde\udf9e\u5905\ud9ad\udf01\udb3b\udd5c\ud9ec\ude59\ud884\udd47\ud862\udfb0\ud97e\ude26\uda9c\udd4d\udac8\udf59\udb04\ude12\ud833\ude0c\ud8a9\udfb3C\udac9\ude19\udae9\udf63\ud80a\udc09", "\000", "Q",
        -5, 99120, -548446496, 1297180190646202271L, 96608L, true, false, (char) 64029, (char) 57760,
        Double.longBitsToDouble(0x3feaa9174d4b37f3L), Double.longBitsToDouble(0x3fc5cceeef4b010cL)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb39|-\ude86|-\uda26|-\udccc|-\ue7b1|-\ud897|-\udd06|-\ud818|-\ude6f|-\ud8f2|-\udf98|-\udbf7|-\udd11|-\uda7e|-\udfdb|-\u01c8|-\udb5e|-\udfce|-\uda33|-\udd3c|-\015|-\000 <arg>|-\udbde|-\udf9e|-\u5905|-\ud9d3|-\ude64 <arg>|-\uda06|-\udd90|-\ud884|-\udd47|-\ud862|-\udfb0|-\uda34|-\udd53|-\uda9c|-\udd4d|-\udac8|-\udf59|-\udb04|-\ude12] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 3, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\ud818\ude6f\ud8f2\udf98\udbf7\udd11\uda7e\udfdb\u01c8\udb5e\udfce\uda33\udd3c\015\000/\udbde\udf9e\u5905\ud9d3\ude64/\uda06\udd90\ud884\udd47\ud862\udfb0\uda34\udd53\uda9c\udd4d\udac8\udf59\udb04\ude12", "\uc8da\u0fe2\u4ca2\u0609\u7de7.\000\uc1cb\u7ea9\u3e2e\uad36\u2e9e\u6021\u0baf", "\uda6c\udf69\udb64\udd1a\ud8f3\udef2\u9eae",
        19, 31829, -509486251, 7455495192527962286L, -80454L, false, false, (char) 27076, (char) 0,
        Double.longBitsToDouble(0x3fdf20a00945dc72L), Double.longBitsToDouble(0x3fe0c91e73efdcc4L)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\ud818\ude6f\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\udb83\udea9\udb1d\udde1\ud071\015\000/\udbde\udf9e\u5905\ud9ad\udf01\000\uda06\udd90\ud884\udd47\ud862\udfb0\uda34\udd53\uda9c\udd4d\udac8\udf59\udb04\ude12", "\uc8da\u0be2\u4ca2\u0609\u7de7.\000\uc1cb\u7ea9\u3e2e\uad36\u2e9e\u6021\u61ae", "\uda6c\udf69\u00e0\ud8d6\uddeb\u9eae",
        19, 31829, -509486251, 7455495189591949486L, 17234L, false, false, (char) 46566, (char) 30899,
        Double.longBitsToDouble(0x3feb7521b8bef96aL), Double.longBitsToDouble(0x3fe023be90b9c507L)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb39|-\ude86|-\u00eb|-\000|-\ud8f2|-\udf98|-\u00dc|-\ud8c4|-\udea2|-\uda4a|-\udda1|-\020|-\udb1d|-\udd4d|-\023|-\udbad|-\udeca|-\udb01|-\udf5a|-\ud988|-\udc1a] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\udb39\ude86\u00eb\000\000\000\ud8f2\udf98\u00dc\ud8c4\udea2\uda4a\udda1\020\000\udb1d\udd4d\023\udbad\udeca\udb01\udf5a\ud988\udc1a", "", "\ud862\udfb0",
        16, -981, 1641063756, -3538153282371490501L, -100000L, false, true, (char) 58908, (char) 0,
        Double.longBitsToDouble(0x3fa7f10000000000L), Double.longBitsToDouble(0x3fe80000069beccaL)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 1, "\udb39\ude86\uda26\udccc\udb6c\udd76\ud855\udd38\ud829\udccc\udb8c\udfc0\udad3\udcbe\ud8c4\udea2\ud944\ude0f\ud9ef\ude82\021\ud86f\udd56\023\udbad\udeca\udb21\ude5a\ud988\udc1a", "\u811b\u2a68\u03a8\uc7fc\ub86d\u493a", "\ud9af\uddf7\000\ud99b\udc15\udae9\udf89\u917f\ud932\udd6d.\ud8a8\uddde\ud8e8\udc3e\uda0d\udee5\udbe8\udcf8\ud80c\udeeb\ud91c\udfb1",
        -1, 23333, -1970133168, -5328091272096699638L, 42153L, true, true, (char) 50372, (char) 7240,
        Double.longBitsToDouble(0x3fec4be6bca20d3aL), Double.longBitsToDouble(0x3fb4ee4795325130L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 1, "\udb39\ude86\uda26\udccc\udae3\udcd8\ud855\udd38\ud829\udccc\ud8f2\udfb3\ud9ce\udce2\ud8c4\udea2\ud8c5\udc84\ud85c\udf2c@\ud86f\udd56\023\udbad\udeca\udb21\ude5a\ud988\udc1a", "\u811b\u2a68\u03a8\uc7fc\ub86d\u493a", "\ud9af\uddf7\000\ud99b\udc15\udae9\udf89\u922e\ud932\udd6d.\ud8a8\uddde\u883f\uda0d\ude90\udbe8\udcf8\ud80c\udeeb\ud91c\udfb1",
        -1, 23333, -1283743008, 1358498055516782604L, 42153L, false, true, (char) 29630, (char) 40165,
        Double.longBitsToDouble(0x3fd00152c945bf28L), Double.longBitsToDouble(0x3fb4ee47a81caa98L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 1, "\udb39\ude86\uda67\udcec\udae2\udfec\udb4f\udc55\000\033\000\000\000\000\000\ud86f\udd56\023\udbad\udeca\udb21\ude5a\ud988\udc1a", "\u811b\u2a68\u03a8\uc7fc\ub86d\u493a", "\ud9af\uddf7\000\000\udae9\udf63\u922e\ud932\udd6d.\000\uda84\udda2\uda0d\ude90\udbe8\udcf8\ud80c\udeeb\uda53\udfcd",
        -1, 23333, -1283743008, 1358498056940552204L, 42153L, false, true, (char) 60862, (char) 40165,
        Double.longBitsToDouble(0x3fd00152c945bf28L), Double.longBitsToDouble(0x3fb4ee47a81caa98L)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 2, "\udb24\udecc\ud8f5\uddff\uda4b\ude6e\udbdd\ude02\u513e\ud8f2\udf98\ud821\udeb9\u915d\ud842\udc3a\udbcf\udd8e`\000", "\uc689", "\u40c2",
        -5, 71591, 1906212946, 752977550675743033L, 97329L, false, true, (char) 29, (char) 41499,
        Double.longBitsToDouble(0x3feb898ee000344cL), Double.longBitsToDouble(0x3fe2f800042f5da4L)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\uda7b\udc1d\ud8f5\uddff\u3010\ud9ff\udd52\udbd9\udebd\uc139\udac5\udcaf\uda9a\uded4\ud808\udc55\ud8d5\uddde\ud960\udc9b\012\udb99\udfe2\ud932\udcf7\udb21\ude5a\u5905\uda18\uddf8\ud9d5\udfe9", "\u6efb\uab39", "\uda37\udd12\ud811\udf32\udabe\udee1",
        -5, 98584, -1273455193, 7159491291881773844L, -17739L, true, true, (char) 2275, (char) 40016,
        Double.longBitsToDouble(0x3feef41940a22447L), Double.longBitsToDouble(0x3fc8e8301f943c9cL)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud9db\udc44\004\udbb5\udd3a\ud977\udf1c\u73b7\ud9fb\udf97", "\u770b\u98c5\u30e3\ud601", "\000",
        -5, 44256, -1927494896, -4329865181615688924L, 36248L, true, false, (char) 21769, (char) 59525,
        Double.longBitsToDouble(0x3fc12740400001b8L), Double.longBitsToDouble(0x3fe33bd913baa359L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb37\udf26\udb8c\udf65\udb98\udc58\uda44\udc99\017*\ud90f\udd87\uda3a\udf45\ud9dc\udc31\ud89c\udc04\udb01\uddd5", "\u1197\u153e\u36fa\uc06c\ub821\u570e\u7edf\ud3e9\u533a", "\udac5\udd23",
        25, -176, -1810336284, -6545717192044802581L, 30877L, false, false, (char) 17623, (char) 54436,
        Double.longBitsToDouble(0x3fd0094551e3c074L), Double.longBitsToDouble(0x3fb942c00f402888L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 5, 1, "\udb39\ude86\ud9c1\udcf4\udbd4\ude19\udb12\udd73\uda16\udf4b%\ud968\udcd4\u2c2a\ud878\udcf7\ud82d\udd1f\ud844\udcfe", "\u1f98\uc31f\u2397\u9aff\u6326\u9712\u382f\u521e\ua5cc\u69f1\u47b9\000", "\ud99b\uddba\ud9b9\udc91\u8a73\ud51b\uda5f\udda5\ud90e\udd5f\ud8df\udf52\udab6\udf0e\ud90c\udd66\ud86a\udcf9\ud9c5\udcb1\ud863\uddd4\ud932\udfb8\ud912\udefc",
        -2, 13049, 1871258111, 1467512408807688007L, -59704L, false, false, (char) 20824, (char) 45089,
        Double.longBitsToDouble(0x3f49d9e1cc000000L), Double.longBitsToDouble(0x3fd2ee2bf5d87e4eL)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb35\udc1d\udb13\udde9\ud8ce\udfb5\u6749\uda16\udf4b%\ud9cf\udf88\013\uda92\udc08\ud80f\ude75\ud8c4\udc32", "\ub47a\u38e0\u039d\u9f8d\u75e1\u9712\u8f95\ua181\uaa3d\u9825\u052a\000\u172e\u2ec2\u8d26\u42c6\ucd88\u55ca\u9ee5\ud1dd", "\ud90c\udd66\ud86a\udcf9\ud9c5\udcb1\ud863\uddd4\ud932\udfb8\udbe7\udd75\ud918\ude76\ud986\udc20\udab0\udc91\ua6d6\udbd2\udd29\ud97a\udfab",
        53, 35507, 1987878248, -3415979485015080768L, -100000L, false, true, (char) 33394, (char) 49747,
        Double.longBitsToDouble(0x3feebcd3c8b6a54eL), Double.longBitsToDouble(0x3fed67dce00480bfL)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 5, 2, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\ud9d4\udc9a\ud8ef\udc86\ud9ad\udd9f\ud99a\ude45\013\000\uda7e\udd1e\udb36\uddb4\ubee8\u7baf\000\000\uda06\udd90\ud884\udd47", "\u8a36\u2925\uce0b", "C\udac9\ude19\udae9\udf63\ud831\udf18\udadd\udd18.\000\udab6\udf0e\uda0d\ude90\udbe8\udcf8\ud93c\udca2\ud9ff\udec2\udaaa\ude86\ud83a\udec6",
        3, 62806, 1111578681, 5953256613572545837L, 82874L, false, true, (char) 34754, (char) 33570,
        Double.longBitsToDouble(0x3fed774be6554aacL), Double.longBitsToDouble(0x3fdfc3788963c80cL)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud9ee\udf11\ud8bf\udfb8\ud8e2\udd95\udbae\udf85\udad0\udd0c\ud8ff\ude98\udbf7\udd11\ud8b9\ude44\udb83\udea9\u0094\000\udb7e\udf0e\ud805\udc74\031\udbde\udf9e\u5921\uda03\udf66\ucaf1\ud8a1\udd3e\ud8ac\uddf2\uf5e9\ud840\ude96\uda37\udfdb\ud9a0\udff7\ud9ad\udd0e", "\u4f18\u3029\u57d8\ua0b8\ucbd6\ubd55\ud066\uc1cb\ub8a9\u83e4\u1b8a\u176c\u6f34", "\ud97f\udd66\uda18\udc95\ud86f\udc13\ud973\uded8\ud868\ude4d\udb8a\ude59\udac2\udc35\udb62\ude04\udbe6\udf78\ud97d\udcec\ud9d4\udf54\uf741\udb12\udc7a\ud96b\udd30\ud9b8\udf15\uda4e\uddfd\ub934\uda14\udf66\ud9a2\udf1b\udaf9\udc25\uda35\ude28\ud959\udd2c\ud907\udec8\uda0b\udf67\udb5c\uddc8\uda87\uddcd\udb2b\udc4b",
        30, 62897, -1676433977, 2964406040274476501L, 14579L, true, false, (char) 50600, (char) 62830,
        Double.longBitsToDouble(0x3fd61a22d8bdc4b8L), Double.longBitsToDouble(0x3fdd078097790542L)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udac2\udcec\uda26\udc07\ue7b1\ud99e\udc2a \ud8f2\udf98\udbf7\udd11\ud8b9\ude44w\000\000\000\ud83c\udffe\033\udb7d\udd1e\u95fd\ud9ad\udf01\000\ud8f6\udc08\u8c57\000\000\ud826\udc93\u5000\udb04\ude12", "C\000\000\u9fca\ubb0d\000\000\uc1cb\ub882\u3d83\u6d36\u5e49\u0f53\u604b", "\ud936\ude1b",
        3, 61440, -65571095, -2188470116593070347L, -50176L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3957b548000000L), Double.longBitsToDouble(0x3e2f20a000000000L)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udac2\udc00\uda26\udccc\ue7b1\ud897\udd06\035\ud914\uddd5\udbf7\udd11\ud8b9\ude44\ud840\ude96\025\000\000\ud83c\udffe\033\udb7d\udd1e\u95fd\ud9ad\udf01\u1884\ud8da\udcce\u8c57\000\000\ud826\udc93\u5000\udb04\ude12", "\u00d6\u7a0c\u8a3f\ua0a8\ubb0d\000\000\uc1cb\ub882\u3d83\u6d36\u5e49\u0f53\u604b", "\ud936\ude1b",
        3, 61440, -65579943, -2188470117373330187L, -100000L, false, false, (char) 38553, (char) 62798,
        Double.longBitsToDouble(0x3fe3254a51f20a00L), Double.longBitsToDouble(0x3fd2c2b57ff02fc8L)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 2, 4, "\ud998\udefe(\000\ud87f\udc7e\udb32\ude22\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\ud983\udd49\ud8e5\udee5\ud919\udd29\udb22\udc82\011\000\udbde\udf9e\u5905\ud9ad\udf01\udb40\udf4b\ud9ec\ude59\ud884\udd47\ud81b\udf6f\ud8bd\udeca\ud873\udc7f\udac8\udef1\udb04\ude12\ud833\ude0c\ud8a9\udfb3\uda37\udcbd\udac9\ude19\udae9\udf63\uda94\udec3", "\000\ub7b9", "\000\udb1f\udc2e\udb3d\udcf2\ud9bd\uddf0\udbe0\udf79\ud9a5\uddf4\ud978\uddb0\udae6\udef0\udbb0\ude65\ud890\udd51\ud8a2\ude5e\udacf\udc2c",
        -5, 96595, -1068436329, -7732051838824358187L, 54695L, true, false, (char) 26176, (char) 12628,
        Double.longBitsToDouble(0x3fe8370b5fccc18cL), Double.longBitsToDouble(0x3fe028d204653b11L)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\006\ud936\ude1b\000\ud87f\udc7e\udb32\ude22\ud8f2\udf98\udbf7\udd11\ud8b9\ude44\ud983\udd49\023\000\036\000\000\udbde\udf9e\u5905\ud9ad\udf01\udb3b\udd5c\ud9ec\ude59\ud884\udd47\ud862\udfb0\ud97e\ude26\uda9c\udd4d\udac8\udf59\ud8e7\udc44\ud833\ude0c\ud8a9\udfb3C\udac9\ude19\udae9\udf63\ud80a\udc09", "\000", "Q",
        -5, 99120, 1500464352, 1297065974580899743L, 96608L, true, false, (char) 28680, (char) 29237,
        Double.longBitsToDouble(0x3feaa9174d4b37f3L), Double.longBitsToDouble(0x3fc5cceeef4b010cL)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb39\ude86\u00eb\000\000\000\ud8f2\udf98\u00dc\ud8c4\udea2\uda4a\udda1\020\000\udb1d\udd4d\023\udbad\udeca\udb01\udf5a\ud988\udc1a", "", "\ud862\udfb0",
        16, -981, 1641063756, -3538153282371490501L, -100000L, false, true, (char) 58908, (char) 0,
        Double.longBitsToDouble(0x3fa7f10000000000L), Double.longBitsToDouble(0x3fe80000069beccaL)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb35\udc1d\udb13\udde9\ud8ce\udfb5\u6749\ud89c\uddd0\011\ud9cf\udf88\013\uda92\udc08\ud80f\ude75\ud8c4\udc32", "\ub47a\u38e0\u039d\u9fe7\u75e1\u9712\u8b6f\ua181\uaa3d\u9825\u9fae\u9765\ucff6\u264d\u8d9f\u42c6\ucd88\u55ca\u9ee5\ud1dd", "\ud90c\udd66\ud86a\udcf9\ud9c5\udcb1\ud863\uddd4\ud932\udfb8\udbe7\udd75\ud918\ude76\ud986\udc20\udab0\udc91\ua6d6\udbd2\udd29\ud97a\udfab",
        53, 35507, 1987878248, 907476157260595205L, -100000L, false, true, (char) 33394, (char) 49853,
        Double.longBitsToDouble(0x3feebcd3c8b6a54eL), Double.longBitsToDouble(0x3fed67dce00480bfL)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udac2|-\udc00|-\uda26|-\udccc|-\ue7b1|-\ud897|-\udd06|-\035|-\u4315|-\udaae|-\udeee|-\ud8b9|-\ude44|-\ud840|-\ude96|-\025|-\000|-\ud83c|-\udffe|-\033|-\udb7d|-\udd1e|-\u95fd|-\ud9ad|-\udf01|-\u1884|-\ud8da|-\udcce|-\u8c57|-\ud826|-\udc93|-\u5000|-\udb04|-\ude12] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 0, "\udac2\udc00\uda26\udccc\ue7b1\ud897\udd06\035\u4315\udaae\udeee\ud8b9\ude44\ud840\ude96\025\000\000\ud83c\udffe\033\udb7d\udd1e\u95fd\ud9ad\udf01\u1884\ud8da\udcce\u8c57\000\000\ud826\udc93\u5000\udb04\ude12", "\u3a56\ub3fc\u767c\ua0a8\ubb0d\000\000\ua005\ub8dd\u3d83\u6d36\u5e49\u0f53\u604b", "\udbc0\udf60",
        5, 61440, -65579943, -2188644939722146571L, -100000L, false, false, (char) 38553, (char) 62798,
        Double.longBitsToDouble(0x3fe3254a51f20a00L), Double.longBitsToDouble(0x3fd2c2b57ff02fc8L)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u4686\u559a\ub999\u2b9f\u483a\u2ec3\u03a8\u533a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af\u9f69\u942b\ua0b8\ubb0d\ud1dc", "\uda0d\ude6f\udbe8\udcf8\ud9c5\udcb1\ud923\uddd4\uda25\udcb0\udbe7\udd75\uda64\ude7c\ud986\udc20\udab0\udc91\udb57\uddd9\udb49\udd14\ud97a\udffe",
        9, 35417, 360488296, -811787604576997220L, 29749L, false, true, (char) 12239, (char) 13698,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 3, "\udb2f\udf3f\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\udddd\uf1ff\000\ud949\udd12", "\u285e\u3481\u1b45\ub9e7\u2b9f\u65ab\000\000\u8200\u7a6c", "\ud833\ude28\ud9af\uddf7\ud9da\udc36\ud9b9\udc91\ud957\udf52",
        59, -1000, -231014400, 775464319235129447L, 6415L, true, false, (char) 17, (char) 35071,
        Double.longBitsToDouble(0x3f9db0f28bab57a0L), Double.longBitsToDouble(0x3fe64b3f42ffd2e3L)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 5, "\udb39\ude86\uda26\udccc\ue7b1\ud899\ude06\uda15\udfb0\ud8da\udfcc\udb26\udf7a\uda9a\ude39\u9e55\ud80f\ude3f\ud949\udd42", "\u293b\u4686\u559a\ub999\u2b9f\u483a\u2ec3\u25be\u517a\u18a6\ub0c5\ubcd7\ube92\u2c37\ub9af\u9f69\u942b\ua0b8\u910f\ud1dc", "\uda0d\ude90\ud9de\udd53\ud9c5\udcf2\ud923\uddd4\ud932\udfb8\udbe7\udd75\uda64\ude7c\u00c9\udab0\udc91\udb57\uddd9\ud99f\udfe1\ud97a\udfab",
        9, 91553, -1954767512, -3415875844216225600L, 71491L, false, false, (char) 17, (char) 0,
        Double.longBitsToDouble(0x3fee3aada2dbc189L), Double.longBitsToDouble(0x3fe16510e2bfbcbbL)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud97c\udff9\022", "\ud0ae\u7301\u1eba\ud4a4\u9ad5", "\ud87d\udd12\udb59\udd18\ud8a8\uddc9\udb21\ude5a\udb62\udc75\udae6\udfcd\uda4b\udc1b\udabe\udd2a",
        19, 66766, 1827963416, -2762258946059867763L, -35259L, true, false, (char) 9801, (char) 52806,
        Double.longBitsToDouble(0x3fea74d67e7070f5L), Double.longBitsToDouble(0x3fee164c3c88acc6L)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 5, 1, "\udb24\ude12\u8ceb\000", "\u96f6\u43f9\u4061\u42ae\u1657\u883a\u8004\u5042\u9654\ub627\u28f5\u20b5", "\ud98c\ude8f\ud862\udfb0\u5b14\ud896\udd16\uda5b\udc45\ud9e9\udc81\ud8bf\ude26\ud9cb\udc41\ud85e\udf52",
        44, 95490, -823964946, 9163172153062059138L, -99919L, false, false, (char) 11, (char) 60698,
        Double.longBitsToDouble(0x3fde80000379a01cL), Double.longBitsToDouble(0x3fecaf07c1e76e39L)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 5, 0, "", "\u8f73\ub5d4\u0a83\u71ea\000\000\u41af\u06d1\ub874\u8f5e\u5042u\ub627\u207f\u20b5\ub6a4\uc445\u2ec3\u6344", "\udaae\ude57",
        54, -1000, 637745668, 265123601913344L, -53646L, true, true, (char) 12, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3deaed0000000000L)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud8ca|-\ude6d|-\uda26|-\udc86|-\ud91d|-\ude83|-\ud9e9|-\uddfd <arg1> [<arg2> ...]|-\ud968|-\udcd4 <arg>|-\uda92|-\udc08|-\ud80f|-\udd7d|-\udaae|-\udc04] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 0, "\ud8ca\ude6d\uda26\udc86\ud91d\ude83\ud9e9\uddfd!*\ud968\udcd4#\uda92\udc08\ud80f\udd7d\udaae\udc04", "\u2917\u3907\000\u120e\u2b9f\u483a\u2ec3\u03a8\u75b1\u31ba\u2d34\u4f68", "\ud994\ude2a\ud9b9\udc91\u8426\ud51b\udaad\ude18\ud90e\udd5e\u3bd8\udbea\udeb4\uda65\udeda\ud8b8\udf4d\ud9c5\udcb1\ud923\uddd4\ud932\udfb8\udbe7\udd75",
        28, 18825, 1874027226, 183354502676480L, -97632L, true, false, (char) 19160, (char) 27041,
        Double.longBitsToDouble(0x3feb6257809c0aecL), Double.longBitsToDouble(0x3fc4515a00000000L)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=null\0121=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 0, 2, "\udb39\ude86\uda26\udccc\ud91d\ude83\u0088\000*\ud968\udcd4\ud8c3\udc8f\ud9d6\udece\ud9b7\udee9\uda9f\udc40", "\u2917\u3907\000\u120e\u2b9f", "\ud862\udfb0\udafa\udc83\ud896\udd36\uda3d\udd17\000\ud809\udec4\u0380\ud994\ude2a\ud9b9\udc91\u8a26",
        2, 94459, -230968786, 775464319240741223L, 39752L, true, false, (char) 15, (char) 59161,
        Double.longBitsToDouble(0x3fee2f2f473741dfL), Double.longBitsToDouble(0x3fe61b7c48000000L)));
  }
  @Test(timeout = 4000)
  public void test177() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\000\uda26\udccc\ue7b1\ud897\udd06\035\ud8f2\udf98\udbf7\udd11\ud8b9\ude44w\000\000\000\ud82d\udd90\005\ud823\ude30\005\ud9ad\udf01\000\ud8f6\udc08\u8c57\000\000\000\000\udb04\ude12", "C\000\000\u9fca\ubb0d\000\000\uc1cb\ub882\u3d83\uad36\u2e9e\u0f3e\u604b", "\ud936\ude1b",
        3, 61440, -65571095, -2188470116593070347L, -50176L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3957b548000000L), Double.longBitsToDouble(0x3e2f20a000000000L)));
  }
  @Test(timeout = 4000)
  public void test178() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 5, "\ud933\uddfe\ud9f6\udf6f\uda9a\udd29\ud8d7\uddea\u73c6\ud9fb\udf97", "\u7788\u1f52\u5c6a\u737c", "\udaca\udc12\ud8cc\udda1\udae8\uddaa\ud8a3\udcda\ud9ed\ude5e\ud89c\udc93",
        42, 64423, 1806670368, 1800899130378802351L, 85495L, true, true, (char) 13, (char) 5700,
        Double.longBitsToDouble(0x3fedd51accaa277fL), Double.longBitsToDouble(0x3fb193a8edab6420L)));
  }
  @Test(timeout = 4000)
  public void test179() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 5, 4, "\ud9d6\ude8b", "\u8d88\u6c3e\ucf47\u9297\u39aa\u42ae\u06d1\u626d\u641d\u5042\ud053\ub627\u877e\u20b5", "\ud884\udd47\ud898\udfab\ud97e\ude26\ud86c\ude3c\uda1f\udee3\ud859\ude4c\ud8bb\udcc8\ud9cb\udd28\ud85e\udf52",
        38, 19865, -823964946, -2374312060008584984L, 29559L, false, false, (char) 23, (char) 60698,
        Double.longBitsToDouble(0x3fe7400003bcd082L), Double.longBitsToDouble(0x3fe0887d891411d0L)));
  }
  @Test(timeout = 4000)
  public void test180() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 4, "", "\u8f73\u8d88\ubca0\u9748\u5420\uadc1\u42ae\u06d1\ub8b2\u02e9\u1ab1\ud053\ub627\u6a0f\u20b5\u96ef\u482b\u2ec3\u6344", "\ud865\udf6c\ud867\udd43\ud8e9\udf5f",
        -1, 60488, -434278915, -8956511726574810386L, -44936L, false, true, (char) 14, (char) 0,
        Double.longBitsToDouble(0x3deaed0000000000L), Double.longBitsToDouble(0x3fe7bbf001bcd07cL)));
  }
  @Test(timeout = 4000)
  public void test181() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\udb39\ude86\uda26\udccc\ue7b1\ud897\udd06\ud818\ude6f\ud8f2\udf98\udbf7\udd11\udaae\udff3\udbe8\udc21\udb5e\udfce\uda33\udd3c\015\000/\udbde\udf9e\u5905\ud9d3\ude64/\uda45\udc90\ud884\udd47\ud862\udfb0\uda34\udd53\uda9c\udd4d\udac8\udf59\udb04\ude12", "\uc8da\u0fe2\u4ca2\u0609\u7de7.\000\uc1cb\u7ea9\u20e2\u9bb1\u2f1c\u6021\u0baf", "\uda6c\udf69\udb64\udd1a\ud8f3\udef2\u9eae",
        19, 36297, 1276746634, 7455495192527962286L, -80345L, false, false, (char) 27076, (char) 0,
        Double.longBitsToDouble(0x3fdf20a00945dc72L), Double.longBitsToDouble(0x3fe0c91e73efdcc4L)));
  }
  @Test(timeout = 4000)
  public void test182() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\013\uda5a\udfec\000\u6700\uda16\udf4b%\ud9cf\udf88\013\uda92\udc08\ud80f\ude75\ud8c4\udc32", "\ub47a\u38e0\u039d\u9f8d\u93e0\u9712\u8f95\ua181\uaa3d\u9825\u052a\000\u172e\u2ec2\u8d26\u42c6\ucd88\u55ca\u9ee5\ud1dd", "\ud90c\udd66\ud86a\udcf9\ud9c5\udcb1\ud863\uddd4\ud932\udfb8\udbe7\udd75\ud918\ude76\ud986\udc20\udab0\udc91\ua6d6\udbd2\udd29\ud97a\udfab",
        53, 35507, 1987878248, -3415979485015080768L, -100000L, false, true, (char) 33394, (char) 49747,
        Double.longBitsToDouble(0x3feebcd3c8b6a54eL), Double.longBitsToDouble(0x3fed67dce00480bfL)));
  }
  @Test(timeout = 4000)
  public void test183() throws Throwable {
    assertEquals("0=null\0121=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 0, 1, "\udb24\ude12\u8ceb\000", "\u96f6\u43f9\u4061\u42ae\u1657\u1ed6\u5e7e\u5042\u9654\ub627\u28f5\u20b5", "\ud98c\ude8f\ud862\udfb0\u5b14\ud896\udd16\uda5b\udc45\ud9e9\udc81\ud8bf\ude26\ud9cb\udc41\ud85e\udf52",
        44, 95490, -823964946, 9163172153062059138L, -99919L, false, false, (char) 11, (char) 60698,
        Double.longBitsToDouble(0x3fde80000379a01cL), Double.longBitsToDouble(0x3fecaf07c1e76e39L)));
  }
  @Test(timeout = 4000)
  public void test184() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\ud8ca\ude6d\uda26\udc86\ud91d\ude83\ud9e9\uddfd!*\udae8\udcd4#\uda92\udc08\ud80f\udd7d\udaae\udc04", "\u2917\u5d78\000\u120e\ua08b\u483a\u2ec3\u03a8\u75b1\ua0c9\u0859\u4f68", "\ud994\ude44\ud9b9\udc91\u8426\ud51b\udaad\ude18\ud90e\udd5e\u3bd8\udbea\udeb4\uda65\udeda\ud8b8\udf4d\ud9c5\udcb1\ud85d\udf11\ud932\udfb8\udbf7\udde6",
        28, 18825, 1874027226, 183354502676480L, -97632L, true, false, (char) 19160, (char) 27041,
        Double.longBitsToDouble(0x3feb6257809c0aecL), Double.longBitsToDouble(0x3fc4515a00000000L)));
  }
  @Test(timeout = 4000)
  public void test185() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 2, "\udb39\ude86\uda26\udccc\uda62\ude79\u0088\000*\ud968\udcd4\ud8c3\udc8f\ud9d6\udece\ud9b7\udee9\uda9f\udc40", "\u2917\ucd84\000\u120e\u2b9f", "\ud862\udfb0\udafa\udc83\ud896\udd36\udb8e\udebf\000\ud809\udec4\u0380\ud994\ude2a\ud9b9\udc91\u8a26",
        40, 22429, -1033883125, -889279458512118035L, 39752L, true, false, (char) 15, (char) 59161,
        Double.longBitsToDouble(0x3fea5dcfdf373543L), Double.longBitsToDouble(0x3fe61b7c48000000L)));
  }
  @Test(timeout = 4000)
  public void test186() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 5, "\ud933\uddfe\ud9f6\udf6f\uda9a\udd29\ud8d7\uddea\u73c6\ud9fb\udf97", "\u7788\u1f52\u5c6a\u737c", "\udaca\udc12\ud8cc\udda1\udae8\uddaa\udb6c\udd1d\ud85c\udee3\ud89c\udcf6",
        42, 64423, 1806670368, 1800899130378802351L, 85495L, true, true, (char) 13, (char) 49420,
        Double.longBitsToDouble(0x3fedd51accaa277fL), Double.longBitsToDouble(0x3fb193a8edab6420L)));
  }
  @Test(timeout = 4000)
  public void test187() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 4, "", "\u17bf\u027c\uc082\ucce3\u5494\uadc1\u67d7\u07a7\ub8b2\u02e9\u1ab1\ua125\ub627\u6a0f\u20b5\u96ef\ua82b\u1a49\u6344", "\ud865\udf6c\ud867\udd43\ud8e9\udf5f",
        -1, 60488, -434278915, -8956511726574810386L, -44936L, false, true, (char) 14, (char) 0,
        Double.longBitsToDouble(0x3fe6c800001a89b8L), Double.longBitsToDouble(0x3fe7bbf001f22be6L)));
  }
  @Test(timeout = 4000)
  public void test188() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 1, "\udb24\ude12\u8ceb\000", "\u4cd2\u6c19\u8698\uaf8b\u171f\u1ed6\u5e7e\u9bdf\u6bb7\u9b7d\u2881\u20b5", "\ud98c\ude8f\ud862\udfb0\u5b14\ud896\udd16\uda5b\udc45\ud9e9\udc81\ud8bf\ude26\ud9cb\udc41\ud85e\udf52",
        44, 95490, -823964946, 9163172153062059138L, -99919L, false, false, (char) 11, (char) 60698,
        Double.longBitsToDouble(0x3fde80000379a01cL), Double.longBitsToDouble(0x3fecaf07c1e76e39L)));
  }
  @Test(timeout = 4000)
  public void test189() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 5, "\ud933\uddfe\ud9f6\udf6f\uda9a\udd29\ud8d7\uddea\023\ud9fb\udf56", "\u7788\u1f52\u5c6a\u737c", "\uda4b\uddf3\ud8a9\udd94\udae8\uddaa\udb6c\udd1d\ud85c\udee3\ufb87",
        -5, 31112, 1795201568, 1800899130378802351L, 85495L, true, true, (char) 13, (char) 49420,
        Double.longBitsToDouble(0x3fedd51accaa277fL), Double.longBitsToDouble(0x3fb193a8edab6420L)));
  }
  @Test(timeout = 4000)
  public void test190() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb39|-\ude86|-\u00eb|-\000|-\ud8f2|-\udf98|-\u00dc|-\ud8c4|-\udea2|-\uda4a|-\udda1|-\020|-\udb1d|-\udd4d|-\023|-\udbad|-\udeca|-\udb01|-\udf5a|-\udaf9|-\udfd2|-\uda06|-\ude85|-\ud90d|-\ude65|-\ud89a|-\udfad|-\ud862|-\udfb0|-\uda1c|-\ude71|-\udab2|-\udf0f|-\ud8b4|-\udd71|-\udaad|-\udc03|-\u0080|-\ud99b|-\udc15|-\ud977|-\ude3b|-\ud823|-\ude5f|-\uc298|-\ud8a8|-\uddde|-\ud912|-\udc55|-\ud882|-\ude81|-\uda6f|-\ude90|-\uda59|-\udded|-\uda7b|-\udcf7|-\ud8df|-\udd6e|-\ud8e9|-\udca8|-\udada|-\udefd|-\udab4|-\udc82|-\udb21|-\udd05|-\ud95a|-\uddad|-\ue78c|-\ud827|-\udd77|-\ud924|-\udce9|-\ud9ae|-\ude28|-\udafb|-\ude6d|-\uda36|-\udd7d|-\uda15|-\udc92|-\ud9e0|-\udf45|-\uda2a|-\udd3a|-\udb8b|-\udd74|-\udab3|-\ude78|-\udb29|-\udf54|-\ud9d7|-\udd5c|-\ud8b1|-\udb22|-\udf07|-\udad6|-\udd2d|-\uda03... |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 5, "\udb39\ude86\u00eb\000\000\000\ud8f2\udf98\u00dc\ud8c4\udea2\uda4a\udda1\020\000\udb1d\udd4d\023\udbad\udeca\udb01\udf5a\udaf9\udfd2\uda06\ude85\ud90d\ude65\000\ud89a\udfad\ud862\udfb0\uda1c\ude71\023\udab2\udf0f\ud8b4\udd71\udaad\udc03\u0080\000\ud99b\udc15\000\ud977\ude3b\ud823\ude5f\uc298\ud8a8\uddde\ud912\udc55\ud882\ude81\uda6f\ude90\uda59\udded\uda7b\udcf7\ud8df\udd6e\ud8e9\udca8\udada\udefd\udab4\udc82\udb21\udd05\ud95a\uddad\ue78c\ud827\udd77\ud924\udce9\ud9ae\ude28\udafb\ude6d\uda36\udd7d\uda15\udc92\ud9e0\udf45\uda2a\udd3a\udb8b\udd74\udab3\ude78\udb29\udf54\ud9d7\udd5c\ud8b1\udc82\udb22\udf07\udad6\udd2d\uda03\udf97\ub899\ud924\udcd1\uda8b\udc2c\udb31\udcc1\ud8ee\ude16\u8431\ud8af\udf4f\udb10\udcb2\ud831\udf88\ud8b8\udc05\udae2\udc3a\udb7e\udeea\udbfa\udc9a\ud9a7\udffc\ud9f6\uddea\udb97\udd88\udb62\uddc8\u2e89\ud988\udefd\ud8c2\udd70\ud87e\udc1e\ud8e4\uddd9\udb12\ude25", "\u9b7b", "\udac7\udc94\ud854\udc9b\ud8e0\ude16\udb84\uddc5\ud9f4\udd92\udbe9\ude63\uda5f\udfff\ud850\udfae\ud9ac\udc5f\udb20\udd9b\u4703\ud88b\ude95\ua3f4\u1b91\udbee\udece\ud864\uddce\udb61\udd22\udbe2\udf75\ud975\ude04\udaea\ude62\uda17\uded9\ud9b1\udf06\udb9b\ude3b\udbad\udf64\ud8d6\uddfa\uda61\udd5b\udb31\udf8f\udaac\udc2c\udbbf\udfdf\ud96a\udded\ud814\udc2c\ud954\udf81\ud964\udfea\udb26\udfe5\ud9a3\udd7d\ud8ee\udfce\ud811\udd3d\ud9a5\udd03\uda7d\udeb3\ud882\udebe\ud96a\udfad\u405d\ud83f\ude5a\uda82\udc5b\udb6d\ude15\ud874\udf04\uda98\udc28\ud9c0\udc2a\ud936\udf28\ud99c\udf26\ud8a3\udc95\ud84b\udf6f\uda3b\udcba\ud9c3\ude17\ud973\udea3",
        35, 22610, 283200460, -3839027397107252259L, -83300L, false, false, (char) 32111, (char) 15132,
        Double.longBitsToDouble(0x3fd767aa598da25aL), Double.longBitsToDouble(0x3fb68f48468e6a60L)));
  }
  @Test(timeout = 4000)
  public void test191() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud802\udd6a\u00c1\udb50\udfef\udba7\udc2e\000\ud8f2\udf98\u00dc\ud8c4\udea2\uda47\udda1\020\000\udb1d\udd4d\023\udbad\udeca\udb01\udf5a\ud94a\udf5b\000\000\000\ud89a\udfad\ud862\udfb0\uda1c\ude71\023\ud92d\udf2e", "\u2251\000\u26ed\u8a25\ua075\u0e96\u3e0f\u0442\u3287\ud3c5\u6029\ub264", "\udae8\udc46\ud8ad\udde7\ud999\udc82\uda9d\udd89\udaca\udeda\udbb7\udc43\ud851\udc15\udbbd\udcf8\uda61\udc6f\uda00\udca8",
        8, 37310, -943367613, -4598729486447117263L, -10828L, true, false, (char) 50281, (char) 29912,
        Double.longBitsToDouble(0x3fe46e0177389296L), Double.longBitsToDouble(0x3fde967a2d252352L)));
  }
  @Test(timeout = 4000)
  public void test192() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udac2\udc00\uda26\udccc\ue7b1\ud897\udd06\035\ud914\uddd5\udbe7\udec2\ud821\udf5d\ud840\ude28\ud8cf\udffc\033\000\ud865\udc81\033\udb7d\udd1e\ud6fd\ud9ad\udf01\u1884\udb9b\udcef\udb63\uddf6\udb6d\udc71\000\ud826\udc93\u5000\ud8ec\udd10", "\u00d6\u7a0c\u8a3f\ua0a8\ubb0d\000\000\uc1cb\ub882\u3d83\u6d36\u5e49\u0f53\u604b", "\uda3f\udd45",
        29, 61440, -65579943, -2188470117373330187L, 58082L, true, true, (char) 9674, (char) 62942,
        Double.longBitsToDouble(0x3fe3254a51f20a00L), Double.longBitsToDouble(0x3fe5db2c4cd2ebc1L)));
  }
  @Test(timeout = 4000)
  public void test193() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 5, "\ud933\uddfe\ud9f6\udf6f\uda9a\udd29\ud822\udc6f\u73c1\ud9fb\udf97", "\u7788\u1f52\u4ddc\u0c31", "\ud9fa\udeaa\ud8cc\udda1\udae8\uddaa\ud8a3\udcda\ud9ed\ude5e\ud89c\udc93",
        42, 64423, 1806670368, 1800899130378802351L, 85495L, true, true, (char) 5, (char) 5700,
        Double.longBitsToDouble(0x3fedd51accaa277fL), Double.longBitsToDouble(0x3fb193a8d2f36420L)));
  }
  @Test(timeout = 4000)
  public void test194() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 3, "\ud9d6\ude8b", "\u8d88\u6c3e\ucf47\u9297\u39aa\u42ae\u06d1\u626d\u641d\u5042\ud053\ub627\u877e\u20b5", "\ud884\udd47\ud898\udfab\udba8\udfdb\ud86c\ude3c\uda1f\udee3\ud859\ude4c\ud8bb\udcc8\ud9cb\udd28\ud85e\udf52",
        38, 19865, -823964946, -2374312060008584984L, 29559L, false, false, (char) 23, (char) 60698,
        Double.longBitsToDouble(0x3fe7400003bcd082L), Double.longBitsToDouble(0x3fe0887d891411d0L)));
  }
  @Test(timeout = 4000)
  public void test195() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 5, "\udb39\ude86\u00eb\000\000\000\ud8f2\udf98\u00dc\ud8c4\udea2\uda4a\udda1\020\000\udb1d\udd4d\023\udbad\udeca\udb01\udf5a\udaf9\udfd2\uda06\ude85\ud90d\ude65\000\ud89a\udfad\ud862\udfb0\uda1c\ude71\023\udab2\udf0f\ud8b4\udd71\udaad\udc03\u0080\000\ud99b\udc15\000\ud977\ude3b\ud823\ude5f\uc298\ud8a8\uddde\ud912\udc55\ud882\ude81\uda6f\ude90\uda59\udded\uda7b\udcf7\ud8df\udd6e\ud8e9\udca8\udada\udefd\udab4\udc82\udb21\udd05\ud95a\uddad\ue78c\ud827\udd77\ud924\udce9\ud9ae\ude28\udafb\ude6d\uda36\udd7d\uda15\udc92\ud9e0\udf45\uda2a\udd3a\udb8b\udd74\udab3\ude78\udb29\udf54\ud9d7\udd5c\ud8b1\udc82\udb22\udf07\udad6\udd2d\uda03\udf97\ub899\ud924\udcd1\uda8b\udc2c\udb31\udcc1\ud8ee\ude16\u8431\ud8af\udf4f\udb10\udcb2\ud831\udf88\ud8b8\udc05\udae2\udc3a\udb7e\udeea\udbfa\udc9a\ud9a7\udffc\ud9f6\uddea\udb97\udd88\udb62\uddc8\u2e89\ud988\udefd\ud8c2\udd70\ud87e\udc1e\ud8e4\uddd9\udb12\ude25", "\u9b7b", "\udac7\udc94\ud854\udc9b\ud8e0\ude16\udb84\uddc5\ud9f4\udd92\udbe9\ude63\uda5f\udfff\ud850\udfae\ud9ac\udc5f\udb20\udd9b\u4703\ud88b\ude95\ua3f4\u1b91\udbee\udece\ud864\uddce\udb61\udd22\udbe2\udf75\ud975\ude04\udaea\ude62\uda17\uded9\ud9b1\udf06\udb9b\ude3b\udbad\udf64\ud8d6\uddfa\uda61\udd5b\udb31\udf8f\uda23\udf08\udbbf\udfdf\ud96a\udded\ud814\udc2c\uda3a\udf74\ud964\udfea\udb26\udfe5\ud9a3\udd7d\ud8ee\udfce\ud811\udd3d\ud9a5\udd03\uda7d\udeb3\ud882\udebe\ud96a\udfad\u405d\ud83f\ude5a\uda82\udc5b\udb6d\ude15\ud874\udf04\uda98\udc28\ud9c0\udc2a\ud936\udf28\ud99c\udf26\ud8a3\udc95\ud84b\udf6f\uda3b\udcba\ud9c3\ude17\ud973\udea3",
        35, 22610, 283200460, -3839027397107252259L, -83300L, false, false, (char) 32111, (char) 15132,
        Double.longBitsToDouble(0x3fd767aa598da25aL), Double.longBitsToDouble(0x3fb68f48468e6a60L)));
  }
  @Test(timeout = 4000)
  public void test196() throws Throwable {
    assertEquals("0=null\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 2, 5, "\ud933\uddfe\ud9f6\udf6f\uda9a\udd29\ud822\udc6f\u73c1\ud9fb\udf97", "\u7788\u1f52\u4ddc\u0c31", "\ud9fa\udeaa\ud8cc\udda1\udae8\uddaa\ud8a3\udcda\ud9ed\ude5e\ud89c\udc93",
        42, 64423, 1806670368, 1800899130378802351L, 85495L, true, true, (char) 5, (char) 5700,
        Double.longBitsToDouble(0x3fedd51accaa277fL), Double.longBitsToDouble(0x3fb193a8d2f36420L)));
  }
  @Test(timeout = 4000)
  public void test197() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 5, "\ud933\uddfe\ud9f6\udf6f\uda9a\udd29\ud822\udc6f\udbdc\udd3f\ud9fc\udc25", "\u7788\u1f52\u4ddc\u0c31", "\ud9fa\udeaa\ud8cc\udda1\udae8\uddaa\ud8a3\udcda\ud9ed\ude5e\ud89c\udc93",
        42, 64423, 1806670368, -7787827426491274358L, 19959L, true, true, (char) 5, (char) 378,
        Double.longBitsToDouble(0x3fedd39a34aa277fL), Double.longBitsToDouble(0x3fb193a8faf36420L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.builder.PatternBuilder|create||new:org.apache.commons.cli2.builder.PatternBuilder:",
    "M|org.apache.commons.cli2.builder.PatternBuilder|createOption|char,boolean,char|new:org.apache.commons.cli2.builder.PatternBuilder:",
    "M|org.apache.commons.cli2.builder.PatternBuilder|reset||new:org.apache.commons.cli2.builder.PatternBuilder:",
    "M|org.apache.commons.cli2.builder.PatternBuilder|validator|char|static",
    "M|org.apache.commons.cli2.builder.PatternBuilder|withPattern|java.lang.String|new:org.apache.commons.cli2.builder.PatternBuilder:",
    "C|org.apache.commons.cli2.builder.PatternBuilder|<init>|",
    "C|org.apache.commons.cli2.builder.PatternBuilder|<init>|org.apache.commons.cli2.builder.GroupBuilder,org.apache.commons.cli2.builder.DefaultOptionBuilder,org.apache.commons.cli2.builder.ArgumentBuilder",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
