package org.apache.commons.cli2.builder;
import org.junit.Test;
import static org.junit.Assert.*;
public class PatternBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u580e\ua578\u44e1\u32ad\ud380\u2eca", "\uda06\udc14",
        18, 57628, -36776770, -637081841405753475L, 67485L, false, false, (char) 13586, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8851608bcaL), Double.longBitsToDouble(0x3fee158872971582L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u580e\ua578\u44e1\u32ad\ud380\u2eca", "\uda06\udc14",
        18, 57628, -36776770, -637081841405753475L, -17881L, true, true, (char) 13586, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8851608bcaL), Double.longBitsToDouble(0x3fee158872971582L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 0, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u580e\ua578\u44e1\u32ad\ud380\u2eca", "\uda06\udc14",
        18, 57628, -36776770, -637081841405753475L, 67485L, false, false, (char) 13586, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8851608bcaL), Double.longBitsToDouble(0x3fee158872971582L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 2, "\ua131\ud806\udfa1\uda08\udd02\ud862\udc38", "\u3593\u6a8d\u6d2a\u0a84\u1409\ucf53\u58ae\ua578\u44e1\u32ad\ud380\u2eca", "\uda54\ude8f\ud844\udd76\udbd6\udf6b\udb9e\udd9c\uda5e\udceb\ud803\udc8d\udba9\uddb8\ud9b5\udfe2\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14\uda25\udf1b\ud8eb\udfa1\udbff\udcb8\ud9f3\udd06\ud995\ude0a\ud8bf\udf34\udb4d\udec6\udb48\udeae\uda10\uddf7\ud8a5\ude26\uda0c\udf4e\uda75\udcf6\udac9\udc59\uda72\ude9f",
        -5, 29442, -394543087, -773981412780531447L, 14489L, true, true, (char) 6209, (char) 4460,
        Double.longBitsToDouble(0x3fdf82bf3173433eL), Double.longBitsToDouble(0x3fd0d40abb282bf6L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 2, 5, 0, "\ua131\ud806\udfa1\uda08\udd02\uda69\uddef", "\u826b\u4cf0\u6d40\u0a84\u9041\ucf53\u580e\ua578\u3f8f\u9e1f", "\ud95d\udd50\ud9e5\udd18\uda04\udd5f\ud844\udd76",
        18, 45565, -1375929615, -3591366177400291068L, 23450L, true, true, (char) 9192, (char) 12171,
        Double.longBitsToDouble(0x3fecd0e75d64ef78L), Double.longBitsToDouble(0x3fd72767c785621cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 2, 0, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41\udafe\udcc7\udbac\udecc", "\u6d2a\u0a84\u9041\ucf53\u580e\uad25", "\ud843\udcae\ud861\ude00\ud962\ude99\ud855\ude2e\uda06\udc14\ud844\udd76\udbd6\udf6b\udbb3\udc9c",
        30, 74325, 1413343426, 4874001894000550458L, 59714L, true, false, (char) 3183, (char) 40929,
        Double.longBitsToDouble(0x3fd608bca785621cL), Double.longBitsToDouble(0x3fe4b8ac12964a9eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 0, 2, 0, "\ua131\ud806\udfa1\ud890\udcc6\000", "", "\u4ed6\udb53\udfe9\ud93f\udde2",
        10, 24129, -2107692544, -8052999085430164102L, 59933L, true, false, (char) 25019, (char) 64791,
        Double.longBitsToDouble(0x3fe2edd730000000L), Double.longBitsToDouble(0x3e271fd000000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "\ud8e6\ude08\ud920\udcd7\uda21\udc15\ud9af\udd06\ud989\udcfb\ud870\ude2d\udb2a\uddbd\udafd\uddee\udae9\udec0", "\ucfad\u580e\ua578\u44e1", "\ud861\ude00",
        29, 34009, -1165704153, 3788158807412436604L, -28514L, false, false, (char) 9693, (char) 46263,
        Double.longBitsToDouble(0x3fde24336b8ec5baL), Double.longBitsToDouble(0x3fd8ce10cdc9c8baL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 0, "\ua131\ud806\udfa1\u1b05\ud88a\ude8c", "\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u580e\ua578\u44e1\u1f1f\ud380\u2eca", "\uda06\udc14",
        18, 57628, -36776770, -637081841851623043L, 67485L, false, false, (char) 13586, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8851608bcaL), Double.longBitsToDouble(0x3fee158872971582L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41\uda86\udc8c\u1aa9\uda22\udcc5", "\u43b3\u96c9\ucf53\u15f4\ua55b\u44e1\u32ad\ud380\u2eca\ub30a\ub157\u9a40\uacab\u8ce4\uc224\ud48f\u5a3f\u37e3\u0a00\u6fd6\u45e6\u5570\u364d\u13ed\u0cca\uce2e\u6c88\u2e88", "\udad3\ude69\udaf6\udd97",
        13, 24574, 889350127, -4671667612155802173L, 73235L, false, true, (char) 34433, (char) 39170,
        Double.longBitsToDouble(0x3fe8aa79267d06caL), Double.longBitsToDouble(0x3fed3a17c4a09709L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\ud9fc\udff0\uda85\ude9b\uda23\udec5\ud96b\udf63\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\udb79\udc2a\ud93f\udde2\ud93e\udd37\udb69\udf67\ud935\udfbf\udbeb\udc16\udb98\udfe9", "\ub30a", "\ud844\udd76\udbd6\udf6b\udbad\udfd4",
        45, 7820, 701632074, -1159270517891669493L, 47028L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fd9f8bca7ac241cL), Double.longBitsToDouble(0x3fe4b8ac17f4e4b4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 0, "\udbf3\uddf0", "\u33df\u6140\u7c5a\u450c\ub0ad\ua606\u3f79\u277e", "\udaba\udef6\u32bf\udb75\udf5e\ud877\udde8\ud934\udf52\ud808\udfc7",
        23, 90226, 881999391, 7259638205116241086L, -19660L, false, false, (char) 40421, (char) 14194,
        Double.longBitsToDouble(0x3fe52ae726e5d17cL), Double.longBitsToDouble(0x3fd1265f052e2bbcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\udac9\udf5f\uda92\udfd1\udb99\udff2", "\u6d2a\u0a84\u9041", "\udaba\udef6\uda06\udd3a\udacf\udda3\ud877\udd4d\udb8b\ude56\ud962\udc35\ud855\ude2e\uda06\udc14\ud861\udfa6\udbd6\udf3f\udbb3\udc9c\uda5e\udceb\ud803\udc8d\udba9\uddb8\ud9b6\udee2\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14\udb7a\ude3f\udb50\udd53\ud8ed\udcca\ud9a1\udd33\uda0f\udd68\ud83b\uddfc\ud88c\udd1e\ud8f4\udece\ud9c9\udfe4\udb4b\udf65\ud844\udf9d\uda5d\udcf9\u96fd\udbf3\udfa8\ud8b8\udfbc\ud80c\ude04",
        10, 51550, 926330898, 2740735920486127242L, 18043L, false, false, (char) 4170, (char) 35273,
        Double.longBitsToDouble(0x3fb5e9fa8e7ad938L), Double.longBitsToDouble(0x3fd0c4511fd72e38L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 0, 4, "\ud9fa\udd5a\ud96a\udd15\uda00\uddb6", "\ubba5\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u580e\ua578\u44e1\uba9d\ud380\u0128\u8ee4\ub114\u7fcc\ua7e0\u712a\uc224\u5ef6", "\ud97c\ude1d\uda43\udc7e",
        29, 75050, 1433952266, 3387600094101662264L, 62714L, true, false, (char) 42493, (char) 27741,
        Double.longBitsToDouble(0x3fe99563755f279cL), Double.longBitsToDouble(0x3feabf4a9552ce35L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "", "\u7e46", "",
        -5, -1000, 9471232, -101526704710183871L, 49666L, true, false, (char) 20759, (char) 27572,
        Double.longBitsToDouble(0x3eaf000000000000L), Double.longBitsToDouble(0x3fe8000006cf7259L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 3, "\ua04b\ud806\udfa1\uda08\udd02\ud88a\udf41\udaa7\uddd6\udbb4\ude3f\udb56\udf00\udbab\ude5d\udae9\udec0\udb7a\udd29\ud93f\udde2\ud865\udd2a\ud864\ude07\uda53\udc42\udbea\udd8a\udbd8\udf73\udaa9\udd41\udb41\udedf\udb4f\ude2f\ud8d0\ude9c\ud8e2\udc1f\ud816\udfe4\udb0d\udd9a\uda03\udf22\udbae\udeb5\ud8a1\udeae\uda22\udf2c\udbd0\udfd6\udbdc\udecf\u76ad\ud844\udc01\ud99d\udd14\ud886\ude89\ud9a7\udced\udacd\udd4a\ud8ff\udc7c\ud8d1\udd69\udaf4\udf95\uda6a\uddb7\uda4f\udec8\ud88f\udcea\udab4\udfd4\ud8d6\udd3e\ud89f\udc69", "\u4fb3\u8b46\uabd3\u920e\u0986\u3180\u84a3\u11f5\ube79\ub0bf\uc730\u8a1c\u522f\ua201\uc6b4\u4535\u0d1e\u6d33", "\ud815\ude35\udbce\ude30\ud839\udcb9\ud827\udccb\udaec\udd4e\ud86d\uded3\ud844\udc47\ud993\udf8d\ud890\udf82\udb86\udc5c\uda4b\udf04\udb66\udea5\uda2e\udcbf\u6ee0\ud9eb\udec5\uda44\udcdd\ue5e7",
        34, 96863, 1405987999, 6684497651496435900L, 42390L, false, false, (char) 49846, (char) 61461,
        Double.longBitsToDouble(0x3fc6ba88a66d467cL), Double.longBitsToDouble(0x3fe48a2cc0ee913cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 2, 0, "\ud84c\udcac\ud806\udfa1\udac0\ude4c\ud88a\udead\uda86\udc8c\udb99\udff2\udb0c\uddc2\uda8f\udf08\ud914\udf36", "\ucf53", "\udaaa\ude48\udb75\udf5e\ud877\udde8\ud861\ude00\ud962\ude99\ud855\ude2e\uda06\udc14\ud9d9\udd76\ud80c\udd26\ud91f\udcbb\udbdf\udc23\ud92d\udfc1\uda68\udf4d\ud9b6\uded9\udb5c\udd2a\ud948\udc21\udae4\ude20\ud99d\udd14\uda1a\udcd0\ud81d\uddcc\ua3d4\ud9f3\udc63\ud851\udf69\udb37\udc86\ud9a2\udccb\uda41\udca5",
        15, 78355, 780424622, 3011337191940918619L, 45186L, true, false, (char) 48714, (char) 23149,
        Double.longBitsToDouble(0x3fddcacb61118deeL), Double.longBitsToDouble(0x3fea79c7f502f335L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 5, 1, 4, "\ua131\u3646\ud8dc\ude62\ud88a\udf41\uda86\udc8c\udb99\udff2\udb0c\uddc2\ud8e6\ude11\udaab\ude54\udb79\udc2a\ud93f\udde2\ud803\udefa\ud8ab\udc71\udaba\udef6\u32bf\udb75\udf5e", "\u50fe\u29ab\u6a41\uacab\u8ce4\uc224\u5ef6\u546a", "\ud958\udce9",
        34, 33202, -1411833334, -3383738699898761595L, -10850L, true, false, (char) 44537, (char) 28839,
        Double.longBitsToDouble(0x3fead9582e5b9f94L), Double.longBitsToDouble(0x3fd33f12338e37a4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u580e\ua578\u44e1\u25f0\ud380\u2eca", "\uda06\udc14",
        18, 57628, -36776770, -637081841405753475L, 67485L, false, false, (char) 8, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8850000000L), Double.longBitsToDouble(0x3e12e2b040000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 2, 0, "\u915d\udb93\udd1d\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u5d4c\u0a84\u9041\ucf53\u580e\ua578\u44e1\u32ad\ud380\uc128", "\uda06\udc14",
        18, 57628, -36776770, -637081841405753475L, 67485L, false, true, (char) 33968, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8851608bcaL), Double.longBitsToDouble(0x3fee158872971582L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 2, 4, 4, "\ua131", "\u5e92\ub018\ubba5\u363c\u6a8d\u6d2a\u0a43\u9041", "\udaba\udef6\u32bf\udb75\udf5e\ud877\udde8\ud861\ude00\ud962\ude99\u2169\000\ud9e2\udf10\udbd6\udf6b\udbb3\udc9c\uda5e\udceb\ud803\udc8d\udba9\uddb8\ud9b6\udee2\uda43\udc7e\u4233\u00e2\000\000\000\ud870\udf58\ud9f3\udd06\udb39\udf7c\ud950\udf41\udb6b\udf08\ud996\ude3b\ud9f9\udd71\uda57\udcd3\ud98d\udc61\uda9e\udfa5\ud963\udc9a\u3864\uda00\uddd2\ud8ed\udeb0",
        5, 25584, -1759176671, -2225822729021905215L, 85191L, false, true, (char) 38053, (char) 30570,
        Double.longBitsToDouble(0x3fd6dafe9999f542L), Double.longBitsToDouble(0x3fe2cd7a7773a1d9L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 4, 0, "", "\u7e46\u00f1\ub018\ubba5\u00f2\u6a8d\u4ed6", "\ud803\udefa",
        42, 74766, 0, 0L, 43055L, false, false, (char) 64791, (char) 63811,
        Double.longBitsToDouble(0x3fd7c349297cc97eL), Double.longBitsToDouble(0x3fd71fdceefbee50L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\uda50\udf39", "\ua9f2\000\u4ed6\u4e42\020\u86b1\uce0d\ua578\u1156\000\000\u8f00", "\udbbe\udfdf",
        23, -1000, 0, 0L, -100000L, false, false, (char) 0, (char) 20962,
        Double.longBitsToDouble(0x3f130872a0000000L), Double.longBitsToDouble(0x3fe42e8851608bcaL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\u00f1", "", "",
        -5, 39417, 1942052624, -2024851121184873943L, -28661L, false, true, (char) 55320, (char) 28855,
        Double.longBitsToDouble(0x3fe67b92c9694052L), Double.longBitsToDouble(0x3fa3a878e5dbae60L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 2, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41", "\u363c\uc26b\ub8c6\u0a84\u9041\ucf53\u58c8\ua578\u44e1\u32ad\ub002\u2eca", "\uda06\udc14",
        18, 57628, -45458686, -637081841405753475L, -38842L, false, false, (char) 3565, (char) 60808,
        Double.longBitsToDouble(0x3feed329722f961bL), Double.longBitsToDouble(0x3fe4ab13d9608bcaL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 0, "\udba8\udff1\ud8fa\uddbd\ud9cb\udee2\ud88a\udf41", "\u363c\u5ef9\u6d2a\u0a84\u74f2\u289c\u4ee2\ua578\u44e1\u32ad\ud380\u2eca", "\uda06\udc14",
        41, 57628, -193604418, -637081841405753475L, 67508L, false, false, (char) 13586, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8851608bcaL), Double.longBitsToDouble(0x3fee158877e51582L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 0, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41\ud8c0\udc89\udb99\udfd4\udb0c\uddc2\ud8e6\ude11\udae9\udec0\ud995\udf19\ud80d\udf76\ud8c3\udf55\ud8e9\udc06\udaba\udf20\u32bf\ud836\udd61\ud939\uddcf\udb70\udd72\ud983\udca9\ud9a3\udcd6\uda8b\udf15\udb2a\udcf4\udbee\ude41", "\u546a\u0c9a\ucf10\u9379\u4eac\u95ed\u9b68\u491a\u7271\u33cf\u7c85\u6b04\u34f7\u9ddc", "\uda6e\udf85\ud81c\udd40\uda08\udc50\ud894\udf33\ud9c2\ude01\udbbf\ude99\udbe1\uddd2\udbca\uddc6\uda67\udcc5\udbb1\ude1f\udba1\udc3e\udaa5\udc5f\ud89f\ude11\uda4b\udcef\ud9ac\udcf9\ud89e\udd3e\uda9c\udfee",
        16, 50821, 1799395595, 1895452196112490551L, 35970L, true, true, (char) 22544, (char) 55195,
        Double.longBitsToDouble(0x3fc1164776145fe0L), Double.longBitsToDouble(0x3fdb08905459b5e4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 4, 0, "\ua131\ud806\udfa1\uda08\udd02\ud91a\udf6f", "\u35fe\u6a8d\u6d2a\u0a84\ub4b2\ucf11\u580e", "\udb75\udf5e\ud877\udde8\ud861\ude00\ud962\ude99\ud855\ude2e\uda06\udc14\ud844\udd76\udbd6\udf6b\udbb3\udc9c",
        30, 74325, 1413343426, 4874001894000550458L, -96190L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fd608b34785621cL), Double.longBitsToDouble(0x3fe4b8ac162ce065L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 0, 0, 2, "\ua131\u3ac8\uda08\udd02\ud88a\udf41", "\u621c\u6a3d\u6c9b\u0a84\u9041\ucf53\u580e\ua578\u44e1\u32ad\ud380\u2eca", "\uda06\udc14",
        18, 57628, -36776770, -637081841405753475L, -38644L, false, false, (char) 9955, (char) 54145,
        Double.longBitsToDouble(0x3fe050984395abd9L), Double.longBitsToDouble(0x3fc85933a5822f28L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 0, 0, "\uf67b\ud802\ude27", "\u1444\ubba5", "\udae9\udec0\udb79\udc2a\ud90c\udc89",
        43, 50497, -2107692450, 779379285078291076L, 59933L, true, false, (char) 20574, (char) 16219,
        Double.longBitsToDouble(0x3fe2eaaa857c3492L), Double.longBitsToDouble(0x3fe4b8553171fd1bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 0, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u580e\ua578\u44e1\u32ad\ud380\u2eca", "\uda06\udc14\ud844\udd76\udbd6\udf6b\udbb3\udc9c\uda5e\udceb\ud803\udc8d\udba9\uddb8\ud9b6\udee2\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14\uda1a\udcd0\udb3f\udfab\udbff\udcb8\ud9f3\udd06\ud97d\udede\udab6\udcb9\uda07\udf49\uda51\udd52\ud975\udd51\udbd5\udc98\udbb7\ude2b\uda85\udd5b\uda3e\uddb4\udb96\udfa1\ud925\udc67\udba6\ude03\ud829\udcb4\uda08\udddd\ud82a\ude4b\udbee\udecb\udaf1\ude97\uda2d\udf04\uffb3\udad8\udcc8\ud962\udf3a\ud853\udfdc\ud8bf\udfdf\ud8ad\ude69\ud82b\udd93\udb22\udc81\ud9ea\udf1a\ud9e5\ude7e\ud962\udfbf\ud91f\udf73\udbad\udd23\udbe2\udd9b\u79ea\udab3\udc74\ud992\udc6d\udafb\udf75\udacd\ude0d\ud95b\ude67\udb2d\udc67\udbdd\ude56\udbc0\udfcb\ud8ef\udc3c\udb9b\udd91\ud894\udf5c\uda24\udf77\udbf8\udeb9\ud9e8\udfea\ud950\udd01\ud83b\udffc",
        53, 17580, -1209449840, 8805564188296449155L, -5811L, false, true, (char) 27377, (char) 16444,
        Double.longBitsToDouble(0x3fc17f9a343291f8L), Double.longBitsToDouble(0x3fee716c027b01cbL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 0, "\ua131", "\u5e92\ub018\u7a9d\u354a\u3e1b\u6d2a\ubce2\000", "",
        15, 58733, 0, 0L, -25911L, true, false, (char) 63811, (char) 2574,
        Double.longBitsToDouble(0x3fc7cc97e5c7f738L), Double.longBitsToDouble(0x3febefb940c2ce28L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 0, 2, "\udb6d\udf5e\ud806\udf3d\ud9f1\udd02\ud88a\udf41\uda86\udc8c\udb99\udff2\udb0c\uddc2\ud9ac\ude12\udae9\udec0\udb79\udc2a\ud93f\udde2\ud803\udefa\ud8ab\udc71\udaba\udef6\u32bf\udb75\udf5e\ud877\udde8\udb54\udcb1", "\uabbc\uad07\u8ce4\uc224\u5ef6\u546a", "\uda43\udc7e",
        29, 33202, -1411833334, -3383738699898761595L, -10850L, true, false, (char) 35787, (char) 22397,
        Double.longBitsToDouble(0x3fd0eda803e1e5acL), Double.longBitsToDouble(0x3fe4f0595e99e21bL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "\ud9c6\ude00\ud806\udfa1\uda08\udd02\000", "\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u9b04\ua578\u44e1\u32ad\ud380\u2e87", "\uda06\udc14",
        18, 57628, 190, -836239360L, 96838L, false, false, (char) 46263, (char) 21016,
        Double.longBitsToDouble(0x3fe050984395abd9L), Double.longBitsToDouble(0x3fe42e8850008bcaL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 2, "\ua131\ud806\udfa1\uda08\udd02\ud862\udc38", "\u3593\u6a8d\u6d2a\u0a84\u1409\ucf53\u58ae\ua578\u44e1\u32ad\ud380\u2eca", "\uda54\ude8f\ud844\udd76\udbd6\udf6b\udb9e\udd9c\uda5e\udceb\ud803\udc8d\udba9\uddb8\ud9b5\udfe2\uda43\udc7e\u4233\ud8f6\udd7a\uda0e\ude0f\uda25\udf1b\ud8eb\udfa1\udbff\udcb8\ud9f3\udd06\ud995\ude0a\ud8bf\udf34\ud844\udfe2\udad8\udf19\udb3b\uddc2\ud8aa\udde0\uda0c\udf4e\uda75\udcf6\udac9\udc59\uda72\ude9f",
        -5, 29442, -394543087, -773981412780531447L, -52688L, false, true, (char) 14236, (char) 37572,
        Double.longBitsToDouble(0x3fecc1784a5dee58L), Double.longBitsToDouble(0x3feabbfb748af16cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 5, 2, 2, "\000", "\u9388\ua4d6\u4100\u3593\u2c72\u4789\000", "\ud8ab\udd11",
        15, 37773, -1738295942, -2201064269337227453L, 64286L, true, true, (char) 32421, (char) 46826,
        Double.longBitsToDouble(0x3fef32a1ea3a43a3L), Double.longBitsToDouble(0x3fe1e933dee24336L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ua131|-\ud806|-\udfa1|-\uda08|-\udd02|-\ud862|-\udc38] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\ua131\ud806\udfa1\uda08\udd02\ud862\udc38", "\u3593\u6a8d\u6d2a\ua08d\u1409\ucf53\u19af\ua578\u44e1\u32ad\u74d9\u4155", "\uda54\ude8f\ud844\udd76\udbd6\udf6b\udbce\udd94\uda5e\udceb\ud803\udc8d\udba9\uddb8\ud82b\udc33\ud9ea\udd64\u4051\ud844\udc01\ud99d\udd14\uda25\udf1b",
        10, 38147, 1865628734, 4435678607524482123L, 14722L, false, true, (char) 44261, (char) 24791,
        Double.longBitsToDouble(0x3fec3d127e59909eL), Double.longBitsToDouble(0x3fc3ecbb889d9768L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 2, "\ud9c6\ude00", "", "\ud9a6\udfb8",
        7, 43192, 9916118, 1937320704L, 71319L, false, false, (char) 27572, (char) 17848,
        Double.longBitsToDouble(0x3f430c6000000000L), Double.longBitsToDouble(0x3fe67b90020000bbL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 2, "\udbed\udf35\ud806\udfa1\uda08\udd02\ud862\udc38", "\u354a\u6a8d\u6d2a\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\uda54\ude8f\ud844\udd76\udbd6\udeef\udb9e\udd9c\000\uda9b\udd0d\udba9\uddb8\udb61\udfd8\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14\uda25\udf1b\ud8eb\udfa1",
        8, 9138, 982430359, 0L, -100000L, false, false, (char) 3, (char) 23431,
        Double.longBitsToDouble(0x3fe2cc84f49f65dcL), Double.longBitsToDouble(0x3fe13b2ed0fa6dffL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 2, "\ua131\ud806\udfa1\uda08\udd02\ud862\udc38", "\u3593\u6a8d\u6d2a\u0a84\u1409\ucf53\u3292\ua578\u44e1\u32ad\ud380\u2eca", "\uda54\ude8f\ud844\udd76\udbd6\udf6b\udb9e\udd9c\uda5e\udceb\ud803\udc8d\udba9\uddb8\ud9b5\udfe2\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14\uda25\udf1b\ud8eb\udfa1\udbff\udcb8\ud9f3\udd06\ud995\ude0a\ud8bf\udf34\udb4d\udec6\udb48\udeae\uda10\uddf7\ud8f8\udf32\uda0c\udf4e\uda97\udd91\udafa\udd72\uda72\ude2f",
        -5, 29442, -394543087, -773981412780531447L, 14489L, true, true, (char) 6209, (char) 4460,
        Double.longBitsToDouble(0x3fdf82bf3173433eL), Double.longBitsToDouble(0x3fd0d40abb282bf6L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "\000\ud8f7\ude3b\uda21\udc15\ud9af\udd06\ud989\udcfb\ud8d4\udec0\000", "\u4c57\u8577\ucfad\u9509\uaace\000", "\ud861\ude00",
        29, 34009, -1165704153, 3788158807412436604L, -28514L, false, false, (char) 9693, (char) 46263,
        Double.longBitsToDouble(0x3fde24336b8ec5baL), Double.longBitsToDouble(0x3e88000000000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "\ud8e6\ude08", "\ucc86\u90da\u6100\u8d13\uc144\u6d2a\u4c57", "\ud8ab\udc71\udaba\udef6\ud919\udfe3\udb51\udc2d\ud801\udded\ud861\ude00\ud962\ude99\ud855\ude2e",
        57, 66453, 1687547516, -157955024550846157L, -28514L, false, false, (char) 9693, (char) 46263,
        Double.longBitsToDouble(0x3fde24336b8ec5baL), Double.longBitsToDouble(0x3fd8ce10c7c9c8baL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "\000\ud920\udc3b\u56f0\000\000\ud835\udf79\udb2a\uddbd", "\u4c57", "\ud8ab\udc48\uda56\ude63\000\udbfc\uddde\ud801\udded\ud861\ude00\ud962\ude99\u2169",
        55, 93197, 9825916, -158188936908725965L, -100000L, false, false, (char) 0, (char) 36351,
        Double.longBitsToDouble(0x3fde24336b8ec5baL), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 4, "\ud9fc\udff0", "\u3a7f\ub018\ubba5\u363c\u64db\u0089\000\000\u9aaa\u9245\u77a7\u58c5", "\ud923\udeee\ud962\ude99\000\000\000\uda8b\udde4\udbad\udfd4q\u73ef\udbb2\udcc0\ud8f8\udca8\uda43\udc4f\u901e\ufad2\ud99d\udd14\uda1a\udcd0\udb3f\udfab\uda20\uddae\ud9f3\udd1a",
        11, 69556, 1037496551, 9078273764572358515L, 11866L, false, false, (char) 33748, (char) 23137,
        Double.longBitsToDouble(0x3fd4492fa3181dcaL), Double.longBitsToDouble(0x3fe5cb42d49cf185L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\ud9fc\udff0\uda85\ude9b\udaf3\udc2d\ud96b\udf63\uda86\udc8c\udb99\udfca\udb0c\uddc2\udba9\udd9e\udba3\udd11\ud9e1\udc2d\ud954\udc4f\uda62\udc09\ud86a\udf5d\udbe0\udc7a\ud80e\udd13\udb99\udc67\ud8ae\udebd\ud916\ude09\ud962\ude99\udbff\udd28\ud986\udc14\ud844\udd76\udbd6\udf6b\udbad\udfd4\udaca\ude8e\ud90a\udf80\uda5d\ude14\ud952\udcaf\ud96c\udd3b\uda2b\ude20\ufad2\udb15\udcc9\uda1a\udcd0\udb3f\udfab", "\u823d\ua34c\u4340\ua40d\uc791\ub5d4\u2c1d", "\ud967\udcf0\ud805\ude63\udbd3\udc3d\ud86a\udc7c\udb1b\ude96\ud97b\udf9e\udaef\udccd\udb42\uddad\ud96a\udca8\u4745\ud992\udeef\udaa2\udfe3\uda31\uddf8\udb8f\udcef\uda55\ude8e\uda68\udfad\uda8c\udf09\udae7\uddef\ud8bf\udc19\ud9f7\ude8b\ud9ea\udec6\ud932\udf19\ud82c\udf56\ufb0a\ud8e3\udf17\ud92f\udcc0\udaef\udf2f\ud852\udfec",
        44, 93706, 1607876112, -4651668239268437122L, 51964L, false, false, (char) 10105, (char) 21237,
        Double.longBitsToDouble(0x3fe232735b19b9deL), Double.longBitsToDouble(0x3fe103e3bb380423L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud9fc\udff0\uda85\ude9b\uda23\udec5\ud96b\udf63\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\udb79\udc2a\ud93f\udde2\ud93e\udd37\udb69\udf67\ud935\udfbf\udbeb\udc16\udb98\udfe9", "\ub30a", "\ud844\udd76\udbd6\udf6b\udbad\udfd4",
        45, 7820, 701632074, -1159270517891669493L, 47028L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fd9f8bca7ac241cL), Double.longBitsToDouble(0x3fe4b8ac17f4e4b4L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 4, "\ud9fc\udff0\uda85\ude9b\uda23\udec5\ud96b\udf63\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\udb79\udc2a\ud93f\udde2\ud93e\udd37\udb69\udf67\ud935\udfbf\udbea\udfeb\udb98\udfe9", "\ub30a", "\ud844\udd76\udbd6\udf6b\udbad\udfd4",
        45, 7820, 1115562313, 5215469548193087714L, 15116L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fd9f8bca7ac241cL), Double.longBitsToDouble(0x3fe4b8ac17f4e4b4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\000\000\000\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\udb79\udc2a\ud93f\udde2\ud93e\udd37\udb69\udf67\ud935\udfbf\uc87b\000", "\ub30a", "\ud844\udd76\udbd6\udf6b\udbad\udfd4",
        45, 7820, 701632074, -1159270517891669493L, 47028L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fd9f8bca7ac241cL), Double.longBitsToDouble(0x3fe4b8ac17f4e4b4L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 4, "\ud9fc\udff0\uda85\ude9b\uda23\udec5\ud96b\udf63\uda86\udc8c\udb99\udff2\ud9f9\udf52\u20af\udbaa\udea6\udb79\udc2a\ud93f\udde2\ud93e\udd37\udb69\udf67\ud935\udfbf\udbeb\udc16\udb98\udfe9", "\ub30a\ub157\u028b", "\udbad\udfd4\ud8b3\udc6b",
        6, 85074, -280927765, 2773058530706624061L, -25750L, true, true, (char) 40847, (char) 38249,
        Double.longBitsToDouble(0x3feeb09072971582L), Double.longBitsToDouble(0x3fefa725a78ef7deL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud9fc\udff0\uda85\ude9b\uda23\udec5\ud96b\udf63\ud91f\udfd9\uda78\ude53\ud93c\ude51\ud800\udc01\udbaa\ude6c\udb79\udc2a\ud925\udc56\ud93e\udd60\udb4c\udd98\ud935\udfbf\udbeb\udc16\udb98\udfe9", "\ub30a", "\ud881\ude09\udbd6\udfe5\udbad\udfd4",
        45, 7820, 701632074, -1159270517891669493L, 47028L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fd9f4de57ac241cL), Double.longBitsToDouble(0x3fe4b8ac17f4e4b4L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 2, "P\000\000\ud96b\udf4d\u13ec\000\udb0c\uddc2\u4f93\udb44\udc6a\000\000\u00a2\udb45\udd22\uda53\ude0d\ud8f2\udf98\udb4d\ude86", "\ub30a", "\ud844\udd76",
        48, -1000, 1132326912, -4971973111742067126L, -100000L, false, false, (char) 43993, (char) 40847,
        Double.longBitsToDouble(0x3e1ac24000000000L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=new org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 5, 4, "\ud9fc\udff0\uda85\ude9b\uda23\udec5\ud96b\udf63\uda86\udc8c\ud99e\udeea\udb0c\uddc2\u4f93\uda7d\udcf5\uda32\uddb7\udbe3\udd35\ud93e\udcc5\ud80b\udd6c\ud935\udfbf\udbeb\udc16\udb98\udfe9", "\ub30a", "\ud844\udd76\udbd6\udf6b\udbad\udfd4",
        45, 7820, 701632074, -1159270517891669493L, 47028L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fd9f8bca7ac241cL), Double.longBitsToDouble(0x3fe4b8ac17f4e4b4L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud9fc\udff0\uda85\ude9b\uda23\udec5\ud96b\udf63\uda86\udc8c", "\u64db\u4054\u0a84\u9041\u8c5d\u70ac\u77a7\u8111\ua035\u6999\uafbb\ub30a\ub157", "\udbd6\udf6b\udbad\udfd4\ud8b3\udc6b\udb35\udec3\udbb2\udcc0\ud8f8\udca8\uda43\udc4f\u901e\ufad2\ud99d\udd14\uda1a\udcd0\udb3f\udfab\ud964\udeaf",
        33, 13151, 1350182900, -7429999682023444558L, 75376L, true, false, (char) 8427, (char) 5619,
        Double.longBitsToDouble(0x3fd58a4811e021eaL), Double.longBitsToDouble(0x3fea9f4ca65f4a09L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 0, "\uf850", "\u3a7f\ub018\ubba5\u363c\u64db\u4054\u28a1\u684c\u8c5d\u70ac\u9e78\000", "\ud923\udeee\ud962\ude99\ud855\ude2e\ud986\udc14\ud844\udd76\udbd6\udf6b\udbad\udfd4\ud8b3\udc6b\udb35\udec3\uda16\ude6a\ud8f8\udca8\uda43\udc4f\u901e\000\000\000\000\000\000",
        52, 62476, -187865656, 5566402102007888044L, 76962L, false, true, (char) 54467, (char) 61809,
        Double.longBitsToDouble(0x3fb1aa2cbb9d3ae8L), Double.longBitsToDouble(0x3fe4d760d2263807L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\ud9fc\udff0\uda85\ude9b\uda23\udec5\ud96b\udf63\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\udb79\udc2a\ud93f\udde2\ud8a1\udee5\udb69\udfeb\ud935\udfbf\udbeb\udc16\udb98\udfe9\ud8ae\udebd\ud923\udeee\ud830\ude08\udbd3\udd42\uda0e\ude19\udbe1\udd25\udbd6\udf6b\udbad\udfd4\ud8b3\udc6b\udb35\udec3\udbb2\udcc0\ud8f8\udca8\ud873\udc88\uda72\udf86\ud84a\uddc6\ud99d\ude06\uda1a\udcd0\udb3f\udfab\ud964\udeaf\ud9f3\udd1a\udaee\udcf7\ud940\udeae\udb88\udda3\ud939\udddd\ud9dd\udd3c\udba3\uddd8\ud245\ud979\uddca\udaf7\udd2e\ud8d1\udc79\uda38\udfb1\u12cb\ud8da\udf18\udb57\ude4a\ud8a5\ude97\ud974\udfac\ue592\udbb4\udc18\uda39\udeb7\udaa0\udc42\ud859\udf34\udbcc\udc21\udafe\uddec\udbe6\udda4\udae4\udfc8\ud80f\udff7\ued4f\ud84b\udf2c\udbc3\udc28\udb79\udcf7\ud91d\udf42\udbf3\udd24\udac4\ude56\udb6d\ude5d\ud05c", "\uaadf\ub90f\u0362\u9e5d\u2824\ud41f\uc2cc\uc4ea\u9092\uc5f4\u5db7", "\udb70\udfe0\ud8ee\udf0c\ud90a\udd63\ud8f9\udc3d\ud958\udc92\udbab\udfe9\udada\uddfd\udb73\udd11\ud8ba\udfee\ud99d\udc39\ud9c5\udf53\uda3e\ude79\ud888\udd56",
        45, 93247, -1611478783, 4247067960166507912L, -69667L, false, true, (char) 43326, (char) 11222,
        Double.longBitsToDouble(0x3fcc242efe1356acL), Double.longBitsToDouble(0x3fd980cf32e16a42L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\uda4b|-\udcd6|-\uda85|-\ude9b|-\uda23|-\udec5|-\ud96b|-\udf63|-\udae7|-\udebc] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 1, "\uda4b\udcd6\uda85\ude9b\uda23\udec5\ud96b\udf63\udae7\udebc", "\u64db\u5bdd\u0a84\u0b22\ub94e\u5100\u7886\u8111\ua862\u6599\u7430", "\udaee\udca4",
        -5, 57628, 2018310334, 4863307538932263542L, 46317L, true, false, (char) 46301, (char) 22990,
        Double.longBitsToDouble(0x3fe0509c6b95abd9L), Double.longBitsToDouble(0x3fe42e88519f8bcaL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41\uda86\udc8c\udb99\udff2\ud99e\udc90", "\u0a84\u9041\ucf53\u9a1a\uab2e\ud3b8\ub728\u037d\u3d53\u14be", "\u1d78\udbd6\udf6b\udbb3\udc9c\ud834\udee9",
        32, 49426, 1134816998, -4576815856428382887L, 82037L, true, false, (char) 2, (char) 5657,
        Double.longBitsToDouble(0x3fe8e128f14c95cdL), Double.longBitsToDouble(0x3fc5bd2864671ba4L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.validation.DateValidator:@?\012",
        Z.run(T, 1, 3, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u580e\ua578\u44e1\u25f0\ud380\u2eca", "\uda06\udc14",
        18, 57628, -36776770, -2366464098314407112L, 67485L, false, false, (char) 35, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8850000000L), Double.longBitsToDouble(0x3e12e2b040000000L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.validation.DateValidator:@?\012",
        Z.run(T, 1, 3, 0, 2, "\ua131\ud806\udfa1\ud90b\udf70\udac1\udcc2", "\033\u6929\u4ed6\u4e42\020\u0ef3\u15fa\uca49\u866a", "\udb3c\udec0",
        12, 57420, -1162059430, 8986978548711424L, -100000L, false, true, (char) 35, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe71218040f1308L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\uda38|-\udd77|-\ud9c6|-\udf94|-\uda08|-\udd02|-\ud88a|-\udf41|-\uda86|-\udc8c|-\udaff|-\udfe5|-\udb0c|-\udcd0|-\ud907|-\udc21|-\ud9bf|-\udc0b|-\ud449|-\000|-\ud993|-\udf9f] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 1, "\uda38\udd77\ud9c6\udf94\uda08\udd02\ud88a\udf41\uda86\udc8c\udaff\udfe5\udb0c\udcd0\ud907\udc21\ud9bf\udc0b\ud449\000\000\ud993\udf9f", "\000\ud2f0\u00c8", "\ud8d5\uded5\ud844\udd74\udbd6\udf6b\udbf6\udc5f\uda66\udfe8\ud803\udc8d\ud85d\ude53\ud932\udc42\udbac\udc9f\ud9bb\udfb5\ud9ac\udfbc\ud85a\ude34\ud9fa\udfe4\ud816\ude81\udbe0\udfc5\ud982\udea7\udbe2\udf43\uda77\ude7e\ud11d\ud874\udd62",
        38, 31223, -2043014802, -4243477366909933613L, 60224L, false, false, (char) 6685, (char) 14846,
        Double.longBitsToDouble(0x3fee05b6db2301fbL), Double.longBitsToDouble(0x3fe507d138216a5eL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 0, 2, "\udb6d\udf5e\ud806\udf3d\ud9f1\udd02\ud88a\udf41\uda86\udc8c\udb99\udff2\udb0c\uddc2\ud946\udd20\ud97e\ude78\016\ud93f\udde2\ud803\udefa\ud8ab\udc71\udaba\udef6\ud92d\udd2d\udb75\udfae\ud877\udde8\udb35\udcb1", "\uabbc\uad07\u10e4\uc224\u5ef6\u11ba", "\uda43\udc7e",
        29, 33202, -1411833219, -3383738699898761595L, 27730L, false, true, (char) 26057, (char) 47284,
        Double.longBitsToDouble(0x3fa2585b02831900L), Double.longBitsToDouble(0x3fecdd2189b59e4cL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud9ab|-\udf5d|-\ud806|-\udf3d|-\udb53|-\uddc3|-\ud88a|-\udeed|-\uda86|-\udc8c|-\udb99|-\udff2|-\ud93f|-\udf2a|-\udb87|-\udcbf|-\udbaf|-\udd83|-\udb79|-\udc2a|-\udde2|-\ud803|-\udefa|-\ud8b8|-\udf71|-\uda19|-\udc64|-\u32e1|-\udb75|-\udf5e|-\ud877|-\udde8|-\udb54|-\udcb1] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\ud9ab\udf5d\ud806\udf3d\udb53\uddc3\ud88a\udeed\uda86\udc8c\udb99\udff2\ud93f\udf2a\udb87\udcbf\udbaf\udd83\udb79\udc2a\ud93f\udde2\ud803\udefa\ud8b8\udf71\uda19\udc64\u32e1\udb75\udf5e\ud877\udde8\udb54\udcb1", "\uabbc\u6e4b\u3df5\uc224\u5ef6\u42f1", "\uda43\udc7e",
        29, 85306, -19324406, -2574788656822262111L, -68838L, false, true, (char) 8286, (char) 22397,
        Double.longBitsToDouble(0x3fd0eda803e1e5acL), Double.longBitsToDouble(0x3fe4f0595e99e21bL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udb6d|-\udf5e|-\ud806|-\udf3d|-\ud9f1|-\udd02|-\ud9b6|-\udfa1|-\uda3b|-\udd83|-\ud8f1|-\udc20|-\uda85|-\udc75|-\ud9db|-\udea8|-\udaa8|-\udf63|-\udb7b|-\udf85|-\ud93d|-\udfe2|-\ud803|-\udf07|-\udb02|-\ude0e|-\udac8|-\ude1f|-\udbc7|-\uddf4|-\udb75|-\udfd0|-\ud88a|-\udf32|-\uda56|-\udd57|-\uda62|-\udf2d|-\ud855|-\ude2e|-\ud8b8|-\udd30|-\ud947|-\ude94|-\udbd6|-\udf9a|-\udb5f|-\udd12|-\uda5e|-\udceb|-\udc8d|-\ud82a|-\udc99|-\udb47|-\udc5c|-\ud899|-\udf48|-\ud975|-\udd71|-\udb3f|-\udd27|-\ud99d|-\udd65|-\ud9f9|-\ude5c|-\udfab|-\udbff|-\udcb8|-\ud9f3|-\udd06|-\ud9c5|-\udde3|-\udb87|-\udd61|-\ud905|-\udc73|-\ud977|-\udc47|-\udb11|-\udc9b|-\uda64|-\udcd5] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\udb6d\udf5e\ud806\udf3d\ud9f1\udd02\ud9b6\udfa1\uda3b\udd83\ud8f1\udc20\uda85\udc75\ud9db\udea8\udaa8\udf63\udb7b\udf85\ud93d\udfe2\ud803\udf07\udb02\ude0e\udac8\ude1f\udbc7\uddf4\udb75\udfd0\ud88a\udf32\uda56\udd57\uda62\udf2d\ud855\ude2e\ud8b8\udd30\ud947\ude94\udbd6\udf9a\udb5f\udd12\uda5e\udceb\ud803\udc8d\ud82a\udc99\udb47\udc5c\ud899\udf48\ud975\udd71\udb3f\udd27\ud99d\udd65\ud9f9\ude5c\udb3f\udfab\udbff\udcb8\ud9f3\udd06\ud9c5\udde3\udb87\udd61\ud905\udc73\ud977\udc47\udb11\udc9b\uda64\udcd5", "\uc693\ubcd6\ud35c\u24ee\ud3aa\u6096\u7d62\u51fe\u20a6\u2634\ud530\u5eb6\ud680\u913d\uaded\u0bd6\u13c8\ub2e4\u634f\u1e3c\u8a5e\u1888\ud15c", "\udbfc\udc55\ud917\ude4d\udb04\udfe8\uda0a\udf24\ud946\udc52\ud86c\udcc0\ud919\udf15\ud8bc\ude45\ud8ad\ude71\ud845\udc48\ud93d\udf78\udb57\udd41\udb30\udf66",
        51, 80577, 1538658867, 3934541996516272019L, 25471L, false, false, (char) 1984, (char) 22769,
        Double.longBitsToDouble(0x3fb2119558776f48L), Double.longBitsToDouble(0x3fd004578f5bea92L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "\ud9c6\ude00\ud806\udfa1\ud9ad\udc5a\034\uda86\udc8c\udb49\udca9\udb0c\uddbf\ud8e6\ude11\uda03\uddd0\udb79\udc03\ud93f\udde2\uda35\udeb5\udbae\ude33\udaba\udef6\u32bf\udb75\udf5e\ud877\udde8", "\ub157\u6a41\uacab\u8ce4\u00be\000\ua4ec\u99d9\ub90f\u7002\u45e6", "\ud8a2\uddd4\ud958\udd2f\ud886\ude83\ud876\ude66\ud866\udc95\uda0f\udca8\ud893\udd47\ud975\udce8\ud81d\udee4\uce3a\ud908\udf52\udab9\ude89\uda29\udf79\udac6\udebb",
        13, 74146, -1667428109, 7630862270745188844L, 15500L, true, false, (char) 7545, (char) 34316,
        Double.longBitsToDouble(0x3fa9fb07b5a6e370L), Double.longBitsToDouble(0x3fcfcd247ca9e90cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udae2\ude4e\ud806\udf62\ud944\udec1\udbfe\udec5\uda86\udc8c\udbda\uddb3\ud84f\udf7d", "\ua08d\u1409\ucf53\ub8f3\ua578\u44e1\u32ad\ud059\u5b7a\uc8a4", "\ud844\udd76\udbd6\udf6b\udbce\udd94\udac6\ude2a\ud81e\uddec\udb9c\ude8b\ud82b\udc33\ud9ea\udd64\u4051\ud844\udc01",
        6, 73792, -1958949243, -8321398416839643203L, -652L, true, true, (char) 33581, (char) 24791,
        Double.longBitsToDouble(0x3fe5e76066599abdL), Double.longBitsToDouble(0x3fe7672ee22765daL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.DefaultOption:[-\ua036] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\ua036", "\u9388\ub018\u3f80\u3593\u6a8d\u6d2a\ua08d\u1409", "\udaba\udef6\u32bf\udb75\udf5e\udb2e\ude64\udabe\udeb4\ud897\udd1e\udaaf\udcfa\uda54\ude8f\uda61\ude65\000\udbce\udd94\uda5e\udceb\ud803\udc8d\udba9\uddb8\ud82b\udc33\ud9ea\udd64\u4051\ud844\udc01\ud99d\udd14\uda25\udf1b\ud8eb\udfa1\ud8e5\ude9e\uda66\udec8\udaaf\uddd1\uda31\udfc9\udb4d\ude59\udb48\udeae\udaf1\udd08\ud8a5\udee4\uda0c\udf4e\uda75\udcf6\udac9\udc59\uda72\ude9f\ud863\udd2e\u8915",
        14, 87826, 1705572684, 8058688637830030233L, 93856L, true, false, (char) 24420, (char) 16654,
        Double.longBitsToDouble(0x3fe55937749d5479L), Double.longBitsToDouble(0x3fd4bd2a409a614eL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ua131|-\ud806|-\udfa1] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 3, "\ua131\ud806\udfa1", "\ub018\u3f80", "\udae9\ude45\udb68\ude34\ud8e6\udcfe",
        10, 89830, -2107692450, -8052742534148672134L, -33782L, true, false, (char) 13725, (char) 315,
        Double.longBitsToDouble(0x3fe2efdccd7c3492L), Double.longBitsToDouble(0x3fdbe64bf2e3fa8eL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ua131|-\ud806|-\udfa1|-\uda08|-\udd02|-\ud862|-\udc38|-\uda86|-\udc8c|-\ud9a6|-\udfb8|-\udb0c|-\udd19|-\ud8e6|-\ude11|-\udae9|-\udec0] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\ua131\ud806\udfa1\uda08\udd02\ud862\udc38\uda86\udc8c\ud9a6\udfb8\udb0c\udd19\ud8e6\ude11\udae9\udec0", "\ucf53\u19af\ua578\u00c2\u42ab\u74d9\u4155\u1682\u9710\u9d9a", "\udbce\udd94\uda5e\udceb",
        40, 49426, 1509177062, -6383449375104398245L, -25750L, false, true, (char) 40847, (char) 65362,
        Double.longBitsToDouble(0x3faf14422316f330L), Double.longBitsToDouble(0x3fb2cf639001da58L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\udab2|-\uddc1] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 2, "\udab2\uddc1", "\u4236\u46eb\u3f80\u3593\u6a8d\u6d2a\ua08d\u1409\ucf53\u19af\ua578\u44e1\u3301\u74d9\u4155\u1682\u9710\u9d9a", "\udbce\udd94\uda5e\udceb",
        40, 49426, 1509176843, -6383449375104398245L, -25750L, false, true, (char) 62351, (char) 43851,
        Double.longBitsToDouble(0x3fe08367428eb8c4L), Double.longBitsToDouble(0x3fb2cf639001da58L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=null\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 4, 4, "\udbed\udf35\ud806\udfa1\uda08\udd02\ud862\udc38", "\u354a\u6a8d\u6d2a\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\uda54\ude8f\ud844\udd76\udbd6\udeef\udb9e\udd9c\000\uda9b\udd0d\udba9\uddb8\udb61\udfd8\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14\uda25\udf1b\ud8eb\udfa1",
        8, 9138, 982430359, 0L, -100000L, false, false, (char) 3, (char) 23431,
        Double.longBitsToDouble(0x3fe2cc84f49f65dcL), Double.longBitsToDouble(0x3fe13b2ed0fa6dffL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 2, "\ud9fc\udff0\uda85\ude9b\uda23\udec5\ud8d7\udd3c\ud8cf\udd38\udb99\udfb6\udb0c\uddc2\u4f93\udbaa\ude6c\udb79\udc2a\ud93f\udde2\ud93e\udd37\udb69\udf67\ud935\udfbf\udbea\udfeb\ud957\udec9", "\ub30a", "\ud844\udd76\udbd6\udf6b\udbad\udfd4",
        45, 7820, 1115569714, 5215469548193087714L, 14953L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fcf959944d04b68L), Double.longBitsToDouble(0x3fdf0e6507041586L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\000\000\000\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\ud8b9\udceb\ud93f\udeb7\uda20\udc61\udb69\udf67\ud935\udfbf\uc87b>", "\ub30a", "\ud844\udd76\udbd6\udf6b\udbad\udfd4",
        45, 7820, 701688394, -1159270517891669493L, -18508L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fecfc5e53d612b2L), Double.longBitsToDouble(0x3fe4b8ac15ec847aL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "P\000\000\ud96b\udf4d\u13ec\000\udb0c\uddc2\u4f93\udb44\udc6a\000\000\u00a2\udb45\udd22\uda53\ude0d\ud8f2\udf98\udb4d\ude86", "\ub30a", "\ud844\udd76",
        48, -1000, 1132326912, -4971973111742067126L, -100000L, false, false, (char) 43993, (char) 40847,
        Double.longBitsToDouble(0x3fd0000001ac2516L), Double.longBitsToDouble(0x3ec04ae000000000L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\uda55\udf1f\udae2\udd49\udb3f\udf54\ud943\udee1\uda76\udf29\udb84\udf03\udb45\udd4c\udb79\udd77\ud929\ude8d\ud92e\udeb7", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        47, 33098, 802295370, 19455236128859821L, -99976L, false, false, (char) 9690, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748d61200L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.validation.DateValidator:@?\0121=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 2, 0, "\ua131\ud806\udfa1\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u0a84\u9041\ucf53\u580e\ua578\u44e1\u25f0\ud380\u2eca", "\ud86a\udf65",
        25, 57628, -36776770, -2366463673112644808L, 67485L, false, false, (char) 35, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8850000000L), Double.longBitsToDouble(0x3e12e2b040000000L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 0, 0, "\ua131\u00f7\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u9441\u9041\ucf53\u580e\uaace\u44e1\u25f0\ud380\u2eca", "\uda47\udc0d",
        18, 57628, -50277186, -2366464098314407112L, 67485L, false, false, (char) 27, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e12e2b040000000L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 0, 2, "\ua131\ud806\udfa1\ud90b\udf70\udac1\udcc2", "\033\u6929\u4ed6\u4e42\020\u0ef3\u15fa\uca49\u866a", "\udb3c\udec0",
        12, 57420, -1162059430, 8986978548711424L, -100000L, false, true, (char) 25, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe7121800dbc03cL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 0, 4, "\ud9d4\udd67\ud96e\udc2c\udbcc\ude13\ud817\udf2b\ud8b9\udc6b\ud973\udc5e\u981b\udb1e\udc0eg\udb53\udfe9\020\ud84a\udd24\ud805\udce1\ud961\ude69\ud9cc\udc3b\ud9ee\ude2c\ud94b\udd07\u5cc6\ud9b7\uddcd\udabc\udcb0\udaa3\udecb", "\u029e", "\000",
        -5, -1000, 1124073472, 1371362451962302509L, -58960L, false, false, (char) 26734, (char) 61880,
        Double.longBitsToDouble(0x3fd9574aeb673abcL), Double.longBitsToDouble(0x3fde5bce0d99da6aL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 0, 2, "\ua0ae\u9191\ud90b\udf30\udac1\udcc2\ud8b9\udc69\ud973\udc5e\033\udb1e\udc0e\u4ed6\ud8b4\udeba", "\u164e", "\u00e9\000\uda1c\udd22\ud8d5\udca0\ud966\udcb1\ud886\ude11\ud9e0\udec9\000\udaab\udc90\ud957\udef4\ud826\udf02\ud8ce\udc06\000\000\udb26\udff2\ud844\udc01\ud8bd\ude59\uda80\udc30",
        59, 46716, 981720605, -1921347401443887234L, 44074L, false, true, (char) 43298, (char) 33109,
        Double.longBitsToDouble(0x3fdaf5c3a722cc40L), Double.longBitsToDouble(0x3fee868850c8c64eL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb6d\udf5e\ud806\udf3d\ud9f1\udd02\ud9b6\udfa1\uda3b\udd83\ud8f1\udc20\uda85\udc75\ud9db\udea8\udaa8\udf63\u993b\udb97\uded7\udade\udf72\udb02\ude0e\uda56\udfd4\udbc7\udd8f\ud947\ude00\ud88a\udf32\uda56\udd57\udb93\ude9e\ud84d\udf49\ud8b8\udd30\ud947\ude94\uda14\udc99\udb5f\udc99\uda5e\udceb\udb70\udc64\ud802\udca8\udb47\udc5c\ud8de\udced\u56b7\ud805\uddad\ud9ca\udfd3\ud877\ude80\u39f0\ud8b4\udfd6\uda14\udc92\ud8c5\udcc2\ud80f\udc25\ud905\udca9\ud977\udc97\udaf5\ude9b\ud813\udc8c", "\uc556\ubcd6\ud35c\u24ee\ud3aa\u6096\u7d62\u51fe\u21a6\u7e23\ud530\u5eb6\ucb2f\u327d\uaded\u44c2\u3e37\ub2e4\u634f", "\udade\udcf3\udbfd\udf0d\udadd\udd34\ud8b8\udd0d\udbfc\udc55\uda85\ude9d\udb1a\ude5d\u0520\udbb4\udc99\ud86c\udcc0\ud919\udf15",
        2, 65214, -1583272190, -7253489861597722505L, -18697L, true, true, (char) 53499, (char) 26192,
        Double.longBitsToDouble(0x3fd3c3ea60811148L), Double.longBitsToDouble(0x3fe0fb3a437867c1L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "\ud9c6\ude00\ud806\udfa1\uda35\udd1e\022\uda86\udc8c\udb03\ude67\udad7\udeda\ud8da\ude14\uda03\uddd0\udb79\udc03\ud93f\udde2\uda35\udeb5\udbae\ude33\udaba\udef6\u32bf\udb75\udf5e\ud877\udde8", "\ub157\u426d\uacab\u8ce4\u00be\000\ua4ec\u99d9\ub90f\u7002\u45e6", "\ud8a2\uddd4\ud958\udd2f\ud886\ude83\ud876\ude66\ud866\udc95\uda0f\udca8\ud893\udd47\ud975\udce8\ud81d\udf4e\uce3a\udb33\udcf7\udac8\udc80\ud866\udc71\udad9\ude2e",
        13, 74146, -1663037197, 7630862270745188844L, 15500L, false, false, (char) 7545, (char) 34316,
        Double.longBitsToDouble(0x3fa9fb07b5a6e370L), Double.longBitsToDouble(0x3fcfcd247ca9e90cL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 2, 0, "\ud9c6\ude00\ud806\udfa1\ud8ec\udff9\021\uda86\udc8c\udb49\udca9\udb0c\uddbf\ud8e6\ude11\uda03\uddd0\udb79\udc03\ud93f\udde2\uda64\udecb\ud949\ude33\udaba\udef6\u32bf\udb75\udf5e\ud877\udde8", "\ub142\ucbbc\u0417\u8ce4\u00be\000\ua4ec\u99d9\ub90f\u7002\u45e6", "\ud8a2\uddd4\ud958\udd2f\ud886\ude83\ud876\ude66\ud866\udc95\uda0f\udca8\ud893\udd47\ud975\udce8\ud81d\udee4\udac3\ude11\ud908\udf52\udab9\ude89\uda29\udf79\udac6\udebb",
        13, 74146, -1667428109, 7630862270745188844L, 15500L, true, false, (char) 7545, (char) 4544,
        Double.longBitsToDouble(0x3fc4767c73d5665cL), Double.longBitsToDouble(0x3fcfcd3d1ca9e90cL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 4, "\udbed\udf35\ud806\udfa1\uda08\udd02\ud862\udc38", "\u354a\u6a8d\u6d2a\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\uda54\ude8f\ud844\udd76\udbd6\udeef\udb9e\udd9c\000\ud9f9\ude7b\udba9\uddec\ud8b2\ude0e\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14\uda25\udf1b\ud8eb\udfa1",
        8, 9138, 982430359, 0L, -100000L, false, false, (char) 3, (char) 23431,
        Double.longBitsToDouble(0x3fe2cc84f49f65dcL), Double.longBitsToDouble(0x3fe13b2ed0fa6dffL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 1, 4, "\udbed\udf35\ud806\udfa1\uda08\udd02\udbe0\ude55", "\u1970\u6740\u1ce1\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\uda6a\udce9\uda12\udf7e\ud974\udfbf\ud804\udc14i\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\u4233\ud844\udc01\ud99d\udd14\uda04\ude46\udb70\udeff",
        5, 8952, 982430359, 0L, -100000L, false, false, (char) 9, (char) 26759,
        Double.longBitsToDouble(0x3fd2a84be93f4168L), Double.longBitsToDouble(0x3fe13b2ed0fa6dffL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\000\000\000\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\ud8b9\udceb\u5fe5\000\udb69\udf67\010\000>", "\ub30a", "\ud844\udd76\uda8b\udde4\udbad\udfd4",
        45, 7820, 701688394, -1159270517891669493L, -100000L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fecfc5e53d612b2L), Double.longBitsToDouble(0x3ec057b000000000L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\000\ud90f\udf87\007\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\ud8b9\udceb\ud93f\udeb7\uda20\udc61\udb69\udf67\ud935\udfbf\uc87b\udac0\udc7a", "\ub30a", "\ud844\udd76\udb13\udcf2\uda16\udd03",
        18, 26004, 701688394, -1159833467845090805L, 80652L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fecfc5e53d612b2L), Double.longBitsToDouble(0x3fc5331046bde95cL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\000\000\000\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\ud8b9\udceb\ud93f\udeb7\uda20\udc61\udb69\udf67\ud935\udfbf\uc87b>", "\ub30a", "\udabc\udc53\uda64\udd23\ud9f0\uddf8",
        45, 7820, 701688394, -1159270517891669493L, -18508L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fecfc5e53d612b2L), Double.longBitsToDouble(0x3fe4b8ac15ec847aL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 3, "\ud9e2\udc74\ud81e\udd58\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\uda55\udf1f\udae2\udd49\udb3f\udf54\ud943\udee1\uda76\udf29\uda85\udc62\udb45\udd82\udb79\udd77\ud929\ude8d\ud92e\udeb7\udb02\udf31\ud916\udcee\ud97e\udfde\uda13\udc49\ud832\udd75\udbcc\udebc\uda63\udcc1\udacc\udd5b\ud865\udc93\uda64\udef5\ud9a8\udd1b\ud811\ude73\uda24\udcf1\uda80\udc1e\030\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\uda42\udf8a\uda90\udcdd\000\ud8e1\uded0\uda3f\udd24\uda32\udd72\ud944\udfd2\uda1a\ude66\ud80f\udf1f\udb4c\udcad\uda6a\uddd2\ud923\udc54\udb6f\ude9f\uda4f\ude6d\ud8d3\uddc2\udb1a\udd26\udbfa\udf24\ud93e\ude8e", "\ua334\ud007\u93e8\u700d\uaa78\ua7da\uc035\u648b\u1c99\ucefb\u9891\u7c11\u90b0\u2775\uaaf6\u83d5\ua82a\u7bba\u34e1\u3c90\u1b96\uafd5\u3b52\u5f7d", "\ud91a\udffb\ud835\udf62\ud8e4\udc26\uf9e1\ud805\udf65\ud91d\uddef\uda19\udcc6\ud825\udcc2\udbfd\udd13\udbac\udd1f\ud887\udf90\udb12\udd13\uda17\udc3d\ud952\udd22\uda7e\ude78\u4f02\ud9d0\udccd\ud856\uddd8\udbc4\udea4\udb3e\udd06\udb0d\udf53\ud8b7\udd40\ud8d7\ude61\ud885\udeba\udb7a\udff4\udb2a\udc0b\ud9ba\udd0b\ud920\udd4e",
        37, 52921, 1996431758, -4506311445876541581L, 18064L, false, true, (char) 25443, (char) 3187,
        Double.longBitsToDouble(0x3fd91be528d14a84L), Double.longBitsToDouble(0x3fde2c12b9ae4888L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\udba8\udd2a\uda56\udd55\udae2\udd49\udb3f\udf54\ud943\udee1\uda76\udf29\udb84\udf03\udb45\udd4c\udb79\udd77\ud929\ude8d\ud92e\udeb7", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        47, 33098, 802295370, 3839202981916835905L, -99976L, false, false, (char) 9820, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748d61200L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\006\ud82e\udf8b\udae2\udd49\udb3f\udf54\ud943\udee1\uda76\udf29\udb84\udf03\udb45\udd4c\udb79\udd77\ud929\ude8d\ud92e\udeb7", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        47, 33098, 802295370, 19455236128859821L, -99976L, false, false, (char) 9690, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98749d61200L), Double.longBitsToDouble(0x3fd96504a8ff1a16L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\uda55\udf1f\udae2\udd49\udb3f\udf54\ud943\udee1\u0091\udb84\udf03*\000\ud929\ude8d\ud84c\udc05", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        47, 33098, 802295370, 19455235491325613L, -100000L, false, false, (char) 9690, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748d61200L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 0, 0, "\ua131\u00f7\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u9441\u9041\ucf53\u580e\uaace\u44e1\ud364\ud380\u2eca", "\uda47\udc0d\ud844\udd76\udbd6\udf6b",
        49, 69641, -834587848, 6070007873900113638L, 67485L, false, false, (char) 13, (char) 0,
        Double.longBitsToDouble(0x3e399a0000000000L), Double.longBitsToDouble(0x3fc731b7225c5608L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 0, 2, "\u1ef1\udab5\ude97\udb6c\ude03\udac1\udcc2", "\ucbc7\u6929\u4ed6\u4e42\020\u0ef3\u15fa\uca49\u6a6b", "\ud887\udc06",
        22, 68076, -813911844, 8986977105870848L, 65059L, true, true, (char) 22, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe7121800dbc03cL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 0, 4, "\ud9d4\udd67\ud96e\udc2c\udbcc\ude13\ud817\udf2b\ud8b9\udc6b\ud973\udc5e\u981b\udb1e\udc0eg\udb53\udfe9\020\ud84a\udd24\ud805\udce1\ud961\ude69\ud9cc\udc3b\ud9ee\ude2c\ud94b\udd07\020\000\udabc\udcb0\udaa3\udecb", "\u029e", "\000",
        -5, -1000, 1124073472, 1371362451962302509L, -58960L, false, false, (char) 26734, (char) 61880,
        Double.longBitsToDouble(0x3fd9574aeb673abcL), Double.longBitsToDouble(0x3fde5bce0d99da6aL)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb6d\udf5e\ud806\udf3d\ud9f1\udd02\ud9b6\udfa1\uda3b\udd83\ud8f1\udc20\uda85\udc75\ud9db\udea8\udaa8\udf63\u993b\udb97\uded7\udade\udf72\udb02\ude0e\uda56\udfd4\udbc7\udd8f\ud947\ude00\ud88a\udf32\uda56\udd57\udb93\ude9e\ud84d\udf49\ud8b8\udd30\ud947\ude94\uda14\udc99\udb5f\udc99\uda5e\udceb\udb70\udc64\ud802\udca8\udb47\udc5c\ud8de\udced\u56b7\ud805\uddad\ud9ca\udfd3\ud877\ude80\u39f0\ud84d\udc3b\uda14\udc92\ud8c5\udcc2\ud80f\udc25\ud905\udca9\ud977\udc97\udaf5\ude9b\ud813\udc8c", "\uc556\ubcd6\ud35c\u24ee\ud3aa\u6096\u7d62\u51fe\u21a6\u7e23\ud530\u5eb6\ucb2f\u327d\uaded\u44c2\u3e37\ub2e4\u634f", "\udade\udcf3\udbfd\udf0d\udadd\udd34\ud8b8\udd0d\udbfc\udc55\uda85\ude9d\udb1a\ude5d\u0520\udbb4\udc99\ud86c\udcc0\ud919\udf15",
        2, 65214, -1583272190, -7253489861597722505L, -18697L, true, true, (char) 53499, (char) 26192,
        Double.longBitsToDouble(0x3fd3c3ea60811148L), Double.longBitsToDouble(0x3fe0fb3a437867c1L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud9c6\ude00\ud806\udfa1\uda35\udd1e\022\uda86\udc8c\udb03\ude67\ud855\udd9a\ud981\udece\uda03\udda6\udb79\udc03\ud93f\udde2\uda35\udeb5\udbae\ude33\udaba\udef6\u32bf\udb75\udf5e\ud877\udde8", "\ub157\u5767\uacab\uac09\u4666\u2296\ua4ec\u99d9\ub90f\u7002\u45e6", "\ud8a2\uddd4\ud958\udd2f\ud886\ude83\ud876\ude66\ud866\udc95\uda0f\udca8\ud893\udd47\ud975\udce8\ud81d\udf4e\uce3a\udb33\udcf7\udac8\udc80\ud866\udc71\udad9\ude2e",
        13, 74146, 569839859, -7372160780270826637L, 46489L, false, false, (char) 7545, (char) 34316,
        Double.longBitsToDouble(0x3fefebd87b5a4f07L), Double.longBitsToDouble(0x3fe253491f2a7a1eL)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 4, "\udbed\udf35\ud806\udfa1\udb7c\udf1d\ucc26", "\u354a\u6a8d\u6d2a\u0a84", "\ud8ab\udd11\udaba\udef6\u326a\udb75\udf5e\ud877\udde8\000\u73ef\udaaf\udcfa\uda54\ude8f\ud844\udd76\udbd6\udeef\udb9e\udd9c\000\ud9f9\ude7b\udba9\uddec\ud8b2\ude0e\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14",
        24, 44941, -1324467872, 1549981276370285207L, -100000L, false, false, (char) 0, (char) 36351,
        Double.longBitsToDouble(0x3e6b870000000000L), Double.longBitsToDouble(0x3fe2cc84f49f65dcL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 4, "\udbed\udf35\ud806\udfa1\uda08\udd02\ud98b\udfeb", "\u1970\u6740\u1ce1\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\uda6a\udce9\uda12\udf7e\ud974\udfbf\ud804\udc14i\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\u4233\uda16\udc7b\ud99d\udd4b\uda04\ude46\udb70\udeff",
        5, 8952, 982430359, 0L, -100000L, false, false, (char) 9, (char) 26759,
        Double.longBitsToDouble(0x3fd2a84be9614168L), Double.longBitsToDouble(0x3fe13b2ed3ecd6ffL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 4, "\udbed\udf35\ud806\udfa1\uda08\udd02\udbe0\ude55", "\u1970\u6740\u1ce1\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\ud90d\udda5\uda13\udc20\ud974\udfbf\ud804\udc14i\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\u4233\ud844\udc01\ud99d\udd14\uda04\ude46\udb70\udeff",
        56, 8952, 982430359, 0L, -100000L, false, false, (char) 9, (char) 26759,
        Double.longBitsToDouble(0x3fd2a84be93f4168L), Double.longBitsToDouble(0x3fe13b2ed0fa6dffL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 1, 1, 4, "\udbed\udf35\ud806\udfa1\uda08\udd02\udbe0\ude55", "\ud6e7\u6740\u1ce1\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\uda6a\udce9\uda12\udf7e\ud974\udfbf\ud804\udc14i\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\u4233\ud844\udc01\ud99d\udd14\uda04\ude46\udb70\udeff",
        5, 8952, 982430359, 0L, 96608L, false, false, (char) 42, (char) 26759,
        Double.longBitsToDouble(0x3fd2a84be93f4168L), Double.longBitsToDouble(0x3fe13b2ed0fa6dffL)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\000\000\000\ud96b\udf4d\uda86\udc8c\udb99\udff2\ua9f2\000\udb43\udfe1\ud8b9\udceb\u5fe5\000\000\010\000>", "\u5730", "\ud844\udd76\000\000",
        -3, 5860, 13822464, -1159271184257253365L, -100000L, false, false, (char) 14190, (char) 52878,
        Double.longBitsToDouble(0x3ec94f584ac80000L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\udb64\uddf1\032\udb14\udcaa\ud8e9\ude0b\ud9e7\udd7d\ud8dd\udc50\udb0c\uddc2\udbb3\udfc3\udbaa\ude6c\udac7\udd2c\udb7f\udcc0\uc348\uda49\udeb6\ud6bb\000>", "\ub30a", "\ud844\udd76\ud8e4\udf63\udbad\udf6e",
        45, 82092, 701688394, -1159270519904935413L, -100000L, false, false, (char) 14190, (char) 11269,
        Double.longBitsToDouble(0x3fecb608d538478aL), Double.longBitsToDouble(0x3fdc48a813dd5900L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\udb88\udd4e\000\000\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\ud8b9\udceb\u5fe5\000\udb69\udf67\udb17\udfa7\011>\udadc\udd2d\ud923\udeee\ud962\ude99\ud855\ude2e\ud986\udc14\ud844\udd76\uda8b\udde4\udbad\udfd4", "\uc3db\u8e89\u6fa7\uce65\000\u3643\u13ed\u0cca\u81c7\ub470\000\u3af3\ucee3\u2277\u74e6\ubf79\ubc90\u4245\ucf90\u5c92", "\udb8e\udd48\ud97a\udcd0\udb5a\ude5a\ud8f0\udc4b\ud9a4\udffe\uda66\ude57\udbbb\udcdc\ua98b\ud850\udd98\ud89a\udc28",
        48, 24874, -687829396, 4711340527880907006L, 42981L, true, true, (char) 21181, (char) 24445,
        Double.longBitsToDouble(0x3fc5457aa0bae8acL), Double.longBitsToDouble(0x3f92e8bcd92e8ae0L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 2, "\003\000\000\ud96b\udf4d\uda86\udc8c\uda45\udfe7\ud898\udfc4\u4f93\udbaa\ude6c\udb2c\udea1\ud840\udd70\000\udb69\udf67\udba6\udce6\uda2c\udf57\udab9\ude4e", "\ub30a", "\ud9ee\ude11\uda8b\udde4\udbad\udfd4",
        33, 7820, 148040266, -6779800077331602835L, -100000L, false, false, (char) 1322, (char) 4264,
        Double.longBitsToDouble(0x3fed352473d612b2L), Double.longBitsToDouble(0x3ec057b000000000L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 0, "\ud852\udee8\uda74\ude10\005\u355e\udbb3\ude59\udb99\udff2\udb0c\uddc2\ud83d\ude47\udbaa\ude6c\ud8b9\udceb\u5fe5\000\ud9ae\udd70\010\000>\udadc\udd2d\ud923\udeee\ud962\ude99\ud855\ude2e\ud986\udc14\ud844\udd76", "\uc86e", "\ud8f8\udca8\uda43\udc4f\u9e3f\000\ud99d\udd0a\uda1a\udcd0\udb3f\udfab\ud801\udcb9\udab8\udfdd\000\ud8e3\udce0\udb96\udf11\udb8a\udf7f\udbc3\udfc2\udb94\udd8e\uda16\udfee\ud9ad\udf20\ud969\udc39\udb21\udf57\uf51d\uda49\udd2d\ud833\udc6d",
        57, 76807, 1396374215, -4670676940030250934L, 21777L, true, true, (char) 52369, (char) 20309,
        Double.longBitsToDouble(0x3fc3e5312398dd7cL), Double.longBitsToDouble(0x3fd0b171ec44729cL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\000\000\000\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\ud8b9\udceb\u5fe5\000\udb69\udf67\010\udab7\udfe0\012", "\ub30a", "\ud844\udd76\uda8b\udde4\udbad\udfd4",
        45, 7820, 701688394, -1159270517891669493L, -100000L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fecfc5e53d612b2L), Double.longBitsToDouble(0x3eca37b000000000L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\000\ud90f\udf87\007\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udaa5\uddbb\ud8ab\uddf8\uda07\udc7b\ud94d\udda9\ud92b\udded\ud8fb\udcf2\uc88b\ud964\udf86", "\ub30a", "\ud844\udd76",
        19, 36782, 1873868643, -4929926653224490422L, -92331L, true, false, (char) 63181, (char) 13830,
        Double.longBitsToDouble(0x3fc2b57b2a344fccL), Double.longBitsToDouble(0x3fefef5ed3d612b2L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\ud9e2\udc74\ud81e\udd58\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\uda55\udf1f\udae2\udd49\udb3f\udf54\ud943\udee1\uda76\udf29\uda85\udc62\udb45\udd82\udb79\udd77\ud929\ude8d\ud92e\udeb7\udb02\udf31\ud916\udcee\ud97e\udfde\uda13\udc49\ud832\udd75\udbcc\udebc\udb32\ude29\udacc\udd09\ud865\udc93\uda64\udef5\ud9a8\udd1b\ud811\ude73\uda24\udcf1\uda80\udc1e\030\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\uda42\udf8a\uda90\udcdd\000\ud8e1\uded0\uda3f\udd24\uda32\udd72\ud944\udfd2\uda1a\ude66\ud80f\udf1f\udb4c\udcad\uda6a\uddd2\udb6b\udd41\udb95\udcb9\uda4f\ude6d\ud8d3\uddc2\udb1a\udd26\udbfa\udf24\ud93e\ude8e", "\ua334\ud007\u93e8\u700d\uaa78\ua7da\uc035\u648b\u1c99\ucefb\u9891\u7c11\u7faf\u2775\uaaf6\u83d5\ua82a\u7bba\u34e1\u3c90\u1b96\uafd5\u8452\u5f7d", "\ud91a\udffb\ud835\udf62\ud8e4\udc26\uf9e1\ud805\udf65\ud91d\uddef\uda19\udcc6\ud825\udcc2\udbfd\udd13\udbac\udd1f\ud887\udf90\udb12\udd13\uda17\udc3d\ud952\udd22\uda7e\ude78\u4f02\ud9d0\udccd\ud856\uddd8\udbc4\udea4\udb3e\udd06\udb0d\udf53\ud8b7\udd40\ud8d7\ude61\ud885\udeba\udb7a\udff4\udb2a\udc0b\ud9ba\udd0b\ud920\udd4e",
        37, 52921, 1996431758, -4506311445876541581L, 18064L, false, true, (char) 25443, (char) 3187,
        Double.longBitsToDouble(0x3fd91be528d14a84L), Double.longBitsToDouble(0x3fde2c12b9ae4888L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 0, 4, 3, "\ud9e2\udc74\ud81e\udd58\ud87a\uddfd\udb96\ude9c\uda63\udce8\ud864\udde8\uda55\udf1f\ud8ba\udda2\udb3f\udf54\ud943\udee1\uda86\udf31\uda85\udc62\udb45\udd82\udb79\udd77\ud88e\udcbd\udb59\ude56\udb76\udf66\ud901\udc93\ud97e\udfde\uda1c\udeee\ud8fe\udfd7\udb01\udc42\uda5f\udfae\ud8c4\ude24\ud865\udc93\uda64\udef5\ud9db\udd1b\ud811\ude73\ud89d\udd6d\uda80\udd05\030\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\udaf8\ude6a\ud9bc\udf94%\ud8e1\uded0\uda3f\udd24\uda32\udd72\ud944\udfd2\udad6\ude84\ud80f\udf1f\ud8e8\udeda\uda6a\uddef\ud923\udc54\udb6f\ude9f\udafd\udc04\udb33\udd64\udb1a\udd26\udbfa\udf24\ud8c2\ude18", "\uc279\ud007\u93e8\u4a51\uaa78\ua7da\uc035", "\ufcd3",
        8, 82826, -1598422206, 8447570388914142827L, -19508L, true, true, (char) 15054, (char) 18698,
        Double.longBitsToDouble(0x3fecd129b6149fcfL), Double.longBitsToDouble(0x3fbb8b606a69f980L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 0, 4, 3, "\ud9e2\udc74\ud886\udfb0\udb1a\udd0c\udb5a\udf38\ud9ab\udc3c\u00b6\uda55\udf1f\udae2\udd49\udb3f\udf54\ud943\udee1\uda76\udf29\uda85\udc62\udb45\udd82\ud95f\uddea\ud915\udf08\ud92e\udeb7\udb02\udf31\ud916\udcee\ud97e\udfde\uda13\udc49\ud832\udd75\udbcc\udebc\uda63\udcc1\udacc\udd5b\ud865\udc93\uda64\udef5\udae2\udf58\udb2a\udee2\udb95\ude00\uda48\udfd2\030\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\ud908\udd4d\uda90\udce9\000\ud8e1\uded0\uda3f\udd24\uda32\udd72\ud944\udfd2\uda1a\ude66\ud80f\udf1f\ud8b1\udeb6\uda6a\uddd2\ud923\udc54\udb6f\ude9f\uda4f\ude6d\ud8d3\uddc2\udb1a\udd26\udbfa\udf24\ud93e\ude8e", "\ua334\ud007\u93e8\u700d\u6fce\ube1a\uc105\ub864\uc9c6\u1b79\u6e8f\u7c11\uc30e\uab93\uab28\u83d5\ua82a\u7bba\u34e1\u3c90\u1b96\uafd5\u3b52\u5f7d\ud41b\u0fdb\u43a7\u6eff\ubdca\u6404\u18b8\ua84f\u4baf\u51c9\u27b2\uc759", "\uda17\udc3d\ud952\udd22\uda7e\ude78\udb36\udc32\udbca\ude16\ud856\uddd8\udbc4\udea4\udb3e\udd06\udb0d\udf53\ud8b7\udd40\ud8d7\ude61\ud885\udeba\udb7a\udff4\udb2a\udc0b\ud9ba\udd0b\udb81\udcc0\uda93\udd74\ufc42\udae8\udc5d\ud9f8\uddee\udb56\udcaf\ud9bd\udc03\udb3e\udeb4\udbb6\udf3b\ud984\udcaa\ud876\udc69\ue038\ud83e\udcb4\ud851\udd06\ud964\udccb\uda53\udde2\udb40\udf99\ud9ff\udc83\ud830\udf25\ud90a\udf8c\udadb\udfe9\ud837\ude41\uda5c\ude35\uda78\udc96\ud9cb\udca5\ud8fd\udc8f\u3851\udaac\udc77\ud8f1\uddbf\ud940\udcdb\udab3\ude34\uc601\udbfa\udcf4",
        43, 24925, 1042365980, 1549120997540002646L, -24655L, false, true, (char) 42235, (char) 47620,
        Double.longBitsToDouble(0x3fec5bb50df5053bL), Double.longBitsToDouble(0x3fdd8ef9c8691f28L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\u00fb+\000\000\ud971\uddb7\udba8\udd2a\uda56\udd55\udae2\udd49\udb3f\udf54\ud943\udee1\uda76\udf29\udb84\udf03*\udb60\udc6f\ud929\udd98\ud92e\udeb7", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        47, -998, 802291712, 3839202981916835905L, -99976L, false, false, (char) 9820, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748d61200L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\006\u00d7\000\000\ud943\udee1\uda76\udf29\u00e1\udb45\udd22\udb60\udc6f\ud929\ude8d\000", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        47, 33098, 802295370, 19455235483238400L, -99976L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe3d80001d61200L), Double.longBitsToDouble(0x3fd96504a0ff1a16L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 1, "\u00fb\ud9d2\udc13\ud918\udd61\udb4e\udc86\ud9c1\udc6b\014\uda55\udf1f\udae2\udd49\udb3f\udf54\ud943\udee1\u0091\udb84\udf03*\000\ud929\ude8d\ud84c\udc05", "\ud6d1", "\udacf\udf67\ud8d4\udf1b\udacc\udd5b",
        47, 33098, 802295370, 19455235491325613L, -100000L, false, false, (char) 56281, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748d61200L), Double.longBitsToDouble(0x3ec04c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\ud8bc\udcb7\ud893\udf27\udb3f\udfc0\ud943\udee1\u0091\ud905\udfa2\ud82e\udcf7@\ud9b5\udd9a\ud84c\udc05", "\u3db0", "\udbcc\udebc\udac1\udcd0\udad5\udffb",
        3, 91172, 802295370, 19455235491325613L, -100000L, false, false, (char) 65497, (char) 11473,
        Double.longBitsToDouble(0x3f5689708d724600L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=null\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\uda55\udf1f\ud891\udd00\udaac\udc2a\ud943\udeff\ud831\udc89\ud850\udc41\002\000\ud929\ude8d\ud84c\udc05", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        28, 89130, 802295370, 19455235491325613L, -100000L, false, false, (char) 33890, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748fe4d00L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\u00fb <arg>|-\udb77|-\udf3b|-\udb5a|-\udf38|-\ud9ab|-\udc3c|-\u00b6|-\uda73|-\udf97|-\ud8de|-\udd31|-\udbb0|-\udddf|-\uda7c|-\ude39|-\ud8e0|-\ude7a|-\udaeb|-\udc25|-\uda83|-\udf22|-\000|-\ud929|-\ude8d|-\uda39|-\uddbc] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\uda73\udf97\ud8de\udd31\udbb0\udddf\uda7c\ude39\ud8e0\ude7a\udaeb\udc25\uda83\udf22\000\ud929\ude8d\uda39\uddbc", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        47, 33098, 802295370, 7153157045246191277L, -100000L, false, false, (char) 27098, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748d61200L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\000\000\000\udb1b\udd04\uda85\udfa0\udb99\udff2\ua9f2\000\udb43\udfe1\ud449\u5f00\000\000\000\000>", "\u5730", "\ud844\udd19\000\000",
        -3, 5860, 13822464, -1159271184257253365L, -100000L, false, false, (char) 35583, (char) 52878,
        Double.longBitsToDouble(0x3ec940004ac80000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\udb64\uddf1\032\udb14\udcaa\ud8e9\ude0b\ud9e7\udd7d\ud8dd\udc50\udb0c\uddc2\udbb3\udfc3\udbaa\ude6c\udac7\udd2c\udb7f\udcc0\uc348\uda49\udeb6\ud6bb\000>", "\ub30a", "\ud844\udd76\ud8e4\udf63\udbad\udf6e",
        45, 82092, 701688394, -1159270519904935413L, -100000L, false, false, (char) 14190, (char) 11269,
        Double.longBitsToDouble(0x3fecb608d338478aL), Double.longBitsToDouble(0x3fd173f0a3dd5900L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\uda00\udd4a\000\000\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\ud8b9\udceb\u5fe5\000\udb69\udf67\udb17\udfa7\ud98a\udf8e\035\udadc\udd2d\ud923\udeee\ud962\ude99\ud855\ude2e\ud986\udc14\ud844\udd76\uda8b\udde4\udbad\udfd4", "\u3849\u8e89\u6fa7\ua97f\000\u3643\u13ed\u0cca\u81c7\ub470\u34f1\ub9e9\ucee3\u2277\u74e6\ubf79\ubc90\u4245\ucf90\u5c92", "\udaa1\udff1\ud971\uddec\udb5a\ude5a\ud8f0\udc4b\ud9a4\udffe\uda7f\udc49\uda0a\uddea\ud8b1\udeb5\ud956\ude5a\ud89a\udc28",
        -5, 41411, -687829396, 4711340527880907006L, 47318L, true, true, (char) 28331, (char) 28465,
        Double.longBitsToDouble(0x3fc5457320bae8acL), Double.longBitsToDouble(0x3f92e8bcd92e8ae0L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 2, "\udafc\udf40\001\000\ud96b\udf4d\uda86\udc8c\uda45\udfe7\ud898\udfc4\u4f93\udbaa\ude6c\udb2c\udea1\ud83b\udc31\ud8a5\udc32\uda1a\udd0d\udba6\udce6\uda2c\udf57\udab9\ude4e", "\u8f9c", "\ud9ee\ude11\uda8b\udde4\udbad\udfd4",
        33, 7820, 148040266, -6779800077331602835L, 31072L, false, false, (char) 1322, (char) 4264,
        Double.longBitsToDouble(0x3fed352473d612b2L), Double.longBitsToDouble(0x3ec057b000000000L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 2, "\031\000\000\ud96b\udf4d\uda86\udc8c\uda45\udfe7\ud898\udfc4\u4f93\udbaa\ude6c\udb2c\udea1\ud840\udd70\000\udb69\udf67\udba6\udce6\uda2c\udf57\udab9\ude4e", "\ub30a", "\ud9ee\ude11\uda8b\udde4\udbad\udfd4",
        33, 7820, 148040266, -6779800077331602835L, -100000L, false, false, (char) 1322, (char) 4264,
        Double.longBitsToDouble(0x3fed352473d612b2L), Double.longBitsToDouble(0x3ec057b000000000L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud852\udee8\uda74\ude10\005\u355e\udbb3\ude59\udb99\udff2\udb0c\uddc2\ud83d\ude47\udbaa\ude6c\ud449\000\000\ud9ae\udd70\010\000\000\udadc\udd2d\ud923\udeee\ud957\udc99\ud855\ude2e\ud986\udc14\ud844\udd76", "\uc86e", "\ud9ff\udeff\uda43\udc4f\u9e3f\000\ud99d\udd0a\uda1a\udcd0\udb3f\udfab\ud801\udcb9\udab8\udfdd\000\000\udb96\udf11\udb8a\udf7f\udbc3\udfc2\udb94\udd8e\uda16\udfee\ud9ad\udf20\ud969\udc39\udb21\udf57\uf51d\uda49\udd2d\ud833\udc6d",
        14, -1000, 1396374215, 13066672420159488L, 40544L, true, true, (char) 52369, (char) 20309,
        Double.longBitsToDouble(0x3fc3e5312000dd7cL), Double.longBitsToDouble(0x3fd0b171ec44729cL)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 0, "\ud984\udde3\uda74\ude10\005\u355e\udbb3\ude59\udb4f\udd2d\udb34\uddf7\ud8b7\udf20\udbaa\uddea\ud8b9\udceb\u5fe5\ud96b\uded2\udad5\udddd\027\000>\udadc\udd2d\ud923\udeee\ud900\udc48\ud855\ude2e\uda6b\udc1c\ud844\udd76", "\uc86e", "\ud8f8\udca8\uda43\udc4f\udbcb\udf90>\ud99d\udd0a\uda1a\udcd0\ud91c\ude38\udb2b\uddd3\uda9a\udfd8\000\ud8e3\udce0\udb96\udf11\udb8a\udf7f\uda51\udd29\udb94\udd72\uda16\udfee\ud9ad\udf20\ud969\udc39\udb21\udf57\uf51d\udb82\udf33\ud833\udc6d",
        57, 76807, 1396374215, -4670676940751671222L, 21777L, true, true, (char) 52369, (char) 20309,
        Double.longBitsToDouble(0x3fc3e5312398dd7cL), Double.longBitsToDouble(0x3fd39b81ec44729cL)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\000\000\000\ud96b\udf4d\uda9d\udd8c\udb99\udff2\udb67\udd9e\u6943\udbaa\ude6c\ud8b9\udceb\u5fe5\000\udb69\udf67\uda50\udc74\udb40\udcb4\015", "\ub30a", "\ud844\udd76\uda8b\udde4\ud816\ude7d",
        45, 7820, 701688394, -1159270517891669493L, -100000L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fecfc5e53d612b2L), Double.longBitsToDouble(0x3eca37b000000000L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\u9500\000\015\ud96b\udf4d\uda86\udc8c\udb99\udff2\udb0c\uddc2\u4f93\udbaa\ude6c\ud8b9\udceb\u5fe5\udbd9\udc8c\udb69\udff7\010\udab7\udfe0\ud954\uddd0\udb11\udd23\udb12\udea7\ud962\ude99", "\uacab\u3e85\u9b50", "\udbe9\udcc0\ud8f8\udca8\uda43\udc4f\u9e3f\000\ud99d\udd0a\uda1a\udcd0\udb3f\udfab\ud801\udcb9\ud942\udfe27\uda33\udd88\ud852\uded3\udab7\udc3f\uda79\udc9d\ud8b2\udc08\ud8fa\ude4e\ud85d\udf26\ud89c\udc2f\udbe9\udd6d",
        19, 15521, -74119450, -2252744835143625028L, 44189L, true, false, (char) 31224, (char) 15658,
        Double.longBitsToDouble(0x3fd438de14a7f4a4L), Double.longBitsToDouble(0x3fecf55fb58d8677L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\ud9e2\udc74\ud81e\udd58\ud87a\uddfd\udb96\ude9c\uda63\udce8\ud881\udde8\uda55\udf1f\ud8ba\udda2\udb3f\udf54\ud884\udca2\uda86\udf31\uda85\udc62\udb45\udd82\udb79\udd77\ud88e\udcbd\udb59\ude56\udb76\udf66\ud846\udf08\ud97f\udc26\uda1c\udeee\ud8fe\udfd7\udb01\udc42\uda5f\udfae\ud8b9\ude6f\ud865\udc93\uda64\udef5\uda49\udc53\ud811\uded5\ud89d\udd6d\ud9d0\uddf5 \ud994\udf0a\ud9dd\uddfe\uda66\udc83\uda82\udccc\ud837\uddef\udae2\udd57\ud8e1\uded0\udb2c\udebc\uda48\udcef\ud944\udfd2\udad6\ude84\ud80f\udf1f\ud8e8\udeda\uda6a\uddef\ud923\udc54\udb6f\ude9f\udb1d\ude14\u6c66\udb1a\udcfd\udbfa\udf24\ud8c2\ude18", "\uc279\ud007\u93e8\u4a51\u8453\u4cfe\u3f3d", "\ufcd3",
        8, 82826, -1598422206, 8447570388914142827L, -19508L, true, true, (char) 15054, (char) 18698,
        Double.longBitsToDouble(0x3fecd129b6149fcfL), Double.longBitsToDouble(0x3fbb8b606a69f980L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\ud9e2\udc74\ud81e\udd58\ud87a\uddfd\udb96\ude9c\uda63\udce8\ud864\udde8\uda55\udf1f\ud8ba\udda2\udb3f\udf54\ud943\udee1\uda86\udf31\uda85\udc62\udb45\udd82\ud8e7\udd0e\ud853\uddc8\udb59\ude56\udb76\udf66\ud901\udc93\ud97e\udfde\000\000\000\000\ud892\uddc9\ud865\udc93\uda64\udef5J\ud811\ude73\ud89d\udd6d\uda80\udd05\030\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\udaf8\ude6a\ud9bc\udf94%\ud8e1\uded0\uda3f\udd24\uda32\udd72\ud944\udfd2\udad6\ude84\ud80f\udf1f\ud8e8\udeda\uda6a\uddef\ud923\udc54\udb6f\ude9f\udafd\udc04\udb33\udd64\udb1a\udd26\udbfa\udf24\ud8c2\ude18", "\uc279\ud007\u93e8\u4a51\uaa78\ua7da\uc035", "\ufcd3",
        8, 82826, -1598422206, 8447570388914142827L, -19508L, true, true, (char) 15054, (char) 18698,
        Double.longBitsToDouble(0x3fecd129b6149fcfL), Double.longBitsToDouble(0x3fbb8b606a69f980L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud9e2\udc74\ud81e\udd58\ud87a\uddfd\ud914\uddbb\udbb8\udffa\ud809\udc7e\uda55\udf37\ud8ba\udda2\udb3f\udf54\ud943\udee1\uda26\udfd2\udb02\udf62\ud90b\udfd8\udb79\udd77\ud88e\udcbd\udb59\ude56\udb76\udf66\ud8c5\udc7f\ud839\udc7e\uda1c\udeee\ud8fe\udfd7\udb75\udd0d\uda5f\udfae\udb3f\ude28\ud865\udc93\uda64\udef5\ud9db\udd1b\ud811\ude73\ud89d\udd6d\ud896\udf70\026\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\udaf8\ude6a\ud9bc\udf94%\ud8e1\uded0\uda3f\udd24\uda32\udd72\ud8fd\udf2e\udbd6\udc5f\uda7d\uddaa\ud8a4\udfb0\ud8df\udd15\udaf8\uddf8\udb6f\ude20\udafd\udc04\udbce\udf72\udb1a\udcdc\udbfa\udf24\udb10\udffe", "\u4d5c\u9416\u93e8\u4a51\uaa78\ua7da\uc035", "\ufcd3\ud821\udd82",
        36, 2794, 1030147203, -2137522713425453726L, -97505L, false, false, (char) 32510, (char) 36048,
        Double.longBitsToDouble(0x3fe0a4fe786e2d81L), Double.longBitsToDouble(0x3fd4d3f30523167eL)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud9aa|-\udf13|-\ud92f|-\udea9|-\ud87a|-\uddfd|-\udb96|-\ude9c|-\uda63|-\udce8|-\ud864|-\udde8|-\uda55|-\udf1f|-\ud8ba|-\udda2|-\udb3f|-\udf54|-\ud943|-\udee1|-\uda86|-\udf31|-\uda85|-\udc62|-\udb45|-\udd82|-\udb79|-\udd77|-\ud88e|-\udcbd|-\udb59|-\ude56|-\udb76|-\udf66|-\udab4|-\udc90|-\ud9ae|-\udeb3|-\uda1c|-\udeee|-\ud8fe|-\udfd7|-\udb01|-\udc42|-\uda5f|-\udfae|-\ud8c4|-\ude24|-\ud865|-\udc93|-\uda64|-\udef5|-\ud9db|-\udd1b|-\ud811|-\ude73|-\ud89d|-\udd6d|-\uda80|-\udd05|-\030|-\ud994|-\udf0a|-\ud9dd|-\uddfe|-\udbb1|-\udd9c|-\udaf8|-\ude6a|-\ud9bc|-\udf94|-\udb1a|-\udf77|-\ud8e1|-\uded0|-\uda3f|-\udd24|-\ud963|-\udc0a|-\udbf4|-\udde7|-\udad6|-\ude84|-\ud80f|-\ud8e8|-\udeda|-\uda94|-\udeef|-\ud923|-\udc54|-\udb6f|-\ude9f|-\udafd|-\udc04|-\udb33|-\udd64|-\udd26|-\udbfa|-\udf24|-\ud8c2... |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 3, "\ud9aa\udf13\ud92f\udea9\ud87a\uddfd\udb96\ude9c\uda63\udce8\ud864\udde8\uda55\udf1f\ud8ba\udda2\udb3f\udf54\ud943\udee1\uda86\udf31\uda85\udc62\udb45\udd82\udb79\udd77\ud88e\udcbd\udb59\ude56\udb76\udf66\udab4\udc90\ud9ae\udeb3\uda1c\udeee\ud8fe\udfd7\udb01\udc42\uda5f\udfae\ud8c4\ude24\ud865\udc93\uda64\udef5\ud9db\udd1b\ud811\ude73\ud89d\udd6d\uda80\udd05\030\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\udaf8\ude6a\ud9bc\udf94\udb1a\udf77\ud8e1\uded0\uda3f\udd24\ud963\udc0a\udbf4\udde7\udad6\ude84\ud80f\udf1f\ud8e8\udeda\uda94\udeef\ud923\udc54\udb6f\ude9f\udafd\udc04\udb33\udd64\udb1a\udd26\udbfa\udf24\ud8c2\ude18", "\uc279\ud007\u93e8\u4a51\uaa78\ua7da\uc035", "\ufcd3",
        8, 82826, -1598422206, 8447570388914142827L, -19508L, true, true, (char) 15054, (char) 18698,
        Double.longBitsToDouble(0x3fecd129b4d66590L), Double.longBitsToDouble(0x3fb7a58e2a69f980L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud892|-\udcd5 <arg>|-\ucf5a|-\000|-\ud971|-\uddb7|-\udba8|-\udd2a|-\uda56|-\udd55|-\udae2|-\udd49|-\udb3f|-\udf54|-\ud943|-\udee1|-\uda76|-\udf29|-\udb84|-\udf03 <arg1> [<arg2> ...]|-\udb60|-\udc6f|-\ud929|-\udd98|-\ud92e|-\udeb7] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 1, "\ud892\udcd5+\ucf5a\000\ud971\uddb7\udba8\udd2a\uda56\udd55\udae2\udd49\udb3f\udf54\ud943\udee1\uda76\udf29\udb84\udf03*\udb60\udc6f\ud929\udd98\ud92e\udeb7", "\ud6d1", "\uda26\udddd\udad2\udd99\udacc\udd5b",
        47, -998, 802291712, 3839202981916835905L, -99976L, true, false, (char) 9820, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748d61200L), Double.longBitsToDouble(0x3f126b8000000000L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "", "\000", "\udba8\udd2a",
        -1, 63589, 1376537215, -1369094286550887791L, -44192L, false, false, (char) 51276, (char) 30333,
        Double.longBitsToDouble(0x3d9a1cc000000000L), Double.longBitsToDouble(0x3fe3de0801877663L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 1, "\u00fb\ud9d2\udc13\ud918\udd61\ud921\udc66\ud927\udd7f\u00fe\uda55\udf1f\udae2\udd49\udb3f\udf54\ud943\udee1\u0091\udb84\udf03\u0b2a\udb64\udfea\udb0c\udede\ud8fa\udebb\026", "\ud554\u1ecc\u7e4d\ucce3\u5969\u4001\u6e3a\uca60\u1cae", "\000\ud88b\uddc4\ud9dd\uddfe\udbb1\udd9c\uda42\udf8a\uda90\udcdd\000\ud9c1\udd33\ud87d\udf83\ud9ea\udeaa",
        57, 82582, 228883867, 353826774607366812L, -67260L, false, false, (char) 28791, (char) 50229,
        Double.longBitsToDouble(0x3fd5aa1bf8a8863eL), Double.longBitsToDouble(0x3fe6c9ee49fc05e3L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\u00fb\udb60\udd2d\udb77\udf3b\udb5a\udf38\ud859\ude94\036\ud8bc\udcb7\udbce\ude64\udb6a\udf28\ud943\udee1\u0091\ud905\udfa2\ud82e\udcf7\udb77\udc3a\udba7\udd54\ud84c\udc05", "\u3db0", "\udbcc\udebc\ud831\udc99\ud9eb\ude62",
        58, 23518, 1620887173, 9983140386530989L, -100000L, false, false, (char) 65497, (char) 11473,
        Double.longBitsToDouble(0x3f5689708d724600L), Double.longBitsToDouble(0x3ec0480000000000L)));
  }
  @Test(timeout = 4000)
  public void test133() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\u00fb <arg>|-\udb77|-\udf3b|-\udb5a|-\udf62|-\ud9ab|-\udc3c|-\u00b6|-\ud886|-\udeb7|-\ud995|-\udca7|-\u524f|-\ud85d|-\udf01|-\ud9a1|-\udf81|-\ud905|-\udec1|-\ud807|-\udf99 <arg>|-\uda2f|-\udd58|-\ud8e4|-\udc9f] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 1, "\u00fb+\udb77\udf3b\udb5a\udf62\ud9ab\udc3c\u00b6\ud886\udeb7\ud995\udca7\u524f\ud85d\udf01\ud9a1\udf81\ud905\udec1\ud807\udf99@\uda2f\udd58\ud8e4\udc9f", "\u3d84", "\udbcc\udebc\udac1\udcd0\udad5\udffb\uda9f\uddde\udb84\uddb6\ud9a8\udd1d\ud811\ude73\uffc0\u0087\udbe0\ude6b\udac7\udd43\uda97\udf26\ud83f\udda2\udbb3\udc86\udaca\udc4d\000\uf6fd\udaf0\uddb8\ud9cc\udc9b\udaf0\udd00",
        43, 95746, -962959546, 8410787125465124020L, 94147L, false, false, (char) 19457, (char) 46967,
        Double.longBitsToDouble(0x3fd07fa521b43e68L), Double.longBitsToDouble(0x3fa0384e4817e770L)));
  }
  @Test(timeout = 4000)
  public void test134() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\ud8bc\udcb7\ud8bc\udf27\ud899\udecb\ud943\udee1\u0091\ud905\udfa2\ud82e\udcf7@\ud9b5\udd9a\ud84c\udc05", "\u3db0", "\udaa8\udfea\ud891\udec4\uda66\udcc0",
        3, 91172, 802295370, 19455235491325613L, 51875L, true, false, (char) 30881, (char) 41376,
        Double.longBitsToDouble(0x3fbf00208e5c5828L), Double.longBitsToDouble(0x3fe30c3e434163feL)));
  }
  @Test(timeout = 4000)
  public void test135() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\ud8bc\udcb7\ud893\udf27\udb3f\udfc0\uda45\ude90/\ud905\udfa2\ud82e\udcf7@\ud9b5\udd9a\ud84c\udc05", "\u3db0", "\udbcc\udebc\udac1\udcd0\udad5\udffb",
        3, 91172, 802295370, 821744565055114480L, -100000L, false, false, (char) 65497, (char) 11473,
        Double.longBitsToDouble(0x3f5689708d724600L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test136() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 2, 4, 1, "\uda09\ude9f\004\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\ud8bc\udcb7\ud893\udf27\udb3f\udfc0\ud943\udee1\u0091\udbc3\udd68\ud889\udf34\010\ud9b5\udd9a\ud84c\udc05", "\u3db0", "\udbcc\udebc\udac1\udcd0\udad5\udffb",
        3, 91172, 802295370, 19455235491325613L, -100000L, false, false, (char) 65497, (char) 11588,
        Double.longBitsToDouble(0x3f5689708d724600L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test137() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "G+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\uda55\udf1f\ud891\udd00\udaac\udc2a\ud943\udeff\ud831\udc89\ud850\udc41\002\000\ud929\ude8d\ud84c\udc05", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        28, 89130, 799542858, 19455235491325613L, -100000L, true, false, (char) 33890, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748fe4d00L), Double.longBitsToDouble(0x3ec0540000000000L)));
  }
  @Test(timeout = 4000)
  public void test138() throws Throwable {
    assertEquals("0=null\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\uda55\udf1f\ud891\udd00\udaac\udc2a\036\ud830\udff8\ud850\udc41\002\000\u00f5\000", "\ud6d1", "\udbcc\udebc\uda63\udcc1\udacc\udd5b",
        28, 61738, 802295370, 19455235491325613L, -100000L, false, false, (char) 33890, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748000000L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test139() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\u00fb <arg>|-\udb77|-\udf3b|-\udb5a|-\udf38|-\ud9ab|-\udc3c|-\u00b6|-\uda73|-\udf97|-\ud8de|-\udd31|-\ud9e3|-\udff9|-\uda7c|-\ude39|-\ud8e0|-\ude7a|-\udaeb|-\udc25|-\ud983|-\udc1a|-\u052f|-\ud929|-\ude8d|-\uda39|-\uddbc|-\000|-\ud916|-\udcee|-\ud97e|-\udfde|-\uda13|-\udc49|-\ud832|-\udd75|-\udb39|-\udf33|-\uda63|-\udce5|-\udacc|-\udd5b|-\ud97d|-\udd3f|-\u0818|-\ud829|-\udc46|-\ud99e|-\udef1|-\ud8e9|-\udeb4|-\ud919|-\udf0c|-\ud9dd|-\uddfe|-\udbb1|-\udd9c|-\uda42|-\udf8a|-\uda90|-\udcdd|-\udb95|-\udf6a|-\udbb2|-\udf48|-\udaad|-\udac0|-\uddd0|-\ud9a6|-\ude86|-\udaf4|-\udedb|-\udbb0|-\udc04|-\ud9f6|-\uddd4|-\ub25f|-\ud831|-\udc13|-\ud80e|-\udd00|-\ud9f2|-\ude9d|-\ud9da|-\udd88|-\udae2|-\udcbc|-\ud9ce|-\udf9c|-\ud90f|-\udc97|-\ud88e|-\ude6f|-\ud8c7|-\ude34|-\udb24|-\udf30|-\udad0... |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\uda73\udf97\ud8de\udd31\ud9e3\udff9\uda7c\ude39\ud8e0\ude7a\udaeb\udc25\ud983\udc1a\u052f\ud929\ude8d\uda39\uddbc\000\ud916\udcee\ud97e\udfde\uda13\udc49\ud832\udd75\udb39\udf33\uda63\udce5\udacc\udd5b\ud97d\udd3f\u0818\ud829\udc46\ud99e\udef1\ud8e9\udeb4\000\000\ud919\udf0c\ud9dd\uddfe\udbb1\udd9c\uda42\udf8a\uda90\udcdd\000\udb95\udf6a\udbb2\udf48\udaad\ude8d\udac0\uddd0\ud9a6\ude86\udaf4\udedb\udbb0\udc04\ud9f6\uddd4\ub25f\ud831\udc13\ud80e\udd00\ud9f2\ude9d\ud9da\udd88\udae2\udcbc\ud9ce\udf9c\ud90f\udc97\ud88e\ude6f\ud8c7\ude34\udb24\udf30\udad0\ude93\ud9df\udff5\udb7a\udcc8\uda76\udd60\ud9cd\udd5f\ud840\udc01\ud95f\udf7b\uda11\uddbf\ud94c\udd77\ud9be\udc0b\ud935\udfb7\udac8\udfbb\ud98b\udcaf\udb9e\udc9b\ueb3a\ud97d\udc21\udb38\udf53\udb8c\udf64\ud84d\udfa5\ud8a1\udc82\ud803\udc39\udbf8\udd93\ud84d\udc75\udac4\ude54\udb34\ude10\uda1f\udd1b\ud96d\ude48\u504c\udb18\udc6b\uda5f\udddf\ud934\uddab\udb68\ude62\udb27\udf0f\udb8a\ude9e\ud90e\udfa0\uda71\udeef\udbd5\udc0c\uc675\ua93d\udb16\udf10\udb05\udc44\ud880\udf21\ud8e7\udc5a\ud87a\udd38\u134a\ud865\udc4d\ud8d4\udf80\ud9f4\udd65\udb59\udd9c\udaee\udc98\ud943\udcad\ud8cb\udef6", "\uaf24\uc236", "\uda18\ude12\ud9b2\udf44\ud9a6\udf5d\u703d\udbc3\udc3f\udbd8\udd8d\udaa5\ude7f\ud8c6\udd20\ud866\uddd2\ud951\udebb\ud829\udf08\ud936\udf7c\uda0a\udf5e\udb6f\udc4f\u14e5\ud8a9\udcc8\ud9bf\udc4e\ud984\udc74",
        3, 49710, -545406922, 1077568370803256325L, -43311L, true, true, (char) 57069, (char) 22331,
        Double.longBitsToDouble(0x3fcaf15f6bd002b4L), Double.longBitsToDouble(0x3fccddb7ddbe2538L)));
  }
  @Test(timeout = 4000)
  public void test140() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 0, "\u00fb\u762b\udb77\udf3b\udb5a\udf38\udb45\udfca\013\uda2c\udc2c\ud8de\udd9f\udbb0\udddf\uda7c\ude39\ud8e0\ude7a\udaeb\udc25\ud812\udcc9\000\ud929\ude8d\uda39\uddbc", "\u9324\u3963\uc7f4\u28ba\u3fd9\u5969\u7401\u6e3a\ub61b\uac16\u373f\ud25e\ubd92\ub3c8\uc253\u14da\u9633\u1170\000\u7504\u25b3\u3b64\ub520\uc0c7", "\ud82b\ude51\udb09\udef3\ud96b\udf66\ud84c\udef7\ud816\ude36\ud83d\ude4e\udafd\udf57\ud9ba\uddfb\uda9a\udc2f\udb89\uddb1\uda54\udc8f\uda4b\ude50\udbaa\udfb1\ud96d\udc73\udba0\udecc\ud892\udcf1\ud976\udd43\uda0c\udffc\ud829\udeda\ud84d\udc27\udae0\ude01\u5052\uda02\udf49",
        27, 68126, -398289396, -2685587856176420375L, -49655L, false, false, (char) 52205, (char) 1799,
        Double.longBitsToDouble(0x3fd4a7028e8d5718L), Double.longBitsToDouble(0x3fe4b14c9d70a476L)));
  }
  @Test(timeout = 4000)
  public void test141() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\uda00\udd4a\000\000\ud96b\udf4d\uda86\udc8c\udb99\udff2\ud962\ude8d\ud806\ude90\udb8d\udc6c\ud8b9\udceb\u5fe5\000\udb69\udf67\udb17\udfa7\ud98a\udf8e\035\udadc\udd2d\ud923\udeee\ud962\ude99\ud855\ude2e\ud986\udc14\ud9d8\udd6d\uda8b\udde4\udbad\udfd4", "\u3849\u8e89\u6fa7\ua97f\000\u7ef1\ub3ec\u90e4\u2d4f\ub470\u34f1\ub9e9\ucee3\u2277\u74e6\u8f8b\ubc90\u4245\ucf90\u5c92", "\udaa1\udff1\ud971\uddec\udb5a\ude5a\ud8f0\udc4b\ud9a4\udffe\uda7f\udc49\uda4d\udeeb\ud8b1\udeb5\udbcb\udd08\udb3f\udc4f",
        13, 41411, -687829396, 4711340527880907006L, 47318L, false, true, (char) 45248, (char) 28465,
        Double.longBitsToDouble(0x3fc545732317aa94L), Double.longBitsToDouble(0x3f92e8bcd92e8ae0L)));
  }
  @Test(timeout = 4000)
  public void test142() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udafc\udf40\001\000\ud96b\udf4d\uda86\udc8c\uda45\udfe7\ud898\udfc4\u4f93\udb66\ude6a\udb2c\udea1\ud83b\udc31\udb4e\udc06\000\udba6\udce6\uda2c\udf57\udab9\ude4e", "\u8f9c", "\ud9ee\ude11",
        30, 26334, 1124073472, -4930004753463449014L, -100000L, false, false, (char) 0, (char) 8704,
        Double.longBitsToDouble(0x3f3e654000000000L), Double.longBitsToDouble(0x3e3eb09590000000L)));
  }
  @Test(timeout = 4000)
  public void test143() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\031\000\000\ud96b\udf4d\uda86\udc8c\ud818\udc11\ud850\udf74\u4f93\udbaa\ude6c\udb2c\udea1\ud840\udd70\000\udb69\udf67\ud9de\udd31\ud5aa\udab9\ude8a\udadc\udd2d\ud92c\ude63\ud962\ude99\ud855\ude2e\udbf1\udde9\ud9de\udec9\uda56\udd39\ud807\udc5d\uda21\uddb5\udbcc\udc9c\ud846\udee8\ud9fc\ude34\uda43\udcb1\u473f\udb40\uddc0\ud822\ude31\ud8b4\udd7d\ud993\udd07\ud801\udcc0", "\u3fb3\u7494", "\ud804\udfc0\udab5\udf7e\uda18\ude5f\ud9e3\udd35\udab2\ude8c\udaa4\uddcb\ud89f\udc6c\ud97f\udcc7\ud99b\udfa9\udb1f\udfdc\ud8a2\udfea\udb44\uded1\udaf1\uddde\ud934\udd51\u47ae\ud859\ude0a",
        32, 9711, 1419412763, 3341497886399750818L, -32595L, false, false, (char) 20870, (char) 41033,
        Double.longBitsToDouble(0x3fe2b586de0a4defL), Double.longBitsToDouble(0x3fdbc60da36a3efeL)));
  }
  @Test(timeout = 4000)
  public void test144() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 2, "\031\ud874\udd79\017\ud96b\udf4d\uda86\udc8c\uda21\udc79\ud898\udfc4\ud806\ude93\udbaa\ude6c\udb2c\udea1\ud840\udd70\000\udb69\udf67\udba6\udce6\uda2c\udf57\udab9\ude4e", "\ub30a", "\ud9ee\ude11\uda8b\udde4\udbad\udfd4",
        33, 7820, 148040266, -6779800078388567443L, -100000L, false, false, (char) 1322, (char) 34497,
        Double.longBitsToDouble(0x3feb9aeb08e368d0L), Double.longBitsToDouble(0x3ec0499100000000L)));
  }
  @Test(timeout = 4000)
  public void test145() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud852\udee8\uda74\ude10\016\u355e\udbb3\ude59\udb99\udff2\udb0c\uddc2\udb13\udd33\udb05\ude2a\ud4b4\000\000\ud9ae\udd70\010\000\000\udadc\udd2d\ud923\udeee\ud957\udc99\ud855\ude2e\ud91a\udc5d\udbf4\ude83", "\u84d1", "\ud9ff\udeff\uda43\udc4f\u9e3f\000\ud99d\udd0a\ud8f7\ude3e\ud9a5\udf5f\ud801\udc71\udab8\udfdd\000\000\udb96\udf11\ud995\udd7b\udbc3\udfc2\udb94\udd8e\udb5f\uded2\uf176\ud969\udc8b\udb21\udef6\ud84a\udd34\ud956\udf8a\ud833\udc6d",
        14, -1000, -902104377, 13066672420159488L, 40544L, true, true, (char) 17042, (char) 20309,
        Double.longBitsToDouble(0x3fc3e5312000dd7cL), Double.longBitsToDouble(0x3fd0b171ec44729cL)));
  }
  @Test(timeout = 4000)
  public void test146() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud9e2\udc74\ud81e\udd58\ud87a\uddfd\ud914\uddbb\ud9e3\uddd0\uda04\udcb7\udbe5\udd78\udb89\udd3c\udb3f\udf54\ud943\udee1\uda26\udfd2\udb02\udf62\ud90b\udfd8\udb79\udd77\ud88e\udcbd\udb59\ude56\udb76\udf66\ud8c5\udc7f\ud839\udc7e\uda1c\udeee\ud8fe\udfd7\udb75\udd0d\uda5f\udfae\udb3f\ude28\ud865\udc93\ud900\udc03\ud855\ude71\udadb\udfd0\ud89d\udd6d\ud896\udf70\u009d\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\udaf8\ude6a\udb4b\udf3b%\ud8e1\uded0\uda3f\udd24\uda32\udd72\ud8fd\udf2e\udbd6\udc5f\uda7d\uddaa\ud8a4\udfb0\ud8df\udd15\udaf8\uddf8\udb6f\ude20\udafd\udc04\udbce\udf72\udac8\udd93\udbfa\udf29\udb10\udffe", "\u4d5c\u9416\u93e8\u4a51\uaa78\ua7da\uc035\u791e\u8029\uc89f\u8091\u7c11\u7a95\uaf50\u7342\u833e\ua82a\u9bba\u0565\uc0fa\u1ed7\u2403\u3b52", "\u7ae2\udb18\ude21\udb84\udc4d\ud90a\uddb1\udabc\udce5\udbb8\udcf9\ud8e0\udd68\udafa\udec1\udaf3\udf15\uda7f\udced\udb69\udc66\uda26\udd56\uda5c\udc34\ud901\uded0\ud86b\udd76\ud81b\udc9f\ud91b\udca3\ud8be\udf20\uda9a\udd6f\udaad\udc25\udae6\udc4d\ud868\udc18\uda51\udcb7\udba0\udf95\ud9f1\ude13\uda0f\uddb2\ud88b\udff8\udab1\udf63\uda03\udece\ud8a3\udd49\ud86e\udd44\udb49\udcd6\uda15\ude99\ud875\udf97\udb93\udc84\ud85a\udd02\uda7c\udc3f\udbbf\udde5\ud8cf\udc72\uda7c\udf18\udbdb\udfef\udbfe\udf30\ud910\udee9\udbc7\udf73\ud83e\uddd0\ud943\ude09\ud924\udddf\udaf3\udcfa\ud929\ude72\uda93\udd2d\udbad\udf6e\ud870\udf0f\ud870\ude6f\ud8df\uddcc\ud97e\udca7\ud86f\udef2\uda7a\udc68\udad0\udd4f\udb71\udc31\ud8ea\udce4\udac4\udda7\udb80\udf64\ud8bb\udfd7\uda6f\udc1c\ud907\udcb4\udaa1\udfae\udae6\ude3c\uda23\udf1a\u7bf4\udbf2\udc40\udb4a\udf6e\uda38\udf17\uda49\udff9\ud8ae\uddbd\udbb3\udf52\ud94b\udf7f\udbca\ude28",
        24, 29219, 245220095, -7884537962009664927L, -76455L, true, false, (char) 1070, (char) 55357,
        Double.longBitsToDouble(0x3fdc002800ccae5eL), Double.longBitsToDouble(0x3fe1b9f2a967f73bL)));
  }
  @Test(timeout = 4000)
  public void test147() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\ud9aa|-\udf13|-\ud92f|-\udea9|-\ud87a|-\uddfd|-\udb96|-\ude9c|-\ud89d|-\udf84|-\ud864|-\udde8|-\uda55|-\udf1f|-\ud8ba|-\udda2|-\udb3f|-\udf54|-\ud943|-\udee1|-\uda86|-\udf31|-\uda85|-\udc62|-\ud8a2|-\udd4b|-\udb79|-\udd77|-\ud88e|-\udcbd|-\udb59|-\ude56|-\udb76|-\udf66|-\udab4|-\udc90|-\ud9ae|-\udeb3|-\uda1c|-\udeee|-\ud8fe|-\udfd7|-\udb01|-\udc42|-\uda5f|-\udfae|-\ud8c4|-\ude24|-\ud865|-\udc93|-\uda64|-\udef5|-\ud9db|-\udd1b|-\ud811|-\ude73|-\udd6d|-\uda80|-\udd05|-\025|-\ud994|-\udf0a|-\ud9dd|-\uddfe|-\udbb1|-\udd9c|-\udaf8|-\ude6a|-\ud9bc|-\udf94|-\udb1a|-\udf77|-\ud8e1|-\uded0|-\uda3f|-\udd24|-\ud963|-\udc0a|-\udbf4|-\udde7|-\udad6|-\ude84|-\ud80f|-\ud8e8|-\udeda|-\uda94|-\udeef|-\ud923|-\udc54|-\udb6f|-\ude9f|-\udafd|-\udc04|-\udb33|-\udd64|-\udd26|-\udbfa|-\udf24|-\ud8c2|-\ude18... |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 3, "\ud9aa\udf13\ud92f\udea9\ud87a\uddfd\udb96\ude9c\ud89d\udf84\ud864\udde8\uda55\udf1f\ud8ba\udda2\udb3f\udf54\ud943\udee1\uda86\udf31\uda85\udc62\ud8a2\udd4b\udb79\udd77\ud88e\udcbd\udb59\ude56\udb76\udf66\udab4\udc90\ud9ae\udeb3\uda1c\udeee\ud8fe\udfd7\udb01\udc42\uda5f\udfae\ud8c4\ude24\ud865\udc93\uda64\udef5\ud9db\udd1b\ud811\ude73\ud89d\udd6d\uda80\udd05\025\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\udaf8\ude6a\ud9bc\udf94\udb1a\udf77\ud8e1\uded0\uda3f\udd24\ud963\udc0a\udbf4\udde7\udad6\ude84\ud80f\udf1f\ud8e8\udeda\uda94\udeef\ud923\udc54\udb6f\ude9f\udafd\udc04\udb33\udd64\udb1a\udd26\udbfa\udf24\ud8c2\ude18", "\uc279\ud007\u93e8\u4a51\uaa78\ua7da\uc035", "\ufcd3",
        8, 82826, -1598422206, 8447570388914142827L, -19508L, true, true, (char) 15054, (char) 18698,
        Double.longBitsToDouble(0x3fecd129b4d66590L), Double.longBitsToDouble(0x3fb7a58e2a69f980L)));
  }
  @Test(timeout = 4000)
  public void test148() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\u6225\ud871\udfd9\ud9df\ude8c\003\ud971\uddb7\udbc5\uded3\ud8c3\udfbf\udbc7\udec1\ud940\udeef\uda21\udfe9\uda72\udfee\udab1\uddb9\ud8d6\uddee\udb14\udfda\ud90e\udc98\udb28\uddf4", "\uc769", "\ud875\uddd9\ud81c\udfd1\udacc\udd5b",
        47, 19578, 1562559736, -5211986663604617151L, -290L, true, false, (char) 47971, (char) 4822,
        Double.longBitsToDouble(0x3f126b800140e000L), Double.longBitsToDouble(0x3fe01b78e4c007f1L)));
  }
  @Test(timeout = 4000)
  public void test149() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 5, "\u00fb+\udbcf\udec6\u9128\ud9ab\udc3c\u00b6\ud8bc\udcb7\ud893\udf27\udb3f\udfc0\uda45\ude90/\ud905\udfa2\ud82e\udcf7@\udab0\uddb8\udb0c\udd7e", "\u7c80", "\ud986\ude71\udac1\udcd0\udad5\udffb",
        3, 91172, -1012613302, 852268837498244336L, -100000L, false, false, (char) 65497, (char) 11473,
        Double.longBitsToDouble(0x3f5689708d724600L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test150() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\uda09\ude9f\004\udb77\udf3b\udb5a\udf38\ud9ab\udc3c\u00b6\ud8bc\udcb7\ud893\udf27\udb3f\udfc0\ud943\udee1\u0091\udbc3\udd68\ud889\udf34\010\ud9b5\udd9a\ud84c\udc05", "\u3db0", "\udbcc\udebc\udac1\udcd0\udad5\udffb",
        3, 91172, 902958666, -2207475592268650806L, -100000L, false, false, (char) 65497, (char) 11588,
        Double.longBitsToDouble(0x3f5689708d724600L), Double.longBitsToDouble(0x3ec0444236f80000L)));
  }
  @Test(timeout = 4000)
  public void test151() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9b5\udf62\udac5\ude5a\uda74\udc5e\ud8de\udd31\ud9e3\udff9\uda7c\ude39\ud8e0\ude7a\udaeb\udc25\ud983\udc1a\u052f\ud929\ude8d\uda39\uddbc\000\ud916\udcee\ud97e\udfde\uda13\udc49\ud832\udd75\udb39\udf33\uda63\udce5\udacc\udd5b\ud97d\udd3f\u0818\ud829\udc46\ud99e\udef1\ud8e9\udeb4\000\000\ud919\udf0c\ud9dd\uddfe\ud928\udc77\uda4b\udf6a\uda90\udcdd\000\udb95\udf6a\udbb2\udf48\udaad\ude8d\udac0\uddd0\ud9a6\ude86\udaf4\udedb\udbb0\udc04\ud9f6\uddd4\ub25f\ud831\udc13\uda5a\udd06\ud9f2\ude9d\ud9da\udd88\udae2\udcbc\ud9ce\udf9c\ud90f\udc97\ud88e\ude6f\ud8c7\ude34\udb24\udf30\udad0\ude93\ud9df\udff5\udb7a\udcc8\uda76\udd60\ud9cd\udd5f\ud840\udc01\ud95f\udf7b\uda11\uddbf\ud952\udd77\ud9be\udc0b\ud935\udfb7\udac8\udfbb\ud98b\udcaf\udb9e\udc9b\ueb3a\ud97d\udc21\udb38\udf53\udb8c\udf64\ud84d\udfa5\ud8a1\udc82\ud803\udc39\udbf8\udd93\ud84d\udc75\udac4\ude54\udb34\ude10\uda1f\udd1b\ud96d\ude48\u504c\udb18\udc6b\uda5f\udddf\ud934\uddab\udb68\ude62\udb27\udf0f\udb8a\ude9e\ud90e\udfa0\uda71\udeef\udbd5\udc0c\uc675\ua93d\udb16\udf10\udb05\udc44\ud880\udf21\ud8e7\udc5a\ud87a\udd38\u134a\ud865\udc4d\ud8d4\udf80\ud9f4\udd65\ud8c6\uddcb\udaee\udc98\ud943\udcad\ud8cb\udef6", "\uaf24\uc236", "\uda18\ude12\ud9b2\udf44\ud9a6\udf5d\u703d\ud95c\udd92\udb85\udda2\ud829\ude04\udb2c\udee0\u9c60\ud98a\udd0f\ud829\udf08\ud936\udf7c\uda0a\udf5e\udb6f\udc4f\u14e5\ud8a9\udcc8\ud9bf\udc4e\uda44\ude5a",
        6, 49710, -545406922, 1077568370803256325L, -43311L, true, true, (char) 57069, (char) 22331,
        Double.longBitsToDouble(0x3fcaf15f6bd002b4L), Double.longBitsToDouble(0x3fccddb7ddbe2538L)));
  }
  @Test(timeout = 4000)
  public void test152() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\u00fb\u762b\udb77\udf3b\udb5a\udf38\udb45\udfca\013\uda2b\udfe4\ud8de\udd9f\ud896\udcb2\ud84a\uddf6\ud8e0\ude7a\udaeb\udc25\ud812\udcc9\000\ud929\ude8d\uda39\uddbc", "\u9324\u3963\uc7f4\u4ce0\u4aeb\u5969\u7401\u6e3a\ub61b\uc6c0\u878a\ud25e\ubd92\ub3c8\uc253\u14da\u9633\u1170\000\u7504\u25b3\u3b64\ub520\uc0c7", "\ud82b\ude51\udb09\udef3\ud96b\udf66\ud84c\udef7\ud816\ude36\ud83d\ude4e\udafd\udf57\ud9ba\uddfb\uda9a\udc2f\udb5f\udcfc\uda54\udc8f\uda4b\ude50\udbaa\udfb1\ud96d\udc73\udba0\udecc\ud892\udcf1\ud976\udd43\ud9b9\udff4\udbea\udf30\ud853\udd57\udae0\udea5\ud838\ude2b\ud848\udcd5",
        9, 68126, -398289396, -2685587856176420375L, -49655L, false, false, (char) 52205, (char) 1799,
        Double.longBitsToDouble(0x3fd4a7028e8d5718L), Double.longBitsToDouble(0x3fe4b14c9d70a476L)));
  }
  @Test(timeout = 4000)
  public void test153() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 0, 4, 2, "\031\ud874\udd79\017\ud96b\udf4d\uda86\udc8c\uda21\udc79\ud898\udfc4\ud806\ude93\udbaa\ude6c\udb2c\udea1\ud840\udd70\023\udb69\udf67\udba6\udce6\uda2c\udf57\udab9\ude4e", "\ub30a", "\ud9ee\ude11\uda15\udcca\udbad\udfd4",
        33, 19636, 148040349, -6779800078388567443L, -100000L, false, false, (char) 1322, (char) 34497,
        Double.longBitsToDouble(0x3feb9aeb08e368d0L), Double.longBitsToDouble(0x3ec04637f0000000L)));
  }
  @Test(timeout = 4000)
  public void test154() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud9c3\udeb6\ud885\udf56\ud87a\uddfd\ud914\uddbb\ud9e3\uddd0\uda04\udcb7\udbe5\udd78\udb89\udd3c\udb3f\udf54\ud943\udee1\uda26\udfd2\udb02\udf62\ud90b\udfd8\udad6\udce5\uda8b\udf50\udb59\ude56\udb76\udf66\ud8c5\udc7f\ud839\udc7e\uda1c\udeee\ud8fe\udfd7\udb75\udd0d\uda5f\udfae\ud9eb\ude1d\ud829\udd1e\ud900\udc03\ud855\ude71\udadb\udfd0\ud89d\udd6d\ud896\udf70\u009d\ud994\udf0a\udab5\ude2b\udbb1\udd9c\udaf8\ude6a\udb4b\udf3b%\ud8e1\uded0\uda3f\udd24\uda32\udd72\ud8fd\udf2e\udbd6\udc5f\uda7d\uddaa\ud8a4\udfb0\udabf\udc05\ud900\udce5\udb6f\ude20\udafd\udc04\udbce\udf72\udac8\udd93\udbfa\udf29\udb10\udffe", "\u4d5c\u9416\u93e8\u4a51\uaa78\ua7da\uc035\u791e\u8029\uc89f\u8891\u7c11\u7a95\uaf50\u7342\u833e\ua82a\u9bba\u0565\uc0fa\u1ed7\u2403\u3b52", "\ud960\udfc2\udb18\ude21\udb84\udc4d\ud90a\uddb1\udabc\udce5\udbb8\udcf9\ud8e0\udd68\udafa\udec1\udaf3\udf15\uda7f\udced\udb69\udc66\uda26\udd56\uda5c\udc34\ud901\uded0\ud86b\udd76\ud81b\udc9f\ud91b\udca3\ud8be\udf20\udb7b\udd59\ud805\udf6d\udae6\udc4d\ud868\udc18\uda51\udcb7\udba0\udf57\ud9f1\ude13\uda0f\uddb2\ud88b\udff8\udab1\udf63\uda03\udece\ud8a3\udd49\ud86e\udd44\udb49\udcd6\uda0f\udc99\ud875\udf97\udb93\udc84\ud85a\udd02\uda7c\udc3f\udbbf\udde5\ud8cf\udc72\uda7c\udf18\udbdb\udfef\udbfe\udf30\ud910\udee9\udbc7\udf73\ud83e\uddd0\ud943\ude09\ud924\udddf\udaf3\udcfa\ud929\ude72\udb34\udfbf\udbad\udf6e\ud870\udf0f\ud870\ude6f\ud8df\uddcc\ud97e\udca7\ud86f\udef2\uda7a\udc68\udad0\udd4f\udb71\udc31\ud8ea\udce4\udac4\udda7\udb80\udf64\ud8bb\udfd7\uda6f\udc1c\ud907\udcb4\udbce\udec5\udae6\ude3c\ud91e\udcb2\udbdd\udfd3\ud97e\udd1b\udab3\udd09\udb70\udd02\uda49\udff9\ud8ae\uddbd\udbb3\udf52\ud94b\udf7f\udbca\ude28",
        24, 29219, 245220095, -7884537962009664927L, -76455L, true, false, (char) 1070, (char) 55357,
        Double.longBitsToDouble(0x3fdc002800ccae5eL), Double.longBitsToDouble(0x3fe1b9f2a967f73bL)));
  }
  @Test(timeout = 4000)
  public void test155() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\ud9aa\udf13\ud92f\udea9\ud87a\uddfd\udb96\ude9c\ud89d\udf84\uda38\udefd\ub9de\ud8c3\udf56\udb3f\udf54\ud943\udee1\uda86\udf31\uda85\udc62\ud8a2\udd4b\udb79\udd77\ud88e\udcbd\udb59\ude56\udb76\udf66\udab4\udc90\ud9ae\udeb3\uda1c\udeee\ud8fe\udfd7\udb01\udc42\uda5f\udfae\ud8c4\ude24\ud865\udc93\uda64\udef5\ud9db\udd1b\ud811\ude73\ud89d\udd6d\uda80\udd05\025\ud9cc\udda5\udb30\udd83\ue322\udaf8\udea2\ud9bc\udf94\udb1a\udf77\ud8e1\uded0\uda3f\udd24\ud963\udc0a\udbf4\udde7\udad6\ude84\ud85d\udc47\ud8c8\udf19\uda94\udeef\ud923\udc54\udb6f\ude9f\udafd\udc04\udb33\udd64\udb1a\udd26\udbfa\udf24\ud8c2\ude18", "\uc279\ud007\u93e8\u4a51\uaa78\ua7da\uc035", "\ufcd3",
        8, 82826, -1598422206, 8452465178468264346L, -19508L, true, true, (char) 15054, (char) 18698,
        Double.longBitsToDouble(0x3fecd129b4d66590L), Double.longBitsToDouble(0x3fb7a58e2a69f980L)));
  }
  @Test(timeout = 4000)
  public void test156() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\023+\udbcf\udec6\u9128\ud9ab\udc3c\u00b6\ud8f0\udc11\ud89d\udf91\udb3f\udfc0\uda45\ude90/\ud905\udfa2\ud82e\udcf7@\udab0\uddb8\udb0c\udd7e", "\u7c80", "\ud986\ude71\udac1\udcd0\udad5\udffb",
        3, 91172, -1012613302, 852268837498244336L, -100000L, false, false, (char) 65497, (char) 11473,
        Double.longBitsToDouble(0x3f5689708d724600L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test157() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9b5\udf62\udac5\ude5a\uda74\udc5e\ud8de\udd31\ud9e3\udff9\uda7c\ude39\ud8e0\ude7a\udaeb\udc25\ud983\udc1a\u052f\ud929\ude8d\uda39\uddbc\000\ud916\udcee\ud97e\udfde\uda13\udc49\ud832\udd75\udb39\udf33\uda63\udce5\udacc\udd13\ud97d\udd3f\u0818\ud829\udc46\ud99e\udef1\ud8e9\udeb4\000\000\ud919\udf0c\ud9dd\uddfe\ud928\udc77\uda4b\udf6a\uda90\udcdd\000\udb95\udf6a\udbb2\udf48\udaad\ude8d\udac0\uddd0\ud9a6\ude86\udaf4\udedb\udbb0\udc04\ud9f6\uddd4\ub25f\ud831\udc13\uda5a\udd06\ud9f2\ude9d\ud9da\udd88\udae2\udcbc\ud9ce\udf9c\ud90f\udc97\ud88e\ude6f\ud8c7\ude34\udb24\udf30\udad0\ude93\ud9df\udff5\udbc6\udc5d\uda76\udcfa\ud9cd\udd5f\ud840\udc01\ud95f\udf7b\uda11\uddbf\ud952\udd77\ud9be\udc0b\ud935\udfb7\udac8\udfbb\ud98b\udcaf\udb9e\udc9b\ueb3a\ud97d\udc21\udb38\udf53\udb8c\udf64\ud84d\udfa5\ud8a1\udc82\udaae\udeef\ud8f0\udece\ud84d\udd16\udac4\ude54\udb34\ude10\uda1f\udd1b\ud96d\ude48\ud854\ude6b\uda92\udcae\udb60\udc75\ud933\udf77\udb68\ude62\udb27\udf0f\udb8a\ude9e\ud90e\udfa0\uda71\udeef\ud8ab\udcc4\ud81f\uddec\ua93d\udb16\udf10\udb05\udc44\ud880\udf21\ud8e7\udc5a\ud87a\udd38\u134a\ud865\udc4d\ud8d4\udf80\ud9f4\udd65\ud8c6\uddcb\udaee\udc98\ud943\udcad", "\uc276\uaf24\uc236\u57e2\u5ef6\u7e81\u2c16\u4a8f\uba08\uc5af\u3811\u4505\u5c97\ucccd\ua72f\ucb68\uc32b\u76f2\u95ec\u3c6a\u9e36\ua5e8", "\ud83a\udfb8\uda1b\ude4b\uda56\udf9a\udae4\udd60\uc453\udbc7\ude6d\udb11\ude6f\uda06\udcd5\uda39\udfdf\ud8a0\udce1\uda36\udde0\ud937\udde7\ud868\udc65\ud978\ude72\udac4\udf4f\ud8b5\udc41\ud8fd\ude8c\ud99c\udd93\udb75\udcc9\ud942\udde3\udbba\udf91\udaa0\udd6a\ud9e0\udeb8\ud836\ude99\ud807\ude1d\ud82c\udcef\ud882\udcf4\ud861\udd00\uda50\udcbe\uda80\udce5\ud9ed\udd51\ua6db\ud842\udddf\udad6\udd4a\ud993\udd7b\ud9b9\udd0f\ud8ef\udeb2\udb8b\udc01\udbc1\ude9b\uda9b\udedf\udab3\udcd8\uda7b\udf0b\ud8ee\udf8e\uda07\udd15\ud877\udcd0\ud821\udd8d",
        56, 95558, -652284839, 2739591355034166295L, -47767L, true, false, (char) 65411, (char) 1998,
        Double.longBitsToDouble(0x3feefe849ba9a17aL), Double.longBitsToDouble(0x3fe0a621c9051fe8L)));
  }
  @Test(timeout = 4000)
  public void test158() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\u4192\ud874\udd79\017\udab8\udcf3\udae9\udd72\ud975\udc9d\uda39\udf99\udb51\udf12\udb97\udd22\udbe9\udf44\uda51\ude98\ud866\udd66\uda30\udd81\u563c\ud9d5\udd02\ud942\udee1", "\ub30a\u0bb6\ud794\u0a87", "\ud8b3\udce1\udafb\udea7\ud846\udf22\ud859\udc75\ud8d5\udf47",
        50, 17373, 2039816704, -6469267391084633929L, 55875L, false, false, (char) 21902, (char) 8426,
        Double.longBitsToDouble(0x3fcb45e21e7838f0L), Double.longBitsToDouble(0x3fe9d1a8caa563e9L)));
  }
  @Test(timeout = 4000)
  public void test159() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\u00fb+\udb77\udf3b\udb5a\udf38\ud9b5\udf62\uef15\000\ud8de\udd31\ud9e3\udff9\uda7c\ude39\ud8e0\ude7a\udaeb\udc25\ud983\udc1a\u052f\ud929\ude8d\uda39\uddbc\000\ud916\udcee\ud97e\udfde\uda13\udc49\ud832\udd75\udb39\udf33\uda63\udce5\udacc\udd13\ud97d\udd3f\u0818\ud829\udc46\ud99e\udef1\ud8e9\udeb4\000\000\ud919\udf0c\ud9dd\uddfe\ud928\udc77\uda4b\udf6a\uda90\udcdd\000\udb95\udf6a\udbb2\udf48\udaad\ude8d\udac0\uddd0\ud9a6\ude86\udaf4\udedb\udbb0\udc04\ud9f6\uddd4\ub25f\ud831\udc13\uda5a\udd06\ud9f2\ude9d\ud9da\udd88+\ud991\udf68\ud90f\udc97\ud88e\ude6f\ud8c7\ude34\udb24\udf30\udad0\ude93\ud9df\udff5\udbc6\udc5d\uda76\udcfa\ud9cd\udd5f\ud840\udc01\ud95f\udf7b\uda11\uddbf\ud952\udd77\ud9be\udc0b\ud935\udfb7\udac8\udfbb\ud98b\udcaf\udb9e\udc9b\ueb3a\ud97d\udc21\udb38\udf53\udb8c\udf64\ud84d\udfa5\u00a5\udaae\udeef\ud8f0\udece\ud84d\udd16\udac4\ude54\udb34\ude10\uda1f\udd1b\ud96d\ude48\ud854\ude6b\uda92\udcae\udb60\udc75\ud933\udf77\udb68\ude62\udb27\udf0f\udb8a\ude9e\ud90e\udfa0\uda71\udeef\ud8ab\udcc4\ud81f\uddec\ua93d\udb16\udf10\udb05\udc44\ud880\udf21\ud8e7\udc5a\ud87a\udd38\u134a\ud865\udc4d\ud8d4\udf80\ud9f4\udd65\ud8c6\uddcb\udaee\udc98\ud943\udcad", "\uc276\uaf24\uc236\u57e2\u5ef6\u7e81\u2c16\u4a8f\uba08\uc5af\u3811\u4505\u5c97\ucccd\ua72f\ucb68\uc32b\u76f2\u95ec\u3c6a\u9e36\ua5e8", "\ud83a\udfb8\uda1b\ude4b\uda56\udf9a\udae4\udd60\uc453\udbc7\ude6d\udb11\ude6f\uda06\udcd5\uda39\udfdf\ud8a0\udce1\uda36\udde0\ud937\udde7\ud868\udc65\ud978\ude72\udac4\udf4f\ud8b5\udc41\ud8fd\ude8c\ud99c\udd93\udb75\udcc9\ud942\udde3\udbba\udf91\udaa0\udd6a\ud9e0\udeb8\ud836\ude99\ud807\ude1d\ud82c\udcef\ud882\udcf4\ud861\udd00\uda50\udcbe\uda80\udce5\ud9ed\udd51\ua6db\ud842\udddf\udad6\udd4a\ud993\udd7b\ud9b9\udd0fA\ud8ab\udef4\udbc1\ude9b\uda9b\udedf\udab3\udcd8\uda7b\udf0b\ud8ee\udf8e\uda07\udd15\ud877\udcd0\ud821\udd8d",
        56, 95558, -652284839, 2739591355034166295L, -47767L, true, false, (char) 65411, (char) 1928,
        Double.longBitsToDouble(0x3feefe849ba9a17aL), Double.longBitsToDouble(0x3fe0a621c9051fe8L)));
  }
  @Test(timeout = 4000)
  public void test160() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 2, 3, 2, "\u7232\udb41\ude8b\ud8b4\udf0f\ud808\udf40", "\u363c\u6a8d\u235b\ubdec\u9041\u6325\ub237", "\ud9be\udd42\udaf9\ude13\ud9e7\ude03\ud962\ude99\ud855\ude2e\ud9af\udc10\ud956\udfc0\udbd4\udd6b\udbb3\udc9c",
        32, 41069, 1417526978, 4874001891936952890L, -4661L, true, false, (char) 36239, (char) 21712,
        Double.longBitsToDouble(0x3fe4b8ac103a9db5L), Double.longBitsToDouble(0x3fed4c9a294fd140L)));
  }
  @Test(timeout = 4000)
  public void test161() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 4, 0, "\ud962\udd6d\udbf8\uddb5\ud913\udf79\udac1\udcc2", "\033\ucba9\u72a4\uca65\u66a7\u8c13\u8e76\u6623\u86de", "\udbe1\udf7c",
        19, 63374, -1162059401, 8986978548711424L, -36146L, true, true, (char) 1, (char) 107,
        Double.longBitsToDouble(0x3fe086f8051f09abL), Double.longBitsToDouble(0x3fe7121806597d85L)));
  }
  @Test(timeout = 4000)
  public void test162() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.validation.DateValidator:@?\0121=org.apache.commons.cli2.validation.DateValidator:@?\012",
        Z.run(T, 2, 3, 3, 3, "\udbd0\udda5\ud953\udf85\ud89e\udfbd\ud9ca\udce6", "\u09e4\u6929\u4ed6\u4e42\u4306\ua1c3\u26d4\uca49\u866a", "\ud8ba\udd26",
        12, 57420, -1162059430, 9736845478854656L, -100000L, false, true, (char) 35, (char) 49407,
        Double.longBitsToDouble(0x3fe86152fe000000L), Double.longBitsToDouble(0x3fe71218040f1308L)));
  }
  @Test(timeout = 4000)
  public void test163() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 1, 4, 5, 2, "\ud9d4\udd67\ud96e\udc2c\udbcc\ude13\ud817\udf2b\ud8b9\udc6b\ud973\udc5e\u981b\udb1e\udc0eg\uda64\udf52<\ud84a\udd24\ud805\udce1\ud961\ude69\ud9cc\udc3b\ud9ee\ude2c\ud94b\udd07\u5cc6\ud9b7\uddcd\udabc\udcb0\udaa3\udecb", "\u118e\000\uc375\u2b1f\000\u1509", "\ud829\uddce\ud9fc\udc4a\uda83\udd24\udb28\udc8a\udb65\udcaf\ud94f\ude18\u37cd\ud938\uddbe\udb61\udee4\udb1c\udc8a\ud8f9\udc33\ud8f2\udfa7\udb2e\ude19\ud955\udd24\ud823\ude77\ud8c0\ude81\udb80\udf28\ud850\udc8a\uda82\udc60\ud897\udcf7\udadc\udc6a\uda8b\udd41\ud82d\udc2f\ud894\udec6\udb3b\ude27\ud99f\udd2a\ud8c2\udf58",
        26, 91866, 1144850155, 6275994498783978709L, -52362L, false, false, (char) 38634, (char) 61160,
        Double.longBitsToDouble(0x3fe28c691008a9bfL), Double.longBitsToDouble(0x3fb0ed08c854cf70L)));
  }
  @Test(timeout = 4000)
  public void test164() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 0, 1, 4, "\udbed\udf35\ud806\udfa1\uda08\udd02\ud98b\udfeb", "\u1970\u6740\u1ce1\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\uda6a\udce9\ud88b\udc19\ud975\udc63\ud804\udc14i\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff\uda04\ude46\udb70\udeff\ud91e\udeab\uda37\udc4e",
        9, -1000, 0, 0L, 18352L, true, false, (char) 42, (char) 64315,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec12829d5f9fe3L)));
  }
  @Test(timeout = 4000)
  public void test165() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\000\000\000\ud96b\udf4d\ud9ca\udfff\uda3f\udeff\ud940\udc1c\udb80\udd03\uda8f\udfd2\ud8b9\udceb\ud9e3\udcc9\ud8e2\udda2\udbd3\udc69\u52e9\udbb9\udca5\012", "\ub30a", "\ud844\udd76\uda8b\udde4\udbad\udfd4",
        41, 7820, 701638986, -1159270517891669493L, -100000L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fecfc5e53d612b2L), Double.longBitsToDouble(0x3fe000068e7f3ff4L)));
  }
  @Test(timeout = 4000)
  public void test166() throws Throwable {
    assertEquals("0=new org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 5, 4, 4, "\ud93d\ude5d\ud890\uddd9\ud802\udc26\uf71a\uda86\udc8c\udb6d\udeeb\udb0c\uddc2\ud802\udd93\ud8a8\udf05\udbed\udf71\uda72\udfdb\000\udb69\udf67\024\udab7\udfe0\012", "\ub30a", "\udb44\udd76\ud81c\uddee\udb92\ude07",
        57, 63343, 701688394, -1159270517891669493L, -100000L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fecfc5e53d612b2L), Double.longBitsToDouble(0x3fe6f73fbd1c0d4eL)));
  }
  @Test(timeout = 4000)
  public void test167() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\u00fb\ud9d2\udc13\ud918\udd61\udb4e\udc86\ud9c1\udc6b\014\uda55\udf1f\udae2\udd49\udb3f\udf54\ud943\udee1\u0091\udb84\udf03*\000\ud929\ude8d\ud84c\udc05", "\ud6d1", "\udacf\udf67\ud8d4\udf1b\udacc\udd5b",
        47, 33098, 802295370, 0L, -100000L, false, false, (char) 56281, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748d61200L), Double.longBitsToDouble(0x3ec0400000000000L)));
  }
  @Test(timeout = 4000)
  public void test168() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud852\udee8\uda74\ude10\010\udb68\udcaa\u6727\ud910\udce2\udb0c\uddc2\ud83d\ude47\udbaa\ude6c\ud449\000\000\ud9ae\udd70\010\000\000\udadc\udd2d\ud923\udeee\ud957\udc99\ud855\ude2e\ud986\udc14\ud844\udd76", "\uc86e", "\ud9ff\udeff\uda43\udc4f\u9e3f\000\ud99d\udd0a\uda1a\udcd0\udb2a\udfab\ud926\udfb3\ud970\ude26\ub90f\udafc\udf3d\ud834\uddf5\udb8a\udf7f\udbc3\udfc2\udb94\udd8e\uda16\udfee\ud9ad\udf20\ud969\udc39\udb21\udf57\uf51d\ud8a5\udd5a\ud833\udc6d",
        14, -1000, 1396374215, 13066672420159488L, 40544L, true, true, (char) 52600, (char) 20309,
        Double.longBitsToDouble(0x3fc3e5312000dd7cL), Double.longBitsToDouble(0x3fd0b171ec44eeb4L)));
  }
  @Test(timeout = 4000)
  public void test169() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud984\udde3\uda74\ude10\005\u355e\udbb3\ude59\udb4f\udd2d\udb34\uddf7\ud8b7\udf20\udbaa\uddea\ud8b9\udceb\u5fe5\udada\udea2\udad5\udd35\027\000>\udadc\udd2d\ud923\udeee\ud900\udc48\uda1e\uddb3\uda71\udec4\udb13\udf9b", "\uc853\u31b5\uc3db", "\udbac\udef7>\ud99d\udd0a\uda1a\udcd0\ud91c\ude38\udb2b\uddd3\uda9a\udf16\000\ud8e3\udce0\udb96\udf11\udb8a\udf7f\uda51\udd29\udb94\udd72\uda16\udfee\ud9ad\udf20\ud969\udc39\udb21\udf57\uf51d\udb82\udf33\ud833\udc6d\ud982\udcb0\ud88f\udfea\ud96c\udf24\udb9c\udc98\ud8f7\udd60\ud977\udf10\udbd2\udf4d\udba0\uddad\uda06\udc37\uda82\udc2a\ud94d\udfe2\uda1f\udca9\uda41\udc99\ud82b\uddf8\udaa3\ude67\udb64\udecc\ud9b1\ude71",
        7, 82101, 1666273579, -5036440466392058909L, -94355L, false, true, (char) 47177, (char) 5803,
        Double.longBitsToDouble(0x3f9a6fa839ab6a60L), Double.longBitsToDouble(0x3fe3a29e82b40915L)));
  }
  @Test(timeout = 4000)
  public void test170() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud8a4\ude6d\ud81e\udd58\ud87a\uddfd\ud914\uddbb\udbb8\udffa\ud809\udc7e\uda55\udf37\udbd0\udfb1\udb47\udff0\ud943\udee1\uda26\udfd2\udb02\udf62\ud90b\udfd8\ud9d8\udda6\ud9c5\ude72\udb59\ude56\udb76\udf66\ud8c5\udc7f\ud839\udc7e\uda1c\udeee\ud8fe\udfd7\udb75\udd0d\uda28\uddca\udb3f\ude28\ud865\udc93\uda64\udef5\ud9db\udd1b\ud811\ude73\ud89d\udd6d\ud896\udf70\021\ud994\udf0a\ud9dd\uddfe\udbb1\udd9c\udaf8\ude6a\udbd7\udf81Q\ud8e1\uded0\udb38\udf41\uda61\udc22\ud8f2\udf29\udbd6\udc5f\uda7d\uddaa\ud8a4\udfb0\ud8df\udd15\udaf8\uddf8\udb6f\ude20\udafd\udc04\udbce\udf72\udb1a\udcdc\udbfa\udf24\udb10\udffe", "\uc6a4\u5bdf\u93e8\u4a51\uaa78\ua7da\u13c3", "\ufcd3\ud821\udd82",
        36, 2794, 1030147203, -2137522713425453726L, -97462L, false, false, (char) 32510, (char) 28042,
        Double.longBitsToDouble(0x3fd36eb340dc5bc2L), Double.longBitsToDouble(0x3fd4d3f30523167eL)));
  }
  @Test(timeout = 4000)
  public void test171() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.GroupImpl:[-\uda71|-\udfc5|-\ucf5a|-\000|-\ud971|-\uddb7|-\udba8|-\udd2a|-\uda56|-\udd55|-\udae2|-\udd49|-\udb3f|-\udf54|-\ud943|-\udee1|-\uda76|-\udf29|-\udb84|-\udf03 <arg1> [<arg2> ...]|-\udb60|-\udc6f|-\ud929|-\udd98|-\ud92e|-\udeb7] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 0, 1, "\uda71\udfc5!\ucf5a\000\ud971\uddb7\udba8\udd2a\uda56\udd55\udae2\udd49\udb3f\udf54\ud943\udee1\uda76\udf29\udb84\udf03*\udb60\udc6f\ud929\udd98\ud92e\udeb7", "\ud6d1", "\uda26\udddd\udad2\udd99\udacc\udd5b",
        47, -998, 802291712, 3839202981916835905L, -99976L, true, false, (char) 9820, (char) 63104,
        Double.longBitsToDouble(0x3fe3d98748d61200L), Double.longBitsToDouble(0x3f126b8000000000L)));
  }
  @Test(timeout = 4000)
  public void test172() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.builder.PatternBuilder:@? |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 1, "\udb2e\udf11\004\udb77\udf3b\udb5a\udf38", "\u17a3\ucf26\u5c29\u217b\u1078", "\010\ud9b5\udd9a\ud84c\udc05\000\ud916\udcee\udba4\udd0b\uda13\udc49\ud832\udd75\udbcc\udebc\udac1\udcd0",
        57, 30368, -1157569828, 3445832375886749295L, -100000L, false, false, (char) 20, (char) 65497,
        Double.longBitsToDouble(0x3fcac60dd005a25cL), Double.longBitsToDouble(0x3fb1ae48c0000410L)));
  }
  @Test(timeout = 4000)
  public void test173() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 1, 1, 4, "\udbed\udf35\ud806\udfa1\uda08\udd02\ud98b\udfeb", "\u1970\u6740\u1ce1\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\uda6a\udce9\ud88b\udc19\ud975\udc63\ud804\udc14i\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud9dc\udc11\ud915\udd36\ud93f\uddff\uda04\ude58\udb70\udeff\ud91e\udeab\uda37\udc4e",
        9, -1000, 0, 0L, 18352L, true, false, (char) 42, (char) 64315,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec12829d5f9fe3L)));
  }
  @Test(timeout = 4000)
  public void test174() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.DefaultOption:-\ufb3b <arg1> [<arg2> ...] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 1, 0, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u1970\ud3fd\u74fb\u0a84\u1409\ucf53\u58ae\u0ff2\u4c6e\u32ad\ud380\000", "\uda6a\udce9\ud88b\udc19\ud975\udc63\ud804\udc14\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff\uda04\ude46\udb70\udeff\u6d0a\uda37\udcbd",
        9, -1000, 0, 0L, 18352L, true, false, (char) 42, (char) 64315,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec128299d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test175() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 1, "\udb2e\udf11\004\udb77\udff7\udb5a\udf38", "\u17a3\ucf26\u5c29\u217b\u1078", "\010\ud9b5\udd9a\ud84c\udc05\udaa5\udde1\udbc8\udf88\ud80c\ude67\ud9d3\udc37\ud8b2\udc5c\udbcc\udeb4\udac1\udcd0",
        57, 30368, 498365119, 1162136000462659183L, -100000L, false, false, (char) 20, (char) 65497,
        Double.longBitsToDouble(0x3fcac60dd005a25cL), Double.longBitsToDouble(0x3fb1b6c8c0000410L)));
  }
  @Test(timeout = 4000)
  public void test176() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=org.apache.commons.cli2.option.DefaultOption:[-\ufb3b [<arg1> [<arg2> ...]]] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 1, 0, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u1970\ud3fd\u74fb\u0a84\u1409\ucf53\u58ae\u0ff2\u4c6e\u32ad\ud380\000", "\uda6a\udce9\ud88b\udc19\ud975\udc63\ud804\udc14\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud834\udfb3\ud85a\ude3f\ud93f\uddff\uda04\ude46\ud885\udded\u6d09\uda37\udcbd",
        9, -1000, 0, 0L, 18352L, false, false, (char) 42, (char) 64315,
        Double.longBitsToDouble(0x3fdaee4b438aa038L), Double.longBitsToDouble(0x3fec128299d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test177() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 0, 5, "\ua131\udabf\udc1e\ud976\uddc2\ud86c\ude9e", "\u9166\u6ac1\u6d2a\u0a84\u773a\ubdd4\u0bfd\uab9b\ua691\ud0f3\u83b6\u7cb5", "\udaec\udf14",
        58, 96212, -401038136, -4537594706671401074L, 67485L, true, true, (char) 11, (char) 14190,
        Double.longBitsToDouble(0x3fe42e8850000000L), Double.longBitsToDouble(0x3fe9e000036053f9L)));
  }
  @Test(timeout = 4000)
  public void test178() throws Throwable {
    assertEquals("0=null\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 4, 4, "\udb1a\udfac\udb68\udd04\uda08\udd02\ud862\udc38", "\u354a\u6a8d\u6d2a\u0a84\u1409\ucf53\u58ae\ua578\u448c\u32ad\ud380\000", "\uda54\ude8f\ud844\udd76\udbd6\udeef\udb9e\udd9c\000\uda9b\udd0d\udba9\uddb8\udb61\udfd8\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14\uda25\udf1b\ud8eb\udfa1",
        8, 9138, 982430359, 0L, -100000L, false, false, (char) 26, (char) 42272,
        Double.longBitsToDouble(0x3fe2cc84f49f65dcL), Double.longBitsToDouble(0x3fe13b2ed0fa53ffL)));
  }
  @Test(timeout = 4000)
  public void test179() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 2, "\ua0ae\ud8d2\udee8\ud833\udcdd\udac1\udcc2\ud8b9\udc69\ud973\udc5e\033\udb1e\udc0e\u4ed6\uc95d", "\u1d84\ub51a\u866a\u3826\000\u3776\u30ac\ud186\u7415\u2cff\u9034\ub470\ucb1d\u63d7", "\ud915\uddcf\udb27\udc49",
        0, 15519, -1285937995, 8003837445419403420L, 31256L, false, true, (char) 14138, (char) 43882,
        Double.longBitsToDouble(0x3fe669710ce7ca59L), Double.longBitsToDouble(0x3fda8965046b1d0cL)));
  }
  @Test(timeout = 4000)
  public void test180() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 0, 0, "\ud947\udfe1\u7bdb\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u9441\u9041\ucf53\u580e\uaace\u9830\ud2a5\ud380\u2eca", "\uda47\udc0d\ud844\udd76\udbd6\udf6b",
        49, 69641, -834587848, 6070007873900113638L, 67485L, false, false, (char) 18, (char) 0,
        Double.longBitsToDouble(0x3e399a0000000000L), Double.longBitsToDouble(0x3fc731b7225c5608L)));
  }
  @Test(timeout = 4000)
  public void test181() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 0, 4, "\u1ef1\udab5\ude97\udb6c\ude03\udac1\udcc2", "\ucbc7\u6929\u4ed6\u4e42\020\u0ef3\u15fa\uae21\u6a6b", "\ud887\udc06",
        22, 68076, -813911844, 8986977105870848L, 65059L, true, false, (char) 29, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe7121800dbc03cL)));
  }
  @Test(timeout = 4000)
  public void test182() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 1, "\003\uda2e\udebe\000\ud96b\udf4d\uda85\udfb7\uda45\udfe7\u4582\u4f25\udbaa\ude6c\udb2c\udea1\ud840\udd70\000\udb69\udf67\udbbd\udc51\udb8e\udebe\ud881\ude2b", "\u4bc1", "\ud9ee\ude11\ud91d\udded\uda04\udea1\ud8b3\udce1\udb35\udec3\ud846\udecf\ud9fc\ude34\uda43\udcb1\u4772\000\uda69\udd88\uda77\uded8\ud98b\uddcf",
        -5, 76622, 0, 613868252885593462L, -96415L, false, true, (char) 23, (char) 18806,
        Double.longBitsToDouble(0x3fec22bfbb056b3aL), Double.longBitsToDouble(0x3fb79cfae9787b08L)));
  }
  @Test(timeout = 4000)
  public void test183() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 3, "\u00fb+\000\000\ud9b5\udee6\uef15\000\ud8de\udd31\ud9e3\udff9\uda7c\ude39\ud8e0\ude7a\udaeb\udc25\ud983\udc1a\u052f\ud929\ude8d\uda39\uddbc\000\ud916\udcee\ud97e\udfde\uda13\udc49\ud832\udd75\udb39\udf33\uda63\udce5\udacc\udd13\ud97d\udd3f\u0818\ud829\udc46\ud99e\udef1\ud8e9\udeb4\000\000\000\ud9be\udffe\ud928\udc77\uda4b\udf6a\uda90\udcdd\000\udb95\udf6a\udbb2\udf48\udaad\ude8d\udac0\uddd0\ud9a6\ude86\udaf4\udedb\udbb0\udc04\ud9f6\uddd4\ub25f\ud831\udc13\uda5a\udd06\ud9f2\ude9d\ud9da\udd88+\ud991\udf68\ud90f\udc97\ud88e\ude6f\u1200\udb24\udeb0\udad0\ude93\ud9df\udff5\udbc6\udc5d\u0b62\ud9ab\udc95\ud840\udc01\ud95f\udf7b\uda11\uddbf\ud952\udd77\ud9be\udc0b\ud935\udfb7\udac8\udfbb\ud98b\udcaf\udb9e\udc9b\ueb3a\ud951\udc21\udb38\udf53'\000\000\000\000\ud84d\udc4d\udac4\ude54\udb34\ude10\uda1f\udd1b\u0094\000\uda92\udc39\udb60\udc75\ud933\udf77\ud85e\ude5d\udb27\udf0f\udb8a\ude9e\u0bbb\000\000\000\u2e25\udb30\udf06\udb05\udc44\ud880\udf21\ud8e7\udc5a\ud87a\udd38\udbe7\udf5a\000\000\ud9bf\ude5f\ud8c6\uddcb\udaee\udc98\ud943\udcad", "\uc276\uaf24\uc236\u49d4\000\u7e81\u2c16\u4a8f\uba08\uc5af\u3811\u4505\u5c97\ucccd\ua72f\ucb68\uc32b\u76f2\u95ec\u3c6a\000\000", "\ud83a\udfb8\ud980\udc3d\ud8a8\udcd3\udae4\udd60\uc453\udbc7\ude6d\ubb7f\000\uda39\udfdf\ud8a0\udce1\uda36\udde0\ud937\udde7\ud868\udc65\ud978\ude72",
        30, 89195, 253, 0L, -58624L, false, false, (char) 59514, (char) 63234,
        Double.longBitsToDouble(0x3fe9ce3a24b474edL), Double.longBitsToDouble(0x3fdf6c00a009ddd2L)));
  }
  @Test(timeout = 4000)
  public void test184() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud9d4\udd67\ud96e\udc2c\udbcc\ude13\ud817\udf2b\ud8b9\udc6b\ud973\udc5e\u981b\udb1e\udc0eg\uda64\udf52<\ud84a\udd24\ud805\udce1\ud961\ude69\ud9cc\udc3b\ud9ee\ude2c\ud94b\udd07\u5cc6\ud9b7\uddcd\udabc\udcb0\uda6e\udfa3", "\u118e\000\uc375\u2b1f\u0670\uc341", "\ud8f3\uddd3\ud9fc\udc4a\uda83\udd24\ud92e\uddcc\udb65\udcaf\ud944\udde8\u37cd\ud938\uddbe\udb61\udee4\udb1c\udc8a\udb47\ude19\udaf2\udcc6\ud936\udc42\uda18\udd84\u7482\ud8c0\udef1\udb80\udf28\ud850\udc8a",
        33, 42242, -1280298566, -4257299413666770988L, 95593L, false, true, (char) 36197, (char) 5579,
        Double.longBitsToDouble(0x3fe2d5fc0eebde1eL), Double.longBitsToDouble(0x3fedfa21ecd55718L)));
  }
  @Test(timeout = 4000)
  public void test185() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud93d\ude5d\ud890\uddd9\ud802\udc26\ud873\udc25\uda86\udc8c\udb6d\udeeb\udb74\udc76\ud802\uddac\ud8a8\udf05\udbed\udf71\uda72\udfdb\000\udb69\udf67\024\udab7\udfe0\012", "\ub30a", "\udb44\udd76\ud81c\uddee\udb92\ude07",
        57, 95983, -604319230, -5211079336069601235L, -61975L, false, false, (char) 14190, (char) 40847,
        Double.longBitsToDouble(0x3fecfc5e53d612b2L), Double.longBitsToDouble(0x3fe6f73fbd1c0d4eL)));
  }
  @Test(timeout = 4000)
  public void test186() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=null\012",
        Z.run(T, 2, 4, 3, 1, "\uda28\udc2e\u84c2\udb77\udf3b\udb5a\udf38", "\u6907\u233c\uc134\u07a2\u1078", "\010\ud8ef\udea6\ud84c\udc6a\udbb1\udf49\ud810\udf10\uda32\udc36\uda13\udc49\ud832\udd75\udbd8\udec2\udac1\udcd0",
        57, 30368, -1157569828, -1252266462026780122L, -100000L, false, false, (char) 19, (char) 65497,
        Double.longBitsToDouble(0x3fcac60dd005a25cL), Double.longBitsToDouble(0x3fb1ae48c0000410L)));
  }
  @Test(timeout = 4000)
  public void test187() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u1970\ud3fd\u74fb\u0a84\u1409\ucf53\u58ae\u0ff2\u4c6e\ub542\ud380\000", "\uda6a\udce9\ud88b\udc19\ud975\udc63\ud804\udc14\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff\uda04\ude46\udb70\udeff\u6d0a\uda37\udcbd",
        9, -1000, 0, 0L, 18352L, true, false, (char) 5, (char) 60219,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec128269d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test188() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 4, "\udb1a\udfac\udb68\udd04\uda08\udd02\ud862\udc38", "\u354a\u6a8d\u6d2a\u0a84\u1409\ucf53\u58ae\ua578\u9b4e\u32ad\ud380\000", "\uda54\ude8f\ud844\udd76\udbd6\udeef\udb9e\udd9c\000\uda9b\udd0d\udba9\uddb8\udb61\udfd8\uda43\udc7e\u4233\ud844\udc01\ud99d\udd14\uda25\udf1b\ud8eb\udfa1",
        8, 9138, 982430359, 0L, -100000L, false, false, (char) 26, (char) 42272,
        Double.longBitsToDouble(0x3fe2cc84f49f65dcL), Double.longBitsToDouble(0x3fe13b2ed0fa53ffL)));
  }
  @Test(timeout = 4000)
  public void test189() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 3, 0, "\ud947\udfe1\u7bdb\uda08\udd02\ud88a\udf41", "\u363c\u6a8d\u6d2a\u9441\u9041\ucf53\u580e\uaace\u9830\ud2a5\ud380\u2eca", "\uda47\udc0d\ud844\udd76\udbd6\udf6b",
        49, 69641, -834587848, 6070007870997655270L, 67485L, false, false, (char) 14, (char) 0,
        Double.longBitsToDouble(0x3fd00000066681aaL), Double.longBitsToDouble(0x3fc731b72d2a5bd0L)));
  }
  @Test(timeout = 4000)
  public void test190() throws Throwable {
    assertEquals("0=null\0121=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 0, 4, "\003\uda2e\udebe\ud8a9\udc06\ud96b\udf4d\uda85\udfb7\uda45\udfe7\u4582\u4f25\udbaa\ude6c\uda18\udef8\ud86c\udc62\udaba\udc06\udb69\udf67\udbbd\udc51\udb8e\udebe\ud881\ude2b", "\u4bc1", "\ud9ee\ude11\ud957\uddcb\ud9b8\udf56\ud8b3\udc25\uda1f\udcb7\ud838\udf9a\ud9fc\ude34\uda43\udcb1\u4772\000\uda69\udd88\uda77\uded8\ud98b\uddcf",
        -5, 76622, 0, 613868252885593462L, -96415L, false, true, (char) 23, (char) 18806,
        Double.longBitsToDouble(0x3fec22bfbb056b3aL), Double.longBitsToDouble(0x3fb79cfafa2fbb08L)));
  }
  @Test(timeout = 4000)
  public void test191() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 4, "\003\ud88c\udf28=\ud96b\udf4d\uda85\udfb7\ud961\udc6b\u6cf6\u4f25\udbaa\ude6c\udb2c\udea1\ud840\udd70\000\udaa1\udcf5\uda7b\udc90\uda8e\udcf5\ud881\ude2b", "\u4bc1", "\ud9ee\ude11\ud91d\udded\uda04\udea1\uda60\udc86\udb5b\udd24\ud846\udecf\ud9fc\ude34\uda43\udcb1\ud94f\uddd1\udb9e\udcad\ud8fe\uddb9\ud844\uddbc\udb62\ude52",
        37, 52130, 0, 613868252885593462L, -96415L, false, true, (char) 23, (char) 18806,
        Double.longBitsToDouble(0x3fc08afee45ec4dcL), Double.longBitsToDouble(0x3fb7969e69787b08L)));
  }
  @Test(timeout = 4000)
  public void test192() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 1, "\uda28\udc2e\u84c2\udb77\udf3b\udb5a\udf38", "\u6907\u965b\u511c\u06d7\ud7c2", "\ud8bb\udc84\udafa\udcc5\ud971\ude68\ud93a\udeaf\ud810\udf10\uda32\udc36\uda13\udc49\ud832\udd75\udbd8\udec2\udac1\udcd0",
        57, 30368, -1157569828, -1540307597624462803L, -100000L, false, false, (char) 19, (char) 65497,
        Double.longBitsToDouble(0x3fcac60dd005a25cL), Double.longBitsToDouble(0x3fb1ae48c0000410L)));
  }
  @Test(timeout = 4000)
  public void test193() throws Throwable {
    assertEquals("0=null\0121=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 0, 4, "\udaf0\udef7\uda1e\uddac\ud9ff\udf95\ud806\udd1f\ud955\udfd5\u4d59", "\u74fb\u0a84\u68e6\u12e9\u58ae\u0ff2\u4c6e\ub542\ud380\u5b0e\u7a6c\ua095", "\ud8f1\udc61\ud9d2\udf6e\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff\uda70\udf7d\ud966\udd11\u6d0a\uda37\udcbd\ud995\ude0a\uda1c\udc0d\000\000\ue3d8\ud84b\udcec\ud896\udda5\ud9d2\udd43",
        9, 49297, -1799841883, 6894766908871953773L, 18352L, false, false, (char) 5, (char) 60219,
        Double.longBitsToDouble(0x3fd84e4b4c02a038L), Double.longBitsToDouble(0x3fec12826c609fe3L)));
  }
  @Test(timeout = 4000)
  public void test194() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u1970\ud3fd\u74fb\u0a84\u1409\ucf53\u58ae\ud629\u4ba1\ub542\ud380\000", "\uda6a\udce9\ud88b\udc19\ud975\udc63\ud804\udc14\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff\uda0e\udceb\ud92e\ude26\u6d0a\uda37\udcbd",
        9, -1000, 0, 0L, 18352L, true, false, (char) 7, (char) 60219,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec128269d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test195() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 4, "\udbed\udf35\udb92\udec0\ud9e5\udfa4\ud98b\udfeb", "\u1970\ud3fd\u74fb\u0a84\u1409\ucf53\u58ae\u0ff2\u4c6e\ub5c7\u0679\000", "\ud84f\udd15\udbd3\udf81\ud975\udc63\ud804\udc14\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff\uda04\ude46\udb70\udeff\u6d0a\uda37\udcbd",
        9, -1000, 0, 0L, 63966L, true, false, (char) 65390, (char) 25469,
        Double.longBitsToDouble(0x3fe64fd39054c0f7L), Double.longBitsToDouble(0x3f92d71e02195cc0L)));
  }
  @Test(timeout = 4000)
  public void test196() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 0, "\ud947\udfe1\u7bdb\uda08\udd02\ud88a\udf41", "\u363c\u29c5\u342d\u9441\u9041\ucf53\u580e\uaace\u9830\ud2a5\ud380\u2eca", "\udb48\udc7f\udba0\udeed\udbd6\udf6b",
        49, 2233, -1153350231, 1679890943253731182L, 1949L, false, false, (char) 14, (char) 0,
        Double.longBitsToDouble(0x3fd00000066681aaL), Double.longBitsToDouble(0x3fc731b7278a5bd0L)));
  }
  @Test(timeout = 4000)
  public void test197() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 4, "\udaf0\udef7\uda1e\uddac\ud9ff\udf95\ud806\udd1f\ud955\udfd5\u4d59", "\u74fb\u0a84\u68e6\u12e9\u58ae\u0ff2\u4c6e\ub542\ud380\u5b0e\u7a6c\ua095", "\ud89a\uddfe\ud9d2\udf70\u008e\uda9b\udd0d\udba9\udd1b\udb61\udfd8\udbb9\ude5a\ud8e1\udd7c\ud82c\udf62\ud93f\uddff\uda70\udf7d\ud976\udc11\ud8b9\udf38\udaaf\uddd8\ud995\uddd8\uda1c\udc0d\000\000\ud939\ude99\ud91d\udcff\ud896\udda5\ud9d2\udd43",
        9, 49297, -1799841883, 6894766908871953773L, 18352L, false, false, (char) 5, (char) 60219,
        Double.longBitsToDouble(0x3fd84e4b4c02a038L), Double.longBitsToDouble(0x3fec12826c609fe3L)));
  }
  @Test(timeout = 4000)
  public void test198() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 1, "\ud9b4\ude03\udb44\udc18\udacb\udd2b\ud8d7\udecc\uda85\udeef", "\u4bc9\u3a51\u5912\u1409\ucf53\u58ae\u6c81\u4c29\ub542\ud380\u8517\ubca8\u6295", "\ud975\udc63\udb47\ude80\ud800\ude44\uda9b\udd0d\uda63\uddb5\udbf5\udedd\ud929\udc51\ud804\udcb6\ud82c\udf62\ud93f\uddff\uda0e\udceb\ud91c\udc0d\u6d0a\ud85a\udcce\ud995\ude32\000\000\udad2\udc08\000\uda17\udeea\uda48\udc4a\ud892\udf6d",
        12, 17286, -687910177, -5907048241643172499L, 14608L, false, false, (char) 7, (char) 60219,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec8a8269d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test199() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 4, "\udbed\udf35\u8af8\ud9ff\udf95\ud98b\udfeb", "\u1970\ud3fd\u74fb\u0a84\u1409\ucf53\u58ae\ud629\u4ba1\u6b42\ud380\uae00", "\uda6a\udce9\ud88b\udc19\ud975\udc8f\ud804\udc14\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff\uda0e\udceb\ud92e\ude26\u6d0a\uda37\udcbd",
        9, -1000, 0, 0L, 18352L, true, false, (char) 7, (char) 60219,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec128269d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test200() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u58bd\ud442\u74fb\u0a84\u1409\ucf53\u58ae\ud629\u4ba1\ub542\ud380\000", "\uda6a\udce9\ud88b\udc19\ud975\udc63\ud878\udf8e\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff\udb74\ude10\ud823\udfe8\uda4c\udc47\uda37\udcbd",
        9, -1000, 0, 0L, 30281L, false, true, (char) 21, (char) 60219,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec128269d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test201() throws Throwable {
    assertEquals("0=org.apache.commons.cli2.option.GroupImpl:[] |this=org.apache.commons.cli2.builder.PatternBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 1, "\ud9b4\ude03\udb44\udc18\udacb\udd2b\ud8d7\udecc\uda85\udeef", "\u4b33\u58aa\u58e5\u1409\ucf53\u58ae\u6c81\u4c29\ub542\ud380\u8517\ubca8\u6295", "\ud975\udc63\udb47\ude80\ud800\ude44\uda9b\udd0d\uda63\uddb5\udbf5\udedd\ud929\udc51\ud804\udcb6\ud82c\udf62\ud93f\uddff\udad8\udeed\ud91c\udc0d\u6d0a\ud85a\udcce\ud995\ude32\000\000\udad2\udc08\000\uda17\udeea\uda48\udc4a\ud921\udc13",
        44, 74775, -687879495, -5907048241643172499L, 14608L, false, false, (char) 28, (char) 60219,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec8a8269d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test202() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u58bd\ud442\u74fb\u0a84\u1409\ucf53\u5871\ud629\u4ba1\ub542\ud380\000", "\uda64\udfe9\ud88b\udc19\ud975\udc63\ud98c\udd77\udb06\udd51\udb57\udf38\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff\udb74\ude10\ud823\udfe8\uda4c\udc47\uda37\udcbd",
        9, 27521, 1666881711, 191418102448128L, 30281L, false, true, (char) 16, (char) 60219,
        Double.longBitsToDouble(0x3fe57725a3c5501cL), Double.longBitsToDouble(0x3fec1286d1d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test203() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u58bd\ud442\u74fb\u0a84\u1409\ucf53\u58ae\ud629\u4ba1\ub542\ud380\000", "\uda6a\udce9\udb43\ude16\ud974\udfd9\ud878\udf8e\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff",
        37, 22672, 754644385, 1559832578432610967L, -45216L, true, false, (char) 17, (char) 50431,
        Double.longBitsToDouble(0x3fdbafeae1861788L), Double.longBitsToDouble(0x3fd2aceb72d240b0L)));
  }
  @Test(timeout = 4000)
  public void test204() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 1, "\ud9b4\ude03\udb44\udc18\udacb\udd2b\ud8d7\udecc\uda85\udeef", "\u4b33\u58aa\u58e5\u1409\uaaef\u58ae\u6c81\u4c29\ub542\ud380\ub717\ubca8\u6295", "\udaf9\udc65\udb1d\ude73\ud800\ude44\uda9b\udd0d\udbca\udf0a\ud8db\uddc6\ud929\udc51\ud804\udcb6\ud82c\udf62\ud93f\uddff\udad8\udeed\ud91c\udc0d\u6d0a\ud85a\udcce\ud995\ude32\ud9c4\udd8f\udb65\udcf0\ud9c6\ude2d\u5f9b\uda17\udeea\ud900\udc46\ud921\udc13",
        44, 74775, -687879495, -5907048241643172499L, 14608L, false, false, (char) 28, (char) 60219,
        Double.longBitsToDouble(0x3fdaee4b458aa038L), Double.longBitsToDouble(0x3fec8a826ed29fe3L)));
  }
  @Test(timeout = 4000)
  public void test205() throws Throwable {
    assertEquals("0=null\0121=void |this=org.apache.commons.cli2.builder.PatternBuilder:@?\012",
        Z.run(T, 2, 3, 4, 4, "\udbed\udfbe\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u58bd\u200e\u19d0\uc15a\u8018\ucf53\u5871\ud629\u4ba1\ub542\ud380\000", "\uda64\udfe9\ud88b\udc19\udb31\udc61\ud98c\udd77\udb06\udd51\udb57\udf38\udb97\udeb8\udb61\udfd8\udbfa\udc48\ud8bd\udc77\ud82c\udf62\ud93f\uddff\udb74\ude10\ud823\udfe8\uda4c\udc47\uda37\udcbd",
        9, 27521, 1666881711, 191418102448128L, 30281L, false, true, (char) 16, (char) 35388,
        Double.longBitsToDouble(0x3fe57725a3c5015bL), Double.longBitsToDouble(0x3fec1286d1d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test206() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\udba3\udcb6", "\u58e8\ud442\u74fb\u0a84\u1409\ucf53\u652e\ud629\u4ba1\ub542\ud380\000", "\uda64\udfe9\ud88b\udc19\ud975\udc63\ud98c\udd77\udb06\udd51\udb57\udf38\ud8b7\uddbf\udb61\udfd8\ud830\udf55\ud8bd\udc77\ud82c\udf62\ud93f\uddff\udb74\ude10\ud823\udfe8\uda4c\udc47\ud98a\udf5c",
        16, 19668, 1666881711, -3195675469041292288L, 30281L, false, true, (char) 6, (char) 60219,
        Double.longBitsToDouble(0x3fe2d725a3c5501cL), Double.longBitsToDouble(0x3fec1286d3d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test207() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u58bd\ud442\u74fb\u0a84\u1409\ucf53\u58ae\ud629\u4ba1\ub542\ud380\000", "\uda6a\udce9\udb43\ude16\ud974\udfd9\ud878\udf8e\u008e\uda9b\udd0d\udba9\uddb8\udb61\udfd8\ud929\udc51\ud8bd\udc77\ud82c\udf62\ud93f\uddff",
        37, 22672, 754644385, 1559832578432610967L, -45216L, true, false, (char) 17, (char) 50431,
        Double.longBitsToDouble(0x3fdba540f1861788L), Double.longBitsToDouble(0x3fd2aceb72d240b0L)));
  }
  @Test(timeout = 4000)
  public void test208() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 1, "\u1d8d\ud859\udf4a\uda0b\udddb\ud98b\udfeb\uda86\udc57", "\u200e\u19d0\uc15a\u8018\ucf53\u5871\u7629\u4ba1\ub542\ud380\u6928\u3fbc\u6295", "\udb31\udc61\ud98b\udf77\udb06\udd51\udb57\udf38\udb97\udeb8\udb61\udfd8\udb40\uddeb\ud93a\uddc0\udad8\udefc\ud803\udf38\udb9c\udfd4\uda87\udea2\uda4c\udc86\uda37\udcbd\ud995\ude0a\udb52\uddbc\udb3f\ude7a\ud983\ude1f\u6939\udbe9\udf1f\ud9e6\uddfe\ud9c9\udddb",
        9, 17233, 2012733919, 6894769050203933990L, 30281L, false, true, (char) 16, (char) 12861,
        Double.longBitsToDouble(0x3fe57403a5c5015bL), Double.longBitsToDouble(0x3fe5848d6a506332L)));
  }
  @Test(timeout = 4000)
  public void test209() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 5, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\udba3\udcb6", "\u58e8\ud442\u74fb\u0a84\u1409\ucf53\u46e5\u4ec2\u4b8d\ub542\ud380\000", "\uda64\udfe9\ud88b\udc19\ud975\udc63\ud8b9\uddee\udb06\udde3\udb57\udf38\ud8b7\uddbf\udb61\udfd8\ud830\udf55\ud8bd\udc77\ud82c\udf62\ud93f\uddff\udb74\ude10\ud823\udfe8\uda4c\udc47\ud98a\udf5c",
        16, 19668, 1666881711, -3195675469041292288L, 30281L, false, true, (char) 6, (char) 60219,
        Double.longBitsToDouble(0x3fe2d725a3c5501cL), Double.longBitsToDouble(0x3fec1286d3d29fe3L)));
  }
  @Test(timeout = 4000)
  public void test210() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 4, "\udbed\udf35\uda10\udf46\ud9ff\udf95\ud98b\udfeb", "\u58bd\ud442\u74fb\u0a84\u1409\ucf53\u58ae\ud629\u4ba1\ub542\ud380\000", "\uda66\udc5a\udb43\ude16\ud916\udf69\ud825\uddae\udb8e\udf34\ud9f5\udfd1\ud95b\udd90\udb61\udfd8\ud876\uded8\ud8bd\udd1f\udaa1\udcda\ud93f\uddff",
        5, 54360, -1470437422, 1531272227030217367L, -45216L, true, false, (char) 21, (char) 50431,
        Double.longBitsToDouble(0x3fdba540f1861788L), Double.longBitsToDouble(0x3fd2ace7a2d240b0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.builder.PatternBuilder|create||new:org.apache.commons.cli2.builder.PatternBuilder:",
    "M|org.apache.commons.cli2.builder.PatternBuilder|createOption|char,boolean,char|new:org.apache.commons.cli2.builder.PatternBuilder:",
    "M|org.apache.commons.cli2.builder.PatternBuilder|reset||new:org.apache.commons.cli2.builder.PatternBuilder:",
    "M|org.apache.commons.cli2.builder.PatternBuilder|validator|char|static",
    "M|org.apache.commons.cli2.builder.PatternBuilder|withPattern|java.lang.String|new:org.apache.commons.cli2.builder.PatternBuilder:",
    "C|org.apache.commons.cli2.builder.PatternBuilder|<init>|",
    "C|org.apache.commons.cli2.builder.PatternBuilder|<init>|org.apache.commons.cli2.builder.GroupBuilder,org.apache.commons.cli2.builder.DefaultOptionBuilder,org.apache.commons.cli2.builder.ArgumentBuilder",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
