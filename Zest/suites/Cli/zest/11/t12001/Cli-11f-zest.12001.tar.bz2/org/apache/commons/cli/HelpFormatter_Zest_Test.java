package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 12, 12, 8, "\ud957\udfc2\ud854\udcca\u0557\ud816\ude19\ud8ad\udfb4\uda36\udfde\udb06\udfcf\ud86e\udc32\ud821\udfd0\udb31\ude18\uda74\udefb\ud9e9\ude9f\udaf7\udf67\ud8d3\ude13\udb18\udd98\uaeac", "\u7ea1", "\ud9a1\ude69\udba1\udc00\udb4b\udfd4\ud9df\udd45\ud963\udc97\uda89\udf15\udb0e\udd21\udb2c\ude00\ud96b\udd6d\ud86e\uddec\uda24\ude96",
        -4, 71293, 184636017, 5403291154834503146L, 59007L, true, false, (char) 31219, (char) 30926,
        Double.longBitsToDouble(0x3fa77d1ffd641430L), Double.longBitsToDouble(0x3feb8d8cf2ea1570L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 12, 12, 8, "\ud957\udfc2\ud854\udcca\udb07\udc2a\ud816\ude19\ud8ad\udfb4\uda36\udfde\udb06\udfcf\ud86e\udc32\ud821\udfd0\udb31\ude18\uda74\udefb\ud9e9\ude9f\udaf7\udf67\ud8d3\ude13\udb18\udd98\uaeac", "\u7ea1", "\ud9a1\ude69\udba1\udc00\udb4b\udfd4\ud9df\udd45\ud963\udc97\uda89\udf15\udb0e\udd21\udb2c\ude00\ud96b\udd6d\ud86e\uddec\uda24\ude96",
        -4, 71293, 184636017, 5403291154834503146L, 59007L, true, false, (char) 31219, (char) 30404,
        Double.longBitsToDouble(0x3fdc104d7fac83e8L), Double.longBitsToDouble(0x3feb8d8cf2ea1570L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 12, 0, "\ud9e1\udcad", "\u42bb\u2c56\u9f9f\uaa20\u70e0\u9efa\u44a8\u0383\u5834\u9b3d", "\ud8c1\udf97\ud800\udce4\ud9eb\udfe3\udaf2\udd01\ud9f8\udefa\ud9aa\udee2\ud9a1\ude69",
        32, 16607, 234087539, -5872387380450427212L, -40216L, false, true, (char) 27334, (char) 24408,
        Double.longBitsToDouble(0x3fe3889650ad0b01L), Double.longBitsToDouble(0x3fdea4afcfccdbd6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 12, 12, 8, "\ud957\udfc2\ud854\udcca\u0557\ud816\ude19\ud8ad\udfb4\uda44\udfe5", "\u9efa\u62a8", "\udaf7\udf67\udbf9\udd0e",
        19, 6346, 1141577189, -4172292080283276689L, -79753L, false, false, (char) 62001, (char) 32134,
        Double.longBitsToDouble(0x3f8a192bb2837140L), Double.longBitsToDouble(0x3fd82627540abd42L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 4, 8, "\udb0e\udf16\ud854\udcd1\udb17\ude62", "\u43de\u618b\u70e0\u9efa\u44a8\u0383", "\ud8d3\ude13\udb18\udd98\ud9db\udde3\uda5d\udcd7\ud9af\udf0b\uda87\udc2c\ud9f8\udeed\ud9aa\udee2\udb13\udc27\udba1\udc00\udb4b\udfd4\ud9df\udd45\ud963\udc97\udb55\udc11\udaed\udf11\ud8c8\udc73\ud94d\udf7a\ud81f\udf3f\ud95b\udd81\ud817\udf10\ud9ea\ude53\u8317\ud8ef\udd18",
        59, 71942, 1671631196, 3486525360875952881L, -56014L, false, true, (char) 2831, (char) 18522,
        Double.longBitsToDouble(0x3fefe405a7827d52L), Double.longBitsToDouble(0x3fcc0981af5c2410L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 6, 12, 8, "\ud962\udd67\ud854\udcca\u0557\ud816\ude19\ud8ad\udfb4\uda36\udfde\udb06\udfcf\ud86e\udc32\ud92d\udea5\udb31\ude18\uda74\udefb\ud9e9\ude9f\udaf7\udf67\ud8d3\ude13\udb18\udd98\uaeac\uda0c\udde7\ud9af\udf0b\ud83c\udc67\uda4c\udd44\udbc9\udca7\ud9a1\ude69\udba1\udc00\udb4b\udfd4\ud9df\udd45\ud963\udc97\uda89\udf15\uda29\udf23\udb2c\ude00\ud96b\udd6d\ud86e\uddec\uda24\ude96\ud886\udc47\ud9f7\udf88", "\u5031\u27e8\ua58d\u2865\u1ada\ube90\u8987\ua2ef\u18da\u59da\u1fed\ubf5c\u31cc\u4371", "\ud862\udc84\udad8\udc0a\udbd4\udedb\ud9bf\udf9b",
        -3, 99826, -646967571, -5147160644772056788L, -67410L, false, false, (char) 57455, (char) 64072,
        Double.longBitsToDouble(0x3fd8d862118c665eL), Double.longBitsToDouble(0x3fecc6f4a0de0392L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 8, "\ud957\udfc2", "\u0b08\u2c56\u9f9f\uaa20\u70e0\u00ff\ua012\000\000\u5e0d\ub680\uc391\u5213\u2e8a\u9dd4\u7ea1\u0695\u8b83\u247a\u3252\ub600\u5cfc\u337b\u31aa\u690f\u4499\u602d\u6309\u6cd8\u7d6f\u04b3\u177c\u898c\ub5ea\u27e8", "\udb9c\udf08\ud8b9\udd0b\uda48\udc06\ud9c8\udf37\ud9ae\udcb4\udbab\udcd8\udaa9\udc24\udae0\udee4\ud9fc\udfb4\ud8af\udef9\ud912\udd2e\uda6a\udf69",
        10, 75301, -2103535959, 8619617244435831729L, 5247L, true, true, (char) 14484, (char) 32611,
        Double.longBitsToDouble(0x3fbcca2b44698d28L), Double.longBitsToDouble(0x3fec8ba2b99a3e05L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|java.io.PrintWriter,int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
