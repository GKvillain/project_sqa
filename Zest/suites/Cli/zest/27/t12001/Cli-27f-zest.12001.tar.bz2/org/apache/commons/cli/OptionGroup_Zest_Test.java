package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class OptionGroup_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 4, 8, "\ud9a3\udc82\ud9f3\udee3\uda1e\udc54\ud821\udded\udb98\udecd\udb77\udcdd\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\ud91c\udf92\ud97c\udc40\ud9a4\udefc\ud88f\udca6\udbce\udd66\udb1d\udf7c\ud87b\udd3f\ud9a4\udf04\udb66\udd7c\udb82\udc4d\ud8b6\udc37\uda56\udee3\ud923\udd28", "\u21f7\u84d7\u696c", "\ud852\ude8e\udbc0\udf26\ud9e0\udf1d\udaa6\udea8\u94eb\ud8f4\udec7\udad4\udead\ud8a6\udd36\udbd1\udff0\udbb0\ude7e\ud919\udc79",
        36, 31331, -812568029, -4808723542547595131L, -7250L, false, true, (char) 56305, (char) 12624,
        Double.longBitsToDouble(0x3fe5ad1301567bbeL), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 0, 0, 8, "\000\ud9e0\ude4f\uda1e\udc54\ud821\udded\udb98\udecd\udb77\udcdd\ud834\udf51\uda5c\uddcc\udaad\udd43\udab3\udfed\ud8e4\udf12\ud91c\udf92_\000\ud889\ude64\udbce\udd66\udb1d\udf7c\u6a4f\ud9a4\udf04\udb66\udd7c\udb81\udde0\ud8b6\udc37\ue455\000", "\u21f7\u84d7\u376c", "\ud852\ude8e",
        55, 35058, 1594344719, 4943607550693106458L, -34650L, false, false, (char) 7904, (char) 46823,
        Double.longBitsToDouble(0x3fc61cd0168cb6fcL), Double.longBitsToDouble(0x3fe1191528000000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 8, 4, 8, "\ud9a3\udc82\ud9f3\udee3\uda1e\udc54\ud821\udded\udb98\udecd\udb77\udcdd\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\ud91c\udf92\ud97c\udc40\ud9a4\udefc\ud88f\udca6\udbce\udd66\udb1d\udf7c\ud87b\udd3f\ud9a4\udf04\udb66\udd7c\udb82\udc4d\ud8b6\udc37\ud866\udd0c\ud930\udc9c", "\u21f7\u84d7\u696c", "\ud852\ude8e\udbc0\udf26\ud9d7\ude78\ud855\udf11\u94eb\ud8f4\udec7\udad4\udead\ud8a6\udd36\udbd1\udff0\udbb0\ude7e\ud919\udc79",
        36, 31331, -963562973, -4808908415119884155L, -7250L, false, true, (char) 56305, (char) 12624,
        Double.longBitsToDouble(0x3fe5ad1301567bbeL), Double.longBitsToDouble(0x3fe010001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 5, 4, 5, "\ud9a3\udc82\ud9f3\udee3\uda1e\udc54\ud821\udded\udb98\udecd\uda1a\udd4e\ud834\udea6\uda5c\uddcc\ud81b\udffa\ud9a5\udde7\ud8eb\udc92\ud8ba\udd01\ud97c\udc40\udb65\udd3d\udbd5\udf5b\ud8a7\udf7d\udb1f\ude5b\ud83b\ude44\ud93d\udd39\udb66\udd7c\ud8c5\udd6f\ud8bc\udc74\uda56\udee3\udbae\udd2d", "\u83b3\u5765\u5f18", "\udb17\udf0d\udbc0\udf26\ud9e0\udf1d\ud92e\ude6c\ud829\udcb7\ud822\ude09\ud93b\udf6b\ud8a6\udd36\udaab\udffd",
        12, 42098, 754989193, 2496610075411558947L, -7250L, false, false, (char) 56420, (char) 12640,
        Double.longBitsToDouble(0x3fe5ad1301567bbeL), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 4, 2, "\ud9a3\udc82\ud9f3\udee3\uda1e\udc54\ud9e6\udecf\ue1f1\udb77\udcdd\ud834\udf51\udbbe\udcdd\ud8e8\udfce\udab4\udf03\udb7e\udf31", "\u6825\ubde7\u1cd0\ua122\u5804", "\udb57\udf98",
        43, 80482, -2049170341, 2958895862732490682L, -34853L, false, true, (char) 34252, (char) 35709,
        Double.longBitsToDouble(0x3fcc14618c69126cL), Double.longBitsToDouble(0x3fa5bbc20b075800L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 4, 8, "\ud879\udc00\ud9f3\udee3\uda1e\udc54", "\u1624\uaa6f\u009c\u4b7f\u0dae", "\ud97c\udc40\ud9a4\udefc\ud88f\udca6",
        56, 91840, -1441043889, -5500144721505741587L, -41423L, true, false, (char) 37790, (char) 41464,
        Double.longBitsToDouble(0x3fedd14882991e8bL), Double.longBitsToDouble(0x3fe486b8ba3ab44cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 6, 4, 8, "\ud9a3\udc82\udb5f\udd79\uda01\udfe9\ud821\udded\udb57\udead\udb77\udc58\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\ud91c\udf92\ud97c\udc40\ud9a4\udefc\ud88f\udca6\udbce\udd66\udb1d\udf7c\ud87b\udd3f\ud9a4\udf04\udb66\udd7c\udb82\udc4d\ud8b6\udc37\uda56\udee3\ud923\udd28", "\u21f7\u84d7\u1f02", "\ud852\ude8e\ud94b\udeac\udba0\ude59\udaa6\udf53\ud9b4\udcd2\ud8e7\udf4d",
        9, 92480, -1993976078, 5831481718183323130L, 14083L, true, false, (char) 51963, (char) 65073,
        Double.longBitsToDouble(0x3fdf2842a1bdb9aeL), Double.longBitsToDouble(0x3fdf017bd30af4d8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 7, 5, 2, "\ud9a3\udc82\ud9f3\udee3\uda1e\udc54\ud9b2\udc87\ud873\udcb6\udb62\udf20\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\ud809\udfa7\ud97c\udc7d\ud9a4\udefc\ud88f\udca6\udbce\udd66\udb1d\udf7c\ud87b\udd3f\ud9a4\udf04\uda3f\udc89\udb59\ude74\ud8b6\udc37\uda56\udee3\ud923\udd28", "\u21f7\u84d7\u696c", "\ud852\ude8e\udbc0\udf26\ud9ac\udf23\udaa6\udea8\udacd\udebe\ud974\udf0f\ud859\udd4b\ud9ac\udd79\udbd1\udfd8\udbb0\ude7e\ud919\udc79",
        36, 37650, -812568029, -4808723542547595131L, -7250L, false, true, (char) 56305, (char) 12624,
        Double.longBitsToDouble(0x3fe5ad13077933beL), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 0, 8, "\ud983\udc82\ud9f3\udee3\uda1e\udc54\ud821\udded\udb98\udecd\udb77\udcdd\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\ud91c\udf92\ud97c\udc40\ud9a4\udefc\ud88f\udca6W\udb1d\udf7c\ud87b\udd3f\ud9a4\udf04\udb66\udd7c\udb81\udfe7\ud92c\udc32\uda56\udee3\ud923\udd28", "\u0f68\u84d7\u696c", "\ud852\ude8e",
        55, 35058, 50447, 4943606588528419610L, -79962L, false, false, (char) 7904, (char) 46823,
        Double.longBitsToDouble(0x3fc61cd0168c0000L), Double.longBitsToDouble(0x3fe119152b6acf91L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 4, 0, "", "\u1164", "\udb77\udcdd\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed",
        14, 56758, -888085665, 1353808742469342786L, -72032L, true, false, (char) 14751, (char) 171,
        Double.longBitsToDouble(0x3fe3326b492fdc76L), Double.longBitsToDouble(0x3fb55dd4e2db7a18L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 3, 6, 8, "\ud857\uddd1\ud9fc\udfa1\uda1e\udc54\ud821\udded\udb98\udecd\udb77\udcdd\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\ud91c\udf92\ud97c\udc40\ud9a4\udefc\ud88f\udca6\udbce\udd66\udb1d\udf7c\udb99\udc42\ud9a4\udf04\udb66\udd7c\udb82\udc4d\ud8b6\udc37\uda56\udee3\uda80\udd95", "\u21f7\u84d7\u696c", "\ud852\ude8e\udbc0\udf26\ud9e0\udf1d\udaa6\udea8\u94eb\ud8f4\udec7\udad4\udead\ud8a6\udd36\ud887\udd8a\udbc6\udd71\ud919\udc79",
        36, 31331, -812568029, -4808723542547595131L, 58286L, false, true, (char) 56305, (char) 12624,
        Double.longBitsToDouble(0x3fe5ad1301567bbeL), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 8, "\ud9a3\udc82\ud9f3\udee3\uda1e\udc54\ud821\udded\udb98\udecd\udb77\udcdd\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\ud91c\udf92\ud97c\udc40\ud9a4\udefc\ud88f\udca6\udbce\udd66\udb1d\udf7c\ud87b\udd3f\udbec\udea4\udb66\udd7c\udb82\udc4d\ud8b6\udc37\uda56\udee3\ud923\udd28", "\u21f7\u84d7\u696c", "\ud852\ude8e\udbc0\udf26\ud9e0\udf1d\udaa6\udea8\u94eb\ud8f4\udec7\udad4\udead\ud8a6\udd36\udbd1\udff0\udbb0\ude7e\ud919\udc79",
        36, 31331, -812568029, -4808723542547595131L, -7250L, false, true, (char) 56305, (char) 12624,
        Double.longBitsToDouble(0x3fe5ad1301567bbeL), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 0, 4, 8, "\ud9a3\udc82", "\ube1e\000\000\ua99b\000\000\uca12\u099d\u2895\u1ca2\u6825\ubda5\u1cd0\u92c0\000\000", "\ud8b6\udc37",
        58, 17659, 688921628, -969673598873128333L, 18214L, false, false, (char) 55295, (char) 49733,
        Double.longBitsToDouble(0x3fed544e9e823b30L), Double.longBitsToDouble(0x3fd0fc66e1c0be0eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 4, 4, 8, "\ud9a3\udc82\ud9f3\udee3\ud913\udc4e\ud9f8\udfee\uda6c\udfe2\ud931\udc08\ud81a\uddc5\ud955\udee9\ud8a1\udf5b\ufdb9\ud9af\uddee\uda64\udf73\ud97c\udca3\ud9a4\udefc\ud88f\udca6\ud8f9\udeba\ud980\udc33\ud8ae\udf18\udbf5\udd5a\udb66\udd7c\udb82\udc4d\ud8b6\udc37\uda56\udee3\ud923\udd28", "\u21f7\u84d7\u6176", "\ud852\ude8e\udbc0\udf26\uda2e\udf24\udaa6\udea8\u94eb\ud8f4\udec7\ud880\udf8e\uda2e\uddc7\ud8de\uddd1\u0985\ud919\udc79",
        -4, 31331, -812568029, 453998725323587717L, 69394L, false, true, (char) 56305, (char) 12624,
        Double.longBitsToDouble(0x3fe5ad1301567bbeL), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud9a3\udc82\ud9f3\udee3\uda1e\udc54\ud9c3\udc9e\uda4f\ude40\udb55\ude17\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\ud91c\udf92\ud97c\udc40\ud9a4\udefc\ud88f\udca6\udbce\udd66\udb1d\udf7c\ud87b\udd3f\ud9a4\udf04\ud90c\udc6f\udb4f\udfd5\uda7e\udfbc\uda54\udc76\udb5b\udf23", "\u21f7\u84d7\u696c", "\ud852\ude8e\udbc0\udf26\ud9e0\udf1d\udaa7\udc9f\u94eb\ud8f4\udec7\udad4\udead\ud8a6\udd36\udbd1\udff0\udb4e\udfb1\ud935\udf79",
        36, 31331, -812568029, -4808723542547595131L, -7250L, false, true, (char) 56305, (char) 12624,
        Double.longBitsToDouble(0x3fc54bac0559eef8L), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\0121=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 8, 7, 8, "\uba51\ud9f3\udee3\uda1e\udc54\ud821\udded\udb98\udecd\udb77\udcdd\udb17\udf03\udbbb\udc6b\ud887\udd6b\udb61\ude9c\ud8e4\udeb3\udad5\udfee\ud97c\udccb\ud9a4\udefc\ud88f\udc92\udbce\udd66\udae8\udec2\udafc\udedd\ud9bf\uddfa\udb66\udd7c\udb3c\udccd\ud8b6\udcc5\uda56\udee3\ud923\udd28\udb3a\udf8a\udbeb\udeee\udb5a\udc09\ud917\udd1c\uda51\udf5b\ud9e9\ude6e\udb44\udc94\ud982\udd86\udbbe\ude26\ud9e0\udf1d\udaa6\udea8\u94eb\ud8f4\udec7\udad4\udead\ud9e7\udc3f\udbd1\udff0\udbb0\ude7e\udbfd\udf4b\ud9aa\udf57\udac5\udfad\uda9f\udf4c\ud8a1\udf7b\uda03\udf15\ud8aa\udef7\ud87b\ude25\udb2c\uded7", "\u9c42\u895a\ucf75\u456d\u1bfb\ucf60\u4974", "\ud9df\udfdf\ud992\udd8b\ud877\udfc2\ud95a\udebc\uda7b\udda1\ud869\udfe7\ud871\udf02\ud887\uddab\ud81d\uddfa\ud835\ude93\ud890\uddfc\ud8f1\udf9a\udbb2\udca2\ud80d\udfa3\ud9ae\ude73\uda5a\udfb2\ud96b\udc3c\ud813\udda0\udb78\udf71\ud8cc\udf97\udab2\ude08\ud8fc\udec3\udbbc\uddd3\udb6d\ude05\ud878\udf97\ud9da\udc2a",
        11, 92435, -1123529248, -4664686011795723307L, 82423L, false, false, (char) 63078, (char) 46341,
        Double.longBitsToDouble(0x3fe183cebb1f6d08L), Double.longBitsToDouble(0x3fee2bd3c047fa83L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 8, 8, "\ud9a2\udfcd\ud9f3\udee3\udb7d\udfa8\ud871\ude7f\ud85e\udc4b\ud8da\udfd4\uda3a\udeaf\uda5c\uddcc\ud86f\ude44\ud8ba\udef0\udae0\udc8f\uda01\ude3c\ud83d\udc7c\ud8bf\uddd5\ud95e\ude0e\udbc7\ude9d\udb1d\udf7c\ud87b\udd3f\ud830\udce9\udb66\udd7c\udb82\udc4d\udb96\udcf4\uda6d\udf1b\ud926\udf6b", "\u7523\u087d\u7d9f", "\uda89\ude06\udbae\udc3f\ud9e0\udf1d\udaa6\udea8\udbc7\udcdb\udadd\udc48\udad4\udead\ud8a6\udd36\udbd1\udff0\udbb0\ude7e",
        -5, 53435, 581287331, -6036227281792009366L, 59994L, false, false, (char) 40429, (char) 26452,
        Double.longBitsToDouble(0x3f7b0401dab4f180L), Double.longBitsToDouble(0x3fd018a7f991825cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 7, 7, 5, "\ud9a3\udc82\ud9f3\udee3\uda0b\udd1b\ud821\udded\udb98\udecd\udb77\udcdd\uda9d\ude5c\uda5c\uddcc\udaad\udd43\udab4\udf4d\ud8e4\udebf\ud91c\udf92\ud97c\udc40\ud9a4\udefc\ud88f\udca6\udbce\udd66\udac9\ude12\ud87b\udd7b\ud9a4\udf04\udb66\udd7c\udb82\udc4d\udabe\udd3c\uda3c\ude83\ud923\udd28", "\u21f7\u84d7\u2ddd", "\ud852\ude8e\udad0\udf2e\ud9e0\udf1d\udaa6\udea8\u94eb\ud919\uddc7\udaf3\udcad\ud8a6\udd36\udbd1\udff0\udbb0\ude7e\ud919\udc79",
        36, 31331, -812568029, -4808723542550167163L, -7250L, false, true, (char) 29495, (char) 6183,
        Double.longBitsToDouble(0x3fe5c8b791567bbeL), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\0121=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 8, 8, 8, "\ud9a3\udc82\ud89d\udec2\uda5a\udfc1\ud821\udded\udb98\udecd\ud841\udd23\udae2\udf7d\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\ud91c\udf92\ud97c\udc40\ud9a4\udefc\ud88f\udca6\udbce\udd66\udb1d\udf7c\udb3b\udfa5\uda16\udc63\udb66\udd7c\udb82\udc4d\ud8b6\udc37\uda56\udee3\ud923\udd28", "\u21f7\u84d7\u696c", "\ud852\ude8e\ud937\ude63\ud9e8\udff6\udaa6\udea8\u94eb\ud8f4\udec7\udad4\udead\ud8a6\udd36\udbd1\udff0\udbb0\ude7e\ud919\udc79",
        36, 31331, -366179468, -4808810675909797755L, 12122L, false, true, (char) 56305, (char) 40777,
        Double.longBitsToDouble(0x3fe5ad1301567bbeL), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 0, 2, "", "\ud423", "\udb52\udedd",
        37, -1000, -502999288, -335796127204900708L, -100000L, false, false, (char) 7430, (char) 13043,
        Double.longBitsToDouble(0x3e40000000000000L), Double.longBitsToDouble(0x3eba400000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 6, 6, 5, "\ud9a3\udc82\ud9f3\udee3\uda1e\udc54\ud821\udded\udb98\udecd\udb77\udcd2", "\u4b7f\u0dae\uae1e\u2196\u7030\u682c\ubde7\u1cd0\ua122\ud481\u750c\u48ac\uc847\u1e9c", "\ud9df\ude87\udbeb\udeee\udb5a\udc09\ud9fe\udd60\uda51\udf5b\udafd\udd63\udb41\udc8a\ud852\ude8e\udbc0\udf26\ud9e0\udf1d\udaa6\udea8\uda5d\udce6\ud8f4\udec7\udad4\udead\ud8a6\udd36\udbd1\udff0\udbb0\ude7e",
        43, 41781, 584330068, -3489953111449797782L, 90751L, true, false, (char) 21933, (char) 56305,
        Double.longBitsToDouble(0x3feaa10fe2b5a260L), Double.longBitsToDouble(0x3fd567bbe6900006L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 0, 1, "\000\udb76\udee3\ud9ce\udc4b\ud821\udde2\udb98\udecd\ufba1\uda5a\ude7f\udbe4\udd6a\udae4\udd98\udab4\udcab\ud8e4\udf12\ud91c\udf92\u00eaw\udade\udece\ud917\udf8a\udb1d\udf55\u6a4f\ud9a4\udf04\udba2\udc41\udbf4\udffc\udaeb\udf7e\uda62\udd6a\000", "\ucb39\u84d7\u382e", "\udb5c\udf93",
        16, 35058, 1594344719, 4943606644455007002L, -34655L, false, false, (char) 7904, (char) 46823,
        Double.longBitsToDouble(0x3fc61cd015d4b6fcL), Double.longBitsToDouble(0x3fe9ca4355320028L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 2, 1, "\u8031\ud9e0\ude87\uda1e\udc54\ud821\udded\ud8ab\udd9e\ud9d2\udc6f\udaf9\udd84\uda5c\uddcc\udaad\udd43\udab3\udfed\ud8e4\udf12\ud91c\udf92_\000\ud896\udf2a\ud970\udf52\udb1d\udf7c\u6a4f\ud9b2\udd2b\ud8e5\ude34\ud9ab\udc88\ud8d0\udd6e\ud9ec\udc8f\ud936\udffd", "\u351a\u1e34\u99ef\u01e8\u2c05\u2946\u4dd0\u2a47\u5db0\u4afd\u96a9\u89bc\u641d", "\udb28\ude2b\ud95a\ude9e\udbe4\udcbb\udb51\udf0c",
        14, 20571, -2077217982, -5835134525260816893L, -30413L, false, true, (char) 45810, (char) 20422,
        Double.longBitsToDouble(0x3fe1b722804a8789L), Double.longBitsToDouble(0x3fe74c6646867147L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 8, 5, "", "", "\uda4f\ude40",
        39, -1000, 0, -2161727821137838028L, 43074L, true, true, (char) 31985, (char) 10507,
        Double.longBitsToDouble(0x3fb5f92d16045230L), Double.longBitsToDouble(0x3fe27e451f84aa1bL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 5, "", "\u63ee", "\026",
        -5, -1000, -1275068416, -5585450536170252491L, -94302L, true, false, (char) 7430, (char) 13043,
        Double.longBitsToDouble(0x3fec2550da1922e2L), Double.longBitsToDouble(0x3fd7fc8cca230ab0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 3, 8, "\ud9a3\udc82\ud9f3\udee3\uda1e\udc54\ud821\udded\udb98\udecd\udb77\udcdd\ud834\udf51\uda5c\uddcc\udaad\udd43\udab4\udeed\ud8e4\udf12\uda72\udefc\ud96e\udc42\ud9a4\udefc\ud88f\udca6\udbce\udd66\udaab\udfc4\ud87b\uddb0\ud9a4\udf04\udb66\udd7c\udb82\udc4d\ud8b6\udc37\uda56\udee3\ud923\udd28", "\u221c\u84d7\u696c", "\ud852\ude8e\udbc0\udf26\ud9e0\udf1d\udaa6\udea8\u94eb\uaac3\udad4\udead\ud8a6\udd36\udbd1\udff0\ud92a\udefb\ud916\udd2b",
        21, 31331, -812567908, -4808723542547595131L, -7250L, false, true, (char) 32099, (char) 42020,
        Double.longBitsToDouble(0x3faf90aa9567b5e0L), Double.longBitsToDouble(0x3fea40001d8f90c7L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 3, 0, "\u00e2\ud9f3\ude4f\uf163\ud821\udded\udb98\udecd\udb77\udcdd\ud9b6\ude32\ud9f6\udd44\udaad\udd4c\udab4\udeed\ud8e4\udf12\uda27\udc96\ud97d\udf6b\ud9a4\ude53\ud93b\udcae\u9bf9\udb1d\udf7c\ud87b\udd3f\ud8bb\ude31\ud9a2\udcf0\uda03\udd8d\ud8cb\uddc5\uda56\udee3\uda35\udd91\ud915\udc84\ud81b\udc3c\ud8d3\udc54\udb24\udea2\udb7e\udf46\uda58\udd64\ud83c\uddf4\ud86b\udede\ud848\udce7\udb8d\udc04\udbc0\udd0f\udb5e\udda4\ud880\udea6\uda79\udf80\ud89a\ude6e\udb14\uded4\uda72\udde6\ud8ed\udf41\ud832\uddb8\uda2f\udc7a\ud9e8\udd5f\udbae\udd62\udb50\udd5b\ud99d\udd3e\ud8c0\uddcf\udac5\udd95\ud8bf\udff7\uda81\udce5\udbca\udf13\udbae\udca8\udb9f\udee3\ud847\ude6f\udbca\udf8a\ud98f\udc88\ud808\ude41\udb5b\udfa7\udad3\udf98\ud831\udf62\ud894\udd39\uda18\ude76\uda56\ude61\udb8f\udf7d\uda0e\udc51\udae2\udef4\ud951\udd1c\udaad\udc6d\uda1e\uddf0\udaef\udee8\uda53\udcf6\ud97a\udf91\ud913\ude74\udb5a\uded2\udbf4\udeed\uda87\udc8a\ud95a\udc79\udaa2\udf47\ud873\udcbc\ud9e1\udf4d\ud80d\udee7\udb64\ude7b\u533f\ud81e\udf9e\ud905\udef9\udb84\udc10\ud9b2\udcf4\ud8ad\ude09\ud873\udd2c\ud8f7\udc51\udb21\udc15\ud9e1\udf79\udbc8\udcee", "\ua878\u4cbd\ub47b\u2396\u5cc9\u9ae5\u075c\u9d15\uced4\u5429\u50d9\u4ac5\u0f32S\uc3c8\uba10\u4a83\ua612\u7701\ubc35\u9cc6\u2df8\u466e\u3dc7", "\ud893\udc31\udbcb\uddc0\udb4f\udc73\udab7\uddde\udbcb\udef3\uc15f\ud881\udf92\ud96c\udf25\udbaa\udd9a\ud895\udd3e\ud8ba\udd36\uda99\udefe",
        31, 50324, -1851116880, -8736006117797589358L, 92653L, false, false, (char) 41098, (char) 64018,
        Double.longBitsToDouble(0x3fa0f2bc1af6a270L), Double.longBitsToDouble(0x3fa213f0dc2f3be0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.OptionGroup|setSelected|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getNames||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getOptions||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getSelected||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|isRequired||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|setRequired|boolean|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|toString||new:org.apache.commons.cli.OptionGroup:",
    "C|org.apache.commons.cli.OptionGroup|<init>|",
    "M|org.apache.commons.cli.OptionGroup|setSelected|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
