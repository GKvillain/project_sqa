package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class OptionGroup_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 2, 0, "\udb7d\ude4d\ud920\udd97\udb90\ude1b\uda57\udd42\udb3f\udfa0", "\u1cff\u5d0e", "\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3",
        50, 82423, -1374425417, 4236225761258488101L, 57418L, false, false, (char) 49696, (char) 17434,
        Double.longBitsToDouble(0x3fd42fa0a43ff06aL), Double.longBitsToDouble(0x3fd3b85a1893081eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 2, 0, "\udb7d\ude4d\ud920\udd97\udb90\ude1b\uda57\udd42\udb3f\udfa0", "\u1cff\u5d0e", "\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3",
        50, 82423, -1374425417, 4236225761258488101L, 57418L, false, false, (char) 49696, (char) 17434,
        Double.longBitsToDouble(0x3fd42fa0a43ff06aL), Double.longBitsToDouble(0x3fd3b85a1893081eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 2, 0, "\u729f\ud893\udcea\udb28\ude97\uda57\udd76", "\u6d9e\u1cff\u5d0e\u9374\u1a8e\ubec7\ud362\u6e98\ubf3d\u410f\u7f68\u4e87", "\ud897\udf8f\ud96e\udf93\udb50\uddfa\ud847\udd31\ud81f\udd69\ud9a7\udccc\ud8d5\udcb1",
        8, 10999, 1016023552, 968367691649626121L, -80062L, true, false, (char) 16267, (char) 47260,
        Double.longBitsToDouble(0x3fb81d62eca61fc0L), Double.longBitsToDouble(0x3fe44df16dfc8a63L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 8, 4, "\udb7d\ude4d\ud920\udd97\udb67\udc87\udbf3\udd82\uda24\uded5\udaa2\udd47\ud901\udf82\u42f4", "\u1a8e\ubec7\ud362\u6e98", "\ud803\udf69\u069a\ud8a1\udd36\udbd4\udff7\ud88e\udcea\ud96e\udf93\udb50\uddfa",
        53, 99923, -130726590, -8817561955187330757L, 49753L, true, false, (char) 52923, (char) 41388,
        Double.longBitsToDouble(0x3fdab8406a125c28L), Double.longBitsToDouble(0x3fde22cd5a74f14eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 2, 0, "\udb7d\ude4d\ud8cc\udc2d\udb90\ude1b\uda57\udd42\udb3f\udfa0", "\u1cff\u5d0e", "\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3\uda91\udcd0\ud803\udf69\ud814\udde3\udbb5\udc59\udbd4\udff7\ud88e\udcea\ud96e\udf93\udb50\uddfa\udbc0\ude74\ud81f\udd69\ud890\udcab",
        45, 24243, 1923030089, 1725963628358880131L, 19464L, true, true, (char) 47857, (char) 13655,
        Double.longBitsToDouble(0x3fee5955f0c65f44L), Double.longBitsToDouble(0x3fe235b0609be59dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.HashMap$KeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 2, 0, 0, "\udb8a\udd38\ud920\udd97\uda0e\udf3a\ud9d0\udfdc\uf994\ud9b9\udcb0", "\u4c76\u9361\u32cf\ubec7\ud362\u6e98\ubf3d\u72fe\ub71c\u4345\ucee0", "\ud96e\udf93",
        3, 9749, 2102710229, -8574637118964485507L, -72349L, true, true, (char) 50653, (char) 29730,
        Double.longBitsToDouble(0x3fd6d06bc6205dbcL), Double.longBitsToDouble(0x3fd8e6d1f5f96aceL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 2, 0, "\udb7d\ude4d\ud920\udd97\ua209\udbfa\ude20\uda29\udcf4\ud85b\udf49", "\u1988\u570c\u1a8e\ubf17", "\uda03\uddc3\uda91\udcd0\ud803\udf69\ud806\udfe3\ud86a\ude67\ufb50\ud88e\udcea\ud96e\udf93\udb50\uddfa\udbc0\ude74\ud81f\udd69\ud81c\udca4\uae13\ud880\uddbc\ud9f2\udddd\uda5d\ude35\udac8\udcc5\udb04\udc0f\ud8e1\udc72\ud99f\udf53\udb5f\udddd\udb36\udc7b\uda54\udcb6\ud9eb\udc4a\udb51\udc87\ud8b9\udf7c\ud81b\udec6\ud804\udffa\udabf\udd3b\ud998\udff7\udb4d\udd05\ud8ab\udc5e\ud98e\ude2f\ud975\udfab",
        28, 68866, -2088553507, -7053922847385398131L, -40184L, false, true, (char) 45203, (char) 59577,
        Double.longBitsToDouble(0x3fe948a8ee69b1b8L), Double.longBitsToDouble(0x3fe5c701b3c98bbeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 4, 2, 5, "\ud8bf\udf4a\ud920\udd97\udb90\ude1b\uda57\udce5\udb25\udffd", "\u1cff\u5d0e", "\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3",
        50, 82423, -1374425554, 4236225761258488101L, 57418L, false, false, (char) 49696, (char) 17434,
        Double.longBitsToDouble(0x3fd42fa0a43ff06aL), Double.longBitsToDouble(0x3fd3b85a1893081eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 5, 2, 2, "\ud801\udc6f\ud920\udd97\ud890\ude1b\uda57\udd42\udb71\udc16\ud94f\udc18\ud901\udf82\u42f4\uda00\udde9", "\u504a\u49bc\u2c5d\u6492", "\ud814\udde3\udbb5\udc59\udbd4\udff7\udadf\uddcf",
        -1, 88282, -27866482, -429454110770248382L, -63451L, true, false, (char) 63263, (char) 56038,
        Double.longBitsToDouble(0x3fee9c35d7e4bf27L), Double.longBitsToDouble(0x3fcb3c6548545c14L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 0, 2, 0, "\udb7d\ude4d\ud920\udd97\udb90\ude1b\uda57\udd42\udb3f\udfa0", "\u1cff\u5d0e", "\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3",
        50, 82423, -1374425417, 4236225761258488101L, 57418L, false, false, (char) 49696, (char) 17434,
        Double.longBitsToDouble(0x3fd42fa0a43ff06aL), Double.longBitsToDouble(0x3fd3b85a1893081eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 7, 2, 0, "\udb7d\ude4d\ud920\udd97\uda3e\uddc1\uda57\udd42\udb3f\udfa0", "\u1cff\u5d0e", "\uda18\uddcb\ud99b\udc07\udb27\udda0\uda03\uddc3",
        50, 82421, -2047611209, 4236225762763422583L, -21745L, false, false, (char) 38796, (char) 12699,
        Double.longBitsToDouble(0x3fd42fa3143ff06aL), Double.longBitsToDouble(0x3fd3b85a1893081eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 7, 8, 0, "\udbc6\ude93\udb91\udc39\udb90\ude1b\uda57\udd42\udb57\udeed", "\u0978\u6c2e", "\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3\udb5a\uddb4\udbf4\udcad\ud814\udde3\udbb5\udc59\udbd4\udff7\ud88e\udcea\ud96e\udf93\udb50\uddfa\udbc0\ude74\ud8a7\ude2d\ud9a4\udf0d\udb80\udee8\ud880\udded\udbd0\udd2c\ud848\udf72\ud8b7\udd80\udbe9\udf8f\ud86f\udd39\ud80a\uddee\uda16\udede\udb74\udd4c\udb63\ude59\ud866\ude48\ud931\udd35\ud955\ude27\u15fc\uda95\udd6e\udbe8\udfd5\ud9ef\ude2b\udbd0\udf32\ud885\udf6e\ud936\udc48\udbdb\udf8e\ud80d\udf16\ud9b5\ude05\uda4c\udc44\ud869\udebe",
        26, 75137, -1324002778, 112219142552342334L, -79887L, true, false, (char) 48274, (char) 33829,
        Double.longBitsToDouble(0x3fc0fbc7052929bcL), Double.longBitsToDouble(0x3fcdda7833bbefe4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 6, 2, 0, "\udb5d\udc3d\uda24\udcaa\udbd3\udc54\udb90\ude27", "\u9f9e\u465f\u5c9a\u0eb8\u1a8e\ubec7\ub4a5", "\uda28\udf55\ud803\udf69\ud814\udd9c\udbb5\udc59\udbd4\udff7\ud88e\udcea",
        56, 77957, -27866482, -429454899114851006L, -81951L, false, false, (char) 21356, (char) 30451,
        Double.longBitsToDouble(0x3fda60e0d0f9fce4L), Double.longBitsToDouble(0x3fe976d99f6fa0d2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 2, 0, "\udb7d\ude4d\ud920\udd97\udb90\ude1b\uda57\udd42\udb3f\udfa0\ud926\udd14\ud901\udf82\u42f4\uda00\udde9\ud995\udf49\ud8d0\udd78\ud9ca\udc35\ud907\ude00\udb27\udda0\uda03\uddc3\uda91\udcd0\ud803\udf69\ud814\udde3\udbb5\udc59\udbd4\udff7\ud88e\udcea\ud96e\udf93\udb50\uddfa\udbc0\ude74\ud81f\udd69\ud9a7\udccc\udb80\udee8\ud880\udded\uda54\udd8f\ud8e6\udcf4\udab1\udf4b\ud88a\udd67\udbc4\udd8f\udbf9\udce8\ud9dd\ude28\ud894\udd54\ud8aa\udcef\ud8fe\udd5f\ud809\udc6a\udbec\udc59\udb83\udffb\ud816\udc75\ud868\ude56\ud9f3\ude1e\ud862\udfdd\udad4\udd0a\udb68\uddaf\ud8ce\ude2f\ud8e5\uded9\ud832\udf58\ud830\udf92\udb85\udf67\ud8d1\udfc9\ud847\uded0\udb98\udd87\udab3\udc16", "\u298b\u9381\u9820\u19c5\u3c1f\ucb1a\u5754", "\uda38\udc05\uda35\udd4e\ud8fa\ude86\udb04\udd1a\ud958\udc33",
        8, 7681, -1324798871, 5351487602289380150L, -20759L, true, false, (char) 39353, (char) 44589,
        Double.longBitsToDouble(0x3fa24faa61deec70L), Double.longBitsToDouble(0x3fc5529c2a57bab8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.HashMap$KeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 3, 2, 4, "\udbab\ude0e\ud9d9\ude2c\udb90\ude1b\uda57\udd42\udb3f\udfa0\ud9d3\udc0a\uda2f\udccd\u430c\uda00\udde9\ud995\udf49\ud837\ude6c\ud9c9\udfa8\ud9ba\udd19\u69a4\uda03\uddc3\ud8eb\uddbe\udbd4\udc3d\uda52\udc8d\udbb5\udc73\ud9b7\udf08\ud89b\udf13\udb64\ude7f\ud86b\uddbd\udbb2\ude0a\ud81f\udd69\ud9a7\udccc\udb80\udee8", "\u128a", "\udbed\uddc8\ud985\ude44\udbd5\udd40\uda29\udd78\ud902\udfeb\uda44\udf28",
        56, 29355, 326339776, -3125002072785361486L, -69730L, false, true, (char) 30938, (char) 6806,
        Double.longBitsToDouble(0x3fb4f3b6fe2cf0e8L), Double.longBitsToDouble(0x3feace05d39bb320L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 1, 0, "\udb7d\ude4d", "\u160f\ua1ca\u792f\u6d9e\u1cff\uca0d\u9374\u1a8e\ubec7\ud362\u6e98\ubf3d\u410f\u1b42\u1ed0\u00e3%\000", "\uca8e",
        38, 67410, -2052998625, -8930795036782420919L, -51870L, false, true, (char) 10954, (char) 2426,
        Double.longBitsToDouble(0x3fea141f02a46098L), Double.longBitsToDouble(0x3fee7f24db60f05bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.util.HashMap$KeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 3, 2, 0, "\udb7d\ude4d\ud920\udd97\udb90\ude1b\uda57\udd42\udb3f\udfa0", "\u1cff\u9339", "\udb75\udf3e\ud916\udebe\udb27\udda0\uda03\uddc3\udbf2\uddb3\uda68\udea5\udbea\udf2e\udb21\uded0\udb06\udcb6\udbdd\udd46\ud96e\udf93",
        11, 8615, -99990077, -561466430820599265L, -12110L, true, true, (char) 24080, (char) 53514,
        Double.longBitsToDouble(0x3fe8df891d8baf20L), Double.longBitsToDouble(0x3fe478328dbc6defL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 6, "\udbb3\udd98\ud920\udd97\udb90\ude1b\uda57\udd42\udb3f\udfa0", "\u1cff\u5d0e\u9374\u1a8e\ubec7\ud362\u6e98\ubf3d", "\ud814\udde3\udbb5\udc59\udbd4\udff7\ud88e\udcea\ud96e\udf93\udb50\uddfa\udbc0\ude74\ud81f\udd69\ud9a7\udccc\udb80\udee8\ud880\udded\ud961\udf56\uda08\udecf\uda9e\udcce\uda16\udc4f\udbf2\udfac\uae28",
        51, 40019, 1291857020, 6147556594487478388L, 38897L, true, true, (char) 28896, (char) 62106,
        Double.longBitsToDouble(0x3fecf3c54210a63eL), Double.longBitsToDouble(0x3fd24bbe83fac480L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 5, "\ud839\ude6b\ud920\udd43\udb90\ude1b\uda57\udd42\udb3f\udfa0\uda12\ude6b\uda0c\udd4d\ub55b\uda00\ude2d", "\ubec7\ud362\u6e98\ubf3d", "\udae5\udc6a\ud965\udd84\udbd4\udff7\ud990\udd6b\ud9f3\ude25\uda64\udcba\ud9d2\udc3e\ud887\udef0\ud9a7\udccc\ud8f9\udc30\udbf5\udcd7\ud9b5\udd86\udad7\udf84\ud94f\udf51\udb66\udd29\uda81\ude6e\udbe8\udeaa",
        50, 13385, 1478398544, 2782000118153479406L, -3845L, true, true, (char) 37768, (char) 3325,
        Double.longBitsToDouble(0x3fbc8c82baf97b28L), Double.longBitsToDouble(0x3fe441d051e2c302L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.util.HashMap$KeySet:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 2, 2, 0, "\udb7d\ude4d", "\u160f\u6fef\000\u6d32\u012c\u5b66\ud500\000\000\ud315\u6d99\ubf3d\u0080\000\u8ee6\u6690\u710c\ucb92", "",
        41, 16859, 0, 0L, -13343L, true, false, (char) 5923, (char) 18870,
        Double.longBitsToDouble(0x3fb379f79bae52f0L), Double.longBitsToDouble(0x3fd896e31d70a42eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 5, 0, "", "", "\000\000",
        -5, 96568, 1834380152, 380641476608L, -1005L, true, true, (char) 28756, (char) 13456,
        Double.longBitsToDouble(0x3fbdc9d235bf70d8L), Double.longBitsToDouble(0x3f45c26000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 6, 0, "\udb7d\ude00\ud920\udd97\udb90\ude1b\uda57\udd42\udb3f\udfa0", "\ud172\u5d0e", "\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3",
        50, 57903, 923752172, 4236224855020388645L, 57418L, true, false, (char) 45555, (char) 17180,
        Double.longBitsToDouble(0x3fd42fa0a43ff06aL), Double.longBitsToDouble(0x3fd3b85a1893081eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 2, 6, "\udb7d\ude4d\ud920\udd97\uda0b\udd19", "", "\u42f4",
        12, 29904, -1606810607, -5686255984937108147L, -100000L, false, false, (char) 50915, (char) 64494,
        Double.longBitsToDouble(0x3fe47d4158000000L), Double.longBitsToDouble(0x3fe3d278028ef792L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 2, 0, "\udb7d\ude4d\ud920\udd97\udb90\ude1b\uda57\udd42\udb3f\udfa0", "\ub7f2\u3566", "\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3\uda91\udcd0\ud803\udf69\ud814\udde3\udbb5\udc59\udbd4\udff7\ud88e\udcea\ud96e\udf93\udb50\uddfa\udbc0\ude74\ud81f\udd69\ud9a7\udccc\udb80\udee8\ud880\udded\ud8e5\udd77\uda24\ude0d\u949c\udb2e\udd04\ud963\uddbd\udac6\udf34\ud8fe\udeee\u74c7\udbd5\ude9d\ud801\udf6f\ud9b2\udda5\udbd5\udc04\udbc0\udd17\u7873\udb96\ude66\ud921\udd7a\uda77\udcae\ud93a\udc59\ud88e\udcee\ud9f0\udf19\ud83f\uddea\ud911\uddc7\uda0a\udd76\udb0a\udd1f\ud830\ude83\udac0\udf15\uda1b\udeb1\udb13\udcdf\udaf9\uddb1\ud941\udf67\uda55\udc0a\udb9f\udd8c\u2037\uda70\ude55\udb49\uddfd\udb69\udee2\ud962\udd3e\uda8a\udd9f\uda01\udfd4\ud9d9\udc69\uda7e\udcb8\ud8f4\uddf4\ud8c1\udf50\udad6\udff0\uda5f\udc42\udb5f\udc2f\ud9c3\udd8d\ud859\udc52\u1a58\udb7d\udcd3\ud8b8\ude48\udb00\ude7c\ud969\udee5\ud93c\ude0e\ud878\udcbe\ud870\udee7",
        43, 8687, 1107235156, -3624077347604214738L, -18493L, true, false, (char) 17132, (char) 49375,
        Double.longBitsToDouble(0x3fec43b7aceed720L), Double.longBitsToDouble(0x3fe1ebb347449694L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 0, 0, 0, "\u00f3", "\u00a9", "",
        -5, 96868, 1834380152, -7410720083586056175L, 63149L, true, true, (char) 63937, (char) 0,
        Double.longBitsToDouble(0x3e48000000000000L), Double.longBitsToDouble(0x3e93200000000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\0121=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 8, 8, 4, "\ud98a\udcfa\ud97b\udc64\ud827\udd88\ud931\udca2\udac3\uddf8\udaa2\udcae\ud901\udf82\u42f4", "\u1a8e\ubec7\ud362\u6e98", "\ud803\udf69\u069a\ud8a1\udd36\udbd4\udff7\ud88e\udcea\ud96e\udf93\udb50\uddfa",
        53, 99923, -130726590, -8817561955187330757L, 49753L, true, true, (char) 7364, (char) 41388,
        Double.longBitsToDouble(0x3fdab8406a125c28L), Double.longBitsToDouble(0x3fde22cd5a74f14eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.OptionGroup:[]\0121=null |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 4, 4, 5, "\udbe0\ude9c\ud9d6\udd58\ud978\ude0a\ud869\udcfe\udb25\udffd", "\u9349\u0dd7\u93ed", "\ud920\udccd",
        -1, 78418, -933308236, 1189967691338155709L, -83909L, true, false, (char) 16581, (char) 9268,
        Double.longBitsToDouble(0x3fda943c0787fcacL), Double.longBitsToDouble(0x3fd4602debd348e0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 6, 2, "\ud8dc\udeeb\ud920\udd97\udb90\ude1b", "\u3894", "\udbed\udea1\ud8b4\udd3f\uba88\ud85f\udfb3\uda01\uddfd\udb27\udda0\uda03\uddc3\uda91\udcd0\ud803\udf69\udbdc\udfb2\udbb4\udf95\udbd4\udff7\ud88e\udcea\ud9e1\udc6c",
        2, 36067, -99976941, -561466430820599265L, -41705L, true, true, (char) 42277, (char) 51832,
        Double.longBitsToDouble(0x3fd0885b1930eb0cL), Double.longBitsToDouble(0x3fc604c343e29bf8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 6, 6, 2, "\ud8e0\ude27\ud920\udd97\ud890\ude1b\uda57\udd42\udb71\udc16\ud94f\udc18\ud952\udecb\u6f19\ud9ad\udeb2", "\ud13c\u494b\u2c5d\u6492", "\ud814\udde3\udbb5\udc59\udbd4\udff7\udad5\ude58",
        58, 94240, -27866536, -6732241789790255810L, -63635L, true, false, (char) 57375, (char) 18000,
        Double.longBitsToDouble(0x3feac87d880d07cdL), Double.longBitsToDouble(0x3fc1ef1711ccabe4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 0, 0, 3, "\000", "", "",
        -5, -1000, 0, 0L, 30993L, true, true, (char) 226, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e1c75c260000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 0, 0, 0, "\udb44\udc8a\ud96e\udd35\udb90\ude66\uda57\udd42\udb3f\udfa0\ud9d3\udc0a\uda2f\udccd\u430c\uda00\udde9\ud995\udf49\ud837\ude6c\ud844\udf84\ud99f\udd41\udb23\udd9e\uda03\uddc3\ud8eb\uddbe\ud96d\udf40\uda52\udcb5\udbb5\udc73\ud856\ude37\udaec\udf5c\ud874\udfde\udaa3\ude6e\udb98\udd71\ud81f\udd69\ud9a7\udccc\udb80\udee8\udb13\ude76\udb9d\udd3f\udb19\udf29\udb79\udf4c\ud86d\udd03\udbed\uddc8\ud985\ude44\udbd5\udd40", "\u5ad9\u97dc\uc3be\uabcd\u77c5\ua5b7\uad9a\u87d5", "\uda45\udcac\ud8ca\ude8e\ud9bb\udc0a\ud8c9\uded1\udbb8\udee7",
        56, 12032, -1079819965, 283071460464122631L, 85541L, true, false, (char) 39502, (char) 13062,
        Double.longBitsToDouble(0x3fdf1e6c345a93e0L), Double.longBitsToDouble(0x3fef2f1eb8b1f487L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\0121=java.lang.String:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 7, 7, 1, "\udbab\ude0e\ud952\uddd4\uda75\uddb8\uda57\udca0\udb35\udda0\ud9d3\udc0a\uda2f\udccd\u430c\udadf\udc44\ud8e8\udc8c\ud837\ude6c\udbcd\udfaa\ud834\udd16\u69a4\uda03\uddc3\ud8eb\uddbe\udbd4\udc3d\uda52\udc8d\udbb5\udc73\ud9b7\udf08\ud89b\udf13\udb64\ude7f\ud86b\uddbd\udbb2\ude0a\ud81f\udd69\ud9a7\udccc\udb80\udee8", "\u128a", "\udbed\uddc8\ud985\ude44\udba1\udde6\udbc5\ude4e\udbae\ude70\udacd\udce5",
        56, 29355, 326339776, -3125002071795505742L, -69730L, false, true, (char) 30938, (char) 6806,
        Double.longBitsToDouble(0x3fd32cedb76c6cf0L), Double.longBitsToDouble(0x3feace05d39bb320L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 2, "\udbb3\udd98\ud920\udd97\udb90\ude93\uda57\udd42\udb3f\udfa0\ud952\udf0b\ud82a\ude58\uda0b\udd71\uda00\udde9\udbfd\udefd\ud85b\udea9\ud9c9\udfa8\ud916\udcc7\udb2b\udc5a\uda03\uddc3", "\ua59e\u6690\u710c\u1a64\uc4aa\u807c\u0896\u96b2\ub405\uc116\u1656\u68c7\u0254\u01ef\uc90d\uc378\u8a76\u7a2e\u6d50\ud7be\u6f44\u20ca\u3487\u2c07\u5d2e\u0a51\u97a3\u653d\u715b\u3d97\u0e54\u43ec\u0e3e\u7196\ua51f\ud4ae\ub2c4\ud0f9\u9b44\ube64\u5986\u2331\u42fb\u203c\u7cf1\u4782\u805d\uc452\u0eb2\u1722\uacea\u8cdc\u6014\u388d\u7e3e\u449b\ua01b\u7baf\u7f64\u6599\ud6de\023\u4323\ub5ba\u6ebc\uacaa\u5af1\u4673\u150f\u51bb\u0b24\u184e\u4cfd\u5c92\u1e47\u673e\uc4b5\u8248\u3c1c", "\ud9a5\udc77\udae7\udc42\udbce\udfe2\udad1\udf66\ud957\udc66\ud9c4\udd3e\udb11\udd40\uda98\udecb\ud9f0\udf18\udb75\udc84\ud955\udeb8\udbe2\udff9\ud906\uddf4\ud844\uded1\ud934\udf19\udaac\udda6\ud883\udcbc\uda05\udfd1\uda18\udf89\ud9fd\udf29\ud8e5\udd31\uda14\udd3e\udbe4\udfea\ud929\udff1\ud8e7\udf81\ud8cc\udfe6\ud86f\ude27\ud997\udf20\uda71\udd6d\udb8b\udf0f\ud81b\udc38\uda4b\udd75\u9871\ud930\ude34\ud910\udc14\ud924\udfe8\udad9\udee9\uda6c\udeab\ud9df\udfeb\ud80f\udf8b\ud994\udc55\ud875\udf48\ud880\ude85\udbd4\ude7b",
        10, 15055, -1835372212, 3029581560368213538L, -44848L, true, false, (char) 30888, (char) 55495,
        Double.longBitsToDouble(0x3fdd452da329e10cL), Double.longBitsToDouble(0x3fed5c06de557acfL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.OptionGroup:[]\0121=void |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 2, 6, 6, 4, "\udaad\udc5a\ud920\udd43", "\ua1ca\u7805\u8955\u7e8d\u5d52", "\ud904\udce5\ud8ee\udffc\udb16\udcff\uda03\uddc3",
        31, 71498, 1623322295, 6640865606829326629L, 44241L, true, true, (char) 16223, (char) 20565,
        Double.longBitsToDouble(0x3fe4cba22e7e1f38L), Double.longBitsToDouble(0x3fbd3be5f3178118L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.HashMap$Values:[] |this=org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 3, 2, 0, "\uda32\udd1f\uda3b\udf50\uda89\udeaf\uda48\ude67\udb3f\udfa0", "\u1cff\u5d0e", "\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3",
        50, 82423, -1374425417, 4236225761258488101L, 57418L, false, false, (char) 49696, (char) 17434,
        Double.longBitsToDouble(0x3fd42fa0a43ff06aL), Double.longBitsToDouble(0x3fd3b85a1893081eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.OptionGroup:[]\012",
        Z.run(T, 1, 8, 2, 0, "\udb7d\ude4d\ud920\udd97\ud823\udfd5\uda57\udcec\udb3f\udfa0\ud926\udd14\ud901\udf82\ud851\udd13\uda00\udde9\ud98d\ude62\ud945\udf73\ud9c9\udfa8\ud907\ude00\udb27\udda0\uda03\uddc3\uda91\udcd0\udb68\udcdb\uda9d\udc4e\udbb5\udc59\udbd4\udff7\ud88e\udcea\ud96e\udf93\udb50\uddfa\udbc0\ude74\ud81f\udd69\ud9a7\udccc\udb80\udee8\ud880\udded", "\u61a0\uca4d\ud33e", "\udaab\udcbd\udb8f\udc65\udadf\ude0d\udbbc\udd19\ud860\udc30\uda95\udfdd\udb18\uddbd\udbfb\uddae\udb73\udf3a\ud854\udce0\uda55\ude96\udb81\ude94\udb45\udca3\udad3\udf56\ud8b1\uded1\uda6d\udd3d\uda27\udc7c\ud8c6\udfd4\ud9e6\ude28\udbf5\udd05\ud88c\udd67\ud9eb\udc4a\udb2d\udfcd\udada\uddba\ud88d\udf39\udba3\ude9b\uda7a\udee6\ud924\udf2c\ud923\ude50\uda9e\udec7\udb3a\udd79\udae4\udf3e\udbc8\udcd0\ud979\uddd6\ud95f\udf88\ud96a\udff3\ud8be\ude96\uda5c\udf04\ud973\udfd7\udacd\udec9\uda9c\udf3c\ud890\udfca\uda88\udcb8\ud894\ude03\ud882\udfb2\udb2c\ude5b\ud8b0\udf37\ud9bd\uddc3\uda64\uded2\ud8ad\udd31\udbb3\ude91\ud9a1\udf3f\uda94\udf63\udbea\udfc2\ud8c3\udef7",
        35, 83099, -535354783, -175997112534332339L, 59899L, false, true, (char) 9360, (char) 9988,
        Double.longBitsToDouble(0x3fe6cbf636f57841L), Double.longBitsToDouble(0x3fbd69cfc9e6fda0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.OptionGroup|setSelected|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getNames||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getOptions||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|getSelected||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|isRequired||new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|setRequired|boolean|new:org.apache.commons.cli.OptionGroup:",
    "M|org.apache.commons.cli.OptionGroup|toString||new:org.apache.commons.cli.OptionGroup:",
    "C|org.apache.commons.cli.OptionGroup|<init>|",
    "M|org.apache.commons.cli.OptionGroup|setSelected|org.apache.commons.cli.Option|new:org.apache.commons.cli.OptionGroup:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
