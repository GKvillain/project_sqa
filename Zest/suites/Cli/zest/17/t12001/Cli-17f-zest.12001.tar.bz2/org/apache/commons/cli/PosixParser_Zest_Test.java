package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 7, "\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud962\udfe4\ud93e\udd12\udaf4\udd32", "\ub9ce\u68bb\u68f0\u61fe\u13da\ua7fe\u2027\u4160\u2cc8\u46b7", "\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e\uda97\udd34\udaa2\udc3b\uda92\udc7d\ud930\ude21\ud8e1\ude99\ud85b\udf6a\udb3c\ude84\ud80e\udfaa\ud9ba\udd5f\uda76\udca9\ud9a8\ude17\udbe0\udea1",
        -3, 67462, 1691465824, -6952113553812447588L, -83947L, true, false, (char) 49115, (char) 40869,
        Double.longBitsToDouble(0x3fc26e3a93d28970L), Double.longBitsToDouble(0x3fe2436a3cd1cd5fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 6, "\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud80e\udc1b", "\u28da\ua835\ub569\u8afa\u68f0\u61fe\u13da\u7b65\u5680\u850a\uc5ff\u8e88\u903b\u591d\u6c95\u4528\ub7b5\u0ff6\u6593\u1a38\u0dea\uc2c8", "\ud904\udea0\ud85b\udf6a",
        27, 71580, -1995636720, -3412787302408996126L, -64649L, false, true, (char) 54354, (char) 16526,
        Double.longBitsToDouble(0x3fe4e4fc2cdb82d4L), Double.longBitsToDouble(0x3fdb947729864778L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 6, "\ud815\udf66\ud85f\udef2\uda5d\udeda\ud962\udff5\ud93e\udd12\udaf4\udd5a", "\ub9ce\u68bb\u68f0\u61fe\u13da\ua7fe\u649c\u927c\u3bde\u7da2", "\udbc5\udc7b\udadd\udd57\udb8d\udf8f\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e\ud996\uddd2\ud9f8\udf04\udaac\udde0",
        1, 40814, -571442836, -3320369828784941266L, 7077L, true, true, (char) 55585, (char) 49405,
        Double.longBitsToDouble(0x3fdbc2c760c00e1aL), Double.longBitsToDouble(0x3fd2d64d1d393f0aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud84c\udfbc\ud866\udd97\ud882\udc2b\ud808\uddb0\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\uda3a\udedb\ud914\uddca\uda24\udf28\udb76\udda9\uda8a\udea5\ud8b3\ude24\uda06\udc4a\udb49\udf2a\ud806\udd51\uda92\udce6\udb3c\uddad\udafe\ude47\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e]] |a1=[Ljava.lang.String;:[[\ud84c\udfbc\ud866\udd97\ud882\udc2b\ud808\uddb0\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\uda3a\udedb\ud914\uddca\uda24\udf28\udb76\udda9\uda8a\udea5\ud8b3\ude24\uda06\udc4a\udb49\udf2a\ud806\udd51\uda92\udce6\udb3c\uddad\udafe\ude47\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 1, 6, 7, "\ud84c\udfbc\ud866\udd97\ud882\udc2b\ud808\uddb0\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\uda3a\udedb\ud914\uddca\uda24\udf28\udb76\udda9\uda8a\udea5\ud8b3\ude24\uda06\udc4a\udb49\udf2a\ud806\udd51\uda92\udce6\udb3c\uddad\udafe\ude47\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e", "\u3ace\u4d99\uac48", "\ud80e\udfaa\ud9ba\udd5f\uda76\udca9\ud9a8\ude17\udbe0\udea1\udb0b\udebf\ud983\udff0",
        4, 60927, -2099994980, 5148349789049208501L, -86923L, false, false, (char) 61031, (char) 40784,
        Double.longBitsToDouble(0x3fe2436a3cd1cd5fL), Double.longBitsToDouble(0x3f821a2bcef54840L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 7, "\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud962\udfe4\ud964\udf93\udb1f\udc76", "\ub9ce\u68bb\u68f0\u61fe\u70d9", "\udb54\udeb5",
        39, 51638, 2069348969, -4849135497668616452L, -67289L, false, false, (char) 58577, (char) 24622,
        Double.longBitsToDouble(0x3fee10e1422f90d1L), Double.longBitsToDouble(0x3fe0cef73cec289cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 7, "\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud962\udfe4\ud93e\udd12\udaf4\udd32\udbd3\ude2c\ud89a\ude28\uda3a\udedb\ud914\uddca\uda24\udf28\udb76\udda9\ud97e\ude18\udb9e\ude16\ud962\udfd8\udb54\udeb5\ud806\udd51\uda92\udce6\udb3c\uddad\udaeb\udcfd\udbc7\uddab", "\u0ff6\u4efd\u57fa\u7616", "\uda98\udc06\udb54\udd99\ud85b\udf6a\udb3c\ude84\ud80e\udfaa\ud9ba\udd5f\uda76\udca9\ud9a8\ude17\udbe0\udea1\udb0b\udebf\ud983\udff0\u4651\ud9a8\udfdf\udaa0\udd38\udad6\udff1\ud84f\uded9\udbf0\udffd\ud9c6\udd14\ud925\udf7b\uda92\udf39\ud9e3\udc37\ud8b6\udfbf\ud81a\ude44\ud9da\udc17\ud97d\udd99",
        14, 6225, -1273185985, -7666405080710743719L, -22717L, false, true, (char) 2316, (char) 2269,
        Double.longBitsToDouble(0x3fed0e0642fd9a2dL), Double.longBitsToDouble(0x3fd926745c69449cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud87d\udea8\ud8b3\uded6\udb5c\udc0e", "\u4bea\ua994\u23c4\ub9ce\ucbb1\ub1b0\ub7bf\u13da\ua7fe", "\ud833\ude12\udbf9\udf2d\ud882\uddcd\udaeb\udcfd\udbc7\uddab",
        23, 27455, 1688049846, 8680829247350695862L, -43215L, true, false, (char) 9608, (char) 27101,
        Double.longBitsToDouble(0x3fec0598007c9764L), Double.longBitsToDouble(0x3fe976893e3e4259L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 7, "\ud80f\udc0a\ud863\udd3f", "\u3112\u4bea\u28da\u23c4\ub9ce\u68bb\u05f0\u61fe\u13da\ua7fe\u2027\u6717\u6aea\u9eb6\uad21\u7930\u6c58\u4528\u2d0f\u0ff6\u4efd\ub032\u57fc\u17f5\u7d8f", "\udac8\udfdd",
        30, 55078, -1995636593, 3585249837774535075L, 12736L, true, true, (char) 42601, (char) 8111,
        Double.longBitsToDouble(0x3fe5aa3b94c323bcL), Double.longBitsToDouble(0x3fcd7e5e031afb7cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 4, 7, 7, "\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud962\udfe4\ud93e\udd12\ud95f\udf08", "\ub9ce\u68bb\u68f0\u61fe\u13da\ud228\u0e37\u4208\u2cc8\u4675", "\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e\uda97\udd34\udaa2\udc3b\uda92\udc7d\ud930\ude21\ud8e1\ude99\ud85b\udf6a\udb3c\ude84\ud80e\udfaa\ud9ba\udd5f\uda76\udca9\ud9a8\ude17\udbe0\udea1",
        -3, 67462, 1691465824, -6952113553812447588L, -83947L, true, false, (char) 49115, (char) 40869,
        Double.longBitsToDouble(0x3fc26e3a93d28970L), Double.longBitsToDouble(0x3fed1958345d99ccL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 7, "\ud860\ude39\ud9d4\udc59\udb50\udd09\udb37\udf75\ud9fb\udc33\ud901\udf72", "\uc4da\u3dfe\uc4ad\u61fe\ub004\ua638\u7f2f\u4160\ucecb\u46b7", "\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e\ud946\udcdc\ud82a\udc64\udba8\udfbd\ud8c5\udf05\ud8e1\ude99\ud85b\udf6a\uda63\ude77\ud82c\udc9c\udaff\udf21\uda76\udce5\ud9a8\ude17\udbcc\udfe1",
        53, 67359, 1691465824, -6952113553812447588L, -69228L, false, false, (char) 13067, (char) 40869,
        Double.longBitsToDouble(0x3fc26e3a8e1e8970L), Double.longBitsToDouble(0x3fe881b8395b334fL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 4, 3, "\udb6c\udd54\udbd4\udd59\udb50\udd09\ud82e\ude2b\u6c28\uc991\udbf2\udd1b\ud8c0\udf36\uda20\udddb\ud914\uddca\uda65\udc29", "\u0649\u7c88\u424c\u336b", "\uda63\udc1a\udbf2\udf00",
        -5, 56527, 906533046, 8650033614578837430L, -43271L, true, true, (char) 7156, (char) 48319,
        Double.longBitsToDouble(0x3fd6c8561a79bbe0L), Double.longBitsToDouble(0x3fa768f5839c44f0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 7, 3, 7, "\udbe6\udc2c\udbd4\udd59\udb50\udd09\ud962\udfe4\ud93e\udd12\udaf4\udd32", "\u0973\u7751\u68f0\u61fe\u13da\ua7fe\u2027\u4160\u2cc8\u46b7", "\udbc7\uddab\udad0\udc91\ud83d\udddc\ud8c3\udff1\ud9d5\udf4e\udb4c\udd5e\uda97\udd34\udaa2\udc3b\uda92\udc7d\ud930\ude21\ud9f9\udde4\udbf8\udf02\udb79\udcd8\ud80e\udfaa\ud9ba\udd5f\uda76\udca9\ud9a8\ude17\udbe0\udeda",
        -3, 67462, 1691465824, -2844830693681928429L, -83947L, true, false, (char) 49115, (char) 40869,
        Double.longBitsToDouble(0x3fc26e3a93d28970L), Double.longBitsToDouble(0x3fe247d49cd1cd5fL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 7, "\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud962\udfe4\ud93e\udd12\u00bb", "", "\udb85\udff9",
        10, -513, -668694724, -4947123350792044544L, -100000L, true, false, (char) 58444, (char) 23292,
        Double.longBitsToDouble(0x3e18e00000000000L), Double.longBitsToDouble(0x3fc6c00000d59274L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 6, 7, "\udbe4\udd9e\udbd4\udd59\udb50\udd09\ud962\udfe4\ud93e\udd12\udaf4\udc82", "\ub9ce\u68bb\u68f0\u61fe\ud2ab\ua854\u16a7\u4160\u2cc8\u46b7", "\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e\uda97\udd34\udaa2\udc3b\uda92\udc7d\ud930\ude21\ud8e1\ude99\ud85b\udf6a\udb3c\ude84\ud80e\udfaa\ud9ba\udd5f\uda76\udca9\ud9a8\ude17\udbe0\udea1",
        -3, 67462, 1691465824, -6952113552613597540L, -83947L, true, false, (char) 49115, (char) 40869,
        Double.longBitsToDouble(0x3fc26e3a93d28970L), Double.longBitsToDouble(0x3fe2436a3cd1cd5fL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 3, 6, 7, "\udbe6\udc2d\udbd4\udd59\ud3dd\ud962\udfe4\ud93e\udd12\udaf4\udd32", "\ud195\u68bb\u68f0\u61fe\u13da\ua7fe\u2027\u4160\u2cc8\u46b7", "\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udafb\ude15\uda97\udc88\udaa2\udc3b\uda92\udc7d\ud930\ude21\ud8e1\ude99\ud85b\udf6a\udb3c\ude84\udac9\udda7\ud9dd\udebf\udb22\udf60\ud9a8\udd8d\udbe0\udea1",
        -3, 67462, 1691465824, -6952113553812447588L, -83947L, true, false, (char) 49115, (char) 40869,
        Double.longBitsToDouble(0x3fc26e3a93d28970L), Double.longBitsToDouble(0x3fe2436a3cd1cd5fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udbe6\udc2d\udbd4\udd59\udb50\udd09\ud962\udfe4\ud8de\udc22\udba4\udedc]] |a1=[Ljava.lang.String;:[[\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud962\udfe4\ud8de\udc22\udba4\udedc]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 1, 5, 7, "\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud962\udfe4\ud8de\udc22\udba4\udedc", "\ub9ce\u68bb\u68f0\u61fe\u13da\ua7fe\uc397\u4160\u2cc8\u02b7", "\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e\uda97\udd34\udaa2\udc3b\uda92\udc7d\ud930\ude21\ud8e1\ude99\ud8a3\uddfa\udb3c\ude84\ud80e\udfaa\uda45\udf63\ud92a\udc93\ud96d\udf58\udbe0\udf12",
        -3, 67462, 1691465824, -6952113551899345606L, 36629L, true, true, (char) 60129, (char) 40869,
        Double.longBitsToDouble(0x3fc26e3a93d28970L), Double.longBitsToDouble(0x3fe2436a3cd17c5fL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 7, "\ud9d7\udcc2\udbd4\uddc9\udb50\udd09\ud962\udfe4\ud93e\udd12\udaf4\udd32\udbd3\ude2c\ud89a\ude28\uda3a\udedb\ud914\uddca\udb0c\udc20\udb76\udda9\uda8a\udea5\udaaf\udce2\ud8bb\udd7a", "\u463b\u3809\ub8a6\u237b\u8cd6\u2c73\u0ff6\u4efd\u66b6\u5e63\uc3bb\u6d3b\u4dab\u5f84\u72d3\uc69e\u187b\u3b67\u58b3\ucac8\ub0f4\u38d3\u5c07\ud4d2\u9f35\ud241\u2189\u790f\ub1c5\u353e\u349b\uad97\u4679\u5247\u69b0\u1e49\ud40e\ubb8e\ub1d9\u96e2\u1b9e\u05c8\u73a4\u7bdd\uc8ac\u03a7\u0f71\ud070\u89c6\u5197\u555f\uc52d\uaa63\u03a5\ub5fe\u7237\u8c82\u26c7", "\ud9e9\udff3\udb01\udd9f\ud9c5\udf15\udb6f\ude2c\udbcd\udc54\uda02\ude71\ud83f\udce8\uda26\ude4b\ud83d\udd06\ud925\udce2\uda42\udc38\udb1c\udced\udbd3\udd29\udb06\ude07",
        -4, 50820, 1610401945, -3169470688115832158L, -4254L, true, true, (char) 47537, (char) 4818,
        Double.longBitsToDouble(0x3feffeff9e322ba4L), Double.longBitsToDouble(0x3fe175f414b03560L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 6, "\000\000\000\ud80d\udfec", "\u8347\ua835\ub569\u3869\u00ed\u611d\u13da<\000\000\000\000\000\000\ua598\u4528\ub7b5\ua970\000\u1a38\u0dea\uc2c8", "\u00d6",
        1, 62012, -2055340032, 68719476736L, 48960L, true, true, (char) 36997, (char) 47103,
        Double.longBitsToDouble(0x3f1ed1d393e00000L), Double.longBitsToDouble(0x3fcb705a86e51dc8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 3, 6, 6, "\ud9de\udeeb\ud895\udd30\udb35\udd3b\ud80c\ude6d", "\u28da\ua835\ub569\u8afa\u68f0\u279f\uc100\ub54c\u7846\u33e0\u29f7\u8e88\u903b\u591d\u6c95\u7360\ub7b5\u0ff6\u6593\u1a38\u0dea\uc2c8", "\ud91e\udee4\udb13\uddb0",
        36, 71580, -1995636720, -3412787302408996126L, -64649L, false, true, (char) 54354, (char) 16526,
        Double.longBitsToDouble(0x3fe4e4fc2c6534d4L), Double.longBitsToDouble(0x3fdb947729864778L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 7, 3, 6, "\udbe6\udc2d\udbd4\uddce\udb50\udd09\ud80e\udc1b", "\ua622\ua7fd\ub569\u8afa\u68f0\u61fe\u13da\u7b65\u5680\u850a\uc5ff\u8e88\u903b\u591d\u6c95\u4528\ub7b5\u0ff6\u6593\u1a38\u0dea\uc2c8", "\ud904\udea0\ud85b\udf6a",
        27, 71580, -1995636720, -3412787302408996126L, -64649L, false, true, (char) 54354, (char) 16526,
        Double.longBitsToDouble(0x3fe4e4fc2cdb82d4L), Double.longBitsToDouble(0x3fdb947729864778L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 6, "\udaad\udd4f\udbb0\udf6a\ud8e2\udf94\udb84\udc88", "\ud31b\ud4c9\ub766\u8afa\u68f0\ua0ce\u1346\ua22e\u5680\u850a\ua52b\u8e88", "\udbc5\udfcb\ud895\udfb3\uafdd",
        36, 86293, 472447192, 6616293361020266997L, -31221L, false, true, (char) 56852, (char) 7213,
        Double.longBitsToDouble(0x3fc28003c04215f8L), Double.longBitsToDouble(0x3f81121ab8b428c0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 6, "\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud80e\udc1b", "\u28da\u74a7\u275d\u8afa\u68f0\u61fe\u8fb3\u7b65\u5680\u850a\uc5ff\u8e88\u903b\u591d\u6c95\u4528\ub7b5\u0ff6\ub19c\u1968\u0dea\uc2c8", "\ud904\udea0\ud85b\udf6a",
        27, 82516, -1995636650, -3427560340639794462L, -64520L, false, true, (char) 54354, (char) 16526,
        Double.longBitsToDouble(0x3fe4e4fc2cdb82d4L), Double.longBitsToDouble(0x3fdb947729864778L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 1, 6, 7, "", "\u2537\uc2e7\uc3e9", "\000",
        -5, 65760, 920301549, 4627604614290781143L, -100000L, false, false, (char) 0, (char) 25338,
        Double.longBitsToDouble(0x3fee3b0978005c34L), Double.longBitsToDouble(0x3faab24efb678780L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udad1\udeaf\ud866\udff3\udb06\ude7c\ud8f4\udc97\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\ud86a\udf2b\ud914\uddca\udbf3\udcc0\ud87c\udd8d\ud865\udfe0\ud8b5\ude6f\uda06\udc4a\udafd\ude44\ud8bc\uddae\ud8b2\udf2c\udb3c\uddad\udafe\ude47\udba0\udf17\uda6f\udd6c\udb5c\uddc4\udbc3\udea3\uda6a\udd1a\ud980\udc03]] |a1=[Ljava.lang.String;:[[\udad1\udeaf\ud866\udff3\udb06\ude7c\ud8f4\udc97\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\ud86a\udf2b\ud914\uddca\udbf3\udcc0\ud87c\udd8d\ud865\udfe0\ud8b5\ude6f\uda06\udc4a\udafd\ude44\ud8bc\uddae\ud8b2\udf2c\udb3c\uddad\udafe\ude47\udba0\udf17\uda6f\udd6c\udb5c\uddc4\udbc3\udea3\uda6a\udd1a\ud980\udc03]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 6, 7, "\udad1\udeaf\ud866\udff3\udb06\ude7c\ud8f4\udc97\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\ud86a\udf2b\ud914\uddca\udbf3\udcc0\ud87c\udd8d\ud865\udfe0\ud8b5\ude6f\uda06\udc4a\udafd\ude44\ud8bc\uddae\ud8b2\udf2c\udb3c\uddad\udafe\ude47\udba0\udf17\uda6f\udd6c\udb5c\uddc4\udbc3\udea3\uda6a\udd1a\ud980\udc03", "\u3ace\u4d99\uac48", "\ud80e\udfaa\ud9ba\udd5f\uda76\udca9\ud9a8\ude17\udbd3\udea1\udb0b\udebf\ud983\udff0",
        4, 60927, -2100031121, -5372058939263502571L, -86923L, false, false, (char) 61031, (char) 40784,
        Double.longBitsToDouble(0x3fe2436a3cd1cd5fL), Double.longBitsToDouble(0x3f821a2bcef54840L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud84c\udfbc\ud910\udec5\ud882\udc7d\ud808\uddb0\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\uda3a\udedb\udbef\udc74\uda26\udf76\udb76\uddac\uda8a\udea5\ud9ad\udc41\uda06\udc4a\ud84a\udd44\ud806\udd51\uda92\udce6\udb3c\uddad\udafe\ude47\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e]] |a1=[Ljava.lang.String;:[[\ud84c\udfbc\ud910\udec5\ud882\udc7d\ud808\uddb0\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\uda3a\udedb\udbef\udc74\uda26\udf76\udb76\uddac\uda8a\udea5\ud9ad\udc41\uda06\udc4a\ud84a\udd44\ud806\udd51\uda92\udce6\udb3c\uddad\udafe\ude47\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 1, 6, 7, "\ud84c\udfbc\ud910\udec5\ud882\udc7d\ud808\uddb0\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\uda3a\udedb\udbef\udc74\uda26\udf76\udb76\uddac\uda8a\udea5\ud9ad\udc41\uda06\udc4a\ud84a\udd44\ud806\udd51\uda92\udce6\udb3c\uddad\udafe\ude47\udbc7\uddab\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e", "\u3af9\u4d34\uac48\u790d\u3d43\u91f4\ucd4e\u2df7\ud018\ub0f4", "\udaf2\udca1\udbd3\udcef\uda65\udf3b\udb94\udd10\ud848\udcd0\udbf0\udffd\ud9c6\udd14\ud925\udf7b\ud915\udf0e\udaa2\udf64\ud8b6\udf4c\ud97d\udd96\ud8d4\udd82\ud9da\udea7\ud899\udccc\ud933\udeab\ud9fc\ude0c\udaa8\udcd3\ud95d\udf5b\ud9fc\udfca\udb8c\udd03\udae3\udce8\ud967\udf5b\ud9d1\udd41\udbb9\udfb6\ud87e\ude1a\udac1\udf25\ud814\udd66\uda52\udc73\ud951\udd4b\ud8c7\udf62\ud94a\ude1b\ud857\udc03\uda6a\udf6a\udba9\ude2d\ud84f\udcb3\uda15\udfdf\ud817\udd72\ud89a\ude9b\udb8e\udc00\uda26\udf67\ud987\ude66\ud84b\udc3c\ud9ab\udcb0\udae6\udea4\ud911\udd1a",
        22, 94095, -1160536948, -5022891026304381179L, -86696L, true, false, (char) 58103, (char) 28239,
        Double.longBitsToDouble(0x3fe3d9b3fba1f709L), Double.longBitsToDouble(0x3fe047989b0c880eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udb8b\ude16\ud86a\udd90\udbd7\udf31\udaf1\ude3f\uda27\udf85\udba2\udc42\udbd3\ude35\ud89a\ude28\uda3a\udedb\ud914\uddca\ud9f7\udef1\udb42\udc0a\udb80\udc47\udaf1\udc46\uda06\udc4a\udb49\udf2a\ud806\udd51\ud83a\udc5b\udb7d\udc0e\uda2d\udfaa\udbbe\udf7a\ud895\udfb3\ud801\udd36\u7da4\ud9d5\udf4e\udb4c\udd5e]] |a1=[Ljava.lang.String;:[[\udb8b\ude16\ud86a\udd90\udbd7\udf31\udaf1\ude3f\uda27\udf85\udba2\udc42\udbd3\ude35\ud89a\ude28\uda3a\udedb\ud914\uddca\ud9f7\udef1\udb42\udc0a\udb80\udc47\udaf1\udc46\uda06\udc4a\udb49\udf2a\ud806\udd51\ud83a\udc5b\udb7d\udc0e\uda2d\udfaa\udbbe\udf7a\ud895\udfb3\ud801\udd36\u7da4\ud9d5\udf4e\udb4c\udd5e]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 5, "\udb8b\ude16\ud86a\udd90\udbd7\udf31\udaf1\ude3f\uda27\udf85\udba2\udc42\udbd3\ude35\ud89a\ude28\uda3a\udedb\ud914\uddca\ud9f7\udef1\udb42\udc0a\udb80\udc47\udaf1\udc46\uda06\udc4a\udb49\udf2a\ud806\udd51\ud83a\udc5b\udb7d\udc0e\uda2d\udfaa\udbbe\udf7a\ud895\udfb3\ud801\udd36\u7da4\ud9d5\udf4e\udb4c\udd5e", "\u3ace\u4d99\uac48\u790d\uc69e\u187b\ucef5\u58b3\u6ea3", "\ud965\ude40\u62bd\ud9a8\udfdf",
        55, 25771, 599547576, 5183903492273589483L, -68109L, false, false, (char) 9103, (char) 37424,
        Double.longBitsToDouble(0x3fd090d158c7aa42L), Double.longBitsToDouble(0x3fe6900b3a85087aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 7, "\udbe6\udc2d\udbd4\udd59\ud857\udc8d\ud962\udfda\ud93e\udd12\udaf4\udd32\udbd3\ude2c\ud89a\ude28\uda3a\udedb\ud914\uddca\ud8fe\udd56\udb76\udda9\ud97e\ude18\udb9e\ude16\ud962\udfd8\udb54\udeb5\ud806\udd51\uda92\udce6\udb3c\uddad\udaeb\udcfd\udbc7\uddab", "\u0ff6\u4efd\u57fa\u7616", "\uda98\udc06\udb54\udd99\ud85b\udf6a\udb3c\ude84\ud80e\udfaa\ud857\udc53\uda6e\udc91\ud9a8\ude17\udbe0\udea1\udb0b\udebf\ud96c\udd87\u4651\ud9a8\udfdf\udaa0\udd38\udad6\udff1\ud84f\uded9\udbf0\udffd\ud9c6\udd14\ud925\udf7b\uda92\udf39\ud9e3\udc37\ud8b6\udfbf\ud81a\ude44\uda1a\udc37\ud97d\udd5a",
        14, 6225, -1273185985, -7666405080710743719L, -14202L, true, false, (char) 59606, (char) 22658,
        Double.longBitsToDouble(0x3fe6cdd2914a890aL), Double.longBitsToDouble(0x3fd6e71e9bbd7830L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 7, "\000", "\u06b1\u00bf\000\000\u235e\ub9ce\u3107\u6803\u61fe\u66fa\ucd74\u3734\uae21\u2cc8\u46b7\uac98\000\u6b99\u4528\u3005\000\000\000\u7569\u95da", "\ud8ae\udd57",
        44, 70156, -1000777938, -8571194094074634821L, -46389L, true, false, (char) 46847, (char) 49004,
        Double.longBitsToDouble(0x3fd8f64d11393f0aL), Double.longBitsToDouble(0x3fcb705452f9e000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 7, "\udbe8\udd62\udbd4\udd59\udb50\udd09\ud94b\ude16\uda38\udebc\udbd0\udeb1\ud80a\udd3d\ud89a\ude96", "\u7b4e\u1478\u66fa\ucd74\ud77f\ubd6d\u683d\ub081\u4730\u3202\uce65\ub6b0\ud42c\u1701\u87b1\ubbcf\u2320\ucb91\u0657\ud6f3", "\ud869\udfdb\ud808\ude86\ud9e2\udc5f\uda84\udc95\udbcb\ude0e\uda55\udd7d\ud95a\uddc2\ud9f5\udd49\udb5b\udf14\ud804\udc8b\uda57\udc17\udad6\udff1",
        27, 75469, -1092629269, 6533336324460958828L, 61105L, true, false, (char) 15007, (char) 39669,
        Double.longBitsToDouble(0x3fea797cf661d0e1L), Double.longBitsToDouble(0x3fee7355ff88e727L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 2, "", "\u3633", "\000\000\uda9a\udc0c\uda3a\udedb\ud948\udd24\uda3f\ude11\ud90f\udf9c\uda8a\udea5\u8700",
        56, 24159, 528346167, 7675445377116799103L, -59300L, false, false, (char) 57543, (char) 62697,
        Double.longBitsToDouble(0x3faab24efb678000L), Double.longBitsToDouble(0x3fee10e1400000d1L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 7, 0, "", "\u3633", "\udaef\ude77\ud87b\udf56\ud89a\ude28\uda3a\udedb\ud948\udd24\uda3f\ude11\ud90f\udf9c\uda8a\udea5\udaaf\udca6",
        21, 24159, 528346167, 7675445377116834431L, 55908L, true, false, (char) 32711, (char) 23786,
        Double.longBitsToDouble(0x3e4ed9e000000000L), Double.longBitsToDouble(0x3fee10e1422f90d1L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud87d\udea8\ud8b3\uded6\udb5c\udc0e", "\u4bea\ua994\u23c4\ub9ce\ucbb1\ub1b0\ub7bf\u13da\ua7fe", "\ud833\ude12\udbf9\udf2d\ud882\uddcd\udaeb\udcfd\udbc7\uddab",
        23, 27455, 1688049846, 8680829247350695862L, -43215L, true, false, (char) 2014, (char) 5867,
        Double.longBitsToDouble(0x3fec0598007c9764L), Double.longBitsToDouble(0x3fe976893e3e4259L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 7, "\udbe6\udc21\"", "", "",
        -5, -1000, 0, 1467610528583647469L, -99785L, false, true, (char) 55216, (char) 46240,
        Double.longBitsToDouble(0x3ecfa00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 2, 1, "\ud860\ude39\ud9d4\udc59\ud9d8\udccd\ud985\udf47\ud976\udecb\udb3e\ude33\udbbb\uddb4\ud9e9\udd73\ud895\ude4a\ud85c\udd43\udb94\ude14\udb76\udda9\uda00\udf40\ud853\udea5\u52bc\ud8ae\udc3c\ud934\udfef\udbd6\udf3a\udb3c\uddad\udaeb\udcfd\udbc7\uddab\udbbf\uddbf\u40cb\ud85c\udc8c\ud9d5\udfa8\udb4c\udd5e", "\u6925", "\ud85b\udf6a\uda63\ude77\ud82c\udc9c",
        54, 91087, 129497507, 8818824509129263817L, 12736L, true, true, (char) 15905, (char) 8111,
        Double.longBitsToDouble(0x3faa23b906c7dbc0L), Double.longBitsToDouble(0x3fd7e258d18d7dbeL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udb6c\udd54\udbd4\udd59\udb50\udd09\ud82e\ude2b\u6c28\uc991\udbf2\udd1b\ud8c0\udf36\uda20\udddb\ud914\uddca\uda65\udc29]] |a1=[Ljava.lang.String;:[[\udb6c\udd54\udbd4\udd59\udb50\udd09\ud82e\ude2b\u6c28\uc991\udbf2\udd1b\ud8c0\udf36\uda20\udddb\ud914\uddca\uda65\udc29]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 4, 3, "\udb6c\udd54\udbd4\udd59\udb50\udd09\ud82e\ude2b\u6c28\uc991\udbf2\udd1b\ud8c0\udf36\uda20\udddb\ud914\uddca\uda65\udc29", "\u0649\u7c88\u424c\u336b", "\uda63\udc1a\udbf2\udf00",
        -5, 56527, 906533046, 8650033614578837430L, -43271L, true, true, (char) 7161, (char) 48319,
        Double.longBitsToDouble(0x3fd6c8561a79bbe0L), Double.longBitsToDouble(0x3fa768f5839c44f0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udb6c\udd54\udbd4\udd59\udb50\udd09\ud82e\ude2b\u6c28\udac0\uddd8\udbd9\udf84\ud816\ude8f\ud84c\udc31]] |a1=[Ljava.lang.String;:[[\udb6c\udd54\udbd4\udd59\udb50\udd09\ud82e\ude2b\u6c28\udac0\uddd8\udbd9\udf84\ud816\ude8f\ud84c\udc31]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 2, 2, "\udb6c\udd54\udbd4\udd59\udb50\udd09\ud82e\ude2b\u6c28\udac0\uddd8\udbd9\udf84\ud816\ude8f\ud84c\udc31", "\u757a", "\udb60\ude6c\ud8f0\ude0e\udba3\udd84\ud8d7\udc65\udb40\ude41\u8319\uda97\udec5\ud845\udccb\udac2\udf17\ud886\udfe5\ub6d1\ud904\udfba\ud83e\udfff\udadd\udc4f\ud9ba\ude80\ud958\ude25\ud825\udd24\ud85b\udf6a\udb3c\ude84\udaa0\udea8\ud8fc\udd28\ud944\udd92\ud89a\ude4b\ud896\ude60\uda6e\udcbb\ud8a2\udc6b\ud91d\udd49",
        26, 43622, 651086678, 4472343418387862012L, 24893L, true, true, (char) 45305, (char) 46837,
        Double.longBitsToDouble(0x3fecc87facd96d9fL), Double.longBitsToDouble(0x3fb5e1df5a50c9c8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 0, 4, 3, "", "", "\u5aa6",
        -5, 68560, 116, 1979894986524504215L, -100000L, false, false, (char) 34559, (char) 23142,
        Double.longBitsToDouble(0x3fd43008c00001beL), Double.longBitsToDouble(0x3f3fec4000000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udad1\udeaf\ud866\udff3\udb06\ude7c\ud8f4\udc97\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\ud86a\udf2b\ud914\uddca\udbf3\udcc0\ud87c\udd8d\ud865\udfe0\ud8b5\ude6f\uda06\udc4a\udafd\ude44\ud8bc\uddae\ud8b2\udf2c\udb3c\uddad\udafe\ude47\udba0\udf17\uda6f\udd6c\udb5c\uddc4\udbc3\udea3\uda6a\udd1a\ud980\udc03]] |a1=[Ljava.lang.String;:[[\udad1\udeaf\ud866\udff3\udb06\ude7c\ud8f4\udc97\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\ud86a\udf2b\ud914\uddca\udbf3\udcc0\ud87c\udd8d\ud865\udfe0\ud8b5\ude6f\uda06\udc4a\udafd\ude44\ud8bc\uddae\ud8b2\udf2c\udb3c\uddad\udafe\ude47\udba0\udf17\uda6f\udd6c\udb5c\uddc4\udbc3\udea3\uda6a\udd1a\ud980\udc03]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \udad1\udeaf\ud866\udff3\udb06\ude7c\ud8f4\udc97\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\ud86a\udf2b\ud914\uddca\udbf3\udcc0\ud87c\udd8d\ud865\udfe0\ud8b5\ude6f\uda06\udc4a\udafd\ude44\ud8bc\uddae\ud8b2\udf2c\udb3c\uddad\udafe\ude47\udba0\udf17\uda6f\udd6c\udb5c\uddc4\udbc3\udea3\uda6a\udd1a\ud980\udc03]] |a1=[Ljava.lang.String;:[[\udad1\udeaf\ud866\udff3\udb06\ude7c\ud8f4\udc97\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\ud86a\udf2b\ud914\uddca\udbf3\udcc0\ud87c\udd8d\ud865\udfe0\ud8b5\ude6f\uda06\udc4a\udafd\ude44\ud8bc\uddae\ud8b2\udf2c\udb3c\uddad\udafe\ude47\udba0\udf17\uda6f\udd6c\udb5c\uddc4\udbc3\udea3\uda6a\udd1a\ud980\udc03]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 6, "\udad1\udeaf\ud866\udff3\udb06\ude7c\ud8f4\udc97\ud92c\udfea\udba2\udcf9\udbd3\ude35\ud89a\ude28\ud86a\udf2b\ud914\uddca\udbf3\udcc0\ud87c\udd8d\ud865\udfe0\ud8b5\ude6f\uda06\udc4a\udafd\ude44\ud8bc\uddae\ud8b2\udf2c\udb3c\uddad\udafe\ude47\udba0\udf17\uda6f\udd6c\udb5c\uddc4\udbc3\udea3\uda6a\udd1a\ud980\udc03", "\u93d8\u7fb1\u4dc7\u87ad\uc69e\u187b", "\ud9a8\ude17\udbd3\udea1\udb0b\udebf",
        2, 17824, 897917327, -9019564986527998757L, -42746L, true, false, (char) 6347, (char) 60872,
        Double.longBitsToDouble(0x3fce944b8189b51cL), Double.longBitsToDouble(0x3fd5304828121b5aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udb8b\ude16\ud86a\udd90\uda95\uddb9\uda66\udded\ud87f\udd2a\udbb3\udca9\udbd3\ude35\ud89a\ude28\uda3a\udedb\ud945\udd43\ud9f7\udef1\udb42\udc0a\udb67\udeb9\udaf1\udc46\uda06\udc4a\udb49\udf2a\ud806\udd51\ud83a\udc5b\udb7d\udc0e\uda2d\udfaa\udbbe\udf7a\ud895\udfb3\ud801\udd36\u7da4\ud9d5\udf4e\udb4c\udd5e]] |a1=[Ljava.lang.String;:[[\udb8b\ude16\ud86a\udd90\uda95\uddb9\uda66\udded\ud87f\udd2a\udbb3\udca9\udbd3\ude35\ud89a\ude28\uda3a\udedb\ud945\udd43\ud9f7\udef1\udb42\udc0a\udb67\udeb9\udaf1\udc46\uda06\udc4a\udb49\udf2a\ud806\udd51\ud83a\udc5b\udb7d\udc0e\uda2d\udfaa\udbbe\udf7a\ud895\udfb3\ud801\udd36\u7da4\ud9d5\udf4e\udb4c\udd5e]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 2, 5, "\udb8b\ude16\ud86a\udd90\uda95\uddb9\uda66\udded\ud87f\udd2a\udbb3\udca9\udbd3\ude35\ud89a\ude28\uda3a\udedb\ud945\udd43\ud9f7\udef1\udb42\udc0a\udb67\udeb9\udaf1\udc46\uda06\udc4a\udb49\udf2a\ud806\udd51\ud83a\udc5b\udb7d\udc0e\uda2d\udfaa\udbbe\udf7a\ud895\udfb3\ud801\udd36\u7da4\ud9d5\udf4e\udb4c\udd5e", "\u3ace\u693c\uac48\u790d\u0d55\u187b\ucef5\u91cd\u63da", "\ud965\ude40\ud94b\udeb7\ud95e\udcb1",
        55, 25771, 599547576, 5183903492273589483L, -68109L, false, false, (char) 9103, (char) 37424,
        Double.longBitsToDouble(0x3fd090d158c7aa42L), Double.longBitsToDouble(0x3fe6900b3a85087aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udb8b\ude16\ud86a\udd90\udbd7\udf31\udaf1\ude3f\uda27\udf85\udba2\udc42\udbd3\ude35\u24c0\uda3a\udea5\ud914\uddca\ud9f7\udef1\udb42\udc0a\udaaa\udfdd\udaf1\udc46\uda06\udc4a\udb49\udf2a\ud806\udd51\ud83a\udc5b\udb7d\udc0e\uda2d\udfaa\udbbe\udf7a\ud895\udfb3\ud801\udd36\u7da4\ud9d5\udf4e\udb4c\udd5e", "\u3ace\u4d99\uac48\u790d\uc69e\u187b\ucef5\u58b3\u0205\ub0ea\uc491", "\ud9a8\udfdf\uda65\udf3b\uda0b\udded\ud850\udcd3\ud938\udd00\ud9c6\udd14\ud925\udf7b\ud915\udf0e\udaa2\udf64\ud8b6\udf4c\ud97d\udd96",
        31, 19123, 142260946, -4984109825148868212L, -39575L, true, false, (char) 43377, (char) 62636,
        Double.longBitsToDouble(0x3febd7af682887cfL), Double.longBitsToDouble(0x3fd4f1882cfae430L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udb8b\ude16\ud86a\udd90\udbd7\udf31\udad4\ude50\uda47\udedc\ud864\ude1d\uda7f\ude2a\ud89a\uddd9\uda3a\udedb\ud8f9\udd03\ud9f7\udef1\ub962\udace\udf62\ud86f\ude54\uda06\udc4a\uda7e\udc03\ud942\udfb1\ud8e6\ude61\udb7d\udc94\uda2d\udfaa\udbdd\udc4e\udacc\udc2f\udacb\udf39\ua353\ud9bb\udd92\udb4c\udd5e]] |a1=[Ljava.lang.String;:[[\udb8b\ude16\ud86a\udd90\udbd7\udf31\udad4\ude50\uda47\udedc\ud864\ude1d\uda7f\ude2a\ud89a\uddd9\uda3a\udedb\ud8f9\udd03\ud9f7\udef1\ub962\udace\udf62\ud86f\ude54\uda06\udc4a\uda7e\udc03\ud942\udfb1\ud8e6\ude61\udb7d\udc94\uda2d\udfaa\udbdd\udc4e\udacc\udc2f\udacb\udf39\ua353\ud9bb\udd92\udb4c\udd5e]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\udb8b\ude16\ud86a\udd90\udbd7\udf31\udad4\ude50\uda47\udedc\ud864\ude1d\uda7f\ude2a\ud89a\uddd9\uda3a\udedb\ud8f9\udd03\ud9f7\udef1\ub962\udace\udf62\ud86f\ude54\uda06\udc4a\uda7e\udc03\ud942\udfb1\ud8e6\ude61\udb7d\udc94\uda2d\udfaa\udbdd\udc4e\udacc\udc2f\udacb\udf39\ua353\ud9bb\udd92\udb4c\udd5e]] |a1=[Ljava.lang.String;:[[\udb8b\ude16\ud86a\udd90\udbd7\udf31\udad4\ude50\uda47\udedc\ud864\ude1d\uda7f\ude2a\ud89a\uddd9\uda3a\udedb\ud8f9\udd03\ud9f7\udef1\ub962\udace\udf62\ud86f\ude54\uda06\udc4a\uda7e\udc03\ud942\udfb1\ud8e6\ude61\udb7d\udc94\uda2d\udfaa\udbdd\udc4e\udacc\udc2f\udacb\udf39\ua353\ud9bb\udd92\udb4c\udd5e]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 5, "\udb8b\ude16\ud86a\udd90\udbd7\udf31\udad4\ude50\uda47\udedc\ud864\ude1d\uda7f\ude2a\ud89a\uddd9\uda3a\udedb\ud8f9\udd03\ud9f7\udef1\ub962\udace\udf62\ud86f\ude54\uda06\udc4a\uda7e\udc03\ud942\udfb1\ud8e6\ude61\udb7d\udc94\uda2d\udfaa\udbdd\udc4e\udacc\udc2f\udacb\udf39\ua353\ud9bb\udd92\udb4c\udd5e", "\u3ace\u4d99\u1f40\u790d\uc69e\u187b\ucef5\u5390\u52e6\ub0c0\uc491\u92cb\ud449\u9f35\ud241\ua68f\u282f\u34a6\ud041\u8842\ua4b2\ub0b6\u0164\u21dc\u7e20", "\ud9d4\udf97\ud930\udeb2\uaf07\ud8cd\ude11\uda00\uddb7",
        8, 14050, -13105445, -5971528202403532415L, 96563L, false, false, (char) 31482, (char) 26267,
        Double.longBitsToDouble(0x3fd03622ef954f52L), Double.longBitsToDouble(0x3fde0ae899a3c56aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 6, 7, "\udbe6\udc2d\udbd4\udd59\udb50\udd09\ud962\udfe4\ud93e\udd12\udaf4\udd32", "\ub9ce\u68bb\u68f0\u61fe\u13da\ua7fe\u2027\u4160\u2cc8\uc913", "\ud82b\udecd\ud895\udfb3\ud801\udd36\udbc3\udea3\ud9d5\udf4e\udb4c\udd5e\uda97\udd34\udaa2\udc3b\uda92\udc7d\ud930\ude21\ud8f1\udc79\ud85b\udf6a\udb3c\ude84\ud80e\udfaa\ud9ba\udd5f\uda76\udca9\ud9a8\ude17\udbe0\udea1",
        -3, 67462, 1691465824, -6952113553812447588L, -86923L, false, false, (char) 61031, (char) 40784,
        Double.longBitsToDouble(0x3fe2436a3cd1cd5fL), Double.longBitsToDouble(0x3fa5886ba49bf1c0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 4, 3, "\udb6c\udd54\udbd4\udd59\udb50\udd09\ud82e\ude2b\u6c28\uc991\udbf2\udd1b\ud8c0\udf36\uda20\udddb\ud914\uddca\uda65\udc29\uda06\udd38\uda83\udc49\ud97b\udd27\udaf2\udf0d\ud892\udd50\ud990\udf9a\ud912\udf7a\udb40\ude41\uda63\udc1a\udbf2\udf00\ud87e\udc0c\ud81d\udec6\ud886\udfe5\ub6d1\udb4c\udd5e\udaae\udc9f\ud8e2\udf93\uda65\udefc\udb85\udd68\ud825\udd37\ud85b\udf6a\udb3c\ude84\ud9cd\udca9\udb3a\udef9\ud9fe\udf7d\udbf8\udf76\udbf3\udda7\udb8d\udec4\ud812\udc99\ud8a9\udf86\ud80f\udc82\uda89\udd1f\uda39\ude64\udbca\udc7a\ud8b2\udd5d\ud92b\udc31\udb45\udc66\udbf2\udc3e\ud70f\ud99e\ude19\udb62\udf6f\uda1f\udf1c\ud98b\udf7d\ud975\udfd1\ub397\udaed\udd45\ud857\udefa\ud9a8\udd5c\ud96f\udf5a", "\u6c0c\u282a\u2944\u4fef\u295a\u27ee\uc2ca\u2805\u0d06\ubacb\u5d9d\u085f\u146e\u0454\ub91e\u42d2\ud552\u1dc4\u9523\u0231\uaba7\uc299\u74c9\u0211\u68de\u8e88\ucd0c\u4faf\ua6f5\u7a2d\u61fd\u6fa9\u8f54\u6ffc\u2bc8\uc0f0\u52e3\uabeb\u374b\u823f\ub339\u942c\u1717\u986f\u55ff\u6070\u35ab\u3094\ua228\u8638\uad27\u0c24\u2c13\ub43f\u4952\ubd85\uba66\u9d61\u796a\u7988\u73d2\u731a\u28db\u3218\u5635\u3676", "\ud9c7\udee2\uda6a\udf64\udadf\udd55\udbd3\udcf6\ud823\udc93",
        26, 77348, -515445541, -3386536654037935225L, 60658L, true, true, (char) 59583, (char) 12117,
        Double.longBitsToDouble(0x3fdf10198bb3ac60L), Double.longBitsToDouble(0x3fd0ac7d2891d9beL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processSingleHyphen|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
