package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\uabc9\u3c85\u40a1", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d\uda96\udcfa\udb7d\uded3\udab3\udf73\udbed\udf09\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a",
        55, 55462, 2001345009, -3431862544648762700L, -92528L, true, true, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\ua3de\u842e\uba73", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d\uda96\udcfa\udb7d\uded3\udab3\udf73\ud93e\udd5a\ud886\ude49\u28fc\ud8c6\udd82\uda77\udd3e\ud8e8\udf66\ud94c\udd4a",
        55, 55462, 2001345009, 6440027838547373244L, -92528L, true, true, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud832\udf2d\udb8d\ude92\ud845\uddc9\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\udabe\udf7f\ud91b\ude8f\uda44\udf37\ub25d\udb5d\udc0f\ud89d\udf07\ud9b1\udf08\uda27\uddd0\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\u9246\u3c85\u40a1", "\ud857\udfa3\udad8\udc27\u6aca\udbed\udd82\ud89c\ude1e\ud965\udc43\udab3\udf9b\udbed\udf09\ud886\udebf\udaa7\udf10\ud959\udfbf\udb64\udc3f\uda7f\udcd4\udb55\udf6d",
        55, 55462, 2001345009, -3431862545917829452L, 61360L, true, false, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf77b54a95c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb39\udfd2\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\udbac\udfb0\uda09\udca4", "\uabc9\u3c85\u40a1\uc91c\u6473\u7d19\u9367\ub7d4\uc529", "\udab3\udf73\udbed\udf09\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a\ud8d0\uddb3\uda4a\udffd\uda98\udcf8\ud9c8\udc64\ud869\udfa7\ud91c\udce1\ud8eb\udc89\ud9db\udd44\ud96e\udf25\uda77\udc7d\ud840\udfb2",
        47, 59237, 1146545865, -3944789221737409329L, -52942L, false, true, (char) 39974, (char) 57530,
        Double.longBitsToDouble(0x3fe94434dba309efL), Double.longBitsToDouble(0x3fe56033da85dad9L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\udacb\udd8b\000\000\000\014\uda26\udeb2\uda2a\udc26\uda81\udeb3\000", "\uabc9\u3c85\u40a1", "\ud857\udfa3",
        -5, 15709, 604037632, -7825128178938034065L, -52726L, true, true, (char) 31689, (char) 53062,
        Double.longBitsToDouble(0x3fb448d37808c7b8L), Double.longBitsToDouble(0x3fe00a54b0d47ba4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 6, 6, "\ud810\ude2d\ue027\ud8e3\udd7b\ud842\udf10\ud902\udc0d\udb43\udfbf\ud8c2\udc30\ud9d9\udfb0\ud995\ude2a\ud85c\udd84\uda44\uded5\ub25d\udb5d\udc0f\udae1\ude8a\udafc\ude19\udb51\ude8a\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\u544e\u6da6\u40a1", "\ud857\udfa3\udad8\udc27\ud825\udf2f\uda24\ude5d\uda96\udcfa\udb7d\uded3\udab3\udf73\udbed\udf09\uda31\udfac\ud841\udd4e\ud84f\ude89\uda4c\uddc3\ud9fe\udff3\uda51\udf76",
        34, 55462, -823068440, -8298084882136036863L, -92528L, true, true, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud82d\udc0d\ud86a\udca8\ud8e3\udcc5", "\ubdc7", "\ud84b\udeb6\u7e1c\udb74\udf2f\ub25d\udbad\udf17",
        19, 61800, -1024694004, 3298505406116238116L, 63313L, false, true, (char) 39335, (char) 30369,
        Double.longBitsToDouble(0x3fe3b42661fd84ddL), Double.longBitsToDouble(0x3fd9e2e1a9bdae26L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud86a\udccf\ud8e3\udcc5\ud842\udf10\udb0d\udf00\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ud881\ude9d\ud91e\udd81\uda48\udc85", "\u940e\uab7b\ubfa5\u4af2\u47df", "\udb97\udf33",
        30, 24102, 447085790, 3420471647010734612L, -42018L, true, true, (char) 38138, (char) 59131,
        Double.longBitsToDouble(0x3fc54f7037b791b0L), Double.longBitsToDouble(0x3fdc4ca0e1228d6cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\uda99\udfdd\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\udafe\udf20\ud99c\udc63\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\uabc9\u0fc8\u4045", "\ud857\udfa3\udad8\udc27\u6aca\uda99\uddae\ud9bc\udc5e\udb87\ude91\udab3\udf73\udbed\udf09\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a",
        55, 55462, 2001345009, -3431862115152033100L, -92528L, true, false, (char) 25310, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 0, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4\ud857\uddf4\udae7\uddc5\uda69\udcb5\ud919\udf34\uda0b\udcb4\uda3f\udf34\u8e70\udb48\udc1b\udad8\udc27\u6aca\ud879\udc9d", "\u0d33\u39b6\u0e44\uadb4\ubcba\u0d87\ud200\u24ec\u8179\u2ccb\ucf52\u62c0\u0d5c\ucb3a\u5496\u380c\u58d7\u679c\ucc08", "\udad4\uddd6\ud900\udc01",
        23, 2436, 2053936339, 8420624348227465117L, -76349L, false, true, (char) 32100, (char) 56266,
        Double.longBitsToDouble(0x3fe09c0b2d126a08L), Double.longBitsToDouble(0x3fd94d8708c60d0eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 3, 4, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udaeb\ude2c\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\uabc9\u3c85\u40a1", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d\uda96\udcfa\udb7d\uded3\udab3\udf73\udbed\udf09\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud9ba\uddc4",
        15, 15270, 2001340648, -3431862544648762700L, -92528L, true, true, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud894\udfe6\ud93b\udf63\ud9ff\ude19\ud842\udf19\ud902\udc0d\ud92a\udcf1\ud9ca\udf34\udbeb\udda4\ud83d\udfce\u1a2a\udba5\udd28\udaa5\uddf2\ud9ed\udf7e\udae1\ude8a\udbfd\udfe6\ud93f\udd3d\udb4e\udd66\udbf2\udfab\udba3\udd60\uda09\udca4", "\uabc9\u3c85\u6a67", "\ud857\udfa3\udad8\udc27\ud836\udc2f\ud8b4\udd85\ud87a\udedb\uda28\udcaa\udab3\udf73\udbed\udf09\udb70\uddbd\udb3d\udcd5\uda54\udca5\ud817\udf63\ud8e8\udf66\udb8e\udc6b",
        46, 55462, 2001374193, 301831231039736500L, -92528L, true, true, (char) 1523, (char) 27236,
        Double.longBitsToDouble(0x3fcf7f754fb26fccL), Double.longBitsToDouble(0x3fe1d2917ec98af9L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 5, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\uda07\udc98\ud902\udc0d\udb43\udfbf\ud9ca\udf34\ua3f5\uda67\ude51\udbb3\udd18\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4\ud857\uddf4\udae7\uddc5\uda69\udcb5\ud919\udf34\uda0b\udcb4\udbd4\udf5f\u8d9e\ud857\udfa3\ud91c\udd68\udb6e\udda8\ud9f7\ude2e\udaa6\ude8d\udb7d\uded3\udab3\udf73\udbed\udf09\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a\ud8d0\uddb3\uda4a\udffd\uda98\udcf8\ud9c8\udc64\ud869\udfa7\uda6a\udc68\udb1c\uddd1\ud9ea\udde9\ud96e\udf3e\uda77\udc7d\ud840\udfb2\ud993\udc29\uda91\udce5\udb11\udfd5\ud8a6\udd27\ud90b\udd9c", "\u2170\u6ade\ucbc6\u5223\u8a7b\u192b\ubed5\u48bf\u4120\u33e1\u18ba\u6a4d\ua2d5\ucda6\uc5dc\u5885\u01af\u285d\u5e36\u860f\u5190\uce18\ud160\uccb9\ubfe7\u7cec", "\udbcb\udf2a\ud9d3\udef8\u8a28\udb49\udc01\ud821\udc11",
        3, 38219, 1219465600, -7940841980097867085L, -56797L, true, false, (char) 25750, (char) 29818,
        Double.longBitsToDouble(0x3fd7fcc7c3f67728L), Double.longBitsToDouble(0x3fb60a3c59baa218L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb1c\udeeb\ud883\udcc4\u2d0c\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4]] |a1=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb1c\udeeb\ud883\udcc4\u2d0c\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb1c\udeeb\ud883\udcc4\u2d0c\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4]] |a1=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb1c\udeeb\ud883\udcc4\u2d0c\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb1c\udeeb\ud883\udcc4\u2d0c\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\uabc9\u3c37\u40a1", "\udba8\udf2c\uda65\udd76\ud908\ude73\ud86e\udc8d\uda96\udcfa\udb7d\uded3\udab3\udf73\udbde\ude1e\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud986\udd4c",
        55, 55462, 2001383409, -3431862544648762700L, -92528L, true, true, (char) 3659, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\uabc9\u3c85\u40a1", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d\uda96\udcfa\udb7d\uded3\udab3\udf73\udbed\udf09\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a",
        55, 55462, 2001345009, -3431862544648762700L, -92528L, true, true, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb1b\udeb3\ud9ca\udf34\udbeb\udda4\u8f90\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\ud99e\udf2f\uda81\udeb3\uda09\udca4]] |a1=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb1b\udeb3\ud9ca\udf34\udbeb\udda4\u8f90\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\ud99e\udf2f\uda81\udeb3\uda09\udca4]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb1b\udeb3\ud9ca\udf34\udbeb\udda4\u8f90\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\ud99e\udf2f\uda81\udeb3\uda09\udca4", "\u2fef\u257e\u40a1", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d\uda96\udcfa\udb7d\uded3\ud845\udde6\udbed\udf1c\udb0a\udccc\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a",
        55, 67126, 2002071303, -3431862544648762700L, -92528L, true, true, (char) 2123, (char) 27146,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\ud819\udd41\uda19\udf09\uda81\udeb3\ud9a3\uded2", "\uabc9\u3c85\u40a1\uc91c\u6473\u7d19\u9367\ub7d4\uc529\u9eab\u0907\u9a17\u3ffb\uc5fd\u5d8a\u4a68\ua5e8\ub767\u248c\u8179", "\ud9c8\udc64\ud869\udfa7\ud91c\udce1\ud8eb\udc89\ud9db\udd44",
        8, 32599, 1911766267, -8036424237399704851L, 78703L, false, false, (char) 49727, (char) 64056,
        Double.longBitsToDouble(0x3fe12239dfc6c269L), Double.longBitsToDouble(0x3fd4645c3dee5908L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud85d\udc81\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ud823\udfb9\udb5d\udc0f\udae1\ude8a\ud84e\udd2f\udab2\udee8\udbd0\ude8c\uda42\udc66\uda81\udf52\uda09\udca4", "\uabc9\u3c85\u0fbe", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d\uda96\udcfa\udb7d\uded3\udab3\udf73\udbed\udf09\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a\ud8d0\uddb3\udad8\udc78\uda98\udcf8\ud9c8\udc64\ud869\udfa7\uda59\uddc2\uda41\udd33\uda9c\uddb1\ud96e\udf25\u7cd2\u06f1\ud962\ude6a\ud8f5\udc78\ud94b\ude67\udaca\ude9b\ud9ba\udfb2\ud9d0\udfc3\u7199\udb6d\udf02\ud8e0\udcbf\udba5\udd09\udba0\udd1e\ud8da\udc47\ud900\udc9f\ud83d\udf6f\udaac\uddf3\ud932\udcce\ud9d8\ude22\ud864\udd8e\ud966\uddd9\udb43\udf4d",
        52, 80336, 151295552, 1351631688305217700L, 62434L, false, true, (char) 39005, (char) 56844,
        Double.longBitsToDouble(0x3fd0f7644216e896L), Double.longBitsToDouble(0x3fe67cd5f087c7d0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud884\udef5\ud842\ude4f\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\ud8ee\udf12\uda2a\udc0f\uda81\udeb3\uda09\udca4]] |a1=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud884\udef5\ud842\ude4f\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\ud8ee\udf12\uda2a\udc0f\uda81\udeb3\uda09\udca4]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 1, 6, "\ud80e\udebb\ud86a\udca8\ud884\udef5\ud842\ude4f\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\ud8ee\udf12\uda2a\udc0f\uda81\udeb3\uda09\udca4", "\uabc9\u3c85\u40a1", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d\uda96\udcfa\udb7d\uded3\udab3\udf73\udbed\udf09\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a",
        55, 55550, 2001345009, -3431862544648762700L, -92528L, false, true, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c1dc2173L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf]] |a1=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 1, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf", "\ud6f2\uaded\u8fc2\uae81\u9a61", "\uda27\udd72",
        -3, 10460, 220731970, 8193874180468449038L, 3939L, false, true, (char) 54257, (char) 3964,
        Double.longBitsToDouble(0x3fe0a17bb945df5eL), Double.longBitsToDouble(0x3fe3f0ce4c612400L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\udb97\udca6\ud86a\udca8", "\u8d0f\ubdc7\u56d5\ud394", "\uda44\udf37\ub25d",
        -4, 48214, -143458200, -4401027234819300047L, -26514L, false, false, (char) 30369, (char) 41026,
        Double.longBitsToDouble(0x3fdfd84dd33c5c34L), Double.longBitsToDouble(0x3f95d71386542f80L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 0, "\ud80e\udebb\udb88\ude64\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf", "\ud6f2\uaded\u8fc2\u2dac\u9a61", "\ud9dc\udd48",
        -3, 17564, 171978265, 8193875048051842830L, 3939L, false, true, (char) 54257, (char) 3964,
        Double.longBitsToDouble(0x3fe0a17bb945df5eL), Double.longBitsToDouble(0x3fe3f0ce4f612400L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 7, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\uabc9\u3c85\u40a1", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d\uda96\udcfa\udb7d\uded3\udab3\udf73\udbed\udf09\ud886\udebf\udb1e\udee5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a",
        38, 55462, 2001345009, -3431862544648762700L, -92528L, true, true, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 1, "\u74dc\ud86a\udca8\ud8e3\udcc5\ud842\udf10\udafc\udc0a\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\uabc9\u3c85\u40a1", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d\uda96\udcfa\udb7d\ude9a\udac6\udde6\ud830\udd90\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\uda6c\uddfb",
        55, 55462, 2001345009, -3431862544648762700L, -92528L, true, true, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 7, 6, 6, "\ud965\udd19\uda0e\udd31\ud8e3\udcc5\ud842\udf10\ud902\udc0d\uda7d\udd7b\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\udade\uded5\udb01\udf05\ud8b3\udc97\ud929\udf6a\ud870\udd99\ud87b\udebc\udacb\udf58\uda81\udef2\uda09\udca4", "\uabc9\u3c85\u08ed", "\ud857\udfa3\udad8\udc27\u6aca\ud879\udc9d",
        19, 94721, -252379526, -1987010283313396243L, 497L, true, false, (char) 36856, (char) 50786,
        Double.longBitsToDouble(0x3fca8f6c617a1c30L), Double.longBitsToDouble(0x3fe5ba476333774bL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 3, "\ud850\udebc", "\u6e49\u34a0\ubdc7\u56d5\u350f\u72ef\u5ae5\u67c1\u6778\uae59\u18ab\u7e45\u80a8\u0372\u0702\u2a3f\uccb6\u81cd", "\udba7\udfdb",
        13, 96174, 439411422, 3420471645923388600L, -42018L, true, true, (char) 23510, (char) 15609,
        Double.longBitsToDouble(0x3fc54211889339b0L), Double.longBitsToDouble(0x3fdbbca0e123f208L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\udbca\udeb9\uda52\udc9c", "\000", "\udbeb\udda4",
        19, -1000, 0, -503316480L, -34568L, false, true, (char) 26604, (char) 11754,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3fe8738db4967511L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "\000", "\u00df\000\ua1f2\000\uca03\u9f3e\000\000\000\000\000\u7ddd\u80a8\u0372", "\uda09\udca4\ud857\uddf4\udae7\uddc5\000",
        -5, 78816, 1264030, 1920218847344915671L, 79899L, false, false, (char) 45920, (char) 23510,
        Double.longBitsToDouble(0x3fe3d363f85c008cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud985\udeb6\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\ud86c\udd11\ub240\udb39\udfd2\udae1\ude8a\udbfd\udfe6\uda27\udd7f\uda4f\udfe3\uda2a\udc26\udbac\udfb0\uda09\udca4", "\uabc9\u3c85\ub2ff\uc91c\u6473\u7d19\u9367\ub7d4\uc529", "\udab3\udf73\udbed\udf09\ud886\udebf\udb67\udc37\uda49\udcef\udaae\uddc9\ud8e8\udf66\ud980\udca4\ub2d5\udaa2\ude26\uda3a\udce9\udad4\udd91\udbe9\udca8\ud91c\udce1\ud8eb\udc89\ud9db\udd44\ud96e\udf25\uda77\udc7d\ud867\udf47",
        24, 24831, 1146545878, -3944789225109637681L, -57800L, true, false, (char) 54912, (char) 44984,
        Double.longBitsToDouble(0x3feb5781b41c57baL), Double.longBitsToDouble(0x3fea838a8a83baa1L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 0, 6, "\000", "\u6e49\ua9e2\000\u56d5\ud394\ud6f2Z\u2af7\u2dac\u0196\u188c\u7e45\u80a8\u0372\u0702\u5708\uccb6\u33d9\u3fd9\uabc9\u3c85\u40a1\uc91c\u9da2\000\u9367\ub7d4", "\udb7d\uded3",
        57, 54162, -905052160, 5095455445725579409L, -99999L, true, false, (char) 50296, (char) 45930,
        Double.longBitsToDouble(0x3fdf1f99c666ee94L), Double.longBitsToDouble(0x3fe5a682f92dcc3eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 6, 6, "\ud810\ude2d\ue027\ud8e3\udd7b\ud842\udf10\ud902\udc0d\ud9f7\udfb9\ud8c2\udc30\ud97b\udd60\ud995\ude2a\ud85c\udd84\uda44\uded5\uda98\udc1f\udb6e\ude16\udae1\ude8a\udafc\ude19\udb51\ude8a\uda4f\udfe3\udb68\udcc5\uda78\udc2b\uda09\udca4", "\u6c4d\u1026\u8914", "\ud857\udfa3\udad8\udc27\uda38\udc8a\uda22\ude26\uda96\udcfa\udb7d\uded3\ud9e2\udc4b\udbed\ude8a\uda31\udfac\ud841\udd4e\ud886\udf9b\ud8c8\udc46\ud9fe\udff3\uda51\udf76\ud9fe\udca9\udaff\ude81\uda43\udff9\udb80\udd90\ud155\udb59\udee5\udac9\udc5a\udba4\udfcf\udbbe\udef5\uda77\udc7d\ud840\udfb2\ud993\udc29\uda91\udce5\ud8bb\udec9\uda17\udd26\ud9eb\udeda\uda3c\udee9\uda61\udcbe\uda3e\udc4e\uda21\uddfb\ud80a\udcdc\ud94e\udf8a\ud95e\uddb9\ud925\udf45\ud991\ude0a\udb13\udc87\ud9f9\udf58\ud984\uddb9\udb84\udd53\uda7a\udfc6\udaa6\udc33",
        2, 54243, -632782177, -504572093881577965L, 39862L, false, false, (char) 75, (char) 50020,
        Double.longBitsToDouble(0x3fe7d48c609a6c7dL), Double.longBitsToDouble(0x3fdf03c2e9873826L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 0, 0, "", "\ud5e2", "\ua1f2",
        -5, 45960, 1676357703, 5245028056972211067L, -91607L, true, false, (char) 26607, (char) 49385,
        Double.longBitsToDouble(0x3fe0ce6a18000000L), Double.longBitsToDouble(0x3e4259d400000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 0, "\000", "", "",
        28, 89074, 1160972689, 1495712230073985626L, -99862L, false, false, (char) 57856, (char) 104,
        Double.longBitsToDouble(0x3fd0cf773a6385d8L), Double.longBitsToDouble(0x3fe9216e3619cd43L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud900\udc1c\ud89e\udee2\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4\ud857\uddf4\udae7\uddc5\uda69\udcb5\ud919\udf34\uda0b\udcb4\uda3f\udf34\u8e70\udb48\udc1b\udad8\udc27\u6aca\ud879\udc9d]] |a1=[Ljava.lang.String;:[[\ud900\udc1c\ud89e\udee2\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4\ud857\uddf4\udae7\uddc5\uda69\udcb5\ud919\udf34\uda0b\udcb4\uda3f\udf34\u8e70\udb48\udc1b\udad8\udc27\u6aca\ud879\udc9d]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 1, 0, "\ud900\udc1c\ud89e\udee2\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4\ud857\uddf4\udae7\uddc5\uda69\udcb5\ud919\udf34\uda0b\udcb4\uda3f\udf34\u8e70\udb48\udc1b\udad8\udc27\u6aca\ud879\udc9d", "\u0d33\u39b6\u0e44\uadb4\ubcba\u0d87\ud200\u24ec\u8179\u2ccb\ua7d1\u62c0\u0d5c\ucb3a\u5496\u380c\u58d7\u679c\ucc08", "\u2456\uda1d\udcee",
        40, 3220, 2053936331, 7627990813810236386L, -76349L, false, true, (char) 32100, (char) 56266,
        Double.longBitsToDouble(0x3fe09c0b2d126a08L), Double.longBitsToDouble(0x3fd94d8708c60d0eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud82d\udd8a\ud86a\udca8\ud8e3\udd3a\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\ud83d\udc29\udb22\udf18]] |a1=[Ljava.lang.String;:[[\ud82d\udd8a\ud86a\udca8\ud8e3\udd3a\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\ud83d\udc29\udb22\udf18]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud82d\udd8a\ud86a\udca8\ud8e3\udd3a\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\ud83d\udc29\udb22\udf18]] |a1=[Ljava.lang.String;:[[\ud82d\udd8a\ud86a\udca8\ud8e3\udd3a\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\ud83d\udc29\udb22\udf18]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud82d\udd8a\ud86a\udca8\ud8e3\udd3a\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\ud83d\udc29\udb22\udf18", "\u9dac\u9d3f\u48f0\u036b\u80a8\u3e69\ube49\u6417\ubbcd\ua8ed\ua7da\ub9ff\u3c37\u40a1\uc91c\u128c\uc2ad\u81c7\u46b5\ucd0d\u9eab\u0907\u6133\u0310\u95e7\u5d8a\u4a68\u6a10\ub767\u651e\u5453\u0742\u8d12\u62c0\u0d5c\ucbd2\u08da", "\uda77\udc7d\ud840\udfb2\ud993\udc29\uda91\udce5\uda17\uddf6\udab8\ude6e\udb59\udce4\udb6a\udc2d\ud89e\ude2a\u85e9\ud846\udfc4\udb70\udda5\ud84d\udcdf\ud905\udd12\ud847\uddf6\ud9a5\udcff\udbe3\udca7\ud997\udcd5\udbef\ude82\udaf8\udef7\udaf3\udc71\udab8\udfc5\ud98f\udedf\udb9e\uddbd\udb49\udf39\uda41\udd4a\udaaa\udc9b\ud87c\udd80\uda1d\udd1d\uda25\udc34\udb67\ude18\uda91\uddb2\ud914\ude34\ud97a\udcbd\uda52\udfa0\uda2b\udc21\ud9f7\udd68",
        49, 91355, 1806338049, -2436603763938887997L, -42290L, false, false, (char) 46321, (char) 7145,
        Double.longBitsToDouble(0x3fde2b02031b28b2L), Double.longBitsToDouble(0x3febde13c2a165f1L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud837\udfff\ud901\udf79\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\uda80\ude0c\udb1c\udeeb\ud883\udcc4\u2d0c\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4]] |a1=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud837\udfff\ud901\udf79\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\uda80\ude0c\udb1c\udeeb\ud883\udcc4\u2d0c\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 2, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud837\udfff\ud901\udf79\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\uda80\ude0c\udb1c\udeeb\ud883\udcc4\u2d0c\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\uabc9\u3c37\u789c", "\udba8\udf2c\uda65\udd76\ud9b0\udff6\ud86e\udc2b\uda96\udcfa\udb7d\uded3\udab3\udf73\udb26\udcd0\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\udb72\udd42",
        51, 92737, 2001383409, -3431862544648762700L, -92528L, true, true, (char) 3659, (char) 38334,
        Double.longBitsToDouble(0x3fdc37765578e27eL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 0, "\000", "\u4e61\u6408\ua1f2\000\uca03\u9f3e\000\000\000\000\000\u7ddd\u80a8\u0372", "\uda09\udca4\ud857\uddf4\udae7\uddc5\000",
        -5, 78816, -975091298, -3960338297154884615L, 79899L, false, false, (char) 45920, (char) 23510,
        Double.longBitsToDouble(0x3fe3d363f85c008cL), Double.longBitsToDouble(0x3fe0000000000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\ud842\udf10\ud902\udc0d\udb43\udfbf\ud9ca\udf34\udbeb\udda4\ud869\udf92\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\uda4f\udfe3\uda2a\udc26\uda81\udeb3\uda09\udca4", "\uabc9\u3c85\u40a1", "\ud857\udfa3\udad8\udc27\u6aca\uda5c\uddae\ud9a3\udc75\udb7d\uded3\udab3\udf73\udbed\udf09\ud886\udebf\udb43\udde5\uda4c\udea5\udaae\uddc9\ud8e8\udf66\ud94c\udd4a",
        55, 55462, 2001345009, -3431862544648762700L, -92528L, true, true, (char) 2123, (char) 27122,
        Double.longBitsToDouble(0x3fcf7f754af1c7ccL), Double.longBitsToDouble(0x3fe76c83c6c92173L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 6, 6, "\ud80e\udebb\ud86a\udca8\ud8e3\udcc5\udb7a\udc2c\uda42\ude7d\u7ce9\ud9e2\ude32\ud904\udfd1\ud840\udd12\u7e1c\uda44\udf37\ub25d\udb5d\udc0f\udae1\ude8a\udbfd\udfe6\uda27\udd72\ud8aa\udcd1\uda6c\udca5\uda84\udd62\uda09\udca4", "\uabc9\u3c85\u40a1\uc91c\u6473\u7d19\u9367\ub7d4\uc529\u9eab\u0907\u9a17\u3ffb\uc5fd\u5d8a\uc2eb\ua5e8\ub767\u248c\u8179\u4cd0\u2497\u62c0\u0d5c\ucb3a\u5496\u380c\u58d7\u679c\ucc08\u068d\u6a92\u3ace\ua0e2\u2092\u268a\uc8ef\u61e0\u5aaf\u8342\u2fb1", "\ud874\uddc0\ud9f1\udfc4\ud8c1\ude8d\ud895\ude19\udb91\udca7\udb8e\udcf2\udb36\udf41\udba1\udfd8\uda2b\udc6d\udac0\udcf5\ud9f7\ude55\ud893\udcc8\udba5\udfe9\u1181\udaf0\udd68\ud8df\udf5e\udae4\udeb8\ud9bf\ude7d\ud85b\udde8\udb5b\ude50\ud960\udc6a\uda4e\udc4d\uda2a\udd64\ud8d5\uddc3\ud937\uddbc\udb2d\udc11\uda00\udc38\ud837\udde7\udab3\udcfd\uda18\udfed\udbd5\udf56\ud922\udfbd\udab9\ude6e\ud9f0\udf1e\udb65\udf0d\udb3f\udf68\ud94a\ude91\ud9c0\udf69\ud831\ude62\ud87f\udfed\uda64\udf3a\uda61\udf6f\ud9e9\udc50\ud822\udc46\ud8f1\udf3c\ud908\ude06\udba7\udc05\udb4b\ude42\udb97\udf80\ud92b\udf80\udab7\udf4e\udb9a\udebe\udb10\udd95\udbb0\udcc9\ud957\uddd6\ud9f9\udfe2\uce03\udb67\udc0a\ud9b4\udece\uda45\udf60\udadd\udc7d\uda6d\udf2d\ud868\ude6a\uda46\ude85\ud8cd\udd80\udbdd\udd66\ud82b\udee9\udaa1\udfe0\udb40\udda1\udb19\uddb5\udac4\udca1",
        32, 16029, -1517994775, -8884033675083375648L, 6929L, false, false, (char) 10542, (char) 4859,
        Double.longBitsToDouble(0x3feefecfcd8fa3a2L), Double.longBitsToDouble(0x3fede72c214db09eL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud8ab\udd89\ub182\ud902\udc0d\udb43\udfbf\ud9ca\udf34\u9583\uda1f\udc80\ud949\udf40\uda44\udea8\ub25d\udb5d\udc0f\udae1\ude8a\ud9ab\udee8\ud89b\udfec\ud831\udcf4\udaa5\udcc3\uda81\udf0f\ud80d\udfc8]] |a1=[Ljava.lang.String;:[[\ud80e\udebb\ud86a\udca8\ud8ab\udd89\ub182\ud902\udc0d\udb43\udfbf\ud9ca\udf34\u9583\uda1f\udc80\ud949\udf40\uda44\udea8\ub25d\udb5d\udc0f\udae1\ude8a\ud9ab\udee8\ud89b\udfec\ud831\udcf4\udaa5\udcc3\uda81\udf0f\ud80d\udfc8]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 1, 6, "\ud80e\udebb\ud86a\udca8\ud8ab\udd89\ub182\ud902\udc0d\udb43\udfbf\ud9ca\udf34\u9583\uda1f\udc80\ud949\udf40\uda44\udea8\ub25d\udb5d\udc0f\udae1\ude8a\ud9ab\udee8\ud89b\udfec\ud831\udcf4\udaa5\udcc3\uda81\udf0f\ud80d\udfc8", "\u67d2\u3c85\u40a1\ua908\u6473\u54ef\u93e7\ub7d4\uc529\u9eab\uc822\u9a41\u3ffb\uc5fd", "\udaae\uddc9\ud8e8\udf66\ud94c\udd4a\ud8d0\uddb3\uda4b\udc55\uda98\udcf8\ud9c8\udc64\ud869\udfa7\ud91c\udce1\ud80b\udff8\ud9db\uddb5",
        8, 48384, 1911766188, -8036424237399704851L, 10264L, false, true, (char) 59542, (char) 18067,
        Double.longBitsToDouble(0x3f90604231db44c0L), Double.longBitsToDouble(0x3fe2db1eae4befcfL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processSingleHyphen|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
