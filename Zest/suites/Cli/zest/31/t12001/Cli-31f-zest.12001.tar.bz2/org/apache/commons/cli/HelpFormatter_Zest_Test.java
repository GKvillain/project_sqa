package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 9, 14, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\udb14\uddb6\ud816\ude9a", "\u51cc", "\ud96c\udf4e\uda02\udd88\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\udae4\udead",
        3, 29821, -1539399125, -8213514253196586289L, 11172L, true, true, (char) 53853, (char) 22750,
        Double.longBitsToDouble(0x3fedf25f7037650eL), Double.longBitsToDouble(0x3fedc0901c7866a0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 8, 9, 14, "\ud890\udc4d\ud83c\udccb", "\u91e1\u7eaa\u521b\u631c\u644c\u4280", "\uda57\udc4f",
        47, 8424, 1870927036, -5007776696143314249L, 63102L, true, false, (char) 37542, (char) 48967,
        Double.longBitsToDouble(0x3fe15938ec4ea43eL), Double.longBitsToDouble(0x3fe67c701ab6c49cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 14, "\ud890\udc4d\ud864\udcd9\udb4e\udf8d\udb88\udcff\udaa9\udc32\ud942\udda3\udb40\udf03\uda63\udda5\udb14\uddb6\ud90e\udf16", "\u51cc\u8086\ua0ef\u50e7\ua342\ucdd9\u2d08\uc0af", "\ud82f\udd3b\ud9cd\udf7c\ud8bf\udd7f\udab2\udeb3\ud8fc\udf6b\udaaa\udc26\ud8c9\udfa4\udac4\udfeb\uda34\udf7b\uda5c\uddb2\udaec\udd46",
        33, 94960, 1829327794, 7111074463039014917L, -4158L, true, false, (char) 9743, (char) 43025,
        Double.longBitsToDouble(0x3fc0cd4d4c38456cL), Double.longBitsToDouble(0x3fd3879193badc5cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 14, 9, 15, "\ud965\udcd4\udbba\uddea\udb47\udcbe\ud802\ude5c\uda67\ude15\udb35\udf2e\ud804\uded0\udab6\ude81\udb14\uddeb\ud93f\udd9f", "\u68c0", "\ud907\ude65\u57bb\u7c85\ud96b\udcbf\ud81c\udf6c\ud9bd\udeeb",
        1, 39625, -1539399125, -8213514253196586289L, 18464L, true, false, (char) 49293, (char) 25625,
        Double.longBitsToDouble(0x3f9abec6e459b640L), Double.longBitsToDouble(0x3fe1c96cd8fea63fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 9, 14, "\ud890\udc4d\uda9a\uddda\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\u7aa2\udaf4\ude49\ud816\ude9a", "\u4b9e\u69c7\u4183\u50e7\ua342\ucdd9\u96c1\uc0ed\uaf25\u61dd\u41a9", "\ud916\udeb0",
        21, 12020, 599672201, 6475242367743885058L, -70184L, true, false, (char) 11742, (char) 29533,
        Double.longBitsToDouble(0x3fdbb5b92b195016L), Double.longBitsToDouble(0x3f814391fea3db80L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 14, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\uda8c\uddd0\uda37\uddbd\uda63\udda5\udb14\uddb6\ud816\ude9a", "\u51cc", "\ud96c\udf4e\uda02\udd88\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\udae4\udead",
        3, 29821, -1539399125, -8213514253196586289L, 11172L, true, true, (char) 53853, (char) 22750,
        Double.longBitsToDouble(0x3fedf25f7037650eL), Double.longBitsToDouble(0x3fe8b8901c7866a0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:    |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 3, 9, 14, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\uda79\ude8a\ud816\udf32", "\u6fe4", "\ud96c\udf4e\ud98e\udd6e\udb15\udf23\ud893\ude7f\ud8f8\udd8c\udae4\udead",
        3, 41686, -1539399125, -8213514253196586289L, 11172L, true, true, (char) 21503, (char) 22750,
        Double.longBitsToDouble(0x3fedf25f7037650eL), Double.longBitsToDouble(0x3fedc0901c7866a0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 16, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\ud9bc\udf8a\ud816\ude9a", "\u51cc\u8086\ua0ef\u86e5\u5a76\ucdd9\u96c1\uc0ed\u99d1\u61dd\ua448\u6d74\u4d35\u2c6b", "\ud8e1\udddb\uda09\udf34\uda34\udf7b\uda5c\uddb2\udaec\udd46\ud919\uddc4\ud823\udcfa\ud961\udc6d",
        37, 2288, -398165253, -2463619585841551861L, 19594L, true, true, (char) 12243, (char) 60117,
        Double.longBitsToDouble(0x3fe886118bfbc39dL), Double.longBitsToDouble(0x3fe5c94f129a5041L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 9, 14, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3", "\u644c\u4280", "\uda57\udc4f",
        37, 10862, 1870927060, -5007776696143314249L, -958L, false, true, (char) 41424, (char) 16356,
        Double.longBitsToDouble(0x3feef938ec4ea43eL), Double.longBitsToDouble(0x3fe67c701ab6c49cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 16, 0, "\ud890\udc4d", "\ud677\u8a12\u7eaa\u521b\u5f0c\u644c\u4280\ua011\u8233\u51cc\u8086\ua0ef\u50e7\ua342\u83c7\000\uc00b\u99d1\u61dd\ua448\u356b\ubc4e\u30e3\u5925\u8e56\ucfe5\u4121\u3101\u2b84\u2d90\uc15a\u4014\ud09f\u043e\u05c4\uc5ac\u23be", "\udb86\udd7c\udab3\udd9f\ud8a4\udd0a\ud933\ude15\udb7a\udd13\ud8c4\udd9d\ud9f5\udfcd\ud837\udf56",
        10, 92733, -1677029463, -3861003887208453483L, 84085L, true, true, (char) 111, (char) 27335,
        Double.longBitsToDouble(0x3fe2be61e9bfa4ffL), Double.longBitsToDouble(0x3fa5d912ef2b7e70L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 9, 14, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\udb14\uddb6\ud816\ude9a\udb4c\udfe1\udb89\udcc3\uda57\udc4f\ud9dc\udcfe\ud83f\udc6b\ud9b3\uddbd\uda02\udd88\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\udae4\udead\ud91e\udc81\ud82e\udc3b\udad7\udcc2\ud93f\udd96\u0f4f\ud820\udc3f\udaaa\udc26", "\u3101\u2b84\u424e\uc0c5\u774d\u6b93\u7731\u9f1f\u8fc7\u596d\u6a45\u365a\u3a0c\ucc25\u98ff\ucb87\u8f9d\u85f2\u655f\u4af0\u9bb5\u98ee\u072e\u8309\u3424\u7e44\u56ad", "\ud8ac\ude94\uda43\ude5b\ud990\udd85\ud920\udc39\udba0\udcba\udacb\ude7d\uda0c\udee5\ud8d1\udc75\udb20\uddf8",
        26, 93151, -917004410, -3465183555101684082L, -98135L, true, false, (char) 33008, (char) 29966,
        Double.longBitsToDouble(0x3fe1e5ce589cff6bL), Double.longBitsToDouble(0x3fe7074e4eb89c24L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:- |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 15, 14, "\ud890\udc4d\ud83c\udccb\udb53\udfb6\udb62\udf72\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\udb14\uddb6\ud816\ude9a", "\u51cc", "\ud96c\udf4e\uda02\udd88\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\udae4\udead\ud91e\udc81\udbd0\ude2c\udad7\udca7\ud93f\udd96\u0f4f\ud820\udc3f\udaaa\udc26",
        6, 6848, -1631067902, 7281972868618072119L, -70184L, true, true, (char) 53635, (char) 54102,
        Double.longBitsToDouble(0x3fe2e91041e22330L), Double.longBitsToDouble(0x3fe66b50559ba885L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 14, "\ud88f\udff4\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\ud84b\uddc7\ubdac\udb14\uddb6\ud816\ude9a", "\u5b8e\u8086\ua0ef\u50e7\u2174\ucdd9\u96c1\uc0ed\u99d1\u61dd", "\ud93f\udd96\u0f4f\ud820\udc3f\udaaa\udc26\ud8c9\udfa4\udb80\udfe9\udad0\udd89\udb6d\udc7c\udaec\udd46\ud919\uddc4\ucf24\udb27\udce0\ud939\udfe9\uda17\udf2d\ud9bb\udc0a",
        10, 18349, 1298197243, 4973066452724564826L, 84699L, true, false, (char) 16480, (char) 12837,
        Double.longBitsToDouble(0x3fe485bb0ab17ef2L), Double.longBitsToDouble(0x3fd16b723a3452a8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                                                |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 3, 4, "\ud961\ude49\udb2b\udd92", "\ub658\u7eaa\u521b\u631c\u97e4\uce87", "\uda57\udc4f",
        47, 8424, 1870927036, -1693127367627866697L, -95780L, true, false, (char) 37542, (char) 41293,
        Double.longBitsToDouble(0x3fe15938ec4ea43eL), Double.longBitsToDouble(0x3fe67c701ab6c49cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 9, "\ud890\udc4d\ud83c\udccb\u00b4\000\000\000\uda37\uddab", "\u4280\ua011\u8233\u51cc\u8086\u7432\u502b\ua342\ucdd9\u96c1\uc0ed\u99d1\u61dd\ua448\u3275\uc930", "\udaaa\udc26",
        6, 6848, 1258291202, 302198839L, 41984L, false, false, (char) 31435, (char) 51605,
        Double.longBitsToDouble(0x3fdf3492ca814616L), Double.longBitsToDouble(0x3feeeae9719edcaaL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:usage:  |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 10, "\ud890\udc4d\uda9d\udffb\ud887\ude2f\udb88\udcff\udaa9\udc32\ud9dd\udda0\uda50\ude80\uda63\udda5\udb14\uddb6\ud96e\udd63\udb4c\udfe1\udb89\udcc3", "\u8908\u50e7\ua342", "\ud8f8\udd8c\udae4\udead\ud903\udd3a\ud872\udde8\udb54\udc87\ud925\udd87\u0f4f\ud820\udc3f\udaaa\udc26\ud8c9\udfa4\udac4\udfeb\uda34\udf7b\uda5c\uddb2\uda03\uddf1\ud8e8\udd72\u5cd5\ud9f7\udc72\ud93a\udc05\ud87a\udd66\udb42\udc33\ud94a\ude8b\ud948\udce4\ud90b\udf3b\ud9c0\udd60\ud984\udd05\u5e58\udb2d\udf3e\uda36\udf39\ud9ff\udd47\ud997\udccf\ud9f6\udc4a\udb82\udd90\ud8ff\ude85\uda91\udde5\ube6a",
        37, 11547, -899735718, -8482873467288292873L, -57686L, false, true, (char) 42253, (char) 62103,
        Double.longBitsToDouble(0x3fe45dd8f8355e37L), Double.longBitsToDouble(0x3fcd7318dabc65b8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 1, 9, 14, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\udb14\uddb6\ud816\ude9a", "\u51cc", "\ud96c\udf4e\uda02\udd88\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\udae4\udead",
        3, 29821, -1539399125, -8213514253196586289L, 11172L, true, true, (char) 41922, (char) 26671,
        Double.longBitsToDouble(0x3fedf259d037650eL), Double.longBitsToDouble(0x3fedc0901c7866a0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 4, 16, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\udb14\uddb6\ud816\ude9a", "\u51cc", "\ud96c\udf4e",
        14, 69567, 6814165, 8149545002359194845L, 80755L, true, false, (char) 24716, (char) 41170,
        Double.longBitsToDouble(0x3fe5b624e5bcd62eL), Double.longBitsToDouble(0x3fd892902d40477cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 2, 10, "\ud9ca\udee9", "\ucf11", "\udbc4\udfb4\ud964\ude1f\ud9f9\udcbc\ud817\uddba\udb4c\udfe1",
        51, 78783, 1303889039, -5496534113726491430L, -84341L, true, true, (char) 43372, (char) 57413,
        Double.longBitsToDouble(0x3fccce55d7b60610L), Double.longBitsToDouble(0x3fe15de8eb4ea43eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                               |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 3, 5, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\ud8ba\ude51\ud906\udee2\udb14\uddb6\ud816\ude9a", "\u51cc", "\ud96c\udf4e\udbb6\udd82\ud9ea\udd5a\udb6b\udff3\ud8f8\udd8c\udae4\udead\ud91e\udc81\udb3e\udec3",
        30, 76190, -996404529, -3013415342710829636L, -39197L, false, false, (char) 51039, (char) 47226,
        Double.longBitsToDouble(0x3fedc0901c7866a0L), Double.longBitsToDouble(0x3fba8cb1fd276cf0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 4, 6, "\uda38\ude5c\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5", "\ua011\u8233\u51cc\u8086\ua0ef", "\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\ud908\udf07\udbdf\uddb9\ud82e\udc3b\udad7\udcc2\ud93f\udd96\u0f4f\ud820\udc3f\udaaa\udc26\ud8c9\udfa4\udac4\udfeb\uda34\udf7b\uda5c\uddb2\udaec\udd46\ud919\uddc4\ud9d7\ude14\ud8c0\udf4c\uda5a\udcbd\ud902\udcb7",
        11, 93092, -1578128099, -9163252770581764929L, -13000L, true, true, (char) 4193, (char) 7339,
        Double.longBitsToDouble(0x3fed463bdc17b28dL), Double.longBitsToDouble(0x3fe231fc7c977855L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 14, "\udafd\udeb8\ud82c\udf76\udb23\udcbe\udb88\udcff\ud957\ude0a\uda0c\udf55\ud9dd\uddcc\uda63\udda5\udb14\uddb6\ud811\udd9a\udac4\udc34\ud98b\udfa1\uda57\udc4f\ud9dc\udcfe\ud822\udd3b\uda1e\udc5c\ud869\ude08\ud88d\udc0c\uda82\udfb8\udbb1\ude7f\udae4\udead\ud97a\udd3e\udaad\udd15\ud9bc\ude77\ud914\udd96\ud87a\ude48\ud81f\udfdb\udaaa\udc26\udac8\udfa7\ud9e8\udc9e\ud947\ude83\ud9fb\udf7d\ud996\udeb2\ud919\uddc4\udae4\udc56\ud8a7\udf54\ud8ba\udd8d\ud9da\ude3d\udbb4\udd83\udb7c\udfb1\ud914\uddb4\ud9e0\uddcd\ud843\ude2a\uda05\ude60\udb22\udcb9\ud93d\udf5e\ud9f0\ude93\ud946\ude19\ud832\ude75\ud92a\udc02\uda24\udd24\ud834\udfc3\ud9c0\uddd6\udb0c\ude5a\ud9c9\udffa\udbf5\uded5\ud8e6\udc10\ud9bc\udc44", "\u9a71\u4c7f\u6e30\u67ae\uae09\u2fa3\u22a4\ua111\u4b47\uc2de\u09af\ub0f4\u44d8\u356a\u83db\u508b\u3ff9\u6ed8\ub275\u5603\u7fa5\u57b6\u7a03\u9ce3", "\uda1e\udf4e\udb56\udf88\ud830\udf09\uda1a\udcbf\ud8ab\udfe6\udb89\udd95\udb8e\ude52\uda08\udef1",
        54, 16045, -2132398341, 5657064486995411050L, 16449L, true, true, (char) 6454, (char) 61566,
        Double.longBitsToDouble(0x3fd0ce6dfd431bbeL), Double.longBitsToDouble(0x3fe0770337d0f2d9L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 0, "\000\ud81e\udecf\udb23\udcbe\ud677\udaa9\udc32`\000\ufc03\000\000", "\u51cc", "\ud96c\udf4e\uda02\udd88\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\u00dd",
        3, 29821, 0, -996409344L, 11172L, true, true, (char) 53853, (char) 22750,
        Double.longBitsToDouble(0x3fe800077037650eL), Double.longBitsToDouble(0x3fedc0901c7866a0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 8, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\udacc\ude08\ud94c\udf53\udaad\udcb9\udb14\uddb6\ud816\ude9a", "\u51cc", "\ud938\udf02\uda02\udd88\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\udae4\udead",
        13, 74907, -1539399125, -8213514253196586289L, 11172L, false, false, (char) 50949, (char) 22750,
        Double.longBitsToDouble(0x3fedf25f7037650eL), Double.longBitsToDouble(0x3fedc0901c7866a0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 5, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\ud95e\udf7b\u657a", "\u95f2", "\ud96c\udf4e\uda02\udd88\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\udae4\udead\ud91e\udc81\ud951\uddbc\udad7\udce1\ud93f\udd96\u0f4f",
        21, 3828, 599672201, 6475242367743885058L, -4648L, true, true, (char) 39987, (char) 58004,
        Double.longBitsToDouble(0x3fac93f2229a7b10L), Double.longBitsToDouble(0x3fcfa8cb78bbcbdcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 9, 3, "\ud890\udc4d\000\udb15\udd0a\udb88\udc88\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\000\000", "\uce3c", "\ud96c\udf4e\ucda1\000\ud893\uddaa\ud8f8\udd8c\u00dd",
        2, 29821, 41515, -996404736L, 50972L, false, true, (char) 53693, (char) 0,
        Double.longBitsToDouble(0x3dfb800000000000L), Double.longBitsToDouble(0x3e41e19a80000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 15, 14, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\udb14\uddb6\ud816\ude9a", "\u51cc", "\ud96c\udf4e\uda02\udd88\udb09\udc1b\ud893\ude7f\ud8f8\udd8c\udae4\udead",
        3, 29821, -1539399125, -8213514253196586289L, 11172L, true, true, (char) 53853, (char) 22750,
        Double.longBitsToDouble(0x3fedf25f7037650eL), Double.longBitsToDouble(0x3fedc0901c7866a0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:                                                 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                                                 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 3, 3, 14, "\000\ud864\udca9\udb4e\udf8d\udb88\udcff\udb1d\udfac\ud942\udda3\udb40\udf03\uda63\udda5\udb14\uddb6\ud90e\udf16", "\u51cc", "\u14bc",
        48, 69567, -105325447, 143642541818880L, 79475L, true, false, (char) 60431, (char) 2313,
        Double.longBitsToDouble(0x3fde40537b79ac1eL), Double.longBitsToDouble(0x3fd892902d40477cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:usage:  |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 13, 6, 16, "", "\000", "\ud942\udda3",
        23, -1000, 0, 0L, -100000L, false, false, (char) 45144, (char) 51316,
        Double.longBitsToDouble(0x3fda16f8456f7500L), Double.longBitsToDouble(0x3fbe63f99527cdc0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 0, "\ud890\udc4d\uda25\udc97\udb3d\ude0b\ud87c\udd3a\ud8d9\udc79\udbaf\ude33\udb40\udf03\uda63\ude42\udb14\uddb6\ud90e\udf16\udb79\udc42\udb86\udefa\uda57\udc4f\ud9dc\udcfe\ud89b\uded9\ud96c\udf4e\uda02\udd88\udb09\udc1b\ud8fb\udc1a\ud8f8\udd4e\udae4\udead\uda90\uddc5\uda7a\udea0\ud9e4\ude2b\ud8bf\udd7f\udab2\udeb3\ud8fc\udf6b\udaaa\udc26\udb78\udf2b\udaa8\udc2f\uda34\udf7b\uda5c\uddb2\udaec\udd46", "\u0ced\u8182\u76c1\u9618\u75b4\u1377\u65f6\u1fe4\u6118\u8a94\u2bce", "\uda86\udc89\ud885\udce8",
        20, 86094, -1745475585, -3564675560975605314L, -47265L, true, true, (char) 51969, (char) 712,
        Double.longBitsToDouble(0x3fec58279dc8aed8L), Double.longBitsToDouble(0x3fc9b53874157210L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 12, 12, 7, "\udbe0\udd47\ud864\udcd9\udb4e\udf8d\udb88\udcff\udaa9\udc32\ud942\udda3", "\u644c\u9c42\u68aa\u786a\u51cc\u8086\ua0ef\u8be7", "\ud8fb\udc1a\ud8f8\udd4e\udae4\udead\ud835\udd4b\ud82f\udd3b\ud9cd\udf7c\ud8bf\udd7f\udab2\udeb3\ud8fc\udf6b\udaaa\udc26",
        6, 7016, 986290936, 1837417598288128250L, -70184L, false, true, (char) 2453, (char) 10932,
        Double.longBitsToDouble(0x3f8e999467b65e40L), Double.longBitsToDouble(0x3fe2bb45909bbd73L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 1, "", "\000", "",
        2, 43642, 56335, 0L, -100000L, false, false, (char) 48311, (char) 230,
        Double.longBitsToDouble(0x3f4f371375c40000L), Double.longBitsToDouble(0x3fefc31572ed815aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 15, 14, "\ud965\udcd4\udbba\uddea\udb47\udcbe\uda53\udea5\uda67\ude15\udb35\udf2e\ud804\uded0\udab6\ude81\ud8ea\uddb8\ud93f\udd9f", "\u68c0", "\ud907\ude65\u57bb\u7c85\ud96b\udcbf\ud81c\udf6c\ud9bd\udeeb",
        1, 39625, -1539399125, -471263544218086705L, 18464L, true, false, (char) 49293, (char) 25625,
        Double.longBitsToDouble(0x3f9abec6e459b640L), Double.longBitsToDouble(0x3fe1c96cdffea63fL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 14, 9, 12, "\udbe5\udd56\udb0b\udec2\ud808\udebe\udb4c\udf8f\ud910\udca8\u0f64\ud804\udfa7\udab6\ude81\udb14\uddeb\ud93f\udd9f", "\u68c0", "\uda7f\udee0\ud82b\udc30\u7d74\ud96b\udcbf\ud81c\udf6c\ud9bd\udeeb",
        1, 39625, -1539399125, -8213514253196586289L, -27322L, false, true, (char) 19412, (char) 22333,
        Double.longBitsToDouble(0x3fc96cddc99245acL), Double.longBitsToDouble(0x3fefd1fb7d2feb15L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 9, 15, "\ud965\udcd4\udbba\udd8f\udb47\udcbe\ud802\ude5c\uda67\ude15\udb35\udf2e\ud804\uded0\udab6\ude81\ud9e7\udc74\ud892\udf17\udb4e\udf60\ud896\udf4a\ud88e\udeec\ud9f5\udecc\ud89b\uded9\ud907\ude65\u57bb\udb29\udc89\ud964\udc22\ud81c\udf6c\ud9bd\udeeb", "\u356b\u59a7\ub1f8\u70b5\u430e\ucfe5\ucbe6", "\ud9ac\udf52\udbe0\udca8\udbec\udc9f\ud84c\udd23\ub1d2\udbb2\udcee\udb8a\udf2d\ud875\udccd\udae9\ude69\udaee\udfde\udafb\udf71\ud911\udf81\udb47\uddc5\uda74\udd8c\ud92f\udc49\ud907\udf68\uda29\udea0\udbf4\udc6f\ud90a\ude88\ud8a2\ude5b\ud981\udeb0\ud988\udfc4\udaf0\udf83\udb22\udf14\uda86\udec7\uda75\ude77\ud94f\udd43\ua47d\udb8c\udc06\ud981\udc9e\uda64\udef0\udbe6\udfb1\udae9\udf68\u09cc\ud8e0\udcf1\ud94f\uddf9\uda99\ude88\uda90\udf53\udb62\udcf2",
        -3, -358, 432202173, -7175815794601171707L, -77042L, false, false, (char) 31684, (char) 45910,
        Double.longBitsToDouble(0x3fbea6f4d7f97dc0L), Double.longBitsToDouble(0x3fd78feeee792476L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 14, 9, 0, "\000", "\u8d3c\ud68a\u5447\ucba8\ucb1a\u6481\u9577\u720a\ua581\u68c0\u0086\u6358\000\000", "",
        32, 43439, -576508069, 2818519137779753515L, -100000L, false, false, (char) 28928, (char) 28496,
        Double.longBitsToDouble(0x3fe5011df7022633L), Double.longBitsToDouble(0x3fe6025f7275fe91L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 11, 15, "\uda4d\udfe1\ud94c\udd8b\ud913\udf2b\ud802\ude5c\uda67\ude15\udb35\udf2e\ud8a7\udd20\udab6\ude81\udb14\uddeb\ud93f\udd9f", "\u68c0", "\ud907\ude65\u57bb\u7c85\ud96b\udcbf",
        19, 43439, -576508069, 2818519136240312875L, 18464L, true, false, (char) 49293, (char) 47384,
        Double.longBitsToDouble(0x3fef9a4c536669a7L), Double.longBitsToDouble(0x3fe4917a3734aeabL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 15, 5, "\ud965\udcd4\udbba\uddea", "\ud68a\u5447\ucba8\ucb1a\u6481\u9577", "\ud88e\udeec",
        4, 8424, -442267661, -7363221967956836391L, 81239L, true, false, (char) 38398, (char) 16861,
        Double.longBitsToDouble(0x3fe15938ec4ea43eL), Double.longBitsToDouble(0x3fe67c701fb6c49cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 15, 11, "\ud9a8\udfee\ud96d\udc63\udb23\udcbe", "\uc620\uce67\u30a4\u7811\u9493\u238f\u8233\u51cc", "\uda72\udfd1\ud8ff\udc8a\udb09\udc1b\udb39\udc32\udbd0\udc12\udbf8\ude67",
        40, 37869, -1539399125, -8213514253548907825L, -80585L, false, true, (char) 34997, (char) 18604,
        Double.longBitsToDouble(0x3fd51ddc4b04d786L), Double.longBitsToDouble(0x3fc935482eadab98L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:usage:  |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 7, "\ud890\udc4d\udb71\udcee\ud81b\udd61\udac2\uddbf\udaa9\udc32\udb6f\udc82\udae4\udda7\uda63\udda5\ud856\udf78\ud879\ude67\udb42\udf4f\udb89\udcc3\uda57\udc4f\ud9dc\udcfe\ud89b\uded9\udb1f\uddeb\udb19\udee1\uda79\ude82\ud852\uddca\ud9c8\ude86\ud950\udf7c\ud919\ude6b\uda56\udc39", "\u2c6b\u62ec\ub906\ucf8d\u4121\u90b7\u2b84\u2d90\uc0b9\u0a39\u8c76\uc31d\u718b\u4635\u5557\u082e\u4e4a\ua92c", "\udb27\udf26\uda84\udecc\uda2b\ude10\udad4\uddcd\ud89e\ude96\udb2e\uddc9\udad4\udf97\uda0f\udc61\udb52\udf43\udbb3\ude25\udaef\udf33\ud8c7\udfbb\ud9ac\udd80\udb02\udc89\udb51\udc01\udaa5\udd43\udb17\uddc8\uda6c\udfd2\ud8e7\udf49\ud91f\ude0f\udb55\udfa2\udb1d\ude4e\u7296\udaf5\udea8",
        47, 27232, -1218373803, 8136605013827359439L, -8070L, false, false, (char) 110, (char) 13198,
        Double.longBitsToDouble(0x3fe353d026e88dacL), Double.longBitsToDouble(0x3fc32b9a44f05918L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 1, 6, 14, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\uda79\uddda\ud816\udf32", "\u6fe4", "\ud96c\udf4e\ud98e\udd6e\udb15\udf23\ud893\ude7f\ud8f8\udd8c\udae4\udead",
        58, 47573, 744070793, -7818444010051278760L, 11172L, true, true, (char) 43900, (char) 60515,
        Double.longBitsToDouble(0x3fe8725f744306a2L), Double.longBitsToDouble(0x3fe6de15f425e0c2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 1, 1, 12, "\ud890\udc60\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\ud832\udda6\ub827", "\u6fe4", "\ud96c\udf4e\ud98e\udd6e\udbd9\udc78\udb2f\udfc3\ud8fc\udf14\udae4\udead",
        46, 6549, 1674207224, 6507681971050873737L, -99133L, true, true, (char) 21503, (char) 22750,
        Double.longBitsToDouble(0x3fedf25f7537650eL), Double.longBitsToDouble(0x3fd9c07ed8f0cd40L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 9, 14, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\uda79\ude8a\ud816\udf32\ud865\udc2c\ud803\uddf0\udafa\udca2\ud9dc\udd36\ud8ae\ude56", "\u28e2\u96c1\uc0ed\u99d1\u61dd\ud2a1\u356b\u4d35\u2f16\u5925\u8e56\u6fb0\u417f\u5998\u6b67\u4f31\uc15a\u5376\u6787\uc473\u7a98", "\udb80\udc5d",
        26, 4671, 1887321322, 6163575590450910137L, 79884L, true, true, (char) 53171, (char) 41673,
        Double.longBitsToDouble(0x3fd2b05d8380af8eL), Double.longBitsToDouble(0x3feb69081133ddb8L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:                                                        |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 12, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\ud9a2\udc33\udafd\udf3f\uda95\udc8a\ud816\udf32", "\u8869\u80be\u146d\u50e7\u9935", "\ud9a3\udec3\ud9e5\udc58\ud961\udd2e\ud938\ude8e\udad7\udcc2\uda43\udff7\udb47\udc3b\udbf9\udfe2\udbe1\ude35\ud8b4\udf9d\udaec\udf35\uda31\udd68\ud95d\udfb4\ud93a\udd4d\ud919\uddc4\udb4d\udf4f\uda37\ude00\u82c0\uda1e\udca1\ud95c\udc28\ud8ec\udd4a\udaa2\udeb7\udb40\ude59\ud927\udc73\ud85e\udc64\uda88\udc15\uda5a\udd5a\udb35\udd63\ub45c\ud860\udd15\uda35\udf00\ud956\ude92\uda1a\ude41\ud86d\ude3c\ud9be\udf89",
        55, 73144, -526655794, 1938528762338518881L, 48300L, false, true, (char) 13980, (char) 540,
        Double.longBitsToDouble(0x3fdfd563fcde30a6L), Double.longBitsToDouble(0x3fc49bb0c0f98c24L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 15, 16, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\ud9bc\udf8a\ud816\ude9a", "\u51cc\u8086\ua0ef\u86e5\u5a76\ucdd9\u96c1\uc0ed\u99d1\u61dd\ua448", "\u0f4f",
        8, 72076, -763692918, 6479195421283385090L, 67182L, false, false, (char) 59382, (char) 24399,
        Double.longBitsToDouble(0x3fe05eee7fee1c38L), Double.longBitsToDouble(0x3fa77c9429594300L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 16, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\ud9bc\udf8a\ud816\ude9a", "\u51cc\u8086\ua0ef\u86e5\u5a76\ucdd9\u96c1\uc065\u99d1\u61dd\ua448\u9575\u4d35\u34b9", "\ud8e1\udddb\uda09\udf34\uda34\udf7b\uda5c\uddb2\udb7a\ude8e\ud8fd\udd7f\ud823\udcfa",
        15, 49602, 1828406288, -1710106740612172022L, -93874L, false, false, (char) 22213, (char) 5383,
        Double.longBitsToDouble(0x3fddd93d13e2abc4L), Double.longBitsToDouble(0x3fed46d96f10c231L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 15, 16, "\ud890\udc4d\ud83c\udccb\udb15\udd0a\udb88\udcff\udb1d\udfac\000\000\ue400\000\ud816\ude9a", "\u51cc\u8086\ua0ef\u86e5\u84d5\000\000\000\u99d1\u61dd\u00ed\000\u4d35\u2c6b", "\ud8e1\udddb",
        5, 40050, 0, 1721825208L, -86556L, false, false, (char) 43777, (char) 59382,
        Double.longBitsToDouble(0x3fe85742260bddcfL), Double.longBitsToDouble(0x3fef70e1c42ef928L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 15, 9, "\ud899\udd8b", "\u1971\u91e1\u7eaa\u521b\u631c\u390a\u4280\u1638\u1052\u51cc\u8086\ua0ef\u86e5", "\udbf6\uddfb\ud8b0\udeb6\udae4\udead\ud91e\udc81\ud82e\udc3b\ud9a9\udc5a\ud93f\udd96\u0f4f\ud820\udc73\udbd3\udf7c",
        7, 18240, -1200498174, 1082126339198365950L, -16579L, true, true, (char) 29043, (char) 45329,
        Double.longBitsToDouble(0x3fee0d3b5780849cL), Double.longBitsToDouble(0x3fe05eee7fee1c38L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 15, 16, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\ud9bc\udf8a\ud816\ude9a", "\u02cd\u8086\ua0ef\u86e5\u5a76\ucdd9\u96c1\uc0ed\u99d1\uacd4\u7cca\u6dee\u4d35\u2c6b", "\ud8e1\udddb\uda09\udf34\uda34\udf7b\uda5c\uddb2\udaec\udd46\ud919\uddc4\udb28\udef6\ud961\udc6d",
        13, 55706, -398165253, -2463619585841551861L, 19594L, true, true, (char) 12243, (char) 60117,
        Double.longBitsToDouble(0x3fe886118bfbc39dL), Double.longBitsToDouble(0x3fe5c94f129a5041L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 16, "\ud890\udc4d\ud83c\udccb\udb23\udcbe\udb88\udcff\udaa9\udc32\ud942\udda3\uda37\uddbd\uda63\udda5\ud9bc\udf8a\ud816\ude9a\udb4b\udc7b\uda9c\udd10\uda57\udc4f", "\u86e5\u5a76\ua87a\u96c1\uc0ed\u99d1", "\udae5\udccb\ud93f\udd96\u0f4f\ud820\udc73\udbd3\udf7c",
        10, 18217, 1273954050, 7281972868618072119L, 67182L, false, true, (char) 59373, (char) 24399,
        Double.longBitsToDouble(0x3fe05eee7aee1c38L), Double.longBitsToDouble(0x3fe04317f34a52bfL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptSeparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
