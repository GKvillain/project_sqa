package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 1, "\udb2f\ude7d\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\u86b5\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u3c2c\u64a6\u0b68", "\udac1\ude2d\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\uda9f\udd36\uda3b\udf60\ud9ca\udd0d\ud998\udd85\udbf6\udd2b",
        22, 7997, 2031982552, 5700237522032592206L, -54810L, false, false, (char) 62948, (char) 50321,
        Double.longBitsToDouble(0x3fe26534e9f34eb0L), Double.longBitsToDouble(0x3fd0c305acde14aaL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 1, "\udb2f\ude7d\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\uc91c\u180d\u25b3\u5664\u86b5\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u3c2c\u64a6\u3c00", "\udac1\ude2d\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\uda9f\udd36\ud9d1\udd96\ud9ca\udd7d\ud998\udd85\udbf6\udd2b",
        22, 7997, 2031982552, 5700237522032592206L, -54810L, false, false, (char) 42441, (char) 43061,
        Double.longBitsToDouble(0x3fe26534e9f34eb0L), Double.longBitsToDouble(0x3fe59182d67acc9bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 1, "\udb2f\ude7d\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\udae2\udf5e\ud957\udc2b\ud98f\udd5c\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\uca4b\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\u86b5\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u3c2c\u64a6\u0b68", "\000",
        52, 93778, 1982101345, 338797925121101209L, 86436L, false, true, (char) 37864, (char) 37173,
        Double.longBitsToDouble(0x3fded1127fb04ba0L), Double.longBitsToDouble(0x3fee9bc8ed4e4f1bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 1, "\u787a\uda4a\udca4\ud87c\udf15\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda89\ude90\udb0b\ude7f\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\u86b5\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u3c2c\u64a6\u0b68", "\udac1\ude2d\ud830\udc53",
        49, 76345, 78882539, -469626047500726755L, -72265L, true, true, (char) 32892, (char) 63601,
        Double.longBitsToDouble(0x3fd4e4f49ee47836L), Double.longBitsToDouble(0x3febd77ad8c410d7L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 16, "\ud8d2\uddb9\u0790\ud904\ude23", "\u54aa\u3cc7", "\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a",
        1, 58895, -1526723737, 6047036728972876973L, 41106L, true, true, (char) 61870, (char) 7650,
        Double.longBitsToDouble(0x3fd490f7037f8c90L), Double.longBitsToDouble(0x3fb065424c2d2b28L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 1, 10, 2, "\ud9bb\udddf\ud82f\udd83\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud80f\uddde\udb50\udf1f\ud92d\udd23\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\ud9e2\udf9d\ud810\udca3\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud9fa\udd4a\ud87f\udeb5\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\ud0f3\u58e1\u72f9\u0cdf\u213c\u2f60\ua7c3\u4d08\u7260\u2fb6\u73e4\ua24c\u5693\u061f\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u3c2c\u64a6\u0b68", "\udaee\udd45\ud990\udcf2\udb0a\udecd\ud94d\ude57\ud838\udcdd\udbd2\udca7\uda3b\udf51\ud9ca\udd0d\ud998\udd85\ud80c\ude96",
        19, 7997, 2031982552, 5700237522032592206L, -54810L, false, false, (char) 62948, (char) 50321,
        Double.longBitsToDouble(0x3fe26534eff34eb0L), Double.longBitsToDouble(0x3fe8625395400a55L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 1, "\udb2f\ude7d\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udb40\udc5a\ud810\udc58\ud84f\uddfd\u28c6\udb51\udca7\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u2fb6\u73e4\u39af\000\000\000\u51e3\u701a\u8590\ua8f8\ub89b\u3c2c\u64a6\u0b68", "\udac1\ude2d\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\uda9f\udd36\uda3b\udf60\ud9ca\udd0d\ud998\udd85\udbf6\udd2b",
        22, 7997, 2031982552, 5700237522032592206L, 8812L, true, false, (char) 54410, (char) 7517,
        Double.longBitsToDouble(0x3fd840d32c964e94L), Double.longBitsToDouble(0x3fe93e5ffe045b25L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 4, 1, "\udb2e\udfef\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda99\udf5f\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda45\udf77\uda32\ude17\ud8e4\udf07\ud9a2\udebd\udbcb\udf3f\ud810\udc90\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3c69\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u55ac\u0b15\u73e4\ua24c\u5693\u86b5\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u3c2c\u64a6\u0b68", "\udac1\ude2d\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\uda9f\udd36\uda3b\udf60\ud9ca\udd0d\ud998\udd85\udbf6\udd2b",
        22, 7997, 2031982552, 5700237522045279822L, -54810L, false, false, (char) 62801, (char) 50321,
        Double.longBitsToDouble(0x3fe26534e9f34eb0L), Double.longBitsToDouble(0x3fd0c305acde14aaL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:                                                |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 1, 2, "\udb2f\ude7d\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23", "\u20a0\u5f99\u9b5c\u9576\u8377\ucd1c\u7cd2\u9d66\u7bb3\u95f3\u6aa2\u3e95\uae1c\u77f9\u3754\u619d\u07d4\ua971\u2e15\u3cf6\u16f4\u58e1\u72f9\u0cdf\u213c\ub66e\u4f72\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\u5a1b", "\uda66\udecb",
        47, 2746, 117659724, -3259962045020186060L, -88405L, false, false, (char) 65119, (char) 36948,
        Double.longBitsToDouble(0x3feb95a3b7612805L), Double.longBitsToDouble(0x3fe75bb1259904b3L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 3, "\u39ae", "\u3623\uc38e\u54aa\u3cc7\u5fcd\u3e59\u7db1\u20a0", "\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbc1\ude3f\ud810\udc86\ud84f\uddfd\ud9d9\udd0d",
        17, 8766, 2029856895, -6557228519033969698L, 38419L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3fdbfc6480832a12L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 7, "\ud91c\udf09\ud852\udeb6\ud9ed\udd53\ud931\udeba\uda2f\udfc3\ud849\udddb\udb50\udf20\uc740\ud953\udedc\udb0a\udfb9\ud8e9\udd33\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a", "\u07d4\ua971\u2e15\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\u86b5\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u3c2c\u64a6\u0b68\uc3f1\u9616\ub297\u6b3c\uc2e0\ucb66\u7c7d\u75df\ub491\u0818\u964c", "\ud9b8\udc27\ud8af\udefb\ud9a9\udc7c\udb18\udcd8\udba1\ude76",
        7, 18268, 1682945052, -6440886054165652916L, 8812L, false, true, (char) 43490, (char) 33825,
        Double.longBitsToDouble(0x3fc9d0e384c9bd54L), Double.longBitsToDouble(0x3fe9d6a8b9073c35L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 1, 1, "\ud860\udc15\u59db\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb", "\u3e59\u7db1\u20a0\u5f99\u9b5c\u2350\u8377\u5142", "\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0",
        44, 77069, -1213847758, -6557529193918542672L, -43351L, true, true, (char) 23882, (char) 42730,
        Double.longBitsToDouble(0x3fef439412b7ab2dL), Double.longBitsToDouble(0x3fabf1854f0adc10L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 7, 1, "\000\000", "\uc38e\u54aa", "\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\u00a3\000\udb0e\ude27",
        57, 9806, 1276793217, -4549435216370639638L, 86241L, true, true, (char) 2271, (char) 28824,
        Double.longBitsToDouble(0x3fea6e715f320a91L), Double.longBitsToDouble(0x3fdf1b7a680149fcL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 1, 1, "\uda58\udfd3\ud871\udc2f\ud827\udff5\ud931\udf0d\udb94\uddf4\ud82b\udf58\udb50\udf20\ud960\udd23\uda89\ude90\ud8e6\udc41\ud95b\udcb2\uda17\uddf7\uda4e\udd5e\ud925\udf9d\uda6f\udd8c\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\udabd\ude65\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u687f\ud254\u41fb\ub2b6\u2f36\u06df\u2f0f\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\ub812\uaf77\u51e7\u701a\u8590\ua8f8\ub89b\u06e4\u6518\u0b68\uc3f1\u9647\u7ca9\uc277\uc33d\ucb66\u7c7d", "\ud9ca\udd0d\ud998\udd85\udbf6\udd2b\udb15\udf80\ud9b8\udc27",
        16, 69091, 1020731726, -1199259932250648710L, 40101L, false, true, (char) 55653, (char) 13805,
        Double.longBitsToDouble(0x3fe26e7cc0992f54L), Double.longBitsToDouble(0x3fdad53133eba65eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=void\012",
        Z.run(T, 2, 10, 1, 1, "\udb2f\ude7d\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\u86b5\ud55a\u2312\u5ad5\u8590\ua8f8\ub89b\u3c2c\u64a6\u0b68", "\udac4\udd12\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\uda9f\udd36\uda3b\udf60\ud9ca\udd0d\ud998\udd85\udbf6\udd2b",
        22, 7997, 2031982552, 5700237522032592206L, -54810L, false, false, (char) 62948, (char) 50321,
        Double.longBitsToDouble(0x3fe26534e9f34eb0L), Double.longBitsToDouble(0x3fd0c305acde14aaL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 3, 12, "\udb2f\ude7d\u0790\ud827\udff5", "\u54aa\u3cc7", "\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\udafb\udc34\ud9d4\udcdb\ud9fa\udd9a",
        1, 58895, 683054439, 5998639225005350061L, 41106L, true, true, (char) 61870, (char) 7650,
        Double.longBitsToDouble(0x3fd490f7037f8c90L), Double.longBitsToDouble(0x3fb2a5424c2d2b28L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 12, 3, "\udb2f\uddcf\u0790", "\ub68e\u54aa", "\uda89\ude38",
        29, -1000, 0, 1837767587L, 61326L, false, true, (char) 26, (char) 7403,
        Double.longBitsToDouble(0x3f8c9f261fe13ec0L), Double.longBitsToDouble(0x3feb3bc7ebdea500L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 1, 1, "\udb2f\ude7d\u0790\ud827\udff5\uda9e\udfe9\udb94\udd49\uda5e\uddf6\ud83d\udd90\ud805\udf77\uda89\udef9\udb0a\udfb9\udbdf\udc9a\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\uda66\udd4c\ud849\uddf1\uda77\udf81\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u7a5c\u7363\ua24c\u5693\u86b5\u242c\u02c1\u70fe\u1a11\u0eb9\ub89b\u45f3\u64b8\u0b68", "\udac1\ude2d\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\udaf3\udc03\ud911\ude59\ud890\udea4\udb4c\udd73\udbf6\udd2b",
        9, 57049, -1721004245, 5700300417533674830L, 86182L, false, false, (char) 62948, (char) 50321,
        Double.longBitsToDouble(0x3fe26534eef34eb0L), Double.longBitsToDouble(0x3fdacf490cdf1decL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 4, 0, "\udb2f\ude7d\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda30\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\udb8c\udda9\ud9fa\udd6c\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u25a4\u2e43\u0cf6\ub729\u9d04\ud526\u51e7\u701a\u8590\u319e\u7fd9\u017b\u7bfd\u6df8", "\udac1\ude2d\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\uda9f\udd36\uda3b\udf60\ud9ca\udd0d\ud998\udd85\udbf6\udd2b",
        22, 7997, 2031982552, 5700237522032592206L, 8812L, true, false, (char) 15478, (char) 18064,
        Double.longBitsToDouble(0x3feb1b2a587f6f95L), Double.longBitsToDouble(0x3fd79c939e979e5aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:   |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 1, 1, "\udb2f\ude7d\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\ud917\udd42\ud9df\udf91\uda6f\ude01\ud956\ude68\udbff\udf1e\udaf6\ude59\ud870\udd6a\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\u86b5\u7935\u7aa7\u58ca\u942c\u642a\ub899\u3c2c\u64a6\u0b68", "\udac1\ude2d\ud990\udc4f\udb11\uddcd\ud94d\ude57\udb33\udc8e\udbb6\ude60\udab4\udf24\ud8d2\uded1\ud998\udd76\udbf6\udd2b\udb2b\udcab",
        2, 63552, 1327189971, 4331061298933227378L, 21028L, false, false, (char) 50321, (char) 234,
        Double.longBitsToDouble(0x3fdf34eb021860b4L), Double.longBitsToDouble(0x3fe37852adf12f13L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 1, "\udb23\udd2e\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda86\udf90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda41\udc2c\uda32\ude17\uda6f\ude01\udb2e\udcf4\udbff\ude99\177\ud84f\uddfd\ud930\udd82\uda04\udcda\ud8fb\udf50\ud915\udda1\ud849\ude0a\ud800\udcd0\ud8ba\udcc5\ud9b9\udc54", "\u3cf6\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\uab5c\u7260\u2fb6\u73e4\ua24c\u5693\u86b5\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u3c2c\u63ae\u9dc5", "\udaa4\uded1\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\uda9f\udd36\uda3b\udf60\ud9ca\udd0d\ud998\udd85\udbf6\udd2b\udbb3\udd6f\ud9bb\udc80\ud8af\udefb\ud9a9\udc7c\udb18\udcd8\udba1\ude76\ud812\udc78\ud9f9\udca4\ud942\ude05\ud9ce\udefd\ud85f\udeef\ud9e3\udccc\udba2\udda7\ud840\uddcc\udacc\udfb3\ua11a\ud910\udd05\udb42\udd0f\ud94a\ude98\udba3\udd3a\udaec\udf8c\udacb\udef1\udb82\udf20\udad5\udd96\ud975\udf18\ud8d4\uddf8\ud837\udfca\uda34\ude84\uda4a\uddb2\ud963\udca9\ud965\udf23\uda05\udfe8\ud9cb\uddde\ud92c\udf3a\uda0b\udcb9\ud815\udfd7\udafb\uddab",
        40, 10731, -468298625, 6050716548936442779L, -24196L, true, false, (char) 27472, (char) 12686,
        Double.longBitsToDouble(0x3fe72448110d41d9L), Double.longBitsToDouble(0x3fe956103e57bfc1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 1, 1, "\u69ce\udaeb\udef3", "\uc38e\u54aa\u3cc7\u5fcd\u7d6e\u7db3\u20a0\u5f25\u9b5c\u9576\u8377\u5142\u152b\ucf5c\ud76f\u1d98\u8987\u5dc1\u16f4", "\ud8a8\udd14\udba3\udfe2\ud9c2\udeee",
        53, 47256, 259005863, -4158830952068816449L, 30683L, false, true, (char) 34276, (char) 1858,
        Double.longBitsToDouble(0x3fce15b8325e475cL), Double.longBitsToDouble(0x3fc4970c46bdc874L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 11, 10, 8, "\udb35\uddc0\ud8dc\udfce\ud84b\udc9a\ud931\udf92\uda2f\udfc3\ud849\udddb\udb50\udf20\ud917\udd18\uda89\uded3\udb0a\udf73\uda91\udd13\ud97b\udfad\ud982\ude8c\uda09\ude92\ud8b4\ude22\udb2e\udcf4\udbc6\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\ua777\u0ff3\u58e1\u3b45\u3f54\u213c\u2f60\uc064\u8abc\u7260\uc91c\u180d\u25b3\u5664\u86b5\ud55a\u52c6\u701a\ua11d\u4bd1\ub89b\u3c2c\u64a6\u3c00", "\udac1\ude2d\ud990\udc4f\ud945\udc27\ud94d\ude76\udbb7\udf31\ud9ca\ude2f\ud9d1\udd96\ud9ca\udd7d\uda46\udd1b\u0857",
        22, 7997, 2031982552, 5700237522032592206L, -54810L, false, false, (char) 55798, (char) 43061,
        Double.longBitsToDouble(0x3fe26534eff34eb0L), Double.longBitsToDouble(0x3fd9bf19acf53b36L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 1, 15, "\ud92d\udd02\udb37\udf6b\udadd\udd7a\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\udae2\udf5e\ud957\udc2b\ud98f\udd5c\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\ud9cd\udc23\udbcc\udee5\uda01\uddb4\ud84f\uddfd\ud9d9\udd0d\uda03\uddc1\ud800\udcce\ud90f\udfa0\ud849\ude0a\udb27\ude58\ud8a8\uddb6\ud9b8\udfec", "\u3cf6\uca4b\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u7260\u2fb6\ud6da\ucc70\u17e1\u86b5\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u7b13\u64cc\u0b68", "\000",
        52, 93778, 1982101345, 338797925121101209L, 86436L, false, true, (char) 37864, (char) 37173,
        Double.longBitsToDouble(0x3fded1127ceb15eeL), Double.longBitsToDouble(0x3fee9aab4d4e4f1bL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 1, 1, "\udb2f\ude7d\u0790\udb12\ude0a\ud8ae\udc03\uda2f\udfc3\ud97b\ude93\udb50\udec7\udae2\udf5e\ud957\udc2b\ud98f\udd5c\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\ud8a6\ude7c\udb2e\udccd\udbff\ude99\ud810\udc86\ud84f\uddfd\ud8b5\ude3b\udab5\ude9c\ud80e\udcce\ud90f\udfa0\udaa3\ude17\udb13\udc4f\ud82a\udc06\ud8e3\ude9c", "\u3cf6\u95e0\u58e1\u92f9\u0d15\u213c\u2f60\uc064\u8abc\u5a60\u2fb6\u0f96", "\udb3c\udda6\uca45\ud82d\ude5d\uda64\ude1f\ud917\udcbd",
        41, 94724, -759019061, -4228640134582908124L, -100000L, false, false, (char) 0, (char) 6121,
        Double.longBitsToDouble(0x3fe5da44ab987624L), Double.longBitsToDouble(0x3fb59cb0d4d6bd78L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 1, 1, "\ucd2f\uda4a\udca4\ud8a3\udf54\ud901\udffb\uda66\udf8a\ud849\udddb\udb50\udf20\ud92d\udd23\uda89\ude90\udb0b\ude7f\ud9b0\udcc3\ud810\uddfa\uda4e\udd5e\uda32\ude17\uda79\udc01\uda1b\udcf2\udbff\ude99\udaf8\uddcb\ud9d4\udd6c\ud9fe\udf67\ud9fa\udd9a\ud9d6\udd19\ud8f0\udea3\ud999\ude12\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\u0ff3\u2508\u6658\u0cdf\u213c\u2f60\uc064\u735a\u717b\u2fb6\u73e4\ua24c\u5693\u86b5\ud55a\u51e7\u701a\u8590\ua8f8\ub8ab\u379f\u6636\u8282", "\udac1\ude2d\ud830\udc53\uda1f\udf27\ud9e9\udc9b\uda4d\ude8f\ud9de\udc4e\udbb7\udd56\ud9ab\udd7f\ud998\udd85\udbf6\udd2b",
        8, 30205, 1988319916, 5713240466801755470L, 37869L, true, false, (char) 3630, (char) 50666,
        Double.longBitsToDouble(0x3fc1398cac23fd90L), Double.longBitsToDouble(0x3fbeac6df23aa360L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 10, 1, 0, "", "\u87a0", "\ud849\udddb\u9bed",
        47, 1736, 1816860702, 62859036810280960L, 23997L, true, false, (char) 39157, (char) 38189,
        Double.longBitsToDouble(0x3fe17350698127c6L), Double.longBitsToDouble(0x3fc8c98353ab0374L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:                         |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 1, 1, "\u787a\udaf0\ude4c\uda15\udd61\ud951\udca1\uda2f\udfc3\ud849\udddb\udba1\udfe9\ud92d\udd23\ud998\udc3b\udb0b\udf43\uda91\udd13\ud810\uddf3\ud85c\udd65\udb2a\udeb4\uda6f\udd9f\ud9e4\ude28\udb2a\udf53\ud90e\udd85\udaca\udf36\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\uda5a\udd06\ud849\ude0a\ud800\udcd0\ud8a8\udd86\ud9b8\udfec", "\u3cf6\u0ff3\u61a2\u72f9\u0cdf\u9edc\u2f60\uc064\ubed1\u723b\u2fb6\u5855\ua24c\u5693\u86b5\ud55a\u51e7\u701a\u77a3\ua8f8\uc99a\ucd8b\u6d52\u1ca2", "\udac1\ude2d\ud9e7\udebf",
        24, 24976, 1691395819, -8525141692662053713L, -72265L, true, true, (char) 32892, (char) 63601,
        Double.longBitsToDouble(0x3fd4e4f49ee47836L), Double.longBitsToDouble(0x3fe75c92dae982c8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 1, 10, 13, "\u3080\udb86\ude7d\ud80f\udd01\ud92b\udc69\ud85d\udf1e\udba6\udfed\udb50\udf1f\ud92d\udd23\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda55\udd17\uda6f\ude01\udb2e\udcf4\u3618\ud810\udca3\ud84f\uddfd\uda8d\udc27\uda19\udd24\ud8a0\udcf0\ud814\udcf8\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\ud0f3\u58e1\u72f9\u0cdf\u9192\u2f60\ua7c3\u4d08\u7260\u5745\u6119\ua24c\u5693", "\ud82d\ude5d\uda64\ude1f\ud90a\udf6f\udb60\ude89",
        34, 72187, -984432001, -6036570471602072900L, 21588L, false, true, (char) 64744, (char) 40806,
        Double.longBitsToDouble(0x3fe03d6b640ecb88L), Double.longBitsToDouble(0x3fe07632a0441572L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 15, 2, "\ud9bb\udddf\uda12\udfd7\udb18\udfd4\u914e\uda6b\udd48\ud80f\uddde\udb50\udf1f\ud92d\udd23\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\ud8ca\udd04\uda6f\ude01\udb2e\udcf4\ud9e2\udf9d\ud810\udca3\udafa\ude54\ud9d9\udd0d\ud9fa\udd9a\ud9fa\udd4a\ud87f\udeb5\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec\ud9c2\udeee\ud805\udc94\ud9db\udcb3", "\u8bdd\u5ae7\u213c\u2f60\ua7c3\u4d08\u7260\u2fb6\u73e4\ua24c\u5693\u061f\ud55a\u51e7\u701a\u8590\ua8f8\ub89b\u3c2c", "\ud831\udd33\uda0e\udd1e\udaee\udd45\ud990\udcf2",
        6, 76345, 1692680939, -4155560156224893426L, 4408L, true, true, (char) 21609, (char) 39821,
        Double.longBitsToDouble(0x3febd77ad8c410d7L), Double.longBitsToDouble(0x3f9c41c9084c89e0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 5, 16, "\ud9bb\udddf\ud82f\udd83\ud827\udff5\ud931\udf0d\uda95\udcc2\udbdc\udf84\udb50\udf1f\udaf0\udc24\uda89\ude90\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\udb2e\udcf4\ud819\udee8\ud810\udccd\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud9fa\udd4a\ud87f\udeb5\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3cf6\ud0f3\u58e1\u72f9\u0cdf\u213c\u2f03\u7c45\u4d08\u7260\uaf25\u73e4\ua24c\u5693\u061f\ud55a\u51e7\u701a\u8590\ua8f8\u2bde\u3c2c\u64f8\u0b68", "\udaee\udd45\ud990\udcf2\udb0a\udecd\ud94d\ude57\ud838\udc81\udbd2\udca7\uda3b\udf51\ud9ca\udd0d\ud91b\ude45\uda31\udd84",
        -5, 7997, 2031982552, 5700237522032592206L, -54810L, false, false, (char) 62948, (char) 50321,
        Double.longBitsToDouble(0x3fe26534eff34eb0L), Double.longBitsToDouble(0x3fe8625395400a55L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 15, 1, "\udb2f\ude7d\u1cd2\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\uda95\udf5a\ud9b7\ude43\uda89\ude90\udb21\ude86\udb88\ude87\ud810\uddf3\uda4e\udd5e\uda32\ude17\uda6f\ude01\uda62\uddad\udb40\udc5a\ud810\udc58\ud84f\uddfd\u28c6\udb51\udca7\ud800\udcce\udb8f\udd97\udab8\ude00\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u03d7\u0ff3\u58e1\u72f9\u0cdf\u213c\u1f46\uc064\u8abc\u7260\u2fb6\u73e4\u39af\000\000\000\u51e3\u701a\u4f57\u0e73\ub89b\u3c2c\u64a6\u0b68", "\udac1\ude2d\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\uda9f\udd36\uda3b\udf60\ud9ca\udd0d\ud998\udd85\udbf6\udd2b",
        22, 7997, 2031982552, 5700237519683781966L, -74088L, true, true, (char) 3925, (char) 50321,
        Double.longBitsToDouble(0x3fe013ee19f34eb0L), Double.longBitsToDouble(0x3fd0c305aede14aaL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 4, 6, "\udb2e\udfef\u0790\ud827\udff5\ud931\udf0d\uda2f\udfc3\ud849\udddb\ud9a7\udded\ud92d\uddb6\ud8c7\udd98\udb0b\udc35\uda91\udd13\ud810\uddf3\ud804\udd77\ud8dd\ude3c\ud8e4\udf07\ud9a2\udebd\udbcb\udf3f\ud810\udc90\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud838\uddce\ud90f\udfa0\ud849\ude0a\ud800\udc63\uda25\udd1a\ud9b8\udfec\ud9c2\udeee", "\u0ff3\u04b9\u72f9\u0cdf\u85f8\u9b4e", "\ud99c\udcd7\ud8da\udf8a\ud9fd\ude64\udb60\udc2d\udb78\udc0b\udb3c\udda6\uca45\ud82d\ude5d\ud85e\udc9b\uda82\udcdf\udb60\ude89\ud9b6\udfce\ud9b4\udf93\uda8b\udebe",
        50, 28141, 1864419986, 8438214355605445827L, -69439L, true, false, (char) 37451, (char) 51096,
        Double.longBitsToDouble(0x3fb1055cbfc28ad0L), Double.longBitsToDouble(0x3fd519297753fb18L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 4, 8, "\udb2e\udfef\uda54\uddec\ud828\udc10\ud931\udf0d\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda99\udf5f\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda45\udf77\uda32\ude17\ud8e4\udf07\ud9a2\udebd\udbcb\udf3f\ud810\udc90\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3c69\u0ff3\u58e1\u72f9\u14d5\uc941\u4645\uc064\u8abc\u55ac\u0b15\u73e4\ua24c\u49c0\u86b5\ud55a\u076a\u7f15\u8590\u0bf9\ub89b\u3c2c\u64a6\u0b68", "\udac1\ude2d\ud990\udc4f\udb11\uddcd\ud94d\ude57\udbb7\udf31\uda9f\udd36\uda3b\udf60\ud9ca\udd0d",
        3, 50804, 287806377, 2724684292056520664L, 8812L, true, false, (char) 36477, (char) 1900,
        Double.longBitsToDouble(0x3fd51c0a88bccdf8L), Double.longBitsToDouble(0x3fec0650dc7fc5bfL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 11, 1, "\udb2e\udfef\u0790\ud9b8\udc1d\ud931\udf19\uda2f\udfc3\ud849\udddb\udb50\udf20\ud92d\udd23\uda99\udf5f\udb0a\udfb9\uda91\udd13\uda8c\uddb1\uda45\udf98\ud969\udd33\uda94\udec5\ud9a2\udea2\udbcb\udf3f\ud810\udc90\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u3c69\u0ff3\u58e1\u72f9\u0cdf\u213c\u2f60\uc064\u8abc\u55ac\u0b15\u73e4\ua24c\u7c06\u7cd9\ud55a\u51e7\u701a", "\udb2a\udcb5",
        37, 99444, -1355166940, -6734057141107111278L, 40129L, false, true, (char) 54020, (char) 4220,
        Double.longBitsToDouble(0x3fd9904b3c3bf2f6L), Double.longBitsToDouble(0x3fb1055cbfc06ad0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:                            |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 1, 2, "\udb2f\ude7d", "\u3623m\000\000\000\000\000\u20a0", "",
        27, 8775, 32461, 0L, -24024L, false, false, (char) 16739, (char) 251,
        Double.longBitsToDouble(0x3e3ef52800000000L), Double.longBitsToDouble(0x3ecd6c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:                |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 2, "\udb2f\ude7d\u0790\ud827\udff5\ud931\udf0d\ud8b1\udfc4\ud849\udddb\udb5a\uddc5\ud92d\udd01", "\u2000\u5f99\u265c\uceca\u8377\ucd1c\u7cd2\u9d66\u1c57\u95f3\u6aa2\u0da0\uae34\u77f9\u3754\u619d\ub491\u4a48\u2e15\u8ad5\u5998\u1d47\u72f9\ua313\u213c\u056e\u4f72\ub351\u2fa6\u26b4\ua71a\u7f56\u56cf\u5a1b", "\udbf6\uded3",
        15, 2746, 120412236, -3259848795322525132L, -88297L, false, false, (char) 57344, (char) 32966,
        Double.longBitsToDouble(0x3fe82ea3b7612805L), Double.longBitsToDouble(0x3fdb07324b320814L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 15, 5, "\ud860\udc15\u59db\u468b\uda4a\ude8c\uda2f\udffa\ud849\udddb", "\u3e59\u7db1\u20a0\u5f99\u9b5c\ucfe9\u8377\u5142", "\ud84f\uddfd\ud9d9\udd0d\ud9fa\udd9a\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec",
        2, 22257, 3886256, 1112421710088953161L, -21217L, true, true, (char) 18026, (char) 34276,
        Double.longBitsToDouble(0x3fce4ff9be49be2cL), Double.longBitsToDouble(0x3fec32688014d68cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 0, 1, "\ud851\udf15\u59db", "\000", "\udae2\udf5e\uda89\ude38\udb0a\udfb9\uda91\udd13\ud810\uddf3\uda4e\udd5e",
        15, 20159, 0, 7642036822268657527L, -24224L, false, false, (char) 20238, (char) 44410,
        Double.longBitsToDouble(0x3feb3bc7ebdea500L), Double.longBitsToDouble(0x3ecd600000000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 13, "\uda04\udc05\ud871\udc13\ud81d\udef5\ud873\udc8c\ud849\udd75\ud838\udf23\uda1d\udcff\ud948\ude71\uda89\ude90\ud8e5\udff3\ud95b\udcb2\uda17\uddf7\uda4e\udd5e\ud925\udf9d", "\u04aa\u4552\u7bb3\u82f5\u8575\u47bc\u4187\u678c", "\ud9b8\udfec\ud867\udf85\ud90a\ude04\ud93d\udd68\ud9ea\udd46\ud8e4\udefc\ud865\udc94\ua355\udafb\udd76\ud935\ude97\ud84e\udd02\ud897\udf5e\ud821\ude72\uda3a\udc5e\uda70\udf5d\ud9f0\udc1f\udb78\udc0b\udafc\udd19\ud842\udcd6\ud82d\ude5d\uda64\ude1f\ud90a\udf6f\udb60\ude89\udb2a\udcb5\uda87\udf7b\uda8b\udf30\ud96d\ude61\ud831\udd33\ud914\udc35\uda32\udce8\ud9ea\udfc5\udb11\ude2a\ud94d\ude57\udbb7\udf31\ud800\udc1b\ud8a6\udf35\ud9ca\udd0d\ud998\udd85",
        34, 34574, 634389997, -5907632767339311149L, 21028L, false, false, (char) 6033, (char) 20946,
        Double.longBitsToDouble(0x3fd728e5e21860b4L), Double.longBitsToDouble(0x3fee40512e36c398L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 1, 1, "\uda58\udfd3\ud871\udc2f\ud827\udff5\ud9a0\ude03\udb94\uddf4\ud82b\udf58\udb50\udf20\ud960\udd23\uda89\ude90\ud8e6\udc41\ud95b\udcb2\uda17\uddf7\uda4e\udd5e\ud925\udf9d\uda6f\udd8c\udb2e\udcf4\udbff\ude99\ud9b7\ude3f\ud8a3\udf4b\ud9d9\udd0d\udabd\ude65\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u687f\ud254\u8c3f\u2641\uc762\u0680\u2f0f\uc064\u8abc\u7260\u5ca4\u7367\ua24c\u5693\ub98d\uaf77\u51e7\u701a\u8590\ua8f8\ub89b\u90e3\u6518\u03e2\uc381\u9647\u7ca9\uc277\uc33d\ucb66\u7c7d", "\ud9ca\udd0d\ud998\udd85\udbf6\udd2b\udb15\udf80\ud83a\udf19",
        24, 69091, 1020731726, -1199259932250648710L, 40101L, false, false, (char) 59289, (char) 13805,
        Double.longBitsToDouble(0x3fe26e7cc0992f54L), Double.longBitsToDouble(0x3fdad53133eba65eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 1, 1, "\uda58\udfd3\ud871\udc2f\ud827\udff5\ud931\udf0d\udb94\uddf4\ud82b\udf58\udb50\udf20\ud960\udd23\uda89\ude90\ud8e6\udc41\ud95b\udcb2\uda17\uddf7\uda4e\udd5e\udae9\udf9f\uda6f\udd8c\udb2e\udcf4\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\udabd\ude65\ud800\udcce\ud90f\udfa0\ud869\udc0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u687f\ud254\u41fb\ub2b6\u2f36\u06df\u4923\u70a2\u4773\u6982\u2f94\u73e4\u0201\u5693\ub812\uaf77\u1819\u701a\u8590\ua8f8\ub89b\u06e4\u6518\u0b68\uaa9d\u4622\u7ca9\uc277\uc33d\ucb66\u7c7d", "\ud9ca\udd0d\ud998\udd85\udbf6\udd2b\udb15\udf80\ud953\udf99",
        15, 57110, 1020731726, -1199259933865008956L, 40101L, false, true, (char) 55653, (char) 58508,
        Double.longBitsToDouble(0x3fede5fa9366f148L), Double.longBitsToDouble(0x3feeb9afa1f5d32fL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 1, 15, "\ud845\udd4f\ud837\udf9e\ud827\udff5\ud931\udf0d\udb94\uddf4\ud82b\udf58\udb50\ude9b\ud960\udd23\uda89\ude90\ud8e6\udc41\ud95b\udcb2\uda17\uddf7\uda4e\udd5e\ud925\udf9d\uda6f\udd8c\udb2e\udcf4\udac7\ude75\ud83f\udc08\ud84f\uddfd\ud9d9\udd0d\udabd\ude65\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u687f\ud254\u41fb\ub2b6\u2f36\u06df\u2ea0\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\ub812\uaf77", "\ud90a\udf6f\udb60\udf22\udb2a\udcb5",
        4, 91110, -1355166940, -6734057143623693678L, 32566L, false, true, (char) 40881, (char) 7439,
        Double.longBitsToDouble(0x3fd9904b3c3bf2f6L), Double.longBitsToDouble(0x3fb1159cbfc06ad0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 1, 1, "\uda58\udfd3\ud871\udc2f\ud827\udff5\ud931\udf0d\udb94\uddf4\ud82b\udf58\udb50\udf20\ud960\udd23\uda89\ude90\ud8e6\udc41\ud95d\udf15\udba2\udfd8\ud8ff\udd48\ud925\udf9d\uda6f\udd8c\ud8e6\udcf0\udbff\ude99\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\udabd\ude65\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u687f\ud254\u1050\u5eeb\u5a22\u06df\u2f0f\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\u2191\uaf77\u522e\u701a\u8590\ua8f8\ub89b\u06e4\u6518\u0b68\uc3f1\u9647\u7ca9\uc277\u9f0f\u9148\u7c7d", "\ud9ca\udd0d\ud998\udd85\udbf6\udd2b\udb15\udf80\ud9b8\udc27",
        11, 83520, 1020731726, -1199259932250643932L, 40101L, false, true, (char) 10405, (char) 30798,
        Double.longBitsToDouble(0x3fe26e7cc0992f54L), Double.longBitsToDouble(0x3fdad53133eba65eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 1, 0, "\uda58\udfd3\ud871\udc2f\ud827\udff5\ud931\udf0d\udb94\uddf4\ud82b\udf58\udb50\udf20\ud960\udd23\ud9e8\ude85\ud8e6\udc41\ud95b\udcb2\uda17\uddf7\uda4e\udd5e\ud925\udf9d\uda6f\udd8c\udb2e\udcf4\udbff\ude99\udaf3\udc38\ud8cd\udc39\ud9ee\udf0b\udabd\ude65\ud800\udcce\ud90f\udfa0\ud849\ude0a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec", "\u8984\ud1bf\u41fb\ub2b6\u2f36\u06df\u2f0f\uc064\u8abc\u7260\u2fb6\u73e4\ua24c\u5693\ub812\uaf77\u51e7\u701a\u8590\ua8f8\ub710\u745f\ua01a\u0b68\u30ea\ub07c\u7d2b\ud577\uc33d\ucb66\u7c7d", "\ud9ca\udd0d\ud88d\udf5e\udb58\udd0f\udb22\udf41\ud9b8\udc27",
        27, 77942, 1020731726, -1199259932250648710L, 40101L, false, true, (char) 55653, (char) 49068,
        Double.longBitsToDouble(0x3fe26e7cc0992f54L), Double.longBitsToDouble(0x3fdad53133eba65eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 1, 1, "\ud81f\ude0f\ud970\udc77\ud827\udff5\ud931\udf0d\udb94\uddf4\udaf6\udc5c\udb5f\uddbf\ud869\udf69\udb14\udc9d\uda82\udf50\ud94b\ude0e\udae6\udd6e\uda4e\udd5e\ud925\udf9d\uda6f\udd8c\ud8e7\udccd\ud914\ude9d\ud810\udc86\ud84f\uddfd\ud9d9\udd0d\udabd\ude65\ud800\udcce\ud90f\udfa0\udbbe\udc03\ud800\udcd0\ud8b3\udd55\ud9b8\udfec", "\u687f\ud254\u41fb\ub2b6\u0afa\u064a\u2f0f\uc064\u8abc\u7260\u2fb6\uc75b\ua24c\u5693\ub812\uaf77\u51e7\u701a\u8590\ua8f8\ub89b\u06e4\u6518\u0b68\uc3f1\u9647\u7ca9\uc277\u484f\ucb66\u7c7d", "\ud9ca\udd0d\ud998\udd85\udbf6\udd2b\udb15\udf80\ud9b8\udc27",
        30, 69091, 1020731726, -1199259932250648710L, 40101L, false, true, (char) 55653, (char) 22861,
        Double.longBitsToDouble(0x3fe26e7cc0992ff9L), Double.longBitsToDouble(0x3fdad53133eba65eL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 1, 1, "\ud8a9\uddb7\ud858\ude6f\ud827\udff5\ud931\udf0d\udb94\uddf4\ud82b\udf58\udb50\udf20\udad2\udd1c\uda89\ude90\ud8e6\udc41\ud95b\udcb2\ud861\udfbc", "\u9635\u5142\u460c", "\ud9d9\udd0d\udabd\ude65\ud800\udcce\ud947\udc73\ud854\ude6a\ud800\udcd0\ud8a8\uddbd\ud9b8\udfec\ud867\udf85\ud8d2\ude89\ud93d\ude43\ud9ea\udd46\ud8e4\udefc\ud865\udc94\ua355\udafb\udd76\ud935\ude97\ud84e\udd02\ud0cc\ud805\uddaa\uda3a\udc5e\uda70\udf5d\ud9f0\udc1f\udb78\udc0b\udafc\udd19\ud842\udcd6\ud82d\ude5d\uda64\ude1f",
        12, 2746, 117659724, -7715337092396426586L, -88405L, false, false, (char) 65119, (char) 45541,
        Double.longBitsToDouble(0x3fee794bb7612805L), Double.longBitsToDouble(0x3fe75bb1259904b3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptSeparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
