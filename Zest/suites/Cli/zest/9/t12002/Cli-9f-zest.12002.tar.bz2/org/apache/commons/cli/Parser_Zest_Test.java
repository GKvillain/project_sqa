package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Parser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 9, "\uda07\udd72\udbce\udf32", "\u1b46\ubbf5\u76d2\u85ba", "\ud928\udc87\uda9b\ude3f\udbac\udfaa\uda01\ude9b\udb36\udf3c\udb5f\udc06\ud896\udc65\uda84\udfc1\udbeb\ude74\udb5d\ude9c\u1d0e\ud95f\udef3\udb26\udecb",
        22, 74289, -1862182079, -5662933138351415113L, -4518L, false, true, (char) 59083, (char) 19705,
        Double.longBitsToDouble(0x3fd5d5085856b6c8L), Double.longBitsToDouble(0x3f9acc31cbd371c0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 3, 0, 9, "\uda07\udd72\udbce\udf32", "\u1b46\ubbf5\u76d2\u85ba", "\ud928\udc87\uda9b\ude3f\uda36\udfaa\uda01\ude9b\udb36\udf3c\udb5f\udc06\udbd0\udfa2\uda41\udd38\udbc6\udc34\udb5d\ude9c\u1d0e\ud95f\udef3\udb26\udecb",
        22, 74289, -1862182079, -5662933138351415113L, -4518L, false, true, (char) 59083, (char) 19705,
        Double.longBitsToDouble(0x3fd5d5085856b6c8L), Double.longBitsToDouble(0x3f9acc31cbd371c0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 8, 5, "\uda57\udf69\udb4d\udf30", "\u0088\ubbdc\u76d2\u85ba", "\ud928\udc87\uda9b\ude3f\ud8a9\udde8\uda01\uddfc\udb36\udf3c\udb5f\udc06\ud896\udc65\uda84\udfc1\udbeb\ude74\udb5d\ude9c\u3652\ud95f\uddfc\udb26\udecb",
        22, 6993, 0, -5662995056441646921L, -100000L, false, true, (char) 12747, (char) 19705,
        Double.longBitsToDouble(0x3fd5d5085856b6c8L), Double.longBitsToDouble(0x3f9acc3100000000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 1, "\ud834\udc6a\udaf8\udcd6", "\u7beb\u9b19\u6758\u85ba\u7978\ud284\u8ae4\ub3a8\uc9c7\u8503\ub915\uc59d", "\ud849\udfda",
        59, 50728, 1988792311, -1949559030021196508L, -11103L, false, true, (char) 868, (char) 65168,
        Double.longBitsToDouble(0x3fe8340f97acfffeL), Double.longBitsToDouble(0x3fd01232566a4388L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 10, "\uda07\udd72\udbce\udf32", "\u1b46\ubbf5\u76d2\u85ba", "\ud928\udc87\uda9b\ude3f\udbac\udfaa\uda01\ude9b\udb36\udf3c\udb5f\udc06\ud896\udc65\uda84\udfc1\udbeb\ude74\udb5d\ude9c\u1d0e\ud95f\udef3\udb26\udecb",
        22, 74289, -1862182079, -5662933138351415113L, -4518L, false, true, (char) 59083, (char) 19705,
        Double.longBitsToDouble(0x3fd5d5085856b6c8L), Double.longBitsToDouble(0x3f9acc31cbd371c0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 9, "\uda07\udd72\ud936\ude45\udba5\udc14\ud9eb\udc38\udb8f\udfd3", "\uad18\ucb5b\u2e5e\u740e\u697d\uc9c7", "\udb5f\udc06\ud896\udc65\uda84\udfc1",
        19, 19644, -1317578021, 8541797933827316836L, -48880L, true, false, (char) 65286, (char) 3320,
        Double.longBitsToDouble(0x3fdb2fffe2cb6accL), Double.longBitsToDouble(0x3fe9a90e255d5085L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 8, 5, "\uda07\udd6b\udbce\udf32", "\u16fd\ubbeb\u4aed\u8629", "\ud928\udc87\uda9b\ude3f\udbac\udfaa\uda01\ude9b\udb36\udf3c\udb5f\udc06\ud896\udc65\uda84\udfc1\udbeb\ude74\udb5d\ude9c\u1d0e\ud95f\udef3\udb98\udc24",
        42, 97251, -1848263299, -5662933138351415113L, -4518L, false, true, (char) 52177, (char) 19705,
        Double.longBitsToDouble(0x3fd5d5085284d4c8L), Double.longBitsToDouble(0x3f9acc5b7eb371c0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 5, 4, "\uda07\udd72\udb41\udf2d", "\u1b46\ub8ff\u76e1\u44cc", "\ud9a6\udea6\ud973\udd0e\udba0\udc28\uda01\ude9b\udbd7\udd89\udb3d\udfa7\udbb5\udc20\ud8f3\uddd9\udbb7\udd94\udb7d\udc3c\u2cc6\ud95f\udef3\udb26\udecb",
        22, 74289, -1851375551, -5662933141455200073L, -4753L, false, true, (char) 59083, (char) 19705,
        Double.longBitsToDouble(0x3fc8aa10b1ea2bc8L), Double.longBitsToDouble(0x3f9a9804cbd371c0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 8, 9, "\uda07\udd19\uda94\udcf5", "\u2a07\ubbf5\u76d2", "\udada\udd14\ud928\udc87\udaa6\ude83",
        12, 70831, 444619181, -4504734643206109325L, -30238L, false, true, (char) 56650, (char) 573,
        Double.longBitsToDouble(0x3fb91da29162bf88L), Double.longBitsToDouble(0x3fec44e908672528L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 9, "\uda07\udd72\udbce\udf32\udba5\udc14\ud9eb\udc38\udb6f\uddc3\udaea\udf6d\ud9fb\udd38\ud9fb\uddab\ud9b0\udf76\udada\udd0e\ud928\udc87\uda9b\ude3f\udbac\udfaa\uda01\ude9b\udb36\udf3c\udb5f\udc06\ud896\udc65\uda84\udfc1\udbeb\ude74", "\ucc75\u6c52\ua0e8\uc87c\ua7b3\u132b\u5ad2\u0bdb\u3b04\u8d47\u216a\ubaa3\u89ae", "\ud88f\udd20",
        27, 83180, -1110550101, 3705129589117464076L, -81640L, false, false, (char) 49197, (char) 36240,
        Double.longBitsToDouble(0x3fd3d57a26c19302L), Double.longBitsToDouble(0x3fe223cb2ef071b0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 4, "\uda07\udd72\udbce\udf32", "\u1b46\ubbf5\u76a9\u85ba", "\u555e",
        -5, 24360, -857923169, 1909624840520464310L, -69840L, false, true, (char) 59914, (char) 56650,
        Double.longBitsToDouble(0x3fefbb923464768aL), Double.longBitsToDouble(0x3fd24e4f12b33bdcL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 9, "\ud9bb\udd14\ud86a\udfba", "\u1b46\u8aa7", "\uda79\udcd6",
        54, 43531, 1716660280, -2679855239017979489L, -4304L, false, true, (char) 14090, (char) 56491,
        Double.longBitsToDouble(0x3fd4a639d8c96462L), Double.longBitsToDouble(0x3fd24e4f12b33bdcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 9, "\uda07\udd72\udbce\udf32", "\u1b46\ubbf5\u76d2\u85ba", "\ud928\udc87\uda9b\ude3f\udbac\udfaa\uda01\ude9b\udb36\udf3c\udb5f\udc06\ud896\udc65\ud824\udc4f\udbcd\udf95\udb5d\ude9c\u1d0e\udb99\udfd1\udb49\udcfc",
        22, 74289, -1862182079, 1038423103312612505L, -4601L, false, true, (char) 59083, (char) 19705,
        Double.longBitsToDouble(0x3fd5d5085856b6c8L), Double.longBitsToDouble(0x3f9acc31cbd371c0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 6, 9, "\uda07\udd72\udbce\udf32", "\u87e4\ubbf5\u0300\u3dc8\u3d88\u34c8", "\udbac\udfaa\uda01\ude9b\ud82c\udfb7\uda78\udeeb\ud95d\udc22\ud97d\uddba\udbeb\uded8\udb5d\ude80\u1d0e\ud95f\udef3\udb26\udecb\ud9cd\udf5c\ud924\udfc2\udac7\uddae\ud94a\udfae\ud85b\udf2f\ud908\uddd3\udba2\udf05\uda1c\udd4c\ud988\udf62\udbbc\udd6c\udb24\udebf\ud98a\udd1d\uda71\udf8c\ud81e\ude08\uda52\uddeb\udb46\uddbe\udaf7\ude2f\ud944\udd26\udbb4\udf09\udbf3\uddcd\ud9c5\udc46\ud8c7\udd40\ud94e\udef2\ud842\ude4b",
        22, 32392, 1141306754, -1777494539875247704L, -42498L, false, true, (char) 62562, (char) 8095,
        Double.longBitsToDouble(0x3fe1ec7203145ea0L), Double.longBitsToDouble(0x3fe841002771310dL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 1, "\uda93\udd87\udb4e\udc80\ud813\udc18", "\u70ea", "\ud88b\udec0",
        26, 62006, -359218523, -2679855237424143969L, -73431L, false, true, (char) 57286, (char) 28902,
        Double.longBitsToDouble(0x3fd95e4f12b33a0aL), Double.longBitsToDouble(0x3fea083030509101L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda07\udd72]] |a1=[Ljava.lang.String;:[[\uda07\udd72]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 1, 4, 9, "\uda07\udd72", "\u7f5f\u5c17\ub071\u4d2a\u4b3b\u938d\ua67c\ub1ce\u7c2f\u7d4c\u5424\ua5ca\u27cb\u724b\u70d9", "\u1d0e\udb0b\ude61\udb26\udecb\ud9cd\udf5c\udb0d\uddb5\ud9c1\udd20\udb39\udcb1\udbea\udc7e",
        -1, 99441, -1251566191, 6444986852956253093L, 17547L, true, false, (char) 52528, (char) 25453,
        Double.longBitsToDouble(0x3fe30d9b578832b3L), Double.longBitsToDouble(0x3fd56281dacc40b2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 7, "\uda07\udd72\udbce\udf32", "\u1b46\ubbf5\u76d2\ua5ae", "\ud928\udc45\uda9b\ude3f\udbac\udfaa\uda01\ude9b\udb36\udf3c\udaea\udd4b\ud896\udc65\uda84\udfc1\udbae\uddc8\udb5d\ude9c\u1d0e\ud95f\udef3\udba5\ude2b",
        11, 74289, -1862182079, -5662933138351415113L, -4518L, false, true, (char) 59083, (char) 19705,
        Double.longBitsToDouble(0x3fe93f8c2c2b5b64L), Double.longBitsToDouble(0x3fdb6a631cbd37a6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 9, "\udbaf\udee7\000", "\u1b46", "\000",
        27, 47703, 0, 7349874591244697052L, 45549L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4fddc918000000L), Double.longBitsToDouble(0x3fb91da2a9272000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 9, "\udbad\ude02\udbce\udf32", "\u2553\ubbf5\uabdb\ub91b\u9c2c\u94e0\ua0dc\u37bb\u885b\ub829\ub915\uc59d\u88c0\u7fda\u4b90\u4257\u3dc2\ucc75\u6c52\ua0e8\uc87c\ua7b3\u132b\u5ad2\u0bdb\u3b04\u8d47\u216a\ubaa3\u89ae\u3ec4\u710e\u604e\ua0c3\u3ad4\uc376\u223c\u6c0f\u3e26\u0704\ua61c\u027d\u91db\uaa58n\u38a3\ub9e1\u73f7\ucb9b\u82a7\u28fc\u426b\u033b\ua000\u6191\u52fa\u1206\u7617\u7465\ua7ca\u8b30\u0375\u7b6b\u1701\uccca\u7317", "\u9ff1",
        40, 97065, 13073414, 5648455542678602501L, -28200L, false, false, (char) 17032, (char) 24009,
        Double.longBitsToDouble(0x3fedafe14a0a3b9bL), Double.longBitsToDouble(0x3fb4fb383c5f3ac8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 5, "\u76df", "", "\udae6\udef6",
        36, -1000, -1627853704, -6315526351018961570L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe2900007f70000L), Double.longBitsToDouble(0x3f3d802920000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 9, "\uda12\udd01\udaa7\ude3f", "\u1b46\u446e\u2e0a\ua1da\u9524\uc596\ud445", "\uda01\ude9b\udb36\udf3c\udb5f\udc06\ud896\udc65\uda85\udc5e\udbeb\ude74\udb5d\ude9c\u1d0e\ud95f\udef3",
        1, 73160, 101075289, -7984131991289039536L, 68257L, false, true, (char) 40065, (char) 59083,
        Double.longBitsToDouble(0x3fd355b2ec9883a2L), Double.longBitsToDouble(0x3fa5add981acc310L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 1, 4, 5, "\uda28\udef4\udbce\udf32\udba5\udc14\ud9c5\ude38", "\u76d2\u85ba\u7978\u2e5e\u7d04\uc1e4\u13e3\u8503\ub955\u746b\u736c\u5635\ud527\ud096\u3dc2\ucc75\u6c52\u26ef\u4d5b\u0159\u135d\u6a27\u0bdb\u6a0c\u8d47\uc66a\u5299\u89ae\u3ec4\u710e", "\uda71\ude71\udb0d\udf6c\ud9b7\ude87\ud8a3\udd80\ud9ee\udc7b\ud8e4\udd24\ud97a\udd52\ud936\udc85\ud936\udfee\ud8f1\udc46\ud9bc\udd0c\ud9e7\udc54\udb27\udff8\udb29\udd7a\ud947\udf28\ud8b5\udcef\ud8a4\ude27\ud93e\udc84\uda5c\udf87\ud9a3\udcd0\ud9ed\udd3e\uf1d4\ud8a0\udcd6\ud963\udd35\uda2d\udf27\ud93f\udff5\u550e\ud8da\ude99",
        16, 38647, 35758184, 5914174683026208013L, -17315L, true, false, (char) 44174, (char) 62586,
        Double.longBitsToDouble(0x3fd27cb7deeb9234L), Double.longBitsToDouble(0x3fee67958b5d9ed3L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda07\udd72\udbce\udf32]] |a1=[Ljava.lang.String;:[[\uda07\udd72\udbce\udf32]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 9, "\uda07\udd72\udbce\udf32", "\u6d80\u222e\u76d2\u85ba", "\ud928\udc87\uda9b\ude3f\udbac\udfaa\uda01\ude9b\udb36\udf3c\udb5f\udc06\ud896\udc65\uda84\udfc1\udbeb\ude74\udb5d\ude9c\u1d0e\ud95f\udef3\udb26\udecb",
        27, 74289, -1862182079, -5662933138351415113L, 86106L, false, false, (char) 6210, (char) 19705,
        Double.longBitsToDouble(0x3fd5d5085856b6c8L), Double.longBitsToDouble(0x3f9acc31cbd371c0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 0, 5, "\uda07\udd33\udb22\udf24", "\uc155\ubc0b\ub283\u857f\uae36\u56ca\u507b\u6a05\uc9c7\u8503", "\udb45\udf08\ud8fd\udea0\ud9f0\uddd3\uda23\udeb7\ud8f6\udfca\udbca\udcbf\udb26\udecb\ud9cd\udf5c\udb88\uddb3\ud9c1\udcb6",
        15, 47318, 381544294, -441343500968526L, -23403L, true, true, (char) 61321, (char) 37963,
        Double.longBitsToDouble(0x3fe2f4dc72f1c1e0L), Double.longBitsToDouble(0x3fef0c55ac712b34L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 10, 10, 4, "\ud9e8\ude80\ud824\udc93\ud852\udeb7\ud809\udd02\ud88c\udc45\ue917\uda19\udd33\ud9fb\uddab\ud88b\udec0", "\u697d\uc9c7\u267d\u275b\uc59d\u8995\u88f7\u4b90\u4257", "\udb26\ude91\ud9cd\udf5c\udb88\uddb3\uda34\udebf\ud94a\udfae\ud85b\udf2f\ud908\uddd3",
        19, 24842, 566505829, 5802091203103323485L, -20154L, false, false, (char) 41973, (char) 91,
        Double.longBitsToDouble(0x3fcc80d972861350L), Double.longBitsToDouble(0x3faa99feb29efff0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 3, 0, 9, "\uda07\udd72\udbce\udf32", "\u1b46\ubbf5\u76d2\u85ba", "\ud928\udc87\uda9b\ude3f\udbac\udfaa\uda01\ude9b\udb7d\udc1f\udb5a\udfdb\ud896\udc65\uda84\udfc1\udb07\udfa3\udbe9\ude90\u1d0e\ud808\udfbf\ud828\uddbe",
        33, 18993, 1571761821, -5662933138351415113L, -4518L, false, true, (char) 59083, (char) 41976,
        Double.longBitsToDouble(0x3fd5d5085856b6c8L), Double.longBitsToDouble(0x3f9acc31cbd371c0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\000", "", "",
        7, -959, 2013265920, -6991578422822912449L, 20776L, false, false, (char) 0, (char) 22784,
        Double.longBitsToDouble(0x3fedb0d40773c17bL), Double.longBitsToDouble(0x3fe184426f7e92dfL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 8, "\udbc7\udc93\ud89d\udc32\uda54\ude0c\ud993\udc0c\ud9ad\udd77\uda3e\udc88\ud9fb\udd38\ud9fb\uddab", "\uc7ad\u699d\u115e\u6529\u544c\u7574\u99f2\u82dc\u3a4e\u9424\u3dc2\u2527\u6c52\u163f\u99eb\ub1be\u132b\u6fb3\u1b12", "\udbd0\udd06\udbaa\udf14\udaee\udd1b\ud988\uddbe\ud9b3\ude30\ud867\ude35\ud956\udef6\ud876\udd56\ud81c\udd13\udb4c\udc4b\udbd7\udf3e\ud8cc\uddde\ud860\udefc\udb9c\udee5\ud95b\uddfc\udb7b\udf8e\uda6f\udda4\u640b\ud9ae\udc0c\ud915\ude54\ue3ce\udb81\ude2a\ud931\ude5f\u1a0e\udaec\udf6d\ud9d1\udf52\uda97\udf73\ud88e\udc23\uda3b\uddb5\uda36\udc6f\uda7c\ude31\uda80\udc98\ud951\ude59\udb8b\udf34\udb3d\udf3c\ud8cf\udec2\u55d9\uda39\udce9\ud8fd\ude4a\ud964\udc41\udae0\udd6b\ud872\udf18\ud9de\udc2c\ud837\ude03\ud851\ude7b\uda5a\udcb7\ud9f5\udcaa\ud94e\udfc8\udbc2\udc76\udbd4\udc81\uda98\ude99\udb0b\udc6b\uda7f\ude86\udb67\udd01\udb37\udf22\ud95d\udf78\ud87b\udd9a\ud87a\udf6a\ud84d\udc5e\ud9f5\udce1\udb70\udf4f\ud849\ude80\udb5f\udf1b",
        7, -455, 468073758, 4462190653756507090L, -17876L, false, false, (char) 61355, (char) 11569,
        Double.longBitsToDouble(0x3fda049ee81d18e8L), Double.longBitsToDouble(0x3fc5f3c7cd5074f0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 8, 5, "\uda57\udf69\udb4d\udf30\udba5\udc14\ud9eb\udc38\u0088\udae6\udedd\ud9fb\udd38\ud9fb\uddab\ud88b\udec0\udada\udd14\ud928\udc87", "\u8464\ub915\uc59d\u8995\u70d9\u4b90\u4257\u3652\ucb7e", "\ud954\udd59\000\ud93c\udf5e",
        58, -1000, 0, 28883071516553573L, -42962L, true, true, (char) 48423, (char) 16791,
        Double.longBitsToDouble(0x3fcf8a62444d2ad0L), Double.longBitsToDouble(0x3fdbc775d68080ceL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda07\udd72\ud936\ude45\udba5\udc14\udba0\ude73\udb31\udcd1]] |a1=[Ljava.lang.String;:[[\uda07\udd72\ud936\ude45\udba5\udc14\udba0\ude73\udb31\udcd1]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 11, "\uda07\udd72\ud936\ude45\udba5\udc14\udba0\ude73\udb31\udcd1", "\uad06\ucb5b\u2e5e\u627a\ub755\u9903", "\udb5f\udc06\ud896\udc65\uda66\uddb8",
        32, 19644, 1757525467, 8541797117984857188L, -41209L, true, true, (char) 51669, (char) 20934,
        Double.longBitsToDouble(0x3fd416dc66eca504L), Double.longBitsToDouble(0x3fe3c26ffc3489eeL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda07\udce2\ud936\ude45\udb85\udd14\ud896\udc6f\uda29\udeb0]] |a1=[Ljava.lang.String;:[[\uda07\udce2\ud936\ude45\udb85\udd14\ud896\udc6f\uda29\udeb0]] |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\uda07\udce2\ud936\ude45\udb85\udd14\ud896\udc6f\uda29\udeb0]] |a1=[Ljava.lang.String;:[[\uda07\udce2\ud936\ude45\udb85\udd14\ud896\udc6f\uda29\udeb0]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 11, "\uda07\udce2\ud936\ude45\udb85\udd14\ud896\udc6f\uda29\udeb0", "\u6504\ucb7a\ubef6\u0d27\u2ea4\ubb7c", "\udb5f\udc06\ud838\udc56\ud837\ude58",
        19, 73124, -277222809, 8560147915707538532L, -21087L, true, false, (char) 18093, (char) 40927,
        Double.longBitsToDouble(0x3febe94a0165b5b0L), Double.longBitsToDouble(0x3fe9a90e215d5085L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 9, "\uda00\udf6d\udbe8\udef6\ud998\udff5\ud880\udea7\ud9da\udf7e", "\u6fe1\u0ae6\u9ec8\u4309\ua5b9", "\ud802\udec7\udbab\udc62\ud8d7\udd48\ud934\udfda\udbeb\ude74\ud9d8\udd89\udb4c\ude1d\ud888\udcb4\udb26\udecb\ud9cd\udf5c\ud85c\udcfd",
        13, 7466, -342985937, 6018072046954234063L, 80095L, false, false, (char) 51580, (char) 37035,
        Double.longBitsToDouble(0x3fead8e0d6292d51L), Double.longBitsToDouble(0x3f90d2d7e629f0a0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 9, "\uda07\udd72\udb0c\ude90", "\ubd7a\ubf7e\u76d2\u85ba", "\uda5c\ude40\uda9b\ude3f\udbac\udfaa\uda01\ude5f\udb36\udf3c\ud9d0\udedb\ud896\udc95",
        42, 34590, -1493666865, 1749145231061276050L, 1084L, true, true, (char) 24903, (char) 51537,
        Double.longBitsToDouble(0x3fc321cd3f9a1e04L), Double.longBitsToDouble(0x3fda806318b67b40L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 9, "\uda07\udd72", "\u7f5f\u9b5f\ub071\u4d2a\u4b3b\u938d\ua67c\ub1ce\u7c2f\u7d4c\u5424\ua5ca\u2c74\u88b6\ubfe9", "\u1d00\udb0b\ude61\udb26\udecb\ud9cd\udf5c\udb0d\uddb5\ud9c1\udd20\udb39\udcb1\udbea\udc7e\udb0b\udd1e\udbbf\udd03\uda1c\udd2b\ud959\udeaa\udb0a\udc63\udb24\udebf\ud90f\udcb8\ud905\udd7f\ud95c\udf36",
        11, 32841, 673021832, 2330979312339799398L, -38402L, true, true, (char) 60308, (char) 2523,
        Double.longBitsToDouble(0x3fc21ee7c2833f00L), Double.longBitsToDouble(0x3fe71e070f2d8618L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 2, 7, "\uda07\udd72\udbce\udf32", "\u1b86\ubbf5\u76d2\ua5ae\u7e3b\u2e5e\u73cc\u697d\u9795\u00f5\ub90c\u1796\u7563\uc576\u9aee\u4257\u3dc2", "\ud9cd\udf51\udb88\uddb3\ud9c1\udcb6\ud94a\udfae\udba6\ude29\ud9fd\udfa5\udba2\udf05\uda1c\udd4c\ud988\udf62\ud934\udf37",
        37, 16755, -1680617034, 3905226013723325265L, -63080L, true, false, (char) 36346, (char) 13511,
        Double.longBitsToDouble(0x3fd21f02cff42d6cL), Double.longBitsToDouble(0x3feba62db3bd613fL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud94e\udeca\udbb0\udd3e\ud92c\ude1b\ud9d7\udd53\udb8f\udf5b]] |a1=[Ljava.lang.String;:[[\ud94e\udeca\udbb0\udd3e\ud92c\ude1b\ud9d7\udd53\udb8f\udf5b]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 7, "\ud94e\udeca\udbb0\udd3e\ud92c\ude1b\ud9d7\udd53\udb8f\udf5b", "\ua5ae\u7978\u2e5e\u73cc\u697d\u0b11", "\udb8c\ude3c\ud986\udf25",
        33, 17702, -1493666852, 8234328503224012791L, 44333L, false, true, (char) 45413, (char) 51537,
        Double.longBitsToDouble(0x3fc526aec105b718L), Double.longBitsToDouble(0x3fe0340c80b2fffeL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 2, "\uda07\udd72\udbce\udf32", "\u7cb6\u2227\u76d2\u9e5d", "\ud928\udc87\uda9b\ude3f\udbac\udfaa\ud9f0\udcb2\udb36\udefe\udb5f\udc06\ud896\udc65\uda2e\udfb6\udb05\udd22\ud932\udc5f\udbd6\udf86\ud83f\udea0",
        15, 52095, 101075289, -7998011129820792752L, 68257L, false, true, (char) 13907, (char) 6210,
        Double.longBitsToDouble(0x3fe9a90e255d5085L), Double.longBitsToDouble(0x3fa5adb201acc310L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 9, "\uda07\udd72\udbce\udf32", "\u1b46\ubbf5\u76d2\u85ba", "\ud928\udc87\uda9b\ude3f\ud9a1\udfe6\uda08\uddf6\udb36\udf3c\udb5f\udc06\ud896\udc65\uda84\udfc1\udbeb\ude74\udb5d\ude9c\ud803\udc4c\ud93e\udd53\udb26\udecb",
        22, 74289, -1862182079, -5662933138351415113L, -4518L, false, true, (char) 59083, (char) 19705,
        Double.longBitsToDouble(0x3fd5d5085856b6c8L), Double.longBitsToDouble(0x3f9acc31cbd371c0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 1, "\uda57\udf69\udb4d\udf30\udba5\udc14\ud9eb\udc38\u0088\udaca\udcdd\ud9fb\udd38\ud9fb\uddab\ud88b\udec0\udada\udd14\ud928\udc87\uda9b\ude3f\ud8a9\udde8\uda32\udefc\ud94e\udf08\udaa8\ude16\udb8e\udf1a\uda84\udfc1\udbeb\ude74\udb69\udd0d\udaf7\udc45\ud941\ude15\udb26\udecb\ud9cd\udf5c\ud954\udd59\000\ud93c\udf89\ua0b7\000\000\ucd06\ud988\udf62\uda20\ude3e\udae1\udfc7\ud930\udee9\udbeb\udd0d\uda8a\ude95\ud847\udefe\ud893\udd10\ud823\udeb9\ud843\udece\udaf8\udc42\ud990\udee7\ud930\udc75\udb21\udebd\ud8f1\udf10\udbf8\udf1d\ud86e\uddf5\uda00\uddcf\u3ca6\ud9fa\ude1c\udac3\ude0a\ud81c\udf95\ud9df\ude20\udb4a\udc99\udbe5\udd2f\udb38\udd4c\udb3a\udf6f\ud958\udeeb\ud912\udfea\udbee\udf20\udb7a\udc71\udbb6\ude71\udaf9\udfdd\ud912\udf11\uda63\udc63\uda65\uddb7\udb9b\udd89\uda3e\ude73\ud820\udcff\ud950\ude69\udaff\udc28\u5bbe\ud8b5\udf06\ud89e\udc7a\udbff\udda1\udaf0\udd4e", "\u2aa6\u79da\u1699\u7312\ub4bc\u793b\u6034\u90ec\u7df2\u1c2a\u0fd1\ud09c\u81f2\uac43\ud1c0\u09b1\u2dc2\u6c41\u6d4e\u61fc\u3b7d\u94b4\u8efe\ub4db\u849f\u5602\u6a4d\u4822\ua577\uac8a\ub921\u3348\u23c5\u75fd\u6012\u291e\u7b60", "\ud8de\udc6d\udac7\udf51\uda0f\uded6\udaa4\ude64\udbed\udc0d\ud82d\udcf9\uda08\ude78\ud9f0\uddb8\ud9d3\udeec\ud998\udeec\ud89a\udcea\ud8ad\udd31\ud8bb\udd72\udb62\udf0b\udbf3\udf27",
        49, 29184, -219099359, -5402767010803704806L, -99050L, false, true, (char) 32792, (char) 58120,
        Double.longBitsToDouble(0x3fed95d61db211e6L), Double.longBitsToDouble(0x3fd2cd0ce38d2ee6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processArgs|org.apache.commons.cli.Option,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processOption|java.lang.String,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|setOptions|org.apache.commons.cli.Options|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
