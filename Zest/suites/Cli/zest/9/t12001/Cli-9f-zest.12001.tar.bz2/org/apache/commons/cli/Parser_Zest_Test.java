package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Parser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\uda9a\udc0a", "\uc1e1\u22f6\u2dba", "\ud877\udc84\udae2\udf35\ud9cc\udd89",
        28, 69257, 477552031, 7775123708811785100L, 26687L, true, true, (char) 56217, (char) 63908,
        Double.longBitsToDouble(0x3fecc0a5030afb54L), Double.longBitsToDouble(0x3fee59e005acdfa1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\uda9a\udc0a", "\uc1e1\u98b6\u4085", "\ud877\udc5d\udae2\udf35\ud9cc\udd89\uda97\udc3f\udb78\udf86\ud993\udf4c\udb6c\udc2d\ubdae\ud983\udf54\uda63\udc8b\ud9c3\udeab\ud890\udc66\ud8a0\udd7d\uda02\udf51\uda2c\udcd6\ud861\ude41\uda9e\udc95\udae3\udc3f\ud944\udf45\u6aad\ud8af\udce5\ud885\udc6a\ud951\udfe7\ud977\udde9\udbdc\udc70\ud8f0\ude8c\uda41\udcc7\uda78\udfeb\udaf8\udc1e\u4468\udbef\udd1f\uda9f\ude8e\ud9b5\uddf4\ud94b\uddf1\udb80\udf51\ud8a0\ude82\udb1b\udfa8\ud995\udc5b\ud9a9\udfdb\ud9f5\udff9\uf14e\ud82f\udeff\ud865\ude56\ud936\udf94\uda34\udf5a\ud9d7\udeac\udb95\udd45\uda92\udcd0\ud8c9\udea8\udb20\udd5b\udb77\uddeb\udae3\udc97\ud899\udec8\udb42\udd0f\ud92f\udd54",
        59, 38829, 1957889294, -7198313753426729440L, -60622L, true, false, (char) 51619, (char) 54104,
        Double.longBitsToDouble(0x3fd8c0b1fd7fff18L), Double.longBitsToDouble(0x3f4da45608e4a000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 5, "\uda29\udccc", "\uc1e1\u22f6\u2dba\u8a57\ua621", "\ud9cc\udd89\uda5d\udc42\udb78\udf86\ud993\udf4c\uda92\udc20\ubda3\ud983\udf54\udbfd\udffd\udad2\udc27\ud867\udc62\ud8a0\ude34\uda02\udf51\ud8a7\ude93\udaf3\udd6d\uda35\udf41\u8615\uda0b\udc00\ud831\uddc6\ud9a9\udfc5",
        46, 41410, 84518533, 2014018360278280562L, -7633L, true, false, (char) 10213, (char) 15005,
        Double.longBitsToDouble(0x3fe04359dc42ac55L), Double.longBitsToDouble(0x3fda1c31f15875a4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\uda9a\udc0a", "\uc1e1\u22f6\u2dba", "\ud879\udc84\udae2\udf35\ud9cc\udd4c\uda97\udc3f\udb78\udf86\udbe2\udf13\uda9d\udd55\ufda0\udb85\udede\udbfd\udffd\udb76\uddc6\uda51\ude20\ud8a0\ude36\uda02\udf51\ud8a7\ude93\uda9b\udde2\udaf4\udd31\ud9cd\udcfb\uda30\udd26\ud9b2\udd9d\uda09\udf2f\ud93d\ude7a\udb1b\udd9b\ud9b3\uded3\ud9eb\udc2d\udbe0\udf5d",
        25, 99851, -1873528923, 8254165531998120365L, -12255L, false, false, (char) 11389, (char) 36985,
        Double.longBitsToDouble(0x3fe602da7ab69320L), Double.longBitsToDouble(0x3fe47c3d712c6a30L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\uda9a\udc0a", "\uc1e1", "\ud8a9\udcba\udb71\udf07",
        46, 12099, 1307208946, 7764634453768616305L, 82738L, false, true, (char) 54667, (char) 62224,
        Double.longBitsToDouble(0x3fd17ecb6ead5886L), Double.longBitsToDouble(0x3fcfe714ce605280L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 10, "\uda9a\udc0a", "\uc1e1\u3826\ud711", "\ud877\udc84\udae2\udf35\ud9b5\ude89",
        11, 45022, 477552031, 7775123708811785100L, -95681L, true, false, (char) 8630, (char) 32020,
        Double.longBitsToDouble(0x3fed911b0bda8a2cL), Double.longBitsToDouble(0x3fac73e1f7142fa0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\uda9a\udc0a", "\uc1e1\u22f6\u8693", "\ud877\udc84\udae2\udf35\ud9cc\udd89",
        28, 69257, 477552031, 7775123708811785100L, 18954L, true, false, (char) 20536, (char) 18015,
        Double.longBitsToDouble(0x3fee59e005acdfa1L), Double.longBitsToDouble(0x3fd5756c3482009aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 7, "\uda9a\udc0a", "\u84a8\uab38\u495e\u1dbe\u3e5b\u34d7", "\uda97\udc3f\udbe7\ude7c\ud87b\udd7d\ud998\ude2b\ud87d\udc93\ud911\udc42",
        33, 88310, 1799565142, 1486400078403091352L, -31603L, true, false, (char) 345, (char) 3684,
        Double.longBitsToDouble(0x3fe83ccc72ed67e8L), Double.longBitsToDouble(0x3fe4bfbe402a4cd0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud9c3\ude60]] |a1=[Ljava.lang.String;:[[\ud9c3\ude60]] |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 10, 3, "\ud9c3\ude60", "\uc014", "\ud8a9\udcba\ud844\udf70",
        18, 39998, 1898937184, 554921605585134522L, -85492L, false, true, (char) 54667, (char) 62224,
        Double.longBitsToDouble(0x3fd17ecb6a38b286L), Double.longBitsToDouble(0x3fcfe714de7c5280L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 11, "\uda9a\udc0a", "\uc658\u16d6\u3e7a\u8a14\ua621", "\udb9f\udf75\uda97\udc49\udb78\udf86\ud993\udf4c\udb6c\udc2d\ud867\udda9\ud983\udf54\u4839\udad2\udc27\uda7a\udeac\ud8a0\ude36\ud865\uddb6\ud9e2\udfd8\ud92a\udf31\ud95a\udf43\ud879\udee3\ud89b\udd74\ud94f\ude14\uda84\udc01",
        13, 48140, 1816395544, 6141061650323684865L, 88061L, true, true, (char) 39526, (char) 39229,
        Double.longBitsToDouble(0x3fe6b29c89b64137L), Double.longBitsToDouble(0x3fea9d3a39ad2ad1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 7, "\uda9a\udc0a", "\uc1e1\u22f6\u3d9a", "\ud877\udc84\udae2\udf49",
        5, 44838, -1683801743, 2051070357093665234L, -49082L, true, true, (char) 45517, (char) 56217,
        Double.longBitsToDouble(0x3fcfe714ce605280L), Double.longBitsToDouble(0x3fe857daa7cb3c00L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda9a\udc0a]] |a1=[Ljava.lang.String;:[[\uda9a\udc0a]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 11, "\uda9a\udc0a", "\uc1e1\ube18\ucf6f", "\ucc44\ud8e6\udd92\udaf5\udcbc",
        0, 40629, 477552031, 6030541803157762956L, 26687L, true, true, (char) 56217, (char) 63908,
        Double.longBitsToDouble(0x3fecc0a5030afb54L), Double.longBitsToDouble(0x3fee59e53dacdfa1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 7, "\uda9a\udc0a", "\uc1e1\u22f6\u2dba\u8a57\ucb77", "\ud9cc\udd89\uda97\udc3f\udb78\udf86\ud993\udf4c",
        3, 66932, -504415974, -1389904602970471145L, -50593L, false, true, (char) 18015, (char) 32116,
        Double.longBitsToDouble(0x3fee4ad1155cb8f1L), Double.longBitsToDouble(0x3fece3214b932403L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 8, "\uda97\ude14\ud2a6\ud8e8\ude1b\ud927\udc9f", "\u8a57\ua621", "\udb3e\udd62\uda5b\udefc\udb9d\udd8a\ud876\udcfe\udb8a\udc84\udafe\ude49\udbf7\udf57\udbff\udc18\udb13\udc47\ud9de\udca5\ud9ed\ude34\ud9e5\udc77\udbe8\ude54\uda9b\udde2\ud95c\ude65\udbd8\udc24\udb56\uddaa\ud9a2\udc5e\ud900\udc5d",
        40, 88326, -1787826109, 9196140551984282342L, -2955L, true, true, (char) 58493, (char) 45132,
        Double.longBitsToDouble(0x3feeeea1baec4814L), Double.longBitsToDouble(0x3fd79e04ea8b095eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\udab0\ude7b", "\ua18c\uc445\u2dba\u8a57\ua621\u4d6d\u4345\u521a\u7511\ua27d\u5f5b\u24b4", "\udb4a\udff0\udad2\udc58",
        11, 27630, -78365800, 4323538148054380491L, 12859L, false, true, (char) 4296, (char) 60888,
        Double.longBitsToDouble(0x3fdb2059ee19d7e8L), Double.longBitsToDouble(0x3fd057ed5949f69aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\udb56\uddd0", "\uc1e1", "\ud86f\ude00\ud9ac\udda3\uda96\uddc3\uda21\ude19\u7541\udb8d\udfda\udab5\udc8b\uda86\udd99\udb39\ude5b\ubdae\ud983\udf54\udbfd\udffd\udad2\udc27",
        5, 52487, -78365800, 4323538148054380491L, -13640L, false, true, (char) 60930, (char) 46422,
        Double.longBitsToDouble(0x3fcf0efafe455424L), Double.longBitsToDouble(0x3fbdd6bbe987fda8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\uda9a\udc41", "\uc1e1\u22f6\u2dba\u8a57\ua621\u4d6d\u4c3f\u894a\u759c\ua27d\u805b\u99b4\u658d\uaf75\u726c\u89d8\u127a\ua971\ua60e\u1a27\u016e\u9cc4\u7501\u7fea\u94f9\u8a79\u8956\u3b90\uad3d\uaad2\uc53e\u37fc\u3fb7\u0bd4", "\uda5c\udcb0\udb2c\ude29\ud916\udfcb\ud8a6\udf36\ud8bb\udf8b\ud84a\ude6a\udb6f\udd37\udbc5\udce3\udb71\udfeb\ud840\udcff\udaba\udcc6\uda8d\udf93\ud936\udd2c\ud92a\udf46\ud9a6\udc0b\ud8a3\udcf6\uda08\ude39\uda87\ude80\udac6\ude56\uda21\udeac\ud913\udec3\ud9dd\ude8d\udb26\ude4e\ud9f7\udcc8\ud9d2\ude7e\uda1d\udc77\ud82d\udfb3\udbe8\ude21\ud995\ude1d\ud9b5\udcee\ud9c9\udf5e\uda73\udef8\ud856\udd90\ud8df\udcb7\ud878\udc84\ud815\udf21\ud96b\uddef\u815d\ud903\ude76\ud879\udd0d\uda93\udc07\ud944\udcb3\udb9b\udf9f\ud9d5\udd0e\udb06\udd20",
        4, 47665, -2020124320, 3517304974469959822L, -41511L, false, false, (char) 51765, (char) 63846,
        Double.longBitsToDouble(0x3fda73e3c0fe3b12L), Double.longBitsToDouble(0x3fbd4c818bfee498L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\uda9a\udc0a]] |a1=[Ljava.lang.String;:[[\uda9a\udc0a]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 1, 5, "\uda9a\udc0a", "\uc1e1\u22f6\u2dba", "\uda9b\udca5\udae2\udd6e\ud861\udc8a",
        28, 69257, 477552031, 1661487214656294443L, 26687L, true, false, (char) 56217, (char) 63908,
        Double.longBitsToDouble(0x3fecc7cd030afb54L), Double.longBitsToDouble(0x3fee59e005acdfa1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 3, 1, "\uda9a\udc0a\ud8f2\uddc3\ud9cc\udf72\ud882\ude4f\u9323\ud8a9\udda2\ud8a9\udd0e\udb71\udf07\ud877\udc84\udae2\udf35\uda02\udc86\udb85\udc8c\udb78\udfb6\ud993\udf4c\udb6c\udc2d\ud897\udce0\udb58\ude7f\udbfd\udffd\udad2\udc27\uda7a\udeac\ud8a0\ude36\uda02\udf51\ud8a7\ude93\uda9b\udde2\uda50\udc9e\ud888\udd77\u2863", "\u09b0\u590a\ud222\uc551", "\ud9cc\udda2\udafc\ude7c\ud92c\udcc0",
        12, 22595, 724361059, 2168756535083036813L, -24823L, true, true, (char) 23978, (char) 48100,
        Double.longBitsToDouble(0x3fdb0c0db43dcfc8L), Double.longBitsToDouble(0x3fcf6e184b8a02f4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 7, "\uda9a\udc0a", "\u3575\u5baa\uca59", "\ud877\udc84\udae2\udf35\ud9cc\udd89",
        56, 73676, 1556195424, 7775123710992823180L, -27841L, false, true, (char) 63854, (char) 63908,
        Double.longBitsToDouble(0x3fecc0a5030afb54L), Double.longBitsToDouble(0x3fe809e001319f4dL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\000", "\uc1e1\u22f6\u2dba", "\ud877\udc84",
        29, 65946, 1807844838, -7231873418655244897L, -54036L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3feab56218ff38a6L), Double.longBitsToDouble(0x3fecc0a5030afb54L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 7, "\uda9a\udc0a", "\uc1e1\u5da6\u4e46", "\ud877\udc84",
        41, 65946, 1807844838, -7231873418655244897L, 11500L, false, true, (char) 62224, (char) 45517,
        Double.longBitsToDouble(0x3feb356218ff38a6L), Double.longBitsToDouble(0x3fecc0a5030afb54L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 0, "\uda9a\udc0a", "\u6290\u22f6\u2dba", "\ud877\udc84",
        29, -758, 0, 62672162839808L, 11360L, false, false, (char) 61985, (char) 45517,
        Double.longBitsToDouble(0x3fb5ab10c0000000L), Double.longBitsToDouble(0x3fc3028000280000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 7, "\uda99\udfb1", "\uc189\u22f6\u2dba\u8a57\ua621\u4d6d\u4c3f\u894a\u759c\ua27d\u5f5b\u99b4\u658d", "\udad2\udc27\udab9\ude02\ud8a0\ude36\uda02\udf51\ud8a7\ude93\uda9b\udde2\ud8ed\udc0d",
        32, 37717, -799258145, 7802116165111313200L, 53831L, true, true, (char) 35730, (char) 16329,
        Double.longBitsToDouble(0x3fe4cf51d5157cc1L), Double.longBitsToDouble(0x3fe7cdf629ea240aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 7, "\u704d", "\uc1e1\u22f6\uab89", "\uda39\udfe0\udae2\udedd\udac2\udd85\u1d56\ud95f\udc46\uda8b\udf02\udb62\ude4b\ubdae\ud983\udf54\udbfd\udffd\udad2\udc27\uda7a\udeac\ud8a0\ude36\uda02\udf51",
        4, 24171, -1520390706, 5500830785494949265L, 91992L, true, true, (char) 50018, (char) 64385,
        Double.longBitsToDouble(0x3fd93e9f1228861cL), Double.longBitsToDouble(0x3feba4b16b76102dL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\ud9eb\uddb7]] |a1=[Ljava.lang.String;:[[\ud9eb\uddb7]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 1, 11, "\ud9eb\uddb7", "\u9a66", "\uda7a\uddc2",
        24, 72741, -1093909877, 8445291915028563427L, 11500L, true, true, (char) 62224, (char) 45517,
        Double.longBitsToDouble(0x3feab56218ff38a6L), Double.longBitsToDouble(0x3fea1c1d072ffb9fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 2, 4, 7, "\uda9a\udc0a", "\u0acd\u00ae\000", "",
        27, 90611, 0, -1683816448L, 82738L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 10, 2, 2, "\udb29\uddad\ud8f2\uddc3\ud818\udc73\ud882\ude4f\ud95f\udfff", "\ua621\u4d6d\u4c3f\u894a\u759c\u6366\u213e\u768f", "\u1f0c\udad2\udc27\ud854\udf20\ud8a0\ude36\uda02\udf51\ud8a7\ude93\uda9b\udde2\ud988\udc5b\udba4\udcb3\ud88b\udefd\udb5e\udd46\uda42\udcc7\ud989\udd67\ud92e\udf88\udab1\udf3b\ud987\uddcc\udbde\udcf1\udb09\udf48\ud91f\uddfa\udba8\udd6d\udbde\udfd9\udbea\ude65\ub6bc\udbe9\udc75\ud86f\udca3\ud951\ude0f\udaaf\udfe2\ud80a\udcbc\ud842\udc9b\ud997\udefd\ud853\udf8c\ud81f\udca6\ud963\udf34\udbbc\udcb2\uf9ac\udb5c\udf73\uda01\udc82\uda18\udec3\udb54\udcaa\udb17\uded6\udb0e\udfe4\ud90c\udcb5\ud811\ude92\udafb\ude62\ud8e2\udfd4\ud9fd\udc50\udaab\udee2\ud9ca\udd46\udb50\udee4\udb45\udf1f\udbb3\udf04\udb95\ude7d\u4688\udbe9\udc26\uda11\udd44\uda79\uddff\uda50\udc9c\ud852\ude01\ud9f9\udc31\ud954\udd3b\udb91\udcf3",
        41, 14224, -825315134, 1403829539712860792L, -588L, true, true, (char) 13264, (char) 9958,
        Double.longBitsToDouble(0x3fec0fe28e4ea9ecL), Double.longBitsToDouble(0x3fd699ea850e7adcL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 10, "\uda9a\udc0a\udaf9\udf26\ud891\udc36\ud882\ude4f\udb66\udd83\uda68\udc21\udaf8\udfca\ud98d\udf9a\ud9b0\uddbe\uda71\udc00\ud9cc\udd88\uda97\udc3f\udb78\udf86\udb99\ude35\ud917\udd50\uda8b\ude8e\udade\udfe5\ud88f\ude50\ud817\udf1f\ud901\uddb2", "\u455b\u699f\u4f32\u4591\ub1f0\u8e6b\uc4e5\u2250\u02f9\ub0ea\ua174\ud69e\u9eed\u7b18", "\ud863\udc17\ud975\udc56\uda78\udf53\ud90e\udc18\udb6b\udfd3\ud954\udcc0\ud975\udf3b\ud9c4\udc90\ud9cc\uddfb\u2746\udbc6\udc36\ud818\udd39\udb07\uddfe\ud9d8\udc01\udb74\udcef\udb72\udd18\udbd8\udcea\ud271\ud9b1\udce6\ud9d4\udf60\uda95\ude82\uda44\udce3\ud84a\udea2\ud956\udc39\udb8b\uddf4\ud8a5\udee5\udb18\ude46\ud9f1\ude66\ud82a\udc41\ud8b8\udea6\uda7f\uddf8\ud93c\udd45\udb49\ude18\ud854\udf21\udb68\udf3f\ud98e\udc67\uda10\ude65\uda15\uddde\uda11\udd52\ud984\udf62\ud9af\udc75\ud83c\udd11\ud82b\udef9\udb87\udc59\ud882\uddaa\ud835\udf7c\u048d\ud909\udfe8\ud8cc\udfec\udb62\udf5e\udbab\ude3b",
        49, 89771, 1943565653, -1157362829284430625L, 38311L, false, true, (char) 61262, (char) 61990,
        Double.longBitsToDouble(0x3fe3c1471725ce6eL), Double.longBitsToDouble(0x3fec99c86359669eL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 10, 10, 3, "\uda9a\udc07\uda84\udcc1", "\u3330\u0d26\u8a57\u178a\u4d6d", "\uda97\udc3f\udb78\udf86\ud90c\udcff\ud8ed\ude00\ud95e\uded9\ud99f\udc51\ud8dd\udc39\ud8b5\udce4\ud9ca\uddb1\ud8a0\ude36\uda02\udf51\udbf6\udfd6\ud84f\udcb1\udb14\udc0b\ud920\udcab\ud8be\udd3d\udb52\udf10\ud948\udfa6\uf868\udaa4\udc21\udb4e\udd55\ud8d0\ude18\udb45\udcb7\uda4a\udcc2\uda88\udfbe\ud927\udc9d\uda0c\udd03\udbb7\udee3\udbfc\udc96\udbca\udd10\ud82a\udea3",
        29, 14362, 1578263621, -4203663008039727167L, 87310L, false, true, (char) 40305, (char) 15454,
        Double.longBitsToDouble(0x3fe901127f9d9665L), Double.longBitsToDouble(0x3fc8e359b8be8f68L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 5, "\udb77\udc53", "", "",
        35, 12455, -1562594171, 3129256223465108371L, -100000L, false, false, (char) 56734, (char) 58951,
        Double.longBitsToDouble(0x3fec0b58311a9c71L), Double.longBitsToDouble(0x3fd21e1efa2fd96cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 6, "\uda29\udccc", "\u374b\u1341\u1b0a\u4a6b\ua621\u4d6d", "\ud955\udc3e\ud8ea\udd3e\udbd8\udc02\udabd\udc27\ubda3\ud983\udf54\udbfd\udffd\udad2\udc27\ud867\udc62\ud8a0\ude34\uda02\udf51\ud8a7\ude93",
        24, 58489, -1872679767, -675658081714997603L, -11557L, true, false, (char) 34149, (char) 23460,
        Double.longBitsToDouble(0x3fe98faf408997f2L), Double.longBitsToDouble(0x3f9a1bcb4f990400L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\udb05\udcdf", "\uc1e1\u22f6\u2d98\u6b82\u4137", "\ud801\udc1f\uda96\udf9b\udb78\udf86\udbe2\udf13\uda9d\udd55\ufda0\udb85\udede\udbfd\udffd\udb76\uddc6\uda51\ude20\udaa1\ude36\udbb1\udf28\ud8cd\udfcc\uda9b\udde2\udaf4\udd31\ud9cd\udcfb\uda30\udd26\ud9b2\udd9d\uda09\udf2f",
        3, 63484, 181775920, -2003602857867777093L, -85465L, false, false, (char) 7638, (char) 8765,
        Double.longBitsToDouble(0x3fd2c6a302a34ea8L), Double.longBitsToDouble(0x3fcd40b56f77ea48L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 7, "\u6d00", "\uc1e1\000\000", "",
        14, 28587, 1307208885, 0L, 94311L, false, true, (char) 33059, (char) 27494,
        Double.longBitsToDouble(0x3ec6ce5c00000000L), Double.longBitsToDouble(0x3fcfe561ce605280L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda9a\udc0a]] |a1=[Ljava.lang.String;:[[\uda9a\udc0a]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 10, "\uda9a\udc0a", "\uc1e1\u3826\uc7c2", "\ud877\udc76\udae2\udf35\udabc\udd56\uda49\uddcd\ud8b7\ude64",
        38, 52025, -1670270068, -2166479798532313311L, 70420L, false, false, (char) 42696, (char) 5122,
        Double.longBitsToDouble(0x3fe9d998c7714207L), Double.longBitsToDouble(0x3fe0dfefcfae8d64L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda9a\udc0a]] |a1=[Ljava.lang.String;:[[\uda9a\udc0a]] |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\uda9a\udc0a]] |a1=[Ljava.lang.String;:[[\uda9a\udc0a]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 10, "\uda9a\udc0a", "\uc1e1\u3826\ud711", "\ud86a\udc6a\udae2\udf35\ud9b5\ude89",
        11, 45022, 477552031, 7775123708811785100L, -95681L, true, false, (char) 8630, (char) 32020,
        Double.longBitsToDouble(0x3fed911b0bda8a2cL), Double.longBitsToDouble(0x3fac73e1f7142fa0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 11, "\ud9dc\ude60", "\u2015", "\ud8a9\udc77\udb71\udf07\udb8f\udd71\ud83f\ude47\uda12\udee0\uda8a\ude55\udb78\udf86\ud993\udf4c\ud818\ude85\udbcf\udd41",
        6, 52388, -1404844777, 4082002159017705727L, 73485L, true, true, (char) 44341, (char) 47314,
        Double.longBitsToDouble(0x3fdf54c1c6ec76acL), Double.longBitsToDouble(0x3fe8ad2578660fafL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda9a\udc0a\ud8f2\uddc3", "\u8070", "\udb75\ude7a\ud8fd\udfd7",
        29, -758, 0, 62672322311972L, 11360L, true, false, (char) 52014, (char) 45517,
        Double.longBitsToDouble(0x3fb5ab10c7cbc0a8L), Double.longBitsToDouble(0x3fc3a2801538873cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 7, "\uda99\udfb1\ud926\udffe\uda8c\udcc0\ud882\uddf7\ud95f\udfff\ud8ec\uddc7\ud8a9\udcba\udaa9\udf03\ud9fe\udfe9\ud9ad\udeb9\ud841\ude1c\udbc7\udfdd\udb78\udf86\ud993\udf4c", "\ud03b\u7244\u58ac\u0ece\ua971\ua60e\u1a27\u016e\u3d17\u1a10\u55b1\u7968\ub829\u2f4f\u7029\uad1e\u8d8d\u7537\ud4b1\u7ab2\u1792\u92fe\uba76\uacf8\u6713\u6891\ud4ec\ub37b\u9ac5\ub885\ud6f2\u152e\u7202\u1528\u7c81\u2637", "\ud93d\udcd0\ud9ac\udf7d\udaaa\udeac\udb06\udc19\ud95e\udc0c\ud91d\ude31\uf995\uda8c\uddf1\udbc1\udc65\uda06\ude4c\udba2\udc02\udb34\udfaf\ud871\udfe9\udb48\udf9d\ud98a\udc30\udb0c\udffe\u09ae\udabf\ude66\ud9a8\udfbe\ud9e2\udc27\udad2\udd32\ud82a\udf33\udbbd\udc34\udbe9\udc9b\udb73\uddf2\ud8f7\udd49\uda8e\udee5\uda93\ude88\ud82c\udf80\uda04\udf65\ud889\ude15\udbd3\udfb3\ud9ab\udcba\ud9df\udff6\udb56\udd45\u77b3\ud89b\udeef\udae6\udc9f\ud83e\udf84\ud81c\udd21\ud934\uded5\ud810\udf89\uda54\ude60\ud941\udf2e\ud8f5\ude0c\ud98d\udde3\udac1\udee6\uda9a\udc85\ud972\udf7d\ud9eb\udd26\ud909\uddd0\udad2\udfc8\udbad\udf2d\udb30\udc8a\udb31\udd1f\udbc8\udff2\ud9a0\ude89\udbea\udc2e\ud98a\udcd5\ud9e8\udd14\ud923\udc77\uda6d\udf77\ud823\udc5e\ud8d7\udc4d\udbc1\udd4b\ud9ed\ude9e\ud830\udf52\u29ae\ud83a\ude26\udad1\uded1\ud8ed\ude37\ud801\udc0d\ud8a5\ude67\u03c0\ud9dd\udfda\udb33\udcbc\uda3e\udfcd\udb38\udc54\ud9a0\udf26\uda1b\udd8a",
        14, 65425, 739388625, -8463575335647995465L, 4093L, true, false, (char) 19160, (char) 50846,
        Double.longBitsToDouble(0x3fd3abdcdb0c349aL), Double.longBitsToDouble(0x3fe9a034fcd4b2d6L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\uda9a\udc0a", "\uc1e1\u22f6\u2dba", "\ud877\udc84\udae2\udf35\ud9cc\udd89",
        28, 27617, 477552031, 7775123708811785100L, 26687L, true, true, (char) 56217, (char) 63908,
        Double.longBitsToDouble(0x3fecc0a5030afb54L), Double.longBitsToDouble(0x3fee59e005acdfa1L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 0, "\uda9a\udc0a", "\u6290\u22f6\u2dba", "\ud877\udc84",
        29, -758, 0, 44910484444470528L, 11360L, false, false, (char) 30397, (char) 27603,
        Double.longBitsToDouble(0x3fb5ab10c0000000L), Double.longBitsToDouble(0x3fc3028000280000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processArgs|org.apache.commons.cli.Option,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processOption|java.lang.String,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|setOptions|org.apache.commons.cli.Options|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
