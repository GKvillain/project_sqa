package org.apache.commons.cli2.commandline;
import org.junit.Test;
import static org.junit.Assert.*;
public class WriteableCommandLineImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 14, "\ud8f7\udf7b\udaa7\udd33\ud9e3\udcb4\udbe5\udc59\ud805\udc91\udab7\uddc6\ud9e2\udf2e\udab8\udd24\ud8f2\udc36\udae8\udc85\ud962\ude8b\ud8e4\udf6a\udafe\udd3d\udb0c\udc3b\ud87a\udf0b", "\u5140", "\udba1\udca9",
        7, 14286, -443007404, 1117933138359530825L, 12817L, true, true, (char) 27069, (char) 51285,
        Double.longBitsToDouble(0x3fd5f8c21dcc67d8L), Double.longBitsToDouble(0x3fe886cfbda8b60eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 14, "\ud8f7\udf7b\udaa7\udd33\ud9e3\udcb4\ud98d\udd4d\udabf\udfbd\ud9b0\udd3d\uda08\uddd5\udab8\uddb8\ud8f2\udc36\udae8\udc85\ud962\ude8b\ud8e4\udf6a\udafe\udd3d\udb0c\udc3b\ud87a\udf0b", "\u7054", "\udba1\udca9",
        7, 14286, 1111440980, 1090056122142733641L, 12817L, true, true, (char) 44477, (char) 7147,
        Double.longBitsToDouble(0x3fd5f8c21dcc67d8L), Double.longBitsToDouble(0x3fe886cfbda8b60eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 2, "\ud8f7\udf7b\udaa7\udd33\uda63\udf54\ud90c\ude25\ucecc\udb63\uddbc\ud9e2\udf2e\uda59\udf55\udb4d\udca4\udae8\udc85\ud962\ude8b\ud8e4\udf6a\udafe\udd3d\udb0c\udc3b\ud87a\udf0b\udbd7\udc67\uda16\ude2b\udafc\uddf5\ud893\udf84\ud93b\udc27\udba1\udca9\ud88b\udd56\udb46\udc9b\uda73\udcff\ud802\udf2e\ud852\udf34\ud905\udd88\udbc9\ude2f\ud95a\udc31\udb79\udd5e\udbc6\udd3b\ud953\udc6e\ud8ad\udca8\ud999\udfb4\udaa1\udf30\ud9ee\udd2f\udaad\ude4c\uda80\udf1e\udbc0\udef2\ud9f1\udcd4\ud94d\ude87\ud9b0\udc14\udbda\udcca\udb70\ude1d\udaa4\ude1d\udbc0\udc89\udbaa\udecc", "\ud10d", "\udae7\udca8\uda3a\udcc4\udbed\udc23\udae5\udd34",
        7, 89644, 152039287, -7059323575740045710L, 75444L, true, true, (char) 27428, (char) 13207,
        Double.longBitsToDouble(0x3fdff928d88b9720L), Double.longBitsToDouble(0x3fd370a5ede1df78L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 14, "\ud813\udec5", "\u2035\u8eb1\u49ad", "\udb16\udd9e\ud934\udc85\ud80a\udd4a\ud8e4\udf6a\udafe\udd3d\udb0c\udc3b\uda2a\udfe3",
        14, 50433, -1906519467, -4030537633940779594L, -87196L, false, true, (char) 23009, (char) 48787,
        Double.longBitsToDouble(0x3fe1264c19472a8eL), Double.longBitsToDouble(0x3fea7d44a153d3b6L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 14, "\ud8f7\udf7b\ud87a\udd27\ud9e3\udcb4", "A\u2760\u7ec0\u9e35\u4925", "\udafe\udd3d",
        11, 98396, 338025272, 3128312484794588510L, -98629L, true, false, (char) 17985, (char) 20191,
        Double.longBitsToDouble(0x3fe46f996aeac417L), Double.longBitsToDouble(0x3fd490f833f4551cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 14, "\udbb0\udffa\udaa7\udd33\ud9cb\udc90\udbe5\udc59\ud953\udf15\udab7\uddc6\ud9e2\udf2e\uda29\udf3d\udbba\udf84\udaef\ude1d\udbcb\udc97\ud8e4\udf38", "\u0bba\u5e8d\u6abc\u515b\u7643\u94dc\u6424\u7a69\u6c03\u3f08", "\udaf8\udf17\udb46\udd6d\ud902\udc59\udb79\udd5e\udbc6\udd3b",
        58, 166, -1567823190, -5984726653803057400L, -22202L, true, true, (char) 61029, (char) 11328,
        Double.longBitsToDouble(0x3fd8ef5442dc0e1eL), Double.longBitsToDouble(0x3fe3f6d8cc747809L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 14, "\ud8f7\udf7b\udaa7\udd33\ud9e3\udcb4\udbe5\udc59\ube91\uda61\udec8\ud82a\udebb\ud8bd\udccf\ud8f1\udf89\udae8\udc85\ud938\uddd6\ud8e4\udf6a\udafe\udd3d\udb0c\udc3b\udb70\udc35", "\u5140", "\udba1\udca9",
        7, 87686, -436781572, 4337844397607812982L, 12817L, true, true, (char) 27069, (char) 22331,
        Double.longBitsToDouble(0x3fd6dca09ef0f37cL), Double.longBitsToDouble(0x3fe881fc4da8b60eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 5, "\ud8f7\udf05\udbe6\ude66\uf3f3\uda98\udd3d\ud961\ude6b\ud8c9\udf95\ud908\ude3f\udaf1\udcce\udba8\udd10\ud9bb\udc48\ud8ee\udc99\ud8d0\uddbd\uda56\udc24\ud987\udc3f\ud9e5\ude81", "\u1841", "\ud84a\udd17\uda17\udd0d\ud917\udee3\uda73\udcc5",
        32, 25593, -1475977145, -3191284882978516653L, 15170L, true, true, (char) 62438, (char) 57765,
        Double.longBitsToDouble(0x3feb9c1bdf21bc3bL), Double.longBitsToDouble(0x3fe1316e019e9e9fL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 1, "\ud804\udc6c\u9d31\uda69\udc70\udbe5\udc59\ud805\udc91\udab7\uddc6\ud9e2\udf2e\udab8\udd24\ud8f2\udc36\udae7\udf85\ud962\ude8b\ud8e4\udf6a\udafe\udd3d\udb0c\udc3b\ud87a\udf0b\udbd7\udc67\uda16\ude2b", "\u94dc\u6424\u7a69\u6c03\u3f08\u3ca7\u8fe4\ua994\u2951\u683c\u5eb1\u16bc", "\ud9c0\udeb4\udb8c\udcc6\ud8ce\udf13\udbaa\udfc9\ud9c9\ude92\u74c5\ud9cc\udf33\udb58\udeba\udb2d\udcbb\udb3d\udf13\ud9d6\udc3b\ud893\ude87\u4ea5\udae3\udfba\uda7d\udf05\ud85e\udcca\udab9\udce4\ud8cb\udda5\udba0\udc5f\ud8f6\udf6d\uda51\udee0\u5708\ud9d0\ude60\ud957\udece\ud912\ude14\udae7\udd86\ud9f6\udc8e\ud975\ude32\uda83\udd2d\ud882\udd9f\udbb9\ude55\udabc\ude14\udbe2\udf52\ud929\udc89\ud9a6\udcd2\uda75\udec1\udb97\udf87\udacc\udd8a",
        9, 80655, 1805346986, 1766175545474593768L, 41308L, true, false, (char) 83, (char) 25333,
        Double.longBitsToDouble(0x3fd1adfc0f2d72f2L), Double.longBitsToDouble(0x3fc6fe24f541a6b4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 14, "\ud914\udc66\ud9c0\udeb2\ud9e3\udcb4\udbe5\udc59", "\u2760", "\udae8\udc85",
        51, 20454, 1250807001, -158689914938307688L, 96513L, true, false, (char) 64350, (char) 58822,
        Double.longBitsToDouble(0x3fd287208e54fec8L), Double.longBitsToDouble(0x3fedf707ee548d7bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 14, "\ud8f7\udf7b", "\000", "",
        43, 40756, -1344172817, -2327276422521894701L, -100000L, false, false, (char) 65124, (char) 63032,
        Double.longBitsToDouble(0x3f14258000000000L), Double.longBitsToDouble(0x3eca16db20400000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 14, "\ud8f7\udf7b\udaa7\udd33\ud9e3\udcb4\udbfe\ude59\udad0\udd2d\udbcb\udec3\ud8e4\udfb5\ud987\ude27\ud8f2\udc36\udae8\udc85\ud962\ude8b\uda03\udf3f\udabb\udd1d\udb0c\udc88\ud87a\udf0b", "\u5140", "\udba1\udca9",
        7, 22990, -443007404, 1117933138359530825L, 92422L, true, true, (char) 27069, (char) 51285,
        Double.longBitsToDouble(0x3fd5f8c2110d210eL), Double.longBitsToDouble(0x3fe886cf35a8b60eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 14, "\ud8f7\udf7b", "\u2010\u3ad8\u13ee\u3e9f\u91ce\ubdf9\u7425\u6a87\u5806\u8535\uadc0\u9887\u1b19\u6abc\u5140\u7643\u94dc\uce16\ua44b\u6c03\u3f08\u3ca7\u3bb9\u3002\u62d1\uca57\u5eb1\u16bc\u96e9\u2dd2\u0f6d\u2f11\u06f9\u8db8\u0ebb\u2022\ua2a3\u032a\u5515\u3a72", "\ud93d\udc20\ud9c9\udeb9",
        48, 50353, -1406906700, 8267669124218605767L, -59339L, true, false, (char) 45796, (char) 30880,
        Double.longBitsToDouble(0x3fc1eac882dcf280L), Double.longBitsToDouble(0x3fe4d967794b76e3L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 13, "\ud8f7\udf7b\udaa7\udd33\ud9e3\udcb4\udbe5\udc59\ud805\udc91\udab7\uddc6\ud9e2\udf2e\udab8\udd24\ud8f2\udc36\uee2e\ud962\ude8b\ud872\udf30\udb09\udf75\udb0c\udc3b\ud87a\udf0b", "\u5140", "\uda92\uded9",
        36, 48435, -975145644, 1117933177014236489L, 12817L, true, true, (char) 27069, (char) 51285,
        Double.longBitsToDouble(0x3fd5f8c21dcc67d8L), Double.longBitsToDouble(0x3fe886cfbda8b60eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 14, "\ud99d\udda3\udaa7\udd33\ud9e3\udcb4\udbe5\udc59\ud805\udc91\ud9b4\udd04\ud9e3\ude9a\udab8\udd24\ud8f2\udc36\udae8\udc85\ud962\ude8b\ud8e4\udf6a\udafe\udd3d\udb0c\udc3b\ud87a\udf0b\ud956\udfc7\ud93e\udcea\udbf2\uddf1\udab3\udfcf\ud93a\udfe7\udba1\udca9\ud88b\udd56\ud90b\udcfe\ud963\udddd\udbbd\udc70\uc7cb\udaf8\udf17\udb59\udcb2\ud901\udfbd\udb79\udd5e\udbc6\udd3b\ud953\udc6e\ud8ad\udca8\ud9c0\udeb4\udaa4\udf32\udb25\uddf7\udb29\udca2\ud949\udec5\uda59\uddf4\u8e7a", "\u4fcc\u5033", "\uda2e\udfb5\uda6c\ude19\udab9\udedd\uda2f\udc0d\uda71\udd6d\ud859\udf38\ud803\udda7\ud8ec\udf43\udb31\udecc\ud8ad\ude2d\ud86a\ude42\udac9\uddbc\udb1c\udc79\ud8cd\udead\ud983\udc1b\udbee\udcc6\udb91\uddb6\ud860\udfe6\ud905\uddc5\ud9c5\udfa3\ud9b6\udd4d\u99d7\udad7\ude46\ud8e8\udf19\udbc7\udc28\ud97e\udc66\ud947\udc1e",
        23, 58307, -1323076508, 1774725993281598961L, -24938L, false, true, (char) 51178, (char) 50958,
        Double.longBitsToDouble(0x3fecd6b3f036d6d8L), Double.longBitsToDouble(0x3fcb3fa00c4846ecL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 14, "\ud8f7\udf7b\udaa7\udd33\ud9e3\udcb4\udbe5\udc59\ud848\udf14\ud984\udc82\ud9e2\udf2e", "\u7454\u6a87\u5806\u8535\uadc0\u9887\u1b19\u2bec\u5140\u7643\u94dc\u6424\u7a69", "\udb06\udcf0\udb7a\ude22\udaf8\udf17\uda37\uddf8\ud901\udfbd",
        16, 800, 871156063, -2740536143676252400L, -35960L, true, true, (char) 17622, (char) 35868,
        Double.longBitsToDouble(0x3fe50dfeb0f5203cL), Double.longBitsToDouble(0x3fecd65c707b1e45L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 14, "\ud8f7\udf7b", "", "",
        -5, -1000, 0, -5773178289729054099L, -78496L, false, false, (char) 0, (char) 6013,
        Double.longBitsToDouble(0x3fd37177e35a6a6cL), Double.longBitsToDouble(0x3fef2b29f64c6d5eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 13, "\ud854\udc70\udafb\udc67\uda72\udd99\udbff\udeec\ud805\udc91\udad3\ude94\ud891\udd06\udab8\udd24\ud926\udcc2\uda59\ude3c\ud95d\uddf7\ud874\udf31\uda74\uddeb\ud8f1\udf62\ud87a\udf0b\udbd7\udc67\uda16\ude2b\udafc\uddf5\uda6a\ude51\ud93f\udf61\udabd\udce2\ud98c\udd4e\ud92c\ude63\ud844\udde7\u48ff\uc7cb\udaff\udff9\ud9f4\udc6b\ud901\udfbd\udb79\udd5e\ud84c\udc1a\ud99e\ude14\ud99f\udf30\ud9c0\udeb4\udb92\uded6\ud97a\udc3f\ud819\ude06\u36fc\ud96a\udd1d\ud877\udf1e\udb15\udd4a", "\u0829\u2a3e\uc576\u10c7\u4b15\u59d6\u97d1\u8bff\u1565\u38a9\uc151\u93ed\u6cb6\ucc08\u9e5b\u113d\u763a\u80ae\ud2e2\u56eb\u24a8\u25b9", "\ud94c\udf6d\ud9af\udecc\udb0d\ude63\uda19\udef0\ud952\udd33\ud98e\ude46\ud969\udf4b\ud80d\udfdc\udab7\udf8f\uda43\udf38\udac7\uddc9\ud80f\udf3c\ue3f6\ud9ab\udd15\ud933\udcb2\ud94e\udf8c\uda8d\udc61\ud97c\ude44\uda54\ude09\uda8d\udd80\ud97f\udf85\ud817\udfa0\udb34\udc53\udab0\uddba\u9835\ud9e1\uddca\udbef\udcfb\udaf7\udc06\udb7c\ude65\udbf2\udc5d\ud882\udec3\udb82\udf14\ud9e2\udffc\uda35\udd09\ud93e\udcd2\udb74\udcb7\ud832\ude2b\u4454\ud8d2\udd7e\udb86\udc89\udb41\udfad\ud80a\udceb\ud860\udd9b\udbb4\udc83\ud833\udd30\u28d0\uda22\udd40\ud9b5\udc69\ud8e7\udd73\uda80\ude4b\udaa4\udff6\udbf1\udf02\ud9ae\ude6a\udbd5\udda7\ud9ab\uddbe\ud8c9\udf5b\ud9f3\udd33\udbd7\udc00\ud920\udc98\udbaf\ude5c\uda67\udd51\ud8f4\udf4c\udbcc\udf5b\uf32c\uda97\ude46\udb29\udd58\ud9c4\udf68\udad3\udfa3\ud9da\uddd5\ud85b\udce1\udb36\udc23\ud82d\ude12\u5345\udb56\udd7f\uda15\uddf9\udab2\udd0d\udb1f\ude7a\ud9b2\udeef\ud800\udd74\ud947\udcf0\uda9b\udfbd\udaf3\udea9\udaaf\udd36\udb1b\udfd0\ud964\udff0",
        58, 52650, 1472346902, 2987259884776884386L, -9630L, false, false, (char) 60581, (char) 34521,
        Double.longBitsToDouble(0x3fc2c00adf9bb198L), Double.longBitsToDouble(0x3feb78c00cc152edL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 14, "\ud8f7\udf7b\udaa7\udd33\ud9e3\udcb4\udbe5\udc59\ud88b\uddd9\ud975\udc04\udafe\ude7a\udab8\udd24\ud8d1\udd72\udae8\udc85\ud962\ude8b\ud8e4\udf6a\udafe\udd3d\udb0c\udc3b\ud87a\udf0b", "\u803c", "\udba1\udc82\udbb1\udf11",
        50, 484, 260289092, 8608830013893338167L, -77811L, false, true, (char) 21337, (char) 21888,
        Double.longBitsToDouble(0x3fe7319f6710d9f7L), Double.longBitsToDouble(0x3fe48d0845e7a3acL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 0, "\u008a", "\u0426\u3ad8\u13ee", "",
        -5, 2733, -1787770669, 472446402560L, -100000L, false, false, (char) 65279, (char) 0,
        Double.longBitsToDouble(0x3e46db2040000000L), Double.longBitsToDouble(0x3fd287208e54fec8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getValues|org.apache.commons.cli2.Option,java.util.List|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addProperty|java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addProperty|org.apache.commons.cli2.Option,java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addSwitch|org.apache.commons.cli2.Option,boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addValue|org.apache.commons.cli2.Option,java.lang.Object|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getNormalised||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getOptionTriggers||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getOptions||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getProperties||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getProperties|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getProperty|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getProperty|org.apache.commons.cli2.Option,java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getSwitch|org.apache.commons.cli2.Option,java.lang.Boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getValues|org.apache.commons.cli2.Option,java.util.List|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
