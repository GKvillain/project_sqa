package org.apache.commons.cli2.commandline;
import org.junit.Test;
import static org.junit.Assert.*;
public class WriteableCommandLineImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\ud89c\udff5\uda02\udd5d\ud89c\ude60\ud82b\uddc0\ud904\udc2f", "\u9b94\u3154\u4b6d\u9213\ud2f1\ud2c1\u7e1f\u9d87\u4768\u834a\u5169\uc8fd\u0b79\u92db", "\udb32\udd0d\udb9c\udd7e\uda37\udd25\udb89\udc2e\uda92\udc66",
        46, 77034, 524649302, 8303183722759307242L, 22201L, true, false, (char) 59281, (char) 58592,
        Double.longBitsToDouble(0x3fe46b44e0d0e6d0L), Double.longBitsToDouble(0x3fd2d1afa3ec902cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 7, "\ud87e\udd06\uda02\udde4\uda9c\ude25\ud840\udc67\udb61\uddfe\ud9f4\udce6\ud8ad\uddb7\udb88\ude09\udb9d\udd77\udb44\udff7\u28d3", "\u7e1f\u9d87", "\udb10\udebe\udb69\udc39\udb4f\ude1d\udab6\uddaa\udb4a\udc40\uda48\udd82\ud9e6\ude89\ud98b\ude6f\uda37\udcbd\udb89\udc2e\uda92\udc66",
        46, 77034, 524649302, 8303183722759307242L, 22201L, true, false, (char) 54462, (char) 46106,
        Double.longBitsToDouble(0x3fbb0abd7d317f50L), Double.longBitsToDouble(0x3fd2d1afa3ec902cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\ud89c\udff5\uda02\udd5d\ud89c\ude60\ud82b\uddc0\ud904\udc2f", "\u3857\u1cc1\u8a31\u9213\ud2f1\ud2c1\u7e1f\u9d87\u4768\u834a\u5169\uc8fd\u0b79\u92db\u5856\u614a\u238f\u094f\u4382\u05ab\u2023\u7bc6\u67d8\u2866\u2e2d\ube47\uabb8\u0b03\ud066\uc94e\ucda1\ua4b3\u98c9\u829d\ub635\u4302\ucf12\u8211\uaa31\ub912\uccf1\u3abd\u5c75\u6839\u825e\u6478", "\uda38\udc9e\ud94c\udcec\ud9b1\udf96\ud9e2\uddb6\uf1a3",
        1, 94098, 1030391415, 5855008537295366663L, -32457L, false, true, (char) 49092, (char) 17673,
        Double.longBitsToDouble(0x3fdde17d853a124eL), Double.longBitsToDouble(0x3fed16b48bdd0ed4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\ud990\udc28\uda13\udc7a\uda05\ude0a\udadc\udc7a\uda4a\udf45\udb91\uded8\ud889\udeab\udb98\udd51\udb31\udc0a\udb20\udcf3\u28d3\udbef\udcaf\u3b42\udb5e\udeb4\uda08\udeb3\uda4a\udc7b\udaef\udeac\udb10\udebe\udbb9\udf82\ud9c4\uddb6\udaa9\udfa2\uda87\udf9e\udb91\udf7a\udb32\udd0d\udb8f\udc56\uda2f\ude29\udb89\udc2e\uda92\udc66\uda7e\udd0c\udac2\ude7e\udb11\udd2d", "\uabb8\u58f6\u28e5\u9fd2", "\u4a67\uda2c\udd6c",
        43, 14376, 779602258, -1034364993668364167L, -96320L, true, true, (char) 30178, (char) 64407,
        Double.longBitsToDouble(0x3fe2268544e8180aL), Double.longBitsToDouble(0x3f7eb7288cc03580L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\ud89c\udff5\uda02\udd5d\udbe1\udca5\ud82b\uddc0\uda8e\udf92", "\u9b94", "\u28d3\udbcf\uddd8",
        33, 42478, -1524853956, -2472088919705756704L, 4184L, true, false, (char) 17995, (char) 46671,
        Double.longBitsToDouble(0x3fdb6798a6203c0aL), Double.longBitsToDouble(0x3fe9d32d567d6a61L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 0, "\ud8d2\udd88", "\ud2c2", "\ud8ad\udd42",
        40, -1000, 0, 49920L, -100000L, false, false, (char) 58060, (char) 56762,
        Double.longBitsToDouble(0x3f44f85800000000L), Double.longBitsToDouble(0x3fe65c0ba8b96c92L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 4, "\ud89c\udff5\uda02\udd5d\ud89c\ude60\ud82b\uddc0\ud858\udef8", "\u9b94\u3154\u4b6d", "\u3b42\udb5e\udf4c\uda08\udeb3\ud82d\udc7f\udaef\udeac\ud92d\uddad\udacf\udf10\ud91a\udd98\ud913\udc13\uda87\udf9e\udb91\udf7a\udb32\udd0d\udb9c\udd7e",
        4, 52331, -599776638, 3757231316821730490L, -49986L, true, false, (char) 61377, (char) 64145,
        Double.longBitsToDouble(0x3fda5f33b51ad138L), Double.longBitsToDouble(0x3fca1cda14b46be8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\ud89c\udff5\uda02\udd5d\ud89c\ude60\ud82b\uddc0\ud904\udc2f\ud8fa\udf1c\ud8ad\udd42\udb88\ude09\udb2e\ude81\udb20\udcf3\u28d3\udbef\udcaf\u3b42\udb5e\udf4c\uda08\udeb3\ud82d\udc7f\udaef\udeac\udb10\udebe\udbb9\udf82\udbe4\udd30\udaa9\udfa2\uda87\udf9e\udb91\udf7a\udb32\udd0d\udb9c\udd7e\uda37\udd25\udb89\udc2e\uda92\udc66", "\u2866", "\ud979\udc96\ud823\udcb4\udb37\ude84\ud953\udfb0\ud8d3\udfcf\uf911\u4a67\uda2c\udd6c\udba4\udf9a\ud983\udf67\udbb3\udd8e\ua4ee\ud810\ude38\uda75\udfe5\ud836\ude82\uda20\ude9b",
        15, 86763, 286212008, -4494831171672832219L, -55628L, false, true, (char) 54285, (char) 32480,
        Double.longBitsToDouble(0x3feff9380941d2d5L), Double.longBitsToDouble(0x3fd19a61745fe066L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 13, 4, "\ud89c\udff5\uda02\udd5d\ud89c\ude60\ud82b\uddc0\ud904\udc2f", "\u9b94\u3154\u4b6d\u9213\ud2f1\u96e7\u7867\u9d87\u4768\u834a\u5169\uc8fd\u0b79\u92db", "\udb32\udd0d\udb9c\udd7e\uda37\udd25\udb89\udc2e\uda92\udc66",
        46, 77034, 524649302, 8303183722759307242L, 22201L, true, false, (char) 59281, (char) 58592,
        Double.longBitsToDouble(0x3fe46b44e0d0e6d0L), Double.longBitsToDouble(0x3fe3d8d7d3f31920L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 3, "\ud89c\udff5\uda02\udd5d\ud89c\ude60\ud82b\uddc0\ud904\udc2f", "\u9b94\u3154\u4b6d\u9213\ud2f1\ud2c1\u7e1f\u9d87\u4768\u834a\u5169\uc8fd\u0b79\u92db", "\udb32\udd0d\udb9c\udd7e\uda37\udd25\udb89\udcc1\uda92\udc66",
        46, 77034, 524649302, 8303183722759307242L, 22201L, true, false, (char) 38208, (char) 58592,
        Double.longBitsToDouble(0x3fe46b44e0d0e6d0L), Double.longBitsToDouble(0x3fd2d1afa3ec902cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\ud89c\udff5\uda02\udd5d\uda79\udf87\udaf8\ude80\uda65\udceb", "\u3c26\u3154\u4b6d\u9213\ud2f1\ud2c1\u7e1f\u9290\u6f7a\u834a\u5169\uc8fd\u0b79\u92db\u6082\u614a\u238f\u094f\u4382\u05ab\u2023\u4025\u5a33\u2866\u2e2d\u06e4\uabb8\u0b03\ubdac\u1511\ucd94\u88d9\u939b\u82ec\ubcdc\u7551\u47d2\ua92a\u1a3d\uca58\u1d96\u3ff3\ub33e\uaf1d\ubc26\ub067\u5bba\u3755\u99f7\u31e1\ud17e\u7aa8\ua260\u70a6\uccf2\ua281\u07a4", "\ud9c2\ude6c\uda80\udd1b\uda11\udeab\uda9e\udf9a\uda70\udf44\udb71\udd9e\udbea\uddd4\ud870\udfdd\udaea\ude7a\ud960\udea3\ud843\udec5\ud949\udce9\udbfb\udc3a\ud828\udd40\ud957\udf3a\u0985\ud8df\udde8\udbcd\udc47\ud977\udd3a",
        42, 4989, -1840999129, 1004488618351039123L, -43451L, true, true, (char) 38520, (char) 18765,
        Double.longBitsToDouble(0x3fe3f3ceb4f1e72aL), Double.longBitsToDouble(0x3fd41e411a311d02L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 4, "\ud89c\udff5\uda02\udd5d\ud89c\ude60\ud82b\uddc0\ud904\udc2f", "\u4375", "\uda31\udc75",
        -3, 40199, -672963158, 2228306413488882657L, 66240L, true, false, (char) 56384, (char) 50507,
        Double.longBitsToDouble(0x3fbd7b636db3cc50L), Double.longBitsToDouble(0x3fe880f02b3a65aaL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\ud89c\udf92w", "", "",
        -5, 59688, 0, 2205637916212493661L, -100000L, false, true, (char) 45617, (char) 56384,
        Double.longBitsToDouble(0x3fc72d9241d7b634L), Double.longBitsToDouble(0x3fdb6798a0000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 5, "\ud89c\udff5\ud879\udf39\ud89c\ude60\ud82b\uddc0\ud8f1\udf49\ud8fa\udf1c\ud8ad\udd42\udb88\ude09\udb2e\ude81\udb20\udcf3\u28d3\udbef\udcaf\u3b42\udb5e\udf4c\uda08\udeb3\ud82d\udc7f\udaef\udeac\u9faa\uda10\udcac\uda9a\udd2b\ud808\udc10\uda58\udd1f\udb91\udf7a\udb32\udd0d\udb9c\udd7e\udad1\udda8\ud868\ude8e\uda92\udc66\uda7e\udd0c\udac2\ude7e\udb11\udd2d\ud98d\udc65", "\u0b03\ud066\u9445\ucda1\ua4b3\u322d\u829d\u3b6d\u704b\ub29a\u38d6\u9335\uc390\u3ffb\ub39c\u0a2d\u8a09\u44e1\u2f8d\ua053\u1435\u023d\u051a\u3ad3\u03f7\uc457\u71c5\ub58c\ua998\u736f\u8b39\uc87b\uaaa7", "\udbbd\udd17\ud858\udd48\uda20\udd95\ud985\udc1f\ud862\ude7d\ud83f\udce6\ud826\udcc0\udaa4\udc81\ud85e\udcdd\udbcc\udf47\ud995\udff7\udba4\uddbc\uda34\uddcb\uda36\udf1a\ud923\ude82\uc183\ud822\udefb\udb53\udddf\udbba\ude7a\udb9a\udef7\uda12\udfcb\ud94d\udfc3\ud90c\udd77\ud90c\ude48\u8ba0\uda77\udfb7\ud89d\udf1e\udb95\udc3b\udaa5\udf4a\ud9da\udf4d\ud849\udf54\ud803\ude4e\uda43\udec7\udbc3\udc60\ud898\udfa6\ud9b7\udc4f\ud91a\udeb9\ud805\udf29\ud8aa\udcf7\udb94\udf67\ud8c6\udd8f",
        46, 18094, -29692221, 7817093807487950186L, 85915L, false, false, (char) 41902, (char) 64475,
        Double.longBitsToDouble(0x3fe725cf8da4798eL), Double.longBitsToDouble(0x3fc48facfe348d60L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 0, "\ud89c\udff5", "\000\u22f6\u6c8a\u9e7d", "",
        29, 87245, 212386801, -4126635768737143382L, 81217L, false, false, (char) 26880, (char) 45617,
        Double.longBitsToDouble(0x3fe65c0ba8b90092L), Double.longBitsToDouble(0x3fbd7b636db3cc50L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\ud89c\udff5\udbdc\udc63\ud89c\ude60\ud82b\uddc0\ud904\udc2f", "\u9b94\u3154\u4b6d\u9213\ud2f1\u1c9d\ua3d8\u69d7\u46af\u8770\u345f\u33ed\ucc87\u92db", "\udb32\udd0d\udb9c\udd7e\uda37\udd25\udb89\udc2e\uda86\udf60\ub174\udb11\udc9f\udb0f\udd06\uda7f\udc1e\uda50\udc2f\ud84f\ude0e\ud823\udcb4\udb37\ude84\ud953\udfb0\ud996\udc71\uf892\u4a67\uda2c\udd6c\udab9\udc63\u199d\udbf1\ude3d",
        38, 58377, 101655255, -2012950924164476580L, -37478L, true, true, (char) 38967, (char) 60931,
        Double.longBitsToDouble(0x3fee8ca218c4c8dbL), Double.longBitsToDouble(0x3fec6eda34c4fef7L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 0, "", "", "\u43f6",
        45, 81260, 3954320, 0L, -50080L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fef080000000000L), Double.longBitsToDouble(0x3f44f85800000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 4, "\ud89c\udff5\uda02\udd5d", "\u2804\u6c8a\u1716", "\udb20\udcf3\u28d3\udbef\udcaf\ud8a2\udee4\udb73\uddae\uda08\udeb3\ud82d\udc7f\udaef\udeac\udb10\udebe\ud98d\ude2b\udbe4\udd27\udaa9\udfa2\uda87\udf9e\udb91\udf7a\udb32\udd0d\udb9c\udd7e",
        2, -549, 910172802, 3757231316821730490L, 85755L, false, true, (char) 51329, (char) 38626,
        Double.longBitsToDouble(0x3fdd65307863cb30L), Double.longBitsToDouble(0x3fe47e30528d8420L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 0, "\ud857\udeea\u45f6\ud90c\udd66\ud80f\udfc0\u43f6\ud926\udef2\ud8ad\udd42\uda1d\ude93\000\000\u00dd\uc600\uda1d\udda8\000\uda08\uddd2\ub85f\udad5\ude97\ud9f6\ude1b\udba3\udf71\udbe4\udd30\ud8a0\ude7d", "\u7769\ua197\u5946\u55ee\u7e6d\ubed0\u45c8\u796f\u37cf\u62c4\u168c\ucee9\ud7d5\u2363\u744a\u380e\u8e0e\u8d1d\uc44d\u1307\ua6ee\u2639\u2739\u1d00\u4c40\u6787\u1a01\u6186\u7c5a\u24e3\u27c8\u9470\uae54\u2278\ud182\u6175\u9d5b\u80b6\u5a78\u8e8e\u7f9b\u100b\u700b\ua321\ua7d0\u4670\u8b6c\u2d73\ucf60\u8f53\ucc4c\u667e\u3af2\u6c90\uae9e\u7793\u367b\u3957\u8966\u5f11\u3b63\u4e57\u4672\u9c8c\u3a0f", "\ud9a0\udde8\ud985\udcb2\ud907\ude7b\udb32\udc1b\udb13\udd73\udaf4\ude4b\ud8a4\udcb5\uda94\udfa9\ud890\udc93\ud99d\udc25\ud988\udd7f\uda23\udff6\u739c\ud96f\udfb0\ud945\udc21\ud9ed\ude1a\ud934\udc76\ud970\udec4\ud89d\udc3c\ud844\uddab\udbde\udd5f\ud8a0\udc07\ud83c\udcce\ud861\udc44\ud93a\ude54\uc517\uda72\udcfe\udbac\udf3d\ud975\udc9c\udba8\ude28\uda96\ude24\udb94\udf61\udb35\udfea\ud9fe\udee1\udadf\udd06\udada\udc45\udadb\udcb7\uda73\udebd\uda9f\udd4f\uda55\udcb3\uda8e\udd27\ud9cb\ude5a\ud978\udcf8\uda6a\uddf3\udb3f\udef1\uda98\udfad\ud87e\ude8f\ud952\udca5\ud907\ude53\ud835\udf1e\udb0d\udcba\ud911\udf0a\ud9e9\udc3b\ud8e9\udcb3\ud843\udd54\ud928\udebb",
        59, 40894, 914807449, 1107886115852484077L, 63283L, false, false, (char) 63632, (char) 33402,
        Double.longBitsToDouble(0x3fe32904ade9dedbL), Double.longBitsToDouble(0x3fec5e4198924347L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getValues|org.apache.commons.cli2.Option,java.util.List|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addProperty|java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addProperty|org.apache.commons.cli2.Option,java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addSwitch|org.apache.commons.cli2.Option,boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addValue|org.apache.commons.cli2.Option,java.lang.Object|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getNormalised||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getOptionTriggers||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getOptions||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getProperties||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getProperties|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getProperty|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getProperty|org.apache.commons.cli2.Option,java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getSwitch|org.apache.commons.cli2.Option,java.lang.Boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getValues|org.apache.commons.cli2.Option,java.util.List|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
