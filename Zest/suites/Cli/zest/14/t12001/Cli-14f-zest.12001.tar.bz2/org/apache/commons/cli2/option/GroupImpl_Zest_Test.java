package org.apache.commons.cli2.option;
import org.junit.Test;
import static org.junit.Assert.*;
public class GroupImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\ud8e8\udc9f\udaef\udf87\ud8c9\uddeb\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\ud82c\udcfe\udae2\udf6c\udb91\ude21\udb83\ude96\ud895\udcf1\u1d4b\ud9a0\udf16\ud94c\udd76\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\ud985\udd2a\udba0\udeb1\uda90\udec1\udb41\udd0d\u627f\udacf\udedd\ud8cd\ude2b\ud867\udc90\ud9b9\udd9d\uda2d\udf0f\udb74\udfaa\udaa4\udc20\udb24\ude78\u6d27\ud954\ude43\ud8d4\udc33\uda6d\udf70\uda9b\udc33\ud81f\uddd7\ud91f\udd40\ud984\uddff\ud98b\udc35\udb08\ude0f\udbe4\udcc3\ud874\udd5f\ud84d\udcd1\udad0\uddf5\udb64\uddf1\ud922\udc59\ud912\uddcc\ud8ce\udcf2\udb2e\udc71\ud870\ude8d\ud8c1\udff7\ud9cf\ude70\ud8ce\udc4b\udb9f\udd60\udb52\udfbc\ud812\udc6b\u02f3\uda70\udd36\udba1\udc0e\ud8d5\udfe8\udbeb\udc36\ud993\udcc4\ud81c\ude09\udaaa\udc01", "\u44ab\ubdbe\u60e3\u11af\u3445\u9732\uc85e\u01e5\uad12", "\ud8f0\udf78\ud80d\udcb5\udab9\udf14\udb4c\ude44\uda60\udf85\udbf3\udd4c\ud8c8\ude71\ud808\udfd2\uda40\udc70\ud91d\uddc7\ud9a2\udfcd\ud9d9\udea1\ud809\udd17\ud9ec\udd25\udb3f\udd7d\uda5b\udfc6\ud8c9\udf65\ud866\udfe6",
        7, 25216, 1166666819, 9090491979123307909L, -61140L, false, false, (char) 23333, (char) 47434,
        Double.longBitsToDouble(0x3fe70ea14e245071L), Double.longBitsToDouble(0x3fb3602660dd34b8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\ud987\udecb\ud98f\udc84\ud8e8\udc9f\udaec\ude87\udb5f\udc06\ud9e1\uddbb\ud92b\ude19\uda64\udd22\ud8cb\udd2c\ud9fb\udca5\udb40\udc76\ud9f5\uddec\ud9b4\ude26\udb91\ude21\udb83\ude96\ud895\udcf1\u1d4b\ud9a0\udf16\ud99d\udcbf\ud83a\udf98\ud9f5\udc5c\ud9ff\uddd2\ud985\udd2a\ud99e\udff0\udbfb\udfc8\udb41\udd0d\udbde\udf28\udacf\udedd\uda6a\udf2a\ud867\udc90\ud9b9\udd9d\uda2d\udf0f\udb74\udfaa\udaa4\udc20\udb24\ude78\u6d27\ud954\ude43\ud8d4\udc33\uda6d\udf70\uda9b\udc33\uf574\ud91f\udd40\ud984\uddff\ud98b\udc35\udb08\ude0f\udbe4\udcc3\ud874\udd5f\ud84d\udcd1\udad0\uddf5\udb64\uddf1\u985c\ud912\uddcc\ud8ce\udcf2\udb2e\udc71\ud870\ude8d\ud8c1\udff7\ue625\ud995\udd95\udb9f\udd60\udb52\udfbc\udb1e\udfed\u033d\uda70\udd36\udba1\udc0e\ud8d5\udfe8\udbeb\udc36\ud993\udcc4\ud81c\ude09\udaaa\udc01", "\u44ab\u16a9\u7b4b\u392c\u3445\u9732\uaeea\u3e31\uad12", "\ud8f0\udf78\ud80d\udcb5\udab9\udf14\udb4c\ude44\uda60\udf85\udbf3\udd4c\ud8c8\ude71\ud99f\udde5\uda52\udf0b\ud91d\uddc7\udb75\uddf7\ud838\udf0b\ud9a0\ude9e\ud9ec\udd25\udb3f\udd7d\uda5b\udfc6\ud8c9\udf65\ud866\udfe6",
        0, 25216, 1019387203, 9090492520289187205L, -48084L, false, false, (char) 23333, (char) 47434,
        Double.longBitsToDouble(0x3fe70ea14e245071L), Double.longBitsToDouble(0x3fe0d29ccc1ba61eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\uda2f\udeba\udbe4\udce2\udb5d\udcc3\ud91c\udc9b\ud995\udd6d\uda64\udd22\ud8cb\udd2c", "\u22a6", "\udb83\ude96\ud895\udcf1\u1d4b\ud9a0\udf16\ud94c\udd76\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\ud985\udd2a\udba0\udeb1",
        47, 46260, 586082416, 4450149315627896447L, 83507L, false, false, (char) 41630, (char) 5478,
        Double.longBitsToDouble(0x3fedeecb5b20dfcaL), Double.longBitsToDouble(0x3fd862414e250098L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 10, 15, 6, "\ud9cb\udecc\ud959\udd16\ud8e8\udc9f\udaef\udf87\ud8c9\uddeb\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\ud953\uddf1\udb05\udf74\udb91\ude21\udb83\ude96\ud895\udcf1\u1d4b\ud9a0\udf16\ud94c\udd76\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\ud985\udd2a\udba0\udeb1\uda90\udec1\udb41\udd0d\u627f\udacf\udedd\ud8cd\ude2b\ud867\udc90\ud9b9\udd9d\uda34\udd0f\udb74\udfaa\udaa4\udc20\udb24\ude78\u6d27\ud954\ude43\ud8d4\udc33\uda6d\udf70\udab4\udc33\ud81f\uddd7\ud91f\udd40\ud984\uddff\ud98b\udc35\udb08\ude0f\udbe4\udcc3\ud874\udd5f\ud84d\udcd1\udad0\uddf5\udb64\uddf1\ud922\udc59\ud912\uddcc\ud8ce\udcf2\ud910\udec1\udbcb\udfda\ud8f0\udd3c\ud9cf\ude70\ud8ce\udc4b\udb9f\udd60\udb52\udfbc\ud812\udc6b\udb7a\udfff\ud94b\udef8\udba1\udc0e\ud8d5\udfe8\udbeb\udc36\ud993\udcc4\ud81c\ude09\udaaa\udc01", "\u44ab\ubdbe\u60e3\u11af\u3445\u9732\uc85e\u01e5\uad12", "\udb85\ude44\u492a\udab9\udf14\udb4c\ude44\uda60\udf85\udbf3\udd4c\ud8c8\ude71\ud808\udfd2\uda40\udc70\ud91d\uddc7\ud9a2\udfcd\ud9d9\udea1\ud809\udd17\ud9ec\udd25\udb3f\udd7d\uda5b\udfc6\ud8c9\udf65\ud866\udfe6",
        7, 25216, 1166666819, 9090491979123307909L, -61140L, false, false, (char) 23333, (char) 47434,
        Double.longBitsToDouble(0x3fe70ea14e245071L), Double.longBitsToDouble(0x3fb3602660dd34b8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\ud8e8\udc9f\udaef\udf87\ud8c9\uddeb\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\udbbb\udda5\udae2\udec1\udb91\ude21\udb83\ude96\ud895\udcf1\u1d4b\ud9a0\udf16\ud94c\udd76\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\ud985\udd2a\udba0\udeb1\uda90\udec1\udb41\udd0d\u627f\udacf\udedd\ud8cd\ude2b\ud867\udc90\ud9b9\udd9d\uda2d\udf0f\ud823\udc6b\udac1\udd7c\ud93c\udce5\ud99e\udec7\ud954\ude43\ud8d4\udc33\uda6d\udf70\uda9b\udc33\ud81f\uddd7\ud91f\udd40\ud984\uddff\ud98b\udc35\udb08\ude0f\udbe4\udcc3\ud874\udd5f\ud84d\udcd1\udad0\uddf5\udb64\uddf1\ud922\udc59\ud912\uddcc\ud8ce\udcf2\udb2e\udc71\ud870\ude8d\ud8c1\udff7\ud9cf\ude70\ud8ce\udc4b\udb9f\udd60\ud832\udf4b\ud9ec\udc35\ud98b\udcf3\udb4c\udda1\udba1\udc7c\ud8d5\udfe8\udbeb\udc36\ud993\udcc4\ud81c\ude09\udaaa\udc01", "\u44ab\ubdbe\u1f11\u11af\u3445\u9732\uc85e\u01e5\uad12", "\ud8f1\udc23\ud9da\ude56\udb76\ude2d\udb4c\ude44\uda60\udf85\udbf3\udd4c\ud8c8\ude71\ud808\udfd2\uda40\udc70\ud91d\uddc7\ud9a2\udfcd\ud9d9\udea1\ud809\udd17\ud9ec\udd25\udb3f\udd7d\uda5b\udfc6\ud8c9\udf65\udbfb\udcb0",
        52, 25216, 1166666819, 9090491979123307909L, 90186L, false, false, (char) 24330, (char) 16021,
        Double.longBitsToDouble(0x3fb3602660dd34b8L), Double.longBitsToDouble(0x3fd74d48b6205800L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\ud8e8\udc9f\udaef\udf87\ud8c9\uddeb\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\ud82c\udcfe\udae2\udf6c\udb91\ude21\u431e\ud895\udc57\ub85f\000\ud96d\udf96\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\000\udba0\uddd5\uda90\udec1\udb41\udd0d\u627f\ud8f2\udf98\ud8cd\ude2b\ud867\udc90\ud9b9\udd9d\uebb6\uda29\udfb4\udaa4\udc20\udb24\ude78\u6d27\ud954\ude43\ud8d4\udc33\uda6d\udf70\uda9b\udc33\ud81f\uddd7\ud91f\udd40\ud984\uddff\ud98b\udc35\udb08\ude0f\udbe4\udcc3\ud874\udd5f\ud963\udedd\000\udb64\uddce\ud922\udc59\ud912\uddcc\ud8ce\udcf2\udab3\udc73\uda5a\udced\ud8c1\udff7\ud9cf\ude70\000\udb62\udf11\udb1a\udf2d\ud812\udc6b\udbbe\udfdf\uda70\udd36\ud8f8\udc3a\udbf6\udd5a\udbeb\udc36\ud993\udcc4\ud81c\ude09\udaaa\udc01", "\u2460\000\u6086V\u33a4\u9732\uc85e\u01e5\uad12", "\ud8f0\udf78\ud80d\udcb5\uda81\udc14\014\000\000\ud8c8\ude71\ud808\udfd2\uda40\udc70\000\ud9a2\udfb6\ud9d9\udea1\ud809\udd17\ud9ec\udd25\u0620\udbde\udc0e\ud89e\udfae\ud866\udfe6",
        7, -824, 0, 9090491979123307909L, 90186L, false, false, (char) 24330, (char) 16021,
        Double.longBitsToDouble(0x3fb3602640000000L), Double.longBitsToDouble(0x3fe11270fdd129fbL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 10, "\udaca\udd63\ud959\udd59\ud8e8\udc9f\ud8f9\udf8c\ud89d\udcd5\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\ud82c\udcfe\udae2\udf6c\udb91\ude21\udb83\ude96\ud895\udcf1\u1d4b\ud9a0\udf16", "\uadec\u16e5\ua269\u778d\u41e8", "\udacf\udedd\ud8cd\ude2b\ud867\udc90\ud9b9\udd9d\uda2d\udf0f\udb74\udfaa\udaa4\udc20\udb24\ude78\u6d27\ud954\ude43\ud8d4\udc33\uda6d\udf70\uda3d\udc24",
        11, 25968, -2142484090, -3498998867190253574L, 26872L, false, false, (char) 33131, (char) 32756,
        Double.longBitsToDouble(0x3fee25c6f5b38225L), Double.longBitsToDouble(0x3fc1f7b9b1a30ad0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\ud8e8\udc9f", "\ud57f\ub0e2\u9a8f\u6cbc\u06bc\u43f1", "\udb91\ude21\udb83\ude96\ud895\udcf1\u1d4b",
        18, 95593, -859500832, 8289312260376898905L, 19516L, false, true, (char) 19965, (char) 40801,
        Double.longBitsToDouble(0x3fe9d117767f3dc2L), Double.longBitsToDouble(0x3fe73fd391b1946eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\ud8e8\udc9f\udaef\udf87\ud8c9\uddeb\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\000\ud82c\udcfe\udae2\udf6c\udb91\ude21", "\u7b5b\u3a1e\u3a19\u1228\uadec\u16e5\ua269\u778d\u41e8\u8ac5\u29d7\u346c\u7fea", "\uda2d\udf0f\udb74\udfaa",
        41, 20236, 371392512, -3131465384994041156L, 92750L, false, true, (char) 61533, (char) 52495,
        Double.longBitsToDouble(0x3fe6d08314326539L), Double.longBitsToDouble(0x3fe11b0e8fc4b8deL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 9, 6, "\ud865\udf74\ud959\udd59\ud8e8\udc9f\ud9fe\ude66\u0d4a\ud90b\uddf0\udb1a\udee2\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\udaf0\udc14\udae2\udf59\udb91\ude21", "\u7b5b\u3a1e\u855b\u9e24\uadec\uba26\u8e45\uc96c\u4f37\u8ac5\u545f\u346c\u7fea", "\uda2d\udf0f",
        35, 46636, -2067549764, -862156922385937197L, -25814L, true, false, (char) 33144, (char) 21250,
        Double.longBitsToDouble(0x3fd862414e250098L), Double.longBitsToDouble(0x3fefd67b8c67bba1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\ud8e8\udc9f\udaef\udf87\ud8c9\uddeb\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\ud82c\udcfe\udae2\udf6c\udb91\ude21\udb83\ude96\ud895\udcf1\u1d4b\ud9a0\udf16\ud94c\udd76\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\ud985\udd2a\udba0\udeb1\uda90\udec1\udb41\udd0d\u627f", "\u2369\u309a\ud714\u3e35\u4561\u9fac", "\ud8d4\udc33\uda6d\udf70\uda9b\udc33\ud81f\uddd7\ud91f\udd40\ud984\uddff\ud98b\udc35\udb08\ude0f",
        46, 40184, 1698262746, 7048445891692076579L, 64429L, true, false, (char) 12061, (char) 61025,
        Double.longBitsToDouble(0x3fecfc426d49c1f9L), Double.longBitsToDouble(0x3fc4f17ac93ed82cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\ud8ae\udc7e\ud822\ude85\uda58\ude1d\udb10\udfa1\ud8c9\uddeb\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\ud82c\udcfe\udae2\udf6c\udb91\ude21\udb83\ude96\ud895\udcf1\u1d4b\ud9a0\udf16\ud94c\udd76\ud83a\udfdb\udb80\udde2\ud8d8\udc3c\ud96f\udd55\udba0\udeb1\u00d8\udba2\udcf6\u61ae\udacf\udedd\ud8cd\ude2b\ud867\udc90\ud9b9\udd74\uda2d\udf0f\udb74\udfaa\udaa4\udc20\udb24\ude78\u6d27\ud954\ude43\ud8d4\udc33\uda6d\udf70\uda9b\udc33\ud98e\udecd\ud91f\udd40\ud984\uddff\ud98b\udc35\udb08\ude0f\udbe4\udcc3\ud874\udd5f\ud84d\udcd1\udad0\uddf5\udb64\uddf1\ud922\udc59\ud912\uddcc\ud8ce\udcf2\udb2e\udc71\ud870\ude8d\ud8c1\udff7\ud9cf\ude70\ud8ce\udc4b\udb9f\udd60\udb52\udfbc\ud812\udc6b\u02f3\uda70\udd36\udba1\udc0e\ud8d5\udfe8\u6b5f\ud9e4\udf2e\uda75\udfad\uda45\udc27", "\u44ab\uc7aa\u9a6c\u11af\u3445\u9732\u1a26\u029b\uad12\u303b\u4803\u7e1f\u0570\u1708\ua44a\u5f44\u268a\u6201\ubf8c\u9c8b\u95ac\u2101\ua24e\u9386\uc3cf\ubb18\uc401\u6d3a\u5fe5\u1d1c\u9eda\ucead\u47d0\u1d24\u3b3e\u20c1\u8476\u8e71\u743a\u8238\u7f25\u6a55\u885c", "\udbd0\udeb2\uda3e\udf71\ud970\ude3b\ud8f3\udf33\ud913\udef7\ud8c5\udd20\udb76\udc6a\ud955\udc8e\udb7d\udf61\uda4a\udc11\ud8c7\udece\uda14\udd03\uda72\udf17\ud9b9\udd90\udb9b\ude6e\udb18\udfb2\ud98c\udd20\udb62\udea3\ufca1\ud9fb\udd8c\ud97c\udd8a\uda85\uddfb\ud819\udffa",
        51, 19441, 2042498419, 4161654652729351981L, -31489L, true, true, (char) 47065, (char) 56520,
        Double.longBitsToDouble(0x3fe2a90f17af55abL), Double.longBitsToDouble(0x3fa925287d8f7cf0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\uda2f\udeba\udbe4\udce2\udb5d\udcc3\ud91c\udc9b\ud8a6\udf96\ufc16\ud8cb\udd2c", "\u22a6", "\udb83\ude96\udac8\udfcb\ud9f0\udd93\uda0f\udf89\ud95e\udde5\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\ud985\udd2a\udba0\udeb1",
        47, 46260, 586082416, 4450149315627896447L, -11869L, false, true, (char) 28058, (char) 36702,
        Double.longBitsToDouble(0x3fdb02bd47925582L), Double.longBitsToDouble(0x3fe740d9c9850d24L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 14, 12, "\ud9d1\udf51", "\u5380\u67e8", "\uda64\udd22\ud8cb\udd2c",
        13, 26644, -1524529575, 4502772165077653445L, 23606L, false, true, (char) 14549, (char) 64195,
        Double.longBitsToDouble(0x3fbd87b3a9e7d980L), Double.longBitsToDouble(0x3fe18967c550fd35L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udb02\udee8", "\u539c", "\ud97e\udc1e",
        2, -1000, -601423872, 4191310429269524569L, -77728L, false, true, (char) 52100, (char) 518,
        Double.longBitsToDouble(0x3ec0876635f40000L), Double.longBitsToDouble(0x3fe707cbb595ccc5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "", "\ub8c8\u539c\u67e8\uca82\ud7b2\u9a8f\u6b9c", "\ud868\udca3",
        26, 1509, 988496670, 5307369676978829407L, 14215L, false, false, (char) 23130, (char) 41058,
        Double.longBitsToDouble(0x3fdf6080e5b86cc2L), Double.longBitsToDouble(0x3fd50fd352b9a940L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "", "", "\udb5d\udcc3",
        17, 4463, 81, 6625858279004642516L, -71L, true, true, (char) 38466, (char) 44822,
        Double.longBitsToDouble(0x3fc3475d617d269cL), Double.longBitsToDouble(0x3fdd653843b31afaL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 2, 15, 6, "", "\000\u539c", "\000",
        51, -1000, -601423872, 4191310429269524569L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e2d98d000000000L), Double.longBitsToDouble(0x3fe70003b595ccc5L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\ud8e8\udc9f\udaf7\udf87\ud8c9\uddeb\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\ud82c\udcfe\udae2\udf6c\udb91\ude21\uda60\udf2e\udaa8\uddd4\u1dac\ud9a0\udf16\ud94c\udd76\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\ud985\udd2a\udba0\udeb1\uda90\udec1\udb41\udd0d\u627f\udacf\udedd\ud8cd\ude2b\ud867\udc90\ud9b9\udd9d\uda2d\udf0f\udb74\udfaa\udaa4\udc20\udb24\ude78\u6d27\uda71\udc3c\ud8d4\udc33\uda6d\udf70\uda9b\udc33\ud81f\uddd7\ud91f\udd40\ud984\uddff\ud80e\udd98\uda73\ude92\udb72\udc8f\ud88f\udc30\ud84d\udcd1\udad0\uddf5\udb64\uddf1\ud922\udc59\ud912\uddcc\ud9c6\udf10\udb2e\udc09\ud870\ude8d\ud8c1\udff7\ud9cf\ude70\ud8ce\udc4b\udb9f\udd60\udb52\udfbc\ud812\udc6b\u02f3\uda70\udd36\udba1\udc0e\ud8d5\udfe8\uda32\udf9a\ud993\udcbe\ud81c\ude09\udaaa\udc01", "\u44ab\ubdbe\ub960\u1edf\u3445\u9732\uc85e\u3e0a\uad12", "\udb1d\udf90\udb41\udc47\udab9\udf14\udb4c\ude44\uda60\udf85\udbf3\udd4c\ud8c8\ude71\ud808\udfd2\uda40\udc70\ud91d\uddc7\ud9a2\udfcd\ud9d9\udea1\ud809\udd17\ud9ec\udd25\udb3f\udd7d\uda5b\udfc6\ud8c9\udf65\ud839\udd10",
        11, 54996, 1166666819, 9090491979123307909L, -61140L, false, false, (char) 23333, (char) 47434,
        Double.longBitsToDouble(0x3fe70ea14e245071L), Double.longBitsToDouble(0x3fb3602660dd34b8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 6, 12, "\udac5\udc18\ud959\udd59\ud8e8\udc9f\udaef\udf87\ud8c9\uddeb\ud92f\uddff\ud92b\ude19\uda64\udd22\ud8cb\udd2c\udb16\udff3\ud9fc\ude6e\ud82c\udcfe\ud99e\udf6a\udb91\ude21\udb83\ude96\ud895\udcf1\uda29\udf17\udbf7\udd26\udaaa\udc18\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\ud985\udd2a\udba0\udeb1\uda90\udec1\uda09\udf6b\udaaa\udccf\ud9d8\udde8\ud8cd\ude2b\ud867\udc90\ud9b9\udd9d\uda2d\udf0f\udb74\udfaa\udaa4\udc20\udb24\ude78\u6c9c\ud954\ude43\ud8d4\udc33\uda6d\udf70\uda9b\udc33\udbec\udc7d\udad2\udf7e\ud9d3\udf04\ud98b\udc4f\udb08\ude0f\udbe4\udcc3\ud874\udd5f\ud84d\udcd1\udad0\uddf5\udb64\uddf1\ud922\udc59\udbb7\udeff\ud8d8\uddae\udb2e\udc71\ud870\ude8d\ud8c1\udff7\ud9cf\ude70\ud8ce\udc4b\udb9f\udd60\udb52\udf34\ud812\udc6b\u02f3\uda70\udd36\udba1\udc0e\udabf\udd3c\udac9\ude6e\ud827\udf73\ud81c\ude09\udaaa\udc01\ud85a\udd3e\uda10\udfae\ud8ab\udca9\ud9fd\udf74\uda8f\udd3a\ud96e\udef7\udb1e\udd5c\ud962\ude6a\ud955\udd93\ud982\udf96\udb09\uded3\udae7\udd51\udb8d\udfd3\ud8f0\udf78\ud80d\udcb5\udab9\udf14\udb4c\ude44\uda5d\udc85\udbf3\udd4c\ud8c8\ude71\ud808\udfd2\ud96f\udc65\ud935\udd75\ud9a2\udfcd\ud8e5\udea7\ud809\udd17\ud92f\ude3d\udb3f\uddfa\uda5b\udfc6\ud8c9\udf65\ud866\udfe6\udb04\udf75\ue61f\ud830\udc5c\ud8dc\uddba\ud9ff\udfee\uda46\udfc2\udab3\udc40\uda20\udd8d\ud91a\udf7c\uda5b\udd9a\uda5f\udf9e\udbf5\udea1\ud85b\udf08\udbfe\udf7b\udb12\ude47", "\u69ed\u5cb4\u4416\ud0af\ucae4\ua327\uc7c9\ud295\u61ed\ud5b9\u60c7\u3244\ua89a\ua077\uc4fa\u0d32", "\udb28\udc51\udbb5\udcae\ud9ff\uddad\udb58\udf19\ud882\udee6\u3e5f\ud9a8\udf54\ud809\udc3a\ud96b\uddd9\udb79\ude21\ud865\udcb7\udbc2\udc7d\ub21b\ud9c8\ude18\udb84\uddfb\ud853\ude7b\udad3\udeb9\udb21\udf1a\ud9d1\udf45\ua0bc",
        47, 58371, -256372587, 343055061444735238L, -38787L, false, true, (char) 39881, (char) 30065,
        Double.longBitsToDouble(0x3fdc188d72f69e34L), Double.longBitsToDouble(0x3f99ceba3b61fe60L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 6, "\udac5\udce9\ud959\udd59\ud8e8\udc9f\udab2\ude95\udb37\ude91\ud90a\udf40\ud92b\ude19\udae2\udf41\ud8cb\udd08\udb16\udff3\ud9fc\ude6e\ud841\udcfe\udae2\udf6c\udb91\ude21\u431e\ud895\udc57\ub85f\000\ud96d\udf96\ud83a\udfdb\ud9f5\udc5c\ud9ff\uddd2\u008e\udba0\uddd5\uda90\udec1\udb41\udd0d\u627f\ud8f2\udf98\ud8cd\ude2b\ud867\udc90\ud9b9\udd9d\uebb6\uda29\udfb4\u4688\uc92b\ud873\udd5c\ud873\udf66\ud8d4\udc33\uda6d\udf70\uda9b\udc33\ud81f\uddd7\ud91f\udd40\ud984\uddff\ud98b\udc35\udb08\ude0f\udbe4\udcc3\ud874\udd5f\ud963\udedd\000\udb64\uddce\ud922\udc59\ud912\uddcc\ud8ce\udcf2\udab3\udc73\uda5a\udced\ud8c1\udff7\ud9cf\ude70\000\udb62\udf11\udb1a\udf2d\uda2d\ude26\udbfa\ude00\ud831\udf16\uda6b\udf32\ud88c\udd94\ud8be\udfc0\ud993\udcc4\ud81c\ude09\udaaa\udc01", "\uc53c\u051a\u9d93V\ubebc\u9732\uc85e\u01e5\uad12", "\ud8f0\udf78\uda7a\ude5b\ud920\uddbd\ud8ad\ude71\000\ud9d2\udc48\ud82e\udd36\ud808\udfd2\uda40\udc70\000\uda0e\udc8b\ud9d9\udea1\ud809\udd17\ud918\udc2a\udbe3\udce1\udbde\udc0e\ud89e\udfae\ud866\udfe6",
        7, -824, 0, 9090491979123307909L, -56223L, true, true, (char) 28426, (char) 33899,
        Double.longBitsToDouble(0x3fefd3bb0451d2cbL), Double.longBitsToDouble(0x3fe694f418ea7a8bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.option.GroupImpl|validate|org.apache.commons.cli2.WriteableCommandLine|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|appendUsage|java.lang.StringBuffer,java.util.Set,java.util.Comparator|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|appendUsage|java.lang.StringBuffer,java.util.Set,java.util.Comparator,java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|canProcess|org.apache.commons.cli2.WriteableCommandLine,java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|defaults|org.apache.commons.cli2.WriteableCommandLine|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|findOption|java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getAnonymous||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getDescription||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getMaximum||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getMinimum||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getOptions||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getPreferredName||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getPrefixes||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getTriggers||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|helpLines|int,java.util.Set,java.util.Comparator|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|isRequired||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|validate|org.apache.commons.cli2.WriteableCommandLine|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
