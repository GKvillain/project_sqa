package org.apache.commons.cli2.option;
import org.junit.Test;
import static org.junit.Assert.*;
public class GroupImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud841\udc1b\ud8b0\udc1c\ud98d\udd62\udabf\udf88\udb63\udc52\udbdc\ude9c\uda97\udffe\udb92\udc6b\ud941\udc97", "\uba9b\u67e3\uc2d5\ud646\u6e74\u4fda\u44d3\u06bfW\u7f59\u11cb\uc7d2\u7b4e\ud0ee\uc195\ubf49\u9b8d\u42c7\u09c9\uaf13", "\ud87f\udf79\ud86b\ude8f\ud864\udfc5\uda61\ude5c\ud9a1\ude70\u3ec5\udbd5\uded1\udb43\udc8a\ud815\udd3c",
        25, 757, -2135193270, 795621845578600639L, -15918L, true, false, (char) 34435, (char) 58072,
        Double.longBitsToDouble(0x3fdacd3005dc0680L), Double.longBitsToDouble(0x3fdd16593b459f04L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\ud85b\ude52\udaa9\udf26\udb7e\udc76\uec39\uda23\udd12\ud93c\udcc5\ud98d\udd62\udabf\udf88\udb63\udc52\udbdc\ude9c\udac9\ude29\udab4\udf16\ud941\udc97", "\uba9b\u67e3\uc2d5\ud646\u6e74\u4fda\u44d3\u06bfW\u7f59\u11cb\uc7d2\u7b4e\ud0ee\uc195\ubf49\u9b8d\u42c7\u09c9\uaf13", "\ud87f\udf79\ud86b\ude8f\ud864\udfc5\uda61\ude5c\ud9a1\ude70\u3ec5\udbd5\uded1\udb43\udc8a\ud815\udd3c",
        25, 757, -2135193270, 795621845578600639L, -15918L, true, false, (char) 34435, (char) 58072,
        Double.longBitsToDouble(0x3fdacd3005dc0680L), Double.longBitsToDouble(0x3fba5964ed167bd8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud822\udc9e\ud8ab\udd9b\udaa9\udfbc\udb7e\udc76\ud9ba\udd19\u4902\ud89c\udd65\ud9b0\udf12\udb94\udc68\udb61\udc92\udbdc\ude9c\uda97\udffe\udb92\udc6b\udb81\udd76", "\u38dd\u67e3\u790b\u0215\u6ea0\u4fda\u44d3\u06bfW\u7f59\u44cb\uc7d2\u7b4e\ud0ee\uaded\u99fc\u9243", "\udb37\ude9d\ud95d\udc34\udadb\udea8\ud97f\ude1a\udae2\udc10\ud864\udfc5\uda61\ude5c\ud9a2\ude70\ud939\udf2d\udbd5\uded1\udb43\udf8a\ud13c\uda77\udd92\ud925\udfde\udbe0\uddc9\uda16\udeac\udb9d\udef2\ud9f0\uddbc\ud8ad\udcdf\uda2c\udca3\ud9b8\udfc0\ud844\udff2\udbb0\udd29\udb8f\udf57",
        22, 15098, -682431449, 6605810886268691341L, 93603L, true, true, (char) 30403, (char) 42084,
        Double.longBitsToDouble(0x3fd0736bf902926cL), Double.longBitsToDouble(0x3fdd14feb174fb08L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 15, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud841\udc1b\ud8b0\udc1c\ud98d\udd62\udabf\udf88\udb63\udc52\udbdc\ude9c\uda97\udffe\udb92\udc6b\ud941\udc97", "\uba9b\u67e3\uc302\ud646\u6e74\u4fda\u44d3\u06bfW\u7f59\u576c\uc7d2\u7b4e\ud0ee\uc195\ubf49\u9b8d\u42c7\u09c9\uaf13", "\ud87f\udf79\ud86b\ude8f\ud864\udfc5\uda61\ude5c\ud9a1\ude70\u3ec5\udbd5\uded1\udb43\udc8a\ud815\udd3c",
        25, 757, 784042314, 795621845578600639L, -15918L, true, false, (char) 34435, (char) 58072,
        Double.longBitsToDouble(0x3fdacd3005dc0680L), Double.longBitsToDouble(0x3fdd16593b459f04L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud841\udc1b\ud8b0\udc1c\ud98d\udd62", "\u5034\u9ebf\u4117\u1aff\u31ea\u2704\uba9b\u67e3\uc2d5\u2263\u7a77\u4fda\u44d3\u06bf\u3c1b\u48bf\u8bb6\u92a5\u7b4e\ud0ee\uc195\ubf49\u9b8d\u42c7", "\ud95d\udc34\ud98a\udc3f\ud87f\udf79",
        12, 91173, 494443680, -2109003858578015059L, -48758L, true, false, (char) 59992, (char) 7829,
        Double.longBitsToDouble(0x3fc7e1615a61a500L), Double.longBitsToDouble(0x3fbc86eb13be1ae8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud9a9\udc0f\ud8b0\udc1c\ud98d\udd62\udabf\udf88\udb63\udc52\udbdc\ude9c\uda97\udffe\udb92\udc6b\ud928\ude4a", "\ubab0\u67e3", "\u3fe0\udb7f\udc08\ud998\udec9\ud92b\udc96\uda3b\udef5\ud8b4\udff6\ud819\udf07",
        34, 98361, -1905578099, 4455291819968929321L, -78103L, false, false, (char) 18937, (char) 53859,
        Double.longBitsToDouble(0x3fec24d2c3e5d9a5L), Double.longBitsToDouble(0x3fd2426baa95b854L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 6, 12, 5, "\ud8eb\udd52\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud841\udc1b\ud8b0\udc1c\udb9c\udd97\udaa8\udd9e\udb63\udce9\udbdc\ude9c\uda97\udffe\u9c0c\ud841\udde9\uda55\udf2d\ud8aa\udc31\udafa\ude38\ud83f\ude83\ud9fc\ude24\ud950\ude84\ud87b\udc35\udb7e\udfaa\ud998\udec9\ud92b\udc96", "\u11cb\uc7d2\u7b4e\ud0ee\uc217", "\ud961\uded2\udb21\ude80\udafe\udcc7\ud95d\udc34\ud95d\udd41\ud87f\udf79\ud86b\ude8f\ud864\udfc5\uda61\ude5c\ud9a1\ude70\u3ec5\udb4d\udecd\udb43\udc8a\ud815\udd3c\ud8ee\udfe8\udbab\udeca\uda1f\udd55\uda0e\uddc9\ud9d7\udddf\ud9cc\udc5c\udaae\udc7f\uda2c\udc37\ud805\udfde\ud844\udff2\ud817\udddd\ud98e\udcea\ud9b2\udef5\udaa1\udd2d\ud8b1\udfa7\udbf3\udfa5\udbbf\udfb5\udac2\udf61\udbe9\udc14\ud9d8\ude64\udac7\ude30\ud910\udf28\udadb\ude55\udb8b\udfd8\ud95b\udcda\udb0b\uddfe\udbb1\ude6b\uda28\udda1",
        38, 46438, -335533779, -5031235113208631299L, 93167L, true, true, (char) 248, (char) 37981,
        Double.longBitsToDouble(0x3fe264b02360455dL), Double.longBitsToDouble(0x3fea206ea9b7555dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud841\udc1b\ud8b0\udc1c\ud98d\udd62\udabf\udf88\udb63\udc52\udbdc\ude9c\uda97\udffe\udb92\udc6b", "\u2704\uba9b\u67e3\uc2d5\ud646\u6e74", "\ud92b\udc96",
        12, 80916, -673820315, -8441132553823072135L, 7620L, false, false, (char) 53845, (char) 8668,
        Double.longBitsToDouble(0x3fef2ecd2f283cbaL), Double.longBitsToDouble(0x3fd5df5de940d96eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd", "\ua8c4\u2741\u1e9e\u5034\u9ebf\u4117\u1aff\u3245\u26bf\uba9b\u67e3\uc2d5\ud646", "\ud998\udec9",
        42, 3586, -67978108, -2894036218270772566L, -78103L, false, false, (char) 48889, (char) 53845,
        Double.longBitsToDouble(0x3fec24d2c305d084L), Double.longBitsToDouble(0x3fe8282a555df5deL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 0, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud841\udc1b\ud8b0\udc1c\ud98d\udd62\udabf\udf88\udb63\udc52\udbdc\ude9c\uda97\udffe\udb92\udc6b\ud941\udc97", "\ud475\u6372\u8327\ud646\u6e74\u4fda\u44d3\u06bfW\u7f59\u11cb\uc7d2\u7b4e\ud0ee\uc195\u8d77\u628d\u42c7\u09c9\uaf13", "\udba8\udfee\ud86b\ude8f\ud864\udfc5\ud867\udde0\ud9a1\ude70\u3ec5\udbd5\uded1\udb43\udc8a\ud815\udd3c",
        25, 757, -2135193270, 795621845578600639L, -15918L, true, false, (char) 34435, (char) 58072,
        Double.longBitsToDouble(0x3fdacd3005dc0680L), Double.longBitsToDouble(0x3fdd16593b459f04L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 14, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud841\udc1b\ud8b0\udc1c\udade\udc67\udabf\udf88\udb63\udc52\udbdc\ude9c\uda97\udffe\udb92\udc6b\ud941\udc97", "\uba9b\u67e3\uc2d5\ud646\u6e74\u4fda\u44d3\u87bfW\u7f59\u11cb\uc7d2\u7b4e\u93a5\ua0bb\u2f4d\u9b8d\u42c7\u09c9\u6b42", "\ud930\udf74\ud86b\udea1\ud864\udfc5\uda61\ude5c\ud9a1\udf0f\u3ec5\udbd5\uded1\udb43\udc8a\ud815\udd3c",
        25, 757, -2135193270, 795621845578600639L, -15918L, true, false, (char) 34285, (char) 58072,
        Double.longBitsToDouble(0x3fdacd3005dc0680L), Double.longBitsToDouble(0x3fdd1c493b459f04L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\udba1\udc59", "\u61d2\u17d2\u6f08\u9b32\u2741\u1e9e\u5034\u9ebf\u4117\u1aff\u31ea\u2704\uba9b\uce92\uc2d5\ud646\u6e74", "\ud90c\udcfd",
        12, 80916, -673820315, -8441132553823072135L, 23225L, false, true, (char) 53887, (char) 8668,
        Double.longBitsToDouble(0x3fef2ecd2f283cbaL), Double.longBitsToDouble(0x3fd5df5de940d96eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 2, 3, 7, "\ud8ea\udc55\u7654\udaa9\udf26\ud836\udc5f\ud821\udecd\ud841\udc1b\uda38\udee0\ud996\uddd0\ud93d\udc48\udbff\udc6f\udbe4\udcae\uda97\udffe\udb86\udf6b\ud941\udc97\uda55\udf66\u882e\udafa\ude38\ud83f\ude83\ud829\udffa\ud89e\udf34\u3fe0\udb7f\udc08\ud998\udec9\ud92b\udc96\uda3b\udef5\ud8b4\udff6\ud819\udf07\udab4\udfc2\udab6\udea3", "\ubf49\u9b8d\u42c7\u09c9\uaf13\u89b6\u120f\u20df\u1326", "\ud9a1\ude70\u3ec5\udbd5\uded1\udb43\udc8a\udb70\ude89",
        25, 757, -2135193270, 795621845578600639L, -15918L, true, false, (char) 6531, (char) 39000,
        Double.longBitsToDouble(0x3fe7782ed2eeeeb7L), Double.longBitsToDouble(0x3fdd16593b459f04L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud835\udf72\u7654\udaa9\udf26\ud98c\udc7d\ud821\udecd\ud841\udc1b\ud8b0\udc1c\ud98d\udd62\ud8c5\udf0c\u49e6\udbdc\ude9c\uda97\udffe\udb92\udc6b\ud941\udc97", "\u77b9\u67e3\uc2d5\ud646\u6e74\u4fda\u44d3\u06bfW\u7f59\u11cb\u3e75\u7b4e\ud0ee\uc195\ubf49\u9b8d\uccd9\u0383\uaf13\uaa67\u1244\u83de\u1326\uae36", "\u3ec5\ud914\udd5b\u4e4a\ud815\udd3c\ud8ee\udfe8",
        7, 1705, -782634043, 7584291124209786520L, 37439L, true, false, (char) 3085, (char) 3388,
        Double.longBitsToDouble(0x3fe13228efee2d8bL), Double.longBitsToDouble(0x3fe82a758654ff05L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\000", "", "\ud841\udc1b\ud8b0\udc1c\ud98d\udd62\udabf\udf88\udb63\udc52",
        39, 66324, 1440009053, -4196659934123257281L, 40161L, true, true, (char) 41152, (char) 27547,
        Double.longBitsToDouble(0x3fe3b6c0e4b8d41eL), Double.longBitsToDouble(0x3fee03e126323388L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud841\udc1b\ud8b0\udc1c\ud98d\udd62\udabf\udf88\udb63\udc52\udbdc\ude9c\uda97\udffe\udb92\udc6b\ud941\udc97\uda55\udf66\ud8aa\udc31\udafa\ude38\ud83f\ude83\ud829\udffa\ud89e\udf34\u3fe0\udb7f\udc08\ud998\udec9\ud92b\udc96\uda3b\udef5\ud8b4\udff6\ud819\udf07\udab4\udfc2\ud80b\udd63\ud9a8\udcdb\udb22\udff2\udab3\udfce\uda2a\udc8c\uda2e\udc94\udb59\udf7c\udafe\udcc7\ud95d\udc34\ud95d\udd41\ud87f\udf79\ud86b\ude8f\ud864\udfc5\uda61\ude5c\ud9a1\ude70\u3ec5\udbd5\uded1\udb43\udc8a\ud815\udd3c\ud8ee\udfe8\ud925\udfed\udbb2\udf1e\udbbd\udd1f\ud9ac\ude2e\ud9cc\udc39", "\u6f84\ua143\u0987\u3b51", "\udbed\udf38\ud890\udd27\udaac\ude5d\ud839\udc33\ud888\udff6\ud99f\udff4\udaa6\udf9f\uda8c\ude6e\ud9cd\udd34\udbee\udf31\udab2\udd24\ud824\udf32\ud899\udc27\uda0f\uddfe\uda40\uddef\udaa1\udde0\ub79c\udbd9\udfc7\udb38\udd88\udb53\udca1",
        16, 15697, -1675333505, 602571606094303112L, 89282L, true, true, (char) 18558, (char) 61824,
        Double.longBitsToDouble(0x3fee6f09df6a8cc1L), Double.longBitsToDouble(0x3fed1d3fdb80734aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\u6129\000\ud9a9\ude39\000\uda82\udfc0\udb63\udc52\udbf2\udf91\ud8e2\uddc3\000", "", "",
        47, 8652, -669235826, -3161823297664684872L, 63378L, false, true, (char) 6596, (char) 19789,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fec6a9b184e8e6bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\000", "\ua1b7)\000\000\000", "\u4f58",
        -5, -1000, -977141760, 6302807740994749886L, -94041L, false, true, (char) 27547, (char) 51858,
        Double.longBitsToDouble(0x3fc71a83c0000000L), Double.longBitsToDouble(0x3fe1919801726c00L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 0, 5, 15, "", "\u6bbc\ua1b7\u61b7\u17d2", "\udabf\udf88",
        28, 89512, 0, 6184568187309422598L, 98078L, true, true, (char) 35141, (char) 41152,
        Double.longBitsToDouble(0x3fd8e1f734edb038L), Double.longBitsToDouble(0x3fc71a83df01f000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud8ea\udc55\uda70\udcc1", "", "\ud9b7\udd49",
        25, 86744, 868360518, -5784223532523501124L, 61798L, true, false, (char) 23862, (char) 19732,
        Double.longBitsToDouble(0x3fdf671feb79e608L), Double.longBitsToDouble(0x3fd8e260d4edb038L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 0, 0, "", "", "\000",
        -5, 50232, 0, 267181325549568L, -53340L, true, true, (char) 30938, (char) 50626,
        Double.longBitsToDouble(0x3e3c080000000000L), Double.longBitsToDouble(0x3fb1dc7f80000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 0, 5, 0, "\ud8ea\udc55\u7654\udaa9\udf26\udb7e\udc76\ud821\udecd\ud812\udf7f\ud8b0\udc12\ud98d\udd62\udabf\udf88\uda16\udf7a\udbdc\ude9c\uda97\udffe\udb92\udc6b\ud941\udc97", "\uba9b\u67e3\uc2d5\ud646\u6e74\u4fda\u44d3\u06bfW\u7f59\u11cb\uc7d2\u7b4e\u2cef\u754c\u32ba\ua467\u42c7\u09c9\uaf13", "\ud87f\udf79\ud86b\ude8f\ud864\udfc5\uda61\ude5c\ud9a1\ude70\u3ec5\udbd5\uded1\udb43\udc8a\ud815\udd3c",
        25, 46461, -2135193270, 795621845578600639L, -15918L, true, false, (char) 34435, (char) 58072,
        Double.longBitsToDouble(0x3fdacd3005dc0680L), Double.longBitsToDouble(0x3fdd16593b459f04L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud801\udddc\u909f\udaa9\udf26\ud828\udfad\uda2b\udc3c\ud80b\ude88\ud8b0\udc1c\ud98d\udd62\udabf\udf88\udb63\udc52\uda47\ude71\uda91\ude60\udb92\udc6b\ud941\udc97\uda55\udf66\ud8aa\udc31\udafa\ude38\uda33\udc5c\ud829\udffa\udb68\udc39\u4be3\udb7f\udc08\ud998\udec9\ud92b\udc96\udac2\uddf9\udaf4\udf2f\ud93c\udc82\ud9c9\ude86\ud80b\udd63\udb24\udcd9\ud97d\udce0\udab3\udfce\uda2a\udc8c\uda2e\udc94\udb59\udf7c\udafe\udcc7\ud95d\udc34\ud98a\udc3f\ud87f\udf79\ud86b\ude8f\uda7e\udf5e\udb72\udfad\ud9a1\ude70\u3ec5\udadb\udedc\udb43\udc8a\uda83\udd91\udb5b\udd0a\ud928\udd9b\ub571\uda35\ude80\udb9d\udef2\ud9cc\udc39\ud8ad\udcdf\ud820\ude5e\udbdf\udc73\udbf7\udf5c\udb7c\udd28\ud9e3\udd7e\ud816\udd5b\ud894\udeeb\ud89e\udeac\ud9ac\udeb0\ud825\ude59\ud85e\udcf4\udbca\uddd7\ud88f\udcea\u349a\ud9e1\udd87\udba0\udc11\uda4b\udd83\udb7e\udeb0\ud9ff\udd49\udbd2\udcc6\udb8a\udd05\udbb5\udd15\ud96d\uddaa\ud9dd\udc7d\uaaec\udbf0\udf1b\uda12\udd83\ud9eb\udc35\udb28\ude12\uda32\udd29\uda04\udefb\ud83e\udc9b\ud89a\udc03", "\ub37e\ua0d7\u0421\u1d78\u0726\u5e14\u1a24\u46ee\u88d3\u55bf\ube06\u706f\u8a3b\ub9a0\u430f\u1627\u822e\u6c6a\u220c\u5fbc\uc08d\u4135\u8a19\u3fab\ud26b\u06ff\u06bc\u5b18\ud4de\uaf93\u4f6d\u4b28\u1018\u84bc\u8e9d", "\u3b0d\ud956\ude22\uda48\udfed\ud9b8\ude6b\ucc72\ud867\udddf\ud92f\uddcf\udac4\udea4\ud86a\udc7d\ud817\udf29\ud9e9\udc63\uda90\udde1\udbb9\udcb5\uda15\udf6b\uda88\udcaf\ud916\udcee\uda31\udd8b\ud9f6\udf17\ud8ef\ude76\ud99f\udd1e\udab4\udd0e\ud82e\udd88\ud817\udcc7\ud831\ude6e\ud813\udf38",
        3, 45875, 325740163, -6993390083449601896L, 80507L, false, true, (char) 34110, (char) 7860,
        Double.longBitsToDouble(0x3fd5f3465c844a9eL), Double.longBitsToDouble(0x3fe9dfee8c888055L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 13, 5, 0, "\ud835\udf72\u7654\udaa9\udf26\ud98c\udc7d\ud8e7\udd90\uda14\ude56\ud8b0\udc1c\udb4d\udd62\ud8c5\udf0c\u49e6\udbdc\ude9c\uda97\udffe\udb92\udc6b\ud941\udc97", "\u77b9\u67e3\uc2d5\ud646\u6e74\u4fda\ua047\u06bfW\u7f59\u11cb\u3e75\u7b4e\ud0ee\uc195\ubf49\u9b8d\uccd9\u0383\uaf13\uaa67\u1244\u83de\u1326\uae36", "\u3ec5\ud914\udd5b\u4e4a\ud90e\udc9d\ud8ee\udfe8",
        7, 1705, -782634043, 7584291124209786520L, -15259L, false, false, (char) 54790, (char) 47368,
        Double.longBitsToDouble(0x3fef54dc50975398L), Double.longBitsToDouble(0x3fe164e297e09d1cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.option.GroupImpl|validate|org.apache.commons.cli2.WriteableCommandLine|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|appendUsage|java.lang.StringBuffer,java.util.Set,java.util.Comparator|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|appendUsage|java.lang.StringBuffer,java.util.Set,java.util.Comparator,java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|canProcess|org.apache.commons.cli2.WriteableCommandLine,java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|defaults|org.apache.commons.cli2.WriteableCommandLine|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|findOption|java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getAnonymous||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getDescription||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getMaximum||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getMinimum||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getOptions||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getPreferredName||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getPrefixes||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|getTriggers||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|helpLines|int,java.util.Set,java.util.Comparator|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|isRequired||new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
    "M|org.apache.commons.cli2.option.GroupImpl|validate|org.apache.commons.cli2.WriteableCommandLine|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
