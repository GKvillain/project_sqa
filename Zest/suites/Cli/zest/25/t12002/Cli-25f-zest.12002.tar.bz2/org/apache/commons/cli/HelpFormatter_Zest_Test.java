package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69\u1e89\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u8422\u9884\ud101\u8de6\u645a\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d\ua877\u3c8d\uccc0\u5158\uab40\u8719\uade4\u16fa\u073a\u23cf\u7023\ua8bf\u494d\uc9cf\u240c\ub4da", "\ud83c\udcbe\udb29\ude1f\ud8de\udc74\uda49\udca6\ud845\udd4f",
        55, 45009, 1977278422, -5731690081973952414L, -88347L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fd38803997ea636L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\ud8f3\uddf9\ud936\udf65\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\u49a5\u0cab\u80c9\u426e\u28bd\u9782\u1e56\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u486c\u3758\u30a5\u5c82\u8422\u9884\ud101\u8de6\u645a\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d\ua877\u3c8d\uccc0\u5158\u7ece\uab80\ua3cd\u16fa\u073a\u6ecf\u7023\ua8bf\u494d\uc9cf\u240c\ub4da", "\ud83c\udcbe\udb29\ude1f\ud8de\udc74\uda49\udca6\ud845\udd4f",
        55, 45009, 1977278422, -5731690081973952413L, -88347L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fd38803997ea636L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2", "\u0e50\u1795\u2c71\ub327\uceb1\u7fdd\ubf15\u1e77\ubb86\ucef1\u00fb\ud40f\u90ac\u401b\u7b89\u9a20\u0392\u81d8\ubadf\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u67cc", "\ud869\ude8d\ud908\ude2e",
        37, 58715, -1671644925, -9120314074407250815L, 59082L, false, true, (char) 37748, (char) 5399,
        Double.longBitsToDouble(0x3fe08a433599fe5eL), Double.longBitsToDouble(0x3fdcc8fb77eef1a8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 15, "\uda96\ude97\ud9af\uded2\ua62f\udac8\ude08\ud969\udf61\uda26\udea5\udb32\udec9\uda29\ude49", "\ubf15", "\udb23\ude1e",
        16, 24761, -1152080279, 6186928120063865848L, 7687L, false, false, (char) 63452, (char) 53008,
        Double.longBitsToDouble(0x3fe0f95898aa1079L), Double.longBitsToDouble(0x3fe1a5a2f14c2e0eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ue92f\udac8\ude08\ud887\udf43\udb3e\udf6b\uda0a\udc50\uda29\ude49\ud904\udcc8\ud942\udee8\ud898\udf1f\ud8ff\udd38\ud8fb\uddd7\udb4b\ude04\uda75\ude0b\ud9d8\udf60\u1e04\ud9ef\ude20\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\uba88\u9f6d\u2a49\u2dcf\u4bb3\u7e69\u1e89\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\ub7a3\u09c4\u21cb\u8dc2\u83da\ud04c\u8de6\u645a\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d\ua877\u3c8d\u85ef\u81a1\uab40\u8719\uade4\u1703\u073a\u23cf\u7023\ua8bf\u494d\uc9cf\u240c\ub9b5", "\ud833\udc07\udbd7\udd0e\ud8de\udc3e\uda49\udd27\uf371",
        42, 30187, 1966102315, -5731690081973952414L, -88347L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fac401cb116c7b0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f", "\u1e77\ubb86", "\udba1\udf16\udba4\uddce\ud847\udf9f\ud9f5\udf2c",
        58, 87318, -1807101659, -8783607758935601092L, -40876L, true, false, (char) 16675, (char) 46738,
        Double.longBitsToDouble(0x3fd4c2e0e26b7aeaL), Double.longBitsToDouble(0x3faa696d7bd347c0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\udb40\udd08\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69\u1e89\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u8422\u9884\ud101\u6c75\u645a\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d\ua877\ua27f\u497b\u6c24\ua912\u8719\uade4\u16fa\u073a\u23cf\u7023\ua8bf\u494d\uc9cf\u240c\ub4da", "\ud83c\udcbe\udb23\udd1f\ud8de\udc74\uda49\udca6\ud845\udd4f",
        55, 45009, 760192470, -5731690081973952414L, -88347L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fd38803997ea636L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u1595\u9501\u49a5\u0706\u80c9\u48e3\u4a38\000\000\ub569\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u0612\u32eb\ud101\u8cef\u645a\u83d5\u6fea\000\uc9b6\u681e\u19ae\u425b\ua44d\u9bba\u3c8d\u350c\000\u6b42\u8719\uade4\u16fa\u073a\ucb60\u7023\ua8bf\u8b4c\u1aae\u6fb3\ub4da", "\ud83c\udcbe\udb29\ude1f\ud8de\udc74\uda49\udca6\ud845\udd4f",
        30, 8080, 1977278422, -5731690081973952414L, -88347L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fd38803997ea636L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\ud8e0\udd2f\ud939\udf67\udaab\udec6", "\u81d8\ubadf\u1d02\u7f4d", "\udbe1\udc34\udb2f\udcea\ud8ec\udfc0\udba1\ude8b\udb6e\udf4b\udaa7\udc73\ud869\ude8d\ud908\ude2e\ud9ca\udea0\ud951\udc76\udb2e\udf23\ud9dc\udf36\ud992\udc6f\ud913\udde7\ue799\ud8ae\udca2\udaf3\udd52\ud8f6\udef7\ud987\uddf8\u6efb\udbbe\udcea\ud86d\ude18\ud966\udf34\ud921\ude6a\ud9e2\udd05\ud9c6\udf5e\u3829\ud8e3\udfed\udbd5\udcd3\ud997\udda1\udac2\udeed",
        42, 28756, 1707174951, 5374730531406491364L, -97726L, false, false, (char) 53952, (char) 15180,
        Double.longBitsToDouble(0x3fe757a1c2ae3143L), Double.longBitsToDouble(0x3fececd029308d9eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\ud881\uddfd\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\udb81\udc1d\ud953\udd0a\ud8b5\udc04\ud83c\uded9\ud841\udd8e\uda7c\udf4c\ud939\udf67\u80e2", "\u81d8\ubadf\u1d02\u7f4d\u9501\ua61c\u7357\u5f2c\u305a\u8646\u7818\u37d2\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u8422\u9884\ud101\u8de6\ua4dc\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d", "\ud85c\ude26",
        31, 9540, -1139429480, 4778469917212820195L, 18674L, false, true, (char) 15180, (char) 35618,
        Double.longBitsToDouble(0x3fe5718a1b9d9a05L), Double.longBitsToDouble(0x3fd308d9e5d9dd2eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\ud8bf\udc8d\ud8a0\udc5e\udbf4\udf4c\ud898\udef2\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69\u1e89\ub5e7\u4186\u8261\u28f0\u0f44\u14a9\u62ad\u4d52\u9934\u3758\u30a5\u5c82\u8422\u2fdb\ud101\u8de6\u645a\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d\ua877\u3c8d\uccc0\u5158\uab40\u8719\uade4\u16fa\u073a\u26da\u70c7\ua8bf\u494d\uc9cf\u240c\ub4da", "\ud997\udff8\ud9e3\udd08\udb34\udce2\uda49\udca6\ud845\udd4f\uda40\udf98\ud98f\udc76\u76c8\udbdb\udd8c\ud9b8\udc39\ud9e9\udc94\uda0d\ude06\ud943\udd4a\udb11\ude84\u56dc\u222a\ud919\udc1c\udb4b\ude1d\udbd4\udc2a",
        9, 83828, 513043799, 9216474565507149329L, 11853L, false, false, (char) 4767, (char) 4524,
        Double.longBitsToDouble(0x3fda91bbe45b0158L), Double.longBitsToDouble(0x3fe7b63938b98374L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 6, "\ud8b7\uddff\ud9af\uded2\uda0b\ude80\udac9\uddb8\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udbd9\udc63\udb69\udc4e\uda9a\ude49\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c\uda62\udf7a", "\ubadf", "\udadb\udc49\ud9fb\uddd6\udbe1\udc34\udb2f\udcea\ud839\udd60\udba1\ude8b\udb6e\udf4b\udaa7\udc73\ud869\ude8d",
        54, 64177, 1854217715, -7179660285522861396L, 18926L, false, true, (char) 5399, (char) 9847,
        Double.longBitsToDouble(0x3fe987f2f669c6c4L), Double.longBitsToDouble(0x3fee11e75b259c62L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud8b1\udfd1\ud910\udf12\uda29\ude49\uda93\udc6f\ud942\udf96\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u773a\u7e69\u1e89\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u8422\u9884\ud101\u8de6\u645a\u83d5\ua248\u5cd4\u21ee\u4b18\u19ae\u425b\ua44d\ua877\u3c8d\uccc0\u5158\uab40\u8719\uade4\u16fa\u073a\u23cf\u7023\ua8bf\u494d\uc9cf\u240c\ub4da", "\ud83c\udcbe\ud8e9\udfa7\udb7e\udea9\uda49\udca6\ud845\udd4f",
        43, 79188, 1977278304, -5731690081973952414L, -88347L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fd38803977ea636L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 4, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e", "\u90ac\u401b\u7b89", "\ud88c\udca0\udbf7\udc29\uda53\ude7b\udaf0\udd4a\ud972\udfa1\uda03\udf17\udbe1\udc34\udb2f\udcea\ud839\udd60\udba1\ude8b\udb6e\udf4b\udaa7\udc73\ud869\ude8d\uda86\udeee\ud997\udd91\ud980\uddec\udb2e\udf23\ud9dc\udf36\ud992\udc6f\ud913\udde7\ue799\ud8ae\udca2\udaf3\udd52\ud8f6\udef7\ud987\uddf8\u6efb\udbbe\udcea\ud86d\ude18\ud966\udf34\ud921\ude6a\ud9e2\udd05\ud9c6\udf5e\u3829\ud8e3\udfed\udbd5\udcd3\ud997\udda1\udac2\udeed\udb14\uddb0\ud82d\uddc2\ud85c\ude26\ud905\udd56\u784d\ud96a\udf97\udb4d\udf47\ud9ad\udd9b\ud80c\udf25\ud891\uddd0\ud837\ude01\ud8f1\ude04\ud8b6\uddd1\ud9c1\udcab\ud959\udcdf\ud88a\udc2d",
        7, 91620, 1271213127, 6318067543765805699L, 68001L, false, true, (char) 26647, (char) 53462,
        Double.longBitsToDouble(0x3fdf3fd504f749c8L), Double.longBitsToDouble(0x3fe2e1e13c8eeddcL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud915\udfc0\ud898\udf75\ud8ff\udd38\ud840\udd17\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u7848\u49e7\ubdfe\uc1a1\u426e\u4bb3\u7e69\u1e89\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u8422\u9884\ud101\u8dab\u645a\u1b85\ua248\u5cd4\uc51d\u32bf\u19ae\u425b\ua44d\ua877\u3c8d\uccc0\u5158\uab40\u8719\uade4\u961a\u073a\u56b7\u0a75\uad64\ua3b5\uc9cf\u240c\ub4da", "\ud83c\udcbe\udb29\ude1f\ud8de\udc74\uda49\udca6\ud845\udd4f",
        16, 45009, 1977278422, -5731690081973952414L, -88347L, false, false, (char) 33386, (char) 59016,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fb414ce67efd238L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62fu\000\ufdff\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\000\uda75\ude0b\ud9d8\udf91\u1e04\ud947\udd02\ud9f5\udf2c", "\u00fb", "\udaf0\udd4a\udaa0\udd18\000\000\000\ud839\udd60\udba1\ude8b\udb6e\udf4b",
        7, 23862, 1539429574, 5614412074311491059L, 18926L, false, true, (char) 5399, (char) 0,
        Double.longBitsToDouble(0x3fd99fe5e3980000L), Double.longBitsToDouble(0x3fefbbc6a3259c62L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda0d\udf8e\uda93\udc6f\ud942\uded8\ud898\udf1f\ud900\udf38\udb07\udecb\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69\u1e89\ub5e7\u9148\u6b16\uc7ea\u1ceb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u8422\u9884\ud101\u8de6\u645a\u5b66\ua236\u5cd4\u756a\u761f\u19ae\u9b8a\u3c93\u0ff3\u8f49\u01f6\u5158\uab40\u8719\uade4\u16fa\u073a\ua2ae\u7023\ua8bf\u494d\uc9cf\u240c\u1d26", "\ud83c\udcbe\udb29\ude1f\ud8de\udc74\uda49\udca6\ud845\udd4f\uda40\udf98\ud98f\udc76",
        -3, 99293, -986314654, -6564953731079089541L, -4398L, false, false, (char) 14194, (char) 7459,
        Double.longBitsToDouble(0x3fd38803997ea636L), Double.longBitsToDouble(0x3fe345ef5a8f596dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ud9dd\udfe0\udabf\udcd7\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e", "\u90ac\u401b\u7b89", "\ud88c\udca0\udbf7\udc29\uda53\ude7b\udaf0\udd4a\ud972\udfa1\uda03\udf17\udbe1\udc34\udb2f\udcea\ud839\udd60\udba1\ude8b\udb6e\udf4b\udaa7\udc73\ud869\ude8d\ud908\ude2e\ud9ca\udea0\ud951\udc76\udb2e\udf23\ud9dc\udf36\ud992\udc6f\udad2\udce0\udbdb\udf43\ud8ae\udd09\udaf3\udd52\ud8f6\udef7\ud987\uddf8\u6efb\udbbe\udcea\ud86d\ude18\udbf8\udf9d\ud915\udc20\ud9e2\udd05\ud9c6\udf5e\u3829\ud8e3\udfed\udbd5\udcd3\ud997\udda1\udac2\udeed\ud89f\udd36\ud828\ude95\ud85c\ude26\uda4a\udc18\ud9be\udf95\ud96a\udf97\udb4d\udf47\ud9ad\udd9b\ud800\udf1f\ud891\uddd0\ud837\ude01\ud8f1\ude04\ud8b6\uddd1\ud9c1\udcab\ud959\udcdf\ud88a\udc2d",
        7, 91620, 1271213127, 6318067543765805699L, 68001L, false, true, (char) 26647, (char) 53462,
        Double.longBitsToDouble(0x3fdf3fd504f749c8L), Double.longBitsToDouble(0x3fe2e1e13c8eeddcL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8a5\udfd1\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\udac3\udcd6\udb5c\udc7d\ud942\uded8\ud898\udf1f\ud95a\udefc\udb31\udc35\udb23\ude1e\uda75\ude0b\ud9d8\udf91\udaf3\udeff\ud939\udf67\ud9f5\udf2c", "\u6ce0\u9b59\u1d02\u7204\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u4114\u1de8\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u85d7\u30a5\uc50b\u8422\u9884\ud101\u8de6\u645a\u83d5\ua248\u5cd4\u6d69\u9573\u19ae\u425b\u601d\ud43e\uafda\ucde5\ub357\uab40\u8719\uade4\u740b\u9e77\u23cf\u2a37\ua8df\u494d\uc9cf\u374f\ub199", "\ud83c\udcbe\udb29\ude1f\udbb7\udd04\uda71\udfac\udbfe\ude40",
        16, 45009, 1977278422, -5731690081973952414L, -88347L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3f9c6471748f2b20L), Double.longBitsToDouble(0x3fd38803946c1c36L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac4\udca6\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\u55fe\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69\u1e89\ub5e7\u4186", "\udb2e\udf23\ud9dc\udf36\ud992\udc6f\ud913\udde7\ue799\ud8ae\udca2\udaf3\udd52",
        12, 32801, 480824335, 8706858632511400951L, -81820L, false, true, (char) 2625, (char) 10408,
        Double.longBitsToDouble(0x3fe5c25d92108cbfL), Double.longBitsToDouble(0x3fe3a1776f8235eaL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 8, "\ud8b7\uddff\ud9af\uded2\udbee\ude92\udaf3\udeb7\ud8d6\ude0f\ud867\udd8f\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\ud9e8\ude8c", "\ud40f\u90ac\u401b\u7b89", "\ud88c\udca0\udbf7\udc29\uda6c\udf7b",
        39, 33940, 276383263, -5449864991596477900L, -22485L, false, false, (char) 5177, (char) 29817,
        Double.longBitsToDouble(0x3fe851178e095b9cL), Double.longBitsToDouble(0x3fdf34dea2b4dd0aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 3, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\u7aaa\u2c29\u80c9\u426e\u4bb3\u7e69\u1e89\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u8422\u9884\ud101\u8de6\u645a\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d\ua877\u3c8d\uccc0\u5158\uab40\u8719\uade4\uaaf9\u073a\u23cf\u7023\ua8bf\u494d\uc9cf\u240c\ub4da", "\ud83c\udcbe\ud8aa\udeca\ud8de\udc74\uda49\udca6\ud845\udd4f",
        55, 45009, 1977278422, -5731690082259165086L, 18340L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fd38803997ea636L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f", "\u1795\u3a55\u18bf\u67f4\uc302\ubf15\ubca0\u1a8e\ubb47\u9974\ud40f\uce0c\u35c9", "\udb52\udc70",
        30, 85161, -489887961, -5245543935549957876L, -16924L, true, true, (char) 19821, (char) 24234,
        Double.longBitsToDouble(0x3fe903a0de111c12L), Double.longBitsToDouble(0x3fbf8d4856311788L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 3, 8, "\ud8b7\uddff\ud9af\uded2\ud815\udf7a\udac8\ude08\udae8\uddfd\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\udad9\udc03\ud9d8\udf91\u1e04\udbc8\ude6f\ud89e\udd00", "\u81d8\u942a\u4cbc\u7f4d\u3f83\u49a5\u3706\u80c9\u426e\u4bb3\u7e69\u1e89\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u0672\u939f\u9884\ud101\u8de6\u645a\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d\ua877\u3c8d\uccc0\u5158\uab40\u8719\uade4\u16fa\u073a\u23cf\u7023\ua8bf\u494d\uc9cf\u240c\ub4da", "\ud83c\udcbe\udb29\ude1f\ud8de\udc74\uda49\udca6\u096f",
        3, 41065, 1977278422, -5731690080099491742L, -98376L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fbb8ddc65202a30L), Double.longBitsToDouble(0x3fd38803997ea636L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 9, "\ud801\uddc9\udb64\udd8f\udbbe\udeb8\uda65\udf29\uda50\udf5f\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udbdf\udce7\ud92f\udd8b\u2636\ud9d8\udf91\u1e04\ud939\udf67", "\u9821\u9777\ub5d5\u1610\u327f\u95e3\u49a5\u3706\u80c9\u426e\u4bb3", "\ud869\ude8d\ud908\ude2e",
        37, 58715, -1671644925, -9120314072342226202L, 73319L, false, true, (char) 37748, (char) 5399,
        Double.longBitsToDouble(0x3fe08a433599fe5eL), Double.longBitsToDouble(0x3fdcc8db77eef1a8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\ud800\uddf2\ud9a8\ude4f\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\ud985\udf6f\uda63\ude18\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c\ud828\udec6\uda0e\udc08\ud88c\udca0\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69 |a0=java.lang.StringBuffer:\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\ud800\uddf2\ud9a8\ude4f\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\ud985\udf6f\uda63\ude18\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c\ud828\udec6\uda0e\udc08\ud88c\udca0\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\ud800\uddf2\ud9a8\ude4f\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\ud985\udf6f\uda63\ude18\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c\ud828\udec6\uda0e\udc08\ud88c\udca0", "\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69", "\ud908\ude2e\ud9ca\udea0\ud951\udc76\udb2e\udf23\ud9dc\udf36\ud992\udc6f\ud913\udde7\ue799\ud8ae\udca2\udaf3\udd52\ud8f6\udef7\ud987\uddf8\u6efb\udbbe\udcea\ud86d\ude18\ud966\udf34\ud921\ude6a\ud9e2\udd05\ud9c6\udf5e\u3829\ud8e3\udfed\udbd5\udcd3\ud997\udda1\udac2\udeed\ud89f\udd36\ud828\ude95\ud85c\ude26\ud905\udd56\u784d\ud987\uddb1\udb4d\udf39\ud9ad\udd9b\ud80c\udf25\ud891\uddd0\ud837\ude01\ud8f1\ude04\ud8b6\uddd1\ud9c1\udcab\ud959\udcdf\ud97b\udef0\udb85\udf2a\ud98e\udc49\ud83c\udcc8\udb29\ude1f\ud8de\udc74\uda49\udca6\ud845\udd4f\uda40\udf98\ud98f\udc76\u76c8\udbdb\udd8c\ud9b8\udc39\ud9e9\udc94",
        27, 1308, -1718381426, 7237650439947145985L, -98264L, true, false, (char) 44646, (char) 59391,
        Double.longBitsToDouble(0x3fe4fa00d458eaaaL), Double.longBitsToDouble(0x3fdca121af892752L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 7, 4, 3, "\ud85f\udeff\ud9af\ude10\ua62f\udac2\udc08\ud9db\udcb6\ud959\ude1e\udb2e\udc69\udb45\udfb0\uda86\udf26\ud942\uded8\ud8be\ude1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda7e\udf6f\udaa4\udd16\u1e04\ud939\udf67\ud9f5\udf2c", "\ua483\uafe5\u1d02\u7f4d\u1363\u7c3f\ubdbf\u24f8\u6f97\u4bb3\u7e69\u1e89\ub5e7\u4186\u8261\u5c7e\ua854\u14a9\u58cf\u4ec5\u8078\u3758\u30a5\u5c82\uc77a\u22b1\ud101\ucc02\u80ea\u8e34\u33b0\u20ec\ub069\u367b\u19aa\u425b\ua44d\u705c\u48d4\uccb3\u5158\uab40\u8719\u376b\u17b6\u073a\u2aa0\u8f96\u044e\u3454\uc94e\u240c\ub4da", "\ud83c\udcbe\udb29\ude1f\uda17\udd31\uda49\udca6\ud845\udd4f\uda40\udf98\ud98f\udc76\u7602\udbdb\udd8c\ud9b8\udc39",
        15, 42293, -604101540, -8605371123683472233L, 54716L, false, true, (char) 16346, (char) 14677,
        Double.longBitsToDouble(0x3fd7633f0bc072caL), Double.longBitsToDouble(0x3fe9f2dfa2db2d8cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\uda0e\udc26\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u6949\u1742\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69\u1e89\ub5e7\u4186\ubbed\u62e4\u8006\u14dd\u62ad\u29ba\u1071\u6c06\u30a5\u5c82\u8422\u9884\ud101\u8de6\u645a\u83d5\ua248\u5cd4\u756a\u1edf\u19ae\u425b\ua44d\ua877\u3c8d\uccc0\u5158\uab40\u8719\uade4\u16fa\u073a\u23cf\u7023\u3cc0\u494d\uc9cf\u240c\ub4da", "\ud8c0\udfa2\udb29\ude00",
        11, 7844, 295943237, 5142080960479268929L, -37987L, false, false, (char) 38723, (char) 30559,
        Double.longBitsToDouble(0x3fe2e1e13c8eeddcL), Double.longBitsToDouble(0x3fc753326c0591c4L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\ud94e\udf1f\uda26\ude63\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\ub4a2\u11d3\u127d\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u8422\u9884\u8401\u8de6\u645a\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d\ua877\u3c8d\u1c28\u7d14\u9b17\u6f18\uade4\u16fa\u073a\u23cf\u7023\ua8bf\u494d\uc9cf\u240c\ub4da", "\ud83c\udcbe\udb29\ude1f\ud8de\udc74\uda49\udca6\ud87f\udd2d",
        1, 45009, 1977278422, -5731690081973952414L, -88347L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fd38803997ea636L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 3, 8, "\ud8b7\uddff\ud9af\uded2\ua62f\udac8\ude08\ud9ee\ude00\ud867\udd0c\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67\ud9f5\udf2c", "\u81d8\ubadf\u1d02\u7f4d\u9501\u49a5\u3706\u80c9\u426e\u4bb3\u7e69\u1e89\ub5e7\u4186\u8261\u28f0\u82eb\u14a9\u62ad\u29ba\u1071\u3758\u30a5\u5c82\u8422\u9884\ud101\u8de6\u645a\u83d5\ua248\u5cd4\u756a\u761f\u19ae\u425b\ua44d\ua877\u3c8d\uccc0\u5158\uab40\u8719\uade4\u16fa\u073a\u23cf\u7023\ua8bf\u494d\uc9cf\u240c\ub4da", "\ud83c\udcbe\udb29\ude1f\udaea\udf7d\uda49\udca6\ud845\udd4f",
        8, 45060, 1977278422, -5731690081973952414L, -88347L, false, false, (char) 33386, (char) 58957,
        Double.longBitsToDouble(0x3fe80b238ba4797fL), Double.longBitsToDouble(0x3fd38803997ea636L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 0, "", "\u4907", "\ud855\ude0a\udb2e\udc69\uda29\ude49\uda93\udc6f\ud942\uded8\ud898\udf1f\ud8ff\udd38\udb02\udeb9\udb23\ude1e\uda75\ude0b\ud9d8\udf91\u1e04\ud939\udf67",
        -5, 15091, 1476653889, 1078036791296L, -100000L, false, false, (char) 512, (char) 28506,
        Double.longBitsToDouble(0x3fd35bd75069a5b4L), Double.longBitsToDouble(0x3fede9a3e4000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
