package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u6dd0\ud81f\uddda\ud954\udee6\uda18\udfa7\uda6d\uddaf", "\u174b\u55f1\u6c97\uc358\u7a90\u2880\u0f16\uc37f\u18c6\u0796\uaef1\uba2a\u250c\ua7cc\u1ab1\uc80d\u7dfb\u7dec\u7cd4\u8f72\u42a6\ubf29\u1ce4\u9b0c\u1483", "\udb12\uddd2\uda10\udeea",
        42, 14407, 855393179, -9122048462917062110L, -37408L, false, true, (char) 48067, (char) 56440,
        Double.longBitsToDouble(0x3fe54fe89cdeaca8L), Double.longBitsToDouble(0x3fda820b2fed0bd2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u6dd0\udbaa\udd41\ud85e\udc55\uda18\udfa7\u7329", "\uc082\u8719\u6c72\u1f72\ub584\u1510\u8582\uc392\u18c6\u91a8\u48fe\uba9a\u250c\u08fc\uad14\uc80d\u7dfb\u7dec\ub1dd\u83a7\u42a6\ubf29\u1ce4\u9b0c\u1483", "\ud8a1\udc8e\uda10\udf9e\udb54\ude66\uda37\uddc9\uda29\udde5\ud94b\udefb\ud80f\udfe6\udad1\ude5b\uda33\udf26\ud8f0\udef9",
        25, 30641, -1398242647, 2356162010781688232L, 529L, false, false, (char) 38976, (char) 41548,
        Double.longBitsToDouble(0x3fec39e324f596abL), Double.longBitsToDouble(0x3fe1bb4b94f0b07eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u7589\udb6b\udf56\udb98\udd60\uda84\ude66\ufd3a", "\u9435\ub0f2\u6c97\u3eec\u7a90\u2880\u57ad\uc37f\u18c6\u4259\u033a", "\udbe8\uded2",
        42, 49291, -1129257619, -4669797423149861484L, -62193L, false, false, (char) 49630, (char) 51353,
        Double.longBitsToDouble(0x3fe72df6beb0417dL), Double.longBitsToDouble(0x3fcc6645c3c80e54L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u6dd0\ud81f\uddda\ud954\udee6\uda18\udfa7\uda6d\uddaf", "\u174b\u55f1\ud560\uc358\u7a90\u2880\u0f16\uc37f\u18c6\u0796\uaef1\uba2a\u250c\ua7cc\u1ab1\uc80d\u7dfb\u7dec\u7cd4\u8f72\u42a6\ubf29\u1ce4\u9b0c\u1483", "\udb27\udff2\uda10\udeea\udb54\ude66\uda37\uddc9\ud895\ude9c",
        0, 66730, 1644906222, 67822823745769226L, -19326L, false, true, (char) 40415, (char) 1937,
        Double.longBitsToDouble(0x3fd4fe1b6e5c2e30L), Double.longBitsToDouble(0x3fe9e1b221a7f449L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u6dd0\uda46\udd6e\ud954\udee6\uda18\udfa7\uda6d\uddaf\ud976\udd39\ud830\udd51\udacd\ude39\udb49\udd34\ud98d\udd01\udb07\udd2e\ud93f\udccd\udb56\udd06\ud92c\uddb0\ud9c1\udc9d", "\uaef1\uba2a\u250c\ua7cc\u1ab1\uc80d\u7dfb\u7dec", "\ud8df\udc40",
        32, 84221, -1093142458, 4718953155891029680L, 16322L, false, false, (char) 54088, (char) 20922,
        Double.longBitsToDouble(0x3fecdccea14132fcL), Double.longBitsToDouble(0x3fe1140b3eeeefeeL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 2, "\u6dd0\ud81f\uddda\ud954\udee6\uda18\udfa7\uda6d\uddaf", "\u174b\u6efb\u9a99\u27d3\u7a90\ua32a\u745f\uc37f\u18c6\u0aeb\u95f1\ua9dd\u24fa\ucfed\u1ab1\uc80d\u8232\ua457\u7cbd\u8f72\u42a6\ubf29\u1ce4\u9b0c\u1483", "\ud9a6\udd61\ud840\udd54",
        47, 14407, 855393179, -9122048462917062110L, -37408L, false, true, (char) 48067, (char) 56373,
        Double.longBitsToDouble(0x3fed4fe89cdeaca8L), Double.longBitsToDouble(0x3fdc820b29ec0efeL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\udb48\ude46\ud8ec\uddfb\udabd\udf8b\uda18\udfa7\uda6d\uddaf", "\u174b\u55f1", "\ud93f\udccd\udbde\udd0a\ud92c\uddb0\ud9c1\udc9d\ud8f6\udcbc\uda79\udd9c\udbf8\ude25\ud9ec\udfd0",
        -1, 57036, -1722653597, 1527994520626587074L, 44721L, false, true, (char) 26441, (char) 7107,
        Double.longBitsToDouble(0x3fd65447908da0a6L), Double.longBitsToDouble(0x3fe72df6beb0417dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 5, 2, "\u6dd0\ud81f\uddda\ud954\udee6\uda18\udfa7\uda6d\uddaf", "\u0dcf\u6f3c\u6c97\uc358\u7a90\u2880\u0f16\uac22\u6e81\u1f7a\uaef1\uba2a\u250c\u2006\u9927\uc75f\u7dfb\u7dec\u7cd4\u8f28\uac22\u39dc\u1e0d\u9b0c\u1483", "\udb12\uddd2\uda10\udeea",
        42, 14407, 855393179, -9122048461595126750L, -37408L, false, true, (char) 14503, (char) 40043,
        Double.longBitsToDouble(0x3fedac3158d7d3a9L), Double.longBitsToDouble(0x3fda820b269d0bd2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u6dd0\ud81f\uddda\ud88a\udc0c\ud998\udce5\u45d3\ud976\udd39", "\u361d\u6c97\uc358\u7a90\u5f59\ucdae\uc3b6\u6c0d\ub9b6\uaef1\uba2a\u250c", "\udba2\udc2b\ud9d3\udfca\udbe0\udcc0\udbe4\udd1e\ud95c\udcbe\ud8df\udc40\udbc0\udf56\ud8cc\udf14\ud9a3\udfc3\udb1d\ude26\ud92c\udd89\ud800\ude19",
        44, 31982, -67055264, -180173142772355443L, 18238L, false, true, (char) 22360, (char) 53241,
        Double.longBitsToDouble(0x3fe5e5a83fa954d0L), Double.longBitsToDouble(0x3fe54fe89cdeaca8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u6dd0\ud81f\uddda\ud954\udee6\u00d3\000", "", "\ud98d\udd01",
        13, 79941, -1325363795, -2725658627354525696L, -47008L, false, true, (char) 41220, (char) 59368,
        Double.longBitsToDouble(0x3fb1303fa31ff000L), Double.longBitsToDouble(0x3fe764ca95c21534L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 2, "\u6dd0\ud81f\uddda\ud954\udee6\uda18\udfa7\uda6d\uddaf", "\u174b\u0da5\u93c7\u600a\u7a90\u2880\u0f16\uc37f\u18c6", "\ud9ec\udfd0\ud9b1\udc02\ud936\udd31\udbbd\ude55\udba2\udc2b\uda0a\uddca\udbe0\udcc0\udbe4\udd1e",
        22, 63527, 1249465858, -3435205949280225210L, -19262L, false, false, (char) 16193, (char) 20922,
        Double.longBitsToDouble(0x3fecdccea14132fcL), Double.longBitsToDouble(0x3fe1140b3eeeefeeL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 0, "\u6dd0O\000\000\000", "\000\u5549\u2a13\uc358\u7a90\u2880\u0f16\uc37f\u18c6\u0796\uaef1\uba2a\u250c\ua7cc\u8cc4\u90e3\u7dfb\u7dec\u7cd4\u8f72\u42a6\u6929\u1ce4\u9b0c\u1483", "\udb12\uddd2",
        -3, 35952, -1714156593, 74330875099392L, -52622L, false, false, (char) 53241, (char) 48067,
        Double.longBitsToDouble(0x3fed4aa682a9fd13L), Double.longBitsToDouble(0x3f45950000000000L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 0, 0, "\u6dd0", "\u4a30\u427f\u49cc\u4723\u174b\u55f1\u6c97\uc358\u7a90\u2880\u0f16\uc37f\u18c6\ucfb3\uaef1", "\ud936\udd31",
        31, -1000, -1129257534, -3763843989831286636L, -99825L, false, false, (char) 49509, (char) 83,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 5, 2, "\ud828\udc55\uda3f\udd90\ud954\udee6\uda18\udfa7\uda6d\uddaf", "\u174b\u55f1\u6c97\u0f7f\u7a7e\u2880\u0f16\uc37f\u7240\u1422\uaef1\uba2a\u250c\ua7cc\ucd95\u6bef\u7dfb\u52c5\u78a4\u33cb\u9ab5\ubf29\u5332\u9b0c\u1483", "\udb12\uddd2\uda10\udeea",
        11, 14384, -1620093964, -9122150017418776030L, 36816L, false, false, (char) 48134, (char) 56440,
        Double.longBitsToDouble(0x3fc53fa26073e638L), Double.longBitsToDouble(0x3fd4dcdb8fed0bd2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 13, "\ud836\udd16\ud8c0\ude07\udb4b\udd41\udbd0\uddb4\uda6d\uddaf", "\u174b\u55b1\u6c97\uc358\u7a90\ubc0e\u3f52\u2fc4\u84aa\u6c2b\uc34a\uba2a\u250c\ua7cc\u2836\u940d\u7dfb\u7dec\u7cd4\u8f72\u42a6\u96be\u08e4\u9b0c\u1483", "\udb12\uddd2\uda10\udeea\udb54\ude66",
        2, 23179, -2123892415, 626604124380198616L, 87833L, true, true, (char) 42855, (char) 22492,
        Double.longBitsToDouble(0x3fd72e4008e61bcaL), Double.longBitsToDouble(0x3f980dec78929ee0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud8d8\udc5a\udb40\udc0b\ud954\uded8\uda18\udfa7\uda6d\uddaf\u3fe2\u55f1\u559c\u85c4\u7c33\ubf7a\u0985\uc327\u18c6\u67da\u921d\ub750\ua04a\ua7cc\u1ab1\uc80d\u7dfb\u6b44\u3f4f\u8f72\u83a5 |a0=java.lang.StringBuffer:\ud8d8\udc5a\udb40\udc0b\ud954\uded8\uda18\udfa7\uda6d\uddaf\u3fe2\u55f1\u559c\u85c4\u7c33\ubf7a\u0985\uc327\u18c6\u67da\u921d\ub750\ua04a\ua7cc\u1ab1\uc80d\u7dfb\u6b44\u3f4f\u8f72\u83a5 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 0, 2, 13, "\ud8d8\udc5a\udb40\udc0b\ud954\uded8\uda18\udfa7\uda6d\uddaf", "\u3fe2\u55f1\u559c\u85c4\u7c33\ubf7a\u0985\uc327\u18c6\u67da\u921d\ub750\ua04a\ua7cc\u1ab1\uc80d\u7dfb\u6b44\u3f4f\u8f72\u83a5", "\u3c6f\udbfe\udec0\ud92c\udd89\ud800\ude19\udad6\udec7\uda93\udf6e",
        42, 49295, -1308867685, -9130541992455032286L, -37408L, false, false, (char) 3351, (char) 56440,
        Double.longBitsToDouble(0x3fc53fa26873be58L), Double.longBitsToDouble(0x3fe0ebb4cb618892L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u6dd0\ud8e8\udf79\udbf6\ude89\ud971\uddef\uda6d\uddaf\ud976\udd39\uda6e\udc50\udb5f\udd3f\udb48\udf30\ud98d\udd01\udb07\udd2e\ud93f\udccd\udbde\udd0a\ud92c\uddb0\ud9c1\udc9d\ud8f6\udcbc\ud9fa\udf7d\udbf8\ude33\ud9ec\udfd0\ud9b1\udc02\ud99b\udedb\udbbd\ude55\udba2\udc2b\uda0a\uddca\udbe0\udcc0\udbe4\udd1e\ud95c\udcbe\ud8df\udc40\ua20b\ud86c\udd4a\u3cfa\udbfe\udec0\ud92c\udd89", "\u20fa\ua09b\uaab6\u8808\uab36\u3f16\ub321\u7d9d\u3e2f\u3341\uc431\u07e2\u139f\u18f5\uc94b\ubcb1\u8ec7\uae40\u51fa\u1bfd\ub34d\u6728", "\udb34\udfe8\uda1a\udcbc\ud9ec\udf8a",
        38, 38008, 1199611356, -6133538606733886258L, 83160L, false, false, (char) 34878, (char) 5235,
        Double.longBitsToDouble(0x3fe4f6998b316c0dL), Double.longBitsToDouble(0x3fe3edf18a7b3396L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 5, 2, "\ucadb\ud858\udcb4\ud954\udee6\ud92c\udea7\ud802\udf5a", "\u387f\u98eb\u6c97\ua1e0\u6ca9\uc88c\u847f\uc37f\u18c6\u72e5\uaee9\uba2a\u250c\ua7cc\ua564\u34fc\uc436\u841f\u2a98\u4304\u8cee\u567f\u6179\uae21\u2814", "\udbfb\udc93\uda10\udee1\ud82f\uded4\uda4f\udd2c\ud895\ude9c\ud852\uddcb\uda28\udd2f\udaaf\udd9b\ud89b\udc8e\udbdc\ude9e",
        54, 33265, -1398242647, 6463444872904540496L, 29733L, true, true, (char) 63261, (char) 28605,
        Double.longBitsToDouble(0x3fd5174c1815943eL), Double.longBitsToDouble(0x3fe5fea1f65a4c91L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u6dd0\ud81f\uddda\ud954\udee6\uda18\udfa7\uda2a\ude6e", "\u174b\u55f1\u6c97\uc358\u7a90\u2880\u0f16\uc37f\u18c6\u0796\uaef1\uba2a\u250c\ua7cc\u1ab1\uc80d\u7dfb\u7dec\u518b\ud173\ud4cf\ubf29\u1ce4\u9b0c\u1483\u9717\u2622\u72af\u20fa\u5926\uaab6\u8808\uab36", "\ud89b\udc8e\udbdc\ude9e\uda02\udfbb\udb89\udf7c\uda8d\uddbf\ud90d\udecb\ud844\ude76\udad3\udd1c\ud87d\udfcc\udba9\udc9e\udaa3\udd9c\udbb4\udc83\ud8a3\udc36\uda8d\udf5d\udac7\udf07\ud914\udcd3\u351b\ud9c0\udccf\ud8d9\uded7\udac4\udcef\uda99\ude96\udaec\uded6\ud9c5\udcab\ud984\udffe\udacd\ude92\udb36\udf53\ud968\udd84\ud85a\udf81\ud98a\udeb2\ud927\udd2c\uda35\udeec\ud8b0\udf74\ud90d\udf50\uda97\uddeb\ud8aa\udf4e\udbab\udd51\uda93\ude0a\udbf8\udff9\uda0c\udc33",
        10, 88680, 1385635879, 1228707946100557982L, 84298L, false, false, (char) 16939, (char) 42970,
        Double.longBitsToDouble(0x3feba765492d1072L), Double.longBitsToDouble(0x3fee4d10f8b4f59bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 2, "\u6dd0", "\000\u92e3\u49cc\000\u26d1\u55f1\u6c97\uc358\u7a90\u2880\000\000\000\000\ubf2e", "\u6944",
        58, -1000, 0, 0L, 90747L, false, false, (char) 0, (char) 51553,
        Double.longBitsToDouble(0x3fb1aca8400007c0L), Double.longBitsToDouble(0x3fee7a2f5b9b99d4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "", "\u6188", "",
        3, 83141, 1803452388, 3118103548450062980L, -100000L, false, false, (char) 42434, (char) 26116,
        Double.longBitsToDouble(0x3f3c0bca26000000L), Double.longBitsToDouble(0x3fb8ffb0f764ca90L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 5, 2, "\u372a\ud81f\uddda\ud954\udee6\ud9da\udfd5\uda6d\uddaf", "\u97e1\u55c6\u6c97\uc358\u7a90\u2880\u0f16\uc37f\u18c6\u0796\u3908\uba28\u250c\ua7cc\u1ab1\uc80d\u9223\u5c6a\u4552\u8f72\u2536\u211b\u1cd6\u9b0c", "\ud800\ude19\udb12\uddd2\uda10\udeea\udb54\ude66\uda37\uddc9",
        -1, 35585, -269602270, 7064818428492706944L, 6920L, false, false, (char) 38531, (char) 5423,
        Double.longBitsToDouble(0x3fd99d28b6809b3eL), Double.longBitsToDouble(0x3fc95115394ac9dcL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 15, 15, "\u6dd0\ud82f\udd03\udbcf\udedf\ud863\ude34\uda6d\uddab\ud976\udd39\ud830\udd51\udacd\ude39\udb49\udd34\udb5f\ude93", "\u2880\u0f16\uc37f\uc7c5\u0e8d\uaef1\u1b1f", "\uda5f\udeb6\uda02\udd33\ud999\udc5b",
        14, 52070, 2006581682, -4197091317765543678L, 98586L, false, true, (char) 63334, (char) 28192,
        Double.longBitsToDouble(0x3fe3101c74463de3L), Double.longBitsToDouble(0x3fe24747c3cf45ebL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 8, "\u7589\udb6b\udf56\udb98\udd60\udbaa\udfb9\ud8ed\udf33", "\u9435\ub0f2\u7eaa\uc18a\u7a90\u2880\u57ad\uc37f\u18c6\u4259\u69f7", "\ud997\udff1",
        32, 49291, -1129257619, -4669797423149861484L, -47345L, true, true, (char) 22420, (char) 29712,
        Double.longBitsToDouble(0x3fe848c4feb08482L), Double.longBitsToDouble(0x3fe22191722a2101L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:                                                    |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 5, 2, "\u7589\udb6b\udf56\udb98\uddad\uda84\ude66\ufd3a", "\u9435\u8b29\u6c97\u3eec\u7a90\u2880\u57ad\uc37f\u18c6\u4f77\u033a", "\udbe8\uded2\ud8c5\udf2f\ud9f1\udf58",
        51, 93060, 1008612756, 8618202699965436847L, -28603L, false, false, (char) 32529, (char) 62598,
        Double.longBitsToDouble(0x3fa9bab1f2513860L), Double.longBitsToDouble(0x3fc4077ef2775734L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:                             |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 8, 2, "\u7589\udb6b\udf56\udb98\udd60\uda84\ude66\ufd3a", "\u9435\ub0f2\u0d51\u3e75\uc031\u7d3e\u2863\ubfd2\u18b6\uaa91\ubb4e", "\udbe8\uded2\uda16\udf2e\ud9f1\udf31",
        28, 8776, -1123825890, 8618364016463775663L, -26609L, true, false, (char) 54510, (char) 10285,
        Double.longBitsToDouble(0x3fcc6645c1670254L), Double.longBitsToDouble(0x3fe012086e34f83aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u1f6e\ud89c\udcee\udb98\uddec\uda84\ude66\ufd3a", "\u9435\u506d\u4cec\u3eec\u7a90\u2880\u57ad\uc37f\u18c6\u4259\u033a", "\udbe8\uded2\ud8c5\udf2f\ud9f1\udf58\uda0a\udd75\ud900\udc2a\udbe4\udd1e\ud995\ude24\ud8c8\udc40\ua20b\ud858\ude41\u3ce1\udbfe\udec0\ud817\udf12\udacd\udd60\uda01\udc8e\ud83d\ude0d\ud8d3\udcca\udb44\ude89\udb1b\udefb\ud962\ude5b\u65a7\ud959\udca6\ud8b9\udeef\ud915\udf70\uda2e\uddd0\ud9f4\udf68\ud8be\udd3d\udbbe\udff5\uda93\udeef\udab4\ude95\ud8f5\udeeb\udbdc\ude0b\ud8db\udee4\udacc\uddc6\udbd8\udd76\u213e\uda1c\ude62\ud956\udc76\udafa\udf44\uda5b\udd94\ud948\ude33\uda53\uddb2\uda2d\udecb\ud965\uddfc\uda05\udf43\udb46\udfc7\udba2\udfb0\ud8ab\uddf6\ud920\udd3e\udb37\uddd2\udbcf\udd69\ud800\udf27\ud9b8\udd65\udb3d\udc9b\udb0c\ude93\udacc\udc83\udb14\ude33\udbd9\ude02\u6106\udbfc\udcdc",
        42, 91198, -61927867, 8417872347042912685L, -75643L, false, true, (char) 54078, (char) 18060,
        Double.longBitsToDouble(0x3fda81386496a4ecL), Double.longBitsToDouble(0x3fd20021126e7a7cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\ud9b9\udd92\udb6b\udf56\udb98\udd60\uda84\ude66\ufd3a", "\u9435\ub0f2\u6c97\u3eec\u079b\ub5d1\u57ad\uc37f\u18c6", "\ud9ec\udfd0\ud9be\udc89\udb5f\ude7f\ud8bf\udc2e\ud9f1\udf58\uda0a\udd75\ud900\udc2a\uda3f\udf2a\ud95c\udcbe\ud8c8\udc40\ua20b\udb00\ude95\u3c6f\udbfe\udec0\ud826\udda5\ud801\udd19\ud98e\udfdb\udadd\udd4c\udb81\ude42\udb51\udda9\ud805\ude7d\uda3f\ude37\ud8f6\udf7a\ud9f9\udc5e\udb5b\udc6e\udac3\udfeb\ud94b\udd35\ud9cc\udd33\udaca\udcd9\ud974\udcff\ud91a\udf05\ud809\ude0e\ud8c7\udcc9\udaed\ude4e\ud84f\udeae\ud809\ude83\udb18\udc53\udb10\ude49\ud9a5\udf4c\ud919\udc2e\ud88c\udde4\udb77\udd2f\udad0\udda0\udb5d\udf7b\uda81\udf75\udacd\ude2f\udb30\udfa4\udb34\udff6\ud8c0\udf0d\ud908\uddc5\u7d24\udbbf\udf63\ud951\udc89\udad7\udc9e\udb0b\udc4e\u9740\ud8bb\udea0\uda10\udec8\ud9e2\udf33\ud91e\udeb6\udbac\udc30\ud8fb\uddf2\ud88b\udd09",
        59, 77250, -765379183, -5294266948303010226L, 1803L, false, true, (char) 33978, (char) 5023,
        Double.longBitsToDouble(0x3fc3c741f394c5e4L), Double.longBitsToDouble(0x3fe40344ad30eb6eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 10, 9, "\u7589\udb6b\udf56\udb98\udd60\uda84\ude66\ufd3a", "\u9435\ub0f2\u6c97\u3eec\u136b\uc520\u853d\uc37f\u46e0\u4204\u40ea", "\udbe8\uded2",
        42, 49291, -1129257619, -4669797423149861484L, -62193L, true, false, (char) 29664, (char) 29851,
        Double.longBitsToDouble(0x3fe72df216b0607dL), Double.longBitsToDouble(0x3fe712ea3c2ea73bL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 5, 2, "\udad0\udcab\udbc8\udf8d\udb80\udf23\uda84\ude66\ufd3a\udada\udd56\uea97\ud8ea\udd97\ud8af\udf09", "\u1327\u2880\u57ad\uc397\uaefe\u42b9\u033a\uba2a\u8f81\u12c4\u370c", "\ud914\udd2f\udbdb\udf48\ud95c\udcbe\ud90f\udce4",
        37, 84221, -1093142458, 4718953158199404208L, 96921L, false, true, (char) 1604, (char) 9393,
        Double.longBitsToDouble(0x3fe8eb8106654ee1L), Double.longBitsToDouble(0x3f9ef6f29a87b120L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 5, 2, "\ud899\uddc3\udb75\udd91\udb98\udd60\uda84\ude66\ud819\udc4a\udb7f\ude09\udabd\udc7d\ue4bd\ud9d3\ude30\udaff\udf6e\ud938\udc85\ud950\udc09\udbce\udc82\uda3c\ude14\ud9c2\udf51\udb42\udc62\ud9b0\udfca\u0e6e\ud87b\udc18\udb4e\udde3\udbe8\uded2\ud8a0\udfdb", "\ubeb2\u85dd\u4139\u6ab2\u2f49\u1ce4\u9b0c\u1483\u322a\u2922", "\udab5\uddf8\uda47\udfd4\udb43\ude2d\ud804\udd1b\ud81e\udfea\ud9b7\udc10\uda7d\udd3a\ud954\udd56\ud977\udef4\udb9d\udc01",
        34, 83272, -1759301205, -1826170584005676368L, 19188L, true, true, (char) 801, (char) 41279,
        Double.longBitsToDouble(0x3fdd51678b5666b2L), Double.longBitsToDouble(0x3fe74b5b2ad405e0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 5, 2, "\u6dd0\ud81f\uddda\ud954\udee6\uda18\udfa7\uda6d\uddaf", "\u174b\u55f1\ud560\uc358\u7a90\u2880\u0f16\uc37f\u18c6\u0796\uaef1\uba2a\u250c\ua7cc\u1ab1\uc80d\u7dfb\u7dec\u7cd4\u8f72\u42a6\ubf29\u1ce4\u9b0c\u1483", "\udb27\udff2\uda10\udeea\udb54\ude66\uda37\uddc9\ud81d\udda5",
        -1, 66730, 1644906222, 67822825327708960L, -48471L, true, false, (char) 29062, (char) 49753,
        Double.longBitsToDouble(0x3fefb42f49100e81L), Double.longBitsToDouble(0x3fd4fe1b6e5c2e30L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 5, 2, "\u6dd0", "\ud5bd\u92e3\u49cc\u4723\u174b\u55f1\000\u7c64\u7a90\u2880\u0f16\u4c72\u18c6\u0796\u60b9", "",
        28, 1403, 355763948, -4850124178180800299L, 31506L, false, true, (char) 7107, (char) 49630,
        Double.longBitsToDouble(0x3fb1b414c72df6b8L), Double.longBitsToDouble(0x3e18af32e0000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 5, 2, "\u6dd0\udb19\udcf7\ud954\udee6\uda18\udfa7\uda6d\uddaf", "\u174b\u55f1\u044e\ua0ae\u7a90\u2880\u0f16\uc37f\u18c6\u0796\uaef1\uba2a\u250c\ua7cc\u1ab1\uc80d\u6d98\u7dec\u7cd4\u8f72\u38df\u3598\u2a36\ud364\u1452", "\udb27\udff2\uda10\udeea\udb54\ude66\uda37\uddc9\ud895\ude9c",
        0, 66730, 1644906222, 67822823745769226L, 77186L, true, true, (char) 20882, (char) 1937,
        Double.longBitsToDouble(0x3fd4fe1b6e5c2e30L), Double.longBitsToDouble(0x3fe9e1b221a7f449L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 9, 9, "\u6d90\ud81f\uddda\ud954\udee6\uda18\udfa7\uda92\udf42", "\u174b\u55f1\ud560\uc358\u7a90\u8b11\u5afc\u5359\u2789\u0796\uaef1\uba2a\u4932\u554e\u1ab1", "\udbe0\udcc0\udbe4\udd1e\ud95c\udcbe\ud8df\udc40\ua20b\udb00\udec3\u3c6f\ud899\udf5f",
        6, 71755, -505097799, -1659338666353675540L, -37408L, false, true, (char) 47900, (char) 65073,
        Double.longBitsToDouble(0x3fe54fee53f02b88L), Double.longBitsToDouble(0x3fda820fb2190dd2L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 10, 7, "\ud8a2\udce5\ud81f\uddda\ud954\udee6\uda18\udfa7\uda6d\uddaf", "\u174b\u55f1\ud5b9\uc358\u7a90\u2880\u0f16\uc37f\u18c6\u0796\uaef1\uba2a\u20e6\ucf2e\u1ab1\uc80d\u197b\u7dec\u4339\u0d17\u40bc\ubf29\u1ce4\u9b0c\u1483", "\udb15\ude4f\udaed\udd18\u2cab\uda37\udd1c\ud895\ude0a",
        24, 11647, 1644906222, 67822870990409482L, -19326L, false, true, (char) 29237, (char) 1937,
        Double.longBitsToDouble(0x3fd4fe1b6e5c2e30L), Double.longBitsToDouble(0x3fe9e1b221a7f449L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
