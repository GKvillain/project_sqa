package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class OptionBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 12, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u2d3e6\u2e36\u7d35\u3dd6\u9573\u00b9\u9709\u72d1\u0a0b\uaaaa\ud1b7\u793b\uc9c0", "\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\udb52\udc32\udbd6\udc36\uda12\udc5d\udbde\udd45\udbf9\udfa7\udb46\ude01\uda19\uddab\uda94\udfa4\ud9ac\udfa2\udaa8\udd78\ud85e\udf17\ud9e7\udcd0\udbdf\udd64\ud917\udc58\udbcb\ude28",
        27, 33394, -266062389, 6028185664044892571L, 54478L, true, false, (char) 21627, (char) 34873,
        Double.longBitsToDouble(0x3feb8c2cd490da72L), Double.longBitsToDouble(0x3fc70e7e5fba56ecL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 12, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u2d3e6\u2e36\u7d35\u3dd6\u9573\u00b9\u9709\u58d1\u0a0b\uaaaa\u8a07\u1fc1\u3205", "\udb06\udca0\udb39\ude8c\ud97c\udd43\ud8ed\udf55\ud89b\udf39\uda82\udeca\udb96\udc3e\uda0c\udcfd\ud8b9\udda7\udbf9\udfa7\udb46\ude01\uda19\uddab\uda94\udfa4\ud9ac\udfa2\udaa8\udd78\ud85e\udf17\ud9e7\udcd0\udbdf\udd64\ud917\udc58\udbcb\ude28",
        27, 33394, -266062389, 6028185664044892571L, 54478L, true, false, (char) 21627, (char) 34873,
        Double.longBitsToDouble(0x3feb8c2cd490da72L), Double.longBitsToDouble(0x3fc70e7e5fba56ecL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=void\012",
        Z.run(T, 2, 3, 12, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u2d2e6\u2e36\u7d35\u3dd6\u9573\u00b9\u9709\u72d1\u0a0b\uaaaa\ud1b7\u793b\u5f80", "\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\u4d93\udbed\uddc6\u0a35\udae7\udf25\udbf9\udfa7\udb46\ude01\ud8ec\udf8a\uda94\udfa4",
        13, 53262, 101358268, 6777369471641196500L, -27897L, false, false, (char) 13951, (char) 59228,
        Double.longBitsToDouble(0x3fe74ed9c99b53a8L), Double.longBitsToDouble(0x3f78e5fe49290780L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 7, 0, 6, "\ud909\udff1", "\u4735", "\ud8b9\udf66\uda31\udcf8\udb76\udc0a\ud9aa\udd07\ud868\udfd0\uda77\ude1f",
        40, 51648, -1999230190, -3471230174433601736L, -6079L, false, false, (char) 3592, (char) 48437,
        Double.longBitsToDouble(0x3feaed526cf5337bL), Double.longBitsToDouble(0x3fb5ac621428e7f8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 12, 12, "\ud909\udff1\ud97b\udc25\udb6e\ude02\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8ec\udd1e\udb42\udfe3", "\u52616\u2e36\u7d35\u3dd6\u9573\u00b9\u9709\u72d1\u0a0b", "\uda74\udfb0\ud866\ude45\udacb\ude1d\udb2b\udd95\ud93e\udc2c\ud8b9\udcaa",
        57, 11911, 460650511, -2584729391488283244L, 22314L, false, true, (char) 52453, (char) 59285,
        Double.longBitsToDouble(0x3fe4dd76bb511683L), Double.longBitsToDouble(0x3fdd60566579f3a0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 16, 6, "\ud943\udfcf\ud819\udf54\ud98c\ude0c\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\ud90e\udfab", "\u84426\u8179\u571d\u235a\u9573\ucc2e\u1f55\u203b\u0a0b", "\udafa\udda2\ud858\udc15\udacb\ude65\ud8aa\udc55\ud9ad\ude0b\uda3b\udcc9",
        57, 23526, 460617115, -2584729390786446308L, 25575L, false, true, (char) 52453, (char) 52488,
        Double.longBitsToDouble(0x3fe28f6463511683L), Double.longBitsToDouble(0x3fdd60566483f3a0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 10, 6, "\ud98a\udf32\ud938\udd2b\udb34\udca9\ud879\uddc2\ud8ca\udf74\udaad\udfb1\ud8e2\udeee\uda31\udd33\udb76\udc0a\ud9aa\udd07\ud868\udfd0\uda77\ude1f", "\u3dd6", "\udb8e\udf35\udafb\udf08\uda07\udfb2\uda26\udd45\udbee\udd71\uda74\udfb0\ud866\ude45\udacb\ude65\ud908\udc64\ud914\udfb4\uda3b\udcc9\ud975\udda5\ud8a6\ude45\ud89b\udf39\udb52\udc32\udbd6\udc36\uda12\udc5d\udbde\udd45\u89a8\udbaa\ude94\uda19\uddbe\uda94\udfa4\udb9d\udebb\ud9d2\udd06\ud867\udece\ud9e7\udcd0\udbdf\udd64\ud917\udc58\udbcb\ude28\ud824\uddcc",
        19, 71611, 1469213420, 4143172684888813062L, 73607L, false, true, (char) 64367, (char) 47371,
        Double.longBitsToDouble(0x3fc21b4e52e1cfc8L), Double.longBitsToDouble(0x3fed34addb9fc496L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 11, 12, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb97\uddb5\ud8b9\udf66\uda31\udcf8", "\u54ff\u41b1\u80eb\u7d35\u3dd6\u9573\u8825\u519f\u72ce\u0a0b\uaaaa\ud1b7\u793b\uc9c0", "\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\udb52\udc3b\udbd6\udc36\uda12\udc5d\udbde\udd45\udbf9\udfa7\udb46\ude01\uda19\uddab\uda94\udfa4\ud9ac\udfa2\udaa8\udd78\ud85e\udf17\ud9e7\udcd0\uda2d\udd4a\ud875\udf51\udbe3\udc80",
        27, 33394, -266062389, 6028110897254203803L, 54478L, true, false, (char) 21627, (char) 34873,
        Double.longBitsToDouble(0x3fe7942cd4489456L), Double.longBitsToDouble(0x3fc70e7e5fba56ecL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 4, 12, 4, "\ud91f\udd06\ud8ec\udedd\ud9f1\udfc0\ud846\ude72\u5014\ud8a6\udca3\ud8b9\udf66\uda31\udcf8\udb76\udc0a\ud9aa\udd07\ud868\udfd0\uda77\ude1f\ud882\udce4", "\ua7f1", "\udafb\udf17",
        59, 83699, 242411672, -4763682963096862894L, 73301L, false, true, (char) 19341, (char) 16886,
        Double.longBitsToDouble(0x3fe573e9e12ccf56L), Double.longBitsToDouble(0x3fdfab905839b84eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 13, 5, 1, "\ud918\udec6\ud8ec\udedd", "\u355f\u60a9\u887b", "\ud9aa\udce6\ud868\udfd0\uda77\ude1f\ud882\udce4\ud865\ude2b\ud8bf\udc0c\ud8a6\udc62\udb2a\ude79\udb8e\udeb7\udae8\ude08\udbbb\udc2b\uda2b\udc5c\udbee\udd71\uda74\udfb0\udbf1\udc29\udacb\udea1\ud8aa\udc55\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\udb52\udc32\udbd6\udc36\ud9cd\udf26\udbde\udd45\udb44\udc0d\udb5a\udc1f\uda19\uddab\uda94\udfa4\ud9ac\udfa2\ud963\udf3d\uaa9a\ud9e7\udcbd\uda4b\udf12\ud917\udc58\ud961\udefe\uda6f\udcf2\udb02\udd39\ud8c8\udd6f\ud83c\udfbb\ud9a9\udcfe\ud90d\udde6\u740b\uda43\udd68\udb41\udfbc\uda6b\udcb9\ud8d1\udc5d\udb10\udc0c\udb35\ude74\udbbe\udff3\udb24\udcba\ud844\udcd1\uda9c\udd02\ud904\udfe9\ud965\udfc5\uda53\udcf3",
        35, 82117, 715527214, -750016200408111176L, 60807L, true, true, (char) 60197, (char) 24000,
        Double.longBitsToDouble(0x3fe2c2d574b5b6a3L), Double.longBitsToDouble(0x3fe29a0fb495624cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 12, 10, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb81\udeea\ud8b9\udf66", "\u6f4b\u2d3e6\u2e36\u7d35\u3dd6\u9573\u00b9\u9709\u72d1\u0a0b\uaaaa\ud1b7\u793b\uc9c0\uc061\u47f5\uaeb3\u5021\ub768\uc2ed\u2625\u67cc\u4eac\uc283\u7904\uc35a\u981d\u47c3\u2500\u19b7\u3a81\u09e5\u3637\u4866\u2b9f\uc6f8\u17ca\u21d8\u42ff\ube12\u8dc0\u7b88\ua2db\u6112\uaeb7\u3ac1\u8eee\u65fc\u7ec5\u03f2\ubc8f\ua6bb\u3326\u6fef\u65ec\u5ef3", "\ud82f\udd5d\ud848\udf05\ud9cf\udeb1\ud8b4\udd94\udbd1\udee8\ud896\udc2d",
        17, 29116, 214415170, -8796932305771763342L, -28705L, true, false, (char) 54510, (char) 57197,
        Double.longBitsToDouble(0x3fd6e9d77e1defb4L), Double.longBitsToDouble(0x3fdfbce0c49dd09aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 6, 12, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u2d3e6\u2e36\u7d35\u3dd6\u9573\u00b9\u97e6\u72d1\u0a0b\uaaaa\ud1b7\u793b\uc9c0", "\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\udb52\udc32\udbd6\udc36\uda12\udc5d\udbde\udd45\udbf9\udfa7\udb46\ude01\uda19\uddab\uda94\udfa4\udaf6\ude4a\ud9c8\udc28\ud85e\udf17\ud9e7\udcd0\udbdf\udd64\ud917\udc58\ud880\ude42",
        27, 33394, -266062389, 6028185664044892571L, 54478L, true, false, (char) 21627, (char) 34873,
        Double.longBitsToDouble(0x3feb8c2cd490da72L), Double.longBitsToDouble(0x3fc95c72da985fbcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 12, 6, "\ud909\udff1", "\u4735", "\ud8b9\udf66\uda31\udcf8\u4458\ud9aa\udc12\ud80a\udfc1\udb77\udf3b",
        40, 51648, -1999230190, -3471230174433601736L, -70268L, false, false, (char) 37274, (char) 28246,
        Double.longBitsToDouble(0x3fecb0739752bde3L), Double.longBitsToDouble(0x3feaed526cf5337bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u547b  :: null ]\012",
        Z.run(T, 1, 1, 4, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\udb27\udc94\ud8b3\uddf0\udaab\udd1d\uda09\udcee\uda31\udcf8", "\ud2df6\u2e36\ucb95\u3e1f\u9573\u00b9\u9709\u72d1\u0a0b\uaaaa\u00cb\u793b\uc9c0", "\ud9ad\ude0b\udbae\uddf6\udbf1\udd4b\ud8ed\udf55\ud89b\udf39\udb52\udc32\udbd6\udc36\ud84d\udede\udb66\udf68\ud870\udf11\udb46\ude01\uda19\uddab\ud8a7\udfee\ud9ac\udfa2\udaa8\udd78\ud85e\udf17\ud9e7\udcd0\udbdf\udd64\ud917\udc58\udbcb\ude28",
        27, 33394, -376945717, 6028185217368293787L, 54478L, true, false, (char) 21627, (char) 34873,
        Double.longBitsToDouble(0x3febec2cd7a8d13eL), Double.longBitsToDouble(0x3fce0e64ffba5488L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 12, 12, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u4baf\u0a10\u2e36\u7d35\u3dd6\u9573\u00b9\u9709\u72d1\ub9be\u1894\uae56\u790c\u546c", "\ud9ad\ude24\uda3b\udcc9\ud94a\ude8d\ud9ba\ude5a\ud899\udfee\udb52\udc32\udbf6\udf36\uda12\udc5d\udbde\udd45\udbf9\udfa7\udb46\ude01\uda19\uddab\uda94\udfa4\ud9ac\udfa2\udaa8\udd78\ud85e\udf17\ud9ef\udfe7\udbdf\udd64\ud917\udc58\udbcb\ude28",
        27, 33394, -266062389, 6031427316381352347L, 54478L, true, false, (char) 21627, (char) 34873,
        Double.longBitsToDouble(0x3feb8c2cd490da72L), Double.longBitsToDouble(0x3fc70e7e5fba56ecL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 4, 8, 14, "\ud909\udff1\ud8ec\udedd\u62d2\ud88e\udc32\ud8ca\udf74\ud842\udcc0\ud8b9\udf66\uda31\udcf8", "\u2d3e\ud798\u0895\u7da3\u5ed8\u9573\ua86a\u9709\u72d1\ud2a2\u1750\ud1b7\u0cba\u79f2", "\ud9ad\uddb5\uda3b\udcc9\uda68\ude2a\ud8ed\udf55\ud89b\udf39\udaf1\udc8c\udb22\udf4b\uda3a\udc65\udae9\ude2b\udbf9\udfa7\udb55\udf01\uda19\uddab\uda94\udfa4\ud9ac\udfa2\udaa8\udd78",
        58, 56456, -908588906, -46262629060240985L, 14238L, true, true, (char) 14129, (char) 33055,
        Double.longBitsToDouble(0x3fe031cbfc92fde6L), Double.longBitsToDouble(0x3fe3cbf66ea90c6eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 12, 6, "\ud909\udff1", "\000", "\ud8b9\udf66",
        30, 336, 4264437, 91482665758600922L, 33576L, false, true, (char) 16226, (char) 26379,
        Double.longBitsToDouble(0x3fd0137447b9b26eL), Double.longBitsToDouble(0x3fc095c3ee44f824L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 14, 0, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8\udb76\udc0a\ud9aa\udd07\ud868\udfd0", "\u7d35\u3dd6\u9573\u00b9\u9709\u72d1\u0a0b\uaaaa\ud1b7\u793b\uc9c0\uc061\u47f5\uaeb3\u5021\ub768\uc2ed\u2625\u67cc\u4eac\u1c9a\u3512\uc35a\u981d", "\ud9ac\udfa2\udaa8\udd78\ud85e\udf17\ud9e7\udcd0\udbdf\udd64\ud917\udc58\udbcb\ude28\ud824\uddcc\udaf7\udf54\udaef\udcdb\ud839\udfda\ud9a9\udcfe\ud90d\udde6\u740b\uda43\udd68\udb41\udfbc",
        6, 88065, 1944183696, -7657257670257031186L, 9377L, true, true, (char) 22809, (char) 52194,
        Double.longBitsToDouble(0x3fddce8e2b96865eL), Double.longBitsToDouble(0x3fc4312d9aef5ce4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 9, 12, 11, "\ud812\udcfb\udada\udd35\ud92b\udc1b\uda54\udfd1\ud8ca\udf74\udba2\udfbe\ud8b9\udf66\uda31\udcf8\udb6c\udd65\ud9e6\udfc1\ud877\udc8b\uda88\ude7b\ud882\udce4\udb64\udfeb\ud853\udfca\ud8a6\uddc7\udb2a\ude79\udb8e\udeb7\udafb\udf08\udbbb\udc2b\uda2b\udc5c\ud9ba\ude74\uda74\udfb0\ud866\ude45\udb0c\ude85\udbae\udf26\ud840\udda5\udb6b\uddb4\ud94c\ude5c", "\u1dbd\uc58e\u5c1e\u7904\u7c7c\u985b\u47c3\u252a\u19b7\u3a81\u7abe\u0424\u484a\u4649\u450f\ud0db\u9aef\u5353", "\ud90d\udde6\udba4\udfef\uda43\udd10\udaf2\udf14\udb27\udcd7\ud95c\ude35\ud8ec\udf65\udb35\ude74\ud959\udd21\uda60\udcc8\ud8a5\udd6a\ud8ae\udfeb\ud9f9\udc74\ud933\udea1\ud830\udc05\ud8c2\udfa7\udb74\udc47\udbe2\ude5a\uda8d\udde4\ud98c\udd00\udae3\udc51\udbdf\uddce\u6a23\uda5d\udcab",
        20, 3397, -1309632160, -4516186444468257366L, -34897L, false, false, (char) 45503, (char) 65107,
        Double.longBitsToDouble(0x3fcc9956e1f7ac20L), Double.longBitsToDouble(0x3fd47b0513708426L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 12, 6, "\udbe3\udcfe", "\u390d\u355f\u60a9", "\udb72\ude0a",
        26, 89157, -207245606, -6313389109504772552L, -81196L, false, true, (char) 48196, (char) 26546,
        Double.longBitsToDouble(0x3fc095c3fe44f824L), Double.longBitsToDouble(0x3fc310b01e5839c8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 5, 9, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u2d2e6\u2e36\u7d35\u3dd6\u9573\u00b9\u9b57\ub876\u0a0b\uaaaa\ud1b7\u793b\u5f80", "\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\u4d93\udbed\uddc6\u0a35\udae7\udf25\udbf9\udfa7\udb46\ude01\ud8ec\udf8a\uda94\udfa4",
        13, 53262, 1678416572, 6777406292395825108L, -27897L, false, false, (char) 13951, (char) 59228,
        Double.longBitsToDouble(0x3fefcb31c93b18d2L), Double.longBitsToDouble(0x3f78e5fe49290780L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 6, "\uda39\udf18\ud90c\udcbd\uda3e\udcae", "\u60a9\u887b\ud09d\u9dd6\u37cc\u2d2e", "\udabc\udf17\ud9a1\udc06\ud8c0\udf6a\udb2a\ude79\u9eae\udafb\udf08\udbbb\udc2b\uda2a\udffc\udbee\udd71\uda74\udfb0\ud90c\uddb7\ud82f\udefd\udb9b\ude93\udb9b\udc50\ud8fb\udf0b\ud94c\ude14\ud8ed\udf55\ud89b\udf39\udb78\ude94\udbed\uddc6\u0a35\ud9bb\udd6f\uda07\ude19\udb46\uddbe",
        52, 89617, 90579793, -445704810792314180L, -14382L, true, true, (char) 42957, (char) 52182,
        Double.longBitsToDouble(0x3fd58a39f33aff4cL), Double.longBitsToDouble(0x3feb8946819a2ad4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \ucce5  :: null ]\0121=org.apache.commons.cli.Option:[ option: \ucce5  :: null ]\012",
        Z.run(T, 2, 1, 1, 6, "\ud909\udff1\ud8ec\udedd\udb2e\udc26\u7f9a\ud8db\udc16\udb87\udc04\ud8b9\udf66\ud906\udde4", "\u2d2e6\u2e36\u9bba\u6941\u9573\u00b9\u9709", "\uda2b\udc5c\udbee\udd71\ud8b3\udf19\ud90c\uddb7\ud82f\udefd\ud893\udfcf\ud848\udf19\uda19\udf84",
        57, 1645, 460617115, 3988274265360816556L, -830L, false, true, (char) 52453, (char) 59964,
        Double.longBitsToDouble(0x3fe28f52bb511683L), Double.longBitsToDouble(0x3fd3eff3d579f3a0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=void\012",
        Z.run(T, 2, 4, 12, 6, "\ud909\udff1\ud8ec\udedd\udaca\udcc7\ud879\uddc2\ud8ca\udf74\udb86\udfbe\uda12\udf48\uda31\udcf8", "\u2d2e6\u2e36\u7d35\ucf67\u9573\u00b9\u9709\u72d1\u0a0b\uaaaa\ud1b7\u0c20\u6013", "\ud91e\udec2\uda44\udfc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\u4293\udbed\uddc6\u0a35\udae7\udf25\udbf9\udfa7\udb46\ude01\ud8ec\udf8a\uda94\udfa4\ud9ac\udfa2\udaa8\udd78\ud85e\udf17\udbda\udf2a\ud85b\uddea\udbed\udfd5\udbcb\ude28\ud824\uddcc\udaf7\udf54\ud88d\udea0\ud839\udfd7\ud83a\udfc7\uda09\udfa1\udafe\uddf4\ud93a\udd94\ud8d8\udd98\udb67\udd6d\udacc\udf14\ud849\ude1e\ud9d6\udce3\uda03\udc51\ud962\udd66\uda6a\udf2b\udbf4\uddfe\ud92b\udc26\ud8f3\udec6\udb7b\udd4f\ud949\udcd8\ud87e\udd04\uda72\udf7c\ud95e\udf91\udac3\udd33\udbfb\udf80\ud819\udf22\udb31\udeed\udba9\ude6b\ud813\udf3e\ud9da\udf67\udb62\udf7b\ud806\udef4\udaf7\udf0f\ud96f\udeac\ud8e7\udfee\ud910\udc9f\ud80c\udd56\uda62\udc0f\ud9e6\udcdc\uda47\udf82",
        40, 35065, 2093374076, 517671413873551422L, 10343L, false, true, (char) 17106, (char) 25502,
        Double.longBitsToDouble(0x3fc09caa6fd312a8L), Double.longBitsToDouble(0x3fe1d4c2eabf22f0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 17, 12, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8\udb76\udc0a\ud9e2\udd02\ud868\udfc0", "\u77df\u3ebf\u64c5\uc93e\u9709\u72d1\u0a0b\uaaaa\u2ebf\u6aca\u5f80\u80d3\uc76e\uaeb3\u5021\ub768\uc2ed\u2625\u5be9\uac3c\ub871\u8d9d\u9dd5\ua657", "\ud855\udd76\udb28\udd78\ud85e\udf17\udbda\udf2a\udbad\udf27\ud83c\udfe4\udbd6\udfa2\ud824\uddcc\udb90\ude3e",
        59, 79065, 964657563, 5913041617542554770L, -66472L, true, false, (char) 58083, (char) 51979,
        Double.longBitsToDouble(0x3fe1e9ade98beeb3L), Double.longBitsToDouble(0x3febc31afd55b606L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 15, 15, 12, "\ud909\udff1\ud8e7\ude1b\udba6\udca2\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\ud95b\uddf4", "\u2d2e\u1d0a\u5085\u3dc6\ud405\uafcd\u00ab\u6822\u3394\u09d3\u8b8f\u4ce9\u396b\u1da9", "\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud9c0\ude06\udafe\udd82\udbed\uddc6\u0a35\udae7\udf25\udbf9\udfa7\udb42\udf01\ud8ec\udf8a\uda95\udc4a",
        13, 53262, 1557174972, 6777476128564058068L, -12793L, true, false, (char) 761, (char) 51326,
        Double.longBitsToDouble(0x3fe74edb319b53a8L), Double.longBitsToDouble(0x3f78e5fe49290780L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 9, 6, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\udbb7\udca7\ud908\udd73\udb9f\udd57\ud8b9\udf66\uda31\udcf8", "\u2d2e6\u2e36\u7d35\u3dd6\u9573\u00b9\u9709\u72d1\u0a0b\uaaaa\ud1b7\u6cc2\u078a", "\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud8fe\ude60\ud93a\udd63\ud94f\uddbe\uda03\ude69",
        4, 60650, 90999216, -1560527159183599535L, -64714L, false, false, (char) 5034, (char) 30178,
        Double.longBitsToDouble(0x3fbf17300d3be5f0L), Double.longBitsToDouble(0x3fe3b263e9c2f4bcL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 6, "\uda91\udd28\ud9f2\udfe8\uda3e\udcae\ud853\ude4f\ud9e9\udcb3\udbae\udd3c", "\u9dd6\u37cc\u2d2e6\ubac5\u8ad5\u3dd6\u9573\u00b9\u9709\u09e6\u0a0b", "\ud9f2\udefd\ud8f9\udc35\ud82f\udefd\ud893\udfcf\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\u4d93\ud9c9\udc92",
        50, 74770, 1601954226, -4725335949717935351L, 40113L, false, true, (char) 38028, (char) 5034,
        Double.longBitsToDouble(0x3feea2f0707c5cc0L), Double.longBitsToDouble(0x3fda77cbc4ec98faL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.Option:[ option: null \ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8  :: null ]\012",
        Z.run(T, 2, 15, 16, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u2d2e6\u2e36\u7d35\u3dd6\ub102\u00b9\u9709\u72d1\u0993\uaaaa\ud1b7\u793b\u5193", "\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\u4d93\udbed\uddc6\u0a35\udae7\udf25\udbf9\udfa7\ud8e2\udc6e\ud8bb\udc86\uda94\udfa4",
        52, 53156, 101358268, 6777369471641196500L, -27897L, false, false, (char) 13951, (char) 59228,
        Double.longBitsToDouble(0x3fe74ed9c99b53a8L), Double.longBitsToDouble(0x3f78e5fe49290780L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.Option:[ option: \ubce4  :: null ]\012",
        Z.run(T, 2, 13, 17, 17, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2", "\u887b\ud09d\u9dd6\u37cc\ub2f46", "\ud8bf\udc0c",
        4, 61040, -650672895, -5899843208782174076L, -28472L, false, true, (char) 48356, (char) 3657,
        Double.longBitsToDouble(0x3fbbc5bc22b58c40L), Double.longBitsToDouble(0x3fe428e7fcfb267bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.Option:[ option: null [ARG...] :: null ]\012",
        Z.run(T, 2, 5, 2, 6, "\ud909\udff1\ud8ec\udedd", "\u355f\u60a9\u887b\ud09d\ua5d7\u37cc\u2d2e6\u2e36\ub1a6", "\udb2a\ude79\udb8e\udeb7\udafb\udf08",
        51, 82881, 242411694, -4763682961729781934L, 63502L, true, true, (char) 19908, (char) 4357,
        Double.longBitsToDouble(0x3fe0ea2d4b624577L), Double.longBitsToDouble(0x3fed95c109b04336L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 7, 0, 6, "\ud909\udff1", "\u2c8b", "",
        -5, -990, -1224522664, -1134605887134694467L, -100000L, false, false, (char) 38711, (char) 48196,
        Double.longBitsToDouble(0x3fe6e6c9bce58500L), Double.longBitsToDouble(0x3fe70ba8f09810a5L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 17, 0, "\u5c59\ud819\udf54\ud98c\ude0c\ud8a5\uddb8\ud852\udc62\ud9f5\udfba\ud8b9\udf1f\ud90e\udfab", "\u84426\u8179\u16aa\u235a\u9573\ucc2e\u1f55\ub4fb\u0a0b", "\ud8a6\udf97\ud934\ude43\udacb\ude65\udbfc\uded0\ud9ad\ude0b\udb31\ude6c\ud94e\udc8b",
        6, 56115, 878335506, 537404715293577800L, 59374L, false, true, (char) 52488, (char) 40669,
        Double.longBitsToDouble(0x3fea88b419d60566L), Double.longBitsToDouble(0x3fe20fce8255cc05L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 4, 11, 4, "\ud9cc\uded3", "\ua367\ud35c\ubde4\u4f14\ud01f\u9dd6\u6f4b\u2d3e6\u2e5b", "\udbcc\udc9a",
        9, 74382, -1368315182, 7576084284164931613L, -81884L, true, true, (char) 9893, (char) 50155,
        Double.longBitsToDouble(0x3feb1650f55cf787L), Double.longBitsToDouble(0x3fe87f7fdf75a3faL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 6, 12, 6, "\u13b0", "\u4735", "",
        54, -990, -1224522664, -1134605887134694467L, 20046L, false, false, (char) 26379, (char) 48417,
        Double.longBitsToDouble(0x3feee6c9b884ae1fL), Double.longBitsToDouble(0x3fec89f0489885beL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\000",
        -5, -1000, 2080178176, 75144483639552L, -100000L, false, false, (char) 63031, (char) 37,
        Double.longBitsToDouble(0x3fe000000038cfd3L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.Option:[ option: null  :: null ]\012",
        Z.run(T, 2, 15, 2, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8\udb76\udc0a\ud9aa\udd07\ud868\udfd0", "\u7d35\u3dd6\u9573\u00b9\u9709\u72d1\u0a0b\uaaaa\ud1b7\u793b\uc9c0\u53ef\u14f8\uaeb3\u5021\ub768\uc2ed\u2625\u67cc\u4eac\u1c9a\u3512\uc35a\u981d", "\ud9ac\udfa2\udaa8\udd78\ud85e\udf17\ud9e7\udcd0\udbdf\udd64\uda78\udd29\ud821\uddd0\ud824\uddd7\udaf7\udf54\udaef\udcdb\ud839\udfda\ud9a9\udcfe\ud90d\udde6\u740b\uda43\udd68\udb41\udfbc",
        6, 88065, 1944183696, -7657257670257031186L, 9377L, true, true, (char) 22809, (char) 52194,
        Double.longBitsToDouble(0x3fddce8e2b96865eL), Double.longBitsToDouble(0x3fc4312d9aef5ce4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 3, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u2d2e6\u2e36\u7d35\u3dd6\u9573\u00b9\u9b57\ub876\u0a0b\uaaaa\ud1b7\u793b\u5f80", "\ud9ad\ude0b\uda3b\udcc9\ud8c6\udffb\ud809\udd77\udb25\udd03\udb0b\uddc3\udbda\ude36\u0a35\udae7\udf25\udbba\udc30\ud9f3\udd26\ud8ec\udf8a\uda94\udfa4",
        13, 53262, 1678416572, 6777406292395825108L, 14238L, true, false, (char) 56882, (char) 39436,
        Double.longBitsToDouble(0x3f78e5fe49290780L), Double.longBitsToDouble(0x3fe8e90e5adec2ecL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 4, 4, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\ud879\uddc2\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u2d2e\u4a8d\u2e36\u7d35\u3dd6\u9573\u00b9\u9b57\ub876\u0a0b\uaaaa\ud1b7\u793b\u5f80", "\ud9ad\ude0b\uda3b\udcc9\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\udbc5\ude2f\udbed\ude00\u0a35\udae7\udf25\udbf9\udfa7\udb46\ude01\ud8ec\udf8a\uda94\udfa4",
        13, 53262, 1678416572, 6777406292395825108L, -27897L, false, false, (char) 13951, (char) 59228,
        Double.longBitsToDouble(0x3fefcb31c93b18d2L), Double.longBitsToDouble(0x3f78e5fe49290780L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 4, 4, 8, "\uda39\udf18\ud90c\udcbd\uda3e\udcae", "\u0d63\u887b\ud09d\u9dd6\u37cc\u2d2e", "\udabc\udf17\ud9a1\udc06\ud8c0\udf6a\udb2a\ude79\u9eae\udafb\udf08\udbbb\udc2b\uda2a\udffc\udbee\udd71\uda74\udfb0\ud90c\uddb7\ud82f\udefd\udb9b\ude93\udb9b\udc50\ud8fb\udf0b\ud94c\ude14\ud8ed\udf55\ud89b\udf39\udb78\ude94\udbed\uddc6\u0a35\ud9bb\udd6f\uda07\ude19\udb46\uddbe",
        52, 89617, 90579793, -445704810792314180L, -14382L, true, true, (char) 42957, (char) 52182,
        Double.longBitsToDouble(0x3fd58a39f33aff4cL), Double.longBitsToDouble(0x3feb8946819a2ad4L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 6, "\ud9fa\udd95\ud8df\udd5d\uda3e\udcae", "\u691a\uc448\u7d7e\u2b08\u36f0\u2d2e", "\ud8d9\uddd6\u285a\ud8c0\udf6a\udb2a\ude79\ud87b\ude17\udafb\udf08\udbbb\udc2b\uda2a\udffc\ud869\uddf2\uda74\udfb0\ud90c\uddb7\ud82f\udefd\ud80a\udd0a\udbaa\udd64\ud8fb\udf0b\ud94c\ude14\ud855\udf68\u6547\udb78\ude94\udbed\uddc6\u0a35\ud9bb\udd6f\uda07\ude19\udb46\uddbe",
        52, 89617, 90579793, -445704810792314180L, 92533L, true, true, (char) 8257, (char) 56429,
        Double.longBitsToDouble(0x3fd415bdbcdbb0bcL), Double.longBitsToDouble(0x3fe944e5e6a75dc9L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 6, "\000\ud9f2\udfe8v\000\ud9cd\udd05\udbae\udd3c", "\u9dd6\u37cc\u2d2e6\ubac5\u8ad5\u3dd6\u9573\u00b9\u9709\u09e6\u0a0b", "\ud9f2\udefd\ud8f9\udc35\ud82f\udefd\ud893\udfcf\ud9ad\ude0b\000\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\u4d93\ud9c9\udc92",
        50, 74770, 1601954226, -4725335949717935351L, -99919L, false, false, (char) 0, (char) 5024,
        Double.longBitsToDouble(0x3feea2f0707c5cc0L), Double.longBitsToDouble(0x3fda77cbc4ec98faL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: null  :: null ]\0121=org.apache.commons.cli.Option:[ option: null  :: null ]\012",
        Z.run(T, 2, 2, 2, 14, "\uda26\udc53\ud9f2\udf5a\uda3e\udcae\ud853\ude4f\ud9e9\udcb3\ud8de\udf6c", "\u9dd6\u7c88\u2d2e6\ubac5\u4b7a\u3dd6\u9573\u0a80\u9792", "\udb31\udfa8\udaf5\udfdb\ud9f2\udefd\uda5c\udf88\ud82f\udef6\ud893\udfcf\ud90d\udc88\uda3b\udcc9",
        57, 23526, 460617115, 3988274262743570857L, 33358L, false, true, (char) 39800, (char) 43381,
        Double.longBitsToDouble(0x3fe0aac56b511683L), Double.longBitsToDouble(0x3fea082b350a15b9L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.Option:[ option: \000\000 [ARG...] :: null ]\012",
        Z.run(T, 2, 5, 2, 6, "\000\000", "\u380a\000\u4dca\ud09d\ua5d7\u2eff\u2d2e6\016\u496e", "",
        33, 69105, 2067420, 4470289390093882257L, -61856L, false, true, (char) 46558, (char) 49918,
        Double.longBitsToDouble(0x3e4ab80000000000L), Double.longBitsToDouble(0x3fd9b83564a036e8L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option:   :: null ]\0121=org.apache.commons.cli.Option:[ option:   :: null ]\012",
        Z.run(T, 2, 2, 2, 0, "", "\000", "\udb86\udfbe\ud8b9\udf66\uda31\udcf8",
        6, -1000, 2066153472, 7047010165855122645L, 20046L, false, false, (char) 38634, (char) 14149,
        Double.longBitsToDouble(0x3fe806c80000001fL), Double.longBitsToDouble(0x3fec89f04aae85beL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 6, "\000\000\000\000\ud9cd\udd05\udbae\udd3c", "\u9dd6\u37cc\uabfe\u295b\ubac5\u0c05\000\u9573\u00b9\u9709\u09e6\u0a0b", "\ud9f2\udefd\ud8f9\udc35\ud82f\udefd\ud893\udfcf\ud9ad\ude0b\000\ud94c\ude5c\000\ud89b\ude9e\u4d93\ud9c9\udc92",
        50, 74770, 1601954226, -4725335949717935351L, -99919L, false, false, (char) 0, (char) 5024,
        Double.longBitsToDouble(0x3feea2f0707c5cc0L), Double.longBitsToDouble(0x3fda77cbc4ec98faL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 2, 12, "\ud8ca\udf71\ud87e\udfb0\ud9f8\udcc0\uda2f\udfea\ud8a3\udf06\udb86\udfbe\ud8b9\udf66\uda31\udcf8", "\u2d3e6\u2e36\u7d35\u3dd6\u9573\u00b9\u9709\u72d1\u0a0b\uaaaa\ud1b7\u793b\uc9c0", "\ud8aa\udd49\uda14\udf53\ud94c\ude5c",
        6, 56115, -601804208, 5019679717745706525L, 17838L, false, true, (char) 44883, (char) 40669,
        Double.longBitsToDouble(0x3fea88b419d60566L), Double.longBitsToDouble(0x3fe5e7ce85a0060aL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u1ce7  :: null ]\0121=void\012",
        Z.run(T, 2, 17, 12, 6, "\ud909\udff1\ud8ec\udedd\uda3e\udcae\udb30\udc9f\ud8ca\udf74\udb86\udfbe\ud8b9\udf66\uda31\udcf8\udb76\udc0a\ud9f8\udd02\ud868\udfc0\uda77\ude1f\ud882\udce4\ud8c9\udebe\ud8bf\udcf5\uda2e\udfac\ud9b8\ude80\ud8b8\udfcb\udafb\ude2e\udbbb\udc2b\uda2b\udc5c\uda3d\udf87\ud975\uddd0\ud90c\uddb7\ud82f\udefd\ud893\udfcf\ud9ad\udd2b\uda3b\udcf3\ud94c\ude5c\ud8ed\udf55\ud89b\udf39\u4d93\udbed\uddc6\u0a35\udbac\udf2f\udab2\udecc\u2245\ud8ec\udf8a\uda94\udfa4\ud855\udd76\udb28\udd78\ud85e\udf17\udbda\udf2a\udbad\udf27\ud83c\udfe4\udbd6\udfa2\ud831\udc95\udacf\udc04\ud876\udea7\ud8c1\ude29\ud9a9\udcfe\u0cdc\udb5b\udc09\ud9c7\udd6e\udb4a\udd7d\udaec\uded9\udbb9\ude61\ud93a\ude3a\u3d38\ud8a9\udf66\ud9a9\udf00\udb9d\uddab", "\ua29e\ubfd2\u85d8\u1969\u1bc3\u7aa5\u981e\u4716\u1b88\uac75\uac22\u093c\u6472\u315b\u5d54\u8984\u273b\u1bf2\u6228\u95f7\u6811\uc1fe\u5a29\u07b8\uc586\u1f82\u9ea7\u0221\u188b\ub9e4\u543f\ucf21\ua7b0\uae14\u1c66\u19c2\u2c16\u9cdc\u8de6\u3591\u4f51\u62ca\u41d2\ua7e2\uca72\ubd16\u5e4c\u463c\u8e0f\u9006\u9b4f\u29d3\u3bc8\ubd9c\u96ff\u6aa9\u7a21\ua56a\u8a93\u48b6\u0cc8\u9dc7\ud208\u72e2\uacbc\u3e19", "\uda30\ude6d",
        29, 48256, -1077538373, -918505011984950823L, -98004L, false, false, (char) 7399, (char) 40954,
        Double.longBitsToDouble(0x3faa695c3380bee0L), Double.longBitsToDouble(0x3fded1216781daa6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.OptionBuilder|create||static",
    "M|org.apache.commons.cli.OptionBuilder|create|char|static",
    "M|org.apache.commons.cli.OptionBuilder|create|java.lang.String|static",
    "M|org.apache.commons.cli.OptionBuilder|hasArg||static",
    "M|org.apache.commons.cli.OptionBuilder|hasArg|boolean|static",
    "M|org.apache.commons.cli.OptionBuilder|hasArgs||static",
    "M|org.apache.commons.cli.OptionBuilder|hasArgs|int|static",
    "M|org.apache.commons.cli.OptionBuilder|hasOptionalArg||static",
    "M|org.apache.commons.cli.OptionBuilder|hasOptionalArgs||static",
    "M|org.apache.commons.cli.OptionBuilder|hasOptionalArgs|int|static",
    "M|org.apache.commons.cli.OptionBuilder|isRequired||static",
    "M|org.apache.commons.cli.OptionBuilder|isRequired|boolean|static",
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
    "M|org.apache.commons.cli.OptionBuilder|withArgName|java.lang.String|static",
    "M|org.apache.commons.cli.OptionBuilder|withDescription|java.lang.String|static",
    "M|org.apache.commons.cli.OptionBuilder|withLongOpt|java.lang.String|static",
    "M|org.apache.commons.cli.OptionBuilder|create||static",
    "M|org.apache.commons.cli.OptionBuilder|create|char|static",
    "M|org.apache.commons.cli.OptionBuilder|create|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
