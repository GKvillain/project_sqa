package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class OptionBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u45a0  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u4194\u52eb\u140a\u3e95\u7901", "\ud8c2\udead\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud82c\udea1\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        20, 33760, 2068449777, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u45a0  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc2f5\u6104\u9f90\u67e4\u6273\u271c\u83b3\u74c0\u5747\u7ef5\u60dc\ubc46\u17f7\u2633\u4194\u52eb\u140a\u57e5\u7901", "\ud8c2\udead\udb4e\udd42\ud8e0\udd34\u9dbe\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud9f9\udff8\udb49\udc21\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        20, 33760, 2068449777, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u45a0  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u4194\u52eb\u140a\u3e95\u7901", "\ud8c2\udead\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud82c\udea1\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud894\ude26",
        16, 5353, 2070667998, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6308,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \ua99a  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udb31\ude94", "\u0321\u6104\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u3f13\u26a7\u4194", "\uda14\udcec\ud89b\uddcb\ud9f7\udea4",
        29, 5550, 1929986147, -8464428510051338392L, 52655L, true, true, (char) 43418, (char) 51476,
        Double.longBitsToDouble(0x3fd74f16ca4a72c0L), Double.longBitsToDouble(0x3fef8a58860f5a76L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.Option:[ option: \u45a0  :: null ]\012",
        Z.run(T, 2, 4, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u2ead\uc1b9\ud319\u1591\u45b3\u2185\uabe5\u7e95\ubf1d\uc2c2\u1a4d\u2633\u5ce3\u52eb\u140a\u3e95\u7901", "\ud9d0\udc41\udada\udf7f\udb44\udcb5\u5708\udbe7\udd95\udbb5\uddf5\uc4bc\uda82\ude7b\ud82c\ude9f\ud825\ude50\ud9b2\udcb4\udaf1\udc7b\uda27\udfc3",
        44, 87048, 2068503384, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c499ce585a0L), Double.longBitsToDouble(0x3fddc231671c17acL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u893f  :: null ]\012",
        Z.run(T, 1, 1, 17, 0, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2434", "\ud8e4\udf74\ud9b5\ude09\ud805\udeb1\ud9eb\udf9d\udb4d\ude9f\udb69\udcd2",
        13, 54277, -496267650, -344799097200086833L, 90430L, false, false, (char) 35135, (char) 49703,
        Double.longBitsToDouble(0x3fd688a88665af66L), Double.longBitsToDouble(0x3fed8d0681232681L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 10, 11, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\uc92d\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u8b86\ubbaf\u17a5\u1bb7\u4194\u52eb\u140a\u3e95\u7901", "\ud8c2\udead\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d4\ude47\ud849\udca1\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        20, 33760, 2068449777, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \uc6c5  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273", "\ud81f\ude9f",
        33, 88726, -254593130, -2285399257756722820L, 67550L, true, false, (char) 50885, (char) 344,
        Double.longBitsToDouble(0x3fa1737d162aab60L), Double.longBitsToDouble(0x3fc733ca1c79cc24L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2434\012\000\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u88c8\000\000\ub97a\u7901", "\ud8c2\udead\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud82c\udea1\u0174\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        0, 33704, 2068449777, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \uf9c4  :: null ]\012",
        Z.run(T, 1, 1, 11, 12, "\ud908\udeae", "\ud168\uc31e", "\ud8b0\udf01",
        43, 24618, 1289813258, 3463029153694420420L, -48694L, false, true, (char) 63940, (char) 31467,
        Double.longBitsToDouble(0x3fc911f255177bb0L), Double.longBitsToDouble(0x3fe3f0c8258d52aeL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u618a  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\ud9f3\udc43\udb1a\udc78", "\u8110\u465a\u8148\u3c7a\u9f98\u0e2d\u2b5a\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u4194\u5bb8\u140a\u3e95\u7901", "\ud8c2\udeff\ud9e1\udf2a\udb3a\udc31\u5708\udbc6\udef9\ud805\udd61\udb38\udde7\ud8d9\udf47\ud82c\udea1\ud85d\ude02\uda76\ude13\udaf1\udc5d\udacb\udd5e",
        20, 33760, 2068449777, -4838810196147815044L, -94646L, false, true, (char) 24970, (char) 45567,
        Double.longBitsToDouble(0x3fd3fde5b79e2b72L), Double.longBitsToDouble(0x3fcd473e3be74b0cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 9, 17, 14, "\udbde\uddfd\ud8a2\udf9a", "\uc31e\u6104\u9f90\u67e4\u6273\u2f76\uc340\u0cd4\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u4194\u52eb\u13a1\u3e95\u7901", "\udafb\udfa9\ud9e1\udf2a\udad7\ude9e\u2f48\udbe7\udd76\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud82c\udea1\udaaf\udcd1\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        20, 33760, 1070205425, -6116807704452183041L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 3, 16, 4, "\udbde\uddfd\udb13\udcb1", "\uc31e\uc7d5\ua020\u67e4\u07e8\u6f83\u83b3\ucab5\u6def\u7ef5\u9d99\ubbe4\u3292\u37db\u2d9f\u7954\u140a\u3e95\u7901", "\ud9a4\udd95\ud8f9\uddad\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8e8\udf47\ud82c\udea1\uda48\ude18\ud9d7\udd91\udaf1\udd45\ud821\udf60\ud96f\udf57\udbd1\udfbb\u3135\udb9a\udfce\udb0d\udca6",
        12, 60013, 528573924, 3369811301773404719L, 37584L, false, true, (char) 51043, (char) 51570,
        Double.longBitsToDouble(0x3fd07bf3217274d0L), Double.longBitsToDouble(0x3feedc082c606628L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u04b2  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\ucba4\u6104\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u2de6\ubc62\u17f7\u2633\u4194\u52eb\u140a\u3e95\u7901", "\ud8cb\udcde\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d2\udd47\ud82c\udea1\uda45\udcd5\udad6\udc24\uda00\udd29\ud822\udc1e\udae1\udc61\ud96e\udce9\u3135\udb9a\udfce\udb0d\udca6\udb6c\udfe7\udb15\udccf\ud8a0\uddde\uda02\udfe0\u47fa\uda02\udea7\ud9ea\udcc0\uda5f\ude1e\udb10\udc3e\ud8c8\udfc4\ud923\udcca\ud934\udde4\ud8af\udcdd\ud800\uddbb\ud99b\udd42",
        31, 51348, -1999232081, -7941539155397532182L, -7896L, true, false, (char) 1202, (char) 21636,
        Double.longBitsToDouble(0x3fdb95fda6288f84L), Double.longBitsToDouble(0x3fcb32a8207b5fb8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 15, 14, 14, "\ud8b0\udf9f\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2e7e\u83b3\ud450\u379e\uc0ae\u9d99\ubbe4\u17f7\u2633\u781c\u52eb\u140a\u3e95\u7901", "\ud8c2\udead\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\udb82\udedb\uda45\udcde\ud9b0\udd91\udaf1\udd45\ud876\udcca",
        20, 33760, 2068449777, -4838810193770755158L, -54511L, true, false, (char) 17824, (char) 13620,
        Double.longBitsToDouble(0x3fcd4c57e5c185a0L), Double.longBitsToDouble(0x3fd6c7c1e7ccf9acL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u4194\u52eb\u140a\u3e95\u7901", "\ud8c2\udead\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud82c\udea1\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        20, 33760, 2068449777, 428712518371131555L, 66640L, false, false, (char) 61664, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 15, 11, 11, "\udbde\uddfd\ud8d8\udc15", "\uca58\u8e13\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u317e\u7e73\u9d99\ubbe4\u17f7\u2633\u4194\u52eb\u140a\u3e95\u7901", "\ud8c2\udead\ud9e1\udf2a\udb09\udef8\u5708\udbe7\udd95\udbb5\uddf5\ud847\ude2f\ud8d9\udf47\ud82c\udea1\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        20, 99840, 2068449764, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 13, 3, 6, "\udbde\uddfd\u32ed", "\uc59b\u6104\u9f90\u67e4\u6273\u2434\u83b3\u1cf1\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u4194\u52eb\u140a", "\ud9f7\udea4\ud8f8\udf1b\ud8c2\udead\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud9a0\udd47\ud82c\udea1\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud821\udf60\ud932\udf37\udaad\udd0d\u30fd\udb9a\udfce\udb0d\udca6\udb6c\udfe7",
        39, 39508, 784595231, 7083293803165521130L, 89804L, false, true, (char) 5610, (char) 35452,
        Double.longBitsToDouble(0x3fd3cc53c3f21682L), Double.longBitsToDouble(0x3fe0dbaa393b81f4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ua3fd\u0fd6\ubc44\u4194\u52eb\u140a\u3e95\u7901", "\udbd1\udcd2\ud801\ude36\udb71\udd53\u5739\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud87f\udcf7\uda77\udc01\udabd\ude94\udaf1\udd45\ud821\udf60\ud96f\udf57\ud96e\udce9\u3135\udb9a\udfce\udb0d\udca6\udb6c\udfe7\udb15\udccf\ud8a0\uddde\uda02\udfe0\u47fa\uda02\udea7\ud9ea\udcc0\uda5f\ude1e\ud86a\udfb4\udaf3\udc68\ud87c\udefd\udb66\udc6a\udb84\udef4\uda46\udf6f\udb07\udc77\ud9ca\udfe6\ud920\udcd1\udb33\udfda\ud9fe\ude79\ud875\uddcc\udb79\udece\udb9d\udf03\ud95d\udca7\ud9ac\udc1c\udb12\uddda\uda4a\udecd\ud942\udcce\udb22\udd66\ud97b\udec7\ud976\udce3\ud927\udf25\udbc1\udfbb",
        11, 27432, 1114250982, 3213846918346717180L, -51042L, true, false, (char) 12991, (char) 43836,
        Double.longBitsToDouble(0x3fd5609b86adcaf8L), Double.longBitsToDouble(0x3fea71660881364cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u964d  :: null ]\012",
        Z.run(T, 1, 1, 7, 0, "", "F", "",
        -5, 82584, 156, 81604378624L, -99798L, false, false, (char) 38477, (char) 47244,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3ebe000000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u1467  :: null ]\0121=org.apache.commons.cli.Option:[ option: \u1467  :: null ]\012",
        Z.run(T, 2, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\u8f64\u6104\u9f90\u67e4\u12b1\u2434\u83b3\ube78\u5747\u94e3\uafff\u2414\u17f7\u2633\u4194\u08c0\uba42\u3e95\u7901", "\ud8c2\udead\ud9e1\udf2a\udb3a\udc31",
        31, 63338, 646032305, 6193840521200817062L, 37201L, true, false, (char) 5223, (char) 49513,
        Double.longBitsToDouble(0x3fdf194faf88f694L), Double.longBitsToDouble(0x3fed55e6cd7010c1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u45a0  :: null ]\0121=org.apache.commons.cli.Option:[ option: \u45a0  :: null ]\012",
        Z.run(T, 2, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u4194\u52eb\uc0a7\u701e\u792a", "\ud8c2\udead\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud82c\udea1\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        20, 33760, 2068449777, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "\uacc3", "\000",
        43, -1000, 0, 4923211747856220170L, -99804L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e38000000000000L), Double.longBitsToDouble(0x3fc911f241177bb0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 12, 12, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u4194\ubb8b\u140a\u3e95\u7901", "\udbe6\ude2a\ud9e1\udee7\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud82c\udea1\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        20, 33760, 1951539953, 970024372741950253L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u893f  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\ucb68", "\u1808\uc31e\uc8ed\u9f90\u67e4\u6273\u2434\u83b3\u74c0\ud4c0\u7ef5\u6c99", "\udb69\udcd2",
        13, 54277, -1280405890, -5222816033009955007L, 24894L, false, false, (char) 35135, (char) 9693,
        Double.longBitsToDouble(0x3fd688a44c20cf66L), Double.longBitsToDouble(0x3fda767072464d02L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 10, 14, "\udb88\uddf2\udbde\udff8", "\uc31e\000\000\ua747\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\ucfb3\u0d4a\u2cbd\ub97a\u7901", "\ud8bf\udc3e\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\u8b7d\uda45\udcd5%\000\u8151",
        20, 33760, 2068449777, -4838810193770755158L, 76561L, false, true, (char) 19585, (char) 0,
        Double.longBitsToDouble(0x3d88400000000000L), Double.longBitsToDouble(0x3fbb1f0018000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u5118  :: null ]\0121=org.apache.commons.cli.Option:[ option: \u5118  :: null ]\012",
        Z.run(T, 2, 1, 17, 14, "\udbde\uddfd\udbde\udff8\ud850\udca9\ud9a4\udfc8\ud964\udc0c\ud9b7\ude62\udafc\udcd5", "\u2434\u83b3\u8b74", "\ud805\udeb1\ud9eb\udf9d\udb4d\ude9f",
        24, 70168, 419710277, -5499301424371805059L, 74110L, false, false, (char) 20760, (char) 32813,
        Double.longBitsToDouble(0x3fe0c6211b88a9dfL), Double.longBitsToDouble(0x3fe340817bb17bacL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u9f90\u67e4\u6273\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\u4194\u52eb\u140a\u3e95\u7901", "\ud8c2\udead\ud9e1\udf2a\udac8\uded8\u56bc\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud82c\udea1\uda45\udcd5\ud9b0\udd91\udaf1\udd45\ud821\udf60",
        20, 33760, 2068449777, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c4985c185a0L), Double.longBitsToDouble(0x3fd6c7c1e71c17acL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \u580a  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udbde\udff8\ud852\udda9\ud9f3\udd7d\ud91d\uded1\ud9b7\ude62\udb8e\ude9d\ud8b0\udf01\ud991\udd68\udaff\udf40\ud90d\ude90\ud81f\ude9f\ud8e4\udf74\ud9b5\ude09\ud805\udeb1\ud90e\udc6c\udb4d\ude9f\udb69\udcd2\udbfb\uded4\ud985\udebe\ud82b\udf5c\ud9dd\udff9\uda08\uddcf\ud93c\udfee\ud927\udc87\ud8c2\udead\ud9e1\udf2a\udb3a\udc31\u5708\udbe7\udd95\udbb5\uddf5\udb1f\ude33\ud8d9\udf47\ud82c\udea1\uda45\udcd5\uda93\udc43\uda13\udc20\ud91c\udf2a\ud96f\udf57\ud96e\udce9\ud869\udd54\ud8cd\ude7b\udb30\udca6\udb6c\udfe7\udb15\udccf\ud8a0\uddde\uda02\udfe0\u47fa\uda02\udea7\ud9ea\udcc0\uda5f\ude1e\ufc36\ud9f1\udd57\ud981\udc4e\ud9c8\udfc0\ud9f0\udedd\uda9c\udee2\ud83e\ude3a\udb6c\udc50\ud868\udc4e\ud8ae\udca7\udb9d\udce9\uda78\ude08", "\u6906\uab7d\u67f9\u34d9\u0ae7\u5aa6\u65af\u183b", "\ud817\uddb9\udb28\udde3\ud974\udfd9\ud872\udeb7\udb7a\udfe2\uda7c\uddbb\udafc\udd42\ud912\ude50\udae2\udd58\ud967\udd3d\ud9b2\uddac\udab0\udc4b\udaac\udcf7\udbf8\udf0a\udb1d\uddc3\udb2a\udeeb\udb7f\udd98\udb91\udcac\u9d36\ud9af\uddef\ud85d\udc65\udabc\ude17\ud82b\udfba\ud918\udf3e\ud841\ude39",
        56, 66379, -886883200, 8168920862632625111L, 95343L, false, true, (char) 22538, (char) 64322,
        Double.longBitsToDouble(0x3fdd8eb984c27feeL), Double.longBitsToDouble(0x3fc62761d934958cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 0, "\udbde\uddfd\udbde\udff8\ud852\udda9\ud9a4\udfc8\ud964\udc0c\ud9b7\ude62\udb8e\ude9d\ud8b0\udf01\ud991\udd68\udaff\udf40", "\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633", "\uda64\uddfe\ud9ea\udc37\ud84b\udc83\ud9f7\udea4\ud8f8\udf1b\ud8c2\udead\u141d\uda7b\udc52\u1a6c\udbe7\udd95\udbb5\uddf5\udb1f\ude33\udba1\udf4b",
        42, 62140, 1259361573, 6518423836253850639L, -70681L, false, false, (char) 37679, (char) 2180,
        Double.longBitsToDouble(0x3feb80860e4fc411L), Double.longBitsToDouble(0x3fd5ce69923ef7aeL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 1, 4, 17, 14, "\ud85e\udf8f\udb77\udedb\ud852\udda9\uda8a\udc3a\uda28\udeab\ud99c\udd62\udb8e\ude9d\ud8b0\udf01\ud852\udc75\ud883\udea7\ud90d\ude90\ud867\udfbf\ud922\udca4\ud9b5\ude09\ud805\ude7b\ud9eb\udf9d\udb4d\ude9f\uda11\udea6\ud829\ude6f\ud84e\udf52\uda64\uddfe\ud9ea\udc37\uda1d\udead\ud87a\udd84\ud82c\udce1\ud8c2\udead", "\u89a4\u6a61\u5154\u5703\ucaf0\u6236\u444a\u4627\u1b28\u8e8c\u4aa2\u5ee5\u8d25\u9dc9", "\ud91e\uddb9",
        11, 65423, -212145617, -8422841305333318859L, -42514L, true, false, (char) 50286, (char) 16391,
        Double.longBitsToDouble(0x3fd67d8c4287f7c8L), Double.longBitsToDouble(0x3fe831b5f5deed04L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 16, 2, "\uda4a\udf12\udab0\udebd\uda8a\udf68\ud8df\uddda\ud843\udd55", "\u67e4\u28aa\u5dd8\u83af\u69a4\u2d5b", "\ud9ff\udda7\udaa4\udff9",
        6, 22189, 302963897, 7940471781431478831L, -38269L, false, true, (char) 40130, (char) 62176,
        Double.longBitsToDouble(0x3fe129cb07f16b0aL), Double.longBitsToDouble(0x3fda35a76353438aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 17, 14, "\udb49\udcd9\ud8d0\udc33", "\uc31e\u6104", "\u2c7b\udbc8\udc73\udbb3\udd6b\ud9cc\udc1c\ud87a\udf7c",
        0, 41300, 456897148, -3497014522491655309L, 74110L, false, false, (char) 60729, (char) 652,
        Double.longBitsToDouble(0x3fecef63e9688addL), Double.longBitsToDouble(0x3fe996bd9bb1a0d0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 6, 6, 2, "\udbde\uddfd\ud88d\udc8f", "\u71f1\u6104\u2ead\uc1b9\u837c\ube6d\u45b3\u2185\uabe5\u7e95\ubf1d\uc2c2\u1a4d\u2633\u5ce3\u52eb\u1f9b\u3ee4\u7901", "\ud9d0\udc41\udada\udf7f\udb44\udcb5\u5708\udbe7\udd95\udbb5\uddf5\uc4bc\uda82\ude7b\ud82c\ude9f\ud825\ude50\ud9d8\ude12\udaf1\udca8\uda27\udfc3",
        44, 87048, 2068503384, -4838810193770755158L, 76561L, false, true, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fea6e956f3961cfL), Double.longBitsToDouble(0x3fddc231671c17acL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 4, 11, 6, "\udbde\uddfd\udbde\udff8", "\uc31e\u6104\u2ead\uc1b9\ud319\u1591\u45b3\u2185\uabe5\u7e95\ubf1d\uc2c2\u1a4d\u2633\u5ce3\u52eb\u140a\u91f9\u9488", "\ud9d0\udc41\udada\udf7f\udb44\udcb5\u5708\udbe7\udd95\udbb5\uddf5\uc4bc\uda82\ude7b",
        40, -945, -417627604, 6518422965144518159L, -46552L, false, true, (char) 37646, (char) 2180,
        Double.longBitsToDouble(0x3fc6e218393f1044L), Double.longBitsToDouble(0x3fd5ce69923e9902L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: null  :: null ]\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 2, 13, 5, "\udbde\uddfd\udaf8\udf25", "\u6e5d\u6193\u95ac\uc1b9", "\ud8bd\udc90",
        6, 43650, -2136621690, 7225850359317246588L, -12819L, false, false, (char) 20581, (char) 13392,
        Double.longBitsToDouble(0x3fbf6cebba0dbc20L), Double.longBitsToDouble(0x3f9e593a045cdf40L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 4, 4, 7, "\udbdd\udf90\udbde\udff8", "\u8fc0\u6104\u2ead\u4e2b\u4311\u0391\u1b3b\u64d8\u2e40\u70f5\u6e0f\uc2ab\u1a4d\u1de6\u5ce3\u399a\u442a\u3e95\u99b7", "\ud9d0\udc41\udada\udf7f\udb44\udcb5\udafa\udd7e\udba2\udec6\udbb5\uddf5\uda57\udc73\u40c5\udad6\udf40\udb7e\udf87\uda63\udc38\udaf1\udc7b\uda27\udfc3",
        15, 2494, -1169499304, -5576018381171026894L, -71920L, true, false, (char) 17824, (char) 6386,
        Double.longBitsToDouble(0x3fcd4c499c6d85a0L), Double.longBitsToDouble(0x3fddc231671c2398L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 13, 8, "\u7fd1\ud9d8\udc7d\udbdc\ude1d\uda55\ude4f\udab1\udd80\uda3f\udd17\ud846\udff9", "\u328a\u8ce0\u74c0\u501a\u29dc\u9d85\u125f\u3487\u252e\u3eda\u4851\uae12\u3e95\u7647\u52f1\ub64f\u1768\u3c9e\u0e93\u749b\u83dd", "\ud984\udef2",
        29, 89737, 500511596, -5248648275498279069L, -76382L, true, true, (char) 8096, (char) 58041,
        Double.longBitsToDouble(0x3fee565923c6bb7fL), Double.longBitsToDouble(0x3faa97ba3e5d3020L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=org.apache.commons.cli.OptionBuilder:@?\012",
        Z.run(T, 2, 4, 4, 13, "\ud8b0\udf9f\udbde\udff8", "\uc357\u6104\u24e6\uaf06\ua5d6", "\ud8a5\udd02\udb0a\udd4a",
        6, 26870, -532110980, -3497017092172764301L, 5197L, false, false, (char) 20760, (char) 35135,
        Double.longBitsToDouble(0x3fe8f39849688a88L), Double.longBitsToDouble(0x3fe996bd9ab1a0d0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: \000\000  :: null ]\012",
        Z.run(T, 1, 2, 7, 14, "\000\000", "\uc31e\u6104\u9f90\u67e4\ua25f\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633", "\000\ud9e9\udfba\ud84b\udc42\ud9f7\udea4\ud8f8\udf1b\ud8c2\udead\000\000\ud9ab\udd95\ud8fa\udf3e\000\000\u53a6",
        -5, 62140, 1259361573, 6518423832617287183L, -28380L, false, true, (char) 4289, (char) 0,
        Double.longBitsToDouble(0x3e21f4c810000000L), Double.longBitsToDouble(0x3fe1797004ea624cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: null  :: null ]\0121=org.apache.commons.cli.Option:[ option: null  :: null ]\012",
        Z.run(T, 2, 2, 2, 0, "\udbde\uddfd\udbde\udff8\ud852\udda9\ud9a4\udfc8\ud964\udc0c\ud9b7\ude62\ud93f\udc36\ud8b0\udf01\ud991\udd68\udaff\udf40", "\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633", "\uda64\uddfe\ud9e0\udd92\ud9b3\udd48\ud9f7\udea4\ud8f8\udf1b\ud8c2\udead\u141d\uda7b\udc52\u1a6c\udbe7\udd95\udbb5\uddf5\udb1f\ude33\udba1\udf4b",
        42, 62140, -997829868, 6518423350922546191L, -70681L, false, false, (char) 26408, (char) 2153,
        Double.longBitsToDouble(0x3feb80860e4fc411L), Double.longBitsToDouble(0x3fd5ce69923ef7aeL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 0, "\000\000\000\ud9a4\udf45\ud964\udc0c\ud9b7\ude62\udb8e\ude9d\ud8b0\udf01\ud991\udd68\udaff\udf40", "\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633", "\uda64\uddfe\ud9ea\udc37\ud84b\udc83\ud9f7\udea4\ud8f8\udf1b\ud8bf\udc3e\u141d\uda7b\udc52\udbff\udd9f\udbe7\udd95\udbb5\uddf5\udb1f\ude33\udba1\udf4b",
        42, 62140, 1259361573, 6518423834525797391L, -70681L, false, false, (char) 37679, (char) 2180,
        Double.longBitsToDouble(0x3feb80860e4fc411L), Double.longBitsToDouble(0x3fd5ce6990000000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 0, "\000\000\000\000\ud964\udc0c\ud97a\udc63\000\000\ud991\udd55\udaff\udf40", "\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633", "\uda64\uddfe\ud9ea\udc37\ud84b\udc83\ud9f7\udea4\ud8f8\udf1b\000\000\uda7b\udc52\udbff\udd9f\udbe7\udd95\udbb5\uddf5\udb1f\ude33\udba1\udf4b",
        42, 62140, 1259361573, 6518423834525797391L, -70681L, false, false, (char) 37679, (char) 2180,
        Double.longBitsToDouble(0x3feb80860e4fc411L), Double.longBitsToDouble(0x3fd5ce6990000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\uddfd\udbde\udff8", "\uc31e\u60c3\u36b8\u67e4\u58d5\u24b7\u83b3\u74c0\uc534\u895d\u2ede\ubbe4\u17f7\u2633\u4194\u52eb\u140a\ucda6\ubc09", "\ud83c\uddda\ud9e1\udf2a\udb3a\udc31",
        6, 63338, 645996558, 6193840521200817062L, -6801L, true, false, (char) 13047, (char) 49513,
        Double.longBitsToDouble(0x3fdf194fab44f694L), Double.longBitsToDouble(0x3fe0444627701098L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: @  :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\ude19\udbdf\udca2", "\u3691\u3291\u9809\u67e4\u6273\u2434\u83b3\u74c0\ub757\u7ef5\u9d99\u22b5\u38c6\u772d\u41bf\u52eb\u36d4\u7bd0\u792c", "\ud95a\udcb6\ud87e\udcfe\udb5b\udc3b\u5708\udadc\udebb\udbb5\uddf5\udb1f\ude33\ud925\udc0d\ud82c\udea1\uda45\udcd5\ud8a2\udf93\udaf1\udd45\ud9a6\udc82",
        22, 33760, 1615464945, 6906843703340518314L, 76561L, false, true, (char) 64, (char) 6309,
        Double.longBitsToDouble(0x3fcd4c4985c2ada0L), Double.longBitsToDouble(0x3f53208ac11d7800L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.cli.OptionBuilder:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 0, "\000\000\000\000\000\000\000\000\ud991\udd55\udaff\udf40", "\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633", "\uda64\uddfe\ud9ea\udc37\ud84b\udc83\ud9f7\udea4\ud8f8\udf1b\000\000\uda7b\udc52\udbff\udd9f\udbe7\udd95\udbb5\uddf5\udb1f\ude33\udba1\udf4b",
        42, 62140, 1259339813, 6518423834525797391L, -70681L, false, false, (char) 37679, (char) 2180,
        Double.longBitsToDouble(0x3feb80860e4fc411L), Double.longBitsToDouble(0x3fd5ce6990000000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option: @  :: null ]\0121=org.apache.commons.cli.Option:[ option: @  :: null ]\012",
        Z.run(T, 2, 1, 17, 14, "\udbde\ude19\udbdf\udca2", "\u3691\ucf72\u127b\u3e53\u62ef\u2434\u83b3\u74c0\ub757\u7ef5\u9d99\u4856\u3879\u772d\ucace\uca72\u36d4\u7bd0\u792c", "\ud828\udde7\ud888\udd28\udb5b\udc3b\u5708\udadc\udebb\udbb5\uddf5\udb1f\ude33\udbc5\ude52\ud82c\udea1\uda45\udcd5\ud8a2\udf93\udaf1\udd45\ud9a6\udc82",
        22, 33760, 1615464945, 6906843703340518314L, 76561L, false, true, (char) 64, (char) 6309,
        Double.longBitsToDouble(0x3fcd4c4985c2ada0L), Double.longBitsToDouble(0x3f53208ac0097800L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 10, 14, "\udb75\udcf2\udbde\udff8", "\uc31e\000\u54ae\u647c\u62ea\u2434\u83b3\u74c0\u5747\u7ef5\u9d99\ubbe4\u17f7\u2633\ucfb3\u0d4a\u64f5\ub9d4\u288a", "\uda1d\udd12\ud9e1\udf2a\udb3a\udc31\udac2\ude46\ud91f\udf57\udbc5\udf5a\udb07\ude96\ud8d9\udf47\u8b7d\uda45\udcd5%\000\u8151\ud96f\udf57\udad7\udd70\u3135\udb9a\udfce\udb0d\udca6\udb6c\udfe7\udb15\udccf\ud8a0\uddde\000\000\ud971\uddb7\udadf\udf4el\ud85f\udeb8\udaf5\uddd5\uda8c\udcab\ud8d1\ude99\ud939\udcf2\ud955\ude15\ud9ca\udd3d\ud842\ude2d\udae0\uddf1\udaba\udd32\ud9c6\udf74\ud94e\udcca\ud88f\udc4f\ud94f\udf83\udbeb\udf6e\ud97d\udc77\udb06\udc9b\ud80c\uddc5\ud846\udce9\ud901\ude06\ud9a3\udd44\udb13\udd67\uda7e\ude50\uda0b\udce7\ud8d3\ude47\udbbf\udd6c\uda3b\udedc\ud8cd\ude0c\udb81\ude43\ud841\ude7d\ud947\udea9\udaf5\udd53\udb6c\ude50\ud816\udd91\ud9a7\udce6\uda34\udc32\uda2c\udd8b\udafc\udeef\ud8dc\udc8b\ud8f6\uddeb\u9c15\uda22\uddf2\uda0c\udfb8\udb04\udd32\uda6a\udd5a\udaaf\udea9\ud832\ude10\ud96b\udfae\udb68\uddb8\ud9e3\udf9d\ud82f\udd79\ud814\udea8\ud8a1\ude2f\udafd\udf44\udaba\udd81\ud899\ude36\udbd2\udf28\ud948\ude98\u2962\uda69\ude59\udaca\udfb2\ud919\udd69\ud9d4\udec4\ud824\udf64\uda5c\udddd\uda56\udd7a\ud97b\udd9e\udbb8\ude95\ud9bd\udff9\uda77\udeb2\ud88c\udd76\ud9cf\ude5f\ud905\udd92\ud91f\udefe\uda72\udc84\ud84f\udebe\u6d18\ud827\udcb9\udbe9\udfcc\udb3a\udda2\ud8b3\udd6b\udba6\udde5",
        -5, 95190, -41353980, 6664477492692306295L, 42873L, false, true, (char) 25840, (char) 22286,
        Double.longBitsToDouble(0x3feaa93938b20cf5L), Double.longBitsToDouble(0x3fed13659e9b38edL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option:    :: null ]\012",
        Z.run(T, 1, 1, 17, 14, "\udbde\ude19\udbdf\udca2", "\u3691\u3291\u9809\u67e4\u6273\u2434\u83b3\ua2ad\ub757\u7ef5\u9d99\u22b5\u38c6\u772d\u41bf\u52eb\u36d4\u7bd0\u792c", "\ud95a\udcb6\ud87e\udcfe\udb5b\udc3b\u5708\udadc\udebb\udbb5\uddf5\udb1f\ude33\ud925\udc0d\ud82c\udea1\uda45\udcd5\ud8a2\udf93\udaf1\udd45\ud9a6\udc82",
        22, 33760, 1615464945, 6906843703340518314L, 74093L, false, false, (char) 32, (char) 6309,
        Double.longBitsToDouble(0x3fcf8c49848a1dc4L), Double.longBitsToDouble(0x3f53208ac11d7800L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Option:[ option:    :: null ]\0121=org.apache.commons.cli.Option:[ option:    :: null ]\012",
        Z.run(T, 2, 1, 17, 14, "\udbde\ude19\udbdf\udca2", "\u3691\u3291\u9809\u67e4\u6273\u2434\u83b3\ua2ad\ub757\u7ef5\u9d99\u22b5\u38c6\u762d\u41bf\u52eb\u36d4\u7bd0\u792c", "\ud95a\udcb6\ud87e\udcfe\udb3e\udc4c\u3eac\udadc\udebb\udbb5\uddf5\udb1f\ude33\ud925\udc0d\ud82c\udea1\uda45\udcd5\ud8a2\udf93\udaf1\udd45\ud9a6\udc82",
        22, 33760, 1615464945, 6906843703340518314L, 74093L, false, false, (char) 32, (char) 6309,
        Double.longBitsToDouble(0x3fcf8c49848a1dc4L), Double.longBitsToDouble(0x3f53208ac11d7800L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.OptionBuilder|create||static",
    "M|org.apache.commons.cli.OptionBuilder|create|char|static",
    "M|org.apache.commons.cli.OptionBuilder|create|java.lang.String|static",
    "M|org.apache.commons.cli.OptionBuilder|hasArg||static",
    "M|org.apache.commons.cli.OptionBuilder|hasArg|boolean|static",
    "M|org.apache.commons.cli.OptionBuilder|hasArgs||static",
    "M|org.apache.commons.cli.OptionBuilder|hasArgs|int|static",
    "M|org.apache.commons.cli.OptionBuilder|hasOptionalArg||static",
    "M|org.apache.commons.cli.OptionBuilder|hasOptionalArgs||static",
    "M|org.apache.commons.cli.OptionBuilder|hasOptionalArgs|int|static",
    "M|org.apache.commons.cli.OptionBuilder|isRequired||static",
    "M|org.apache.commons.cli.OptionBuilder|isRequired|boolean|static",
    "M|org.apache.commons.cli.OptionBuilder|reset||static",
    "M|org.apache.commons.cli.OptionBuilder|withArgName|java.lang.String|static",
    "M|org.apache.commons.cli.OptionBuilder|withDescription|java.lang.String|static",
    "M|org.apache.commons.cli.OptionBuilder|withLongOpt|java.lang.String|static",
    "M|org.apache.commons.cli.OptionBuilder|create||static",
    "M|org.apache.commons.cli.OptionBuilder|create|char|static",
    "M|org.apache.commons.cli.OptionBuilder|create|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
