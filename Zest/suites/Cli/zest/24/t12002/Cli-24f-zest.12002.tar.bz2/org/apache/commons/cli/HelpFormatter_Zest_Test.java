package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u88a5\u4199\u068e", "\udbf9\ude18",
        57, 50, -1043517028, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fc7a3331c2ac024L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\u8a7b\udaa4\udd35\ud8b8\udc58\ud8c1\udcd5\ud99b\ude8b\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u88a5\u4199\ub679", "\udbf9\ude18\udb88\udcd2\ud827\udf0e\uda77\uddf1\ud939\udd89\ud9fb\udcc1\uc753\ud8f0\udcd1\udbb9\udfd7",
        0, 47420, -1447649762, 1844283063212284093L, -81958L, true, false, (char) 4827, (char) 21956,
        Double.longBitsToDouble(0x3fe7179b09dbde50L), Double.longBitsToDouble(0x3fe4847dcca76157L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 5, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\uda18\udc90\udad7\udecc\uda13\udfa8\udb11\udec9\ud91f\udef0\ud82d\udce6\uda1c\udf88\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b\ud9b8\udd5b\udb8f\udef7\ud804\ude59\udaa2\udcf1\ud8e5\udd00\ud91a\udf46\udb48\udd12\ud8b7\udfbf\uda9e\udfc8", "\u11a6\uc659\uce7f\u7a44\u88a5\u4a23\ub9a6\u39eb\ub6f7\u9d07\u9134\u8320\u27e4", "\ud88c\ude3f\ud93a\udce0\udbba\udc59",
        0, 47420, -1447649762, 1844283063212284093L, 77750L, false, true, (char) 29030, (char) 18696,
        Double.longBitsToDouble(0x3fc8a43b54aecab4L), Double.longBitsToDouble(0x3fd21614898c082cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 4, "\ud981\ude26\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\ud9c5\udea5\uda70\udcfd\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u883a\u4199\u068e", "\udbf9\ude18",
        57, 50, -1043517028, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fdec0798f688fdeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 6, "\ud827\udcb8\uda9f\ude2c\ud9c0\udd21\ud8f6\udc59", "\u884f\u0907\uafec\u6a28\u7a7f\u5e15\ua8ba", "\udafa\udcd8\ud90b\ude2e\ud913\udcc9\ud998\udc01\udb26\udce3\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\udbcd\udca1\uda1c\udea5",
        17, 97367, 981052227, 4890150604786218923L, 61124L, true, false, (char) 53845, (char) 29275,
        Double.longBitsToDouble(0x3fd1416bcbd02404L), Double.longBitsToDouble(0x3fe2918c099c0c77L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "\ud827\udcb8", "\u4684\u4f37\u49a1\u884f\u0907\u414a\u6951\u40e9\u5e15\ua8ba\u81a3\u2de4", "\ud80b\udfa9\ud87e\udf17\udae4\udf37\ud804\ude58\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\uda1c\udea5",
        17, 53591, -1082938557, 4890150604786218923L, -4412L, true, false, (char) 19228, (char) 10890,
        Double.longBitsToDouble(0x3fc9e7179ba04a48L), Double.longBitsToDouble(0x3fe2918c099c0c77L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 6, 5, 11, "\ud831\udc0d\ud978\ude59\u6c10\uda0b\udced\ud953\udf96\ud96f\udd6e\udad7\udf24\udb65\udffe\udab5\udccf\ud91f\udef0\ud816\udd7b\udaa4\udd35\udb6a\udeab\ud824\udd0f", "\u5b54\u9b83\u5a97\u10e7\ucade\u4d44\ud742\ub95b\u4623\u6d45\u2dc9\u63ad\u2979\u64f6\u2091\uce7f\u76e0", "\ud908\udf6c\uda47\udc71\udbc7\udc67\udbf9\ude18\udb28\udef8\ud889\udd0c\ud9e5\ude88\uda77\ude88\ud926\udd38\ud8ad\udd93",
        44, 42324, 484300835, 3038918797625302558L, 63182L, false, false, (char) 25427, (char) 13189,
        Double.longBitsToDouble(0x3fb5ca5263da0f28L), Double.longBitsToDouble(0x3fdf10d61cdf8704L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10", "\u3114w\000\u4084", "\ud89b\udc0d\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b",
        29, 54426, 0, 0L, 30048L, true, false, (char) 0, (char) 31866,
        Double.longBitsToDouble(0x3fda5ae0bfee4808L), Double.longBitsToDouble(0x3fea1a07be113a79L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "\ud823\uded0\uda9f\ude2c\u6c10", "\u49ca\u884f\u0907\u414a", "\ud9ca\udc04",
        -5, -1000, 0, -5575063814525946686L, 31009L, false, true, (char) 57142, (char) 30658,
        Double.longBitsToDouble(0x3f3bd14000000000L), Double.longBitsToDouble(0x3e12600000000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 4, 9, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b", "\u81a3\u3a46\u5060\u5592", "\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\ud9ea\ude44\ud987\ude6b\ud83a\udf4d\ud891\udeb5\udb54\ude10\udbb5\uddce\ud878\udf01\ud851\udcf2\ud84a\udf28",
        47, 96869, -1572475994, 3567400291533305426L, -31595L, true, true, (char) 48994, (char) 27990,
        Double.longBitsToDouble(0x3f9cf120605fc300L), Double.longBitsToDouble(0x3fc1838ef878a8b0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\ud9a1\udcd1\uda1c\udedc\ud953\udfc4\ud83a\udfcb\ud891\udeb5\udb54\ude10\udbb5\uddce\ud878\udf01\ud851\udcf2", "\u70cb\u1300\u0895\ub518\u27e4\u1f08\uc954\ucfb8\ua8ec\u466d\u6a59\ud287\u6fd9\u9c02\u49f7\u7b67\u705e\u5753\u0ba1\u551e\u0a0a\u3e27\u6876\u3852\u2446\u6b97\u8dcb\u8d24\ucb19\u8983\ud318\u768b\u8e8b\u9d95\u8d47\u49a4\u4a6b\u0ab1\u04d1\uae21\uc5d3\u56c7", "\ud803\udc52\udb4d\udfed\udb0a\udc7c",
        44, 23575, -877871249, 3680690726673933131L, -72829L, false, false, (char) 15186, (char) 60458,
        Double.longBitsToDouble(0x3fdc9c1759eba51eL), Double.longBitsToDouble(0x3fee65252d8adf2bL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 12, "\ud827\udcb8\ud90b\ude22\u6c10\ud9c9\udd86\ud9d7\udf02\ud8c4\udc37\udad7\udecc\udb65\udffe\udb11\udec9\ud987\udda4\ua625\udaa4\udd76\ud8b8\udc58\uda3f\ude14\udbd7\ude2a\ud9a2\udea7\ud9fe\udf90\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\uda3f\udca8\ud9ef\udd68\ud830\udfd9\udaf8\udca0\ud8b7\udfbf\udab2\uddac", "\ub716\u2091\uce7f\u7a44\u88a5\u5627\u068e", "\ud8ec\uddb1",
        35, 18746, 168064930, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f1516002a9b6L), Double.longBitsToDouble(0x3fc7a3331ed2c024L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\ud94d\uddfa\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udcd4\ud97a\udf5c\udbc3\udfec\uda68\udfec\ud80a\udc04\uda08\udfd2\udbe7\udd09\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\u64f6\u2091\u057a\000\000\000\u0897 |a0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\ud94d\uddfa\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udcd4\ud97a\udf5c\udbc3\udfec\uda68\udfec\ud80a\udc04\uda08\udfd2\udbe7\udd09\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\u64f6\u2091\u057a\000\000\000\u0897 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 0, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\ud94d\uddfa\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udcd4\ud97a\udf5c\udbc3\udfec\uda68\udfec\ud80a\udc04\uda08\udfd2\udbe7\udd09\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\u057a\000\000\000\u0897", "\udbf9\ude18",
        57, -1000, -1043529728, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fc7a3331c000024L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "", "\u69ef\u4684\u77f2\u49ca\u884f\u0907\u414a\u3318\u7344\u5e15\ua8ba\u81a3\u3a46\u3e22\000\000\u7200\u276b\u1d88\000\u6000\ub95b", "\000",
        -3, 78797, 1089945591, 4213587231771545105L, -18333L, false, false, (char) 9340, (char) 53845,
        Double.longBitsToDouble(0x3fd000021a020178L), Double.longBitsToDouble(0x3fde8128fca46302L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 0, 13, "\ud9eb\udd57\udab6\uddd6\udba9\udeb6\ud9c9\udd14\ud9d7\udf02\ud9b0\udd8e\ud9c1\ude7c\udb70\udcce\udb27\udf4a\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98b\udda2\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbb0\uddec\ud804\ude59\udaa2\udd7b\udb10\uddec\udb67\udd60\uda30\udc3e\uda9a\udc1c\uda9e\udfc8", "\u6436\u2091\uce7f\u7a44\u88a5\u6e0b\u068e\ua6fb\u90cb\u058e\u0895\ub518\u27e4\ubada\uc954\ucfb8\uad64\u36d7\u6a59", "\ud9cb\udf2b\uda79\udc06\uda2f\udfdc\ud818\udf96\ud809\udd1d\ud826\udd65\udb9f\udcc3\ud8cf\udd61",
        8, 40819, -518527182, -2077686151715866859L, -73856L, true, false, (char) 20467, (char) 16442,
        Double.longBitsToDouble(0x3fec70d53afd2b82L), Double.longBitsToDouble(0x3fcb4716b6ae1524L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\u0de8\ua7ff |a0=java.lang.StringBuffer:\u0de8\ua7ff |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 0, 12, "\u0de8", "\ua7ff", "\000\000\000\000\ud984\udf03\000\000",
        26, 54653, -1298045597, -6410028813164464233L, -70918L, true, true, (char) 30658, (char) 3656,
        Double.longBitsToDouble(0x3fef428d0c8e6679L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud8b2\udcda\ud9ca\udd6b\ud9b0\udd8e\udad7\udecc\udb65\udffe\udbf8\udfee\udaac\udf6c\ud88a\uddfa\uda96\ude66\ud8b8\udc39\udb43\udcf7\ud98e\udedf\udafa\udcd3\udbff\udf83\ud9c0\udd70\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\udbce\uddb6\udb63\ude30\ud846\udda0\udbd5\udef9\uda07\udf91", "\u64f6\u2091\u8763\ua69b\u8808\u4199", "\udbd0\udce4\udbf9\ude18\udb88\udcd2\ud827\udf0e\uda77\uddf1\ud939\udd89\ud887\udf19\ud912\udf31\ud8f0\udcc2\udbb9\udfd7\ud9de\uddd6\ud8d4\udf08\ud8bc\udd08\ud853\udf2f\uda79\udc06\ua0e7\udbe3\udd7d\ud9ad\udd63\ud987\udf63\uda48\udccf\ud94a\udf0f\ud84c\udd50\udad6\udc17\udbed\udfab\udbb1\udc1b\ud9ed\udd0e\ud9e7\udda1\ud866\udee5\udb74\udf54\ud9b4\udd27\ua5a3\udb6f\udf9b\ud94c\udc58\uda91\udfe8\u1d38\udba0\udc44\uda80\ude27\ud855\udfe7\udac4\udf24\ud9c0\udfab\uda02\udc91\ud808\udd58",
        45, 83109, -626816303, -3011154893920210239L, -72953L, false, true, (char) 43340, (char) 47184,
        Double.longBitsToDouble(0x3fbaa53df0929198L), Double.longBitsToDouble(0x3fe2993969a50f4eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "", "\ud3db", "\ud9b0\udd8e\udad7\udecc\udb65\udffe\udab8\udcfc",
        31, -1000, 0, -1963326378L, 70653L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f31400000000000L), Double.longBitsToDouble(0x3fe3180007036f45L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\ud89e\udfb0\udbba\uded4\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udeb8\ud91f\udef0\ud816\udd7b\ud8ab\udc77\ud881\udc47\ud9f5\udd70\udb5a\udd88\udafa\udcd3\uda4a\udd48\uda7a\udd58\ud97a\udf5c\udbc3\udfec\ud804\ude59\ud937\udd23\uda08\udfd2\udbe7\uddf1\ud946\udcb0\udbad\udf13\udbef\udf51\u64f6\u2091\u3f80\u3a2a\u88a5\u4199\u068e |a0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\ud89e\udfb0\udbba\uded4\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udeb8\ud91f\udef0\ud816\udd7b\ud8ab\udc77\ud881\udc47\ud9f5\udd70\udb5a\udd88\udafa\udcd3\uda4a\udd48\uda7a\udd58\ud97a\udf5c\udbc3\udfec\ud804\ude59\ud937\udd23\uda08\udfd2\udbe7\uddf1\ud946\udcb0\udbad\udf13\udbef\udf51\u64f6\u2091\u3f80\u3a2a\u88a5\u4199\u068e |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 12, "\ud827\udcb8\uda9f\ude2c\ud89e\udfb0\udbba\uded4\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udeb8\ud91f\udef0\ud816\udd7b\ud8ab\udc77\ud881\udc47\ud9f5\udd70\udb5a\udd88\udafa\udcd3\uda4a\udd48\uda7a\udd58\ud97a\udf5c\udbc3\udfec\ud804\ude59\ud937\udd23\uda08\udfd2\udbe7\uddf1\ud946\udcb0\udbad\udf13\udbef\udf51", "\u64f6\u2091\u3f80\u3a2a\u88a5\u4199\u068e", "\udbf9\ude18",
        57, 50, -1043517028, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15160e4a9b6L), Double.longBitsToDouble(0x3fc7af4dfc2ac024L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 12, "\ud827\udcb8\ud991\udd3d\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u88a5\u4199\u068e", "\udbf9\ude18",
        57, 50, -1043517028, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fc7a3331c2ac024L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd30\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\ud806\ude0b\ud97a\udf46\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u88a5\u4199\u068e", "\udbf9\ude18",
        57, 50, -1043517028, -8872666536698390241L, -31048L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fc7a3331c2ac024L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 12, "\ud827\udcb8\ud9ef\udd25\u6c10\ud9c9\udd86\ud9d7\udf02\ud993\udfc1\udb81\uddb8\ud9fa\udeeb\udb77\udcf2\ud9ee\uddbd\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud935\udfef\ud98d\udcaa\ud9ad\udeb1\udbff\udf21\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\ud819\udcae\udb72\udd4f\ud865\ude52\udaf1\udf97\ud8b7\udfbf\ud829\udd27", "\u64f6\u2091\uce7f\u7a44\u88a5\u617f\u068e\ua6fb\u5276", "\ud9b0\udc12\udbca\udc8a\ud939\udd89\ud9fb\udcc1\uc753\ud8f0\udcd1\udbb9\udfd7\ud9de\uddd6\ud8d4\udf08\ud85b\udea7",
        16, 91035, 1540459267, 7837250552968611206L, 99695L, false, false, (char) 299, (char) 36377,
        Double.longBitsToDouble(0x3fd67c29b301b390L), Double.longBitsToDouble(0x3fe87df926a913dcL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 2, 0, "\ud827\udcb8\uda9f\ude2c\u6c10", "\u31c9\u884f\u0907\u414a", "\udaa4\udd35\ud8b8\udc58\u0456\000\udafa\udc70\udbff\udf83\udad7\udf9b",
        -5, 16194, 1834972135, 8017826133290622723L, 30190L, true, false, (char) 3971, (char) 31866,
        Double.longBitsToDouble(0x3fda5ae0b1ee4808L), Double.longBitsToDouble(0x3fea1a0006113a79L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\ud9c3\ude63\ud91f\udef0\ud816\udd7b\ud8ba\udfa0\udb60\uddba\ud8e6\uddc7\ud98d\udca2\udafa\udcd3\udbff\udf83\udaa8\udeba\ud991\udfbc\udbb7\udfa8\ud804\ude59\ud8eb\udd17\ud8d1\udfb0\ud0ea\ud81f\udcb7\udb28\udf69\ud97a\udd78", "\u64f6\u2091\uce7f\u7a44\u88a5\u2df7\u063e", "\udbf9\ude18\udb88\udcd2\ud827\udf0e\uda77\uddf1\ud939\udd89\ud9fb\udcc1\uc753\ud8f0\udcd1\udaa9\ude4f\ud9ea\udca4\udbc4\udf1b\ud8bc\udd08\ud8ff\udc06\udbac\udd4d\udae4\udfc4\ud9c5\udde2\udb2e\udf04\uda2f\udcec\ud9f8\udcbd\udb0d\uddcc\udb34\udd58\ud8b1\udf01\uda83\uddb0",
        43, 24505, 1517217674, 3475524505961837186L, 8268L, false, false, (char) 24363, (char) 60065,
        Double.longBitsToDouble(0x3fe18eb2f9bf1cceL), Double.longBitsToDouble(0x3fc39c811065ff88L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 12, "\ud869\udd98\ud8ff\udd96\u6c10\uda0b\udc67\udb32\udcf5\uda12\uddb6\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\udbf9\udf8c\ud881\udc13", "\uc919\u1ecb\u5b54\u59cc\ubc1e\u35fa\ucba8\u8e43\u85af\u7f8b\u4623\u0f7a\u91e4\u3e57\ud054", "\ud936\udd09\udb6e\udd2a\ud892\udc91",
        33, 22303, -1407104413, 4088280606600799489L, 33941L, true, true, (char) 8341, (char) 53442,
        Double.longBitsToDouble(0x3fd5cf8fe04744ceL), Double.longBitsToDouble(0x3fc1839bb878a8b0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "\ud827\udcb8", "\ua6f2", "\udad7\udecc",
        46, 76334, 676620, -1929243719601487836L, -100000L, false, false, (char) 0, (char) 62657,
        Double.longBitsToDouble(0x3fecbd3858000050L), Double.longBitsToDouble(0x3e1ced69e0000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "", "", "\ud9d7\udf02",
        51, 59016, -699645324, -8541026363773398260L, 29962L, true, true, (char) 0, (char) 42690,
        Double.longBitsToDouble(0x3fecbd385f3f9750L), Double.longBitsToDouble(0x3fd9a45d27ced69eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:                                                          |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u8aae\u0948\u4ac9\u7a44\u88a5\u4199\u068e", "\udbf9\ude18",
        57, 50, -1043517028, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fc7a3331c2ac024L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 12, 0, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\uda09\uddcd\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud9e5\uddcf\udb92\udea3\ud98d\udca2\udafa\udcd3\udbd1\ude4c\uda76\udd6b\ud97a\udf5c\ud8a9\udcbe\ud8c5\udfab\udaa2\udcf1\uda08\udfd2\udbe7\udd5b\ud869\udca2\ud8cf\udcbf\uda5e\udd4b", "\u64f6\u2091\uce7f\u0a95\u88a5\u4199\u068e", "\uda77\udd6b",
        10, 13158, 1741757437, -8872666608096650977L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f151644aa9b6L), Double.longBitsToDouble(0x3fc7a3331c2ac024L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                              |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 3, 12, "\ud806\udc69\uda9f\ude9c\u6c10\ud9c9\udd86\ud9d7\udf02", "\u0907\u414a\u6951\u7353\u5e15\ua8ba\u81a3\u6e96\u11b0", "\ud97a\udf5c\udbc3\udfec\udb1a\udffc\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\uda1c\udea5\ud97e\udc79\ud868\udfba\ud86d\udee5\ud80b\udcec",
        29, 72432, 665160348, -8650573932924817565L, 33941L, true, true, (char) 8341, (char) 53442,
        Double.longBitsToDouble(0x3fd5cf8fe04744ceL), Double.longBitsToDouble(0x3fc1839bb878a8b0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 14, 6, "\ud827\udcb8\udab4\udd3a\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\uaeba\u4199\u068e", "\udbf9\ude18",
        13, 50, -1043517028, -8872666539377174241L, 28623L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fc7a3331c2ac024L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 5, 15, 9, "\ud827\udcb8\uda9f\ude2c\u6c10", "\u0c75\u884f\u0907\u414a\u035d\u7907\ubf90\ua8ba\u2eb5\u3a46\ud0bb\ud38d\u4e41\u041d\uc121\u2407\u8e43\ud7c2\ub95b\u4623\u28d4\u2e21\u3e57\ud054\u962f\u2058\uce7f\u7a44\u88a5\u7dea\ub542\u619c\u70cb\u1300\u0895\ub518\u27e4", "\uc753\ud8f0\udcd1\udbb9\udfd7",
        0, 47420, -1447649762, 1844283063212284093L, -59816L, false, true, (char) 62696, (char) 37088,
        Double.longBitsToDouble(0x3fb450b639c21000L), Double.longBitsToDouble(0x3fd0118b7a52c664L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 3, 15, "\ud827\udcb8\ud81c\udf2a\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udbbb\udeff\udaa9\ude2b\u9199\ud91f\udef0\ud80c\uded6\uda95\udf37\ud8b9\udf7f\ud9f5\udd70\ud98d\udca2\udaf6\udcda\udbff\udecd\uda76\udd6b\ud8d0\udee1\udbc2\ude6a\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\uc8c4\u38b5\u4255\ud663\u8802\u4199\u068e", "\udbf9\ude18\udb88\udcd2\ud827\udf0e\uda77\uddf1\ud939\udd89",
        15, 53351, -117569221, -6744407227691575261L, 51247L, true, false, (char) 3067, (char) 51068,
        Double.longBitsToDouble(0x3febe68412605964L), Double.longBitsToDouble(0x3fe031dc2fabe4c4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud857\uddf1\000\000\000\000\000\udb98\udd4b\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd11Y\000\000\udafa\udc70\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59c\u9f00\000\000\000\000\u00f7\u2bd3\000\000\u9fa7\u4199\u068e |a0=java.lang.StringBuffer:\ud857\uddf1\000\000\000\000\000\udb98\udd4b\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd11Y\000\000\udafa\udc70\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59c\u9f00\000\000\000\000\u00f7\u2bd3\000\000\u9fa7\u4199\u068e |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\ud857\uddf1\000\000\000\000\000\udb98\udd4b\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd11Y\000\000\udafa\udc70\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59c\u9f00\000\000\000\000\u00f7\u2bd3\000\000\u9fa7\u4199\u068e |a0=java.lang.StringBuffer:\ud857\uddf1\000\000\000\000\000\udb98\udd4b\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd11Y\000\000\udafa\udc70\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59c\u9f00\000\000\000\000\u00f7\u2bd3\000\000\u9fa7\u4199\u068e |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud857\uddf1\000\000\000\000\000\udb98\udd4b\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd11Y\000\000\udafa\udc70\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59c\u9f00\000\000\000\000", "\u00f7\u2bd3\000\000\u9fa7\u4199\u068e", "\udbf9\ude18",
        32, -1000, -1043517184, -8872666539377174241L, -100000L, false, false, (char) 55330, (char) 34153,
        Double.longBitsToDouble(0x3e46b6a400000000L), Double.longBitsToDouble(0x3fc7a3331c2ac000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\ud8ae\udd22\udb0e\udcab\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud9d4\udd5e\udaa2\udcf1\u99cd\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\ud83a\udea6", "\u64f6\u2091\uce7f\u7a44\u88a5\u4199\u5fbd\ubf37\ucfbc\u4f25\u7b57\ub518\u637a\u6773\uc954\u4f82\ua8ec\u466d\u6a59\ud287\u0497\u9c02\u49f7\ua9c2\u9bb8\ubd44\u9803\u32f3\u187a\u9d11\ud5e7\u20ff\u8b8e\u650a\u31ce\u92e0\u7612\ud3e2\u1384\u60da\u054c\u5846\u3da8\ub0cf\u0b75\u1f79\u495c\ua6f6\u3b15\ud590\u1f35\ubbcc\u72e1\u80af\u9b5c\ucfda\u6b3b\u935b\u44b5\u04c6\u70db\u0146\u549e\u1f92", "\ud84a\udeca\uda16\udfd2\ud8bc\udcbc",
        45, 52478, 1950180132, 4925638498409328654L, 44746L, false, false, (char) 46073, (char) 19208,
        Double.longBitsToDouble(0x3fd4d53e9d9d4274L), Double.longBitsToDouble(0x3fb8ada91908c360L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 12, "\ud9cc\udc0c\udaaa\udddb\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\u8a7b\udaa4\udd35\ud8b8\udc58\ud8c1\udcd5\ud99b\ude8b\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\ud8fe\ude35\uda47\udc41\udbe7\uddf1\ud869\udca2\ud8fb\ude42\ud997\udeb0", "\u64f6\u2091\uce7f\u7a44\u88a5\u3030\ub679", "\udbf9\ude18\udb88\udcd2\ud827\udf0e\ud970\udf0e\ud88d\ude53\ud9fb\udcc9\uc753\ud8f0\udcd1\udbb9\udfd7",
        0, 47420, -1447649762, 1844283063212284093L, -81958L, true, false, (char) 4827, (char) 21956,
        Double.longBitsToDouble(0x3fe7179b09dbde50L), Double.longBitsToDouble(0x3fe4847dcca76157L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\u8a7b\udaa4\udd35\ud8b8\udc58\ud8c1\udcd5\ud99b\ude8b\udafa\udcd3\udbff\udec3\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud9bc\ude96\udbaf\udd4a\uda09\udc97\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u88a5\u9bd7\ub6a7", "\udbf9\ude18\udb88\udcd2\ud827\udf0e\uda77\uddf1\ud939\udd89\ud9fb\udcc1\uc753\ud8f0\udcd1\udbb9\udfd7",
        0, 47420, -1447649762, 1844283063212284093L, -68912L, true, false, (char) 39821, (char) 1098,
        Double.longBitsToDouble(0x3fd7aa729ea44c46L), Double.longBitsToDouble(0x3fe8e429e95a075dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 4, "\ud827\udcb8\uda9f\ude2c\udbea\uded6\ud9c9\udd84\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\ud9e1\udef1\ud991\udc63\ud804\ude7b\udaa4\udd35\ud8b8\udc58\ud8c1\udcd5\ufc3d\uda6b\udf1a\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud951\udcd9\ud8ba\udda9\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u63f5\u41e4\u1f0b", "\udbf9\ude18\udb88\udcd2\ud827\udf0e\udaaf\udfcd\ud864\udef5\ud9fb\udcc1\uc753\ud8f0\udcd1\udbb9\udfd7",
        0, 47420, 44632350, 1844283239305943229L, -16422L, true, false, (char) 45402, (char) 21956,
        Double.longBitsToDouble(0x3fc3dd352f282140L), Double.longBitsToDouble(0x3fe4847dcca76157L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 0, 6, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\u8a7b\udaa4\udd35", "\u742f\u11b0\u5b54\u9b83\u7200\u48c9\u1d88\u01d9\ud7c2\u2b87\u9f22\ubdd3\u2e21\u3e57\ud054", "\udb54\ude10\udbb5\uddce\ud878\udf01",
        3, 29038, -329968757, 4071040655119295745L, 33941L, true, true, (char) 8341, (char) 53442,
        Double.longBitsToDouble(0x3fd5cf82b04744ceL), Double.longBitsToDouble(0x3fc1839bb878a8b0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:usage:  |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 12, "\ud95e\udec9\udaaa\ude76\udadc\udf30\ud9d2\udd05\udb68\ude43\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud9c2\ude62\u8af6\udaa4\udd35\ud840\udf7c\ud8c1\udcd5\ud99b\ude8b\udafa\udcd3\udbff\udf83\udace\udcf6\ud9f6\udf0c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u8fe6\u2091\uce7f\u7a44\u88a5\u4199\ub679", "\udbf9\ude18\ud9c9\udc47\ud827\udf0e\uda77\uddf1\ud939\udd89\ud9fb\udcc1\uc753\ud8f0\udcd1\ud88f\udf81",
        35, 83306, -1447649762, 1844283063212284093L, -97318L, false, false, (char) 37850, (char) 21956,
        Double.longBitsToDouble(0x3fe7179b09dbde50L), Double.longBitsToDouble(0x3fe4847dcca76157L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:usage:  |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 15, 4, "\ud924\udeb7\udbf8\udff8\ud8d2\udc9c\ud974\udf4f\udb6f\udf0e\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\uda8b\udeba\ud98d\udd25\udae8\uded3\ud9c5\udea5\ud974\udcff\uc93e\udbc3\udfd1\ud804\ude59\udaa2\udcf1\uda81\ude51\u1c32\ud869\udca2\ud8b7\udfbf\ud89c\ude88", "\u9bab\ucebd\uce7f", "\ud851\udcf2\udb3a\uddd4",
        47, 52005, 311371009, 3567349980286400082L, 33941L, true, true, (char) 8341, (char) 56550,
        Double.longBitsToDouble(0x3fd5cf8fe04744ceL), Double.longBitsToDouble(0x3fc1839bb878a8b0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 4, "\ud981\ude26\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\ud86b\udd00\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\ud9c5\udea5\uda70\udcfd\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8d2\udced\udb78\udeb6", "\u6430\u2091\uce7f\u7a44\u883a\u4199\u068e\ua6fb\u70cb\u1300\u0895", "\ud939\udd89\ud9fb\udcc1",
        21, 94779, -1570304676, 2080056248458045580L, 80148L, false, true, (char) 28201, (char) 49577,
        Double.longBitsToDouble(0x3fc064e8c241c0f0L), Double.longBitsToDouble(0x3fcf19fd969b2fa0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud981\ude26\uda90\ude25\u6c10\ud847\udea5\ud9be\ude3e\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\ud871\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\ud9c5\udea5\uda70\udcfd\ud97a\udf5c\u02f0\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\u64f6\u2091\uce7f\u7a44\u883a\u4199\u068e |a0=java.lang.StringBuffer:\ud981\ude26\uda90\ude25\u6c10\ud847\udea5\ud9be\ude3e\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\ud871\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\ud9c5\udea5\uda70\udcfd\ud97a\udf5c\u02f0\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\u64f6\u2091\uce7f\u7a44\u883a\u4199\u068e |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 4, "\ud981\ude26\uda90\ude25\u6c10\ud847\udea5\ud9be\ude3e\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\ud871\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\ud9c5\udea5\uda70\udcfd\ud97a\udf5c\u02f0\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u883a\u4199\u068e", "\udbf9\ude18",
        57, 50, -1043517028, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fd370798f688facL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 4, "\ud981\ude26\uda9f\ude2c\u6c10\ud9df\udd86\ud811\udde0\ud9b0\udd8e\udad7\udecc\ud80a\udcf0\ud968\udd86\udbcd\udf8c\uda49\udfe0\udaa4\udd50\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\ud9c5\udea5\uda70\udcfd\udbbe\udedf\ud97e\ude16\ud843\ude33\udab6\udd4c\ud9ba\udeec\udbbf\udc85\ud869\udc44\ud8b7\udfbf\ud968\udf2d", "\u64f6\u913c\u1718\ud70f", "\udb14\udcdc\udaaf\udd71\udbd0\udce4\udbf9\ude18\ud826\udda2\udbf3\ude19\udaf7\ude52\ud939\udd89\ud9fb\udcc1\uc753",
        4, 39851, 484300874, 3038918797625302558L, 96964L, false, false, (char) 5521, (char) 46592,
        Double.longBitsToDouble(0x3fd634fac804d9a6L), Double.longBitsToDouble(0x3fefe3edf70b6dadL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 15, 4, "\ud981\ude26\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\ud9dc\udd24\ud9c5\uddfc\uda70\udcfd\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udf68", "\u64f6\u2091\uce7f\u74a3\uac92\u4199\u068e", "\udbf9\ude18",
        5, 22258, -96668737, 3662779625256114463L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fdec0798f688fdeL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\u00e8 |a0=java.lang.StringBuffer:\u00e8 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 4, "\u00e8", "", "\ud9b0\udd8e",
        20, 81676, -1988612666, 4758707266825876239L, -27641L, false, false, (char) 53823, (char) 54188,
        Double.longBitsToDouble(0x3fc856543ca4802cL), Double.longBitsToDouble(0x3fe9fcba819a45d2L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:                                                |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\uda4f\udfcd\udb1f\udfef\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\ud9a4\udc5f\ud9c2\udffe\ud86f\ude41\udaa2\uddbe", "\u2226\u8f0e\uce7f\u7a44\u883a\u4199\u068e", "\ud926\udd8f",
        47, 50, -1043517028, -6741719546813555747L, 81647L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fee9c2121c602efL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 15, 2, "\ud981\ude26\uda9f\ude2c\u6c10\uda5e\udf10\ud9ad\udfbe\ud9b0\udd8e\ud848\udd95\uda59\udc36\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\ud9c5\udea5\uda70\udcfd\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\ud907\udca2\ud871\udfb2\ud990\udda1\uda9e\udfb6", "\u64f6\u2091\u6b5b\u6128\u883a\u4199\u068e", "\ud82f\udc3c",
        2, 88364, -1043517028, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fdec0798fc48fdeL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 15, 4, "\ud981\ude26\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\ud9c5\udea5\uda70\udcfd\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u883a\u4199\u068e", "\udbf9\ude18",
        3, 50, -1043517028, -8872666539377174241L, 28709L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fdec0798f688fdeL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 15, 4, "", "", "\uc1f0",
        -5, 14728, -699645324, -8541026363773398260L, 29962L, true, true, (char) 14509, (char) 45923,
        Double.longBitsToDouble(0x3fe94800073f9700L), Double.longBitsToDouble(0x3fd9a45d27ced69eL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 9, 12, "\uda29\udf3b\ud890\udf9b\uda22\udffb\u279e\u609b\ud974\udcd9w\000", "\017\u4897\u6105\u81a3\u3a46\u11b0\u5cb1\u9b83\u7200\u21f8\u284c\u87ca\000", "\ud890\udf80\uda81\udf3f\uda9d\udd88\udbb2\ude2e\uda3e\udc1c",
        4, 74993, -525046429, 5238416667320470602L, -18586L, false, true, (char) 42865, (char) 12002,
        Double.longBitsToDouble(0x3fe9e7f0828d2d81L), Double.longBitsToDouble(0x3fe3325cbf343342L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 12, "\ud827\udcb8\uda9f\ude2c\udaac\ude78", "\u3114w\000\u4084", "\ud89b\udc0d\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b",
        29, 54426, 0, 0L, 32096L, true, true, (char) 54809, (char) 38969,
        Double.longBitsToDouble(0x3fd7baeb0fee4808L), Double.longBitsToDouble(0x3fea1a07be113a79L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 11, 11, 9, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b", "\u81a3\u3a46\u5060\u5592", "\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\udb8a\uddca\ud987\udecd\ud83a\udf4d\ud891\udeb5\udb54\ude10\udbb5\uddce\ud878\udf01\ud851\udcf2\ud84a\udf28",
        47, 96869, -1572475994, 3567400291533305426L, -31595L, true, true, (char) 48994, (char) 27990,
        Double.longBitsToDouble(0x3f9cf120605fc300L), Double.longBitsToDouble(0x3fc1838ef878a8b0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 14, 9, "\ud827\udcb8\ud884\udf2b\u6c10\udab3\udcc6\udb6b\uded0\ud974\udd55\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b", "\u81a3\u3a46\u7015\u55ba", "\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\ud858\udd4a\udaf2\udece\udaf6\udf0e\udbb5\udf0c\ud9ea\ude44\ud85c\udf57\udb93\udff7\udbbf\udf51\udb54\ude10\udbb5\uddce\ud878\udf01\ud851\udcf2\udb8c\udc53",
        15, 96869, -1572475994, 3567400291533305426L, 78741L, true, true, (char) 34582, (char) 58964,
        Double.longBitsToDouble(0x3f9c031a60580300L), Double.longBitsToDouble(0x3fc1838eec78a8b0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\000\ud9b0\udd8e\udb3f\udd80 |a0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\000\ud9b0\udd8e\udb3f\udd80 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\000\ud9b0\udd8e\udb3f\udd80 |a0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\000\ud9b0\udd8e\udb3f\udd80 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\000\ud9b0\udd8e\udb3f\udd80", "\014", "",
        40, 11622, -750172347, -8694762030592102656L, 31072L, false, true, (char) 57142, (char) 30658,
        Double.longBitsToDouble(0x3fe81b7a2fe851a1L), Double.longBitsToDouble(0x3fc1cccf224c0554L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 2, 12, "\udb29\udd19\ud804\udd8f\u6c10\ud9c9\udd86\ud9d7\udf02\ud8c4\udc37\udad7\udecc\udb65\udffe\udb11\udec9\ud987\udda4\ua625\udaa4\udd76\ud902\udf1d\uda5f\uddd7\udbd7\ude2a\ud9a2\udea7\ud9fe\udf90\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\uda3f\udca8\ud9ef\udd68\ud830\udfd9\udaf8\udca0\ud8b7\udfbf\udab2\uddac\uda1c\udea5\ud953\udfc4\ud84f\uddeb\ud891\udeb5\udb54\ude10\udbb5\uddce\ud878\udf01\udb14\udf94\udb57\uddc3\udaaf\udd71\udbd0\udce4\ud8ec\uddb1\ud914\ude52", "\u5d3a\u0dac\u5b1b\uabde\u99fb\u4234\u7713\u62c4\ud678\u49f7\ub464\ub1e8\u8747\u136d\ub3a5", "\ud9ed\udd6a\ud821\ude0b\udb7f\udc07\ud9ef\udf30",
        2, 91343, -1436586743, -957518728689413875L, 79211L, false, true, (char) 39603, (char) 53049,
        Double.longBitsToDouble(0x3fee13e61510e0ffL), Double.longBitsToDouble(0x3feade855044fd9fL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 0, 1, "\ud827\udcb8\ud9cc\udea3\u430e\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\ud94d\uddfa\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udcd4\ud97a\udf5c\udbc3\udfec\uda68\udfec\ud80a\udc04\uda08\udfd2\udbe7\udd09\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\u1465\u2cdd\u0b39@\ua394", "\u2496\ud89e\udc3d\000\uda6b\udc55\ud939\udd89\ud9fb\udcc1\uc753\ud8f0\udcd1\udbb9\udfd7\ud9de\uddd6\ud8d4\udf08\ud8bc\udd08\ud853\udf2f\uda28\udcbd\ud95b\udc34\ud98d\udd34\ud983\udf3e\ud81d\udd0c\uda2e\ude6d",
        6, 35534, 494160000, -3720356447129018202L, 47836L, false, true, (char) 12551, (char) 1430,
        Double.longBitsToDouble(0x3fd6961b2c1b9b66L), Double.longBitsToDouble(0x3fc8ddf287aa9130L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 12, "\ud9dd\ude9b", "\u5bf6\u77f2\u49ca", "\udb11\udec9\u3fca\udb1e\uddee\uda89\udf6d\ud8b8\udcbd\udab8\uddd0",
        3, 19739, -1492388670, 3634465373598971697L, -78544L, false, false, (char) 60999, (char) 60555,
        Double.longBitsToDouble(0x3fc1cccf224c0554L), Double.longBitsToDouble(0x3fdcd79b6ef4cb0cL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd30\ud8b8\udc58\udb16\udd61\ud98d\udca2\udafa\udcd3\udbff\udf83\ud806\ude0b\ud97a\udf46\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\u64f6\u2091\uce7f\u7a44\u88a5\u4199\u068e |a0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd30\ud8b8\udc58\udb16\udd61\ud98d\udca2\udafa\udcd3\udbff\udf83\ud806\ude0b\ud97a\udf46\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\u64f6\u2091\uce7f\u7a44\u88a5\u4199\u068e |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 12, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\udb11\udec9\ud91f\udef0\ud816\udd7b\udaa4\udd30\ud8b8\udc58\udb16\udd61\ud98d\udca2\udafa\udcd3\udbff\udf83\ud806\ude0b\ud97a\udf46\udbc3\udfec\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u88a5\u4199\u068e", "\udbf9\ude18",
        57, 50, -1043517028, -8872666536698390241L, -100000L, false, true, (char) 31370, (char) 34153,
        Double.longBitsToDouble(0x3fe0f15165ada9b6L), Double.longBitsToDouble(0x3fc7a3331c2ac024L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 2, 12, "\ud827\udcb8\uda9f\udea1\u6c10\ud9c9\udd86\ud9d7\udf02\ud9b0\udd8e\udad7\udecc\udb65\udffe\ud9c3\ude63\ud91f\udef0\ud816\udd7b\ud8ba\udfa0\udb57\udc7b\ud8e6\uddc7\ud98d\udca2\udafa\udcd3\udbff\udf83\udaa8\udeba\ud991\udfbc\udbb7\udfa8\ud804\ude59\ud8eb\udd17\uda91\udc90\udb47\ude3a\ud81f\udc86\udb28\udf69\ud97a\udd78\uda1c\udea5\ud953\udfc4\ud83a\udfcb\ud891\udeb5\udb54\ude10\ud956\uded9\uda23\udfcb\ud9fd\udc89\udbdc\udf95\uda84\udd0b", "\u9fbf\ub518\u27e4\ubada\uc954\ucfb8\ua8ec\u49e7\u34f2\u0acc", "\udbac\udd4d\uda4a\udc43\uda08\udd6a\udb2e\udf04\uda2f\udcec\ud9f8\udcbd",
        7, 16024, -1429982460, -5871714807488362295L, -21649L, false, true, (char) 50773, (char) 720,
        Double.longBitsToDouble(0x3fe7d5418ba03702L), Double.longBitsToDouble(0x3fe18eb2fabf1cceL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.StringBuffer: |a0=java.lang.StringBuffer: |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer: |a0=java.lang.StringBuffer: |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "", "\ud94c\udc1d\udbeb\udf5c\udb55\udfa1\ud964\udd67\udb2c\udf00\ud87d\udca0\ud816\udd7b\ud9cb\udd28\ud8b8\udc58\ud9f5\udd70\u4745\ud8cf\udc13\ud91a\udf88\ud9c2\udf31\ud845\udeac\udbc3\udfe2\ud929\udeac",
        34, 30787, -1325902693, -4238943433221270580L, -36400L, true, true, (char) 42986, (char) 25967,
        Double.longBitsToDouble(0x3febc8e7b1090618L), Double.longBitsToDouble(0x3fe829b781a3d8c3L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 14, 6, "\ud813\udfe3\ud9be\udf52\u6c10\udb97\udd8d\ud9d7\udf02\ud9b0\udd8e\udb11\udec9\udb65\udffe\ud818\udc5a\udac7\udf11\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9a1\udd28\ud98d\udca2\udafa\udcd3\udbff\udf83\uda76\udd6b\ud97a\udf5c\u8657\ud804\ude28\udaa2\udcf1\uda08\udfd2\uda68\udf52\ud833\udcf5\ud8b7\udfbf\uda9e\udfc8\ud89d\udcc5\ud96a\udc98\ud83a\udfcb", "\u7a44", "\udb57\uddc3\udac2\udf71\udbd0\udce4\udbf9\ude18",
        1, 37, 171061660, -2939836352928294625L, 28623L, false, true, (char) 25482, (char) 34153,
        Double.longBitsToDouble(0x3fe6c95163fba9b6L), Double.longBitsToDouble(0x3fc7a3331c2ac024L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.String:                                             |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                                             |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 3, 3, 15, "\ud9a1\udcb5\ud81c\udf2a\u6c10", "\ud391\uae8d\u944e\u679c", "\uda95\udf37\ud8b9\udf7f\uda9f\udd65\ud98d\udca2\udaf6\udcda\udbff\udecd\uda76\udd6b",
        44, 41128, 1834972135, 8017826133290622723L, 92166L, true, false, (char) 3971, (char) 32000,
        Double.longBitsToDouble(0x3fda5ae0b049809eL), Double.longBitsToDouble(0x3fea05ca91113a9aL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String:                                                |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud918\udfb1\udaf6\udf9a\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\012\ud9c2\udfc8\ud86f\ude41\udaa2\uddbe", "\u2226\000\000\u7a44\u883a\u4199\u068e", "\ud926\udd8f",
        47, 50, 0, 169097157410816L, 81647L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fee9c2121c602efL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9cb\udd87\000\ud947\udd19\udb3b\udd82 |a0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud9cb\udd87\000\ud947\udd19\udb3b\udd82 |this=org.apache.commons.cli.HelpFormatter:@?\0121=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 11, 14, "\ud827\udcb8\uda9f\ude2c\u6c10\ud9cb\udd87\000\ud947\udd19\udb3b\udd82", "\014", "\ud85e\udda2",
        47, 54653, -2024407040, 913649084085287720L, -31805L, true, true, (char) 39305, (char) 25351,
        Double.longBitsToDouble(0x3fc2602aa4b71eb8L), Double.longBitsToDouble(0x3fdcea2bf370febeL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 12, "\ud9c1\uddc3\udb2c\ude65\udb91\udff4\ud882\udde4\ube85\udbd0\udc7f\udb38\udfbe\ud892\udfae\udb11\udec9\u3fca\udb1e\uddee\uda89\udf6d\ud8b8\udcbd\udaef\uddcc\ud9fb\udd2f\udb39\udfcc\ud903\udf53\udbfd\udf2c\ud97a\udfb3\udb0d\udff1\udac3\udca7\ud828\udde0\ud96c\ude88\udbe7\udd53\ud869\udca2\ud8b7\udfbf\uda9e\udfc8\uda6a\udc2c\ud96e\udf93\udab7\udd63\ud925\udd8e\ud97a\udcc6\udb9a\udf3e\udacf\udcdf\ud9bc\udd86\u762a\ud916\ude5a\u99d2\ud801\uddec\uda98\udd37\ud870\uddc3\ud98e\udecb\ud8c8\udc26\ud8c1\udda4\ud97f\udc38\ud99f\udf2a\udaf1\ude6f\uda85\udd0e\udb29\udf25\uda1e\udf7c\uda3e\udd5a\udb46\udce3\ud949\udde1\ud96d\udd3f\ud97d\udf08", "\u8927\u8656\u284e\ua811", "\ud8c5\udc86\ud938\udfc6\ud91d\udffa\udadb\uddf6\udab0\udc7a\ud977\udc3e\udaa9\udd60\ud8bc\udd1f\ud918\udfa0\ud8b2\udd30\ud848\udeb6\udb18\udc74\udb1f\ude34\udbc8\ude7a\ud92d\udc97",
        8, 88495, 1800739344, -5432020363109301201L, -77624L, true, true, (char) 35768, (char) 23229,
        Double.longBitsToDouble(0x3fe6488844d970bbL), Double.longBitsToDouble(0x3fc29fbdfdefe244L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 14, 6, "\ud813\udfe3\ud998\udcbe\ud9f2\udcdb\ud817\udeb6\ud80e\ude1c\ud9b0\udd8e\udb11\udec9\ud941\ude23\ud818\udc5a\udac7\udf11\ud816\udd7b\udaa4\udd35\ud8b8\udc58\ud9a1\udd28\ud98d\udca2\udafa\udcd3\udbff\udf83\udadf\udda7\ud976\udcf6\ud9c5\udc15\ud803\udfe1\udaa2\udcf1\ud89a\uded7\ud83e\udd1d\ud833\udc01\ud8b7\udfbf\uda9e\udfc8\ud89d\udcc5\ud96a\udc98\ud83a\udfcb", "\u7a44", "\udb57\uddc3\udac2\udf71\udbd0\udce4\udbf9\ude18",
        1, 37, 171061660, -2939836352928294625L, 28623L, false, true, (char) 25482, (char) 34153,
        Double.longBitsToDouble(0x3fe6c95164ff7261L), Double.longBitsToDouble(0x3fc8b9b2456b4944L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.String:                        |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud918\udfb1\udaf6\udf9a\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\012\ud9c2\udfc8\ud86f\ude41\ud87f\udfdf", "\u2226\000\000\uab4e\u883a\u4199\u068e\ua6fb\u6934\u3fbd", "\000\u99cb\000\udb29\udd4f\udb73\ude30",
        23, 47474, 708715059, 8151085543265158220L, 27430L, false, true, (char) 47274, (char) 1294,
        Double.longBitsToDouble(0x3fb0b19e73042a58L), Double.longBitsToDouble(0x3fe72426637c5410L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.String:         |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\ud85f\udc5e\uda94\udf42\ud8fc\udf63\ud9da\udfd9\udbd9\ude4f\udbb7\udd2f\ud9d4\udf2c\ud828\udce8\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud918\udfb1\udaf6\udf9a\udaf5\ude8c\udbbe\udcf3\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\012\ud9c2\udfc8\ud86f\ude41\udaa2\uddbe", "\u2226\000\000\uaa15\u888e\u4199\u068e", "\ud926\udd8f",
        8, 59379, 59, 169097157410816L, 81647L, false, false, (char) 11265, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fee9c2121c602efL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.String:                                                |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\uda1d\uddf4\000\uda2d\ude0c\u00f8\000\000\udad7\ude55\ud90b\udebb\udb36\udf69\uda56\udf0c\000\ud9ca\udc04\udab3\udffd\ud9f5\udd1a\ud918\udfb1\udaf6\udf9a\udaf5\ude8c\u7768\uff3f\u7100\000\u0a63\ud9a8\udec2\012\ud9c2\udfc8\u4c74\000", "\u213b\000\000\u7a44\u883a\u4199\u068e", "\ud926\udd8f",
        47, 50, 0, 169097157410816L, -100000L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e800003cL), Double.longBitsToDouble(0x3fee9c20010000efL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.String:                      |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\ud930\ude15\ud8fc\udf63\ud87e\udfcc\uda9b\udf9d\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\uda04\udde3\ud918\udfb1\u20cf\udb21\ude7d\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\012\ud9c2\udfc8\ud86f\ude41\udaa2\uddbe", "\u2226\000\000\u7a44\u883a\u4199\u068e", "\ud926\udd8f",
        21, -11, 0, 169097157410816L, 81647L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fee9c2121c602efL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud918\udfb1\udaf6\udf9a\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\012\ud9c2\udfc8\ud86f\ude41\udaa2\uddbe", "\u2226\000\000\u7a44\u883a\u4199\u068e", "\udab0\udc14",
        0, 151, 0, 169097157410816L, 81647L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fee9c2121c602efL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.String:               |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\ud8eb\udf93\ud892\udcde\uda5b\udced\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\uda1f\udccf\ud880\ude69\u861d\uda8a\udf1a\uda51\uddbc\udaa4\udd35\ud8b8\udc58", "\ud07d\u1aa9\uac4f\u7200\u48c9\u1d88\u45ed\uc262\012\ub8f8\u80ae\u3c17\u50b9", "\000\udbe4\ude50\udbb5\uddce\ud80c\udfc0\ud851\udcf2\udb57\uddc3\udaaf\udd71\ud930\udfcf\ud926\udd8f\udb59\ude29\ud827\udf0e\000\u99cb\000\udb29\udd4f\udb73\ude30\udbb6\ude9d",
        14, 98059, 1897822494, -8924933468284056621L, 67059L, false, false, (char) 64214, (char) 40486,
        Double.longBitsToDouble(0x3fd3b4b7fde4a59aL), Double.longBitsToDouble(0x3fdc37a13d5c1218L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.String:                                                |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb45\udfcb\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud918\udfb1\udb32\udf26\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\uda44\udf6e\ud94f\ude19\udaf4\udc9a\ud994\udf81\012\ud9c2\udfc8\ud88b\udf41\udaa2\uddbe", "\u2226\000\000\u3dec\u5a65\u4128\u068e", "\ud926\udd8f",
        47, 50, 0, 169098974509824L, 81647L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fed542120db627bL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:           |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\ud9f5\udd70\ud918\udfb1\udaf6\udf9a\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\012\ud9c2\udfc8\udb79\udd44\udaa2\uddbe", "\u2226\000\000\u7a44\u3d92\u4103\u1b4c", "\ud926\udd8f\udb59\ude29\ud827\udf0e\000\u99cb\000\udb29\udd4f\udb73\ude30\udbb6\ude9d\ud8a1\ude5f\ud905\udcb0\uda35\udfc8\ud977\udcff\ud8dc\udfff\uda09\udecc\ud92a\udf31\ud840\udece\uf157\udb18\udd40\uda1d\ude91\udae9\udfd9\ud9ec\udc1a\udb37\ude4e\ud861\ude09\udb01\uddca\udb00\udd4b\udb9d\udf5a\ud9fa\uddc3\udb48\udccd\ud8a0\udeb0\uda0f\ude71\ud8e1\udcf1",
        10, 14602, 776387140, -1346943860812571790L, 29401L, false, false, (char) 5690, (char) 33602,
        Double.longBitsToDouble(0x3fe1eff7a12a91f3L), Double.longBitsToDouble(0x3fb0336f210e74c8L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:   |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\udbb3\ude0e\udbff\udda1\udaf6\udf9a\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\012\ud999\udf02\ud86f\ude41\udaa2\uddbe", "\u7047\000\000\u7a44\u883a\u4199\u068e", "\ud949\ude2e",
        2, 50, 0, 169097157410816L, 81647L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fee9c2121c602efL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.String:               |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\ud9f5\uddfd\ud918\udfb1\udaf6\udf9a\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\012\ud9c2\udfc8\ud86f\ude41\udaa2\uddbe", "\u2226\000\000\u7a44\u883a\u4199\u07be", "\ud926\udd8f\udb59\ude29\ud827\udf0e\000\u99cb\000\udb29\udd4f\udb73\ude30\udbb6\ude9d",
        14, 98059, 1897822494, -8924933468284056621L, -10884L, false, false, (char) 28303, (char) 60115,
        Double.longBitsToDouble(0x3fda7cfd73879a6cL), Double.longBitsToDouble(0x3fcb53f312ebe050L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:             |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\ud8e9\uddab\ud8fc\udf63\ud87e\udfcc\uda19\udf9a\ud98b\udce4\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\udad7\ude41\udb0d\uded2\uda31\udcf7\ud844\udf3f\uda4c\udec4\ud971\ude5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud9a8\udec2\012\ud9c2\udfc8\udaa0\udc7a\udaa2\udd12", "\u2226\000\000\u7a44\u883a\u1099\u35fc", "\uda45\udf95",
        12, 50, -855112192, 16377225695751680L, 72943L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fee9c2127f802efL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\uddb1\ud9a5\ude84\ud8aa\udf44\uda51\uddbc\udb94\ude18\ud8b8\udc58\ud07d\u1aa9\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012             \ub8f8\012             \u80ae\012             \u3c17\012             \u7963 |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\uddb1\ud9a5\ude84\ud8aa\udf44\uda51\uddbc\udb94\ude18\ud8b8\udc58\ud07d\u1aa9\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012             \ub8f8\012             \u80ae\012             \u3c17\012             \u7963 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 15, "\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\uddb1\ud9a5\ude84\ud8aa\udf44\uda51\uddbc\udb94\ude18\ud8b8\udc58", "\ud07d\u1aa9\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012\ub8f8\u80ae\u3c17\u7963", "\000\udbbb\ude1c\udb9f\udc6b\ud80c\udfc0\ud851\udcf2\udbd7\udc95\uda9c\udcc2\udb19\ude61\udbed\udd6c\ud9d2\udcf5\ud82a\udc3c\uda58\udffc\ud966\udcf1\ud967\ude84\u891b\udb73\ude30\udbb6\ude9d",
        14, 32809, 1897822631, -8924933467260646445L, 67059L, false, false, (char) 64214, (char) 10023,
        Double.longBitsToDouble(0x3fb84bc4956aaea8L), Double.longBitsToDouble(0x3fef94cd0ab6a433L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \ub8f8\012                                                    \u80ae\012                                                    \u3c17\012                                                    \u7963\012                                                    \u5b9c\012... |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \ub8f8\012                                                    \u80ae\012                                                    \u3c17\012                                                    \u7963\012                                                    \u5b9c\012... |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 15, "\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec", "\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012\ub8f8\u80ae\u3c17\u7963\u5b9c\u2226\000\u48c9", "\ud851\udcf2\udbd7\udc95",
        53, 18006, -338086243, 2185080537294151996L, -55019L, true, true, (char) 3990, (char) 15108,
        Double.longBitsToDouble(0x3fa1417d49aa2670L), Double.longBitsToDouble(0x3fd99964a34f0dacL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012  \ub8f8\012  \u80ae\012  \u3c17\012  \u7963\012  \u5b9c\012  \u2226\012  \u48c9 |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012  \ub8f8\012  \u80ae\012  \u3c17\012  \u7963\012  \u5b9c\012  \u2226\012  \u48c9 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 15, 15, "\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec", "\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012\ub8f8\u80ae\u3c17\u7963\u5b9c\u2226\000\u48c9", "\ud851\udcf2\udbd7\udc95\uda9c\udcc2\udb19\ude61\udbed\udd6c",
        3, 35428, 991615780, 1511150866594684829L, 81647L, false, false, (char) 65281, (char) 40931,
        Double.longBitsToDouble(0x3fda786d697022aeL), Double.longBitsToDouble(0x3fee57da2b842eceL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda51\udce8\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\005\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \u538e\012                                                    \u3c17\012                                                    \u00f5\012                                                    \u5b40\012                                                    \u2226\012 ... |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda51\udce8\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\005\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \u538e\012                                                    \u3c17\012                                                    \u00f5\012                                                    \u5b40\012                                                    \u2226\012 ... |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda51\udce8\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\005\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \u538e\012                                                    \u3c17\012                                                    \u00f5\012                                                    \u5b40\012                                                    \u2226\012 ... |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda51\udce8\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\005\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \u538e\012                                                    \u3c17\012                                                    \u00f5\012                                                    \u5b40\012                                                    \u2226\012 ... |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 15, "\uda06\udce8\udacb\udfe8\uda51\udce8\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\005", "\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012\000\u538e\u3c17\u00f5\u5b40\u2226\000\u48c9", "\ud851\udcf2\udbd7\udc95",
        53, 18006, -352307555, 2185080537294151996L, -55019L, true, true, (char) 3990, (char) 15108,
        Double.longBitsToDouble(0x3fa1417d49aa2670L), Double.longBitsToDouble(0x3fd99964a34f0dacL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 5, 2, 12, "\ud827\udcb8\uda9f\ude2c\udaed\udc18\ud9c9\udd86\ud9d7\udf02\udacc\udffd\ud9fe\udf1d\udbaa\uddae\ud9e5\udc12\ud82d\udfd7\ud816\ude13\udaa4\udd35\ud9ad\udfb2\ud9f5\udd70\ud98d\udca2\ud893\udebf\udbff\udf83\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud804\ude59\uda64\uddb7\udaec\ude57\udbe7\uddf1\ud869\udca2\ud8b7\udfbf\uda9e\udfc8", "\u64f6\u2091\uce7f\u7a44\u88a5\u4199\u068e", "\udbf9\ude18",
        57, 50, -1043517028, -8872666540108490465L, 68956L, false, true, (char) 7616, (char) 34153,
        Double.longBitsToDouble(0x3fe0f3e9629560faL), Double.longBitsToDouble(0x3fcac8e3a1cf4be0L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 12, "\udb7e\udcd6\udb2e\udd2a\udac4\udfd2\ud9be\uded1\ud9d7\udf02\ud8c4\udc37\udad7\udecc\udb65\udffe\udb11\udec9\ud987\udda4\ua625\udaa4\udd76\ud8b8\udc58\uda3f\ude14\udbd7\ude2a\ud9a2\udea7\ud9fe\udf90\uda76\udd6b\ud97a\udf5c\udbc3\udfec\ud80f\uddb7\uda3f\udca8\ud9ef\udd68\ud830\udfd9\udaf8\udca0\ud8b7\udfbf\udab2\uddac\uda1c\udea5\ud953\udfc4\ud84f\uddeb\ud891\udeb5\udb54\ude10\udbb5\uddce\ud878\udf01\udb14\udf94\udb57\uddc3\udaaf\udd71\udbd0\udce4\ud8ec\ude18\ud914\ude52\udb58\udcc5\ud84e\udc39\ud939\udd89\ud9fb\udcc1\uc753\ud8f0\udcd1\udbb9\udfd7\ud9de\uddd6\ud8d4\udf08\ud8bc\udd08\ud862\udd84\uda87\udf60\ud978\uddd7\udb48\udf69\u77d1\ud8ec\udf6e\udacb\udd7c\udb5f\ude2a\ud811\uddd3\udb33\ude9e\ud83f\udd2e\uda49\udf32\ud997\ude0b\uda01\udf0e\uda68\udf18\udbd9\udd86\ud994\udfcb\ud882\ude1f\udb8e\udc84", "\u0556\uba47\u5e0d\u95d8\uab2d\u556d\u273f\ub8e8\u5d68", "\ud8be\ude7f\udb8e\udee9\ub48a\udae6\udc7a\ud879\udd68\ud852\uddcc\ud986\udcbc\ud937\udda8\udb94\udc49\ud98f\udd06\u2318\ud993\ude53\ud9cf\udf14\ud962\udde3\ud9d5\udf16\ud9e3\udf26\ud8ef\ude91\ud83e\udfc4\udb9f\udd2e\ud879\udd1b\udbe5\udd47\ud903\ude7f\udb34\udda3\ud826\udf32\ud8ad\ude19\udb9b\udf73\uda33\udf72\udb5c\uddb2\ud9bd\ude85\udae8\udece\ud945\udfc2\udb5a\udc6c\udb16\udeb6\ud817\udd41\ud93f\ude59\ud82c\udf0d\uda51\udc06\ue047\uda06\udf59\udba3\udea5\udbff\udfb3\udbb5\uded4\uda03\udf2d\udb11\udc22\ud9b4\udc6b\udba2\udc0d\ud8d0\udd06\udae1\udc4a\ud948\udd16\ud822\udf1d\ud887\udf9c\ud85e\udd1b",
        15, 1166, 534863247, -3410670166713141443L, -46261L, true, true, (char) 10070, (char) 4418,
        Double.longBitsToDouble(0x3fe972a4dfa617e8L), Double.longBitsToDouble(0x3fea050af55b2f10L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud89f\ude30\u00a9\ud9b0\uddba\udb3f\udd80\012                                                         \ua767 |a0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud89f\ude30\u00a9\ud9b0\uddba\udb3f\udd80\012                                                         \ua767 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud89f\ude30\u00a9\ud9b0\uddba\udb3f\udd80\012                                                         \ua767 |a0=java.lang.StringBuffer:\ud827\udcb8\uda9f\ude2c\u6c10\ud89f\ude30\u00a9\ud9b0\uddba\udb3f\udd80\012                                                         \ua767 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud827\udcb8\uda9f\ude2c\u6c10\ud89f\ude30\u00a9\ud9b0\uddba\udb3f\udd80", "\011\ua767", "\ud9f5\udd70",
        58, 35960, 61184, 22578472447770624L, 6243L, false, true, (char) 25351, (char) 29160,
        Double.longBitsToDouble(0x3fee43ddccb12163L), Double.longBitsToDouble(0x3feaf4656d81c0f7L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String:   |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\udbb3\ude0e\udbff\udda1\udaf6\udf9a\udaf5\ude8c\uda91\udc78\udb4f\uddf8\ud911\udcca\ud92b\udfe5\udaa2\udcf1\udba1\udf80 \ud999\udf02\ud86f\ude41\udaa2\uddbe", "\u7047\000\000\u7a44\u883a\u1eee\u06b3", "\ud949\ude2e",
        2, 50, 0, 169097157410816L, 81647L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fee9c2121c602efL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \ub8f8\012                                                    \u80ae\012                                                    \u3c17\012                                                    \u7963\012                                                    \u5b9c\012... |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \ub8f8\012                                                    \u80ae\012                                                    \u3c17\012                                                    \u7963\012                                                    \u5b9c\012... |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 15, "\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec", "\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012\ub8f8\u80ae\u3c17\u7963\u5b9c\u2226\u2000\u00d3", "\ud851\udcf2\udbd7\udc95",
        53, 18006, -338086243, 2185080537294151996L, -55019L, true, true, (char) 3990, (char) 15108,
        Double.longBitsToDouble(0x3fa1417d49aa2670L), Double.longBitsToDouble(0x3fd99964a34f0dacL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud9da\udddf\u0734\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\u2d50\u55e8\u2e6a\ub2f0\u45ea\uc262\012                   \u6def\012                   \u19a0\012                   \ucc0b\012                   \u7963\012                   \ub911\012                   \u7ad0\012\012                   \u48c9\012                   \u20e1 |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud9da\udddf\u0734\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\u2d50\u55e8\u2e6a\ub2f0\u45ea\uc262\012                   \u6def\012                   \u19a0\012                   \ucc0b\012                   \u7963\012                   \ub911\012                   \u7ad0\012\012                   \u48c9\012                   \u20e1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 15, "\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud9da\udddf", "\u0734\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\u2d50\u55e8\u2e6a\ub2f0\u45ea\uc262\012\u6def\u19a0\ucc0b\u7963\ub911\u7ad0\u2009\u48c9\u20e1", "\udbd7\udc95\uda9c\udcc2\udb19\ude61\udbed\udd6c\ud9d2\udcf5\ud82a\udc3c\udaaf\ude9f\ud966\udcf1",
        20, 99735, -2097494641, -6744421772708651878L, 60755L, true, false, (char) 25498, (char) 20661,
        Double.longBitsToDouble(0x3fe00b2da45c1fa1L), Double.longBitsToDouble(0x3fea27dc4cfb1a0bL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\udb7a\udfc2\ud85c\ude2a\u6c10\ud89f\ude30\u00a9\ud817\udf6e\ud888\uddf4\012                                                         \ua767 |a0=java.lang.StringBuffer:\udb7a\udfc2\ud85c\ude2a\u6c10\ud89f\ude30\u00a9\ud817\udf6e\ud888\uddf4\012                                                         \ua767 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 12, "\udb7a\udfc2\ud85c\ude2a\u6c10\ud89f\ude30\u00a9\ud817\udf6e\ud888\uddf4", "\011\ua767", "\ud9f5\udd70",
        58, 35960, 61184, 22578472447770624L, 6243L, false, true, (char) 25351, (char) 29160,
        Double.longBitsToDouble(0x3fee43ddccb12163L), Double.longBitsToDouble(0x3feaf4656d81c0f7L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 12, 4, "\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\ud89f\ude56\u00a9\ud9b0\uddba\uaed8", "\011\ua767\000\uc341\u81a3\u3a46\u6953\u1706\u0f5f", "\ud804\ude59\udaa2\udcf1\uda08\udfd2\udbe7\uddf1\udb05\udcd1\uda33\udfdd",
        -3, 47836, -1057507791, -3327292057619661619L, 83294L, true, false, (char) 27143, (char) 48734,
        Double.longBitsToDouble(0x3fea599a5717607aL), Double.longBitsToDouble(0x3feef2cc5ad50b05L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 12, 4, "\ud8fc\udf27\udb14\udf03\ud905\uddee\udb9c\uddce\u3ac2\ud9b0\uddba\uaed8\udb44\udc27\udb11\ude5b\011\udbc0\udcbf\uda4a\udcc7\uda7a\udefd\ud9f5\udd70\ud98d\udca2\udb8e\udce7\uf705\udad7\udf04\ud93d\udc1d\uda27\udf7f\ud804\udd96\udaa2\udcf1\ud8b4\udc09\udbcc\udc6c\udb2f\ude04\uda33\udfdd\udbca\udd1e\udae5\udf23\ud800\ude7a\ud954\udec8\ud86d\udec4\uda65\udf87\ud8a8\udc9f", "\uc69d\u9da7\u9d10", "\ud8d7\udc84\ud876\udf49",
        14, 20339, 1701510502, -6122670708069608348L, -33557L, true, true, (char) 54809, (char) 43201,
        Double.longBitsToDouble(0x3fdf6b0d2b1e49c2L), Double.longBitsToDouble(0x3fd6f58e9f6715b0L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 12, 4, "\ud8fc\udf27\udb14\udf03\ud905\uddee\udb9c\uddce\u3ac2\ud9b0\uddba\uaed8\udb44\udc27\udb11\ude5b\011\udbc0\udcf8\uda4a\udcc7\uda7a\udefd\ud9f5\udd70\ud98d\udca2\ud884\udea1\uf705\ud9f5\udfac\ud93d\udcd4\uda27\udf7f\ud804\udd96\udaa2\udcf1\ud8b4\udc09\udbaf\ude7e\udb0a\udecc\uda33\udfdd\udbca\udd1e\udae5\udf23\uda35\ude74\ud827\udfe0\ud847\udccc\uda65\udf87\ud8a8\udc9f", "\uc69d\u9da7\u2b62", "\ud8d7\udc84\uda73\ude28\ud95a\udf59",
        10, 63467, -1425545362, 2941506296370488017L, -26308L, false, false, (char) 56000, (char) 12035,
        Double.longBitsToDouble(0x3fdb3230d9a9a28aL), Double.longBitsToDouble(0x3fd5ecf63857bda4L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbbe\uddcf\ud83b\udd3a\udb80\uddfa\ud9da\udddf\u0734\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\u2d50\u55e8\u2e6a\ub2f0\u45ea\uc262\012             \u6def\012             \u19a0\012             \ucc0b\012             \u7963\012             \ub911\012             \u7ad0\012\012             \u48c9\012             \u20e1 |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbbe\uddcf\ud83b\udd3a\udb80\uddfa\ud9da\udddf\u0734\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\u2d50\u55e8\u2e6a\ub2f0\u45ea\uc262\012             \u6def\012             \u19a0\012             \ucc0b\012             \u7963\012             \ub911\012             \u7ad0\012\012             \u48c9\012             \u20e1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 15, "\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbbe\uddcf\ud83b\udd3a\udb80\uddfa\ud9da\udddf", "\u0734\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\u2d50\u55e8\u2e6a\ub2f0\u45ea\uc262\012\u6def\u19a0\ucc0b\u7963\ub911\u7ad0\u2009\u48c9\u20e1", "\udbd7\udc95\uda9c\udcc2\udb19\ude61\udbed\udd6c\ud9d2\udcf5\ud82a\udc3c\udaaf\ude9f\ud966\udcf1\ud967\ude84\u891b\udb73\ude30\udbb6\ude9d",
        14, 32809, 357071271, -9048380435513208806L, 60755L, true, false, (char) 25498, (char) 4822,
        Double.longBitsToDouble(0x3fc406d631707ec0L), Double.longBitsToDouble(0x3fea27dc4cfb1a0bL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\ud89f\ude56\u00a9\ud9b0\uddba\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\uda7a\udefd\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43 |a0=java.lang.StringBuffer:\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\ud89f\ude56\u00a9\ud9b0\uddba\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\uda7a\udefd\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 4, "\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\ud89f\ude56\u00a9\ud9b0\uddba\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\uda7a\udefd", "\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43", "\udb05\udcd1\uda33\udfdd\udbca\udd1e\udae5\udf23\ud800\ude7a",
        15, 47477, -72515130, -4715918717323314392L, 58217L, false, false, (char) 48734, (char) 64148,
        Double.longBitsToDouble(0x3f97607a60a411c0L), Double.longBitsToDouble(0x3fe6a8582ddfb0c6L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\ud89f\ude56\u00a9\ud9b0\uddba\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\udbcd\udcc6\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43 |a0=java.lang.StringBuffer:\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\ud89f\ude56\u00a9\ud9b0\uddba\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\udbcd\udcc6\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 4, "\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\ud89f\ude56\u00a9\ud9b0\uddba\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\udbcd\udcc6", "\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43", "\udb05\udcd1\uda33\udfdd\udbca\udd1e\udae5\udf23\ud800\ude7a",
        7, 47477, -72515130, -4715918717323314392L, 58217L, false, false, (char) 48734, (char) 64148,
        Double.longBitsToDouble(0x3f97607a60a411c0L), Double.longBitsToDouble(0x3fe6a8582ddfb0c6L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\udab5\udf50\000\ud974\udcd9\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\udbcd\udcc6\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43 |a0=java.lang.StringBuffer:\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\udab5\udf50\000\ud974\udcd9\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\udbcd\udcc6\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 0, "\ud9f6\udcc1\uda5a\udc14\ud905\uddc9\udab5\udf50\000\ud974\udcd9\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\udbcd\udcc6", "\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43", "\udb05\udcd1\uda33\udfdd\udbca\udd1e\udae5\udf23\ud800\ude7a",
        7, 47477, -72515130, -4715918717323314392L, 58217L, false, false, (char) 36607, (char) 64148,
        Double.longBitsToDouble(0x3f97607a60a411c0L), Double.longBitsToDouble(0x3fe6a8582ddfb0c6L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud9f6\udcc1\ubec0\ud905\udd2f\udab5\udf50\000\ud974\udcd9\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\udbcd\udcc6\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43 |a0=java.lang.StringBuffer:\ud9f6\udcc1\ubec0\ud905\udd2f\udab5\udf50\000\ud974\udcd9\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\udbcd\udcc6\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 0, "\ud9f6\udcc1\ubec0\ud905\udd2f\udab5\udf50\000\ud974\udcd9\uaed8\udb01\udcfb\udb11\udeec\011\udb0c\ude66\000\udbcd\udcc6", "\u6954\u1706\u0f5f\u52c0\u48c9\u1d88\u8e43", "\udb05\udcd1\u7093\udb1d\udd4d\udae5\udf23\ud800\ude7a",
        7, 47477, -72515130, 39882489179929344L, 58217L, false, false, (char) 36607, (char) 64148,
        Double.longBitsToDouble(0x3f97607a60a411c0L), Double.longBitsToDouble(0x3fe000582ddfb0c6L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.String:        |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 15, 14, "\udb95\ude30\uda9f\ude2c\ud9c6\udc47\uda0d\uddc4\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\udbb3\ude0e\udbff\udda1\udaf6\udf9a\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\u81d0\udadb\udf15\ud9a8\udec2\012\ud999\udf02\ud86f\ude41\ud943\udef2\udbb8\ude35\ud823\udf16\udb8a\udf34\u00dc\000\uda8f\ude3a\ud9a6\udeca\ud85f\ude0e\udb57\uddc3\udaaf\udd71\ud930\udfcf\ud949\ude2e\ud86b\udc2e\ud827\udf0e\000\u99cb\000\udae6\udeef\udb9c\udc35\ud96d\udfcb\udb2e\udf73\uda9c\udc2f\uda35\udfc8\ud977\udcff\ud8dc\udfff\udb83\udd09\ud9eb\udd67\udb51\udd48\udb84\ude7b\ud8e1\udc9a\ud97b\ude2e\uda94\uddd8\udac2\udc96\udb03\udd60\ud855\udcaf\uda77\ude2f\udbf3\udf43\u3178\udac3\ude2a\uda61\uded3\ud922\udd87\udaa5\udcc2\ud8e5\udc1d\ud995\udc21", "\ua16d\u73f1\uc507\u2c70\ucb65\uc536\ua7a6\ua5c7\u82c3\u8cdd\ud2cf\u3fcb\u7f9b\ub474\u495c\u5feb\u0680\u050a", "\uda81\udf43\udb56\udc61\ud802\udf2d\u00af",
        7, 4045, -845223999, 5212309817623338159L, 47614L, false, true, (char) 60860, (char) 56416,
        Double.longBitsToDouble(0x3febc8d7e84ce14aL), Double.longBitsToDouble(0x3fe3694f41fe43e9L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.String:   |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud87d\ude18\ud86d\udc84\ud90b\ude5b\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\udbb3\ude0e\udbff\udda1\udaf6\udf9a\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\ud804\ude59\udaa2\udcf1\ud903\ude0f\015\ud999\udf02\ud86f\ude41\udaa2\uddbe", "\u7047\000\000\u7a44\u883a\u4199\u068e", "\ud949\ude2e",
        2, 50, 0, 169097157410816L, 81647L, false, false, (char) 65281, (char) 47229,
        Double.longBitsToDouble(0x3fd1e2a3e898e23cL), Double.longBitsToDouble(0x3fee9c2121c602efL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \ub8f8\012                                                    \u80ae\012                                                    \u3c17\012                                                    \u7963\012                                                    \u5b9c\012... |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \ub8f8\012                                                    \u80ae\012                                                    \u3c17\012                                                    \u7963\012                                                    \u5b9c\012... |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \ub8f8\012                                                    \u80ae\012                                                    \u3c17\012                                                    \u7963\012                                                    \u5b9c\012... |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012                                                    \ub8f8\012                                                    \u80ae\012                                                    \u3c17\012                                                    \u7963\012                                                    \u5b9c\012... |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 15, "\uda06\udce8\udacb\udfe8\uda5b\udced\ud87e\udfcc\udbd4\udc3c\ud83b\udd3a\udb80\uddfa\ud900\udcec", "\u6d20\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\uac4f\u7200\u48c9\ub2dc\u45ea\uc262\012\ub8f8\u80ae\u3c17\u7963\u5b9c\u2226\u2000\u00d3", "\ud95a\ude4c\udbd7\udc95",
        53, 18006, -338086243, 2185080537294151996L, -55019L, false, true, (char) 3990, (char) 15108,
        Double.longBitsToDouble(0x3fa1417d49aa2670L), Double.longBitsToDouble(0x3e2a786000000000L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\uda88\udf71\ud940\udf62\ud83b\udd3a\udb80\uddfa\ud9da\udddf\u0734\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\u2d50\ub1c2\u2263\u9cc0\u4547\uc262\012      \u6def\012      \u19a0\012      \u0c13\012      \u7963\012      \ub911\012      \u7ad0\012\012      \u48c9\012      \u20e1 |a0=java.lang.StringBuffer:\uda06\udce8\udacb\udfe8\uda5b\udced\uda88\udf71\ud940\udf62\ud83b\udd3a\udb80\uddfa\ud9da\udddf\u0734\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\u2d50\ub1c2\u2263\u9cc0\u4547\uc262\012      \u6def\012      \u19a0\012      \u0c13\012      \u7963\012      \ub911\012      \u7ad0\012\012      \u48c9\012      \u20e1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 15, "\uda06\udce8\udacb\udfe8\uda5b\udced\uda88\udf71\ud940\udf62\ud83b\udd3a\udb80\uddfa\ud9da\udddf", "\u0734\ua6e9\ua8ba\u81a3\u5048\ud07d\u56a8\u2d50\ub1c2\u2263\u9cc0\u4547\uc262\012\u6def\u19a0\u0c13\u7963\ub911\u7ad0\u2009\u48c9\u20e1", "\udbd6\udfe3\uda9c\udcc2\udb19\ude61",
        7, 15708, -284581572, 4258957345649373109L, 87857L, true, true, (char) 33564, (char) 65281,
        Double.longBitsToDouble(0x3fd99964a34f0dacL), Double.longBitsToDouble(0x3fdef154803504daL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.String:        |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 15, 14, "\udb95\ude30\uda9f\ude2c\ud9c6\udc47\uda0d\uddc4\uda03\ude9a\ud98c\ude8e\udad7\udecc\ud90b\udebb\udb36\udf69\uda8a\ude66\uda51\uddbc\udaa4\udd35\ud8b8\udc58\udbb3\ude0e\udbff\udda1\udaf6\udf9a\uda0e\uddf8\ud82f\udc0a\ud97a\udf5c\udbc3\udfec\u81d0\udadb\udf15\udb7b\udcec\ud8d5\udf6f\ud979\udfe2\ud873\uddc4\ud943\udef2\udbb8\ude35\ud823\udf16\udb8a\udf34\u00dc\000\uda8f\ude3a\ud9a6\udeca\ud85f\ude0e\udb57\uddc3\udaaf\udd71\ud930\udfcf\ud949\ude2e\ud86b\udc2e\ud827\udf0e\000\u99cb\000\udae6\udeef\udb9c\udc35\ud96d\udfcb\udb2e\udf73\ud9b7\udd3b\uda36\udc26\ud977\udcff\ud972\udd89\udb83\udd09\ud9eb\udd67\udb51\udd48\udb84\ude7b\ud8e1\udc9a\ud97b\ude2e\uda94\uddd8\udac2\udc96\udb03\udd60\ud855\udcaf\uda77\ude2f\udbf3\udf43\u3178\udac3\ude2a\uda61\uded3\ud922\udd87\udaa5\udcc2\ud8e5\udc1d\ud995\udc21", "\ua16d\u73f1\uc507\u2c70\ucb65\uc536\ua7a6\ua5c7\u82c3\u8cdd\ud2cf\u3fcb\u7f9b\ub474\u495c\u5feb\u0680\u050a", "\uda81\udf43\udb56\udc61\ud802\udf2d\u00af",
        7, 4045, -845223999, 5212309817623338159L, 47614L, false, true, (char) 60860, (char) 56416,
        Double.longBitsToDouble(0x3febc8d7e84ce14aL), Double.longBitsToDouble(0x3fe3694f41fe43e9L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.String:                                                        |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\udb95\ude30\uda9f\ude2c\ud8fc\udf63\ud87e\udfcc\uda03\ude9a\ud87d\ude18\ud86d\udc84\ud816\udcc0\uda32\udcbf\udaf1\udf96\udb91\udc63\udaa4\udd35\ud8b8\udc58\udbb3\ude0e\udbff\udda1\udaff\udd9a\udaf5\ude8c\udbbe\udcd7\ud97a\udf5c\udbc3\udfec\udacb\udd58\udaa2\udcf1\ud903\ude0f\015\ub50c\uda0e\udd11\ud806\udf90", "\u7047\000\000\u7a44\u883a\u4199\u068e\ua6fb\u6934\u1669\u5a39\ub518\000\u99cb\000\u0c95\u2962\u3933\u4f50\ud443\ua72f\ua97f\u1f4d\u756f\u7789\u3ce3\ud10a\u0aa9", "\u5475\ud842\udfd1\uda5e\udd38\udb76\udfb3\ud92d\udd07\ud8ce\udcc2",
        55, 25197, -1178434054, 3469014464699360171L, -34322L, false, false, (char) 46212, (char) 22821,
        Double.longBitsToDouble(0x3fe46819c72d4bb5L), Double.longBitsToDouble(0x3fe3589eb141bb39L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
