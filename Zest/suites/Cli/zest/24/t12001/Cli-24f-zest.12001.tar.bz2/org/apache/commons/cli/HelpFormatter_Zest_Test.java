package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u382d", "\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e",
        43, 63390, 658413381, 6002263176054290841L, -72783L, true, true, (char) 18976, (char) 31795,
        Double.longBitsToDouble(0x3fecf6bc3e68a333L), Double.longBitsToDouble(0x3fe5d2270b7032bdL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u382d", "\ud939\udc7b\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e",
        43, 63390, 658413381, 6002263176054290841L, -72783L, true, true, (char) 18976, (char) 31795,
        Double.longBitsToDouble(0x3fecf6bc3e68a333L), Double.longBitsToDouble(0x3fe5d2270b7032bdL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\udb9d\udd29\u710a", "\u0566\ua865\u012b\u382d\ua961\u7d24\u82bd\u458a\u7cac", "\ud885\udf1e\ud81f\udd01\u794e\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a\ud8c7\udff9\udb84\udc39",
        30, 29057, -1528702471, -1932706975749531898L, 84728L, false, false, (char) 44589, (char) 38044,
        Double.longBitsToDouble(0x3fe8e135b67e3b6bL), Double.longBitsToDouble(0x3fe456c635d3632dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 10, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8a3\ude6d\ud955\udcc4\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb17\udc4b\ud9ba\udc18\ud88e\udd7e", "\u23c3\u8511\u012b\uc12a", "\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\ud81f\udd01\ub89a",
        43, 63390, 658413381, 6002263176054290841L, 54305L, false, true, (char) 1830, (char) 53659,
        Double.longBitsToDouble(0x3fe5d2270b7032bdL), Double.longBitsToDouble(0x3fe23c07139cc085L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 2, 11, "\ud857\udd8a\ud86e\udd76\udb8a\udd2f\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u382d", "\ud95d\udced\ud96a\udd1c\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e",
        43, 63390, 658413381, 6002263176054290841L, -72783L, true, true, (char) 18976, (char) 31795,
        Double.longBitsToDouble(0x3fecf6bc3e68a333L), Double.longBitsToDouble(0x3fe5d2270b7032bdL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u382d", "\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\ud81f\udd01\udb66\udd51",
        43, 7030, 721485457, 6002263176054290841L, -72783L, true, true, (char) 18976, (char) 31886,
        Double.longBitsToDouble(0x3fecf6bc3e68a333L), Double.longBitsToDouble(0x3fe5d2270b7032bdL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\u0566\u00c3\u012b\u382d |a0=java.lang.StringBuffer:\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\u0566\u00c3\u012b\u382d |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 0, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\u00c3\u012b\u382d", "\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e",
        43, 63390, 658413381, 6002263176054290841L, -72783L, true, true, (char) 18976, (char) 31795,
        Double.longBitsToDouble(0x3fecf6bc3e68a333L), Double.longBitsToDouble(0x3fe00000037032bdL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a", "\uc237\u65ae\u260b\ucaac\u747d\000\000", "\ud88e\udd7e\ud995\ude59\uda4b\ude98",
        19, -805, 0, -31850496L, 36739L, true, false, (char) 16749, (char) 33802,
        Double.longBitsToDouble(0x3ec021f0be340000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud9ac\udd86\ud835\udc34\udacf\udfdb\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u382d", "\ud92b\udf52",
        -3, 76031, -964587542, 3426632875817041532L, -15934L, true, true, (char) 15450, (char) 52083,
        Double.longBitsToDouble(0x3fe47939f66f294cL), Double.longBitsToDouble(0x3fd0036a16971e40L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a\ud8b5\udf1d\uda38\udc0b\udaa7\udeac\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\u59c4\udb1d\udfe2\ud9ba\udc18\ud840\udc3c", "\u8314\u4817\u012b\uaa8b\u4a27\u7d24\u82bd\u458a\u3817\uc826", "\ud81f\udd01\udb48\udd4f\u6ac9\ud90c\udf79\ud808\udd95\ud8b9\udd5f\ud995\udcdb\ud876\udf7b\udac3\udf59\u5f07\ud9df\udc90\ud8b2\udfdb\uda92\uddea\ud9a1\udca3\udbda\ude25\ud86c\ude77\uda84\ude59\ud97b\udcfe\udb2a\udce9\uda99\udd83\ud898\udc0c",
        46, 59507, -1935990061, -6391762882361924484L, 30919L, false, true, (char) 62618, (char) 43939,
        Double.longBitsToDouble(0x3fdc5e248e1adce8L), Double.longBitsToDouble(0x3fd8987b76c14f0eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 0, "\000\000\000\uf27c\ud877\uddfb\ud8c8\udf2b\udb5d\udc55", "\u9055", "\ud88e\udd7e\000\udb30\udcd7",
        32, 1099, 1998859254, -2696164663535555679L, 36739L, true, false, (char) 16749, (char) 33802,
        Double.longBitsToDouble(0x3fbc802073e17c68L), Double.longBitsToDouble(0x3fe9d80000081e19L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a\ud8b5\udf1d\ud9c9\udd9e\udac5\ude91\udad5\uddf6\ud8c8\ude7c\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\uddd2", "\u0566\ua865\u012b\u382d\u2c0c\u7cc4\u82bd\u458a\u7cac\u83c5\u70ce\u9339", "\udb6b\udf70\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a\ud8c7\udff9\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud8bc\udd07\ud9a1\udcd1\udbda\ude25\ud86c\ude77\ud9c2\uddb7\u27e6\uda3f\udfac\ud80a\udcf8\uda90\ude84\udbb3\udc15\uac27",
        3, 32421, 101010029, -7151161412027209546L, -99396L, false, false, (char) 18960, (char) 52635,
        Double.longBitsToDouble(0x3fe4b121669a8bf5L), Double.longBitsToDouble(0x3fd10a356810dc84L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 5, 3, "\ud857\udd8a\ud8b5\udf1d", "\u65ae\u260b\u41a7\u92d9\u18c3\uc0c3\u9d29\u1a04", "\udb31\udf6b\udab0\udcc9\ud833\udefe",
        42, 55727, -30996133, -6134216226550978195L, 41198L, false, false, (char) 19962, (char) 26145,
        Double.longBitsToDouble(0x3fede8ace066abf4L), Double.longBitsToDouble(0x3fea29a17a1a5af0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:                                                       |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 0, 6, "\ud857\udd8a\udaf4\udd9c\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\uda5a\udc75\udb5d\udc38\uda64\udf09\udb6d\ude57\ud834\udfc2\udb1d\udfe2\udb82\udc1c\ud9f3\udc70\ud865\udd94\ud857\udf84\ud9cb\uddcb\udbb3\udc1f\ud99a\udeba", "\u4a0f\u8289\u458a\u7cac\u027c\u70ce\u9339\u46e7\uc1a4\u8b20\ub60b\u3dc8", "\ud8eb\udd95\ud861\udc1e\udb7b\udd8c\udaa0\uddd7\ud86d\udf0f\ud89e\ude68\ucaaa\udbda\ude41\ud86c\ude77\uda95\udf83\ud803\udec1\ud905\ude7c\ud80f\udfc5\ud976\udeb3\ud803\udd9c\udb25\ude0f\ud8ec\udfbb",
        54, 24431, -2037542379, -5435660800765126637L, -63030L, true, true, (char) 41471, (char) 18141,
        Double.longBitsToDouble(0x3fe95fe01367c805L), Double.longBitsToDouble(0x3fe08dab150ccebdL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa4\udfa6\ud854\udd76\ud8c8\udf03\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u382d", "\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\udb04\udf38\ud885\udf1e\ud81f\udd01\u794e",
        43, 63390, 658413381, 6002262712197822873L, -72783L, true, true, (char) 18976, (char) 31795,
        Double.longBitsToDouble(0x3fecf6bc3e68a333L), Double.longBitsToDouble(0x3fe5d2270b7032bdL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 7, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\udb6f\ude50\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\ucc06", "\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc3c\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf47\ud878\ude7d\ud8c7\udff9\udb84\udc39\udb62\ude0a\udadd\udcd8\ud939\udc33\ud9fd\udde6\ud9a1\udcd1\udbda\ude25\ud86c\ude77\ud9c2\uddb6\udbcd\udfa6\ud8fe\udea6\u9803\uda40\udef7\ud858\udd25\ud843\udff9\uda8a\udde7\udaed\udcf4\udbeb\udfe2\ud9d2\udda7\ud82b\udd6c\uda3e\ude74\udadf\udda1\ud9b4\udf97\uafac\udb5b\udd1f\u5746\udaa4\udd01\ud94d\udfe0\u2184\udab2\udc8c\udb91\udfbf\ud809\udc6f\udafd\udd02\ud946\udfd0\ud9ee\udd5a\ud85f\udcd1\ud94d\udc88\uda81\udcca\ud961\udc66\ud99b\udcfd\uda0d\udd20\u50b0\ud863\udda1\ud89c\udcdf\ud83d\udd1b\udac9\udedf\ud827\udc7f\ud8dd\udc68\uda1e\udcf2\udaeb\udc1b\ud86f\udd19\ud905\uddeb\uda97\udf66\ud84f\ude6c\uda8c\ude4b\ud8e3\udf06",
        31, 67964, 1342809464, -3073636075308260268L, -85683L, true, false, (char) 46632, (char) 54007,
        Double.longBitsToDouble(0x3faaf0a708ea8630L), Double.longBitsToDouble(0x3fc9491732cc085cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 11, "", "\u2b14", "\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2",
        27, -1000, 0, 1030768598938065798L, -88746L, false, false, (char) 34358, (char) 46834,
        Double.longBitsToDouble(0x3fddde8a05eb51faL), Double.longBitsToDouble(0x3fe5fdf577eaf420L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 11, "\ud857\udd8a\ud86f\udc79\ud8e3\uddbc\udaaf\udfa2\ud877\ude7c\ud8c8\udf2b\udb92\uded4\uda70\ude79\udb62\udcdd\ud80a\ude2e\udb1e\udc56\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u7c53", "\uda3f\udfd0\udb7d\ude37\ud8b2\udf3d\ud9bb\udfd2\ud8b1\udcce\udb27\ude13\udbe0\udd33\u8039",
        0, 12014, -1425414456, -2499798867560688508L, -72783L, true, true, (char) 18976, (char) 31795,
        Double.longBitsToDouble(0x3fe877443e880ae7L), Double.longBitsToDouble(0x3fe5d2270ff064f2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 11, "\ud857\ude31\ud8b5\udf1d\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d", "\u0566\u038c\u5f0f\u382d", "\ud832\udf28\uda1f\udf1b\udb7a\ude0b\uda4e\udf86\ud992\udf3f\ud9d5\udf22\udb73\udf2b\uc4b9\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a\ud8c7\udff9\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud940\udfaa\ud9a1\udca3\udbda\ude25\ud86c\ude77\ud9c2\uddb7\udb42\udde1\udb9f\udf56\ud9d6\udc6e\udb64\ude03\ud97c\ude18\ud87a\ude90\udb67\uded3\ud996\ude55\uda49\udde3\ud95e\udc32\udb83\udfeb\uda1f\udebc\udbcb\udc25\udaec\udc21\udaf6\udee8\ud81e\udfcf\uda25\udf48\ud87d\udfd1\ud8f2\udefa\ud8bf\udf55\udaf3\udf39\ud81b\ude07\ud907\ude3a\uda20\ude67\ud8ad\udf9a\ud85d\udd33\ud975\udce0\ua3f7\udb88\udfd5\ud9d1\udc38\ud847\udf97\ud92d\udd6c\ud967\udf0a\ud818\udca2\uda31\udeeb\ud907\udea7\ud8ec\udd15\uda22\udee6\ud8b9\udc17\uda36\ude97\ud95a\udfac",
        7, 12430, -1856657591, 3720155329408727604L, -34563L, false, true, (char) 13689, (char) 24457,
        Double.longBitsToDouble(0x3fe4a50ed81ff176L), Double.longBitsToDouble(0x3fecacc2d7f15ef5L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a\ud8b5\udf1d", "\ua498\u4994\ub73e\u747d", "\ud840\uddda",
        49, 47501, -1657607124, 1030768598938065798L, -88746L, false, false, (char) 34358, (char) 46834,
        Double.longBitsToDouble(0x3fddde8a05eb51faL), Double.longBitsToDouble(0x3fe5fdf572bc131aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 2, 11, "\ud857\udd8a\udaa9\udd72\udb7d\udee3\udaa2\udc2f\ud877\ude7c", "\u4a92\ua7d2\u9055\u9d29\u3e2a\uce73\u6712\u3788\u5c68\ub3c2\u012b\u382d\ua961\u7d24\u82bd\uabf6\u7cac", "\ud885\udf1e\ud81f\udd01\u794e\u6ac9\ud90c\udfe1\ud808\udd95\ud87a\ude61\ud903\udc29\ud8c7\udff9\udb84\udc39",
        30, 45953, -1528702471, 3606905283869644709L, 84728L, false, false, (char) 44589, (char) 23424,
        Double.longBitsToDouble(0x3fedf6e0317a48feL), Double.longBitsToDouble(0x3feaaf3b7e66b435L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 2, "\udbe9\udea3\ud8c1\udf03\udaf0\udc46\udb3b\udf1d\udaba\udfe5\ud8c8\udf2b\udb5d\udc55\udaf2\udd6f\ud8aa\udf73\uf647\ud916\udd8f", "\ucadb\u3788", "\udbb2\uddd9\udb66\udcd2",
        48, 172, 658172176, -233031028283389628L, -69942L, true, false, (char) 24733, (char) 10822,
        Double.longBitsToDouble(0x3feb60ab2a66abf4L), Double.longBitsToDouble(0x3fda21abca83a28aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 11, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb38\udfef\uda29\udc6f\ud88e\udd7e", "\u05b6\ua865\u012b\u382d", "\ud92f\udebc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e",
        43, 63390, 658413381, -5152027200523822311L, -72783L, true, true, (char) 45826, (char) 26362,
        Double.longBitsToDouble(0x3fd0a5577f729aceL), Double.longBitsToDouble(0x3fc2e15faa354fa0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 7, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u382d", "\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\udbf9\udcd8\u794e",
        45, 63390, 658413381, 6002263176054290841L, -72783L, true, true, (char) 18976, (char) 31795,
        Double.longBitsToDouble(0x3fecf6bc3e68a333L), Double.longBitsToDouble(0x3fe5d2270b7032bdL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 5, 11, "\ud857\udd8a\uda36\udd70\udb7d\udfa1\udaa2\udc2f\ud85a\udfd8\ud8c8\udf2b\ud9db\udc82\udb3e\ude26\ud9cd\udefe\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u6e33\u388a", "\udaa1\udcb0\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud919\udddc\udb04\udca6\ud8a8\udf10\u794e\u6aa0\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a",
        12, 94143, 1700472390, -5185778076320933383L, -37809L, false, true, (char) 28470, (char) 23307,
        Double.longBitsToDouble(0x3feb8195eff2cd72L), Double.longBitsToDouble(0x3fd4665239cfa05eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\u4159\ud8b5\udf1d\u65ae\u260b\u7bb0\u3689\ua7d2\u9055\u9d29\u32e8 |a0=java.lang.StringBuffer:\u4159\ud8b5\udf1d\u65ae\u260b\u7bb0\u3689\ua7d2\u9055\u9d29\u32e8 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 0, 8, "\u4159\ud8b5\udf1d", "\u65ae\u260b\u7bb0\u3689\ua7d2\u9055\u9d29\u32e8", "\udb31\udf6b\ud9ff\udfb4\ud8d5\uddfa\ud998\udefb\ud9ec\udf62\ud972\udf84\ud997\udedc\ud8be\udffe\udaa7\udca9\udb4d\uddf5\uda56\udc86\udb0a\ude33\ud975\udcaf",
        53, 73592, -1410068547, 3760382982297130821L, -72783L, true, false, (char) 62009, (char) 21903,
        Double.longBitsToDouble(0x3fb6114064079c18L), Double.longBitsToDouble(0x3fe5d239db7032bdL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 4, 0, 0, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\ua17b\ua865\u012b\u382d", "\ud939\udc7b\uda1f\udf1b\udb7a\ude0b\uda39\udd86\ud992\udf3f\ud885\udf1e\ud81f\udd01\ud8a6\udc11",
        -5, -1000, 658413381, 6002263176054290841L, -72783L, true, true, (char) 18976, (char) 58675,
        Double.longBitsToDouble(0x3fecf6b80668a333L), Double.longBitsToDouble(0x3fe5d2270b7032bdL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 0, 0, "\ud93a\udc89", "\u2d16\u65ae\u260b\u9b3e\u747d\ua7d2\u9055", "\u710a",
        21, 95305, 1498717062, 837518622720L, -100000L, false, false, (char) 0, (char) 62450,
        Double.longBitsToDouble(0x3fc7f7d5dfabd000L), Double.longBitsToDouble(0x3fbcb1a073e17c68L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 5, "\ud951\udfa3", "\u61af\u3703\u1c2a\u5339\u1437\u240b\u40fe", "\udb93\udf79\ud98d\udd13\udb77\udc1a",
        51, 21732, 953716813, -2700694138355340383L, 33605L, true, false, (char) 16749, (char) 33802,
        Double.longBitsToDouble(0x3fe396340e7c2f31L), Double.longBitsToDouble(0x3fe9d855f8081e19L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:                             |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 3, 13, 10, "\ud857\udd8a\ud88f\udd73\ud867\ude37\udaa2\udc2f\ud877\ude7c\ud8a3\ude6d\ud955\udcc4\uda64\udf09\ud89f\ude1f\ud8f0\ude60\ueda5\uda17\udcc4\ud9bc\udc3f\ud995\udf02\udbfc\uddb3\ud972\ude69\ud948\udfa1\ud998\udefb\udb2c\udf82\ud984\udf84\ud9c3\ude42\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\udb2d\udd6d\ud95b\udca5\ud81f\udd77\ub89a\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a\ud8c7\udff9\ud88d\udf3d\ud82a\ude24", "\ucea4", "\ud86c\ude77\ud9c2\uddb7\ud8e2\udff2\ud93d\ude89\udb85\ude69\ud9ef\ude21\ud8f8\uddc6\udb7c\uddd2\ud865\ude49\ud8af\udf53\ud85d\udd5b\ud96b\udf60\udbbe\udea5\ud962\udcac\uda3e\uddac\udaf7\udfb4\udb10\udf56\ud9bb\ude1f\ud97f\udf30\udabc\udfc2\ud8d0\udfa1\ud932\udd14\ud802\udfdf",
        28, 86328, 62853550, 6972820969962090450L, -80493L, true, false, (char) 18251, (char) 21783,
        Double.longBitsToDouble(0x3fd1f129ec409ea4L), Double.longBitsToDouble(0x3fe0156d8928662bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 15, 0, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\uda96\udc48\ud877\ude36\ud8c8\udf2b\uda71\udfad\udb37\ude92\uda5a\udfa3\ud80a\ude8c\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u382d", "\uda0d\udddc",
        -3, 76031, -964587542, 3426632877052591740L, -16024L, true, true, (char) 44300, (char) 63389,
        Double.longBitsToDouble(0x3fe479580199534cL), Double.longBitsToDouble(0x3fea0630fc077136L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud893\udf1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd6f\u0566\ua865\u012b\u382d |a0=java.lang.StringBuffer:\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud893\udf1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd6f\u0566\ua865\u012b\u382d |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud893\udf1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd6f", "\u0566\ua865\u012b\u382d", "\ud939\udcbc\uda1f\udf1b\uda8b\udf94\uda5d\udc7a\ud8c0\ude0b\ud885\udeaa\ud81f\udd01\udb66\udd51",
        43, 7030, 721455761, 6002263176054290841L, -1871L, true, true, (char) 18976, (char) 5880,
        Double.longBitsToDouble(0x3fc303c19119233cL), Double.longBitsToDouble(0x3fd905993d6c1e54L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 2, 11, "\udbab\udd54\ud890\udcc3\udb7d\udf2b\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\u79ac\udbca\uddd9", "\ud748\u00c3\u012b\u382d\ua961\u7d24\u82bd\u55af", "\ud992\udf3f\uda5b\udf2d\ud847\udd48\u79b7\u6ac9\ud90c\udf79\ud808\udd95",
        4, 92337, 1909680452, -4647859922554640706L, 40807L, true, true, (char) 31795, (char) 1830,
        Double.longBitsToDouble(0x3fe345199e000000L), Double.longBitsToDouble(0x3feb8195ed57c903L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:                                                            |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 6, 11, "\uda33\udcce\ud8e2\udd24\udb94\udd41\udaa2\udc5a\ud897\udd90\ud88b\udf44\udb5d\udc55\uda64\udf09\ud85b\udd7e\u6425", "\uce73\u6712\u3788", "\u693d\udb56\udf6a\ud972\udf84\ud96d\udf77",
        59, 76197, -199195969, -4142871946221201294L, -17253L, false, false, (char) 41408, (char) 15450,
        Double.longBitsToDouble(0x3fea29a17a8f273eL), Double.longBitsToDouble(0x3fd99534c289523eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 11, "\ud857\udd8a\ud8c7\udc11\udba5\udcb0\udaa2\udc2f\uda41\udc31\uda00\udc7e\udb5d\udc55\uda64\udf09\udae1\ude20\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\u00c3\ud998\udefb\ud9ea\ude51\ud8f6\udcb8\ud845\ude69\udae4\ude6e\ud977\ude9b\udb7a\ude0b\uda5d\udc86\uda7f\ude44\u8eb9\ud81c\udf37\ud8eb\udffe\ud9c3\udcbd\udb89\ude39\udbee\uddee\udaa7\udf28\ud931\udc7a\ud8c7\udfd5\udacd\ude5e\ud97c\uddb4\ud8df\ude7e\udb23\udf31\udab1\udf2c\udb56\uddd0\uda02\udfa1\u2ebc\ud9c2\udcfd\ud842\udd21\udb6c\udd2a\ud960\udd02", "\u5963\u2060\uadf2\ucffc\u8cd0\u3ce9\u1b4b\uad32\u7ec3\u00e0\u19ae\u92e1\u2b9e\u4fa1\u638e\ua66c\u07a6\u1843\ua2b9\u7398\u176f\u30af\u5562\u944f\u5b67\ub60c\ub45f\ubbdd\ubb14\u0848\u93cf\u3239\ua036\u4975\u1cc4\ud1b9\u91d0", "\ud800\ude88\ud815\udcad\ud946\udef7\ud845\udc4d\ud868\udd6e\ud9e9\ude6b\ud8e1\udf00\ud995\udccd\udbec\udcba",
        24, 6690, 886384655, 458170868773937184L, -42032L, true, true, (char) 34386, (char) 45434,
        Double.longBitsToDouble(0x3febe2012efa3f92L), Double.longBitsToDouble(0x3fed24459d5ec867L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 2, 0, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda64\udf09\ud89f\ude1f\u216d\000\ud97a\udcbc\000", "\u0566\u00c3\u012b", "\ud96d\ude9f\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86r\ud885\udf1e\ud9d4\udf3c\u3146\u6ac9",
        0, 94381, 1397510799, -6260080888330884796L, -44382L, true, false, (char) 37377, (char) 18976,
        Double.longBitsToDouble(0x3fe837296f9ed787L), Double.longBitsToDouble(0x3fe345199e000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 9, 11, "\uda52\udc61\ud9ad\ude33\udbdf\udee9\ud8d9\udc1f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda2d\udd8e\uda72\udd01", "\ud646\u87c1\u6746\uc2c1\u04ee\u00c3\u012b\u9a69\u6df9\uadb6\ud209\u46e1\u1924\u83c5\u70ce\u9339\u9c13\uc043\u2420\u2006\ub9b1\u58b5", "\ud951\udce8\ud98f\udcfa\udb79\ude23\udaf1\uddc1",
        3, 56381, 956072056, -6222493844599185572L, -86647L, true, true, (char) 33945, (char) 26441,
        Double.longBitsToDouble(0x3fe9e9bdb3cd4fe5L), Double.longBitsToDouble(0x3fed418b487fd5b3L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 11, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u4081\u3873\u52df\u382d", "\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e",
        8, 26265, 2037085800, -5502090915677750887L, -72783L, true, true, (char) 10396, (char) 31795,
        Double.longBitsToDouble(0x3fecf6bc3e68a333L), Double.longBitsToDouble(0x3fe00000037032bdL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 1, 14, 2, 11, "\u9c8b\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\udb17\udc82\u64e2\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\u00c3\u012b\u382d", "\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\ud971\udf39\ud885\udf1e\ud81f\udd01\u794e\u6ac9",
        0, 94381, 1397510799, -6260080888330884796L, -44382L, true, false, (char) 37377, (char) 18976,
        Double.longBitsToDouble(0x3fe837296f9ed787L), Double.longBitsToDouble(0x3fe345199e000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 2, 13, "\u2386\ud8bc\udd1f\udb7d\udfa1\udaa2\udc2f\ud9e2\uddf2\ud88b\udf44\ud8fe\udf46\ud91d\udd1b\ud9cc\udeae\ud834\udfc2\udba3\udfc5\ud9ba\udc18\ud88e\udd7e\ud995\ude59\uda3d\udd6d\udab0\udcc9\u00c3\ud998\udefb\ud95d\ude40\ud32f\ud979\udc90\ud939\udcbc\uda1f\udf1b\u847d\ud9e4\udd5b\ud96d\udfd4\ud885\udf1e\ud81f\udd01\u794e\u6ac9\ud90c\udf79", "\ubfb4\u3942\uc998\u9ede\u3505\u95fa\ucd74\ucea0\u39a1\u52cf\ua5cf\u84b1\u98b5\ud56c\u6e50\ua1ec", "\uda88\udd29\uda97\uddb0\ud83b\ude22\udab4\udfac\uda2e\udc06\ud91d\udce6\udaeb\udfa4\udae4\udee9\udb61\udc81\ud9bc\udd0c\ud873\udc50\udb58\udfca\ud936\udd09",
        11, 69679, 1245208544, 1064357685479729480L, -66145L, true, false, (char) 11769, (char) 48483,
        Double.longBitsToDouble(0x3fee02622ccbf5baL), Double.longBitsToDouble(0x3fae02e37da58e10L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\uda7a\udf41\ud84c\ude7b\ud88b\udf44\udb46\udd55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udbbf\udf1e", "\u0566\u00c3\u012b\u382d\ua961\u7d24\u82bd\u458a\u7cac\u83c5\u70ce\ubf5b\u46e7\u6720\u2420\ub63f\u3dc8\u9d48\u92a1\u82bb", "\ud8df\ude13\ud939\udc9a\ud940\udfaa\ud9a1\udca3\udbda\ude25\u2e68\ud9c2\udcfd\uda4e\udf27\ud9ff\ude0b\ud833\udc7f\udbfc\udd7f\uda0e\uddb6\udafe\udd68\ud8f7\ude60\udbff\udd72\ud9c4\udd90\uda07\uddfe\ud88c\udc25\uda6c\udf77\udaaf\udfa3",
        13, 48738, -574740616, 7168648455535144051L, -20324L, false, false, (char) 10471, (char) 16864,
        Double.longBitsToDouble(0x3fe3643a8c0fb66eL), Double.longBitsToDouble(0x3fef4af2b3892547L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 5, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\u00c3\ud998\udefb\ud9ea\ude51\ud972\udf84\ud96d\udf77\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86", "\u46e7\uc1a4\u2420\ub63f\u3dc8\u9d48\u92a1\u302c\u3794\u9ede\u3505\u95fa\ucd74\ua70e\u39a1\u2e68\ua222\ucbae\u7a93\ud5ad\u4278", "\ud89a\udd40\u17fb\uf4a9\udb63\ude33\ud9c2\udf2d",
        6, 86743, 660706966, 8751858244637353826L, -28231L, false, false, (char) 10461, (char) 52948,
        Double.longBitsToDouble(0x3fead065144a8e83L), Double.longBitsToDouble(0x3fb049f4be3c0ba8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 2, 11, "\ud846\ude05\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\u00c3\ud998\udefb\ud9ea\ude51\ud972\udf84\udae9\uddd4\uda17\udc38\uda1f\udf1b\udb7a\ude0b\uda5d\udc86", "\u46e7\uc1a4\u2420\ub63f\u3dc8\u9d48\u92a1\u302c\u3794\u9ede\u3505\u95fa\ucd74\ua70e\u39a1\u2e68\ua222\ud4d6\u2bea#\u3147", "\ud90b\udda1\udb12\ude37\udae9\udf63\uda3c\uddba\uda1a\uddb5\udb71\udcc4\udbbc\udff3\uda9e\udff7\ud992\ude33\udaca\udcec\udabc\udd56",
        19, 22398, -798352497, 5371039485133033062L, -51700L, true, false, (char) 57115, (char) 18261,
        Double.longBitsToDouble(0x3fd5a6623bdef61eL), Double.longBitsToDouble(0x3fc554780d8ffd98L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 5, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud88b\udf44\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\u00c3\u012b\u382d\ua961\uc20e\u614d\u6546\u353d\u985f\u70ce\u9339\u46e7\u6fa9\u77b8", "\udaa7\udf77\ud931\udc7a\ud8c7\udff9\udb84\udc39",
        30, 45953, -1528702471, -1932706975749531898L, 62672L, true, true, (char) 51217, (char) 31226,
        Double.longBitsToDouble(0x3fdda07b0b7459b4L), Double.longBitsToDouble(0x3feee95a15bf423eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 13, 11, "\ud857\udd8a", "\uc237\u65ae\u260b\ucaac\u747d\000\000", "\ud88e\udd7e\ud980\udf59\uda4b\ude98",
        19, -805, 0, -8791026472650348967L, 36739L, true, false, (char) 16749, (char) 33802,
        Double.longBitsToDouble(0x3fe800040f5b3d04L), Double.longBitsToDouble(0x3fe72a9898a69ca3L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 2, 11, "\ud857\udd8a\ud8b5\udf1d\ud9c9\udd9e\ud92b\udc16\ud9a8\udd3f\ud8c8\ude7c\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\uddd2", "\u0566\ua865\u012b\u382d\u2c0c\u7cc4\u82bd\u8b92\u7cac\ubcc6\u70ce\u9339", "\udb6b\udf70\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a\ud8c7\udff9\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud8bc\udd07\ud9a1\udcd1\udbda\ude25\ud86c\ude77\ud9c2\uddb7\u27e6\uda3f\udfac\ud80a\udcf8\uda90\ude84\udbb3\udc15\uac27",
        3, 32421, 101010029, -7151161412027209546L, -99396L, false, false, (char) 18960, (char) 52635,
        Double.longBitsToDouble(0x3fd15899bd351684L), Double.longBitsToDouble(0x3fd10a356c10dc84L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 0, 0, "\ud857\udd8a\000", "", "\udb57\udebd",
        17, 41324, -322818304, -8934984272163372964L, -100000L, false, false, (char) 43475, (char) 0,
        Double.longBitsToDouble(0x3fefb2c007872ee3L), Double.longBitsToDouble(0x3fd5bb2bd401fc4eL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 5, 3, "", "\u2a83", "\000",
        -5, -1000, 1867972608, -1386493433231405275L, 29256L, false, false, (char) 41926, (char) 43475,
        Double.longBitsToDouble(0x3fdc359547ecb184L), Double.longBitsToDouble(0x3fec3977195bb2bdL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 0, 1, "\ud857\udd8a\udaf4\udd9c\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\uda5a\udc75\udb5d\udc38\uda64\udf09\udb66\udc08\udae7\ude3b\udb6d\udef7\ud96a\udf29\uda2f\udd12\ud9cf\uddaa\ud857\udf84\ud9cb\uddcb\udbb3\udc1f\ud99a\udeba", "\u4a0f\u8289\u458a\u7cac\u55bf\u7070\u195a\u091e\uc1a4\u8b20\ub60b\u3dc8", "\uda52\udef9\ud861\udc1e\udb7b\udd8c\udaa1\udfd7\u5985\ud89e\ude68\ucaaa\ud8d8\udefc\ud80b\ude1a\uda95\udef4\ud803\udec1\ud80f\ude80\ud9ad\ude68\ud976\udeb3\ud803\udd9c\udac7\ude00\ud85b\udf67",
        2, 8370, -1079773261, -5435651733652957165L, -63030L, true, true, (char) 41471, (char) 18141,
        Double.longBitsToDouble(0x3fe95fe01367c805L), Double.longBitsToDouble(0x3fe08dab150ccebdL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:            |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 1, "\ud857\udd8a\udaf4\udd9c\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\uda50\uddd0\uda32\udfce\uda44\ude87\udb6d\ude57\ud834\udfc2\udb1d\udfe2\uda42\udc9a\udb6e\udf78\udb57\udd1f\ud927\udca8\ud877\udc76\udbb3\udc1f\ud99a\udeba", "\u4a0f\u8289", "\udbce\udf82\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e\udb6b\udcea\ud90c\udf45\ud808\udd95\udaa7\udf77\ud8e5\uddf3\ud8eb\udd95",
        11, 28045, -2051004148, 693315191095922540L, -46682L, false, false, (char) 61807, (char) 42998,
        Double.longBitsToDouble(0x3fdad100b10b93baL), Double.longBitsToDouble(0x3fc44f60ec7d9bdcL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 0, "\u6d4d", "", "\000",
        8, 15891, 1812889537, 2851941216067518464L, -100000L, false, false, (char) 41778, (char) 3662,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc0cee000036a54L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa4\udfa6\ud854\udd76\ud8c8\udf03\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\ud8fd\udf43\udb22\udf00\ud9ea\ude51\ud972\udf84\ud96d\udf77\ud939\udcbc\uda1f\udf1b\udb7a\ude25\uda5d\udc86\ud8d8\udcb0\ud862\udc2e\ud81f\udd01\u794e\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf0b\ud931\udc7a\ud8c7\udff9\udb84\udc39\ud83f\udcb7", "\ucd74", "\ud86c\ude77\ud9c2\uddb7\ud8ec\uddf6\ud850\udd6c\udb79\udc08\u82be\ud866\udfd3\udbc0\ude25\uda1f\udc38\udb34\ude3d\udbbd\ude09\u3bd0\udb7c\ude6b\ud96d\udeef\ud82d\udd55\ud96a\udd9d\udba2\udc1e\udb7e\udce1\ud875\udcf5\ud812\udd5c\udaf7\uddef",
        46, 45999, -1548509952, -4089679119538943633L, -43367L, false, false, (char) 5511, (char) 13526,
        Double.longBitsToDouble(0x3fab709ea4c48f50L), Double.longBitsToDouble(0x3fc50e96dec70ee0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 13, 5, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa4\udfa6\ud854\udd76\udb54\udd93\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865", "\ud972\udf84\ud96d\udf77\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\udb04\udf38\ud885\udf1e\ud81f\udd01\udb55\udc69\u6a21\ud90c\udf79\ud808\udd95\udaa7\udf0b\ud931\udc7a",
        12, 49783, 1700472510, -5185778076320933383L, -73126L, false, true, (char) 53659, (char) 23451,
        Double.longBitsToDouble(0x3feb8195eab892e0L), Double.longBitsToDouble(0x3fdf856575b946f6L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 11, "\uda34\udf4b\uda61\udf7c\ud949\udf47\udaa4\udf66\ud854\udd76\ud8c8\udf03\uda8f\udc52\ud907\ude9c\ud8b5\udcbc\ud840\udfc3\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\u0566\u97b3\u3652\ub514", "\ud95c\udd34\u3c2c\udb7a\ude0b\uda5d\udc86\udae4\udd28\ud885\udf1e\ud81f\udd01\u794e",
        16, 94175, 1737429222, 6216378714453640450L, -72319L, false, true, (char) 53128, (char) 46935,
        Double.longBitsToDouble(0x3fee82dab3db3bc6L), Double.longBitsToDouble(0x3fd8bc95592e4bd8L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa4\udfa6\ud854\udd76\ud8c8\udf03\ud85e\udf4e\uda64\udf03\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\ud8fd\udf43\ud998\udefb\ud9ea\ude51\ud972\udf84\ud96d\udf77\ud939\udcbc\uda5c\udd14\udb7a\ude0b\uda5d\udc86\udb04\udf38\ud885\udf1e\uda96\uddfd\u7a1b\udbb5\udcf7\ud90c\udf79\ud808\udd95\udaa7\udf0b\ud931\udc7a\ud8c7\udff9", "\u3505\u95fa\ucd74\ua70e\u39a1\ud00a\ua2dc\ub1a4\ud533\uc6ea\u66ee\u665f\ub6d5", "\ud8b3\udf3e\udb83\udf49\ud807\udcb1\ud9a1\udf75\ud95e\udfe6\uda3a\udd61\u0d6f\udb0e\udcbe\udadf\ude43\ud832\uddab\ud8cb\udfcb\ud85a\udd67\uda70\udeaf\ud878\ude08\udbb3\udcbe\ud82d\udf89\udbe0\ude9e",
        36, 36486, -747862478, -8368067629415555792L, -4419L, true, false, (char) 24546, (char) 46649,
        Double.longBitsToDouble(0x3fd25e24e7272698L), Double.longBitsToDouble(0x3febfa2d74496ed7L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 15, 3, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa4\udfa6\ud854\udd76\ud8f1\udd64\ud9dd\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud850\udf7f", "\u0566\ua865\u012b\u382d", "\ud939\udc51\uda1f\udf1b\udb7a\ude0b\uda5d\udc86\udb04\udf38\ud885\udf1e\ud81f\udd01\ud8ea\uddf4",
        7, 47822, 658413381, 6002262712197822873L, 69110L, true, true, (char) 18815, (char) 31795,
        Double.longBitsToDouble(0x3f9f118705cf3120L), Double.longBitsToDouble(0x3f26abb707507000L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 6, 11, "\udbc4\udd8d\ud8b5\udf1d\udb7d\udfa1\ud8c0\uddfa\ud854\udd76\ud8c8\udf03\udb5d\udc55\uda64\udf09\ud8b5\udee9\ud9e0\udf7e\ud82c\udecb\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\ud8fd\udf43\ud998\udefb\ud9ea\ude51\ud972\udf84\ud96d\udf77\uda92\udc88\ue180\uda28\ude33", "\u9339\u46e7\uc1a4\u2420\ub63f\u3dc8\ubfea\u26cf\u302c\u3794", "\ud939\udc9a\ud940\udfaa\ud9a1\udca3\udbda\ude25",
        8, 23922, -106136720, -7348695201572560911L, -94189L, false, true, (char) 4450, (char) 5202,
        Double.longBitsToDouble(0x3fc955e251e26ee4L), Double.longBitsToDouble(0x3fd0dcd430b9db58L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 2, 0, "", "\u6b14", "\ud8c8\udf03",
        25, 15891, 1812889537, 2851941214001073957L, -98184L, false, false, (char) 41926, (char) 3796,
        Double.longBitsToDouble(0x3fdc359007ecbab0L), Double.longBitsToDouble(0x3fc0cee48e876a54L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 11, "", "", "\000",
        -5, 62890, 140810891, 140467559727104L, 30816L, false, false, (char) 0, (char) 1684,
        Double.longBitsToDouble(0x3fe8007271c30054L), Double.longBitsToDouble(0x3fefb2eac0000000L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 11, "\uda78\udc9a\ud86f\udc79\ud8e3\uddbc\udaaf\udfa2\ud877\ude7c\ud8c8\udf2b\udb92\uded4\uda70\ude79\udb62\udcdd\udb2a\udf7e\udb1e\udc56\ud9ba\udc18\ud88e\udd7e", "\u0566\ua865\u012b\u7c53", "\uda3f\udfd0\ud8f6\ude3e\ud94e\udd28\ud9bb\udfd2\ud8b1\udcce\udb27\ude13\udbe0\udd33\u8039\ud888\udfbe\udbc1\udd64\ud8b6\uddbd\uda65\udc21",
        1, 72452, -1082164217, 7303473816989624913L, 54305L, false, true, (char) 57237, (char) 14703,
        Double.longBitsToDouble(0x3fe5d2270ff064f2L), Double.longBitsToDouble(0x3f9e5959d12ea8a0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud857\udd8a\ud86f\udc79\u91f2 |a0=java.lang.StringBuffer:\ud857\udd8a\ud86f\udc79\u91f2 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 7, "\ud857\udd8a\ud86f\udc79", "\u91f2", "\ud9fb\udc39\udb62\udcdd\ud80a\ude2e\ud9ad\udc5c",
        41, 67363, -1741493204, 1030768873815972742L, 11327L, false, false, (char) 8620, (char) 44437,
        Double.longBitsToDouble(0x3fddde88ee13112eL), Double.longBitsToDouble(0x3fca5e4478ba852cL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 11, "\ud857\udd8a\ud86f\udc60\ud983\udd6b\udaaf\udfa2\ud877\ude7c\ud8c8\udf2b\udb92\uded4\uda70\ude79\udb62\udcdd\ud80a\ude2e\udb1e\udc56\ud8fb\udd11\ud940\udef7", "\u0566\ua865\u012b\u7c53", "\ud995\udd53\udb7d\ude37\ud8b2\udf3d\uda50\udc6a\ud8b1\udcce\udb27\ude13\ud853\udf28\ud96d\uddbf",
        3, 12014, 1329587912, -2499798764481473404L, -72783L, true, true, (char) 38851, (char) 31795,
        Double.longBitsToDouble(0x3fe877443e880ae7L), Double.longBitsToDouble(0x3fe5d2270ff064f2L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\000\ud86f\udc4b\ud8e3\uddbc\000\000\000\udb92\ude3a\u550d\udbd2\udd29\ud80a\ude2e\udb1e\udc56\ud9ba\udc18\ud88e\udd7e |a0=java.lang.StringBuffer:\000\ud86f\udc4b\ud8e3\uddbc\000\000\000\udb92\ude3a\u550d\udbd2\udd29\ud80a\ude2e\udb1e\udc56\ud9ba\udc18\ud88e\udd7e |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 0, 1, 11, "\000\ud86f\udc4b\ud8e3\uddbc\000\000\000\udb92\ude3a\u550d\udbd2\udd29\ud80a\ude2e\udb1e\udc56\ud9ba\udc18\ud88e\udd7e", "", "\ud998\udefb\uda89\ude80\ud972\udf84",
        20, -1000, -232554743, -6824236762636827090L, -34464L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fef83279247bd7bL), Double.longBitsToDouble(0x3feb29ecf40166e1L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 11, "\ud857\ude31\ud8b5\udf1d\udb7d\udfa1\ud9e5\udcae\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d", "\u0566\u038c\u5f0f\u382d", "\ud832\udf28\uda1f\udf1b\udb7a\ude0b\uda4e\udf86\ud8ed\udd86\u21dd\udb73\udf01\uc4b9\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a\ud8c7\udff9\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud940\udfaa\ud9a1\udca3\udbda\ude25\ud86c\ude77\ud9c2\uddb7\udb42\udde1\udb9f\udf56\ud9d6\udc6e\udb64\ude03\ud97c\ude18\ud87a\ude90\udb2e\udf9a\ud98f\udee2\uda49\udde3\ud95e\udc32\udb83\udfeb\uda1f\udebc\udbcb\udc25\udaec\udc21\udaf6\udee8\ud81e\udfcf\uda25\udf48\ud87d\udfd1\ud8f2\udefa\ud8bf\udf55\udaf3\udf39\ud81b\ude07\ud83b\udef3\udae2\udf46\uda78\udf79\ud85d\udd33\ud8a5\udf78\ud872\udfa9\udb88\udfc2\ud9d1\udc38\ud847\udf97\ud84d\udd1d\ud872\udde1\ud817\udfee\uda31\udeeb\ud907\udea7\ud8ec\udd15\uda22\udee6\ud8b9\udc17\uda36\ude97\ud95a\udfac",
        7, 12430, -1856681911, 3720155329408727604L, -34563L, false, true, (char) 13689, (char) 24457,
        Double.longBitsToDouble(0x3fe4a50ed81ff176L), Double.longBitsToDouble(0x3fecacc2d7f15ef5L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 11, "\ud857\ude31\ud8b5\udf1d\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d", "\u0566\u038c\u5f0f\u0c17", "\ud832\udf28\uda1f\udf1b\udb7a\ude0b\uda4e\udf86\ud992\udf3f\ud9d5\udf22\udb73\udf2b\uc4b9\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a\ud8c7\udff9\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud940\udfaa\ud9a1\udca3\udbda\ude25\ud86c\ude77\ud9c2\uddb7\udb42\udde1\udb9f\udf56\ud9d6\udc6e\udb64\ude03\ud97c\ude18\ud87a\ude90\udb67\uded3\ud996\ude55\uda49\udde3\ud95e\udc32\udb83\udfeb\uda1f\udebc\udbcb\udc25\udaec\udc21\udaf6\udee8\ud81e\udfcf\uda25\udf48\udbb9\udef9\ud8f2\udefa\ud8bf\udf55\udaf3\udf39\ud81b\ude07\ud907\ude3a\uda20\ude67\ud897\ude9a\ud85d\udd33\ud975\udce0\ua3f7\udb88\udfd5\ud9d1\udc38\ud847\udf97\ud92d\udd6c\ud967\udf0a\udbfa\udc93\uda31\udeeb\ud907\udea7\ud8ec\udd15\uda22\udee6\ud8b9\udc17\uda36\ude97\ud95a\udfac",
        7, 12430, -1856657591, 3720155329408727604L, -38224L, false, true, (char) 13689, (char) 24457,
        Double.longBitsToDouble(0x3fe4a50ed81ff176L), Double.longBitsToDouble(0x3fecacc2d7f15ef5L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud857\ude31\ud8b5\udf1d\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d\u0566\u038c\u5f0f\u382d |a0=java.lang.StringBuffer:\ud857\ude31\ud8b5\udf1d\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d\u0566\u038c\u5f0f\u382d |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\ud857\ude31\ud8b5\udf1d\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d\u0566\u038c\u5f0f\u382d |a0=java.lang.StringBuffer:\ud857\ude31\ud8b5\udf1d\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d\u0566\u038c\u5f0f\u382d |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud857\ude31\ud8b5\udf1d\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d", "\u0566\u038c\u5f0f\u382d", "\ud832\udf28\uda1f\udf1b\udb7a\ude0b\uda4e\udf86\ud992\udf3f\ud9d5\udf22\udb73\udf2b\uc4b9\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf77\000\000\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud940\udfaa\ud9a1\udca3\udbda\ude25\ud86c\ude77\ud9c2\uddb7\udb42\udde1\udb9f\udf56\udbdc\uddf2\udb64\udd75\ud97c\ude18\ud87a\ude90\udb67\uded3\ud996\ude55\uda49\udde3\ud95e\udc32\udb83\udfeb\uda1f\udebc\udbcb\udc25\udaec\udc21\udaf6\udee8\ud81e\udfcf\uda25\udf48\ud87d\udfd1\000\ud8bf\udf0c\udaf3\udf39\ud81b\ude07\ud907\ude3a\uda20\ude67\ud8ad\udf9a\ud85d\udd33\ud975\udce0\ua3d8\udb88\udfd5\ud9d1\udc38\ud847\udf97\ud92d\udd6c\ud967\udf0a\ud818\udca2\uda31\udeeb\ud907\udea7\ud8ec\udd15\uda22\udee6\ud8b9\udc17\uda36\ude97\ud95a\udfac",
        7, 12430, -1856657591, 3720155329408727604L, -34563L, false, true, (char) 13689, (char) 24457,
        Double.longBitsToDouble(0x3fe4a50ed81ff176L), Double.longBitsToDouble(0x3fecacc2d7f15ef5L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 11, "\udb85\udca8\ud8b5\udf04\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d\ud995\ude59\udb31\udf6b\udab0\udcc9\udad9\ude58\ud9b0\udcdf\ud9ea\ude51\ud890\udda4\udb0b\udc09\ud832\udf28\uda1f\udf1b\udb7a\ude0b\uda4e\udf86\ud992\udf3f\ud9d5\udf22\udb73\udf2b\uc4b9\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a\ud8c7\udff9\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud940\udfaa\ud9a1\udca3\udbda\ude25\ud86c\ude77\ud9c2\uddb7\udb42\udde1\udb9f\udf56\ud9d6\udc6e\udb64\ude03\ud97c\ude18\ud87a\ude90\udb67\uded3\ud996\ude55\uda49\udde3\ud95e\udc32\udb83\udfeb\uda1f\udebc\udbcb\udc25\udaec\udc21\udaf6\udee8\ud81e\udfcf\uda25\udf48\ud87d\udfd1\ud8f2\udefa\ud8bf\udf55\udaf3\udf39\ud81b\ude07\ud907\ude3a\uda20\ude67\ud8ad\udf9a\ud85d\udd33\ud975\udce0\ua3f7\udb88\udfd5\ud9d1\udc38\ud847\udf97\ud92d\udd6c\ud967\udf0a\ud818\udca2\ud9f1\uddc1\ud8a8\udd68\ud84e\ude30\uda22\uded6\ud8b9\udc17\ud9f9\udc97\ud95a\udfac\uda0a\udcff\ud812\udd8b\ud99e\udcc3\udb80\udc9a\uda9f\udfc4\ud9cc\udf8f\udbed\udd53\ud875\udf61\udb48\udfbf\udad6\udc52\udac5\uddb8\ud930\ude03\uda36\udd2d\ud86e\udc9a\udaa5\udeb9\udb5f\udef6\udbc6\udec2\ud812\ude7d\uda06\uddb8\ud98d\udc5d\ud98f\udfb2\udb44\udc92\ud92e\ude8e\udaca\udcb9\ud863\udd25\udaf7\udc17\ud925\udf03\ud8d1\udf8a\uda38\udd7f\ud9f9\ude6a\ud8e0\udf43\udacf\udfe9", "\u559a\u2b5b\ua44a\u8def\ubb30\u7f1d", "\udb2f\udeb0\udb54\udc71\udbeb\udc09\ud9c7\udf52\udb7f\udee9\ud8f6\udf5d\u281d",
        14, 30414, -994589891, -7865527077816043970L, 29135L, false, false, (char) 56527, (char) 62825,
        Double.longBitsToDouble(0x3fec4e7cd6ae4e6cL), Double.longBitsToDouble(0x3fe0e9bc760c4325L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 2, 11, "\ud857\udd8a\uda3a\ude7c\udb7d\udf17\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda8a\udd0a\ud88a\udcc2\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\ud8eb\udc68\ud984\udeea\ud998\udefb\ud9ea\ude51\ud972\udf84\ud96d\udf77\ud939\udcbc\ud845\udd20\udb7a\ude0b\uda5d\udc86\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e\u6ac9\ud90c\udfe1\ud808\uddad\ud87a\ude61\ud903\udc29\ud8c7\udff9\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud87c\udc32\ud9a1\udd42\uda65\udeea\ud86c\ude51\ud9c2\uddb7\udbd3\udf6a\udae1\udff2\ud8bf\udeab\ud966\udc07\uda14\udedd\udb10\udc6c\udaae\udfc3\udbf4\udd57\udbcb\udc8e\uda1e\ude4c\udb59\udc13\ud9ff\uddf5\udb63\udcb2\uf74e\ud9d2\udf18\uda06\ude92\ud8aa\udd37\uda9f\ude41\udbd3\udc50\ud902\udeea\ud9de\udc24\udace\udccb\udb1a\udea2\udbcc\udc87\ud9f5\ude4c\udaf8\udf30\udb06\udca7\uda94\udc36\udbbc\udc65\uf6a9\ud913\udd48\udaba\uddc8\udb2d\ude79\udad7\udfc8\udad1\udec2\uda16\uddc4\udb12\udc99", "\uabdb\u0a55\u154d\uaffb\u67eb", "\uda9d\udcde\udbd3\udd9e\udb8c\udf40\ud916\udc90\ud97a\uded4\ud8a2\udd6d\ud96a\udd22\udb23\udd42\ud8f6\udcc8\ud8dd\udce1\udbdb\udf75\ud814\udc5e\udb28\udf46\u0096\ud872\udedc\udb59\ude8d\uda86\udc8e\udb6b\udcab\udb70\udfcc\ud942\uddd5",
        58, 11404, 1883801087, -1350093556845435686L, 57788L, false, false, (char) 5176, (char) 49120,
        Double.longBitsToDouble(0x3fe088711209b718L), Double.longBitsToDouble(0x3fc26b56af2b5ce0L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 0, 8, "\u4159\udbf7\udd5d", "\u65ae\u260b\u7bb0\u3689\ua7d2\u9055\u9d29\u32e8\u1baf\u67a6\u3788\u6ba3\u071c", "\ud972\udf84\ud997\udedc\ud8be\udffe\udaa7\udca9\udb4d\uddf5\uda56\udc86\udb0a\ude33\ud975\udcaf\ud9fc\udf5c\udb4f\udd23\ud817\udfe2\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a",
        12, 49783, 1700472510, -5185778076569707271L, 59207L, false, false, (char) 36867, (char) 54108,
        Double.longBitsToDouble(0x3feb8190935f3d6cL), Double.longBitsToDouble(0x3fdc94df662c3fdcL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 15, 8, "\u4159\ud8b5\udf1d", "\u65ae\u260b\u5ce0\u3689\ua7d2\u9055\u9d29\u32e8", "\udb31\udf6b\ud9ff\udfb4\ud8d5\uddfa\udb70\udf4c\ud9db\ude52\ud972\udf84\ud997\udedc\ud8be\udffe\udaa7\udca9\udb4d\uddf5\uda56\udc86\udb0a\ude33\ud975\udcaf",
        53, 73592, -1410068547, 3760382982297130821L, -72783L, true, false, (char) 62009, (char) 21903,
        Double.longBitsToDouble(0x3fb6114064079c18L), Double.longBitsToDouble(0x3fe5d239db7032bdL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.String:                                    |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                                    |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 3, 3, 11, "\ud857\udd8a\ud8c7\udc11\udba5\udcb0\udaa2\udc2f\uda41\udc31\uda00\udc7e\udb5d\udc55\uda64\udf09\udae1\ude20\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\u00c3\ud998\udefb\ud9ea\ude51\ud8f6\udcb8\ud845\ude69\udae4\ude6e\ud977\ude9b", "\u9e6f", "\ud8eb\udffe\ud9c3\udcbd",
        35, 96463, 1397603414, -6260080888330884832L, -65103L, true, true, (char) 24060, (char) 29177,
        Double.longBitsToDouble(0x3fe5e5d59e000000L), Double.longBitsToDouble(0x3feb8195ea83d8d5L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 14, 5, "\ud857\udd8a\ud8c7\udc11\ud9e9\uddc5\udaa1\udfda\uda41\udc31\uda00\udc7e\udac7\ude8b\uda64\udf79\udae1\ude20\ud90c\udc6d\udb1e\udc1c\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\u00c3\ud8ff\udf50\ud9ea\ude51\ud9ac\udc52\udb5c\udfa8\ud990\udd43\uda4c\udcea\u738b\uda2a\udeda\ud806\udf98\u8f69\udbb1\udec3\ud9fd\udece\ud9c3\udcbd\udb89\ude39\udbee\uddee\udaa7\udf28\ud931\udc7a\ud8c7\udfd5\ud87b\udeb4\ud8bb\udd2e\ud8df\ude7e\udb23\udf31\udab1\udf2c\udb7d\udd35\uda02\udfa1\u80bc\ud9c2\udcfd\u4c98\udb88\ude19\ud960\udd02", "\u5963\u6fbc\uadf2\ucffc\u8cd0\u3ce9\u1b4b\uad32\u7ec3\u00e0\u19ae\u92e1\u2b9e\u5f11\uc433\u2750\u07a6\u1843\ua2b9\u7398\u176f\u30af\u12b5\u944f\u5b67\ub60c\ub45f\ubbdd\ubb14\u0848\u93cf\u3239\u23a3\uc53e\u9cc4\u5c5c\u91d0", "\ud800\ude88\ud815\udcad\ud946\udef7\ud845\udc4d\ud868\udd6e\ud9e9\ude6b\ud8e1\udf00\ud995\udccd\udbec\udcba",
        24, 6690, 886384655, 458170868773937184L, 71562L, true, false, (char) 34386, (char) 7526,
        Double.longBitsToDouble(0x3febe20128fa3f92L), Double.longBitsToDouble(0x3fec200c655ec864L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 11, 11, "\ud83c\udc3d\ud8b5\udf1d\uda1c\uded0\000\000\000\000\000\ud87f\ude5e\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\000", "", "\000",
        26, -839, 0, -6269855107325736203L, -100000L, false, false, (char) 65023, (char) 0,
        Double.longBitsToDouble(0x3d659c0000000000L), Double.longBitsToDouble(0x3f43574000000000L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 11, 11, "\ud857\uddf4\ud8b5\udf1d\udb7d\udfa1\ud881\udd1f\ud8a4\ude71\udab8\udf35\udadf\udc90\uda64\udf09\u842f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\ud8c0\udcf1\uda2a\udc66\udb25\udfac\udab0\udea7\ud972\udf84\ud96d\udf77\ud939\udcbc\uda1f\udf1b\udb7a\ude0b\uda5d\udc2e\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e\ud854\uddc5\udb77\ude4a\udb2f\udd8f\ua0f7\ud931\udc7a\ud8c7\udff9\udb84\udc39\ud83f\udcb7", "\ucdf7", "\u2e68\ud9c2\udcfd",
        1, 12054, -1946133027, -1129370865931791136L, -98296L, true, false, (char) 52593, (char) 61344,
        Double.longBitsToDouble(0x3fdc60e227b5f3c4L), Double.longBitsToDouble(0x3fe2cb34723c6347L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 1, 1, "\u9c8b\ud8b5\udf1d\udb7d\udfa1\udb2d\udf14\ud877\ude7c\ud88b\udf44\udb5d\udc55\udb17\udc82\u64e2\ud8a0\udc97\udbb9\udc40\ud88e\udefc\ud9b4\udd71\ud995\ude59\udb31\udf6b\udab0\udcc9\u00c3\ud998\udefb\ud9ea\ude51\ud9fc\udc87\ud96d\udf77\ud939\udcbc\uda1f\udf1b\udb5e\udcc1\uda5c\udff5\ud971\udf39\ud885\udf1e\ud81f\udd01\u794e\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf77\udb72\udd9a\udb22\udfce\udb84\udc39\udb0e\udf1f\ud92c\udd22\ud920\udc18\ud940\udfaa\ud9a1\udca3\udbda\ude25\u2e68", "\u2212\uaec1\u67e7\u1d2a\ud5ad\u6f6f\ub162\u54d6\u0323\u5990\u18f5\u0661\ucb02\ua7df\ubefd\u2b64\u12de\u6f59", "\udadb\ude93\udb72\udc2f\udadb\udee3\ud849\udfd9",
        7, 52761, 868607692, -1206053067290854254L, 93312L, false, false, (char) 15697, (char) 18664,
        Double.longBitsToDouble(0x3fdbaec8d63cc922L), Double.longBitsToDouble(0x3fc29bbf2d32f46cL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 15, 1, "\ud857\udd8a\udaf4\udd9c\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\uda50\uddd0\uda32\udfce\uda44\ude87\udb6d\ude57\ud834\udfc2\udb1d\udfe2\uda42\udc9a\udb6e\udf78\udb57\udd1f\uda7e\ude26\ud9cb\udc5a\udbb3\udc1f\ud99a\udeba", "\u4a0f\u8289", "\udbce\udf82\ud992\udf3f\ud885\udf1e\ud81f\udd01\u794e\udb6b\udcea\ud90c\udf45\ud808\udd95\udaa7\udf77\ud8e5\uddf3\ud8eb\udd95",
        1, 28045, 1166245683, 693315191095922540L, -46682L, false, false, (char) 61807, (char) 42998,
        Double.longBitsToDouble(0x3fdad100b10b93baL), Double.longBitsToDouble(0x3fc44f60f04dc148L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.String:            |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 1, "\ud857\udd8a\ud816\udd98\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\uda50\uddd0\uda32\udfce\011\udb6d\ude57\ud834\udfc2\udb1d\udfe2\uda42\udc9a\udb6e\udf78\udb57\udd1f\ud927\udca8\ud877\udc76\udbb3\udc1f\ud99a\udeba", "\u4a0f\u8289", "\udbce\udf82\ud948\udc7a\ud885\udf1e\ud80e\ude01\ud8a6\udc11\000\000\u8250\udaa7\udf77\ud8e5\uddf3\ud8eb\udd95",
        11, 28045, -2051004148, 693315191095922540L, -46682L, false, false, (char) 61807, (char) 42998,
        Double.longBitsToDouble(0x3fdad100b10b93baL), Double.longBitsToDouble(0x3fc44f60ec7d9bdcL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:              |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 1, "\u6d4d", "\000", "\uda32\udfce",
        13, -807, 664019309, -8875311574786110884L, 85420L, false, true, (char) 34159, (char) 46989,
        Double.longBitsToDouble(0x3fda9fa005eb51faL), Double.longBitsToDouble(0x3fe5f80006000020L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.String:                                                           |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 15, 1, "", "\u2b14", "\uda50\uddd0\000\udab2\udc78\udb6d\ude57\udada\udd75\udb1d\udfe2",
        58, 58748, -1282381407, 8025711405607409463L, 85420L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fda900005eb51faL), Double.longBitsToDouble(0x3fc7f7d5c003d000L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 11, 11, 3, "\ud885\udca0\ud903\udc8c\udb7d\udfa1\uda7f\udca6\ud8c7\udf57\ud91a\udc10\uda9b\ude56\udb70\udd0a\ud89f\ude1f\ud9ad\uddc2\udb1d\udfe2\ud9ba\udc18\ud850\udf7f", "\u0566\u5d23\u02ed\u2af5\u40fd\u8c9d\u9538\u458a\u7cac\u83c5\u8048\u9339\u46e7\u0dd0\u243d\u71c7\u3dc8\uac8f\u92a1\u302c\u74c4\ua233\u90b0\u50c2\uc0f2\u9bcc\u482a\u9dea\u9eb4\u661e\ub5a7\uaedf\u7355\u787d\uce00\u5352\u21fb\u1fd5\u6c5d\u7949\u456f\u1550\ub81b\u0fec\u638e\u9ab7\ua288\u6636\u8016\u4191\ub468\ud604\u264c\u087e\u7984\uc0f4\u6cf6\u5d2d\ud04a\u184c\ua2ae\ua579", "\ud840\uddc0\ud889\udcb5\ud9b5\udd73",
        30, 69961, -507394701, -4851107199132472873L, -24242L, false, true, (char) 39283, (char) 44517,
        Double.longBitsToDouble(0x3fe820935233e809L), Double.longBitsToDouble(0x3fe100f92557b022L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 0, "\012", "\000\uab42\u25e3\u573f\u747d\ua7d2\u9055", "\u0718\ud95a\ude2d\udb31\udf6b",
        14, 1099, 1998859254, -2696164662737065055L, -85197L, false, true, (char) 21110, (char) 18340,
        Double.longBitsToDouble(0x3fef266c52b2e284L), Double.longBitsToDouble(0x3fde366f82aef854L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.StringBuffer: |a0=java.lang.StringBuffer: |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer: |a0=java.lang.StringBuffer: |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "", "\uda32\udf6f",
        12, 28246, -157330233, -8330516169536530947L, -100000L, false, false, (char) 78, (char) 0,
        Double.longBitsToDouble(0x3fe6fae8047cb925L), Double.longBitsToDouble(0x3fb77bd380000000L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\udaa1\udf87\ud86f\udc4b\ud8e3\uddbc\u00fc\000\000\udb92\ude3a\u550d\uda09\udda4\u649b\udb1e\udc56\ud9ba\udc18\ud88e\udd7e |a0=java.lang.StringBuffer:\udaa1\udf87\ud86f\udc4b\ud8e3\uddbc\u00fc\000\000\udb92\ude3a\u550d\uda09\udda4\u649b\udb1e\udc56\ud9ba\udc18\ud88e\udd7e |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 0, 1, 11, "\udaa1\udf87\ud86f\udc4b\ud8e3\uddbc\u00fc\000\000\udb92\ude3a\u550d\uda09\udda4\u649b\udb1e\udc56\ud9ba\udc18\ud88e\udd7e", "", "\ud998\udefb\uda89\ude80\ud972\udf84",
        20, -1000, -232554743, -6824236762636827090L, 64848L, true, false, (char) 2831, (char) 20528,
        Double.longBitsToDouble(0x3f5ca19f6cad7400L), Double.longBitsToDouble(0x3fd5d71e94a79c88L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 14, 5, "\udb75\udf65\ud95a\uddd4\udad8\uddb5\udaac\udfa2\uda41\udc31\uda00\udc7e\udac7\ude8b\uda64\udf79\udae1\ude20\ud90c\udc6d\udb11\udf1c\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\u00c3\ud8ff\udf50\ud9ea\ude51\udb51\udf53\udb5c\udfa8\ud990\udd43\uda4c\udcea\u738b\uda2a\udeda\ud806\udf98\u8f69\udbb1\udec3\ud9fd\udece\udb7e\udd68\udbf4\ude6f\uda87\udf66\ud896\udf41\ud931\udc7a\ud8c7\udfd5\ud87b\udeb4\ud8bb\udd2e\ud8df\ude7e\udb23\udf31\udab1\udf2c\udb7d\udd35\uda02\udfa1\u80bc\ud9c4\udcff\ud828\udca7\udb87\udc73\uda08\udfd6", "\u5963\u6fbc\uadf2\ucffc\u8cd0\u3ce9\u1b4b\uad32\u7ec3\u00e0\u19ae\u92e1\u2b9e\u5f11\uc433\u2750\u07a6\u1843\ua2b9\u7398\u176f\u30af\u126c\u944f\u5b67\ub60c\ub45f\ubbdd\ubb14\u0848\u93cf\u3239\u23a3\uc53e\u9cc4\u5c5c\ucd31", "\ud800\ude88\ud815\udcad\ud946\udef7\ud845\udc4d\ud868\udd6e\ud9e9\ude6b\ud8e1\udf00\ud995\udccd\uda16\udc6f",
        6, 18899, 876544796, 6968014177814688987L, -9418L, true, false, (char) 34386, (char) 7526,
        Double.longBitsToDouble(0x3febe20128fa3f92L), Double.longBitsToDouble(0x3fec200c6384c864L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:                                  |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 1, "\000\000\000\u580b\000\000\uda32\udf3e\011\udb6d\ude57\ud834\udfc2\000\u0a5c\udb4a\udc64\udb57\udd1f\ud927\udca8\ud877\udc76\udbb3\udc1f\000", "\u4a0f\u11aa", "\udbce\ude98\ud948\udc7a\ud885\udf1e\ud80e\ude01\ud8a6\udc11\000\000\u8250\udaa7\udf77\u0099\000",
        33, 28045, -2051004148, 693315190246080512L, -46682L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fdad100b10b93baL), Double.longBitsToDouble(0x3fc44f60ec7d9bdcL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String:       |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 15, 6, "\ud857\udd8a\ud816\udd98\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\uda50\uddd0\uda32\udfce\011\udb6d\ude57\ud834\udfc2\udb1d\udfe2\uda42\udc9a\udb6e\udf78\udb57\udd1f\ud927\udca8\ud877\udc76\udbb3\udc1f\ud99a\udeba\ud812\udeda\ud9ec\udca3\uda82\udc81\ud939\udc88\uda1f\udf1b\udb7a\ude0b\udbce\udf82\ud948\udc7a\ud885\udf1e\ud80e\ude01\ud8a6\udc11\000\000\u8250\udaa7\udf77\ud8e5\uddf3", "\ubda6\ud027\u49e5\u3375\ua2cc\u39bd\ud00a\u9400\u28d3\uc983", "\udbf3\udcb4\ud896\udf3c\udb14\udf51\uda78\ude87\udbd2\udec8\ud908\udcea\ud96a\ude75\u258e\ud932\udea8\ud9e2\udd3d\ud8a0\udf34\ufab9\uda46\udc0e\ud8c4\udda7",
        6, 88257, -1813391482, -8937838603838080808L, 94639L, false, false, (char) 10995, (char) 16892,
        Double.longBitsToDouble(0x3fb247fc15e7f728L), Double.longBitsToDouble(0x3fed16db9ac2313dL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.String:                |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 1, "\ud857\udd8a\ud816\udd98\ud8bc\udc7c\udaa2\udc35\ud877\ude7c\uda50\uddd0\uda32\udfce\011\udac8\udda4\ud981\udc2c\udb1d\udfe2\uda42\udc9a\udb6e\udf78\udb57\udd1f\ud927\udca8\uda9b\udd9c\udbb3\udc1f\ud99a\udeba", "\u4a0f\u8289", "\udbce\udf82\ud948\udc7a\ud885\udf1e\ud80e\ude01\ud8a6\udc11\000\000\u8250\udaa7\udf77\ud8e5\uddf3\ud89a\udd52",
        15, 28045, -2051004148, 693315191095922540L, -46682L, false, false, (char) 4976, (char) 40110,
        Double.longBitsToDouble(0x3fee85b1b085c9ddL), Double.longBitsToDouble(0x3fc44f60ec7cc3dcL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:     |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 5, "\ud857\udd8c\ud97a\udf0a\udb4f\udd24", "\u69eb\u2e42\011\u9af0\u9055\u9d29", "\ud9ce\udd61\uda50\udf9e\ud877\udd01\udbb3\udc1f\ud99a\udeba\udbb5\udfe9\ud9e1\udf62",
        4, 84313, -1092917003, -855540173318686998L, -81560L, false, false, (char) 24025, (char) 11986,
        Double.longBitsToDouble(0x3fe47939f199534cL), Double.longBitsToDouble(0x3f6a4edb6c5e8a00L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String:              |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 1, "\ud929\udee4\udb85\udc2f\udb7d\udefa\udaa2\udc2f", "\u2e42\011", "\udb1d\udfe2\uda42\udc9a\udb6e\udf78",
        13, 29576, 1493686071, -6892502203962676300L, -15849L, false, false, (char) 58351, (char) 62450,
        Double.longBitsToDouble(0x3fe5fdf576eaf420L), Double.longBitsToDouble(0x3fec82a21ce23142L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 15, 1, "\ud857\udd8a\ud816\udd98\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\uda50\uddd0\uda32\udfce\011\udb6d\ude57\ud834\udfc2\udb1d\udfe2\uda42\udc9a\udb6e\udf78\udb57\udd1f\ud927\udca8\ud877\udc76\udbb3\udc1f\ud99a\udeba", "\u4a0f\u8289", "\ud8c6\udd73\ud9fe\udc06\ud885\udf1e\ud80e\ude01\ud8a6\udc11\000",
        -5, 55656, 1397510799, 5322051453035614211L, -95597L, false, true, (char) 44094, (char) 39178,
        Double.longBitsToDouble(0x3fea19953fbab1fcL), Double.longBitsToDouble(0x3fe345199c8f44e1L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.String:     |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 11, "\ud857\udd8a\ud816\udd98\udb53\udfac\udaa2\udc2f\ud877\ude7c", "\011\ud64f", "\uda42\udc9a\udb6e\udf78\udb4d\ude7a\uda2d\udc54\ud8b2\uddd7\ud812\udf40\ud99a\ude85\ud812\udeda\ud9ec\udca3\uda82\udc81\udbba\udebc\ud845\udcb9\udb7a\ude0b\udb4a\udf9f\ud948\udc0d\ud885\udf1e\ud80e\ude01\ud8a6\udc11\000\000\u8250",
        4, 67665, 2042177768, -8930933366203093299L, -96316L, false, false, (char) 51689, (char) 57782,
        Double.longBitsToDouble(0x3fe345199c1844e1L), Double.longBitsToDouble(0x3fdcf322735a2016L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.String:                         |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 13, "\ua310\udade\udd6e\u00cd\000\000", "\u2b1c\ua64a", "\uda42\udc9a\ud939\udd18\udab2\udc6c\ud911\udcb2\ud877\udcb5\udb2b\udfc7\ud99a\udeba\ud9a6\udf04\ud9a1\ude0c\ud9fa\udc7d\ud939\udc88\ud91f\udc5b\ud804\udf6b\ud897\udd07\uda34\udd33\ud9d7\ude84\ud891\udf2c\udaa5\udeab\uda08\udeb3",
        24, 23098, 2115975001, 4956547004209725551L, 92596L, true, false, (char) 28508, (char) 20817,
        Double.longBitsToDouble(0x3fe97cdf62aeef86L), Double.longBitsToDouble(0x3fe2227a7b843f08L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 0, 0, "\012", "\000\uab42\u25e3\u573f\u747d\ua7d2\u9055", "\000\000\000",
        -5, -1000, 1998859008, -2696164662737065055L, -85197L, false, true, (char) 19630, (char) 0,
        Double.longBitsToDouble(0x3fef266c52b2e284L), Double.longBitsToDouble(0x3fcc6cdf055df000L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud857\udd8a\ud816\udd98\udb7d\udfa1\udaa2\udc2f\u2e28\012             |a0=java.lang.StringBuffer:\ud857\udd8a\ud816\udd98\udb7d\udfa1\udaa2\udc2f\u2e28\012             |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 13, "\ud857\udd8a\ud816\udd98\udb7d\udfa1\udaa2\udc2f", "\u2e28\011", "\ud98f\udfdb\ud9a9\udcef\udb6e\udf74",
        13, 29793, 1493686071, -6892502203962676300L, 77992L, false, false, (char) 58351, (char) 62450,
        Double.longBitsToDouble(0x3fe5fdf576eaf420L), Double.longBitsToDouble(0x3fbcb190f3e00468L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud857\udd8c\ud97a\udf0a\udb4f\udd24\u69eb\uac32\012   \u9af0\012   \u9055\012   \u9d29 |a0=java.lang.StringBuffer:\ud857\udd8c\ud97a\udf0a\udb4f\udd24\u69eb\uac32\012   \u9af0\012   \u9055\012   \u9d29 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\ud857\udd8c\ud97a\udf0a\udb4f\udd24\u69eb\uac32\012   \u9af0\012   \u9055\012   \u9d29 |a0=java.lang.StringBuffer:\ud857\udd8c\ud97a\udf0a\udb4f\udd24\u69eb\uac32\012   \u9af0\012   \u9055\012   \u9d29 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 7, "\ud857\udd8c\ud97a\udf0a\udb4f\udd24", "\u69eb\uac32\011\u9af0\u9055\u9d29", "\ud8bb\udc84\uec62\ud877\udd01\udbb3\udc1f\ud99a\udeba\udbb5\udfe9\ud9e1\udf62",
        4, 84313, -1092917003, -855540173318686998L, -81560L, false, false, (char) 22215, (char) 30368,
        Double.longBitsToDouble(0x3fe47939f199534cL), Double.longBitsToDouble(0x3f6a4edb6c5e8a00L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.String:                                         |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1\u2e42\012                                       \ud64f\012                                       \u267c\012                                       \u9d29\012                                       \ucff1\012                                       \u9fe1\012                                       \u44d9\012                                       \ua872\012   ... |a0=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1\u2e42\012                                       \ud64f\012                                       \u267c\012                                       \u9d29\012                                       \ucff1\012                                       \u9fe1\012                                       \u44d9\012                                       \ua872\012   ... |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 3, 0, 1, "\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1", "\u2e42\011\ud64f\u267c\u9d29\ucff1\u9fe1\u44d9\ua872\u62b3\u5c91\ube8d\u79c4\u072f\uc634\ud081\u81b5\u6c50\u90a4\u0353\u91be\ucbf0\ucf61\000\000\u8ad4\ub565\u5d89\ua764\u13a0\u076d\u02b6\ua72c\u3c0a\ubbb0\u0384\u3c7c", "\uda12\udfe8\udacf\udc8b\ud9a8\ude6e\udbb6\ude34\ud851\udf0b\uda25\ude2f\ud851\udfba\udac0\udfc6",
        40, 89334, -1424800893, -7535916456563384175L, 39296L, true, true, (char) 37321, (char) 53511,
        Double.longBitsToDouble(0x3fe3432dc2f0bcacL), Double.longBitsToDouble(0x3fec22462a0a34e0L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud857\udd8a\ud816\udd98\udb53\udfac\udaa2\udc2f\ud877\ude7c\012   \ud64f |a0=java.lang.StringBuffer:\ud857\udd8a\ud816\udd98\udb53\udfac\udaa2\udc2f\ud877\ude7c\012   \ud64f |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 11, "\ud857\udd8a\ud816\udd98\udb53\udfac\udaa2\udc2f\ud877\ude7c", "\011\ud64f", "\uda42\udc9a\udb6e\udf78\udb4d\ude7a\uda2d\udc54\ud8b2\uddd7\ud812\udf40\ud99a\ude85\ud812\udeda\ud9ec\udca3\uda82\udc81\udbba\udebc\ud845\udcb9\udb7a\ude0b\udb4a\udf9f\000\ud885\udea2\ud80e\ude01\ud8a6\udc11\000\000\u8250",
        4, 67665, 2042177768, -8930933366203093299L, -100000L, false, false, (char) 51689, (char) 57782,
        Double.longBitsToDouble(0x3fe345199c1844e1L), Double.longBitsToDouble(0x3fdcf32270000000L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 1, 0, "\012\ud89f\udeef", "\uab42", "\uda64\udf09\ud89f\ude1f\uda73\udcdb\udb1e\udc5b\ud9ba\udc18\ud8ac\udf00",
        58, -798, 407786752, -8341266295779218688L, -85197L, false, true, (char) 19630, (char) 0,
        Double.longBitsToDouble(0x3fef266c52665284L), Double.longBitsToDouble(0x3f5a9f82aef80000L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\udb5d\udd20\ud990\udffd\ud856\udf72\udbdd\ude03\ubf27\012                                              \u9af0\012                                              \u9055\012                                              \u7c95\012                                              \u2d46\012                                              \u7afc\012                                              \u0b96\012  ... |a0=java.lang.StringBuffer:\udb5d\udd20\ud990\udffd\ud856\udf72\udbdd\ude03\ubf27\012                                              \u9af0\012                                              \u9055\012                                              \u7c95\012                                              \u2d46\012                                              \u7afc\012                                              \u0b96\012  ... |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 13, "\udb5d\udd20\ud990\udffd\ud856\udf72\udbdd\ude03", "\ubf27\011\u9af0\u9055\u7c95\u2d46\u7afc\u0b96\ubaf2\u4571\u6d24", "\ud9ec\udca4\uda82\udc81\ud939\udc88\uda1f\udf1b\udb7a\ude0b\udbce\udf82\ud948\udc7a",
        47, 42569, -1881047767, -5854248812672537473L, -89052L, false, true, (char) 5692, (char) 41495,
        Double.longBitsToDouble(0x3fe6d43123806926L), Double.longBitsToDouble(0x3fed94943bf76e9fL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1\u2e42\012                                       \ud64f\012                                       \u267c\012                                       \u9d29\012                                       \ucff1\012                                       \u9fe1\012                                       \u44d9\012                                       \ua872\012   ... |a0=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1\u2e42\012                                       \ud64f\012                                       \u267c\012                                       \u9d29\012                                       \ucff1\012                                       \u9fe1\012                                       \u44d9\012                                       \ua872\012   ... |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 8, 0, 1, "\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1", "\u2e42\011\ud64f\u267c\u9d29\ucff1\u9fe1\u44d9\ua872\u62b3\u5c91\ube8d\u79c4\u072f\uc634\ud081\u81b5\u6c50\u90a4\u0353\u91be\ucbf0\ucf61\000\u2000\u7c35\u3388\u5d89\u13d6\u1323\u076d\u02b6\ua72c\u3c0a\ubbb0\u0384\u3c7c", "\uda12\udfe8\udacf\udc8b\ud9a8\ude6e\udbb6\ude34\ud851\udf0b\uda25\ude2f\ud851\udfba\udac0\udfc6",
        40, 89334, -1424800893, -7535916456563384175L, 39296L, true, true, (char) 37321, (char) 53511,
        Double.longBitsToDouble(0x3fe3432dc2f0bcacL), Double.longBitsToDouble(0x3fec22462a0a34e0L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1\u2e42\012                                       \ud64f\012                                       \u267c\012                                       \u9d29\012                                       \ucff1\012                                       \u9fe1\012                                       \u44d9\012                                       \u18ef\012   ... |a0=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1\u2e42\012                                       \ud64f\012                                       \u267c\012                                       \u9d29\012                                       \ucff1\012                                       \u9fe1\012                                       \u44d9\012                                       \u18ef\012   ... |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1\u2e42\012                                       \ud64f\012                                       \u267c\012                                       \u9d29\012                                       \ucff1\012                                       \u9fe1\012                                       \u44d9\012                                       \u18ef\012   ... |a0=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1\u2e42\012                                       \ud64f\012                                       \u267c\012                                       \u9d29\012                                       \ucff1\012                                       \u9fe1\012                                       \u44d9\012                                       \u18ef\012   ... |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 1, "\uda2d\udd7a\udbb0\udf26\ud9f9\udf9f\ud826\udff1", "\u2e42\011\ud64f\u267c\u9d29\ucff1\u9fe1\u44d9\u18ef\u62b3\u5c91\ube8d\u79c4\u072f\uc634\ud081\u81b5\u6c50\u90a4\u0353\u91be\000\ucf61\000\000\u8ad4\ub565\u5d89\u28e8\u12da\u076d\u02b6\ua72c\u3c0a\ubbb0\u0384\u3c7c", "\uda12\udfe8\udacf\udc8b\uc794\udbb6\udd79\ud851\udf0b\uda25\ude2f\ud851\udfba\udac0\udfc6",
        40, 89334, -1424800893, -7535916456563384175L, 39296L, true, true, (char) 37321, (char) 53511,
        Double.longBitsToDouble(0x3fe3432dc2f0bcacL), Double.longBitsToDouble(0x3fec22462a0a34e0L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud803\udd44\ud826\udff1\u2e42\012           \ud64f\012           \u267c\012           \u9d29\012           \ucff1\012           \u9fe1\012           \u44d9\012           \u0973\012           \u62b3\012           \u5c91\012           \ube8d\012           \u79c4\012           \u072f\012           \uc634\012           \ud081\012           \u81b5\012           \u6c50\012           \u90a4\012           \u0353\012           \u91be\012           \ucbf0\012           \ucf61\012\012           \u7c35\012   ... |a0=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud803\udd44\ud826\udff1\u2e42\012           \ud64f\012           \u267c\012           \u9d29\012           \ucff1\012           \u9fe1\012           \u44d9\012           \u0973\012           \u62b3\012           \u5c91\012           \ube8d\012           \u79c4\012           \u072f\012           \uc634\012           \ud081\012           \u81b5\012           \u6c50\012           \u90a4\012           \u0353\012           \u91be\012           \ucbf0\012           \ucf61\012\012           \u7c35\012   ... |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 8, 0, 1, "\uda2d\udd7a\udbb0\udf26\ud803\udd44\ud826\udff1", "\u2e42\011\ud64f\u267c\u9d29\ucff1\u9fe1\u44d9\u0973\u62b3\u5c91\ube8d\u79c4\u072f\uc634\ud081\u81b5\u6c50\u90a4\u0353\u91be\ucbf0\ucf61\000\u2000\u7c35\u3388\u5d89\u13d6\u1323\u076d\u02b6\u1428\u5675\u0bc0\uc4d9\uca7e", "\uda12\udfe8\udacf\udc8b\ud9a8\ude6e\udbb6\ude34\ud851\udf0b\uda25\ude2f\ud851\udfba\udac0\udfc6\u3c75\ud9d0\udd91",
        12, 79721, -444276591, -7210222510719702816L, 81431L, false, false, (char) 40992, (char) 3997,
        Double.longBitsToDouble(0x3fec22462a0a34e0L), Double.longBitsToDouble(0x3fe9171548cd7948L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud803\udd44\ud826\udff1\u2e42\012               \ud64f\012               \u267c\012               \u9d29\012               \ucff1\012               \u9fe1\012               \u44d9\012               \u0973\012               \u62b3\012               \u5c91\012               \ube8d\012               \u79c4\012               \u072f\012               \uc634\012               \ud081\012               \u81b5\012               \u6c50\012               \u90a4\012 ... |a0=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud803\udd44\ud826\udff1\u2e42\012               \ud64f\012               \u267c\012               \u9d29\012               \ucff1\012               \u9fe1\012               \u44d9\012               \u0973\012               \u62b3\012               \u5c91\012               \ube8d\012               \u79c4\012               \u072f\012               \uc634\012               \ud081\012               \u81b5\012               \u6c50\012               \u90a4\012 ... |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 8, 0, 1, "\uda2d\udd7a\udbb0\udf26\ud803\udd44\ud826\udff1", "\u2e42\011\ud64f\u267c\u9d29\ucff1\u9fe1\u44d9\u0973\u62b3\u5c91\ube8d\u79c4\u072f\uc634\ud081\u81b5\u6c50\u90a4\u0353\u91be\ubf57\u34a9\000\u2000\uceb2\u3388\u75fe\u7f74\u1323\uc095\u44d7\ud04d\u5675\u0bc0\uc4d9\uca7e", "\uda12\udfe8\ud943\udf05\ud9da\udcc8\udbb6\ude34\ud851\udf0b\uda25\ude2f\ud851\udfba\udac0\udfc6\u3c75\ud9d0\udd91\ud9ef\udd40\ud8af\uddbf\ud9d9\udf01\ud97d\udeee\ud837\udffe\udb05\ude64\ud95e\udd2f\uda5a\udee8\ud8df\ude70\uda1e\ude34\udadc\udeda\ud97c\udc4f",
        16, 52701, -726433621, 2378854260462884121L, -69920L, true, false, (char) 51297, (char) 40528,
        Double.longBitsToDouble(0x3fe4bfd97f01922cL), Double.longBitsToDouble(0x3fda3ae2c967b872L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 2, 11, "\ud857\udd8a\ud8b5\udf1d\udb7d\udfa1\udaa2\udc2f\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e", "\000\u96a1\u1e00\u382d", "\000\uda0d\udd1b\u82bf\uda39\udc9c\ud992\udf3f\ud885\udf1e\ud81f\udd01\u4808",
        43, 63390, 658413381, 6002172401920489881L, -100000L, false, false, (char) 42239, (char) 31750,
        Double.longBitsToDouble(0x3fc3daf0e0000000L), Double.longBitsToDouble(0x3fc748800dc0c800L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 11, "\udb85\udca8\ud8b5\udf04\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\udb60\udc97\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d\ud995\ude59\udb31\udf6b\udab0\udcc9\udad9\ude58\ud9b0\udcdf\ud9ea\ude51\ud890\udda4\udb0b\udc09\ud832\udf28\uda1f\udf1b\udb7a\ude0b\uda4e\udf86\ud992\udf3f\ud9d5\udf22\udb71\udfd3\uc4b9\u6ac9\ud8c7\ude36\ud860\udd77\uda99\udf09\ud931\udc7a\ud8c7\udff9\udb95\udc01\udbee\udd7e\ud8dd\udf09\ud939\udc9a\ud940\udfaa\ud9a1\udca3\udbda\ude25\ud86c\ude77\ud9c2\uddb7\udb42\udde1\udb9f\udf56\ud9d6\udc6e\udb64\ude03\ud97c\ude18\ud87a\ude90\udb67\uded3\ud996\ude55\uda49\udde3\ud95e\udc32\udb83\udfeb\uda1f\udebc\udbcb\udc25\udaec\udc21\udaf6\udee8\ud81e\udfcf\uda25\udf48\ud87d\udfd1\ud8f2\udefa\ud8bf\udf55\ud86a\udd6d\ud8a3\udd60\ud907\ude3a\uda20\ude67\ud8ad\udf9a\ud85d\udd33\ud975\udce0\udb5a\ude2f\udb88\udf6c\ud9d1\udc38\ud847\udf97\ud92d\udd6c\uda15\udf01\ud818\udca2\ud9a6\udfc1\ud8a8\udd68\ud84e\ude30\uda22\uded6\ud8b9\udc17\ud9f9\udc97\udad2\udfe8\uda0e\udc80\ud812\udd8b\ud99e\udcc3\udb80\udc9a\uda9f\udfc4\ud9cc\udf8f\udbed\udd53\ud875\udf61\udb48\udfbf\udad6\udc52\udac5\uddb8\ud930\ude03\udbf3\udec0\ud88f\uddcc\udaa5\udeb9\udb5f\udef6\udbc6\udec2\ud812\ude7d\uda06\uddb8\ud98d\udc5d\ud98f\udfb2\udb44\udc92\ud92e\ude8e\udaca\udcb9\ud863\udd25\udaf7\udc17\ud925\udf03\ud8d1\udf8a\uda3d\udde0\ud9ed\ude64\ud8e0\udf43\ud9d3\udceb", "\u559a\u2b5b\ua44a\u8def\ubb30\u7f1d\u9bb5\u0baf\u0eaa\ud15a\u9105\u2cf3\u5b73\ube1a\u383b\u3448\u4ded\u2989\uad12\u8fe4\u14a0\u4298\u3ebf", "\udb1b\ude8d\udb65\udc4a\ud97b\udda5\udb77\udcbf\udaa8\udec4\uda05\udebf\ud8a0\udf2d\ud805\udd0e\udbe3\udf94\ud913\udd98\udb9f\udded",
        56, 98, 423131063, -5109463668444142933L, 84388L, true, true, (char) 18500, (char) 20020,
        Double.longBitsToDouble(0x3fc5bf298c11ced0L), Double.longBitsToDouble(0x3fe83fc0de4bf991L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 2, 11, "\ud857\udd8a\uda3a\ude7c\udb7d\udf17\ud98e\udc25\ud877\ude7c\ud8c8\udf2b\udb5d\udc55\uda8a\udd0a\ud88a\udcc2\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud993\udd9c\udb31\udf6b\ud8eb\udc68\ud984\udeea\u78fd\ud9ea\ude51\ud972\udf84\ud96d\udeb6\ud939\udcbc\ud845\udd20\udb7a\ude0b\uda5d\udc86\ud8e6\ude4a\udb1b\udc2c\ud940\udc75\uce4d\u6ac9\ud90c\udfe1\ud808\uddad\ud87a\ude61\ud903\udc29\ud8c7\udff9\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud87c\udc32\ud9a1\udd42\uda65\udeea\ud86c\ude51\ud9c2\uddb7\udbd3\udf6a\udae1\udff2\ud8bf\udeab\ud966\udc07\uda14\udedd\udb10\udc6c\udaae\udfc3\udbf4\udd57\udbcb\udc1f\uda1e\ude4c\ud873\udf1f\udb1b\uddb3\udb63\udcb2\uf74e\ud9e6\uddc1\udbd2\udf24\ud8aa\udd0d\uda9f\ude41\udbd3\udc50\ud902\udeea\ud9de\udc24\udace\udccb\udb1a\udea2\udbcc\udc87\ud9f5\ude4c\udaf8\udf30\udb06\udca7\uda94\udc36\udbbc\udc65\uf6a9\uda11\udd47\udaba\uddc8\udb2d\ude79\udad7\udfc8\udad1\udec2\uda16\uddc4\udb12\udc99", "\uabdb\ub752\u15a0\uaffb\u8d8c", "\uda9d\udcde\udbd3\udd9e\udb8c\udf40\ud8d3\ude1a\ud986\udea7\ud8a2\udd6d\ud96a\udd22\udb23\udd42\ud8f6\udcc8\ud8dd\udce1\udbdb\udf75\ud814\udc5e",
        3, 94625, -1974842932, 8309985472549321628L, -94065L, false, true, (char) 58974, (char) 61783,
        Double.longBitsToDouble(0x3fcb5da868ecaabcL), Double.longBitsToDouble(0x3fed26d5a4820b3dL)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.String:                 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 15, 11, "\ud857\udd8a\ud816\udd98\udb53\udfac\udaa2\udc2f\ud877\ude7c\uda50\uddd0\uda32\udfce\011\ud98f\udf70", "\ucff1\u7b00\uba4b\u6764\u661b\u4788\u20c8\u7f3d\u072f\u4a0f\u57e0\uc44e\u7cac\u0da5\u18ad\u9339\u03e7\u30c1\000\000\u7e82", "\ud966\udc14\ud861\udc1e\udb7b\udd8c\uda9f\udcb5\uda94\udfab\ud8a0\udf40\ucaaa\udbda\ude41\ud86c\ude77\uda89\udf0c\ud803\udec1\uda9e\udc67\ud90c\udc2c\udb1c\uddc7\ud9c6\ude3b\udbd6\ude63\uda35\ude20",
        16, 16451, 2022042102, 7598898853209643143L, -81032L, false, false, (char) 32306, (char) 39970,
        Double.longBitsToDouble(0x3fd5939b147d5e20L), Double.longBitsToDouble(0x3fec34327dfb84e8L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud803\udd44\ud826\udff1\u2e42\012     \ud64f\012     \u267c\012     \u9d29\012     \ucff1\012     \u9fe1\012     \u44d9\012     \u06c8\012     \u6244\012     \u5c91\012     \ube8d\012     \u79c4\012     \u072f\012     \uc634\012     \ud081\012     \u81b5\012     \u6c50\012     \u90a4\012     \u0353\012     \u91be\012     \ubf57\012     \u34a9\012\012     \uceb2\012     \u3388\012     \u75fe\012     \u7f74\012     \u1323\012     \uc095\012     \u44d7\012     \ud04d\012     \u5675\012     \u0bc0\012     \uc4d9\012     \uca7e |a0=java.lang.StringBuffer:\uda2d\udd7a\udbb0\udf26\ud803\udd44\ud826\udff1\u2e42\012     \ud64f\012     \u267c\012     \u9d29\012     \ucff1\012     \u9fe1\012     \u44d9\012     \u06c8\012     \u6244\012     \u5c91\012     \ube8d\012     \u79c4\012     \u072f\012     \uc634\012     \ud081\012     \u81b5\012     \u6c50\012     \u90a4\012     \u0353\012     \u91be\012     \ubf57\012     \u34a9\012\012     \uceb2\012     \u3388\012     \u75fe\012     \u7f74\012     \u1323\012     \uc095\012     \u44d7\012     \ud04d\012     \u5675\012     \u0bc0\012     \uc4d9\012     \uca7e |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 8, 0, 1, "\uda2d\udd7a\udbb0\udf26\ud803\udd44\ud826\udff1", "\u2e42\011\ud64f\u267c\u9d29\ucff1\u9fe1\u44d9\u06c8\u6244\u5c91\ube8d\u79c4\u072f\uc634\ud081\u81b5\u6c50\u90a4\u0353\u91be\ubf57\u34a9\000\u2000\uceb2\u3388\u75fe\u7f74\u1323\uc095\u44d7\ud04d\u5675\u0bc0\uc4d9\uca7e", "\uda12\udfe8\ud943\udf05\ud9da\udcc8\udbb6\ude34\ud851\udf0b\uda25\ude2f\ud851\udfba\udac0\udfc6\u3c75\ud9d0\udd91\ud9ef\udd40\ud8af\uddbf\ud9d9\udf01\ud97d\udeee\ud837\udffe\udb05\ude64\ud95e\udd2f\uda5a\udee8\ud8df\ude70\uda1e\ude34\udadc\udeda\ud97c\udc4f",
        6, 52701, -726433621, 2378854260462884121L, -69920L, true, false, (char) 51297, (char) 40528,
        Double.longBitsToDouble(0x3fe4bfd97f01922cL), Double.longBitsToDouble(0x3fda3ae2c967b872L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 2, 9, "\ud857\udd8a\uda3a\ude7c\udb7d\udf17\ud98e\udc25\ud877\ude7c\ud972\udfdd\udab3\udc35\ud9ff\udec0\udb97\udd5b\ud835\udc23\udb1d\udfe2\ud9ba\udc18\ud88e\udd7e\ud993\udd9c\uda54\udfbf\udbc3\udfc6\ud814\uddbd\u78fd\ud9ea\ude51\ud972\udf84\ud96d\udeb6\ud939\udcbc\ud845\udd20\udb7a\ude0b\uda5d\udc86\ud8e6\ude4a\udb5c\udc4c\udb43\udce7\ud8b7\ude72\u6ac9\ud90c\udfe1\ud808\uddad\udadb\uddf1\ud68d\ud8c8\udc30\udb84\udc39\ud83f\udcb7\udab5\udd82\ud929\ude49\ud86c\udc38\ud9a1\udd42\uda65\udeea\ud86c\ude51\ud9c2\uddb7\udbd3\udf6a\udae1\udff2\ud8bf\ude50\ud966\udc07\uda14\udedd\udb10\udc6c\udaae\udfc3\udbf4\udd57\udbcb\udc1f\uda1e\ude4c\ud873\udf1f\udb49\udfb3\udb63\udcb2\uf74e\ud9e6\uddc1\udbd2\udf24\uda9e\ude10\uda00\ude12\udbd3\udc50\ud902\udeea\ud979\udca7\ud992\ude24\udb1a\udea4\udbcc\udc87\ud9f5\ude4c\udaf8\udf30\udb06\udca7\uda93\udff5\udbbc\udc65\uf6a9\uda11\udd47\udabf\udec8\udb2d\ude79\udad7\udfc8\udad1\udec2\uda16\uddc4\udb12\udc99", "\uabdb\ub752\u15a0\uaffb\u8d8c", "\uda9d\udcde\udbd3\udd9e\udb8c\udf40\ud8d3\ude1a\ud986\udea7\ud8a2\udd6d\ud96a\udd22\udb23\udd42\ud8f6\udcc8\ud8dd\udce1\udbd8\udd60\ud814\udc5e",
        2, 94625, -1974842932, 8309985472549321628L, -94065L, false, true, (char) 58974, (char) 61783,
        Double.longBitsToDouble(0x3fe2976a1a3bbb93L), Double.longBitsToDouble(0x3fed26d5a5820b3dL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 14, 5, "\ud8d9\ude1e\ud8c7\udc11\ud9e9\uddc5\udaa1\udfda\uda41\udc31\uda00\udc7e\udac7\ude8b\uda64\udf79\udae1\ude20\ud90c\udc6d\udb1e\udc1c\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\015\ud8ff\udf50\ud9ea\ude51\ud9ac\udc52\udb5c\udfa8\ud990\udd43\uda4c\udcea\u738b\uda2a\udeda\ud806\udf98\u8f69\udbb1\udec3\ud9fd\udece\ud9c3\udcbd\udb89\ude39\u1f16\uda6c\udfa9\ud9c0\ude54\ud8c7\udfd5\ud87b\udeb4\ud8bb\udd2e\ud8df\ude7e\udb23\udf31\udab1\udf2c\udb7d\udd35\uda02\udf0b\u80bc\ud9c2\udcfd\u4c98\ud87a\udc52\ud97b\udf26", "\u5963\u6fbc\uadf2\ucffc\u8cd0\u3ce9\u1b4b\uad32\u26c4\u00e0\u19ae\u92e1\u2b9e\u5f11\uc433\u2750\u07a6\u1843\ua2b9\u7398\u176f\u30af\u12b5\u944f\u95c6\ud331\u02c3\u0591\ubb14\u0848\u93cf\u3239\u23a3\uc53e\u9cc4\u5c5c\u91d0", "\ud800\ude88\ud815\udcad\ud946\udef7\ud845\udc4d\ud868\udd6e\ud9e9\ude6b\ud8ab\udd30\ud995\udccd\udbec\udcba",
        24, 6690, 886384655, 458170868773937184L, 71562L, true, false, (char) 34386, (char) 7526,
        Double.longBitsToDouble(0x3febe2012ca94692L), Double.longBitsToDouble(0x3fec200c655ec864L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 14, 5, "\ud8d9\ude1e\ud8c7\udc11\ud95b\udede\uda84\udf85\uda41\udc31\uda00\udc7e\udac7\ude8b\uda64\udf79\udae1\ude20\ud90c\udc6d\udb1e\udc1c\ud9ba\udc18\ud88e\udd7e\ud995\ude59\udb31\udf6b\udab0\udcc9\015\ud8ff\udf50\ud9ea\ude51\ud9ac\udc52\udb5c\udfa8\ud990\udd43\uda4c\udcea\u738b\uda2a\udeda\ud806\udf98\u8f69\udbb1\udec3\ud9fd\udece\ud9c3\udcbd\udb89\ude39\u1f16\uda6c\udfa9\ud9c0\ude54\ud8c7\udfd5\ud87b\udeb4\ud8bb\udd2e\ud8df\ude7e\udb23\udf31\udab1\udf2c\udb7d\udd35\uda02\udf0b\u80bc\ud9c2\udcfd\u4c98\ud87a\udc52\ud97b\udf26", "\ud549\u7035\u1723\ucffc\u8cd0\u3ce9\u1b4b\uad32", "\uda17\udfe6",
        1, 15151, 406055522, 7517731042669047111L, -77159L, false, true, (char) 32442, (char) 24363,
        Double.longBitsToDouble(0x3fe9b48fd35e307eL), Double.longBitsToDouble(0x3fc65fee3484bbb0L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 11, "\udb85\udca8\ud8b5\udf04\udb7d\udfa1\ud9d9\ude0a\ud877\ude7c\ud8c8\udf2b\ud8c9\udd08\uda64\udf09\ud89f\ude1f\ud834\udfc2\udb1d\udfe2\ud9ba\udc18\udafe\udc7d\ud965\udcda\ud827\udf7b\udab0\udcc9\udad9\ude58\uda14\udead\ud9eb\udd78\uda13\udf6f\ud803\udec8\ud832\udf28\uda1f\udf1b\udb7a\ude0b\uda4e\udf86\ud992\udf3f\ud9d5\udf22\udb73\udf2b\uc4b9\u6ac9\ud90c\udf79\ud808\udd95\udaa7\udf77\ud931\udc7a\ud8c7\udff9\udb84\udc39\ud83f\udcb7\ud8df\ude13\ud939\udc9a\ud940\udfaa\ud9a1\udca3\udbda\ude25\ud86c\ude77\ud9c2\uddb7\udb42\udde1\ud81d\udf55\ud9d6\udc6e\udb64\ude03\uda4d\udc60\ud87a\ude53\udb67\uded3\ud996\ude55\uda49\udde3\ud95e\udc32\udb83\udfeb\uda1f\udebc\udbcb\udc25\udaec\udc21\udaf6\udee8\ud81e\udfcf\uda25\udf48\ud87d\udfd1\udb39\udcdd\uda28\udeb2\uda34\udcfa\ud81b\ude90\ud907\ude3a\uda20\ude67\ud8ad\udf9a\ud85d\udd33\ud975\udce0\ua3f7\udb88\udfd5\ud9d1\udc38\ud847\udf97\ud92d\udd6c\ud967\udf0a\ud818\udca2\ud9f1\uddc1\ud8a8\udd68\ud84e\ude30\uda22\uded6\ud8b9\udc17\ud9f9\udc97\ud95a\udfac\uda0a\udcff\u4b8c\ud99e\udcc3\udb80\udc9a\uda9f\udfc4\ud9cc\udf8f\udbed\udd53\ud875\udf61\udb48\udfbf\udad6\udc52\udac5\uddb8\ud930\ude03\uda36\udd2d\ud86e\udc9a\udaa5\udeb9\udb5f\udef6\udbc6\udec2\ud812\ude7d\uda06\uddb8\ud98d\udc5d\ud98f\udfb2\udb44\udc92\ud92e\ude8e\udaca\udcb9\ud863\udd25\udaf7\udc17\ud925\udf03\ud8d1\udf8a\uda38\udd7f\ud9f9\ude6a\ud8e0\udf43\udacf\udfe9", "\u559a\u2b5b\ua44a\u8def\ubb30\u7f1d", "\udb2f\udeb0\udb54\udc71\udbeb\udc09\ud9c7\udf52\udb7f\udee9\ud8f6\udf5d\u281d\udb4d\udff1\ud8ec\ude13\uda73\udfbe\uda40\udeca\ud902\udcd8\ud852\udfd0\ud8b4\udeab\udb04\udea0\ud907\udc2f\udb4c\udfd6\ud852\udc28\ud858\uddf4\udbfc\ude11\ud962\udfd6",
        22, 32397, -50049712, -1594140235467465847L, 29350L, true, false, (char) 63697, (char) 60855,
        Double.longBitsToDouble(0x3fe9b11352b93af6L), Double.longBitsToDouble(0x3fdf48b0a4070d1cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
