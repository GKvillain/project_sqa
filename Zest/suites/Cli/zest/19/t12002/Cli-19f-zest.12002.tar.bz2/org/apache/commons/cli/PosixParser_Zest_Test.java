package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 4, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\u3009\u7897\u9fba\uc644", "\ud90d\udd4f\ud860\udfa3\uda3c\udd00",
        33, 48694, -1308691455, 4347250661543800991L, -34929L, true, false, (char) 39163, (char) 27920,
        Double.longBitsToDouble(0x3fe1690c8df4ee95L), Double.longBitsToDouble(0x3fe6dbf3bc9c59d1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 4, "\udad8\udcfa\ud84b\uddb0\ud9d0\udc4a\ud834\udf99\udb65\udc10\uda30\udea9\udaa8\udc58\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\u3009\u7897\u9031\u7de9", "\u1062\ud860\udfa3\uda3c\udd00",
        33, 48694, -1308691455, 4347250661543800991L, -34929L, true, false, (char) 39163, (char) 27920,
        Double.longBitsToDouble(0x3fe1690c8df4ee95L), Double.longBitsToDouble(0x3fe6dbf3bc9c59d1L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 4, "\ud859\udd87\ud889\udfa8\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\uda0f\udf8a\ud89b\udefb\ud951\udf37\ud96f\uddf4", "\u3009\u7897\u9fba\uc644\u0d02\uae92", "\uda3c\udd00\udaec\udebc\uda5f\udda1\ud88b\udf68\ud881\udd00\udb1a\udf5e\uda16\udfb1\udb13\udeba\ud8ed\udf80\udad2\ude32\ud9ac\ude71\ud8be\udd26\udbd1\udd67\ufc26\ud9f7\udc80\udb14\udda8\ud923\udcb3\ud973\udfee\udac9\udef4\uda50\udd84\u0bd8",
        53, 20482, 1403874425, -2272449453968314665L, 7493L, true, false, (char) 41778, (char) 34243,
        Double.longBitsToDouble(0x3fb12d38bbcdfbd8L), Double.longBitsToDouble(0x3fdd07edb37aea78L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 4, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\u3009", "\udbd2\udf72",
        35, 63403, -2131485492, 8134693881883005510L, -58366L, true, false, (char) 15216, (char) 50886,
        Double.longBitsToDouble(0x3fc405d34747c0c4L), Double.longBitsToDouble(0x3fc53973f61ea1d0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 6, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c\udb4f\udcf1", "\u7897\u9fba\uc644\u0d02\u59b3\u6638\ua2c8\u9199", "\ud88b\udf68\ud881\udd00\udb1a\udf5e\uda16\udfb1\udb13\udeba\ud8ed\udf80",
        15, 29263, -292214227, 9112926043811976923L, 6224L, false, false, (char) 9602, (char) 46557,
        Double.longBitsToDouble(0x3fc44a46a34a5a58L), Double.longBitsToDouble(0x3fe640db5625db07L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 4, 4, 2, "\udada\udf09\ud84f\uddb0\udb44\ude65\ud83f\udccd\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\ub41e\u7897\u9fba\uc644", "\ud90d\udd4f",
        -3, 54958, -1849642692, 322954455286739969L, 2241L, false, false, (char) 248, (char) 51272,
        Double.longBitsToDouble(0x3fc0f50e81de5264L), Double.longBitsToDouble(0x3fe1690c8df4ee95L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 3, "\udada\udf09\udaf0\udc97\udb44\ude65\ud847\udd22\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\ud9c8\udce3\ud9a5\udd33", "\u3009\u7897\ub761\uc644", "\ud90d\udd4f\udac5\udd36\udb35\udc4a\ud9bf\udc5a\u99f6\ud88b\udf68\ud881\udd00\udb1a\udf5e\uda16\udfb1\udb13\udeba\ud8ed\udf80\udad2\ude32\udb82\udebc\udab8\ude27\udbd1\udd67\ufc26\ud83f\udd45\uda21\udd1f\ud90c\ude41\ud95f\udc0f\ud910\udefa\ud9cc\udc6f\u7de4\ud80d\ude11",
        23, 15560, -1740632485, -3918914537011397929L, 2238L, true, true, (char) 35746, (char) 58957,
        Double.longBitsToDouble(0x3fbbfdbfffa3a6b0L), Double.longBitsToDouble(0x3fd82be5c4fac914L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud88f\udfd5\udbce\ude67\udb1b\ude37]] |a1=[Ljava.lang.String;:[[\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud88f\udfd5\udbce\ude67\udb1b\ude37]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 5, 4, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud88f\udfd5\udbce\ude67\udb1b\ude37", "\u3009\u7897\u9fba\uc644\u1db2\u593f", "\ud847\udf1f\ud915\uded5\uda5f\udda1",
        15, 51170, -1494847329, -1138904244059962927L, -44107L, false, false, (char) 7307, (char) 38539,
        Double.longBitsToDouble(0x3fe6dbf3bc9c59d1L), Double.longBitsToDouble(0x3fedc7474928b134L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 3, 4, 4, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\ud807\udcc5\ud987\uddc6\ud89f\ude90\ud8df\udecf\ud8a4\ude68", "\u5cf7\u890a\u9fba\u393c", "\ud90d\udd4f\ud860\udfa3\uda3c\udd00\udaec\udebc\uda5f\udda1\ud88b\udf68\uda10\udca7\ue259",
        53, 40280, 930413737, -8984135320774494860L, -74900L, true, false, (char) 3693, (char) 52452,
        Double.longBitsToDouble(0x3fbd76014f8937b8L), Double.longBitsToDouble(0x3fd5c9664dcb9806L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 4, "\udada\udf09\ud84b\uddb0", "\ucc69\u2e38\u3ec3", "\udbce\ude67",
        26, 67156, -1373186356, 4052348380474994888L, -86787L, true, false, (char) 55878, (char) 28155,
        Double.longBitsToDouble(0x3fcf901e8919c390L), Double.longBitsToDouble(0x3fd3c722eabd2380L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 4, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud81f\udfec\ud8ec\udda3\udb41\ude3c\ud905\ude88\ud863\udc47\udb2d\udf93\ud807\udc99\ud9a5\udc9c", "\uc6f5\u7897\u9fba\ub5f5", "\udb40\udd47\ud922\udd44\udb89\ude77\udaec\udebc\udaae\udf3f\ud877\ude84\udb7b\udf47\uda28\udcc8\ud817\uddf2\ud99b\udc49\ud8ed\udf26\udad2\ude32\ud9ac\ude71\ud8be\udd26\udbd1\udd67",
        57, 67756, 1103803505, -716540852665458194L, -22500L, true, true, (char) 20994, (char) 19639,
        Double.longBitsToDouble(0x3fe186f9f0203de1L), Double.longBitsToDouble(0x3f7398792d36fe80L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb78\udc10\udb2d\uddb6\udaa8\udc58\ud987\uddc6\ud89f\ude90\ud986\ude43\ud9a5\udc84]] |a1=[Ljava.lang.String;:[[\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb78\udc10\udb2d\uddb6\udaa8\udc58\ud987\uddc6\ud89f\ude90\ud986\ude43\ud9a5\udc84]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 4, 4, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb78\udc10\udb2d\uddb6\udaa8\udc58\ud987\uddc6\ud89f\ude90\ud986\ude43\ud9a5\udc84", "\u3009\u7897\u9fba\u726b", "\ud8b5\uddca\ud993\udee2\ud9d8\udd3d\udaec\udf07\ud8e7\udd65",
        42, 61392, -1494847329, -1138904244059963088L, 35033L, true, false, (char) 19390, (char) 18567,
        Double.longBitsToDouble(0x3fe6dbf3bc9c59d1L), Double.longBitsToDouble(0x3fc8673a1768fca0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 4, 4, "\ucbe8\ud8b2\udc59\ud9ab\udfbf\ud961\udedf\ud90e\udde6\ud9aa\udf07\udbc3\ude32\ud97f\udcda\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\u3009\u7897\u9fba\uc644", "\uda7e\udf07\ue7e7\uda3c\udd7c",
        30, 68782, 1839948755, 4347251052385824927L, -59248L, false, false, (char) 8157, (char) 28226,
        Double.longBitsToDouble(0x3fe96871ddf422ceL), Double.longBitsToDouble(0x3fe6dbf3bee059d1L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 6, "\udada\udf09\udab6\udfa6\udb44\ude9e", "\u9c1e\ua1b5\u4744\u3e7c\ucf50", "\ud87c\udfc5\ud998\udcb2\ud8e3\udccb\uda23\udd7c",
        46, 10665, 1362049403, -9154660480172164356L, -54628L, true, true, (char) 6341, (char) 15216,
        Double.longBitsToDouble(0x3fc3e78a82829b98L), Double.longBitsToDouble(0x3fe61a6462fdd373L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 2, "\ud863\udcd7\ud84b\udcf9\ud8c0\udf82\ud87a\uddda\ud84f\udc81\uda4c\udc06\udaa8\udc58\ud788\ud89f\udebe\udb6e\udfd6\uda13\udf4f\ud9fb\udd24", "\u1f1d\u1bb3\uc644\u0d02\u59b3\ua217\ua2c8\u9199", "\udbdf\udce4\ud881\udd74\udb1a\udf5e\uda16\udfb1\uda43\ude60\ud8ed\udf80\ud9e6\uded4\udafe\udf52\udaaf\udc9d\udbd1\udd67\ufc26\udabb\udf03\udaf6\udd22\ud806\udedd\ud955\ude55\ucb7b\ud80f\uddc5\udb31\udc88\uda4b\udfe4\ud917\udfd7",
        51, 9105, 1903187454, 9064154792180042669L, 89146L, false, false, (char) 39092, (char) 1641,
        Double.longBitsToDouble(0x3fdb4a608fd14940L), Double.longBitsToDouble(0x3fe1a68439797c0fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 5, 4, "\udada\udf09\ud84b\uddb0\ud8d2\udd6d\ud9c6\udd34\udb65\udc10\uda3a\udcff\udaa8\udc58\udb29\udeb7\ud914\udcc8\ud896\udd6d\ud9a5\udc9c", "\u3009\u7897", "\uda8c\udc3c\udb21\ude43",
        28, 53012, 1915621958, -7944154871350207138L, -69650L, true, false, (char) 29574, (char) 61954,
        Double.longBitsToDouble(0x3fc53973e21ea1d0L), Double.longBitsToDouble(0x3fbde52641690c88L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 0, 4, "\udabe\ude12\ud95b\udf38", "\uccab\u2e38", "\uc861\uda56\ude2b\ud9a5\udc9c\udb4f\udcf1\ud93d\udfd8\ud998\udcb2\ud958\udc45\uda14\udfa2\ud957\udd32",
        36, 93015, -1033702626, 8134693878791302709L, 27437L, false, false, (char) 10352, (char) 12923,
        Double.longBitsToDouble(0x3fd35f7a13a3e06eL), Double.longBitsToDouble(0x3fc53973e21ea1d0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 4, "\000", "\000", "\ud800\udce5",
        3, 38632, -771695332, 22841456418881536L, -100000L, false, false, (char) 42495, (char) 52322,
        Double.longBitsToDouble(0x3fdd9d9162f74196L), Double.longBitsToDouble(0x3fc98a25f0000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 0, 0, "\udbdd\udd8a\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c\udb4f\udcf1\ud87c\udfc5\ud998\udcb2\ud8e3\udccb\uda23\udd7c\udbdc\ude17\ud882\udc97\udade\ude53\ud933\uddf1\ud860\udfa3\uda3c\udd00\ud926\ude52\ud842\ude04\ud88b\udf68\ud881\udd00\udb1a\udf5e\uda16\udfb1\udb13\udeba\ud8ed\udf80\udad2\ude32\ud9ac\ude71\u2a2a\udbd1\udd67\ufc26\uda84\ude47\ud852\ude84\udaa5\ude6b\ud908\udd5c\ud87b\udec1\udbcb\udf5a\udac2\udc49\u0fb2\uda6c\udc1b\ud92b\udd60\ud981\udfb5", "^\u339c\ua17a\u744e\u3593\uced1\u6b5e\ub84f\u4ac7\u1044\uca37\u9bd2\u1985\u159e", "\u3029\uda27\udf86\ud83e\udd15\ud9a7\udf7d\uda85\udc5a\u55a6\ud823\uddb0\ud949\ude72\uda87\ude45\udb27\uddb2\ud81a\udd2e\udb45\ude48\udb05\udd56\ud8b7\udee3\ud841\ude92\udbc6\udece\ud971\udcc4\ud8fe\udec7\uda57\udfd9",
        1, 38228, 1628512933, -4538583802047978045L, -31991L, true, true, (char) 53492, (char) 33639,
        Double.longBitsToDouble(0x3fe00fe7f6a085d0L), Double.longBitsToDouble(0x3fe13e8389a795d8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 6, 2, "\udb3c\udd79\ud989\udfda\uda5c\udeb5\ud840\udc88\udb65\udc10\ud954\udc2c\ud922\udf56\udbca\udcf4\ud89f\ude90\ud925\udeb5\ud9a5\udc9c\ud8d1\udc6f\ud87c\udfc1\ud90e\udca0\udb78\ude63\udab2\udd5f\udbdc\ude17\uda8c\udc3c\udb21\ude43", "\u5773\u05bb\ubaad", "\udb1a\udf5e\uda16\udfb1\udb13\udeba\ud8ed\udf80\udad2\ude32\ud9ac\ude71\udb53\udfb0",
        -3, 20606, 1233152938, 1944058005051907575L, -59055L, false, true, (char) 55712, (char) 65495,
        Double.longBitsToDouble(0x3fd2d63cfa2405d0L), Double.longBitsToDouble(0x3fe2d7c17088e84cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 4, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb7d\udfe1\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\u3009\u7897\uafa8\u1287", "\ud91e\udf6d\ud860\udfa3",
        -2, 98564, 75203871, -5620786998767482510L, 44224L, true, true, (char) 11848, (char) 39163,
        Double.longBitsToDouble(0x3fbdd76651690c88L), Double.longBitsToDouble(0x3fdf4ee95db6fceeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 5, 1, "\ud98a\udf1e\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\ud8a4\ude11\ud9a5\udd11", "\u3009\u9897\u43bc\ub488", "\ud936\ude23\ud860\udfa3\ud9da\uded0",
        22, 28925, -758385663, -6522838559150250650L, -18477L, false, false, (char) 64554, (char) 27920,
        Double.longBitsToDouble(0x3fe1690c8df4ee95L), Double.longBitsToDouble(0x3fe6dbf3bc9c59d1L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 4, "\udada\udf09\udb98\udfa3\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\udacb\udea8\ud89f\ude90\udbce\ude67\ud9a5\udc9c\udb4f\udcf1\ud87c\udfc5\ud998\udcb2\uda71\udcd2\uda23\udd7c\udbdc\ude17", "\u6638\ua2c8\u9199", "\ud88b\udf68\ud881\udd00\udb1a\udf5e\uda16\udfb1\udb13\udeba\ud8ed\udf80",
        15, 62407, -290447112, 9112926043811976923L, -66681L, true, true, (char) 55475, (char) 22806,
        Double.longBitsToDouble(0x3fe64143a67ba351L), Double.longBitsToDouble(0x3fd5e423e9b46270L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 4, 0, 2, "\ud919\udf6f\udb07\udd82\ud827\udd67\ud855\udc1a\udb65\udc10\udb98\uddbb\ud9b2\ude57\ud848\udeb3", "\u235e\uc98f\uaf95\u3009\u78b7\u9fba\uc644\u5447\ub752\uc5e3\ua219\u889e\ubd0d", "\ud881\udd00\uda5e\udf40",
        52, 91030, -1464829380, -7738890021350811529L, -74900L, true, false, (char) 3693, (char) 2831,
        Double.longBitsToDouble(0x3fea5288f286827eL), Double.longBitsToDouble(0x3fe14faab2312d95L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 6, "\udada\udf98\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c\udb4f\udcf1\ud87c\udfc5\ud998\udcb2\ud8e3\udccb\uda23\udd7c\udbdc\ude17\uda8c\udc3c\udb21\ude43\ud90d\udd4f\ud860\udfa3\uda3c\udd00\udaec\udebc\uda5f\udda1\ud88b\udf68\ud8d5\ude6a\uda94\udcf6\uda16\udfb1\udb13\udeba\ud8ed\udf80\udad2\ude32", "\uabd7\u214f\u4e20\u00f5\u3e5d", "\ud8c1\udf7a\ud8c0\udf7f\udab2\ude6b\uda54\ude6f\ud8ac\udc9a\ud88a\udcee\ud9a8\udf67\uda0c\udfc3\ud8a2\udc88\uda95\udd64\ud9d9\udffe\ud869\udd19\udaa8\udc3b\udab1\udd70\udbef\udd52\ud856\udf4b\ud9dd\udde1\udb10\udd5a\udba3\uddbd\ud9aa\udc69\udba4\udc09\uda1a\udec2\ud8ad\udc0b\udaca\ude4c\udb1f\udf7f\uda46\udf48\udac7\udd31\ud929\udcb5\udbc1\udfd2\udafa\udf62\uda06\udf94\ud864\udd10\udbf8\udf69\udb45\udc0f\ud974\udf9d\uda8e\udc8c\udbe6\udceb\uda24\udcd7\udbbd\udff9\uda69\udf5d\udb33\udc30\udbd6\uddf2",
        11, 91509, -873458584, 4227647806843359702L, 89745L, true, true, (char) 45765, (char) 21385,
        Double.longBitsToDouble(0x3fef57228123aa45L), Double.longBitsToDouble(0x3fe2593ef7ba87b6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud88f\udfd5\udbce\ude67\udb1b\ude37]] |a1=[Ljava.lang.String;:[[\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud88f\udfd5\udbce\ude67\udb1b\ude37]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 4, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud88f\udfd5\udbce\ude67\udb1b\ude37", "\u3009\u7897\u9fba\uc644\u1db2\u593f", "\ud847\udf1f\ud915\uded5\uda5f\udda1",
        15, 51170, -1494847329, -1138904244059962927L, -44107L, false, false, (char) 7307, (char) 25373,
        Double.longBitsToDouble(0x3fe6dbf3b99c59d1L), Double.longBitsToDouble(0x3fb080cdc0d8cb10L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udb44\udc99\ud84b\uddb0\udb07\udc66\udadc\ude7c\udbfa\udda2\ubb7c\udaa8\udc58\ud987\uddc6\ud913\udf18\ud8f4\uddb2\udbe8\udde7]] |a1=[Ljava.lang.String;:[[\udb44\udc99\ud84b\uddb0\udb07\udc66\udadc\ude7c\udbfa\udda2\ubb7c\udaa8\udc58\ud987\uddc6\ud913\udf18\ud8f4\uddb2\udbe8\udde7]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 5, 4, "\udb44\udc99\ud84b\uddb0\udb07\udc66\udadc\ude7c\udbfa\udda2\ubb7c\udaa8\udc58\ud987\uddc6\ud913\udf18\ud8f4\uddb2\udbe8\udde7", "\u3009\u7897\u9fba\uc644\u1db2\u593f", "\ud9de\udf65\udb2e\udd70\udacc\udd32",
        23, 95978, -1494847329, -1138904243038746415L, 11134L, true, false, (char) 7307, (char) 38539,
        Double.longBitsToDouble(0x3fe6dbf3bc9c59d1L), Double.longBitsToDouble(0x3fedc7474928b134L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 4, "\ud923\udcd1", "\u6cbd", "",
        -5, 63384, 1494823424, 9250311593338415L, -3896L, false, true, (char) 14596, (char) 48375,
        Double.longBitsToDouble(0x3ce6000000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udada\udf93\ud84b\uddb0\ud822\uddf3\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\udb9e\udf84]] |a1=[Ljava.lang.String;:[[\udada\udf93\ud84b\uddb0\ud822\uddf3\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\udb9e\udf84]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \udada\udf93\ud84b\uddb0\ud822\uddf3\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\udb9e\udf84]] |a1=[Ljava.lang.String;:[[\udada\udf93\ud84b\uddb0\ud822\uddf3\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\udb9e\udf84]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 4, "\udada\udf93\ud84b\uddb0\ud822\uddf3\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\udb9e\udf84", "\ua6df\u6f78\u2597\u947a", "\udbdc\ude17\uda2b\udc6b\udb21\ude8c\ud90d\udd4f\ud882\ude43\ud847\udf1f\ud915\uded5\uda5f\udda1\udab2\udc5b\ud881\udd00\udb1a\udf5e",
        49, 44049, -1468728151, 316137817311194716L, -74693L, true, false, (char) 23242, (char) 9958,
        Double.longBitsToDouble(0x3fd28b1341ce7872L), Double.longBitsToDouble(0x3fe0e1a29f9172ceL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\udada\udf09\ud834\ude45\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udd11\udaa8\udc58\udb12\udfec\ud890\udc36\udbce\ude67]] |a1=[Ljava.lang.String;:[[\udada\udf09\ud834\ude45\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udd11\udaa8\udc58\udb12\udfec\ud890\udc36\udbce\ude67]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 2, 2, "\udada\udf09\ud834\ude45\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udd11\udaa8\udc58\udb12\udfec\ud890\udc36\udbce\ude67", "\uaf95\u3009\u7897\u9fba\uc644\ubd96\u593f\u6638\ua1cb\u00a3\ua8c7\ubaad\u5557", "\uda16\udfb1",
        26, 12849, 73606571, -3898236715379830108L, 58076L, false, false, (char) 44193, (char) 16988,
        Double.longBitsToDouble(0x3fe1261f43fe5916L), Double.longBitsToDouble(0x3fd8e8e87d148226L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 5, 2, "", "", "\udb64\udfec",
        34, 59037, 194, 6420218358555270428L, -98751L, false, false, (char) 33672, (char) 60,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fdd9d90000001beL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 3, 1, "\udbd3\udd0e\ud84b\uddb0\uda36\uded4\ud923\udf75\ud932\udd83\ud885\udc7e\udae3\udd53\u2131\ud9c0\ude03\uf907\udbcf\udd9a\ud8da\udc8d\udac0\udefa\ud9b5\udfc2\udaed\udc70\uda6f\udd13\udbdc\ude17\ud971\udf6e\udb21\uddcf\udabf\udd0b\ud931\udd1a\ud831\ude2f\uda39\udfc4", "\ud0f2\uba96", "\ud870\ude8b\udbf0\ude8d\udb4a\udeda",
        12, 64872, 1494544813, -1663600006735281224L, -77274L, true, false, (char) 64984, (char) 12436,
        Double.longBitsToDouble(0x3fb590e69b7f5988L), Double.longBitsToDouble(0x3fe3422f67d01748L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\000", "\u1af5\uaf14\000", "",
        32, -1000, 0, 0L, 73862L, false, false, (char) 47377, (char) 53247,
        Double.longBitsToDouble(0x3fd0000198000000L), Double.longBitsToDouble(0x3fcf901e8119c390L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 3, 4, "\ucbe8\ud8b2\udc59\ud9ab\udfbf\ud961\udedf\ud90e\udde6", "\u5f47", "\ud9a5\udc9c\udb4f\udcf1\ud87c\udfc5\ud998\udcb2\ud8e3\udccb",
        45, 45691, -1597303335, 5849957640882691308L, 26270L, false, true, (char) 8364, (char) 37281,
        Double.longBitsToDouble(0x3fe5e77d589f3c54L), Double.longBitsToDouble(0x3fa6d3737306b890L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 4, "\ucbe8\ud8b2\udc59\ud9ab\udfbf\uda50\ude35\u8f2a\ud9aa\udf07\udbc3\ude32\ud97f\udcda\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\u3009\u7897\u9fba\uc644", "\uda7e\udf07\ue7e7\ud867\udf0d",
        -2, 68782, 1839948755, 4347251052385824927L, 85648L, false, false, (char) 8157, (char) 28226,
        Double.longBitsToDouble(0x3fe96871ddf422ceL), Double.longBitsToDouble(0x3fe6dbf3bee059d1L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 5, 1, "\ucbe8\ud8b2\udc59\ud9ab\udfbf\ud961\udedf\ud90e\udde6\ud9aa\udf07\udbc3\ude32\ud97f\udcda\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\u3009\u7897\u9fba\uc644", "\uda7e\udf07\ue7e7\uda3c\udd7c",
        30, 68782, -493984813, 1667598604513888463L, -59248L, false, false, (char) 8157, (char) 28226,
        Double.longBitsToDouble(0x3fe96871ddf422ceL), Double.longBitsToDouble(0x3fe6dbf3bee059d1L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 3, "\ucbe8\ud8b2\udc59\ud9ab\udfbf\ud961\udedf\ud90e\udde6\ud9aa\udf07\udbc3\ude32\ud97f\udcda\ud89f\ude90\udbce\ude67\uda13\ude7f", "\u3009\u3b5f\u9fba\uc644\u0d02\u59b3\u2403\ucad6\u4297\ub3b5\ua89f\u1dce\ud14d\ucf04\u71a1\ua5df\u1b22\u0b5a\uc003\u106e", "\udb69\udd20\udb98\udf79\ud902\udd34\uda3e\udd2e\udbc2\udd67\udbe6\ude70\ud8f9\ude94\ud8b3\ude45\ud80c\udc44\ud835\udf5e",
        5, 5226, -442824669, -2463133465330275250L, -48843L, true, false, (char) 18158, (char) 54397,
        Double.longBitsToDouble(0x3fd41f2b74036e48L), Double.longBitsToDouble(0x3fd738601620d12eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udada\udf09\ud9b2\udde4\udb44\ude65\ud850\udd25\ud967\udff5\uda3d\udd21\udaa8\udc5e\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c]] |a1=[Ljava.lang.String;:[[\udada\udf09\ud9b2\udde4\udb44\ude65\ud850\udd25\ud967\udff5\uda3d\udd21\udaa8\udc5e\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\udada\udf09\ud9b2\udde4\udb44\ude65\ud850\udd25\ud967\udff5\uda3d\udd21\udaa8\udc5e\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c]] |a1=[Ljava.lang.String;:[[\udada\udf09\ud9b2\udde4\udb44\ude65\ud850\udd25\ud967\udff5\uda3d\udd21\udaa8\udc5e\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udada\udf09\ud9b2\udde4\udb44\ude65\ud850\udd25\ud967\udff5\uda3d\udd21\udaa8\udc5e\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\u3009\u7897\u30d8\u3e55\u43df\ua35f\u0158", "\ud899\uddd2\uda69\udd62\ud88b\udf68",
        55, 52671, -265171808, -3858175508999194379L, 58329L, false, false, (char) 65497, (char) 7081,
        Double.longBitsToDouble(0x3fe058782878752eL), Double.longBitsToDouble(0x3fe1422d28439f99L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 1, 4, "\u07fd", "\u87b2\u6202\u2f29", "\ud920\udd35\ud853\ude27\ud9a5\udd68\udb4f\udcf1\ud87c\udfc5\ud998\udcb2\ud8e3\udccb\udaf9\udee5\uda80\udc41",
        30, 42873, -992558018, 8098872587434463814L, 22619L, true, true, (char) 45379, (char) 4163,
        Double.longBitsToDouble(0x3fce8391752ea26cL), Double.longBitsToDouble(0x3fc8b4a7820ec5d0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 4, "\u07fd", "\u15f3\u6202\u2f29", "\ud920\udd35\ud853\ude27\ud9a5\udd68\udb4f\udcf1\ud92c\uddb0\ud998\udcbf\ud8e3\udccb\udaea\udee5\ud94b\udec7",
        17, 42934, -992558018, 8098872587434463814L, 22619L, true, true, (char) 12611, (char) 57709,
        Double.longBitsToDouble(0x3fce8391752ea26cL), Double.longBitsToDouble(0x3fc8b4a7820ec5d0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 4, 4, "\udada\udf09\ud84b\uddb0\udb44\ude65\ud850\udd25\udb65\udc10\uda3a\udcff\udaa8\udc58\ud987\uddc6\ud89f\ude90\udbce\ude67\ud9a5\udc9c", "\u3009\u7897\u9fba\uc644", "\ud90d\udd4f\ud860\udfa3\uda3c\udd00",
        33, 48694, -1308691455, 4347250661543800991L, -34929L, true, false, (char) 39163, (char) 27920,
        Double.longBitsToDouble(0x3fa690c8df471cb0L), Double.longBitsToDouble(0x3fe6dbf3bc9c59d1L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 5, 1, 6, "\uda66\udf9a\ud992\uddec\uda7b\udc89\udb3e\udf92\udb0a\ude22\udbbc\uddfe\u043f\000\ud89f\ude40\000\000\000\ud942\ude6c\udb67\udfa8\udb4a\udf74\ud80c\udd1b\u9c86\ud804\udfc7\ud95b\uded3\udb63\udcdd\uda77\udca4\udbd2\udc4e\udb7b\udde2\ud9e7\udfbf\udbed\udc8d\ud886\udc43\uda17\uddb5\ud959\udcf5\ue08b\ud919\udd7b\ud864\udfb8\udb22\udfc2\uda1d\udd6f\udbe2\udd3e\udbd7\ude24\uda18\ude21\udafb\ude0d", "\u8afe\u3635\u03bf\u727a\u9622\u7b65\u83c4M\u8d0b\u5370\u528b\u284d\u79da\u3ecf\ub8f3\uac47\ud1f5\u9484\u8b7e\u6b2b\u026c\u5b93\uc5d0\ub465\ub4b0\u5356\u2d1c\u5f12\u644a\u3d9d\u6841\ud1d5\u9c22\u1e1e", "\udbbb\udd81\udae3\udf80\ud82d\ude46\ud8b7\udc75\ud8d2\uddb9\ud99e\udd36\udad1\udfb1\ud9ff\udf9f\uda1f\udff8\ud9bb\udea7\ud94a\udc2b\ud822\udcc0\ud962\udf55\uda44\udc46\udb4e\ude08\ud8c5\udc6c\ud9cf\udc41\ufca1\uda2f\udf71\ud9ce\udfda\udb36\udc3c\ud95c\udf85\ud96a\udde3\udb83\udfb0\ud8b5\udfca\ud9fa\udff3\udacb\ude6f\ud835\uddda\uda61\ude92\ud9c4\udecf\udbfa\udc33\ud980\ude4d\ud820\udd41\udbd1\udcd4\ud954\udeeb\ud861\ude85\ud9a1\udfa1\udb1f\udef8\udafb\uddfa\uda54\udc97\ud857\ude00\udb39\udd00\ud960\ude08\ud869\udef3\udab7\ude05\udb84\udc83\udb12\udda5\udb5b\udd2b\ud9f8\udd72\ud9f5\udffb\uda6a\udf24\ud814\udd87\ud831\udef4\ud8d5\ude21\uda14\udec7\ud80e\udebc\ud870\udf7b",
        56, 59767, -2071978132, -2653156906895980664L, 90069L, true, true, (char) 39834, (char) 46646,
        Double.longBitsToDouble(0x3fec2977cdbbfbf0L), Double.longBitsToDouble(0x3fdafe3e9e517794L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udbd3\udd0e\ud8f4\udf29\uda36\uded4\ud923\udf75\ud932\udd83\ud8a5\ude8e\udb95\uddf1\udb01\ude73\udaaf\udd38\uf907\udbcf\udd9a\ud898\ude8b\ud969\udcd2\ud8b2\udcd8\udbbb\udcb7\ud9c2\udd6e\udaa3\udcb4\ud971\udf29\udb21\ude48\udabf\udd0b\ud931\udd1a\ud914\udce1\ud879\udf5c\uda43\udf4b\ud932\udfed\ud931\uddcf\ud8d0\udd14\udab9\ude23\ud811\udccd\uda97\udc7d\uda9f\uddc9\udb4a\udeda\ud8ed\udc02\ud954\udfb9\udbbd\udeec\udab4\udf3f\ud91b\ude8a\ud8a0\udfe6\ud832\udcae\uda6f\udd87\udaf3\udede\ud9d6\udf3d\udadb\udfa0\ud960\udc34\ud845\udd05\udb89\udf8d\ud8c2\uddc7\uda2b\ude36\uda0a\udc43\ud82c\udf4c\udadb\udfca\u4680\udb26\udf51\ud892\udf34\ud863\udc6a\ud9f7\udd59\uda87\udeb7\ud9a4\udd87\ud9e4\udcef\uda25\udd9a\uda3d\udc30\ud900\udcba\ud8aa\udfb6\uda54\udffc\ud93c\udeaf\ud9fe\uddca\ud965\ude6c\ud8ee\udcd7\ud855\udc74\ud8de\udfd4\ud85d\udd92\u882d\ue540\ud822\udfdd\udbd0\udf11\ud896\ude9a\uda8a\udcf5\u875d\ud923\udf4a\udbee\uddb3]] |a1=[Ljava.lang.String;:[[\udbd3\udd0e\ud8f4\udf29\uda36\uded4\ud923\udf75\ud932\udd83\ud8a5\ude8e\udb95\uddf1\udb01\ude73\udaaf\udd38\uf907\udbcf\udd9a\ud898\ude8b\ud969\udcd2\ud8b2\udcd8\udbbb\udcb7\ud9c2\udd6e\udaa3\udcb4\ud971\udf29\udb21\ude48\udabf\udd0b\ud931\udd1a\ud914\udce1\ud879\udf5c\uda43\udf4b\ud932\udfed\ud931\uddcf\ud8d0\udd14\udab9\ude23\ud811\udccd\uda97\udc7d\uda9f\uddc9\udb4a\udeda\ud8ed\udc02\ud954\udfb9\udbbd\udeec\udab4\udf3f\ud91b\ude8a\ud8a0\udfe6\ud832\udcae\uda6f\udd87\udaf3\udede\ud9d6\udf3d\udadb\udfa0\ud960\udc34\ud845\udd05\udb89\udf8d\ud8c2\uddc7\uda2b\ude36\uda0a\udc43\ud82c\udf4c\udadb\udfca\u4680\udb26\udf51\ud892\udf34\ud863\udc6a\ud9f7\udd59\uda87\udeb7\ud9a4\udd87\ud9e4\udcef\uda25\udd9a\uda3d\udc30\ud900\udcba\ud8aa\udfb6\uda54\udffc\ud93c\udeaf\ud9fe\uddca\ud965\ude6c\ud8ee\udcd7\ud855\udc74\ud8de\udfd4\ud85d\udd92\u882d\ue540\ud822\udfdd\udbd0\udf11\ud896\ude9a\uda8a\udcf5\u875d\ud923\udf4a\udbee\uddb3]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 5, 3, "\udbd3\udd0e\ud8f4\udf29\uda36\uded4\ud923\udf75\ud932\udd83\ud8a5\ude8e\udb95\uddf1\udb01\ude73\udaaf\udd38\uf907\udbcf\udd9a\ud898\ude8b\ud969\udcd2\ud8b2\udcd8\udbbb\udcb7\ud9c2\udd6e\udaa3\udcb4\ud971\udf29\udb21\ude48\udabf\udd0b\ud931\udd1a\ud914\udce1\ud879\udf5c\uda43\udf4b\ud932\udfed\ud931\uddcf\ud8d0\udd14\udab9\ude23\ud811\udccd\uda97\udc7d\uda9f\uddc9\udb4a\udeda\ud8ed\udc02\ud954\udfb9\udbbd\udeec\udab4\udf3f\ud91b\ude8a\ud8a0\udfe6\ud832\udcae\uda6f\udd87\udaf3\udede\ud9d6\udf3d\udadb\udfa0\ud960\udc34\ud845\udd05\udb89\udf8d\ud8c2\uddc7\uda2b\ude36\uda0a\udc43\ud82c\udf4c\udadb\udfca\u4680\udb26\udf51\ud892\udf34\ud863\udc6a\ud9f7\udd59\uda87\udeb7\ud9a4\udd87\ud9e4\udcef\uda25\udd9a\uda3d\udc30\ud900\udcba\ud8aa\udfb6\uda54\udffc\ud93c\udeaf\ud9fe\uddca\ud965\ude6c\ud8ee\udcd7\ud855\udc74\ud8de\udfd4\ud85d\udd92\u882d\ue540\ud822\udfdd\udbd0\udf11\ud896\ude9a\uda8a\udcf5\u875d\ud923\udf4a\udbee\uddb3", "\ub171\u8a68\u454c\ub68f\u2ed1\u0ecd", "\ud87c\udd5d\ud960\ude36\uda98\udcbe\ud97f\ude7f\ud973\udc2e\ud95b\ude68\ud850\udd47\ud834\udf6b\u826c\ud93f\udc25\ud8ab\udc5f\u336a\udb53\uddbb\udaaf\ude91\ud9d9\udd1f\udae3\udfde\ud8b9\ude8b\udb5e\udfc2\uda5c\udcef\u1004\uf866\ud8ef\udf1f\ud8e8\udca9\ud8db\udc16\udb02\udf7a\ud901\udc4b\uda59\udd93\ud9fb\udd91\ud8c8\udca6\ud9e4\udea2\uda11\udd3a\udbeb\udf15\udb62\uddae\udac7\udeb3\udb6c\udce0\udaa0\ude21\udbc1\udcd5\udb83\ude8a\ud9d7\udf03\ub93f\ud917\udfc6\ud8d3\udf2d\udabb\udc59\udb0c\udeeb\ud8a8\udf99\ud91b\udf22\ud994\udc8a\uda3d\udcd8\ud94c\udc99\ud80f\udd35\ud98d\udcde\udb2e\udd85\udb42\udcf3\ud870\udc92\udbbb\udd45\udb58\udcaa\uda1d\udcdf\uda66\udc6e\uda73\udd9f\ud824\ude26\ud83d\udf0f\ud87b\udc85\udbbb\udeda\ud8ec\udeb4\uda05\uded1\ud99b\udec4\udb7e\udd37\udbb1\ude53\uda20\udce4\ud95d\udc52",
        3, 32694, 987287694, -8955399120681216754L, -14269L, true, false, (char) 64979, (char) 28879,
        Double.longBitsToDouble(0x3fdedf1b22f02a0eL), Double.longBitsToDouble(0x3fe98bf33bca986cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
