package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 6, 4, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\u2b6e\u814f\ud132\u9c3f", "\ud856\udf02\udb0c\udefc\uda79\udee4",
        26, 90346, -1062063999, 2290409721005165695L, -99367L, false, true, (char) 57598, (char) 31542,
        Double.longBitsToDouble(0x3fc4a752a9f78ea0L), Double.longBitsToDouble(0x3fe6bc90266ef69aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\u00a6\000\u8f72\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\u00a6\000\u8f72\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 6, 4, "\u00a6\000\u8f72\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\u2b6e\u814f\ud132\u9c3f", "\ud856\udf02\udb0c\udefc\uda79\udee4",
        26, 90346, -1062063999, 2290409721005165695L, -99367L, false, true, (char) 57598, (char) 31542,
        Double.longBitsToDouble(0x3fc4a752a9f78ea0L), Double.longBitsToDouble(0x3fe6bc90266ef69aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\ud96a\uddab\ud893\udf71\udbbc\udcfa\ud8d2\udef2\ud9ed\udc0d", "\u2b6e\u814f\ud132\u9c3f", "\uda05\udc9c\udb0c\udefc\uda79\udee4",
        26, 90346, -1062063999, 41987608368070125L, -98903L, true, false, (char) 63846, (char) 57803,
        Double.longBitsToDouble(0x3fe4cad182dc70ecL), Double.longBitsToDouble(0x3fdd79204cdded34L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udb29\udeeb\udade\udd38\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udb29\udeeb\udade\udd38\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 6, 4, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udb29\udeeb\udade\udd38\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\u2b6e\u814f\ud132\ua930", "\ud856\udf02\udb0c\udefc\uda79\udee4\uda68\udc44\ud813\udf0d\udbd5\udcc5\udb89\ude21\udaed\uddd4\ud8ba\udf49\udbc0\udd66\ud954\udf58\ud9e5\udfff\udb55\udff7\ud98f\udef9\udaf1\udc01\ud8b1\ude49\uab61\u297b\uda27\udc48\uda98\ude23",
        2, 44907, -1440971328, -5292864134551955986L, -31340L, false, false, (char) 10893, (char) 8227,
        Double.longBitsToDouble(0x3fbbf1fbbcf3aae8L), Double.longBitsToDouble(0x3fd913174aa6bffcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 4, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\000", "\udb19\udf2c",
        11, 9488, 1337964111, 6551978386782935779L, -23456L, true, false, (char) 6074, (char) 56965,
        Double.longBitsToDouble(0x3fe9f20dfb60459fL), Double.longBitsToDouble(0x3fc098d64294ea54L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 5, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud906\udeac\ud894\ude1c\ud92f\udc94\udab0\udd5c\ud9a8\ude06\udb86\ude07\ud904\udfbb", "\ud09f\u814f", "\ud8c6\udde2",
        42, 16111, -1360179807, -8520885533006245237L, 18655L, false, true, (char) 27720, (char) 6074,
        Double.longBitsToDouble(0x3fd87e0fe67c837eL), Double.longBitsToDouble(0x3feb00d0dc84c6b2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 5, 5, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\ud8dc\udd20\ud97c\uddc2\uda46\uddf9\ud957\udf6b\uda4b\udd4b\udb06\udf6a", "\u3b6f\u814f\ud132\u9c3f", "\ud856\udf02\udb0c\udefc\uda79\udee4",
        26, 90346, -1062063999, 2290409721005165695L, -8487L, false, true, (char) 41985, (char) 9425,
        Double.longBitsToDouble(0x3feeb1d4a97da9eaL), Double.longBitsToDouble(0x3fe37b153f6a5c29L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud87c\udefb\ufa46\ud8de\uddbf\ud8b3\udee5\uda60\udf42\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\ufa46\ud8de\uddbf\ud8b3\udee5\uda60\udf42\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 6, 5, "\ud87c\udefb\ufa46\ud8de\uddbf\ud8b3\udee5\uda60\udf42\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\u2b6e\ud135\ud132\u4c9c", "\ud856\udf02\udb0c\udefc\uda79\udee4\udb90\udead\ud80a\udd8d\udbd5\udcc5",
        15, 94791, -1191254080, 6016651185977522011L, 50396L, true, false, (char) 31976, (char) 64157,
        Double.longBitsToDouble(0x3fd9c85f9d8cc2ecL), Double.longBitsToDouble(0x3fe88a982bbf5704L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 6, 4, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\u4d1e\u8153\ud132\u9c3f\u9809\ua110", "\uda79\udee4\uda68\udc44\ud813\udf0d\udbd5\udcc5\uda0b\udd61\udaed\ude0c\ud8ba\udf49\udbc0\udd66\ud954\udf58\ud9e5\udfff\udb55\udff7\ud98f\udef9\udaf1\udc01\ud8b1\ude49\ud9e6\ude9f\ud842\ude88\udbe8\udfd1\ud882\udd0f\udb8d\ude36\ud9ba\ude31\udab2\udf61\ud8a7\ude26\ud889\udf66\ud8c0\ude22\udaa3\udc2a\ud8dd\udf8a\ua561",
        46, 48471, 2048835100, -2999469653789802470L, 56263L, false, false, (char) 32986, (char) 18027,
        Double.longBitsToDouble(0x3fd9ce3bdb051236L), Double.longBitsToDouble(0x3fd5eec24dbb3b4eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 3, 4, "\ud87c\udefb\uda4d\ude7f\udb42\ude5d\ud9c1\ude4c\uda74\udf6c\ud9f1\udf91\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a\ud8a8\ude53\u33fb\ud9e6\udcde\ud988\udca2\udb01\udf4c\ud9ed\udc47\ud8c6\udde2\udb94\udff6\ud856\udf87\udb0c\udefc", "\u3279", "\ud877\udf4f\uda3e\ude0a\ud9c1\udc6a\ud954\udf58\udbf6\ude4b\ud94f\ude75\ud98f\udef9\udaf1\udc01\ud8b1\ude49\ud800\udc0b\udb29\udc6d\ud99e\udc39\udace\udf8a\uda4a\udd72\ua319",
        41, 45873, -4808878, 2638637919836139591L, -42220L, false, false, (char) 14156, (char) 55851,
        Double.longBitsToDouble(0x3fcd5cb9fb916f94L), Double.longBitsToDouble(0x3fed486c80c4a4b2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\000\000\uda74\udf03\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\ud9e2\udc1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\000\000\uda74\udf03\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\ud9e2\udc1a]] |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 6, 4, "\ud87c\udefb\uda4b\udf3e\000\000\uda74\udf03\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\ud9e2\udc1a", "\u2b6e\u814f\ud132\u9c3f", "\ud856\udf02\udb0c\udefc\uda79\udee4",
        26, 44946, -1062063999, 56624307664584704L, -8704L, false, false, (char) 54073, (char) 34341,
        Double.longBitsToDouble(0x3fe6bc90266ef69aL), Double.longBitsToDouble(0x3fef947c21a7ab37L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud84c\udc72\ud924\udd0e\uda74\udf6c\udb28\udf8c]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud84c\udc72\ud924\udd0e\uda74\udf6c\udb28\udf8c]] |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 6, 3, "\ud87c\udefb\uda4b\udf3e\ud84c\udc72\ud924\udd0e\uda74\udf6c\udb28\udf8c", "\ud2bb\u498f\u4f0b\u546e\u629a\u814f", "\ud8c6\udde2",
        42, 16111, 1525501345, -4883068703106994805L, 18655L, false, true, (char) 27720, (char) 6074,
        Double.longBitsToDouble(0x3fd87e0feba6837eL), Double.longBitsToDouble(0x3feb022cfc84c6b2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\ud89c\udfc6\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\ud89c\udfc6\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\ud89c\udfc6\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\ud89c\udfc6\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 6, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\ud89c\udfc6\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\ua562", "\uda25\udff2\udb8d\udc4c\udb95\udcdf\ud856\udf02",
        25, 27971, -647638389, -5411159088965275519L, 77041L, true, true, (char) 56965, (char) 47409,
        Double.longBitsToDouble(0x3feb022cfc84c6b2L), Double.longBitsToDouble(0x3fc4a752aa1b8ea0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 6, 4, "\ud87c\udefb\uda4b\udf3e", "\u6423\u769d\ub72f\u4ec4\u4882\u498f\u170c\u546e\u2184\uca8f", "\udad4\udf0a",
        9, 16111, 1525501345, -4883068703108377973L, 18655L, false, true, (char) 16475, (char) 6074,
        Double.longBitsToDouble(0x3fd87e0fee7c837eL), Double.longBitsToDouble(0x3feb022cfcab59dbL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 4, 5, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\u2b6e\u814f\ud132\u9c3f\u9809\ua110\ub4d3\u5965\ua0f7", "\udbd5\udcc5\uda0b\udd61\udaed\ude0c\ud8ba\udf49\udbc0\udd66",
        49, 44656, 982889604, -2042214598420684163L, -90754L, true, true, (char) 24801, (char) 46088,
        Double.longBitsToDouble(0x3fe49be1b84231a9L), Double.longBitsToDouble(0x3fee2045020bdcf0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbe7\ude76\uda1c\udebd]] |a1=[Ljava.lang.String;:[[\udbe7\ude76\uda1c\udebd]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 3, 0, "\udbe7\ude76\uda1c\udebd", "\u6423\u769d\ub72f\u4ec4\ub3ad\u498f\u170c\u546e\u7cd5\u0bfb\ud132\u9c3f", "\ud856\udf02\udb0c\udede\uda79\udee4",
        26, 90346, -1062063999, 2290409721005165695L, -99367L, false, true, (char) 57598, (char) 31542,
        Double.longBitsToDouble(0x3fc4a752a9f78ea0L), Double.longBitsToDouble(0x3fe6bf94ae6ef69aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 5, 4, "\ud87c\udefb\uda4b\udf3e\ud816\udc38", "\u769d\u5614\ud7fd\u2697\u6b72\u949a\u55aa\ubd0f\u814f\ud132\u9c3f\u9809\ud291\u4279\u5965\uba91\u7dd8\u3279\ua579\u312e", "\udbc0\uddb4\ud954\udf58\ud9e5\udfff\udb55\udff7\ud9ba\udc02\udaf1\udc01\ud8b1\ude49\uda92\udc94\ud80a\udc33\ud852\udfee\u82af\ud920\udd84\ud97d\udd41\udaf0\udcbc\ud937\ude89",
        -2, 9582, -7980091, 8685800567370931699L, -80781L, true, true, (char) 5518, (char) 61733,
        Double.longBitsToDouble(0x3fe523d876fa66d9L), Double.longBitsToDouble(0x3fb1fa2d487d4da0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 6, 0, "\ud8b5\udcf3\uda4b\udf3e", "\u6423", "\udaa4\udc01\ud9e6\uddad\uda03\udd1a\udb45\udc1c",
        16, 38189, 85465677, 6647406954941953004L, -63440L, true, false, (char) 31315, (char) 37603,
        Double.longBitsToDouble(0x3fe05e1d3b7a9b90L), Double.longBitsToDouble(0x3fc0369cee0b02c8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud875\udd7d\000\udaba\ude9f\udab0\udd53\udada\uddff\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud875\udd7d\000\udaba\ude9f\udab0\udd53\udada\uddff\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud875\udd7d\000\udaba\ude9f\udab0\udd53\udada\uddff\ud8ae\udce5\uda03\udd1a]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud875\udd7d\000\udaba\ude9f\udab0\udd53\udada\uddff\ud8ae\udce5\uda03\udd1a]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 4, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud875\udd7d\000\udaba\ude9f\udab0\udd53\udada\uddff\ud8ae\udce5\uda03\udd1a", "\u2b6e\u814f\ud132\u9c3f", "\ud856\udf02\udb0c\udefc\uda79\udee4",
        0, 44400, -1062063999, 2290409721005165695L, -99367L, false, true, (char) 57598, (char) 31542,
        Double.longBitsToDouble(0x3fc4a752a9f78ea0L), Double.longBitsToDouble(0x3fe6bc90266ef69aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 5, 5, 4, "\ud87c\udefb\uda4b\udf3e\ud895\udcde\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\u307f\u07dc\u0a0a\u2176", "\ud856\udf02\udb0c\udefc\uda79\udee4",
        26, 90346, -1062063999, 2290409721005165695L, -99367L, false, true, (char) 57598, (char) 31542,
        Double.longBitsToDouble(0x3fc4a752a9f78ea0L), Double.longBitsToDouble(0x3fe6bc90266ef69aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 4, 4, "\ud89d\udf4c\ud8eb\udd88\ud81c\udc38\ud914\uddac\uda74\udf6c\udbdb\ude7f\ud824\udf53\ud9a8\ude06\udbe5\ude01\uda03\udd1a", "\u2b6e\u1758\ud0f2\u9c3f", "\ud9b4\udd76\udb0c\udefc\uda79\udee4\uda68\udc44\ud813\udf0d\udbd5\udcc5\udb00\udedc\udb2d\ude0c\ub76e\u6c10\ud84a\ude58\ud8b8\udee8\uda8f\udecb\uda2e\udec2\ud9ff\udf5f\ud92d\ude73\ud91e\udd2f\ud88d\udc18\udb9e\udcf2\udb89\udc0d\udbbb\udd97\uda5d\udeb7\udbfe\udc31\ud8c7\udc98\udb77\udef0\uda0d\ude91\ud962\udc88\u2820\ud96f\udd79\ud88b\uddd4\ud9e7\ude6f\ud95c\udc15\ud96b\udcf3\udb18\uddda\ud8fe\udc40\uda3e\udcff\ud9ad\udd2e\ud886\udda9\ud9e9\udfff\ud93a\udee2\ud976\udd34\u9d78\uda22\ude4f\ud902\udd5d\udb55\udc38\ud818\udf67\ud8b8\uddbf\udba5\udc5d\ud809\udc36\ud8f8\ude2f\ud939\udf54",
        4, 47957, -377261403, 2875018836179646316L, 81721L, true, false, (char) 63800, (char) 2803,
        Double.longBitsToDouble(0x3fe23ea1f1e75dedL), Double.longBitsToDouble(0x3fd1e289ab286068L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a\udb45\udc1c\ud816\udc7d\ud9e6\udcde\ud988\udca2\udae8\udd4c\ud9de\udf24\ud8c6\udde2\udb94\udff6\uda73\uddd0\ud80e\ude09\uda10\udf62\uda68\udc44\ud813\udf0d\udbd5\udcc5\uda0b\udd61\ud937\udd30\ud8ba\udfc0\udbc0\udd66\ud954\udf58\ud9e5\udfff\udb55\udff7\ud98f\udef9\udaf1\udc01\ud8b1\ude49\udbe8\udee0\ud8c9\udf4a\udb56\udeb6\udb78\udc8c\udabe\uddee\ud899\udc69\udbda\udc0c\uf046\ud86f\ude3e\udbea\udf56\uda81\udde5\ud84d\udde7\ud8a4\ude75\uda61\ude21\ud9c6\uddc1\udb36\udee1]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a\udb45\udc1c\ud816\udc7d\ud9e6\udcde\ud988\udca2\udae8\udd4c\ud9de\udf24\ud8c6\udde2\udb94\udff6\uda73\uddd0\ud80e\ude09\uda10\udf62\uda68\udc44\ud813\udf0d\udbd5\udcc5\uda0b\udd61\ud937\udd30\ud8ba\udfc0\udbc0\udd66\ud954\udf58\ud9e5\udfff\udb55\udff7\ud98f\udef9\udaf1\udc01\ud8b1\ude49\udbe8\udee0\ud8c9\udf4a\udb56\udeb6\udb78\udc8c\udabe\uddee\ud899\udc69\udbda\udc0c\uf046\ud86f\ude3e\udbea\udf56\uda81\udde5\ud84d\udde7\ud8a4\ude75\uda61\ude21\ud9c6\uddc1\udb36\udee1]] |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 6, 4, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a\udb45\udc1c\ud816\udc7d\ud9e6\udcde\ud988\udca2\udae8\udd4c\ud9de\udf24\ud8c6\udde2\udb94\udff6\uda73\uddd0\ud80e\ude09\uda10\udf62\uda68\udc44\ud813\udf0d\udbd5\udcc5\uda0b\udd61\ud937\udd30\ud8ba\udfc0\udbc0\udd66\ud954\udf58\ud9e5\udfff\udb55\udff7\ud98f\udef9\udaf1\udc01\ud8b1\ude49\udbe8\udee0\ud8c9\udf4a\udb56\udeb6\udb78\udc8c\udabe\uddee\ud899\udc69\udbda\udc0c\uf046\ud86f\ude3e\udbea\udf56\uda81\udde5\ud84d\udde7\ud8a4\ude75\uda61\ude21\ud9c6\uddc1\udb36\udee1", "\u62b8\u43ce\u0b72\u696e\u0bb4\u6bb0\u8e02\u1463\uadca\u4d17\u2900\ub444\ucbc5", "\ud82a\ude1f\udbfd\udfc1\ud88c\udf32\udaf1\udf75\udaf8\ude87\uda1d\ude06\ud8b5\udc77\ud8ff\udcc5\ud94b\uddd7\ud869\udfb9\ud8be\uddec\ud8ab\udcab\ud862\ude0e\ud851\udcfa\ud9f6\ude3f\ud8dd\udd7c\udbb5\uded1\u9c30\udb42\udfaf\ua6b5\ud96b\udeff",
        55, 14627, -943906655, -1108438308860799119L, 73406L, false, false, (char) 57402, (char) 31305,
        Double.longBitsToDouble(0x3fd8f7b6c5883344L), Double.longBitsToDouble(0x3fc64a099cacbf44L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud88f\ude76\uda4b\udf3e\ud81c\udc38", "\u769d\u7833\u0447\u5501\u498f\u170c\u546e\u2b6e\u814f\ud132\u9c3f\u9809\u682c\u69e6\u5965\uba91\u7cca\u3279\ua579\u312e", "\udbc0\udd66\ud954\udf58\ud9e5\udfff\ud9fe\udde3\ud96a\udd38\udaf1\udc01\ud8b1\ude49\ud8ea\ude60\ud9af\udd32\ud99a\udc0b\ud990\udc46",
        -3, 18239, 1491908832, -8173836928479856482L, 60018L, false, false, (char) 43752, (char) 954,
        Double.longBitsToDouble(0x3fedaccf8cb43133L), Double.longBitsToDouble(0x3fe81f02030d60f6L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 1, "\udb20\udd3a\ud8ff\ude15\uda2a\udd17\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53", "\ua396\u170c\u546e\u7241\u814f", "\ud8c6\udde2",
        30, 41665, 1525501432, -4883068703108396405L, 23775L, true, false, (char) 61663, (char) 8970,
        Double.longBitsToDouble(0x3fd87e0fee7c837eL), Double.longBitsToDouble(0x3febb964782ae49bL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a\udb45\udc1c\ud816\udc7d\ud9e6\udcde\ud988\udca2\udbea\udcab\ud9de\ude67\ud8c6\udde2\udb94\udff6\ud856\udef1\udb0c\udefc\uda79\udee4\uda68\udc44]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a\udb45\udc1c\ud816\udc7d\ud9e6\udcde\ud988\udca2\udbea\udcab\ud9de\ude67\ud8c6\udde2\udb94\udff6\ud856\udef1\udb0c\udefc\uda79\udee4\uda68\udc44]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 3, 2, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a\udb45\udc1c\ud816\udc7d\ud9e6\udcde\ud988\udca2\udbea\udcab\ud9de\ude67\ud8c6\udde2\udb94\udff6\ud856\udef1\udb0c\udefc\uda79\udee4\uda68\udc44", "\u312e\u02da\u605d", "\ud9e5\udfff\udb55\udff7\ud98f\udef9\udaf1\udc01\ud8b1\ude49\udb80\ude0b",
        19, 84747, 435029135, -42574324870028977L, 31204L, true, true, (char) 26063, (char) 41809,
        Double.longBitsToDouble(0x3fc519ac296e0e2cL), Double.longBitsToDouble(0x3fea30f12d313772L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 4, "\u42a6\000", "", "",
        -5, -1000, 11883450, 61508097483145216L, 13964L, false, false, (char) 58637, (char) 23616,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3fe0000005a14fbfL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[]] |a1=[Ljava.lang.String;:[[]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "", "", "i",
        -5, 75640, 193, 14286848L, -100000L, false, false, (char) 194, (char) 6912,
        Double.longBitsToDouble(0x3fcd8b881de00000L), Double.longBitsToDouble(0x3fd0028fac9eec5aL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 2, 0, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddaci\udaba\ude9f\udab0\udd53\ud9a8\ude06\udaaa\udfc4\uda87\udfc3", "\000\000\ud132\u9c3f", "\ud856\udf02",
        25, 27971, -647638389, -5411159091757043583L, -14881L, true, true, (char) 56965, (char) 47357,
        Double.longBitsToDouble(0x3feb022cfc84c6b2L), Double.longBitsToDouble(0x3fc4a752a9f78ea0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 4, "\u42a6\000", "\000\u75a7\ub72f\u4ec4\000\000\ucd90\u5408\u2b6e\u814f", "\ud8c6\udde2",
        54, 22656, 19873, -647638389L, -99873L, false, false, (char) 0, (char) 16702,
        Double.longBitsToDouble(0x3feb00000484c6b2L), Double.longBitsToDouble(0x3fc4a752a9f78ea0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud87c\udefb\uda4b\udf3e\ud81c\udc38]] |a1=[Ljava.lang.String;:[[\ud87c\udefb\uda4b\udf3e\ud81c\udc38]] |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 6, 4, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38", "\u769d\ub72f\u4ec4\ub3ad\u498f\u170c\u546e\u2b6e\u814f\ud132\u9c3f\u9809\ua110\ub4d3\u5965\uba91\u7cca\u47e3\ua579\u312e", "\udbc0\udd66\udaca\udef9\ud99d\udecb\uda42\udc4e\ud98f\udef8\udaf1\udc01\ud8b1\ude49\uda33\udd85\ud9f3\udd87\ud873\udd09\ud859\udccf",
        12, 92328, -1159303197, -2956039068864453820L, -89158L, true, false, (char) 18111, (char) 17430,
        Double.longBitsToDouble(0x3fc7d2f149f02874L), Double.longBitsToDouble(0x3fe800ef0de16ff8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 1, 2, "", "\ub59f", "\ud96a\uddab\ud893\udf71\udbbc\udcfa\ud8d2\udef2\ud9ed\udc0d\udb45\udc1c\ud816\udc7d\ud9e6\udcde\ud988\udca2\udae8\udd4c\ud9de\udf24\ud9b8\ude5b\u9500\uda05\udc9c\u4da1\000\uda68\udc44\ud813\udf0d\udbd5\udcc5\udb1c\udf8a",
        23, 60193, -1451754569, 4593850345270917376L, -49312L, false, false, (char) 22491, (char) 1289,
        Double.longBitsToDouble(0x3fc57524a8757488L), Double.longBitsToDouble(0x3fd004b37656fe80L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 1, "\ud87c\udefb", "\u5a62\u6423\u769d\u1f30\u4ec4\ub3ad\u498f", "\udada\udc0c",
        56, 72783, -234881024, 2952883029791473664L, -72191L, true, false, (char) 59, (char) 45823,
        Double.longBitsToDouble(0x3eccec0000000000L), Double.longBitsToDouble(0x3fbfc7f268ec9708L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 3, 4, "\ud8f0\ude93\ud934\udeb1\udb42\ude5d\ud9c1\ude4c\uda74\udf6c\ub42e\ud805\ude55\ud9a8\ude06\ud8ae\udce5\ud9f3\ude92\ud8a8\udece\u33fb\ud9e6\udcde\ud988\udca2\udb01\udf4c\ud8a5\udff5\ud8c6\ude14\udb08\udc10\ud950\udf00\udb0c\udefc", "\u3279", "\ud877\udf1e\uda3e\ude0a\ud9c1\udc6a\ud9fd\udfc5\ud976\udc4f\ud94f\ude75\ud9a3\uddf9\udaf1\udc01\ud8b1\ude49\ud800\udc0b\udb29\udc6d\ud99e\udc39\uda46\udec6\udb53\udcc1\uda33\ude87",
        35, 19073, -2110839430, -2489326111287409813L, -42220L, false, false, (char) 61250, (char) 55851,
        Double.longBitsToDouble(0x3fcd5cb9fb916f94L), Double.longBitsToDouble(0x3fed486c84fba4b2L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 5, 4, "\ud87c\udefb\udb58\udea5\udaa0\udd14`\udb88\udeac\udaba\udf39\udab0\udd53\ud9a8\ude06\ud8ae\udce5\ud9e2\udc1a", "\u4086\u814f\ud132\u9c3f\u1f3f\ua16f\ub4d3\u5965\u6691\u7cca\ub37a\ua579\u5c70\u807c\u2645\u6ddf\u8a91\ucb4f\u59e7\ub70d\u1023\u83b3\ub91c\u1776\u651c\uc185\u2e6f\u9c7c\u4500\ua32d\u19ca\u7ab9\u7c68\u12d2\u719e\u015a\u355f\u2a1b\ucdf4\u918e\u71f9\u59f9\u029e\u7952\u8f78\u240f\u8c2b\u9c36\u80ce\u4152\ucb02\u0e39\u48e2\u7224\u519e\u063d\ub432\u2cea\u0480\u5e01\u246a", "\udbc4\udce3\uda1e\ude6e\uda23\udebf\u917d\ud802\udc71\uda44\udf37\u56c6\uda29\udeb4\ud901\udc9a\uda2b\udc0e\udb12\ude83\uda07\udde4\udb5a\udc29\udb81\udd37\ud866\ude93\ud847\udcef\ud871\udea6\ud987\udced\ud963\udf4d\ud816\udef5\uda82\udd9f\ud93e\udd04\ud88a\udff2\udbbb\uddce\ud9ae\udef7\ud917\ude46\udb1a\ude85\ud887\uddf7\ud810\udf3a\ud807\udd89\ud8c8\uddf2\udbfa\udf51\udab1\udf95\udbfa\udf2f\ud957\udd67\ud971\udd58\uda28\udd1c\ud9a1\udc3b\udae2\udd71\udaac\udcad\ud972\udc49\udb73\udf5b\ud9e7\ude57\udb82\udc96\ud863\uddb7\uda48\udf83\ud911\udd23\udbed\udc8e\ud9b2\udc24\uda74\udeec\ud8cf\ude26\udac5\udc15\ud88b\udd46\ud9e0\udc70\ud984\udcb4\uda3d\udfe1\udb51\udf95\udae8\udd0b\ud8c4\udd3c\ud97e\ude4d\ud9f7\udc89",
        18, 39051, 2115390100, 1581900473552464218L, 48693L, false, false, (char) 62994, (char) 65244,
        Double.longBitsToDouble(0x3fee6bf1dc4748a5L), Double.longBitsToDouble(0x3fec89807c86359eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 5, "", "\u7636", "\ud96a\udd5e\uda38\udfc5\udb18\udc47",
        27, 31238, -313796944, -8448859116045974828L, 81795L, true, true, (char) 62150, (char) 48383,
        Double.longBitsToDouble(0x3fd4f0000a5fe296L), Double.longBitsToDouble(0x3e34580000000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 4, "\ud87c\udefb\uda4b\udf3e\ud81c\udc38\ud914\uddac\uda74\udf6c\udaba\udf95\udab0\udd53\ud9a8\ude06\ud8ae\udce5\uda03\udd1a", "\u2b6e\u814f\ud132\u9c3f", "\ud9ef\udd89\udae7\ude00\uda37\udf5b",
        34, 90346, -1062063999, 2290409721005165695L, -99367L, false, true, (char) 17891, (char) 65244,
        Double.longBitsToDouble(0x3fc4a752a9f78ea0L), Double.longBitsToDouble(0x3fe6bc90266ef69aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
