package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 6, 3, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\udbf9\ude59\udbd6\uddda\uda39\udde9\udaac\uddf2\udb49\udfef\ud993\uddcb\udb9c\udf9b", "\u726a\u0fd1\u4261\ud513", "\udb4d\udc92\uc6fd\ud9cc\udca2\udb5e\ude60\udb05\udcda",
        25, 51095, -2091023062, 1965288638145515447L, 99242L, true, true, (char) 60990, (char) 29270,
        Double.longBitsToDouble(0x3fe1a0d10ec1ecddL), Double.longBitsToDouble(0x3fdb8a706621739cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 6, 3, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\udbf9\ude59\udbd6\uddda\uda73\uddc7\udaac\ude22\udb49\udfef\ud993\uddcb\udb9c\udf9b\udad6\udef7\udb4a\uddd7\uda93\udc13\ud9cf\udddf\udb83\uded1\uef8c\udb95\ude2d\udbd4\ude0a\udb4d\udc92\uc6fd\ud9cc\udca2\udb5e\ude60\udb05\udcda\udb79\udc70", "\u33ee\ub9d0", "\udbb1\udfeb\udabf\udde4\uda68\udc23\ue765\ud9f2\uddcb\ud8f7\udc14\ud8b7\udf69\ud923\udd13\uda86\udd82\u1995\udb30\ude11\ud9d3\ude01\udafa\udc18\ud828\ude1b\ud8fc\ude51\uda62\uddef\udbc7\udc27\udae5\udd00\udb87\udee6\ud8c6\uddab\udb83\ude24\ud883\udf24\udae0\udcfa\uda8e\udd2a\ud9ab\udfea\u0935\udb9b\udc33\udbc2\udccc\ud9c0\udd57\ud89c\udd78\uda75\udf0c\ud860\udd69\uda5c\udffc\ud838\ude1b",
        9, 83565, -44966573, 5116775788828757991L, 37045L, false, true, (char) 48238, (char) 9997,
        Double.longBitsToDouble(0x3fe53bbd09d880b4L), Double.longBitsToDouble(0x3fde123729f2cffeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:                          |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 5, 15, 3, "\ud9c4\udd64\ud9c5\udcbc\u211b\uda85\udeda\ud99e\udd4c\uda80\udf69\ud848\udd4d\udabf\udc4d\ud823\udd0e\udbd6\udd87\uda39\udde9\udaac\uddf2\udb49\udfef\ud993\uddcb\udb9c\udf9b", "\u9c1c\u107a\u8c38\uc050", "\udb4d\udc92\ud895\udee5\ud9cc\udca2\udb5e\ude60\udb05\udcda",
        25, 51095, -2091023062, 1965288638145515447L, 99242L, false, true, (char) 60990, (char) 61969,
        Double.longBitsToDouble(0x3fdf01affd826cdeL), Double.longBitsToDouble(0x3fdb8a706781739cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 15, 3, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\udbf9\ude59\udbf2\udc40\uda39\udde9\udaac\uddf2\udb33\udc84\ud912\udcbd\udbad\udc3a", "\u06fe\u3ee5\u41bc\ud513", "\ud885\udfab\ud8ed\udefa\ud9cc\udca2\udb5e\ude60\udb05\udcda",
        25, 51095, -2091023058, 638880691350047087L, -64430L, false, true, (char) 6598, (char) 19903,
        Double.longBitsToDouble(0x3fd3b2edbbbfd8eeL), Double.longBitsToDouble(0x3fdd71a21d9cebc8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 6, 3, "\ud898\udf1b\ud9f1\udd5e\u211b\uda85\udeda", "\ua8a5\u3e21\uc3b9\u3317\u9108\u5989\uc9a7\u00cd\u9d6e\u99a5\u0b69\u726a\u0fd1\u4261\ud513\u8bc1\u615c\uac85\u8258\u5c45\u13f1\u3638", "\udaaf\uddd1\ud9bf\udd36\ud98e\udd74\u492a\ud9c5\udd86\udbb1\udfeb\udabf\udde4\uda68\udc23\ue765\ud9f2\uddcb\udb0a\uddb2\ud8b7\udf69\ud923\udd13\uda86\udd82\u1995\udac3\udd9c\ud884\udfaf\ud8f9\udf79\udaf7\udc76\uc246\uda99\udfba\udb5b\ude73\udb36\udca2\ud823\udc0d\ud979\udc3b\ud81b\udcf9\ud890\uddd4\udb21\udd7c",
        0, 66084, -1565450210, 2941005243650089484L, 23266L, true, false, (char) 57353, (char) 35922,
        Double.longBitsToDouble(0x3feb96c5fdfb977cL), Double.longBitsToDouble(0x3fedcea09d3b887dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 6, 3, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\udbf9\ude59\udbd6\uddda\uda39\udde9\udaac\uddf2\udb49\udfef\ud993\uddcb\udb9c\udf9b", "\u726a\u0fd1\u4261\ud513", "\udaa1\ude2f\uc6fd\ud9cc\udca2\udb5e\ude60\udb05\udcda",
        25, 51095, 1453819178, 7265468766499918717L, 99242L, true, true, (char) 60990, (char) 29270,
        Double.longBitsToDouble(0x3fe1a0d10ec1ecddL), Double.longBitsToDouble(0x3fdb8a7b3621739cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 14, 0, 11, "\udae0\udf48\u6dad\u211b\uda85\udeda\udb1d\uddca\ud8be\udf0f\udbc7\ude6d\udabf\udc4d\udbf9\ude59\udbd6\uddda\uda39\udde9", "\u31e5", "\udb4a\uddd7\uda93\udc13\ud9cf\udddf\udb83\uded1\udb51\udf66\ud84c\uddc8\ud8dd\udd9a\uda51\udc7a\uc6fd\ud869\udef4\udb5e\ude60\udbb3\udf58\udb6e\udd47",
        35, 79938, 457579419, -7654342867394788718L, -89182L, false, true, (char) 22172, (char) 6598,
        Double.longBitsToDouble(0x3fef0db6cd3be1d0L), Double.longBitsToDouble(0x3feeff63bdbc5e66L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 6, 3, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\uda9b\udde5\udabf\udc4d\udbf9\ude59\udbd6\uddda\udb9a\udeba\udaac\uddf2\ud90b\udff0\ud993\uddcb\udb9c\udf9b", "\u726a\u0fd1\u4261\ud513", "\udb4d\udc92\uc6fd\ud9cc\udca2\udb5e\ude60\udb00\udfda",
        25, 51095, -2091023062, 1965288638145646519L, 21549L, false, false, (char) 33127, (char) 57039,
        Double.longBitsToDouble(0x3fe256616b9fcee3L), Double.longBitsToDouble(0x3fd3be103bbfd8eeL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 3, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\uda81\ude1d\udbb1\ude57\uda39\udde9\udaac\uddf2\udb49\udfef\ud993\uddcb\u1250", "\uc0ce", "\udbef\udcc6\ud919\ude2c\udbd4\ude0a\udb4d\udc92\uc6fd\ud9cc\udca2",
        35, 74175, -1480293980, 8407974413468534058L, 51479L, false, false, (char) 227, (char) 24864,
        Double.longBitsToDouble(0x3fe00000073aae40L), Double.longBitsToDouble(0x3f0ef8e7f3b8c000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 6, 13, "\udba5\ude82\ud9c5\udc83\u211b\udbd0\udc40\uda74\udde6\udb3a\udc0d\udb2f\udfb1", "\ua797", "\udb49\udfef\ud993\uddcb\udb9c\udf9b",
        53, 24686, -1344708409, 4721533830864130234L, 31262L, false, false, (char) 5931, (char) 32301,
        Double.longBitsToDouble(0x3feebd6df7bd515cL), Double.longBitsToDouble(0x3fec3d2861a41685L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 15, 3, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\udbf9\ude59\udbd6\uddda\uda39\udde9\udaac\uddf2\udb49\udfef\ud993\uddcb\udb9c\udf9b", "\u726a\u55bd\uad33\ud513", "\udb4d\udc92\uc6fd\ud9cc\udca2\udb5e\ude60\udb05\udcda",
        25, 51095, -2091023062, 1965288638145515447L, 93120L, false, false, (char) 25938, (char) 64890,
        Double.longBitsToDouble(0x3fe2507be39fcee3L), Double.longBitsToDouble(0x3fd3be103bbfd8eeL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 6, 3, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\udbf9\ude59\udbd6\uddda\uda97\udef9\ud9e4\ude80\udb49\udfef\ud993\uddcb\udb9c\udf9b", "\u4c15\u7293\u4261\ud513", "\udb4d\udc92\uc6fd\ud9cc\udca2\udb5e\ude60\udb05\udcda\udb79\udc70\ud94b\udf0f\udaaf\uddd1\ud9bf\udd36\ud98e\udd74\u492a\ud9c5\udd86\udbb1\udfeb\udabf\udde4\uda68\udc23\ud966\udc5e\uceec\ud8f7\udc0d\ud8b7\udf69\ud923\udd13\ud840\ude1f\ud801\udf8b\ud989\udd9f\ud878\udcfc\ud961\ude22\uda88\ude1b\uda66\udc62\ud8a8\udec3\udb47\udc9c\udbd5\ude4f\udb70\udf25\ube12\ud8d3\udd4d\ud8e3\udf54\udba2\udda5\ud9f7\udda2\ud996\udd23\ud83f\udd05\ud8e2\udeca\ud9c5\udef1\ud9d8\udc27\ud939\udf79\ud8df\udd18\ud93b\ude14\udb35\ude15\udb88\udd3e\udba8\udd65\udaa2\uddc0\u04b1\ue471\udaf8\udc14\uda97\uddf9\ud9dd\udd4d\udbb2\uddd8",
        16, 68235, 1003495049, -7075316557708670581L, 59495L, false, true, (char) 20606, (char) 58466,
        Double.longBitsToDouble(0x3feeac07a6430b40L), Double.longBitsToDouble(0x3fced60fb529df00L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 9, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb29\udfca\ud978\udc0c\udb2f\udfb1\udabf\udc4d\udbf9\ude59\ud91f\uddf5\uda39\udde9\udaac\uddf2\udb49\udfef\ud993\uddcb\udb9c\udf9b", "\u726a\u9628\u7344\ud513", "\udb4d\udc92\uc6f0\ud9cc\udca2\udb5e\ude60\udb05\udcda\udb3a\ude30\uda29\udc1b\udaaf\uddd1\ud933\ude90\ud978\udf78\u492a\ud9c5\udd86\udbb1\udfeb\udabf\udde4\uda68\udc23\ue765\ud9f2\uddcb\ud8f7\udc14\ud8b7\udf69\ud8fa\udede\udabd\udd6e\u1995\udb7f\udfd9\udadb\ude27",
        10, 62923, -2017058995, -5607298052929902417L, 99196L, false, false, (char) 62892, (char) 17224,
        Double.longBitsToDouble(0x3fd9d86ccf42cc20L), Double.longBitsToDouble(0x3fe795593f7d77aeL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 6, 3, "\udba5\udf82", "\ub0fb\u4d7c\u0d24", "\udbf9\ude59\udbd6\uddda\uda39\udde9\udaac\uddf2\udb49\udfef",
        50, 63322, 1767875778, -411558001398281829L, -13798L, true, false, (char) 61313, (char) 60946,
        Double.longBitsToDouble(0x3fdd55bbc7add54aL), Double.longBitsToDouble(0x3feebd6df7bd515cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 12, 0, 3, "\udba5\udf82", "\ub0fb\u4d7c\u9e23", "\udbf9\udf08\udbd6\uddda",
        30, 86256, -515303487, 704159201369104962L, 21390L, true, true, (char) 58416, (char) 37473,
        Double.longBitsToDouble(0x3fc7fbf4be4ef3a8L), Double.longBitsToDouble(0x3fc47c34b7556ef0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 0, 0, "\udba5\udf82", "\u00d0\000\000", "\udbf9\ude59\udbd6\uddda\uda39\udde9\udaac\uddf2\u00c1",
        -5, -1000, 0, -411558198966777445L, -13798L, true, false, (char) 61313, (char) 60946,
        Double.longBitsToDouble(0x3fdd55bbc7add54aL), Double.longBitsToDouble(0x3feebd6df7bd515cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 6, 3, "\udba5\udf82\ud9c5\udc83\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\udbf9\ude59\udbd6\uddda\uda39\udde9\udaac\uddf2\udb49\udfef\ud993\uddcb\udb9c\udf9b", "\u726a\u0fd1\u4261\ud513", "\udb4d\udc92\uc6fd\ud9cc\udca2\udb5e\ude60\udb05\udcda",
        52, 51180, -2091023062, 1965288638145515447L, 99242L, true, true, (char) 60990, (char) 29270,
        Double.longBitsToDouble(0x3fe1a0d10ec1ecddL), Double.longBitsToDouble(0x3fdb8a706621739cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 2, 13, "\udbdd\udcfd", "\ub0fb", "\udab8\udcfc\udabf\udc20\udbf9\ude59\udbd6\uddda\uda8a\udd32\uda85\udde2\udb49\udfef\ud968\udc93\u1250\000\udb4a\uddd7\uda93\udc13\ud9be\udfdf\udb83\uded1\uef8c\udb95\ude2d\udbd4\ude0a\udb4d\udc92\ud8bc\udfe1\ucbd7\000\000",
        52, -1000, -2097152000, 1965288638145515447L, -100000L, false, false, (char) 6598, (char) 12931,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 6, 12, 1, "\udb07\uddbd\ud992\udc29\udb23\udf22\ud9f6\udcb3\udb1d\ude76\udb3a\udc0d\udb2f\udfb1\udabf\udc4d", "\u9108\u01ba\uc9a7", "\ud8f2\udccf\ud8cf\udc39\udbcb\udccf\ud9cf\udddf",
        38, 6662, -513546942, 6610172246289557973L, 44425L, true, true, (char) 16014, (char) 38839,
        Double.longBitsToDouble(0x3fa7d3e252a74af0L), Double.longBitsToDouble(0x3fecdc1aefb71b46L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 16, 3, "\ud9b3\udf89\ud9c5\udc83\u211b\uda85\udeeb\udb1d\uddca\ud959\udffe\uda95\ude94\ud8e8\udff1\ud886\udeed\uda46\udfcb\uda39\udde9\udaac\uddf2\udb49\udfef\ud993\uddcb\udb9c\udf9b", "\u7213\u1bd1\u4261\ud513", "\udb4d\udc92\uc6fd\ud9cc\udca2\udb5e\ude60\udb05\udcda",
        23, 51095, -2091023062, 7342023643282793557L, 99242L, true, true, (char) 60990, (char) 29270,
        Double.longBitsToDouble(0x3fe1a0d10ec1ecddL), Double.longBitsToDouble(0x3febfd38359c7843L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 12, 6, 3, "\udba5\udf82\ud85a\ude8e\u211b\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\udbf9\ude59\udbd6\uddda\uda39\udde9\udaac\uddf2\udb49\udfef\ud993\uddcb\uda2a\udfe3", "\u726a\u0fd1\u4261\ud513", "\udb4d\udc92\uc6fd\ud9cc\udca2\udb5e\ude60\udb05\udcda",
        25, 51095, -2091023062, 3278932354454146999L, -50797L, false, false, (char) 25938, (char) 64890,
        Double.longBitsToDouble(0x3fe251b26b9fcee3L), Double.longBitsToDouble(0x3fd3be103bbfd8eeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\udba5\udf82\udb0b\udfc8\ud859\udc0b\ud9f3\uddc1\udb53\udf87\uda24\ude37\udb2f\udfb1\udabf\udc4d\udbf9\ude59\uda22\udf1b\uda76\udc28\ud881\udf0f\udb49\udfef\ud993\uddcb\udb9c\udf9b\u726a\u0fd1\u4261\ud513 |a0=java.lang.StringBuffer:\udba5\udf82\udb0b\udfc8\ud859\udc0b\ud9f3\uddc1\udb53\udf87\uda24\ude37\udb2f\udfb1\udabf\udc4d\udbf9\ude59\uda22\udf1b\uda76\udc28\ud881\udf0f\udb49\udfef\ud993\uddcb\udb9c\udf9b\u726a\u0fd1\u4261\ud513 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 2, 6, 12, "\udba5\udf82\udb0b\udfc8\ud859\udc0b\ud9f3\uddc1\udb53\udf87\uda24\ude37\udb2f\udfb1\udabf\udc4d\udbf9\ude59\uda22\udf1b\uda76\udc28\ud881\udf0f\udb49\udfef\ud993\uddcb\udb9c\udf9b", "\u726a\u0fd1\u4261\ud513", "\udb51\udc80\uc6fd\ud9cc\udca2\udb53\udf60\udb05\udcda",
        25, 51095, -2091023062, 1965288638144008119L, -16483L, false, false, (char) 41012, (char) 64890,
        Double.longBitsToDouble(0x3fe2507be3aedbfdL), Double.longBitsToDouble(0x3fd3be146bbfd8eeL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 8, 3, "\udba5\udf82\uda7f\ude42\ud979\udd11\uda85\udeda\udb1d\uddca\udb3a\udc0d\udb2f\udfb1\udabf\udc4d\udbf9\ude59\ud971\udc89\uda39\udde9\udaac\uddf2\udab4\ude65\ud96b\udd2c\udb9c\udf9b", "\u726a\u33f7\u4261\ud513", "\udb4d\udc92\uc6fd\ud9cc\udca2\udb5e\ude60\udb05\udcda",
        25, 51095, -2091023062, 1965288638145515447L, -76886L, false, true, (char) 6598, (char) 12931,
        Double.longBitsToDouble(0x3fd3be103bbfd8eeL), Double.longBitsToDouble(0x3fe1a0d10fe25dddL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|printWrapped|java.io.PrintWriter,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printWrapped|java.io.PrintWriter,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedTextBlock|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptSeparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printWrapped|java.io.PrintWriter,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printWrapped|java.io.PrintWriter,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedTextBlock|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
