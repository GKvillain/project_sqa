package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\udb15\udc9a", "\u4b8d\u6775", "\uda72\ude06\ud8d0\ude6d\u2cd1\uda8a\udd92\udacc\udd55\uda92\udd2d\ud82c\uddd8",
        51, 13971, -2091177166, -1526578527198514950L, -9697L, true, true, (char) 5240, (char) 65033,
        Double.longBitsToDouble(0x3f943f63a1f73340L), Double.longBitsToDouble(0x3fd97abd8352428cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\udb15\udc9a", "\u4b8d\u6775", "\uda72\ude9c\ud8d0\ude6d\ud9cd\udf32\uda8a\ude10\udacc\udd55\ud822\udd55\ud847\udd7e",
        51, 13971, -2091177166, -1526578527198514950L, -9697L, false, false, (char) 37884, (char) 16007,
        Double.longBitsToDouble(0x3f943f63a1f73340L), Double.longBitsToDouble(0x3fd97abd8352428cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 17, "\udb15\udc9a", "\u95ab\u6775", "\uda72\ude06\ud8d0\ude6d\u2cd1\uda8a\udd92\udacc\udd55\udbbc\ude9b\uda1f\udce7",
        10, 13971, -2091177166, -1526578527198514950L, -9697L, true, true, (char) 5240, (char) 65033,
        Double.longBitsToDouble(0x3f943f63a1f73340L), Double.longBitsToDouble(0x3fd97abd8352428cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 14, 10, "\udb15\udc9a\udba6\ude37\ud9b4\uded5\ud814\udd6b", "\u3c42", "\ud901\udc4b\ud8e9\udc58\udafd\udf55\ud926\udd37\ud8f7\udf5e\ud8ee\udfb8\udb20\udc39\udbbd\udf34",
        2, 36306, -903971502, -7198265952439473587L, -89257L, false, true, (char) 36833, (char) 23194,
        Double.longBitsToDouble(0x3fe5bd8170402619L), Double.longBitsToDouble(0x3fe439d92ffb2b07L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 4, "\udb15\udc9a\udba6\ude37\ud9b4\ude57\udb43\udc42\ud90d\udf70\ud998\udd61\uda75\udffa\uda72\ude06\ud8d0\ude6d\u2cd1\uda8a\udd92\udacc\udd55\uda92\udd2d\ud82c\uddd8\ud98a\uddc6\ud81f\udeb4\uda18\udfd9\ud961\udfab", "\u38db\uaa93", "\udbcf\udfed\ud95a\udc19\udbfd\udf8c\udb4f\udc65\uda3f\udd3b\uda34\udf2a\udab5\udcf9\ud88f\udd58\uda3f\udf72\ud9c8\udfe3\uda8a\udee7\ud8b5\ude1a\udaa6\udcdc\udabe\udda0\u641d\udaca\udcb9\ud9e7\udca6\udab3\udc92\ud940\uddaa\udb7f\udddc\uda41\udce4\udaca\uddb0\ud84e\udd4c\uda02\udc05\udab3\udea9\ud8c9\uddc6\udad3\udc10\ud82f\udfcf\udbd4\udd53\udadb\udd1a\ud845\udd32",
        29, 52263, 1591682635, -874225552008216408L, 4593L, false, true, (char) 16393, (char) 56881,
        Double.longBitsToDouble(0x3fdf8df6efc8919aL), Double.longBitsToDouble(0x3fd0ceab9d7aa82cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\udb15\udc9a", "", "\udb2d\udd8c\uda75\udffa\udae6\udc02\ud8d0\ude6d\u2cd1",
        46, 70717, 1127257400, 0L, -99950L, true, false, (char) 56266, (char) 27114,
        Double.longBitsToDouble(0x3fea0e50f34d9c1aL), Double.longBitsToDouble(0x3fe0a8d31e347fd5L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\udb15\udc9a", "\u4b8d\u6694", "\ud831\udf82\ud8d0\ude6d\ud9e2\udf90\ud83b\ude2e\ud819\udd7f\ud9a3\udedd\udb7c\uddf0",
        51, 13971, -2091177166, -1526578527198514950L, 47088L, false, false, (char) 45981, (char) 52905,
        Double.longBitsToDouble(0x3fd97abd8352428cL), Double.longBitsToDouble(0x3fa7b3cc934b6870L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\uda95\udddb", "\u4b8d\u6775\u6b9e\u40f4\u0ef0\uba69\u2c42\u2275\u4a80\u34da\u14f2\ucf18", "\ud961\udfab",
        56, 78498, -1675976895, 1901534224839997973L, 1331L, true, true, (char) 61807, (char) 18928,
        Double.longBitsToDouble(0x3fe5876edefd92a1L), Double.longBitsToDouble(0x3fa55a14438ce5c0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 2, 11, "\ud9d7\udffa", "\u8eef\u68ef", "\ud82e\udcc7\ud8d0\uded0\u2cd1\ud99e\udd9c\udacc\udd55\ud942\ude06\ud885\udcf4\udb68\udda4\ud843\ude67\udae5\udede\udbda\udc58\uda6f\uddd3\udbbe\udf61\ud857\ude55\ud84a\udc6c",
        59, 87100, -1181059896, 8565306696032208294L, 27855L, true, false, (char) 36216, (char) 51330,
        Double.longBitsToDouble(0x3fd1075b20f075c4L), Double.longBitsToDouble(0x3f7364e2cf810080L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:   |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\udb15\udc9a\u4b8d\u6775 |a0=java.lang.StringBuffer:\udb15\udc9a\u4b8d\u6775 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 5, 2, 5, "\udb15\udc9a", "\u4b8d\u6775", "\uda8d\udf06\ud8d0\ude6d\u2cd1\uda8a\udd92\udacc\udd55\uda92\udd2d\ud82c\uddd8\ud98a\uddc6\ud81f\udeb4\uda18\udfd9\uda4b\ude9f\udbbf\uded8\ud846\ude25\udba0\udd5d\ud845\udcdb\uda8a\udd99\ud91a\uddf0\udbcf\udfed\ud95a\udc19",
        2, 26863, 1907174251, 7906139801817545883L, 92622L, false, false, (char) 63996, (char) 3915,
        Double.longBitsToDouble(0x3fc19f4c3f99f1d4L), Double.longBitsToDouble(0x3feb2cb62a448945L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\udb15\udc9a\u853b\u65c4\u97e3\u40f4\u0ef0\uba69\u2c42\u2275\u4a80\u34da\u14f2\ua26d\uad59\u1792\u07cf\ub1f9\ub575\u38db\uaa93\u0998\uc954\u0c36\u019d\uc506\u7562\u3eaa\u2471\u1e7e\u8803\u9f6a\u32cf\u11dc |a0=java.lang.StringBuffer:\udb15\udc9a\u853b\u65c4\u97e3\u40f4\u0ef0\uba69\u2c42\u2275\u4a80\u34da\u14f2\ua26d\uad59\u1792\u07cf\ub1f9\ub575\u38db\uaa93\u0998\uc954\u0c36\u019d\uc506\u7562\u3eaa\u2471\u1e7e\u8803\u9f6a\u32cf\u11dc |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 2, 6, 5, "\udb15\udc9a", "\u853b\u65c4\u97e3\u40f4\u0ef0\uba69\u2c42\u2275\u4a80\u34da\u14f2\ua26d\uad59\u1792\u07cf\ub1f9\ub575\u38db\uaa93\u0998\uc954\u0c36\u019d\uc506\u7562\u3eaa\u2471\u1e7e\u8803\u9f6a\u32cf\u11dc", "\uda25\udf75\udae3\ude6d\ud9a3\udf5d\ud9d1\udc87\ud82e\udc86\uda05\udfe9\uda98\udea5\uda8f\udfe2\ud98d\udfbf\ud863\udc07\uda5d\udd69",
        37, 97065, 988101873, -7964650008116478909L, 82063L, true, false, (char) 3414, (char) 43876,
        Double.longBitsToDouble(0x3fcb960601927994L), Double.longBitsToDouble(0x3fe2bf02016d10a4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 10, 5, "\ud8dc\udd94\ud81a\udfb1\ud9b4\uded9\ud85f\udcf1\uda0e\udc60", "\u0ef0\u258c", "\uda19\udd98\ud895\udccb\ud82c\uddd8",
        17, 38805, -2091177166, -1526578527336227553L, -81236L, true, false, (char) 5171, (char) 65033,
        Double.longBitsToDouble(0x3f943f63a1f73340L), Double.longBitsToDouble(0x3fe9d55ec1a9215dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 2, "\udb15\udc9a\udba6\ude37\ud9b4\ude57\udb43\udc42\ud90d\udf70\uda53\ude1f\udafe\udcf6\uda72\ude06\ud8d0\udf01\u2cd1\uda8a\udd92\udacc\udd55\uda92\udd2d\uda93\udc75\ud804\udcc3", "\u07cf", "\udba0\udd5d\ud845\udcdb",
        16, 70316, -1190036342, -6064073743527426665L, -73411L, true, true, (char) 29550, (char) 38679,
        Double.longBitsToDouble(0x3fe9cd19b4283ef9L), Double.longBitsToDouble(0x3fe27a49289d357cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\udb15\udc9a\uda32\udc1c\ud9b4\ude57\udb43\udc42\ud90d\udf70\ud998\udd61\uda75\udffa\uda72\ude06\ud8d0\ude6d\u2cd1\u0c8e |a0=java.lang.StringBuffer:\udb15\udc9a\uda32\udc1c\ud9b4\ude57\udb43\udc42\ud90d\udf70\ud998\udd61\uda75\udffa\uda72\ude06\ud8d0\ude6d\u2cd1\u0c8e |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 10, 2, 11, "\udb15\udc9a\uda32\udc1c\ud9b4\ude57\udb43\udc42\ud90d\udf70\ud998\udd61\uda75\udffa\uda72\ude06\ud8d0\ude6d\u2cd1", "\u0c8e", "\uda19\udc43\uda18\udfd9\ud961\udfab\ud8b3\udfd5\ud846\ude25\udba0\udd5d\udb72\udf52\uda52\udd9d\ud91a\uddf0\udbcf\udfed\ud95a\udc19\udbfd\udf8c",
        4, 5528, 34849107, -5207953702843113971L, -61106L, true, false, (char) 26217, (char) 12876,
        Double.longBitsToDouble(0x3fe0d52d274bee4aL), Double.longBitsToDouble(0x3fe1c7fbb0f2489cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 2, 5, "\udb15\udc9a", "\u4b8d\u6775", "\uda72\ude06\ud842\udd25\000",
        -5, 70717, 1127257400, -4408032881297820015L, -96154L, false, true, (char) 26975, (char) 14183,
        Double.longBitsToDouble(0x3fe0a8d31e347fd5L), Double.longBitsToDouble(0x3f943f63a1f73340L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 5, "\ud913\ude5c\udba6\udede\ud9b4\ude57\udace\udcc8\uda8c\udc8e\ud857\udd73\uda50\udc44\uba0f\ud8d0\ude6d\u2cd1\uda8a\udd92\udacc\udd55\uda92\udd2d\ud82c\uddd8\ud98a\uddc6\ud81f\udeb4\uda18\udfd9\udae3\ude8c\udb1a\udfaa\u4f25\ud8d1\udc34\ud845\udcdb\uda52\udd9d\ud917\udef0\udbd6\udf8a", "\u858a\uc9a3", "\udb58\udf7f\ud8c1\ude97\udbce\udf88\uda6b\udecb\udaf7\udceb\u521d\udb41\udff3\uda3a\udc1f\ud87f\udf34\udba9\uddaa\u5594\ud891\ude44\u40fd\ud8b0\udff2\u90ef\ud891\ude45\ud9a3\ude2c\udaa0\udec0\udbfc\udeb5\ud9af\udc98\udb0b\udfeb\u5993\ud91c\udf25\ud96e\uddcf\udb19\udfe6\udb93\ude4c\ud806\udf9f\ud8b1\udd49\u024e\ud8f5\udefc\udb73\udee3\ue5d8\ud922\ude21\ud929\udeac\uda7c\udcf1\ud9ae\udd14\ud851\udca8\ud9cb\ude36\udbd8\udea5\ud908\udd32\u0484",
        6, 97310, 1896859520, 6723729873854575871L, 40351L, true, true, (char) 8664, (char) 41813,
        Double.longBitsToDouble(0x3fe771e7666f7622L), Double.longBitsToDouble(0x3febc92dc3d2bd60L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 13, 12, 16, "\udb7a\udc1e\uda3e\udddc\ud839\udd8e\ud9e2\ude2d\ud90d\ude8b\ud894\uddbd\udaa3\udd32", "\u2372\u5277\u3829\ub007", "\ud9ee\udd8e\uda8e\udd37\ud8e3\udd8c\ud8b3\udfcb\ud846\ude25\udba0\udd5d\udb86\udd22\udafb\udf05\ud9d8\udfe7\udbbd\uded1\ud990\udcbe\udbfd\udf8c\ud9b7\uddfb\udb90\ude23\udb61\udd08\uda0e\uddc2\uda4b\uddca\ud9c2\udd92\ud91d\udfd6\ud9d8\udd13\udb53\udcdf\uda1f\udeb2\ud9c7\udce7\ud910\udc14\udac8\udd7d\ud8fd\udc80\ud98d\udefc\udb2a\udcda",
        36, 28854, 658791476, -9184622081064644036L, 68278L, false, false, (char) 65503, (char) 61071,
        Double.longBitsToDouble(0x3fd20e7c158f0dfaL), Double.longBitsToDouble(0x3fad1ff20848aa60L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 5, "\udb15\udc9a", "\u9096\u8bb0", "\uda72\ude06\ud8ea\uddda\ud860\udc85\ud84f\udc25",
        43, 62360, -1732643409, 3923253852126194411L, -66997L, true, true, (char) 43896, (char) 26975,
        Double.longBitsToDouble(0x3fea6ce0d2151a63L), Double.longBitsToDouble(0x3fe1a3feac143f63L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\000", "\ua300\000", "\000",
        -1, 41255, 609027951, 27060995499229184L, 719L, true, false, (char) 27502, (char) 1094,
        Double.longBitsToDouble(0x3fcf5d5a154bb25cL), Double.longBitsToDouble(0x3fea0800f34d9c1aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\u00e9", "\000", "\uda75\udffa\uda72\ude06\ud8d0\ude6d\u2cd1\uda88\ude23",
        7, 96400, 0, 129743449762304L, -77047L, true, true, (char) 45508, (char) 63463,
        Double.longBitsToDouble(0x3f941692078441a0L), Double.longBitsToDouble(0x3fecfd258c3a06d1L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|printWrapped|java.io.PrintWriter,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printWrapped|java.io.PrintWriter,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedTextBlock|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptSeparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printWrapped|java.io.PrintWriter,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printWrapped|java.io.PrintWriter,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedTextBlock|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
