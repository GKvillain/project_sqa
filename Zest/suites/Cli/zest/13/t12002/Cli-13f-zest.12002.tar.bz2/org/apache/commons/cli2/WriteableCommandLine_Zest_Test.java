package org.apache.commons.cli2;
import org.junit.Test;
import static org.junit.Assert.*;
public class WriteableCommandLine_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 12, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud86e\udda6\ud8d0\udf2c\ud82c\udd0f\udb7f\udc4f", "\ua0a5\u50e3\u86e3\u654a\uc04f\u83c7\u34f3", "\ud9be\udc49\ud9f1\udd0f\uda10\udf41\uda9d\ude87\udb62\ude9b\ud8fc\udfec\uda49\ude60\uda85\udfdd",
        -4, 73476, 384647209, -1995187985077803522L, 6685L, true, true, (char) 30260, (char) 64955,
        Double.longBitsToDouble(0x3fc12d04b635935cL), Double.longBitsToDouble(0x3fe922179361cf5cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 6, 12, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud86e\udda6\ud8d0\udf2c\ud82c\udd0f\udb7f\udc4f", "\ua0a5\u50e3\u86e3\u654a\u1113\u835f\u34f3", "\ud9be\udc49\ud9f1\udd0f\uda10\udf41\uda9d\ude87\udb62\ude9b\ud8fc\udfec\uda49\ude60\uda85\udfdd",
        -4, 73476, 384647209, -1995187985077803522L, 6685L, true, true, (char) 30260, (char) 64955,
        Double.longBitsToDouble(0x3fc12d04b635935cL), Double.longBitsToDouble(0x3fe922179361cf5cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 7, "\udb7a\ude70\uda95\udd51\ud95a\udfd7\uda98\uddd4\ud84e\udfe5\ud943\udfb9\uda97\udd84\u58bd", "\u5890\u50e3\u2388", "\udbdb\ude88\udbef\udfd2\udb43\udd57\udb98\udf91\ud9be\udc49\ud9f1\udd0f\ud9f5\udd41\uda9d\ude87\udb62\ude9b",
        14, 95632, -1810825670, -3410534676210439788L, -10983L, true, false, (char) 7416, (char) 30260,
        Double.longBitsToDouble(0x3fa76cc688968250L), Double.longBitsToDouble(0x3fd8d64d7e4885e4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 12, "\udb8a\udeba\uda95\udd51\ud907\udf93\udbe5\udf46", "\u85d0\u5eaf\u9cd2", "\udafa\udc66\ud93d\udca1",
        28, 20196, -875230820, 1351615039628079780L, -12992L, false, false, (char) 45206, (char) 56650,
        Double.longBitsToDouble(0x3fd75b5bd0b0aed6L), Double.longBitsToDouble(0x3fe5ada7e63abd39L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 9, 2, "\udb7a\ude4d\uda95\udd51\ud843\udd8b\uda52\udc11\ud86e\udda6\ud8d0\udf2c\udbed\udc0a\uda06\udfb0\ud8ce\ude1a\ud8ae\udd24\ud9c4\udd8d\udaba\udd96\ud93d\udca1", "\u83c7\u34f3\u5019\ubd18\u2662\u3825\u4a15\u82e4\u99c9\u197a\u8b2b\u764d\u38af\u8242\u3b55\uba47\uc1e9\u16c0\ud22b\u75dc\u185d\ucf9c\u4340\u0475", "\ud987\udd3c\udaa2\udc68\ud9fb\udfc6\udb3e\udfdf\ud826\udf70\udaac\udf17\ua06d\udb6f\ude09\udbb6\ude0f\u1b52\uda76\udeda\ud860\uddc5\ud8f5\udf5a\ud904\udf9c\udbb3\ude76\ud893\ude50\udbf9\udcc0\ud95a\udd89",
        52, 29229, -1741651385, -3013504905410681160L, -32313L, true, false, (char) 25774, (char) 31478,
        Double.longBitsToDouble(0x3fd356cea8462b64L), Double.longBitsToDouble(0x3fc51fbae96cbb3cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 12, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud86e\udda6", "\u5eaf\u9cd2\u292f\ua0a5\u50e3\u86e3", "\udbdb\ude88\udbef\udfd2\udb43\udd57\udb98\udf91\ud9be\udc49\ud9f1\udd0f\uda10\udf41\uda9d\ude87\udb62\ude9b",
        14, 95632, -1810629062, -3410534676210439788L, -10983L, true, false, (char) 7416, (char) 30260,
        Double.longBitsToDouble(0x3fa76cc688968250L), Double.longBitsToDouble(0x3fe44326bf2442f2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 10, "\ud8b2\udd60\uda95\udcb3\ud843\udd8b\uda52\udc11\ud86e\udda6\ud8d0\udf2c\udb2d\udc6e\ud8a6\udc3d", "\ua0a5\u50e3\u1c29\u6897\ubd97\u83c7\u34f3", "\ud9be\udc49\ud9f1\udd0f\uda84\udf37\uda9d\udde1\udb62\ude9b\udaf0\udc34\uda26\udffc\uda53\udf4d\udbc1\uddfd\udb6a\udde3\u66a8\udab1\udf9e\uda18\ude51\udadf\ude64\uda5b\udc36\ud92f\udc85\udbbf\ude6e\ud892\ude51\udaaf\udc8b\udb61\udd29\ud8b7\udc72\uf997\ud95e\uddd3\ud811\udeca\ud98a\udc42\udb78\udc3e\udaeb\udfb5\ud990\udcde\udbfa\udeb5\uf93e\uda48\udc6d\ud86e\ude6b\ud8c6\udeb5\udb13\udd87\udaa0\ude4b\u4e5c\ud8da\udc79\udb69\udd87",
        12, 27023, -721018712, 7663717981949255127L, 12585L, false, false, (char) 40997, (char) 15148,
        Double.longBitsToDouble(0x3fc33ef3b7e8503cL), Double.longBitsToDouble(0x3fb7540d21ee5880L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 0, 12, "\uda92\uddd2\uda8f\uddb3\ud827\udf0e\uda52\udc11\ud86e\udda6\ud8d0\udf2c\ud82c\udd0f\udb7f\udc4f", "\u45ab\u50f6\u86e3\u654a\uc04f\u83c7\u34f3", "\udbbe\udf6a\udbf9\udf4f\uda10\udf41\ud821\udd29",
        48, 27224, -1759649332, -7777437032201365304L, 47497L, true, true, (char) 19022, (char) 38152,
        Double.longBitsToDouble(0x3fc7a6ecb30c04d4L), Double.longBitsToDouble(0x3fdee88469bbb31aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 12, "\udb6f\uddf1\uda95\udd51\ud843\udd8b\uda52\udc11\ud86e\udda6\uda4e\udfec\ud82c\udce7\udb7f\udc4f", "\ua0a5\u50e3\u86e3\u654a\uc04f\u83c7\ud7f2", "\ud9be\udc49\ud9f1\udd0f\uda10\udf41\uda9d\ude87\udb62\ude9b\ud8fc\udfb3\uda49\ude60\uda85\udfdd",
        -4, 73476, 384647209, -7903910695690266835L, -96222L, false, true, (char) 25313, (char) 1873,
        Double.longBitsToDouble(0x3fc12d04b635935cL), Double.longBitsToDouble(0x3fe922179361cf5cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 0, 12, "\ud892\udde9", "\u0373\u9e57\u94d0", "\ud8ce\ude1a\ud870\udde5\udad6\udf96\ud802\ude98\ud93d\udca1\udbaa\udc03\ud89a\udfd6\udacd\ude76\udbef\udfd2",
        45, 22649, 686651310, 5571595409549612405L, -54293L, false, false, (char) 10927, (char) 23164,
        Double.longBitsToDouble(0x3fbe67d0abcd6f48L), Double.longBitsToDouble(0x3fe69db490797fc9L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 12, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud86e\udda6\ud8d0\udf2c\udb91\udd01\000", "\ua0a5\u50e3\u86e3\uc29f\000\000\000", "",
        11, 94145, 1650906485, -5350985643928629899L, -100000L, false, false, (char) 25856, (char) 38152,
        Double.longBitsToDouble(0x3fc7a6eca0000000L), Double.longBitsToDouble(0x3e40b80000000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\udb7a\ude70", "\u0373", "\ud82c\udd0f\udb7f\udc4f\ud8ce\ude1a",
        8, 46560, -1574615008, 6798305760320221741L, -32004L, false, false, (char) 34149, (char) 42523,
        Double.longBitsToDouble(0x3fcc00000204a3b4L), Double.longBitsToDouble(0x3fd7500525d0c4ccL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 12, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud86e\udda6\ud8a7\udc18\ud85e\udce8\udb96\udebb\uda1b\udcee\ud8ae\udd24\udad6\udf96\ud802\ude98\ud93d\udca1\ud86a\udd23\udad1\udf4c\udbdb\ude88", "\ubd18\u266c\u7d8c\ucf17\u8209\u1511", "\uda85\udfdd\udbc1\uddfd\udb72\udd99\ud982\ude22\u3735\uda5c\udd17\udadf\udefc\ud8ce\udccf\udae9\udcb4\udbf2\udfa9\ud892\ude51\udb64\udc3a\u610b\ud8b7\udc46\udb2a\ude2c\udab6\udd35\ud8fe\udec8\ud9f6\udfd9\uda79\udc12\udb64\udfce\ud948\udf43\ud888\uddd7\udb1c\udcaf\ud952\udfe6",
        5, 61629, 856574287, 8828504398337370489L, -17968L, false, false, (char) 63230, (char) 47219,
        Double.longBitsToDouble(0x3fcaa29bdb23fcb4L), Double.longBitsToDouble(0x3fe80165b247ed21L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 8, 11, "\ud97a\ude12", "\u0365", "\ud82c\udd0f\u00bf\000",
        -5, 21152, -1574615008, 6798305760320221741L, -32004L, false, false, (char) 34149, (char) 15828,
        Double.longBitsToDouble(0x3fde0414810251daL), Double.longBitsToDouble(0x3e37400000000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 12, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud990\udd97\ud8d0\udf2c\ud82c\udd0f\udb7f\udc4f", "\ua0a5\u50e3\u751b\u5739\uc04f\u83c7\u8c62", "\ud9be\udc49\ud9f1\udd0f\uda0c\ude9b\ud9f4\udc9d\udb62\ude5f\ud8fc\udfec\uda49\ude60\uda85\udfdd",
        -4, 73476, 384647209, -1995301827480951298L, 6685L, true, true, (char) 30260, (char) 64955,
        Double.longBitsToDouble(0x3fa73412d8d64d70L), Double.longBitsToDouble(0x3fe922179361cf5cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 8, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud88c\udd43\ud8f3\udf15\ud82c\udc4d\udb7f\udc4f\uda2f\udeeb\udbd6\udc51\udad6\udf96\ud802\ude98\ud93d\udca1\ud86a\udd23\ud96d\udc5a\ud974\uddd9\udbef\udfd2\udb43\udd57\udb98\udf91\uda26\udd3e\ud9f1\udd0f\uda10\udf41\uda9d\ude87\udb62\ude9b\ud8fc\udfec\uda49\ude60\uda85\udfdd\udbc1\uddfd\udb56\udf99\udb84\udd82\ud8e8\udd77\uda5c\udd5e\udadf\udefc\ud8ce\udccf\udae9\udcb4\udbf2\udfa9\ud892\ude51\ud94b\ude7a\u617f\ud8b7\udc46\udab0\udd26\udbfd\udfa5\uda77\udc1b\udb17\udd1c\ud8b4\udc15\ud97d\udf16\ud918\udc34\ud841\udc40\u60cf\uda49\udf8c\ud886\udefa\uda2b\uddfc\u1e6d\ud815\udde2\ud83e\ude71", "\u28b1\u5384\ua804\u53a4\u6c37\u98d8\u71af\u21da\uac38\u5c36\u7946\u2f9e\u1642\u80ca\u4f34\u562e\u5dc0\uc996\u04fb\ud74b\u45d6\u6b82\u936d\u58f1", "\ud8da\udf86\udb7e\ude4d\uda62\uddb2\udbd4\udcd4\udb69\uddf6",
        4, 78458, 1509275579, -1613318785001293796L, -23711L, false, false, (char) 58445, (char) 32231,
        Double.longBitsToDouble(0x3feb304ca66af63dL), Double.longBitsToDouble(0x3fdccf5ca6c4fe9aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 2, "", "\u81bf", "\ud8d0\udf2c",
        11, 68759, 636375006, 0L, -100000L, false, false, (char) 27957, (char) 4508,
        Double.longBitsToDouble(0x3fe5c65ea80000c1L), Double.longBitsToDouble(0x3e47810400000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\ud86e\udda6\ud8d0\udf2c\ud82c\udd0f",
        39, 74006, 477316983, 3394624295281182752L, -38003L, false, false, (char) 2204, (char) 45709,
        Double.longBitsToDouble(0x3fe520960fb9a61bL), Double.longBitsToDouble(0x3fd0000001020000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "^", "", "",
        -5, -1000, 7499264, 0L, -16000L, false, false, (char) 0, (char) 61236,
        Double.longBitsToDouble(0x3fd9c0800d7197aaL), Double.longBitsToDouble(0x3ec8200000000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 7, "\udb7a\ude70\uda95\udd51\ud95a\udfd7\udb29\udf8e\ud84e\udf99\ud81e\udd06\uda9f\udfc7\udadf\udca0\uda29\udee5\ud8ae\udcff\uda94\udf95\ud802\ude98\ue852\ud86a\udd9e\udad1\udf4c\udbdb\ude88\udbef\udfd2\udacb\udd5b\udb98\udf91\ud9be\udc49\ud9f1\udd0f\ud935\udf02\uda84\ude59\udb62\ude9b\ud8fc\udfec\uda49\ude60\uda85\udfdd\udbc1\uddfd\udb56\udf99\udbca\udf66\udbfa\udf8f\uda51\udd30\udadf\udefc\ud8ce\udccf\udae9\udcb4\udbf2\udfa9\ud892\ude51\ud94b\ude7a\u617f", "\u5703\ua824\u16e0\ud58c", "\ud9cd\udfe5\ud8b1\udda7\uda22\udf72\u6f4f\uda2f\ude0e\ud8c7\ude5f\udb5a\udc9e\ud817\udd24\uda0f\ude04\ud93d\udcbe\ud851\ude91\ud812\uddee\u2833\udb68\udc29\uab15\u5ecd\ud92b\ude08\udbc2\udd28\udabf\uddb5\udad8\udeb5\ud8e7\udf38\udb8c\udd03\udb35\ude69\udbbd\ude5d\uda27\udcd3\uda66\udcc9\ud837\udfdc\ud870\udccb\uda9c\ude42\udb55\ude92\u34f7\uda96\udfa3\ud81c\udea5\ud8c1\ude28\udba6\udc63\ud948\uded4\ud9b8\udcc1\ud9b5\udc08",
        10, 76022, 765900355, 1378183144267407212L, 89835L, false, false, (char) 36965, (char) 6405,
        Double.longBitsToDouble(0x3fe8d636300b595cL), Double.longBitsToDouble(0x3fe536d6b74797beL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 12, "\uda92\uddd2\uda8f\uddb3\ud827\udf0e\uda52\udc11\ud86e\udda6\ud8d0\udf2c\ud82c\udd0f\uda27\udd43", "\u45ab\u50f6\u86e3\uca04\ub14f\u83c7\u34f3", "\udbbe\udf6a\uda2f\ude31\uda10\udf41\ud821\udd29",
        48, 22696, -1759649332, -7777437032201365304L, 47497L, true, false, (char) 51251, (char) 38192,
        Double.longBitsToDouble(0x3fc7a6ee730c04d4L), Double.longBitsToDouble(0x3fdee88469bbb31aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 11, "\ud928\ude22\uda8d\udc26\udbb4\udd7a\ud9e2\ude00\ud9b4\ude63", "\000\u4d19\u292f\ua0a5\u50e3\u86e3", "\uda37\udc7a",
        43, -1000, 0, 2949195713601489025L, -3000L, true, true, (char) 48893, (char) 26822,
        Double.longBitsToDouble(0x3fe1d5e800c89410L), Double.longBitsToDouble(0x3fe43e8000002277L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 12, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud86e\udda6\ud8a5\udc0e\udb91\udd01\000", "\ua0a5\u50e3\u86e3\uc29f\000\000\000", "",
        11, 69521, 1650906485, -5350985643298280075L, -58851L, false, false, (char) 0, (char) 9262,
        Double.longBitsToDouble(0x3fba6014b1633c20L), Double.longBitsToDouble(0x3fc79c5052f25bccL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 12, "\udb7a\ude70\uda95\udd51\ud836\udcc5\uda52\udc03\ud86e\udda6\ud8a7\udc18\ud85e\udce8\udb96\udebb\ud93e\udec0\000\000\ud802\ude78\ud93d\udca1\000\udab2\udc78\udbdb\ude88", "\u97b9\u2582\u7d8c\u3e59\000\u9f9b", "",
        37, 17384, 0, 655019008L, -99815L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fa7000014c68250L), Double.longBitsToDouble(0x3fd19ede5e4885e4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 12, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud86e\udda6\ud8d0\udf2c\ud82c\udd0f\udb7f\udc4f", "\ua0a5\u50e3\u2837\u0c4e\ubffe\u83c7\u34f3", "\ud9be\udc49\ud9f1\udd0f\uda10\udf41\uda9d\ude87\udb62\ude9b\ud8fc\udfec\uda49\ude60\uda85\udfdd",
        -4, 73476, 384647209, -1995187985077803522L, 6685L, true, true, (char) 30260, (char) 64955,
        Double.longBitsToDouble(0x3fc12d04b635935cL), Double.longBitsToDouble(0x3fe922179361cf5cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 12, "\udb7a\ude70\uda95\udd51\ud843\udd8b\uda52\udc11\ud990\udd97\ud8d0\udf2c\ud82c\udd0f\udb7f\udc4f", "\ua0a5\u50e3\ua151\u5739\uc04f\u18cf\u214d", "\ud9be\udc49\udbb7\udd74\uda30\udc7a\ud81d\ude2f\udb62\ude41\ud8fc\udfec\uda49\ude60\uda85\udfdd\udbc1\uddfd\udb56\udf99\udb84\udd82\ud8ce\udded\uda5c\udd5e",
        57, 90773, -2008671293, -2770296588327327698L, 75430L, true, true, (char) 30308, (char) 5861,
        Double.longBitsToDouble(0x3fe981cdf9b63d16L), Double.longBitsToDouble(0x3fb1d2bc16d6da88L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 4, "\udb8a\udeba\uda95\udd51\ud907\udf93\udbe5\udf46\ud86e\udda6\ud8d0\udf2c\ud82c\udd0f\udb7f\udc4f\ud953\udcbd\ud90d\udd95\udbf1\udfda\udafa\udc66\udbf3\udfa7\uda76\udd4c\udad1\udf4c\udbdb\ude88\udbef\udfd2\udb43\udd57\udb98\udf91", "\ua2f5\u82e4\u1511\u8f6f\u8b90", "\ud922\udc99\ud861\ude0b\ud8c3\udf99\ud939\udcd6\udb26\udcb8\ud928\ude2b\udae2\udf30\ud98c\ude59\udaa1\udf6b\ud9de\udc83\ud920\udf31\uda61\udd8b\ud9a0\udc77\udb29\udd6b\ud93e\udf7f\udb16\udeee\ud8b7\udde3\ud9e1\udcda\udb09\udf63\ud98d\udc9e\ud93d\uddbe\ud80b\ude3b\ud9bf\udcc1\ud98b\udf4e\udb46\udf6c\ud845\udcfd\udb45\udec9\ud8bd\udc91\udbe4\udda2\ud939\udc52\udbbc\udc51\ud8c2\udeb7\ud8c8\udfd4\udabb\udd41\udad2\udc15\uda72\udca3\udb7b\udfc2\ud8ab\udf4b\udbce\udf88\uda86\uddde\ud80c\udff9\udb0b\ude27\udb14\udf90\ud833\udcb2\uda84\ude79\ud956\ude56\uda97\udd16\ud8c0\ude57\udab8\udebd\uda85\udd56\udbc3\udd10\udb3b\udd0b\u8db8\u9a0b\ud904\udf65\uda19\udc3c\udacc\udfa5\u45f7\udaf2\udc88\udba5\udeb3\ud834\udd3e\u8f69\ud9fc\udc92\udb76\udcde\ud8bb\udf74\ud909\udf1f\ud993\udca6\ud9f7\udecb\udb58\udfe7\udaf5\udecd\ud873\ude49\udb2f\udf53\uda0b\udcd7\uda9a\uddc0\udb5d\udcd9\ud8df\udf3a\udb52\udf00\uda48\udfe3\uda4b\uded4\u2df2\uda34\udfd0\udb1a\udc2f\ud87d\udc39\ud95d\udeb6\ud865\udc89\ud9d1\udec2\ud850\udde0\udb6c\udd15\udb55\ude72\ud2e6\uda9c\udf53\udaba\uddb2\udb8b\udfb5\uda47\udfee\ud8d0\udcfc\udbf9\ude94\ud92a\ude0a\udb06\udc85\uda0d\udf95\udb86\udd0f\ucc6c\ud8fd\udeb4\ud8c1\udc6c\uda44\udc46\uda49\ude93\udac4\udee6\udb17\udefb\ud9d4\udd3f\ud898\uddc6\udb9e\udf30\udbdd\udc83\ud8ae\udc1a\udabb\udef3",
        19, 40973, 1211545974, 3227284725252952175L, -29937L, true, false, (char) 54532, (char) 12674,
        Double.longBitsToDouble(0x3fed5bd596dfd510L), Double.longBitsToDouble(0x3fe7ce3ac600968aL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 4, "\udb8a\udeba\uda95\udd51\ud907\udf93\udbe5\udf46\ud86e\udda6\ud8d0\udf2c\ud82c\udd0f\udb7f\udc4f\ud953\udcbd\ud930\udc95\udbf1\udfda\udafa\udc66\udbf3\udfa7\uda76\udd4c\udad1\udf4c\udbdb\ude88\udbef\udfd2\udb43\udd57\udb98\udf91", "\ua2f5\u82e4\u1511\u8f6f\uba88", "\ud922\udc99\ud861\ude0b\ud8c3\udf99\udbcf\uddc9\udb26\udcb8\ud928\ude2b\udae2\udf30\ud98c\ude59\udaa1\udf6b\ud9de\udc83\ud920\udf31\uda61\udd8b\ud9a0\udc77\udb29\udd6b\ud93e\udf7f\udb00\udc2e\ud8b7\udde3\ud9e1\udcda\udb09\udf63\ud98d\udc9e\ud93d\uddbe\ud80b\ude3b\ud9bf\udcc1\ud98b\udf4e\udb46\udf6c\ud845\udcfd\udb45\udec9\ud8bd\udc91\udbe4\udda2\ud939\udc52\udbbc\udc51\ud8c2\udeb7\ud8c8\udfd4\udabb\udd41\udad2\udc15\uda72\udca3\udb7b\udfc2\ud8ab\udf4b\udbce\udf88\uda86\uddde\ud80c\udff9\udb0b\ude27\udb14\udf90\ud94a\udfbd\uda83\udfff\ud956\ude56\uda97\udd16\ud8c0\ude57\udab8\udebd\uda85\udd56\udbc3\udd10\udb3b\udd0b\u8db8\u9a0b\ud904\udf65\uda19\udc3c\udacc\udfa5\u45f7\udaf2\udc88\udba5\udeb3\ud834\udd3e\u8f69\ud9fc\udc92\udb76\udcde\ud8bb\udf74\ud909\udf1f\ud993\udca6\ud9f7\udecb\udb58\udfe7\udaf5\udecd\ud873\ude49\udb2f\udf53\uda0b\udcd7\uda9a\uddc0\udb5d\udcd9\ud8df\udf3a\udb52\udf00\uda48\udfe3\uda4b\uded4\u2df2\uda34\udfd0\udb1a\udc2f\ud87d\udc39\ud95d\udeb6\ud865\udc89\ud9d1\udec2\ud850\udde0\udb6c\udd15\udb55\ude72\ud2e6\uda9c\udf53\udaba\uddb2\udb8b\udfb5\uda47\udfee\ud8d0\udcfc\ud91b\ude97\ud92a\ude0a\udb06\udc85\uda0d\udf95\udb86\udd0f\ucc6c\ud8fd\udeb4\ud8c1\udc6c\uda44\udc46\uda49\ude93\udac4\udee6\udb17\udefb\ud9d4\udd3f\ud898\uddc6\udb9e\udf30\udbdd\udc83\ud8ae\udc1a\udabb\udef3\uda73\udd6e\uda20\udfbf\ud9b3\uddb7",
        50, 19295, 2099133568, -1001749998532099579L, -4209L, true, true, (char) 19440, (char) 18002,
        Double.longBitsToDouble(0x3fe004b453705231L), Double.longBitsToDouble(0x3fe033a4a73fec5eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.option.ArgumentImpl|processValues|org.apache.commons.cli2.WriteableCommandLine,java.util.ListIterator,org.apache.commons.cli2.Option|new:org.apache.commons.cli2.option.ArgumentImpl:java.lang.String,java.lang.String,int,int,char,char,org.apache.commons.cli2.validation.Validator,java.lang.String,java.util.List,int",
    "M|org.apache.commons.cli2.WriteableCommandLine|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addProperty|java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addSwitch|org.apache.commons.cli2.Option,boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addValue|org.apache.commons.cli2.Option,java.lang.Object|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|looksLikeOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setDefaultSwitch|org.apache.commons.cli2.Option,java.lang.Boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setDefaultValues|org.apache.commons.cli2.Option,java.util.List|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addProperty|java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addSwitch|org.apache.commons.cli2.Option,boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addValue|org.apache.commons.cli2.Option,java.lang.Object|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getNormalised||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.option.ArgumentImpl|processValues|org.apache.commons.cli2.WriteableCommandLine,java.util.ListIterator,org.apache.commons.cli2.Option|new:org.apache.commons.cli2.option.ArgumentImpl:java.lang.String,java.lang.String,int,int,char,char,org.apache.commons.cli2.validation.Validator,java.lang.String,java.util.List,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
